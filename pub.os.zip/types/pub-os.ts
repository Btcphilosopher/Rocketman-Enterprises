export type AssetType = 
  | 'DRAUGHT_DISPENSER'
  | 'SPIRIT_DISPENSER'
  | 'REFRIGERATOR'
  | 'FREEZER'
  | 'KEG_STORAGE'
  | 'CARD_TERMINAL'
  | 'POS_TILL'
  | 'BEER_PUMP'
  | 'COFFEE_MACHINE'
  | 'DISHWASHER'
  | 'GLASS_WASHER'
  | 'HVAC'
  | 'LIGHTING'
  | 'CELLAR_COOLER';

export type PhysicalLocation = 
  | 'MAIN_BAR'
  | 'LOUNGE_BAR'
  | 'CELLAR'
  | 'COLD_STORAGE'
  | 'WAREHOUSE'
  | 'KITCHEN'
  | 'TABLE_AREA'
  | 'DELIVERY_ENTRANCE';

export interface PhysicalAsset {
  asset_id: string;
  asset_type: AssetType;
  name: string;
  manufacturer: string;
  model: string;
  serial_number: string;
  location: PhysicalLocation;
  status: 'OPERATIONAL' | 'WARNING' | 'FAULT' | 'MAINTENANCE' | 'OFFLINE';
  installation_date: string;
  maintenance_state: {
    last_service: string;
    next_due: string;
    health_score: number; // 0 - 100
    failure_probability: number; // 0 - 1
    remaining_useful_life_days: number;
  };
  energy_state: {
    power_kw: number;
    voltage: number;
    current_amp: number;
    daily_kwh: number;
  };
  sensor_state: {
    temperature_c?: number;
    pressure_bar?: number;
    flow_ml_s?: number;
    vibration_hz?: number;
  };
}

export type ProductCategory = 
  | 'DRAUGHT_BEER'
  | 'BOTTLED_BEER'
  | 'CIDER'
  | 'WINE'
  | 'SPIRITS'
  | 'SOFT_DRINKS'
  | 'MIXERS'
  | 'COFFEE'
  | 'TEA'
  | 'FOOD'
  | 'SNACKS'
  | 'INGREDIENTS'
  | 'CLEANING_PRODUCTS'
  | 'CONSUMABLES'
  | 'PACKAGING';

export interface Product {
  product_id: string;
  SKU: string;
  name: string;
  category: ProductCategory;
  brand: string;
  supplier_id: string;
  unit: string; // e.g., 'pint', 'L', 'bottle', 'kg'
  purchase_price: number; // £
  selling_price: number; // £
  vat_rate: number; // e.g. 0.20
  container_size_litres?: number;
  alcohol_abv?: number;
  storage_requirement: 'CELLAR_COLD' | 'REFRIGERATED' | 'FROZEN' | 'DRY_STORAGE';
  minimum_stock: number;
  maximum_stock: number;
  reorder_point: number;
  lead_time_days: number;
  shelf_life_days: number;
  density_g_ml: number; // Density for precision mass-volume calculation (e.g. 1.015 for stout)
}

export interface KegTwin {
  keg_id: string;
  product_id: string;
  product_name: string;
  batch_id: string;
  supplier_id: string;
  capacity_litres: number; // e.g. 50.0 or 30.0
  current_volume_litres: number; // e.g. 38.42
  initial_volume_litres: number;
  temperature_c: number;
  pressure_bar: number;
  location: PhysicalLocation;
  connected: boolean;
  tap_id?: string;
  installation_time: string;
  quality_state: 'OPTIMAL' | 'DEGRADED' | 'EXPIRED' | 'FOAMING';
  
  // Derived physics calculations
  litres_remaining: number;
  pints_remaining: number;
  estimated_sales_remaining_gbp: number;
  estimated_remaining_hours: number;
}

export type FlowProfileStage = 'START' | 'RAMP' | 'STEADY_FLOW' | 'REDUCE_FLOW' | 'STOP';

export interface NozzleController {
  nozzle_id: string;
  tap_number: number;
  bar_id: string;
  product_id: string;
  product_name: string;
  keg_id: string;
  device_id: string;
  target_volume_ml: number;
  actual_volume_ml: number;
  current_flow_rate_ml_s: number;
  stage: FlowProfileStage;
  pressure_bar: number;
  temperature_c: number;
  calibration_factor: number;
  valve_open: boolean;
}

export type PourState = 
  | 'ORDER_CREATED'
  | 'PAYMENT_AUTHORISED'
  | 'PRODUCT_ALLOCATED'
  | 'POUR_REQUESTED'
  | 'DISPENSER_READY'
  | 'POUR_STARTED'
  | 'FLOW_MEASURED'
  | 'TARGET_APPROACHED'
  | 'POUR_STOPPED'
  | 'VOLUME_VALIDATED'
  | 'SALE_COMPLETED'
  | 'INVENTORY_UPDATED'
  | 'POUR_FAILED';

export interface LiquidMeasurement {
  measurement_id: string;
  nozzle_id: string;
  timestamp: string;
  product_id: string;
  keg_id: string;
  flow_rate_ml_s: number;
  volume_ml: number;
  mass_g: number;
  temperature_c: number;
  pressure_bar: number;
  density_g_ml: number;
  duration_s: number;
  confidence: number;
  calibration_state: 'VALID' | 'CALIBRATION_REQUIRED' | 'DRIFT_DETECTED';
}

export interface PourEvent {
  pour_id: string;
  timestamp: string;
  nozzle_id: string;
  bartender_id: string;
  product_id: string;
  product_name: string;
  keg_id: string;
  target_volume_ml: number;
  actual_volume_ml: number;
  error_volume_ml: number;
  error_percent: number;
  duration_s: number;
  avg_flow_ml_s: number;
  peak_flow_ml_s: number;
  temperature_c: number;
  pressure_bar: number;
  pour_state: PourState;
  sale_price_gbp: number;
  variance_classification: 'MEASUREMENT_ERROR' | 'PROCESS_VARIANCE' | 'EXPECTED_WASTE' | 'UNEXPLAINED_VARIANCE' | 'POTENTIAL_SHRINKAGE';
}

export type StockEventType = 
  | 'STOCK_RECEIVED'
  | 'STOCK_TRANSFERRED'
  | 'STOCK_DISPENSED'
  | 'STOCK_SOLD'
  | 'STOCK_WASTED'
  | 'STOCK_SPOILED'
  | 'STOCK_RETURNED'
  | 'STOCK_ADJUSTED'
  | 'STOCK_COUNTED'
  | 'STOCK_CORRECTED';

export interface StockLedgerEntry {
  entry_id: string;
  timestamp: string;
  product_id: string;
  product_name: string;
  event_type: StockEventType;
  quantity_units: number;
  volume_litres?: number;
  unit_cost_gbp: number;
  total_value_gbp: number;
  source_location: PhysicalLocation;
  destination_location?: PhysicalLocation;
  reference_id?: string; // order_id or pour_id or po_id
  notes?: string;
}

export interface Supplier {
  supplier_id: string;
  name: string;
  lead_time_days: number;
  minimum_order_gbp: number;
  delivery_schedule: string;
  reliability_score: number; // 0-100
  invoice_accuracy_score: number; // 0-100
  historical_price_variance_pct: number;
  active_products: string[];
}

export interface PurchaseOrderLine {
  product_id: string;
  product_name: string;
  ordered_quantity: number;
  received_quantity?: number;
  unit_price_gbp: number;
  line_total_gbp: number;
}

export type POStatus = 'RECOMMENDED' | 'APPROVED' | 'ORDERED' | 'RECEIVED' | 'INVOICED' | 'MATCHED' | 'DISCREPANCY';

export interface PurchaseOrder {
  po_id: string;
  supplier_id: string;
  supplier_name: string;
  created_at: string;
  expected_delivery: string;
  status: POStatus;
  lines: PurchaseOrderLine[];
  subtotal_gbp: number;
  tax_gbp: number;
  total_gbp: number;
  three_way_match: {
    po_matched: boolean;
    grn_matched: boolean;
    invoice_matched: boolean;
    discrepancy_details?: string;
  };
}

export interface DoubleEntryAccount {
  account_code: string;
  account_name: string;
  type: 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';
  balance_gbp: number;
}

export interface JournalEntry {
  journal_id: string;
  timestamp: string;
  description: string;
  debit_account: string;
  credit_account: string;
  amount_gbp: number;
  reference_event_id: string;
}

export type EmployeeRole = 'BAR' | 'KITCHEN' | 'MANAGER' | 'CLEANING' | 'MAINTENANCE' | 'SUPERVISOR' | 'DELIVERY' | 'ADMIN';

export interface Employee {
  employee_id: string;
  name: string;
  role: EmployeeRole;
  employment_state: 'ACTIVE' | 'ON_LEAVE' | 'TERMINATED';
  pay_rate_hourly_gbp: number;
  contract_hours_weekly: number;
  skills: string[];
  clocked_in: boolean;
  current_shift_start?: string;
}

export interface ShiftRecord {
  shift_id: string;
  employee_id: string;
  employee_name: string;
  role: EmployeeRole;
  clock_in: string;
  clock_out?: string;
  break_minutes: number;
  hours_worked: number;
  regular_pay_gbp: number;
  overtime_pay_gbp: number;
  total_employer_cost_gbp: number;
}

export interface TelemetryReading {
  sensor_id: string;
  asset_id: string;
  asset_name: string;
  timestamp: string;
  metric_name: string;
  value: number;
  unit: string;
  quality: 'VALID' | 'ESTIMATED' | 'STALE' | 'CALIBRATION_REQUIRED' | 'SENSOR_FAULT';
  normal_min?: number;
  normal_max?: number;
}

export interface MaintenancePrediction {
  asset_id: string;
  asset_name: string;
  failure_probability: number;
  remaining_useful_life_days: number;
  confidence_pct: number;
  evidence: string[];
  recommended_action: string;
  expected_economic_effect_gbp: number;
}

export interface ForecastPoint {
  time_label: string;
  actual_sales_gbp?: number;
  forecast_sales_gbp: number;
  confidence_lower_gbp: number;
  confidence_upper_gbp: number;
  predicted_customer_count: number;
  predicted_pint_demand: number;
}

export interface MonteCarloScenario {
  scenario_id: string;
  name: string;
  iterations: number;
  avg_revenue_gbp: number;
  avg_profit_gbp: number;
  stockout_probability_pct: number;
  waste_cost_gbp: number;
  p5_profit_gbp: number;
  p95_profit_gbp: number;
}

export type AutomationLevel = 0 | 1 | 2 | 3;
// Level 0 = MONITOR, Level 1 = RECOMMEND, Level 2 = APPROVAL, Level 3 = AUTONOMOUS

export interface OperationalAlert {
  alert_id: string;
  timestamp: string;
  severity: 'INFO' | 'NOTICE' | 'WARNING' | 'CRITICAL';
  title: string;
  message: string;
  subsystem: 'CELLAR' | 'POURING' | 'STOCK' | 'PROCUREMENT' | 'FINANCE' | 'WORKFORCE' | 'ENERGY' | 'EQUIPMENT' | 'ML_DRIFT';
  acknowledged: boolean;
  action_recommendation?: string;
}

export interface PubTwin {
  pub_id: string;
  pub_name: string;
  address: string;
  automation_level: AutomationLevel;
  live_simulation_active: boolean;
  
  // Physical Infrastructure & Assets
  assets: PhysicalAsset[];
  
  // Product Master & Stock Physics
  products: Product[];
  kegs: KegTwin[];
  nozzles: NozzleController[];
  stock_ledger: StockLedgerEntry[];
  
  // Commercial & Operations
  suppliers: Supplier[];
  purchase_orders: PurchaseOrder[];
  pours_history: PourEvent[];
  
  // Financial double entry
  accounts: DoubleEntryAccount[];
  journal_entries: JournalEntry[];
  
  // Workforce
  employees: Employee[];
  active_shifts: ShiftRecord[];
  
  // IoT Telemetry & Energy
  telemetry: TelemetryReading[];
  maintenance_predictions: MaintenancePrediction[];
  daily_energy_kwh: number;
  daily_energy_cost_gbp: number;
  
  // Intelligence & Forecast
  forecast: ForecastPoint[];
  alerts: OperationalAlert[];
  
  // Real-time Econometrics Summary (Today)
  metrics: {
    revenue_today_gbp: number;
    revenue_forecast_gbp: number;
    variance_pct: number;
    cogs_today_gbp: number;
    gross_margin_pct: number;
    labour_cost_today_gbp: number;
    labour_pct: number;
    energy_cost_today_gbp: number;
    waste_cost_today_gbp: number;
    waste_pct: number;
    operating_profit_today_gbp: number;
    total_litres_dispensed_today: number;
    pints_sold_today: number;
    pour_variance_pct: number;
    customer_count_today: number;
    sales_per_staff_hour_gbp: number;
    inventory_capital_value_gbp: number;
    break_even_pints_daily: number;
  };
}
