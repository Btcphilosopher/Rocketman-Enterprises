'use client';

import React, { useState, useEffect } from 'react';
import { PubTwin } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { HeaderBar } from '@/components/control-room/HeaderBar';
import { DigitalTwinMap } from '@/components/control-room/DigitalTwinMap';
import { PrecisionPouringView } from '@/components/control-room/PrecisionPouringView';
import { KegCellarView } from '@/components/control-room/KegCellarView';
import { PosTerminalView } from '@/components/control-room/PosTerminalView';
import { InventoryLedgerView } from '@/components/control-room/InventoryLedgerView';
import { ProcurementView } from '@/components/control-room/ProcurementView';
import { FinanceView } from '@/components/control-room/FinanceView';
import { WorkforceView } from '@/components/control-room/WorkforceView';
import { TelemetryIoTView } from '@/components/control-room/TelemetryIoTView';
import { RQuantAnalyticsView } from '@/components/control-room/RQuantAnalyticsView';
import { CliTerminalView } from '@/components/control-room/CliTerminalView';
import { AiManagerDrawer } from '@/components/control-room/AiManagerDrawer';

import { 
  Cpu, Droplets, Database, ShoppingBag, Layers, Truck, DollarSign, 
  Users, Activity, LineChart, Terminal, Bot 
} from 'lucide-react';

export default function PubOsControlCenter() {
  const [twin, setTwin] = useState<PubTwin>(pubStore.getState());
  const [activeTab, setActiveTab] = useState<
    'MAP' | 'POURING' | 'CELLAR' | 'POS' | 'STOCK' | 'PROCUREMENT' | 'FINANCE' | 'WORKFORCE' | 'IOT' | 'R_QUANT' | 'CLI'
  >('MAP');
  const [selectedTapNumber, setSelectedTapNumber] = useState<number>(1);
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState<boolean>(false);

  useEffect(() => {
    const unsubscribe = pubStore.subscribe(() => {
      setTwin({ ...pubStore.getState() });
    });

    const interval = setInterval(() => {
      pubStore.tickTelemetry();
    }, 3000);

    return () => {
      unsubscribe();
      clearInterval(interval);
    };
  }, []);

  const handleSelectTapFromMap = (tapNum: number) => {
    setSelectedTapNumber(tapNum);
    setActiveTab('POURING');
  };

  return (
    <div className="min-h-screen bg-[#050505] text-[#e0e0e0] font-sans flex flex-col selection:bg-green-500 selection:text-[#050505]">
      
      {/* Top Header & Real-Time Economic Ribbon */}
      <HeaderBar twin={twin} onOpenAiManager={() => setIsAiDrawerOpen(true)} />

      {/* Main Subsystem Navigation Tabs */}
      <nav className="bg-[#0a0a0a] border-b border-[#222] px-6 py-2.5 overflow-x-auto font-mono text-xs flex items-center gap-1 scrollbar-none sticky top-[73px] z-30 backdrop-blur-md">
        {[
          { id: 'MAP', label: 'Digital Twin Map', icon: Cpu },
          { id: 'POURING', label: 'Precision Pouring', icon: Droplets },
          { id: 'CELLAR', label: 'Kegs & Cellar', icon: Database },
          { id: 'POS', label: 'POS Terminal', icon: ShoppingBag },
          { id: 'STOCK', label: 'Stock Physics', icon: Layers },
          { id: 'PROCUREMENT', label: 'Procurement', icon: Truck },
          { id: 'FINANCE', label: 'Finance Ledger', icon: DollarSign },
          { id: 'WORKFORCE', label: 'Workforce Rota', icon: Users },
          { id: 'IOT', label: 'IoT Telemetry', icon: Activity },
          { id: 'R_QUANT', label: 'R Quant ML', icon: LineChart },
          { id: 'CLI', label: 'CLI Simulator', icon: Terminal }
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center space-x-2 px-3 py-2 border-l-2 text-sm transition whitespace-nowrap ${
                isActive
                  ? 'bg-[#111] border-green-500 text-white font-medium'
                  : 'border-transparent text-[#666] hover:text-white hover:bg-[#111]/50'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-green-500' : 'text-[#666]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Primary Subsystem Viewport */}
      <main className="flex-1 p-6 max-w-[1700px] w-full mx-auto space-y-6 bg-[#050505]">
        
        {activeTab === 'MAP' && (
          <DigitalTwinMap twin={twin} onSelectTap={handleSelectTapFromMap} />
        )}

        {activeTab === 'POURING' && (
          <PrecisionPouringView twin={twin} selectedTapNumber={selectedTapNumber} />
        )}

        {activeTab === 'CELLAR' && (
          <KegCellarView twin={twin} />
        )}

        {activeTab === 'POS' && (
          <PosTerminalView twin={twin} onPourCompleted={() => setTwin({ ...pubStore.getState() })} />
        )}

        {activeTab === 'STOCK' && (
          <InventoryLedgerView twin={twin} />
        )}

        {activeTab === 'PROCUREMENT' && (
          <ProcurementView twin={twin} />
        )}

        {activeTab === 'FINANCE' && (
          <FinanceView twin={twin} />
        )}

        {activeTab === 'WORKFORCE' && (
          <WorkforceView twin={twin} />
        )}

        {activeTab === 'IOT' && (
          <TelemetryIoTView twin={twin} />
        )}

        {activeTab === 'R_QUANT' && (
          <RQuantAnalyticsView twin={twin} />
        )}

        {activeTab === 'CLI' && (
          <CliTerminalView twin={twin} />
        )}

      </main>

      {/* AI Pub Manager Drawer */}
      <AiManagerDrawer twin={twin} isOpen={isAiDrawerOpen} onClose={() => setIsAiDrawerOpen(false)} />

      {/* Footer Status Bar */}
      <footer className="bg-[#0a0a0a] border-t border-[#222] px-6 py-4 font-mono text-xs text-[#888] flex flex-col sm:flex-row justify-between items-center gap-2">
        <div className="flex items-center gap-3">
          <span className="w-3 h-3 bg-green-500 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
          <span>PUB.OS CYBER-PHYSICAL ENGINE RUNNING <span className="text-[#444]">|</span> <span className="text-white">v4.2.0_RUST_CORE</span></span>
        </div>
        <div className="flex items-center gap-6 text-[11px]">
          <div>Automation Governance: <span className="text-green-400 font-bold">Level {twin.automation_level} ({
            twin.automation_level === 0 ? 'MONITOR' :
            twin.automation_level === 1 ? 'RECOMMEND' :
            twin.automation_level === 2 ? 'APPROVAL' : 'AUTONOMOUS'
          })</span></div>
          <div>Uptime: <span className="text-white font-mono">142:12:04</span></div>
        </div>
      </footer>

    </div>
  );
}
