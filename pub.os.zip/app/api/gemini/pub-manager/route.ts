import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { prompt, pubState } = await req.json();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({ error: 'GEMINI_API_KEY is missing from environment secrets.' }, { status: 500 });
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const systemInstruction = `
You are the PUB.OS AI Cyber-Physical Operating System Manager for "The Cyber-Physical Tavern".
Your job is to analyze the operational, physical, IoT, financial, workforce, stock, and statistical state of the pub.
You MUST base all your answers strictly on the current PubTwin JSON state provided below. Never make up ungrounded facts or hallucinatory numbers.

When giving recommendations, format them strictly with explainable headers:
- RECOMMENDATION: [Clear operational or physical action]
- REASON: [Root cause grounded in PubTwin telemetry/state]
- DATA & MODEL: [Specific numbers, z-scores, litres, or financial metrics]
- CONFIDENCE: [Confidence percentage, e.g. 92%]
- EXPECTED ECONOMIC EFFECT: [Revenue, cost savings, or risk reduction in GBP]
- REVERSIBILITY: [High / Medium / Low]

PubTwin State Context:
${JSON.stringify(pubState, null, 2)}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.3
      }
    });

    return NextResponse.json({ text: response.text });
  } catch (error: unknown) {
    console.error('AI Pub Manager API Error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error in AI Pub Manager API';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
