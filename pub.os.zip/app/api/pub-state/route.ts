import { NextResponse } from 'next/server';
import { pubStore } from '@/lib/pub-store';

export async function GET() {
  const state = pubStore.getState();
  return NextResponse.json(state);
}
