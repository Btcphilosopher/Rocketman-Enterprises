import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'PUB.OS — Cyber-Physical Industry 4.0 Hospitality Operating System',
  description: 'An Industry 4.0 cyber-physical pub operating system combining Rust core state, R statistics, ML forecasting, precision liquid measurement, IoT telemetry, digital twin, POS, workforce, and double-entry finance.',
  openGraph: {
    title: 'PUB.OS — Cyber-Physical Industry 4.0 Hospitality Operating System',
    description: 'An Industry 4.0 cyber-physical pub operating system combining Rust core state, R statistics, ML forecasting, precision liquid measurement, IoT telemetry, digital twin, POS, workforce, and double-entry finance.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'PUB.OS — Cyber-Physical Industry 4.0 Hospitality Operating System',
    description: 'An Industry 4.0 cyber-physical pub operating system combining Rust core state, R statistics, ML forecasting, precision liquid measurement, IoT telemetry, digital twin, POS, workforce, and double-entry finance.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
