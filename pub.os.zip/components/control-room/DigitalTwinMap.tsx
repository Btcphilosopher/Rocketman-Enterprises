'use client';

import React, { useState } from 'react';
import { PubTwin, NozzleController, KegTwin } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { Droplets, Thermometer, ShieldAlert, Cpu, AlertTriangle, CheckCircle2, UserCheck, Flame } from 'lucide-react';

interface DigitalTwinMapProps {
  twin: PubTwin;
  onSelectTap: (tapNum: number) => void;
}

export const DigitalTwinMap: React.FC<DigitalTwinMapProps> = ({ twin, onSelectTap }) => {
  const [selectedZone, setSelectedZone] = useState<'ALL' | 'BAR' | 'CELLAR' | 'TABLES' | 'EQUIPMENT'>('ALL');

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Map Zone Filter Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#222] pb-4">
        <div>
          <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-green-500" />
            <span>Cellar <span className="text-[#444]">/</span> Infrastructure Map <span className="text-green-400 text-xs font-mono ml-2">Live</span></span>
          </h2>
          <p className="text-xs text-[#666] mt-1 font-mono">
            Real-time physical state mirroring 20 precision taps, cellar coolers, refrigeration sensors, and guest nodes.
          </p>
        </div>

        <div className="flex items-center gap-1 bg-[#111] p-1 border border-[#222] text-xs font-mono">
          {(['ALL', 'BAR', 'CELLAR', 'TABLES', 'EQUIPMENT'] as const).map(zone => (
            <button
              key={zone}
              onClick={() => setSelectedZone(zone)}
              className={`px-3 py-1.5 transition ${
                selectedZone === zone
                  ? 'bg-green-500 text-[#050505] font-bold shadow-[0_0_8px_rgba(34,197,94,0.4)]'
                  : 'text-[#666] hover:text-white'
              }`}
            >
              {zone}
            </button>
          ))}
        </div>
      </div>

      {/* Cyber Physical Map Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* MAIN BAR & LOUNGE BAR (Taps 1-20) */}
        {(selectedZone === 'ALL' || selectedZone === 'BAR') && (
          <div className="lg:col-span-7 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white flex items-center gap-2 font-mono uppercase tracking-widest">
                <Droplets className="w-4 h-4 text-green-400" />
                <span>Main Bar & Lounge Dispensing Bank (20 Taps)</span>
              </h3>
              <span className="text-[10px] font-mono text-[#666]">Click tap to pour</span>
            </div>

            {/* Tap Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {twin.nozzles.map((nozzle) => {
                const keg = twin.kegs.find(k => k.tap_id === `TAP-${nozzle.tap_number.toString().padStart(2, '0')}`);
                const pct = keg ? Math.round((keg.current_volume_litres / keg.capacity_litres) * 100) : 0;
                
                let pctBar = 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]';
                if (pct < 15) pctBar = 'bg-red-600 shadow-[0_0_10px_rgba(220,38,38,0.5)] animate-pulse';
                else if (pct < 40) pctBar = 'bg-orange-400 shadow-[0_0_10px_rgba(251,146,60,0.5)]';
                else pctBar = 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]';

                return (
                  <button
                    key={nozzle.nozzle_id}
                    onClick={() => onSelectTap(nozzle.tap_number)}
                    className="bg-[#0a0a0a] border border-[#111] hover:border-green-500/50 p-3 rounded text-left transition transform hover:-translate-y-0.5 relative overflow-hidden group"
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold font-mono text-[#888]">TAP_{nozzle.tap_number.toString().padStart(2, '0')}</span>
                      <span className={`text-[9px] font-mono px-1.5 py-0.2 rounded ${nozzle.valve_open ? 'bg-green-500 text-[#050505] font-bold' : 'bg-[#111] text-[#666]'}`}>
                        {nozzle.valve_open ? 'POURING' : 'READY'}
                      </span>
                    </div>

                    <div className="text-xs font-mono font-medium text-white truncate mb-2">
                      {nozzle.product_name}
                    </div>

                    {keg ? (
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] font-mono text-[#666]">
                          <span>{keg.current_volume_litres.toFixed(1)}L</span>
                          <span className="font-bold text-white">{pct}%</span>
                        </div>
                        <div className="w-full bg-[#222] h-1 rounded-full overflow-hidden">
                          <div className={`h-full ${pctBar} transition-all duration-500`} style={{ width: `${pct}%` }}></div>
                        </div>
                      </div>
                    ) : (
                      <span className="text-[10px] text-[#444] font-mono block">Offline / Clean</span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* CELLAR & COLD STORAGE */}
        {(selectedZone === 'ALL' || selectedZone === 'CELLAR' || selectedZone === 'EQUIPMENT') && (
          <div className="lg:col-span-5 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-white flex items-center gap-2 font-mono uppercase tracking-widest">
                <Thermometer className="w-4 h-4 text-green-400" />
                <span>Cellar Telemetry</span>
              </h3>
              <span className="text-[10px] font-mono text-green-500 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]"></span>
                ACTIVE
              </span>
            </div>

            {/* Cellar Climate Card */}
            <div className="bg-[#0a0a0a] border border-[#111] p-3 rounded space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-white font-medium">Cellar Master Climate</span>
                <span className="text-green-400 font-mono font-bold">4.1°C | 2.15 bar</span>
              </div>
              <div className="text-[11px] text-[#666] font-mono flex justify-between">
                <span>Humidity: 62% RH</span>
                <span>Power: 2.8 kW</span>
              </div>
            </div>

            {/* Refrigerator Alert Unit */}
            <div className="bg-[#0a0a0a] border border-red-900/40 p-3 rounded space-y-1.5">
              <div className="flex justify-between items-center text-xs">
                <span className="text-red-400 font-medium flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-500" />
                  Main Bar Triple Door Chiller
                </span>
                <span className="text-red-500 font-mono font-bold">6.8°C (HIGH)</span>
              </div>
              <p className="text-[11px] text-[#888] leading-relaxed font-mono">
                Predictive Maintenance RUL: 21 days. Compressor vibration +38.2 Hz.
              </p>
            </div>

            {/* Keg Stock Volume Summary List */}
            <div className="space-y-2 pt-2 border-t border-[#1a1a1a]">
              <h4 className="text-[10px] font-bold text-[#666] font-mono uppercase tracking-widest">Active Keg Physical States</h4>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {twin.kegs.map((keg) => (
                  <div key={keg.keg_id} className="bg-[#0a0a0a] border border-[#111] p-2 rounded text-xs flex items-center justify-between font-mono">
                    <div>
                      <span className="text-white font-bold block">{keg.keg_id}</span>
                      <span className="text-[#666] text-[11px]">{keg.product_name}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-white font-bold block">{keg.current_volume_litres.toFixed(2)} L</span>
                      <span className="text-[10px] text-[#444]">~{keg.pints_remaining} pints remaining</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* GUEST TABLES & SEATING ZONE */}
        {(selectedZone === 'ALL' || selectedZone === 'TABLES') && (
          <div className="lg:col-span-12 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-3">
            <h3 className="text-xs font-bold text-white flex items-center gap-2 font-mono uppercase tracking-widest">
              <UserCheck className="w-4 h-4 text-green-400" />
              <span>Pub Seating Nodes (20 Occupancy Nodes)</span>
            </h3>

            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 font-mono text-xs text-center">
              {Array.from({ length: 20 }).map((_, i) => {
                const tableNum = i + 1;
                const isOccupied = tableNum % 2 === 1;
                return (
                  <div
                    key={tableNum}
                    className={`p-2 border ${
                      isOccupied
                        ? 'bg-[#111] border-green-500/40 text-white'
                        : 'bg-[#0a0a0a] border-[#111] text-[#444]'
                    }`}
                  >
                    <span className="block font-bold">T-{tableNum.toString().padStart(2, '0')}</span>
                    <span className="text-[9px] block text-[#666]">{isOccupied ? 'Occupied' : 'Vacant'}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
