'use client';

import React, { useState } from 'react';
import { PubTwin, MonteCarloScenario } from '@/types/pub-os';
import { RQuantEngine, CounterfactualResult } from '@/lib/r-quant-engine';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, AreaChart, Area } from 'recharts';
import { LineChart as LineChartIcon, Play, RefreshCw, Cpu, TrendingUp, Sliders } from 'lucide-react';

interface RQuantAnalyticsViewProps {
  twin: PubTwin;
}

export const RQuantAnalyticsView: React.FC<RQuantAnalyticsViewProps> = ({ twin }) => {
  const [mcResult, setMcResult] = useState<MonteCarloScenario | null>(null);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  // Counterfactual Sliders State
  const [priceDelta, setPriceDelta] = useState<number>(5); // +5%
  const [demandDelta, setDemandDelta] = useState<number>(10); // +10%
  const [staffDelta, setStaffDelta] = useState<number>(1); // +1 staff

  const counterfactual = RQuantEngine.simulateCounterfactual(twin, priceDelta, demandDelta, staffDelta);

  const handleRunMonteCarlo = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const result = RQuantEngine.runMonteCarloSimulation(twin, 1000);
      setMcResult(result);
      setIsSimulating(false);
    }, 400);
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <LineChartIcon className="w-5 h-5 text-green-400" />
          <span>R Quantitative Intelligence Layer <span className="text-[#444] text-xs font-mono ml-2">`pubquant`</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          R-powered econometric stack: ARIMA/ETS demand forecasting, 1,000-run Monte Carlo Pub Simulation, and Counterfactual Digital Twin Time Machine.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* TIME SERIES FORECAST CHART */}
        <div className="lg:col-span-12 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center font-mono">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <span>R ARIMA/ETS Revenue & Pint Demand Forecast</span>
            </h3>
            <span className="text-xs text-green-400 font-bold">Model: ARIMA(2,1,1) + Seasonality</span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={twin.forecast}>
                <XAxis dataKey="time_label" stroke="#444" fontSize={11} tick={{ fill: '#666' }} />
                <YAxis stroke="#444" fontSize={11} tick={{ fill: '#666' }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0a0a0a', borderColor: '#222', borderRadius: '4px', color: '#fff', fontFamily: 'monospace', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="confidence_upper_gbp" stroke="transparent" fill="#22c55e" fillOpacity={0.05} />
                <Area type="monotone" dataKey="forecast_sales_gbp" stroke="#888" fill="#888" fillOpacity={0.15} name="Forecast Revenue (£)" />
                <Line type="monotone" dataKey="actual_sales_gbp" stroke="#22c55e" strokeWidth={2} name="Actual Revenue (£)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* MONTE CARLO PUB SIMULATOR */}
        <div className="lg:col-span-6 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center font-mono">
            <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
              <Cpu className="w-4 h-4 text-green-400" />
              <span>1,000-Iteration Monte Carlo Simulator</span>
            </h3>

            <button
              disabled={isSimulating}
              onClick={handleRunMonteCarlo}
              className="bg-green-500 hover:bg-green-400 text-[#050505] font-mono font-bold text-xs px-3 py-1.5 rounded flex items-center gap-1.5 transition shadow-[0_0_10px_rgba(34,197,94,0.3)]"
            >
              <Play className="w-3.5 h-3.5 fill-[#050505]" />
              <span>{isSimulating ? 'Simulating...' : 'Run 1,000 Runs'}</span>
            </button>
          </div>

          {mcResult ? (
            <div className="bg-[#0a0a0a] border border-[#111] p-4 rounded space-y-3 font-mono text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[#666] text-[9px] block uppercase tracking-wider">EXPECTED REVENUE</span>
                  <span className="text-green-400 font-bold text-sm">£{mcResult.avg_revenue_gbp.toFixed(2)}</span>
                </div>

                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[#666] text-[9px] block uppercase tracking-wider">EXPECTED PROFIT</span>
                  <span className="text-white font-bold text-sm">£{mcResult.avg_profit_gbp.toFixed(2)}</span>
                </div>

                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[#666] text-[9px] block uppercase tracking-wider">STOCKOUT RISK %</span>
                  <span className="text-red-400 font-bold text-sm">{mcResult.stockout_probability_pct}%</span>
                </div>

                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[#666] text-[9px] block uppercase tracking-wider">P5-P95 PROFIT BAND</span>
                  <span className="text-white font-bold text-xs">£{mcResult.p5_profit_gbp} – £{mcResult.p95_profit_gbp}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#0a0a0a] border border-dashed border-[#222] p-8 rounded text-center text-[#666] text-xs font-mono">
              Click &quot;Run 1,000 Runs&quot; to execute synthetic pub stochastic iterations.
            </div>
          )}
        </div>

        {/* COUNTERFACTUAL & DIGITAL TWIN TIME MACHINE */}
        <div className="lg:col-span-6 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
            <Sliders className="w-4 h-4 text-green-400" />
            <span>Counterfactual &quot;What-If&quot; Time Machine</span>
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#666] text-[10px] uppercase">Price Shift:</span>
                <span className="text-green-400 font-bold">{priceDelta > 0 ? '+' : ''}{priceDelta}%</span>
              </div>
              <input
                type="range"
                min="-20"
                max="30"
                value={priceDelta}
                onChange={(e) => setPriceDelta(Number(e.target.value))}
                className="w-full accent-green-500"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-[#666] text-[10px] uppercase">Demand Customer Shift:</span>
                <span className="text-white font-bold">{demandDelta > 0 ? '+' : ''}{demandDelta}%</span>
              </div>
              <input
                type="range"
                min="-30"
                max="50"
                value={demandDelta}
                onChange={(e) => setDemandDelta(Number(e.target.value))}
                className="w-full accent-green-500"
              />
            </div>

            <div className="bg-[#0a0a0a] p-3 rounded border border-[#111] space-y-2">
              <span className="text-white font-bold block">{counterfactual.scenario_name}</span>
              <div className="flex justify-between text-[#888]">
                <span>Simulated Revenue:</span>
                <span className="text-green-400 font-bold">£{counterfactual.simulated_revenue_gbp.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-[#888]">
                <span>Simulated Profit:</span>
                <span className="text-white font-bold">£{counterfactual.simulated_profit_gbp.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold text-xs pt-1 border-t border-[#222]">
                <span>Net Profit Delta:</span>
                <span className={counterfactual.delta_profit_gbp >= 0 ? 'text-green-400' : 'text-red-400'}>
                  {counterfactual.delta_profit_gbp >= 0 ? '+' : ''}£{counterfactual.delta_profit_gbp.toFixed(2)}
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
