'use client';

import React, { useState } from 'react';
import { PubTwin } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { Truck, CheckCircle2, ShieldCheck, AlertTriangle, ShoppingCart, Plus } from 'lucide-react';

interface ProcurementViewProps {
  twin: PubTwin;
}

export const ProcurementView: React.FC<ProcurementViewProps> = ({ twin }) => {
  const [selectedSupplier, setSelectedSupplier] = useState<string>('SUP-001');
  const [selectedProduct, setSelectedProduct] = useState<string>('PRD-001');
  const [orderQty, setOrderQty] = useState<number>(6);

  const handleCreatePo = () => {
    pubStore.createPurchaseOrder(selectedSupplier, selectedProduct, orderQty);
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <Truck className="w-5 h-5 text-green-400" />
          <span>Automated Procurement <span className="text-[#444] text-xs font-mono ml-2">3-Way Matching Engine</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          Industry 4.0 3-Way Matching Engine: Purchase Order $\leftrightarrow$ Goods Received Note $\leftrightarrow$ Supplier Invoice.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* SUPPLIER SCORECARDS */}
        <div className="lg:col-span-7 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest">Active Supplier Performance Scorecards</h3>

          <div className="space-y-3">
            {twin.suppliers.map(sup => (
              <div key={sup.supplier_id} className="bg-[#0a0a0a] border border-[#111] p-4 rounded space-y-2 font-mono text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-sm">{sup.name}</span>
                  <span className="bg-[#111] border border-green-500/40 text-green-400 px-2 py-0.5 rounded text-[10px] font-bold">
                    Score: {sup.reliability_score}%
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-[#888] text-[11px] pt-1 border-t border-[#111] mt-2">
                  <div>
                    <span className="text-[#444] block text-[9px] uppercase">Lead Time:</span>
                    <span className="text-white">{sup.lead_time_days} Days</span>
                  </div>
                  <div>
                    <span className="text-[#444] block text-[9px] uppercase">Invoice Accuracy:</span>
                    <span className="text-green-400">{sup.invoice_accuracy_score}%</span>
                  </div>
                  <div>
                    <span className="text-[#444] block text-[9px] uppercase">Price Variance:</span>
                    <span className="text-orange-400">±{sup.historical_price_variance_pct}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* PO GENERATOR & 3-WAY MATCHING STREAM */}
        <div className="lg:col-span-5 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest">Generate Purchase Order</h3>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <label className="text-[#666] block mb-1 uppercase tracking-wider text-[10px]">Supplier</label>
              <select
                value={selectedSupplier}
                onChange={(e) => setSelectedSupplier(e.target.value)}
                className="w-full bg-[#111] border border-[#222] text-white rounded p-2 focus:outline-none focus:border-green-500"
              >
                {twin.suppliers.map(s => (
                  <option key={s.supplier_id} value={s.supplier_id}>{s.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#666] block mb-1 uppercase tracking-wider text-[10px]">Product</label>
              <select
                value={selectedProduct}
                onChange={(e) => setSelectedProduct(e.target.value)}
                className="w-full bg-[#111] border border-[#222] text-white rounded p-2 focus:outline-none focus:border-green-500"
              >
                {twin.products.map(p => (
                  <option key={p.product_id} value={p.product_id}>{p.name}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[#666] block mb-1 uppercase tracking-wider text-[10px]">Keg Quantity (50L Units)</label>
              <input
                type="number"
                value={orderQty}
                onChange={(e) => setOrderQty(Number(e.target.value))}
                className="w-full bg-[#111] border border-[#222] text-white rounded p-2 focus:outline-none focus:border-green-500"
              />
            </div>

            <button
              onClick={handleCreatePo}
              className="w-full bg-green-500 hover:bg-green-400 text-[#050505] font-mono font-bold py-2.5 rounded transition uppercase tracking-wider flex items-center justify-center gap-2 shadow-[0_0_12px_rgba(34,197,94,0.4)]"
            >
              <Plus className="w-4 h-4" />
              <span>Create Purchase Order</span>
            </button>
          </div>

          {/* Active POs */}
          <div className="space-y-2 pt-3 border-t border-[#222]">
            <h4 className="text-[10px] font-bold text-[#666] font-mono uppercase tracking-widest">Recent Purchase Orders</h4>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
              {twin.purchase_orders.map(po => (
                <div key={po.po_id} className="bg-[#0a0a0a] p-2.5 rounded text-xs font-mono space-y-1 border border-[#111]">
                  <div className="flex justify-between">
                    <span className="text-white font-bold">{po.po_id}</span>
                    <span className="bg-[#111] text-green-400 border border-green-500/40 px-1.5 py-0.2 text-[9px]">
                      {po.status}
                    </span>
                  </div>
                  <div className="text-[#666] flex justify-between text-[11px]">
                    <span>{po.supplier_name}</span>
                    <span className="text-green-400 font-bold">£{po.total_gbp.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
