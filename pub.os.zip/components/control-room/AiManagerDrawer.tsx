'use client';

import React, { useState } from 'react';
import { PubTwin } from '@/types/pub-os';
import { Bot, X, Send, Sparkles, RefreshCw, CheckCircle2 } from 'lucide-react';

interface AiManagerDrawerProps {
  twin: PubTwin;
  isOpen: boolean;
  onClose: () => void;
}

export const AiManagerDrawer: React.FC<AiManagerDrawerProps> = ({ twin, isOpen, onClose }) => {
  const [prompt, setPrompt] = useState<string>('What physical or financial actions should be taken right now based on current PubTwin telemetry?');
  const [messages, setMessages] = useState<Array<{ sender: 'USER' | 'AI'; text: string }>>([
    {
      sender: 'AI',
      text: `Hello! I am your AI Pub Manager operating under Automation Level ${twin.automation_level}. I continuously query the canonical PubTwin machine state to give grounded, explainable physical and financial recommendations.`
    }
  ]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim() || isLoading) return;

    const userQuery = prompt.trim();
    setMessages(prev => [...prev, { sender: 'USER', text: userQuery }]);
    setPrompt('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/pub-manager', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userQuery,
          pubState: twin
        })
      });

      const data = await res.json();
      if (data.text) {
        setMessages(prev => [...prev, { sender: 'AI', text: data.text }]);
      } else if (data.error) {
        setMessages(prev => [...prev, { sender: 'AI', text: `Error from Gemini API: ${data.error}` }]);
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to query AI Manager API.';
      setMessages(prev => [...prev, { sender: 'AI', text: `Error: ${msg}` }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full max-w-lg bg-[#050505] border-l border-[#222] shadow-2xl z-50 flex flex-col font-sans">
      
      {/* Header */}
      <div className="bg-[#0a0a0a] px-6 py-4 border-b border-[#222] flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Bot className="w-6 h-6 text-green-400" />
          <div>
            <h3 className="text-base font-light tracking-tight text-white">AI Cyber-Physical Pub Manager</h3>
            <span className="text-[10px] text-green-400 font-mono">Grounded in PubTwin Machine State</span>
          </div>
        </div>
        <button onClick={onClose} className="text-[#666] hover:text-white transition p-1">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Message Chat List */}
      <div className="flex-1 p-6 overflow-y-auto space-y-4 font-mono text-xs">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`p-4 rounded border leading-relaxed ${
              m.sender === 'USER'
                ? 'bg-[#111] border-green-500/40 text-green-400 ml-8'
                : 'bg-[#0a0a0a] border-[#222] text-[#e0e0e0] mr-4 shadow-lg'
            }`}
          >
            <div className="text-[9px] text-[#666] font-bold uppercase mb-1 tracking-wider">
              {m.sender === 'USER' ? 'Operator Query' : 'AI Pub Manager Recommendation'}
            </div>
            <div className="whitespace-pre-wrap font-sans text-xs">{m.text}</div>
          </div>
        ))}

        {isLoading && (
          <div className="bg-[#0a0a0a] border border-[#222] p-4 rounded text-[#888] flex items-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin text-green-400" />
            <span>Analyzing PubTwin telemetry & econometric models...</span>
          </div>
        )}
      </div>

      {/* Input Form */}
      <form onSubmit={handleSendMessage} className="p-4 border-t border-[#222] bg-[#0a0a0a] flex gap-2">
        <input
          type="text"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Ask AI Pub Manager..."
          className="flex-1 bg-[#050505] border border-[#222] text-white rounded px-3 py-2 text-xs focus:outline-none focus:border-green-500 font-mono"
        />
        <button
          type="submit"
          disabled={isLoading}
          className="bg-green-500 hover:bg-green-400 text-[#050505] font-mono font-bold px-4 py-2 rounded text-xs transition flex items-center gap-1 shadow-[0_0_10px_rgba(34,197,94,0.3)]"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Ask</span>
        </button>
      </form>

    </div>
  );
};
