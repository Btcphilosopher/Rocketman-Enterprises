'use client';

import React from 'react';
import { PubTwin } from '@/types/pub-os';
import { Database, AlertOctagon, ShieldCheck, Thermometer, Droplets, Clock } from 'lucide-react';

interface KegCellarViewProps {
  twin: PubTwin;
}

export const KegCellarView: React.FC<KegCellarViewProps> = ({ twin }) => {
  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
            <Database className="w-5 h-5 text-green-400" />
            <span>Cellar <span className="text-[#444]">/</span> Cold Storage Live</span>
          </h2>
          <p className="text-xs text-[#666] mt-1 font-mono">
            Exact physical volume tracking (Keg A = 38.42L, Keg B = 11.73L). Stock is modeled as continuous liquid physics.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <div className="bg-[#111] border border-[#222] px-3 py-1.5 text-[#888]">
            TEMP: <span className="font-bold text-white">4.2°C</span>
          </div>
          <div className="bg-[#111] border border-[#222] px-3 py-1.5 text-[#888]">
            PRESS: <span className="font-bold text-white">2.15 bar</span>
          </div>
        </div>
      </div>

      {/* Keg Twin Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {twin.kegs.map((keg) => {
          const pct = Math.round((keg.current_volume_litres / keg.capacity_litres) * 100);
          
          let barStyle = 'bg-blue-500 shadow-[0_0_10px_rgba(59,130,246,0.5)]';
          if (pct < 15) barStyle = 'bg-red-600 shadow-[0_0_10px_rgba(220,38,38,0.5)]';
          else if (pct < 40) barStyle = 'bg-orange-400 shadow-[0_0_10px_rgba(251,146,60,0.5)]';
          else barStyle = 'bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.5)]';

          return (
            <div key={keg.keg_id} className={`bg-[#0a0a0a] border border-[#111] p-4 flex flex-col justify-between relative overflow-hidden ${pct < 15 ? 'border-red-900/40' : ''}`}>
              <div className="flex justify-between items-start mb-2">
                <div>
                  <span className={`text-[10px] font-mono ${pct < 15 ? 'text-red-500' : 'text-[#666]'}`}>{keg.keg_id} // {keg.product_name.toUpperCase()}</span>
                  <div className={`text-3xl font-mono mt-1 ${pct < 15 ? 'text-red-500' : 'text-white'}`}>
                    {keg.current_volume_litres.toFixed(1)}<span className="text-xs text-[#444] ml-1">L</span>
                  </div>
                </div>
                <span className={`text-[9px] font-mono px-2 py-0.5 border ${
                  keg.quality_state === 'OPTIMAL'
                    ? 'bg-[#111] text-green-400 border-green-500/30'
                    : 'bg-red-950/40 text-red-400 border-red-800/40'
                }`}>
                  {keg.quality_state}
                </span>
              </div>

              {/* Exact Physical Liquid Gauge */}
              <div className="space-y-1 font-mono my-2">
                <div className="h-1 bg-[#222] mt-3 rounded-full overflow-hidden">
                  <div className={`h-full ${barStyle}`} style={{ width: `${pct}%` }}></div>
                </div>

                <div className="text-[9px] text-[#444] mt-2 flex justify-between">
                  <span>PRESS: {keg.pressure_bar} BAR</span>
                  <span>EST: {keg.estimated_remaining_hours}h</span>
                </div>
              </div>

              {/* Keg Physics Metadata */}
              <div className="bg-[#111] p-2.5 text-xs font-mono space-y-1 text-[#888] border border-[#222] mt-2">
                <div className="flex justify-between">
                  <span>Tap Line:</span>
                  <span className="text-white">{keg.tap_id || 'Cellar Reserve'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Est. Sales Value:</span>
                  <span className="text-green-400 font-bold">£{keg.estimated_sales_remaining_gbp.toFixed(2)}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
