'use client';

import React from 'react';
import { PubTwin } from '@/types/pub-os';
import { Layers, FileText, CheckCircle2, AlertCircle, ArrowUpRight, Scale } from 'lucide-react';

interface InventoryLedgerViewProps {
  twin: PubTwin;
}

export const InventoryLedgerView: React.FC<InventoryLedgerViewProps> = ({ twin }) => {
  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <Layers className="w-5 h-5 text-green-400" />
          <span>Stock Reconciliation Engine <span className="text-[#444] text-xs font-mono ml-2">Stock Physics</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          Stock Reconciliation Equation: $Opening + Purchases - Dispensed - Waste - Returns = Closing$. Physical liquid stock is measured directly rather than inferred from sales.
        </p>
      </div>

      {/* Reconciliation Equation KPI Banner */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3 font-mono text-xs text-center">
        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-[#666] text-[9px] block uppercase tracking-wider">OPENING STOCK</span>
          <span className="text-white font-bold text-sm">1,280.0 L</span>
          <span className="text-[10px] text-[#444] block">£14,250.00</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-green-500 text-[9px] block uppercase tracking-wider">+ PURCHASES</span>
          <span className="text-green-400 font-bold text-sm">+300.0 L</span>
          <span className="text-[10px] text-green-500/80 block">+£750.00</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-blue-400 text-[9px] block uppercase tracking-wider">- DISPENSED</span>
          <span className="text-blue-400 font-bold text-sm">-{twin.metrics.total_litres_dispensed_today} L</span>
          <span className="text-[10px] text-blue-500/80 block">-£{twin.metrics.cogs_today_gbp.toFixed(2)}</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-orange-400 text-[9px] block uppercase tracking-wider">- WASTE & SPOILAGE</span>
          <span className="text-orange-400 font-bold text-sm">-14.2 L</span>
          <span className="text-[10px] text-orange-500/80 block">-£82.00</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-green-500/40">
          <span className="text-green-400 text-[9px] block uppercase tracking-wider font-bold">= CLOSING PHYSICAL</span>
          <span className="text-green-400 font-bold text-sm">{(1280 + 300 - twin.metrics.total_litres_dispensed_today - 14.2).toFixed(1)} L</span>
          <span className="text-[10px] text-green-500 block font-bold">100% Reconciled</span>
        </div>
      </div>

      {/* Immutable Stock Movement Event Stream */}
      <div className="bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
        <div className="flex justify-between items-center font-mono">
          <h3 className="text-xs font-bold text-white uppercase tracking-widest flex items-center gap-2">
            <FileText className="w-4 h-4 text-green-400" />
            <span>Immutable Operational Stock Movement Events</span>
          </h3>
          <span className="text-xs text-[#666]">{twin.stock_ledger.length} Logged Events</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#222] text-[#666] text-[9px] uppercase tracking-wider">
                <th className="p-2">Event ID</th>
                <th className="p-2">Timestamp</th>
                <th className="p-2">Type</th>
                <th className="p-2">Product</th>
                <th className="p-2 text-right">Volume (L)</th>
                <th className="p-2 text-right">Value (£)</th>
                <th className="p-2">Location</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#111] text-[#888]">
              {twin.stock_ledger.map(entry => (
                <tr key={entry.entry_id} className="hover:bg-[#0a0a0a]">
                  <td className="p-2 text-white font-bold">{entry.entry_id}</td>
                  <td className="p-2 text-[#444]">{new Date(entry.timestamp).toLocaleTimeString()}</td>
                  <td className="p-2">
                    <span className="bg-[#111] border border-[#222] px-2 py-0.5 text-[9px] text-green-400">
                      {entry.event_type}
                    </span>
                  </td>
                  <td className="p-2 font-semibold text-white">{entry.product_name}</td>
                  <td className="p-2 text-right text-green-400">{entry.volume_litres ? entry.volume_litres.toFixed(3) : '-'}</td>
                  <td className="p-2 text-right text-white">£{entry.total_value_gbp.toFixed(2)}</td>
                  <td className="p-2 text-[#666]">{entry.source_location}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
