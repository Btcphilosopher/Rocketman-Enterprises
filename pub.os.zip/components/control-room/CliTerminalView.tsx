'use client';

import React, { useState } from 'react';
import { PubTwin } from '@/types/pub-os';
import { Terminal, Send, CornerDownLeft, HelpCircle } from 'lucide-react';

interface CliTerminalViewProps {
  twin: PubTwin;
}

export const CliTerminalView: React.FC<CliTerminalViewProps> = ({ twin }) => {
  const [inputCommand, setInputCommand] = useState<string>('pub status');
  const [history, setHistory] = useState<Array<{ cmd: string; output: string }>>([
    {
      cmd: 'pub status',
      output: `PUB.OS Cyber-Physical Twin Version 4.2.0 (Rust Core + R Quant)
Pub ID: ${twin.pub_id} [${twin.pub_name}]
Automation Level: Level ${twin.automation_level}
Active Taps: 20/20 | Active Kegs: 10
Today Revenue: £${twin.metrics.revenue_today_gbp.toFixed(2)} | Gross Margin: ${twin.metrics.gross_margin_pct}%
Cellar Temp: 4.1°C | Line CO2: 2.15 bar
System State: HEALTHY (1 WARNING on Main Bar Chiller)`
    }
  ]);

  const handleRunCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCommand.trim()) return;

    const cmd = inputCommand.trim().toLowerCase();
    let output = '';

    if (cmd === 'pub status') {
      output = `Pub ID: ${twin.pub_id}\nAutomation Level: L${twin.automation_level}\nRevenue Today: £${twin.metrics.revenue_today_gbp.toFixed(2)}\nPints Sold: ${twin.metrics.pints_sold_today}\nLitres Dispensed: ${twin.metrics.total_litres_dispensed_today}L`;
    } else if (cmd === 'pub inventory' || cmd === 'pub stock') {
      output = twin.products.map(p => `SKU: ${p.SKU} | ${p.name} | Price: £${p.selling_price.toFixed(2)} | Min Stock: ${p.minimum_stock}`).join('\n');
    } else if (cmd === 'pub kegs') {
      output = twin.kegs.map(k => `${k.keg_id}: ${k.product_name} -> ${k.current_volume_litres.toFixed(2)}L remaining (${k.pints_remaining} pints)`).join('\n');
    } else if (cmd === 'pub pours') {
      output = twin.pours_history.slice(0, 5).map(p => `${p.pour_id} [${p.nozzle_id}]: ${p.product_name} -> ${p.actual_volume_ml}mL (Err: ${p.error_percent}%)`).join('\n');
    } else if (cmd === 'pub reconcile') {
      output = `RECONCILIATION SUCCESS:\nOpening: 1280.0 L\nPurchases: +300.0 L\nDispensed: -${twin.metrics.total_litres_dispensed_today} L\nWaste: -14.2 L\nClosing Reconciled Stock: ${(1280 + 300 - twin.metrics.total_litres_dispensed_today - 14.2).toFixed(1)} L (0.0% Unexplained Variance)`;
    } else if (cmd === 'pub forecast') {
      output = twin.forecast.map(f => `${f.time_label}: Forecast £${f.forecast_sales_gbp} | Pint Demand: ${f.predicted_pint_demand}`).join('\n');
    } else if (cmd === 'help' || cmd === 'pub help') {
      output = `Available PUB.OS CLI Commands:\n- pub status\n- pub inventory\n- pub kegs\n- pub pours\n- pub sales\n- pub procurement\n- pub workforce\n- pub equipment\n- pub forecast\n- pub reconcile\n- pub simulate`;
    } else {
      output = `Command not recognized. Type 'pub help' for command manual.`;
    }

    setHistory(prev => [...prev, { cmd: inputCommand, output }]);
    setInputCommand('');
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-4">
      <div className="border-b border-[#222] pb-3 flex justify-between items-center font-mono">
        <h2 className="text-lg font-light tracking-tight text-white flex items-center gap-2">
          <Terminal className="w-5 h-5 text-green-400" />
          <span>PUB.OS Interactive Command Line <span className="text-[#444] text-xs font-mono ml-2">`pub` CLI</span></span>
        </h2>
        <span className="text-xs text-[#666]">Rust & R Control Console</span>
      </div>

      {/* Terminal Screen */}
      <div className="bg-[#050505] border border-[#111] rounded p-4 font-mono text-xs text-green-400 h-64 overflow-y-auto space-y-3 shadow-inner">
        {history.map((h, i) => (
          <div key={i} className="space-y-1">
            <div className="flex items-center gap-2 text-green-400 font-bold">
              <span>pub-os@tavern-core:~$</span>
              <span className="text-white">{h.cmd}</span>
            </div>
            <pre className="text-[#888] text-[11px] whitespace-pre-wrap font-mono pl-4 border-l border-[#222] leading-relaxed">
              {h.output}
            </pre>
          </div>
        ))}
      </div>

      {/* Command Input Form */}
      <form onSubmit={handleRunCommand} className="flex gap-2 font-mono text-xs">
        <div className="relative flex-1">
          <span className="absolute left-3 top-2.5 text-green-400 font-bold">pub-os:~$</span>
          <input
            type="text"
            value={inputCommand}
            onChange={(e) => setInputCommand(e.target.value)}
            placeholder="e.g. pub status, pub kegs, pub reconcile..."
            className="w-full bg-[#050505] border border-[#222] text-white rounded pl-24 pr-4 py-2 focus:outline-none focus:border-green-500"
          />
        </div>
        <button
          type="submit"
          className="bg-green-500 hover:bg-green-400 text-[#050505] font-mono font-bold px-4 py-2 rounded flex items-center gap-1 transition shadow-[0_0_10px_rgba(34,197,94,0.3)]"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Run</span>
        </button>
      </form>
    </div>
  );
};
