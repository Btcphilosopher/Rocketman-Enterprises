'use client';

import React from 'react';
import { PubTwin, AutomationLevel } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { Activity, ShieldAlert, Cpu, RefreshCw, Zap, Bot } from 'lucide-react';

interface HeaderBarProps {
  twin: PubTwin;
  onOpenAiManager: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({ twin, onOpenAiManager }) => {
  const unackAlerts = twin.alerts.filter(a => !a.acknowledged).length;

  return (
    <header className="bg-[#0a0a0a] border-b border-[#222] text-[#e0e0e0] px-6 py-4 sticky top-0 z-40 shadow-2xl">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        
        {/* Brand & Pub State */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-3 h-3 bg-green-500 rounded-full shadow-[0_0_8px_rgba(34,197,94,0.6)]"></div>
            <span className="font-mono font-bold tracking-tighter text-xl text-white">
              PUB.OS <span className="text-[#666] font-normal text-xs ml-2">v4.2.0_RUST_CORE</span>
            </span>
          </div>
          <div className="border-l border-[#222] pl-4">
            <div className="flex items-center space-x-2">
              <h1 className="text-sm font-bold tracking-tight text-white">{twin.pub_name}</h1>
              <span className="text-[10px] bg-[#111] text-green-400 border border-green-500/40 px-2 py-0.5 font-mono flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse"></span>
                STATE: AUTHORITATIVE
              </span>
            </div>
            <p className="text-[11px] text-[#666] font-mono">Node: LND-001-CENTRAL | {twin.address}</p>
          </div>
        </div>

        {/* Real-time Economic KPI Ribbon */}
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-3 font-mono text-xs">
          <div className="bg-[#111] border border-[#222] p-2.5 rounded">
            <span className="text-[#666] block text-[9px] uppercase tracking-wider">GROSS REVENUE</span>
            <span className="text-white font-bold text-sm">£{twin.metrics.revenue_today_gbp.toFixed(2)}</span>
            <span className="text-[10px] text-green-500 block">vs Fcst +{twin.metrics.variance_pct}%</span>
          </div>

          <div className="bg-[#111] border border-[#222] p-2.5 rounded">
            <span className="text-[#666] block text-[9px] uppercase tracking-wider">GROSS MARGIN</span>
            <span className="text-green-400 font-bold text-sm">{twin.metrics.gross_margin_pct}%</span>
            <span className="text-[10px] text-[#888] block">COGS: £{twin.metrics.cogs_today_gbp.toFixed(0)}</span>
          </div>

          <div className="bg-[#111] border border-[#222] p-2.5 rounded">
            <span className="text-[#666] block text-[9px] uppercase tracking-wider">BEER DISPENSED</span>
            <span className="text-white font-bold text-sm">{twin.metrics.total_litres_dispensed_today} L</span>
            <span className="text-[10px] text-[#888] block">{twin.metrics.pints_sold_today} Pints Sold</span>
          </div>

          <div className="bg-[#111] border border-[#222] p-2.5 rounded">
            <span className="text-[#666] block text-[9px] uppercase tracking-wider">POUR VARIANCE</span>
            <span className={`font-bold text-sm ${twin.metrics.pour_variance_pct >= 0 ? 'text-orange-400' : 'text-green-400'}`}>
              {twin.metrics.pour_variance_pct >= 0 ? '+' : ''}{twin.metrics.pour_variance_pct}%
            </span>
            <span className="text-[10px] text-[#888] block">Calibrated</span>
          </div>

          <div className="bg-[#111] border border-[#222] p-2.5 rounded">
            <span className="text-[#666] block text-[9px] uppercase tracking-wider">LABOUR COST %</span>
            <span className="text-white font-bold text-sm">{twin.metrics.labour_pct}%</span>
            <span className="text-[10px] text-[#888] block">£{twin.metrics.labour_cost_today_gbp.toFixed(2)}</span>
          </div>

          <div className="bg-[#111] border border-[#222] p-2.5 rounded">
            <span className="text-[#666] block text-[9px] uppercase tracking-wider">ENERGY TODAY</span>
            <span className="text-white font-bold text-sm">{twin.daily_energy_kwh} kWh</span>
            <span className="text-[10px] text-[#888] block">£{twin.daily_energy_cost_gbp.toFixed(2)}</span>
          </div>
        </div>

        {/* Controls & Automation Governance */}
        <div className="flex items-center space-x-3">
          {/* Automation Level Selector */}
          <div className="flex flex-col">
            <label className="text-[9px] font-mono text-[#666] mb-0.5 uppercase tracking-wider">Automation Governance</label>
            <select
              value={twin.automation_level}
              onChange={(e) => pubStore.setAutomationLevel(Number(e.target.value) as AutomationLevel)}
              className="bg-[#111] border border-[#222] text-green-400 text-xs font-mono font-semibold rounded px-2 py-1.5 focus:outline-none focus:border-green-500"
            >
              <option value={0}>L0 — MONITOR</option>
              <option value={1}>L1 — RECOMMEND</option>
              <option value={2}>L2 — APPROVAL</option>
              <option value={3}>L3 — AUTONOMOUS</option>
            </select>
          </div>

          {/* Live IoT Simulation Toggle */}
          <button
            onClick={() => pubStore.toggleLiveSimulation()}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded text-xs font-mono border transition ${
              twin.live_simulation_active
                ? 'bg-[#111] text-green-400 border-green-500/50 hover:bg-green-950/20'
                : 'bg-[#111] text-[#666] border-[#222] hover:text-white'
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${twin.live_simulation_active ? 'animate-spin text-green-400' : ''}`} />
            <span>{twin.live_simulation_active ? 'IoT Live' : 'IoT Paused'}</span>
          </button>

          {/* AI Manager Drawer Trigger */}
          <button
            onClick={onOpenAiManager}
            className="flex items-center space-x-2 bg-green-500 hover:bg-green-400 text-[#050505] font-mono font-bold text-xs px-3 py-1.5 rounded transition shadow-[0_0_10px_rgba(34,197,94,0.4)]"
          >
            <Bot className="w-4 h-4" />
            <span>AI Pub Manager</span>
          </button>
        </div>

      </div>
    </header>
  );
};
