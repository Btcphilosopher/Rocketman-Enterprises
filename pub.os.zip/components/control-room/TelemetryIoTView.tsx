'use client';

import React from 'react';
import { PubTwin } from '@/types/pub-os';
import { Cpu, AlertTriangle, Zap, Thermometer, Activity, ShieldCheck } from 'lucide-react';

interface TelemetryIoTViewProps {
  twin: PubTwin;
}

export const TelemetryIoTView: React.FC<TelemetryIoTViewProps> = ({ twin }) => {
  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <Cpu className="w-5 h-5 text-green-400" />
          <span>Industrial IoT Telemetry <span className="text-[#444] text-xs font-mono ml-2">Predictive Maintenance</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          High-frequency sensor streams detecting micro-vibration drift, pressure drops, and thermal degradation before equipment failure occurs.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* PREDICTIVE MAINTENANCE CARDS */}
        <div className="lg:col-span-6 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-red-400 font-mono uppercase tracking-widest flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span>AI Predictive Maintenance Models</span>
          </h3>

          <div className="space-y-3">
            {twin.maintenance_predictions.map(pred => (
              <div key={pred.asset_id} className="bg-[#0a0a0a] border border-red-900/40 p-4 rounded space-y-3 font-mono text-xs">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-white text-sm">{pred.asset_name}</span>
                  <span className="bg-red-950/40 text-red-400 border border-red-800/40 px-2 py-0.5 rounded text-[10px] font-bold">
                    Failure Prob: {(pred.failure_probability * 100).toFixed(0)}%
                  </span>
                </div>

                <div className="bg-[#111] p-2.5 rounded text-red-300 space-y-1 text-[11px] border border-[#222]">
                  <div className="flex justify-between">
                    <span>Remaining Useful Life (RUL):</span>
                    <span className="font-bold text-red-400">{pred.remaining_useful_life_days} Days</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Avoided Economic Loss:</span>
                    <span className="font-bold text-green-400">£{pred.expected_economic_effect_gbp.toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-1 text-[11px] text-[#666]">
                  <span className="text-[#888] font-bold block">Physical Sensor Evidence:</span>
                  <ul className="list-disc list-inside space-y-0.5 text-[#666]">
                    {pred.evidence.map((ev, i) => (
                      <li key={i}>{ev}</li>
                    ))}
                  </ul>
                </div>

                <div className="bg-[#111] border border-[#222] p-2 rounded text-[11px] text-orange-400">
                  <strong className="text-white">Recommended Action:</strong> {pred.recommended_action}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* LIVE SENSOR TELEMETRY READINGS */}
        <div className="lg:col-span-6 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
            <Activity className="w-4 h-4 text-green-400" />
            <span>Industrial Sensor Telemetry Stream</span>
          </h3>

          <div className="space-y-2">
            {twin.telemetry.map(sen => (
              <div key={sen.sensor_id} className="bg-[#0a0a0a] p-3 rounded border border-[#111] font-mono text-xs flex justify-between items-center">
                <div>
                  <span className="text-white font-bold block">{sen.asset_name}</span>
                  <span className="text-[#666] text-[10px]">{sen.metric_name}</span>
                </div>

                <div className="text-right">
                  <span className={`font-bold text-sm block ${sen.quality === 'CALIBRATION_REQUIRED' || sen.quality === 'SENSOR_FAULT' ? 'text-red-400' : 'text-green-400'}`}>
                    {sen.value} {sen.unit}
                  </span>
                  <span className={`text-[9px] px-1.5 py-0.2 rounded border ${sen.quality === 'CALIBRATION_REQUIRED' || sen.quality === 'SENSOR_FAULT' ? 'bg-red-950/40 text-red-400 border-red-800/40' : 'bg-[#111] text-[#666] border-[#222]'}`}>
                    {sen.quality}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
