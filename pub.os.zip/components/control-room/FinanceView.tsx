'use client';

import React from 'react';
import { PubTwin } from '@/types/pub-os';
import { DollarSign, PieChart, TrendingUp, BarChart3, Scale } from 'lucide-react';

interface FinanceViewProps {
  twin: PubTwin;
}

export const FinanceView: React.FC<FinanceViewProps> = ({ twin }) => {
  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <DollarSign className="w-5 h-5 text-green-400" />
          <span>Double-Entry Financial Ledger <span className="text-[#444] text-xs font-mono ml-2">Unit Economics</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          Real-time double-entry accounting. Every physical pint dispensed immediately credits Revenue and debits Inventory COGS.
        </p>
      </div>

      {/* Real-time Unit Economics Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 font-mono text-xs">
        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-[#666] text-[9px] block uppercase tracking-wider">PROFIT PER PINT</span>
          <span className="text-green-400 font-bold text-base">£{(6.20 - 1.45).toFixed(2)}</span>
          <span className="text-[10px] text-[#444] block">76.6% Margin</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-[#666] text-[9px] block uppercase tracking-wider">PROFIT PER TABLE</span>
          <span className="text-white font-bold text-base">£{(twin.metrics.operating_profit_today_gbp / 20).toFixed(2)}</span>
          <span className="text-[10px] text-[#444] block">Across 20 Table Nodes</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-[#666] text-[9px] block uppercase tracking-wider">PROFIT PER STAFF-HOUR</span>
          <span className="text-white font-bold text-base">£{twin.metrics.sales_per_staff_hour_gbp.toFixed(2)}</span>
          <span className="text-[10px] text-[#444] block">Labour Ratio 15.2%</span>
        </div>

        <div className="bg-[#050505] p-3 rounded border border-[#111]">
          <span className="text-[#666] text-[9px] block uppercase tracking-wider">BREAK-EVEN VOLUME</span>
          <span className="text-green-400 font-bold text-base">{twin.metrics.break_even_pints_daily} Pints</span>
          <span className="text-[10px] text-green-500 block font-bold">Passed @ 14:30</span>
        </div>
      </div>

      {/* Double Entry Accounts Table */}
      <div className="bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
        <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
          <Scale className="w-4 h-4 text-green-400" />
          <span>General Ledger Accounts</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs">
            <thead>
              <tr className="border-b border-[#222] text-[#666] text-[9px] uppercase tracking-wider">
                <th className="p-2">Code</th>
                <th className="p-2">Account Name</th>
                <th className="p-2">Type</th>
                <th className="p-2 text-right">Balance (£)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#111] text-[#888]">
              {twin.accounts.map(acc => (
                <tr key={acc.account_code} className="hover:bg-[#0a0a0a]">
                  <td className="p-2 text-white font-bold">{acc.account_code}</td>
                  <td className="p-2 font-semibold text-white">{acc.account_name}</td>
                  <td className="p-2 text-[#666]">{acc.type}</td>
                  <td className={`p-2 text-right font-bold ${acc.type === 'REVENUE' || acc.type === 'ASSET' ? 'text-green-400' : 'text-white'}`}>
                    £{acc.balance_gbp.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
