'use client';

import React from 'react';
import { PubTwin } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { RQuantEngine } from '@/lib/r-quant-engine';
import { Users, Clock, Calendar, CheckCircle2, DollarSign } from 'lucide-react';

interface WorkforceViewProps {
  twin: PubTwin;
}

export const WorkforceView: React.FC<WorkforceViewProps> = ({ twin }) => {
  const rotaRecommendations = RQuantEngine.optimizeRota(twin.forecast);

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <Users className="w-5 h-5 text-green-400" />
          <span>Workforce Management <span className="text-[#444] text-xs font-mono ml-2">Time Clock & Rota</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          Demand-driven shift scheduling. Rota is optimized against forecasted customer arrival curves and maximum labor cost ratios.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* EMPLOYEES & TIME CLOCK */}
        <div className="lg:col-span-6 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
            <Clock className="w-4 h-4 text-green-400" />
            <span>Live Employee Time Clock</span>
          </h3>

          <div className="space-y-2">
            {twin.employees.map(emp => (
              <div key={emp.employee_id} className="bg-[#0a0a0a] p-3 rounded border border-[#111] flex justify-between items-center font-mono text-xs">
                <div>
                  <span className="font-bold text-white block">{emp.name}</span>
                  <span className="text-[#666] text-[10px]">{emp.role} • £{emp.pay_rate_hourly_gbp.toFixed(2)}/hr</span>
                </div>

                <div className="flex items-center gap-3">
                  <span className={`text-[9px] font-bold px-2 py-0.5 border ${
                    emp.clocked_in
                      ? 'bg-[#111] text-green-400 border-green-500/40'
                      : 'bg-[#0a0a0a] text-[#444] border-[#222]'
                  }`}>
                    {emp.clocked_in ? 'CLOCKED IN' : 'OFF SHIFT'}
                  </span>

                  <button
                    onClick={() => pubStore.toggleEmployeeClock(emp.employee_id)}
                    className={`px-3 py-1 rounded text-xs font-bold transition ${
                      emp.clocked_in
                        ? 'bg-red-950/40 text-red-400 border border-red-800/40 hover:bg-red-900/60'
                        : 'bg-green-500 text-[#050505] hover:bg-green-400'
                    }`}
                  >
                    {emp.clocked_in ? 'Clock Out' : 'Clock In'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* DEMAND-DRIVEN ROTA OPTIMIZATION TABLE */}
        <div className="lg:col-span-6 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
            <Calendar className="w-4 h-4 text-green-400" />
            <span>R Quant Demand-Driven Rota Schedule</span>
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs">
              <thead>
                <tr className="border-b border-[#222] text-[#666] text-[9px] uppercase tracking-wider">
                  <th className="p-2">Day</th>
                  <th className="p-2 text-right">Cust. Fcst</th>
                  <th className="p-2 text-center">Bar / Kitch</th>
                  <th className="p-2 text-right">Est. Cost</th>
                  <th className="p-2 text-right">Labour %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#111] text-[#888]">
                {rotaRecommendations.map(r => (
                  <tr key={r.day_label} className="hover:bg-[#0a0a0a]">
                    <td className="p-2 text-white font-bold">{r.day_label}</td>
                    <td className="p-2 text-right text-white">{r.predicted_customer_count}</td>
                    <td className="p-2 text-center text-green-400">{r.recommended_bar_staff} Bar / {r.recommended_kitchen_staff} Ktchn</td>
                    <td className="p-2 text-right text-white">£{r.estimated_labour_cost_gbp}</td>
                    <td className="p-2 text-right font-bold text-green-400">{r.labour_cost_ratio_pct}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  );
};
