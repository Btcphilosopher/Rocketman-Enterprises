'use client';

import React, { useState } from 'react';
import { PubTwin } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { Droplets, Play, AlertCircle, Gauge, CheckCircle, Scale, Activity } from 'lucide-react';

interface PrecisionPouringViewProps {
  twin: PubTwin;
  selectedTapNumber?: number;
}

export const PrecisionPouringView: React.FC<PrecisionPouringViewProps> = ({ twin, selectedTapNumber = 1 }) => {
  const [tapNum, setTapNum] = useState<number>(selectedTapNumber);
  const [targetMl, setTargetMl] = useState<number>(568); // Default 1 pint
  const [bartenderId, setBartenderId] = useState<string>('EMP-003');
  const [isPouringActive, setIsPouringActive] = useState<boolean>(false);
  const [currentStage, setCurrentStage] = useState<string>('STOP');
  const [lastPourResult, setLastPourResult] = useState<any | null>(null);

  const nozzle = twin.nozzles.find(n => n.tap_number === tapNum) || twin.nozzles[0];
  const keg = twin.kegs.find(k => k.tap_id === `TAP-${tapNum.toString().padStart(2, '0')}`);
  const product = twin.products.find(p => p.product_id === (keg ? keg.product_id : nozzle.product_id));

  const handleExecutePour = async () => {
    setIsPouringActive(true);
    
    // Simulate real-time precision flow profiling
    setCurrentStage('START');
    await new Promise(r => setTimeout(r, 200));
    
    setCurrentStage('RAMP');
    await new Promise(r => setTimeout(r, 300));
    
    setCurrentStage('STEADY_FLOW');
    await new Promise(r => setTimeout(r, 500));
    
    setCurrentStage('REDUCE_FLOW');
    await new Promise(r => setTimeout(r, 300));
    
    setCurrentStage('STOP');
    
    // Dispatch authoritative state change in pubStore
    const pourResult = pubStore.triggerPour(tapNum, targetMl, bartenderId);
    setLastPourResult(pourResult);
    setIsPouringActive(false);
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Title Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <Droplets className="w-5 h-5 text-green-400" />
          <span>Liquid Measurement Engine <span className="text-[#444] text-xs font-mono ml-2">Precision Pouring</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          Cyber-physical measurement of actual liquid leaving nozzles via mass flow sensors, temperature-density calibration ($m = \rho \times V$), and error variance analysis.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* DISPENSING CONTROL & REAL-TIME NOZZLE SIMULATOR */}
        <div className="lg:col-span-5 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-5">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
            <Gauge className="w-4 h-4 text-green-400" />
            <span>Active Dispenser Nozzle Control</span>
          </h3>

          {/* Select Tap & Volume */}
          <div className="grid grid-cols-2 gap-3 font-mono">
            <div>
              <label className="text-[10px] text-[#666] block mb-1 uppercase tracking-wider">Select Tap Nozzle</label>
              <select
                value={tapNum}
                onChange={(e) => setTapNum(Number(e.target.value))}
                className="w-full bg-[#111] border border-[#222] text-white text-xs rounded p-2 focus:outline-none focus:border-green-500 font-mono"
              >
                {twin.nozzles.map(n => (
                  <option key={n.nozzle_id} value={n.tap_number}>
                    TAP_{n.tap_number.toString().padStart(2, '0')} — {n.product_name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[10px] text-[#666] block mb-1 uppercase tracking-wider">Target Volume</label>
              <select
                value={targetMl}
                onChange={(e) => setTargetMl(Number(e.target.value))}
                className="w-full bg-[#111] border border-[#222] text-white text-xs rounded p-2 focus:outline-none focus:border-green-500 font-mono"
              >
                <option value={568}>1 Pint (568 mL)</option>
                <option value={284}>Half Pint (284 mL)</option>
                <option value={175}>Wine Glass (175 mL)</option>
                <option value={25}>Spirit Shot (25 mL)</option>
              </select>
            </div>
          </div>

          {/* Product & Physics Parameters */}
          <div className="bg-[#0a0a0a] border border-[#111] p-3 rounded space-y-2 text-xs font-mono">
            <div className="flex justify-between">
              <span className="text-[#666]">Connected Product:</span>
              <span className="text-white font-bold">{product?.name}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#666]">Calibrated Liquid Density ($\rho$):</span>
              <span className="text-green-400">{product?.density_g_ml || 1.012} g/mL</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#666]">Line CO2 Pressure:</span>
              <span className="text-white">{keg ? keg.pressure_bar : 2.1} bar</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#666]">Cellar Line Temp:</span>
              <span className="text-white">{keg ? keg.temperature_c : 4.2} °C</span>
            </div>
          </div>

          {/* Nozzle Flow Profile Visualizer */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-[#666] uppercase tracking-wider text-[10px]">Flow Profile Stage:</span>
              <span className="font-mono font-bold text-green-400 bg-[#111] border border-green-500/40 px-2 py-0.5 rounded">
                {currentStage}
              </span>
            </div>

            <div className="grid grid-cols-5 gap-1 font-mono text-[10px] text-center">
              {['START', 'RAMP', 'STEADY_FLOW', 'REDUCE_FLOW', 'STOP'].map(stg => (
                <div
                  key={stg}
                  className={`p-1.5 border ${
                    currentStage === stg
                      ? 'bg-green-500 text-[#050505] font-bold border-green-400 animate-pulse'
                      : 'bg-[#0a0a0a] border-[#111] text-[#444]'
                  }`}
                >
                  {stg.replace('_', ' ')}
                </div>
              ))}
            </div>
          </div>

          {/* Trigger Precision Pour Button */}
          <button
            disabled={isPouringActive}
            onClick={handleExecutePour}
            className={`w-full py-3 rounded font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition ${
              isPouringActive
                ? 'bg-[#111] text-[#444] border border-[#222] cursor-not-allowed'
                : 'bg-green-500 hover:bg-green-400 text-[#050505] shadow-[0_0_12px_rgba(34,197,94,0.4)]'
            }`}
          >
            {isPouringActive ? (
              <>
                <Activity className="w-4 h-4 animate-spin text-[#050505]" />
                <span>Dispensing Liquid...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-[#050505]" />
                <span>Execute Precision Pour ({targetMl} mL)</span>
              </>
            )}
          </button>
        </div>

        {/* POUR VALIDATION & MEASURED REAL-TIME RESULT */}
        <div className="lg:col-span-7 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-5">
          <h3 className="text-xs font-bold text-white font-mono uppercase tracking-widest flex items-center gap-2">
            <Scale className="w-4 h-4 text-green-400" />
            <span>Liquid Measurement & Error Validation</span>
          </h3>

          {lastPourResult ? (
            <div className="bg-[#0a0a0a] border border-[#111] p-4 rounded space-y-4 font-mono">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center font-mono">
                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[9px] text-[#666] block uppercase tracking-wider">TARGET VOL</span>
                  <span className="text-white font-bold text-sm">{lastPourResult.target_volume_ml} mL</span>
                </div>

                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[9px] text-[#666] block uppercase tracking-wider">ACTUAL MEASURED</span>
                  <span className="text-green-400 font-bold text-sm">{lastPourResult.actual_volume_ml} mL</span>
                </div>

                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[9px] text-[#666] block uppercase tracking-wider">VOLUME ERROR</span>
                  <span className={`font-bold text-sm ${lastPourResult.error_volume_ml >= 0 ? 'text-orange-400' : 'text-green-400'}`}>
                    {lastPourResult.error_volume_ml >= 0 ? '+' : ''}{lastPourResult.error_volume_ml} mL
                  </span>
                </div>

                <div className="bg-[#111] p-2.5 rounded border border-[#222]">
                  <span className="text-[9px] text-[#666] block uppercase tracking-wider">ERROR %</span>
                  <span className="text-orange-400 font-bold text-sm">{lastPourResult.error_percent}%</span>
                </div>
              </div>

              <div className="text-xs font-mono space-y-1 text-[#888] bg-[#111] p-3 rounded border border-[#222]">
                <div className="flex justify-between">
                  <span>Dispense Duration:</span>
                  <span className="text-white">{lastPourResult.duration_s} seconds</span>
                </div>
                <div className="flex justify-between">
                  <span>Avg Flow Rate:</span>
                  <span className="text-green-400">{lastPourResult.avg_flow_ml_s} mL/s</span>
                </div>
                <div className="flex justify-between">
                  <span>Variance Classification:</span>
                  <span className="text-green-400 font-bold">{lastPourResult.variance_classification}</span>
                </div>
                <div className="flex justify-between">
                  <span>Physical Keg Stock Deducted:</span>
                  <span className="text-white">{(lastPourResult.actual_volume_ml / 1000).toFixed(3)} Litres</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#0a0a0a] border border-dashed border-[#222] p-8 rounded text-center text-[#666] text-xs font-mono">
              Ready to record real-time liquid flow. Trigger a pour on any nozzle above.
            </div>
          )}

          {/* Recent Pours Log */}
          <div className="space-y-2">
            <h4 className="text-[10px] font-bold text-[#666] font-mono uppercase tracking-widest">Authoritative Pour Event Stream</h4>
            <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
              {twin.pours_history.map(p => (
                <div key={p.pour_id} className="bg-[#0a0a0a] p-2.5 rounded text-xs flex justify-between items-center font-mono border border-[#111]">
                  <div>
                    <span className="text-white font-bold block">{p.pour_id} | {p.nozzle_id}</span>
                    <span className="text-[#666]">{p.product_name} ({p.actual_volume_ml} mL)</span>
                  </div>
                  <div className="text-right">
                    <span className="text-green-400 font-bold block">+£{p.sale_price_gbp.toFixed(2)}</span>
                    <span className="text-[10px] text-[#444]">{new Date(p.timestamp).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
