'use client';

import React, { useState } from 'react';
import { PubTwin, Product } from '@/types/pub-os';
import { pubStore } from '@/lib/pub-store';
import { ShoppingBag, CreditCard, DollarSign, CheckCircle2, ArrowRight, RefreshCw, Smartphone } from 'lucide-react';

interface PosTerminalViewProps {
  twin: PubTwin;
  onPourCompleted?: () => void;
}

export const PosTerminalView: React.FC<PosTerminalViewProps> = ({ twin, onPourCompleted }) => {
  const [selectedTable, setSelectedTable] = useState<number>(1);
  const [cart, setCart] = useState<{ product: Product; qty: number }[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<'CARD' | 'CONTACTLESS' | 'CASH' | 'MOBILE'>('CONTACTLESS');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [lastTxId, setLastTxId] = useState<string | null>(null);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.product_id === product.product_id);
      if (existing) {
        return prev.map(item => item.product.product_id === product.product_id ? { ...item, qty: item.qty + 1 } : item);
      }
      return [...prev, { product, qty: 1 }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.product_id !== productId));
  };

  const subtotal = cart.reduce((acc, item) => acc + item.product.selling_price * item.qty, 0);
  const tax = subtotal * 0.20;
  const total = subtotal;

  const handleCheckout = async () => {
    if (cart.length === 0) return;
    setIsProcessing(true);

    // End-to-end Cyber-Physical Order -> Dispense -> Stock -> Accounting State Machine
    await new Promise(r => setTimeout(r, 600));

    // Trigger physical pour for any draught products in order
    for (const item of cart) {
      if (item.product.category === 'DRAUGHT_BEER' || item.product.category === 'CIDER') {
        // Find nozzle with this product
        const nozzle = twin.nozzles.find(n => n.product_id === item.product.product_id) || twin.nozzles[0];
        for (let i = 0; i < item.qty; i++) {
          pubStore.triggerPour(nozzle.tap_number, 568, 'EMP-003');
        }
      }
    }

    const txId = `TX-${Date.now().toString().slice(-6)}`;
    setLastTxId(txId);
    setCart([]);
    setIsProcessing(false);
    if (onPourCompleted) onPourCompleted();
  };

  return (
    <div className="bg-[#0a0a0a] border border-[#222] rounded-xl p-6 shadow-2xl space-y-6">
      
      {/* Header */}
      <div className="border-b border-[#222] pb-4">
        <h2 className="text-xl font-light tracking-tight text-white flex items-center gap-2">
          <ShoppingBag className="w-5 h-5 text-green-400" />
          <span>Point of Sale (POS) <span className="text-[#444] text-xs font-mono ml-2">Order State Machine</span></span>
        </h2>
        <p className="text-xs text-[#666] mt-1 font-mono">
          A sale triggers physical measurement: ORDER_CREATED $\rightarrow$ PAYMENT_AUTHORISED $\rightarrow$ PHYSICAL_MEASUREMENT $\rightarrow$ STOCK_UPDATE $\rightarrow$ FINANCIAL_LEDGER.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* PRODUCT CATALOG GRID */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex justify-between items-center text-xs font-mono">
            <span className="text-white uppercase font-bold tracking-widest text-[10px]">Product Master Catalog</span>
            <span className="text-[#666]">{twin.products.length} SKU Items Available</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {twin.products.map(product => (
              <button
                key={product.product_id}
                onClick={() => addToCart(product)}
                className="bg-[#050505] border border-[#111] hover:border-green-500/50 p-3 rounded text-left transition transform hover:-translate-y-0.5 flex flex-col justify-between"
              >
                <div>
                  <span className="text-[9px] font-mono font-bold text-green-400 uppercase block">{product.category.replace('_', ' ')}</span>
                  <span className="text-xs font-mono font-bold text-white block mt-0.5">{product.name}</span>
                </div>
                <div className="mt-3 flex justify-between items-center text-xs font-mono">
                  <span className="text-white font-bold">£{product.selling_price.toFixed(2)}</span>
                  <span className="text-[10px] text-green-400 bg-[#111] border border-green-500/30 px-1.5 py-0.5">Add +</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* ORDER TICKET & PAYMENT SUMMARY */}
        <div className="lg:col-span-5 bg-[#050505] border border-[#111] rounded-lg p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-[#222] pb-3 font-mono">
            <span className="text-xs font-bold text-white uppercase tracking-widest">Active Order Ticket</span>
            <select
              value={selectedTable}
              onChange={(e) => setSelectedTable(Number(e.target.value))}
              className="bg-[#111] border border-[#222] text-white text-xs rounded px-2 py-1 font-mono"
            >
              {Array.from({ length: 20 }).map((_, i) => (
                <option key={i + 1} value={i + 1}>Table #{i + 1}</option>
              ))}
            </select>
          </div>

          {/* Cart Items List */}
          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {cart.length === 0 ? (
              <div className="text-center py-8 text-[#666] text-xs font-mono">
                Order ticket is empty. Select items from product catalog.
              </div>
            ) : (
              cart.map(item => (
                <div key={item.product.product_id} className="flex justify-between items-center bg-[#0a0a0a] p-2.5 rounded text-xs font-mono border border-[#111]">
                  <div>
                    <span className="text-white font-bold block">{item.product.name}</span>
                    <span className="text-[10px] text-[#666]">£{item.product.selling_price.toFixed(2)} × {item.qty}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-green-400 font-bold">£{(item.product.selling_price * item.qty).toFixed(2)}</span>
                    <button
                      onClick={() => removeFromCart(item.product.product_id)}
                      className="text-red-400 hover:text-red-300 text-xs font-bold"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Payment Method Selector */}
          <div className="space-y-2 pt-3 border-t border-[#222] font-mono text-xs">
            <span className="text-[#666] block text-[9px] uppercase font-bold tracking-widest">Payment Interface</span>
            <div className="grid grid-cols-2 gap-2">
              {(['CONTACTLESS', 'CARD', 'CASH', 'MOBILE'] as const).map(method => (
                <button
                  key={method}
                  onClick={() => setPaymentMethod(method)}
                  className={`p-2 rounded border text-center transition ${
                    paymentMethod === method
                      ? 'bg-green-500 text-[#050505] font-bold border-green-400 shadow-[0_0_8px_rgba(34,197,94,0.4)]'
                      : 'bg-[#0a0a0a] border-[#111] text-[#666]'
                  }`}
                >
                  {method}
                </button>
              ))}
            </div>
          </div>

          {/* Total & Checkout Button */}
          <div className="bg-[#0a0a0a] p-3 rounded border border-[#111] space-y-2 font-mono">
            <div className="flex justify-between text-xs text-[#666]">
              <span>Subtotal:</span>
              <span>£{subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-xs text-[#666]">
              <span>VAT (20%):</span>
              <span>£{tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm text-white font-bold pt-1 border-t border-[#222]">
              <span>Total Amount:</span>
              <span className="text-green-400">£{total.toFixed(2)}</span>
            </div>
          </div>

          <button
            disabled={cart.length === 0 || isProcessing}
            onClick={handleCheckout}
            className={`w-full py-3 rounded font-mono font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition ${
              cart.length === 0 || isProcessing
                ? 'bg-[#111] text-[#444] border border-[#222] cursor-not-allowed'
                : 'bg-green-500 hover:bg-green-400 text-[#050505] shadow-[0_0_12px_rgba(34,197,94,0.4)]'
            }`}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-[#050505]" />
                <span>Executing Order & Dispense...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 text-[#050505]" />
                <span>Process Sale & Trigger Dispense</span>
              </>
            )}
          </button>

          {lastTxId && (
            <div className="bg-[#111] border border-green-500/40 p-2.5 rounded text-xs font-mono text-green-400 flex justify-between items-center">
              <span>Tx Confirmed: <strong>{lastTxId}</strong></span>
              <span className="text-[10px] text-green-500">Stock & Ledger Synced</span>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
