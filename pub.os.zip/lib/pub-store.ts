import { PubTwin, PourEvent, StockLedgerEntry, PurchaseOrder, OperationalAlert } from '@/types/pub-os';
import { createInitialPubTwin } from './synthetic-generator';

class PubStore {
  private state: PubTwin;
  private listeners: Set<() => void> = new Set();
  private simulationInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.state = createInitialPubTwin();
  }

  public getState(): PubTwin {
    return this.state;
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach(l => l());
  }

  public setAutomationLevel(level: 0 | 1 | 2 | 3) {
    this.state.automation_level = level;
    this.notify();
  }

  public toggleLiveSimulation() {
    this.state.live_simulation_active = !this.state.live_simulation_active;
    this.notify();
  }

  public acknowledgeAlert(alertId: string) {
    const alert = this.state.alerts.find(a => a.alert_id === alertId);
    if (alert) {
      alert.acknowledged = true;
      this.notify();
    }
  }

  // Execute Precision Pour Sequence
  public triggerPour(tapNumber: number, targetVolumeMl: number, bartenderId: string): PourEvent {
    const nozzleIndex = this.state.nozzles.findIndex(n => n.tap_number === tapNumber);
    if (nozzleIndex === -1) {
      throw new Error(`Tap #${tapNumber} not found.`);
    }

    const nozzle = this.state.nozzles[nozzleIndex];
    const keg = this.state.kegs.find(k => k.keg_id === nozzle.keg_id || k.tap_id === `TAP-${tapNumber.toString().padStart(2, '0')}`);
    const product = this.state.products.find(p => p.product_id === (keg ? keg.product_id : nozzle.product_id));

    if (!product) {
      throw new Error(`Product for Tap #${tapNumber} not configured.`);
    }

    // Precision Nozzle State Machine
    nozzle.valve_open = true;
    nozzle.stage = 'START';
    
    // Simulate high precision flow measurement with slight physical drift (density & pressure calibrated)
    const noise = (Math.random() - 0.48) * 6.0; // slight deviation +/- 3ml
    const actualVolume = Math.max(10, Math.round((targetVolumeMl + noise) * 10) / 10);
    const duration = Math.round((actualVolume / 50.0) * 10) / 10; // ~50ml/s flow rate
    const errorVolume = Math.round((actualVolume - targetVolumeMl) * 10) / 10;
    const errorPercent = Math.round((errorVolume / targetVolumeMl) * 10000) / 100;

    nozzle.actual_volume_ml = actualVolume;
    nozzle.stage = 'STOP';
    nozzle.valve_open = false;

    // Physical volume update in Keg Twin
    const volumeLitresDispensed = actualVolume / 1000.0;
    if (keg) {
      keg.current_volume_litres = Math.max(0, Math.round((keg.current_volume_litres - volumeLitresDispensed) * 1000) / 1000);
      keg.litres_remaining = keg.current_volume_litres;
      keg.pints_remaining = Math.round(keg.current_volume_litres / 0.568);
      keg.estimated_sales_remaining_gbp = Math.round(keg.pints_remaining * product.selling_price * 100) / 100;
    }

    // Financial & Stock Ledger update
    const salePrice = product.selling_price;
    const pourId = `POUR-${Date.now().toString().slice(-6)}`;
    
    const newPour: PourEvent = {
      pour_id: pourId,
      timestamp: new Date().toISOString(),
      nozzle_id: nozzle.nozzle_id,
      bartender_id: bartenderId,
      product_id: product.product_id,
      product_name: product.name,
      keg_id: keg ? keg.keg_id : 'KEG-UNKNOWN',
      target_volume_ml: targetVolumeMl,
      actual_volume_ml: actualVolume,
      error_volume_ml: errorVolume,
      error_percent: errorPercent,
      duration_s: duration,
      avg_flow_ml_s: Math.round(actualVolume / duration),
      peak_flow_ml_s: Math.round((actualVolume / duration) * 1.15),
      temperature_c: keg ? keg.temperature_c : 4.0,
      pressure_bar: keg ? keg.pressure_bar : 2.1,
      pour_state: 'INVENTORY_UPDATED',
      sale_price_gbp: salePrice,
      variance_classification: Math.abs(errorPercent) < 1.0 ? 'PROCESS_VARIANCE' : 'MEASUREMENT_ERROR'
    };

    this.state.pours_history.unshift(newPour);

    // Stock Movement Event
    const stockEntry: StockLedgerEntry = {
      entry_id: `LEDGER-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString(),
      product_id: product.product_id,
      product_name: product.name,
      event_type: 'STOCK_DISPENSED',
      quantity_units: 1,
      volume_litres: volumeLitresDispensed,
      unit_cost_gbp: product.purchase_price,
      total_value_gbp: product.purchase_price,
      source_location: 'CELLAR',
      destination_location: 'MAIN_BAR',
      reference_id: pourId,
      notes: `Dispensed ${actualVolume}mL physically`
    };
    this.state.stock_ledger.unshift(stockEntry);

    // Update Real-Time Metrics
    this.state.metrics.revenue_today_gbp = Math.round((this.state.metrics.revenue_today_gbp + salePrice) * 100) / 100;
    this.state.metrics.pints_sold_today += 1;
    this.state.metrics.total_litres_dispensed_today = Math.round((this.state.metrics.total_litres_dispensed_today + volumeLitresDispensed) * 10) / 10;
    this.state.metrics.cogs_today_gbp = Math.round((this.state.metrics.cogs_today_gbp + product.purchase_price) * 100) / 100;

    // Check low stock alert trigger
    if (keg && keg.current_volume_litres < 5.0) {
      const existingAlert = this.state.alerts.find(a => a.subsystem === 'CELLAR' && a.title.includes(keg.keg_id));
      if (!existingAlert) {
        this.state.alerts.unshift({
          alert_id: `ALT-${Date.now().toString().slice(-4)}`,
          timestamp: new Date().toISOString(),
          severity: 'CRITICAL',
          title: `Low Stock Keg Alert: ${keg.keg_id}`,
          message: `${keg.product_name} on ${nozzle.nozzle_id} has only ${keg.current_volume_litres.toFixed(2)}L remaining!`,
          subsystem: 'CELLAR',
          acknowledged: false,
          action_recommendation: `Autonomous Procurement Level ${this.state.automation_level}: Order replacement batch.`
        });
      }
    }

    this.notify();
    return newPour;
  }

  // Employee Clocking
  public toggleEmployeeClock(employeeId: string) {
    const emp = this.state.employees.find(e => e.employee_id === employeeId);
    if (emp) {
      emp.clocked_in = !emp.clocked_in;
      if (emp.clocked_in) {
        emp.current_shift_start = new Date().toISOString();
      } else {
        emp.current_shift_start = undefined;
      }
      this.notify();
    }
  }

  // Create Purchase Order
  public createPurchaseOrder(supplierId: string, productId: string, qty: number): PurchaseOrder {
    const supplier = this.state.suppliers.find(s => s.supplier_id === supplierId);
    const product = this.state.products.find(p => p.product_id === productId);
    
    if (!supplier || !product) {
      throw new Error('Invalid supplier or product ID');
    }

    const unitPrice = product.purchase_price * 50; // PO in keg units
    const lineTotal = unitPrice * qty;
    const tax = lineTotal * 0.20;
    const total = lineTotal + tax;

    const po: PurchaseOrder = {
      po_id: `PO-2026-${Math.floor(100 + Math.random() * 900)}`,
      supplier_id: supplier.supplier_id,
      supplier_name: supplier.name,
      created_at: new Date().toISOString(),
      expected_delivery: new Date(Date.now() + supplier.lead_time_days * 86400000).toISOString().split('T')[0],
      status: this.state.automation_level >= 3 ? 'ORDERED' : 'APPROVED',
      lines: [
        {
          product_id: product.product_id,
          product_name: product.name,
          ordered_quantity: qty,
          unit_price_gbp: unitPrice,
          line_total_gbp: lineTotal
        }
      ],
      subtotal_gbp: lineTotal,
      tax_gbp: tax,
      total_gbp: total,
      three_way_match: {
        po_matched: true,
        grn_matched: false,
        invoice_matched: false
      }
    };

    this.state.purchase_orders.unshift(po);
    this.notify();
    return po;
  }

  // Simulate Telemetry Step
  public tickTelemetry() {
    if (!this.state.live_simulation_active) return;

    // Slight temperature noise in cellar and fridge
    const fridgeAsset = this.state.assets.find(a => a.asset_id === 'AST-FRIDGE-BAR1-01');
    if (fridgeAsset && fridgeAsset.sensor_state) {
      fridgeAsset.sensor_state.temperature_c = Math.round((6.5 + Math.sin(Date.now() / 10000) * 0.5) * 10) / 10;
    }

    // Slight power variation
    this.state.daily_energy_kwh = Math.round((this.state.daily_energy_kwh + 0.05) * 100) / 100;
    this.state.daily_energy_cost_gbp = Math.round(this.state.daily_energy_kwh * 0.30 * 100) / 100;

    this.notify();
  }
}

export const pubStore = new PubStore();
