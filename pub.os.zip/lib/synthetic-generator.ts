import { 
  PubTwin, Product, KegTwin, NozzleController, PhysicalAsset, 
  Supplier, Employee, DoubleEntryAccount, ForecastPoint, MaintenancePrediction, OperationalAlert, StockLedgerEntry, ShiftRecord, TelemetryReading
} from '@/types/pub-os';

export function createInitialPubTwin(): PubTwin {
  const products: Product[] = [
    {
      product_id: 'PRD-001',
      SKU: 'BEER-IPA-01',
      name: 'CyberHop Craft IPA',
      category: 'DRAUGHT_BEER',
      brand: 'Rust & Barley Microbrewery',
      supplier_id: 'SUP-001',
      unit: 'pint',
      purchase_price: 1.45,
      selling_price: 6.20,
      vat_rate: 0.20,
      container_size_litres: 50.0,
      alcohol_abv: 5.4,
      storage_requirement: 'CELLAR_COLD',
      minimum_stock: 4,
      maximum_stock: 12,
      reorder_point: 5,
      lead_time_days: 2,
      shelf_life_days: 60,
      density_g_ml: 1.012
    },
    {
      product_id: 'PRD-002',
      SKU: 'BEER-STOUT-01',
      name: 'Quantum Stout',
      category: 'DRAUGHT_BEER',
      brand: 'Heavy Industry Brewing',
      supplier_id: 'SUP-001',
      unit: 'pint',
      purchase_price: 1.60,
      selling_price: 6.50,
      vat_rate: 0.20,
      container_size_litres: 50.0,
      alcohol_abv: 6.0,
      storage_requirement: 'CELLAR_COLD',
      minimum_stock: 3,
      maximum_stock: 10,
      reorder_point: 4,
      lead_time_days: 2,
      shelf_life_days: 90,
      density_g_ml: 1.022
    },
    {
      product_id: 'PRD-003',
      SKU: 'BEER-LAGER-01',
      name: 'Precision Pilsner',
      category: 'DRAUGHT_BEER',
      brand: 'Nordic Control Brewery',
      supplier_id: 'SUP-002',
      unit: 'pint',
      purchase_price: 1.20,
      selling_price: 5.80,
      vat_rate: 0.20,
      container_size_litres: 50.0,
      alcohol_abv: 4.8,
      storage_requirement: 'CELLAR_COLD',
      minimum_stock: 6,
      maximum_stock: 20,
      reorder_point: 8,
      lead_time_days: 1,
      shelf_life_days: 45,
      density_g_ml: 1.008
    },
    {
      product_id: 'PRD-004',
      SKU: 'CIDER-01',
      name: 'Orchard IoT Apple Cider',
      category: 'CIDER',
      brand: 'Cyber Orchard',
      supplier_id: 'SUP-003',
      unit: 'pint',
      purchase_price: 1.30,
      selling_price: 5.90,
      vat_rate: 0.20,
      container_size_litres: 50.0,
      alcohol_abv: 5.0,
      storage_requirement: 'CELLAR_COLD',
      minimum_stock: 3,
      maximum_stock: 8,
      reorder_point: 4,
      lead_time_days: 2,
      shelf_life_days: 120,
      density_g_ml: 1.018
    },
    {
      product_id: 'PRD-005',
      SKU: 'SPIRIT-GIN-01',
      name: 'Botanical Vector Gin',
      category: 'SPIRITS',
      brand: 'Distillery 4.0',
      supplier_id: 'SUP-004',
      unit: 'shot (25ml)',
      purchase_price: 0.40,
      selling_price: 4.50,
      vat_rate: 0.20,
      container_size_litres: 0.7,
      alcohol_abv: 41.5,
      storage_requirement: 'DRY_STORAGE',
      minimum_stock: 6,
      maximum_stock: 24,
      reorder_point: 8,
      lead_time_days: 3,
      shelf_life_days: 730,
      density_g_ml: 0.940
    },
    {
      product_id: 'PRD-006',
      SKU: 'WINE-MALBEC-01',
      name: 'Mendoza Digital Reserve Malbec',
      category: 'WINE',
      brand: 'Estate Twin Vintners',
      supplier_id: 'SUP-005',
      unit: 'glass (175ml)',
      purchase_price: 1.80,
      selling_price: 7.20,
      vat_rate: 0.20,
      container_size_litres: 0.75,
      alcohol_abv: 13.8,
      storage_requirement: 'CELLAR_COLD',
      minimum_stock: 12,
      maximum_stock: 48,
      reorder_point: 15,
      lead_time_days: 3,
      shelf_life_days: 365,
      density_g_ml: 0.995
    },
    {
      product_id: 'PRD-007',
      SKU: 'FOOD-BURGER-01',
      name: 'Cyber-Smash Double Wagyu Burger',
      category: 'FOOD',
      brand: 'Pub.OS Kitchen',
      supplier_id: 'SUP-006',
      unit: 'portion',
      purchase_price: 3.80,
      selling_price: 14.50,
      vat_rate: 0.20,
      storage_requirement: 'REFRIGERATED',
      minimum_stock: 20,
      maximum_stock: 100,
      reorder_point: 30,
      lead_time_days: 1,
      shelf_life_days: 5,
      density_g_ml: 1.000
    },
    {
      product_id: 'PRD-008',
      SKU: 'FOOD-FISH-01',
      name: 'Crispy Pilsner Batter Fish & Chips',
      category: 'FOOD',
      brand: 'Pub.OS Kitchen',
      supplier_id: 'SUP-006',
      unit: 'portion',
      purchase_price: 4.10,
      selling_price: 15.80,
      vat_rate: 0.20,
      storage_requirement: 'FROZEN',
      minimum_stock: 15,
      maximum_stock: 80,
      reorder_point: 25,
      lead_time_days: 1,
      shelf_life_days: 14,
      density_g_ml: 1.000
    }
  ];

  // 20 Taps and 10 connected active kegs + cellar stock
  const kegs: KegTwin[] = [
    {
      keg_id: 'KEG-A101',
      product_id: 'PRD-001',
      product_name: 'CyberHop Craft IPA',
      batch_id: 'BATCH-2026-881',
      supplier_id: 'SUP-001',
      capacity_litres: 50.0,
      current_volume_litres: 38.42,
      initial_volume_litres: 50.0,
      temperature_c: 4.2,
      pressure_bar: 2.1,
      location: 'CELLAR',
      connected: true,
      tap_id: 'TAP-01',
      installation_time: '2026-09-03T10:00:00Z',
      quality_state: 'OPTIMAL',
      litres_remaining: 38.42,
      pints_remaining: 67.62,
      estimated_sales_remaining_gbp: 419.24,
      estimated_remaining_hours: 18.5
    },
    {
      keg_id: 'KEG-A102',
      product_id: 'PRD-002',
      product_name: 'Quantum Stout',
      batch_id: 'BATCH-2026-702',
      supplier_id: 'SUP-001',
      capacity_litres: 50.0,
      current_volume_litres: 11.73,
      initial_volume_litres: 50.0,
      temperature_c: 5.1,
      pressure_bar: 2.3,
      location: 'CELLAR',
      connected: true,
      tap_id: 'TAP-02',
      installation_time: '2026-09-02T14:30:00Z',
      quality_state: 'OPTIMAL',
      litres_remaining: 11.73,
      pints_remaining: 20.65,
      estimated_sales_remaining_gbp: 134.22,
      estimated_remaining_hours: 5.2
    },
    {
      keg_id: 'KEG-A103',
      product_id: 'PRD-003',
      product_name: 'Precision Pilsner',
      batch_id: 'BATCH-2026-990',
      supplier_id: 'SUP-002',
      capacity_litres: 50.0,
      current_volume_litres: 44.10,
      initial_volume_litres: 50.0,
      temperature_c: 3.8,
      pressure_bar: 2.0,
      location: 'CELLAR',
      connected: true,
      tap_id: 'TAP-03',
      installation_time: '2026-09-04T09:15:00Z',
      quality_state: 'OPTIMAL',
      litres_remaining: 44.10,
      pints_remaining: 77.64,
      estimated_sales_remaining_gbp: 450.31,
      estimated_remaining_hours: 24.0
    },
    {
      keg_id: 'KEG-A104',
      product_id: 'PRD-004',
      product_name: 'Orchard IoT Apple Cider',
      batch_id: 'BATCH-2026-411',
      supplier_id: 'SUP-003',
      capacity_litres: 50.0,
      current_volume_litres: 4.12,
      initial_volume_litres: 50.0,
      temperature_c: 4.5,
      pressure_bar: 2.2,
      location: 'CELLAR',
      connected: true,
      tap_id: 'TAP-04',
      installation_time: '2026-09-01T11:00:00Z',
      quality_state: 'DEGRADED',
      litres_remaining: 4.12,
      pints_remaining: 7.25,
      estimated_sales_remaining_gbp: 42.78,
      estimated_remaining_hours: 1.8
    }
  ];

  // 20 Nozzle Controllers
  const nozzles: NozzleController[] = Array.from({ length: 20 }).map((_, idx) => {
    const tapNum = idx + 1;
    const isConnected = tapNum <= 4;
    const keg = kegs[idx];
    return {
      nozzle_id: `NZL-${tapNum.toString().padStart(2, '0')}`,
      tap_number: tapNum,
      bar_id: tapNum <= 10 ? 'MAIN_BAR' : 'LOUNGE_BAR',
      product_id: isConnected ? keg.product_id : 'PRD-001',
      product_name: isConnected ? keg.product_name : `Draft Tap #${tapNum}`,
      keg_id: isConnected ? keg.keg_id : `KEG-OFFLINE-${tapNum}`,
      device_id: `FLOW-DEVICE-${tapNum}`,
      target_volume_ml: 568, // 1 Pint in mL
      actual_volume_ml: 0,
      current_flow_rate_ml_s: 0,
      stage: 'STOP',
      pressure_bar: isConnected ? keg.pressure_bar : 0,
      temperature_c: isConnected ? keg.temperature_c : 20.0,
      calibration_factor: 1.002,
      valve_open: false
    };
  });

  const assets: PhysicalAsset[] = [
    {
      asset_id: 'AST-CELLAR-COOL-01',
      asset_type: 'CELLAR_COOLER',
      name: 'Cellar Master Climate System 4.0',
      manufacturer: 'KlimatTech GmbH',
      model: 'K-Cool-9000',
      serial_number: 'SN-99812-CL',
      location: 'CELLAR',
      status: 'OPERATIONAL',
      installation_date: '2024-03-15',
      maintenance_state: {
        last_service: '2026-06-01',
        next_due: '2026-12-01',
        health_score: 94,
        failure_probability: 0.03,
        remaining_useful_life_days: 412
      },
      energy_state: {
        power_kw: 2.8,
        voltage: 230,
        current_amp: 12.2,
        daily_kwh: 42.5
      },
      sensor_state: {
        temperature_c: 4.1,
        pressure_bar: 2.15,
        vibration_hz: 12.4
      }
    },
    {
      asset_id: 'AST-FRIDGE-BAR1-01',
      asset_type: 'REFRIGERATOR',
      name: 'Main Bar Triple Door Chiller',
      manufacturer: 'ColdDisplay Systems',
      model: 'CD-300-PRO',
      serial_number: 'SN-11204-FR',
      location: 'MAIN_BAR',
      status: 'WARNING',
      installation_date: '2023-11-20',
      maintenance_state: {
        last_service: '2026-01-10',
        next_due: '2026-09-10',
        health_score: 71,
        failure_probability: 0.28,
        remaining_useful_life_days: 21
      },
      energy_state: {
        power_kw: 1.4,
        voltage: 228,
        current_amp: 6.1,
        daily_kwh: 21.8
      },
      sensor_state: {
        temperature_c: 6.8, // Slightly elevated!
        vibration_hz: 38.2 // High compressor vibration!
      }
    },
    {
      asset_id: 'AST-DISPENSER-PRECISION-01',
      asset_type: 'DRAUGHT_DISPENSER',
      name: 'RoboPour Precision 20-Tap Bank',
      manufacturer: 'Fluidic Dynamics Robotics',
      model: 'FP-20-PRO',
      serial_number: 'SN-77210-RP',
      location: 'MAIN_BAR',
      status: 'OPERATIONAL',
      installation_date: '2025-01-10',
      maintenance_state: {
        last_service: '2026-08-01',
        next_due: '2026-11-01',
        health_score: 98,
        failure_probability: 0.01,
        remaining_useful_life_days: 620
      },
      energy_state: {
        power_kw: 0.6,
        voltage: 230,
        current_amp: 2.6,
        daily_kwh: 8.4
      },
      sensor_state: {
        flow_ml_s: 48.5,
        pressure_bar: 2.2
      }
    }
  ];

  const suppliers: Supplier[] = [
    {
      supplier_id: 'SUP-001',
      name: 'Rust & Barley Microbrewery Ltd',
      lead_time_days: 2,
      minimum_order_gbp: 250,
      delivery_schedule: 'Tuesdays & Fridays',
      reliability_score: 98.2,
      invoice_accuracy_score: 99.5,
      historical_price_variance_pct: 1.2,
      active_products: ['PRD-001', 'PRD-002']
    },
    {
      supplier_id: 'SUP-002',
      name: 'Nordic Craft Distributors',
      lead_time_days: 1,
      minimum_order_gbp: 300,
      delivery_schedule: 'Daily Morning',
      reliability_score: 96.0,
      invoice_accuracy_score: 98.0,
      historical_price_variance_pct: 2.5,
      active_products: ['PRD-003']
    },
    {
      supplier_id: 'SUP-003',
      name: 'Cyber Orchard Ciders Ltd',
      lead_time_days: 2,
      minimum_order_gbp: 200,
      delivery_schedule: 'Wednesdays',
      reliability_score: 94.5,
      invoice_accuracy_score: 97.2,
      historical_price_variance_pct: 0.8,
      active_products: ['PRD-004']
    }
  ];

  const employees: Employee[] = [
    { employee_id: 'EMP-001', name: 'Alexander Wright', role: 'MANAGER', employment_state: 'ACTIVE', pay_rate_hourly_gbp: 18.50, contract_hours_weekly: 40, skills: ['Management', 'Cellar Master', 'POS Admin'], clocked_in: true, current_shift_start: '2026-09-05T08:00:00Z' },
    { employee_id: 'EMP-002', name: 'Elena Rostova', role: 'SUPERVISOR', employment_state: 'ACTIVE', pay_rate_hourly_gbp: 14.20, contract_hours_weekly: 35, skills: ['Bar Lead', 'Mixology', 'Inventory'], clocked_in: true, current_shift_start: '2026-09-05T10:00:00Z' },
    { employee_id: 'EMP-003', name: 'Marcus Chen', role: 'BAR', employment_state: 'ACTIVE', pay_rate_hourly_gbp: 12.00, contract_hours_weekly: 25, skills: ['Precision Pouring', 'Customer Flow'], clocked_in: true, current_shift_start: '2026-09-05T11:30:00Z' },
    { employee_id: 'EMP-004', name: 'Sarah Jenkins', role: 'BAR', employment_state: 'ACTIVE', pay_rate_hourly_gbp: 12.00, contract_hours_weekly: 30, skills: ['Speed Service', 'Tabs'], clocked_in: false },
    { employee_id: 'EMP-005', name: 'Chef David Miller', role: 'KITCHEN', employment_state: 'ACTIVE', pay_rate_hourly_gbp: 16.00, contract_hours_weekly: 40, skills: ['Head Chef', 'HACCP', 'Cost Control'], clocked_in: true, current_shift_start: '2026-09-05T09:00:00Z' },
    { employee_id: 'EMP-006', name: 'Liam O’Connor', role: 'MAINTENANCE', employment_state: 'ACTIVE', pay_rate_hourly_gbp: 17.00, contract_hours_weekly: 20, skills: ['IoT Sensors', 'Line Cleaning', 'HVAC'], clocked_in: false }
  ];

  const accounts: DoubleEntryAccount[] = [
    { account_code: '1010', account_name: 'Cash / Card Clearing', type: 'ASSET', balance_gbp: 4827.40 },
    { account_code: '1200', account_name: 'Inventory Stock Asset', type: 'ASSET', balance_gbp: 14250.00 },
    { account_code: '2000', account_name: 'Supplier Accounts Payable', type: 'LIABILITY', balance_gbp: 3410.00 },
    { account_code: '2200', account_name: 'VAT / Tax Payable', type: 'LIABILITY', balance_gbp: 965.48 },
    { account_code: '4000', account_name: 'Sales Revenue - Draught Beer', type: 'REVENUE', balance_gbp: 3210.00 },
    { account_code: '4010', account_name: 'Sales Revenue - Food', type: 'REVENUE', balance_gbp: 1617.40 },
    { account_code: '5000', account_name: 'Cost of Goods Sold (COGS)', type: 'EXPENSE', balance_gbp: 1583.39 },
    { account_code: '5100', account_name: 'Labour Wage Expense', type: 'EXPENSE', balance_gbp: 734.20 },
    { account_code: '5200', account_name: 'Energy & Utility Expense', type: 'EXPENSE', balance_gbp: 96.40 },
    { account_code: '5300', account_name: 'Wastage & Spoilage Expense', type: 'EXPENSE', balance_gbp: 82.00 }
  ];

  const forecast: ForecastPoint[] = [
    { time_label: '12:00', actual_sales_gbp: 340, forecast_sales_gbp: 320, confidence_lower_gbp: 290, confidence_upper_gbp: 350, predicted_customer_count: 28, predicted_pint_demand: 42 },
    { time_label: '14:00', actual_sales_gbp: 680, forecast_sales_gbp: 650, confidence_lower_gbp: 600, confidence_upper_gbp: 700, predicted_customer_count: 52, predicted_pint_demand: 88 },
    { time_label: '16:00', actual_sales_gbp: 1250, forecast_sales_gbp: 1200, confidence_lower_gbp: 1100, confidence_upper_gbp: 1300, predicted_customer_count: 95, predicted_pint_demand: 160 },
    { time_label: '18:00', actual_sales_gbp: 2400, forecast_sales_gbp: 2350, confidence_lower_gbp: 2100, confidence_upper_gbp: 2550, predicted_customer_count: 180, predicted_pint_demand: 320 },
    { time_label: '20:00', actual_sales_gbp: 3950, forecast_sales_gbp: 3800, confidence_lower_gbp: 3500, confidence_upper_gbp: 4100, predicted_customer_count: 240, predicted_pint_demand: 480 },
    { time_label: '22:00', forecast_sales_gbp: 4690, confidence_lower_gbp: 4300, confidence_upper_gbp: 5000, predicted_customer_count: 210, predicted_pint_demand: 410 },
    { time_label: '24:00', forecast_sales_gbp: 5100, confidence_lower_gbp: 4600, confidence_upper_gbp: 5500, predicted_customer_count: 120, predicted_pint_demand: 210 }
  ];

  const maintenance_predictions: MaintenancePrediction[] = [
    {
      asset_id: 'AST-FRIDGE-BAR1-01',
      asset_name: 'Main Bar Triple Door Chiller',
      failure_probability: 0.28,
      remaining_useful_life_days: 21,
      confidence_pct: 88,
      evidence: ['Compressor vibration +34% above baseline', 'Internal temperature drift (+2.7°C)', 'Duty cycle continuous 92%'],
      recommended_action: 'Replace compressor fan assembly and clean condenser coils',
      expected_economic_effect_gbp: 1450.00 // avoided food/beer spoilage
    }
  ];

  const alerts: OperationalAlert[] = [
    {
      alert_id: 'ALT-001',
      timestamp: '2026-09-05T01:30:00Z',
      severity: 'WARNING',
      title: 'Keg Near Empty',
      message: 'Orchard IoT Apple Cider (KEG-A104) on TAP-04 has 4.12 L remaining (~7.2 pints).',
      subsystem: 'CELLAR',
      acknowledged: false,
      action_recommendation: 'Prepare replacement Keg B209 from cellar cold storage.'
    },
    {
      alert_id: 'ALT-002',
      timestamp: '2026-09-05T01:15:00Z',
      severity: 'CRITICAL',
      title: 'Refrigeration Temperature Anomaly',
      message: 'Main Bar Triple Door Chiller temperature at 6.8°C (Threshold 4.0°C). Compressor duty cycle high.',
      subsystem: 'EQUIPMENT',
      acknowledged: false,
      action_recommendation: 'Dispatch maintenance technician. Re-route bottled stock to Cellar 2.'
    },
    {
      alert_id: 'ALT-003',
      timestamp: '2026-09-05T01:00:00Z',
      severity: 'NOTICE',
      title: 'Recommended Automated Order',
      message: 'R Forecast model predicts stockout of CyberHop IPA in 18.5 hours. Recommended PO for 6x 50L Kegs.',
      subsystem: 'PROCUREMENT',
      acknowledged: false,
      action_recommendation: 'Approve PO-2026-904 to Rust & Barley Microbrewery.'
    }
  ];

  const stock_ledger: StockLedgerEntry[] = [
    {
      entry_id: 'LEDGER-001',
      timestamp: '2026-09-05T00:10:00Z',
      product_id: 'PRD-001',
      product_name: 'CyberHop Craft IPA',
      event_type: 'STOCK_DISPENSED',
      quantity_units: 1,
      volume_litres: 0.568,
      unit_cost_gbp: 1.45,
      total_value_gbp: 1.45,
      source_location: 'CELLAR',
      destination_location: 'MAIN_BAR',
      reference_id: 'POUR-8801',
      notes: 'Precision pour 568mL on TAP-01'
    }
  ];

  return {
    pub_id: 'PUB-TEST-01',
    pub_name: 'The Cyber-Physical Tavern',
    address: '42 Industry Way, London EC1V 2NX',
    automation_level: 2, // LEVEL 2 — APPROVAL
    live_simulation_active: true,
    assets,
    products,
    kegs,
    nozzles,
    stock_ledger,
    suppliers,
    purchase_orders: [
      {
        po_id: 'PO-2026-904',
        supplier_id: 'SUP-001',
        supplier_name: 'Rust & Barley Microbrewery Ltd',
        created_at: '2026-09-04T16:00:00Z',
        expected_delivery: '2026-09-06T09:00:00Z',
        status: 'RECOMMENDED',
        lines: [
          {
            product_id: 'PRD-001',
            product_name: 'CyberHop Craft IPA',
            ordered_quantity: 6,
            unit_price_gbp: 125.00,
            line_total_gbp: 750.00
          }
        ],
        subtotal_gbp: 750.00,
        tax_gbp: 150.00,
        total_gbp: 900.00,
        three_way_match: {
          po_matched: true,
          grn_matched: false,
          invoice_matched: false
        }
      }
    ],
    pours_history: [
      {
        pour_id: 'POUR-8801',
        timestamp: '2026-09-05T00:10:00Z',
        nozzle_id: 'NZL-01',
        bartender_id: 'EMP-003',
        product_id: 'PRD-001',
        product_name: 'CyberHop Craft IPA',
        keg_id: 'KEG-A101',
        target_volume_ml: 568,
        actual_volume_ml: 570.2,
        error_volume_ml: 2.2,
        error_percent: 0.38,
        duration_s: 11.2,
        avg_flow_ml_s: 50.9,
        peak_flow_ml_s: 58.0,
        temperature_c: 4.2,
        pressure_bar: 2.1,
        pour_state: 'INVENTORY_UPDATED',
        sale_price_gbp: 6.20,
        variance_classification: 'PROCESS_VARIANCE'
      }
    ],
    accounts,
    journal_entries: [],
    employees,
    active_shifts: [
      {
        shift_id: 'SHF-001',
        employee_id: 'EMP-001',
        employee_name: 'Alexander Wright',
        role: 'MANAGER',
        clock_in: '2026-09-05T08:00:00Z',
        break_minutes: 30,
        hours_worked: 5.5,
        regular_pay_gbp: 101.75,
        overtime_pay_gbp: 0,
        total_employer_cost_gbp: 115.00
      }
    ],
    telemetry: [
      { sensor_id: 'SEN-TEMP-CELLAR', asset_id: 'AST-CELLAR-COOL-01', asset_name: 'Cellar Climate', timestamp: new Date().toISOString(), metric_name: 'Temperature', value: 4.1, unit: '°C', quality: 'VALID', normal_min: 3.5, normal_max: 5.5 },
      { sensor_id: 'SEN-PRESS-TAP01', asset_id: 'AST-DISPENSER-PRECISION-01', asset_name: 'TAP-01 Line', timestamp: new Date().toISOString(), metric_name: 'CO2 Pressure', value: 2.1, unit: 'bar', quality: 'VALID', normal_min: 1.8, normal_max: 2.4 },
      { sensor_id: 'SEN-VIB-FRIDGE1', asset_id: 'AST-FRIDGE-BAR1-01', asset_name: 'Main Bar Chiller', timestamp: new Date().toISOString(), metric_name: 'Compressor Vibration', value: 38.2, unit: 'Hz', quality: 'CALIBRATION_REQUIRED', normal_min: 5.0, normal_max: 25.0 }
    ],
    maintenance_predictions,
    daily_energy_kwh: 128.4,
    daily_energy_cost_gbp: 38.52, // @ 0.30/kWh
    forecast,
    alerts,
    metrics: {
      revenue_today_gbp: 4827.40,
      revenue_forecast_gbp: 4690.00,
      variance_pct: 2.93,
      cogs_today_gbp: 1583.39,
      gross_margin_pct: 67.2,
      labour_cost_today_gbp: 734.20,
      labour_pct: 15.2,
      energy_cost_today_gbp: 96.40,
      waste_cost_today_gbp: 82.00,
      waste_pct: 1.70,
      operating_profit_today_gbp: 2331.41,
      total_litres_dispensed_today: 428.5,
      pints_sold_today: 754,
      pour_variance_pct: +0.42, // +0.42% slight overpour
      customer_count_today: 412,
      sales_per_staff_hour_gbp: 142.00,
      inventory_capital_value_gbp: 14250.00,
      break_even_pints_daily: 320
    }
  };
}
