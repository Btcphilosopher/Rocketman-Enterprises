export type Department = 
  | 'News'
  | 'University'
  | 'Opinion'
  | 'Global'
  | 'Science & Tech'
  | 'Arts'
  | 'Sports'
  | 'Magazine'
  | 'Podcasts'
  | 'Research'
  | 'Medicine'
  | 'Engineering'
  | 'Humanities'
  | 'Business'
  | 'Markets'
  | 'Politics'
  | 'Law'
  | 'Technology';

export interface Author {
  id: string;
  name: string;
  role: string;
  department?: string;
  avatar: string;
  bio: string;
  lightningAddress?: string;
  btcAddress?: string;
}

export interface Citation {
  id: string;
  authors: string;
  title: string;
  journalOrPublisher: string;
  year: number;
  doi?: string;
  url?: string;
}

export interface Comment {
  id: string;
  articleId: string;
  authorName: string;
  authorRole: 'Student' | 'Faculty' | 'Alumni' | 'Reader';
  avatar: string;
  timestamp: string;
  content: string;
  likes: number;
}

export interface ArticleChartData {
  title: string;
  description: string;
  type: 'line' | 'bar' | 'pie';
  data: Array<Record<string, any>>;
  dataKeys: string[];
  xAxisKey: string;
}

export interface Article {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  department: Department;
  categoryTag: string; // e.g. "TOP STORY", "FEATURE", "COLUMN", "RESEARCH"
  author: Author;
  publishedAt: string;
  updatedAt?: string;
  readTimeMinutes: number;
  featuredImage: string;
  caption?: string;
  photoCredit?: string;
  isHero?: boolean;
  isBreaking?: boolean;
  isEditorsPick?: boolean;
  isTrending?: boolean;
  summary: string;
  content: string[]; // Content paragraphs
  pullQuote?: string;
  citations?: Citation[];
  chartData?: ArticleChartData;
  audioNarrationUrl?: string;
  relatedArticleIds?: string[];
  viewCount: number;
  satsTipped?: number;
  isPremiumPaywall?: boolean;
  paywallSatsPrice?: number;
}

export interface BitcoinWalletState {
  isConnected: boolean;
  walletType: 'WebLN' | 'Alby' | 'Xverse' | 'Unisat' | 'NWC' | 'Manual' | null;
  pubkey?: string;
  lightningAddress?: string;
  balanceSats: number;
  nodeAlias?: string;
}

export interface LightningInvoice {
  id: string;
  paymentHash: string;
  paymentRequest: string;
  amountSats: number;
  description: string;
  status: 'pending' | 'settled' | 'expired';
  createdAt: number;
  settledAt?: number;
}

export interface TipTransaction {
  id: string;
  articleId?: string;
  articleTitle?: string;
  authorName?: string;
  amountSats: number;
  timestamp: string;
  note?: string;
  paymentHash?: string;
}

export interface PodcastEpisode {
  id: string;
  title: string;
  showName: string;
  host: string;
  guest?: string;
  date: string;
  duration: string;
  audioUrl: string;
  coverImage: string;
  description: string;
  transcript: string[];
}

export interface VideoDoc {
  id: string;
  title: string;
  duration: string;
  category: string;
  thumbnail: string;
  youtubeId?: string;
  videoUrl?: string;
  description: string;
  producer: string;
}

export interface ArchiveEntry {
  year: number;
  dateStr: string;
  title: string;
  snippet: string;
  department: Department;
  headlineImage?: string;
  historicalContext: string;
}

export interface ReaderSettings {
  fontSize: 'sm' | 'base' | 'lg' | 'xl';
  fontFamily: 'serif' | 'sans';
  highContrast: boolean;
  lineSpacing: 'comfortable' | 'spacious';
}

export interface CMSArticleDraft {
  id: string;
  title: string;
  subtitle: string;
  department: Department;
  categoryTag: string;
  authorName: string;
  status: 'Draft' | 'Editorial Review' | 'Fact Checking' | 'Published';
  content: string;
  featuredImage: string;
  lastEdited: string;
}

export interface CampusEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  department: string;
  speaker: string;
  description: string;
  registrationUrl?: string;
}
