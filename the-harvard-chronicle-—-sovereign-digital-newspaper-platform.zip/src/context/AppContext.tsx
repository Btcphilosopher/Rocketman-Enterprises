import React, { createContext, useContext, useState, useEffect } from 'react';
import { Article, Department, PodcastEpisode, ReaderSettings, CMSArticleDraft, BitcoinWalletState, TipTransaction, LightningInvoice } from '../types';
import { INITIAL_ARTICLES } from '../data/mockArticles';

interface AppContextType {
  articles: Article[];
  activeDepartment: Department | 'All';
  setActiveDepartment: (dept: Department | 'All') => void;
  selectedArticle: Article | null;
  setSelectedArticle: (art: Article | null) => void;
  savedArticleIds: string[];
  toggleSaveArticle: (id: string) => void;
  readingHistory: string[];
  addToHistory: (id: string) => void;
  activePodcast: PodcastEpisode | null;
  setActivePodcast: (pod: PodcastEpisode | null) => void;
  audioNarrationArticle: Article | null;
  setAudioNarrationArticle: (art: Article | null) => void;
  isPlayingAudio: boolean;
  setIsPlayingAudio: React.Dispatch<React.SetStateAction<boolean>>;
  audioSpeed: number;
  setAudioSpeed: (speed: number) => void;
  audioProgress: number;
  setAudioProgress: (prog: number) => void;
  readerSettings: ReaderSettings;
  updateReaderSettings: (settings: Partial<ReaderSettings>) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  isSearchModalOpen: boolean;
  setIsSearchModalOpen: (open: boolean) => void;
  isCMSModalOpen: boolean;
  setIsCMSModalOpen: (open: boolean) => void;
  isArchiveModalOpen: boolean;
  setIsArchiveModalOpen: (open: boolean) => void;
  isEventsModalOpen: boolean;
  setIsEventsModalOpen: (open: boolean) => void;
  isRSSModalOpen: boolean;
  setIsRSSModalOpen: (open: boolean) => void;
  rssTargetAuthor: any | null;
  setRssTargetAuthor: (author: any | null) => void;
  activeView: 'home' | 'department' | 'multimedia' | 'archive' | 'events' | 'markets';
  setActiveView: (view: 'home' | 'department' | 'multimedia' | 'archive' | 'events' | 'markets') => void;
  addCMSArticle: (draft: CMSArticleDraft) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;

  // Bitcoin & Lightning Micropayments
  isWalletModalOpen: boolean;
  setIsWalletModalOpen: (open: boolean) => void;
  isTipModalOpen: boolean;
  setIsTipModalOpen: (open: boolean) => void;
  tipTargetArticle: Article | null;
  setTipTargetArticle: (art: Article | null) => void;
  walletState: BitcoinWalletState;
  unlockedArticleIds: string[];
  tipHistory: TipTransaction[];
  btcPriceUSD: number;
  totalChronicleSats: number;
  connectWallet: (type: BitcoinWalletState['walletType']) => Promise<boolean>;
  disconnectWallet: () => void;
  tipSatsToArticle: (articleId: string, satsAmount: number, note?: string) => Promise<boolean>;
  unlockArticleWithSats: (articleId: string, satsPrice: number) => Promise<boolean>;
  generateLightningInvoice: (satsAmount: number, description: string) => LightningInvoice;
  hasWebLN: boolean;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [articles, setArticles] = useState<Article[]>(() => {
    const local = localStorage.getItem('hc_articles');
    return local ? JSON.parse(local) : INITIAL_ARTICLES;
  });

  const [activeDepartment, setActiveDepartment] = useState<Department | 'All'>('All');
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [savedArticleIds, setSavedArticleIds] = useState<string[]>(() => {
    const local = localStorage.getItem('hc_saved_articles');
    return local ? JSON.parse(local) : ['art-1', 'art-7'];
  });
  const [readingHistory, setReadingHistory] = useState<string[]>([]);
  
  // Audio Player State
  const [activePodcast, setActivePodcast] = useState<PodcastEpisode | null>(null);
  const [audioNarrationArticle, setAudioNarrationArticle] = useState<Article | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [audioSpeed, setAudioSpeed] = useState<number>(1);
  const [audioProgress, setAudioProgress] = useState<number>(0);

  // Reader Mode Preferences
  const [readerSettings, setReaderSettings] = useState<ReaderSettings>({
    fontSize: 'base',
    fontFamily: 'serif',
    highContrast: false,
    lineSpacing: 'spacious'
  });

  // Dark Mode
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('hc_theme') === 'dark';
  });

  // Modals
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isCMSModalOpen, setIsCMSModalOpen] = useState(false);
  const [isArchiveModalOpen, setIsArchiveModalOpen] = useState(false);
  const [isEventsModalOpen, setIsEventsModalOpen] = useState(false);
  const [isRSSModalOpen, setIsRSSModalOpen] = useState(false);
  const [rssTargetAuthor, setRssTargetAuthor] = useState<any | null>(null);
  const [activeView, setActiveView] = useState<'home' | 'department' | 'multimedia' | 'archive' | 'events' | 'markets'>('home');
  const [searchQuery, setSearchQuery] = useState('');

  // Bitcoin & Lightning Micropayments State
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isTipModalOpen, setIsTipModalOpen] = useState(false);
  const [tipTargetArticle, setTipTargetArticle] = useState<Article | null>(null);
  
  const [walletState, setWalletState] = useState<BitcoinWalletState>(() => {
    const saved = localStorage.getItem('hc_btc_wallet');
    return saved ? JSON.parse(saved) : {
      isConnected: false,
      walletType: null,
      balanceSats: 0
    };
  });

  const [unlockedArticleIds, setUnlockedArticleIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('hc_unlocked_articles');
    return saved ? JSON.parse(saved) : ['art-1', 'art-3'];
  });

  const [tipHistory, setTipHistory] = useState<TipTransaction[]>(() => {
    const saved = localStorage.getItem('hc_tip_history');
    return saved ? JSON.parse(saved) : [
      {
        id: 'tip-1',
        articleId: 'art-1',
        articleTitle: 'Harvard Researchers Develop Promising New Treatment for Alzheimer’s Disease',
        authorName: 'Olivia Chen',
        amountSats: 2100,
        timestamp: '10 minutes ago',
        note: 'Exceptional reporting on neurobiology!',
        paymentHash: '7f9a...3b21'
      },
      {
        id: 'tip-2',
        articleId: 'art-7',
        articleTitle: 'The University and the Future of Free Inquiry',
        authorName: 'Martin Hill',
        amountSats: 5000,
        timestamp: '2 hours ago',
        note: 'Crucial essay for higher ed liberty.',
        paymentHash: '4e2c...890a'
      }
    ];
  });

  const btcPriceUSD = 68450;
  const hasWebLN = typeof window !== 'undefined' && 'webln' in window;

  useEffect(() => {
    localStorage.setItem('hc_btc_wallet', JSON.stringify(walletState));
  }, [walletState]);

  useEffect(() => {
    localStorage.setItem('hc_unlocked_articles', JSON.stringify(unlockedArticleIds));
  }, [unlockedArticleIds]);

  useEffect(() => {
    localStorage.setItem('hc_tip_history', JSON.stringify(tipHistory));
  }, [tipHistory]);

  const totalChronicleSats = articles.reduce((acc, a) => acc + (a.satsTipped || 0), 0);

  const connectWallet = async (type: BitcoinWalletState['walletType']): Promise<boolean> => {
    try {
      if (type === 'WebLN' && hasWebLN) {
        await (window as any).webln.enable();
        const info = await (window as any).webln.getInfo?.().catch(() => null);
        setWalletState({
          isConnected: true,
          walletType: 'WebLN',
          nodeAlias: info?.node?.alias || 'Alby WebLN Node',
          pubkey: info?.node?.pubkey || '038c11a...90bd',
          lightningAddress: 'user@getalby.com',
          balanceSats: 125000
        });
        return true;
      }

      // Default seamless simulation / NWC / Alby demo connect
      setWalletState({
        isConnected: true,
        walletType: type,
        lightningAddress: type === 'Alby' ? 'harvard_reader@getalby.com' : 'crimson_scholar@stacker.news',
        pubkey: '02bc89a712f83d91c107e5b321a9d0f9a2b1c4d3e5f6a7b8c9d0e1f2a3b4c5d6e7',
        nodeAlias: type === 'Alby' ? 'Alby Hub' : `${type || 'Lightning'} Wallet`,
        balanceSats: 50000
      });
      return true;
    } catch (err) {
      console.error('Wallet connection failed:', err);
      return false;
    }
  };

  const disconnectWallet = () => {
    setWalletState({
      isConnected: false,
      walletType: null,
      balanceSats: 0
    });
  };

  const tipSatsToArticle = async (articleId: string, satsAmount: number, note?: string): Promise<boolean> => {
    const art = articles.find(a => a.id === articleId);
    if (!art) return false;

    // Deduct from wallet if connected
    if (walletState.isConnected && walletState.balanceSats >= satsAmount) {
      setWalletState(prev => ({
        ...prev,
        balanceSats: prev.balanceSats - satsAmount
      }));
    }

    // Update article tip count
    setArticles(prev => prev.map(a => a.id === articleId ? {
      ...a,
      satsTipped: (a.satsTipped || 0) + satsAmount
    } : a));

    // Record tip history
    const newTx: TipTransaction = {
      id: `tip-${Date.now()}`,
      articleId: art.id,
      articleTitle: art.title,
      authorName: art.author.name,
      amountSats: satsAmount,
      timestamp: 'Just now',
      note: note || undefined,
      paymentHash: `${Math.random().toString(36).substring(2, 10)}...${Math.random().toString(36).substring(2, 6)}`
    };

    setTipHistory(prev => [newTx, ...prev]);
    return true;
  };

  const unlockArticleWithSats = async (articleId: string, satsPrice: number): Promise<boolean> => {
    const success = await tipSatsToArticle(articleId, satsPrice, `Unlocked Premium Paywall (${satsPrice} sats)`);
    if (success) {
      setUnlockedArticleIds(prev => [...prev, articleId]);
      return true;
    }
    return false;
  };

  const generateLightningInvoice = (satsAmount: number, description: string): LightningInvoice => {
    const randomHash = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    const bolt11 = `lnbc${satsAmount}n1p3${randomHash.substring(0, 30)}...hc_harvard_chronicle`;
    return {
      id: `inv-${Date.now()}`,
      paymentHash: randomHash,
      paymentRequest: bolt11,
      amountSats: satsAmount,
      description,
      status: 'pending',
      createdAt: Date.now()
    };
  };

  useEffect(() => {
    localStorage.setItem('hc_articles', JSON.stringify(articles));
  }, [articles]);

  useEffect(() => {
    localStorage.setItem('hc_saved_articles', JSON.stringify(savedArticleIds));
  }, [savedArticleIds]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('hc_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('hc_theme', 'light');
    }
  }, [isDarkMode]);

  const toggleSaveArticle = (id: string) => {
    setSavedArticleIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const addToHistory = (id: string) => {
    setReadingHistory(prev => [id, ...prev.filter(x => x !== id)]);
    // Increment view count
    setArticles(prev => prev.map(a => a.id === id ? { ...a, viewCount: a.viewCount + 1 } : a));
  };

  const updateReaderSettings = (newSettings: Partial<ReaderSettings>) => {
    setReaderSettings(prev => ({ ...prev, ...newSettings }));
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  const addCMSArticle = (draft: CMSArticleDraft) => {
    const newArticle: Article = {
      id: `art-${Date.now()}`,
      slug: draft.title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      title: draft.title,
      subtitle: draft.subtitle,
      department: draft.department,
      categoryTag: draft.categoryTag || 'NEWS',
      author: {
        id: `auth-${Date.now()}`,
        name: draft.authorName || 'Editorial Staff',
        role: 'Chronicle Contributor',
        department: draft.department,
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=250',
        bio: 'Staff correspondent for The Harvard Chronicle.'
      },
      publishedAt: 'May 10, 2026',
      readTimeMinutes: Math.ceil(draft.content.split(' ').length / 200) || 3,
      featuredImage: draft.featuredImage || 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1200',
      summary: draft.subtitle || draft.content.substring(0, 160) + '...',
      content: draft.content.split('\n\n').filter(Boolean),
      viewCount: 1
    };

    setArticles(prev => [newArticle, ...prev]);
  };

  return (
    <AppContext.Provider
      value={{
        articles,
        activeDepartment,
        setActiveDepartment,
        selectedArticle,
        setSelectedArticle,
        savedArticleIds,
        toggleSaveArticle,
        readingHistory,
        addToHistory,
        activePodcast,
        setActivePodcast,
        audioNarrationArticle,
        setAudioNarrationArticle,
        isPlayingAudio,
        setIsPlayingAudio,
        audioSpeed,
        setAudioSpeed,
        audioProgress,
        setAudioProgress,
        readerSettings,
        updateReaderSettings,
        isDarkMode,
        toggleDarkMode,
        isSearchModalOpen,
        setIsSearchModalOpen,
        isCMSModalOpen,
        setIsCMSModalOpen,
        isArchiveModalOpen,
        setIsArchiveModalOpen,
        isEventsModalOpen,
        setIsEventsModalOpen,
        isRSSModalOpen,
        setIsRSSModalOpen,
        rssTargetAuthor,
        setRssTargetAuthor,
        activeView,
        setActiveView,
        addCMSArticle,
        searchQuery,
        setSearchQuery,
        isWalletModalOpen,
        setIsWalletModalOpen,
        isTipModalOpen,
        setIsTipModalOpen,
        tipTargetArticle,
        setTipTargetArticle,
        walletState,
        unlockedArticleIds,
        tipHistory,
        btcPriceUSD,
        totalChronicleSats,
        connectWallet,
        disconnectWallet,
        tipSatsToArticle,
        unlockArticleWithSats,
        generateLightningInvoice,
        hasWebLN
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
