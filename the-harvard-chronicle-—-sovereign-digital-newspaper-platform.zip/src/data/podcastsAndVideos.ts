import { PodcastEpisode, VideoDoc, ArchiveEntry, CampusEvent } from '../types';

export const MOCK_PODCASTS: PodcastEpisode[] = [
  {
    id: 'pod-1',
    title: 'Ep. 42: The Future of Quantum Computing & Cryptographic Security',
    showName: 'The Crimson Podcast: Ideas That Shape Tomorrow',
    host: 'Elena Rostova',
    guest: 'Dr. Michael Chang (Professor of Applied Physics)',
    date: 'May 8, 2026',
    duration: '38:15',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/05/27/audio_1808fbf07a.mp3?filename=lofi-study-112191.mp3',
    coverImage: 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&q=80&w=600',
    description: 'We sit down with Professor Michael Chang to discuss quantum error correction, post-quantum encryption standards, and why Harvard’s new quantum network mark a turning point.',
    transcript: [
      'Elena Rostova: Welcome back to The Crimson Podcast. Today we are joined in the Harvard Yard studio by Professor Michael Chang from the Quantum Physics Laboratory.',
      'Prof. Chang: It is a pleasure to be here, Elena.',
      'Elena Rostova: Professor, last week your team demonstrated a 100-qubit fault-tolerant topological circuit. What does this mean for post-quantum encryption?',
      'Prof. Chang: It means the timeline for post-quantum migration is accelerating. Modern RSA encryption relies on factoring difficulty, which quantum Shor algorithms can compute rapidly once physical fidelity crosses 99.9% thresholds.'
    ]
  },
  {
    id: 'pod-2',
    title: 'Ep. 41: Decarbonizing the Ivy League — Behind the 2030 Net-Zero Plan',
    showName: 'The Crimson Podcast: Ideas That Shape Tomorrow',
    host: 'Julian Sterling',
    guest: 'Professor Thomas Wright (Salata Institute)',
    date: 'May 1, 2026',
    duration: '29:40',
    audioUrl: 'https://cdn.pixabay.com/download/audio/2022/03/15/audio_c8c8a7321e.mp3?filename=relaxing-light-mood-10940.mp3',
    coverImage: 'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?auto=format&fit=crop&q=80&w=600',
    description: 'A deep dive into how Harvard is retrofitting 600 historic buildings with geothermal heat exchangers and microgrid storage.',
    transcript: [
      'Julian Sterling: Retrofitting 300-year-old brick architecture is no simple engineering task. Professor Wright explains the geothermal drilling underneath Harvard Yard.',
      'Prof. Wright: We are installing 450 vertical geothermal closed loops 500 feet into the bedrock without interrupting daily academic schedules.'
    ]
  }
];

export const MOCK_VIDEOS: VideoDoc[] = [
  {
    id: 'vid-1',
    title: 'Inside the Longwood Neurobiology Labs: Hunting the Tau Protein',
    duration: '14:20',
    category: 'RESEARCH DOCUMENTARY',
    thumbnail: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&q=80&w=800',
    description: 'An exclusive documentary inside Dr. Aris Thorne’s laboratory observing real-time microglial clearance of neurodegenerative plaques using super-resolution microscopy.',
    producer: 'Harvard Chronicle Media Labs'
  },
  {
    id: 'vid-2',
    title: 'Architectural Heritage: 390 Years of Harvard Yard Buildings',
    duration: '18:45',
    category: 'HISTORICAL ARTS',
    thumbnail: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=800',
    description: 'From Massachusetts Hall built in 1720 to Renzo Piano’s glass art museum expansion, explore how physical architecture mirrors intellectual evolution.',
    producer: 'Department of History of Art & Architecture'
  }
];

export const MOCK_ARCHIVE_ENTRIES: ArchiveEntry[] = [
  {
    year: 1873,
    dateStr: 'September 4, 1873',
    title: 'The Crimson Founded: A New Voice for Independent Student Journalism',
    snippet: 'The inaugural edition of The Harvard Crimson is printed on press, pledging independent coverage of university governance and intellectual life.',
    department: 'News',
    headlineImage: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?auto=format&fit=crop&q=80&w=600',
    historicalContext: 'Founded shortly after the American Civil War during President Charles William Eliot’s transformative tenure introducing the elective course system.'
  },
  {
    year: 1920,
    dateStr: 'June 17, 1920',
    title: 'Widener Library Dedicated in Memory of Harry Elkins Widener',
    snippet: 'The monumental 3.5-million-volume library opens its grand colonnaded doors in Harvard Yard.',
    department: 'University',
    headlineImage: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&q=80&w=600',
    historicalContext: 'Built following the sinking of the Titanic in 1912, forming the heart of the world’s largest university library network.'
  },
  {
    year: 1969,
    dateStr: 'April 9, 1969',
    title: 'University Hall Strike & Student Protests Reshape Governance',
    snippet: 'Students occupy University Hall calling for ROTC abolition and institutional reform.',
    department: 'Politics',
    headlineImage: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=600',
    historicalContext: 'A pivotal moment in 20th-century university governance establishing formal student representation on administrative councils.'
  },
  {
    year: 2004,
    dateStr: 'February 4, 2004',
    title: 'The Harvard Connection: Social Network Launched from Kirkland House',
    snippet: 'Mark Zuckerberg ’06 launches "Thefacebook" inside a sophomore dormitory room.',
    department: 'Technology',
    headlineImage: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=600',
    historicalContext: 'Beginning as an internal collegiate directory, triggering the global social media revolution.'
  },
  {
    year: 2026,
    dateStr: 'May 10, 2026',
    title: 'Landmark Alzheimer’s & AI Governance Initiatives Unveiled',
    snippet: 'Harvard researchers publish HCM-409 therapeutic findings while launching joint $150M AI Safety Center with MIT.',
    department: 'Science & Tech',
    headlineImage: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=600',
    historicalContext: 'Pioneering sovereign academic research in biotechnology and artificial intelligence alignment.'
  }
];

export const MOCK_EVENTS: CampusEvent[] = [
  {
    id: 'evt-1',
    title: 'The 2026 Tanner Lectures on Human Values: Democracy in the Algorithmic Age',
    date: 'May 14, 2026',
    time: '16:00 EST',
    location: 'Sanders Theatre, Memorial Hall',
    department: 'Department of Philosophy & Law',
    speaker: 'Dr. Danielle Allen & Guest Panelists',
    description: 'Annual flagship university lecture series addressing moral philosophy, computational governance, and civic renewal.'
  },
  {
    id: 'evt-2',
    title: 'Harvard BioInnovation Symposium: Next-Gen Peptide Therapeutics',
    date: 'May 18, 2026',
    time: '09:00 EST',
    location: 'Klarman Hall, Harvard Business School',
    department: 'Harvard Medical School & HBS',
    speaker: 'Dr. Aris Thorne & Industry Leaders',
    description: 'Bringing together venture partners, clinical researchers, and FDA regulators to accelerate clinical translation of breakthrough therapeutics.'
  },
  {
    id: 'evt-3',
    title: 'Exhibition Vernissage: Florentine Masterworks from Uffizi Archives',
    date: 'May 21, 2026',
    time: '18:30 EST',
    location: 'Harvard Art Museums Calderwood Courtyard',
    department: 'Harvard Art Museums',
    speaker: 'Sophia Lang & Curator Dr. Marcus Vance',
    description: 'Evening reception and gallery tour of the newly opened Renaissance perspective exhibition.'
  }
];
