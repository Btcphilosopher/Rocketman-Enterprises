import { Article } from '../types';

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-1',
    slug: 'alzheimers-breakthrough-neurobiology',
    title: 'Harvard Researchers Develop Promising New Treatment for Alzheimer’s Disease',
    subtitle: 'A breakthrough study from the Department of Neurobiology offers new hope in the fight against a neurodegenerative disease affecting millions worldwide.',
    department: 'Medicine',
    categoryTag: 'TOP STORY',
    author: {
      id: 'auth-1',
      name: 'Olivia Chen',
      role: 'Senior Science Writer',
      department: 'Department of Neurobiology & Harvard Medical School',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=250',
      bio: 'Olivia Chen covers molecular biology, neuroscience, and medical innovation for The Chronicle.',
      lightningAddress: 'olivia@stacker.news',
      btcAddress: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh'
    },
    publishedAt: 'May 10, 2026',
    updatedAt: 'May 10, 2026 at 14:15 EST',
    readTimeMinutes: 7,
    featuredImage: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1600',
    caption: 'The Harvard Medical School research complex in Longwood, where the landmark study on microglial clearance of amyloid plaques was conducted.',
    photoCredit: 'Photo by Marcus Vance / The Harvard Chronicle',
    isHero: true,
    isBreaking: true,
    isEditorsPick: true,
    viewCount: 24910,
    satsTipped: 48500,
    summary: 'In a pivotal clinical paper published in Nature Neuroscience, Harvard researchers introduced a targeted monoclonal peptide that restores native microglial motility, accelerating toxic tau protein clearing by 64% in early-phase trial models.',
    pullQuote: '“For three decades, neurodegenerative research focused on preventing protein accumulation. Our paradigm shifts toward activating the brain’s endogenous repair machinery.” — Dr. Aris Thorne',
    content: [
      'In what senior clinicians are describing as a foundational leap in neurodegenerative therapeutics, a multi-disciplinary team led by Harvard Medical School’s Department of Neurobiology has announced a novel peptide therapeutic that successfully reactivates dormant microglial clearance mechanisms in preclinical models of Alzheimer’s disease.',
      'The drug candidate, currently designated HCM-409, targets specific cell-surface receptors on brain macrophages, restoring their capacity to ingest and breakdown oligomeric tau tangles and amyloid-beta aggregates before irreversible neuronal damage occurs.',
      'For decades, therapeutic interventions focused predominantly on monoclonal antibodies designed to clear amyloid plaques from extracellular space. However, clinical trials consistently demonstrated limited cognitive stabilization once neurofibrillary tangles had established widespread cortical presence.',
      '“Our work fundamentally reinterprets the microglial response,” said Dr. Aris Thorne, Professor of Cellular Neurobiology and senior author of the study published this morning in Nature Neuroscience. “Instead of attempting to suppress neuroinflammation wholesale, HCM-409 acts as a molecular light switch, signaling immune cells to resume physiological waste clearance while dampening cytotoxic cytokine release.”',
      'The multi-center study, conducted over five years across Harvard Medical School, the Broad Institute of MIT and Harvard, and Brigham and Women’s Hospital, monitored cognitive velocity and PET biomarker intensity across 480 longitudinal subjects.',
      'Neurological assessments revealed a statistically significant 58% reduction in cognitive decline metrics over an 18-month trial period, alongside a dramatic decrease in cerebrospinal fluid tau phosphorylated at threonine 181.',
      'With Phase II human clinical safety trials scheduled to commence at Massachusetts General Hospital this autumn, global medical authorities are cautiously optimistic about the potential for early-stage therapeutic stabilization.'
    ],
    citations: [
      {
        id: 'c-1',
        authors: 'Thorne, A., Chen, O., Vance, M., & Sowers, K.',
        title: 'Microglial Receptor Modulation Restores Autophagic Tau Flux in Human Cortical Organoids',
        journalOrPublisher: 'Nature Neuroscience',
        year: 2026,
        doi: '10.1038/s41593-026-01894-x'
      },
      {
        id: 'c-2',
        authors: 'Harvard Stem Cell Institute',
        title: 'Longitudinal Biomarker Analysis of HCM-409 Administration',
        journalOrPublisher: 'Harvard University Press Repository',
        year: 2026
      }
    ],
    chartData: {
      title: 'Tau Clearance & Cognitive Velocity Metrics (HCM-409 vs Control)',
      description: 'Percentage reduction in neurofibrillary tau density measured via tau-PET imaging over 18 trial months.',
      type: 'line',
      xAxisKey: 'month',
      dataKeys: ['ControlGroup', 'HCM409Therapeutic'],
      data: [
        { month: 'Baseline', ControlGroup: 100, HCM409Therapeutic: 100 },
        { month: 'Month 3', ControlGroup: 98, HCM409Therapeutic: 84 },
        { month: 'Month 6', ControlGroup: 96, HCM409Therapeutic: 69 },
        { month: 'Month 9', ControlGroup: 94, HCM409Therapeutic: 52 },
        { month: 'Month 12', ControlGroup: 92, HCM409Therapeutic: 41 },
        { month: 'Month 15', ControlGroup: 89, HCM409Therapeutic: 36 },
        { month: 'Month 18', ControlGroup: 87, HCM409Therapeutic: 32 }
      ]
    }
  },
  {
    id: 'art-2',
    slug: 'harvard-mit-ai-safety-initiative',
    title: 'Harvard and MIT Launch New Initiative on AI Safety & Governance',
    subtitle: 'A joint $150M endowment commitment creates the Center for Sovereign Algorithmic Alignment.',
    department: 'Technology',
    categoryTag: 'BREAKING',
    author: {
      id: 'auth-2',
      name: 'Julian Sterling',
      role: 'Staff Technology Correspondent',
      department: 'School of Engineering and Applied Sciences',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      bio: 'Julian covers artificial intelligence governance, high-performance computing, and computational law.'
    },
    publishedAt: 'May 10, 2026',
    readTimeMinutes: 4,
    featuredImage: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=1200',
    caption: 'The Maxwell Dworkin Laboratory, home to joint computational research initiatives across the Charles River.',
    isBreaking: true,
    isTrending: true,
    viewCount: 18240,
    satsTipped: 125000,
    isPremiumPaywall: true,
    paywallSatsPrice: 210,
    summary: 'Harvard University and Massachusetts Institute of Technology have co-founded a $150M research entity dedicated to mathematical alignment, autonomous agent safety, and policy frameworks for Frontier AI models.',
    content: [
      'In an unprecedented cross-institutional alliance, Harvard President and MIT Leadership announced the launch of the Center for Sovereign Algorithmic Alignment (CSAA).',
      'Supported by a foundational $150 million joint endowment fund, the Center will convene top researchers in formal verification, cryptography, economic mechanism design, and constitutional law to address systemic vulnerabilities in autonomous artificial intelligence.',
      '“We are reaching a structural transition point where frontier models execute economic and infrastructure operations autonomously,” remarked Dr. Eleanor Vance, Co-Director of CSAA. “Academic institutions must provide objective, uncompromised safety standards independent of private venture incentives.”',
      'Initial research tracks will focus on deterministic output bounds for autonomous code generators, machine unlearning mechanisms for sensitive dataset red-teaming, and global governance blueprints for international AI treaties.'
    ]
  },
  {
    id: 'art-3',
    slug: 'faculty-approves-sustainability-plan',
    title: 'Faculty Vote Approves New University Climate Action & Net-Zero Plan',
    subtitle: 'Harvard pledges total operational decarbonization by 2030 and complete endowment fossil fuel decoupling by 2035.',
    department: 'Science & Tech',
    categoryTag: 'UNIVERSITY',
    author: {
      id: 'auth-3',
      name: 'Elena Rostova',
      role: 'Campus Affairs Editor',
      department: 'Salata Institute for Climate and Sustainability',
      avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=250',
      bio: 'Elena writes on climate policy, campus infrastructure, and environmental economics.'
    },
    publishedAt: 'May 10, 2026',
    readTimeMinutes: 5,
    featuredImage: 'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?auto=format&fit=crop&q=80&w=1200',
    caption: 'Solar arrays and geothermal heating wells being integrated across Allston Science and Engineering Complex campus.',
    isTrending: true,
    viewCount: 14500,
    summary: 'The Faculty of Arts and Sciences voted overwhelmingly (312 to 18) to approve the 2030 Climate Decarbonization Roadmap, mandating real-time campus microgrid monitoring and thermal energy storage.',
    content: [
      'The Harvard Faculty of Arts and Sciences overwhelmingly adopted the 2030 Decarbonization Accord during yesterday’s faculty assembly in Loeb House.',
      'The comprehensive policy legally commits the University to achieving operational zero emissions across all 600 campus buildings by December 2030, alongside complete endowment decarbonization targets by 2035.',
      'Key pillars include transitioning Harvard District Heating & Cooling systems to deep geothermal heat pumps, deploying microgrid battery arrays across Allston, and establishing strict embodied-carbon caps for all new capital construction projects.',
      '“Harvard has a moral imperative not merely to study global warming, but to serve as a living laboratory for urban energy transition,” stated Dean of Science Professor Thomas Wright.'
    ]
  },
  {
    id: 'art-4',
    slug: 'harvard-endowment-posts-strong-returns',
    title: 'Harvard Endowment Posts Strong Fiscal Returns Driven by Climate Tech & Bio Innovation',
    subtitle: 'Harvard Management Company reports a 14.2% return, elevating total university fund valuation to $54.8 billion.',
    department: 'Business',
    categoryTag: 'ECONOMICS',
    author: {
      id: 'auth-4',
      name: 'Arthur Pendelton',
      role: 'Financial Editor',
      department: 'Harvard Business School',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
      bio: 'Arthur covers institutional investment, macroeconomic policy, and venture capital allocations.'
    },
    publishedAt: 'May 10, 2026',
    readTimeMinutes: 4,
    featuredImage: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80&w=1200',
    caption: 'Harvard Management Company headquarters in Boston, financial stewards of the university endowment.',
    viewCount: 12100,
    summary: 'Harvard Management Company reported a 14.2% annualized return for the preceding fiscal year, outperforming peer ivy benchmarks due to early positions in generative biotechnology and grid storage ventures.',
    content: [
      'Harvard Management Company (HMC) announced today that the university endowment achieved a 14.2% investment return for Fiscal Year 2026, boosting total fund capital to $54.8 billion.',
      'Chief Executive Officer N.P. Narvekar credited the performance to disciplined private equity allocation, particularly within synthetic biology, targeted therapeutics, and clean energy storage technologies.',
      'Direct distributions from the endowment will contribute over $2.4 billion to the university operating budget this academic year, underwriting financial aid for over 55% of undergraduate families and supporting non-tenured faculty research grants.'
    ],
    chartData: {
      title: 'Harvard Endowment Growth & Annual Returns (2020 - 2026)',
      description: 'Total endowment asset value in Billions USD and annualized return percentages.',
      type: 'bar',
      xAxisKey: 'year',
      dataKeys: ['EndowmentValuationBillion', 'AnnualizedReturnPercent'],
      data: [
        { year: '2020', EndowmentValuationBillion: 41.9, AnnualizedReturnPercent: 7.3 },
        { year: '2021', EndowmentValuationBillion: 53.2, AnnualizedReturnPercent: 33.6 },
        { year: '2022', EndowmentValuationBillion: 50.9, AnnualizedReturnPercent: -2.3 },
        { year: '2023', EndowmentValuationBillion: 50.7, AnnualizedReturnPercent: 2.9 },
        { year: '2024', EndowmentValuationBillion: 51.8, AnnualizedReturnPercent: 9.6 },
        { year: '2025', EndowmentValuationBillion: 52.4, AnnualizedReturnPercent: 11.1 },
        { year: '2026', EndowmentValuationBillion: 54.8, AnnualizedReturnPercent: 14.2 }
      ]
    }
  },
  {
    id: 'art-5',
    slug: 'open-course-initiative-expansion',
    title: 'Students Propose Major Expansion of Harvard Open Course Initiative',
    subtitle: 'Undergraduate Council resolution advocates making all foundational seminar lectures freely accessible globally.',
    department: 'University',
    categoryTag: 'CAMPUS LIFE',
    author: {
      id: 'auth-5',
      name: 'Emma Richardson',
      role: 'Staff Writer',
      department: 'Harvard College',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=250',
      bio: 'Emma writes on student governance, undergraduate life, and global educational access.'
    },
    publishedAt: 'May 9, 2026',
    readTimeMinutes: 5,
    featuredImage: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&q=80&w=1200',
    caption: 'Students gathered outside Widener Library discussing academic policy reform.',
    isEditorsPick: true,
    viewCount: 9840,
    summary: 'A student-led movement supported by over 2,400 undergraduate signatures seeks to digitize and release 150 foundational Harvard humanities and STEM course archives with multi-language AI transcriptions.',
    content: [
      'A coalition of undergraduate scholars and digital humanities advocates has presented a formal proposal to Harvard’s Educational Policy Committee requesting a expansion of free public courseware.',
      'The resolution, titled the "Open Knowledge Charter," outlines a framework for high-definition video capture, real-time AI translation into 40 languages, and open-access textbook repositories for core general education courses.',
      '“Education at Harvard should not end at the gates of Harvard Yard,” said Student Council Vice President Marcus Lin ’27. “By open-sourcing our core lectures, we extend academic scholarship to self-guided learners worldwide.”'
    ]
  },
  {
    id: 'art-6',
    slug: 'global-collaboration-climate-crisis',
    title: 'Global Collaboration Key to Solving Climate Crisis, Experts Say at Harvard Summit',
    subtitle: 'Delegates from 60 nations convene at Harvard Kennedy School to establish cross-border decarbonization treaties.',
    department: 'Global',
    categoryTag: 'INTERNATIONAL',
    author: {
      id: 'auth-6',
      name: 'Daniel Brooks',
      role: 'Global Affairs Correspondent',
      department: 'Harvard Kennedy School',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250',
      bio: 'Daniel covers international diplomacy, geopolitical economics, and global environmental governance.'
    },
    publishedAt: 'May 9, 2026',
    readTimeMinutes: 6,
    featuredImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=1200',
    caption: 'Global climate delegates at the John F. Kennedy Forum discussing carbon tariff synchronization.',
    viewCount: 11400,
    summary: 'Keynote addresses at the 2026 Harvard Climate Diplomacy Summit emphasized that national carbon pricing mechanisms must synchronize internationally to prevent carbon leakage and economic arbitrage.',
    content: [
      'Addressing an auditorium filled with international diplomats, climate ministers, and academic economists, Harvard Kennedy School Dean Douglas Elmendorf underscored the critical necessity of harmonized international climate regulation.',
      'The three-day summit focused on standardizing border carbon adjustments, financing green technology transfers to developing nations, and establishing international satellite verification protocols for methane leak enforcement.',
      '“Individual nation-state initiatives are fundamentally insufficient when dealing with atmospheric common pools,” noted Dr. Amina Diallo, Visiting Professor of International Development. “We need verifiable, binding multi-lateral protocols.”'
    ]
  },
  {
    id: 'art-7',
    slug: 'university-future-of-free-inquiry',
    title: 'The University and the Future of Free Inquiry',
    subtitle: 'Academic freedom is not a luxury of peaceful times; it is the essential furnace where truth is refined.',
    department: 'Opinion',
    categoryTag: 'COLUMN',
    author: {
      id: 'auth-7',
      name: 'Martin Hill',
      role: 'Professor of Constitutional Law & University Columnist',
      department: 'Harvard Law School',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=250',
      bio: 'Martin Hill is the Carl M. Loeb University Professor at Harvard Law School.'
    },
    publishedAt: 'May 8, 2026',
    readTimeMinutes: 8,
    featuredImage: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&q=80&w=1200',
    caption: 'Professor Martin Hill delivering the annual Oliver Wendell Holmes Lecture.',
    isEditorsPick: true,
    viewCount: 28400,
    summary: 'When institutions prioritize ideological conformity over rigorous empirical debate, scholarship loses its core moral authority. We must fiercely protect dissenting inquiries.',
    content: [
      'The fundamental purpose of a university is neither to comfort nor to validate contemporary consensus. Its purpose is to subject every premise, no matter how revered, to relentless empirical and logical scrutiny.',
      'In recent years, institutional pressures from across the political spectrum have threatened to shrink the boundaries of acceptable academic inquiry. When scholars hesitate to test controversial hypotheses for fear of reputational censure, the quiet death of scholarship begins.',
      'We must reaffirm our historic commitment to Veritas. Truth is not discovered through managed consensus; it emerges through the friction of opposing arguments, meticulously tested against evidence.',
      'Let Harvard remain a sanctuary for difficult questions. For if the world’s leading research university cannot withstand the discomfort of intellectual heterodoxy, no institution can.'
    ]
  },
  {
    id: 'art-8',
    slug: 'why-harvard-must-lead-with-courage',
    title: 'Why Harvard Must Lead with Courage in an Era of Institutional Polarization',
    subtitle: 'An editorial statement on principle, purpose, and enduring moral leadership.',
    department: 'Opinion',
    categoryTag: 'EDITORIAL',
    author: {
      id: 'auth-edboard',
      name: 'The Editorial Board',
      role: 'The Harvard Chronicle Editorial Board',
      department: 'Independent Student Editorial Board',
      avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&q=80&w=250',
      bio: 'The Editorial Board represents the collective opinion of The Harvard Chronicle staff.'
    },
    publishedAt: 'May 7, 2026',
    readTimeMinutes: 4,
    featuredImage: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1200',
    caption: 'Harvard Yard under early morning light.',
    viewCount: 19800,
    summary: 'In times of national fracture, higher education must resist tribal retrenchment and renew its commitment to rigorous inquiry, civic courage, and social mobility.',
    content: [
      'As universities across the nation navigate intense public scrutiny and political headwinds, Harvard faces a defining choice: retreat into defensive insularity or step forward with unwavering institutional courage.',
      'Courage demands that we expand financial aid, defend truth-seeking scholarship without ideological compromise, and ensure that our campus remains a vibrant crossroads for open dialogue.',
      'Our legacy since 1636 was built not by avoiding complex debates, but by shaping the ideas that guide democratic societies.'
    ]
  },
  {
    id: 'art-9',
    slug: 'moment-for-faith-in-science',
    title: 'A Moment for Faith in Science and Empirical Truth',
    subtitle: 'Rebuilding public trust in biomedical research requires radical transparency and humble communication.',
    department: 'Opinion',
    categoryTag: 'COMMENTARY',
    author: {
      id: 'auth-8',
      name: 'Priya Desai',
      role: 'Biethics Fellow & Columnist',
      department: 'Harvard T.H. Chan School of Public Health',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      bio: 'Priya writes on bioethics, public health trust, and scientific communication.'
    },
    publishedAt: 'May 6, 2026',
    readTimeMinutes: 5,
    featuredImage: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&q=80&w=1200',
    caption: 'Laboratory at Harvard T.H. Chan School of Public Health.',
    viewCount: 8900,
    summary: 'Public skepticism toward scientific institutions is not cured by condescension, but by opening the laboratory doors, demonstrating methods transparently, and acknowledging uncertainty.',
    content: [
      'Science is not a body of static dogma to be believed on authority; it is an active, self-correcting process of disciplined doubt.',
      'When scientists communicate findings as immutable decrees rather than provisional models based on current data, any subsequent shift in guidance undermines public confidence.',
      'To rebuild trust, researchers must invite the public into the scientific process—explaining how hypotheses are tested, acknowledging limitations, and communicating with clarity and humility.'
    ]
  },
  {
    id: 'art-10',
    slug: 'art-of-looking-inside-harvard-art-museums',
    title: 'The Art of Looking: Inside Harvard Art Museums’ Newest Renaissance Exhibition',
    subtitle: 'A retrospective bringing together rarely seen masterworks from Venetian and Florentine archives.',
    department: 'Magazine',
    categoryTag: 'FEATURE',
    author: {
      id: 'auth-9',
      name: 'Sophia Lang',
      role: 'Arts & Culture Critic',
      department: 'Department of History of Art and Architecture',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250',
      bio: 'Sophia covers visual art, museum curation, and architectural design.'
    },
    publishedAt: 'May 5, 2026',
    readTimeMinutes: 7,
    featuredImage: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&q=80&w=1200',
    caption: 'Visitors viewing Renaissance oil paintings inside the glass-roofed courtyard of Harvard Art Museums.',
    isEditorsPick: true,
    viewCount: 16400,
    summary: 'Curator Dr. Marcus Vance brings together 45 rare 15th-century canvasses, revealing how subtle geometric perspective techniques transformed human perception of space.',
    content: [
      'Walking beneath the light-flooded glass canopy designed by Renzo Piano at the Harvard Art Museums, one is immediately struck by the quiet serenity of the new exhibition: "Shadow & Geometry: The Florentine Renaissance."',
      'Featuring works on loan from the Uffizi Gallery, the Louvre, and private collegiate collections, the show offers a masterclass in visual analytical observation.',
      'High-resolution multispectral reflectography scans displayed alongside original oil canvasses expose the underlying charcoal underdrawings, revealing how masters like Botticelli refined compositions during production.'
    ]
  },
  {
    id: 'art-11',
    slug: 'mathematician-who-sees-patterns-everywhere',
    title: 'The Mathematician Who Sees Patterns Everywhere',
    subtitle: 'Profile: Professor James T. Ash on non-Euclidean geometry, fluid dynamics, and quantum chaos.',
    department: 'Magazine',
    categoryTag: 'PROFILE',
    author: {
      id: 'auth-10',
      name: 'James T. Ash',
      role: 'Contributing Editor',
      department: 'Department of Mathematics',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=250',
      bio: 'James covers theoretical physics, pure mathematics, and computational geometry.'
    },
    publishedAt: 'May 4, 2026',
    readTimeMinutes: 9,
    featuredImage: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&q=80&w=1200',
    caption: 'Professor Ash filling blackboards in Science Center Hall B with topological proof sequences.',
    viewCount: 21300,
    summary: 'Fields Medal candidate Professor Ash shares how finding mathematical symmetries in fluid turbulence led to breakthroughs in climate modelling and ocean circulation theory.',
    content: [
      'In Science Center Hall B, the blackboards are covered in chalk dust and complex differential equations. Professor Ash stands with chalk in hand, tracing intricate geometric topologies.',
      '“Mathematics is not about calculation,” Ash reflects, gazing at a multi-dimensional manifolds diagram. “It is the art of perceiving hidden order beneath apparent randomness.”',
      'His latest monograph unifies non-linear wave mechanics with quantum thermodynamic fluctuations, yielding equations now utilized by climate scientists to predict rapid ocean current shifts.'
    ]
  },
  {
    id: 'art-12',
    slug: '5-books-our-editors-are-reading-now',
    title: '5 Essential Works Our Editors Are Reading This Spring',
    subtitle: 'From environmental political economy to deep histories of information technology.',
    department: 'Magazine',
    categoryTag: 'BOOKS',
    author: {
      id: 'auth-booksdesk',
      name: 'The Books Desk',
      role: 'Literary Editors',
      department: 'Harvard University Press Review',
      avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&q=80&w=250',
      bio: 'The Books Desk curates weekly literary commentary and academic monograph reviews.'
    },
    publishedAt: 'May 3, 2026',
    readTimeMinutes: 5,
    featuredImage: 'https://images.unsplash.com/photo-1495446815901-a7297e633e8d?auto=format&fit=crop&q=80&w=1200',
    caption: 'A stack of archival leather-bound volumes inside Houghton Rare Books Library.',
    viewCount: 14200,
    summary: 'Our editors select five transformative books exploring democratic theory, quantum computing history, climate resilience, macroeconomics, and architectural history.',
    content: [
      'Every season, our literary staff curates five exceptional publications that demand careful reflection across disciplines.',
      '1. "The Sovereign Network: A History of Computational Infrastructure" by Dr. Aris Thorne — A sweeping history of global undersea fiber optic cables and digital sovereignty.',
      '2. "Eco-Capitalist Realism: Market Solutions to Ecological Collapse" by Professor Clara Vance — An incisive critique of carbon trading mechanisms.',
      '3. "The Architecture of Memory" by Julian Sterling — How university library design shapes centuries of intellectual habits.'
    ]
  },
  {
    id: 'art-13',
    slug: 'hbs-case-study-sovereign-bitcoin-treasury',
    title: 'HBS Case Study: Corporate Treasury Allocation to Sovereign Bitcoin Reserves',
    subtitle: 'Harvard Business School researchers analyze 45 Fortune 500 balance sheets adopting Bitcoin Lightning settlement networks.',
    department: 'Business',
    categoryTag: 'MARKETS & FINANCE',
    author: {
      id: 'auth-4',
      name: 'Arthur Pendelton',
      role: 'Financial Editor',
      department: 'Harvard Business School',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
      bio: 'Arthur covers global financial markets, private equity, macroeconomics, and sovereign debt.',
      lightningAddress: 'arthur@stacker.news'
    },
    publishedAt: 'May 10, 2026',
    readTimeMinutes: 8,
    featuredImage: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?auto=format&fit=crop&q=80&w=1200',
    caption: 'Trading floor activity at Baker Library, Harvard Business School.',
    isEditorsPick: true,
    isTrending: true,
    viewCount: 31200,
    satsTipped: 89000,
    isPremiumPaywall: true,
    paywallSatsPrice: 350,
    summary: 'A new landmark report from Harvard Business School demonstrates that companies utilizing Bitcoin Lightning micro-settlements reduced international transaction fees by 94% compared to legacy SWIFT channels.',
    content: [
      'In a groundbreaking working paper published by the Harvard Business School Finance Unit, researchers evaluated the capital structure performance of corporate treasuries allocating 2% to 5% of cash reserves into digital sovereign assets.',
      'The longitudinal study tracked 45 global enterprises over a three-year period, examining real-time cross-border trade settlements, working capital velocity, and counterparty risk mitigation.',
      '“The integration of instant Lightning Network micro-settlements turns corporate liquidity management from a multi-day friction into a zero-latency competitive advantage,” noted lead author Arthur Pendelton.',
      'Furthermore, the paper highlights how university endowment funds are increasingly adopting market-neutral arbitrage models in crypto asset derivatives while earning yield via Lightning routing node operations.'
    ]
  },
  {
    id: 'art-14',
    slug: 'global-markets-rand-dollar-volatility',
    title: 'Global Markets Focus: Emerging Currencies, Rand Volatility, and Commodities Supercycle',
    subtitle: 'Wall Street analysts weigh South African Rand (R) resilience amidst gold and platinum mining rally.',
    department: 'Markets',
    categoryTag: 'WALL STREET',
    author: {
      id: 'auth-14',
      name: 'Sibongile Khumalo',
      role: 'Global Markets Reporter',
      department: 'Harvard Kennedy School & HBS',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      bio: 'Sibongile covers emerging market currencies, African trade corridors, and commodity futures.',
      lightningAddress: 'sibongile@stacker.news'
    },
    publishedAt: 'May 9, 2026',
    readTimeMinutes: 6,
    featuredImage: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?auto=format&fit=crop&q=80&w=1200',
    caption: 'Johannesburg Stock Exchange (JSE) and international commodity futures trading ticker boards.',
    isTrending: true,
    viewCount: 19800,
    satsTipped: 42000,
    summary: 'The South African Rand (R) strengthened to 17.40 per USD as platinum group metal exports surged, sparking renewed institutional inflow into emerging market bond funds.',
    content: [
      'Emerging market asset managers are recalibrating portfolios as commodity tailwinds drive historic surges across resource-rich economies.',
      'In Johannesburg and London trading sessions, the South African Rand (R) gained 2.4% against the Greenback, buoyed by record trade surplus figures and expanding solar infrastructure investments.',
      'Harvard Kennedy School macroeconomic fellows highlight that regional currency stabilization has been further accelerated by decentralized trade settlement rails bypassing traditional correspondent banking fees.',
      '“We are seeing a multi-polar currency environment where commodities, sovereign reserves, and Bitcoin settlement networks co-exist to hedge against inflation,” stated Senior Macro Fellow Sibongile Khumalo.'
    ]
  }
];

export const MOCK_DEPARTMENTS = [
  'News',
  'University',
  'Opinion',
  'Global',
  'Science & Tech',
  'Arts',
  'Sports',
  'Magazine',
  'Podcasts',
  'Research',
  'Medicine',
  'Engineering',
  'Humanities',
  'Business',
  'Markets',
  'Politics',
  'Law',
  'Technology'
] as const;
