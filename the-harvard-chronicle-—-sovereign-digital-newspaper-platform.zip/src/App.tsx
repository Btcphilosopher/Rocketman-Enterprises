import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { InteractiveDataVisualizer } from './components/InteractiveDataVisualizer';
import { SectionGrid } from './components/SectionGrid';
import { MultimediaSection } from './components/MultimediaSection';
import { ArticleModal } from './components/ArticleModal';
import { AISearchModal } from './components/AISearchModal';
import { NewsroomCMSModal } from './components/NewsroomCMSModal';
import { ArchiveExplorer } from './components/ArchiveExplorer';
import { CampusEventsCalendar } from './components/CampusEventsCalendar';
import { AudioPlayerDrawer } from './components/AudioPlayerDrawer';
import { BitcoinWalletModal } from './components/BitcoinWalletModal';
import { LightningTipModal } from './components/LightningTipModal';
import { RSSFeedModal } from './components/RSSFeedModal';
import { StockMarketDashboard } from './components/StockMarketDashboard';
import { Footer } from './components/Footer';

function MainContent() {
  const { activeDepartment, activeView } = useApp();

  return (
    <div className="min-h-screen bg-[#FAFAFA] dark:bg-[#121212] text-[#1A1A1A] dark:text-[#E8E8E8] font-serif transition-colors duration-200 selection:bg-[#A51C30] selection:text-white pb-20">
      
      {/* 1. Master Header */}
      <Header />

      {/* 2. Main Body Views */}
      <main>
        {activeView === 'markets' && (
          <StockMarketDashboard />
        )}

        {activeView === 'home' && activeDepartment === 'All' && (
          <>
            <HeroSection />
            <SectionGrid />
            <InteractiveDataVisualizer />
            <MultimediaSection />
          </>
        )}

        {activeView !== 'markets' && (activeView === 'department' || activeDepartment !== 'All') && (
          <SectionGrid />
        )}
      </main>

      {/* 3. Global Overlays & Modals */}
      <ArticleModal />
      <AISearchModal />
      <NewsroomCMSModal />
      <ArchiveExplorer />
      <CampusEventsCalendar />
      <BitcoinWalletModal />
      <LightningTipModal />
      <RSSFeedModal />
      
      {/* 4. Global Audio Player */}
      <AudioPlayerDrawer />

      {/* 5. Institutional Footer */}
      <Footer />

    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
