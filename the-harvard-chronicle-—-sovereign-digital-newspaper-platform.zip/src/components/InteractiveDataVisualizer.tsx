import React, { useState } from 'react';
import { 
  LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend 
} from 'recharts';
import { Database, Download, Sparkles, Filter, Info } from 'lucide-react';

const ENDOWMENT_DATA = [
  { year: '2020', EndowmentValuationBillion: 41.9, AnnualizedReturnPercent: 7.3 },
  { year: '2021', EndowmentValuationBillion: 53.2, AnnualizedReturnPercent: 33.6 },
  { year: '2022', EndowmentValuationBillion: 50.9, AnnualizedReturnPercent: -2.3 },
  { year: '2023', EndowmentValuationBillion: 50.7, AnnualizedReturnPercent: 2.9 },
  { year: '2024', EndowmentValuationBillion: 51.8, AnnualizedReturnPercent: 9.6 },
  { year: '2025', EndowmentValuationBillion: 52.4, AnnualizedReturnPercent: 11.1 },
  { year: '2026', EndowmentValuationBillion: 54.8, AnnualizedReturnPercent: 14.2 }
];

const ALZHEIMERS_TRIAL_DATA = [
  { month: 'Baseline', ControlGroup: 100, HCM409Peptide: 100 },
  { month: 'Month 3', ControlGroup: 98, HCM409Peptide: 84 },
  { month: 'Month 6', ControlGroup: 96, HCM409Peptide: 69 },
  { month: 'Month 9', ControlGroup: 94, HCM409Peptide: 52 },
  { month: 'Month 12', ControlGroup: 92, HCM409Peptide: 41 },
  { month: 'Month 15', ControlGroup: 89, HCM409Peptide: 36 },
  { month: 'Month 18', ControlGroup: 87, HCM409Peptide: 32 }
];

const RESEARCH_GRANTS_DATA = [
  { dept: 'Medicine & Bio', MillionsUSD: 480, ProjectsCount: 310 },
  { dept: 'Engineering & CS', MillionsUSD: 310, ProjectsCount: 240 },
  { dept: 'Physics & Chem', MillionsUSD: 220, ProjectsCount: 165 },
  { dept: 'Climate & Earth', MillionsUSD: 195, ProjectsCount: 130 },
  { dept: 'Humanities & Social', MillionsUSD: 140, ProjectsCount: 190 }
];

export const InteractiveDataVisualizer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'endowment' | 'alzheimers' | 'grants'>('alzheimers');

  const downloadCSV = () => {
    let dataset: Array<Record<string, any>> = ALZHEIMERS_TRIAL_DATA;
    let filename = "harvard_alzheimers_hcm409_trial_data.csv";
    if (activeTab === 'endowment') {
      dataset = ENDOWMENT_DATA;
      filename = "harvard_endowment_returns_2020_2026.csv";
    } else if (activeTab === 'grants') {
      dataset = RESEARCH_GRANTS_DATA;
      filename = "harvard_research_grants_by_dept.csv";
    }

    const headers = Object.keys(dataset[0]).join(',');
    const rows = dataset.map(row => Object.values(row).join(','));
    const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join("\n");
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <section className="w-full bg-[#F4F1EA] dark:bg-[#161616] py-10 border-t border-b border-[#E5E0D8] dark:border-[#2A2A2A] transition-colors">
      <div className="max-w-7xl mx-auto px-4 space-y-6">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-[#D8D2C5] dark:border-[#333] pb-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2 text-[#A51C30] dark:text-[#E57373] text-xs font-sans font-bold uppercase tracking-widest">
              <Database className="w-4 h-4" />
              <span>Interactive Graphics & Research Visualizations</span>
            </div>
            <h2 className="font-serif text-2xl md:text-3xl font-black text-[#1A1A1A] dark:text-[#F5F5F3]">
              The Chronicle Data Journal
            </h2>
          </div>

          {/* Controls & Tab selector */}
          <div className="flex flex-wrap items-center gap-2 text-xs font-sans">
            <button
              onClick={() => setActiveTab('alzheimers')}
              className={`px-3 py-1.5 rounded-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'alzheimers' 
                  ? 'bg-[#A51C30] text-white' 
                  : 'bg-white dark:bg-[#222] text-[#333] dark:text-[#CCC] hover:bg-[#EAE5DB]'
              }`}
            >
              Alzheimer's Trial (HCM-409)
            </button>

            <button
              onClick={() => setActiveTab('endowment')}
              className={`px-3 py-1.5 rounded-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'endowment' 
                  ? 'bg-[#A51C30] text-white' 
                  : 'bg-white dark:bg-[#222] text-[#333] dark:text-[#CCC] hover:bg-[#EAE5DB]'
              }`}
            >
              Endowment Returns
            </button>

            <button
              onClick={() => setActiveTab('grants')}
              className={`px-3 py-1.5 rounded-xs font-semibold cursor-pointer transition-colors ${
                activeTab === 'grants' 
                  ? 'bg-[#A51C30] text-white' 
                  : 'bg-white dark:bg-[#222] text-[#333] dark:text-[#CCC] hover:bg-[#EAE5DB]'
              }`}
            >
              Research Grants Allocations
            </button>

            <button
              onClick={downloadCSV}
              className="px-3 py-1.5 bg-white dark:bg-[#222] border border-[#D8D2C5] dark:border-[#333] text-[#1A1A1A] dark:text-[#CCC] hover:text-[#A51C30] flex items-center gap-1.5 rounded-xs font-medium cursor-pointer"
              title="Download raw dataset CSV"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>
          </div>
        </div>

        {/* Visualizer Canvas Card */}
        <div className="bg-white dark:bg-[#1C1C1C] p-6 rounded-xs border border-[#E0DACF] dark:border-[#2A2A2A] shadow-xs space-y-4">
          
          <div className="flex items-center justify-between text-xs font-serif text-[#555] dark:text-[#AAA]">
            <div className="flex items-center space-x-2">
              <Info className="w-4 h-4 text-[#A51C30]" />
              <span className="font-semibold text-[#1A1A1A] dark:text-[#EEE]">
                {activeTab === 'alzheimers' && "Tau Protein Density Clearance over 18 Months (Nature Neuroscience 2026)"}
                {activeTab === 'endowment' && "Harvard Endowment Asset Growth & Annualized Return (%)"}
                {activeTab === 'grants' && "2026 Annual Research Grant Allocations ($ Millions)"}
              </span>
            </div>
            <span>Source: Harvard Office of Scholarly Communication</span>
          </div>

          <div className="w-full h-[320px] pt-4">
            <ResponsiveContainer width="100%" height="100%">
              {activeTab === 'alzheimers' ? (
                <LineChart data={ALZHEIMERS_TRIAL_DATA} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E0D8" opacity={0.5} />
                  <XAxis dataKey="month" stroke="#777" fontSize={11} />
                  <YAxis stroke="#777" fontSize={11} domain={[0, 110]} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1A1A1A', color: '#FFF', borderRadius: '4px', fontSize: '12px' }} 
                  />
                  <Legend />
                  <Line type="monotone" dataKey="ControlGroup" name="Control Group (%)" stroke="#8884d8" strokeWidth={2} />
                  <Line type="monotone" dataKey="HCM409Peptide" name="HCM-409 Group (%)" stroke="#A51C30" strokeWidth={3} dot={{ r: 5 }} />
                </LineChart>
              ) : activeTab === 'endowment' ? (
                <BarChart data={ENDOWMENT_DATA} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E0D8" opacity={0.5} />
                  <XAxis dataKey="year" stroke="#777" fontSize={11} />
                  <YAxis stroke="#777" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1A1A1A', color: '#FFF', borderRadius: '4px', fontSize: '12px' }} 
                  />
                  <Legend />
                  <Bar dataKey="EndowmentValuationBillion" name="Endowment Valuation ($B)" fill="#1A365D" />
                  <Bar dataKey="AnnualizedReturnPercent" name="Annualized Return (%)" fill="#A51C30" />
                </BarChart>
              ) : (
                <BarChart data={RESEARCH_GRANTS_DATA} layout="vertical" margin={{ top: 10, right: 30, left: 40, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E5E0D8" opacity={0.5} />
                  <XAxis type="number" stroke="#777" fontSize={11} />
                  <YAxis dataKey="dept" type="category" stroke="#777" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#1A1A1A', color: '#FFF', borderRadius: '4px', fontSize: '12px' }} 
                  />
                  <Bar dataKey="MillionsUSD" name="Grants ($ Millions)" fill="#A51C30" radius={[0, 4, 4, 0]} />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>

          <div className="pt-2 text-[11px] font-sans text-[#777] dark:text-[#AAA] flex items-center justify-between border-t border-[#EFECE6] dark:border-[#222]">
            <span>Methodology: Multispectral reflectography and longitudinal PET voxel registration.</span>
            <span className="text-[#A51C30] dark:text-[#E57373] font-semibold flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Peer Reviewed Data Standard
            </span>
          </div>

        </div>

      </div>
    </section>
  );
};
