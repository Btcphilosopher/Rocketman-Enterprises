import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Zap, 
  Search, 
  BarChart2, 
  Globe, 
  Building2, 
  Briefcase, 
  ArrowUpRight, 
  ArrowDownRight, 
  RefreshCw, 
  Lock,
  Layers,
  Sliders,
  Calculator
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

type CurrencyMode = 'USD' | 'ZAR' | 'INR' | 'SATS';

interface StockQuote {
  symbol: string;
  name: string;
  category: 'Index' | 'Tech' | 'Crypto' | 'Harvard Fund' | 'Mining & Energy';
  priceUSD: number;
  changePercent: number;
  volume24h: string;
  marketCapUSD: string;
  peRatio?: number;
}

const STOCK_DATA: StockQuote[] = [
  { symbol: 'BTC/USD', name: 'Bitcoin (Sovereign Reserve)', category: 'Crypto', priceUSD: 68450, changePercent: 4.25, volume24h: '$38.4B', marketCapUSD: '$1.34T' },
  { symbol: '^GSPC', name: 'S&P 500 Index', category: 'Index', priceUSD: 5420.15, changePercent: 0.85, volume24h: '$42.1B', marketCapUSD: '$45.2T', peRatio: 24.5 },
  { symbol: '^IXIC', name: 'Nasdaq Composite', category: 'Index', priceUSD: 16980.40, changePercent: 1.42, volume24h: '$68.9B', marketCapUSD: '$26.8T', peRatio: 31.2 },
  { symbol: 'HETX', name: 'Harvard Endowment Tech Index', category: 'Harvard Fund', priceUSD: 342.50, changePercent: 3.10, volume24h: '$1.8B', marketCapUSD: '$54.8B', peRatio: 28.1 },
  { symbol: 'NVDA', name: 'NVIDIA Corporation', category: 'Tech', priceUSD: 128.40, changePercent: 2.80, volume24h: '$18.2B', marketCapUSD: '$3.15T', peRatio: 45.8 },
  { symbol: 'AMS.JO', name: 'Anglo Platinum (JSE Rand Mining)', category: 'Mining & Energy', priceUSD: 43.03, changePercent: 3.80, volume24h: '$420M', marketCapUSD: '$11.4B', peRatio: 14.2 },
  { symbol: 'AAPL', name: 'Apple Inc.', category: 'Tech', priceUSD: 215.80, changePercent: 0.65, volume24h: '$11.5B', marketCapUSD: '$3.31T', peRatio: 33.4 },
  { symbol: 'MSFT', name: 'Microsoft Corporation', category: 'Tech', priceUSD: 448.20, changePercent: 1.10, volume24h: '$14.1B', marketCapUSD: '$3.33T', peRatio: 36.2 },
  { symbol: 'USD/ZAR', name: 'South African Rand (R Spot)', category: 'Index', priceUSD: 18.25, changePercent: -0.45, volume24h: '$8.2B', marketCapUSD: 'FX Pair' }
];

const HISTORICAL_CHART_DATA: Record<string, Array<{ time: string; value: number }>> = {
  'BTC/USD': [
    { time: '09:00', value: 65400 },
    { time: '11:00', value: 66100 },
    { time: '13:00', value: 65800 },
    { time: '15:00', value: 67200 },
    { time: '17:00', value: 68100 },
    { time: '19:00', value: 68450 }
  ],
  'HETX': [
    { time: '09:00', value: 331 },
    { time: '11:00', value: 334 },
    { time: '13:00', value: 336 },
    { time: '15:00', value: 339 },
    { time: '17:00', value: 341 },
    { time: '19:00', value: 342.5 }
  ],
  '^GSPC': [
    { time: '09:00', value: 5380 },
    { time: '11:00', value: 5395 },
    { time: '13:00', value: 5410 },
    { time: '15:00', value: 5405 },
    { time: '17:00', value: 5418 },
    { time: '19:00', value: 5420.15 }
  ]
};

export const StockMarketDashboard: React.FC = () => {
  const { 
    articles, 
    setSelectedArticle, 
    btcPriceUSD, 
    setIsTipModalOpen, 
    setTipTargetArticle,
    unlockArticleWithSats,
    unlockedArticleIds 
  } = useApp();

  const [currency, setCurrency] = useState<CurrencyMode>('USD');
  const [selectedStock, setSelectedStock] = useState<StockQuote>(STOCK_DATA[0]);
  const [timeframe, setTimeframe] = useState<'1D' | '1W' | '1M' | '1Y'>('1D');
  const [converterAmount, setConverterAmount] = useState<number>(100);
  const [converterCurrency, setConverterCurrency] = useState<CurrencyMode>('ZAR');

  // Conversion Factors
  const ZAR_PER_USD = 18.25; // R 18.25 per 1 USD
  const INR_PER_USD = 83.50; // ₹ 83.50 per 1 USD
  const SATS_PER_USD = 100000000 / btcPriceUSD; // ~1460 sats per 1 USD

  const formatPrice = (priceInUSD: number, curr: CurrencyMode) => {
    switch (curr) {
      case 'ZAR':
        return `R ${(priceInUSD * ZAR_PER_USD).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'INR':
        return `₹ ${(priceInUSD * INR_PER_USD).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      case 'SATS':
        const sats = Math.round(priceInUSD * SATS_PER_USD);
        return `⚡ ${sats.toLocaleString()} sats`;
      case 'USD':
      default:
        return `$ ${priceInUSD.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
  };

  const businessArticles = articles.filter(a => a.department === 'Business' || a.department === 'Markets');

  // Converter calculation
  const getUSDValueFromConverter = () => {
    switch (converterCurrency) {
      case 'ZAR': return converterAmount / ZAR_PER_USD;
      case 'INR': return converterAmount / INR_PER_USD;
      case 'SATS': return converterAmount / SATS_PER_USD;
      case 'USD': default: return converterAmount;
    }
  };
  const usdVal = getUSDValueFromConverter();
  const sharesOfSelected = usdVal / selectedStock.priceUSD;
  const satsEquivalent = Math.round(usdVal * SATS_PER_USD);

  const chartDataRaw = HISTORICAL_CHART_DATA[selectedStock.symbol] || HISTORICAL_CHART_DATA['BTC/USD'];
  const chartDataFormatted = chartDataRaw.map(pt => ({
    time: pt.time,
    price: currency === 'ZAR' ? pt.value * ZAR_PER_USD : currency === 'INR' ? pt.value * INR_PER_USD : currency === 'SATS' ? pt.value * SATS_PER_USD : pt.value
  }));

  return (
    <div id="stock-market-dashboard" className="max-w-7xl mx-auto px-4 py-8 space-y-8 font-sans animate-fadeIn">
      
      {/* 1. Header & Global Currency Denomination Bar */}
      <div className="bg-gradient-to-r from-[#1A1A1A] via-[#222] to-[#A51C30] text-white p-6 rounded-2xl shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6 border border-[#333]">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <span className="px-2.5 py-0.5 rounded bg-amber-400 text-black font-extrabold text-[10px] uppercase tracking-wider">
              Harvard Financial Markets
            </span>
            <span className="text-xs text-amber-200 font-serif italic">Baker Library & Wall Street Desk</span>
          </div>
          <h1 className="font-serif text-2xl sm:text-3xl font-black tracking-tight">
            Stock Exchange & Macro Economic Index
          </h1>
          <p className="text-xs text-[#CCC] max-w-xl">
            Real-time equity quotes, Rand (R) forex markets, Harvard Endowment ETF, and sovereign Bitcoin settlement analytics.
          </p>
        </div>

        {/* Currency Denomination Switcher (USD / Rand (R) / Rupee / Sats) */}
        <div className="bg-black/50 p-2 rounded-xl border border-white/10 flex flex-col space-y-1.5 shrink-0">
          <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300 text-center">
            Display Denomination
          </span>
          <div className="flex gap-1">
            {(['USD', 'ZAR', 'INR', 'SATS'] as CurrencyMode[]).map((mode) => (
              <button
                key={mode}
                onClick={() => setCurrency(mode)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  currency === mode
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'text-white/80 hover:text-white hover:bg-white/10'
                }`}
              >
                {mode === 'ZAR' ? 'R (Rand)' : mode === 'USD' ? '$ (USD)' : mode === 'INR' ? '₹ (INR)' : '⚡ Sats'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Live Market Ticker Tape */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {STOCK_DATA.map((stock) => {
          const isSelected = selectedStock.symbol === stock.symbol;
          const isPositive = stock.changePercent >= 0;
          return (
            <button
              key={stock.symbol}
              onClick={() => setSelectedStock(stock)}
              className={`p-3.5 rounded-xl border text-left transition-all cursor-pointer ${
                isSelected 
                  ? 'border-amber-400 bg-white dark:bg-[#1E1E1E] shadow-lg ring-2 ring-amber-400/30'
                  : 'border-[#E0DACF] dark:border-[#2D2D2D] bg-[#FAF9F6] dark:bg-[#181818] hover:border-amber-400'
              }`}
            >
              <div className="flex items-center justify-between text-[11px] font-bold text-[#666] dark:text-[#AAA]">
                <span>{stock.symbol}</span>
                <span className={`flex items-center ${isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600'}`}>
                  {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                  {stock.changePercent > 0 ? `+${stock.changePercent}%` : `${stock.changePercent}%`}
                </span>
              </div>
              <div className="text-sm font-black text-[#1A1A1A] dark:text-white mt-1 truncate">
                {formatPrice(stock.priceUSD, currency)}
              </div>
              <div className="text-[10px] text-[#888] truncate mt-0.5 font-medium">
                {stock.name}
              </div>
            </button>
          );
        })}
      </div>

      {/* 3. Interactive Asset Chart & Key Statistics */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Chart Card (2 Cols) */}
        <div className="lg:col-span-2 bg-white dark:bg-[#1A1A1A] p-6 rounded-2xl border border-[#E0DACF] dark:border-[#2D2D2D] shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#E5E0D8] dark:border-[#2D2D2D] pb-4">
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="font-serif text-xl font-bold text-[#1A1A1A] dark:text-white">
                  {selectedStock.name} ({selectedStock.symbol})
                </h2>
                <span className="text-[10px] font-bold text-amber-800 bg-amber-100 dark:bg-amber-950 dark:text-amber-300 px-2 py-0.5 rounded">
                  {selectedStock.category}
                </span>
              </div>
              <div className="text-2xl font-black text-[#1A1A1A] dark:text-white mt-1 flex items-baseline space-x-3">
                <span>{formatPrice(selectedStock.priceUSD, currency)}</span>
                <span className={`text-sm font-bold flex items-center ${selectedStock.changePercent >= 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                  {selectedStock.changePercent > 0 ? `+${selectedStock.changePercent}%` : `${selectedStock.changePercent}%`}
                </span>
              </div>
            </div>

            {/* Timeframe Selectors */}
            <div className="flex rounded-lg bg-[#F5F3EF] dark:bg-[#252525] p-1 text-xs font-bold">
              {(['1D', '1W', '1M', '1Y'] as Array<'1D' | '1W' | '1M' | '1Y'>).map((tf) => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`px-3 py-1 rounded transition-colors cursor-pointer ${
                    timeframe === tf
                      ? 'bg-[#A51C30] text-white shadow-xs'
                      : 'text-[#666] dark:text-[#AAA] hover:text-[#1A1A1A]'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>

          {/* Recharts Area Chart */}
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartDataFormatted}>
                <defs>
                  <linearGradient id="colorStock" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#A51C30" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#A51C30" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#88888820" />
                <XAxis dataKey="time" stroke="#888888" fontSize={11} />
                <YAxis stroke="#888888" fontSize={11} domain={['auto', 'auto']} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1A1A1A', border: 'none', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="price" stroke="#A51C30" strokeWidth={3} fillOpacity={1} fill="url(#colorStock)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Currency & Stock Share Converter Card (1 Col) */}
        <div className="bg-[#FAF9F6] dark:bg-[#1E1E1E] p-6 rounded-2xl border border-[#E0DACF] dark:border-[#2D2D2D] shadow-sm space-y-4">
          <div className="flex items-center space-x-2 border-b border-[#E5E0D8] dark:border-[#2D2D2D] pb-3">
            <Calculator className="w-5 h-5 text-amber-500" />
            <h3 className="font-serif font-bold text-base text-[#1A1A1A] dark:text-white">
              Rand & Stock Share Calculator
            </h3>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <label className="block font-bold text-[#444] dark:text-[#CCC] mb-1">
                Input Investment Amount
              </label>
              <div className="flex gap-2">
                <input
                  type="number"
                  value={converterAmount}
                  onChange={(e) => setConverterAmount(Number(e.target.value))}
                  className="flex-1 px-3 py-2 bg-white dark:bg-[#2A2A2A] border border-[#E0DACF] dark:border-[#333] rounded-lg text-sm font-bold text-[#1A1A1A] dark:text-white"
                />
                <select
                  value={converterCurrency}
                  onChange={(e) => setConverterCurrency(e.target.value as CurrencyMode)}
                  className="px-3 py-2 bg-white dark:bg-[#2A2A2A] border border-[#E0DACF] dark:border-[#333] rounded-lg text-xs font-bold"
                >
                  <option value="ZAR">R (Rand)</option>
                  <option value="USD">$ (USD)</option>
                  <option value="INR">₹ (INR)</option>
                  <option value="SATS">⚡ Sats</option>
                </select>
              </div>
            </div>

            {/* Output Conversions */}
            <div className="p-4 bg-white dark:bg-[#151515] rounded-xl border border-[#E5E0D8] dark:border-[#333] space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-[#666] dark:text-[#AAA]">USD Value:</span>
                <span className="font-bold text-[#1A1A1A] dark:text-white">${usdVal.toFixed(2)} USD</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#666] dark:text-[#AAA]">SA Rand (R):</span>
                <span className="font-bold text-amber-600 dark:text-amber-400">R {(usdVal * ZAR_PER_USD).toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[#666] dark:text-[#AAA]">Sats Equivalent:</span>
                <span className="font-bold text-amber-500">⚡ {satsEquivalent.toLocaleString()} sats</span>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-[#EEE] dark:border-[#2A2A2A]">
                <span className="font-bold text-[#1A1A1A] dark:text-white">Shares of {selectedStock.symbol}:</span>
                <span className="font-extrabold text-[#A51C30] dark:text-amber-400 text-sm">
                  {sharesOfSelected < 0.01 ? sharesOfSelected.toFixed(4) : sharesOfSelected.toFixed(2)} shares
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* 4. Business & Markets News Grid */}
      <div className="space-y-4 pt-4 border-t border-[#E5E0D8] dark:border-[#2D2D2D]">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Briefcase className="w-5 h-5 text-[#A51C30]" />
            <h2 className="font-serif text-2xl font-bold text-[#1A1A1A] dark:text-white">
              Business, Wall Street & Macro News
            </h2>
          </div>
          <span className="text-xs text-[#777]">Updated continuously</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {businessArticles.map(article => (
            <div 
              key={article.id}
              className="bg-white dark:bg-[#1A1A1A] p-5 rounded-xl border border-[#E0DACF] dark:border-[#2D2D2D] shadow-xs flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="relative">
                  <img src={article.featuredImage} alt={article.title} className="w-full h-48 object-cover rounded-lg" />
                  {article.isPremiumPaywall && (
                    <span className="absolute top-2 right-2 bg-amber-400 text-black text-[10px] font-sans font-bold px-2.5 py-1 rounded-md shadow-md flex items-center gap-1">
                      <Lock className="w-3.5 h-3.5" /> ⚡ {article.paywallSatsPrice || 210} sats
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-[#A51C30]">
                  <span>{article.categoryTag}</span>
                  {article.satsTipped && (
                    <span className="text-amber-600 dark:text-amber-400 flex items-center gap-1 font-mono">
                      <Zap className="w-3.5 h-3.5 fill-amber-500" />
                      {article.satsTipped.toLocaleString()} sats
                    </span>
                  )}
                </div>

                <h3 
                  onClick={() => setSelectedArticle(article)}
                  className="font-serif text-xl font-bold text-[#1A1A1A] dark:text-white hover:text-[#A51C30] cursor-pointer leading-tight"
                >
                  {article.title}
                </h3>
                <p className="text-xs text-[#555] dark:text-[#AAA] line-clamp-2">
                  {article.summary}
                </p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-[#EEE] dark:border-[#2A2A2A] text-xs font-serif">
                <span>By {article.author.name}</span>
                <button
                  onClick={() => setSelectedArticle(article)}
                  className="text-[#A51C30] dark:text-amber-400 font-bold hover:underline"
                >
                  Read Full Report →
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
