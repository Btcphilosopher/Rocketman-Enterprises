import React from 'react';
import { useApp } from '../context/AppContext';
import { Article } from '../types';
import { Bookmark, ArrowRight, Quote, BookOpen, Zap, Lock } from 'lucide-react';

export const SectionGrid: React.FC = () => {
  const { articles, setSelectedArticle, savedArticleIds, toggleSaveArticle, activeDepartment } = useApp();

  // Filter articles based on active department
  const filtered = activeDepartment === 'All' 
    ? articles 
    : articles.filter(a => a.department.toLowerCase() === activeDepartment.toLowerCase());

  // Categorized collections
  const universityArticles = articles.filter(a => a.department === 'University' || a.department === 'Climate');
  const globalArticles = articles.filter(a => a.department === 'Global' || a.department === 'Technology');
  const opinionArticles = articles.filter(a => a.department === 'Opinion');
  const magazineArticles = articles.filter(a => a.department === 'Magazine' || a.categoryTag === 'FEATURE' || a.categoryTag === 'BOOKS');

  return (
    <div className="w-full bg-[#FAFAFA] dark:bg-[#121212] py-8 transition-colors">
      <div className="max-w-7xl mx-auto px-4 space-y-12">
        
        {/* If user selected a specific department tab, show direct filtered list */}
        {activeDepartment !== 'All' ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between border-b-2 border-[#A51C30] pb-2">
              <h2 className="font-serif text-2xl font-black text-[#1A1A1A] dark:text-[#F5F5F3] uppercase tracking-wide">
                Department: {activeDepartment}
              </h2>
              <span className="text-xs font-sans text-[#777]">{filtered.length} Stories Published</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {filtered.map(art => (
                <article key={art.id} className="bg-white dark:bg-[#1A1A1A] p-4 border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs shadow-xs space-y-3 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="relative">
                      <img src={art.featuredImage} alt={art.title} className="w-full h-48 object-cover rounded-xs" />
                      {art.isPremiumPaywall && (
                        <span className="absolute top-2 right-2 bg-amber-400 text-black text-[10px] font-sans font-bold px-2 py-0.5 rounded shadow-sm flex items-center gap-1">
                          <Lock className="w-3 h-3" /> ⚡ {art.paywallSatsPrice || 210} sats
                        </span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[10px] font-sans font-bold uppercase tracking-wider">
                      <span className="text-[#A51C30] dark:text-[#E57373]">{art.categoryTag}</span>
                      {art.satsTipped && (
                        <span className="text-amber-600 dark:text-amber-400 flex items-center gap-0.5 font-mono">
                          <Zap className="w-3 h-3 fill-amber-500 text-amber-500" />
                          {art.satsTipped.toLocaleString()} sats
                        </span>
                      )}
                    </div>
                    <h3 
                      onClick={() => setSelectedArticle(art)}
                      className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#EEE] hover:text-[#A51C30] cursor-pointer leading-snug"
                    >
                      {art.title}
                    </h3>
                    <p className="font-serif text-xs text-[#555] dark:text-[#AAA] line-clamp-3">{art.summary}</p>
                  </div>

                  <div className="pt-3 border-t border-[#EFECE6] dark:border-[#222] flex items-center justify-between text-xs font-serif text-[#777]">
                    <span>By {art.author.name}</span>
                    <button onClick={() => toggleSaveArticle(art.id)} className="cursor-pointer">
                      <Bookmark className={`w-3.5 h-3.5 ${savedArticleIds.includes(art.id) ? 'fill-current text-[#A51C30]' : ''}`} />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          </div>
        ) : (
          <>
            {/* ROW 1: University | Global | Opinion */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              
              {/* 1. University Section (4 Cols) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="flex items-center space-x-2 border-b-2 border-[#A51C30] pb-2">
                  <h3 className="font-serif text-xl font-bold text-[#1A1A1A] dark:text-[#F5F5F3]">
                    University
                  </h3>
                </div>

                {universityArticles.slice(0, 2).map((art, idx) => (
                  <div key={art.id} className="space-y-2 pb-4 border-b border-[#E5E0D8] dark:border-[#2A2A2A] last:border-b-0">
                    {idx === 0 && (
                      <img 
                        src={art.featuredImage} 
                        alt={art.title}
                        onClick={() => setSelectedArticle(art)}
                        className="w-full h-44 object-cover rounded-xs border border-[#E0DACF] dark:border-[#2A2A2A] cursor-pointer" 
                      />
                    )}

                    <h4 
                      onClick={() => setSelectedArticle(art)}
                      className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#F5F5F3] hover:text-[#A51C30] leading-snug cursor-pointer"
                    >
                      {art.title}
                    </h4>

                    <p className="font-serif text-xs text-[#555] dark:text-[#AAA] leading-relaxed line-clamp-2">
                      {art.subtitle}
                    </p>

                    <div className="text-[11px] font-serif text-[#A51C30] dark:text-[#E57373] font-semibold">
                      By {art.author.name}
                    </div>
                  </div>
                ))}
              </div>

              {/* 2. Global Section (4 Cols) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="flex items-center space-x-2 border-b-2 border-[#A51C30] pb-2">
                  <h3 className="font-serif text-xl font-bold text-[#1A1A1A] dark:text-[#F5F5F3]">
                    Global
                  </h3>
                </div>

                {globalArticles.slice(0, 2).map((art, idx) => (
                  <div key={art.id} className="space-y-2 pb-4 border-b border-[#E5E0D8] dark:border-[#2A2A2A] last:border-b-0">
                    {idx === 0 && (
                      <img 
                        src={art.featuredImage} 
                        alt={art.title}
                        onClick={() => setSelectedArticle(art)}
                        className="w-full h-44 object-cover rounded-xs border border-[#E0DACF] dark:border-[#2A2A2A] cursor-pointer" 
                      />
                    )}

                    <h4 
                      onClick={() => setSelectedArticle(art)}
                      className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#F5F5F3] hover:text-[#A51C30] leading-snug cursor-pointer"
                    >
                      {art.title}
                    </h4>

                    <p className="font-serif text-xs text-[#555] dark:text-[#AAA] leading-relaxed line-clamp-2">
                      {art.subtitle}
                    </p>

                    <div className="text-[11px] font-serif text-[#A51C30] dark:text-[#E57373] font-semibold">
                      By {art.author.name}
                    </div>
                  </div>
                ))}
              </div>

              {/* 3. Opinion Columnists (4 Cols) */}
              <div className="lg:col-span-4 space-y-4">
                <div className="flex items-center space-x-2 border-b-2 border-[#A51C30] pb-2">
                  <h3 className="font-serif text-xl font-bold text-[#1A1A1A] dark:text-[#F5F5F3]">
                    Opinion
                  </h3>
                </div>

                <div className="space-y-4">
                  {opinionArticles.map((art) => (
                    <div key={art.id} className="flex items-start space-x-3 pb-3 border-b border-[#E5E0D8] dark:border-[#2A2A2A] last:border-b-0">
                      <img 
                        src={art.author.avatar} 
                        alt={art.author.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-[#A51C30]/40 shrink-0" 
                      />

                      <div className="space-y-1 flex-1">
                        <span className="text-[10px] font-sans font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-widest">
                          {art.categoryTag}
                        </span>

                        <h4 
                          onClick={() => setSelectedArticle(art)}
                          className="font-serif text-sm font-bold text-[#1A1A1A] dark:text-[#F5F5F3] hover:text-[#A51C30] leading-snug cursor-pointer"
                        >
                          {art.title}
                        </h4>

                        <div className="flex items-center justify-between text-[11px] font-serif text-[#666] dark:text-[#AAA]">
                          <span>By {art.author.name}</span>
                          <button onClick={() => toggleSaveArticle(art.id)} className="cursor-pointer">
                            <Bookmark className={`w-3.5 h-3.5 ${savedArticleIds.includes(art.id) ? 'fill-current text-[#A51C30]' : ''}`} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>

            {/* Editorial Rule Divider */}
            <div className="w-full h-px bg-[#E5E0D8] dark:bg-[#2A2A2A]"></div>

            {/* ROW 2: The Chronicle Magazine Section (3-column feature showcase) */}
            <div className="space-y-6">
              
              <div className="flex items-center justify-between border-b-2 border-[#A51C30] pb-2">
                <div className="flex items-center space-x-3">
                  <BookOpen className="w-5 h-5 text-[#A51C30] dark:text-[#E57373]" />
                  <h3 className="font-serif text-2xl font-black text-[#1A1A1A] dark:text-[#F5F5F3]">
                    The Chronicle Magazine
                  </h3>
                </div>
                <span className="text-xs font-serif italic text-[#777] dark:text-[#AAA]">Spring Quarterly Features</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {magazineArticles.map((art) => (
                  <article key={art.id} className="space-y-3 group">
                    <div 
                      onClick={() => setSelectedArticle(art)}
                      className="relative overflow-hidden rounded-xs border border-[#E0DACF] dark:border-[#2A2A2A] cursor-pointer"
                    >
                      <img 
                        src={art.featuredImage} 
                        alt={art.title}
                        className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-500" 
                      />
                      <span className="absolute top-3 left-3 bg-[#1A1A1A]/90 text-white text-[10px] font-sans font-bold uppercase tracking-widest px-2 py-0.5">
                        {art.categoryTag}
                      </span>
                    </div>

                    <h4 
                      onClick={() => setSelectedArticle(art)}
                      className="font-serif text-xl font-bold text-[#1A1A1A] dark:text-[#F5F5F3] group-hover:text-[#A51C30] leading-snug cursor-pointer"
                    >
                      {art.title}
                    </h4>

                    <p className="font-serif text-xs text-[#555] dark:text-[#AAA] leading-relaxed line-clamp-3">
                      {art.summary}
                    </p>

                    <div className="pt-2 text-xs font-serif text-[#A51C30] dark:text-[#E57373] font-semibold">
                      By {art.author.name}
                    </div>
                  </article>
                ))}
              </div>

            </div>
          </>
        )}

      </div>
    </div>
  );
};
