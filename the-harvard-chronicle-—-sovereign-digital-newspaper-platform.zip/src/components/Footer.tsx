import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Department } from '../types';
import { MOCK_DEPARTMENTS } from '../data/mockArticles';
import { Mail, Shield, Check, Heart, ExternalLink } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setActiveDepartment, setActiveView, setIsArchiveModalOpen, setIsEventsModalOpen, setIsCMSModalOpen, setIsRSSModalOpen } = useApp();
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.trim()) return;
    setSubscribed(true);
    setTimeout(() => {
      setNewsletterEmail('');
      setSubscribed(false);
    }, 3000);
  };

  return (
    <footer className="w-full bg-[#A51C30] text-white border-t-4 border-[#8A1627] pt-12 pb-8 transition-colors">
      <div className="max-w-7xl mx-auto px-4 space-y-12">
        
        {/* Top Brand Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-white/20">
          
          {/* Brand Info (4 Cols) */}
          <div className="md:col-span-4 space-y-4">
            <div className="flex items-center space-x-3">
              <svg className="w-9 h-9 fill-current text-white" viewBox="0 0 100 100">
                <path d="M50,5 L90,20 L90,65 C90,80 50,95 50,95 C50,95 10,80 10,65 L10,20 Z" fill="currentColor" opacity="0.2" />
                <path d="M50,10 L85,23 L85,62 C85,75 50,88 50,88 C50,88 15,75 15,62 L15,23 Z" fill="none" stroke="currentColor" strokeWidth="4" />
                <text x="50" y="45" textAnchor="middle" fontSize="22" fontWeight="bold" fill="currentColor" fontFamily="serif">VE RI</text>
                <text x="50" y="68" textAnchor="middle" fontSize="22" fontWeight="bold" fill="currentColor" fontFamily="serif">TAS</text>
              </svg>

              <div>
                <h3 className="font-serif text-2xl font-black text-white leading-none">The Harvard Chronicle</h3>
                <p className="font-serif italic text-xs text-white/80 mt-1">Independent since 1873</p>
              </div>
            </div>

            <p className="font-serif text-xs text-white/80 leading-relaxed">
              The Harvard Chronicle is the independent student-run daily newspaper of Harvard University, published in Cambridge, Massachusetts. Reporting on academic discovery, global affairs, and campus life for over 150 years.
            </p>

            <div className="text-[11px] font-sans font-semibold text-amber-200">
              Harvard Yard • Cambridge, MA 02138
            </div>
          </div>

          {/* Department Directory Links (4 Cols) */}
          <div className="md:col-span-4 grid grid-cols-2 gap-4 text-xs font-sans">
            <div>
              <h4 className="font-bold uppercase text-amber-200 mb-3 tracking-wider">Sections</h4>
              <ul className="space-y-2 text-white/90">
                {['News', 'University', 'Opinion', 'Global', 'Science & Tech', 'Arts'].map(d => (
                  <li key={d}>
                    <button 
                      onClick={() => {
                        setActiveDepartment(d as Department);
                        setActiveView('department');
                        window.scrollTo({ top: 400, behavior: 'smooth' });
                      }}
                      className="hover:text-amber-200 cursor-pointer"
                    >
                      {d}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-bold uppercase text-amber-200 mb-3 tracking-wider">Publishing & Feeds</h4>
              <ul className="space-y-2 text-white/90">
                <li><button onClick={() => setIsRSSModalOpen(true)} className="hover:text-amber-200 font-bold cursor-pointer text-orange-300">⚡ RSS & Value-4-Value Feeds</button></li>
                <li><button onClick={() => setActiveView('markets')} className="hover:text-amber-200 cursor-pointer">Stock Market Index (R)</button></li>
                <li><button onClick={() => setIsArchiveModalOpen(true)} className="hover:text-amber-200 cursor-pointer">1873-2026 Archives</button></li>
                <li><button onClick={() => setIsEventsModalOpen(true)} className="hover:text-amber-200 cursor-pointer">Academic Events</button></li>
                <li><button onClick={() => setIsCMSModalOpen(true)} className="hover:text-amber-200 font-bold cursor-pointer">Newsroom CMS</button></li>
              </ul>
            </div>
          </div>

          {/* Newsletter Box (4 Cols) */}
          <div className="md:col-span-4 space-y-3 bg-black/20 p-5 rounded-xs border border-white/10">
            <h4 className="font-serif text-base font-bold text-white flex items-center gap-2">
              <Mail className="w-4 h-4 text-amber-200" />
              <span>Subscribe to The Morning Dispatch</span>
            </h4>

            <p className="font-serif text-xs text-white/80">
              Delivered daily to over 40,000 scholars, faculty, and global alumni every morning at 06:00 EST.
            </p>

            {subscribed ? (
              <div className="p-2.5 bg-emerald-800 text-white text-xs font-sans font-bold rounded flex items-center gap-2">
                <Check className="w-4 h-4" /> You are subscribed to The Daily Dispatch!
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  required
                  placeholder="Enter your university email..."
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  className="flex-1 bg-white text-[#1A1A1A] p-2 text-xs font-sans rounded-xs focus:outline-none"
                />
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#1A1A1A] hover:bg-black text-amber-200 text-xs font-sans font-bold uppercase rounded-xs cursor-pointer"
                >
                  Join
                </button>
              </form>
            )}
          </div>

        </div>

        {/* Bottom Copyright */}
        <div className="flex flex-col sm:flex-row items-center justify-between text-xs font-serif text-white/70 space-y-2 sm:space-y-0">
          <div>
            © {new Date().getFullYear()} The Harvard Chronicle. All rights reserved.
          </div>
          <div className="flex items-center space-x-4 font-sans text-[11px]">
            <span>Privacy Policy</span>
            <span>•</span>
            <span>Terms of Service</span>
            <span>•</span>
            <span>Accessibility Standards</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
