import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Rss, 
  Copy, 
  Check, 
  ExternalLink, 
  Zap, 
  User, 
  Building2, 
  Radio, 
  Code2, 
  Sparkles,
  CheckCircle2
} from 'lucide-react';
import { Author } from '../types';

export const RSSFeedModal: React.FC = () => {
  const { 
    isRSSModalOpen, 
    setIsRSSModalOpen, 
    rssTargetAuthor, 
    setRssTargetAuthor,
    articles 
  } = useApp();

  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedXml, setCopiedXml] = useState(false);
  const [selectedAuthorId, setSelectedAuthorId] = useState<string>(rssTargetAuthor?.id || 'all');
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [activeTab, setActiveTab] = useState<'subscribe' | 'xml' | 'authors'>('subscribe');
  const [isSubscribed, setIsSubscribed] = useState(false);

  if (!isRSSModalOpen) return null;

  // Extract unique authors across all articles
  const authorsMap = new Map<string, Author>();
  articles.forEach(a => {
    if (a.author && !authorsMap.has(a.author.id)) {
      authorsMap.set(a.author.id, a.author);
    }
  });
  const authors = Array.from(authorsMap.values());

  const currentAuthor = authors.find(a => a.id === selectedAuthorId) || rssTargetAuthor;

  // Generate RSS Feed URL
  const getFeedUrl = () => {
    if (currentAuthor) {
      const slug = currentAuthor.name.toLowerCase().replace(/\s+/g, '-');
      return `https://harvardchronicle.org/rss/author/${slug}.xml`;
    }
    if (selectedDept !== 'all') {
      return `https://harvardchronicle.org/rss/department/${selectedDept.toLowerCase().replace(/[^a-z0-9]/g, '')}.xml`;
    }
    return `https://harvardchronicle.org/rss/feed.xml`;
  };

  const feedUrl = getFeedUrl();

  // Filter articles for RSS XML payload
  const feedArticles = articles.filter(a => {
    if (currentAuthor && a.author.id !== currentAuthor.id) return false;
    if (selectedDept !== 'all' && a.department !== selectedDept) return false;
    return true;
  }).slice(0, 10);

  // Generate RSS 2.0 XML text with Lightning V4V extension
  const generateRSSXml = () => {
    const channelTitle = currentAuthor 
      ? `The Harvard Chronicle — Journalist Stream: ${currentAuthor.name}`
      : selectedDept !== 'all' 
      ? `The Harvard Chronicle — ${selectedDept} Department`
      : `The Harvard Chronicle — Official Value-4-Value Feed`;

    const channelDesc = currentAuthor 
      ? `RSS 2.0 feed and Lightning micropayment channel for ${currentAuthor.name} (${currentAuthor.role}).`
      : `Independent journalism from Harvard University with native Bitcoin Lightning micropayments.`;

    const authorLightning = currentAuthor?.lightningAddress || 'chronicle@stacker.news';

    const itemsXml = feedArticles.map(a => `
    <item>
      <title><![CDATA[${a.title}]]></title>
      <link>https://harvardchronicle.org/article/${a.slug}</link>
      <guid isPermaLink="true">https://harvardchronicle.org/article/${a.slug}</guid>
      <pubDate>${a.publishedAt}</pubDate>
      <author>${a.author.name}</author>
      <category>${a.department}</category>
      <description><![CDATA[${a.summary}]]></description>
      <lightning:address>${a.author.lightningAddress || authorLightning}</lightning:address>
      <podcast:value type="lightning" method="keysend">
        <podcast:valueRecipient name="${a.author.name}" address="${a.author.lightningAddress || authorLightning}" split="85" />
        <podcast:valueRecipient name="Harvard Chronicle Fund" address="chronicle@stacker.news" split="15" />
      </podcast:value>
    </item>`).join('');

    return `<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0" xmlns:lightning="https://lightning.network/rss/1.0" xmlns:podcast="https://podcastindex.org/namespace/1.0">
  <channel>
    <title><![CDATA[${channelTitle}]]></title>
    <link>${feedUrl}</link>
    <description><![CDATA[${channelDesc}]]></description>
    <language>en-us</language>
    <publisher>The Harvard Chronicle</publisher>
    <lightning:address>${authorLightning}</lightning:address>
    ${itemsXml}
  </channel>
</rss>`;
  };

  const xmlContent = generateRSSXml();

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(feedUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const handleCopyXml = () => {
    navigator.clipboard.writeText(xmlContent);
    setCopiedXml(true);
    setTimeout(() => setCopiedXml(false), 2000);
  };

  const handleClose = () => {
    setIsRSSModalOpen(false);
    setRssTargetAuthor(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div 
        id="rss-feed-modal"
        className="w-full max-w-2xl bg-white dark:bg-[#181818] rounded-2xl shadow-2xl border border-[#E5E0D8] dark:border-[#333] overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-[#A51C30] text-white p-5 flex items-center justify-between border-b border-[#8A1627]">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-orange-500 text-white rounded-lg shadow-md">
              <Rss className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold tracking-tight">
                RSS Feeds & Journalist Subscriptions
              </h2>
              <p className="text-xs text-orange-100 font-sans">
                Open RSS 2.0 • Value-4-Value Lightning Specification
              </p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Context Banner */}
        <div className="bg-[#FAF8F5] dark:bg-[#202020] px-6 py-3 border-b border-[#E5E0D8] dark:border-[#2D2D2D] flex items-center justify-between font-sans">
          <div className="flex items-center space-x-3 overflow-hidden">
            {currentAuthor ? (
              <>
                <img 
                  src={currentAuthor.avatar} 
                  alt={currentAuthor.name}
                  className="w-9 h-9 rounded-full object-cover border border-[#A51C30]" 
                />
                <div className="truncate">
                  <div className="text-xs font-bold text-[#1A1A1A] dark:text-white truncate">
                    Subscribing to {currentAuthor.name}
                  </div>
                  <div className="text-[11px] text-[#666] dark:text-[#AAA] truncate flex items-center gap-1.5">
                    <span>{currentAuthor.role}</span>
                    {currentAuthor.lightningAddress && (
                      <span className="text-amber-600 dark:text-amber-400 font-semibold">⚡ {currentAuthor.lightningAddress}</span>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Building2 className="w-5 h-5 text-[#A51C30]" />
                <div>
                  <div className="text-xs font-bold text-[#1A1A1A] dark:text-white">
                    The Harvard Chronicle — Full Newsroom Feed
                  </div>
                  <div className="text-[11px] text-[#666] dark:text-[#AAA]">
                    Syndicated articles, research papers, and podcasts
                  </div>
                </div>
              </div>
            )}
          </div>

          {currentAuthor && (
            <button
              onClick={() => {
                setSelectedAuthorId('all');
                setRssTargetAuthor(null);
              }}
              className="text-[11px] text-[#A51C30] dark:text-amber-400 underline font-semibold cursor-pointer shrink-0"
            >
              Reset to Main Feed
            </button>
          )}
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-[#E5E0D8] dark:border-[#2D2D2D] bg-[#F5F3EF] dark:bg-[#1E1E1E] text-xs font-sans font-semibold">
          <button
            onClick={() => setActiveTab('subscribe')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'subscribe'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>Subscribe & Feed Link</span>
          </button>

          <button
            onClick={() => setActiveTab('authors')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'authors'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <User className="w-4 h-4" />
            <span>Journalists Directory ({authors.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('xml')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'xml'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>Raw RSS XML Code</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 font-sans space-y-5">
          
          {/* TAB 1: SUBSCRIBE & FEED URL */}
          {activeTab === 'subscribe' && (
            <div className="space-y-4">
              <div className="text-xs text-[#555] dark:text-[#AAA] leading-relaxed">
                Subscribe to instant updates and Lightning Value-4-Value payments using any standard RSS reader, Podcast Index app, or Fountain reader.
              </div>

              {/* Feed URL Copy Bar */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold text-[#333] dark:text-[#EEE]">
                  Direct RSS Feed Endpoint URL
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    readOnly
                    value={feedUrl}
                    className="flex-1 px-3.5 py-2 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] rounded-xl text-xs font-mono text-amber-700 dark:text-amber-300 font-semibold focus:outline-none"
                  />
                  <button
                    onClick={handleCopyUrl}
                    className="px-4 py-2 bg-[#A51C30] hover:bg-[#8A1627] text-white text-xs font-bold rounded-xl transition-colors cursor-pointer flex items-center gap-1.5 shadow-xs"
                  >
                    {copiedUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    <span>{copiedUrl ? 'Copied!' : 'Copy Link'}</span>
                  </button>
                </div>
              </div>

              {/* 1-Click Readers Integration Grid */}
              <div className="space-y-2 pt-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-[#666] dark:text-[#AAA]">
                  Add to Reader App
                </label>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  <a
                    href={`https://feedly.com/i/subscription/feed/${encodeURIComponent(feedUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] hover:border-emerald-500 rounded-xl text-center text-xs font-bold text-[#1A1A1A] dark:text-white transition-all hover:shadow-sm flex flex-col items-center gap-1"
                  >
                    <span className="text-emerald-600 dark:text-emerald-400 font-extrabold text-sm">Feedly</span>
                    <span className="text-[10px] text-[#777]">1-Click Web</span>
                  </a>

                  <a
                    href={`https://www.inoreader.com/feed/${encodeURIComponent(feedUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-3 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] hover:border-blue-500 rounded-xl text-center text-xs font-bold text-[#1A1A1A] dark:text-white transition-all hover:shadow-sm flex flex-col items-center gap-1"
                  >
                    <span className="text-blue-600 dark:text-blue-400 font-extrabold text-sm">Inoreader</span>
                    <span className="text-[10px] text-[#777]">1-Click Web</span>
                  </a>

                  <button
                    onClick={() => {
                      setIsSubscribed(true);
                      setTimeout(() => setIsSubscribed(false), 3000);
                    }}
                    className="p-3 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] hover:border-amber-500 rounded-xl text-center text-xs font-bold text-[#1A1A1A] dark:text-white transition-all hover:shadow-sm flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <span className="text-amber-500 font-extrabold text-sm flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 fill-amber-500" />
                      Fountain / V4V
                    </span>
                    <span className="text-[10px] text-[#777]">Lightning RSS</span>
                  </button>

                  <button
                    onClick={handleCopyUrl}
                    className="p-3 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] hover:border-orange-500 rounded-xl text-center text-xs font-bold text-[#1A1A1A] dark:text-white transition-all hover:shadow-sm flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <span className="text-orange-600 dark:text-orange-400 font-extrabold text-sm">Apple / NetNews</span>
                    <span className="text-[10px] text-[#777]">Copy RSS Feed</span>
                  </button>
                </div>

                {isSubscribed && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs rounded-xl flex items-center gap-2 animate-fadeIn">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Subscribed! Journalist stream linked to your Bitcoin Lightning wallet.</span>
                  </div>
                )}
              </div>

              {/* Preview Articles in Feed */}
              <div className="pt-2 border-t border-[#E5E0D8] dark:border-[#2D2D2D] space-y-2">
                <div className="text-xs font-bold text-[#333] dark:text-[#EEE]">
                  Feed Content Preview ({feedArticles.length} items)
                </div>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {feedArticles.map(art => (
                    <div key={art.id} className="p-3 bg-[#FAF9F6] dark:bg-[#202020] rounded-xl border border-[#E0DACF] dark:border-[#333] flex items-center justify-between text-xs">
                      <div className="truncate pr-3">
                        <span className="font-bold text-[#1A1A1A] dark:text-white block truncate">{art.title}</span>
                        <span className="text-[11px] text-[#777]">{art.publishedAt} • By {art.author.name}</span>
                      </div>
                      <span className="text-[10px] font-mono text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950 px-2 py-0.5 rounded border border-amber-200 dark:border-amber-800 shrink-0">
                        ⚡ {art.author.lightningAddress || 'olivia@stacker.news'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: JOURNALISTS DIRECTORY */}
          {activeTab === 'authors' && (
            <div className="space-y-3">
              <div className="text-xs text-[#555] dark:text-[#AAA]">
                Select any Harvard Chronicle journalist to generate their dedicated RSS stream and Lightning wallet link:
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-80 overflow-y-auto">
                {authors.map((auth) => (
                  <div
                    key={auth.id}
                    onClick={() => {
                      setSelectedAuthorId(auth.id);
                      setRssTargetAuthor(auth);
                      setActiveTab('subscribe');
                    }}
                    className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center space-x-3 ${
                      selectedAuthorId === auth.id || currentAuthor?.id === auth.id
                        ? 'border-[#A51C30] bg-rose-50/50 dark:bg-rose-950/20 shadow-sm'
                        : 'border-[#E0DACF] dark:border-[#333] bg-[#FAF9F6] dark:bg-[#202020] hover:border-amber-500'
                    }`}
                  >
                    <img 
                      src={auth.avatar} 
                      alt={auth.name} 
                      className="w-11 h-11 rounded-full object-cover border-2 border-amber-400 shrink-0"
                    />
                    <div className="truncate flex-1">
                      <div className="font-bold text-xs text-[#1A1A1A] dark:text-white truncate">{auth.name}</div>
                      <div className="text-[11px] text-[#666] dark:text-[#AAA] truncate">{auth.role}</div>
                      {auth.lightningAddress && (
                        <div className="text-[10px] font-mono text-amber-600 dark:text-amber-400 font-semibold truncate mt-0.5">
                          ⚡ {auth.lightningAddress}
                        </div>
                      )}
                    </div>
                    <button className="px-2.5 py-1 bg-[#A51C30] hover:bg-[#8A1627] text-white text-[10px] font-bold rounded-md shrink-0">
                      RSS →
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: RAW RSS XML */}
          {activeTab === 'xml' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#333] dark:text-[#EEE]">
                  Generated RSS 2.0 & Value-4-Value XML Schema
                </span>
                <button
                  onClick={handleCopyXml}
                  className="px-3 py-1 bg-[#A51C30] text-white rounded-md text-xs font-bold flex items-center gap-1 cursor-pointer"
                >
                  {copiedXml ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedXml ? 'Copied XML' : 'Copy XML Payload'}</span>
                </button>
              </div>

              <pre className="p-4 bg-[#1E1E1E] text-amber-300 rounded-xl font-mono text-[11px] overflow-x-auto max-h-72 border border-[#333]">
                {xmlContent}
              </pre>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-[#F5F3EF] dark:bg-[#1A1A1A] border-t border-[#E5E0D8] dark:border-[#2A2A2A] text-center text-[11px] text-[#666] dark:text-[#AAA] flex items-center justify-between font-sans">
          <span>RSS 2.0 Standard • Podcast Index Namespace Compliant</span>
          <a
            href="https://podcastindex.org"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline text-[#A51C30] dark:text-amber-400 flex items-center gap-1 font-semibold"
          >
            <span>Value-4-Value Specification</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

      </div>
    </div>
  );
};
