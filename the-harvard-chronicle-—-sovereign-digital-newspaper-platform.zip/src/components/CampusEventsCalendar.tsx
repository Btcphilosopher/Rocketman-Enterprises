import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MOCK_EVENTS } from '../data/podcastsAndVideos';
import { Calendar, X, MapPin, Clock, User, Check } from 'lucide-react';

export const CampusEventsCalendar: React.FC = () => {
  const { isEventsModalOpen, setIsEventsModalOpen } = useApp();
  const [registeredIds, setRegisteredIds] = useState<string[]>([]);

  if (!isEventsModalOpen) return null;

  const toggleRegister = (id: string) => {
    setRegisteredIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#FAFAFA] dark:bg-[#121212] text-[#1A1A1A] dark:text-[#E8E8E8] max-w-3xl w-full my-auto rounded-xs shadow-2xl border border-[#E0DACF] dark:border-[#2A2A2A] relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 bg-[#A51C30] text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Calendar className="w-5 h-5" />
            <div>
              <h3 className="font-serif text-lg font-bold">University Lectures, Symposia & Public Events</h3>
              <p className="text-[11px] font-sans opacity-90">Spring Term Academic Calendar</p>
            </div>
          </div>
          <button 
            onClick={() => setIsEventsModalOpen(false)}
            className="p-1 hover:bg-white/20 rounded cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* List of Events */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1 divide-y divide-[#EFECE6] dark:divide-[#222]">
          {MOCK_EVENTS.map((evt) => {
            const isRegistered = registeredIds.includes(evt.id);

            return (
              <div key={evt.id} className="pt-4 first:pt-0 space-y-2">
                <div className="flex items-center justify-between text-xs font-sans text-[#777]">
                  <span className="font-bold text-[#A51C30] uppercase">{evt.department}</span>
                  <span className="flex items-center gap-1 font-semibold text-[#1A1A1A] dark:text-[#EEE]">
                    <Clock className="w-3.5 h-3.5" /> {evt.date} • {evt.time}
                  </span>
                </div>

                <h4 className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#EEE]">
                  {evt.title}
                </h4>

                <p className="font-serif text-xs text-[#555] dark:text-[#AAA]">
                  {evt.description}
                </p>

                <div className="flex flex-wrap items-center justify-between text-xs font-sans text-[#666] pt-1">
                  <div className="flex items-center space-x-3">
                    <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-[#A51C30]" /> {evt.location}</span>
                    <span className="flex items-center gap-1"><User className="w-3.5 h-3.5 text-[#A51C30]" /> {evt.speaker}</span>
                  </div>

                  <button
                    onClick={() => toggleRegister(evt.id)}
                    className={`px-3 py-1 text-xs font-sans font-bold uppercase rounded-xs transition-colors cursor-pointer flex items-center gap-1 ${
                      isRegistered 
                        ? 'bg-green-700 text-white' 
                        : 'bg-[#A51C30] hover:bg-[#8A1627] text-white'
                    }`}
                  >
                    {isRegistered ? <><Check className="w-3.5 h-3.5" /> RSVD Spot</> : 'RSVP Free Ticket'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
