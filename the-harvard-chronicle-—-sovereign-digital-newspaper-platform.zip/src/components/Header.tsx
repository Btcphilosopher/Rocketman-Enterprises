import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Department } from '../types';
import { MOCK_DEPARTMENTS } from '../data/mockArticles';
import { 
  Search, 
  Sun, 
  Moon, 
  Bookmark, 
  Menu, 
  X, 
  Newspaper, 
  Volume2, 
  Calendar, 
  Archive as ArchiveIcon, 
  PenTool, 
  Sparkles,
  ChevronDown,
  BookOpen,
  Zap,
  Rss,
  TrendingUp
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    activeDepartment, 
    setActiveDepartment, 
    savedArticleIds, 
    isDarkMode, 
    toggleDarkMode, 
    setIsSearchModalOpen,
    setIsCMSModalOpen,
    setIsArchiveModalOpen,
    setIsEventsModalOpen,
    setIsWalletModalOpen,
    setIsRSSModalOpen,
    walletState,
    activeView,
    setActiveView,
    audioNarrationArticle,
    activePodcast,
    isPlayingAudio
  } = useApp();

  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const todayDateStr = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  });

  const handleDeptSelect = (dept: Department | 'All') => {
    setActiveDepartment(dept);
    setActiveView(dept === 'All' ? 'home' : 'department');
    setIsMegaMenuOpen(false);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className="w-full bg-[#FAFAFA] dark:bg-[#121212] border-b border-[#E5E0D8] dark:border-[#2A2A2A] text-[#1A1A1A] dark:text-[#E8E8E8] transition-colors duration-200">
      
      {/* 1. Top Institutional Utility Bar */}
      <div className="bg-[#A51C30] text-white text-xs font-sans px-4 py-1.5 border-b border-[#8A1627]">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Left: Harvard Seal & Crest Brand */}
          <div className="flex items-center space-x-3">
            <svg className="w-5 h-5 fill-current text-white" viewBox="0 0 100 100">
              <path d="M50,5 L90,20 L90,65 C90,80 50,95 50,95 C50,95 10,80 10,65 L10,20 Z" fill="currentColor" opacity="0.15" />
              <path d="M50,10 L85,23 L85,62 C85,75 50,88 50,88 C50,88 15,75 15,62 L15,23 Z" fill="none" stroke="currentColor" strokeWidth="4" />
              <text x="50" y="45" textAnchor="middle" fontSize="22" fontWeight="bold" fill="currentColor" fontFamily="serif">VE RI</text>
              <text x="50" y="68" textAnchor="middle" fontSize="22" fontWeight="bold" fill="currentColor" fontFamily="serif">TAS</text>
            </svg>
            <span className="font-semibold tracking-wider text-[11px] uppercase">HARVARD UNIVERSITY</span>
            <span className="hidden sm:inline text-white/50">|</span>
            <span className="hidden sm:inline text-white/90 text-[11px] italic">Est. 1636 • Cambridge, Massachusetts</span>
          </div>

          {/* Right: Quick Action Links */}
          <div className="flex items-center space-x-4 text-[11px] font-medium tracking-wide uppercase">
            <button 
              onClick={() => setIsRSSModalOpen(true)}
              className="hover:text-amber-200 transition-colors flex items-center gap-1 cursor-pointer text-orange-300"
              title="RSS Feeds & Journalist Subscriptions"
            >
              <Rss className="w-3.5 h-3.5" />
              <span className="hidden md:inline">RSS Feeds</span>
            </button>

            <button 
              onClick={() => setIsEventsModalOpen(true)}
              className="hover:text-amber-200 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <Calendar className="w-3 h-3" />
              <span className="hidden md:inline">Events</span>
            </button>

            <button 
              onClick={() => setIsArchiveModalOpen(true)}
              className="hover:text-amber-200 transition-colors flex items-center gap-1 cursor-pointer"
            >
              <ArchiveIcon className="w-3 h-3" />
              <span className="hidden md:inline">Archives (1873-2026)</span>
            </button>

            <button 
              onClick={() => setIsCMSModalOpen(true)}
              className="hover:text-amber-200 transition-colors flex items-center gap-1 text-amber-200 bg-white/10 px-2 py-0.5 rounded cursor-pointer"
              title="Editorial CMS Newsroom"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>Newsroom CMS</span>
            </button>

            <button
              onClick={toggleDarkMode}
              className="hover:text-amber-200 transition-colors cursor-pointer p-0.5"
              aria-label="Toggle dark mode"
            >
              {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
            </button>
          </div>

        </div>
      </div>

      {/* 2. Main Masthead Section */}
      <div className="max-w-7xl mx-auto px-4 py-6 md:py-8 border-b border-[#E5E0D8] dark:border-[#2A2A2A]">
        <div className="grid grid-cols-1 md:grid-cols-12 items-center gap-4">
          
          {/* Left: Weather & Date */}
          <div className="hidden md:block md:col-span-3 text-xs text-[#555555] dark:text-[#A0A0A0] space-y-1 font-serif">
            <div className="font-sans font-semibold text-[#1A1A1A] dark:text-[#E0E0E0]">{todayDateStr}</div>
            <div>Cambridge, MA • 68°F Clear</div>
            <div className="text-[11px] text-[#A51C30] dark:text-[#E57373] font-sans tracking-wide">Vol. CLIII • No. 142</div>
          </div>

          {/* Center: Grand Title & Tagline */}
          <div className="md:col-span-6 text-center">
            <button 
              onClick={() => handleDeptSelect('All')}
              className="inline-block text-left md:text-center group cursor-pointer focus:outline-none"
            >
              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-[#1A1A1A] dark:text-[#F5F5F3] leading-none select-none">
                The Harvard Chronicle
              </h1>
              <p className="font-serif italic text-xs sm:text-sm text-[#555555] dark:text-[#A0A0A0] mt-2 tracking-wide">
                Independent since 1873. Reporting on ideas that shape tomorrow.
              </p>
            </button>
          </div>

          {/* Right: Printed Edition Widget & Search Trigger */}
          <div className="hidden md:flex md:col-span-3 justify-end items-center gap-4">
            <div className="text-right border-r border-[#E5E0D8] dark:border-[#2A2A2A] pr-4">
              <div className="text-[10px] font-sans font-bold uppercase tracking-wider text-[#A51C30] dark:text-[#E57373]">The Weekly Print</div>
              <div className="text-xs font-serif text-[#333] dark:text-[#CCC]">Edition May 10, 2026</div>
              <span className="text-[10px] underline text-[#555] dark:text-[#AAA]">View Digital PDF →</span>
            </div>

            <button
              onClick={() => setIsSearchModalOpen(true)}
              className="p-2.5 rounded-full bg-[#EFECE6] dark:bg-[#222222] hover:bg-[#A51C30] hover:text-white transition-all cursor-pointer border border-[#E0DACF] dark:border-[#333]"
              title="Search and AI Assistant"
            >
              <Search className="w-4 h-4" />
            </button>
          </div>

        </div>
      </div>

      {/* 3. Primary Sticky Department Navigation Bar */}
      <div className="sticky top-0 z-40 bg-[#FAFAFA]/95 dark:bg-[#121212]/95 backdrop-blur-md border-b border-[#E5E0D8] dark:border-[#2A2A2A] shadow-xs">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
          
          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-[#333] dark:text-[#EEE]"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Desktop Horizontal Department Tabs */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2 overflow-x-auto py-2.5 scrollbar-none">
            <button
              onClick={() => handleDeptSelect('All')}
              className={`px-3 py-1 text-xs font-sans font-bold uppercase tracking-wider rounded transition-colors cursor-pointer ${
                activeDepartment === 'All' && activeView === 'home'
                  ? 'bg-[#A51C30] text-white'
                  : 'text-[#333] dark:text-[#DDD] hover:bg-[#EFECE6] dark:hover:bg-[#222]'
              }`}
            >
              All News
            </button>

            <button
              onClick={() => {
                setActiveView('markets');
                setIsMegaMenuOpen(false);
                setIsMobileMenuOpen(false);
              }}
              className={`px-3 py-1 text-xs font-sans font-bold uppercase tracking-wider whitespace-nowrap rounded transition-all cursor-pointer flex items-center gap-1 ${
                activeView === 'markets'
                  ? 'bg-amber-400 text-black shadow-sm'
                  : 'text-amber-600 dark:text-amber-400 hover:bg-amber-400/10'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Markets (R)</span>
            </button>

            {['News', 'University', 'Opinion', 'Global', 'Business', 'Science & Tech', 'Arts', 'Magazine', 'Podcasts'].map((dept) => (
              <button
                key={dept}
                onClick={() => handleDeptSelect(dept as Department)}
                className={`px-3 py-1 text-xs font-sans font-semibold uppercase tracking-wider whitespace-nowrap rounded transition-colors cursor-pointer ${
                  activeDepartment === dept && activeView !== 'markets'
                    ? 'bg-[#A51C30] text-white'
                    : 'text-[#444] dark:text-[#CCC] hover:text-[#A51C30] dark:hover:text-[#E57373]'
                }`}
              >
                {dept}
              </button>
            ))}

            <button
              onClick={() => setIsMegaMenuOpen(!isMegaMenuOpen)}
              className="px-2 py-1 text-xs font-sans font-semibold text-[#777] dark:text-[#AAA] hover:text-[#A51C30] flex items-center gap-0.5 cursor-pointer uppercase"
            >
              <span>More</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isMegaMenuOpen ? 'rotate-180' : ''}`} />
            </button>
          </nav>

          {/* Search & Audio Indicators (Right side) */}
          <div className="flex items-center space-x-3">
            
            {/* Audio Playing Pill */}
            {(isPlayingAudio && (audioNarrationArticle || activePodcast)) && (
              <div className="flex items-center gap-1.5 bg-[#A51C30]/10 text-[#A51C30] dark:text-[#E57373] text-[11px] font-sans font-semibold px-2.5 py-1 rounded-full animate-pulse">
                <Volume2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Audio Playing</span>
              </div>
            )}

            {/* AI Search & Ask */}
            <button
              onClick={() => setIsSearchModalOpen(true)}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-[#EFECE6] dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] hover:border-[#A51C30] rounded text-xs font-sans font-medium text-[#333] dark:text-[#CCC] cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#A51C30] dark:text-[#E57373]" />
              <span>AI Search</span>
            </button>

            {/* Bitcoin Lightning Wallet Button */}
            <button
              onClick={() => setIsWalletModalOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-400 hover:bg-amber-500 text-black border border-amber-500 rounded text-xs font-sans font-bold shadow-xs cursor-pointer transition-all"
              title="Bitcoin & Lightning Wallet Micropayments"
            >
              <Zap className="w-3.5 h-3.5 fill-black text-black" />
              <span>
                {walletState.isConnected 
                  ? `${walletState.balanceSats.toLocaleString()} sats`
                  : '⚡ Wallet'
                }
              </span>
            </button>

            {/* Bookmarks Counter */}
            <button
              onClick={() => {
                setActiveView('home');
                setActiveDepartment('All');
              }}
              className="relative p-1.5 text-[#444] dark:text-[#CCC] hover:text-[#A51C30] cursor-pointer"
              title="Saved Articles"
            >
              <Bookmark className="w-4 h-4" />
              {savedArticleIds.length > 0 && (
                <span className="absolute -top-1 -right-1 bg-[#A51C30] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {savedArticleIds.length}
                </span>
              )}
            </button>
          </div>

        </div>

        {/* Mega Menu Dropdown */}
        {isMegaMenuOpen && (
          <div className="border-t border-[#E5E0D8] dark:border-[#2A2A2A] bg-[#FAFAFA] dark:bg-[#181818] p-6 shadow-xl animate-fadeIn">
            <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 text-xs font-sans">
              <div>
                <h3 className="font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-wider mb-2 pb-1 border-b border-[#E0DACF] dark:border-[#333]">
                  Academic Research
                </h3>
                <ul className="space-y-1.5 text-[#444] dark:text-[#BBB]">
                  {['Science & Tech', 'Medicine', 'Engineering', 'Humanities', 'Climate'].map(d => (
                    <li key={d}>
                      <button onClick={() => handleDeptSelect(d as Department)} className="hover:text-[#A51C30] dark:hover:text-white cursor-pointer">
                        {d}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-wider mb-2 pb-1 border-b border-[#E0DACF] dark:border-[#333]">
                  Opinion & Columns
                </h3>
                <ul className="space-y-1.5 text-[#444] dark:text-[#BBB]">
                  {['Opinion', 'Business', 'Politics', 'Law'].map(d => (
                    <li key={d}>
                      <button onClick={() => handleDeptSelect(d as Department)} className="hover:text-[#A51C30] dark:hover:text-white cursor-pointer">
                        {d}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-wider mb-2 pb-1 border-b border-[#E0DACF] dark:border-[#333]">
                  Culture & Life
                </h3>
                <ul className="space-y-1.5 text-[#444] dark:text-[#BBB]">
                  {['Arts', 'Sports', 'Magazine', 'Podcasts'].map(d => (
                    <li key={d}>
                      <button onClick={() => handleDeptSelect(d as Department)} className="hover:text-[#A51C30] dark:hover:text-white cursor-pointer">
                        {d}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-wider mb-2 pb-1 border-b border-[#E0DACF] dark:border-[#333]">
                  Archives & Tools
                </h3>
                <ul className="space-y-1.5 text-[#444] dark:text-[#BBB]">
                  <li>
                    <button onClick={() => { setIsArchiveModalOpen(true); setIsMegaMenuOpen(false); }} className="hover:text-[#A51C30] cursor-pointer">
                      1873-2026 Archive Timeline
                    </button>
                  </li>
                  <li>
                    <button onClick={() => { setIsEventsModalOpen(true); setIsMegaMenuOpen(false); }} className="hover:text-[#A51C30] cursor-pointer">
                      Campus Lecture Events
                    </button>
                  </li>
                  <li>
                    <button onClick={() => { setIsCMSModalOpen(true); setIsMegaMenuOpen(false); }} className="hover:text-[#A51C30] text-[#A51C30] dark:text-[#E57373] font-bold cursor-pointer">
                      Newsroom CMS Editor
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#FAFAFA] dark:bg-[#181818] border-b border-[#E5E0D8] dark:border-[#333] p-4 space-y-3 font-sans text-sm">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleDeptSelect('All')}
              className="text-left px-3 py-2 bg-[#EFECE6] dark:bg-[#222] font-bold text-[#A51C30] dark:text-[#E57373] rounded"
            >
              All Sections
            </button>
            {MOCK_DEPARTMENTS.slice(0, 8).map(d => (
              <button
                key={d}
                onClick={() => handleDeptSelect(d as Department)}
                className="text-left px-3 py-2 text-[#333] dark:text-[#DDD] hover:bg-[#EFECE6] dark:hover:bg-[#222] rounded"
              >
                {d}
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-[#E0DACF] dark:border-[#333] flex flex-col gap-2">
            <button
              onClick={() => { setIsSearchModalOpen(true); setIsMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-[#A51C30] dark:text-[#E57373] font-semibold"
            >
              <Search className="w-4 h-4" /> AI Semantic Search & Assistant
            </button>
            <button
              onClick={() => { setIsCMSModalOpen(true); setIsMobileMenuOpen(false); }}
              className="flex items-center gap-2 text-[#333] dark:text-[#DDD]"
            >
              <PenTool className="w-4 h-4" /> Editorial CMS Newsroom
            </button>
          </div>
        </div>
      )}

    </header>
  );
};
