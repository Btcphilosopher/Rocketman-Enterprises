import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Department, CMSArticleDraft } from '../types';
import { MOCK_DEPARTMENTS } from '../data/mockArticles';
import { PenTool, X, Plus, Check, Eye, BarChart2, Users, Send, FileText } from 'lucide-react';

export const NewsroomCMSModal: React.FC = () => {
  const { isCMSModalOpen, setIsCMSModalOpen, addCMSArticle, articles } = useApp();

  const [activeTab, setActiveTab] = useState<'editor' | 'pipeline' | 'analytics'>('editor');

  // New Draft State
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [department, setDepartment] = useState<Department>('Medicine');
  const [categoryTag, setCategoryTag] = useState('TOP STORY');
  const [authorName, setAuthorName] = useState('Dr. Olivia Chen');
  const [content, setContent] = useState('');
  const [featuredImage, setFeaturedImage] = useState('https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&q=80&w=1200');
  const [status, setStatus] = useState<'Draft' | 'Editorial Review' | 'Fact Checking' | 'Published'>('Published');

  // Drafts pipeline
  const [drafts, setDrafts] = useState<CMSArticleDraft[]>([
    {
      id: 'd-1',
      title: 'Quantum Entanglement Protocols Demonstrated Across Charles River',
      subtitle: 'Harvard SEAS researchers achieve 99.8% fidelity quantum state transfer.',
      department: 'Science & Tech',
      categoryTag: 'RESEARCH',
      authorName: 'Julian Sterling',
      status: 'Editorial Review',
      content: 'A breakthrough experiment conducted between Harvard Allston campus and Cambridge laboratories...',
      featuredImage: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=1200',
      lastEdited: '10 mins ago'
    },
    {
      id: 'd-2',
      title: 'Decarbonizing Historic Brick Architecture: Allston Geothermal Study',
      subtitle: 'Engineering analysis on retrofitting 300-year-old structures.',
      department: 'Climate',
      categoryTag: 'UNIVERSITY',
      authorName: 'Elena Rostova',
      status: 'Fact Checking',
      content: 'The Salata Institute releases interim feasibility findings on deep vertical geothermal wells...',
      featuredImage: 'https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?auto=format&fit=crop&q=80&w=1200',
      lastEdited: '1 hour ago'
    }
  ]);

  const [publishedSuccess, setPublishedSuccess] = useState(false);

  if (!isCMSModalOpen) return null;

  const handlePublish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    const draft: CMSArticleDraft = {
      id: `d-${Date.now()}`,
      title,
      subtitle,
      department,
      categoryTag,
      authorName,
      status,
      content,
      featuredImage,
      lastEdited: 'Just now'
    };

    addCMSArticle(draft);
    setPublishedSuccess(true);
    setTimeout(() => {
      setPublishedSuccess(false);
      setIsCMSModalOpen(false);
    }, 1800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#FAFAFA] dark:bg-[#121212] text-[#1A1A1A] dark:text-[#E8E8E8] max-w-4xl w-full my-auto rounded-xs shadow-2xl border border-[#E0DACF] dark:border-[#2A2A2A] relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* CMS Header Bar */}
        <div className="p-4 bg-[#A51C30] text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <PenTool className="w-5 h-5" />
            <div>
              <h3 className="font-serif text-lg font-bold">The Harvard Chronicle — Editorial CMS</h3>
              <p className="text-[11px] font-sans opacity-90">Newsroom Desk & Publication Workflow Engine</p>
            </div>
          </div>
          <button 
            onClick={() => setIsCMSModalOpen(false)}
            className="p-1 hover:bg-white/20 rounded cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="bg-[#EFECE6] dark:bg-[#1A1A1A] px-6 py-2 border-b border-[#E0DACF] dark:border-[#2A2A2A] flex items-center space-x-4 text-xs font-sans font-bold uppercase tracking-wider">
          <button
            onClick={() => setActiveTab('editor')}
            className={`py-1 cursor-pointer border-b-2 ${activeTab === 'editor' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            Article Desk Editor
          </button>
          <button
            onClick={() => setActiveTab('pipeline')}
            className={`py-1 cursor-pointer border-b-2 ${activeTab === 'pipeline' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            Editorial Pipeline ({drafts.length})
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-1 cursor-pointer border-b-2 ${activeTab === 'analytics' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            Newsroom Readership Analytics
          </button>
        </div>

        {/* TAB 1: Editor */}
        {activeTab === 'editor' && (
          <form onSubmit={handlePublish} className="p-6 overflow-y-auto space-y-4 flex-1">
            {publishedSuccess && (
              <div className="p-4 bg-green-800 text-white text-xs font-sans font-bold rounded flex items-center gap-2">
                <Check className="w-4 h-4" /> Story successfully published to live front page!
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-sans">
              <div>
                <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1">Article Headline Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Harvard Laboratory Discovers Quantum Phase Shift..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 text-sm font-serif rounded-xs"
                />
              </div>

              <div>
                <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1">Subtitle / Subhead Excerpt</label>
                <input
                  type="text"
                  placeholder="A short descriptive secondary lead..."
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 text-sm font-serif rounded-xs"
                />
              </div>

              <div>
                <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1">Department</label>
                <select
                  value={department}
                  onChange={(e: any) => setDepartment(e.target.value)}
                  className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 rounded-xs text-[#333] dark:text-[#EEE]"
                >
                  {MOCK_DEPARTMENTS.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1">Category Tag</label>
                <input
                  type="text"
                  placeholder="e.g. TOP STORY, INVESTIGATION, FEATURE"
                  value={categoryTag}
                  onChange={(e) => setCategoryTag(e.target.value)}
                  className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 rounded-xs"
                />
              </div>

              <div>
                <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1">Author Name & Affiliation</label>
                <input
                  type="text"
                  value={authorName}
                  onChange={(e) => setAuthorName(e.target.value)}
                  className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 rounded-xs"
                />
              </div>

              <div>
                <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1">Workflow Status</label>
                <select
                  value={status}
                  onChange={(e: any) => setStatus(e.target.value)}
                  className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 rounded-xs text-[#333] dark:text-[#EEE]"
                >
                  <option value="Draft">Draft</option>
                  <option value="Editorial Review">Editorial Review</option>
                  <option value="Fact Checking">Fact Checking</option>
                  <option value="Published">Immediate Publication</option>
                </select>
              </div>
            </div>

            <div>
              <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1 text-xs font-sans">Featured Lead Image URL</label>
              <input
                type="text"
                value={featuredImage}
                onChange={(e) => setFeaturedImage(e.target.value)}
                className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-2 text-xs font-sans rounded-xs"
              />
            </div>

            <div>
              <label className="font-bold text-[#333] dark:text-[#CCC] block mb-1 text-xs font-sans">Article Paragraphs Content (Separate paragraphs with blank lines) *</label>
              <textarea
                rows={8}
                required
                placeholder="Write or paste full article content..."
                value={content}
                onChange={(e) => setContent(e.target.value)}
                className="w-full bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-3 text-sm font-serif rounded-xs"
              />
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="submit"
                className="px-6 py-2.5 bg-[#A51C30] hover:bg-[#8A1627] text-white text-xs font-sans font-bold uppercase tracking-wider rounded-xs cursor-pointer flex items-center gap-2"
              >
                <Send className="w-4 h-4" /> Publish to Chronicle Edition
              </button>
            </div>
          </form>
        )}

        {/* TAB 2: Pipeline */}
        {activeTab === 'pipeline' && (
          <div className="p-6 overflow-y-auto space-y-4 flex-1">
            <h4 className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#EEE]">Active Newsroom Draft Pipeline</h4>
            <div className="space-y-3">
              {drafts.map((d) => (
                <div key={d.id} className="p-4 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs flex items-center justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-sans font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded uppercase">
                      {d.status}
                    </span>
                    <h5 className="font-serif text-sm font-bold">{d.title}</h5>
                    <p className="text-xs text-[#666]">{d.subtitle}</p>
                    <span className="text-[11px] text-[#888]">Edited {d.lastEdited} by {d.authorName}</span>
                  </div>

                  <button 
                    onClick={() => {
                      setTitle(d.title);
                      setSubtitle(d.subtitle);
                      setContent(d.content);
                      setActiveTab('editor');
                    }}
                    className="px-3 py-1 bg-[#1A1A1A] text-white text-xs font-sans font-semibold rounded cursor-pointer"
                  >
                    Open in Editor
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 3: Analytics */}
        {activeTab === 'analytics' && (
          <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs font-sans">
            <h4 className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#EEE]">Live Newsroom Readership Metrics</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-1">
                <span className="text-[#777] font-bold uppercase">Total Digital Readers</span>
                <div className="text-2xl font-serif font-black text-[#A51C30]">184,920</div>
                <span className="text-green-600 font-semibold">+18% this edition</span>
              </div>

              <div className="p-4 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-1">
                <span className="text-[#777] font-bold uppercase">Avg. Read Completion</span>
                <div className="text-2xl font-serif font-black text-[#1A1A1A] dark:text-[#EEE]">7.4 mins</div>
                <span className="text-[#666]">Top 5% Ivy readership velocity</span>
              </div>

              <div className="p-4 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-1">
                <span className="text-[#777] font-bold uppercase">Newsletter Subscribers</span>
                <div className="text-2xl font-serif font-black text-[#1A1A1A] dark:text-[#EEE]">42,100</div>
                <span className="text-[#666]">94.2% open rate</span>
              </div>
            </div>

            <div className="p-4 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-2">
              <span className="font-bold text-[#1A1A1A] dark:text-[#EEE] uppercase">Top Read Stories This Edition</span>
              <div className="divide-y divide-[#EFECE6] dark:divide-[#222]">
                {articles.slice(0, 4).map(a => (
                  <div key={a.id} className="py-2 flex items-center justify-between font-serif text-xs">
                    <span className="font-bold truncate max-w-md">{a.title}</span>
                    <span className="text-[#A51C30] font-bold font-sans">{a.viewCount.toLocaleString()} views</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
