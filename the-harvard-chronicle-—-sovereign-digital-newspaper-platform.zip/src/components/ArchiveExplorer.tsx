import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MOCK_ARCHIVE_ENTRIES } from '../data/podcastsAndVideos';
import { Archive, X, Calendar, BookOpen, Clock, ArrowRight } from 'lucide-react';

export const ArchiveExplorer: React.FC = () => {
  const { isArchiveModalOpen, setIsArchiveModalOpen } = useApp();
  const [selectedYear, setSelectedYear] = useState<number>(1873);

  if (!isArchiveModalOpen) return null;

  const currentEntry = MOCK_ARCHIVE_ENTRIES.find(e => e.year === selectedYear) || MOCK_ARCHIVE_ENTRIES[0];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#FAFAFA] dark:bg-[#121212] text-[#1A1A1A] dark:text-[#E8E8E8] max-w-4xl w-full my-auto rounded-xs shadow-2xl border border-[#E0DACF] dark:border-[#2A2A2A] relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 bg-[#1A1A1A] text-white flex items-center justify-between border-b border-[#A51C30]">
          <div className="flex items-center space-x-3">
            <Archive className="w-5 h-5 text-[#A51C30]" />
            <div>
              <h3 className="font-serif text-lg font-bold">Historical Archive Explorer (1873 – 2026)</h3>
              <p className="text-[11px] font-sans text-neutral-400">153 Years of Sovereign Collegiate Journalism</p>
            </div>
          </div>
          <button 
            onClick={() => setIsArchiveModalOpen(false)}
            className="p-1 hover:bg-white/20 rounded cursor-pointer"
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>

        {/* Timeline Slider / Year Picker */}
        <div className="p-6 bg-[#EFECE6] dark:bg-[#1A1A1A] border-b border-[#E0DACF] dark:border-[#2A2A2A] space-y-4">
          <div className="flex items-center justify-between text-xs font-sans font-bold uppercase text-[#A51C30]">
            <span>Select Milestone Era:</span>
            <span className="text-lg font-serif text-[#1A1A1A] dark:text-[#EEE]">Year {selectedYear}</span>
          </div>

          <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
            {MOCK_ARCHIVE_ENTRIES.map((entry) => (
              <button
                key={entry.year}
                onClick={() => setSelectedYear(entry.year)}
                className={`px-4 py-2 text-xs font-sans font-bold rounded cursor-pointer transition-all ${
                  selectedYear === entry.year
                    ? 'bg-[#A51C30] text-white shadow-md scale-105'
                    : 'bg-white dark:bg-[#222] text-[#333] dark:text-[#CCC] hover:bg-[#D8D2C5]'
                }`}
              >
                {entry.year}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Archive Detail */}
        <div className="p-6 md:p-8 overflow-y-auto space-y-6 flex-1">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            
            <div className="md:col-span-5 space-y-2">
              <img 
                src={currentEntry.headlineImage} 
                alt={currentEntry.title}
                className="w-full h-56 object-cover rounded-xs border border-[#E0DACF] dark:border-[#333] shadow-xs" 
              />
              <span className="text-[10px] font-sans font-bold uppercase text-[#A51C30] tracking-widest">
                ARCHIVAL RECORDS • {currentEntry.dateStr}
              </span>
            </div>

            <div className="md:col-span-7 space-y-3 font-serif">
              <h4 className="text-2xl font-black text-[#1A1A1A] dark:text-[#F5F5F3] leading-tight">
                {currentEntry.title}
              </h4>

              <p className="text-sm text-[#333] dark:text-[#DDD] leading-relaxed">
                {currentEntry.snippet}
              </p>

              <div className="p-4 bg-[#F4F1EA] dark:bg-[#222] border-l-4 border-[#A51C30] space-y-1 text-xs">
                <div className="font-sans font-bold uppercase text-[#A51C30]">Historical Context:</div>
                <p className="text-[#555] dark:text-[#AAA] leading-relaxed">{currentEntry.historicalContext}</p>
              </div>
            </div>

          </div>
        </div>

      </div>
    </div>
  );
};
