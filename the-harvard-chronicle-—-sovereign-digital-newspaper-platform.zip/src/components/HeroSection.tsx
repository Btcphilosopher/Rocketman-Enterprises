import React from 'react';
import { useApp } from '../context/AppContext';
import { Article } from '../types';
import { Bookmark, Clock, ArrowRight, Sparkles, Volume2, Share2, Flame } from 'lucide-react';

export const HeroSection: React.FC = () => {
  const { articles, setSelectedArticle, savedArticleIds, toggleSaveArticle, setAudioNarrationArticle, setIsPlayingAudio } = useApp();

  // Find hero article or fallback
  const heroArticle = articles.find(a => a.isHero) || articles[0];
  const breakingNews = articles.filter(a => a.id !== heroArticle.id).slice(0, 4);

  if (!heroArticle) return null;

  return (
    <section className="w-full bg-[#FAFAFA] dark:bg-[#121212] pt-6 pb-8 border-b border-[#E5E0D8] dark:border-[#2A2A2A] transition-colors">
      <div className="max-w-7xl mx-auto px-4">
        
        {/* Editorial Top Border Rule */}
        <div className="w-full h-0.5 bg-[#1A1A1A] dark:bg-[#E8E8E8] mb-6"></div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* 1. Left Column: Lead Story Copy (4 Cols) */}
          <div className="lg:col-span-4 space-y-4">
            
            {/* Tag Badge */}
            <div className="flex items-center space-x-2">
              <span className="text-[11px] font-sans font-bold uppercase tracking-widest text-[#A51C30] dark:text-[#E57373]">
                {heroArticle.categoryTag || 'TOP STORY'}
              </span>
              <span className="text-xs text-[#888]">•</span>
              <span className="text-[11px] font-sans text-[#777] dark:text-[#AAA] flex items-center gap-1">
                <Clock className="w-3 h-3" /> {heroArticle.readTimeMinutes} min read
              </span>
            </div>

            {/* Lead Headline */}
            <h2 
              onClick={() => setSelectedArticle(heroArticle)}
              className="font-serif text-2xl sm:text-3xl md:text-4xl font-black text-[#1A1A1A] dark:text-[#F5F5F3] leading-[1.12] hover:text-[#A51C30] dark:hover:text-[#E57373] transition-colors cursor-pointer"
            >
              {heroArticle.title}
            </h2>

            {/* Subtitle / Excerpt */}
            <p className="font-serif text-sm sm:text-base text-[#444444] dark:text-[#CCCCCC] leading-relaxed">
              {heroArticle.subtitle}
            </p>

            {/* Byline */}
            <div className="pt-2 border-t border-[#EFECE6] dark:border-[#222] flex items-center justify-between text-xs font-serif text-[#555] dark:text-[#AAA]">
              <div>
                <span className="text-[#A51C30] dark:text-[#E57373] font-semibold">By {heroArticle.author.name}</span>
                <div className="text-[11px] text-[#777] dark:text-[#888]">{heroArticle.publishedAt}</div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    setAudioNarrationArticle(heroArticle);
                    setIsPlayingAudio(true);
                  }}
                  className="p-1.5 rounded-full hover:bg-[#EFECE6] dark:hover:bg-[#222] text-[#A51C30] dark:text-[#E57373] cursor-pointer"
                  title="Listen to audio narration"
                >
                  <Volume2 className="w-4 h-4" />
                </button>

                <button
                  onClick={() => toggleSaveArticle(heroArticle.id)}
                  className={`p-1.5 rounded-full hover:bg-[#EFECE6] dark:hover:bg-[#222] transition-colors cursor-pointer ${
                    savedArticleIds.includes(heroArticle.id) ? 'text-[#A51C30] fill-current' : 'text-[#777]'
                  }`}
                  title="Bookmark story"
                >
                  <Bookmark className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Read Story Button */}
            <div className="pt-2">
              <button
                onClick={() => setSelectedArticle(heroArticle)}
                className="group flex items-center gap-2 text-xs font-sans font-bold uppercase tracking-wider text-[#1A1A1A] dark:text-[#EEE] hover:text-[#A51C30] dark:hover:text-[#E57373] cursor-pointer"
              >
                <span>Read Full Investigation</span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-[#A51C30] dark:text-[#E57373]" />
              </button>
            </div>

          </div>

          {/* 2. Center Column: Large Featured Photography (5 Cols) */}
          <div className="lg:col-span-5 space-y-2">
            <div 
              onClick={() => setSelectedArticle(heroArticle)}
              className="relative overflow-hidden rounded-xs border border-[#E0DACF] dark:border-[#2A2A2A] shadow-xs group cursor-pointer"
            >
              <img
                src={heroArticle.featuredImage}
                alt={heroArticle.title}
                className="w-full h-[320px] sm:h-[420px] object-cover group-hover:scale-[1.02] transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                <span className="text-white text-xs font-sans font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> View Photo Essay & Interactive Figures
                </span>
              </div>
            </div>

            {heroArticle.caption && (
              <p className="text-[11px] font-serif italic text-[#666] dark:text-[#999] leading-snug">
                {heroArticle.caption}
              </p>
            )}
          </div>

          {/* 3. Right Column: "Latest News" Real-Time Feed (3 Cols) */}
          <div className="lg:col-span-3 space-y-4 pl-0 lg:pl-4 border-t lg:border-t-0 lg:border-l border-[#E5E0D8] dark:border-[#2A2A2A] pt-6 lg:pt-0">
            
            <div className="flex items-center justify-between border-b-2 border-[#A51C30] pb-2">
              <h3 className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#F5F5F3]">
                Latest News
              </h3>
              <span className="flex items-center gap-1 text-[10px] font-sans font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-wider">
                <Flame className="w-3 h-3 animate-pulse" /> Live Feed
              </span>
            </div>

            {/* List of Latest Stories */}
            <div className="divide-y divide-[#EFECE6] dark:divide-[#222] space-y-4 pt-1">
              {breakingNews.map((news, idx) => (
                <div key={news.id} className="pt-3 first:pt-0 space-y-1">
                  <div className="flex items-center justify-between text-[10px] font-sans text-[#777] dark:text-[#888]">
                    <span>{idx === 0 ? '2h ago' : idx === 1 ? '4h ago' : `${(idx+1)*2}h ago`}</span>
                    <span className="uppercase text-[#A51C30] dark:text-[#E57373] font-semibold">{news.department}</span>
                  </div>

                  <h4 
                    onClick={() => setSelectedArticle(news)}
                    className="font-serif text-sm font-bold text-[#222] dark:text-[#DDD] hover:text-[#A51C30] dark:hover:text-[#E57373] transition-colors leading-snug cursor-pointer line-clamp-2"
                  >
                    {news.title}
                  </h4>

                  <div className="flex items-center justify-between text-[11px] font-sans pt-1">
                    <button
                      onClick={() => setSelectedArticle(news)}
                      className="text-[#555] dark:text-[#AAA] hover:text-[#1A1A1A] font-semibold flex items-center gap-1 cursor-pointer"
                    >
                      <span>READ MORE</span>
                      <ArrowRight className="w-3 h-3 text-[#A51C30]" />
                    </button>

                    <button
                      onClick={() => toggleSaveArticle(news.id)}
                      className="text-[#888] hover:text-[#A51C30] cursor-pointer"
                    >
                      <Bookmark className={`w-3.5 h-3.5 ${savedArticleIds.includes(news.id) ? 'fill-current text-[#A51C30]' : ''}`} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* View All Button */}
            <div className="pt-4 border-t border-[#E5E0D8] dark:border-[#2A2A2A]">
              <button 
                onClick={() => window.scrollTo({ top: 800, behavior: 'smooth' })}
                className="w-full text-center py-2 bg-[#EFECE6] dark:bg-[#222] hover:bg-[#A51C30] hover:text-white text-xs font-sans font-bold uppercase tracking-wider text-[#333] dark:text-[#CCC] transition-colors rounded-xs cursor-pointer"
              >
                VIEW ALL NEWS →
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
