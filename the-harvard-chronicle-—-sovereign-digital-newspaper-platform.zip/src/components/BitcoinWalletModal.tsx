import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Zap, 
  Wallet, 
  QrCode, 
  Copy, 
  Check, 
  ArrowUpRight, 
  History, 
  TrendingUp, 
  ShieldCheck, 
  ExternalLink,
  Coins,
  Sparkles,
  RefreshCw,
  Award
} from 'lucide-react';

export const BitcoinWalletModal: React.FC = () => {
  const { 
    isWalletModalOpen, 
    setIsWalletModalOpen, 
    walletState, 
    connectWallet, 
    disconnectWallet, 
    tipHistory, 
    btcPriceUSD, 
    totalChronicleSats,
    generateLightningInvoice,
    hasWebLN
  } = useApp();

  const [activeTab, setActiveTab] = useState<'connect' | 'deposit' | 'history' | 'stats'>('connect');
  const [copied, setCopied] = useState(false);
  const [nwcUri, setNwcUri] = useState('');
  const [depositAmountSats, setDepositAmountSats] = useState<number>(10000);
  const [activeInvoice, setActiveInvoice] = useState<{ paymentRequest: string; amountSats: number } | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectMessage, setConnectMessage] = useState<string | null>(null);

  if (!isWalletModalOpen) return null;

  const satsToUSD = (sats: number) => {
    return ((sats / 100000000) * btcPriceUSD).toFixed(2);
  };

  const handleConnect = async (type: 'WebLN' | 'Alby' | 'Xverse' | 'Unisat' | 'NWC' | 'Manual') => {
    setIsConnecting(true);
    setConnectMessage(`Connecting to ${type}...`);
    
    setTimeout(async () => {
      const success = await connectWallet(type);
      setIsConnecting(false);
      if (success) {
        setConnectMessage(`Successfully connected via ${type}!`);
        setTimeout(() => setConnectMessage(null), 3000);
      } else {
        setConnectMessage(`Failed to connect ${type}. Try Demo Wallet.`);
      }
    }, 600);
  };

  const handleGenerateInvoice = () => {
    if (!depositAmountSats || depositAmountSats <= 0) return;
    const inv = generateLightningInvoice(depositAmountSats, 'Fund Harvard Chronicle Bitcoin Wallet');
    setActiveInvoice({
      paymentRequest: inv.paymentRequest,
      amountSats: inv.amountSats
    });
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        id="bitcoin-wallet-modal"
        className="w-full max-w-2xl bg-white dark:bg-[#181818] rounded-xl shadow-2xl border border-[#E5E0D8] dark:border-[#333] overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-[#A51C30] text-white p-5 flex items-center justify-between border-b border-[#8A1627]">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-amber-400 text-black rounded-lg font-bold shadow-md">
              <Zap className="w-6 h-6 fill-current" />
            </div>
            <div>
              <h2 className="font-serif text-xl font-bold tracking-tight">
                Bitcoin & Lightning Micropayments
              </h2>
              <p className="text-xs text-amber-100 font-sans">
                Value-for-Value Journalism • Zero Transaction Fees
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsWalletModalOpen(false)}
            className="text-white/80 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Balance Summary Banner */}
        <div className="bg-[#FAF8F5] dark:bg-[#202020] px-6 py-4 border-b border-[#E5E0D8] dark:border-[#2D2D2D] flex items-center justify-between">
          <div>
            <div className="text-[11px] font-sans font-semibold uppercase tracking-wider text-[#777] dark:text-[#AAA]">
              {walletState.isConnected ? `Connected Wallet (${walletState.walletType})` : 'Reader Lightning Balance'}
            </div>
            <div className="flex items-baseline space-x-2 mt-0.5">
              <span className="font-serif text-2xl font-black text-[#1A1A1A] dark:text-white flex items-center gap-1">
                <Zap className="w-5 h-5 text-amber-500 fill-amber-500 inline" />
                {walletState.balanceSats.toLocaleString()}
                <span className="text-sm font-sans font-medium text-[#777] dark:text-[#AAA]">sats</span>
              </span>
              <span className="text-xs font-sans text-emerald-600 dark:text-emerald-400 font-semibold">
                ≈ ${satsToUSD(walletState.balanceSats)} USD
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {walletState.isConnected ? (
              <button
                onClick={disconnectWallet}
                className="px-3 py-1.5 text-xs font-sans font-medium text-rose-700 dark:text-rose-400 border border-rose-300 dark:border-rose-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-md transition-colors cursor-pointer"
              >
                Disconnect
              </button>
            ) : (
              <button
                onClick={() => handleConnect('Alby')}
                className="px-3.5 py-1.5 text-xs font-sans font-semibold bg-amber-500 hover:bg-amber-600 text-black rounded-md shadow-xs transition-colors cursor-pointer flex items-center gap-1.5"
              >
                <Zap className="w-3.5 h-3.5 fill-black" />
                <span>Quick Connect</span>
              </button>
            )}
          </div>
        </div>

        {/* Modal Navigation Tabs */}
        <div className="flex border-b border-[#E5E0D8] dark:border-[#2D2D2D] bg-[#F5F3EF] dark:bg-[#1E1E1E] text-xs font-sans font-semibold">
          <button
            onClick={() => setActiveTab('connect')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'connect'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Wallets</span>
          </button>

          <button
            onClick={() => setActiveTab('deposit')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'deposit'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <QrCode className="w-4 h-4" />
            <span>Deposit Sats</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'history'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <History className="w-4 h-4" />
            <span>Tips Ledger ({tipHistory.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('stats')}
            className={`flex-1 py-3 text-center border-b-2 transition-colors cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'stats'
                ? 'border-[#A51C30] text-[#A51C30] dark:text-amber-400 bg-white dark:bg-[#181818]'
                : 'border-transparent text-[#666] dark:text-[#AAA] hover:text-[#A51C30]'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Newsroom Metrics</span>
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto flex-1 font-sans space-y-5">
          {connectMessage && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs rounded-lg flex items-center justify-between">
              <span>{connectMessage}</span>
              {isConnecting && <RefreshCw className="w-4 h-4 animate-spin text-amber-600" />}
            </div>
          )}

          {/* TAB 1: CONNECT WALLETS */}
          {activeTab === 'connect' && (
            <div className="space-y-4">
              <div className="text-xs text-[#555] dark:text-[#AAA] leading-relaxed">
                Connect your browser WebLN wallet (Alby, Mutiny, Zeus) or Nostr Wallet Connect (NWC) to enable 
                1-click micropayments to Harvard Chronicle student journalists and authors.
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* WebLN Auto Detect */}
                <button
                  onClick={() => handleConnect('WebLN')}
                  className="p-4 rounded-xl border border-[#E0DACF] dark:border-[#333] hover:border-amber-500 dark:hover:border-amber-500 bg-[#FAF9F6] dark:bg-[#202020] text-left transition-all hover:shadow-md cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm text-[#1A1A1A] dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
                      WebLN Extension
                    </span>
                    {hasWebLN && <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100 dark:bg-emerald-950 px-2 py-0.5 rounded">Detected</span>}
                  </div>
                  <p className="text-xs text-[#666] dark:text-[#AAA]">
                    Seamless 1-click payment with in-browser extensions like Alby, Mutiny, or Strike.
                  </p>
                </button>

                {/* Alby Hub */}
                <button
                  onClick={() => handleConnect('Alby')}
                  className="p-4 rounded-xl border border-[#E0DACF] dark:border-[#333] hover:border-amber-500 dark:hover:border-amber-500 bg-[#FAF9F6] dark:bg-[#202020] text-left transition-all hover:shadow-md cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm text-[#1A1A1A] dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 flex items-center gap-1.5">
                      <Coins className="w-4 h-4 text-amber-500" />
                      Alby Account / Hub
                    </span>
                    <span className="text-[10px] font-semibold text-[#888]">LNURL / NWC</span>
                  </div>
                  <p className="text-xs text-[#666] dark:text-[#AAA]">
                    Connect using Alby lightning address or Nostr Wallet Connect secret key.
                  </p>
                </button>

                {/* Bitcoin On-Chain / Ordinals Wallet */}
                <button
                  onClick={() => handleConnect('Xverse')}
                  className="p-4 rounded-xl border border-[#E0DACF] dark:border-[#333] hover:border-amber-500 dark:hover:border-amber-500 bg-[#FAF9F6] dark:bg-[#202020] text-left transition-all hover:shadow-md cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm text-[#1A1A1A] dark:text-white group-hover:text-amber-600 dark:group-hover:text-amber-400 flex items-center gap-1.5">
                      <Wallet className="w-4 h-4 text-orange-500" />
                      Xverse / UniSat Wallet
                    </span>
                    <span className="text-[10px] font-semibold text-[#888]">Bitcoin L1</span>
                  </div>
                  <p className="text-xs text-[#666] dark:text-[#AAA]">
                    Connect Bitcoin Layer 1 wallet for larger tip transactions or inscriptions.
                  </p>
                </button>

                {/* Built-in Reader Demo Wallet */}
                <button
                  onClick={() => handleConnect('Manual')}
                  className="p-4 rounded-xl border-2 border-dashed border-amber-400/80 bg-amber-50/50 dark:bg-amber-950/20 text-left transition-all hover:shadow-md cursor-pointer group"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm text-amber-900 dark:text-amber-300 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      Instant Demo Wallet
                    </span>
                    <span className="text-[10px] font-bold text-amber-700 bg-amber-200 dark:bg-amber-900 px-2 py-0.5 rounded">Pre-Funded</span>
                  </div>
                  <p className="text-xs text-amber-800 dark:text-amber-400">
                    Instantly load a simulated 50,000 sat wallet to test micropayments and paywalls right away.
                  </p>
                </button>
              </div>

              {/* Nostr Wallet Connect (NWC) Input */}
              <div className="pt-3 border-t border-[#E5E0D8] dark:border-[#2D2D2D] space-y-2">
                <label className="block text-xs font-semibold text-[#444] dark:text-[#CCC]">
                  Nostr Wallet Connect (NWC) Connection String
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={nwcUri}
                    onChange={(e) => setNwcUri(e.target.value)}
                    placeholder="nostr+walletconnect://..."
                    className="flex-1 px-3 py-2 bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] rounded-lg text-xs font-mono focus:outline-none focus:border-[#A51C30]"
                  />
                  <button
                    onClick={() => handleConnect('NWC')}
                    disabled={!nwcUri}
                    className="px-4 py-2 bg-[#A51C30] hover:bg-[#8A1627] disabled:opacity-50 text-white rounded-lg text-xs font-bold cursor-pointer transition-colors"
                  >
                    Pair NWC
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: DEPOSIT SATS */}
          {activeTab === 'deposit' && (
            <div className="space-y-4">
              <div className="text-xs text-[#555] dark:text-[#AAA]">
                Generate a Bolt11 Lightning invoice to top up your reader wallet from any mobile Bitcoin Lightning wallet (CashApp, Strike, Phoenix, Wallet of Satoshi, Zeus).
              </div>

              <div className="bg-[#FAF9F6] dark:bg-[#202020] p-4 rounded-xl border border-[#E0DACF] dark:border-[#333] space-y-3">
                <label className="block text-xs font-bold text-[#333] dark:text-[#EEE]">
                  Amount in Satoshis (sats)
                </label>
                <div className="flex gap-2">
                  {[1000, 5000, 10000, 25000, 100000].map(sats => (
                    <button
                      key={sats}
                      onClick={() => setDepositAmountSats(sats)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        depositAmountSats === sats
                          ? 'bg-[#A51C30] text-white shadow-xs'
                          : 'bg-white dark:bg-[#2A2A2A] text-[#444] dark:text-[#CCC] border border-[#E0DACF] dark:border-[#333]'
                      }`}
                    >
                      {sats.toLocaleString()} sats
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="number"
                    value={depositAmountSats}
                    onChange={(e) => setDepositAmountSats(Number(e.target.value))}
                    className="w-full px-3.5 py-2 bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] rounded-lg text-sm font-bold text-[#1A1A1A] dark:text-white"
                  />
                  <span className="text-xs text-[#666] font-semibold whitespace-nowrap">
                    ≈ ${satsToUSD(depositAmountSats)} USD
                  </span>
                </div>

                <button
                  onClick={handleGenerateInvoice}
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-black font-bold text-xs rounded-lg transition-colors cursor-pointer flex items-center justify-center gap-1.5 shadow-xs"
                >
                  <QrCode className="w-4 h-4" />
                  <span>Generate Lightning Invoice</span>
                </button>
              </div>

              {activeInvoice && (
                <div className="bg-white dark:bg-[#1A1A1A] p-5 rounded-xl border-2 border-amber-400 text-center space-y-4 animate-fadeIn">
                  <div className="flex justify-center">
                    {/* Simulated visual QR Code */}
                    <div className="p-4 bg-white rounded-lg border border-[#DDD] shadow-sm">
                      <div className="w-40 h-40 bg-slate-950 p-2 rounded flex flex-col items-center justify-center text-amber-400 font-mono text-[10px] space-y-1">
                        <QrCode className="w-16 h-16 text-amber-400" />
                        <span className="text-white font-bold text-xs">{activeInvoice.amountSats.toLocaleString()} SATS</span>
                        <span className="text-[9px] text-slate-400 truncate w-32">lnbc{activeInvoice.amountSats}...</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="text-xs font-bold text-[#333] dark:text-[#EEE]">
                      Lightning Invoice Ready
                    </div>
                    <div className="text-[11px] text-[#777] font-mono break-all max-w-md mx-auto line-clamp-2">
                      {activeInvoice.paymentRequest}
                    </div>
                  </div>

                  <div className="flex gap-2 justify-center">
                    <button
                      onClick={() => copyToClipboard(activeInvoice.paymentRequest)}
                      className="px-4 py-2 bg-[#EFECE6] dark:bg-[#2A2A2A] hover:bg-amber-100 text-[#333] dark:text-[#EEE] text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                      <span>{copied ? 'Copied Invoice!' : 'Copy Bolt11 String'}</span>
                    </button>
                    <button
                      onClick={() => {
                        handleConnect('Manual');
                        setActiveInvoice(null);
                      }}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      <Check className="w-4 h-4" />
                      <span>Simulate Invoice Payment</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TRANSACTION TIPS HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              <div className="text-xs text-[#555] dark:text-[#AAA]">
                Your personal micro-funding record for student journalism and investigative reporting at Harvard.
              </div>

              {tipHistory.length === 0 ? (
                <div className="text-center py-8 text-[#888] text-xs">
                  No tips recorded yet. Open any article and click "⚡ Tip Author" to send satoshis directly!
                </div>
              ) : (
                <div className="space-y-2">
                  {tipHistory.map((tx) => (
                    <div 
                      key={tx.id}
                      className="p-3.5 bg-[#FAF9F6] dark:bg-[#202020] rounded-xl border border-[#E0DACF] dark:border-[#333] flex items-center justify-between"
                    >
                      <div className="space-y-1 pr-4">
                        <div className="text-xs font-bold text-[#1A1A1A] dark:text-white line-clamp-1">
                          {tx.articleTitle}
                        </div>
                        <div className="flex items-center space-x-2 text-[11px] text-[#666] dark:text-[#AAA]">
                          <span>Author: <strong className="text-[#333] dark:text-[#DDD]">{tx.authorName}</strong></span>
                          <span>•</span>
                          <span>{tx.timestamp}</span>
                        </div>
                        {tx.note && (
                          <p className="text-[11px] italic text-[#777] dark:text-[#999] bg-white dark:bg-[#181818] px-2 py-0.5 rounded border border-[#E5E0D8] dark:border-[#333] inline-block">
                            "{tx.note}"
                          </p>
                        )}
                      </div>

                      <div className="text-right whitespace-nowrap">
                        <div className="text-sm font-extrabold text-amber-600 dark:text-amber-400 flex items-center justify-end gap-1">
                          <Zap className="w-4 h-4 fill-amber-500 text-amber-500" />
                          +{tx.amountSats.toLocaleString()} sats
                        </div>
                        <div className="text-[10px] text-emerald-600 font-semibold">
                          ≈ ${satsToUSD(tx.amountSats)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 4: NEWSROOM METRICS */}
          {activeTab === 'stats' && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl">
                  <div className="text-[11px] font-bold text-amber-800 dark:text-amber-300 uppercase tracking-wider">
                    Total Newsroom Satoshis
                  </div>
                  <div className="text-2xl font-black text-amber-900 dark:text-amber-100 mt-1 flex items-center gap-1">
                    <Zap className="w-5 h-5 fill-amber-500 text-amber-500" />
                    {totalChronicleSats.toLocaleString()}
                  </div>
                  <div className="text-xs text-amber-700 dark:text-amber-400 mt-1">
                    ≈ ${satsToUSD(totalChronicleSats)} USD Raised
                  </div>
                </div>

                <div className="p-4 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
                  <div className="text-[11px] font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                    Bitcoin Market Index
                  </div>
                  <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
                    ${btcPriceUSD.toLocaleString()}
                  </div>
                  <div className="text-xs text-emerald-600 font-semibold mt-1">
                    1 Sat = ${ (btcPriceUSD / 100000000).toFixed(6) }
                  </div>
                </div>
              </div>

              <div className="bg-[#FAF9F6] dark:bg-[#202020] p-4 rounded-xl border border-[#E0DACF] dark:border-[#333] space-y-3">
                <h3 className="font-serif font-bold text-sm text-[#1A1A1A] dark:text-white flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-500" />
                  Harvard Chronicle Lightning Value-Split Architecture
                </h3>
                <p className="text-xs text-[#555] dark:text-[#AAA] leading-relaxed">
                  Every satoshi tipped on The Harvard Chronicle is cryptographically routed in real-time: 
                  <strong> 85% directly to the student author's Lightning address</strong>, <strong>10% to the investigative reporting grant fund</strong>, and <strong>5% to platform server node upkeep</strong>.
                </p>
                <div className="h-2 bg-[#E0DACF] dark:bg-[#333] rounded-full overflow-hidden flex">
                  <div className="w-[85%] bg-amber-500 h-full" title="85% Author Direct" />
                  <div className="w-[10%] bg-crimson-700 bg-[#A51C30] h-full" title="10% Newsroom Fund" />
                  <div className="w-[5%] bg-emerald-500 h-full" title="5% Node Infrastructure" />
                </div>
                <div className="flex justify-between text-[10px] text-[#777] font-semibold">
                  <span>85% Author Direct</span>
                  <span>10% Student Grant</span>
                  <span>5% Node Ops</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 bg-[#F5F3EF] dark:bg-[#1A1A1A] border-t border-[#E5E0D8] dark:border-[#2A2A2A] text-center text-[11px] text-[#666] dark:text-[#AAA] flex items-center justify-between font-sans">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Non-custodial Lightning Protocol • WebLN Standard</span>
          </div>
          <a
            href="https://lightning.network"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:underline text-[#A51C30] dark:text-amber-400 flex items-center gap-1 font-semibold"
          >
            <span>Learn about Bitcoin Lightning</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
