import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, 
  Zap, 
  CheckCircle2, 
  Copy, 
  Check, 
  Sparkles, 
  QrCode, 
  Heart,
  MessageSquare
} from 'lucide-react';

export const LightningTipModal: React.FC = () => {
  const { 
    isTipModalOpen, 
    setIsTipModalOpen, 
    tipTargetArticle, 
    tipSatsToArticle, 
    walletState, 
    btcPriceUSD,
    generateLightningInvoice
  } = useApp();

  const [selectedSats, setSelectedSats] = useState<number>(210);
  const [customSats, setCustomSats] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [copiedInvoice, setCopiedInvoice] = useState(false);
  const [copiedAddress, setCopiedAddress] = useState(false);
  const [activeTab, setActiveTab] = useState<'instant' | 'qrcode'>('instant');

  if (!isTipModalOpen || !tipTargetArticle) return null;

  const currentSats = customSats ? parseInt(customSats) || 0 : selectedSats;
  const satsUSD = ((currentSats / 100000000) * btcPriceUSD).toFixed(2);
  const lightningAddress = tipTargetArticle.author.lightningAddress || `${tipTargetArticle.author.name.toLowerCase().replace(/\s+/g, '')}@getalby.com`;

  const handlePayTip = async () => {
    if (currentSats <= 0) return;
    setIsProcessing(true);

    setTimeout(async () => {
      const success = await tipSatsToArticle(tipTargetArticle.id, currentSats, note);
      setIsProcessing(false);
      if (success) {
        setIsSuccess(true);
      }
    }, 800);
  };

  const handleClose = () => {
    setIsTipModalOpen(false);
    setIsSuccess(false);
    setNote('');
    setCustomSats('');
  };

  const dummyInvoice = generateLightningInvoice(currentSats, `Tip to ${tipTargetArticle.author.name} for "${tipTargetArticle.title}"`);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fadeIn">
      <div 
        id="lightning-tip-modal"
        className="w-full max-w-lg bg-white dark:bg-[#181818] rounded-2xl shadow-2xl border border-[#E5E0D8] dark:border-[#333] overflow-hidden"
      >
        {/* Header Banner */}
        <div className="bg-gradient-to-r from-[#A51C30] to-rose-900 text-white p-5 relative">
          <button
            onClick={handleClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-amber-400 shrink-0 shadow-md">
              <img 
                src={tipTargetArticle.author.avatar} 
                alt={tipTargetArticle.author.name}
                className="w-full h-full object-cover" 
              />
            </div>
            <div>
              <div className="text-[11px] font-sans font-bold uppercase tracking-wider text-amber-300 flex items-center gap-1">
                <Zap className="w-3.5 h-3.5 fill-amber-300" />
                Lightning Value-for-Value
              </div>
              <h3 className="font-serif text-lg font-bold">
                Tip {tipTargetArticle.author.name}
              </h3>
              <p className="text-xs text-white/80 line-clamp-1 font-sans">
                "{tipTargetArticle.title}"
              </p>
            </div>
          </div>
        </div>

        {isSuccess ? (
          /* SUCCESS STATE */
          <div className="p-8 text-center space-y-4 animate-scaleUp">
            <div className="w-16 h-16 bg-emerald-100 dark:bg-emerald-950/80 text-emerald-600 dark:text-emerald-400 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-1">
              <h3 className="font-serif text-2xl font-black text-[#1A1A1A] dark:text-white">
                Payment Settled!
              </h3>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400 flex items-center justify-center gap-1">
                <Zap className="w-4 h-4 fill-amber-500 text-amber-500" />
                +{currentSats.toLocaleString()} sats (${satsUSD} USD) sent
              </p>
            </div>

            <p className="text-xs text-[#555] dark:text-[#AAA] max-w-sm mx-auto leading-relaxed">
              Your satoshis were delivered directly to <strong>{tipTargetArticle.author.name}</strong>'s Lightning node via the Harvard Chronicle sovereign network.
            </p>

            <button
              onClick={handleClose}
              className="w-full py-3 bg-[#A51C30] hover:bg-[#8A1627] text-white font-bold text-sm rounded-xl transition-all cursor-pointer shadow-md"
            >
              Back to Article
            </button>
          </div>
        ) : (
          /* PAYMENT FORM */
          <div className="p-6 space-y-5 font-sans">
            
            {/* Quick Sat Presets */}
            <div className="space-y-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-[#666] dark:text-[#AAA]">
                Select Tip Amount
              </label>
              
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                {[21, 210, 1000, 5000, 21000].map((sats) => (
                  <button
                    key={sats}
                    onClick={() => {
                      setSelectedSats(sats);
                      setCustomSats('');
                    }}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold transition-all cursor-pointer border flex flex-col items-center ${
                      selectedSats === sats && !customSats
                        ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 shadow-sm'
                        : 'border-[#E0DACF] dark:border-[#333] bg-[#FAF9F6] dark:bg-[#202020] text-[#333] dark:text-[#DDD] hover:border-amber-400'
                    }`}
                  >
                    <span className="flex items-center gap-0.5 font-extrabold text-sm">
                      <Zap className="w-3 h-3 text-amber-500 fill-amber-500" />
                      {sats >= 1000 ? `${sats / 1000}k` : sats}
                    </span>
                    <span className="text-[10px] opacity-75 font-normal">
                      ${((sats / 100000000) * btcPriceUSD).toFixed(2)}
                    </span>
                  </button>
                ))}
              </div>

              {/* Custom Sats Input */}
              <div className="relative pt-1">
                <input
                  type="number"
                  placeholder="Or enter custom sat amount..."
                  value={customSats}
                  onChange={(e) => setCustomSats(e.target.value)}
                  className="w-full px-4 py-2 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] rounded-xl text-xs font-bold text-[#1A1A1A] dark:text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Note to Author */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-[#444] dark:text-[#CCC] flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5 text-amber-500" />
                Note to {tipTargetArticle.author.name} (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. Insightful analysis on Harvard's research..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full px-3.5 py-2 bg-[#FAF9F6] dark:bg-[#202020] border border-[#E0DACF] dark:border-[#333] rounded-xl text-xs text-[#1A1A1A] dark:text-white focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-3 pt-2 border-t border-[#E5E0D8] dark:border-[#2D2D2D]">
              <div className="flex rounded-lg bg-[#EFECE6] dark:bg-[#222] p-1 text-xs font-bold">
                <button
                  onClick={() => setActiveTab('instant')}
                  className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer ${
                    activeTab === 'instant' 
                      ? 'bg-white dark:bg-[#333] text-[#1A1A1A] dark:text-white shadow-xs' 
                      : 'text-[#666] dark:text-[#AAA]'
                  }`}
                >
                  1-Click WebLN Pay
                </button>
                <button
                  onClick={() => setActiveTab('qrcode')}
                  className={`flex-1 py-1.5 rounded-md transition-all cursor-pointer ${
                    activeTab === 'qrcode' 
                      ? 'bg-white dark:bg-[#333] text-[#1A1A1A] dark:text-white shadow-xs' 
                      : 'text-[#666] dark:text-[#AAA]'
                  }`}
                >
                  QR Code / LNURL
                </button>
              </div>

              {activeTab === 'instant' ? (
                <div className="space-y-3">
                  <button
                    onClick={handlePayTip}
                    disabled={isProcessing || currentSats <= 0}
                    className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-black font-extrabold text-sm rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isProcessing ? (
                      <span className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 animate-spin text-black" />
                        Settling on Lightning Network...
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Zap className="w-5 h-5 fill-black text-black" />
                        Send {currentSats.toLocaleString()} Sats (${satsUSD} USD)
                      </span>
                    )}
                  </button>

                  {walletState.isConnected && (
                    <div className="text-[11px] text-center text-[#666] dark:text-[#AAA]">
                      Paying from <strong>{walletState.nodeAlias || walletState.walletType}</strong> (Balance: {walletState.balanceSats.toLocaleString()} sats)
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-4 bg-[#FAF9F6] dark:bg-[#202020] rounded-xl border border-[#E0DACF] dark:border-[#333] text-center space-y-3">
                  <div className="text-xs font-bold text-[#333] dark:text-[#EEE]">
                    Author Lightning Address
                  </div>
                  
                  <div className="flex items-center justify-between p-2.5 bg-white dark:bg-[#181818] border border-[#E0DACF] dark:border-[#333] rounded-lg text-xs font-mono">
                    <span className="truncate text-amber-600 dark:text-amber-400 font-bold">{lightningAddress}</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(lightningAddress);
                        setCopiedAddress(true);
                        setTimeout(() => setCopiedAddress(false), 2000);
                      }}
                      className="ml-2 text-[#666] hover:text-[#1A1A1A] cursor-pointer"
                    >
                      {copiedAddress ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>

                  <div className="pt-2">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(dummyInvoice.paymentRequest);
                        setCopiedInvoice(true);
                        setTimeout(() => setCopiedInvoice(false), 2000);
                      }}
                      className="w-full py-2 bg-[#EFECE6] dark:bg-[#2A2A2A] hover:bg-amber-100 text-xs font-bold rounded-lg cursor-pointer flex items-center justify-center gap-1.5"
                    >
                      {copiedInvoice ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                      <span>{copiedInvoice ? 'Invoice Copied!' : 'Copy Bolt11 Invoice'}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
