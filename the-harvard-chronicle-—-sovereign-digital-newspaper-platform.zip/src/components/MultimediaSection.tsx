import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { MOCK_PODCASTS, MOCK_VIDEOS } from '../data/podcastsAndVideos';
import { Headphones, Play, Pause, FileText, Video, Sparkles, Clock } from 'lucide-react';

export const MultimediaSection: React.FC = () => {
  const { setActivePodcast, isPlayingAudio, setIsPlayingAudio, activePodcast } = useApp();
  const [selectedTranscript, setSelectedTranscript] = useState<string[] | null>(null);

  return (
    <section className="w-full bg-[#FAFAFA] dark:bg-[#121212] py-10 border-b border-[#E5E0D8] dark:border-[#2A2A2A]">
      <div className="max-w-7xl mx-auto px-4 space-y-8">
        
        {/* Section Heading */}
        <div className="flex items-center justify-between border-b-2 border-[#A51C30] pb-2">
          <div className="flex items-center space-x-3">
            <Headphones className="w-5 h-5 text-[#A51C30] dark:text-[#E57373]" />
            <h2 className="font-serif text-2xl font-black text-[#1A1A1A] dark:text-[#F5F5F3]">
              Chronicle Multimedia: Podcasts & Documentaries
            </h2>
          </div>
          <span className="text-xs font-serif text-[#777] dark:text-[#AAA]">Audio & Video Journalism</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Podcast Showcase (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#EEE] flex items-center gap-2">
              <span>The Crimson Podcast Series</span>
              <span className="text-[10px] font-sans font-bold uppercase bg-[#A51C30] text-white px-2 py-0.5 rounded-full">Weekly</span>
            </h3>

            <div className="space-y-4">
              {MOCK_PODCASTS.map((pod) => {
                const isThisPlaying = activePodcast?.id === pod.id && isPlayingAudio;

                return (
                  <div 
                    key={pod.id}
                    className="bg-white dark:bg-[#1A1A1A] p-4 border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs shadow-xs flex flex-col sm:flex-row gap-4 items-start sm:items-center"
                  >
                    <img 
                      src={pod.coverImage} 
                      alt={pod.title} 
                      className="w-24 h-24 object-cover rounded-xs border border-[#E0DACF] shrink-0" 
                    />

                    <div className="space-y-1.5 flex-1">
                      <div className="flex items-center justify-between text-[11px] font-sans text-[#777]">
                        <span className="font-bold text-[#A51C30] uppercase">{pod.showName}</span>
                        <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {pod.duration}</span>
                      </div>

                      <h4 className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#EEE] leading-snug">
                        {pod.title}
                      </h4>

                      <p className="font-serif text-xs text-[#555] dark:text-[#AAA] line-clamp-2">
                        {pod.description}
                      </p>

                      <div className="pt-2 flex items-center space-x-3 text-xs font-sans">
                        <button
                          onClick={() => {
                            setActivePodcast(pod);
                            setIsPlayingAudio(!isThisPlaying);
                          }}
                          className="px-3 py-1 bg-[#A51C30] hover:bg-[#8A1627] text-white font-semibold rounded-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          {isThisPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                          <span>{isThisPlaying ? 'Pause Episode' : 'Play Audio'}</span>
                        </button>

                        <button
                          onClick={() => setSelectedTranscript(pod.transcript)}
                          className="text-[#555] dark:text-[#AAA] hover:text-[#A51C30] font-medium flex items-center gap-1 cursor-pointer"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          <span>Transcript</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Video Documentaries Showcase (5 Cols) */}
          <div className="lg:col-span-5 space-y-4">
            <h3 className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#EEE] flex items-center gap-2">
              <Video className="w-4 h-4 text-[#A51C30]" />
              <span>Video Documentaries</span>
            </h3>

            <div className="space-y-4">
              {MOCK_VIDEOS.map((vid) => (
                <div key={vid.id} className="group bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs overflow-hidden shadow-xs space-y-2">
                  <div className="relative cursor-pointer">
                    <img src={vid.thumbnail} alt={vid.title} className="w-full h-44 object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center group-hover:bg-black/20 transition-colors">
                      <div className="w-12 h-12 rounded-full bg-[#A51C30] text-white flex items-center justify-center shadow-lg">
                        <Play className="w-5 h-5 fill-current ml-0.5" />
                      </div>
                    </div>
                    <span className="absolute bottom-2 right-2 bg-black/80 text-white text-[10px] font-sans px-2 py-0.5 rounded">
                      {vid.duration}
                    </span>
                  </div>

                  <div className="p-3 space-y-1">
                    <span className="text-[10px] font-sans font-bold text-[#A51C30] dark:text-[#E57373] uppercase tracking-wider">
                      {vid.category}
                    </span>
                    <h4 className="font-serif text-sm font-bold text-[#1A1A1A] dark:text-[#EEE]">
                      {vid.title}
                    </h4>
                    <p className="font-serif text-xs text-[#555] dark:text-[#AAA] line-clamp-2">
                      {vid.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Podcast Transcript Modal */}
        {selectedTranscript && (
          <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
            <div className="bg-white dark:bg-[#1A1A1A] max-w-2xl w-full p-6 rounded-xs border border-[#E0DACF] dark:border-[#333] space-y-4 max-h-[80vh] overflow-y-auto">
              <div className="flex items-center justify-between border-b pb-2">
                <h3 className="font-serif text-lg font-bold text-[#1A1A1A] dark:text-[#EEE]">Episode Transcript</h3>
                <button onClick={() => setSelectedTranscript(null)} className="text-xs font-sans font-bold uppercase text-[#A51C30]">Close</button>
              </div>

              <div className="space-y-3 font-serif text-sm text-[#333] dark:text-[#DDD] leading-relaxed">
                {selectedTranscript.map((line, i) => (
                  <p key={i} className="p-2 bg-[#FAFAFA] dark:bg-[#222] rounded border-l-2 border-[#A51C30]">
                    {line}
                  </p>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
