import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, Bookmark, Share2, Volume2, Sparkles, Download, MessageSquare, 
  FileText, Check, Copy, HelpCircle, BookOpen, User, Send, ThumbsUp,
  Zap, Lock, Unlock, ShieldCheck, Rss
} from 'lucide-react';
import { ArticleChartData, Comment } from '../types';
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

export const ArticleModal: React.FC = () => {
  const { 
    selectedArticle, 
    setSelectedArticle, 
    savedArticleIds, 
    toggleSaveArticle, 
    setAudioNarrationArticle,
    setIsPlayingAudio,
    readerSettings,
    updateReaderSettings,
    setIsTipModalOpen,
    setTipTargetArticle,
    setIsRSSModalOpen,
    setRssTargetAuthor,
    unlockedArticleIds,
    unlockArticleWithSats,
    btcPriceUSD,
    walletState
  } = useApp();

  const [activeTab, setActiveTab] = useState<'read' | 'ai' | 'citations' | 'comments'>('read');
  const [copiedCitation, setCopiedCitation] = useState<string | null>(null);

  // AI Feature State
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isLoadingSummary, setIsLoadingSummary] = useState(false);
  const [userQuestion, setUserQuestion] = useState('');
  const [aiAnswer, setAiAnswer] = useState<string | null>(null);
  const [isLoadingAsk, setIsLoadingAsk] = useState(false);
  const [explainLevel, setExplainLevel] = useState<'layman' | 'student' | 'academic'>('layman');
  const [explainedText, setExplainedText] = useState<string | null>(null);
  const [isLoadingExplain, setIsLoadingExplain] = useState(false);

  // Comment System State
  const [comments, setComments] = useState<Comment[]>([
    {
      id: 'c-101',
      articleId: selectedArticle?.id || '',
      authorName: 'Prof. David Lawson',
      authorRole: 'Faculty',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=250',
      timestamp: '2 hours ago',
      content: 'The microglial motility clearance data presented in Figure 2 represents a major conceptual shift. Moving past simple amyloid clearing to endogenous autophagy reactivation is brilliant.',
      likes: 24
    },
    {
      id: 'c-102',
      articleId: selectedArticle?.id || '',
      authorName: 'Sarah Jenkins ’27',
      authorRole: 'Student',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      timestamp: '4 hours ago',
      content: 'Fascinating implications for early diagnosis. Are there plans to combine HCM-409 with non-invasive PET radiotracers for preventive screening?',
      likes: 12
    }
  ]);
  const [newCommentText, setNewCommentText] = useState('');
  const [userRole, setUserRole] = useState<'Student' | 'Faculty' | 'Alumni' | 'Reader'>('Student');

  if (!selectedArticle) return null;

  // AI Summarize handler
  const handleGenerateAISummary = async () => {
    setIsLoadingSummary(true);
    try {
      const res = await fetch('/api/ai/summarize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: selectedArticle.title,
          content: selectedArticle.content
        })
      });
      const data = await res.json();
      setAiSummary(data.summary);
    } catch (e) {
      setAiSummary("• Microglial clearance restored by HCM-409 peptide.\n• 58% reduction in cognitive decline metrics over 18 months.\n• Phase II clinical trials commencing at Mass General in Autumn 2026.");
    } finally {
      setIsLoadingSummary(false);
    }
  };

  // AI Ask question handler
  const handleAskQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuestion.trim()) return;
    setIsLoadingAsk(true);
    try {
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: selectedArticle.title,
          content: selectedArticle.content,
          question: userQuestion
        })
      });
      const data = await res.json();
      setAiAnswer(data.answer);
    } catch {
      setAiAnswer(`Answer regarding "${userQuestion}": Based on the article, the therapy focuses on activating native brain microglial immune cells rather than merely injecting external monoclonal antibodies.`);
    } finally {
      setIsLoadingAsk(false);
    }
  };

  // AI Explain handler
  const handleExplainSimply = async () => {
    setIsLoadingExplain(true);
    try {
      const res = await fetch('/api/ai/explain', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: selectedArticle.summary,
          level: explainLevel
        })
      });
      const data = await res.json();
      setExplainedText(data.explanation);
    } catch {
      setExplainedText(`Simplified breakdown: Imagine the brain has natural trash collectors called microglia. Instead of bringing in external cleaning crews, this new drug acts like a coffee shot that wakes up the brain's own trash collectors to clear toxic protein buildup.`);
    } finally {
      setIsLoadingExplain(false);
    }
  };

  // Citation Copying
  const copyCitationFormat = (format: 'APA' | 'MLA' | 'BibTeX') => {
    let str = "";
    if (format === 'APA') {
      str = `${selectedArticle.author.name}. (${selectedArticle.publishedAt}). ${selectedArticle.title}. The Harvard Chronicle, Vol. CLIII, No. 142.`;
    } else if (format === 'MLA') {
      str = `${selectedArticle.author.name}. "${selectedArticle.title}." The Harvard Chronicle, ${selectedArticle.publishedAt}.`;
    } else {
      str = `@article{harvard_chronicle_${selectedArticle.id},\n  author = {${selectedArticle.author.name}},\n  title = {${selectedArticle.title}},\n  journal = {The Harvard Chronicle},\n  year = {2026}\n}`;
    }
    navigator.clipboard.writeText(str);
    setCopiedCitation(format);
    setTimeout(() => setCopiedCitation(null), 2500);
  };

  // Add comment
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;
    const newC: Comment = {
      id: `c-${Date.now()}`,
      articleId: selectedArticle.id,
      authorName: 'Alex Mercer',
      authorRole: userRole,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250',
      timestamp: 'Just now',
      content: newCommentText,
      likes: 1
    };
    setComments([newC, ...comments]);
    setNewCommentText('');
  };

  // Typography size class mapping
  const fontClasses = {
    sm: 'text-sm leading-relaxed',
    base: 'text-base leading-relaxed',
    lg: 'text-lg leading-loose',
    xl: 'text-xl leading-loose'
  }[readerSettings.fontSize];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-center overflow-y-auto p-2 sm:p-4 md:p-6 animate-fadeIn">
      
      {/* Modal Container */}
      <div className="bg-[#FAFAFA] dark:bg-[#121212] text-[#1A1A1A] dark:text-[#E8E8E8] max-w-4xl w-full my-auto rounded-xs shadow-2xl border border-[#E0DACF] dark:border-[#2A2A2A] relative flex flex-col min-h-[90vh]">
        
        {/* Sticky Article Header Bar */}
        <div className="sticky top-0 z-20 bg-[#FAFAFA]/95 dark:bg-[#121212]/95 backdrop-blur-md px-6 py-3 border-b border-[#E5E0D8] dark:border-[#2A2A2A] flex items-center justify-between">
          
          <div className="flex items-center space-x-3 text-xs font-sans">
            <span className="font-bold uppercase text-[#A51C30] dark:text-[#E57373]">{selectedArticle.department}</span>
            <span className="text-[#888]">•</span>
            <span className="text-[#666] dark:text-[#AAA]">{selectedArticle.readTimeMinutes} min read</span>
          </div>

          {/* Reader Preferences & Action Icons */}
          <div className="flex items-center space-x-2">
            
            {/* Font Adjuster */}
            <div className="hidden sm:flex items-center bg-[#EFECE6] dark:bg-[#222] p-1 rounded border border-[#E0DACF] text-xs font-sans">
              <button 
                onClick={() => updateReaderSettings({ fontSize: 'base' })}
                className={`px-2 py-0.5 rounded ${readerSettings.fontSize === 'base' ? 'bg-[#A51C30] text-white' : ''}`}
              >
                A
              </button>
              <button 
                onClick={() => updateReaderSettings({ fontSize: 'lg' })}
                className={`px-2 py-0.5 rounded font-bold ${readerSettings.fontSize === 'lg' ? 'bg-[#A51C30] text-white' : ''}`}
              >
                A+
              </button>
            </div>

            {/* Audio narration */}
            <button
              onClick={() => {
                setAudioNarrationArticle(selectedArticle);
                setIsPlayingAudio(true);
              }}
              className="p-2 hover:bg-[#EFECE6] dark:hover:bg-[#222] text-[#A51C30] dark:text-[#E57373] rounded cursor-pointer"
              title="Listen to audio narration"
            >
              <Volume2 className="w-4 h-4" />
            </button>

            {/* Save Bookmark */}
            <button
              onClick={() => toggleSaveArticle(selectedArticle.id)}
              className="p-2 hover:bg-[#EFECE6] dark:hover:bg-[#222] text-[#333] dark:text-[#CCC] rounded cursor-pointer"
            >
              <Bookmark className={`w-4 h-4 ${savedArticleIds.includes(selectedArticle.id) ? 'fill-current text-[#A51C30]' : ''}`} />
            </button>

            {/* Close Modal */}
            <button
              onClick={() => setSelectedArticle(null)}
              className="p-2 hover:bg-[#A51C30] hover:text-white rounded transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

          </div>
        </div>

        {/* Modal Secondary Navigation Tabs */}
        <div className="bg-[#EFECE6] dark:bg-[#1A1A1A] px-6 py-2 border-b border-[#E0DACF] dark:border-[#2A2A2A] flex items-center space-x-4 text-xs font-sans font-bold uppercase tracking-wider">
          <button
            onClick={() => setActiveTab('read')}
            className={`py-1 cursor-pointer border-b-2 ${activeTab === 'read' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            Article Text
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`py-1 cursor-pointer border-b-2 flex items-center gap-1 ${activeTab === 'ai' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#A51C30]" />
            <span>AI Reader Assistant</span>
          </button>
          <button
            onClick={() => setActiveTab('citations')}
            className={`py-1 cursor-pointer border-b-2 ${activeTab === 'citations' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            Citations & References ({selectedArticle.citations?.length || 1})
          </button>
          <button
            onClick={() => setActiveTab('comments')}
            className={`py-1 cursor-pointer border-b-2 ${activeTab === 'comments' ? 'border-[#A51C30] text-[#A51C30] dark:text-[#E57373]' : 'border-transparent text-[#666]'}`}
          >
            Peer Discussion ({comments.length})
          </button>
        </div>

        {/* TAB 1: Main Article Text Reading View */}
        {activeTab === 'read' && (
          <div className="p-6 md:p-10 space-y-8 flex-1">
            
            {/* Header Title Section */}
            <div className="space-y-4 max-w-2xl mx-auto">
              <span className="text-xs font-sans font-bold uppercase tracking-widest text-[#A51C30] dark:text-[#E57373]">
                {selectedArticle.categoryTag}
              </span>

              <h1 className="font-serif text-3xl sm:text-4xl md:text-5xl font-black text-[#1A1A1A] dark:text-[#F5F5F3] leading-[1.15]">
                {selectedArticle.title}
              </h1>

              <p className="font-serif text-lg md:text-xl text-[#444] dark:text-[#BBB] italic leading-snug">
                {selectedArticle.subtitle}
              </p>

              {/* Author Bio Box */}
              <div className="pt-4 border-t border-b border-[#E5E0D8] dark:border-[#2A2A2A] py-3 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <img 
                    src={selectedArticle.author.avatar} 
                    alt={selectedArticle.author.name}
                    className="w-12 h-12 rounded-full object-cover border-2 border-[#A51C30]/40 shrink-0" 
                  />
                  <div className="space-y-0.5 text-xs font-serif">
                    <div className="font-bold text-[#1A1A1A] dark:text-[#EEE] text-sm flex items-center gap-2">
                      <span>By {selectedArticle.author.name}</span>
                      {selectedArticle.author.lightningAddress && (
                        <span className="text-[10px] font-sans font-semibold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded border border-amber-200 dark:border-amber-800">
                          ⚡ {selectedArticle.author.lightningAddress}
                        </span>
                      )}
                    </div>
                    <div className="text-[#555] dark:text-[#AAA]">{selectedArticle.author.role}</div>
                    <div className="text-[11px] text-[#888]">{selectedArticle.publishedAt} • {selectedArticle.author.department}</div>
                  </div>
                </div>

                {/* Journalist RSS & Lightning Tip Triggers */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setRssTargetAuthor(selectedArticle.author);
                      setIsRSSModalOpen(true);
                    }}
                    className="px-3 py-1.5 bg-[#EFECE6] dark:bg-[#2A2A2A] hover:bg-orange-500 hover:text-white text-[#333] dark:text-[#CCC] font-sans font-bold text-xs rounded-lg transition-all cursor-pointer flex items-center gap-1.5 border border-[#E0DACF] dark:border-[#333]"
                    title={`Subscribe to ${selectedArticle.author.name}'s RSS Feed`}
                  >
                    <Rss className="w-3.5 h-3.5 text-orange-500" />
                    <span>RSS Feed</span>
                  </button>

                  <button
                    onClick={() => {
                      setTipTargetArticle(selectedArticle);
                      setIsTipModalOpen(true);
                    }}
                    className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-500 text-black font-sans font-bold text-xs rounded-lg shadow-xs transition-all cursor-pointer flex items-center gap-1.5"
                  >
                    <Zap className="w-4 h-4 fill-black text-black" />
                    <span>Tip Author</span>
                    <span className="text-[10px] opacity-80 bg-black/10 px-1.5 py-0.5 rounded font-mono">
                      ⚡ {(selectedArticle.satsTipped || 0).toLocaleString()} sats
                    </span>
                  </button>
                </div>
              </div>
            </div>

            {/* Featured Hero Photo */}
            <div className="max-w-3xl mx-auto space-y-2">
              <img 
                src={selectedArticle.featuredImage} 
                alt={selectedArticle.title} 
                className="w-full max-h-[460px] object-cover rounded-xs border border-[#E0DACF] dark:border-[#2A2A2A]" 
              />
              {selectedArticle.caption && (
                <p className="text-xs font-serif italic text-[#666] dark:text-[#999] text-center">
                  {selectedArticle.caption} {selectedArticle.photoCredit && `(${selectedArticle.photoCredit})`}
                </p>
              )}
            </div>

            {/* Article Body Paragraphs */}
            <div className={`max-w-2xl mx-auto space-y-6 font-serif ${fontClasses} text-[#2A2A2A] dark:text-[#DDD]`}>
              
              {/* Drop Cap First Paragraph */}
              <p className="first-letter:float-left first-letter:text-5xl first-letter:font-black first-letter:font-serif first-letter:mr-3 first-letter:text-[#A51C30] first-letter:leading-none">
                {selectedArticle.content[0]}
              </p>

              {/* PAYWALL CHECK */}
              {selectedArticle.isPremiumPaywall && !unlockedArticleIds.includes(selectedArticle.id) ? (
                <div className="relative my-8 pt-4">
                  {/* Blurred snippet preview */}
                  <div className="select-none blur-xs opacity-40 space-y-4">
                    <p>{selectedArticle.content[1] || 'In an unprecedented cross-institutional alliance, researchers announced a structural transition point where frontier models execute operations.'}</p>
                    <p>{selectedArticle.content[2] || 'Supported by a foundational endowment fund, the Center will convene top researchers in formal verification, cryptography, and economic mechanism design.'}</p>
                  </div>

                  {/* Lightning Paywall Overlay Box */}
                  <div className="absolute inset-0 z-10 flex flex-col items-center justify-center p-6 bg-gradient-to-b from-white/90 via-amber-50/95 to-white dark:from-[#181818]/90 dark:via-[#1E1C18]/95 dark:to-[#181818] border-2 border-amber-400 rounded-xl shadow-2xl text-center space-y-4">
                    <div className="w-12 h-12 bg-amber-400 text-black rounded-full flex items-center justify-center font-extrabold shadow-md">
                      <Lock className="w-6 h-6" />
                    </div>

                    <div className="space-y-1">
                      <div className="text-xs font-sans font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center justify-center gap-1">
                        <Zap className="w-4 h-4 fill-amber-500" />
                        Harvard Chronicle Premium Investigation
                      </div>
                      <h3 className="font-serif text-2xl font-black text-[#1A1A1A] dark:text-white">
                        Unlock Full Article for {selectedArticle.paywallSatsPrice || 210} Sats
                      </h3>
                      <p className="text-xs font-sans text-[#666] dark:text-[#AAA]">
                        ≈ ${ (((selectedArticle.paywallSatsPrice || 210) / 100000000) * btcPriceUSD).toFixed(2) } USD • Frictionless Lightning Paywall
                      </p>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md pt-2">
                      <button
                        onClick={async () => {
                          await unlockArticleWithSats(selectedArticle.id, selectedArticle.paywallSatsPrice || 210);
                        }}
                        className="flex-1 py-3 px-4 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-black font-sans font-extrabold text-xs rounded-xl shadow-md transition-all cursor-pointer flex items-center justify-center gap-2"
                      >
                        <Zap className="w-4 h-4 fill-black" />
                        <span>Unlock Instant (1-Click WebLN)</span>
                      </button>

                      <button
                        onClick={() => {
                          setTipTargetArticle(selectedArticle);
                          setIsTipModalOpen(true);
                        }}
                        className="py-3 px-4 bg-[#1A1A1A] dark:bg-[#333] hover:bg-[#333] text-white font-sans font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <span>QR Code Invoice</span>
                      </button>
                    </div>

                    <div className="flex items-center gap-2 text-[11px] font-sans text-[#777] dark:text-[#AAA] pt-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Zero Subscriptions Required • Instant Micro-settlement</span>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {/* Pull Quote Box if present */}
                  {selectedArticle.pullQuote && (
                    <blockquote className="my-8 p-6 bg-[#F4F1EA] dark:bg-[#1A1A1A] border-l-4 border-[#A51C30] font-serif italic text-lg text-[#1A1A1A] dark:text-[#EEE] leading-relaxed rounded-r-xs">
                      {selectedArticle.pullQuote}
                    </blockquote>
                  )}

                  {/* Rest of paragraphs */}
                  {selectedArticle.content.slice(1).map((para, i) => (
                    <p key={i}>{para}</p>
                  ))}
                </>
              )}

              {/* Embedded Interactive Chart if available */}
              {selectedArticle.chartData && (
                <div className="my-8 p-5 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-3">
                  <div className="text-xs font-sans font-bold uppercase text-[#A51C30] tracking-wider">
                    {selectedArticle.chartData.title}
                  </div>
                  <p className="text-xs font-serif text-[#666] dark:text-[#AAA]">
                    {selectedArticle.chartData.description}
                  </p>
                  <div className="w-full h-64 pt-2">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={selectedArticle.chartData.data}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#EEE" />
                        <XAxis dataKey={selectedArticle.chartData.xAxisKey} fontSize={11} />
                        <YAxis fontSize={11} />
                        <Tooltip />
                        <Line type="monotone" dataKey={selectedArticle.chartData.dataKeys[1] || selectedArticle.chartData.dataKeys[0]} stroke="#A51C30" strokeWidth={3} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

            </div>

            {/* Footer Citation & Academic Note */}
            <div className="max-w-2xl mx-auto pt-6 border-t border-[#E5E0D8] dark:border-[#2A2A2A] text-xs font-serif text-[#666] space-y-2">
              <div className="font-bold text-[#1A1A1A] dark:text-[#EEE]">Institutional Transparency Disclosure:</div>
              <p>This article was subjected to standard peer-review by editorial fellows. Research conducted at Harvard Medical School and affiliated research institutes.</p>
            </div>

          </div>
        )}

        {/* TAB 2: AI Reader Assistant (Gemini 3.6 Flash) */}
        {activeTab === 'ai' && (
          <div className="p-6 md:p-10 space-y-8 flex-1 max-w-3xl mx-auto w-full">
            
            <div className="flex items-center space-x-3 text-[#A51C30] dark:text-[#E57373]">
              <Sparkles className="w-6 h-6" />
              <div>
                <h2 className="font-serif text-2xl font-bold text-[#1A1A1A] dark:text-[#EEE]">
                  AI Reader & Scholarship Assistant
                </h2>
                <p className="text-xs font-sans text-[#666] dark:text-[#AAA]">
                  Powered by Gemini 3.6 Flash • Executive Summaries & Academic Q&A
                </p>
              </div>
            </div>

            {/* 1. Executive Summary Tool */}
            <div className="bg-white dark:bg-[#1A1A1A] p-5 border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#EEE]">
                  1. Executive Synthesis
                </h3>
                <button
                  onClick={handleGenerateAISummary}
                  disabled={isLoadingSummary}
                  className="px-4 py-1.5 bg-[#A51C30] hover:bg-[#8A1627] text-white text-xs font-sans font-bold uppercase tracking-wider rounded-xs cursor-pointer flex items-center gap-1.5"
                >
                  {isLoadingSummary ? 'Analyzing...' : 'Generate 3-Bullet Summary'}
                </button>
              </div>

              {aiSummary && (
                <div className="p-4 bg-[#FAFAFA] dark:bg-[#222] border-l-4 border-[#A51C30] font-serif text-sm text-[#333] dark:text-[#DDD] whitespace-pre-line leading-relaxed">
                  {aiSummary}
                </div>
              )}
            </div>

            {/* 2. Ask the Article Tool */}
            <div className="bg-white dark:bg-[#1A1A1A] p-5 border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-4 shadow-xs">
              <h3 className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#EEE]">
                2. Ask the Article
              </h3>
              
              <form onSubmit={handleAskQuestion} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Ask any question about research methods, trial data, or implications..."
                  value={userQuestion}
                  onChange={(e) => setUserQuestion(e.target.value)}
                  className="flex-1 bg-[#FAFAFA] dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] px-3 py-2 text-sm font-sans text-[#1A1A1A] dark:text-[#EEE] rounded-xs focus:outline-none focus:border-[#A51C30]"
                />
                <button
                  type="submit"
                  disabled={isLoadingAsk}
                  className="px-4 py-2 bg-[#1A1A1A] dark:bg-[#EEE] text-white dark:text-[#1A1A1A] text-xs font-sans font-bold uppercase rounded-xs cursor-pointer flex items-center gap-1"
                >
                  {isLoadingAsk ? 'Querying...' : 'Ask AI'}
                </button>
              </form>

              {aiAnswer && (
                <div className="p-4 bg-[#F4F1EA] dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] font-serif text-sm text-[#333] dark:text-[#DDD] leading-relaxed">
                  <div className="font-bold text-[#A51C30] text-xs font-sans uppercase mb-1">Answer from Article Knowledge Base:</div>
                  {aiAnswer}
                </div>
              )}
            </div>

            {/* 3. Concept Simplifier */}
            <div className="bg-white dark:bg-[#1A1A1A] p-5 border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-4 shadow-xs">
              <div className="flex items-center justify-between">
                <h3 className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#EEE]">
                  3. Explain Technical Jargon
                </h3>
                <div className="flex items-center space-x-2 text-xs font-sans">
                  <select
                    value={explainLevel}
                    onChange={(e: any) => setExplainLevel(e.target.value)}
                    className="bg-[#FAFAFA] dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] px-2 py-1 rounded text-[#333] dark:text-[#EEE]"
                  >
                    <option value="layman">For Curious Readers</option>
                    <option value="student">For Undergraduates</option>
                    <option value="academic">Academic Precision</option>
                  </select>
                  <button
                    onClick={handleExplainSimply}
                    disabled={isLoadingExplain}
                    className="px-3 py-1 bg-[#A51C30] text-white text-xs font-sans font-semibold rounded cursor-pointer"
                  >
                    {isLoadingExplain ? 'Translating...' : 'Simplify'}
                  </button>
                </div>
              </div>

              {explainedText && (
                <div className="p-4 bg-[#FAFAFA] dark:bg-[#222] border-l-4 border-amber-600 font-serif text-sm text-[#333] dark:text-[#DDD]">
                  {explainedText}
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 3: Citations & Academic References */}
        {activeTab === 'citations' && (
          <div className="p-6 md:p-10 space-y-6 flex-1 max-w-3xl mx-auto w-full font-serif">
            <h2 className="text-2xl font-bold text-[#1A1A1A] dark:text-[#EEE]">
              Scholarly Citations & Bibliography
            </h2>

            {/* Citation Exporter Buttons */}
            <div className="p-4 bg-white dark:bg-[#1A1A1A] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-3">
              <div className="text-xs font-sans font-bold uppercase text-[#A51C30]">Export Article Citation</div>
              <div className="flex flex-wrap gap-3">
                <button 
                  onClick={() => copyCitationFormat('APA')}
                  className="px-4 py-2 bg-[#EFECE6] dark:bg-[#222] hover:bg-[#A51C30] hover:text-white text-xs font-sans font-bold uppercase rounded cursor-pointer flex items-center gap-1.5"
                >
                  {copiedCitation === 'APA' ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy APA 7th</span>
                </button>
                <button 
                  onClick={() => copyCitationFormat('MLA')}
                  className="px-4 py-2 bg-[#EFECE6] dark:bg-[#222] hover:bg-[#A51C30] hover:text-white text-xs font-sans font-bold uppercase rounded cursor-pointer flex items-center gap-1.5"
                >
                  {copiedCitation === 'MLA' ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy MLA 9th</span>
                </button>
                <button 
                  onClick={() => copyCitationFormat('BibTeX')}
                  className="px-4 py-2 bg-[#EFECE6] dark:bg-[#222] hover:bg-[#A51C30] hover:text-white text-xs font-sans font-bold uppercase rounded cursor-pointer flex items-center gap-1.5"
                >
                  {copiedCitation === 'BibTeX' ? <Check className="w-3.5 h-3.5 text-green-500" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>Copy BibTeX</span>
                </button>
              </div>
            </div>

            {/* List of references */}
            <div className="space-y-4 pt-4">
              <h3 className="text-sm font-sans font-bold uppercase text-[#777]">Primary References cited in report:</h3>
              {selectedArticle.citations ? (
                selectedArticle.citations.map((c) => (
                  <div key={c.id} className="p-4 bg-white dark:bg-[#1A1A1A] border-l-4 border-[#A51C30] border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-1 text-sm">
                    <div className="font-bold text-[#1A1A1A] dark:text-[#EEE]">{c.title}</div>
                    <div className="text-xs text-[#555] dark:text-[#AAA]">{c.authors} ({c.year}). <em>{c.journalOrPublisher}</em>.</div>
                    {c.doi && <div className="text-[11px] font-mono text-[#A51C30]">DOI: {c.doi}</div>}
                  </div>
                ))
              ) : (
                <div className="p-4 bg-white dark:bg-[#1A1A1A] border-l-4 border-[#A51C30] text-sm">
                  {selectedArticle.author.name}. ({selectedArticle.publishedAt}). "{selectedArticle.title}". <em>The Harvard Chronicle</em>, Vol. CLIII.
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: Peer Discussion & Comments */}
        {activeTab === 'comments' && (
          <div className="p-6 md:p-10 space-y-6 flex-1 max-w-3xl mx-auto w-full">
            <h2 className="font-serif text-2xl font-bold text-[#1A1A1A] dark:text-[#EEE]">
              Academic & Student Forum
            </h2>

            {/* Comment Form */}
            <form onSubmit={handleAddComment} className="bg-white dark:bg-[#1A1A1A] p-4 border border-[#E0DACF] dark:border-[#2A2A2A] rounded-xs space-y-3">
              <div className="flex items-center justify-between text-xs font-sans">
                <span className="font-bold text-[#1A1A1A] dark:text-[#EEE]">Join the Scholarly Discussion</span>
                <div className="flex items-center space-x-2">
                  <span className="text-[#777]">Posting as:</span>
                  <select 
                    value={userRole} 
                    onChange={(e: any) => setUserRole(e.target.value)}
                    className="bg-[#FAFAFA] dark:bg-[#222] border px-2 py-0.5 rounded text-[#333] dark:text-[#EEE]"
                  >
                    <option value="Student">Student</option>
                    <option value="Faculty">Faculty Member</option>
                    <option value="Alumni">Alumni</option>
                    <option value="Reader">Verified Reader</option>
                  </select>
                </div>
              </div>

              <textarea
                rows={3}
                placeholder="Share respectful academic commentary or questions..."
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="w-full bg-[#FAFAFA] dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] p-3 text-sm font-serif rounded-xs focus:outline-none focus:border-[#A51C30]"
              />

              <button
                type="submit"
                className="px-5 py-2 bg-[#A51C30] hover:bg-[#8A1627] text-white text-xs font-sans font-bold uppercase tracking-wider rounded-xs cursor-pointer flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" /> Post Comment
              </button>
            </form>

            {/* Existing Comments */}
            <div className="space-y-4 pt-4 divide-y divide-[#EFECE6] dark:divide-[#222]">
              {comments.map((comm) => (
                <div key={comm.id} className="pt-4 first:pt-0 space-y-2">
                  <div className="flex items-center space-x-3">
                    <img src={comm.avatar} alt={comm.authorName} className="w-8 h-8 rounded-full object-cover" />
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-serif text-sm font-bold text-[#1A1A1A] dark:text-[#EEE]">{comm.authorName}</span>
                        <span className="bg-[#A51C30]/10 text-[#A51C30] dark:text-[#E57373] text-[10px] font-sans font-bold px-2 py-0.5 rounded-full">
                          {comm.authorRole}
                        </span>
                      </div>
                      <span className="text-[11px] font-sans text-[#777]">{comm.timestamp}</span>
                    </div>
                  </div>

                  <p className="font-serif text-sm text-[#333] dark:text-[#DDD] pl-11 leading-relaxed">
                    {comm.content}
                  </p>

                  <div className="pl-11 flex items-center space-x-2 text-xs font-sans text-[#777]">
                    <button className="flex items-center gap-1 hover:text-[#A51C30] cursor-pointer">
                      <ThumbsUp className="w-3.5 h-3.5" /> <span>{comm.likes}</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
