import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Article, Department } from '../types';
import { MOCK_DEPARTMENTS } from '../data/mockArticles';
import { Search, X, Sparkles, Filter, ArrowRight, Clock, Bookmark } from 'lucide-react';

export const AISearchModal: React.FC = () => {
  const { 
    isSearchModalOpen, 
    setIsSearchModalOpen, 
    articles, 
    setSelectedArticle,
    savedArticleIds,
    toggleSaveArticle
  } = useApp();

  const [query, setQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [aiMatches, setAiMatches] = useState<Array<{ id: string; relevanceScore: number; reason: string }>>([]);
  const [isSearching, setIsSearching] = useState(false);

  if (!isSearchModalOpen) return null;

  const handleSearchSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setIsSearching(true);
    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query, articles })
      });
      const data = await res.json();
      setAiMatches(data.matches || []);
    } catch {
      // Fallback local matching
      const q = query.toLowerCase();
      const matched = articles.filter(a =>
        a.title.toLowerCase().includes(q) ||
        a.subtitle.toLowerCase().includes(q) ||
        a.department.toLowerCase().includes(q)
      ).map(a => ({ id: a.id, relevanceScore: 0.9, reason: `Matches query "${query}"` }));
      setAiMatches(matched);
    } finally {
      setIsSearching(false);
    }
  };

  // Quick preset search chips
  const searchPresets = [
    'Alzheimer peptide treatment',
    'AI safety governance MIT',
    'Climate net zero 2030',
    'Endowment fiscal returns',
    'Academic free inquiry',
    'Renaissance art exhibition'
  ];

  // Filter combined articles
  let results: Article[] = [];
  if (aiMatches.length > 0) {
    results = aiMatches
      .map(m => articles.find(a => a.id === m.id))
      .filter((a): a is Article => Boolean(a));
  } else if (query.trim()) {
    const q = query.toLowerCase();
    results = articles.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.subtitle.toLowerCase().includes(q) ||
      a.department.toLowerCase().includes(q)
    );
  } else {
    results = articles;
  }

  if (selectedDept !== 'All') {
    results = results.filter(a => a.department.toLowerCase() === selectedDept.toLowerCase());
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#FAFAFA] dark:bg-[#121212] text-[#1A1A1A] dark:text-[#E8E8E8] max-w-3xl w-full my-auto rounded-xs shadow-2xl border border-[#E0DACF] dark:border-[#2A2A2A] relative overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="p-4 bg-[#EFECE6] dark:bg-[#1A1A1A] border-b border-[#E0DACF] dark:border-[#2A2A2A] flex items-center justify-between">
          <div className="flex items-center space-x-2 text-[#A51C30] dark:text-[#E57373]">
            <Sparkles className="w-5 h-5" />
            <h3 className="font-serif text-lg font-bold">Natural Language & AI Semantic Search</h3>
          </div>
          <button 
            onClick={() => setIsSearchModalOpen(false)}
            className="p-1 hover:bg-[#A51C30] hover:text-white rounded transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Input Box */}
        <div className="p-4 space-y-4">
          <form onSubmit={handleSearchSubmit} className="relative">
            <input
              type="text"
              placeholder="Search by natural query, topic, author, or research paper..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-white dark:bg-[#222] border-2 border-[#A51C30] p-3.5 pl-11 text-base font-serif text-[#1A1A1A] dark:text-[#EEE] rounded-xs shadow-inner focus:outline-none"
              autoFocus
            />
            <Search className="absolute left-3.5 top-4 w-5 h-5 text-[#A51C30]" />
            <button
              type="submit"
              disabled={isSearching}
              className="absolute right-2 top-2 px-4 py-2 bg-[#A51C30] hover:bg-[#8A1627] text-white text-xs font-sans font-bold uppercase rounded cursor-pointer"
            >
              {isSearching ? 'AI Ranking...' : 'Search'}
            </button>
          </form>

          {/* Preset Chips */}
          <div className="flex flex-wrap gap-1.5 text-xs font-sans">
            <span className="text-[#777] font-semibold py-1">Suggested:</span>
            {searchPresets.map(preset => (
              <button
                key={preset}
                onClick={() => {
                  setQuery(preset);
                  setIsSearching(true);
                  fetch('/api/ai/search', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query: preset, articles })
                  })
                  .then(r => r.json())
                  .then(d => setAiMatches(d.matches || []))
                  .finally(() => setIsSearching(false));
                }}
                className="px-2.5 py-1 bg-white dark:bg-[#222] border border-[#E0DACF] dark:border-[#333] hover:border-[#A51C30] text-[#333] dark:text-[#CCC] rounded-xs cursor-pointer"
              >
                {preset}
              </button>
            ))}
          </div>

          {/* Department Filter Pills */}
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 scrollbar-none text-xs font-sans">
            <span className="text-[#777] font-semibold">Department:</span>
            <button
              onClick={() => setSelectedDept('All')}
              className={`px-2.5 py-0.5 rounded ${selectedDept === 'All' ? 'bg-[#A51C30] text-white font-bold' : 'bg-[#EFECE6] dark:bg-[#222] text-[#444]'}`}
            >
              All
            </button>
            {MOCK_DEPARTMENTS.slice(0, 8).map(d => (
              <button
                key={d}
                onClick={() => setSelectedDept(d)}
                className={`px-2.5 py-0.5 rounded whitespace-nowrap ${selectedDept === d ? 'bg-[#A51C30] text-white font-bold' : 'bg-[#EFECE6] dark:bg-[#222] text-[#444]'}`}
              >
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Results List */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1 divide-y divide-[#EFECE6] dark:divide-[#222]">
          <div className="text-xs font-sans text-[#777] font-semibold">
            Showing {results.length} matched stories
          </div>

          {results.map((art) => {
            const aiMatchInfo = aiMatches.find(m => m.id === art.id);

            return (
              <div key={art.id} className="pt-3 first:pt-0 space-y-1.5">
                <div className="flex items-center justify-between text-[11px] font-sans">
                  <span className="font-bold text-[#A51C30] uppercase">{art.department}</span>
                  <span className="text-[#777]">{art.publishedAt}</span>
                </div>

                <h4
                  onClick={() => {
                    setSelectedArticle(art);
                    setIsSearchModalOpen(false);
                  }}
                  className="font-serif text-base font-bold text-[#1A1A1A] dark:text-[#EEE] hover:text-[#A51C30] leading-snug cursor-pointer"
                >
                  {art.title}
                </h4>

                <p className="font-serif text-xs text-[#555] dark:text-[#AAA] line-clamp-2">
                  {art.subtitle}
                </p>

                {aiMatchInfo?.reason && (
                  <div className="p-2 bg-[#F4F1EA] dark:bg-[#222] border-l-2 border-[#A51C30] text-[11px] font-sans text-[#A51C30] dark:text-[#E57373]">
                    <strong>AI Relevance Note:</strong> {aiMatchInfo.reason}
                  </div>
                )}

                <div className="flex items-center justify-between text-xs font-serif text-[#777] pt-1">
                  <span>By {art.author.name}</span>
                  <button onClick={() => toggleSaveArticle(art.id)} className="cursor-pointer">
                    <Bookmark className={`w-3.5 h-3.5 ${savedArticleIds.includes(art.id) ? 'fill-current text-[#A51C30]' : ''}`} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
