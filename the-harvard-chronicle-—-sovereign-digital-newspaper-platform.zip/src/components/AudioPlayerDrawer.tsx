import React from 'react';
import { useApp } from '../context/AppContext';
import { Play, Pause, X, Volume2, FastForward, RotateCcw } from 'lucide-react';

export const AudioPlayerDrawer: React.FC = () => {
  const { 
    audioNarrationArticle, 
    setAudioNarrationArticle,
    activePodcast, 
    setActivePodcast,
    isPlayingAudio, 
    setIsPlayingAudio,
    audioSpeed,
    setAudioSpeed,
    audioProgress,
    setAudioProgress
  } = useApp();

  if (!audioNarrationArticle && !activePodcast) return null;

  const title = audioNarrationArticle ? audioNarrationArticle.title : activePodcast?.title;
  const subtitle = audioNarrationArticle ? `Narrated by AI Voice • ${audioNarrationArticle.author.name}` : activePodcast?.showName;
  const cover = audioNarrationArticle ? audioNarrationArticle.featuredImage : activePodcast?.coverImage;

  const toggleSpeed = () => {
    const speeds = [1, 1.25, 1.5, 2];
    const nextIdx = (speeds.indexOf(audioSpeed) + 1) % speeds.length;
    setAudioSpeed(speeds[nextIdx]);
  };

  const handleClose = () => {
    setIsPlayingAudio(false);
    setAudioNarrationArticle(null);
    setActivePodcast(null);
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-[#1A1A1A] text-white border-t border-[#A51C30] shadow-2xl py-3 px-4 animate-slideUp">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        
        {/* Left: Artwork & Details */}
        <div className="flex items-center space-x-3 w-full md:w-1/3">
          <img src={cover} alt={title} className="w-12 h-12 object-cover rounded-xs border border-white/20 shrink-0" />
          <div className="min-w-0">
            <h4 className="font-serif text-sm font-bold truncate text-white">{title}</h4>
            <p className="font-sans text-[11px] text-neutral-400 truncate">{subtitle}</p>
          </div>
        </div>

        {/* Center: Playback Controls & Progress */}
        <div className="flex flex-col items-center w-full md:w-1/3 space-y-1">
          <div className="flex items-center space-x-4">
            <button 
              onClick={() => setAudioProgress(Math.max(0, audioProgress - 10))}
              className="text-neutral-400 hover:text-white cursor-pointer"
              title="Rewind 10s"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              onClick={() => setIsPlayingAudio(!isPlayingAudio)}
              className="w-9 h-9 rounded-full bg-[#A51C30] hover:bg-[#8A1627] text-white flex items-center justify-center cursor-pointer shadow-md"
            >
              {isPlayingAudio ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
            </button>

            <button 
              onClick={() => setAudioProgress(Math.min(100, audioProgress + 10))}
              className="text-neutral-400 hover:text-white cursor-pointer"
              title="Forward 10s"
            >
              <FastForward className="w-4 h-4" />
            </button>

            <button
              onClick={toggleSpeed}
              className="text-xs font-sans font-bold text-amber-300 hover:text-amber-200 cursor-pointer bg-white/10 px-2 py-0.5 rounded"
              title="Playback Speed"
            >
              {audioSpeed}x
            </button>
          </div>

          {/* Progress Scrub Bar */}
          <div className="w-full flex items-center space-x-2 text-[10px] font-sans text-neutral-400">
            <span>02:14</span>
            <input 
              type="range"
              min="0"
              max="100"
              value={audioProgress}
              onChange={(e) => setAudioProgress(Number(e.target.value))}
              className="w-full accent-[#A51C30] h-1 bg-neutral-700 rounded cursor-pointer"
            />
            <span>07:30</span>
          </div>
        </div>

        {/* Right: Waveform Animation & Close */}
        <div className="hidden md:flex items-center justify-end space-x-4 w-1/3">
          {isPlayingAudio && (
            <div className="flex items-end space-x-1 h-5">
              <span className="w-1 bg-[#A51C30] animate-bounce h-3"></span>
              <span className="w-1 bg-[#A51C30] animate-bounce h-5 delay-75"></span>
              <span className="w-1 bg-[#A51C30] animate-bounce h-2 delay-150"></span>
              <span className="w-1 bg-[#A51C30] animate-bounce h-4 delay-100"></span>
            </div>
          )}

          <button onClick={handleClose} className="p-1 text-neutral-400 hover:text-white cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

      </div>
    </div>
  );
};
