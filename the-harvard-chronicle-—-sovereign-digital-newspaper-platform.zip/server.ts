import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialize Gemini SDK client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    try {
      aiClient = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    } catch (e) {
      console.warn("Failed to initialize GoogleGenAI client:", e);
    }
  }
  return aiClient;
}

// API Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// AI Executive Summarizer API
app.post("/api/ai/summarize", async (req, res) => {
  try {
    const { title, content } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: "Title and content are required" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Fallback response if key is missing
      return res.json({
        summary: `Executive Synthesis of "${title}":\n• Breakthrough finding published in major journal.\n• Significant implications for institutional policy and public trust.\n• Follow-up studies and trials scheduled for autumn 2026.`,
        isFallback: true
      });
    }

    const prompt = `You are an elite senior editorial analyst for The Harvard Chronicle. Provide a pristine 3-bullet executive synthesis of the following article entitled "${title}". Keep each bullet crisp, intellectual, authoritative, and focused on key facts.

Article Content:
${Array.isArray(content) ? content.join("\n\n") : content}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are a distinguished Harvard editor. Be concise, precise, and academic."
      }
    });

    res.json({
      summary: response.text || "Summary generated successfully.",
      isFallback: false
    });
  } catch (err: any) {
    console.error("AI Summarize error:", err);
    res.status(500).json({ error: err.message || "Failed to generate AI summary" });
  }
});

// AI "Ask the Article" Q&A API
app.post("/api/ai/ask", async (req, res) => {
  try {
    const { title, content, question } = req.body;
    if (!question) {
      return res.status(400).json({ error: "Question is required" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      return res.json({
        answer: `Regarding your question "${question}": Based on the article "${title}", the researchers emphasize empirical verification, rigorous methodological controls, and institutional collaboration across Harvard departments.`,
        isFallback: true
      });
    }

    const prompt = `You are a research assistant at Harvard University answering a reader's question about an article in The Harvard Chronicle.

Article Title: "${title}"
Article Text:
${Array.isArray(content) ? content.join("\n\n") : content}

User Question: "${question}"

Provide a clear, authoritative, and direct answer based strictly on the article context. Include relevant academic perspective if helpful.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    res.json({
      answer: response.text || "No response generated.",
      isFallback: false
    });
  } catch (err: any) {
    console.error("AI Ask error:", err);
    res.status(500).json({ error: err.message || "Failed to process question" });
  }
});

// AI Concept Simplifier ("Explain Simply")
app.post("/api/ai/explain", async (req, res) => {
  try {
    const { text, level } = req.body; // level: 'layman' | 'student' | 'academic'
    const ai = getGeminiClient();

    if (!ai) {
      return res.json({
        explanation: `Simplified explanation (${level || 'layman'}): The article explains how natural biological or economic mechanisms can be reactivated with targeted tools instead of complete suppression.`,
        isFallback: true
      });
    }

    const prompt = `Explain the following excerpt from a Harvard scholarly article in clear terms tailored for a ${level || 'curious undergraduate'} audience.

Excerpt:
"${text}"

Break down any technical jargon, metaphors, or complex equations into clear concepts.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    res.json({
      explanation: response.text || "Explanation generated.",
      isFallback: false
    });
  } catch (err: any) {
    console.error("AI Explain error:", err);
    res.status(500).json({ error: err.message || "Failed to explain text" });
  }
});

// AI Semantic Search API
app.post("/api/ai/search", async (req, res) => {
  try {
    const { query, articles } = req.body;
    if (!query) {
      return res.status(400).json({ error: "Query required" });
    }

    const ai = getGeminiClient();
    if (!ai) {
      // Fallback keyword search
      const q = query.toLowerCase();
      const matched = (articles || []).filter((a: any) =>
        a.title.toLowerCase().includes(q) ||
        a.subtitle.toLowerCase().includes(q) ||
        a.department.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q)
      ).map((a: any) => ({
        id: a.id,
        relevanceScore: 0.85,
        reason: `Keyword match for "${query}" in title or summary.`
      }));

      return res.json({ matches: matched, isFallback: true });
    }

    const articlesBrief = (articles || []).map((a: any) => ({
      id: a.id,
      title: a.title,
      department: a.department,
      summary: a.summary
    }));

    const prompt = `Given the user natural language query: "${query}"
Analyze these articles from The Harvard Chronicle archive:
${JSON.stringify(articlesBrief, null, 2)}

Return a JSON array of objects with fields:
"id": article id string
"relevanceScore": number between 0 and 1
"reason": short explanation of why it relates to the query.

Return ONLY JSON array.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    let matches = [];
    try {
      matches = JSON.parse(response.text || "[]");
    } catch {
      matches = [];
    }

    res.json({ matches, isFallback: false });
  } catch (err: any) {
    console.error("AI Search error:", err);
    res.status(500).json({ error: err.message || "Search failed" });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`The Harvard Chronicle server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
