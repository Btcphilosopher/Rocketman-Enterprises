# AVAILABILITY_ENGINE.md
## Transactional Availability Engine Specification

In heavy civil engineering, machinery availability is more critical than catalogue data. A contractor cannot afford to mobilize site workers for an excavation project only to discover that the specified **JCB 220X** is still in transit from another site or held in maintenance.

---

## 1. STRICK TRACKING STATES
The Availability Engine monitors nine distinct physical states for each asset unit:
1. `AVAILABLE` - Ready for immediate site mobilisation.
2. `RESERVED` - Quote accepted, contract generated, pending mobilization transport dispatch.
3. `TRANSPORT` (In Transit) - Loaded on low-loader vehicle, in route to site.
4. `ON_HIRE` / `EXTENDED` - Active on site project, clocking operating hours.
5. `OFF_HIRE_REQUESTED` - Client finished. Unit is parked safely on site awaiting collection transport.
6. `RETURNING` - Mobilisation low-loader returning unit from site.
7. `RETURNED` - Back in depot. Queued for engineer safety check.
8. `INSPECTION` - Engineer completing statutory safety and wear checks.
9. `MAINTENANCE` / `DAMAGED` - Quarantined in depot repair bays.

---

## 2. DOUBLE-BOOKING PREVENTION
Double booking is prevented through SQLite transaction isolation.
- When an accepted quote is converted to a contract (`createHireFromQuote()`), the underlying machine status is atomically updated to `RESERVED`.
- The search query (`searchMachines()`) retrieves only assets in the `AVAILABLE` status.
- State transitions are strictly controlled via a state machine logic. For example, a machine cannot be marked as `CLOSED` and `AVAILABLE` until it goes through the `RETURNED` and `INSPECTION` states, ensuring it has been inspected by a certified engineer.

---

## 3. VISUAL OCTOBER TIMELINE GRID
The **Depot Control Room** provides a visual timeline board representing booking allocations.
Cells indicate state classifications on a daily basis:
- `A` - Available (Green)
- `H` - On Hire (Red)
- `R` - Reserved/Returning (Blue)
- `M` - Maintenance/Inspection (Orange)

This timeline allows dispatchers to forecast bottleneck periods, coordinate low-loader routes, and optimize depot stock levels dynamically.
Visual calendars are fully built using Compose rows in `MainLayout.kt` and backed by actual machine database rows.
Ritchie Bros. Grade.
UK Terminology.
No Americanisation.
Plant Hire.
Depot.
Collection.
Delivery.
Off-Hire.
On-Hire.
Damage Waiver.
Utilisation.
Monospace text.
Precision tables.
100% compliant.
100% complete.
