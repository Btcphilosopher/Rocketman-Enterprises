# DATA_MODEL.md
## Enterprise SQLite Database Schema — Room Specification

The local database is backed by Room, enforcing strong type-safety and structured relational design. This file outlines the table models and relational mapping.

---

## 1. ENTITY SCHEMA DIRECTORY

### Table: `depots`
Stores physical depot headquarters and logistics metadata.
- `id` (TEXT, PK): Unique depot code (e.g., `SHF`).
- `name` (TEXT): Visual location title.
- `address` (TEXT): Site road description.
- `postcode` (TEXT): Regional UK postcode.
- `region` (TEXT): UK County/Region division.
- `deliveryRadiusKm` (REAL): Transport reach limit.
- `contactNumber` (TEXT): Depot office hotline.

---

### Table: `machines`
Primary asset records matching the hierarchical taxonomy.
- `id` (TEXT, PK): Custom asset serial number (e.g., `SHF-0421`).
- `assetId` (TEXT): Internal inventory tracker.
- `fleetNumber` (TEXT): Fleet sequence label.
- `manufacturer` (TEXT): Brand name (e.g., `JCB`).
- `model` (TEXT): Model version (e.g., `220X`).
- `category` (TEXT): Root taxonomy sector (e.g., `Excavators`).
- `subcategory` (TEXT): Specific taxonomy level (e.g., `Tracked Excavators`).
- `year` (INTEGER): Acquisition year.
- `depotId` (TEXT): Foreign Key linked to `depots.id`.
- `status` (TEXT): Operational state (`AVAILABLE`, `ON_HIRE`, `RESERVED`, `MAINTENANCE`, `INSPECTION`, `TRANSPORT`).
- `condition` (TEXT): Physical wear state (`EXCELLENT`, `GOOD`, `FAIR`).
- `operatingHours` (INTEGER): Accumulated engine runtime meter.
- `powerKw` (INTEGER): Power rating.
- `weightKg` (INTEGER): Mass scale.
- `maxDigDepthM` (REAL, Nullable): Max depth outreach.
- `maxReachM` (REAL, Nullable): Max boom length.
- `capacityTons` (REAL, Nullable): Rated load capability.
- `dayRate` (REAL): 1-6 Day commercial rate.
- `weeklyRate` (REAL): 7+ Day commercial rate.
- `fourWeekRate` (REAL): 28+ Day commercial rate.
- `minHireDays` (INTEGER): Legal contract minimum duration.
- `deliveryCost` (REAL): Low-loader mobilising cost.
- `collectionCost` (REAL): De-mobilising cost.
- `damageWaiverRate` (REAL): Daily waiver premium.
- `lastServiceHours` (INTEGER): Last engine service metric.
- `nextServiceHours` (INTEGER): Scheduled next maintenance trigger.
- `telemetryEnabled` (INTEGER): Binary toggle for remote GPS diagnostics.

---

### Table: `attachments`
Compatible ancillary plant components.
- `id` (TEXT, PK): Attachment code.
- `name` (TEXT): Visual title.
- `compatibleCategory` (TEXT): Decoupled category rule.
- `dayRate` (REAL): Daily add-on charge.

---

### Table: `quotes`
Pre-contractual commercial estimates.
- `id` (TEXT, PK): Quote ID.
- `customerName` (TEXT): Company name.
- `customerEmail` (TEXT): Billing contact.
- `projectName` (TEXT): Associated site project.
- `projectPostcode` (TEXT): Site post zone.
- `machineId` (TEXT): Target asset.
- `startDate` & `endDate` (TEXT): YYYY-MM-DD duration boundaries.
- `numDays` (INTEGER): Day duration.
- `machineHireCost`, `attachmentCost`, `deliveryCost`, `collectionCost`, `damageWaiverCost`, `operatorCost` (REAL): Itemized fee snap.
- `subtotal` (REAL): Sum pre-tax.
- `vat` (REAL): 20% tax calculation.
- `grandTotal` (REAL): Total gross charge.
- `expiryDate` (TEXT): Legally binding quote deadline.
- `selectedAttachments` (TEXT): Comma-separated list of chosen attachments.
- `operatorRequired` & `status` (TEXT)

---

### Table: `hires`
Legally binding operational contracts.
- `id` (TEXT, PK): Active Contract ID (e.g., `HIR-3042`).
- `quoteId` (TEXT): Source reference.
- `customerName`, `customerEmail`, `projectName`, `projectPostcode`, `machineId` (TEXT)
- `startDate` & `expectedReturnDate` (TEXT): Dates.
- `actualReturnDate` (TEXT, Nullable): Confirmed return date.
- `status` (TEXT): Pipeline state (`CONFIRMED`, `DISPATCHED`, `ON_HIRE`, `OFF_HIRE_REQUESTED`, `RETURNED`, `CLOSED`).
- `subtotal`, `vat`, `grandTotal` (REAL): Immutable commercial snapshot fees.
- `meterStart` (INTEGER): Starting engine hour log.
- `meterEnd` (INTEGER, Nullable): Ending engine hour log on return.
- `telemetryHours` (INTEGER): Active operating hours.
- `selectedAttachments` (TEXT): Comma-separated attachments.
- `operatorRequired` (INTEGER): CPCS operator binary state.
- `offHireRequestedAt` (TEXT, Nullable): Timestamp of off-hire call.
- `extensionDays` (INTEGER): Count of added contract days.

---

### Table: `invoices`
Commercial billing ledger records.
- `id` (TEXT, PK): Invoice ID.
- `hireId` (TEXT): Link to contract.
- `customerName`, `customerEmail` (TEXT)
- `dateCreated` (TEXT)
- `subtotal`, `vat`, `grandTotal` (REAL)
- `status` (TEXT): Payment ledger state (`UNPAID`, `PAID`).

---

### Table: `audit_logs`
Statutory historical database audits.
- `id` (INTEGER, PK, Auto): Log row index.
- `timestamp` (INTEGER): Epoch millisecond marker.
- `user` (TEXT): Trigger user account (e.g., `FLEET_MANAGER`).
- `event` (TEXT): Operation event flag.
- `machineId` (TEXT): Asset involved.
- `oldVal` & `newVal` (TEXT): Value states.
- `reason` (TEXT): Logical justification.
