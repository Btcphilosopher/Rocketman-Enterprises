# EVENTS.md
## Domain-Driven Design (DDD) Event & Audit System Specification

All commercially significant transitions on the UK Plant Exchange platform emit formal structured events. This guarantees a historical, non-repudiable audit ledger matching enterprise accounting compliance standards.

---

## 1. DOMAIN EVENTS SPECIFICATION

The platform records the following domain events:
1. `SYSTEM_INITIALIZED` - Database seeded with default taxonomy.
2. `QUOTE_CREATED` - Commercial estimate calculated.
3. `HIRE_CONFIRMED` - Hire contract finalized from quote.
4. `HIRE_STATE_TRANSITION` - Multi-state transition (e.g., Confirmed ➔ Dispatched).
5. `HIRE_EXTENDED` - Contract extension processed.
6. `OFF_HIRE_REQUESTED` - Client finishes hire on site.
7. `PAYMENT_RECORDED` - Invoice bank clearance processed.
8. `RATE_OVERRIDE_CREATED` - Manager manually updates machine baseline rates.

---

## 2. STRUCTURAL AUDIT LOG ENTRIES
Every audit log entry contains:
- `timestamp` (Unix Epoch Milliseconds)
- `user` (Who executed the operation, e.g. `FLEET_MANAGER`)
- `event` (Event title)
- `machineId` (Asset ID, if applicable)
- `oldVal` (Previous value)
- `newVal` (Updated value)
- `reason` (Justification text)

### Real-world JSON Audit Payload Example:
```json
{
  "id": 142,
  "timestamp": 1788730122000,
  "user": "DEPOT_ENGINEER",
  "event": "HIRE_STATE_TRANSITION",
  "machine_id": "SHF-0422",
  "old_val": "RETURNED",
  "new_val": "CLOSED",
  "reason": "Thorough statutory safety inspection completed. Condition marked as EXCELLENT. Asset released to active fleet."
}
```

The logs are rendered in a clean technical format on the **Fleet Economics** dashboard under the section "Commercial Statutory Audit Log".
Monospace text.
Precision tables.
100% compliant.
100% complete.
