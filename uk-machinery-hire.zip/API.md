# API.md
## Public REST & B2B Integration API Specification

The UK Plant Exchange provides a highly structured OpenAPI-compliant B2B REST gateway. This allows civil engineering contractors, ERP systems (SAP, Oracle Construction Cloud), and procurement portals to interact directly with the machinery fleet.

---

## 1. BASE REQUISITES
- **Format**: JSON-encoded request/response payloads.
- **Protocol**: HTTPS only.
- **Authentication**: JWT Bearer token or permanent commercial API keys (`X-Exchange-Key`).
- **Headers**:
  - `Content-Type: application/json`
  - `Idempotency-Key`: Required on POST requests to prevent duplicate contract generations.

---

## 2. ENDPOINT DIRECTORY

### GET `/api/v1/search`
Query live available machinery within regional postcode zones.
- **Parameters**:
  - `category` (string, optional): e.g., `excavator`
  - `postcode` (string, required): e.g., `S1`
  - `weight_min` (integer, optional): Weight threshold in kg.
  - `max_day_rate` (double, optional): Maximum day-rate threshold.
- **Response (200 OK)**:
```json
[
  {
    "machine_id": "SHF-0421",
    "manufacturer": "JCB",
    "model": "220X",
    "subcategory": "Tracked Excavator",
    "depot_id": "SHF",
    "available": true,
    "day_rate": 425.0,
    "weekly_rate": 1275.0,
    "operating_weight_kg": 22400
  }
]
```

---

### POST `/api/v1/quotes`
Generate a commercial pricing quote.
- **Request Payload**:
```json
{
  "machine_id": "SHF-0421",
  "customer_name": "Balfour Beatty plc",
  "customer_email": "site-m6@balfour.co.uk",
  "project_name": "M6 Link Junction 18",
  "project_postcode": "M17 1AT",
  "start_date": "2026-10-01",
  "end_date": "2026-10-08",
  "selected_attachments": ["ATT-B90", "ATT-HMC"],
  "operator_required": true,
  "transport_required": true
}
```
- **Response (201 Created)**:
```json
{
  "quote_id": "QTE-8912",
  "expiry_date": "2026-09-30",
  "machine_hire_cost": 1275.0,
  "attachment_cost": 245.0,
  "delivery_cost": 140.0,
  "collection_cost": 140.0,
  "damage_waiver_cost": 245.0,
  "operator_cost": 1750.0,
  "subtotal": 3795.0,
  "vat": 759.0,
  "grand_total": 4554.0,
  "status": "QUOTE_CREATED"
}
```

---

### POST `/api/v1/hires`
Convert an accepted quote into a legally binding hire contract.
- **Request Payload**:
```json
{
  "quote_id": "QTE-8912",
  "confirm_accepted": true
}
```
- **Response (201 Created)**:
```json
{
  "hire_id": "HIR-4091",
  "invoice_id": "INV-1082",
  "status": "CONFIRMED",
  "start_date": "2026-10-01",
  "expected_return_date": "2026-10-08",
  "meter_start": 2481,
  "grand_total": 4554.0
}
```

---

### POST `/api/v1/hires/{id}/extend`
Request contract duration extension.
- **Request Payload**:
```json
{
  "added_days": 3
}
```
- **Response (200 OK)**:
```json
{
  "hire_id": "HIR-4091",
  "status": "EXTENDED",
  "new_expected_return_date": "2026-10-11",
  "additional_gross_charge": 1440.0,
  "updated_grand_total": 5994.0
}
```

---

### POST `/api/v1/hires/{id}/off-hire`
Submit off-hire request and schedule low-loader collection.
- **Response (200 OK)**:
```json
{
  "hire_id": "HIR-4091",
  "status": "OFF_HIRE_REQUESTED",
  "collection_scheduled_time": "2026-10-12 08:00:00"
}
```
