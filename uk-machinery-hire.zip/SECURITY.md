# SECURITY.md
## Enterprise Security, Access Control, and Secrets Management

The UK Plant Exchange is designed with modern enterprise security standards to protect commercially sensitive data, customer billing details, and fleet telemetry information.

---

## 1. ROLE-BASED ACCESS CONTROL (RBAC)
The platform isolates permissions across six user profiles to ensure least-privilege access:
1. **Fleet Manager**: Can override machine base rates, inspect national fleet metrics, and view commercial economics.
2. **Depot Manager**: Handles transport job dispatches and depot stock boards.
3. **Depot Engineer**: Records returned engine meter logs and signs off on statutory safety inspections.
4. **Site Manager / Site Agent**: Represents the contractor on-site. Can request contract extensions and trigger off-hire collection.
5. **Buyer / Procurement Officer**: Inspects quotes, accepts estimates, and reviews commercial pricing breakdowns.
6. **Accounts Receivable**: Reviews invoice ledger logs and clears pending payments.

---

## 2. SECRETS AND CONFIGURATION MANAGEMENT
- **No Hardcoded Keys**: API keys, credentials, and endpoints must never be stored in source files or VCS.
- **Secrets Gradle Plugin**: The project leverages the `secrets-gradle-plugin` to inject variables from a safe `.env` file at build-time.
- **BuildConfig Injection**: At runtime, secrets are loaded securely from `BuildConfig`.
- **Runtime Error Tolerance**: The application gracefully handles missing environment variables or network timeouts by showing clear error dialogs rather than crashing.

---

## 3. SQL INJECTION & DATA PROTECTION
- **Type-Safe Queries**: The database layer is written exclusively using Room compile-time verified DAOs. Raw query string concatenations are forbidden to eliminate SQL injection vulnerabilities.
- **Tenant Isolation**: Contract logs and project site postcodes are isolated in indexed tables, allowing easy multi-tenant filtering when querying databases.
- **GDPR Compliance**: Customer contacts (names, billing emails) are tracked strictly within quoting or contract limits and can be cleared dynamically on contract close.
