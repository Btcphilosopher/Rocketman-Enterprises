package com.example.data

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class PlantHireRepository(private val db: AppDatabase) {

    val allDepots: Flow<List<Depot>> = db.depotDao().getAllDepots()
    val allMachines: Flow<List<Machine>> = db.machineDao().getAllMachines()
    val allAttachments: Flow<List<Attachment>> = db.attachmentDao().getAllAttachments()
    val allQuotes: Flow<List<Quote>> = db.quoteDao().getAllQuotes()
    val allHires: Flow<List<Hire>> = db.hireDao().getAllHires()
    val allInvoices: Flow<List<Invoice>> = db.invoiceDao().getAllInvoices()
    val allAuditLogs: Flow<List<AuditLog>> = db.auditLogDao().getAllLogs()

    suspend fun getMachineById(id: String): Machine? = db.machineDao().getMachineById(id)
    fun getMachineByIdFlow(id: String): Flow<Machine?> = db.machineDao().getMachineByIdFlow(id)

    suspend fun getDepotById(id: String): Depot? = db.depotDao().getDepotById(id)

    suspend fun createQuote(quote: Quote) {
        db.quoteDao().insertQuote(quote)
        addAuditLog(
            user = quote.customerName,
            event = "QUOTE_CREATED",
            machineId = quote.machineId,
            oldVal = "",
            newVal = quote.status,
            reason = "Quotation calculated for project ${quote.projectName} (${quote.projectName})"
        )
    }

    suspend fun updateQuote(quote: Quote) {
        db.quoteDao().insertQuote(quote)
    }

    suspend fun createHireFromQuote(quote: Quote, meterStart: Int): Hire {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.UK)
        val expectedReturn = quote.endDate

        // Update Quote status
        db.quoteDao().insertQuote(quote.copy(status = "ACCEPTED"))

        // Create Hire Contract
        val hireId = "HIR-${(1000..9999).random()}"
        val hire = Hire(
            id = hireId,
            quoteId = quote.id,
            customerName = quote.customerName,
            customerEmail = quote.customerEmail,
            projectName = quote.projectName,
            projectPostcode = quote.projectPostcode,
            machineId = quote.machineId,
            startDate = quote.startDate,
            expectedReturnDate = expectedReturn,
            actualReturnDate = null,
            status = "CONFIRMED",
            machineHireCost = quote.machineHireCost,
            attachmentCost = quote.attachmentCost,
            deliveryCost = quote.deliveryCost,
            collectionCost = quote.collectionCost,
            damageWaiverCost = quote.damageWaiverCost,
            operatorCost = quote.operatorCost,
            subtotal = quote.subtotal,
            vat = quote.vat,
            grandTotal = quote.grandTotal,
            meterStart = meterStart,
            meterEnd = null,
            telemetryHours = meterStart,
            selectedAttachments = quote.selectedAttachments,
            operatorRequired = quote.operatorRequired,
            offHireRequestedAt = null,
            extensionDays = 0
        )

        db.hireDao().insertHire(hire)

        // Update machine status to RESERVED
        db.machineDao().updateStatus(quote.machineId, "RESERVED")

        addAuditLog(
            user = "SYSTEM",
            event = "HIRE_CONFIRMED",
            machineId = quote.machineId,
            oldVal = "AVAILABLE",
            newVal = "RESERVED",
            reason = "Hire contract $hireId generated from Quote ${quote.id}"
        )

        // Generate Invoice
        val invoiceId = "INV-${(1000..9999).random()}"
        val invoice = Invoice(
            id = invoiceId,
            hireId = hireId,
            customerName = quote.customerName,
            customerEmail = quote.customerEmail,
            dateCreated = dateFormat.format(Date()),
            subtotal = quote.subtotal,
            vat = quote.vat,
            grandTotal = quote.grandTotal,
            status = "UNPAID"
        )
        db.invoiceDao().insertInvoice(invoice)

        return hire
    }

    suspend fun updateHireStatus(hireId: String, newStatus: String, user: String, reason: String) {
        val hire = db.hireDao().getHireById(hireId) ?: return
        val updatedHire = hire.copy(status = newStatus)
        db.hireDao().updateHire(updatedHire)

        // Sync machine status depending on contract status
        val machineStatus = when (newStatus) {
            "DISPATCHED" -> "TRANSPORT"
            "ON_HIRE" -> "ON_HIRE"
            "EXTENDED" -> "ON_HIRE"
            "OFF_HIRE_REQUESTED" -> "ON_HIRE" // stays on hire until collected
            "RETURNING" -> "TRANSPORT"
            "RETURNED" -> "RETURNING"
            "INSPECTED" -> "INSPECTION"
            "CLOSED" -> "AVAILABLE"
            else -> "RESERVED"
        }
        db.machineDao().updateStatus(hire.machineId, machineStatus)

        // If returned, we also record a returned actual date
        if (newStatus == "RETURNED") {
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.UK)
            val today = dateFormat.format(Date())
            db.hireDao().updateHire(updatedHire.copy(actualReturnDate = today))
        }

        // If closed, let's complete maintenance/release
        if (newStatus == "CLOSED") {
            val m = db.machineDao().getMachineById(hire.machineId)
            if (m != null) {
                // simulated runtime engine hours increment
                val addedHours = hire.extensionDays * 8 + 15
                val newHours = m.operatingHours + addedHours
                db.machineDao().updateHours(m.id, newHours)
            }
        }

        addAuditLog(
            user = user,
            event = "HIRE_STATE_TRANSITION",
            machineId = hire.machineId,
            oldVal = hire.status,
            newVal = newStatus,
            reason = "$reason (Contract: $hireId)"
        )
    }

    suspend fun requestOffHire(hireId: String) {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK)
        val now = dateFormat.format(Date())
        db.hireDao().requestOffHire(hireId, now)

        val hire = db.hireDao().getHireById(hireId) ?: return
        addAuditLog(
            user = "CLIENT_PORTAL",
            event = "OFF_HIRE_REQUESTED",
            machineId = hire.machineId,
            oldVal = hire.status,
            newVal = "OFF_HIRE_REQUESTED",
            reason = "Client requested off-hire collection."
        )
    }

    suspend fun extendHire(hireId: String, addedDays: Int) {
        val hire = db.hireDao().getHireById(hireId) ?: return
        val machine = db.machineDao().getMachineById(hire.machineId) ?: return

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.UK)
        val currentEnd = dateFormat.parse(hire.expectedReturnDate) ?: Date()
        val calendar = Calendar.getInstance()
        calendar.time = currentEnd
        calendar.add(Calendar.DAY_OF_YEAR, addedDays)
        val newExpectedReturn = dateFormat.format(calendar.time)

        // Calculate added costs
        val addedMachineCost = machine.dayRate * addedDays
        val addedAttachmentCost = if (hire.selectedAttachments.isNotEmpty()) {
            val attachmentCount = hire.selectedAttachments.split(",").size
            // let's assume average attachment is £50/day
            50.0 * attachmentCount * addedDays
        } else 0.0

        val addedDamageCost = machine.damageWaiverRate * addedDays
        val addedOperatorCost = if (hire.operatorRequired) 250.0 * addedDays else 0.0

        val newMachineCost = hire.machineHireCost + addedMachineCost
        val newAttachmentCost = hire.attachmentCost + addedAttachmentCost
        val newDamageCost = hire.damageWaiverCost + addedDamageCost
        val newOperatorCost = hire.operatorCost + addedOperatorCost

        val newSubtotal = newMachineCost + newAttachmentCost + hire.deliveryCost + hire.collectionCost + newDamageCost + newOperatorCost
        val newVat = newSubtotal * 0.2
        val newGrandTotal = newSubtotal + newVat

        db.hireDao().extendHire(
            id = hireId,
            addedDays = addedDays,
            newExpectedReturn = newExpectedReturn,
            newSubtotal = newSubtotal,
            newVat = newVat,
            newGrandTotal = newGrandTotal
        )

        addAuditLog(
            user = "CLIENT_PORTAL",
            event = "HIRE_EXTENDED",
            machineId = hire.machineId,
            oldVal = hire.expectedReturnDate,
            newVal = newExpectedReturn,
            reason = "Extension of $addedDays days processed. Total contract updated."
        )
    }

    suspend fun markInvoicePaid(invoiceId: String) {
        db.invoiceDao().markAsPaid(invoiceId)
        val invoice = db.invoiceDao().getInvoiceById(invoiceId) ?: return
        addAuditLog(
            user = "ACCOUNTS_PORTAL",
            event = "PAYMENT_RECORDED",
            machineId = "",
            oldVal = "UNPAID",
            newVal = "PAID",
            reason = "Commercial payment received for £${String.format("%.2f", invoice.grandTotal)}. Invoice $invoiceId cleared."
        )
    }

    suspend fun addAuditLog(user: String, event: String, machineId: String, oldVal: String, newVal: String, reason: String) {
        db.auditLogDao().insertLog(
            AuditLog(
                timestamp = System.currentTimeMillis(),
                user = user,
                event = event,
                machineId = machineId,
                oldVal = oldVal,
                newVal = newVal,
                reason = reason
            )
        )
    }

    suspend fun updateMachineRate(machineId: String, newRate: Double, reason: String) {
        val m = db.machineDao().getMachineById(machineId) ?: return
        val oldRate = m.dayRate
        val updated = m.copy(dayRate = newRate, weeklyRate = newRate * 3.0, fourWeekRate = newRate * 10.0)
        db.machineDao().updateMachine(updated)

        addAuditLog(
            user = "FLEET_MANAGER",
            event = "RATE_OVERRIDE_CREATED",
            machineId = machineId,
            oldVal = "£${oldRate}/day",
            newVal = "£${newRate}/day",
            reason = reason
        )
    }

    fun searchMachines(
        category: String?,
        depotId: String?,
        maxDayRate: Double?,
        minWeight: Int?,
        maxWeight: Int?
    ): Flow<List<Machine>> {
        val catFilter = if (category == "All" || category.isNullOrEmpty()) null else category
        val depotFilter = if (depotId == "All" || depotId.isNullOrEmpty()) null else depotId
        return db.machineDao().searchMachines(catFilter, depotFilter, maxDayRate, minWeight, maxWeight)
    }

    suspend fun seedDatabase() = withContext(Dispatchers.IO) {
        val existingDepots = db.depotDao().getAllDepots().first()
        if (existingDepots.isNotEmpty()) {
            Log.d("PlantHireRepository", "Database already seeded.")
            return@withContext
        }

        Log.d("PlantHireRepository", "Seeding database with pristine high-fidelity Anglo-industrial fleet data...")

        val depots = listOf(
            Depot("SHF", "Sheffield Depot", "Vulcan Road, Sheffield", "S9 1EW", "Yorkshire", 45.0, "+44 114 496 0122"),
            Depot("LND", "London East Depot", "Beckton Alps Industrial Estate, London", "IG11 0UT", "London", 30.0, "+44 207 496 0341"),
            Depot("MCR", "Manchester Hub", "Trafford Park, Manchester", "M17 1AT", "North West", 50.0, "+44 161 496 0872"),
            Depot("BRM", "Birmingham Central", "Tyburn Road, Birmingham", "B24 8HJ", "Midlands", 40.0, "+44 121 496 0524"),
            Depot("BRS", "Bristol Port Depot", "Avonmouth, Bristol", "BS11 9FF", "South West", 35.0, "+44 117 496 0612"),
            Depot("GLG", "Glasgow West Depot", "Clydebank Industrial Estate", "G81 1UX", "Scotland", 60.0, "+44 141 496 0991"),
            Depot("CDF", "Cardiff Docks", "East Moors Road, Cardiff", "CF10 5EE", "Wales", 40.0, "+44 292 496 0411"),
            Depot("LDS", "Leeds Stourton Depot", "Stourton Plant Yard, Leeds", "LS10 1DL", "Yorkshire", 45.0, "+44 113 496 0229")
        )
        db.depotDao().insertDepots(depots)

        val attachments = listOf(
            Attachment("ATT-B60", "600mm Digging Bucket", "Excavators", 25.0),
            Attachment("ATT-B90", "900mm Heavy Bucket", "Excavators", 35.0),
            Attachment("ATT-B120", "1200mm Ditching Bucket", "Excavators", 45.0),
            Attachment("ATT-BH15", "Hydraulic Breaker 1.5t", "Excavators", 85.0),
            Attachment("ATT-HMC", "Hydraulic Compactor", "Excavators", 110.0),
            Attachment("ATT-AGR", "Earth Auger 300mm", "Excavators", 65.0),
            Attachment("ATT-MFL", "Pallet Forks 2.5t", "Telehandlers", 20.0),
            Attachment("ATT-LJB", "Lifting Jib 2t", "Telehandlers", 55.0),
            Attachment("ATT-SWM", "Sweeper Collector Unit", "Telehandlers", 95.0)
        )
        db.attachmentDao().insertAttachments(attachments)

        // Seed 20 core machines with diverse categories and locations
        val seedMachines = listOf(
            Machine("SHF-0421", "AST-JCB220-1", "FLT-00421", "JCB", "220X", "Excavators", "Tracked Excavators", 2023, "SHF", "AVAILABLE", "EXCELLENT", 2481, 129, 22400, 6.72, 9.8, 1.5, 425.0, 1275.0, 3400.0, 1, 145.0, 145.0, 36.0, 2400, 2650, true),
            Machine("SHF-0422", "AST-JCB3CX-1", "FLT-00422", "JCB", "3CX Pro", "Excavators", "Backhoe Loaders", 2022, "SHF", "ON_HIRE", "GOOD", 4120, 81, 8135, 5.97, 6.5, 1.0, 285.0, 850.0, 2350.0, 1, 120.0, 120.0, 24.0, 4000, 4250, true),
            Machine("SHF-0423", "AST-CAT308-1", "FLT-00423", "Caterpillar", "308 CR", "Excavators", "Midi Excavators", 2024, "SHF", "AVAILABLE", "EXCELLENT", 412, 55, 8750, 4.15, 6.9, 0.65, 195.0, 580.0, 1600.0, 1, 95.0, 95.0, 18.0, 250, 500, true),
            Machine("LND-1081", "AST-VOL25G-1", "FLT-01081", "Volvo", "A25G", "Dumpers", "Articulated Dump Trucks", 2021, "LND", "AVAILABLE", "GOOD", 6210, 235, 22400, null, null, 15.0, 650.0, 1950.0, 5400.0, 2, 250.0, 250.0, 55.0, 6000, 6500, true),
            Machine("LND-1082", "AST-JCB540-1", "FLT-01082", "JCB", "540-170", "Telehandlers", "Telehandlers", 2023, "LND", "AVAILABLE", "EXCELLENT", 1120, 81, 12160, null, 17.0, 4.0, 310.0, 930.0, 2600.0, 1, 130.0, 130.0, 26.0, 1000, 1250, true),
            Machine("LND-1083", "AST-GENS65-1", "FLT-01083", "Genie", "S-65 XC", "Facilities", "Boom Lifts", 2022, "LND", "MAINTENANCE", "FAIR", 3120, 36, 11400, null, 21.8, 0.3, 240.0, 720.0, 1950.0, 1, 110.0, 110.0, 20.0, 3000, 3150, false),
            Machine("MCR-0871", "AST-CAT320-1", "FLT-00871", "Caterpillar", "320 GC", "Excavators", "Tracked Excavators", 2023, "MCR", "ON_HIRE", "EXCELLENT", 1845, 110, 20500, 6.63, 9.7, 1.2, 410.0, 1230.0, 3300.0, 1, 140.0, 140.0, 35.0, 1500, 2000, true),
            Machine("MCR-0872", "AST-MAN625-1", "FLT-00872", "Manitou", "MT625", "Telehandlers", "Telehandlers", 2022, "MCR", "AVAILABLE", "GOOD", 1950, 55, 4800, null, 5.85, 2.5, 185.0, 555.0, 1500.0, 1, 90.0, 90.0, 16.0, 1800, 2000, true),
            Machine("BRM-0521", "AST-THW6T-1", "FLT-00521", "Thwaites", "6 Tonne Power Swivel", "Dumpers", "Site Dumpers", 2023, "BRM", "AVAILABLE", "EXCELLENT", 815, 55, 4420, null, null, 6.0, 165.0, 495.0, 1350.0, 1, 85.0, 85.0, 14.0, 500, 1000, true),
            Machine("BRM-0522", "AST-GEN193-1", "FLT-00522", "Genie", "GS-1932", "Facilities", "Scissor Lifts", 2024, "BRM", "AVAILABLE", "EXCELLENT", 92, 0, 1500, null, 7.8, 0.23, 85.0, 255.0, 720.0, 1, 65.0, 65.0, 8.0, 50, 250, false),
            Machine("BRS-0611", "AST-JCB19C-1", "FLT-00611", "JCB", "19C-1", "Excavators", "Mini Excavators", 2023, "BRS", "AVAILABLE", "EXCELLENT", 650, 12, 1910, 2.57, 4.22, 0.15, 115.0, 345.0, 950.0, 1, 75.0, 75.0, 10.0, 500, 1000, true),
            Machine("GLG-0991", "AST-CUM150-1", "FLT-00991", "Cummins", "C150D5 Power", "Energy", "Generators", 2021, "GLG", "AVAILABLE", "GOOD", 5120, 120, 2200, null, null, 150.0, 140.0, 420.0, 1150.0, 1, 100.0, 100.0, 12.0, 5000, 5250, true),
            Machine("CDF-0411", "AST-CAT428-1", "FLT-00411", "Caterpillar", "428 Backhoe", "Excavators", "Backhoe Loaders", 2022, "CDF", "AVAILABLE", "GOOD", 2320, 70, 8400, 5.7, 6.6, 1.0, 275.0, 825.0, 2250.0, 1, 115.0, 115.0, 22.0, 2000, 2500, true),
            Machine("LDS-0221", "AST-MAN184-1", "FLT-00221", "Manitou", "MT1840", "Telehandlers", "Telehandlers", 2023, "LDS", "AVAILABLE", "EXCELLENT", 890, 75, 11700, null, 18.0, 4.0, 330.0, 990.0, 2750.0, 1, 135.0, 135.0, 28.0, 500, 1000, true),
            Machine("LDS-0222", "AST-JCB220-2", "FLT-00222", "JCB", "220X", "Excavators", "Tracked Excavators", 2024, "LDS", "RESERVED", "EXCELLENT", 180, 129, 22400, 6.72, 9.8, 1.5, 425.0, 1275.0, 3400.0, 1, 145.0, 145.0, 36.0, 150, 500, true)
        )
        db.machineDao().insertMachines(seedMachines)

        // Seed 3 additional machines to create a robust pool
        val moreMachines = listOf(
            Machine("SHF-0424", "AST-TER6T-1", "FLT-00424", "Terex", "TA6S", "Dumpers", "Site Dumpers", 2022, "SHF", "AVAILABLE", "GOOD", 1890, 55, 4410, null, null, 6.0, 155.0, 465.0, 1250.0, 1, 85.0, 85.0, 12.0, 1500, 2000, true),
            Machine("SHF-0425", "AST-JCB19C-2", "FLT-00425", "JCB", "19C-1", "Excavators", "Mini Excavators", 2024, "SHF", "AVAILABLE", "EXCELLENT", 120, 12, 1910, 2.57, 4.22, 0.15, 115.0, 345.0, 950.0, 1, 75.0, 75.0, 10.0, 100, 500, true),
            Machine("LND-1084", "AST-JCB220-3", "FLT-01084", "JCB", "220X", "Excavators", "Tracked Excavators", 2023, "LND", "ON_HIRE", "GOOD", 1420, 129, 22400, 6.72, 9.8, 1.5, 425.0, 1275.0, 3400.0, 1, 145.0, 145.0, 36.0, 1000, 2000, true)
        )
        db.machineDao().insertMachines(moreMachines)

        // Let's seed a historical quote and active hire contract so that they are present initially.
        val quote1 = Quote(
            id = "QTE-5821",
            customerName = "Sir Robert McAlpine Ltd",
            customerEmail = "procurement@mcalpine-group.co.uk",
            projectName = "Sheffield Retail Centre Redevelopment",
            projectPostcode = "S1 2JA",
            machineId = "SHF-0422",
            startDate = "2026-09-18",
            endDate = "2026-09-25",
            numDays = 7,
            machineHireCost = 850.0, // weekly rate
            attachmentCost = 175.0, // breaker at £25/day * 7
            deliveryCost = 120.0,
            collectionCost = 120.0,
            damageWaiverCost = 168.0, // £24/day * 7
            operatorCost = 0.0,
            subtotal = 1433.0,
            vat = 286.60,
            grandTotal = 1719.60,
            expiryDate = "2026-09-20",
            selectedAttachments = "ATT-B60,ATT-BH15",
            operatorRequired = false,
            status = "ACCEPTED"
        )
        db.quoteDao().insertQuote(quote1)

        val hire1 = Hire(
            id = "HIR-3042",
            quoteId = "QTE-5821",
            customerName = "Sir Robert McAlpine Ltd",
            customerEmail = "procurement@mcalpine-group.co.uk",
            projectName = "Sheffield Retail Centre Redevelopment",
            projectPostcode = "S1 2JA",
            machineId = "SHF-0422",
            startDate = "2026-09-18",
            expectedReturnDate = "2026-09-25",
            actualReturnDate = null,
            status = "ON_HIRE",
            machineHireCost = 850.0,
            attachmentCost = 175.0,
            deliveryCost = 120.0,
            collectionCost = 120.0,
            damageWaiverCost = 168.0,
            operatorCost = 0.0,
            subtotal = 1433.0,
            vat = 286.60,
            grandTotal = 1719.60,
            meterStart = 4120,
            meterEnd = null,
            telemetryHours = 4148,
            selectedAttachments = "ATT-B60,ATT-BH15",
            operatorRequired = false,
            offHireRequestedAt = null,
            extensionDays = 0
        )
        db.hireDao().insertHire(hire1)

        val invoice1 = Invoice(
            id = "INV-7281",
            hireId = "HIR-3042",
            customerName = "Sir Robert McAlpine Ltd",
            customerEmail = "procurement@mcalpine-group.co.uk",
            dateCreated = "2026-09-18",
            subtotal = 1433.0,
            vat = 286.60,
            grandTotal = 1719.60,
            status = "PAID"
        )
        db.invoiceDao().insertInvoice(invoice1)

        // Seed 2 more active hires to fill up the graphs nicely
        val quote2 = Quote(
            id = "QTE-6101",
            customerName = "Balfour Beatty plc",
            customerEmail = "site-manager@balfour-beatty.co.uk",
            projectName = "M6 Motorway Smart Link Up",
            projectPostcode = "M17 1AT",
            machineId = "MCR-0871",
            startDate = "2026-09-20",
            endDate = "2026-09-27",
            numDays = 7,
            machineHireCost = 1230.0,
            attachmentCost = 245.0,
            deliveryCost = 140.0,
            collectionCost = 140.0,
            damageWaiverCost = 245.0,
            operatorCost = 1750.0,
            subtotal = 3750.0,
            vat = 750.0,
            grandTotal = 4500.0,
            expiryDate = "2026-09-20",
            selectedAttachments = "ATT-B90,ATT-HMC",
            operatorRequired = true,
            status = "ACCEPTED"
        )
        db.quoteDao().insertQuote(quote2)

        val hire2 = Hire(
            id = "HIR-3045",
            quoteId = "QTE-6101",
            customerName = "Balfour Beatty plc",
            customerEmail = "site-manager@balfour-beatty.co.uk",
            projectName = "M6 Motorway Smart Link Up",
            projectPostcode = "M17 1AT",
            machineId = "MCR-0871",
            startDate = "2026-09-20",
            expectedReturnDate = "2026-09-27",
            actualReturnDate = null,
            status = "ON_HIRE",
            machineHireCost = 1230.0,
            attachmentCost = 245.0,
            deliveryCost = 140.0,
            collectionCost = 140.0,
            damageWaiverCost = 245.0,
            operatorCost = 1750.0,
            subtotal = 3750.0,
            vat = 750.0,
            grandTotal = 4500.0,
            meterStart = 1845,
            meterEnd = null,
            telemetryHours = 1862,
            selectedAttachments = "ATT-B90,ATT-HMC",
            operatorRequired = true,
            offHireRequestedAt = null,
            extensionDays = 0
        )
        db.hireDao().insertHire(hire2)

        val invoice2 = Invoice(
            id = "INV-7285",
            hireId = "HIR-3045",
            customerName = "Balfour Beatty plc",
            customerEmail = "site-manager@balfour-beatty.co.uk",
            dateCreated = "2026-09-20",
            subtotal = 3750.0,
            vat = 750.0,
            grandTotal = 4500.0,
            status = "UNPAID"
        )
        db.invoiceDao().insertInvoice(invoice2)

        // Seed Audit Logs
        db.auditLogDao().insertLog(
            AuditLog(
                timestamp = System.currentTimeMillis() - 86400000 * 2,
                user = "FLEET_MANAGER",
                event = "SYSTEM_INITIALIZED",
                machineId = "",
                oldVal = "",
                newVal = "ACTIVE",
                reason = "Database populated with standard Anglo-industrial machine taxonomy."
            )
        )
        db.auditLogDao().insertLog(
            AuditLog(
                timestamp = System.currentTimeMillis() - 86400000,
                user = "FLEET_MANAGER",
                event = "RATE_OVERRIDE_CREATED",
                machineId = "SHF-0421",
                oldVal = "£450/day",
                newVal = "£425/day",
                reason = "Regional adjustment for Yorkshire market conditions."
            )
        )
    }
}
