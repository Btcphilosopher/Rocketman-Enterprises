package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "depots")
data class Depot(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val postcode: String,
    val region: String,
    val deliveryRadiusKm: Double,
    val contactNumber: String
)

@Entity(tableName = "machines")
data class Machine(
    @PrimaryKey val id: String, // SHF-0421
    val assetId: String,
    val fleetNumber: String,
    val manufacturer: String,
    val model: String,
    val category: String, // Excavators, Loaders, Dumpers, Telehandlers, Access Platforms
    val subcategory: String, // Tracked Excavators, Mini Excavators, Midi Excavators
    val year: Int,
    val depotId: String,
    val status: String, // AVAILABLE, RESERVED, ON_HIRE, RETURNING, MAINTENANCE, INSPECTION, DAMAGED, QUARANTINED, TRANSPORT
    val condition: String, // EXCELLENT, GOOD, FAIR
    val operatingHours: Int,
    val powerKw: Int,
    val weightKg: Int,
    val maxDigDepthM: Double?,
    val maxReachM: Double?,
    val capacityTons: Double?,
    val dayRate: Double,
    val weeklyRate: Double,
    val fourWeekRate: Double,
    val minHireDays: Int,
    val deliveryCost: Double,
    val collectionCost: Double,
    val damageWaiverRate: Double,
    val lastServiceHours: Int,
    val nextServiceHours: Int,
    val telemetryEnabled: Boolean
) {
    val displayCategory: String get() = subcategory.uppercase()
    val weightTonnes: Double get() = weightKg / 1000.0
}

@Entity(tableName = "attachments")
data class Attachment(
    @PrimaryKey val id: String,
    val name: String,
    val compatibleCategory: String, // e.g. "Excavators" or "Telehandlers"
    val dayRate: Double
)

@Entity(tableName = "quotes")
data class Quote(
    @PrimaryKey val id: String,
    val customerName: String,
    val customerEmail: String,
    val projectName: String,
    val projectPostcode: String,
    val machineId: String,
    val startDate: String, // YYYY-MM-DD
    val endDate: String, // YYYY-MM-DD
    val numDays: Int,
    val machineHireCost: Double,
    val attachmentCost: Double,
    val deliveryCost: Double,
    val collectionCost: Double,
    val damageWaiverCost: Double,
    val operatorCost: Double,
    val subtotal: Double,
    val vat: Double,
    val grandTotal: Double,
    val expiryDate: String,
    val selectedAttachments: String, // comma-separated attachment IDs
    val operatorRequired: Boolean,
    val status: String // QUOTE_CREATED, ACCEPTED, EXPIRED
)

@Entity(tableName = "hires")
data class Hire(
    @PrimaryKey val id: String, // HIRE-1001
    val quoteId: String,
    val customerName: String,
    val customerEmail: String,
    val projectName: String,
    val projectPostcode: String,
    val machineId: String,
    val startDate: String,
    val expectedReturnDate: String,
    val actualReturnDate: String?,
    val status: String, // RESERVED, CONFIRMED, DISPATCHED, ON_HIRE, EXTENSION_REQUESTED, EXTENDED, OFF_HIRE_REQUESTED, RETURNING, RETURNED, INSPECTED, CLOSED
    val machineHireCost: Double,
    val attachmentCost: Double,
    val deliveryCost: Double,
    val collectionCost: Double,
    val damageWaiverCost: Double,
    val operatorCost: Double,
    val subtotal: Double,
    val vat: Double,
    val grandTotal: Double,
    val meterStart: Int,
    val meterEnd: Int?,
    val telemetryHours: Int,
    val selectedAttachments: String,
    val operatorRequired: Boolean,
    val offHireRequestedAt: String?,
    val extensionDays: Int
)

@Entity(tableName = "invoices")
data class Invoice(
    @PrimaryKey val id: String,
    val hireId: String,
    val customerName: String,
    val customerEmail: String,
    val dateCreated: String,
    val subtotal: Double,
    val vat: Double,
    val grandTotal: Double,
    val status: String // UNPAID, PAID
)

@Entity(tableName = "audit_logs")
data class AuditLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: Long,
    val user: String,
    val event: String,
    val machineId: String,
    val oldVal: String,
    val newVal: String,
    val reason: String
)
