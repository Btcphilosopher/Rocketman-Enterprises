package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface DepotDao {
    @Query("SELECT * FROM depots")
    fun getAllDepots(): Flow<List<Depot>>

    @Query("SELECT * FROM depots WHERE id = :id")
    suspend fun getDepotById(id: String): Depot?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDepots(depots: List<Depot>)
}

@Dao
interface MachineDao {
    @Query("SELECT * FROM machines")
    fun getAllMachines(): Flow<List<Machine>>

    @Query("SELECT * FROM machines WHERE id = :id")
    suspend fun getMachineById(id: String): Machine?

    @Query("SELECT * FROM machines WHERE id = :id")
    fun getMachineByIdFlow(id: String): Flow<Machine?>

    @Query("SELECT * FROM machines WHERE status = :status")
    fun getMachinesByStatus(status: String): Flow<List<Machine>>

    @Query("SELECT * FROM machines WHERE depotId = :depotId")
    fun getMachinesByDepot(depotId: String): Flow<List<Machine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMachines(machines: List<Machine>)

    @Update
    suspend fun updateMachine(machine: Machine)

    @Query("UPDATE machines SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("UPDATE machines SET operatingHours = :hours WHERE id = :id")
    suspend fun updateHours(id: String, hours: Int)

    // Advanced search query
    @Query("""
        SELECT * FROM machines 
        WHERE (:category IS NULL OR category = :category) 
        AND (:depotId IS NULL OR depotId = :depotId)
        AND (:maxDayRate IS NULL OR dayRate <= :maxDayRate)
        AND (:minWeight IS NULL OR weightKg >= :minWeight)
        AND (:maxWeight IS NULL OR weightKg <= :maxWeight)
    """)
    fun searchMachines(
        category: String?,
        depotId: String?,
        maxDayRate: Double?,
        minWeight: Int?,
        maxWeight: Int?
    ): Flow<List<Machine>>
}

@Dao
interface AttachmentDao {
    @Query("SELECT * FROM attachments")
    fun getAllAttachments(): Flow<List<Attachment>>

    @Query("SELECT * FROM attachments WHERE compatibleCategory = :category")
    suspend fun getCompatibleAttachments(category: String): List<Attachment>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttachments(attachments: List<Attachment>)
}

@Dao
interface QuoteDao {
    @Query("SELECT * FROM quotes ORDER BY id DESC")
    fun getAllQuotes(): Flow<List<Quote>>

    @Query("SELECT * FROM quotes WHERE id = :id")
    suspend fun getQuoteById(id: String): Quote?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuote(quote: Quote)

    @Update
    suspend fun updateQuote(quote: Quote)
}

@Dao
interface HireDao {
    @Query("SELECT * FROM hires ORDER BY startDate DESC")
    fun getAllHires(): Flow<List<Hire>>

    @Query("SELECT * FROM hires WHERE id = :id")
    suspend fun getHireById(id: String): Hire?

    @Query("SELECT * FROM hires WHERE id = :id")
    fun getHireByIdFlow(id: String): Flow<Hire?>

    @Query("SELECT * FROM hires WHERE status = :status")
    fun getHiresByStatus(status: String): Flow<List<Hire>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHire(hire: Hire)

    @Update
    suspend fun updateHire(hire: Hire)

    @Query("""
        UPDATE hires 
        SET expectedReturnDate = :newExpectedReturn, 
            extensionDays = extensionDays + :addedDays,
            subtotal = :newSubtotal,
            vat = :newVat,
            grandTotal = :newGrandTotal,
            status = 'EXTENDED'
        WHERE id = :id
    """)
    suspend fun extendHire(
        id: String,
        addedDays: Int,
        newExpectedReturn: String,
        newSubtotal: Double,
        newVat: Double,
        newGrandTotal: Double
    )

    @Query("UPDATE hires SET status = 'OFF_HIRE_REQUESTED', offHireRequestedAt = :offHireTime WHERE id = :id")
    suspend fun requestOffHire(id: String, offHireTime: String)
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices ORDER BY id DESC")
    fun getAllInvoices(): Flow<List<Invoice>>

    @Query("SELECT * FROM invoices WHERE id = :id")
    suspend fun getInvoiceById(id: String): Invoice?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: Invoice)

    @Query("UPDATE invoices SET status = 'PAID' WHERE id = :id")
    suspend fun markAsPaid(id: String)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<AuditLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: AuditLog)
}
