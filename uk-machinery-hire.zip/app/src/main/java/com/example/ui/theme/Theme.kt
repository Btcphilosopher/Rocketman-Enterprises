package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = Brass,
    secondary = Steel,
    tertiary = BritishGreenLight,
    background = Charcoal,
    surface = Graphite,
    onPrimary = OffBlack,
    onSecondary = OffWhite,
    onBackground = OffWhite,
    onSurface = OffWhite
)

private val LightColorScheme = lightColorScheme(
    primary = BritishGreen,
    secondary = Steel,
    tertiary = Brass,
    background = OffWhite,
    surface = OffWhite,
    onPrimary = OffWhite,
    onSecondary = OffBlack,
    onBackground = OffBlack,
    onSurface = OffBlack
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
