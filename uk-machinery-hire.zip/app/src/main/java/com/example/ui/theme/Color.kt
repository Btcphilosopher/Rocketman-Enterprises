package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BritishGreen = Color(0xFF0A3C2A)
val BritishGreenLight = Color(0xFFE6EFEA)
val Charcoal = Color(0xFF151716)
val Graphite = Color(0xFF232524)
val Steel = Color(0xFF4A5560)
val SteelLight = Color(0xFFEAECEE)
val Brass = Color(0xFFB5892F)
val Oxblood = Color(0xFF6B1D2F)
val MutedBlue = Color(0xFF3B5D7A)
val OffWhite = Color(0xFFF9FAF9)
val OffBlack = Color(0xFF0B0C0C)
val BorderColor = Color(0xFFD0D4D2)
val WarningOrange = Color(0xFFD97706)
val GreenActive = Color(0xFF15803D)
