package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class PlantHireViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = PlantHireRepository(db)

    // Observables
    val depots = repository.allDepots.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val machines = repository.allMachines.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val attachments = repository.allAttachments.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val quotes = repository.allQuotes.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val hires = repository.allHires.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val invoices = repository.allInvoices.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val auditLogs = repository.allAuditLogs.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // Search filters
    private val _searchCategory = MutableStateFlow("All")
    val searchCategory = _searchCategory.asStateFlow()

    private val _searchDepot = MutableStateFlow("All")
    val searchDepot = _searchDepot.asStateFlow()

    private val _searchMaxDayRate = MutableStateFlow<Double?>(null)
    val searchMaxDayRate = _searchMaxDayRate.asStateFlow()

    private val _searchPostcode = MutableStateFlow("S1")
    val searchPostcode = _searchPostcode.asStateFlow()

    private val _searchStartDate = MutableStateFlow("2026-10-01")
    val searchStartDate = _searchStartDate.asStateFlow()

    private val _searchEndDate = MutableStateFlow("2026-10-08")
    val searchEndDate = _searchEndDate.asStateFlow()

    // Calculated days
    val searchDurationDays: StateFlow<Int> = combine(searchStartDate, searchEndDate) { start, end ->
        try {
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.UK)
            val d1 = format.parse(start)!!
            val d2 = format.parse(end)!!
            val diff = d2.time - d1.time
            val days = (diff / (1000 * 60 * 60 * 24)).toInt()
            if (days < 1) 1 else days
        } catch (e: Exception) {
            7
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 7)

    // Filtered machines
    val filteredMachines: StateFlow<List<Machine>> = combine(
        machines,
        searchCategory,
        searchDepot,
        searchMaxDayRate
    ) { list, cat, depot, maxRate ->
        var result = list
        if (cat != "All" && cat.isNotEmpty()) {
            result = result.filter { it.category == cat }
        }
        if (depot != "All" && depot.isNotEmpty()) {
            result = result.filter { it.depotId == depot }
        }
        if (maxRate != null) {
            result = result.filter { it.dayRate <= maxRate }
        }
        result
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Quotation Building
    private val _selectedMachineForQuote = MutableStateFlow<Machine?>(null)
    val selectedMachineForQuote = _selectedMachineForQuote.asStateFlow()

    private val _quoteSelectedAttachments = MutableStateFlow<Set<Attachment>>(emptySet())
    val quoteSelectedAttachments = _quoteSelectedAttachments.asStateFlow()

    val quoteOperatorRequired = MutableStateFlow(false)
    val quoteTransportRequired = MutableStateFlow(true)

    // Customer details
    val quoteCustomerName = MutableStateFlow("Sir Robert McAlpine Ltd")
    val quoteCustomerEmail = MutableStateFlow("procurement@mcalpine-group.co.uk")
    val quoteProjectName = MutableStateFlow("Sheffield Bypass Link")
    val quoteProjectPostcode = MutableStateFlow("S1 2JA")

    // Active Quote result
    private val _activeQuote = MutableStateFlow<Quote?>(null)
    val activeQuote = _activeQuote.asStateFlow()

    // Simulator Scenario
    private val _currentScenario = MutableStateFlow("Standard Market")
    val currentScenario = _currentScenario.asStateFlow()

    // Navigation and screen states (simple custom state management)
    private val _currentScreen = MutableStateFlow("control_centre")
    val currentScreen = _currentScreen.asStateFlow()

    // Drill down
    val selectedMachineId = MutableStateFlow<String?>(null)
    val selectedHireId = MutableStateFlow<String?>(null)
    val selectedDepotId = MutableStateFlow<String?>(null)

    init {
        // Automatically seed database if empty
        viewModelScope.launch {
            repository.seedDatabase()
        }
    }

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun setSearchFilters(category: String, depotId: String, maxRate: Double?, postcode: String, start: String, end: String) {
        _searchCategory.value = category
        _searchDepot.value = depotId
        _searchMaxDayRate.value = maxRate
        _searchPostcode.value = postcode
        _searchStartDate.value = start
        _searchEndDate.value = end
    }

    fun selectMachineForQuote(machine: Machine) {
        _selectedMachineForQuote.value = machine
        _quoteSelectedAttachments.value = emptySet()
        quoteOperatorRequired.value = false
        quoteTransportRequired.value = true
        _activeQuote.value = null
    }

    fun toggleAttachmentSelection(attachment: Attachment) {
        val current = _quoteSelectedAttachments.value.toMutableSet()
        if (current.contains(attachment)) {
            current.remove(attachment)
        } else {
            current.add(attachment)
        }
        _quoteSelectedAttachments.value = current
    }

    fun calculatePricingSummary(machine: Machine, days: Int): PricingSummary {
        // Business logic: Day-Rate pricing engine
        // Base Day Rate: dayRate
        // 1 day: dayRate
        // 2-6 days: blends dayRate with weeklyRate. We use a professional curves:
        // Weekly Rate covers up to 7 days. If days >= 7, we calculate weekly increments.
        val baseHireCost = when {
            days == 1 -> machine.dayRate
            days in 2..6 -> {
                // weeklyRate / 3.0 or slightly adjusted
                val dailyBlend = machine.weeklyRate / 3.0
                dailyBlend * days
            }
            days in 7..27 -> {
                val weeks = days / 7
                val extraDays = days % 7
                val extraDayPrice = machine.weeklyRate / 4.0
                (weeks * machine.weeklyRate) + (extraDays * extraDayPrice)
            }
            else -> {
                val fourWeeks = days / 28
                val extraDays = days % 28
                val extraDayPrice = machine.weeklyRate / 4.0
                (fourWeeks * machine.fourWeekRate) + (extraDays * extraDayPrice)
            }
        }

        // Apply Market Simulator Scenarios
        val scenarioMultiplier = when (_currentScenario.value) {
            "Construction Boom" -> 1.25 // +25% rates
            "Winter Slowdown" -> 0.85 // -15% rates
            "Machine Shortage" -> 1.40 // +40% rates
            "Fuel-Price Shock" -> 1.10 // +10% rates
            else -> 1.0
        }

        val adjustedBaseHire = baseHireCost * scenarioMultiplier

        // Attachments
        val attachDailyTotal = _quoteSelectedAttachments.value.sumOf { it.dayRate }
        val attachmentCost = attachDailyTotal * days

        // Logistics (Delivery & Collection)
        val delivery = if (quoteTransportRequired.value) machine.deliveryCost else 0.0
        val collection = if (quoteTransportRequired.value) machine.collectionCost else 0.0

        // Damage waiver
        val waiver = machine.damageWaiverRate * days

        // Operator Cost: standard £250/day if required
        val operator = if (quoteOperatorRequired.value) 250.0 * days else 0.0

        val subtotal = adjustedBaseHire + attachmentCost + delivery + collection + waiver + operator
        val vat = subtotal * 0.20
        val grandTotal = subtotal + vat

        return PricingSummary(
            machineBaseCost = adjustedBaseHire,
            attachmentCost = attachmentCost,
            deliveryCost = delivery,
            collectionCost = collection,
            damageWaiverCost = waiver,
            operatorCost = operator,
            subtotal = subtotal,
            vat = vat,
            grandTotal = grandTotal
        )
    }

    fun generateQuote() {
        val machine = _selectedMachineForQuote.value ?: return
        val days = searchDurationDays.value
        val summary = calculatePricingSummary(machine, days)

        viewModelScope.launch {
            val quoteId = "QTE-${(1000..9999).random()}"
            val expiryCalendar = Calendar.getInstance()
            expiryCalendar.add(Calendar.DAY_OF_YEAR, 3)
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.UK)

            val quote = Quote(
                id = quoteId,
                customerName = quoteCustomerName.value,
                customerEmail = quoteCustomerEmail.value,
                projectName = quoteProjectName.value,
                projectPostcode = quoteProjectPostcode.value,
                machineId = machine.id,
                startDate = _searchStartDate.value,
                endDate = _searchEndDate.value,
                numDays = days,
                machineHireCost = summary.machineBaseCost,
                attachmentCost = summary.attachmentCost,
                deliveryCost = summary.deliveryCost,
                collectionCost = summary.collectionCost,
                damageWaiverCost = summary.damageWaiverCost,
                operatorCost = summary.operatorCost,
                subtotal = summary.subtotal,
                vat = summary.vat,
                grandTotal = summary.grandTotal,
                expiryDate = dateFormat.format(expiryCalendar.time),
                selectedAttachments = _quoteSelectedAttachments.value.joinToString(",") { it.id },
                operatorRequired = quoteOperatorRequired.value,
                status = "QUOTE_CREATED"
            )

            repository.createQuote(quote)
            _activeQuote.value = quote
            navigateTo("quote_summary")
        }
    }

    fun convertActiveQuoteToBooking() {
        val quote = _activeQuote.value ?: return
        viewModelScope.launch {
            val machine = repository.getMachineById(quote.machineId)
            val meterStart = machine?.operatingHours ?: 1200
            val hire = repository.createHireFromQuote(quote, meterStart)
            _activeQuote.value = null
            selectedHireId.value = hire.id
            navigateTo("hire_detail")
        }
    }

    // Hire state transitions
    fun dispatchMachine(hireId: String) {
        viewModelScope.launch {
            repository.updateHireStatus(
                hireId = hireId,
                newStatus = "DISPATCHED",
                user = "DEPOT_MANAGER",
                reason = "Low-loader dispatched from depot with asset payload."
            )
        }
    }

    fun startHire(hireId: String) {
        viewModelScope.launch {
            repository.updateHireStatus(
                hireId = hireId,
                newStatus = "ON_HIRE",
                user = "SITE_MANAGER",
                reason = "Machine delivered to site, inspection completed, signed off on hire."
            )
        }
    }

    fun extendHire(hireId: String, days: Int) {
        viewModelScope.launch {
            repository.extendHire(hireId, days)
        }
    }

    fun requestOffHire(hireId: String) {
        viewModelScope.launch {
            repository.requestOffHire(hireId)
        }
    }

    fun completeReturn(hireId: String, currentMeter: Int) {
        viewModelScope.launch {
            val hire = db.hireDao().getHireById(hireId) ?: return@launch
            // Update hire to store meter end
            val updated = hire.copy(meterEnd = currentMeter, status = "RETURNED")
            db.hireDao().updateHire(updated)

            // Transition machine to inspection
            repository.updateHireStatus(
                hireId = hireId,
                newStatus = "RETURNED",
                user = "DEPOT_ENGINEER",
                reason = "Machine returned to depot. Logged meter at $currentMeter h. Queued for engineer inspection."
            )
        }
    }

    fun completeInspectionAndClose(hireId: String, condition: String) {
        viewModelScope.launch {
            val hire = db.hireDao().getHireById(hireId) ?: return@launch
            val machine = db.machineDao().getMachineById(hire.machineId)
            if (machine != null) {
                // update condition
                db.machineDao().updateMachine(machine.copy(condition = condition, status = "AVAILABLE"))
            }

            repository.updateHireStatus(
                hireId = hireId,
                newStatus = "CLOSED",
                user = "DEPOT_ENGINEER",
                reason = "Thorough statutory safety inspection completed. Condition marked as $condition. Asset released to active fleet."
            )
        }
    }

    fun overrideRate(machineId: String, newRate: Double, reason: String) {
        viewModelScope.launch {
            repository.updateMachineRate(machineId, newRate, reason)
        }
    }

    fun payInvoice(invoiceId: String) {
        viewModelScope.launch {
            repository.markInvoicePaid(invoiceId)
        }
    }

    fun selectScenario(scenario: String) {
        _currentScenario.value = scenario
        viewModelScope.launch {
            repository.addAuditLog(
                user = "SYSTEM_SIMULATOR",
                event = "MARKET_SCENARIO_UPDATED",
                machineId = "",
                oldVal = "",
                newVal = scenario,
                reason = "Market simulator state changed to $scenario. Adjusting fleet pricing dynamics."
            )
        }
    }
}

data class PricingSummary(
    val machineBaseCost: Double,
    val attachmentCost: Double,
    val deliveryCost: Double,
    val collectionCost: Double,
    val damageWaiverCost: Double,
    val operatorCost: Double,
    val subtotal: Double,
    val vat: Double,
    val grandTotal: Double
)
