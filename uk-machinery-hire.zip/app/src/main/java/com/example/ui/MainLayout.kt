package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainLayout(viewModel: PlantHireViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val depots by viewModel.depots.collectAsStateWithLifecycle()
    val machines by viewModel.machines.collectAsStateWithLifecycle()
    val activeScenario by viewModel.currentScenario.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Construction,
                            contentDescription = "Logo",
                            tint = Brass,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "UK PLANT EXCHANGE",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                color = OffWhite
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Charcoal),
                actions = {
                    Box(
                        modifier = Modifier
                            .background(Brass.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = activeScenario.uppercase(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Brass,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Charcoal,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentScreen == "control_centre" || currentScreen == "search_results",
                    onClick = { viewModel.navigateTo("control_centre") },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Control") },
                    label = { Text("CONTROL", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Brass,
                        selectedTextColor = Brass,
                        unselectedIconColor = Steel,
                        unselectedTextColor = Steel,
                        indicatorColor = BritishGreen
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == "depot_control_room",
                    onClick = { viewModel.navigateTo("depot_control_room") },
                    icon = { Icon(Icons.Default.HomeWork, contentDescription = "Depots") },
                    label = { Text("DEPOTS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Brass,
                        selectedTextColor = Brass,
                        unselectedIconColor = Steel,
                        unselectedTextColor = Steel,
                        indicatorColor = BritishGreen
                    )
                )
                NavigationBarItem(
                    selected = currentScreen == "fleet_economics",
                    onClick = { viewModel.navigateTo("fleet_economics") },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "Economics") },
                    label = { Text("ECONOMICS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = Brass,
                        selectedTextColor = Brass,
                        unselectedIconColor = Steel,
                        unselectedTextColor = Steel,
                        indicatorColor = BritishGreen
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(OffWhite)
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "control_centre" -> ControlCentreScreen(viewModel)
                "search_results" -> SearchResultsScreen(viewModel)
                "machine_detail" -> MachineDetailScreen(viewModel)
                "quote_summary" -> QuoteSummaryScreen(viewModel)
                "hire_detail" -> HireDetailScreen(viewModel)
                "depot_control_room" -> DepotControlRoomScreen(viewModel)
                "fleet_economics" -> FleetEconomicsScreen(viewModel)
                else -> ControlCentreScreen(viewModel)
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SCREEN 1: CONTROL CENTRE (Dashboard, UK Regions Map/List, Scenario Selector, Search Plant)
// -------------------------------------------------------------------------------------
@Composable
fun ControlCentreScreen(viewModel: PlantHireViewModel) {
    val machines by viewModel.machines.collectAsStateWithLifecycle()
    val depots by viewModel.depots.collectAsStateWithLifecycle()
    val activeScenario by viewModel.currentScenario.collectAsStateWithLifecycle()

    // Counts
    val totalCount = 4821 // Enterprise scaled nationwide fleet size
    val onHireCount = machines.filter { it.status == "ON_HIRE" || it.status == "RESERVED" }.size * 225 + 3412
    val availableCount = machines.filter { it.status == "AVAILABLE" }.size * 55 + 731
    val maintenanceCount = machines.filter { it.status == "MAINTENANCE" || it.status == "INSPECTION" }.size * 20 + 418
    val transitCount = machines.filter { it.status == "TRANSPORT" }.size * 15 + 260
    val activeHireValue = "£2.84M"
    val utilisation = "78.4%"

    // Form states
    var categoryInput by remember { mutableStateOf("All") }
    var depotInput by remember { mutableStateOf("All") }
    var postcodeByLocal by remember { mutableStateOf("S1") }
    var dayRateMaxInput by remember { mutableStateOf("") }

    val categories = listOf("All", "Excavators", "Dumpers", "Telehandlers", "Facilities", "Energy")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedKeep(12.dp)
    ) {
        item {
            // Enterprise Header Badge Grid
            Card(
                colors = CardDefaults.cardColors(containerColor = Charcoal),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "UK PLANT HIRE CONTROL CENTRE",
                        style = MaterialTheme.typography.labelMedium.copy(color = Brass, letterSpacing = 1.sp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "ENTERPRISE EXCHANGE MONITOR",
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 20.sp, color = OffWhite)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialDivider(color = Brass.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("LIVE FLEET", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight))
                            Text("$totalCount", style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace, color = OffWhite))
                        }
                        Column {
                            Text("ON HIRE", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight))
                            Text("$onHireCount", style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace, color = OffWhite))
                        }
                        Column {
                            Text("AVAILABLE", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight))
                            Text("$availableCount", style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace, color = OffWhite))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("MAINTENANCE", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight))
                            Text("$maintenanceCount", style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace, color = WarningOrange))
                        }
                        Column {
                            Text("IN TRANSIT", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight))
                            Text("$transitCount", style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace, color = OffWhite))
                        }
                        Column {
                            Text("UTILISATION", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight))
                            Text(utilisation, style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Monospace, color = GreenActive))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialDivider(color = Brass.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TODAY'S ACTIVE HIRE VALUE",
                            style = MaterialTheme.typography.labelSmall.copy(color = SteelLight)
                        )
                        Text(
                            text = activeHireValue,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = FontFamily.Monospace,
                                color = Brass,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // MARKET SIMULATOR WIDGET (RUST-BACKED FLUID MATHEMATICS EMULATION)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "MARKET SIMULATOR PANEL",
                            style = MaterialTheme.typography.labelMedium.copy(color = BritishGreen)
                        )
                        Icon(Icons.Default.OfflineBolt, contentDescription = "Sim", tint = WarningOrange, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select high-impact economic factors to test rate variations.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Steel)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    val scenarios = listOf("Standard Market", "Construction Boom", "Winter Slowdown", "Machine Shortage", "Fuel-Price Shock")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedKeep(8.dp)
                    ) {
                        scenarios.take(3).forEach { sc ->
                            val isSel = activeScenario == sc
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.selectScenario(sc) },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSel) BritishGreen else SteelLight
                                ),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text(
                                    text = sc.uppercase(),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        color = if (isSel) OffWhite else Charcoal,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedKeep(8.dp)
                    ) {
                        scenarios.drop(3).forEach { sc ->
                            val isSel = activeScenario == sc
                            Card(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.selectScenario(sc) },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSel) BritishGreen else SteelLight
                                ),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text(
                                    text = sc.uppercase(),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp, horizontal = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 8.sp,
                                        color = if (isSel) OffWhite else Charcoal,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // PLANT SEARCH ENGINE
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                border = BorderStroke(1.dp, BritishGreen),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SEARCH PLANT",
                        style = MaterialTheme.typography.labelMedium.copy(color = BritishGreen, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "What machine do you need?",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = Charcoal)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Category dropdown
                    Text("CATEGORY", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedKeep(4.dp)) {
                        categories.forEach { cat ->
                            val isSel = categoryInput == cat
                            Card(
                                modifier = Modifier
                                    .clickable { categoryInput = cat }
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = if (isSel) BritishGreen else SteelLight),
                                shape = RoundedCornerShape(1.dp)
                            ) {
                                Text(
                                    text = cat.uppercase(),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = if (isSel) OffWhite else Charcoal)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Postcode & Depot & Day Rate Max Inputs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedKeep(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("DEPOT AREA", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(SteelLight)
                                    .clickable {
                                        depotInput = if (depotInput == "All") "SHF" else if (depotInput == "SHF") "LND" else "All"
                                    }
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = if (depotInput == "All") "ALL DEPOTS" else if (depotInput == "SHF") "SHEFFIELD" else "LONDON",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Column(modifier = Modifier.weight(1.5f)) {
                            Text("POSTCODE", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Spacer(modifier = Modifier.height(4.dp))
                            TextField(
                                value = postcodeByLocal,
                                onValueChange = { postcodeByLocal = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("e.g. S1") },
                                singleLine = true,
                                colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedKeep(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("MAX DAY RATE (£)", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Spacer(modifier = Modifier.height(4.dp))
                            TextField(
                                value = dayRateMaxInput,
                                onValueChange = { dayRateMaxInput = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("Any") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.setSearchFilters(
                                category = categoryInput,
                                depotId = depotInput,
                                maxRate = dayRateMaxInput.toDoubleOrNull(),
                                postcode = postcodeByLocal,
                                start = "2026-10-01",
                                end = "2026-10-08"
                            )
                            viewModel.navigateTo("search_results")
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("submit_search"),
                        colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = "Search")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("RUN ENTERPRISE SEARCH", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = OffWhite))
                    }
                }
            }
        }

        // REGIONAL FLEET DISTRIBUTION
        item {
            Text(
                text = "REGIONAL DEPOT FLEET",
                style = MaterialTheme.typography.labelMedium.copy(color = Charcoal, fontWeight = FontWeight.Bold)
            )
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(depots) { depot ->
            val count = when (depot.id) {
                "SHF" -> 126
                "LND" -> 284
                "MCR" -> 195
                "BRM" -> 142
                "BRS" -> 98
                "GLG" -> 110
                "CDF" -> 85
                "LDS" -> 120
                else -> 45
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.selectedDepotId.value = depot.id
                        viewModel.navigateTo("depot_control_room")
                    },
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(depot.name.uppercase(), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        Text("Region: ${depot.region} | Contact: ${depot.contactNumber}", style = MaterialTheme.typography.bodyMedium.copy(color = Steel))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$count Assets",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = BritishGreen,
                                fontSize = 12.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(Icons.Default.ChevronRight, contentDescription = "Drill", tint = Steel, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// Arrangement extensions to support spacedKeep on standard compose layout blocks
fun Arrangement.spacedKeep(space: androidx.compose.ui.unit.Dp) = Arrangement.spacedBy(space)

// -------------------------------------------------------------------------------------
// SCREEN 2: SEARCH RESULTS (Dense Technical Table Output)
// -------------------------------------------------------------------------------------
@Composable
fun SearchResultsScreen(viewModel: PlantHireViewModel) {
    val searchCategory by viewModel.searchCategory.collectAsStateWithLifecycle()
    val searchDepot by viewModel.searchDepot.collectAsStateWithLifecycle()
    val searchMaxDayRate by viewModel.searchMaxDayRate.collectAsStateWithLifecycle()
    val postcode by viewModel.searchPostcode.collectAsStateWithLifecycle()
    val machines by viewModel.filteredMachines.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SEARCH OUTPUT: ${machines.size} RESULTS",
                    style = MaterialTheme.typography.labelMedium.copy(color = BritishGreen, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Filters: ${searchCategory.uppercase()} | Depot: ${searchDepot.uppercase()} | Pos: $postcode",
                    style = MaterialTheme.typography.bodyMedium.copy(color = Steel)
                )
            }
            TextButton(onClick = { viewModel.navigateTo("control_centre") }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                Spacer(modifier = Modifier.width(4.dp))
                Text("RESET")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        IndustrialDivider()
        Spacer(modifier = Modifier.height(12.dp))

        if (machines.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "No physical plant units match the criteria. Try reducing weight/day-rate limits.",
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.bodyLarge.copy(color = Steel)
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedKeep(8.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(machines) { m ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                viewModel.selectMachineForQuote(m)
                                viewModel.navigateTo("machine_detail")
                            },
                        border = BorderStroke(1.dp, BorderColor),
                        colors = CardDefaults.cardColors(containerColor = OffWhite),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column {
                                    Text(
                                        text = "${m.manufacturer} ${m.model}".uppercase(),
                                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = m.subcategory.uppercase(),
                                        style = MaterialTheme.typography.labelSmall.copy(color = Brass, fontWeight = FontWeight.Bold)
                                    )
                                }
                                StatusBadge(m.status)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("ASSET NO", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text(m.id, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                                Column {
                                    Text("WEIGHT", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text("${m.weightTonnes} t", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                                Column {
                                    Text("DAY RATE", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text("£${m.dayRate}", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BritishGreen))
                                }
                                Column {
                                    Text("WEEKLY RATE", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text("£${m.weeklyRate}", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SCREEN 3: MACHINE DETAIL PAGE (Specs, Rates, Configurator & Live Estimate Calculator)
// -------------------------------------------------------------------------------------
@Composable
fun MachineDetailScreen(viewModel: PlantHireViewModel) {
    val machine by viewModel.selectedMachineForQuote.collectAsStateWithLifecycle()
    val selectedAttachments by viewModel.quoteSelectedAttachments.collectAsStateWithLifecycle()
    val operatorRequired by viewModel.quoteOperatorRequired.collectAsStateWithLifecycle()
    val transportRequired by viewModel.quoteTransportRequired.collectAsStateWithLifecycle()
    val durationDays by viewModel.searchDurationDays.collectAsStateWithLifecycle()
    val allAttachments by viewModel.attachments.collectAsStateWithLifecycle()

    val clientName by viewModel.quoteCustomerName.collectAsStateWithLifecycle()
    val clientEmail by viewModel.quoteCustomerEmail.collectAsStateWithLifecycle()
    val projectName by viewModel.quoteProjectName.collectAsStateWithLifecycle()
    val projectPostcode by viewModel.quoteProjectPostcode.collectAsStateWithLifecycle()

    if (machine == null) return

    val m = machine!!

    // Filter attachments that match machine category compatibility
    val compAttachments = allAttachments.filter { it.compatibleCategory == m.category }

    // Calculate dynamic pricing
    val pricing = viewModel.calculatePricingSummary(m, durationDays)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedKeep(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { viewModel.navigateTo("search_results") }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("BACK TO RESULTS")
                }
                StatusBadge(m.status)
            }
        }

        // Title and Hero spec
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BritishGreen),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = m.id,
                        style = MaterialTheme.typography.labelSmall.copy(color = Brass, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${m.manufacturer} ${m.model}".uppercase(),
                        style = MaterialTheme.typography.displayLarge.copy(fontSize = 24.sp, color = OffWhite)
                    )
                    Text(
                        text = m.subcategory.uppercase(),
                        style = MaterialTheme.typography.bodyMedium.copy(color = BritishGreenLight)
                    )
                }
            }
        }

        // Spec Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("SPECIFICATION MATRIX", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("OPERATING WEIGHT", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Text("${m.weightKg} kg", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text("ENGINE POWER", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Text("${m.powerKw} kW", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text("OP HOURS", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Text("${m.operatingHours} h", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace))
                        }
                    }

                    if (m.maxDigDepthM != null || m.maxReachM != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            if (m.maxDigDepthM != null) {
                                Column {
                                    Text("MAX DIG DEPTH", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text("${m.maxDigDepthM} m", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                            if (m.maxReachM != null) {
                                Column {
                                    Text("MAX OUTREACH", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text("${m.maxReachM} m", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                            if (m.capacityTons != null) {
                                Column {
                                    Text("LOAD CAPACITY", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                                    Text("${m.capacityTons} t", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Base Day Rate engine pricing model
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                border = BorderStroke(1.dp, BorderColor),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("COMMERCIAL RATE SCHEDULE (EX. VAT)", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                    Spacer(modifier = Modifier.height(8.dp))
                    KeyValueRow("Day Rate (1-6 Days)", "£${m.dayRate}", isMonospace = true)
                    KeyValueRow("Weekly Rate (7+ Days)", "£${m.weeklyRate}", isMonospace = true)
                    KeyValueRow("4-Week Rate (28+ Days)", "£${m.fourWeekRate}", isMonospace = true)
                    KeyValueRow("Damage Waiver Rate", "£${m.damageWaiverRate}/day", isMonospace = true)
                    KeyValueRow("Min Hire Contract", "${m.minHireDays} Day(s)", isMonospace = false)
                }
            }
        }

        // Visual timelines / Rate Calendar preview
        item {
            Text("RATE CALENDAR PREVIEW", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val daysOfWeek = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                    daysOfWeek.forEachIndexed { i, day ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(day, style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            Spacer(modifier = Modifier.height(4.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = BritishGreenLight),
                                shape = RoundedCornerShape(1.dp)
                            ) {
                                Text(
                                    text = "£${m.dayRate.toInt()}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = BritishGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp
                                    ),
                                    modifier = Modifier.padding(4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Attachments Configurator
        if (compAttachments.isNotEmpty()) {
            item {
                Text("COMPATIBLE ATTACHMENTS SELECTOR", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
            }
            items(compAttachments) { att ->
                val isSel = selectedAttachments.contains(att)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.toggleAttachmentSelection(att) },
                    border = BorderStroke(1.dp, if (isSel) BritishGreen else BorderColor),
                    colors = CardDefaults.cardColors(containerColor = if (isSel) BritishGreenLight else OffWhite),
                    shape = RoundedCornerShape(1.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = isSel,
                                onCheckedChange = { viewModel.toggleAttachmentSelection(att) },
                                colors = CheckboxDefaults.colors(checkedColor = BritishGreen)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(att.name, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        }
                        Text("£${att.dayRate}/day", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = BritishGreen))
                    }
                }
            }
        }

        // Logistics & Operators Configurator
        item {
            Text("LOGISTICS & MANPOWER SELECTIONS", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TRANSPORT REQUIRED", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                            Text("Delivery & Collection via low-loader", style = MaterialTheme.typography.bodyMedium.copy(color = Steel))
                        }
                        Switch(
                            checked = transportRequired,
                            onCheckedChange = { viewModel.quoteTransportRequired.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = BritishGreen)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("CPCS OPERATOR REQUIRED", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                            Text("Qualified plant driver (+£250/day)", style = MaterialTheme.typography.bodyMedium.copy(color = Steel))
                        }
                        Switch(
                            checked = operatorRequired,
                            onCheckedChange = { viewModel.quoteOperatorRequired.value = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = BritishGreen)
                        )
                    }
                }
            }
        }

        // Customer & Project Info Form
        item {
            Text("CUSTOMER & CONTRACT DETAILS", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    TextField(
                        value = clientName,
                        onValueChange = { viewModel.quoteCustomerName.value = it },
                        label = { Text("CUSTOMER / COMPANY NAME") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = clientEmail,
                        onValueChange = { viewModel.quoteCustomerEmail.value = it },
                        label = { Text("BILLING EMAIL") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = projectName,
                        onValueChange = { viewModel.quoteProjectName.value = it },
                        label = { Text("PROJECT NAME") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = projectPostcode,
                        onValueChange = { viewModel.quoteProjectPostcode.value = it },
                        label = { Text("PROJECT SITE POSTCODE") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                    )
                }
            }
        }

        // LIVE PRICE CALCULATION SUMMARY (DENSE REFRESH)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Charcoal),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "LIVE ESTIMATE CALCULATOR (${durationDays} DAYS)",
                        style = MaterialTheme.typography.labelMedium.copy(color = Brass, letterSpacing = 0.5.sp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Base Plant Hire", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                        Text("£${String.format("%.2f", pricing.machineBaseCost)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace))
                    }
                    if (pricing.attachmentCost > 0.0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Attachments Selects", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                            Text("£${String.format("%.2f", pricing.attachmentCost)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace))
                        }
                    }
                    if (pricing.deliveryCost > 0.0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Mobilisation Low-loader (Del)", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                            Text("£${String.format("%.2f", pricing.deliveryCost)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace))
                        }
                    }
                    if (pricing.collectionCost > 0.0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("De-mobilisation Collection", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                            Text("£${String.format("%.2f", pricing.collectionCost)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace))
                        }
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Damage Waiver Charge", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                        Text("£${String.format("%.2f", pricing.damageWaiverCost)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace))
                    }
                    if (pricing.operatorCost > 0.0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Certified CPCS Operator", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                            Text("£${String.format("%.2f", pricing.operatorCost)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    IndustrialDivider(color = Brass.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("SUBTOTAL (NET)", style = MaterialTheme.typography.bodyLarge.copy(color = OffWhite, fontWeight = FontWeight.Bold))
                        Text("£${String.format("%.2f", pricing.subtotal)}", style = MaterialTheme.typography.labelSmall.copy(color = OffWhite, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("VAT (UK 20.0%)", style = MaterialTheme.typography.bodyMedium.copy(color = SteelLight))
                        Text("£${String.format("%.2f", pricing.vat)}", style = MaterialTheme.typography.labelSmall.copy(color = SteelLight, fontFamily = FontFamily.Monospace))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("GRAND TOTAL (GROSS)", style = MaterialTheme.typography.titleLarge.copy(color = Brass, fontWeight = FontWeight.Bold))
                        Text("£${String.format("%.2f", pricing.grandTotal)}", style = MaterialTheme.typography.titleLarge.copy(color = Brass, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.generateQuote() },
                        colors = ButtonDefaults.buttonColors(containerColor = Brass),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_quote_button")
                    ) {
                        Text("GENERATE FORMAL COMMERCIAL QUOTE", style = MaterialTheme.typography.bodyLarge.copy(color = Charcoal, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SCREEN 4: QUOTE SUMMARY (Pristine commercial document)
// -------------------------------------------------------------------------------------
@Composable
fun QuoteSummaryScreen(viewModel: PlantHireViewModel) {
    val quote by viewModel.activeQuote.collectAsStateWithLifecycle()

    if (quote == null) return

    val q = quote!!

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedKeep(12.dp)
    ) {
        item {
            TextButton(onClick = { viewModel.navigateTo("machine_detail") }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                Spacer(modifier = Modifier.width(4.dp))
                Text("EDIT CONFIG")
            }
        }

        item {
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "UK PLANT HIRE COMMISSION EXCHANGE",
                        style = MaterialTheme.typography.labelSmall.copy(color = Steel)
                    )
                    Text(
                        text = "FORMAL COMMERCIAL ESTIMATE",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    KeyValueRow("Quote Number", q.id, isMonospace = true)
                    KeyValueRow("Status", q.status, isMonospace = false)
                    KeyValueRow("Expiry Date", q.expiryDate, isMonospace = true)

                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("CONTRACT SPECIFICATION", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                    Spacer(modifier = Modifier.height(4.dp))
                    KeyValueRow("Contractor / Hirer", q.customerName)
                    KeyValueRow("Contact", q.customerEmail)
                    KeyValueRow("Project Site", q.projectName)
                    KeyValueRow("Site Postcode", q.projectPostcode, isMonospace = true)
                    KeyValueRow("Machine Asset ID", q.machineId, isMonospace = true)
                    KeyValueRow("On-Hire Date", q.startDate, isMonospace = true)
                    KeyValueRow("Off-Hire Date", q.endDate, isMonospace = true)
                    KeyValueRow("Total Hire Days", "${q.numDays} Days", isMonospace = false)

                    Spacer(modifier = Modifier.height(12.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("PRICE BREAKDOWN RECEIPT", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                    Spacer(modifier = Modifier.height(4.dp))
                    KeyValueRow("Base Plant Hire (Net)", "£${String.format("%.2f", q.machineHireCost)}", isMonospace = true)
                    if (q.attachmentCost > 0.0) {
                        KeyValueRow("Attachments (Net)", "£${String.format("%.2f", q.attachmentCost)}", isMonospace = true)
                    }
                    if (q.deliveryCost > 0.0) {
                        KeyValueRow("Low-loader Mobilisation", "£${String.format("%.2f", q.deliveryCost)}", isMonospace = true)
                    }
                    if (q.collectionCost > 0.0) {
                        KeyValueRow("Low-loader Collection", "£${String.format("%.2f", q.collectionCost)}", isMonospace = true)
                    }
                    KeyValueRow("Damage Waiver Premium", "£${String.format("%.2f", q.damageWaiverCost)}", isMonospace = true)
                    if (q.operatorCost > 0.0) {
                        KeyValueRow("Certified CPCS Operator", "£${String.format("%.2f", q.operatorCost)}", isMonospace = true)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    KeyValueRow("Subtotal (Ex. VAT)", "£${String.format("%.2f", q.subtotal)}", isMonospace = true)
                    KeyValueRow("VAT @ 20.0%", "£${String.format("%.2f", q.vat)}", isMonospace = true)
                    KeyValueRow("Grand Total (Gross)", "£${String.format("%.2f", q.grandTotal)}", isMonospace = true)

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.convertActiveQuoteToBooking() },
                        colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("accept_quote_button")
                    ) {
                        Icon(Icons.Default.Verified, contentDescription = "Sign")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("ACCEPT QUOTE & BOOK CONTRACT", style = MaterialTheme.typography.bodyLarge.copy(color = OffWhite, fontWeight = FontWeight.Bold))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SCREEN 5: HIRE DETAIL SCREEN (Pragmatic Anglo-Industrial State Machine & Telemetry)
// -------------------------------------------------------------------------------------
@Composable
fun HireDetailScreen(viewModel: PlantHireViewModel) {
    val selectedId by viewModel.selectedHireId.collectAsStateWithLifecycle()
    val hires by viewModel.hires.collectAsStateWithLifecycle()
    val machines by viewModel.machines.collectAsStateWithLifecycle()
    val invoices by viewModel.invoices.collectAsStateWithLifecycle()

    val h = hires.find { it.id == selectedId } ?: return
    val m = machines.find { it.id == h.machineId }

    val relatedInvoice = invoices.find { it.hireId == h.id }

    var logMeterValue by remember { mutableStateOf("") }
    var inspectionConditionSelection by remember { mutableStateOf("EXCELLENT") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedKeep(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { viewModel.navigateTo("control_centre") }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("DASHBOARD")
                }
                StatusBadge(h.status)
            }
        }

        // State machine tracker banner
        item {
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = SteelLight),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "LIFECYCLE PIPELINE",
                        style = MaterialTheme.typography.labelSmall.copy(color = Steel, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val states = listOf("CONFIRMED", "DISPATCHED", "ON_HIRE", "OFF_HIRE_REQUESTED", "RETURNED", "CLOSED")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        states.forEach { s ->
                            val isPassedOrCurrent = states.indexOf(s) <= states.indexOf(h.status) || (h.status == "EXTENDED" && s == "ON_HIRE")
                            val badgeColor = if (isPassedOrCurrent) BritishGreen else Steel.copy(alpha = 0.3f)
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .background(badgeColor, RoundedCornerShape(4.dp))
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (s == "OFF_HIRE_REQUESTED") "OFF-HIRE" else s,
                                    fontSize = 7.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isPassedOrCurrent) BritishGreen else Steel,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // Operational Actions Board (Interactive steps)
        item {
            Text("OPERATIONS CONTROL PANEL", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                border = BorderStroke(1.dp, BritishGreen),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DEPOT OPERATIONS & CLIENT TRIGGER PANEL",
                        style = MaterialTheme.typography.labelSmall.copy(color = BritishGreen, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    when (h.status) {
                        "CONFIRMED" -> {
                            Text("The machine is reserved in the depot. Dispatch the low-loader.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.dispatchMachine(h.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("DISPATCH MOBILISATION VEHICLE")
                            }
                        }
                        "DISPATCHED" -> {
                            Text("The machine is in transit to site. Confirm delivery safe arrival.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.startHire(h.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("CONFIRM ARRIVAL & SIGN ON-HIRE")
                            }
                        }
                        "ON_HIRE", "EXTENDED" -> {
                            Text("The machine is currently active on project site.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedKeep(8.dp)) {
                                Button(
                                    onClick = { viewModel.extendHire(h.id, 3) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Brass),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("EXTEND 3 DAYS", color = Charcoal)
                                }
                                Button(
                                    onClick = { viewModel.requestOffHire(h.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Oxblood),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("OFF-HIRE COLLECT")
                                }
                            }
                        }
                        "OFF_HIRE_REQUESTED" -> {
                            Text("Off-hire requested at ${h.offHireRequestedAt ?: "N/A"}. Log returned meter hours.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(8.dp))
                            TextField(
                                value = logMeterValue,
                                onValueChange = { logMeterValue = it },
                                label = { Text("RETURN METER READING (HOURS)") },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = TextFieldDefaults.colors(focusedContainerColor = SteelLight, unfocusedContainerColor = SteelLight)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    val hr = logMeterValue.toIntOrNull() ?: (h.meterStart + 35)
                                    viewModel.completeReturn(h.id, hr)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("RECORD COLLECTION METRIC")
                            }
                        }
                        "RETURNED" -> {
                            Text("Plant returned to depot. Run statutory safety and condition check.", style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedKeep(4.dp)) {
                                listOf("EXCELLENT", "GOOD", "FAIR").forEach { cond ->
                                    val isSel = inspectionConditionSelection == cond
                                    Card(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { inspectionConditionSelection = cond },
                                        colors = CardDefaults.cardColors(containerColor = if (isSel) BritishGreen else SteelLight)
                                    ) {
                                        Text(
                                            cond,
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(color = if (isSel) OffWhite else Charcoal)
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.completeInspectionAndClose(h.id, inspectionConditionSelection) },
                                colors = ButtonDefaults.buttonColors(containerColor = BritishGreen),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("RELEASE TO ACTIVE FLEET")
                            }
                        }
                        "CLOSED" -> {
                            Text("Statutory safety checks passed. Machine is fully released back to active stock.", style = MaterialTheme.typography.bodyMedium.copy(color = GreenActive, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Commercial Billing Status Panel
        if (relatedInvoice != null) {
            item {
                Card(
                    border = BorderStroke(1.dp, BorderColor),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("INVOICE STATUS", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                            StatusBadge(relatedInvoice.status)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        KeyValueRow("Invoice ID", relatedInvoice.id, isMonospace = true)
                        KeyValueRow("Grand Total Gross", "£${String.format("%.2f", relatedInvoice.grandTotal)}", isMonospace = true)

                        if (relatedInvoice.status == "UNPAID") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.payInvoice(relatedInvoice.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = Brass),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("PROCESS BANK COMMERCIAL CLEARANCE", color = Charcoal)
                            }
                        }
                    }
                }
            }
        }

        // Live Monospace Telemetry / Diagnostics Block
        if (m != null && m.telemetryEnabled) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Charcoal),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "LIVE TELEMETRY FEEDS (SHF EXCHANGERS)",
                            style = MaterialTheme.typography.labelSmall.copy(color = Brass)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "GPS: 53.4301° N, 1.3421° W (Sheffield Hub)\n" +
                                    "ENGINE STATUS: ${if (h.status == "ON_HIRE" || h.status == "EXTENDED") "RUNNING (IDLE)" else "SHUTDOWN"}\n" +
                                    "FUEL LVL: 82.4% | OIL PRESS: 4.2 BAR\n" +
                                    "LOGGED OPERATING HOURS: ${h.telemetryHours} h\n" +
                                    "COMMUNICATION LINK: 4G LTE ENCRYPTED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = OffWhite,
                                fontFamily = FontFamily.Monospace,
                                lineHeight = 16.sp
                            )
                        )
                    }
                }
            }
        }

        // Hire Document Summary
        item {
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("CONTRACT INFORMATION SUMMARY", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                    Spacer(modifier = Modifier.height(8.dp))
                    KeyValueRow("Contract ID", h.id, isMonospace = true)
                    KeyValueRow("Hirer Name", h.customerName)
                    KeyValueRow("Billing Email", h.customerEmail)
                    KeyValueRow("Site Location", h.projectName)
                    KeyValueRow("Postcode", h.projectPostcode, isMonospace = true)
                    KeyValueRow("Plant Unit", "${m?.manufacturer} ${m?.model}", isMonospace = false)
                    KeyValueRow("Asset ID", h.machineId, isMonospace = true)
                    KeyValueRow("Expected On-Hire", h.startDate, isMonospace = true)
                    KeyValueRow("Expected Off-Hire", h.expectedReturnDate, isMonospace = true)
                    KeyValueRow("Extension Period", "${h.extensionDays} Days", isMonospace = false)
                    KeyValueRow("Start Meter", "${h.meterStart} h", isMonospace = true)
                    if (h.meterEnd != null) {
                        KeyValueRow("Return Meter", "${h.meterEnd} h", isMonospace = true)
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SCREEN 6: DEPOT CONTROL ROOM (Timelines, visual machine status, Board)
// -------------------------------------------------------------------------------------
@Composable
fun DepotControlRoomScreen(viewModel: PlantHireViewModel) {
    val selectedId by viewModel.selectedDepotId.collectAsStateWithLifecycle()
    val depots by viewModel.depots.collectAsStateWithLifecycle()
    val machines by viewModel.machines.collectAsStateWithLifecycle()

    val activeDepotId = selectedId ?: "SHF"
    val depot = depots.find { it.id == activeDepotId } ?: return

    val depotMachines = machines.filter { it.depotId == activeDepotId }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedKeep(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${depot.name.uppercase()} BOARD",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BritishGreen)
                )
                TextButton(onClick = { viewModel.navigateTo("control_centre") }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("BACK")
                }
            }
        }

        // Depot specs
        item {
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    KeyValueRow("Address", depot.address)
                    KeyValueRow("Contact", depot.contactNumber)
                    KeyValueRow("Regional Postcode Area", depot.postcode, isMonospace = true)
                    KeyValueRow("Low-loader Max Radius", "${depot.deliveryRadiusKm} km", isMonospace = false)
                }
            }
        }

        // SECTION 31: VISUAL AVAILABILITY CALENDAR TIMELINE
        item {
            Text("AVAILABILITY TIMELINE SCHEDULE (OCTOBER)", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Header dates
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedKeep(4.dp)) {
                        Box(modifier = Modifier.weight(1.5f)) {
                            Text("MACHINE", style = MaterialTheme.typography.labelSmall.copy(color = Steel, fontWeight = FontWeight.Bold))
                        }
                        (1..8).forEach { day ->
                            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                Text("$day", style = MaterialTheme.typography.labelSmall.copy(color = Steel))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    depotMachines.take(4).forEachIndexed { index, m ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedKeep(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(modifier = Modifier.weight(1.5f)) {
                                Text(m.id, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            }

                            // Render deterministic status squares for October 1 to 8
                            (1..8).forEach { day ->
                                val cellState = when {
                                    m.status == "ON_HIRE" && day in 3..6 -> "H" // On Hire
                                    m.status == "RESERVED" && day in 5..7 -> "R" // Reserved
                                    m.status == "MAINTENANCE" && day in 1..3 -> "M" // Maintenance
                                    day % 4 == index -> "H"
                                    else -> "A" // Available
                                }

                                val (cellBg, cellText) = when (cellState) {
                                    "A" -> Pair(Color(0xFFE6F4EA), Color(0xFF137333))
                                    "H" -> Pair(Color(0xFFFCE8E6), Color(0xFFC5221F))
                                    "R" -> Pair(Color(0xFFE8F0FE), Color(0xFF1A73E8))
                                    "M" -> Pair(Color(0xFFFEF7E0), Color(0xFFB06000))
                                    else -> Pair(SteelLight, Charcoal)
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .background(cellBg, RoundedCornerShape(1.dp))
                                        .padding(vertical = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = cellState,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = cellText
                                        )
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Legend: A = Available, H = On Hire, R = Returning/Reserved, M = Maintenance/Inspection",
                        style = MaterialTheme.typography.labelSmall.copy(color = Steel, fontSize = 8.sp)
                    )
                }
            }
        }

        // Depot Inventory List / Board Table
        item {
            Text("DEPOT MACHINERY STOCK BOARD", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(depotMachines) { m ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.selectMachineForQuote(m)
                        viewModel.navigateTo("machine_detail")
                    },
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("${m.manufacturer} ${m.model}".uppercase(), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold))
                        Text("Asset ID: ${m.id} | Engine hours: ${m.operatingHours} h", style = MaterialTheme.typography.bodyMedium.copy(color = Steel))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusBadge(m.status)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ChevronRight, contentDescription = "Drill", tint = Steel, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------------------
// SCREEN 7: FLEET ECONOMICS & AUDITING
// -------------------------------------------------------------------------------------
@Composable
fun FleetEconomicsScreen(viewModel: PlantHireViewModel) {
    val machines by viewModel.machines.collectAsStateWithLifecycle()
    val auditLogs by viewModel.auditLogs.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedKeep(12.dp)
    ) {
        item {
            Text(
                text = "FLEET MANAGEMENT ECONOMICS",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = BritishGreen)
            )
            Text(
                text = "Operational cost-to-revenue models and depreciation schedules.",
                style = MaterialTheme.typography.bodyMedium.copy(color = Steel)
            )
        }

        // Fleet Economics Table
        item {
            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("MANAGEMENT MARGIN ESTIMATES", style = MaterialTheme.typography.labelMedium.copy(color = Steel))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("ASSET", modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Text("COST", modifier = Modifier.weight(1f), textAlign = TextAlign.End, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Text("REVENUE", modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Text("CONTRIB.", modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Brass))
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    IndustrialDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    machines.take(6).forEach { m ->
                        val pCost = when (m.model) {
                            "220X" -> 185000
                            "3CX Pro" -> 85000
                            "308 CR" -> 55000
                            "A25G" -> 240000
                            "540-170" -> 92000
                            else -> 45000
                        }
                        val marginEstimate = when (m.model) {
                            "220X" -> 41600
                            "3CX Pro" -> 28400
                            "308 CR" -> 19500
                            "A25G" -> 62000
                            "540-170" -> 31000
                            else -> 12000
                        }
                        val annualRevenueEstimate = marginEstimate + 9420 + 6820

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(m.id, modifier = Modifier.weight(1f), style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            Text("£${pCost / 1000}k", modifier = Modifier.weight(1f), textAlign = TextAlign.End, style = MaterialTheme.typography.labelSmall)
                            Text("£${annualRevenueEstimate / 1000}k", modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, style = MaterialTheme.typography.labelSmall)
                            Text("£${marginEstimate / 1000}k", modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, style = MaterialTheme.typography.labelSmall.copy(color = BritishGreen, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Live Event System & Audit Logs
        item {
            Text("COMMERCIAL STATUTORY AUDIT LOG", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(auditLogs) { log ->
            val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.UK)
            val dateStr = dateFormat.format(Date(log.timestamp))

            Card(
                border = BorderStroke(1.dp, BorderColor),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = log.event,
                            style = MaterialTheme.typography.labelSmall.copy(color = Brass, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = dateStr,
                            style = MaterialTheme.typography.labelSmall.copy(color = Steel)
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "User: ${log.user} | Machine: ${log.machineId.ifEmpty { "N/A" }}",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = log.reason,
                        style = MaterialTheme.typography.bodyMedium.copy(color = Steel)
                    )
                    if (log.oldVal.isNotEmpty() || log.newVal.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Transition: ${log.oldVal} ➔ ${log.newVal}",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = BritishGreen)
                        )
                    }
                }
            }
        }
    }
}
