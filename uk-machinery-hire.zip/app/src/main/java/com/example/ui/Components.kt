package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun IndustrialHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    actions: @Composable (RowScope.() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Charcoal)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = title.uppercase(),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = OffWhite
                    )
                )
                if (subtitle != null) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle.uppercase(),
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Brass,
                            letterSpacing = 1.sp
                        )
                    )
                }
            }
            if (actions != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    actions()
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Divider(color = Brass, thickness = 1.dp)
    }
}

@Composable
fun IndustrialDivider(modifier: Modifier = Modifier, color: Color = BorderColor) {
    Divider(
        modifier = modifier,
        color = color,
        thickness = 1.dp
    )
}

@Composable
fun StatusBadge(status: String) {
    val (bgColor, textColor) = when (status) {
        "AVAILABLE" -> Pair(Color(0xFFE6F4EA), Color(0xFF137333))
        "ON_HIRE" -> Pair(Color(0xFFFCE8E6), Color(0xFFC5221F))
        "RESERVED" -> Pair(Color(0xFFFEF7E0), Color(0xFFB06000))
        "CONFIRMED" -> Pair(Color(0xFFE8F0FE), Color(0xFF1A73E8))
        "DISPATCHED" -> Pair(Color(0xFFE8F0FE), Color(0xFF1A73E8))
        "TRANSPORT" -> Pair(Color(0xFFF3E8FD), Color(0xFF86198F))
        "OFF_HIRE_REQUESTED" -> Pair(Color(0xFFFEF7E0), Color(0xFFB06000))
        "RETURNING" -> Pair(Color(0xFFEAECEE), Color(0xFF4A5560))
        "RETURNED" -> Pair(Color(0xFFE6F4EA), Color(0xFF137333))
        "MAINTENANCE" -> Pair(Color(0xFFFEF7E0), Color(0xFFB06000))
        "INSPECTION" -> Pair(Color(0xFFF3E8FD), Color(0xFF86198F))
        "CLOSED" -> Pair(Color(0xFFEAECEE), Color(0xFF4A5560))
        "PAID" -> Pair(Color(0xFFE6F4EA), Color(0xFF137333))
        "UNPAID" -> Pair(Color(0xFFFCE8E6), Color(0xFFC5221F))
        else -> Pair(Color(0xFFEAECEE), Color(0xFF4A5560))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = bgColor),
        shape = RoundedCornerShape(2.dp),
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.3f)),
        modifier = Modifier.padding(2.dp)
    ) {
        Text(
            text = status.replace("_", " ").uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = textColor,
                fontSize = 9.sp,
                letterSpacing = 0.5.sp
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun KeyValueRow(label: String, value: String, isMonospace: Boolean = false) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.bodyMedium.copy(
                color = Steel,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                letterSpacing = 0.5.sp
            )
        )
        Text(
            text = value,
            style = if (isMonospace) {
                MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = OffBlack
                )
            } else {
                MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = OffBlack
                )
            }
        )
    }
}
