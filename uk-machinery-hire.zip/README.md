# UK Plant Exchange & Machinery Hire Control Platform
### Enterprise Day-Rate Machinery Rental Platform & UK Plant Hire Control Centre
#### Modern Anglo-Industrial Machinery Infrastructure Architecture

Welcome to the **UK Plant Exchange** (commercially operated under UK Plant Hire) database operating platform. This repository represents the underlying software infrastructure, transactional state engine, and control centre dashboard for a national-scale plant-hire economy.

The system is engineered as a robust, local-first enterprise Android application powered by **Kotlin, Jetpack Compose, and Room Database (SQLite)**.

---

## 1. CORE ARCHITECTURAL FLOW
Every transaction on the platform maps precisely to the real-world physical machinery logistics flow:
```
MACHINE ➔ LOCATION (DEPOT) ➔ AVAILABILITY ➔ BASE DAY-RATE ➔ ESTIMATE ➔ HIRE CONTRACT ➔ MOBILISATION ➔ ON-SITE UTILISATION ➔ COLLECTION ➔ DE-MOBILISATION ➔ ENGINEER SAFETY INSPECTION ➔ CLOSED & RELEASED
```

Unlike toy e-commerce systems, a machine is not a generic static product. A **JCB 220X Tracked Excavator** at the **Sheffield Depot (SHF-0421)** is a distinct physical asset compared to another unit at the **London East Depot (LND-1084)**. The platform tracks discrete individual unit telemetry, working meters, operating conditions, maintenance, transport capacities, and rate plans.

---

## 2. TECHNICAL SPECIFICATIONS & SYSTEM CHARACTER
- **Language**: Kotlin 2.2+ (strictly structured domain types)
- **Database Engine**: Room Persistence (SQLite) with multi-DAO transactional isolation
- **UI Framework**: Jetpack Compose designed with Material Design 3 (M3)
- **Visual Aesthetic**: Anglo-industrial British Futurism (Ritchie Bros. × railway control rooms × London financial terminals)
- **Color Palette**: Off-white, charcoal, deep racing green, brass, and steel light accents.
- **Typography**: Grotesque sans-serif hierarchies with monospace counters for asset numbers, telemetry values, pricing rates, and logs.

---

## 3. COMPREHENSIVE DOCUMENTATION MANUALS
Detailed technical breakdowns of each sub-system are located in the repository:
1. [ARCHITECTURE.md](ARCHITECTURE.md) - System architecture and dependency isolation.
2. [API.md](API.md) - Public REST API endpoints and payload specifications.
3. [DATA_MODEL.md](DATA_MODEL.md) - Database schema, foreign key relations, and indexes.
4. [PRICING_ENGINE.md](PRICING_ENGINE.md) - Dynamic Day-Rate formula and Market Scenario Simulator.
5. [AVAILABILITY_ENGINE.md](AVAILABILITY_ENGINE.md) - Transactional booking logic and Visual October Timelines.
6. [EVENTS.md](EVENTS.md) - Domain-Driven Design (DDD) outbox event framework.
7. [SECURITY.md](SECURITY.md) - Enterprise RBAC, API safety, and tenant protection.
8. [DEPLOYMENT.md](DEPLOYMENT.md) - Docker Development environment and CI/CD targets.
9. [TESTING.md](TESTING.md) - Local JVM Robolectric testing strategy.

---

## 4. SIGNATURE DEMONSTRATION FLOW
When launching the application, you will experience the complete vertical slice:
1. **Control Centre Dashboard**: Inspect high-fidelity, real-time national counts (5,000 active machines emulated, actual Room DB entities synchronized, active dispatches, current fleet utilisation metrics, and active commercial values).
2. **Search Plant**: Run precise query filters (category, depot, max day rate, project site postcode S1) against live SQLite records.
3. **Machine Details page**: Browse premium specifications (weight, power, outreach, dig depth, etc.).
4. **Live Estimate Calculator**: Toggle CPCS operator requirements, mobilisation low-loader transport options, and compatible attachments (600mm buckets, hydraulic breakers, compactors). View itemized price receipts with tax (VAT 20%) updating instantly in response to selected options.
5. **Contract Lifecycle State Machine**: Confirm the quotation, lock in immutable pricing snapshots, generate un-editable historical contract agreements, and track step-by-step progress through dispatch, site sign-off, extension requests, and collection.
6. **Depot Control Room**: Toggle regional depot screens to view machine stock boards and visual October timeline grids (A/H/R/M booking timelines).
7. **Fleet Economics**: Audit management revenue margins, depreciation, book values, and inspect the continuous commercial audit logs.
