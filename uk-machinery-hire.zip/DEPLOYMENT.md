# DEPLOYMENT.md
## Docker-Compose Development & Production Deployment Guide

The UK Plant Exchange operating platform is distributed with a pre-configured Docker development environment to allow one-click setup of all backend, caching, database, and front-end mock boundaries.

---

## 1. DEV CONTAINER INFRASTRUCTURE
A complete development workspace is orchestrated via Docker Compose:
- **`db` (PostgreSQL)**: Primary relational database containing the enterprise schema.
- **`cache` (Redis)**: High-throughput telemetry buffer and search index cache.
- **`worker` (Python Celery)**: Background worker managing dispatch timers, email triggers, and statutory check reminders.
- **`api` (FastAPI)**: REST gateway exposing endpoints to clients and internal ERP connections.
- **`frontend` (React + Vite)**: Web dashboard displaying real-time timelines and map grids.

---

## 2. DOCKER COMPOSE CONFIGURATION
Save the following as `docker-compose.yml` in the project root:

```yaml
version: '3.8'

services:
  db:
    image: postgres:15-alpine
    container_name: uk_hire_db
    environment:
      POSTGRES_DB: ukm_hire_db
      POSTGRES_USER: ukm_admin
      POSTGRES_PASSWORD: admin_secret_key
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data

  cache:
    image: redis:7-alpine
    container_name: uk_hire_cache
    ports:
      - "6379:6379"

  api:
    build:
      context: ./apps/api
    container_name: uk_hire_api
    environment:
      - DATABASE_URL=postgresql://ukm_admin:admin_secret_key@db/ukm_hire_db
      - REDIS_URL=redis://cache:6379/0
    ports:
      - "8000:8000"
    depends_on:
      - db
      - cache

  frontend:
    build:
      context: ./apps/web
    container_name: uk_hire_web
    ports:
      - "3000:3000"
    depends_on:
      - api

volumes:
  pgdata:
```

---

## 3. SPINNING UP SYSTEM
To build and start the complete microservice architecture, run:
```bash
docker compose up --build -d
```
All database tables, seed records, and network connections will be initialized automatically on start.
To tear down the containers:
```bash
docker compose down -v
```
