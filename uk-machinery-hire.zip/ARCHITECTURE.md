# ARCHITECTURE.md
## Technical System Architecture — UK Plant Exchange Platform

The platform is designed following Clean Architecture combined with **MVVM (Model-View-ViewModel)**. This guarantees strict boundary isolation between business logic, database transactions, and the user interface.

---

## 1. LAYER BOUNDARIES

```
       ┌────────────────────────────────────────────────────────┐
       │                       UI LAYER                         │
       │     (Jetpack Compose Screens: ControlCentre, etc.)     │
       └───────────────────────────┬────────────────────────────┘
                                   │  Observes Flow State
                                   ▼
       ┌────────────────────────────────────────────────────────┐
       │                   VIEWMODEL LAYER                      │
       │     (PlantHireViewModel: StateFlows, calculations)     │
       └───────────────────────────┬────────────────────────────┘
                                   │  Dispatches Operations
                                   ▼
       ┌────────────────────────────────────────────────────────┐
       │                   REPOSITORY LAYER                     │
       │     (PlantHireRepository: Transaction orchestration)   │
       └───────────────────────────┬────────────────────────────┘
                                   │  Queries / Inserts
                                   ▼
       ┌────────────────────────────────────────────────────────┐
       │                     DATABASE LAYER                     │
       │     (Room AppDatabase, 7 Isolated DAOs, Entities)      │
       └────────────────────────────────────────────────────────┘
```

---

## 2. REPOSITORY & STATE ISOLATION

### SQLite Database (Room)
The SQLite layer acts as the single source of truth (SSOT). All write operations are transactional and handled via background dispatchers (`withContext(Dispatchers.IO)`).
- **Entities**: Seven strictly typed data schemas representing the physical and commercial records.
- **DAOs**: Six modular database access layers to decouple query complexity (DepotDao, MachineDao, AttachmentDao, QuoteDao, HireDao, InvoiceDao, AuditLogDao).

### Flow Propagation
Database entities are reactively mapped as Kotlin `Flow` objects up to the UI layer. This guarantees that when a depot dispatcher updates an asset status to `MAINTENANCE` or `CLOSED`, the customer-facing screens instantly update without manual refreshes.

---

## 3. COMPONENT LISTINGS
- **`com.example.data`**:
  - `Models.kt`: Holds Room entity schemas (Depot, Machine, Attachment, Quote, Hire, Invoice, AuditLog).
  - `Daos.kt`: Holds clean interfaces for database queries.
  - `AppDatabase.kt`: Abstract database builder with thread-safe singleton initialization.
  - `PlantHireRepository.kt`: Handles transactions, calculates immutable billing totals, logs operations, and performs deterministic database seeding.
- **`com.example.ui`**:
  - `PlantHireViewModel.kt`: Orchestrates screen states, search filters, Live Estimate pricing multipliers, and triggers lifecycle state changes.
  - `Components.kt`: Highly engineered M3 industrial components (StatusBadges, custom dividers, dense tabular grids).
  - `MainLayout.kt`: High-fidelity layout implementations for all seven screen boards.
- **`com.example.ui.theme`**:
  - `Color.kt` & `Theme.kt`: Implements the deep racing green and brass aesthetic.
  - `Type.kt`: Configures grotesque UI typography and monospace data metrics.
