/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Lobby from './components/Lobby';
import PokerTableComponent from './components/PokerTableComponent';
import ProvablyFair from './components/ProvablyFair';
import VIPLeaderboard from './components/VIPLeaderboard';
import BitcoinSection from './components/BitcoinSection';
import { Send, Twitter, MessageSquare, Mail } from 'lucide-react';

export default function App() {
  const [currentView, setView] = useState<string>('home');
  const [selectedTableId, setSelectedTableId] = useState<string | null>('table-1');
  const [walletAddress, setWalletAddress] = useState<string | null>(null);

  const handleConnectWallet = (address?: string) => {
    // Generate randomized secure address if not specified
    const finalAddress = address || 'bc1q9p2ef' + Math.floor(Math.random() * 10000000).toString(16) + 'z';
    setWalletAddress(finalAddress);
  };

  const handleDisconnectWallet = () => {
    setWalletAddress(null);
  };

  return (
    <div className="min-h-screen bg-[#060606] text-[#F7F7F7] flex flex-col font-sans selection:bg-[#D6B35A]/30 selection:text-white">
      
      {/* 1. Header Navigation Bar */}
      <Header
        currentView={currentView === 'home' ? 'lobby' : currentView}
        setView={setView}
        walletAddress={walletAddress}
        onConnectWallet={() => handleConnectWallet()}
        onDisconnectWallet={handleDisconnectWallet}
      />

      {/* 2. Main Content Screen Router */}
      <main className="flex-grow">
        {currentView === 'home' && (
          <div className="space-y-4 animate-fade-in">
            {/* Massive Cinema Hero */}
            <Hero
              setView={setView}
              walletAddress={walletAddress}
              onConnectWallet={handleConnectWallet}
              onDisconnectWallet={handleDisconnectWallet}
            />
            {/* Live Tables Lobby on Landing */}
            <Lobby
              setView={setView}
              onSelectTable={setSelectedTableId}
            />
          </div>
        )}

        {currentView === 'lobby' && (
          <Lobby
            setView={setView}
            onSelectTable={setSelectedTableId}
          />
        )}

        {currentView === 'table' && (
          <PokerTableComponent
            tableId={selectedTableId}
            walletAddress={walletAddress}
            onConnectWallet={() => handleConnectWallet()}
          />
        )}

        {currentView === 'fairness' && (
          <ProvablyFair />
        )}

        {currentView === 'leaderboard' && (
          <VIPLeaderboard />
        )}

        {currentView === 'security' && (
          <BitcoinSection />
        )}
      </main>

      {/* 3. High-End Editorial Footer (Direct alignment with prompt mockup) */}
      <footer className="bg-[#0b0b0b] border-t border-white/[0.04] py-12 px-6 lg:px-8 mt-auto">
        <div className="mx-auto max-w-7xl flex flex-col md:flex-row items-center justify-between gap-8">
          
          {/* Logo & Manifesto Quote */}
          <div className="text-left space-y-3 max-w-xs">
            <div className="flex items-center space-x-2">
              <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-b-[12px] border-b-[#D6B35A]" />
              <span className="font-display text-sm font-bold tracking-[0.2em] text-[#F7F7F7] uppercase">
                AGORIST POKER
              </span>
            </div>
            <p className="text-[10px] text-[#6E6E6E] leading-relaxed">
              "The house always wins in centralized systems. Here, the players win." <br />
              <strong className="text-[#D6B35A]">— The Agorist Manifesto</strong>
            </p>
          </div>

          {/* Links Column */}
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-[11px] font-mono text-[#B7B7B7] uppercase tracking-widest">
            <button onClick={() => setView('home')} className="hover:text-[#D6B35A] transition-colors cursor-pointer">About</button>
            <button onClick={() => setView('fairness')} className="hover:text-[#D6B35A] transition-colors cursor-pointer">Fairness</button>
            <button onClick={() => setView('security')} className="hover:text-[#D6B35A] transition-colors cursor-pointer">Privacy</button>
            <button onClick={() => setView('leaderboard')} className="hover:text-[#D6B35A] transition-colors cursor-pointer">VIP Club</button>
            <a href="mailto:support@agorist.poker" className="hover:text-[#D6B35A] transition-colors">Contact</a>
          </div>

          {/* Call-to-action & Social community links */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
            
            <div className="flex items-center space-x-3 bg-white/[0.03] border border-white/[0.06] rounded-lg px-4 py-2 text-xs font-mono text-[#B7B7B7]" id="newsletter-form">
              <Send className="h-4 w-4 text-[#D6B35A]" />
              <input 
                type="email" 
                placeholder="JOIN COMMUNITY FEED..." 
                className="bg-transparent outline-none border-none text-[10px] placeholder-[#6E6E6E] w-36 uppercase tracking-wider font-bold"
              />
            </div>

            {/* Social icons */}
            <div className="flex items-center space-x-3 text-[#B7B7B7]">
              <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#D6B35A] transition-colors" title="Twitter / X">
                <Twitter className="h-4 w-4" />
              </a>
              <a href="https://discord.com" target="_blank" rel="noopener noreferrer" className="hover:text-[#D6B35A] transition-colors" title="Discord Group">
                <MessageSquare className="h-4 w-4" />
              </a>
              <a href="mailto:support@agorist.poker" className="hover:text-[#D6B35A] transition-colors" title="Email Node Support">
                <Mail className="h-4 w-4" />
              </a>
            </div>

          </div>

        </div>

        <div className="mx-auto max-w-7xl border-t border-white/[0.03] mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between text-[9px] font-mono text-[#6E6E6E] gap-4">
          <span>© 2026 AGORIST POKER NETWORK. NO SOVEREIGN CUSTODY RISK. ALL RIGHT RESERVED.</span>
          <span>LATENCY GUARANTEE: SUB-30MS GLOBAL ANONYMOUS HOPPING</span>
        </div>
      </footer>

    </div>
  );
}
