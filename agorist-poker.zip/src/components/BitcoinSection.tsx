/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Coins, Zap, ShieldCheck, ArrowDownLeft, ArrowUpRight, Copy, Check, Database, RefreshCw } from 'lucide-react';

export default function BitcoinSection() {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw' | 'vault'>('deposit');
  
  // Lightning invoice state
  const [depositAmountSat, setDepositAmountSat] = useState(100000);
  const [generatedInvoice, setGeneratedInvoice] = useState('');
  const [isInvoiceSettled, setIsInvoiceSettled] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Withdrawal state
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [withdrawAmountSat, setWithdrawAmountSat] = useState(50000);
  const [isWithdrawing, setIsWithdrawing] = useState(false);
  const [withdrawalTx, setWithdrawalTx] = useState('');

  const [copiedText, setCopiedText] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const handleGenerateInvoice = () => {
    setIsGenerating(true);
    setIsInvoiceSettled(false);
    setTimeout(() => {
      const b11 = 'lnbc1u1p' + Array.from({ length: 48 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      setGeneratedInvoice(b11);
      setIsGenerating(false);
    }, 1000);
  };

  const handleSimulatePayment = () => {
    setIsInvoiceSettled(true);
    // Play sound if possible
  };

  const handleWithdrawal = () => {
    if (!withdrawAddress) return;
    setIsWithdrawing(true);
    setTimeout(() => {
      const txid = Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      setWithdrawalTx(txid);
      setIsWithdrawing(false);
    }, 2000);
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8 bg-[#060606]">
      
      {/* Page Title */}
      <div className="border-b border-white/[0.06] pb-6 text-left">
        <h2 className="font-display text-xl font-extrabold text-[#F7F7F7] uppercase tracking-widest">
          Bitcoin Native Treasury & Escrow
        </h2>
        <p className="text-xs text-[#B7B7B7] mt-1 font-sans">
          Zero fiat. Zero altcoins. Instant on-chain and Lightning channel settlements.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Interaction Module (5 columns) */}
        <div className="lg:col-span-5 rounded-none border border-white/[0.08] bg-[#111111] p-6 shadow-2xl space-y-6 text-left">
          
          {/* Section nav */}
          <div className="flex border-b border-white/[0.08] pb-2 font-sans text-[10px] font-bold uppercase tracking-widest">
            {[
              { id: 'deposit', label: 'DEPOSIT', icon: ArrowDownLeft },
              { id: 'withdraw', label: 'WITHDRAW', icon: ArrowUpRight },
              { id: 'vault', label: 'MULTISIG VAULT', icon: ShieldCheck },
            ].map(tab => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 flex items-center justify-center space-x-1.5 pb-2 border-b-2 transition-all cursor-pointer ${
                    activeTab === tab.id
                      ? 'border-[#F2A900] text-[#F2A900]'
                      : 'border-transparent text-[#6E6E6E] hover:text-[#B7B7B7]'
                  }`}
                  id={`treasury-tab-${tab.id}`}
                >
                  <Icon className="h-3.5 w-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* TAB 1: LIGHTNING DEPOSIT */}
          {activeTab === 'deposit' && (
            <div className="space-y-4 font-sans">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono tracking-widest text-[#B7B7B7] uppercase block">
                  DEPOSIT AMOUNT (SATOSHIS)
                </label>
                <input
                  type="number"
                  value={depositAmountSat}
                  onChange={(e) => setDepositAmountSat(Number(e.target.value))}
                  className="w-full rounded-none border border-white/[0.08] bg-[#0d0d0d] p-3 text-xs text-white font-mono placeholder-[#6E6E6E] outline-none"
                  id="sat-deposit-input"
                />
                <span className="text-[9px] text-[#6E6E6E] font-mono">
                  Equivalent to {(depositAmountSat / 100000000).toFixed(5)} BTC
                </span>
              </div>

              <button
                onClick={handleGenerateInvoice}
                disabled={isGenerating}
                className="w-full h-11 inline-flex items-center justify-center space-x-2 rounded-none bg-[#F2A900] text-xs font-bold uppercase tracking-widest text-black hover:bg-[#FFBD14] transition-all cursor-pointer"
                id="btn-generate-lightning"
              >
                <Zap className="h-4 w-4" />
                <span>{isGenerating ? 'GENERATING...' : 'GENERATE INVOICE'}</span>
              </button>

              {/* Display Generated Invoice */}
              {generatedInvoice && (
                <div className="space-y-4 pt-2 border-t border-white/[0.08] text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-[8px] font-mono text-[#F2A900] uppercase tracking-widest">
                      LIGHTNING CHANNEL INVOICE
                    </span>
                    <button
                      onClick={() => handleCopy(generatedInvoice)}
                      className="text-[#F2A900] hover:text-white"
                      id="btn-copy-invoice"
                    >
                      {copiedText ? <Check className="h-3.5 w-3.5 text-[#4ADE80]" /> : <Copy className="h-3.5 w-3.5" />}
                    </button>
                  </div>

                  <div className="bg-black/40 border border-white/[0.08] p-3 rounded-none text-[9px] font-mono break-all leading-normal text-[#B7B7B7]">
                    {generatedInvoice}
                  </div>

                  {/* QR Code Graphic styled as vector elements */}
                  <div className="flex flex-col items-center justify-center space-y-3 pt-2">
                    <div className="h-32 w-32 bg-white rounded-none p-2 flex items-center justify-center relative shadow-xl">
                      {/* Abstract Vector blocks representing QR code */}
                      <div className="absolute inset-2 grid grid-cols-4 gap-1 opacity-90">
                        {[...Array(16)].map((_, idx) => (
                          <div 
                            key={idx} 
                            className={`rounded-none ${
                              (idx % 3 === 0 || idx % 5 === 0 || idx === 1 || idx === 15) ? 'bg-[#060606]' : 'bg-transparent'
                            }`} 
                          />
                        ))}
                      </div>
                      <div className="absolute top-2 left-2 w-6 h-6 border-4 border-[#060606] bg-white rounded-none" />
                      <div className="absolute top-2 right-2 w-6 h-6 border-4 border-[#060606] bg-white rounded-none" />
                      <div className="absolute bottom-2 left-2 w-6 h-6 border-4 border-[#060606] bg-white rounded-none" />
                    </div>

                    <button
                      onClick={handleSimulatePayment}
                      className="px-4 h-9 bg-white/[0.03] border border-white/[0.08] text-[#F2A900] font-bold uppercase tracking-wider text-[10px] rounded-none hover:bg-white/[0.06]"
                      id="btn-simulate-payment"
                    >
                      SIMULATE INVOICE PAYMENT
                    </button>
                  </div>

                  {isInvoiceSettled && (
                    <div className="rounded-none bg-[#4ADE80]/10 border border-[#4ADE80]/20 p-3 text-center text-[#4ADE80] font-mono text-[10px] uppercase tracking-wide">
                      ⚡ DEPOSIT COMPLETE. SATOSHIS COMMITTED TO BALANCE.
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 2: WITHDRAWAL */}
          {activeTab === 'withdraw' && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[9px] font-mono tracking-widest text-[#B7B7B7] uppercase block">
                  RECEIVING ON-CHAIN BTC ADDRESS / LN INVOICE
                </label>
                <input
                  type="text"
                  placeholder="bc1q... or lnbc..."
                  value={withdrawAddress}
                  onChange={(e) => setWithdrawAddress(e.target.value)}
                  className="w-full rounded-none border border-white/[0.08] bg-[#0d0d0d] p-3 text-xs text-white font-mono placeholder-[#6E6E6E] outline-none"
                  id="withdraw-address-input"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-mono tracking-widest text-[#B7B7B7] uppercase block">
                  WITHDRAWAL AMOUNT (SATOSHIS)
                </label>
                <input
                  type="number"
                  value={withdrawAmountSat}
                  onChange={(e) => setWithdrawAmountSat(Number(e.target.value))}
                  className="w-full rounded-none border border-white/[0.08] bg-[#0d0d0d] p-3 text-xs text-white font-mono outline-none"
                  id="sat-withdraw-input"
                />
                <span className="text-[9px] text-[#6E6E6E] font-mono block">
                  Available Balance: <strong className="text-white">125,000,000 SAT (1.25 BTC)</strong>
                </span>
              </div>

              <button
                onClick={handleWithdrawal}
                disabled={isWithdrawing || !withdrawAddress}
                className="w-full h-11 inline-flex items-center justify-center space-x-2 rounded-none bg-[#F2A900] text-xs font-bold uppercase tracking-widest text-black hover:bg-[#FFBD14] transition-all cursor-pointer"
                id="btn-trigger-withdrawal"
              >
                <span>{isWithdrawing ? 'PROPAGATING...' : 'INITIATE WITHDRAWAL'}</span>
              </button>

              {withdrawalTx && (
                <div className="space-y-2 pt-3 border-t border-white/[0.08] text-[10px] font-mono text-[#B7B7B7]">
                  <span className="text-[#4ADE80] font-bold block">✓ TX PROPAGATED TO MEMPOOL</span>
                  <p className="break-all text-[8px] bg-black/40 p-2 rounded-none border border-white/[0.08] text-[#6E6E6E]">
                    TXID: {withdrawalTx}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: COLD VAULT MONITOR */}
          {activeTab === 'vault' && (
            <div className="space-y-4 text-xs font-mono text-[#B7B7B7]">
              <span className="text-[8px] text-[#F2A900] uppercase tracking-widest block font-bold">
                MULTISIG VAULT STATUS (3-OF-5 THRESHOLD)
              </span>

              <div className="space-y-2">
                {[
                  { name: 'Tokyo Node #1 (Hot Escrow)', status: 'ACTIVE', color: 'text-[#4ADE80]' },
                  { name: 'Zurich Node #2 (Vault Cold Key)', status: 'OFFLINE (DEEP COLD)', color: 'text-[#B7B7B7]' },
                  { name: 'Singapore Node #3 (Vault Cold Key)', status: 'OFFLINE (DEEP COLD)', color: 'text-[#B7B7B7]' },
                  { name: 'London Node #4 (Backup Oracle)', status: 'ACTIVE', color: 'text-[#4ADE80]' },
                  { name: 'Reykjavik Node #5 (Hardware Enclave)', status: 'ACTIVE', color: 'text-[#4ADE80]' },
                ].map((node, idx) => (
                  <div key={idx} className="flex justify-between p-2.5 rounded-none bg-black/30 border border-white/[0.04] text-[10px]">
                    <span className="text-white font-bold">{node.name}</span>
                    <span className={`font-bold uppercase ${node.color}`}>{node.status}</span>
                  </div>
                ))}
              </div>

              <div className="bg-[#F2A900]/5 border border-[#F2A900]/15 rounded-none p-3 leading-relaxed text-[9px] text-[#F2A900]">
                🛡️ <strong>Sovereign Escrow:</strong> Agorist P2P Poker does not custody private keys. Funds are automatically distributed deterministically via multisig thresholds. No singular entry vector exists.
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Interactive live blocks diagram (7 columns) */}
        <div className="lg:col-span-7 flex flex-col space-y-6">
          <div className="rounded-none border border-white/[0.08] bg-[#111111] p-6 shadow-2xl text-left space-y-5">
            
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <h3 className="font-display text-xs font-bold text-[#F7F7F7] uppercase tracking-widest flex items-center space-x-2">
                <Database className="h-4 w-4 text-[#F2A900]" />
                <span>On-Chain Block Visualizer</span>
              </h3>
              <span className="text-[9px] font-mono text-[#6E6E6E] tracking-widest">LIVE BITCOIN MEMPOOL</span>
            </div>

            {/* Block graphics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { block: '840,121', size: '1.42 MB', tx: '3,842', time: '4m ago', status: 'CONFIRMED' },
                { block: '840,122', size: '1.58 MB', tx: '4,102', time: '12m ago', status: 'CONFIRMED' },
                { block: '840,123 (Mempool)', size: '2.10 MB', tx: '4,891', time: 'In Queue', status: 'PENDING' },
              ].map((blk, idx) => (
                <div 
                  key={idx} 
                  className={`border rounded-none p-4 flex flex-col justify-between h-36 font-mono text-[10px] ${
                    blk.status === 'CONFIRMED' 
                      ? 'border-[#4ADE80]/20 bg-[#191919] text-[#B7B7B7]' 
                      : 'border-[#F2A900]/30 bg-black/40 text-[#B7B7B7] border-dashed animate-pulse'
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className={blk.status === 'CONFIRMED' ? 'text-[#4ADE80]' : 'text-[#F2A900]'}>
                      {blk.status}
                    </span>
                    <span className="text-[#6E6E6E]">{blk.time}</span>
                  </div>

                  <div className="my-3 text-left">
                    <span className="text-[12px] font-bold text-[#F7F7F7] block">Block {blk.block}</span>
                    <span className="text-[#6E6E6E] text-[9px]">Transactions: {blk.tx}</span>
                  </div>

                  <div className="text-[8px] text-[#6E6E6E] border-t border-white/[0.08] pt-1.5 flex justify-between">
                    <span>SIZE: {blk.size}</span>
                    <span className="text-[#F2A900] font-bold">AGORIST POOL</span>
                  </div>
                </div>
              ))}
            </div>

            {/* General info */}
            <div className="text-[10px] font-mono text-[#6E6E6E] leading-relaxed">
              Agorist Poker operates custom Lightning channel payment hubs with Zero-Knowledge cryptographic privacy routers, completely decoupling ledger addresses from user's active game profiles. Your anonymity remains absolute.
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
