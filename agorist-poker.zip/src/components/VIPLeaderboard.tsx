/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Award, Trophy, Users, Shield, Target, Sparkles, Flame, Coins, Calendar } from 'lucide-react';
import { LEADERBOARD_DATA, ACTIVE_TOURNAMENTS } from '../data';

export default function VIPLeaderboard() {
  const [leaderboard, setLeaderboard] = useState(LEADERBOARD_DATA);
  const [activeTournaments, setActiveTournaments] = useState(ACTIVE_TOURNAMENTS);

  // Simulate leaderboard Satoshis updating occasionally for organic high-traffic feel
  useEffect(() => {
    const timer = setInterval(() => {
      setLeaderboard(prev =>
        prev.map(player => {
          if (Math.random() > 0.8) {
            const extraWins = Number((Math.random() * 0.05).toFixed(4));
            return {
              ...player,
              bitcoinWon: Number((player.bitcoinWon + extraWins).toFixed(3)),
              handsPlayed: player.handsPlayed + Math.floor(Math.random() * 5) + 1,
            };
          }
          return player;
        }).sort((a, b) => b.bitcoinWon - a.bitcoinWon)
          .map((p, idx) => ({ ...p, rank: idx + 1 }))
      );
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-6 py-10 lg:px-8 bg-[#060606]">
      
      {/* 1. Header Standings Panel */}
      <div className="border-b border-white/[0.06] pb-6 text-left">
        <h2 className="font-display text-xl font-extrabold text-[#F7F7F7] uppercase tracking-widest">
          The Satoshi Standings & Tournaments
        </h2>
        <p className="text-xs text-[#B7B7B7] mt-1 font-sans">
          Active high-roller leaders and guaranteed prize pool brackets. Settlement in BTC only.
        </p>
      </div>

      {/* 2. Main Content Grid (12 Columns) */}
      <div className="mt-8 grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: ACTIVE TOURNAMENTS CARD STACK (7 columns) */}
        <div className="xl:col-span-7 space-y-5">
          <div className="flex items-center space-x-2 text-[#F2A900] text-left mb-2">
            <Trophy className="h-4.5 w-4.5" />
            <h3 className="font-display text-xs font-bold uppercase tracking-widest">MAJOR ACTIVE BRACKETS</h3>
          </div>

          <div className="space-y-4">
            {activeTournaments.map((tourney) => (
              <div 
                key={tourney.id} 
                className="rounded-none border border-white/[0.08] bg-gradient-to-r from-[#111111] to-[#0a0a0a] p-5 relative overflow-hidden"
                id={`tourney-card-${tourney.id}`}
              >
                {/* Horizontal status accent line */}
                <div className="absolute top-0 left-0 w-1.5 h-full bg-[#F2A900]" />
                
                <div className="pl-2 space-y-4 text-left">
                  {/* Top line metadata */}
                  <div className="flex items-center justify-between">
                    <span className="font-display text-xs font-bold text-[#F7F7F7] uppercase tracking-wider">
                      {tourney.title}
                    </span>
                    <span className="text-[9px] font-mono rounded-none bg-[#F2A900]/10 border border-[#F2A900]/20 text-[#F2A900] px-2 py-0.5 uppercase">
                      LEVEL {tourney.currentLevel}
                    </span>
                  </div>

                  {/* Guaranteed prize pool large display */}
                  <div>
                    <span className="text-[20px] sm:text-[24px] font-display font-extrabold text-[#F7F7F7] tracking-tight block">
                      {tourney.prizePool}
                    </span>
                    <span className="text-[9px] font-mono text-[#6E6E6E] uppercase tracking-widest block">
                      GUARANTEED BTC PROTOCOL PRIZE
                    </span>
                  </div>

                  {/* High-density metrics row */}
                  <div className="grid grid-cols-3 gap-4 border-t border-white/[0.08] pt-4 font-mono text-[10px] text-[#B7B7B7]">
                    <div>
                      <span className="text-[#6E6E6E] text-[8px] uppercase block">ENTRANTS</span>
                      <strong>{tourney.entrants} Seated</strong>
                    </div>
                    <div>
                      <span className="text-[#6E6E6E] text-[8px] uppercase block">BUY-IN</span>
                      <strong className="text-[#F2A900]">{tourney.buyIn}</strong>
                    </div>
                    <div>
                      <span className="text-[#6E6E6E] text-[8px] uppercase block">LEVEL BLINDS</span>
                      <strong>1,000 / 2,000 Sat</strong>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* VIP Perks card */}
          <div className="rounded-none border border-white/[0.08] bg-[#111111]/40 p-5 text-left space-y-3">
            <span className="text-[10px] font-mono tracking-widest text-[#F2A900] uppercase block font-bold">
              👑 ELITE VIP PRIVILEGES
            </span>
            <p className="text-xs text-[#B7B7B7] leading-relaxed">
              Agorist Private Lounges are reserved for accounts holding validated VIP signatures. Enjoy 0% commission structures, customizable walnut wood felt visuals, hardware wallet deep-cold integration consults, and 24/7 dedicated system administrators.
            </p>
          </div>
        </div>

        {/* RIGHT COLUMN: HIGH ROW LEADERS STANDINGS (5 columns) */}
        <div className="xl:col-span-5 rounded-none border border-white/[0.08] bg-[#111111] p-5 shadow-2xl space-y-4 text-left">
          
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
            <h3 className="font-display text-xs font-bold text-[#F7F7F7] uppercase tracking-widest flex items-center space-x-2">
              <Award className="h-4 w-4 text-[#F2A900]" />
              <span>THE SATOSHI 100</span>
            </h3>
            <span className="text-[9px] font-mono text-[#6E6E6E]">SORT: NET SAT WON</span>
          </div>

          <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
            {leaderboard.map((player) => (
              <div 
                key={player.rank} 
                className="flex items-center justify-between p-3 rounded-none bg-black/40 border border-white/[0.04] text-[11px] font-mono transition-all hover:bg-white/[0.01]"
                id={`leaderboard-row-${player.rank}`}
              >
                
                {/* Left side detail */}
                <div className="flex items-center space-x-3">
                  <span className={`text-[10px] font-bold h-5 w-5 rounded-none flex items-center justify-center ${
                    player.rank === 1 ? 'bg-[#F2A900]/20 text-[#F2A900] border border-[#F2A900]/30' :
                    player.rank === 2 ? 'bg-[#B7B7B7]/20 text-[#B7B7B7] border border-[#B7B7B7]/30' :
                    'bg-[#191919] text-[#6E6E6E]'
                  }`}>
                    {player.rank}
                  </span>

                  <div className="space-y-0.5">
                    <div className="flex items-center space-x-1.5">
                      <span className="text-xs">{player.countryCode === 'CH' ? '🇨🇭' : player.countryCode === 'JP' ? '🇯🇵' : player.countryCode === 'DE' ? '🇩🇪' : player.countryCode === 'SG' ? '🇸🇬' : '🇦🇹'}</span>
                      <strong className="text-[#F7F7F7]">{player.name}</strong>
                    </div>
                    <span className="text-[9px] text-[#6E6E6E] block">
                      {player.handsPlayed} hands played
                    </span>
                  </div>
                </div>

                {/* Right side net profits */}
                <div className="text-right">
                  <span className="text-[#F2A900] font-extrabold">{player.bitcoinWon.toFixed(3)} BTC</span>
                  <span className="text-[9px] text-[#4ADE80] block font-sans">
                    {player.winRate}% WR
                  </span>
                </div>

              </div>
            ))}
          </div>

          <div className="text-[9px] font-mono text-[#6E6E6E] bg-white/[0.01] border border-white/[0.08] rounded-none p-2.5 text-center leading-relaxed">
            🛡️ <em>Leaderboard stats refresh instantly as blocks settle on-chain.</em>
          </div>

        </div>

      </div>

    </div>
  );
}
