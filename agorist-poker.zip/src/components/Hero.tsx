/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Play, Eye, ShieldAlert, Cpu, Wallet, KeyRound, Check, Award, ArrowUpRight, Zap } from 'lucide-react';
import { SUPPORTED_WALLETS } from '../data';

interface HeroProps {
  setView: (view: string) => void;
  walletAddress: string | null;
  onConnectWallet: (addr: string) => void;
  onDisconnectWallet: () => void;
}

export default function Hero({ setView, walletAddress, onConnectWallet, onDisconnectWallet }: HeroProps) {
  const [countdown, setCountdown] = useState({ days: 2, hours: 14, mins: 37, secs: 19 });
  const [selectedWallet, setSelectedWallet] = useState<string | null>(null);
  const [isSigning, setIsSigning] = useState(false);
  const [signatureStep, setSignatureStep] = useState(0);
  const [signedHash, setSignedHash] = useState('');
  const [seedChallenge, setSeedChallenge] = useState('');

  // High Roller Countdown Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev.secs > 0) {
          return { ...prev, secs: prev.secs - 1 };
        } else if (prev.mins > 0) {
          return { ...prev, mins: prev.mins - 1, secs: 59 };
        } else if (prev.hours > 0) {
          return { ...prev, hours: prev.hours - 1, mins: 59, secs: 59 };
        } else if (prev.days > 0) {
          return { days: prev.days - 1, hours: 23, mins: 59, secs: 59 };
        }
        return prev;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Handle Wallet Signature Process
  const handleWalletSelect = (walletId: string) => {
    setSelectedWallet(walletId);
    setSeedChallenge('AGORIST_AUTH_CHALLENGE_NONCE_' + Math.floor(Math.random() * 100000000).toString(16));
    setIsSigning(true);
    setSignatureStep(1); // Challenge generated

    // Step 2: Animated signature simulation (looks incredibly premium)
    setTimeout(() => {
      setSignatureStep(2); // Injecting cryptographic seed
    }, 1000);

    setTimeout(() => {
      setSignatureStep(3); // Generating SHA-256 signature
      const walletName = SUPPORTED_WALLETS.find(w => w.id === walletId)?.name || 'Generic';
      const fakeHash = '0x' + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      setSignedHash(fakeHash);
    }, 2200);

    setTimeout(() => {
      setSignatureStep(4); // Verified & Authenticated
      // Connect address
      const randomPrefix = walletId === 'alby' ? 'lnurl1' : 'bc1q';
      const fakeAddress = randomPrefix + Array.from({ length: 24 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
      onConnectWallet(fakeAddress);
    }, 3500);
  };

  const handleResetSignature = () => {
    setIsSigning(false);
    setSelectedWallet(null);
    setSignatureStep(0);
    setSignedHash('');
  };

  return (
    <section className="relative w-full overflow-hidden bg-[#060606] px-6 py-12 md:py-20 lg:px-8 lg:py-24 border-b border-white/[0.06]">
      {/* Background architectural light accents */}
      <div className="absolute top-0 left-1/4 h-[500px] w-[500px] rounded-full bg-gradient-to-br from-[#F2A900]/3 to-transparent blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 h-[400px] w-[400px] rounded-full bg-gradient-to-br from-[#4FA8FF]/2 to-transparent blur-[100px] pointer-events-none" />

      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-8 items-start">
          
          {/* LEFT COLUMN: Hero content & value propositions */}
          <div className="lg:col-span-7 flex flex-col space-y-8 text-left">
            
            {/* Subtle high-end subtitle with lines */}
            <div className="flex items-center space-x-3 text-[10px] font-mono tracking-[0.3em] text-[#F2A900] uppercase">
              <span className="h-[1px] w-6 bg-[#F2A900]/40" />
              <span>Play Freely. Keep What's Yours.</span>
              <span className="h-[1px] w-6 bg-[#F2A900]/40" />
            </div>

            {/* Title Block */}
            <h1 className="font-display text-4xl font-extrabold tracking-tight text-[#F7F7F7] sm:text-6xl uppercase leading-tight">
              Poker. <br />
              By Players. <br />
              <span className="text-[#F2A900]">
                For Players.
              </span>
            </h1>

            {/* Description */}
            <p className="max-w-xl font-sans text-sm sm:text-base text-[#B7B7B7] leading-relaxed">
              Agorist Poker is the premier Bitcoin poker room. 
              No KYC. No custody. Just you, your chips, and the game. 
              Enjoy peer-to-peer high stakes with global sovereign liquidity.
            </p>

            {/* CTA Actions */}
            <div className="flex flex-col sm:flex-row gap-4 pt-2">
              <button
                onClick={() => setView('table')}
                className="inline-flex h-14 items-center justify-center space-x-3 rounded-none bg-[#F2A900] px-8 text-xs font-bold uppercase tracking-widest text-[#060606] hover:bg-[#FFBD14] transition-all cursor-pointer group"
                id="btn-play-now-hero"
              >
                <Play className="h-4.5 w-4.5 fill-[#060606] text-[#060606] group-hover:scale-110 transition-transform" />
                <div className="flex flex-col items-start leading-none">
                  <span>Play Now</span>
                  <span className="text-[9px] font-mono tracking-wider text-[#060606]/60 mt-0.5 uppercase">Instant Seat</span>
                </div>
              </button>

              <button
                onClick={() => setView('lobby')}
                className="inline-flex h-14 items-center justify-center space-x-3 rounded-none border border-white/[0.1] bg-transparent hover:bg-white/5 px-8 text-xs font-bold uppercase tracking-widest text-[#F7F7F7] transition-all cursor-pointer"
                id="btn-view-tables-hero"
              >
                <Eye className="h-4.5 w-4.5 text-[#B7B7B7]" />
                <div className="flex flex-col items-start leading-none">
                  <span>View Tables</span>
                  <span className="text-[9px] font-mono tracking-wider text-[#6E6E6E] mt-0.5 uppercase">Live Poker Lobby</span>
                </div>
              </button>
            </div>

            {/* Direct Value Props in a row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-white/[0.05]">
              <div className="flex items-start space-x-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-none bg-white/[0.02] border border-white/[0.08]">
                  <ShieldAlert className="h-4.5 w-4.5 text-[#F2A900]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#F7F7F7] uppercase tracking-wider">No KYC</h4>
                  <p className="text-[11px] text-[#6E6E6E] mt-0.5">Play completely anonymously</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-none bg-white/[0.02] border border-white/[0.08]">
                  <Zap className="h-4.5 w-4.5 text-[#F2A900]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#F7F7F7] uppercase tracking-wider">Bitcoin native</h4>
                  <p className="text-[11px] text-[#6E6E6E] mt-0.5">Instant Lightning deposits</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-none bg-white/[0.02] border border-white/[0.08]">
                  <Cpu className="h-4.5 w-4.5 text-[#4FA8FF]" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-[#F7F7F7] uppercase tracking-wider">Provably fair</h4>
                  <p className="text-[11px] text-[#6E6E6E] mt-0.5">Verifiable on-chain shuffles</p>
                </div>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: Interactive High Roller and Web3 Sign-In Card */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            
            {/* 1. High Roller Tournament Box */}
            <div className="relative overflow-hidden rounded-none bg-gradient-to-br from-[#111111] to-[#060606] border border-white/[0.08] p-6 shadow-2xl">
              {/* Background gold badge water mark */}
              <div className="absolute top-[-30px] right-[-30px] opacity-5 pointer-events-none">
                <Award className="h-32 w-32 text-[#F2A900]" />
              </div>

              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono tracking-[0.25em] text-[#F2A900] uppercase font-bold">
                  High Roller
                </span>
                <span className="flex items-center space-x-1.5 rounded-none bg-[#F2A900]/10 border border-[#F2A900]/20 px-2.5 py-0.5 text-[9px] font-mono uppercase tracking-wider text-[#F2A900]">
                  <span className="h-1.5 w-1.5 rounded-none bg-[#F2A900] animate-pulse" />
                  <span>Registering</span>
                </span>
              </div>

              <div className="mt-4">
                <h3 className="font-display text-3xl font-extrabold text-[#F7F7F7] tracking-tight">
                  $250,000
                </h3>
                <p className="text-[11px] font-mono uppercase tracking-widest text-[#B7B7B7] mt-0.5">
                  Guaranteed Prize Pool
                </p>
              </div>

              {/* Grid Countdown */}
              <div className="grid grid-cols-4 gap-2 mt-5 text-center">
                {[
                  { label: 'Days', val: countdown.days },
                  { label: 'Hrs', val: countdown.hours },
                  { label: 'Min', val: countdown.mins },
                  { label: 'Sec', val: countdown.secs },
                ].map((item, idx) => (
                  <div key={idx} className="bg-white/[0.02] border border-white/[0.06] rounded-none p-2.5">
                    <span className="font-display text-lg font-bold text-[#F7F7F7] tracking-tight block">
                      {String(item.val).padStart(2, '0')}
                    </span>
                    <span className="text-[8px] font-mono uppercase tracking-widest text-[#6E6E6E] mt-0.5 block">
                      {item.label}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-5 flex items-center justify-between border-t border-white/[0.05] pt-4 font-mono text-xs">
                <span className="text-[#6E6E6E] uppercase">Buy-In:</span>
                <span className="text-[#F2A900] font-bold">1.5 BTC</span>
              </div>

              <button
                onClick={() => setView('leaderboard')}
                className="w-full mt-4 inline-flex h-11 items-center justify-center rounded-none border border-[#F2A900]/20 bg-[#F2A900]/5 hover:bg-[#F2A900]/10 text-[11px] font-bold uppercase tracking-widest text-[#F2A900] transition-all cursor-pointer"
                id="btn-view-tournament-hero"
              >
                <span>View Tournament</span>
              </button>
            </div>

            {/* 2. Web3 Sign-In Card */}
            <div className="rounded-none bg-[#111111] border border-white/[0.08] p-6 shadow-2xl relative">
              <h3 className="font-display text-sm font-bold text-[#F7F7F7] uppercase tracking-widest">
                Crypto Sign-In
              </h3>
              <p className="text-[11px] text-[#B7B7B7] mt-1">
                Sign in securely using your lightning or hardware wallet.
              </p>

              {/* Wallet Select Grid / Signature screen */}
              {!isSigning ? (
                <div className="mt-5 space-y-2">
                  <div className="grid grid-cols-2 gap-2">
                    {SUPPORTED_WALLETS.slice(0, 4).map((wallet) => (
                      <button
                        key={wallet.id}
                        onClick={() => handleWalletSelect(wallet.id)}
                        className="flex items-center space-x-2 bg-[#0d0d0d] border border-white/[0.06] hover:border-[#F2A900] rounded-none p-3 text-left transition-all cursor-pointer group"
                        id={`wallet-btn-${wallet.id}`}
                      >
                        <span className="text-xl group-hover:scale-110 transition-transform">{wallet.icon}</span>
                        <div className="flex flex-col">
                          <span className="text-[10px] font-bold text-[#F7F7F7] leading-tight">
                            {wallet.name.split(' ')[0]}
                          </span>
                          <span className="text-[8px] font-mono text-[#6E6E6E]">Connect</span>
                        </div>
                      </button>
                    ))}
                  </div>

                  {/* Rest of the wallets */}
                  <div className="grid grid-cols-2 gap-2">
                    {SUPPORTED_WALLETS.slice(4).map((wallet) => (
                      <button
                        key={wallet.id}
                        onClick={() => handleWalletSelect(wallet.id)}
                        className="flex items-center space-x-2 bg-[#0d0d0d] border border-white/[0.06] hover:border-[#F2A900] rounded-none p-3 text-left transition-all cursor-pointer group"
                        id={`wallet-btn-${wallet.id}`}
                      >
                        <span className="text-xl group-hover:scale-110 transition-transform">{wallet.icon}</span>
                        <div className="flex flex-col">
                          <span className="text-[10px] font-bold text-[#F7F7F7] leading-tight">
                            {wallet.name}
                          </span>
                          <span className="text-[8px] font-mono text-[#6E6E6E]">Connect</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                /* Premium simulation of cryptographic signature sequence */
                <div className="mt-5 bg-black/40 border border-white/[0.06] rounded-none p-4 font-mono text-left space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] text-[#F2A900] font-bold uppercase tracking-widest">
                      SYSTEM INTEGRITY SECURE
                    </span>
                    <button
                      onClick={handleResetSignature}
                      className="text-[9px] text-[#FF5A5A] hover:underline"
                      id="btn-cancel-signature"
                    >
                      Cancel
                    </button>
                  </div>

                  {/* Step Indicators */}
                  <div className="space-y-2.5 text-[10px] text-[#B7B7B7]">
                    <div className="flex items-center justify-between">
                      <span>1. Requesting wallet session...</span>
                      {signatureStep >= 1 ? (
                        <Check className="h-3.5 w-3.5 text-[#4ADE80]" />
                      ) : (
                        <span className="animate-pulse">●</span>
                      )}
                    </div>

                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center justify-between">
                        <span>2. Cryptographic challenge:</span>
                        {signatureStep >= 2 ? (
                          <span className="text-[#F2A900] font-bold">Generated</span>
                        ) : (
                          <span className="animate-pulse">...</span>
                        )}
                      </div>
                      {signatureStep >= 2 && (
                        <div className="bg-[#111111] border border-white/[0.05] rounded-none p-1 text-[8px] text-[#6E6E6E] break-all">
                          {seedChallenge}
                        </div>
                      )}
                    </div>

                    <div className="flex flex-col space-y-1">
                      <div className="flex items-center justify-between">
                        <span>3. Hardware wallet signature:</span>
                        {signatureStep >= 3 ? (
                          <span className="text-[#4FA8FF] font-bold">Signed</span>
                        ) : signatureStep === 2 ? (
                          <span className="animate-pulse text-[#F2A900]">Awaiting hardware approval...</span>
                        ) : (
                          <span>-</span>
                        )}
                      </div>
                      {signatureStep >= 3 && (
                        <div className="bg-[#111111] border border-white/[0.05] rounded-none p-1 text-[8px] text-[#6E6E6E] break-all font-mono">
                          Sig: {signedHash.substring(0, 32)}...
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-[#4ADE80] font-bold pt-1 border-t border-white/[0.05]">
                      <span>4. Authenticated Session:</span>
                      {signatureStep >= 4 ? (
                        <span className="flex items-center space-x-1 uppercase text-[9px] tracking-wider bg-[#4ADE80]/10 border border-[#4ADE80]/20 px-2 py-0.5 rounded-none">
                          <span>Secure</span>
                        </span>
                      ) : (
                        <span className="animate-pulse text-white">Validating...</span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Supported Wallets Row from Mockup */}
              {!isSigning && (
                <div className="mt-5 border-t border-white/[0.05] pt-4">
                  <span className="text-[8px] font-mono tracking-widest text-[#6E6E6E] uppercase block mb-2 text-center">
                    SUPPORTED ENCLAVES & WALLETS
                  </span>
                  <div className="flex items-center justify-center space-x-3 text-lg opacity-40 hover:opacity-75 transition-opacity">
                    <span>🦊</span>
                    <span>⚡</span>
                    <span>💀</span>
                    <span>🪙</span>
                    <span>🔑</span>
                  </div>
                </div>
              )}
            </div>

          </div>
        </div>

        {/* STATS STRIP (Direct alignment with prompt screenshot) */}
        <div className="mt-16 grid grid-cols-2 gap-4 rounded-none border border-white/[0.08] bg-[#111111]/80 p-6 backdrop-blur-sm sm:grid-cols-4 sm:p-8">
          {[
            { id: 'stat-players', val: '2,847', label: 'PLAYERS ONLINE', desc: 'Active cryptographic sessions' },
            { id: 'stat-jackpot', val: '$4,391,782', label: 'TOTAL JACKPOTS', desc: 'Sovereign BTC rewards pool' },
            { id: 'stat-tables', val: '130', label: 'ACTIVE TABLES', desc: 'High-stakes peer-to-peer' },
            { id: 'stat-uptime', val: '24/7', label: 'ALWAYS RUNNING', desc: '100% decentralized uptime' },
          ].map((stat, idx) => (
            <div key={idx} className="text-left border-r last:border-none border-white/[0.05] pr-4 last:pr-0" id={stat.id}>
              <span className="font-display text-2xl font-extrabold text-[#F7F7F7] tracking-tight block sm:text-3xl">
                {stat.val}
              </span>
              <span className="text-[10px] font-mono tracking-widest text-[#F2A900] uppercase block mt-1 font-bold">
                {stat.label}
              </span>
              <span className="text-[9px] text-[#6E6E6E] block mt-0.5 font-sans">
                {stat.desc}
              </span>
            </div>
          ))}
        </div>

        {/* WALNUT & CARBON FIBER CARD LANDING DISPLAY SECTION */}
        <div className="mt-16 relative overflow-hidden rounded-none border border-white/[0.08] bg-[#111111] p-8 sm:p-12 text-center">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-[#F2A900]/50 to-transparent" />
          
          <div className="max-w-2xl mx-auto space-y-4">
            <span className="text-[9px] font-mono tracking-[0.4em] text-[#F2A900] uppercase font-bold">
              THE ART OF THE DEAL
            </span>
            <h2 className="font-display text-2xl sm:text-4xl font-extrabold text-[#F7F7F7] uppercase tracking-tight">
              AESTHETICALLY SUPERIOR HARDWARE
            </h2>
            <p className="text-xs sm:text-sm text-[#B7B7B7] leading-relaxed">
              Every detail of Agorist Poker is sculpted using fine digital walnut wood, matte carbon fiber, and brushed titanium. 
              The layout adapts smoothly to 120Hz screens, making cards slide naturally with physically accurate micro-reflections.
            </p>
          </div>

          {/* Interactive Card Presentation using clean HTML representation */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-8 relative py-8">
            
            {/* The Walnut Table Base background effect */}
            <div className="absolute inset-0 bg-[#161616] border border-[#2c1d11]/30 rounded-none blur-xl opacity-20 transform scale-y-50 pointer-events-none" />

            {/* Left Card: Gold Agorist Ace */}
            <motion.div 
              initial={{ y: 20, rotate: -6 }}
              animate={{ y: [0, -10, 0], rotate: -6 }}
              transition={{ repeat: Infinity, duration: 6, ease: 'easeInOut' }}
              className="relative w-48 h-72 rounded-none bg-[#0d0d0d] border border-white/[0.1] hover:border-[#F2A900] p-4 flex flex-col justify-between shadow-2xl transition-colors group cursor-grab active:cursor-grabbing"
              style={{ boxShadow: '0 25px 50px -12px rgba(0,0,0,0.8)' }}
            >
              {/* Premium carbon fiber weave effect overlay */}
              <div className="absolute inset-0 rounded-none bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:8px_8px] opacity-10 pointer-events-none" />
              
              <div className="flex flex-col items-start leading-none">
                <span className="font-display text-xl font-bold text-[#F2A900]">A</span>
                <span className="text-xs text-[#F2A900] mt-1">♠</span>
              </div>

              {/* Gold Agorist emblem central logo */}
              <div className="self-center flex items-center justify-center">
                <div className="w-16 h-16 rounded-none border border-white/[0.1] group-hover:border-[#F2A900] flex items-center justify-center relative bg-gradient-to-b from-[#111111] to-black">
                  <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-b-[24px] border-[#F2A900] relative">
                    <div className="absolute top-[8px] left-[-5px] w-0 h-0 border-l-[5px] border-l-transparent border-r-[5px] border-r-transparent border-b-[10px] border-[#0d0d0d]" />
                  </div>
                </div>
              </div>

              <div className="flex flex-col items-end leading-none rotate-180">
                <span className="font-display text-xl font-bold text-[#F2A900]">A</span>
                <span className="text-xs text-[#F2A900] mt-1">♠</span>
              </div>
            </motion.div>

            {/* Right Card: King of Diamonds */}
            <motion.div 
              initial={{ y: 10, rotate: 6 }}
              animate={{ y: [0, -6, 0], rotate: 6 }}
              transition={{ repeat: Infinity, duration: 5, ease: 'easeInOut', delay: 0.5 }}
              className="relative w-48 h-72 rounded-none bg-[#0d0d0d] border border-white/[0.08] p-4 flex flex-col justify-between shadow-2xl hover:border-[#F2A900] transition-colors group cursor-grab active:cursor-grabbing"
              style={{ boxShadow: '0 25px 50px -12px rgba(0,0,0,0.8)' }}
            >
              <div className="absolute inset-0 rounded-none bg-[radial-gradient(#1a1a1a_1px,transparent_1px)] [background-size:8px_8px] opacity-10 pointer-events-none" />

              <div className="flex flex-col items-start leading-none">
                <span className="font-display text-xl font-bold text-[#F7F7F7]">K</span>
                <span className="text-xs text-[#FF5A5A] mt-1">♦</span>
              </div>

              {/* Centered Diamond icon */}
              <div className="self-center flex items-center justify-center">
                <div className="w-14 h-14 bg-[#111111] border border-white/[0.06] rounded-none rotate-45 flex items-center justify-center">
                  <span className="text-2xl text-[#FF5A5A] -rotate-45">♦</span>
                </div>
              </div>

              <div className="flex flex-col items-end leading-none rotate-180">
                <span className="font-display text-xl font-bold text-[#F7F7F7]">K</span>
                <span className="text-xs text-[#FF5A5A] mt-1">♦</span>
              </div>
            </motion.div>

            {/* Luxury stack of obsidian chips */}
            <div className="flex flex-col items-center space-y-[-12px] transform scale-90 sm:scale-100">
              {[...Array(6)].map((_, idx) => (
                <div 
                  key={idx} 
                  className="w-24 h-5 rounded-none bg-gradient-to-r from-[#111111] via-[#1a1a1a] to-[#0d0d0d] border-b-[3px] border-[#060606] shadow-lg flex items-center justify-between px-3 relative"
                  style={{
                    border: '1px solid rgba(255, 255, 255, 0.08)',
                    transform: `translateY(${idx * -1}px) rotateX(45deg)`,
                  }}
                >
                  <span className="w-1.5 h-1.5 rounded-none bg-[#F2A900]" />
                  <span className="text-[7px] font-mono text-white/50">1,000,000 SAT</span>
                  <span className="w-1.5 h-1.5 rounded-none bg-[#F2A900]" />
                </div>
              ))}
              <span className="text-[9px] font-mono text-[#6E6E6E] pt-4 block">OBSIDIAN SAT SHIELD</span>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
