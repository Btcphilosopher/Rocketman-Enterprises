/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type TableType = 'cash' | 'tournament' | 'sitgo' | 'highroller' | 'lightning';

export interface PokerTable {
  id: string;
  name: string;
  type: TableType;
  blinds: string;
  buyIn: string;
  playersCount: number;
  maxPlayers: number;
  avgPot: number; // in Satoshis/BTC
  avgStack: number; // in Satoshis/BTC
  handsPerHour: number;
  observerCount: number;
  latencyMs: number;
  connectionHealth: 'optimal' | 'stable' | 'congested';
}

export interface Player {
  id: string;
  name: string;
  country: string;
  countryCode: string; // e.g. 'US', 'JP', 'DE', 'CH'
  winRate: number; // Win %
  handsPlayed: number;
  currentStack: number; // in BTC or Satoshis
  recentAction: string; // e.g. "Folded", "Called", "Raised 0.05 BTC", "Thinking..."
  connectionQuality: number; // percentage, e.g. 98
  badge: 'Satoshi Club' | 'HODLer' | 'Genius' | 'Validator' | 'Genesis Node';
  avatarSeed: string; // for nice visual indicators
  cards?: Card[];
  isDealer?: boolean;
  isActive?: boolean;
  isHero?: boolean;
}

export interface Card {
  suit: 'spades' | 'hearts' | 'diamonds' | 'clubs';
  value: string; // "2"-"10", "J", "Q", "K", "A"
}

export interface GameState {
  stage: 'waiting' | 'dealing' | 'preflop' | 'flop' | 'turn' | 'river' | 'showdown' | 'ended';
  pot: number; // in BTC/Satoshis
  activeTableId: string | null;
  communityCards: Card[];
  currentTurnPlayerId: string | null;
  userCards: Card[];
  userStack: number;
  userCurrentBet: number;
  dealerIndex: number;
  opponents: Player[];
  winnerId: string | null;
  winningHandName: string | null;
  logMessages: string[];
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  country: string;
  countryCode: string;
  bitcoinWon: number; // in BTC
  handsPlayed: number;
  winRate: number;
  tier: 'Diamond' | 'Titanium' | 'Gold';
}

export interface Tournament {
  id: string;
  title: string;
  prizePool: string;
  entrants: number;
  maxEntrants: number;
  buyIn: string;
  timeLeftSeconds: number;
  blindTimerSeconds: number;
  currentLevel: number;
  status: 'upcoming' | 'registering' | 'active' | 'ended';
}

export interface Message {
  id: string;
  sender: string;
  content: string;
  timestamp: string;
  isSystem?: boolean;
  isAi?: boolean;
}
