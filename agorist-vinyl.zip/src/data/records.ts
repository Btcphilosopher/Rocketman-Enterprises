import { VinylProduct, QCReport } from "../types";

export const RECORDS_DATA: VinylProduct[] = [
  {
    id: "liminal-archive-02",
    artist: "AGORIST VINYL",
    release: "LIMINAL ARCHIVE .02",
    catalogNumber: "AV-LP-001",
    price: 32.00,
    weight: 180,
    rpm: 33,
    batchNo: "AV-2026-LA02",
    pressTolerance: "+0.0015 mm",
    masterCut: "DMM (Direct Metal Mastering)",
    dynamicRange: "15.4 dB",
    edition: "First Pressing, Ltd 300",
    runNumber: "001-300",
    qcPassed: "K. Althaus",
    releasedYear: 2026,
    coverStyle: "geometric",
    description: "An architectural exploration of space through frequency. Pressed on ultra-pure 180g virgin copolymer using direct-to-lathe lacquer transfers to minimize acoustic loss.",
    tracks: [
      { id: "la-01", title: "Voluntary Exchange Protocol", duration: "05:42", bpm: 122 },
      { id: "la-02", title: "Decentralized Node Alignment", duration: "06:14", bpm: 120 },
      { id: "la-03", title: "Non-Aggression Principle", duration: "04:55", bpm: 118 },
      { id: "la-04", title: "The Agoric Counter-Economy", duration: "07:01", bpm: 124 }
    ]
  },
  {
    id: "the-grid",
    artist: "ASC",
    release: "THE GRID",
    catalogNumber: "AV-LP-012",
    price: 28.00,
    weight: 180,
    rpm: 33,
    batchNo: "AV-2026-GR12",
    pressTolerance: "+0.0021 mm",
    masterCut: "Half-Speed Mastered Lacquer",
    dynamicRange: "14.8 dB",
    edition: "Standard Audiophile Weight",
    runNumber: "001-500",
    qcPassed: "J. Dietrich",
    releasedYear: 2025,
    coverStyle: "minimal",
    description: "A mathematically structured soundscape traversing rhythmic matrices and digital grids. Minimalist drum-and-bass architecture designed for deep playback response.",
    tracks: [
      { id: "tg-01", title: "Grid Alignment Alpha", duration: "06:30", bpm: 170 },
      { id: "tg-02", title: "Vector Fields", duration: "05:12", bpm: 168 },
      { id: "tg-03", title: "Acoustic Geometry", duration: "07:05", bpm: 172 },
      { id: "tg-04", title: "Zero State", duration: "04:48", bpm: 165 }
    ]
  },
  {
    id: "persistence-of-memory",
    artist: "M. DURAND",
    release: "PERSISTENCE OF MEMORY",
    catalogNumber: "AV-LP-014",
    price: 26.00,
    weight: 180,
    rpm: 45,
    batchNo: "AV-2026-PM14",
    pressTolerance: "+0.0019 mm",
    masterCut: "Neumann VMS-80 Direct Cut",
    dynamicRange: "14.2 dB",
    edition: "45 RPM Reference Series",
    runNumber: "001-250",
    qcPassed: "S. Tanaka",
    releasedYear: 2025,
    coverStyle: "photographic",
    description: "Time-dilation experiments recorded in isolated subterranean chambers. Deep analog drone synthesis with transient acoustic reflections.",
    tracks: [
      { id: "pm-01", title: "Dilated Horizon", duration: "08:12", bpm: 80 },
      { id: "pm-02", title: "Chronostatic Void", duration: "07:44", bpm: 75 }
    ]
  },
  {
    id: "dissonant-fields-1",
    artist: "V/A",
    release: "DISSONANT FIELDS VOL. 1",
    catalogNumber: "AV-LP-015",
    price: 30.00,
    weight: 200,
    rpm: 33,
    batchNo: "AV-2026-DF15",
    pressTolerance: "+0.0009 mm",
    masterCut: "Direct Metal Mastering (DMM)",
    dynamicRange: "16.1 dB",
    edition: "200g Ultra-Heavyweight Master",
    runNumber: "001-400",
    qcPassed: "K. Althaus",
    releasedYear: 2026,
    coverStyle: "abstract",
    description: "A collaborative compilation from modular sound designers mapping nonlinear physical processes. Extreme low-frequency performance engineered with extreme press tolerances.",
    tracks: [
      { id: "df-01", title: "Chaotic Pendulum", duration: "05:18", bpm: 110 },
      { id: "df-02", title: "Friction Vectors", duration: "06:02", bpm: 115 },
      { id: "df-03", title: "Thermodynamic Flow", duration: "05:54", bpm: 120 }
    ]
  },
  {
    id: "resonance-studies",
    artist: "K. NAKAMURA",
    release: "RESONANCE STUDIES",
    catalogNumber: "AV-LP-016",
    price: 27.00,
    weight: 180,
    rpm: 33,
    batchNo: "AV-2026-RS16",
    pressTolerance: "+0.0022 mm",
    masterCut: "Half-Speed Mastered Lacquer",
    dynamicRange: "14.9 dB",
    edition: "First Pressing, Standard Weight",
    runNumber: "001-600",
    qcPassed: "J. Dietrich",
    releasedYear: 2025,
    coverStyle: "line-art",
    description: "Acoustic measurement research utilizing custom physical resonators. Focuses on pure sine wave interference and organic mechanical resonance.",
    tracks: [
      { id: "rs-01", title: "Resonance Sweep (100Hz - 15kHz)", duration: "04:30", bpm: 90 },
      { id: "rs-02", title: "Harmonic Interferences", duration: "06:15", bpm: 95 },
      { id: "rs-03", title: "Nodal Grid Lines", duration: "05:40", bpm: 100 }
    ]
  },
  {
    id: "infinite-return",
    artist: "STONE TAPE",
    release: "INFINITE RETURN",
    catalogNumber: "AV-LP-018",
    price: 26.00,
    weight: 180,
    rpm: 45,
    batchNo: "AV-2026-IR18",
    pressTolerance: "+0.0018 mm",
    masterCut: "Neumann VMS-80 Direct Cut",
    dynamicRange: "15.0 dB",
    edition: "45 RPM Reference Series",
    runNumber: "001-350",
    qcPassed: "S. Tanaka",
    releasedYear: 2026,
    coverStyle: "abstract",
    description: "Cyclical tape loops processed through dual-reel analog delays. Creates an overlapping feedback matrix that mimics infinite, recursive time horizons.",
    tracks: [
      { id: "ir-01", title: "Recursive Feedback Sweep", duration: "09:04", bpm: 125 },
      { id: "ir-02", title: "Decaying Loop Vectors", duration: "07:56", bpm: 120 }
    ]
  },
  {
    id: "quiet-observers",
    artist: "R. HEATH",
    release: "QUIET OBSERVERS",
    catalogNumber: "AV-LP-019",
    price: 26.00,
    weight: 180,
    rpm: 33,
    batchNo: "AV-2026-QO19",
    pressTolerance: "+0.0020 mm",
    masterCut: "DMM (Direct Metal Mastering)",
    dynamicRange: "14.5 dB",
    edition: "First Edition, Ltd 400",
    runNumber: "001-400",
    qcPassed: "K. Althaus",
    releasedYear: 2025,
    coverStyle: "minimal",
    description: "Subtle psychoacoustic recordings capturing silence and room tones from historical industrial architecture. A triumph of silent press surfaces.",
    tracks: [
      { id: "qo-01", title: "Industrial Room Resonance", duration: "08:12", bpm: 60 },
      { id: "qo-02", title: "Low Frequency Acoustic Dust", duration: "07:30", bpm: 58 }
    ]
  }
];

export const QC_REPORTS: Record<string, QCReport> = {
  "AV-2026-LA02": {
    batchNo: "AV-2026-LA02",
    purity: "99.98% Virgin Co-polymer (Low-Static Formula)",
    thickness: "1.92 mm (Ref: Standard 1.90mm)",
    weightDistribution: "180.2g ±0.15g (N=100 sampling)",
    groovePurity: "Uncompromised (Zero Pre-echo detected)",
    measuredDr: 15.4,
    lacquerEngineer: "K. Althaus",
    hash: "8f7e34d612a9bc8d4fef9012cd345eaef8902dcb12e34f45a78d0ea67df562c1"
  },
  "AV-2026-GR12": {
    batchNo: "AV-2026-GR12",
    purity: "99.95% Virgin Co-polymer",
    thickness: "1.90 mm (Ref: Standard 1.90mm)",
    weightDistribution: "180.1g ±0.22g",
    groovePurity: "99.98% Surface Acoustic Compliance",
    measuredDr: 14.8,
    lacquerEngineer: "J. Dietrich",
    hash: "3a9f02cde02188ff6a71bb210103287deca11f75984ea0bc3e51ff088ad0892c"
  },
  "AV-2026-PM14": {
    batchNo: "AV-2026-PM14",
    purity: "99.97% Virgin High-Dynamic Vinyl",
    thickness: "1.94 mm",
    weightDistribution: "180.3g ±0.18g",
    groovePurity: "Direct-to-Disk High Transient Integrity",
    measuredDr: 14.2,
    lacquerEngineer: "S. Tanaka",
    hash: "b55c66d21ea5c6ef021817ef8a112cdcb334f5aa112e34fa5efd66aefbc892ea"
  },
  "AV-2026-DF15": {
    batchNo: "AV-2026-DF15",
    purity: "99.99% Extreme Purity Black Carbon Copolymer",
    thickness: "2.10 mm (Heavy Audiophile Standard)",
    weightDistribution: "200.4g ±0.12g (N=50 sampling)",
    groovePurity: "Ultra-low surface friction coating applied",
    measuredDr: 16.1,
    lacquerEngineer: "K. Althaus",
    hash: "da39a3ee5e6b4b0d3255bfef95601890afd80709fc71d74112e6c1a8aa019a71"
  },
  "AV-2026-RS16": {
    batchNo: "AV-2026-RS16",
    purity: "99.95% Virgin Co-polymer",
    thickness: "1.89 mm",
    weightDistribution: "179.8g ±0.25g",
    groovePurity: "Precision Cut for Fine Frequencies",
    measuredDr: 14.9,
    lacquerEngineer: "J. Dietrich",
    hash: "ef741bc23ef4518ff2a0134f9a0c12da9f9392e21b22ffef9012ebcaee124ff3"
  },
  "AV-2026-IR18": {
    batchNo: "AV-2026-IR18",
    purity: "99.96% Virgin Co-polymer",
    thickness: "1.91 mm",
    weightDistribution: "180.2g ±0.19g",
    groovePurity: "Excellent High-Frequency Response",
    measuredDr: 15.0,
    lacquerEngineer: "S. Tanaka",
    hash: "ab612faed39bcde8f112e5ffab61deaf61cdfe12ffbcda67812eafeee2e3f421"
  },
  "AV-2026-QO19": {
    batchNo: "AV-2026-QO19",
    purity: "99.98% Low-Noise Audiophile Formulation",
    thickness: "1.92 mm",
    weightDistribution: "180.1g ±0.11g",
    groovePurity: "Absolute Quiet Surfaces, S/N > 72dB",
    measuredDr: 14.5,
    lacquerEngineer: "K. Althaus",
    hash: "983bfedc214e2d3dfa67812ebcdfaef231dcb654fe786e21abcfefbcca78deaa"
  }
};
