import React, { useState, useEffect } from "react";
import { 
  Play, 
  Pause, 
  Volume2, 
  Trash2, 
  ChevronRight, 
  Info, 
  Maximize2, 
  Activity, 
  ShieldCheck, 
  Sparkles, 
  ArrowUpRight,
  ExternalLink,
  Disc,
  Sliders,
  Radio
} from "lucide-react";

import { RECORDS_DATA } from "./data/records";
import { VinylProduct, CartItem, Track } from "./types";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { ProductCard } from "./components/ProductCard";
import { ProductDetailsModal } from "./components/ProductDetailsModal";
import { Cart } from "./components/Cart";
import { BatchVerification } from "./components/BatchVerification";
import { LatheConfigurator } from "./components/LatheConfigurator";
import audioSystem from "./lib/audio";

// Fallback high-resolution layout placeholder in case of image load delay
const HERO_IMAGE_PATH = "/src/assets/images/liminal_archive_sleeve_1784220643019.jpg";

export default function App() {
  // Navigation & Category States
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [activeTab, setActiveTab] = useState<string>("records");
  const [searchQuery, setSearchQuery] = useState<string>("");

  // Modal / Dialog states
  const [selectedProduct, setSelectedProduct] = useState<VinylProduct | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isQCOpen, setIsQCOpen] = useState<boolean>(false);
  const [isLatheOpen, setIsLatheOpen] = useState<boolean>(false);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  // Web Audio Playback State
  const [playingProduct, setPlayingProduct] = useState<VinylProduct | null>(null);
  const [playingTrackId, setPlayingTrackId] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  // Braun physical audio controllers (Bottom docked bar)
  const [masterVolume, setMasterVolume] = useState<number>(0.6);
  const [crackleVolume, setCrackleVolume] = useState<number>(0.3);
  const [preampWarmth, setPreampWarmth] = useState<number>(65);

  // Synced state initialization for audio system
  useEffect(() => {
    audioSystem.setVolume(masterVolume);
    audioSystem.setCrackleLevel(crackleVolume);
    audioSystem.setWarmth(preampWarmth);
  }, []);

  // Update volume on change
  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setMasterVolume(val);
    audioSystem.setVolume(val);
  };

  // Update vinyl crackle level on change
  const handleCrackleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setCrackleVolume(val);
    audioSystem.setCrackleLevel(val);
  };

  // Update tube warmth parameter
  const handleWarmthChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    setPreampWarmth(val);
    audioSystem.setWarmth(val);
  };

  // Universal Audio Player Trigger
  const handlePlayProduct = (product: VinylProduct, trackId?: string) => {
    const targetTrackId = trackId || product.tracks[0]?.id;

    if (isPlaying && playingProduct?.id === product.id && playingTrackId === targetTrackId) {
      // Toggle play off if exact track clicked
      audioSystem.stop();
      setIsPlaying(false);
      setPlayingProduct(null);
      setPlayingTrackId(null);
    } else {
      // Trigger new audio
      const track = product.tracks.find(t => t.id === targetTrackId) || product.tracks[0];
      audioSystem.play(track.bpm || 120, product.catalogNumber);
      
      setPlayingProduct(product);
      setPlayingTrackId(track.id);
      setIsPlaying(true);

      // Instantly sync active physical dial controls
      audioSystem.setVolume(masterVolume);
      audioSystem.setCrackleLevel(crackleVolume);
      audioSystem.setWarmth(preampWarmth);
    }
  };

  const handleStopAudio = () => {
    audioSystem.stop();
    setIsPlaying(false);
    setPlayingProduct(null);
    setPlayingTrackId(null);
  };

  // Cart operations
  const handleAddToCart = (product: VinylProduct, quantity: number = 1, weight: number = 180) => {
    setCartItems(prev => {
      const existingIndex = prev.findIndex(
        item => item.product.id === product.id && item.selectedWeight === weight
      );
      if (existingIndex > -1) {
        const copy = [...prev];
        copy[existingIndex].quantity += quantity;
        return copy;
      }
      return [...prev, { product, quantity, selectedWeight: weight }];
    });
    setIsCartOpen(true);
  };

  const handleRemoveFromCart = (productId: string, weight: number) => {
    setCartItems(prev => prev.filter(
      item => !(item.product.id === productId && item.selectedWeight === weight)
    ));
  };

  const handleUpdateCartQuantity = (productId: string, weight: number, newQty: number) => {
    setCartItems(prev => prev.map(item => {
      if (item.product.id === productId && item.selectedWeight === weight) {
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Filtering Logic
  const filteredProducts = RECORDS_DATA.filter(product => {
    // 1. Tab check: Records tab only
    if (activeTab !== "records") return false;

    // 2. Search check
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchName = product.release.toLowerCase().includes(q);
      const matchArtist = product.artist.toLowerCase().includes(q);
      const matchCat = product.catalogNumber.toLowerCase().includes(q);
      if (!matchName && !matchArtist && !matchCat) return false;
    }

    // 3. Category category check
    if (activeCategory === "all") return true;
    if (activeCategory === "new" && product.releasedYear === 2026) return true;
    if (activeCategory === "pre-order" && product.id === "liminal-archive-02") return true;
    if (activeCategory === "bestseller" && (product.id === "the-grid" || product.id === "dissonant-fields-1")) return true;
    if (activeCategory === "staff-pick" && (product.id === "persistence-of-memory" || product.id === "resonance-studies")) return true;
    if (activeCategory === "clearance" && product.price <= 26.00) return true;

    return false;
  });

  const heroAlbum = RECORDS_DATA[0];

  return (
    <div className="min-h-screen flex flex-col justify-between bg-[#FAFAF8] text-[#111111] font-sans selection:bg-black selection:text-white relative pb-32 overflow-hidden">
      
      {/* Clean Minimalism CAD Grid & Decorative Line Overlays */}
      <div className="absolute inset-0 pointer-events-none border-[1px] border-[#E7E7E7] m-4 md:m-8 z-0"></div>
      <div className="absolute top-1/2 left-0 w-full h-[1px] bg-[#E7E7E7] opacity-40 z-0 pointer-events-none"></div>
      <div className="absolute left-1/2 top-0 w-[1px] h-full bg-[#E7E7E7] opacity-40 z-0 pointer-events-none"></div>
      <div className="absolute bottom-40 right-[-80px] rotate-90 text-[140px] font-extrabold text-[#111111] opacity-[0.015] pointer-events-none select-none tracking-tighter z-0">
        AGORIST
      </div>
      <div className="absolute top-20 left-[-80px] -rotate-90 text-[140px] font-extrabold text-[#111111] opacity-[0.012] pointer-events-none select-none tracking-tighter z-0">
        VINYL
      </div>

      {/* Dynamic Background Noise Overlay */}
      <div className="absolute inset-0 pointer-events-none paper-texture z-10"></div>

      <div className="flex flex-col lg:flex-row items-stretch flex-1 relative z-10">
        
        {/* Sticky Left Column Sidebar */}
        <Sidebar 
          activeCategory={activeCategory}
          setActiveCategory={(cat) => {
            setActiveCategory(cat);
            setActiveTab("records"); // Automatically shift view
          }}
          onOpenVerification={() => setIsQCOpen(true)}
          onOpenLathe={() => setIsLatheOpen(true)}
        />

        {/* Right Content Stream Container */}
        <div className="flex-1 flex flex-col justify-between min-w-0">
          
          {/* Top Sticky Header bar */}
          <Header 
            cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
            onOpenCart={() => setIsCartOpen(true)}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            activeTab={activeTab}
            setActiveTab={(tab) => {
              setActiveTab(tab);
              setActiveCategory("all"); // Reset category filter on tab shift
            }}
          />

          {/* Main Layout Stream */}
          <main className="flex-1 flex flex-col">
            
            {/* TAB 1: RECORDS CATALOGUE */}
            {activeTab === "records" && (
              <>
                {/* Hero Editorial Display */}
                <Hero 
                  heroAlbum={heroAlbum}
                  onPlayAlbum={(album) => handlePlayProduct(album)}
                  onOpenDetails={(album) => setSelectedProduct(album)}
                  onBrowseRecords={() => {
                    const el = document.getElementById("catalog-target");
                    el?.scrollIntoView({ behavior: "smooth" });
                  }}
                  isPlayingHero={isPlaying && playingProduct?.id === heroAlbum.id}
                  heroImageSrc={HERO_IMAGE_PATH}
                />

                {/* Main Product Catalog Section */}
                <section className="p-6 lg:p-12 border-b border-[#E7E7E7]" id="catalog-target">
                  <div className="flex justify-between items-center mb-8 border-b border-neutral-200 pb-4">
                    <div className="flex items-center gap-3">
                      <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">
                        [FEATURED CATALOGUE]
                      </span>
                      <span className="font-mono text-[8px] text-neutral-400">
                        {filteredProducts.length} ACTIVE REFERENCE ALLOCATIONS
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 font-mono text-[9px] text-[#555555]">
                      <span>CURRENT MATRIX FILTER:</span>
                      <span className="text-black font-semibold uppercase">{activeCategory}</span>
                    </div>
                  </div>

                  {/* 3-Column responsive Grid */}
                  {filteredProducts.length === 0 ? (
                    <div className="py-24 text-center border border-dashed border-neutral-200 flex flex-col items-center justify-center gap-3 bg-white">
                      <span className="font-mono text-xs text-neutral-400">NO BATCH MATCHES FOUND WITH ACTIVE QUERY CONFIGURATION</span>
                      <button 
                        onClick={() => {
                          setSearchQuery("");
                          setActiveCategory("all");
                        }}
                        className="font-mono text-[10px] font-bold border border-black px-4 py-2 hover:bg-black hover:text-white transition-colors"
                      >
                        RESET FILTERS
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 lg:gap-8">
                      {filteredProducts.map((product) => (
                        <ProductCard 
                          key={product.id}
                          product={product}
                          onOpenDetails={(prod) => setSelectedProduct(prod)}
                          onPlayTrack={(prod) => handlePlayProduct(prod)}
                          onAddToCart={(prod) => handleAddToCart(prod, 1, prod.weight)}
                          isPlaying={isPlaying && playingProduct?.id === product.id}
                        />
                      ))}
                    </div>
                  )}
                </section>
              </>
            )}

            {/* TAB 2: AUDIO EQUIPMENT (Dieter Rams Laboratory Inspired) */}
            {activeTab === "equipment" && (
              <section className="p-8 lg:p-12 flex flex-col gap-8 max-w-7xl mx-auto w-full">
                <div className="border-b border-neutral-200 pb-4">
                  <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">[HEAVY HARDWARE REFERENCE]</span>
                  <h2 className="font-sans font-extrabold text-3xl uppercase tracking-tight mt-1 text-black">Precision Playback Instruments</h2>
                  <p className="font-sans text-xs text-[#555555] mt-1">Dieter Rams and Braun-inspired machinery built to pull un-degraded transient curves out of continuous physical grooves.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* EQ-1: Reference Turntable */}
                  <div className="bg-white border border-[#E7E7E7] p-6 flex flex-col justify-between group">
                    <div className="aspect-video bg-[#FAFAF8] border border-neutral-200 flex items-center justify-center relative mb-6">
                      <span className="absolute top-2 left-2 font-mono text-[7px] text-neutral-400">DRAWING NO. AV-TT-100</span>
                      {/* Stylized Turntable Wireframe */}
                      <svg className="w-40 h-40 text-black/80" viewBox="0 0 100 100" fill="none">
                        <rect x="5" y="15" width="90" height="70" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="45" cy="50" r="30" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="45" cy="50" r="8" stroke="currentColor" strokeWidth="0.25" />
                        <circle cx="45" cy="50" r="2" fill="currentColor" />
                        <line x1="80" y1="20" x2="60" y2="60" stroke="currentColor" strokeWidth="0.75" />
                        <circle cx="80" cy="20" r="3" stroke="currentColor" strokeWidth="0.5" fill="white" />
                        <circle cx="20" cy="80" r="1.5" fill="currentColor" />
                        <circle cx="25" cy="80" r="1.5" fill="currentColor" />
                      </svg>
                    </div>

                    <div className="flex flex-col gap-1">
                      <div className="flex justify-between text-[9px] font-mono text-neutral-400 uppercase tracking-wider">
                        <span>INSTRUMENT NO: AG-TT-100</span>
                        <span>CNC ALUMINIUM ASSEMBLY</span>
                      </div>
                      <h3 className="font-sans font-extrabold text-lg text-black uppercase tracking-tight mt-1">AG-TT-100 Direct Lathe Platter</h3>
                      <p className="font-sans text-xs text-[#555555] leading-relaxed my-2">
                        Zero-cogging direct drive motor featuring a 5.2kg CNC machined aerospace grade billet aluminium platter. Real-time optical quartz loop monitoring calibrated to &plusmn;0.0003% rotational deviation.
                      </p>
                      
                      <div className="border-t border-b border-neutral-100 py-2 my-2 font-mono text-[9px] text-[#555555] flex justify-between">
                        <span>ROTATIONAL STABILITY: &plusmn;0.0003%</span>
                        <span>SN-RATIO: &gt; 82 dB</span>
                      </div>

                      <div className="flex justify-between items-center pt-2">
                        <span className="font-mono text-sm font-extrabold text-black">$1,450.00 USD</span>
                        <button 
                          onClick={() => alert("Hardware dispatch simulation logged. Reference order queue for AV-TT-100 initialized.")}
                          className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase tracking-widest px-4 py-2"
                        >
                          COMMISSION BUILD
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* EQ-2: Vacuum Tube Preamp */}
                  <div className="bg-white border border-[#E7E7E7] p-6 flex flex-col justify-between group">
                    <div className="aspect-video bg-[#FAFAF8] border border-neutral-200 flex items-center justify-center relative mb-6">
                      <span className="absolute top-2 left-2 font-mono text-[7px] text-neutral-400">DRAWING NO. AV-PA-04</span>
                      {/* Stylized Preamp Wireframe */}
                      <svg className="w-40 h-40 text-black/80" viewBox="0 0 100 100" fill="none">
                        <rect x="10" y="25" width="80" height="50" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="25" cy="50" r="6" stroke="currentColor" strokeWidth="0.5" />
                        <line x1="25" y1="44" x2="25" y2="56" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="45" cy="50" r="6" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="65" cy="50" r="6" stroke="currentColor" strokeWidth="0.5" />
                        <rect x="80" y="45" width="4" height="10" stroke="currentColor" strokeWidth="0.5" />
                        <line x1="15" y1="35" x2="85" y2="35" stroke="currentColor" strokeWidth="0.25" strokeDasharray="1,1" />
                      </svg>
                    </div>

                    <div className="flex flex-col gap-1">
                      <div className="flex justify-between text-[9px] font-mono text-neutral-400 uppercase tracking-wider">
                        <span>INSTRUMENT NO: AG-PA-04</span>
                        <span>PURE TRIODE VACUUM SYSTEM</span>
                      </div>
                      <h3 className="font-sans font-extrabold text-lg text-black uppercase tracking-tight mt-1">AG-PA-04 Vacuum Tube Pre-Amplifier</h3>
                      <p className="font-sans text-xs text-[#555555] leading-relaxed my-2">
                        Dual-mono class-A tube preamplifier leveraging reference matched NOS Telefunken ECC83 triodes. Custom hand-wound toroidal power transformers ensure absolute electrostatic silence.
                      </p>
                      
                      <div className="border-t border-b border-neutral-100 py-2 my-2 font-mono text-[9px] text-[#555555] flex justify-between">
                        <span>INPUT IMPEDANCE: 47k Ohms</span>
                        <span>THD: &lt; 0.0018% AT 1kHz</span>
                      </div>

                      <div className="flex justify-between items-center pt-2">
                        <span className="font-mono text-sm font-extrabold text-black">$820.00 USD</span>
                        <button 
                          onClick={() => alert("Vacuum Preamp build order logged in direct queue.")}
                          className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase tracking-widest px-4 py-2"
                        >
                          COMMISSION BUILD
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* TAB 3: BOOKS (Agorist and Economic Philosophy) */}
            {activeTab === "books" && (
              <section className="p-8 lg:p-12 flex flex-col gap-8 max-w-7xl mx-auto w-full">
                <div className="border-b border-neutral-200 pb-4">
                  <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">[AGORIC THEORY SHELF]</span>
                  <h2 className="font-sans font-extrabold text-3xl uppercase tracking-tight mt-1 text-black">Philosophical Blueprints</h2>
                  <p className="font-sans text-xs text-[#555555] mt-1">Voluntary exchange manuals, counter-economic blueprints, and classic structural critique designed to endure.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Book 1 */}
                  <div className="bg-white border border-[#E7E7E7] p-5 flex flex-col justify-between">
                    <div className="bg-neutral-100 aspect-[3/4] border border-neutral-200 flex flex-col justify-between p-6 mb-4 relative paper-texture text-black">
                      <span className="font-mono text-[7px] text-[#555555]">ISBN-12 // PRINTED 1979</span>
                      <h4 className="font-sans font-extrabold text-lg uppercase tracking-tight text-center my-auto leading-tight">
                        Our Enemy,<br />The State
                      </h4>
                      <span className="font-mono text-[8px] text-[#555555] text-center">ALBERT JAY NOCK</span>
                    </div>
                    <div className="flex flex-col gap-1 font-mono text-[9px] text-[#555555]">
                      <div className="flex justify-between uppercase">
                        <span>VOL: STANDARD PB</span>
                        <span>CAT: AV-BK-001</span>
                      </div>
                      <h3 className="font-sans font-bold text-xs text-black uppercase mt-1">Our Enemy, The State</h3>
                      <span className="font-sans text-xs text-black font-extrabold mt-1">$14.00 USD</span>
                      <button 
                        onClick={() => alert("Book catalog allocation logged.")}
                        className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase py-2 tracking-widest text-center mt-3"
                      >
                        ADD ALLOCATION
                      </button>
                    </div>
                  </div>

                  {/* Book 2 */}
                  <div className="bg-white border border-[#E7E7E7] p-5 flex flex-col justify-between">
                    <div className="bg-neutral-150 aspect-[3/4] border border-neutral-200 flex flex-col justify-between p-6 mb-4 relative paper-texture text-black">
                      <span className="font-mono text-[7px] text-[#555555]">ISBN-09 // PRINTED 1980</span>
                      <h4 className="font-sans font-extrabold text-lg uppercase tracking-tight text-center my-auto leading-tight">
                        New Libertarian<br />Manifesto
                      </h4>
                      <span className="font-mono text-[8px] text-[#555555] text-center">SAMUEL EDWARD KONKIN III</span>
                    </div>
                    <div className="flex flex-col gap-1 font-mono text-[9px] text-[#555555]">
                      <div className="flex justify-between uppercase">
                        <span>VOL: HEAVY WEIGHT PRINT</span>
                        <span>CAT: AV-BK-002</span>
                      </div>
                      <h3 className="font-sans font-bold text-xs text-black uppercase mt-1">New Libertarian Manifesto</h3>
                      <span className="font-sans text-xs text-black font-extrabold mt-1">$16.00 USD</span>
                      <button 
                        onClick={() => alert("Book catalog allocation logged.")}
                        className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase py-2 tracking-widest text-center mt-3"
                      >
                        ADD ALLOCATION
                      </button>
                    </div>
                  </div>

                  {/* Book 3 */}
                  <div className="bg-white border border-[#E7E7E7] p-5 flex flex-col justify-between">
                    <div className="bg-neutral-100 aspect-[3/4] border border-neutral-200 flex flex-col justify-between p-6 mb-4 relative paper-texture text-black">
                      <span className="font-mono text-[7px] text-[#555555]">ISBN-24 // PRINTED 2011</span>
                      <h4 className="font-sans font-extrabold text-lg uppercase tracking-tight text-center my-auto leading-tight">
                        An Agorist<br />Primer
                      </h4>
                      <span className="font-mono text-[8px] text-[#555555] text-center">SEK3 ACADEMY</span>
                    </div>
                    <div className="flex flex-col gap-1 font-mono text-[9px] text-[#555555]">
                      <div className="flex justify-between uppercase">
                        <span>VOL: MINI PB</span>
                        <span>CAT: AV-BK-003</span>
                      </div>
                      <h3 className="font-sans font-bold text-xs text-black uppercase mt-1">An Agorist Primer</h3>
                      <span className="font-sans text-xs text-black font-extrabold mt-1">$12.00 USD</span>
                      <button 
                        onClick={() => alert("Book catalog allocation logged.")}
                        className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase py-2 tracking-widest text-center mt-3"
                      >
                        ADD ALLOCATION
                      </button>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* TAB 4: MERCH (Precision apparel and items) */}
            {activeTab === "merch" && (
              <section className="p-8 lg:p-12 flex flex-col gap-8 max-w-7xl mx-auto w-full">
                <div className="border-b border-neutral-200 pb-4">
                  <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">[UTILITY APPAREL &amp; ASSETS]</span>
                  <h2 className="font-sans font-extrabold text-3xl uppercase tracking-tight mt-1 text-black">Laboratory Accoutrements</h2>
                  <p className="font-sans text-xs text-[#555555] mt-1">Stark, highly tactile industrial jackets and machined copper parts engineered for the active sound technician.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Item 1 */}
                  <div className="bg-white border border-[#E7E7E7] p-6 flex flex-col justify-between">
                    <div className="aspect-square bg-[#FAFAF8] border border-neutral-200 flex items-center justify-center mb-6 relative">
                      <span className="absolute top-2 left-2 font-mono text-[7px] text-neutral-400">REFERENCE: AV-AP-M01</span>
                      {/* Stylized Coat drawing */}
                      <svg className="w-32 h-32 text-black/80" viewBox="0 0 100 100" fill="none">
                        <path d="M30 20 L50 35 L70 20 L80 40 L70 90 L30 90 L20 40 Z" stroke="currentColor" strokeWidth="0.75" />
                        <line x1="50" y1="35" x2="50" y2="90" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="50" cy="50" r="1" fill="currentColor" />
                        <circle cx="50" cy="65" r="1" fill="currentColor" />
                        <circle cx="50" cy="80" r="1" fill="currentColor" />
                      </svg>
                    </div>
                    <div className="flex flex-col gap-1.5 font-mono text-[9px] text-[#555555]">
                      <div className="flex justify-between uppercase">
                        <span>SIZE: S / M / L</span>
                        <span>100% ORGANIC LINEN CANVAS</span>
                      </div>
                      <h3 className="font-sans font-extrabold text-base text-black uppercase tracking-tight mt-1">AV-AP-M01 Lab Press Technician Coat</h3>
                      <p className="font-sans text-xs text-[#555555] leading-normal my-2">
                        Stark white lab technician coat styled with deep storage pockets for anti-static brushes and calibration tools. Heavyweight linen construction designed for physical longevity.
                      </p>
                      <span className="font-mono text-sm font-extrabold text-black mt-2">$145.00 USD</span>
                      <button 
                        onClick={() => alert("Linen Coat added to direct shipment roster.")}
                        className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase py-2.5 tracking-widest text-center mt-3"
                      >
                        COMMISSION GARMENT
                      </button>
                    </div>
                  </div>

                  {/* Item 2 */}
                  <div className="bg-white border border-[#E7E7E7] p-6 flex flex-col justify-between">
                    <div className="aspect-square bg-[#FAFAF8] border border-neutral-200 flex items-center justify-center mb-6 relative">
                      <span className="absolute top-2 left-2 font-mono text-[7px] text-neutral-400">REFERENCE: AV-AC-04</span>
                      {/* Stylized Machined spindle Adapter */}
                      <svg className="w-32 h-32 text-black/80" viewBox="0 0 100 100" fill="none">
                        <polygon points="50,15 80,45 80,75 50,90 20,75 20,45" stroke="currentColor" strokeWidth="0.75" />
                        <circle cx="50" cy="53" r="15" stroke="currentColor" strokeWidth="0.5" />
                        <circle cx="50" cy="53" r="3.5" fill="currentColor" />
                        <line x1="50" y1="15" x2="50" y2="38" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1,1" />
                        <line x1="20" y1="75" x2="38" y2="62" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1,1" />
                      </svg>
                    </div>
                    <div className="flex flex-col gap-1.5 font-mono text-[9px] text-[#555555]">
                      <div className="flex justify-between uppercase">
                        <span>MATERIAL: PURE BILLET COPPER</span>
                        <span>WEIGHT: 320G DENSE</span>
                      </div>
                      <h3 className="font-sans font-extrabold text-base text-black uppercase tracking-tight mt-1">AV-AC-04 Machined Copper Spindle Hub</h3>
                      <p className="font-sans text-xs text-[#555555] leading-normal my-2">
                        CNC carved solid copper 45 RPM record adapter and spindle stabilizer. Weighted precisely to absorb platter micro-vibrations and steady rotational drag.
                      </p>
                      <span className="font-mono text-sm font-extrabold text-black mt-2">$65.00 USD</span>
                      <button 
                        onClick={() => alert("Machined spindle added to direct shipment.")}
                        className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold uppercase py-2.5 tracking-widest text-center mt-3"
                      >
                        ADD ALLOCATION
                      </button>
                    </div>
                  </div>
                </div>
              </section>
            )}

            {/* TAB 5: JOURNAL THINK PIECES */}
            {activeTab === "journal" && (
              <section className="p-8 lg:p-12 flex flex-col gap-8 max-w-4xl mx-auto w-full">
                <div className="border-b border-neutral-200 pb-4">
                  <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">[COOPERATIVE ARCHIVE // ESSAYS]</span>
                  <h2 className="font-sans font-extrabold text-3xl uppercase tracking-tight mt-1 text-black">Acoustic Counter-Economics</h2>
                  <p className="font-sans text-xs text-[#555555] mt-1">Critical investigations detailing structural acoustics, voluntary distribution, and raw thermodynamic media physical mechanics.</p>
                </div>

                <div className="flex flex-col divide-y divide-neutral-200">
                  {/* Essay 1 */}
                  <article className="py-8 flex flex-col gap-3">
                    <div className="flex justify-between items-center font-mono text-[9px] text-neutral-400">
                      <span>DOCUMENT NO: JOURNAL_14</span>
                      <span>PUBLISHED: JULY 2026 // 8 MIN READ</span>
                    </div>
                    <h3 className="font-sans font-extrabold text-xl text-black hover:underline cursor-pointer uppercase tracking-tight">
                      The Thermodynamics of Analog Grooves: Physical Degradation vs. Digital Extinction
                    </h3>
                    <p className="font-sans text-xs text-[#555555] leading-relaxed">
                      An investigation into physical matter as a vehicle for true permanent information storage. We analyze why lacquer cuts degrade on a linear predictable logarithmic curve, while digital distribution models suffer sudden systemic extinction through centralized gatekeeper licensing agreements...
                    </p>
                    <a href="#read" className="font-mono text-[9px] font-bold text-black hover:underline self-start uppercase mt-2">READ SPECIFICATION SCHEMATIC →</a>
                  </article>

                  {/* Essay 2 */}
                  <article className="py-8 flex flex-col gap-3">
                    <div className="flex justify-between items-center font-mono text-[9px] text-neutral-400">
                      <span>DOCUMENT NO: JOURNAL_12</span>
                      <span>PUBLISHED: FEB 2026 // 12 MIN READ</span>
                    </div>
                    <h3 className="font-sans font-extrabold text-xl text-black hover:underline cursor-pointer uppercase tracking-tight">
                      Decentralizing the Pressing Lathe: High-Precision Local Copolymer Extrusions
                    </h3>
                    <p className="font-sans text-xs text-[#555555] leading-relaxed">
                      A research paper mapping the transition from heavy industrial coal-fired pressing factories to high-precision, small-scale local desktop extrusion lathes. Explores how voluntary cooperatives can build local micro-presses with zero central tracking...
                    </p>
                    <a href="#read" className="font-mono text-[9px] font-bold text-black hover:underline self-start uppercase mt-2">READ SPECIFICATION SCHEMATIC →</a>
                  </article>

                  {/* Essay 3 */}
                  <article className="py-8 flex flex-col gap-3">
                    <div className="flex justify-between items-center font-mono text-[9px] text-neutral-400">
                      <span>DOCUMENT NO: JOURNAL_09</span>
                      <span>PUBLISHED: NOV 2025 // 6 MIN READ</span>
                    </div>
                    <h3 className="font-sans font-extrabold text-xl text-black hover:underline cursor-pointer uppercase tracking-tight">
                      Evaluating Voluntarism in Intellectual Property and Physical Master Copies
                    </h3>
                    <p className="font-sans text-xs text-[#555555] leading-relaxed">
                      How Agorist Vinyl bypasses centralized corporate copyright frameworks. Discusses the legal architecture of distributing master physical lacquer ownership rights directly to community members, protecting artists' wallets and buyers' permanently.
                    </p>
                    <a href="#read" className="font-mono text-[9px] font-bold text-black hover:underline self-start uppercase mt-2">READ SPECIFICATION SCHEMATIC →</a>
                  </article>
                </div>
              </section>
            )}

            {/* TAB 6: ABOUT AGORIST VINYL */}
            {activeTab === "about" && (
              <section className="p-8 lg:p-12 flex flex-col gap-10 max-w-3xl mx-auto w-full">
                <div className="border-b border-neutral-200 pb-4">
                  <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">[COOPERATIVE PROFILES // STATEMENTS]</span>
                  <h2 className="font-sans font-extrabold text-3xl uppercase tracking-tight mt-1 text-black">Built For Owners. Not Renters.</h2>
                  <p className="font-sans text-xs text-[#555555] mt-1">Agorist Vinyl is a high-precision materials and acoustics engineering cooperative that happens to press and sell vinyl records.</p>
                </div>

                <div className="flex flex-col gap-6 font-sans text-xs text-[#555555] leading-relaxed">
                  <p>
                    We operate entirely on the principles of **Agorism**—the philosophy of building free, voluntary networks that exist outside the rent-seeking, centralized political economy. We do not accept gatekeepers, licensing monopolies, or platform tolls.
                  </p>
                  
                  <div className="border-l-[1.5px] border-black pl-4 py-1 my-2 italic text-black font-semibold uppercase tracking-wide">
                    "Voluntary exchange is the highest form of human cooperative action. Sound is the highest form of physical wave transmission."
                  </div>

                  <p>
                    Traditional record stores sell collectibles; we manufacture durable physical documents. Our records are engineered to endure decades, pressed on ultra-dense 180g and 200g low-static copolymer bases under cleanroom conditions.
                  </p>

                  <h3 className="font-mono text-[10px] text-black uppercase font-bold tracking-widest mt-6">[OUR WORKFLOW RULES]</h3>
                  <ul className="flex flex-col gap-2.5 font-mono text-[9px] text-[#555555] list-decimal pl-4">
                    <li><strong>NO STRUCTURAL DEBT:</strong> All operations are fully funded and owned by the cooperative, bypassing banking intermediaries.</li>
                    <li><strong>ABSOLUTE DISCLOSURE:</strong> Every batch is logged with material composition, weight deviation, and Measured Dynamic Range.</li>
                    <li><strong>DIRECT REVENUE ESCROW:</strong> Over 80% of all voluntary proceeds go directly into the designated artist's cryptographic wallet.</li>
                    <li><strong>CLIENT-SIDE RESILIENCY:</strong> Our digital platforms contain no tracking scripts, analytics cookies, or centralized database servers.</li>
                  </ul>
                </div>
              </section>
            )}

          </main>

          {/* Page Bottom Technical Features Grid */}
          <section className="p-6 lg:p-12 bg-white border-t border-[#E7E7E7] grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 lg:gap-8 select-none">
            
            <div className="flex flex-col justify-between p-4 border border-neutral-150 relative">
              <div className="flex items-center gap-3">
                {/* Custom CAD crosshair */}
                <div className="w-8 h-8 rounded-full border border-black flex items-center justify-center relative shrink-0">
                  <div className="absolute w-[1px] h-full bg-black"></div>
                  <div className="absolute h-[1px] w-full bg-black"></div>
                </div>
                <div className="flex flex-col">
                  <span className="font-mono text-[9px] text-[#555555] uppercase font-bold">PROTOCOL I</span>
                  <h4 className="font-sans font-extrabold text-xs uppercase tracking-tight text-black">AGORIST IN CONCEPT</h4>
                </div>
              </div>
              <p className="font-sans text-[11px] text-[#555555] leading-relaxed my-4">
                We operate entirely outside the rent-seeking extraction economy. No gatekeepers, artificial scarcity, or platform tolls. Only pure voluntary exchange.
              </p>
              <button 
                onClick={() => {
                  setActiveTab("about");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }} 
                className="font-mono text-[8px] font-bold text-black hover:underline self-start uppercase mt-auto"
              >
                LEARN MORE →
              </button>
            </div>

            <div className="flex flex-col justify-between p-4 border border-neutral-150">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full border border-dashed border-neutral-300 flex items-center justify-center shrink-0">
                  <Activity className="w-3.5 h-3.5 text-black" />
                </div>
                <div className="flex flex-col">
                  <span className="font-mono text-[9px] text-[#555555] uppercase font-bold">PROTOCOL II</span>
                  <h4 className="font-sans font-extrabold text-xs uppercase tracking-tight text-black">HIGH-PRECISION PRESSING</h4>
                </div>
              </div>
              <p className="font-sans text-[11px] text-[#555555] leading-relaxed my-4">
                Our records are pressed under pristine laboratory conditions using low-friction 180g and 200g virgin copolymer formulas to secure uncompromised physical playback.
              </p>
              <button 
                onClick={() => setIsLatheOpen(true)}
                className="font-mono text-[8px] font-bold text-black hover:underline self-start uppercase mt-auto"
              >
                LEARN MORE →
              </button>
            </div>

            <div className="flex flex-col justify-between p-4 border border-neutral-150">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 border border-neutral-300 flex items-center justify-center shrink-0">
                  <div className="w-4 h-4 border border-black"></div>
                </div>
                <div className="flex flex-col">
                  <span className="font-mono text-[9px] text-[#555555] uppercase font-bold">PROTOCOL III</span>
                  <h4 className="font-sans font-extrabold text-xs uppercase tracking-tight text-black">DIRECT DISTRIBUTION</h4>
                </div>
              </div>
              <p className="font-sans text-[11px] text-[#555555] leading-relaxed my-4">
                We distribute physical master records directly from localized press hubs to collectors. Artists keep over 80% of all generated proceeds securely.
              </p>
              <button 
                onClick={() => {
                  setActiveTab("records");
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }} 
                className="font-mono text-[8px] font-bold text-black hover:underline self-start uppercase mt-auto"
              >
                LEARN MORE →
              </button>
            </div>

            <div className="flex flex-col justify-between p-4 border border-neutral-150">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full border border-neutral-300 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-3.5 h-3.5 text-black" />
                </div>
                <div className="flex flex-col">
                  <span className="font-mono text-[9px] text-[#555555] uppercase font-bold">PROTOCOL IV</span>
                  <h4 className="font-sans font-extrabold text-xs uppercase tracking-tight text-black">PRIVACY RESPECTED</h4>
                </div>
              </div>
              <p className="font-sans text-[11px] text-[#555555] leading-relaxed my-4">
                Zero telemetry trackers, no cookies, no metadata profiling. Your delivery addresses are encrypted local variables that dissolve on closure.
              </p>
              <button 
                onClick={() => setIsQCOpen(true)}
                className="font-mono text-[8px] font-bold text-black hover:underline self-start uppercase mt-auto"
              >
                LEARN MORE →
              </button>
            </div>

          </section>

          {/* Technical Documentation styled Footer */}
          <footer className="bg-[#FAFAF8] border-t border-[#E7E7E7] px-6 lg:px-12 py-6 text-[9px] font-mono text-[#555555] flex flex-col md:flex-row justify-between items-center gap-4 md:gap-0 select-none">
            
            <div className="flex items-center gap-6">
              <span>&copy; AGORIST VINYL COOPERATIVE 2026</span>
              <div className="flex gap-4">
                <a href="#terms" onClick={(e) => { e.preventDefault(); alert("Acoustic Terms: All physical master transfers are permanent."); }} className="hover:text-black">TERMS</a>
                <a href="#privacy" onClick={(e) => { e.preventDefault(); alert("Privacy Statement: No data is saved, compiled, or transmitted."); }} className="hover:text-black">PRIVACY</a>
                <a href="#shipping" onClick={(e) => { e.preventDefault(); alert("Shipping Rules: Ships globally from independent decentralized hubs."); }} className="hover:text-black">SHIPPING</a>
                <a href="#returns" onClick={(e) => { e.preventDefault(); alert("Return protocol: Physical defects verified under 0.05% tolerance are replaced free."); }} className="hover:text-black">RETURNS</a>
                <a href="#faq" onClick={(e) => { e.preventDefault(); alert("FAQ: Agorist Vinyl presses standard 33/45 RPM records on virgin co-polymer."); }} className="hover:text-black">FAQ</a>
              </div>
            </div>

            <span className="text-black font-semibold uppercase tracking-wider hidden lg:inline">
              BUILT FOR OWNERS. NOT RENTERS.
            </span>

            {/* Micro QR Barcode */}
            <div className="flex items-center gap-3">
              <span className="text-[7px] text-right font-medium">QC BATCH LEDGER: // APPROVED</span>
              <div className="flex gap-[1px] items-stretch h-5 bg-black p-0.5" title="SHA256 CHECKSUM BARCODE">
                <span className="w-0.5 bg-white"></span>
                <span className="w-1 bg-white"></span>
                <span className="w-0.5 bg-white"></span>
                <span className="w-[1.5px] bg-white"></span>
                <span className="w-0.5 bg-white"></span>
                <span className="w-1 bg-white"></span>
                <span className="w-[2.5px] bg-white"></span>
                <span className="w-0.5 bg-white"></span>
                <span className="w-[1.5px] bg-white"></span>
                <span className="w-0.5 bg-white"></span>
                <span className="w-1 bg-white"></span>
              </div>
            </div>

          </footer>

        </div>

      </div>

      {/* BRAUN-INSPIRED STICKY PHYSICAL CONTROLLER BAR (Docked Bottom Ambient Listening Station) */}
      <div className="fixed bottom-0 left-0 right-0 bg-[#FAFAF8] border-t-2 border-black z-40 p-4 md:px-8 select-none shadow-[0_-15px_30px_rgba(0,0,0,0.05)]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 md:gap-8">
          
          {/* Section 1: Active Plate Monitor */}
          <div className="flex items-center gap-4 w-full md:w-auto">
            {/* Spinning Indicator */}
            <div className={`w-10 h-10 rounded-full bg-black flex items-center justify-center shrink-0 border border-neutral-800 relative shadow-inner ${
              isPlaying ? "animate-[spin_3s_linear_infinite]" : ""
            }`}>
              <Disc className="w-5 h-5 text-neutral-300" />
              <div className="absolute w-2 h-2 bg-[#FAFAF8] rounded-full border border-neutral-400"></div>
            </div>

            <div className="flex flex-col min-w-0">
              <div className="flex items-center gap-2">
                <span className="font-mono text-[8px] bg-black text-[#FAFAF8] px-1 font-bold">PLAYING</span>
                {isPlaying && (
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                )}
              </div>
              <span className="font-sans font-bold text-xs text-black uppercase truncate mt-0.5">
                {playingProduct ? `${playingProduct.artist} — ${playingProduct.release}` : "PLATE MONITOR IDLE"}
              </span>
              <span className="font-mono text-[8px] text-[#555555] tracking-wider mt-0.5 uppercase">
                {playingProduct ? `CURRENT RPM: 33.3 // ${playingProduct.catalogNumber}` : "STANDBY CONTROLLER"}
              </span>
            </div>
          </div>

          {/* Section 2: Braun Dial Sliders */}
          <div className="flex-1 w-full grid grid-cols-3 gap-6 max-w-xl font-mono text-[9px] text-[#555555]">
            
            {/* Dial 1: Volume */}
            <div className="flex flex-col gap-1.5 bg-neutral-50 p-2 border border-neutral-200">
              <div className="flex justify-between items-center">
                <span className="font-bold text-black flex items-center gap-1">
                  <Volume2 className="w-3 h-3 text-black" />
                  VOL:
                </span>
                <span className="font-bold text-black">{(masterVolume * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={masterVolume}
                onChange={handleVolumeChange}
                className="w-full accent-black h-1 bg-neutral-200 cursor-pointer"
                id="volume-slider"
              />
            </div>

            {/* Dial 2: Static Crackle level */}
            <div className="flex flex-col gap-1.5 bg-neutral-50 p-2 border border-neutral-200">
              <div className="flex justify-between items-center">
                <span className="font-bold text-black flex items-center gap-1">
                  <Sliders className="w-3 h-3 text-black" />
                  CRACKLE:
                </span>
                <span className="font-bold text-black">{(crackleVolume * 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="1.0"
                step="0.05"
                value={crackleVolume}
                onChange={handleCrackleChange}
                className="w-full accent-black h-1 bg-neutral-200 cursor-pointer"
                id="crackle-slider"
              />
            </div>

            {/* Dial 3: Preamp Tube Warmth */}
            <div className="flex flex-col gap-1.5 bg-neutral-50 p-2 border border-neutral-200">
              <div className="flex justify-between items-center">
                <span className="font-bold text-black flex items-center gap-1">
                  <Radio className="w-3 h-3 text-black" />
                  WARMTH:
                </span>
                <span className="font-bold text-black">{preampWarmth}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={preampWarmth}
                onChange={handleWarmthChange}
                className="w-full accent-black h-1 bg-neutral-200 cursor-pointer"
                id="warmth-slider"
              />
            </div>

          </div>

          {/* Section 3: Physical Action Toggles */}
          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            {isPlaying && (
              <button
                onClick={handleStopAudio}
                className="bg-red-600 hover:bg-red-700 text-white font-mono text-[9px] font-extrabold tracking-widest px-4 py-2 uppercase cursor-pointer"
                id="audio-stop-trigger"
              >
                STOP SYNTH
              </button>
            )}

            <button
              onClick={() => {
                if (playingProduct) {
                  setSelectedProduct(playingProduct);
                } else {
                  setSelectedProduct(heroAlbum);
                }
              }}
              className="border border-black hover:bg-black hover:text-white text-black font-mono text-[9px] font-extrabold tracking-widest px-4 py-2 uppercase cursor-pointer"
            >
              INSPECT CAD
            </button>
          </div>

        </div>
      </div>

      {/* RENDER DYNAMIC FLOATING DRAWER OVERLAYS */}
      
      {/* 1. Spec Sheet Schematic Modal */}
      <ProductDetailsModal 
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onPlayTrack={(prod, trackId) => handlePlayProduct(prod, trackId)}
        currentlyPlayingId={playingTrackId}
        isPlaying={isPlaying && playingProduct?.id === selectedProduct?.id}
      />

      {/* 2. Direct Shipment Cart slide-drawer */}
      <Cart 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onRemoveItem={handleRemoveFromCart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onClearCart={handleClearCart}
      />

      {/* 3. Cryptographic Merkle Batch QC verification */}
      <BatchVerification 
        isOpen={isQCOpen}
        onClose={() => setIsQCOpen(false)}
      />

      {/* 4. High-Precision Lathe Master Cutter Configurator */}
      <LatheConfigurator 
        isOpen={isLatheOpen}
        onClose={() => setIsLatheOpen(false)}
      />

    </div>
  );
}
