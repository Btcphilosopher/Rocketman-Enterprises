import React, { useState, useEffect } from "react";
import { X, Play, Volume2, ShieldCheck, ChevronRight, Settings2 } from "lucide-react";
import { VinylProduct } from "../types";
import { VinylCover } from "./VinylCover";
import audioSystem from "../lib/audio";

interface ProductDetailsModalProps {
  product: VinylProduct | null;
  onClose: () => void;
  onAddToCart: (product: VinylProduct, quantity: number, weight: number) => void;
  onPlayTrack: (product: VinylProduct, trackId?: string) => void;
  currentlyPlayingId: string | null;
  isPlaying: boolean;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onPlayTrack,
  currentlyPlayingId,
  isPlaying,
}) => {
  if (!product) return null;

  const [selectedWeight, setSelectedWeight] = useState<number>(product.weight);
  const [quantity, setQuantity] = useState<number>(1);
  const [stylusForce, setStylusForce] = useState<number>(1.8); // Grams of force
  const [grooveDepth, setGrooveDepth] = useState<number>(35); // Micrometers

  // Calculated stats based on sliders
  const calculatedSnr = (72 + (grooveDepth - 35) * 0.15 - (Math.abs(stylusForce - 1.8) * 1.4)).toFixed(1);
  const estimatedWearRate = ((stylusForce * 1.5) + (grooveDepth > 40 ? 1.2 : 0)).toFixed(2);

  // Close with Esc key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      
      {/* Outer Content Card */}
      <div 
        className="bg-[#FAFAF8] w-full max-w-5xl h-[90vh] md:h-[80vh] border border-black overflow-y-auto no-scrollbar flex flex-col justify-between shadow-2xl relative"
        id="product-details-container"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header bar styled like an oscilloscope readout */}
        <div className="sticky top-0 bg-black text-[#FAFAF8] px-6 py-4 flex items-center justify-between border-b border-neutral-800 z-10">
          <div className="flex flex-col">
            <span className="font-mono text-[9px] text-neutral-400 tracking-widest uppercase">
              SPECIFICATION DOCUMENT // BATCH {product.batchNo}
            </span>
            <h2 className="font-sans font-extrabold text-sm md:text-base tracking-tight uppercase mt-0.5">
              {product.artist} — {product.release}
            </h2>
          </div>
          
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white border border-neutral-800 hover:border-neutral-500 p-1.5 transition-colors"
            id="modal-close-btn"
          >
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        {/* Content Body Grid */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-neutral-200">
          
          {/* Left Column: Sleeve Visualizer and Physical Configurator */}
          <div className="p-6 md:p-8 flex flex-col justify-between gap-8 bg-white overflow-y-auto no-scrollbar">
            
            {/* Vector Vinyl Sleeve */}
            <div className="flex justify-center relative bg-[#FAFAF8] border border-neutral-200 p-8">
              <div className="absolute top-2 left-2 font-mono text-[7px] text-neutral-400">
                POS_Y: 412 // COORDS_X
              </div>
              <div className="w-56 md:w-72 aspect-square">
                <VinylCover
                  style={product.coverStyle}
                  artist={product.artist}
                  release={product.release}
                  catalogNumber={product.catalogNumber}
                  isPlaying={isPlaying}
                />
              </div>
            </div>

            {/* Tactical Calibration Controls (Stylus Tracking & Grooves depth) */}
            <div className="border border-neutral-200/80 p-4 bg-neutral-50 flex flex-col gap-4">
              <div className="flex items-center gap-2 text-[9px] font-mono font-bold text-black border-b border-neutral-200 pb-2">
                <Settings2 className="w-3.5 h-3.5" />
                <span> stylus tracking & grooves calibration</span>
              </div>

              {/* Slider 1: Stylus force */}
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between font-mono text-[9px]">
                  <span className="text-[#555555]">STYLUS TRACKING FORCE</span>
                  <span className="font-bold text-black">{stylusForce} grams</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.1"
                  value={stylusForce}
                  onChange={(e) => setStylusForce(parseFloat(e.target.value))}
                  className="w-full accent-black h-1 bg-neutral-200 rounded-none cursor-pointer"
                />
                <span className="font-mono text-[7px] text-neutral-400">OPTIMAL RANGE: 1.5g - 2.0g for low record degradation</span>
              </div>

              {/* Slider 2: Micro-groove Depth */}
              <div className="flex flex-col gap-1.5 mt-1">
                <div className="flex justify-between font-mono text-[9px]">
                  <span className="text-[#555555]">GROOVE CUT DEPTH</span>
                  <span className="font-bold text-black">{grooveDepth} µm</span>
                </div>
                <input
                  type="range"
                  min="25"
                  max="55"
                  step="1"
                  value={grooveDepth}
                  onChange={(e) => setGrooveDepth(parseInt(e.target.value))}
                  className="w-full accent-black h-1 bg-neutral-200 rounded-none cursor-pointer"
                />
                <span className="font-mono text-[7px] text-neutral-400">GREATER DEPTH = INCREASED BASS RESPONSE (+0.15dB SNR/µm)</span>
              </div>

              {/* Dynamic Feedback readout */}
              <div className="grid grid-cols-2 gap-2 border-t border-neutral-200 pt-3 font-mono text-[8px] text-[#555555]">
                <div className="flex flex-col gap-0.5 bg-white p-2 border border-neutral-200">
                  <span>SIGNAL TO NOISE RATIO:</span>
                  <span className="font-bold text-black text-xs">{calculatedSnr} dB</span>
                </div>
                <div className="flex flex-col gap-0.5 bg-white p-2 border border-neutral-200">
                  <span>GROOVE WEAR COEFFICIENT:</span>
                  <span className="font-bold text-red-600 text-xs">{estimatedWearRate} λ/hr</span>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Audio Playback, Tracklist and Purchase spec sheet */}
          <div className="p-6 md:p-8 flex flex-col justify-between gap-8 bg-neutral-50/30 overflow-y-auto no-scrollbar">
            
            {/* Audio Section & Tracklist */}
            <div className="flex flex-col gap-4">
              <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold border-b border-neutral-200 pb-1">
                [AUDIO REFERENCE TRACKS]
              </span>

              {/* Minimal Waveform playback monitor */}
              <div className="border border-neutral-200 p-4 bg-white flex flex-col gap-2">
                <div className="flex justify-between items-center text-[8px] font-mono text-[#555555]">
                  <span>MONITOR RESOLUTION: ANALOG OUTPUT</span>
                  <span>{isPlaying ? "STATUS: 33.3 RPM CALIBRATED" : "STATUS: STANDBY"}</span>
                </div>
                {/* Micro visualizer bar */}
                <div className="h-10 bg-black flex gap-[1px] items-end p-1 overflow-hidden">
                  {Array.from({ length: 48 }).map((_, i) => (
                    <div 
                      key={i} 
                      className="flex-1 bg-[#FAFAF8] transition-all duration-300"
                      style={{ 
                        height: isPlaying 
                          ? `${10 + Math.sin(i * 0.4 + (currentlyPlayingId ? 1 : 0)) * 40 + Math.random() * 45}%` 
                          : "3%" 
                      }}
                    ></div>
                  ))}
                </div>
              </div>

              {/* List of track components */}
              <div className="flex flex-col divide-y divide-neutral-100">
                {product.tracks.map((track, i) => {
                  const isTrackPlaying = isPlaying && (currentlyPlayingId === track.id || (!currentlyPlayingId && i === 0));
                  return (
                    <button
                      key={track.id}
                      onClick={() => onPlayTrack(product, track.id)}
                      className={`w-full py-3 text-left font-sans flex items-center justify-between group transition-colors px-2 ${
                        isTrackPlaying ? "bg-black text-[#FAFAF8]" : "hover:bg-neutral-100 text-black"
                      }`}
                      id={`track-play-row-${track.id}`}
                    >
                      <div className="flex items-center gap-3">
                        <span className={`font-mono text-[9px] ${isTrackPlaying ? "text-neutral-400" : "text-[#555555]"}`}>
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        <span className="font-bold text-xs tracking-tight uppercase">
                          {track.title}
                        </span>
                      </div>

                      <div className="flex items-center gap-3 font-mono text-[9px]">
                        {track.bpm && (
                          <span className={`${isTrackPlaying ? "text-neutral-400" : "text-[#555555]"}`}>
                            {track.bpm} BPM
                          </span>
                        )}
                        <span className={`${isTrackPlaying ? "text-neutral-300" : "text-[#555555] font-semibold"}`}>
                          {track.duration}
                        </span>
                        
                        <div className="w-5 h-5 border border-current flex items-center justify-center text-[10px]">
                          {isTrackPlaying ? "■" : "▶"}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Engineering specifications table */}
            <div className="flex flex-col gap-3">
              <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold border-b border-neutral-200 pb-1">
                [MANUFACTURING SPECIFICATIONS]
              </span>

              <div className="grid grid-cols-2 gap-x-6 gap-y-2.5 font-mono text-[10px] bg-white p-4 border border-neutral-200">
                <div className="flex justify-between border-b border-neutral-100 pb-1.5">
                  <span className="text-[#555555]">MASTER CUT ENGINE:</span>
                  <span className="text-black font-semibold uppercase">{product.masterCut}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-100 pb-1.5">
                  <span className="text-[#555555]">PRESS TOLERANCE:</span>
                  <span className="text-black font-semibold">{product.pressTolerance}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-100 pb-1.5">
                  <span className="text-[#555555]">DYNAMIC RANGE:</span>
                  <span className="text-black font-semibold">{product.dynamicRange}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-100 pb-1.5">
                  <span className="text-[#555555]">ESTIMATED RPM:</span>
                  <span className="text-black font-semibold">{product.rpm} RPM</span>
                </div>
                <div className="flex justify-between border-b border-neutral-100 pb-1.5">
                  <span className="text-[#555555]">EDITION QUANTITY:</span>
                  <span className="text-black font-semibold uppercase">{product.edition}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-100 pb-1.5">
                  <span className="text-[#555555]">QC SIGN-OFF:</span>
                  <span className="text-black font-semibold uppercase">{product.qcPassed}</span>
                </div>
                <div className="flex justify-between col-span-2 text-[8px] text-neutral-400 pt-1">
                  <span>BLOCK ENCRYPTED HASH PROOF:</span>
                  <span className="font-mono truncate max-w-sm">
                    {product.batchNo.toLowerCase()}-hash-9f8e3d8f8a1122daefbc8971032
                  </span>
                </div>
              </div>
            </div>

            {/* Direct purchase configurations */}
            <div className="border-t border-neutral-200 pt-6 flex flex-col sm:flex-row gap-6 justify-between items-stretch sm:items-end">
              
              {/* Weight selection */}
              <div className="flex flex-col gap-2">
                <span className="font-mono text-[9px] text-[#555555] tracking-wider uppercase">SELECT VINYL WEIGHT:</span>
                <div className="flex border border-black p-0.5 self-start bg-white">
                  <button
                    onClick={() => {
                      setSelectedWeight(180);
                    }}
                    className={`font-mono text-[9px] font-bold px-3 py-1.5 ${
                      selectedWeight === 180 ? "bg-black text-white" : "text-black hover:bg-neutral-50"
                    }`}
                  >
                    180G REFERENCE
                  </button>
                  <button
                    onClick={() => {
                      setSelectedWeight(200);
                    }}
                    className={`font-mono text-[9px] font-bold px-3 py-1.5 ${
                      selectedWeight === 200 ? "bg-black text-white" : "text-black hover:bg-neutral-50"
                    }`}
                  >
                    200G ULTRA-HEAVY
                  </button>
                </div>
              </div>

              {/* Quantity and direct add */}
              <div className="flex items-center gap-3">
                <div className="flex flex-col gap-2">
                  <span className="font-mono text-[9px] text-[#555555] tracking-wider uppercase">QTY:</span>
                  <div className="flex border border-black bg-white font-mono text-[10px] font-bold">
                    <button 
                      onClick={() => setQuantity(q => Math.max(1, q - 1))}
                      className="px-2 py-1.5 border-r border-black hover:bg-neutral-50"
                    >
                      -
                    </button>
                    <span className="px-3 py-1.5 self-center">{quantity}</span>
                    <button 
                      onClick={() => setQuantity(q => q + 1)}
                      className="px-2 py-1.5 border-l border-black hover:bg-neutral-50"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="flex flex-col gap-2 flex-1 sm:flex-initial">
                  <span className="font-mono text-[9px] opacity-0">SPACING</span>
                  <button
                    onClick={() => {
                      onAddToCart(product, quantity, selectedWeight);
                      onClose();
                    }}
                    className="bg-black hover:bg-neutral-900 text-white font-mono text-[10px] font-bold tracking-widest uppercase px-6 py-3 border border-black"
                    id="add-to-cart-drawer-btn"
                  >
                    ADD TO DIRECT SHIPMENT // ${(product.price * quantity).toFixed(2)}
                  </button>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Footer info bar */}
        <div className="bg-neutral-100 px-6 py-3 border-t border-neutral-200 flex justify-between items-center text-[8px] font-mono text-[#555555]">
          <div className="flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-black" />
            <span>DIRECT OWNERSHIP PROTOCOL ENFORCED</span>
          </div>
          <span>AGORIST VINYL MANUFACTURE &copy; 2026 // ALL RIGHTS SECURED INDEPENDENTLY</span>
        </div>

      </div>
    </div>
  );
};
