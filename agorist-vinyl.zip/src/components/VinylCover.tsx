import React from "react";

interface VinylCoverProps {
  style: "geometric" | "minimal" | "line-art" | "abstract" | "photographic";
  artist: string;
  release: string;
  catalogNumber: string;
  isPlaying?: boolean;
  size?: string;
  className?: string;
}

export const VinylCover: React.FC<VinylCoverProps> = ({
  style,
  artist,
  release,
  catalogNumber,
  isPlaying = false,
  size = "100%",
  className = "",
}) => {
  return (
    <div
      className={`relative overflow-hidden bg-white aspect-square border border-[#E7E7E7] select-none paper-texture flex flex-col justify-between p-6 ${className}`}
      style={{ width: size, height: size }}
      id={`cover-${catalogNumber.toLowerCase()}`}
    >
      {/* Background CAD Target Guides */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.04]">
        {/* Hairline grid lines */}
        <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-black"></div>
        <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-black"></div>
        {/* Crosshair markers in corners */}
        <div className="absolute top-2 left-2 w-4 h-4 border border-black flex items-center justify-center">
          <div className="w-[1px] h-full bg-black"></div>
          <div className="h-[1px] w-full bg-black absolute"></div>
        </div>
        <div className="absolute top-2 right-2 w-4 h-4 border border-black flex items-center justify-center">
          <div className="w-[1px] h-full bg-black"></div>
          <div className="h-[1px] w-full bg-black absolute"></div>
        </div>
        <div className="absolute bottom-2 left-2 w-4 h-4 border border-black flex items-center justify-center">
          <div className="w-[1px] h-full bg-black"></div>
          <div className="h-[1px] w-full bg-black absolute"></div>
        </div>
        <div className="absolute bottom-2 right-2 w-4 h-4 border border-black flex items-center justify-center">
          <div className="w-[1px] h-full bg-black"></div>
          <div className="h-[1px] w-full bg-black absolute"></div>
        </div>
      </div>

      {/* Top Section - Metadata Labels */}
      <div className="z-10 flex justify-between items-start font-mono text-[9px] text-[#555555] tracking-widest uppercase">
        <div className="flex flex-col gap-0.5">
          <span className="font-semibold text-black">{artist}</span>
          <span>{catalogNumber}</span>
        </div>
        <div className="flex flex-col items-end gap-0.5">
          <span>PRESS NO. 1.94MM</span>
          <span>LATITUDE: 47.3769° N</span>
        </div>
      </div>

      {/* Center Art - High Precision SVG */}
      <div className="absolute inset-0 flex items-center justify-center p-12 z-0">
        {style === "geometric" && (
          <svg className="w-full h-full text-black opacity-85" viewBox="0 0 200 200" fill="none">
            {/* Dynamic projection lines */}
            <path d="M40,40 L160,40 L160,160 L40,160 Z" stroke="currentColor" strokeWidth="0.75" />
            <path d="M60,60 L140,60 L140,140 L60,140 Z" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2,2" />
            <path d="M40,40 L60,60" stroke="currentColor" strokeWidth="0.5" />
            <path d="M160,40 L140,60" stroke="currentColor" strokeWidth="0.5" />
            <path d="M160,160 L140,140" stroke="currentColor" strokeWidth="0.5" />
            <path d="M40,160 L60,140" stroke="currentColor" strokeWidth="0.5" />
            
            {/* Center target circle */}
            <circle cx="100" cy="100" r="10" stroke="currentColor" strokeWidth="0.75" />
            <circle cx="100" cy="100" r="2" fill="currentColor" />
            
            {/* Measurement lines */}
            <line x1="100" y1="20" x2="100" y2="180" stroke="currentColor" strokeWidth="0.25" strokeDasharray="4,4" />
            <line x1="20" y1="100" x2="180" y2="100" stroke="currentColor" strokeWidth="0.25" strokeDasharray="4,4" />
            
            {/* Dimension markers */}
            <text x="105" y="35" className="font-mono text-[6px]" fill="currentColor">t = 1.94mm</text>
            <text x="105" y="170" className="font-mono text-[6px]" fill="currentColor">Ø = 300mm</text>
          </svg>
        )}

        {style === "minimal" && (
          <svg className="w-full h-full text-black opacity-85" viewBox="0 0 200 200" fill="none">
            {/* Perfect Braun-inspired circle inside a pristine square */}
            <circle cx="100" cy="100" r="45" stroke="currentColor" strokeWidth="1" />
            <rect x="75" y="75" width="50" height="50" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1,1" />
            <line x1="100" y1="40" x2="100" y2="160" stroke="currentColor" strokeWidth="0.5" />
            <line x1="40" y1="100" x2="160" y2="100" stroke="currentColor" strokeWidth="0.5" />
            
            {/* Fine laboratory grids */}
            <circle cx="100" cy="100" r="5" stroke="currentColor" strokeWidth="0.5" />
            <text x="105" y="95" className="font-mono text-[5px]" fill="currentColor">CALIBRATION PASS</text>
          </svg>
        )}

        {style === "line-art" && (
          <svg className="w-full h-full text-black opacity-85" viewBox="0 0 200 200" fill="none">
            {/* Joy Division/frequency studies curve stack */}
            {Array.from({ length: 15 }).map((_, i) => {
              const y = 50 + i * 7;
              const peakX = 100;
              const spread = 25;
              const amplitude = 18 * Math.sin((i / 14) * Math.PI);
              const path = Array.from({ length: 101 })
                .map((_, xIndex) => {
                  const x = 40 + (xIndex / 100) * 120;
                  // Gaussian distribution for the peaks
                  const dist = Math.abs(x - peakX);
                  const waveFactor = Math.exp(-Math.pow(dist / spread, 2));
                  const noise = Math.sin(xIndex * 0.25 + i * 1.5) * waveFactor * amplitude;
                  const currentY = y - noise;
                  return `${xIndex === 0 ? "M" : "L"}${x},${currentY}`;
                })
                .join(" ");

              return (
                <path
                  key={i}
                  d={path}
                  stroke="currentColor"
                  strokeWidth="0.6"
                  fill="white"
                />
              );
            })}
            <line x1="40" y1="160" x2="160" y2="160" stroke="currentColor" strokeWidth="0.5" />
          </svg>
        )}

        {style === "abstract" && (
          <svg className="w-full h-full text-black opacity-85" viewBox="0 0 200 200" fill="none">
            {/* Concentric high-precision grooves and vector angles */}
            {Array.from({ length: 8 }).map((_, i) => (
              <circle
                key={i}
                cx="100"
                cy="100"
                r={15 + i * 9}
                stroke="currentColor"
                strokeWidth={0.4}
                strokeDasharray={i % 2 === 0 ? "none" : "2,4"}
              />
            ))}
            {/* Angular slice markers */}
            {Array.from({ length: 6 }).map((_, i) => {
              const angle = (i * Math.PI) / 3;
              const x1 = 100 + 80 * Math.cos(angle);
              const y1 = 100 + 80 * Math.sin(angle);
              const x2 = 100 - 80 * Math.cos(angle);
              const y2 = 100 - 80 * Math.sin(angle);
              return (
                <line
                  key={i}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="currentColor"
                  strokeWidth="0.25"
                  opacity="0.3"
                />
              );
            })}
            <circle cx="100" cy="100" r="3" fill="currentColor" />
          </svg>
        )}

        {style === "photographic" && (
          <div className="w-full h-full flex items-center justify-center relative">
            {/* Stark black and white road / architectural mountain contour */}
            <div className="w-4/5 h-4/5 border border-black p-1 flex flex-col justify-between items-center relative overflow-hidden bg-black text-white">
              <div className="absolute inset-0 bg-gradient-to-b from-neutral-900 to-black"></div>
              {/* Abstract horizon wireframe lines representing depth */}
              <svg className="absolute inset-0 w-full h-full text-white opacity-40" viewBox="0 0 100 100" fill="none">
                <path d="M50,20 L10,90 L90,90 Z" stroke="currentColor" strokeWidth="0.5" />
                <line x1="50" y1="20" x2="50" y2="90" stroke="currentColor" strokeWidth="0.5" strokeDasharray="1,1" />
                <line x1="30" y1="55" x2="70" y2="55" stroke="currentColor" strokeWidth="0.5" />
                <line x1="20" y1="72" x2="80" y2="72" stroke="currentColor" strokeWidth="0.5" />
              </svg>
              <span className="font-mono text-[5px] text-neutral-400 absolute bottom-2 tracking-widest">DECAY PROFILE V.14</span>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Section - Editorial Title */}
      <div className="z-10 mt-auto pt-4 border-t border-neutral-100 flex justify-between items-end">
        <div className="flex flex-col gap-0.5">
          <span className="font-sans font-bold text-sm tracking-tight leading-none text-black">
            {release}
          </span>
          <span className="font-mono text-[8px] text-[#555555] tracking-wider mt-1">
            AGORIST COOPERATIVE SYSTEM
          </span>
        </div>
        <div className="flex flex-col items-end">
          {isPlaying && (
            <div className="flex gap-0.5 items-end h-3 mb-1" id="playing-visualizer">
              <span className="w-0.5 bg-black animate-[bounce_1s_infinite_100ms] h-full"></span>
              <span className="w-0.5 bg-black animate-[bounce_1s_infinite_300ms] h-3/4"></span>
              <span className="w-0.5 bg-black animate-[bounce_1s_infinite_500ms] h-1/2"></span>
              <span className="w-0.5 bg-black animate-[bounce_1s_infinite_200ms] h-5/6"></span>
            </div>
          )}
          <span className="font-mono text-[9px] text-black bg-neutral-100 px-1.5 py-0.5 font-medium border border-neutral-200">
            {style.toUpperCase()}
          </span>
        </div>
      </div>
    </div>
  );
};
