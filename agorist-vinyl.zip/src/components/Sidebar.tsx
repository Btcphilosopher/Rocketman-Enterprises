import React, { useState } from "react";
import { Mail, Check, AlertCircle } from "lucide-react";

interface SidebarProps {
  activeCategory: string;
  setActiveCategory: (category: string) => void;
  onOpenVerification: () => void;
  onOpenLathe: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeCategory,
  setActiveCategory,
  onOpenVerification,
  onOpenLathe,
}) => {
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [showNewsletterForm, setShowNewsletterForm] = useState(false);
  const [newsletterStatus, setNewsletterStatus] = useState<"idle" | "success" | "error">("idle");

  const categories = [
    { id: "all", label: "RECORDS CATALOG" },
    { id: "new", label: "NEW ARRIVALS" },
    { id: "pre-order", label: "PRE-ORDERS" },
    { id: "bestseller", label: "BESTSELLERS" },
    { id: "staff-pick", label: "STAFF PICKS" },
    { id: "clearance", label: "CLEARANCE" },
  ];

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail.includes("@")) {
      setNewsletterStatus("error");
      return;
    }
    setNewsletterStatus("success");
    setTimeout(() => {
      setNewsletterEmail("");
      setShowNewsletterForm(false);
      setNewsletterStatus("idle");
    }, 2500);
  };

  return (
    <aside className="w-full lg:w-72 border-r border-[#E7E7E7] flex flex-col justify-between min-h-screen bg-[#FAFAF8] select-none relative z-20">
      
      {/* Brand Icon & Main Header */}
      <div className="p-8 border-b border-[#E7E7E7] flex items-center justify-between lg:justify-center relative">
        <div 
          onClick={() => setActiveCategory("all")}
          className="cursor-pointer group flex flex-col items-center gap-1"
          id="sidebar-logo-trigger"
        >
          {/* Elite Circle 'A' Agorist Vinyl Logo */}
          <div className="w-16 h-16 rounded-full border-[1.5px] border-black flex items-center justify-center relative transition-transform duration-700 group-hover:rotate-180">
            {/* Fine Inner Target circle */}
            <div className="absolute inset-2 rounded-full border border-neutral-100"></div>
            
            {/* The bold stylized A */}
            <svg viewBox="0 0 100 100" className="w-9 h-9 text-black" fill="none" stroke="currentColor" strokeWidth="6.5">
              <path d="M50 15 L22 80 M50 15 L78 80 M30 62 L70 62" strokeLinecap="square" />
            </svg>
            
            {/* CAD Target Dot */}
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-black rounded-full"></div>
          </div>
          <span className="font-mono text-[9px] text-[#555555] tracking-[0.3em] font-medium mt-2">AGORIST</span>
        </div>
        
        {/* CAD crosshair in sidebar top edge */}
        <div className="absolute right-4 top-4 opacity-30 font-mono text-[10px] text-neutral-400">
          ⊕
        </div>
      </div>

      {/* Navigation Links Grid */}
      <div className="p-8 flex-1 flex flex-col gap-10 py-12">
        <div className="flex flex-col gap-4">
          <span className="font-mono text-[9px] text-neutral-400 tracking-[0.25em] uppercase font-semibold">
            [CATEGORIES]
          </span>
          <nav className="flex flex-col gap-2">
            {categories.map((cat) => {
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`text-left font-sans text-xs font-semibold tracking-wider py-1.5 transition-all duration-300 relative flex items-center justify-between group ${
                    isActive ? "text-black" : "text-[#555555] hover:text-black hover:pl-2"
                  }`}
                  id={`cat-btn-${cat.id}`}
                >
                  <span>{cat.label}</span>
                  {isActive && (
                    <span className="w-1.5 h-1.5 bg-black rounded-none"></span>
                  )}
                  {!isActive && (
                    <span className="w-1 h-[1px] bg-neutral-200 group-hover:w-3 transition-all duration-300"></span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Dynamic Navigation Extensions for Engineering Tools */}
        <div className="flex flex-col gap-3">
          <span className="font-mono text-[9px] text-neutral-400 tracking-[0.25em] uppercase font-semibold">
            [UTILITIES]
          </span>
          <div className="flex flex-col gap-2">
            <button
              onClick={onOpenVerification}
              className="text-left font-mono text-[10px] text-[#555555] hover:text-black transition-colors py-1 flex items-center justify-between border border-neutral-100 hover:border-black/20 p-2 bg-neutral-50"
              id="qc-tool-btn"
            >
              <span>QC BATCH VERIFICATION</span>
              <span className="text-[8px] px-1 bg-black text-white font-mono font-medium">SHA-256</span>
            </button>
            <button
              onClick={onOpenLathe}
              className="text-left font-mono text-[10px] text-[#555555] hover:text-black transition-colors py-1 flex items-center justify-between border border-neutral-100 hover:border-black/20 p-2 bg-neutral-50"
              id="cnc-tool-btn"
            >
              <span>LATHE CONFIGURATOR</span>
              <span className="text-[8px] px-1 border border-black font-mono font-medium">3D CAD</span>
            </button>
          </div>
        </div>

        {/* Philosophy Copy Block */}
        <div className="border-t border-[#E7E7E7] pt-8 flex flex-col gap-3">
          <p className="font-mono text-[9px] text-black font-semibold uppercase tracking-wider leading-relaxed">
            DIRECT TO YOU.
            <br />
            NO INTERMEDIARIES.
            <br />
            NO RENT SEEKERS.
            <br />
            ONLY OWNERSHIP.
          </p>
          <div className="w-8 h-[1px] bg-black"></div>
          
          {/* Subtle Cad alignment crosshair */}
          <div className="relative w-8 h-8 flex items-center justify-center opacity-30 mt-1">
            <div className="w-[1px] h-full bg-black absolute"></div>
            <div className="h-[1px] w-full bg-black absolute"></div>
            <div className="w-3 h-3 border border-black rounded-full"></div>
          </div>
        </div>
      </div>

      {/* Footer Metadata & Newsletter */}
      <div className="p-8 border-t border-[#E7E7E7] flex flex-col gap-6 bg-neutral-50/50">
        <ul className="flex flex-col gap-2 font-mono text-[9px] text-[#555555] tracking-wider uppercase font-medium">
          <li className="flex items-center gap-1.5">
            <span className="w-1 h-1 bg-black"></span>
            WORLDWIDE SHIPPING
          </li>
          <li className="flex items-center gap-1.5">
            <span className="w-1 h-1 bg-black"></span>
            CARBON NEUTRAL PRODUCTION
          </li>
          <li className="flex items-center gap-1.5">
            <span className="w-1 h-1 bg-black"></span>
            SECURE DECENTRALIZED PAYMENT
          </li>
          <li className="flex items-center gap-1.5">
            <span className="w-1 h-1 bg-black"></span>
            PRIVACY FIRST (NO COOKIES)
          </li>
        </ul>

        {/* Newsletter Inline Trigger */}
        <div className="border-t border-[#E7E7E7] pt-4">
          {!showNewsletterForm ? (
            <button
              onClick={() => setShowNewsletterForm(true)}
              className="w-full flex items-center justify-between font-mono text-[10px] text-black font-bold tracking-widest hover:pl-2 transition-all duration-300 py-1"
              id="newsletter-expand-btn"
            >
              <span>NEWSLETTER →</span>
              <Mail className="w-3.5 h-3.5" />
            </button>
          ) : (
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col gap-2">
              <span className="font-mono text-[8px] text-[#555555] tracking-wider">ENTER EMAIL (VOLUNTARY ONLY):</span>
              <div className="flex border border-black bg-white">
                <input
                  type="email"
                  value={newsletterEmail}
                  onChange={(e) => setNewsletterEmail(e.target.value)}
                  placeholder="name@domain.com"
                  className="w-full font-mono text-[10px] px-2 py-1.5 outline-none bg-transparent"
                  id="newsletter-email-input"
                />
                <button
                  type="submit"
                  className="bg-black text-white px-3 font-mono text-[10px] flex items-center justify-center font-bold active:bg-neutral-800 transition-colors"
                  id="newsletter-submit-btn"
                >
                  →
                </button>
              </div>

              {newsletterStatus === "success" && (
                <div className="flex items-center gap-1 font-mono text-[8px] text-green-600 mt-1">
                  <Check className="w-2.5 h-2.5" />
                  <span>REGISTRATION LOGGED SUCCESS</span>
                </div>
              )}
              {newsletterStatus === "error" && (
                <div className="flex items-center gap-1 font-mono text-[8px] text-red-600 mt-1">
                  <AlertCircle className="w-2.5 h-2.5" />
                  <span>INVALID REGISTER FORMAT</span>
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </aside>
  );
};
