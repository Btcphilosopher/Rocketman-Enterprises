import React, { useState } from "react";
import { Search, ShoppingBag, X } from "lucide-react";

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  searchQuery,
  setSearchQuery,
  activeTab,
  setActiveTab,
}) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const navLinks = [
    { id: "records", label: "RECORDS" },
    { id: "equipment", label: "EQUIPMENT" },
    { id: "books", label: "BOOKS" },
    { id: "merch", label: "MERCH" },
    { id: "journal", label: "JOURNAL" },
    { id: "about", label: "ABOUT" },
  ];

  return (
    <header className="sticky top-0 bg-[#FAFAF8] border-b border-[#E7E7E7] z-30 select-none">
      <div className="flex flex-col md:flex-row items-stretch justify-between px-6 lg:px-12 py-4 gap-4 md:gap-0">
        
        {/* Brand Meta Title */}
        <div className="flex items-center gap-4">
          <div className="flex flex-col">
            <span className="font-sans font-extrabold text-sm tracking-[0.15em] text-black">
              AGORIST VINYL
            </span>
            <span className="font-mono text-[8px] text-[#555555] tracking-[0.2em] uppercase">
              FREEDOM THROUGH OWNERSHIP
            </span>
          </div>
          
          {/* Subtle design crosshair */}
          <div className="hidden lg:flex items-center justify-center relative w-6 h-6 opacity-30">
            <div className="w-[1px] h-full bg-black absolute"></div>
            <div className="h-[1px] w-full bg-black absolute"></div>
            <div className="w-1.5 h-1.5 border border-black rounded-full"></div>
          </div>
        </div>

        {/* Desktop Editorial Navigation Links */}
        <nav className="flex items-center justify-start md:justify-center gap-6 lg:gap-8 overflow-x-auto no-scrollbar py-1">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setActiveTab(link.id)}
                className={`font-mono text-[10px] font-bold tracking-widest relative pb-1 transition-colors ${
                  isActive ? "text-black" : "text-neutral-400 hover:text-black"
                }`}
                id={`nav-tab-${link.id}`}
              >
                <span>{link.label}</span>
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-black"></span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Search & Cart Interactions */}
        <div className="flex items-center justify-end gap-6">
          
          {/* CAD Search Box */}
          <div className="relative flex items-center">
            {isSearchOpen ? (
              <div className="flex items-center border border-black bg-white px-2 py-1 transition-all duration-300 w-44 md:w-56" id="search-input-container">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="SEARCH CATALOGUE..."
                  className="w-full bg-transparent font-mono text-[9px] uppercase tracking-widest outline-none pr-1"
                  autoFocus
                  id="search-input-field"
                />
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setIsSearchOpen(false);
                  }}
                  className="text-[#555555] hover:text-black"
                  id="search-close-btn"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => setIsSearchOpen(true)}
                className="flex items-center gap-2 font-mono text-[10px] font-bold text-black tracking-widest hover:opacity-75 py-1"
                id="search-expand-btn"
              >
                <span>SEARCH</span>
                <Search className="w-3.5 h-3.5 stroke-[2.5]" />
              </button>
            )}
          </div>

          {/* Cart Indicator */}
          <button
            onClick={onOpenCart}
            className="flex items-center gap-2 font-mono text-[10px] font-bold text-black tracking-widest bg-black text-white px-3 py-1.5 hover:bg-neutral-800 transition-colors cursor-pointer group"
            id="header-cart-btn"
          >
            <span>CART</span>
            <span className="font-mono text-[10px] bg-white text-black px-1.5 py-0.5 font-bold rounded-none group-hover:scale-105 transition-transform">
              {cartCount.toString().padStart(2, "0")}
            </span>
          </button>
        </div>

      </div>
    </header>
  );
};
