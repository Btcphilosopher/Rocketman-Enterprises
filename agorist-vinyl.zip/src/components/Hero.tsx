import React, { useState } from "react";
import { Play, RotateCcw, HelpCircle } from "lucide-react";
import { VinylProduct } from "../types";

interface HeroProps {
  heroAlbum: VinylProduct;
  onPlayAlbum: (album: VinylProduct) => void;
  onOpenDetails: (album: VinylProduct) => void;
  onBrowseRecords: () => void;
  isPlayingHero: boolean;
  heroImageSrc: string;
}

export const Hero: React.FC<HeroProps> = ({
  heroAlbum,
  onPlayAlbum,
  onOpenDetails,
  onBrowseRecords,
  isPlayingHero,
  heroImageSrc,
}) => {
  const [hoveredProduct, setHoveredProduct] = useState(false);
  const [activeTab, setActiveTab] = useState<"cad" | "optics">("cad");

  return (
    <section className="border-b border-[#E7E7E7] bg-[#FAFAF8] relative overflow-hidden select-none">
      
      {/* Background Subtle CAD Crosshair Matrix */}
      <div className="absolute inset-0 pointer-events-none cad-grid opacity-35 z-0"></div>

      <div className="flex flex-col xl:flex-row items-stretch min-h-[580px] relative z-10">
        
        {/* Left Core Philosophy Block (Grid Columns 1-6) */}
        <div className="flex-1 p-8 lg:p-16 flex flex-col justify-between border-b xl:border-b-0 xl:border-r border-[#E7E7E7]">
          
          {/* Top Label */}
          <div className="flex justify-between items-center">
            <span className="font-mono text-[9px] text-black bg-neutral-100 px-2.5 py-1 border border-neutral-200 uppercase tracking-widest font-semibold">
              [AGORIST BY DESIGN]
            </span>
            <div className="flex items-center gap-2 font-mono text-[8px] text-[#555555]">
              <span>CALIBRATION STATUS:</span>
              <span className="flex items-center gap-1 text-black font-semibold">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping"></span>
                OPTIMIZED
              </span>
            </div>
          </div>

          {/* Main Massive Editorial Typography */}
          <div className="my-12 lg:my-0 flex flex-col gap-1.5">
            <h1 className="font-sans font-extrabold text-5xl md:text-7xl lg:text-8xl tracking-tighter leading-[0.85] uppercase text-black select-none">
              VINYL.
              <br />
              OWNERSHIP.
              <br />
              FREEDOM.
            </h1>
            
            <p className="mt-8 font-sans text-xs md:text-sm text-[#555555] tracking-wide leading-relaxed max-w-lg font-medium">
              A CURATED SELECTION OF VINYL RECORDS AND AUDIO EQUIPMENT.
              MANUFACTURED WITH PRECISION. COOPERATIVE DESIGN.
              DISTRIBUTED FREELY, WITHOUT CENTRALIZED INTERMEDIARIES.
            </p>

            {/* Premium Button with CAD Grid Crosshairs */}
            <div className="mt-10 flex flex-wrap gap-4 items-center">
              <button
                onClick={onBrowseRecords}
                className="bg-black hover:bg-neutral-900 text-white font-mono text-[10px] font-extrabold tracking-[0.2em] uppercase px-8 py-4 flex items-center gap-4 transition-all duration-300 relative group overflow-hidden cursor-pointer"
                id="hero-browse-btn"
              >
                {/* Horizontal progress scanner line on hover */}
                <span className="absolute inset-x-0 top-0 h-[1.5px] bg-white opacity-0 group-hover:opacity-40 -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></span>
                <span>BROWSE RECORDS</span>
                <span className="text-white opacity-40 font-mono text-[10px] select-none">⊕</span>
              </button>

              <button
                onClick={() => onPlayAlbum(heroAlbum)}
                className={`font-mono text-[10px] font-bold tracking-[0.15em] uppercase px-6 py-4 border border-black flex items-center gap-2 transition-all duration-300 ${
                  isPlayingHero 
                    ? "bg-green-50 text-green-700 border-green-600" 
                    : "hover:bg-black hover:text-white bg-transparent text-black"
                }`}
                id="hero-play-btn"
              >
                {isPlayingHero ? (
                  <>
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                    <span>ACTIVE TRACKS PLAYING</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>PLAY REFERENCE CHORD</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Technical Quality Control Signature Footer */}
          <div className="border-t border-neutral-200/60 pt-6 mt-8 flex justify-between items-end">
            <div className="flex flex-col gap-1 max-w-sm">
              <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">
                WE DON'T JUST SELL RECORDS.
              </span>
              <p className="font-sans text-[11px] text-[#555555] leading-relaxed">
                We remove structural barriers to physical audio ownership. Each release includes direct physical master rights and high-precision quality control reports.
              </p>
            </div>
            
            {/* Engineering tick marks */}
            <div className="hidden sm:flex gap-1 items-end h-4 opacity-45">
              {Array.from({ length: 12 }).map((_, i) => (
                <span 
                  key={i} 
                  className={`w-[1px] bg-black ${i % 4 === 0 ? "h-4" : i % 2 === 0 ? "h-2.5" : "h-1.5"}`}
                ></span>
              ))}
            </div>
          </div>

        </div>

        {/* Right Product Spotlight Image Box (Grid Columns 7-12) */}
        <div className="flex-1 bg-transparent p-8 lg:p-12 flex flex-col justify-between relative overflow-hidden">
          
          {/* Subtle Technical Annotations CAD Overlay */}
          <div className="absolute top-4 left-4 z-10 font-mono text-[8px] text-[#555555] tracking-wider uppercase flex gap-4">
            <span>DRAWING NO: AG-LP-S02</span>
            <span>SCALE: 1:1.94</span>
            <span>TOLERANCE: ±0.0015mm</span>
          </div>
          
          {/* Interactive display switch (Optics vs CAD View) */}
          <div className="absolute top-4 right-4 z-20 flex bg-neutral-100 border border-neutral-200 p-0.5" id="hero-display-toggle">
            <button
              onClick={() => setActiveTab("cad")}
              className={`font-mono text-[8px] px-2 py-0.5 tracking-wider uppercase font-semibold ${
                activeTab === "cad" ? "bg-white text-black shadow-sm" : "text-[#555555] hover:text-black"
              }`}
            >
              STUDIO PHOTO
            </button>
            <button
              onClick={() => setActiveTab("optics")}
              className={`font-mono text-[8px] px-2 py-0.5 tracking-wider uppercase font-semibold ${
                activeTab === "optics" ? "bg-white text-black shadow-sm" : "text-[#555555] hover:text-black"
              }`}
            >
              GROOVE SPECTROMETER
            </button>
          </div>

          {/* Interactive Turntable / Disc Container */}
          <div className="my-auto py-12 flex items-center justify-center relative">
            
            {/* Outer CAD Measurement Circles */}
            <div className="absolute w-[340px] md:w-[420px] lg:w-[460px] aspect-square rounded-full border border-black/[0.04] flex items-center justify-center pointer-events-none">
              <div className="absolute w-4/5 aspect-square rounded-full border border-black/[0.02]"></div>
              <div className="absolute w-3/5 aspect-square rounded-full border border-black/[0.03] border-dashed"></div>
              {/* Radial Degrees lines */}
              <div className="absolute w-full h-[1px] bg-black/[0.015]"></div>
              <div className="absolute h-full w-[1px] bg-black/[0.015]"></div>
            </div>

            {activeTab === "cad" ? (
              <div 
                className="relative cursor-pointer flex items-center justify-center group"
                onMouseEnter={() => setHoveredProduct(true)}
                onMouseLeave={() => setHoveredProduct(false)}
                onClick={() => onOpenDetails(heroAlbum)}
                id="hero-vinyl-mockup"
              >
                {/* 1. Heavy textured record sleeve */}
                <div className="relative w-64 md:w-80 lg:w-96 aspect-square z-10 transition-transform duration-700 group-hover:-translate-x-4 shadow-[15px_15px_30px_rgba(0,0,0,0.06)] border border-neutral-200 overflow-hidden bg-white">
                  <img
                    src={heroImageSrc}
                    alt="AGORIST VINYL - Liminal Archive"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover select-none"
                  />
                  
                  {/* Subtle paper texture overlay */}
                  <div className="absolute inset-0 bg-neutral-900/[0.01] pointer-events-none paper-texture"></div>
                  
                  {/* Outer CAD spec overlay on sleeve */}
                  <div className="absolute bottom-4 left-4 z-10 font-mono text-[7px] text-black tracking-widest font-semibold bg-white/90 backdrop-blur-xs px-2 py-1 border border-neutral-100">
                    QC VERIFIED PASS: ALTHAUS
                  </div>
                </div>

                {/* 2. Audiophile gloss black vinyl record partially pulled out */}
                <div 
                  className={`absolute w-60 md:w-76 lg:w-92 aspect-square rounded-full bg-neutral-950 transition-all duration-700 ease-out z-0 flex items-center justify-center ${
                    hoveredProduct ? "translate-x-32 md:translate-x-44 rotate-45" : "translate-x-12 rotate-12"
                  } ${isPlayingHero ? "animate-[spin_4s_linear_infinite]" : ""}`}
                  style={{
                    boxShadow: "0 10px 40px rgba(0,0,0,0.3), inset 0 0 40px rgba(255,255,255,0.05)"
                  }}
                >
                  {/* Record grooves detail */}
                  <div className="absolute inset-4 rounded-full border border-white/[0.03] flex items-center justify-center">
                    <div className="absolute inset-6 rounded-full border border-black/80 flex items-center justify-center">
                      <div className="absolute inset-10 rounded-full border border-white/[0.04]"></div>
                      <div className="absolute inset-16 rounded-full border border-white/[0.03] flex items-center justify-center">
                        <div className="absolute inset-20 rounded-full border border-black/90"></div>
                      </div>
                    </div>
                  </div>

                  {/* Core black center label with branding */}
                  <div className="w-20 md:w-24 lg:w-28 aspect-square bg-[#FAFAF8] rounded-full border border-neutral-300 flex flex-col items-center justify-center relative shadow-inner">
                    <div className="w-6 h-6 rounded-full border border-black flex items-center justify-center relative">
                      <span className="font-sans font-bold text-[8px] text-black">A</span>
                      {/* Center hole spindle placeholder */}
                      <div className="absolute w-2 h-2 bg-neutral-800 rounded-full border border-neutral-300"></div>
                    </div>
                    <span className="font-mono text-[5px] text-neutral-500 tracking-[0.2em] uppercase mt-2">AGORIST</span>
                    <span className="font-mono text-[5px] text-black uppercase font-bold">AV-LP-001</span>
                    <span className="font-mono text-[4px] text-neutral-400">33 RPM / 180G</span>
                  </div>
                </div>
              </div>
            ) : (
              /* High precision frequency graph visualization representing visual spectrometer */
              <div className="w-full max-w-md h-72 md:h-80 border border-black p-6 bg-black flex flex-col justify-between text-[#FAFAF8] font-mono select-none relative shadow-xl">
                <div className="absolute inset-0 pointer-events-none opacity-[0.02] cad-grid"></div>
                <div className="flex justify-between items-start text-[8px] text-neutral-400">
                  <span>SPECTROMETER PLOT V.12</span>
                  <span className="text-green-500 animate-pulse">● LIVE GRATING</span>
                </div>

                <div className="flex-1 flex items-end gap-[3px] py-6 border-b border-neutral-800 h-full relative overflow-hidden">
                  {/* Subtle waveform grid */}
                  <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-10">
                    <div className="w-full h-[1px] bg-white"></div>
                    <div className="w-full h-[1px] bg-white"></div>
                    <div className="w-full h-[1px] bg-white"></div>
                  </div>

                  {/* Generated spectrum bars */}
                  {Array.from({ length: 42 }).map((_, i) => {
                    // Random-ish but deterministic sound peaks
                    const heightVal = 10 + Math.sin(i * 0.15) * 40 + Math.cos(i * 0.5) * 20 + (isPlayingHero ? Math.random() * 25 : 0);
                    return (
                      <div key={i} className="flex-1 flex flex-col justify-end h-full">
                        <div 
                          className="bg-white hover:bg-green-400 transition-all duration-300"
                          style={{ height: `${Math.max(2, Math.min(100, heightVal))}%` }}
                        ></div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex justify-between items-end mt-4 text-[7px] text-neutral-400 uppercase tracking-widest">
                  <div className="flex flex-col">
                    <span>BANDWIDTH: 10Hz - 22kHz</span>
                    <span>SWEPT RESOLUTION: 0.05%</span>
                  </div>
                  <div className="flex flex-col items-end">
                    <span>DYNAMIC RANGE: 15.4 DB</span>
                    <span>SIGNAL LEVEL: {isPlayingHero ? "-12.4dBFS" : "-INF DB"}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Far Right sidebar-aligned fine markings with text vertically stacked */}
          <div className="border-t border-neutral-100 pt-4 flex justify-between items-center text-[8px] font-mono text-[#555555]">
            <div className="flex items-center gap-1.5">
              <span className="font-semibold text-black">BATCH REFERENCE:</span>
              <span>AV-2026-LA02</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span>LATEX WEAR DEGREE:</span>
              <span className="text-black font-semibold">0.02%</span>
            </div>
          </div>

        </div>

      </div>

      {/* Aesthetic border text decoration element from the mockup */}
      <div className="hidden lg:flex absolute right-0 top-1/2 -translate-y-1/2 flex-col items-center gap-10 font-mono text-[8px] tracking-[0.4em] text-neutral-400 uppercase pointer-events-none z-10 select-none pr-3">
        <span className="rotate-90 origin-center whitespace-nowrap">high-precision pressing</span>
        <span className="rotate-90 origin-center whitespace-nowrap">audiophile grade</span>
        <span className="rotate-90 origin-center whitespace-nowrap">built to last</span>
      </div>

    </section>
  );
};
