import React, { useState, useEffect } from "react";
import { X, Cpu, RotateCcw, Activity, ShieldAlert, Sparkles } from "lucide-react";
import audioSystem from "../lib/audio";

interface LatheConfiguratorProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LatheConfigurator: React.FC<LatheConfiguratorProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  // Lathe settings
  const [rpm, setRpm] = useState<33 | 45>(33);
  const [temp, setTemp] = useState<number>(195); // 180 - 220 °C
  const [pitch, setPitch] = useState<number>(180); // 120 - 240 lines/inch (groove pitch)
  const [stylus, setStylus] = useState<"diamond" | "sapphire">("diamond");
  
  // Cut states
  const [isCutting, setIsCutting] = useState(false);
  const [cutProgress, setCutProgress] = useState(0);
  const [cutComplete, setCutComplete] = useState(false);

  // Dynamic calculations based on sliders
  const maxCutTime = (rpm === 33 ? (pitch * 0.125) : (pitch * 0.09)).toFixed(1);
  const grooveWidth = (50 - (pitch - 120) * 0.12).toFixed(1);
  const resonanceFreq = (7.5 + (temp - 180) * 0.025 + (stylus === "diamond" ? 1.2 : 0)).toFixed(2);
  const pressTolerance = (0.0012 + (Math.abs(temp - 195) * 0.00008)).toFixed(4);

  useEffect(() => {
    let interval: any = null;
    if (isCutting) {
      // Play high-frequency cutting tone (1200Hz sine) to represent the physical carving action
      try {
        audioSystem.play(140, "CUT-TONE");
      } catch (e) {}

      interval = setInterval(() => {
        setCutProgress((p) => {
          if (p >= 100) {
            clearInterval(interval);
            setIsCutting(false);
            setCutComplete(true);
            audioSystem.stop();
            return 100;
          }
          return p + 5;
        });
      }, 150);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isCutting]);

  const handleStartCut = () => {
    setCutComplete(false);
    setCutProgress(0);
    setIsCutting(true);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      
      {/* Main Panel */}
      <div 
        className="bg-[#FAFAF8] w-full max-w-3xl border border-black p-6 md:p-8 flex flex-col justify-between shadow-2xl relative"
        id="lathe-configurator-panel"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header bar */}
        <div className="flex justify-between items-start border-b border-neutral-200 pb-4 mb-6">
          <div className="flex flex-col">
            <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">
              MANUFACTURING DEPT // CAD INTERACTIVE TERMINAL
            </span>
            <h2 className="font-sans font-extrabold text-sm md:text-base tracking-tight uppercase text-black mt-1">
              LATHE CUTTER &amp; PRESS CONFIGURATOR
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-500 hover:text-black border border-neutral-200 p-1 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Columns */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          
          {/* Left Column: Lathe parameters slider */}
          <div className="flex flex-col gap-5 justify-between">
            <div className="flex flex-col gap-4">
              <span className="font-mono text-[9px] text-black tracking-widest uppercase font-bold">
                [CALIBRATE PARAMETERS]
              </span>

              {/* Speed selector */}
              <div className="flex flex-col gap-1.5">
                <span className="font-mono text-[9px] text-[#555555]">CUTTING ROTATIONAL SPEED:</span>
                <div className="grid grid-cols-2 border border-black p-0.5 bg-white">
                  <button
                    onClick={() => setRpm(33)}
                    className={`py-1.5 font-mono text-[9px] font-bold ${rpm === 33 ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                  >
                    33.3 RPM STANDARD
                  </button>
                  <button
                    onClick={() => setRpm(45)}
                    className={`py-1.5 font-mono text-[9px] font-bold ${rpm === 45 ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                  >
                    45 RPM DYNAMIC REFERENCE
                  </button>
                </div>
              </div>

              {/* Temperature slider */}
              <div className="flex flex-col gap-1.5 mt-1">
                <div className="flex justify-between font-mono text-[9px]">
                  <span className="text-[#555555]">PRESS MELTING TEMPERATURE:</span>
                  <span className="font-bold text-black">{temp}°C</span>
                </div>
                <input
                  type="range"
                  min="180"
                  max="220"
                  step="1"
                  value={temp}
                  onChange={(e) => setTemp(parseInt(e.target.value))}
                  className="w-full accent-black h-1 bg-neutral-200 rounded-none cursor-pointer"
                />
                <span className="font-mono text-[7px] text-neutral-400">OPTIMAL PRESS VISCOSITY AT 195°C FOR VIRGIN CO-POLYMER</span>
              </div>

              {/* Groove Pitch density slider */}
              <div className="flex flex-col gap-1.5 mt-1">
                <div className="flex justify-between font-mono text-[9px]">
                  <span className="text-[#555555]">GROOVE PITCH DENSITY:</span>
                  <span className="font-bold text-black">{pitch} LINES/INCH</span>
                </div>
                <input
                  type="range"
                  min="120"
                  max="240"
                  step="5"
                  value={pitch}
                  onChange={(e) => setPitch(parseInt(e.target.value))}
                  className="w-full accent-black h-1 bg-neutral-200 rounded-none cursor-pointer"
                />
                <span className="font-mono text-[7px] text-neutral-400">HIGHER DENSITY = MORE PLAYBACK CAPACITY, LESS ACOUSTIC ENERGY</span>
              </div>

              {/* Stylus Tip Material */}
              <div className="flex flex-col gap-1.5 mt-1">
                <span className="font-mono text-[9px] text-[#555555]">LACQUER STYLUS MATERIAL:</span>
                <div className="grid grid-cols-2 border border-black p-0.5 bg-white">
                  <button
                    onClick={() => setStylus("diamond")}
                    className={`py-1.5 font-mono text-[9px] font-bold ${stylus === "diamond" ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                  >
                    DIAMOND TIP (REF)
                  </button>
                  <button
                    onClick={() => setStylus("sapphire")}
                    className={`py-1.5 font-mono text-[9px] font-bold ${stylus === "sapphire" ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                  >
                    SAPPHIRE GLOSS
                  </button>
                </div>
              </div>

            </div>

            {/* Launch button */}
            <div className="border-t border-neutral-200 pt-4 mt-4 flex flex-col gap-3">
              {isCutting ? (
                <div className="flex flex-col gap-1.5 font-mono text-[9px]">
                  <div className="flex justify-between text-black font-bold animate-pulse">
                    <span>CARVING LACQUER GROOVES...</span>
                    <span>{cutProgress}%</span>
                  </div>
                  <div className="w-full h-2 bg-neutral-200 relative">
                    <div className="h-full bg-black transition-all duration-150" style={{ width: `${cutProgress}%` }}></div>
                  </div>
                </div>
              ) : cutComplete ? (
                <div className="flex items-center gap-2 font-mono text-[10px] text-green-700 bg-green-50 border border-green-600 p-2.5">
                  <Sparkles className="w-4 h-4 text-green-700 shrink-0" />
                  <div className="flex flex-col">
                    <span className="font-bold">LACQUER MASTER CUT COMPLETE</span>
                    <span className="text-[8px] text-green-600">SIGNED BATCH ASSIGNMENT TOLERANCE: {pressTolerance}mm</span>
                  </div>
                </div>
              ) : null}

              <button
                onClick={handleStartCut}
                disabled={isCutting}
                className={`w-full font-mono text-[10px] font-bold tracking-[0.25em] uppercase py-3 border border-black transition-colors ${
                  isCutting ? "bg-neutral-100 border-neutral-300 text-neutral-400 cursor-not-allowed" : "bg-black hover:bg-neutral-900 text-white cursor-pointer"
                }`}
                id="execute-cut-trigger"
              >
                {isCutting ? "ENGRAVING IN PROGRESS" : "EXECUTE MASTER CUT"}
              </button>
            </div>
          </div>

          {/* Right Column: CAD visualizer container */}
          <div className="bg-white border border-neutral-200 p-6 flex flex-col justify-between relative overflow-hidden min-h-[350px]">
            <div className="absolute top-2 left-2 font-mono text-[8px] text-neutral-400">
              CAD_VIEW // ORTHOGONAL
            </div>

            {/* Interactive SVG dynamic rotation wireframe */}
            <div className="my-auto flex items-center justify-center py-6 relative">
              <svg 
                className={`w-44 h-44 text-black transition-transform duration-300 ${isCutting ? "animate-[spin_2.5s_linear_infinite]" : ""}`} 
                viewBox="0 0 100 100" 
                fill="none"
              >
                {/* Outmost turntable platter */}
                <circle cx="50" cy="50" r="48" stroke="currentColor" strokeWidth="0.5" />
                <circle cx="50" cy="50" r="45" stroke="currentColor" strokeWidth="0.25" strokeDasharray="1,2" />
                
                {/* Vinyl Grooves based on pitch density */}
                {Array.from({ length: 6 }).map((_, i) => (
                  <circle
                    key={i}
                    cx="50"
                    cy="50"
                    r={12 + i * 5}
                    stroke="currentColor"
                    strokeWidth="0.3"
                    opacity={0.15 + (i / 10)}
                  />
                ))}

                {/* Laser cutting line / angle pointer */}
                <line x1="50" y1="2" x2="50" y2="98" stroke="currentColor" strokeWidth="0.25" opacity="0.1" />
                <line x1="2" y1="50" x2="98" y2="50" stroke="currentColor" strokeWidth="0.25" opacity="0.1" />
                
                {/* Center label */}
                <circle cx="50" cy="50" r="10" stroke="currentColor" strokeWidth="0.5" fill="white" />
                <circle cx="50" cy="50" r="2" fill="currentColor" />

                {/* Simulated stylus cutter arm pointing to center */}
                <path d="M50,15 L78,5 M78,5 L82,12" stroke="currentColor" strokeWidth="1" strokeLinecap="round" opacity="0.8" />
              </svg>

              {/* Sparks visualizer on cutting */}
              {isCutting && (
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 pointer-events-none flex items-center justify-center">
                  <div className="w-2 h-2 bg-yellow-500 rounded-full animate-ping absolute top-10 right-20"></div>
                  <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full animate-ping absolute bottom-12 left-16"></div>
                </div>
              )}
            </div>

            {/* Live readout calculations spec sheet */}
            <div className="border-t border-neutral-100 pt-4 flex flex-col gap-1.5 font-mono text-[9px] text-[#555555]">
              <div className="flex justify-between">
                <span>ESTIMATED MAX PLAYING CAPACITY:</span>
                <span className="text-black font-bold">{maxCutTime} MINS/SIDE</span>
              </div>
              <div className="flex justify-between">
                <span>MICRO-GROOVE WIDTH DIMENSION:</span>
                <span className="text-black font-bold">{grooveWidth} µm</span>
              </div>
              <div className="flex justify-between">
                <span>CUTTER-HEAD COUPLING RESONANCE:</span>
                <span className="text-black font-bold">{resonanceFreq} kHz</span>
              </div>
              <div className="flex justify-between">
                <span>EXPECTED PRESS TOLERANCE:</span>
                <span className="text-black font-bold">±{pressTolerance} mm</span>
              </div>
            </div>

          </div>

        </div>

        {/* Footer secure info bar */}
        <div className="mt-6 pt-4 border-t border-neutral-200 flex justify-between items-center text-[8px] font-mono text-neutral-400">
          <div className="flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-black animate-pulse" />
            <span>NEUMANN VMS-80 DIRECT-TO-DISK SIMULATION STABLE</span>
          </div>
          <span>AGORIST TOOL-CHAIN DEPT</span>
        </div>

      </div>
    </div>
  );
};
