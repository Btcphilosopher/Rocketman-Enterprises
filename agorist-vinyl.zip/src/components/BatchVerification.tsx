import React, { useState } from "react";
import { X, Search, ShieldCheck, CheckCircle2, RefreshCw } from "lucide-react";
import { QC_REPORTS } from "../data/records";

interface BatchVerificationProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BatchVerification: React.FC<BatchVerificationProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const [searchBatch, setSearchBatch] = useState("AV-2026-LA02");
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<any>(QC_REPORTS["AV-2026-LA02"]);

  const sampleBatches = Object.keys(QC_REPORTS);

  const handleVerify = (batchId: string) => {
    setIsVerifying(true);
    setSearchBatch(batchId);
    setTimeout(() => {
      const report = QC_REPORTS[batchId];
      setVerificationResult(report || null);
      setIsVerifying(false);
    }, 1200);
  };

  // Helper to generate a visual matrix from a hash string
  const getHashGrid = (hash: string) => {
    const chars = hash.split("").slice(0, 36);
    return (
      <div className="grid grid-cols-6 gap-1 w-32 h-32 bg-neutral-900 p-2 border border-neutral-800">
        {chars.map((char, index) => {
          const charCode = char.charCodeAt(0);
          const isFilled = charCode % 2 === 0;
          return (
            <div
              key={index}
              className={`w-full aspect-square transition-all duration-500 ${
                isFilled ? "bg-white" : "bg-neutral-800"
              }`}
              title={`Byte ${index}: ${char}`}
            ></div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none">
      
      {/* Container card */}
      <div 
        className="bg-[#FAFAF8] w-full max-w-2xl border border-black p-6 md:p-8 flex flex-col justify-between shadow-2xl relative"
        id="batch-verification-panel"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header bar */}
        <div className="flex justify-between items-start border-b border-neutral-200 pb-4 mb-6">
          <div className="flex flex-col">
            <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold">
              SYSTEM TRUST UTILITIES // AUDIT ENGINE
            </span>
            <h2 className="font-sans font-extrabold text-sm md:text-base tracking-tight uppercase text-black mt-1">
              CRYPTOGRAPHIC QC BATCH VERIFIER
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-500 hover:text-black border border-neutral-200 p-1 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Input & Search Section */}
        <div className="flex flex-col gap-4">
          <p className="font-sans text-xs text-[#555555] leading-relaxed">
            Agorist Vinyl audits and signs the chemical purity, thickness, and measured physical deviation of every batch. Select or enter a batch serial number below to pull the raw QA parameters from our decentralized ledger.
          </p>

          <div className="flex border border-black bg-white">
            <div className="flex items-center pl-3 pr-2 text-[#555555]">
              <Search className="w-4 h-4" />
            </div>
            <input
              type="text"
              value={searchBatch}
              onChange={(e) => setSearchBatch(e.target.value.toUpperCase())}
              placeholder="ENTER BATCH SERIAL NUMBER..."
              className="w-full font-mono text-[10px] py-3 uppercase tracking-widest outline-none"
              id="qc-search-input"
            />
            <button
              onClick={() => handleVerify(searchBatch)}
              className="bg-black hover:bg-neutral-800 text-white font-mono text-[9px] font-bold tracking-widest uppercase px-6"
              id="qc-verify-trigger"
            >
              AUDIT DATA
            </button>
          </div>

          {/* Clickable Quick Seeds */}
          <div className="flex flex-wrap gap-1.5 items-center">
            <span className="font-mono text-[8px] text-neutral-400 mr-1.5">KNOWN BATCH SEEDS:</span>
            {sampleBatches.map((batch) => (
              <button
                key={batch}
                onClick={() => handleVerify(batch)}
                className={`font-mono text-[8px] font-semibold px-2 py-1 border transition-all ${
                  searchBatch === batch 
                    ? "bg-black text-white border-black" 
                    : "bg-white border-neutral-200 text-[#555555] hover:border-neutral-400"
                }`}
              >
                {batch}
              </button>
            ))}
          </div>
        </div>

        {/* Verification Result Display */}
        <div className="mt-8 min-h-[220px] bg-white border border-neutral-200 p-4 relative flex flex-col justify-between">
          <div className="absolute top-2 left-2 font-mono text-[7px] text-neutral-300">
            ENGINE_STATE: ACTIVE_PARSER // VER_3.12
          </div>

          {isVerifying ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3">
              <RefreshCw className="w-6 h-6 text-black animate-spin" />
              <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase">
                AUDITING LEDGER CHECKSUMS &amp; PURITY...
              </span>
            </div>
          ) : verificationResult ? (
            <div className="flex flex-col md:flex-row gap-6 items-stretch justify-between h-full pt-4">
              
              {/* Text Specs */}
              <div className="flex-1 flex flex-col gap-2.5 font-mono text-[10px]">
                <div className="flex items-center gap-1.5 text-green-700 font-bold text-[9px] uppercase border-b border-neutral-100 pb-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>CRYPTOGRAPHIC QA PASS SECURED</span>
                </div>

                <div className="grid grid-cols-2 gap-y-2 gap-x-4 mt-1 text-[#555555]">
                  <div className="flex flex-col border-b border-neutral-50 pb-1">
                    <span className="text-[8px] text-neutral-400">BATCH IDENTIFIER:</span>
                    <span className="text-black font-semibold uppercase">{verificationResult.batchNo}</span>
                  </div>
                  <div className="flex flex-col border-b border-neutral-50 pb-1">
                    <span className="text-[8px] text-neutral-400">POLYMER FORMULATION:</span>
                    <span className="text-black font-semibold uppercase">{verificationResult.purity}</span>
                  </div>
                  <div className="flex flex-col border-b border-neutral-50 pb-1">
                    <span className="text-[8px] text-neutral-400">NOMINAL THICKNESS:</span>
                    <span className="text-black font-semibold">{verificationResult.thickness}</span>
                  </div>
                  <div className="flex flex-col border-b border-neutral-50 pb-1">
                    <span className="text-[8px] text-neutral-400">BATCH WEIGHT VARIANCE:</span>
                    <span className="text-black font-semibold">{verificationResult.weightDistribution}</span>
                  </div>
                  <div className="flex flex-col border-b border-neutral-50 pb-1">
                    <span className="text-[8px] text-neutral-400">GROOVE DEPTH COMPLIANCE:</span>
                    <span className="text-black font-semibold uppercase">{verificationResult.groovePurity}</span>
                  </div>
                  <div className="flex flex-col border-b border-neutral-50 pb-1">
                    <span className="text-[8px] text-neutral-400">MEASURED DYNAMIC RANGE:</span>
                    <span className="text-black font-semibold">{verificationResult.measuredDr} dB</span>
                  </div>
                </div>

                <div className="mt-2 text-[8px] text-neutral-400 flex flex-col">
                  <span>SHA-256 MERKLE BLOCK CHECKSUM:</span>
                  <span className="truncate max-w-md font-bold text-neutral-600">{verificationResult.hash}</span>
                </div>
              </div>

              {/* Grid visualizer */}
              <div className="flex flex-col items-center justify-center gap-1.5 p-2 bg-neutral-50 border border-neutral-200">
                {getHashGrid(verificationResult.hash)}
                <span className="font-mono text-[7px] text-neutral-400 uppercase tracking-widest">SHA-256 GRID MATRIX</span>
              </div>

            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center gap-2 py-8">
              <span className="font-mono text-[10px] text-red-600 font-bold uppercase tracking-widest">
                VERIFICATION FAILURE: NO RECORD RECORDED
              </span>
              <p className="font-sans text-[11px] text-[#555555] text-center max-w-sm">
                The batch serial number <strong className="text-black">"{searchBatch}"</strong> could not be audited. Please verify seed formatting.
              </p>
            </div>
          )}
        </div>

        {/* Bottom secure info bar */}
        <div className="mt-6 pt-4 border-t border-neutral-200 flex justify-between items-center text-[8px] font-mono text-neutral-400">
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-black opacity-30" />
            <span>SIGNED BY LICENSED CO-OP IN-LINE INSPECTOR</span>
          </div>
          <span>LEDGER ENGINE V2.14</span>
        </div>

      </div>
    </div>
  );
};
