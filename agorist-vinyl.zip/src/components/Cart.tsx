import React, { useState } from "react";
import { X, Trash2, Check, ArrowRight, ShieldCheck } from "lucide-react";
import { CartItem } from "../types";

interface CartProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemoveItem: (productId: string, weight: number) => void;
  onUpdateQuantity: (productId: string, weight: number, quantity: number) => void;
  onClearCart: () => void;
}

export const Cart: React.FC<CartProps> = ({
  isOpen,
  onClose,
  cartItems,
  onRemoveItem,
  onUpdateQuantity,
  onClearCart,
}) => {
  if (!isOpen) return null;

  const [contribution, setContribution] = useState<number>(15); // Default 15% voluntary artist support
  const [checkoutStep, setCheckoutStep] = useState<"cart" | "shipping" | "complete">("cart");
  
  // Shipping form fields
  const [fullName, setFullName] = useState("");
  const [address, setAddress] = useState("");
  const [currencyChoice, setCurrencyChoice] = useState<"USD" | "BTC" | "XMR">("USD");

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const contributionAmount = subtotal * (contribution / 100);
  
  // High-precision physical production costs ($9.50/unit for 180g, $11.20/unit for 200g)
  const estimatedPhysicalProductionCosts = cartItems.reduce((acc, item) => {
    const costPerUnit = item.selectedWeight === 200 ? 11.20 : 9.50;
    return acc + (costPerUnit * item.quantity);
  }, 0);

  const finalTotal = subtotal + contributionAmount;

  // Real-time Agorist transparent calculations
  const artistRoyaltyFraction = subtotal > 0 
    ? (((subtotal - estimatedPhysicalProductionCosts) + contributionAmount) / finalTotal * 100).toFixed(1)
    : "0";

  const coopFraction = subtotal > 0 
    ? ((estimatedPhysicalProductionCosts) / finalTotal * 100).toFixed(1)
    : "0";

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !address) return;
    setCheckoutStep("complete");
  };

  const handleResetCheckout = () => {
    onClearCart();
    setCheckoutStep("cart");
    setFullName("");
    setAddress("");
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex justify-end z-50 select-none">
      
      {/* Drawer Overlay back-click */}
      <div className="absolute inset-0" onClick={onClose}></div>

      {/* Main Drawer Container */}
      <div 
        className="relative bg-[#FAFAF8] w-full max-w-lg h-full border-l border-black flex flex-col justify-between shadow-2xl z-10"
        id="cart-drawer-container"
      >
        
        {/* Drawer Header */}
        <div className="p-6 border-b border-neutral-200 flex items-center justify-between bg-black text-[#FAFAF8]">
          <div className="flex items-center gap-2">
            <span className="font-mono text-[10px] bg-[#FAFAF8] text-black px-1.5 py-0.5 font-bold">SHIP</span>
            <h2 className="font-sans font-extrabold text-sm tracking-tight uppercase">
              DIRECT OWNERSHIP CART
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-white border border-neutral-800 p-1 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic Steps rendering */}
        {checkoutStep === "cart" && (
          <div className="flex-1 flex flex-col justify-between overflow-y-auto no-scrollbar">
            
            {/* List items */}
            <div className="p-6 flex-1 overflow-y-auto no-scrollbar flex flex-col gap-4">
              <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold border-b border-neutral-200 pb-1">
                [MANUFACTURING ALLOCATIONS]
              </span>

              {cartItems.length === 0 ? (
                <div className="py-20 flex flex-col items-center justify-center text-center gap-3">
                  <div className="w-12 h-12 border border-dashed border-neutral-300 rounded-full flex items-center justify-center font-mono text-neutral-400">
                    ∅
                  </div>
                  <span className="font-mono text-[10px] text-neutral-400 uppercase tracking-widest">
                    DIRECT SHIPPING GRID IS EMPTY
                  </span>
                  <button 
                    onClick={onClose}
                    className="font-mono text-[9px] font-bold border border-black px-4 py-2 hover:bg-black hover:text-white transition-colors uppercase mt-2"
                  >
                    SELECT RECORDS
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-4 divide-y divide-neutral-100">
                  {cartItems.map((item, i) => (
                    <div key={`${item.product.id}-${item.selectedWeight}`} className={`pt-4 ${i === 0 ? "pt-0" : ""} flex gap-4 items-start`}>
                      
                      {/* Technical visual representation */}
                      <div className="w-16 h-16 border border-neutral-200 flex items-center justify-center bg-white font-mono text-[10px] font-bold">
                        {item.selectedWeight}G
                      </div>

                      {/* Info and Quantity block */}
                      <div className="flex-1 flex flex-col gap-1">
                        <div className="flex justify-between items-start font-mono text-[8px] text-neutral-400 uppercase">
                          <span>{item.product.artist}</span>
                          <span>{item.product.catalogNumber}</span>
                        </div>
                        <span className="font-sans font-bold text-xs tracking-tight text-black uppercase">
                          {item.product.release}
                        </span>
                        
                        <div className="flex items-center justify-between mt-2">
                          {/* Quantity selector */}
                          <div className="flex border border-black bg-white font-mono text-[9px] font-bold">
                            <button
                              onClick={() => onUpdateQuantity(item.product.id, item.selectedWeight, Math.max(1, item.quantity - 1))}
                              className="px-1.5 py-0.5 border-r border-black hover:bg-neutral-50"
                            >
                              -
                            </button>
                            <span className="px-2">{item.quantity}</span>
                            <button
                              onClick={() => onUpdateQuantity(item.product.id, item.selectedWeight, item.quantity + 1)}
                              className="px-1.5 py-0.5 border-l border-black hover:bg-neutral-50"
                            >
                              +
                            </button>
                          </div>

                          <div className="flex items-center gap-3">
                            <span className="font-mono text-xs font-bold text-black">
                              ${(item.product.price * item.quantity).toFixed(2)}
                            </span>
                            
                            <button
                              onClick={() => onRemoveItem(item.product.id, item.selectedWeight)}
                              className="text-[#555555] hover:text-red-600 transition-colors"
                              title="REMOVE ALLOCATION"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Agorist Philosphical Transparency Slider */}
            {cartItems.length > 0 && (
              <div className="p-6 bg-white border-t border-b border-neutral-200 flex flex-col gap-4">
                <span className="font-mono text-[9px] text-black tracking-widest uppercase font-bold border-b border-neutral-100 pb-1.5 flex items-center justify-between">
                  <span>VOLUNTARY COOPERATIVE CONTRIBUTION</span>
                  <span className="text-black bg-neutral-100 px-1 font-mono font-medium border border-neutral-200">{contribution}%</span>
                </span>

                <div className="flex flex-col gap-2">
                  <input
                    type="range"
                    min="0"
                    max="50"
                    step="5"
                    value={contribution}
                    onChange={(e) => setContribution(parseInt(e.target.value))}
                    className="w-full accent-black h-1 bg-neutral-100 rounded-none cursor-pointer"
                    id="donation-slider"
                  />
                  <p className="font-sans text-[10px] text-[#555555] leading-normal">
                    Traditional distributors extract up to 50% rent-seeking fees. Agorist Vinyl operates transparently. Adjust this booster to allocate more funds directly to the artist's wallet.
                  </p>
                </div>

                {/* Live Math Transparency breakdown */}
                <div className="flex flex-col gap-1.5 bg-neutral-50 p-3 border border-neutral-200 font-mono text-[9px]">
                  <div className="flex justify-between text-black font-semibold">
                    <span>AGGREGATE VALUATION RATIO:</span>
                    <span>100% OWNERSHIP VALUE</span>
                  </div>
                  <div className="flex justify-between text-green-700 mt-1">
                    <span>DIRECT TO ARTIST SHARE:</span>
                    <span>{artistRoyaltyFraction}%</span>
                  </div>
                  <div className="flex justify-between text-[#555555]">
                    <span>PHYSICAL MATERIALS &amp; CO-OP COSTS:</span>
                    <span>{coopFraction}%</span>
                  </div>
                  <div className="flex justify-between text-neutral-400 line-through">
                    <span>CENTRAL RENT-SEEKERS / PLATFORMS:</span>
                    <span>0% (AGORIC ZERO)</span>
                  </div>
                </div>
              </div>
            )}

            {/* Total Block & Navigation Trigger */}
            {cartItems.length > 0 && (
              <div className="p-6 bg-neutral-50 flex flex-col gap-4">
                <div className="flex flex-col gap-1 font-mono text-xs">
                  <div className="flex justify-between text-[#555555]">
                    <span>BASE SUB-TOTAL VALUATION:</span>
                    <span>${subtotal.toFixed(2)} USD</span>
                  </div>
                  <div className="flex justify-between text-green-700">
                    <span>VOLUNTARY BOOSTER PROCEEDS:</span>
                    <span>+${contributionAmount.toFixed(2)} USD</span>
                  </div>
                  <div className="flex justify-between text-black font-extrabold text-sm border-t border-black/10 pt-2 mt-1">
                    <span>FINAL SETTLEMENT TOTAL:</span>
                    <span>${finalTotal.toFixed(2)} USD</span>
                  </div>
                </div>

                <button
                  onClick={() => setCheckoutStep("shipping")}
                  className="w-full bg-black hover:bg-neutral-900 text-white font-mono text-[10px] font-extrabold tracking-[0.2em] uppercase py-4 flex items-center justify-center gap-3 transition-colors cursor-pointer"
                  id="checkout-step-btn"
                >
                  <span>PROCEED TO SHIPMENT PROTOCOL</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

          </div>
        )}

        {/* Shipping details input screen */}
        {checkoutStep === "shipping" && (
          <form onSubmit={handleCheckoutSubmit} className="flex-1 flex flex-col justify-between p-6 overflow-y-auto no-scrollbar">
            <div className="flex flex-col gap-6">
              <span className="font-mono text-[9px] text-[#555555] tracking-widest uppercase font-bold border-b border-neutral-200 pb-1">
                [SECURE DELIVERY IDENTIFICATION]
              </span>

              <div className="flex flex-col gap-4 font-mono text-[10px]">
                
                {/* Full name input */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[#555555] uppercase font-bold">FULL NAME / NOM-DE-GUERRE:</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="E.G. JOHN SMITH"
                    className="w-full border border-black p-2.5 bg-white font-sans text-xs uppercase tracking-wide outline-none focus:ring-1 focus:ring-neutral-500"
                    id="shipping-name-input"
                  />
                  <span className="text-[8px] text-neutral-400">Anonymous pseudonyms are fully supported for agoric trade</span>
                </div>

                {/* Delivery address */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-[#555555] uppercase font-bold">DELIVERY COORDS / STREET ADDRESS:</label>
                  <textarea
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="E.G. 14 APERTURE BLVD, SECTOR 7"
                    rows={3}
                    className="w-full border border-black p-2.5 bg-white font-sans text-xs uppercase tracking-wide outline-none focus:ring-1 focus:ring-neutral-500"
                    id="shipping-address-input"
                  />
                  <span className="text-[8px] text-neutral-400">Encrypted in-transit using local client-side session hashing</span>
                </div>

                {/* Settlement currency selection */}
                <div className="flex flex-col gap-2">
                  <label className="text-[#555555] uppercase font-bold">SETTLEMENT PROTOCOL:</label>
                  <div className="grid grid-cols-3 border border-black p-0.5 bg-white">
                    <button
                      type="button"
                      onClick={() => setCurrencyChoice("USD")}
                      className={`py-2 text-[9px] font-bold ${currencyChoice === "USD" ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                    >
                      USD CURRENCY
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrencyChoice("BTC")}
                      className={`py-2 text-[9px] font-bold ${currencyChoice === "BTC" ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                    >
                      BITCOIN
                    </button>
                    <button
                      type="button"
                      onClick={() => setCurrencyChoice("XMR")}
                      className={`py-2 text-[9px] font-bold ${currencyChoice === "XMR" ? "bg-black text-white" : "text-black hover:bg-neutral-50"}`}
                    >
                      MONERO
                    </button>
                  </div>
                  <span className="text-[8px] text-neutral-400">
                    {currencyChoice === "XMR" && "MONERO (XMR): zero-knowledge proof voluntary exchange network enabled"}
                    {currencyChoice === "BTC" && "BITCOIN (BTC): native multisig escrow ledger reference"}
                    {currencyChoice === "USD" && "USD CREDIT: processed through standard peer-to-peer gateways"}
                  </span>
                </div>

              </div>
            </div>

            {/* Total block and submit buttons */}
            <div className="flex flex-col gap-4 border-t border-neutral-200 pt-6 mt-6">
              <div className="font-mono text-xs flex justify-between text-black font-extrabold">
                <span>SETTLEMENT TOTAL DUE:</span>
                <span>
                  {currencyChoice === "USD" && `$${finalTotal.toFixed(2)} USD`}
                  {currencyChoice === "BTC" && `${(finalTotal * 0.000014).toFixed(6)} BTC`}
                  {currencyChoice === "XMR" && `${(finalTotal * 0.0058).toFixed(4)} XMR`}
                </span>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setCheckoutStep("cart")}
                  className="flex-1 font-mono text-[9px] font-bold border border-black py-4 hover:bg-neutral-100 transition-colors text-center uppercase"
                >
                  BACK TO CART
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-black hover:bg-neutral-900 text-white font-mono text-[9px] font-extrabold tracking-wider py-4 flex items-center justify-center gap-1 uppercase"
                  id="submit-order-btn"
                >
                  <span>EXECUTE SETTLEMENT</span>
                  <Check className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </form>
        )}

        {/* Complete confirmation step */}
        {checkoutStep === "complete" && (
          <div className="flex-1 p-8 flex flex-col justify-center items-center text-center gap-6">
            <div className="w-16 h-16 rounded-full border-[1.5px] border-black flex items-center justify-center relative">
              <div className="absolute inset-1.5 border border-dashed border-neutral-300 rounded-full"></div>
              <ShieldCheck className="w-8 h-8 text-black" />
            </div>

            <div className="flex flex-col gap-2 max-w-sm">
              <span className="font-mono text-[8px] text-green-600 tracking-widest uppercase font-bold">
                PROCEEDING SUCCESS // RECORD LOGGED
              </span>
              <h3 className="font-sans font-extrabold text-sm text-black uppercase tracking-tight">
                SETTLEMENT BROADCASTED
              </h3>
              <p className="font-sans text-xs text-[#555555] leading-relaxed">
                Thank you, <strong className="text-black">{fullName}</strong>. Your voluntary order has been registered and scheduled for direct manufacture dispatch to <strong className="text-black">{address}</strong>.
              </p>
            </div>

            {/* Simulated QC batch proof */}
            <div className="w-full bg-white p-4 border border-neutral-200 font-mono text-[8px] text-[#555555] flex flex-col gap-1 text-left">
              <div className="flex justify-between font-bold text-black border-b border-neutral-100 pb-1">
                <span>LOCAL RECEIPT HASH</span>
                <span>STATUS: QUEUED</span>
              </div>
              <span className="truncate">ORDER_BLOCK_HEX: 4f8e23daefbc89710328a1122daefbc8971032bda9f8e3d8f8a1122daef</span>
              <span>BATCH ASSIGNMENT: {cartItems[0]?.product.batchNo || "AV-2026-TBA"}</span>
            </div>

            <button
              onClick={handleResetCheckout}
              className="font-mono text-[9px] font-extrabold tracking-widest bg-black text-white px-8 py-4 uppercase border border-black hover:bg-neutral-900 transition-colors"
              id="confirm-reset-btn"
            >
              COMPLETE DIRECT ACTION
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
