import React from "react";
import { Play, Eye, ShoppingCart } from "lucide-react";
import { VinylProduct } from "../types";
import { VinylCover } from "./VinylCover";

interface ProductCardProps {
  product: VinylProduct;
  onOpenDetails: (product: VinylProduct) => void;
  onPlayTrack: (product: VinylProduct) => void;
  onAddToCart: (product: VinylProduct) => void;
  isPlaying: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenDetails,
  onPlayTrack,
  onAddToCart,
  isPlaying,
}) => {
  return (
    <article 
      className="bg-transparent border border-[#E7E7E7] hover:border-black/30 transition-all duration-500 flex flex-col p-4 group select-none relative"
      id={`product-card-${product.id}`}
    >
      {/* Outer Cad Target Mark on Hover */}
      <span className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 font-mono text-[9px] text-black">
        ⊕
      </span>

      {/* Dynamic Cover Art Display (Sharp SVGs) */}
      <div 
        className="relative aspect-square overflow-hidden mb-4 cursor-pointer"
        onClick={() => onOpenDetails(product)}
      >
        <VinylCover
          style={product.coverStyle}
          artist={product.artist}
          release={product.release}
          catalogNumber={product.catalogNumber}
          isPlaying={isPlaying}
          className="group-hover:scale-[1.01] transition-transform duration-700"
        />

        {/* Hover Quick Actions Overlay */}
        <div className="absolute inset-0 bg-neutral-900/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-3 z-10 backdrop-blur-[1px]">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onPlayTrack(product);
            }}
            className="w-10 h-10 bg-white hover:bg-black hover:text-white text-black transition-colors flex items-center justify-center font-bold relative"
            title="PLAY CHORD PREVIEW"
            id={`play-hover-${product.id}`}
          >
            <Play className={`w-4.5 h-4.5 ${isPlaying ? "fill-current animate-pulse text-green-600" : "fill-current"}`} />
          </button>
          
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpenDetails(product);
            }}
            className="w-10 h-10 bg-white hover:bg-black hover:text-white text-black transition-colors flex items-center justify-center font-bold"
            title="INSPECT CAD SCHEMATIC"
            id={`details-hover-${product.id}`}
          >
            <Eye className="w-4.5 h-4.5" />
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onAddToCart(product);
            }}
            className="w-10 h-10 bg-white hover:bg-black hover:text-white text-black transition-colors flex items-center justify-center font-bold"
            title="ADD TO DIRECT SHIPMENT"
            id={`cart-hover-${product.id}`}
          >
            <ShoppingCart className="w-4.5 h-4.5" />
          </button>
        </div>
      </div>

      {/* Content Details Block */}
      <div className="flex flex-col gap-1.5 mt-auto">
        <div className="flex justify-between items-start font-mono text-[9px] text-neutral-400 uppercase tracking-widest font-semibold">
          <span>{product.artist}</span>
          <span>{product.catalogNumber}</span>
        </div>

        <h3 
          className="font-sans font-extrabold text-sm text-black tracking-tight cursor-pointer hover:underline uppercase"
          onClick={() => onOpenDetails(product)}
        >
          {product.release}
        </h3>

        {/* Fine Technical Metadata */}
        <div className="flex justify-between items-center text-[10px] font-mono text-[#555555] py-1 border-t border-b border-[#E7E7E7] my-1">
          <span>{product.weight}G / {product.rpm} RPM</span>
          <span>DEV: {product.pressTolerance}</span>
        </div>

        <div className="flex justify-between items-center pt-1">
          <span className="font-mono text-xs font-extrabold text-black">
            ${product.price.toFixed(2)} USD
          </span>
          
          <span className="font-mono text-[8px] text-neutral-400 border border-neutral-200 px-1 py-0.5">
            EDITION: L-350
          </span>
        </div>
      </div>
    </article>
  );
};
