// Web Audio API Synthesizer & Vinyl Crackle Simulator

class AudioEngine {
  private ctx: AudioContext | null = null;
  private oscillators: OscillatorNode[] = [];
  private gainNodes: GainNode[] = [];
  private crackleNode: AudioWorkletNode | ScriptProcessorNode | null = null;
  private crackleGain: GainNode | null = null;
  private masterGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;

  private currentBpm: number = 120;
  private currentRPM: number = 33;
  private currentPitch: number = 0; // -8 to +8 percent
  private crackleLevel: number = 0.25;
  private filterWarmth: number = 50; // 0 to 100

  // Interval for generative note sequences
  private synthInterval: any = null;

  constructor() {
    // Initialized lazily on user interaction to comply with browser autoplay policies
  }

  private init() {
    if (this.ctx) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioContextClass();

      // Master gain
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.2, this.ctx.currentTime);

      // Low-pass warm filter (simulates analog tube preamp)
      this.filterNode = this.ctx.createBiquadFilter();
      this.filterNode.type = "lowpass";
      this.updateFilter();

      // Connections
      this.filterNode.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);

      // Start vinyl crackle node
      this.startCrackleEngine();
    } catch (e) {
      console.warn("Web Audio API not supported or blocked in this context", e);
    }
  }

  private startCrackleEngine() {
    if (!this.ctx || !this.filterNode) return;

    this.crackleGain = this.ctx.createGain();
    this.crackleGain.gain.setValueAtTime(this.crackleLevel * 0.15, this.ctx.currentTime);
    this.crackleGain.connect(this.filterNode);

    // Replicate classic crackle using ScriptProcessor (or fall back to noise)
    try {
      // Create random buffer noise with pops
      const bufferSize = 2048;
      if (this.ctx.createScriptProcessor) {
        this.crackleNode = this.ctx.createScriptProcessor(bufferSize, 1, 1);
        this.crackleNode.onaudioprocess = (e) => {
          const output = e.outputBuffer.getChannelData(0);
          for (let i = 0; i < bufferSize; i++) {
            // White noise base
            let noise = (Math.random() * 2 - 1) * 0.04;
            
            // Random static pop spikes
            if (Math.random() < 0.0003) {
              const spike = (Math.random() * 2 - 1) * 0.8;
              noise += spike;
            }
            
            // Periodic slow friction thuds (simulating rotational dust, every 1.8s for 33 RPM)
            const rotPeriod = this.currentRPM === 33 ? 1.8 : 1.33;
            const rotTime = this.ctx!.currentTime % rotPeriod;
            if (rotTime < 0.05 && Math.random() < 0.3) {
              noise += (Math.random() * 2 - 1) * 0.3 * Math.exp(-rotTime * 100);
            }

            output[i] = noise;
          };
        };
        this.crackleNode.connect(this.crackleGain);
      }
    } catch (err) {
      console.warn("Could not create ScriptProcessor crackle node", err);
    }
  }

  private updateFilter() {
    if (!this.filterNode || !this.ctx) return;
    // Map warmth 0-100 to lowpass cutoff (lower cutoff = warmer/darker analog sound)
    const minFreq = 400;
    const maxFreq = 8000;
    const targetFreq = maxFreq - (this.filterWarmth / 100) * (maxFreq - minFreq);
    this.filterNode.frequency.setValueAtTime(targetFreq, this.ctx.currentTime);
    this.filterNode.Q.setValueAtTime(1.0, this.ctx.currentTime);
  }

  public play(bpm: number, catalog: string) {
    this.init();
    if (!this.ctx) return;
    
    // Resume context if suspended
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }

    this.stopSynth();
    this.currentBpm = bpm;

    // Build unique frequencies based on catalog seed
    const charSum = catalog.split("").reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const baseFreq = 55 + (charSum % 4) * 13.75; // A1 (55Hz) to C2-ish

    const chordDegrees = [0, 4, 7, 11, 14]; // Maj9 chord formula
    const playChord = () => {
      if (!this.ctx || !this.filterNode) return;
      
      const pitchMultiplier = 1 + this.currentPitch / 100;
      const speedFactor = this.currentRPM === 45 ? 1.35 : 1.0;
      const finalMultiplier = pitchMultiplier * speedFactor;

      // Clean old notes
      this.oscillators.forEach(osc => {
        try { osc.stop(); } catch(e){}
      });
      this.oscillators = [];
      this.gainNodes = [];

      chordDegrees.forEach((degree, index) => {
        const osc = this.ctx!.createOscillator();
        const gainNode = this.ctx!.createGain();

        // High precision wave shaping: Dieter Rams loves pristine sine waves
        osc.type = index % 3 === 0 ? "triangle" : "sine";
        
        // Equal-temperament frequency calculation
        const freq = baseFreq * Math.pow(2, degree / 12) * finalMultiplier;
        osc.frequency.setValueAtTime(freq, this.ctx!.currentTime);

        // Slow cinematic envelope fades
        const now = this.ctx!.currentTime;
        gainNode.gain.setValueAtTime(0, now);
        gainNode.gain.linearRampToValueAtTime(0.08 / chordDegrees.length, now + 1.5);
        gainNode.gain.exponentialRampToValueAtTime(0.001, now + (60 / this.currentBpm) * 8);

        osc.connect(gainNode);
        gainNode.connect(this.filterNode!);
        
        osc.start(now);
        
        this.oscillators.push(osc);
        this.gainNodes.push(gainNode);
      });
    };

    // Play immediate chord
    playChord();

    // Loop chord according to BPM
    const beatIntervalMs = (60 / this.currentBpm) * 4 * 1000;
    this.synthInterval = setInterval(() => {
      playChord();
    }, beatIntervalMs);
  }

  private stopSynth() {
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    this.oscillators.forEach(osc => {
      try {
        osc.stop();
      } catch (e) {}
    });
    this.oscillators = [];
  }

  public stop() {
    this.stopSynth();
  }

  public setVolume(volume: number) {
    this.init();
    if (!this.masterGain || !this.ctx) return;
    this.masterGain.gain.setValueAtTime(volume * 0.3, this.ctx.currentTime);
  }

  public setCalibration(rpm: number, pitchPercent: number) {
    this.currentRPM = rpm;
    this.currentPitch = pitchPercent;
    
    // Re-modulate existing oscillator frequencies on-the-fly
    if (this.ctx && this.oscillators.length > 0) {
      const pitchMultiplier = 1 + this.currentPitch / 100;
      const speedFactor = this.currentRPM === 45 ? 1.35 : 1.0;
      const finalMultiplier = pitchMultiplier * speedFactor;

      // Shift frequencies on existing nodes
      this.oscillators.forEach((osc, i) => {
        try {
          const currentFreq = osc.frequency.value;
          // Calculate target based on base
          // To keep it simple, shift pitch instantly
          osc.frequency.setTargetAtTime(osc.frequency.value * finalMultiplier / (this.currentRPM === 45 ? 1.35 : 1.0), this.ctx!.currentTime, 0.2);
        } catch(e){}
      });
    }
  }

  public setCrackleLevel(level: number) {
    this.crackleLevel = level;
    this.init();
    if (this.crackleGain && this.ctx) {
      this.crackleGain.gain.setValueAtTime(level * 0.15, this.ctx.currentTime);
    }
  }

  public setWarmth(warmth: number) {
    this.filterWarmth = warmth;
    this.init();
    this.updateFilter();
  }
}

export const audioSystem = new AudioEngine();
export default audioSystem;
