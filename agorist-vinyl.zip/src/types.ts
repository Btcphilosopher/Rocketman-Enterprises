export interface Track {
  id: string;
  title: string;
  duration: string;
  audioUrl?: string; // Simulated audio
  bpm?: number;
}

export interface VinylProduct {
  id: string;
  artist: string;
  release: string;
  catalogNumber: string;
  price: number;
  weight: number; // 180g or 200g
  rpm: number; // 33 or 45
  batchNo: string;
  pressTolerance: string; // e.g. "+0.002 mm"
  masterCut: string; // e.g. "DMM (Direct Metal Mastering)"
  dynamicRange: string; // e.g. "14 dB"
  edition: string; // e.g. "First Edition, 500 units"
  runNumber: string; // e.g. "001-500"
  qcPassed: string; // e.g. "J. Dietrich"
  releasedYear: number;
  coverStyle: "geometric" | "minimal" | "line-art" | "abstract" | "photographic";
  description: string;
  tracks: Track[];
}

export interface CartItem {
  product: VinylProduct;
  quantity: number;
  selectedWeight: number;
}

export interface QCReport {
  batchNo: string;
  purity: string; // e.g. "99.98% Virgin Copolymer"
  thickness: string; // e.g. "1.92 mm"
  weightDistribution: string; // e.g. "180.2g ±0.1g"
  groovePurity: string; // e.g. "Uncompromised"
  measuredDr: number; // e.g. 14.2
  lacquerEngineer: string;
  hash: string;
}
