import React, { useState, useEffect } from 'react';
import { Page, PhotoItem, MerchandiseItem, CartItem } from './types';
import { PHOTOS_DATA } from './data/mockData';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { LightboxModal } from './components/LightboxModal';
import { CartDrawer } from './components/CartDrawer';

import { HomePage } from './components/pages/HomePage';
import { AboutPage } from './components/pages/AboutPage';
import { PortfolioPage } from './components/pages/PortfolioPage';
import { PhotosPage } from './components/pages/PhotosPage';
import { CampaignsPage } from './components/pages/CampaignsPage';
import { VideosPage } from './components/pages/VideosPage';
import { NewsPage } from './components/pages/NewsPage';
import { CalendarPage } from './components/pages/CalendarPage';
import { FanClubPage } from './components/pages/FanClubPage';
import { StorePage } from './components/pages/StorePage';
import { ContactPage } from './components/pages/ContactPage';
import { AdminDashboard } from './components/pages/AdminDashboard';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [darkMode, setDarkMode] = useState<boolean>(false);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  // Lightbox Modal state
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoItem | null>(null);

  // Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState<boolean>(false);

  // News article deep link state
  const [activeNewsArticleId, setActiveNewsArticleId] = useState<string | null>(null);

  // Synchronize dark mode class on HTML document
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Cart helper actions
  const addToCart = (product: MerchandiseItem) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const updateQuantity = (productId: string, qty: number) => {
    if (qty <= 0) {
      setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
    } else {
      setCartItems((prev) =>
        prev.map((item) =>
          item.product.id === productId ? { ...item, quantity: qty } : item
        )
      );
    }
  };

  const clearCart = () => setCartItems([]);

  // Lightbox navigation helpers
  const handleNextPhoto = () => {
    if (!selectedPhoto) return;
    const currentIndex = PHOTOS_DATA.findIndex((p) => p.id === selectedPhoto.id);
    const nextIndex = (currentIndex + 1) % PHOTOS_DATA.length;
    setSelectedPhoto(PHOTOS_DATA[nextIndex]);
  };

  const handlePrevPhoto = () => {
    if (!selectedPhoto) return;
    const currentIndex = PHOTOS_DATA.findIndex((p) => p.id === selectedPhoto.id);
    const prevIndex = (currentIndex - 1 + PHOTOS_DATA.length) % PHOTOS_DATA.length;
    setSelectedPhoto(PHOTOS_DATA[prevIndex]);
  };

  const openNewsArticle = (articleId: string) => {
    setActiveNewsArticleId(articleId);
    setCurrentPage('news');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-[#F9F8F6] text-[#1A1A1A] dark:bg-[#121111] dark:text-[#F9F8F6] transition-colors duration-300 font-sans selection:bg-[#1A1A1A] selection:text-[#F9F8F6] dark:selection:bg-[#F9F8F6] dark:selection:text-[#1A1A1A]">
      
      {/* Top Header */}
      <Header
        currentPage={currentPage}
        setCurrentPage={(p) => {
          setCurrentPage(p);
          setActiveNewsArticleId(null);
        }}
        cartCount={totalCartCount}
        openCart={() => setCartOpen(true)}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        isAdmin={isAdmin}
        setIsAdmin={setIsAdmin}
      />

      {/* Main Page View */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <HomePage
            setCurrentPage={setCurrentPage}
            onSelectPhoto={(photo) => setSelectedPhoto(photo)}
            openNewsArticle={openNewsArticle}
          />
        )}

        {currentPage === 'about' && <AboutPage />}

        {currentPage === 'portfolio' && (
          <PortfolioPage onSelectPhoto={(photo) => setSelectedPhoto(photo)} />
        )}

        {currentPage === 'photos' && (
          <PhotosPage onSelectPhoto={(photo) => setSelectedPhoto(photo)} />
        )}

        {currentPage === 'campaigns' && <CampaignsPage />}

        {currentPage === 'videos' && <VideosPage />}

        {currentPage === 'news' && (
          <NewsPage initialArticleId={activeNewsArticleId} />
        )}

        {currentPage === 'calendar' && <CalendarPage />}

        {currentPage === 'fanclub' && <FanClubPage />}

        {currentPage === 'store' && <StorePage addToCart={addToCart} />}

        {currentPage === 'contact' && <ContactPage />}

        {currentPage === 'admin' && <AdminDashboard />}
      </main>

      {/* Editorial Footer */}
      <Footer setCurrentPage={setCurrentPage} />

      {/* Lightbox Fullscreen Viewer */}
      <LightboxModal
        photo={selectedPhoto}
        onClose={() => setSelectedPhoto(null)}
        onPrev={handlePrevPhoto}
        onNext={handleNextPhoto}
        totalCount={PHOTOS_DATA.length}
        currentIndex={
          selectedPhoto
            ? PHOTOS_DATA.findIndex((p) => p.id === selectedPhoto.id)
            : 0
        }
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        updateQuantity={updateQuantity}
        clearCart={clearCart}
      />

    </div>
  );
}
