export type Page =
  | 'home'
  | 'about'
  | 'portfolio'
  | 'photos'
  | 'campaigns'
  | 'videos'
  | 'news'
  | 'calendar'
  | 'fanclub'
  | 'store'
  | 'contact'
  | 'admin';

export type PortfolioCategory =
  | 'All'
  | 'Editorial'
  | 'Fashion'
  | 'Beauty'
  | 'Luxury'
  | 'Commercial'
  | 'Runway'
  | 'Lifestyle'
  | 'Campaigns'
  | 'Film'
  | 'BTS';

export interface PhotoItem {
  id: string;
  title: string;
  category: PortfolioCategory;
  year: number;
  imageUrl: string;
  thumbnailUrl?: string;
  photographer: string;
  publication?: string;
  location?: string;
  isBlackAndWhite?: boolean;
  season?: 'Spring/Summer' | 'Autumn/Winter' | 'Resort' | 'Haute Couture';
  description?: string;
  featured?: boolean;
  aspectRatio?: 'portrait' | 'landscape' | 'square' | 'tall';
}

export interface CampaignItem {
  id: string;
  title: string;
  brand: string;
  year: number;
  season: string;
  creativeDirector: string;
  photographer: string;
  publication: string;
  coverImage: string;
  galleryImages: string[];
  story: string;
  videoUrl?: string;
  featured?: boolean;
}

export interface VideoItem {
  id: string;
  title: string;
  category: 'Editorial Film' | 'Runway' | 'Interviews' | 'Behind the Scenes' | 'Press';
  duration: string;
  thumbnailUrl: string;
  videoUrl: string;
  date: string;
  description: string;
  featured?: boolean;
}

export interface NewsArticle {
  id: string;
  title: string;
  date: string;
  publication: string;
  category: 'Magazine Feature' | 'Campaign Launch' | 'Fashion Week' | 'Interview' | 'Travel Journal';
  excerpt: string;
  content: string[];
  coverImage: string;
  gallery?: string[];
  readTime: string;
  author?: string;
  featured?: boolean;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  isoDate: string;
  location: string;
  country: string;
  category: 'Fashion Week' | 'Brand Event' | 'Photoshoot' | 'Meet & Greet' | 'Charity Gala' | 'Store Opening';
  description: string;
  status: 'Upcoming' | 'In Progress' | 'Completed';
  ticketsAvailable?: boolean;
  rsvpCount?: number;
}

export interface MerchandiseItem {
  id: string;
  title: string;
  category: 'Books' | 'Prints' | 'Stationery' | 'Apparel' | 'Gift Cards';
  price: number;
  description: string;
  details: string[];
  images: string[];
  isLimited?: boolean;
  isSigned?: boolean;
  stock: number;
}

export interface CartItem {
  product: MerchandiseItem;
  quantity: number;
}

export interface AgencyInfo {
  region: string;
  agency: string;
  contactName: string;
  email: string;
  phone: string;
  location: string;
}

export interface FanClubPerk {
  id: string;
  title: string;
  description: string;
  icon: string;
}

export interface DigitalWallpaper {
  id: string;
  title: string;
  resolution: string;
  imageUrl: string;
  downloadUrl: string;
  season: string;
}

export interface BookingEnquiry {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  enquiryType: 'Campaign' | 'Editorial' | 'Runway' | 'Commercial' | 'Press/Interview';
  dates: string;
  budget: string;
  message: string;
  dateSubmitted: string;
  status: 'Pending' | 'Reviewed' | 'Accepted' | 'Declined';
}
