import React, { useState } from 'react';
import { Page } from '../types';
import {
  Instagram,
  Twitter,
  Youtube,
  ShoppingBag,
  Menu,
  X,
  Moon,
  Sun,
  ShieldCheck,
  Calendar
} from 'lucide-react';

interface HeaderProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  cartCount: number;
  openCart: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  setCurrentPage,
  cartCount,
  openCart,
  darkMode,
  setDarkMode,
  isAdmin,
  setIsAdmin,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems: { label: string; page: Page }[] = [
    { label: 'HOME', page: 'home' },
    { label: 'ABOUT', page: 'about' },
    { label: 'PHOTOS', page: 'photos' },
    { label: 'VIDEOS', page: 'videos' },
    { label: 'PORTFOLIO', page: 'portfolio' },
    { label: 'CAMPAIGNS', page: 'campaigns' },
    { label: 'NEWS', page: 'news' },
    { label: 'CALENDAR', page: 'calendar' },
    { label: 'FAN CLUB', page: 'fanclub' },
    { label: 'STORE', page: 'store' },
    { label: 'CONTACT', page: 'contact' },
  ];

  const handleNavClick = (page: Page) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 backdrop-blur-md bg-[#F9F8F6]/90 dark:bg-[#121111]/90 border-b border-[#1A1A1A]/10 dark:border-[#2A2826] transition-colors duration-300">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Brand Logo */}
        <button
          onClick={() => handleNavClick('home')}
          className="group text-left focus:outline-none"
        >
          <span className="font-serif text-2xl sm:text-3xl tracking-[0.35em] font-light text-[#1A1A1A] dark:text-[#F9F8F6] uppercase group-hover:opacity-70 transition-opacity">
            L A R A &nbsp; A S H L E Y
          </span>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden xl:flex items-center space-x-6 text-[10px] font-medium tracking-[0.2em] text-[#1A1A1A]/70 dark:text-[#A8A29E]">
          {navItems.map((item) => {
            const isActive = currentPage === item.page;
            return (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className={`py-1 relative transition-all duration-200 uppercase hover:opacity-50 ${
                  isActive
                    ? 'text-[#1A1A1A] dark:text-[#F9F8F6] font-semibold'
                    : ''
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 w-full h-[1px] bg-[#1A1A1A] dark:bg-[#F9F8F6] transition-all" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Right Actions: Socials, Dark Mode, Cart, Admin Toggle */}
        <div className="flex items-center space-x-4 sm:space-x-5 text-[#1A1A1A] dark:text-[#F9F8F6]">
          
          {/* Social Icons (Desktop) */}
          <div className="hidden md:flex items-center space-x-3 text-[#1A1A1A]/60 dark:text-[#A8A29E] border-r border-[#1A1A1A]/10 dark:border-[#2A2826] pr-4">
            <a
              href="https://instagram.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
              className="hover:text-[#1A1A1A] dark:hover:text-[#F9F8F6] transition-colors"
            >
              <Instagram className="w-4 h-4" />
            </a>
            <a
              href="https://twitter.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Twitter"
              className="hover:text-[#1A1A1A] dark:hover:text-[#F9F8F6] transition-colors"
            >
              <Twitter className="w-4 h-4" />
            </a>
            <a
              href="https://youtube.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="YouTube"
              className="hover:text-[#1A1A1A] dark:hover:text-[#F9F8F6] transition-colors"
            >
              <Youtube className="w-4 h-4" />
            </a>
            <a
              href="https://tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="TikTok"
              className="hover:text-[#1A1A1A] dark:hover:text-[#F9F8F6] transition-colors text-xs font-semibold"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64c.29 0 .56.04.83.12V9.38a6.32 6.32 0 00-.83-.05A6.34 6.34 0 003.15 15.7 6.34 6.34 0 009.49 22c3.5 0 6.34-2.84 6.34-6.34V9.05a8.28 8.28 0 003.76 1.09V6.69z"/>
              </svg>
            </a>
          </div>

          {/* Cart Button */}
          <button
            onClick={openCart}
            aria-label="Shopping Bag"
            className="relative p-2 rounded-full hover:bg-[#E8E6E1]/50 dark:hover:bg-[#2A2826] transition-colors"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute top-1 right-1 bg-[#C5A059] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            aria-label="Toggle Theme"
            className="p-2 rounded-full hover:bg-[#E8E6E1]/50 dark:hover:bg-[#2A2826] transition-colors"
          >
            {darkMode ? (
              <Sun className="w-5 h-5 text-[#C5A059]" />
            ) : (
              <Moon className="w-5 h-5 text-[#1A1A1A]" />
            )}
          </button>

          {/* Admin Dashboard Quick Switch */}
          <button
            onClick={() => {
              const newAdmin = !isAdmin;
              setIsAdmin(newAdmin);
              if (newAdmin) handleNavClick('admin');
              else if (currentPage === 'admin') handleNavClick('home');
            }}
            title={isAdmin ? "Exit Manager Mode" : "Manager Dashboard"}
            className={`px-3 py-1.5 rounded-full text-xs tracking-wider uppercase font-medium flex items-center space-x-1.5 border transition-all ${
              isAdmin
                ? 'bg-[#1A1A1A] text-[#F9F8F6] border-[#1A1A1A] dark:bg-[#F9F8F6] dark:text-[#1A1A1A]'
                : 'border-[#1A1A1A]/20 dark:border-[#383533] hover:border-[#1A1A1A] dark:hover:border-[#F9F8F6]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#C5A059]" />
            <span className="hidden sm:inline">{isAdmin ? 'Manager' : 'Manager'}</span>
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle Mobile Menu"
            className="xl:hidden p-2 rounded-lg hover:bg-[#E8E6E1]/50 dark:hover:bg-[#2A2826] transition-colors"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-[#F9F8F6] dark:bg-[#121111] border-b border-[#1A1A1A]/10 dark:border-[#2A2826] px-6 py-6 space-y-4 animate-in slide-in-from-top duration-300">
          <div className="grid grid-cols-2 gap-3 text-xs tracking-[0.2em] font-medium uppercase text-[#1A1A1A]/70 dark:text-[#A8A29E]">
            {navItems.map((item) => (
              <button
                key={item.page}
                onClick={() => handleNavClick(item.page)}
                className={`text-left py-2 px-3 rounded-md transition-colors ${
                  currentPage === item.page
                    ? 'bg-[#1A1A1A] text-[#F9F8F6] font-semibold dark:bg-[#F9F8F6] dark:text-[#1A1A1A]'
                    : 'hover:bg-[#E8E6E1]/60 dark:hover:bg-[#2A2826]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-[#1A1A1A]/10 dark:border-[#2A2826] flex items-center justify-between text-xs text-[#8A8580]">
            <span>Official Flagship Portal</span>
            <div className="flex space-x-4 text-[#1A1A1A] dark:text-[#F9F8F6]">
              <a href="https://instagram.com" target="_blank" rel="noreferrer"><Instagram className="w-4 h-4" /></a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer"><Twitter className="w-4 h-4" /></a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer"><Youtube className="w-4 h-4" /></a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
