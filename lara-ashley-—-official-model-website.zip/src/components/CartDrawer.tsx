import React from 'react';
import { CartItem } from '../types';
import { X, ShoppingBag, Trash2, ArrowRight, ShieldCheck } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  updateQuantity: (productId: string, qty: number) => void;
  clearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  updateQuantity,
  clearCart,
}) => {
  if (!isOpen) return null;

  const total = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  const handleCheckout = () => {
    alert("Thank you for your order! In a production deployment, this redirects to secure Stripe luxury checkout.");
    clearCart();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#FAF8F5] dark:bg-[#121111] text-[#1C1B1A] dark:text-[#FAF8F5] h-full shadow-2xl flex flex-col justify-between p-6 sm:p-8 border-l border-[#EAE1D5] dark:border-[#2A2826]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#EAE1D5] dark:border-[#2A2826]">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="w-5 h-5 text-[#C5A059]" />
            <h2 className="font-serif text-2xl font-light">Shopping Bag</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto my-6 space-y-4 pr-1">
          {cartItems.length === 0 ? (
            <div className="text-center py-12 space-y-3">
              <ShoppingBag className="w-12 h-12 text-[#8C827A] mx-auto stroke-[1]" />
              <p className="font-serif text-xl font-light text-[#8C827A]">Your shopping bag is empty.</p>
              <p className="text-xs text-[#8C827A]">Explore our monographs, signed prints, and luxury accessories.</p>
            </div>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.product.id}
                className="flex items-center space-x-4 p-3 bg-[#F5F0EB] dark:bg-[#1E1C1B] rounded-xl border border-[#EAE1D5] dark:border-[#2A2826]"
              >
                <img
                  src={item.product.images[0]}
                  alt={item.product.title}
                  className="w-16 h-16 object-cover rounded-lg border border-[#D8D2C9] dark:border-[#383533]"
                />

                <div className="flex-1 min-w-0 space-y-1">
                  <h3 className="font-serif text-sm font-light truncate">{item.product.title}</h3>
                  <p className="text-xs text-[#8C827A]">€{item.product.price} each</p>
                  
                  <div className="flex items-center space-x-2 text-xs">
                    <button
                      onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                      className="px-2 py-0.5 bg-stone-300 dark:bg-stone-700 rounded"
                    >
                      -
                    </button>
                    <span>{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                      className="px-2 py-0.5 bg-stone-300 dark:bg-stone-700 rounded"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="text-right space-y-2">
                  <p className="font-serif text-sm font-bold">€{item.product.price * item.quantity}</p>
                  <button
                    onClick={() => updateQuantity(item.product.id, 0)}
                    className="text-red-500 hover:text-red-700 transition-colors p-1"
                    title="Remove item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Bottom Checkout Action */}
        {cartItems.length > 0 && (
          <div className="pt-4 border-t border-[#EAE1D5] dark:border-[#2A2826] space-y-4">
            <div className="flex items-center justify-between font-serif text-2xl font-light">
              <span>Total Amount:</span>
              <span className="font-bold text-[#C5A059]">€{total}</span>
            </div>

            <p className="text-[11px] text-[#8C827A] flex items-center space-x-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              <span>Complimentary insured express global shipping & gift boxing included.</span>
            </p>

            <button
              onClick={handleCheckout}
              className="w-full py-4 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-xl hover:bg-[#C5A059] dark:hover:bg-[#C5A059] dark:hover:text-black transition-colors flex items-center justify-center space-x-2 shadow-xl"
            >
              <span>PROCEED TO SECURE CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
