import React, { useEffect, useState } from 'react';
import { PhotoItem } from '../types';
import { X, ChevronLeft, ChevronRight, ZoomIn, ZoomOut, Download, Share2, Heart } from 'lucide-react';

interface LightboxModalProps {
  photo: PhotoItem | null;
  onClose: () => void;
  onPrev?: () => void;
  onNext?: () => void;
  totalCount?: number;
  currentIndex?: number;
}

export const LightboxModal: React.FC<LightboxModalProps> = ({
  photo,
  onClose,
  onPrev,
  onNext,
  totalCount,
  currentIndex,
}) => {
  const [zoomLevel, setZoomLevel] = useState(1);
  const [isLiked, setIsLiked] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setZoomLevel(1);
    setIsLiked(false);
  }, [photo]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!photo) return;
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft' && onPrev) onPrev();
      if (e.key === 'ArrowRight' && onNext) onNext();
      if (e.key === '+' || e.key === '=') handleZoomIn();
      if (e.key === '-') handleZoomOut();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [photo, onPrev, onNext]);

  if (!photo) return null;

  const handleZoomIn = () => setZoomLevel((prev) => Math.min(prev + 0.5, 3));
  const handleZoomOut = () => setZoomLevel((prev) => Math.max(prev - 0.5, 1));

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0E0D0C]/95 backdrop-blur-xl flex flex-col justify-between p-4 sm:p-6 text-[#FAF8F5] animate-in fade-in duration-200">
      
      {/* Top Bar Controls */}
      <div className="flex items-center justify-between text-xs tracking-widest uppercase py-2 border-b border-white/10 z-10">
        <div className="flex items-center space-x-3">
          <span className="font-serif text-lg tracking-widest text-[#C5A059]">LARA ASHLEY</span>
          <span className="text-white/40">|</span>
          <span className="text-white/70">
            {photo.category} {photo.year ? `(${photo.year})` : ''}
          </span>
          {currentIndex !== undefined && totalCount && (
            <span className="bg-white/10 px-2 py-0.5 rounded text-[10px]">
              {currentIndex + 1} / {totalCount}
            </span>
          )}
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleZoomIn}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
            title="Zoom In (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
            title="Zoom Out (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsLiked(!isLiked)}
            className={`p-2 rounded-full transition-colors ${
              isLiked ? 'text-red-500 bg-white/10' : 'hover:bg-white/10'
            }`}
            title="Favorite Photo"
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-current' : ''}`} />
          </button>

          <button
            onClick={handleShare}
            className="p-2 hover:bg-white/10 rounded-full transition-colors relative"
            title="Share Photo Link"
          >
            <Share2 className="w-4 h-4" />
            {copied && (
              <span className="absolute top-10 right-0 bg-[#C5A059] text-black text-[10px] px-2 py-1 rounded font-bold whitespace-nowrap">
                Link Copied!
              </span>
            )}
          </button>

          <a
            href={photo.imageUrl}
            download={`Lara_Ashley_${photo.id}.jpg`}
            target="_blank"
            rel="noreferrer"
            className="p-2 hover:bg-white/10 rounded-full transition-colors"
            title="Download High-Res"
          >
            <Download className="w-4 h-4" />
          </a>

          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 bg-white/10 rounded-full transition-colors text-white"
            title="Close Viewer (Esc)"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Center Image Container with Zoom & Keyboard Controls */}
      <div className="relative flex-1 flex items-center justify-center my-4 overflow-hidden select-none">
        {onPrev && (
          <button
            onClick={onPrev}
            className="absolute left-2 sm:left-6 z-20 p-3 bg-black/40 hover:bg-black/80 rounded-full border border-white/20 text-white transition-all hover:scale-105"
            title="Previous (Left Arrow)"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        )}

        <div className="max-w-full max-h-full overflow-auto flex items-center justify-center p-2">
          <img
            src={photo.imageUrl}
            alt={photo.title}
            style={{ transform: `scale(${zoomLevel})` }}
            className="max-h-[78vh] max-w-[90vw] object-contain transition-transform duration-200 ease-out shadow-2xl rounded-sm"
          />
        </div>

        {onNext && (
          <button
            onClick={onNext}
            className="absolute right-2 sm:right-6 z-20 p-3 bg-black/40 hover:bg-black/80 rounded-full border border-white/20 text-white transition-all hover:scale-105"
            title="Next (Right Arrow)"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        )}
      </div>

      {/* Bottom Editorial Caption */}
      <div className="bg-black/60 backdrop-blur-md p-4 rounded-lg border border-white/10 max-w-4xl mx-auto w-full flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs space-y-2 sm:space-y-0">
        <div>
          <h3 className="font-serif text-xl font-light text-[#FAF8F5] tracking-wide">
            {photo.title}
          </h3>
          <p className="text-white/60 pt-0.5">
            Photographer: <strong className="text-white">{photo.photographer}</strong>
            {photo.publication && <> &nbsp;•&nbsp; Publication: <strong className="text-white">{photo.publication}</strong></>}
            {photo.location && <> &nbsp;•&nbsp; Location: <strong className="text-white">{photo.location}</strong></>}
          </p>
        </div>

        <div className="flex items-center space-x-3 text-[11px] text-[#C5A059] uppercase tracking-widest font-medium">
          {photo.isBlackAndWhite && <span className="border border-[#C5A059]/40 px-2 py-0.5 rounded">Monochrome</span>}
          {photo.season && <span className="border border-[#C5A059]/40 px-2 py-0.5 rounded">{photo.season}</span>}
        </div>
      </div>

    </div>
  );
};
