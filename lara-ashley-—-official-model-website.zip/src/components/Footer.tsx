import React from 'react';
import { Page } from '../types';
import { Instagram, Twitter, Youtube, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  setCurrentPage: (page: Page) => void;
}

export const Footer: React.FC<FooterProps> = ({ setCurrentPage }) => {
  return (
    <footer className="bg-[#1A1A1A] text-[#F9F8F6] pt-16 pb-12 border-t border-white/10 transition-colors duration-300">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Editorial Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-16 border-b border-white/10">
          
          {/* Brand Info */}
          <div className="md:col-span-5 space-y-4">
            <h3 className="font-serif text-3xl tracking-[0.35em] font-light text-[#F9F8F6] uppercase">
              L A R A &nbsp; A S H L E Y
            </h3>
            <p className="text-[10px] uppercase tracking-[0.3em] text-[#C5A059] font-medium">
              Authenticity • Presence • Elegance • Timeless
            </p>
            <p className="text-xs text-[#A8A29E] max-w-md font-light leading-relaxed pt-2">
              The official flagship representation portal for international fashion model Lara Ashley. High fashion editorials, luxury campaigns, global fashion weeks, and private fan club atelier.
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-[10px] font-semibold uppercase tracking-[0.25em] text-[#C5A059]">
              Navigation
            </h4>
            <ul className="space-y-2 text-[11px] tracking-[0.2em] text-[#A8A29E] font-medium">
              <li>
                <button onClick={() => { setCurrentPage('about'); window.scrollTo(0,0); }} className="hover:text-[#F9F8F6] transition-colors">
                  BIOGRAPHY & AGENCIES
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('portfolio'); window.scrollTo(0,0); }} className="hover:text-[#F9F8F6] transition-colors">
                  EDITORIAL PORTFOLIO
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('campaigns'); window.scrollTo(0,0); }} className="hover:text-[#F9F8F6] transition-colors">
                  GLOBAL CAMPAIGNS
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('fanclub'); window.scrollTo(0,0); }} className="hover:text-[#F9F8F6] transition-colors">
                  THE ATELIER CLUB
                </button>
              </li>
              <li>
                <button onClick={() => { setCurrentPage('store'); window.scrollTo(0,0); }} className="hover:text-[#F9F8F6] transition-colors">
                  LUXURY STORE & BOOKS
                </button>
              </li>
            </ul>
          </div>

          {/* Representation & Enquiries */}
          <div className="md:col-span-4 space-y-3">
            <h4 className="text-[10px] font-semibold uppercase tracking-[0.25em] text-[#C5A059]">
              Professional Representation
            </h4>
            <div className="text-xs text-[#A8A29E] space-y-2 font-light">
              <p><strong className="text-[#F9F8F6] font-normal">Mother Agency:</strong> Elite Model Management Paris</p>
              <p><strong className="text-[#F9F8F6] font-normal">US Representation:</strong> IMG Models NYC</p>
              <p><strong className="text-[#F9F8F6] font-normal">Press & Enquiries:</strong> bookings@laraashley.com</p>
            </div>

            <div className="pt-3">
              <button
                onClick={() => { setCurrentPage('contact'); window.scrollTo(0,0); }}
                className="inline-flex items-center space-x-2 text-[10px] uppercase tracking-[0.2em] text-[#F9F8F6] border border-[#C5A059] px-4 py-2 hover:bg-[#C5A059] hover:text-[#1A1A1A] transition-all"
              >
                <span>Bookings & Press</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>

        {/* Geometric Balance Status Footer */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-[10px] tracking-widest text-[#8A8580] space-y-4 sm:space-y-0">
          <div className="flex space-x-8 uppercase">
            <span>IG / @LARAASHLEY</span>
            <span>TW / @LARAASHLEY</span>
          </div>

          <p>© {new Date().getFullYear()} LARA ASHLEY. All rights reserved.</p>
          
          <div className="flex items-center space-x-6">
            <div className="flex flex-col items-end">
              <span className="text-[9px] uppercase tracking-widest opacity-40">Editorial Excellence</span>
              <span className="text-[11px] font-medium tracking-tighter text-[#F9F8F6]">Est. 2024</span>
            </div>
            <div className="h-6 w-[1px] bg-white/20" />
            <div className="flex items-center">
              <span className="text-[14px] font-serif text-[#F9F8F6]">01</span>
              <span className="mx-2 text-[10px] opacity-30">/</span>
              <span className="text-[10px] opacity-30">08</span>
            </div>
          </div>
        </div>

      </div>
    </footer>
  );
};
