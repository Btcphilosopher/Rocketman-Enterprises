import React from 'react';
import { AGENCY_LIST, ABOUT_PORTRAIT_BW } from '../../data/mockData';
import { Globe, Award, Sparkles, Mail, Phone, MapPin } from 'lucide-react';

export const AboutPage: React.FC = () => {
  const careerTimeline = [
    { year: '2026', title: 'Saint Laurent SS26 Campaign & Chanel Haute Couture Opener', detail: 'Selected as the face of Saint Laurent global campaign shot by David Sims; opened Chanel Haute Couture at Grand Palais.' },
    { year: '2025', title: 'Vogue Italia & Harper’s Bazaar Cover Stories', detail: 'Appeared on 8 international Vogue covers; launched The Row Autumn/Winter campaign.' },
    { year: '2024', title: 'Dior Beauty Global Ambassador', detail: 'Appointed official ambassador for Dior Beauty; walk 22 runway shows during Paris, Milan, and New York Fashion Weeks.' },
    { year: '2022', title: 'Breakthrough Season in Milan & Paris', detail: 'Debut walking for Prada, Alexander McQueen, and Celine; named Model of the Year by British Fashion Council.' },
    { year: '2020', title: 'Discovered in Copenhagen', detail: 'Signed as mother agency talent with Elite Model Management Paris.' }
  ];

  const fashionPhilosophy = [
    { title: 'Restraint & Structure', text: 'True luxury lives in restraint. A single sharp line or effortless silhouette speaks far louder than excessive decoration.' },
    { title: 'Authentic Presence', text: 'Modeling is the art of wordless storytelling. Presence is captured when mind and body are fully aligned with the garment.' },
    { title: 'Scandinavian Heritage', text: 'Rooted in natural light, organic materials, and clean architecture, my personal philosophy reflects quiet confidence.' }
  ];

  const awards = [
    'International Model of the Year — British Fashion Awards (2025)',
    'Best Campaign Performance — Elle Style Awards (2025)',
    'Top 50 Models Worldwide — Models.com Official Ranking',
    'Copenhagen Design & Fashion Ambassador (2024)'
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-20 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Editorial Header */}
      <div className="border-b border-[#EAE1D5] dark:border-[#2A2826] pb-10 text-center max-w-3xl mx-auto space-y-4">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          BIOGRAPHY & PHILOSOPHY
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl lg:text-7xl font-light tracking-wide">
          LARA ASHLEY
        </h1>
        <p className="text-sm font-light text-[#8C827A] dark:text-[#A8A29E] tracking-widest uppercase">
          International Fashion Model • Paris • New York • London
        </p>
      </div>

      {/* Main Bio Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        
        {/* Left B&W Portrait */}
        <div className="lg:col-span-5 relative">
          <div className="relative aspect-[3/4] overflow-hidden rounded-2xl shadow-2xl bg-stone-200 dark:bg-stone-800">
            <img
              src={ABOUT_PORTRAIT_BW}
              alt="Lara Ashley Portrait"
              className="w-full h-full object-cover grayscale"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] p-6 rounded-xl shadow-2xl max-w-xs text-xs font-serif italic hidden sm:block">
            "Elegance isn't about being noticed; it's about being remembered."
          </div>
        </div>

        {/* Right Bio Narrative */}
        <div className="lg:col-span-7 space-y-6">
          <h2 className="font-serif text-3xl sm:text-4xl font-light leading-snug">
            A timeless presence on the world's most prestigious runways and magazine covers.
          </h2>

          <div className="space-y-4 text-sm font-light leading-relaxed text-[#4A4643] dark:text-[#A8A29E]">
            <p>
              Born with an innate appreciation for Scandinavian architectural minimalism and classical arts, Lara Ashley has established herself as one of high fashion's most sought-after muses.
            </p>
            <p>
              Over her seven-year career, Lara has fronted global campaigns for <strong>Saint Laurent</strong>, <strong>Chanel</strong>, <strong>Dior</strong>, and <strong>The Row</strong>. Her editorial portfolio spans cover features in <em>Vogue Paris</em>, <em>Harper’s Bazaar</em>, <em>W Magazine</em>, and <em>Kinfolk</em>.
            </p>
            <p>
              Beyond the lens, Lara is a passionate advocate for sustainable design, fine art curation, and author of the upcoming monograph <em>Presence</em>.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 pt-6 border-t border-[#EAE1D5] dark:border-[#2A2826] text-xs">
            <div>
              <span className="text-[#8C827A] dark:text-[#A8A29E] uppercase tracking-wider block">Height</span>
              <strong className="text-base font-serif">180 cm / 5'11"</strong>
            </div>
            <div>
              <span className="text-[#8C827A] dark:text-[#A8A29E] uppercase tracking-wider block">Bust / Waist / Hips</span>
              <strong className="text-base font-serif">83 / 60 / 89 cm</strong>
            </div>
            <div>
              <span className="text-[#8C827A] dark:text-[#A8A29E] uppercase tracking-wider block">Eyes & Hair</span>
              <strong className="text-base font-serif">Hazel / Soft Brown</strong>
            </div>
          </div>
        </div>

      </div>


      {/* Fashion Philosophy */}
      <div className="bg-[#F5F0EB] dark:bg-[#181716] rounded-2xl p-8 sm:p-12 border border-[#EAE1D5] dark:border-[#2A2826] space-y-8">
        <div className="text-center max-w-xl mx-auto space-y-2">
          <Sparkles className="w-5 h-5 text-[#C5A059] mx-auto" />
          <h2 className="font-serif text-3xl font-light">Fashion & Aesthetic Philosophy</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {fashionPhilosophy.map((phil, idx) => (
            <div key={idx} className="space-y-2">
              <h3 className="font-serif text-xl font-normal text-[#C5A059]">{phil.title}</h3>
              <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] leading-relaxed font-light">
                {phil.text}
              </p>
            </div>
          ))}
        </div>
      </div>


      {/* Career Timeline */}
      <div className="space-y-8">
        <h2 className="font-serif text-3xl font-light text-center">Career Milestones</h2>

        <div className="relative border-l border-[#C5A059]/40 ml-4 sm:ml-32 space-y-10">
          {careerTimeline.map((item, idx) => (
            <div key={idx} className="relative pl-8 group">
              {/* Timeline Dot */}
              <div className="absolute -left-[6.5px] top-1.5 w-3 h-3 rounded-full bg-[#1C1B1A] dark:bg-[#FAF8F5] border-2 border-[#C5A059]" />
              
              <span className="absolute -left-28 sm:-left-32 top-0 text-sm font-serif font-bold text-[#C5A059] hidden sm:block">
                {item.year}
              </span>

              <div className="space-y-1">
                <span className="text-xs font-bold text-[#C5A059] sm:hidden block">{item.year}</span>
                <h3 className="font-serif text-xl font-light">{item.title}</h3>
                <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] max-w-2xl font-light leading-relaxed">
                  {item.detail}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>


      {/* Global Agencies Representation */}
      <div className="space-y-8 pt-8">
        <div className="text-center space-y-2">
          <p className="text-xs uppercase tracking-[0.2em] text-[#C5A059] font-medium">REPRESENTATION</p>
          <h2 className="font-serif text-3xl font-light">Official Agency Network</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {AGENCY_LIST.map((ag, idx) => (
            <div
              key={idx}
              className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-4 hover:border-[#C5A059] transition-colors"
            >
              <div className="flex items-center justify-between border-b border-[#EAE1D5] dark:border-[#2A2826] pb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#C5A059]">
                  {ag.region}
                </span>
                <Globe className="w-4 h-4 text-[#8C827A]" />
              </div>

              <div>
                <h3 className="font-serif text-xl font-light">{ag.agency}</h3>
                <p className="text-xs text-[#8C827A] dark:text-[#A8A29E]">Agent: {ag.contactName}</p>
              </div>

              <div className="space-y-1.5 text-xs text-[#4A4643] dark:text-[#A8A29E] pt-2 border-t border-[#EAE1D5]/50 dark:border-[#2A2826]/50">
                <p className="flex items-center space-x-2">
                  <Mail className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>{ag.email}</span>
                </p>
                <p className="flex items-center space-x-2">
                  <Phone className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span>{ag.phone}</span>
                </p>
                <p className="flex items-center space-x-2">
                  <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
                  <span className="truncate">{ag.location}</span>
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>


      {/* Awards & Recognition */}
      <div className="bg-[#1C1B1A] text-[#FAF8F5] rounded-2xl p-8 sm:p-12 space-y-6">
        <div className="flex items-center space-x-3 text-[#C5A059]">
          <Award className="w-6 h-6" />
          <h2 className="font-serif text-2xl font-light uppercase tracking-widest">Awards & Recognition</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-light tracking-wide text-white/80">
          {awards.map((award, i) => (
            <div key={i} className="flex items-center space-x-3 p-3 bg-white/5 rounded-lg border border-white/10">
              <span className="w-2 h-2 rounded-full bg-[#C5A059]" />
              <span>{award}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
