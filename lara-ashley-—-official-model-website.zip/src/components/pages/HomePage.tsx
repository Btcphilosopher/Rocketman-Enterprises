import React, { useState } from 'react';
import { Page, PhotoItem } from '../../types';
import {
  HERO_IMAGE,
  ABOUT_PORTRAIT_BW,
  PHOTOS_DATA,
  EVENTS_DATA,
  NEWS_DATA
} from '../../data/mockData';
import { ArrowRight, Users, CheckCircle } from 'lucide-react';

interface HomePageProps {
  setCurrentPage: (page: Page) => void;
  onSelectPhoto: (photo: PhotoItem) => void;
  openNewsArticle?: (articleId: string) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  setCurrentPage,
  onSelectPhoto,
  openNewsArticle,
}) => {
  const [emailInput, setEmailInput] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.trim()) {
      setSubscribed(true);
      setEmailInput('');
      setTimeout(() => setSubscribed(false), 5000);
    }
  };

  const latestPhotos = PHOTOS_DATA.slice(0, 6);
  const featuredNews = NEWS_DATA[0];
  const upcomingEvents = EVENTS_DATA.slice(0, 4);

  return (
    <div className="space-y-12 sm:space-y-16 pb-12">
      
      {/* GEOMETRIC BALANCE HERO SECTION */}
      <section className="relative min-h-[82vh] lg:min-h-[88vh] grid grid-cols-1 lg:grid-cols-12 gap-0 overflow-hidden bg-[#E8E6E1] dark:bg-[#181716] border-b border-[#1A1A1A]/10 dark:border-[#2A2826]">
        
        {/* Left Editorial Info */}
        <div className="lg:col-span-5 flex flex-col justify-between p-8 sm:p-12 lg:p-16 z-10 bg-[#F9F8F6] dark:bg-[#121111] border-r border-[#1A1A1A]/10 dark:border-[#2A2826]">
          <div className="space-y-6 max-w-lg">
            <p className="text-[10px] tracking-[0.3em] uppercase opacity-40 font-medium">
              The Current Season
            </p>
            <h1 className="text-5xl sm:text-7xl font-serif leading-[0.9] italic font-light text-[#1A1A1A] dark:text-[#F9F8F6]">
              Silence of <br />the Muse
            </h1>
            <p className="text-xs leading-relaxed opacity-70 font-light max-w-sm">
              An exploration of natural light and architectural form. Photographed in the high deserts of Morocco by Julian Thorne for Vogue Paris.
            </p>
            
            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={() => { setCurrentPage('photos'); window.scrollTo(0,0); }}
                className="px-6 py-3.5 bg-[#1A1A1A] text-[#F9F8F6] dark:bg-[#F9F8F6] dark:text-[#1A1A1A] text-[10px] uppercase tracking-[0.2em] font-medium hover:opacity-80 transition-all"
              >
                View Campaign
              </button>
              <button
                onClick={() => { setCurrentPage('fanclub'); window.scrollTo(0,0); }}
                className="px-6 py-3.5 border border-[#1A1A1A] dark:border-[#F9F8F6] text-[10px] uppercase tracking-[0.2em] font-medium hover:bg-[#1A1A1A] hover:text-[#F9F8F6] dark:hover:bg-[#F9F8F6] dark:hover:text-[#1A1A1A] transition-all"
              >
                Join Fan Club
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 border-t border-[#1A1A1A]/10 dark:border-[#2A2826] pt-8 mt-12">
            <div>
              <span className="block text-[9px] uppercase tracking-widest opacity-40 mb-1">Representation</span>
              <span className="block text-[11px] font-medium">The Society, NYC</span>
            </div>
            <div>
              <span className="block text-[9px] uppercase tracking-widest opacity-40 mb-1">Current City</span>
              <span className="block text-[11px] font-medium">Paris, FR</span>
            </div>
          </div>
        </div>

        {/* Central Cinematic Image & Floating Atelier Club / Events Card */}
        <div className="lg:col-span-7 relative bg-[#E8E6E1] dark:bg-[#1C1B1A] min-h-[450px] lg:min-h-full">
          <div className="absolute inset-0 bg-cover bg-center mix-blend-multiply opacity-95 transition-all duration-700 hover:scale-105"
               style={{ backgroundImage: `url(${HERO_IMAGE})` }}
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#F9F8F6] dark:from-[#121111] via-transparent to-transparent opacity-80 lg:opacity-100" />
          
          {/* Floating Membership / Events Card */}
          <div className="relative lg:absolute bottom-8 right-8 m-6 lg:m-0 bg-white/50 dark:bg-black/50 backdrop-blur-md border border-white/40 dark:border-white/10 p-6 sm:p-8 max-w-sm shadow-2xl space-y-4">
            <div className="flex justify-between items-start">
              <span className="text-[10px] tracking-[0.3em] uppercase font-bold text-[#C5A059]">Atelier Club</span>
              <div className="w-2 h-2 rounded-full bg-[#C5A059] animate-pulse" />
            </div>
            
            <p className="text-xl font-serif italic font-light">Upcoming Private Circle & Events</p>
            
            <div className="divide-y divide-black/10 dark:divide-white/10 text-xs">
              {upcomingEvents.slice(0, 3).map((ev) => (
                <div key={ev.id} className="py-2 flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-[11px]">{ev.location}</p>
                    <p className="text-[10px] opacity-60">{ev.category}</p>
                  </div>
                  <span className="text-[10px] font-mono text-[#C5A059]">{ev.date}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => { setCurrentPage('calendar'); window.scrollTo(0,0); }}
              className="w-full py-3 border border-[#1A1A1A] dark:border-[#F9F8F6] text-[10px] uppercase tracking-[0.2em] font-medium hover:bg-[#1A1A1A] hover:text-white dark:hover:bg-[#F9F8F6] dark:hover:text-black transition-all"
            >
              Explore Calendar & Tickets
            </button>
          </div>
        </div>

      </section>


      {/* MAIN 3-COLUMN EDITORIAL GRID: LATEST NEWS | ABOUT LARA | LATEST PHOTOS */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#F5F0EB] dark:bg-[#181716] rounded-2xl p-6 sm:p-10 border border-[#EAE1D5] dark:border-[#2A2826] grid grid-cols-1 lg:grid-cols-3 gap-8 sm:gap-10">
          
          {/* COLUMN 1: LATEST NEWS */}
          <div className="flex flex-col justify-between space-y-4 pr-0 lg:pr-6 lg:border-r border-[#EAE1D5] dark:border-[#2A2826]">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[#1C1B1A] dark:text-[#FAF8F5] mb-4">
                LATEST NEWS
              </h2>

              <div className="group cursor-pointer space-y-4" onClick={() => openNewsArticle ? openNewsArticle(featuredNews.id) : setCurrentPage('news')}>
                <div className="overflow-hidden rounded-xl aspect-[4/3] bg-stone-200 dark:bg-stone-800">
                  <img
                    src={featuredNews.coverImage}
                    alt={featuredNews.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                <div className="space-y-2">
                  <span className="text-[11px] font-medium uppercase tracking-wider text-[#8C827A] dark:text-[#A8A29E]">
                    {featuredNews.date}
                  </span>
                  <h3 className="font-serif text-2xl font-light text-[#1C1B1A] dark:text-[#FAF8F5] group-hover:text-[#C5A059] transition-colors leading-tight">
                    {featuredNews.title}
                  </h3>
                  <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] leading-relaxed line-clamp-3">
                    {featuredNews.excerpt}
                  </p>
                </div>
              </div>
            </div>

            <button
              onClick={() => openNewsArticle ? openNewsArticle(featuredNews.id) : setCurrentPage('news')}
              className="inline-block px-6 py-3 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-md hover:opacity-90 transition-opacity self-start mt-4"
            >
              READ MORE
            </button>
          </div>

          {/* COLUMN 2: ABOUT LARA */}
          <div className="flex flex-col justify-between space-y-4 pr-0 lg:pr-6 lg:border-r border-[#EAE1D5] dark:border-[#2A2826]">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[#1C1B1A] dark:text-[#FAF8F5] mb-4">
                ABOUT LARA
              </h2>

              <div className="space-y-4">
                <div className="overflow-hidden rounded-xl aspect-[16/10] bg-stone-200 dark:bg-stone-800">
                  <img
                    src={ABOUT_PORTRAIT_BW}
                    alt="About Lara Ashley"
                    className="w-full h-full object-cover grayscale filter hover:grayscale-0 transition-all duration-500"
                  />
                </div>

                <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] leading-relaxed">
                  Lara Ashley is an international model known for her work in fashion, beauty, and lifestyle. This is my official space to share my journey with you.
                </p>
              </div>
            </div>

            <button
              onClick={() => { setCurrentPage('about'); window.scrollTo(0,0); }}
              className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-[0.2em] text-[#1C1B1A] dark:text-[#FAF8F5] hover:text-[#C5A059] transition-colors self-start mt-4"
            >
              <span>MORE ABOUT ME</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* COLUMN 3: LATEST PHOTOS */}
          <div className="flex flex-col justify-between space-y-4">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-[0.2em] text-[#1C1B1A] dark:text-[#FAF8F5] mb-4">
                LATEST PHOTOS
              </h2>

              <div className="grid grid-cols-3 gap-2.5">
                {latestPhotos.map((photo) => (
                  <div
                    key={photo.id}
                    onClick={() => onSelectPhoto(photo)}
                    className="group relative aspect-square overflow-hidden rounded-lg cursor-pointer bg-stone-200 dark:bg-stone-800 shadow-sm"
                  >
                    <img
                      src={photo.imageUrl}
                      alt={photo.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-1 text-center">
                      <span className="text-[10px] uppercase font-bold text-white tracking-widest">View</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => { setCurrentPage('photos'); window.scrollTo(0,0); }}
              className="inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-[0.2em] text-[#1C1B1A] dark:text-[#FAF8F5] hover:text-[#C5A059] transition-colors self-start mt-4"
            >
              <span>VIEW ALL PHOTOS</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>


      {/* FAN CLUB BOTTOM BANNER (MATCHING REFERENCE UI) */}
      <section className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#EAE1D5]/60 dark:bg-[#1E1C1B] rounded-2xl p-6 sm:p-8 border border-[#D8D2C9] dark:border-[#2A2826] flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-full border border-[#1C1B1A] dark:border-[#FAF8F5] flex items-center justify-center text-[#1C1B1A] dark:text-[#FAF8F5] shrink-0">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xs font-bold uppercase tracking-[0.2em] text-[#1C1B1A] dark:text-[#FAF8F5]">
                JOIN THE FAN CLUB
              </h3>
              <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] mt-0.5">
                Get exclusive updates, behind the scenes, early access, and more — only for my fans.
              </p>
            </div>
          </div>

          <form onSubmit={handleSubscribe} className="w-full md:w-auto flex flex-col sm:flex-row gap-2.5">
            <input
              type="email"
              required
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              placeholder="Enter your email"
              className="px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-md focus:outline-none focus:border-[#1C1B1A] dark:focus:border-[#FAF8F5] w-full sm:w-72"
            />
            <button
              type="submit"
              className="px-6 py-3 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-md hover:opacity-90 transition-opacity whitespace-nowrap"
            >
              {subscribed ? 'SIGNED UP!' : 'SIGN UP'}
            </button>
          </form>

        </div>

        {subscribed && (
          <div className="mt-3 text-center text-xs text-emerald-600 dark:text-emerald-400 font-medium flex items-center justify-center space-x-1">
            <CheckCircle className="w-4 h-4" />
            <span>Welcome to The Atelier Club! Check your inbox for exclusive access.</span>
          </div>
        )}
      </section>

    </div>
  );
};
