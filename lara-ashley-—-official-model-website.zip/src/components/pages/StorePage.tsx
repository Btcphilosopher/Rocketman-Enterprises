import React, { useState } from 'react';
import { MerchandiseItem } from '../../types';
import { PRODUCTS_DATA } from '../../data/mockData';
import { ShoppingBag, BookOpen, Check, Sparkles, Filter, X } from 'lucide-react';

interface StorePageProps {
  addToCart: (product: MerchandiseItem) => void;
}

export const StorePage: React.FC<StorePageProps> = ({ addToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedProductDetail, setSelectedProductDetail] = useState<MerchandiseItem | null>(null);

  const categories = ['All', 'Books', 'Prints', 'Stationery', 'Apparel', 'Gift Cards'];

  const filteredProducts = selectedCategory === 'All'
    ? PRODUCTS_DATA
    : PRODUCTS_DATA.filter((p) => p.category === selectedCategory);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          LUXURY MERCHANDISE
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          The Atelier Store
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          Monographs, signed archival prints, natural linen journals, postcard collector boxes, and silk accessories.
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex items-center justify-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider font-medium transition-all ${
              selectedCategory === cat
                ? 'bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A]'
                : 'bg-[#F5F0EB] text-[#4A4643] dark:bg-[#1E1C1B] dark:text-[#A8A29E] hover:bg-[#EAE1D5]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map((product) => (
          <div
            key={product.id}
            className="group bg-[#FAF8F5] dark:bg-[#1C1B1A] rounded-2xl overflow-hidden border border-[#EAE1D5] dark:border-[#2A2826] shadow-md hover:border-[#C5A059] transition-all flex flex-col justify-between"
          >
            <div
              className="space-y-4 cursor-pointer"
              onClick={() => setSelectedProductDetail(product)}
            >
              <div className="relative aspect-[4/3] overflow-hidden bg-stone-200 dark:bg-stone-800">
                <img
                  src={product.images[0]}
                  alt={product.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {product.isLimited && (
                  <span className="absolute top-3 left-3 bg-[#1C1B1A] text-[#FAF8F5] text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-full border border-[#C5A059]">
                    Limited Edition
                  </span>
                )}
                {product.isSigned && (
                  <span className="absolute top-3 right-3 bg-[#C5A059] text-black text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 rounded-full">
                    Hand Signed
                  </span>
                )}
              </div>

              <div className="p-6 pt-0 space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#C5A059]">
                  {product.category}
                </span>
                <h3 className="font-serif text-2xl font-light leading-snug group-hover:text-[#C5A059] transition-colors">
                  {product.title}
                </h3>
                <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-light line-clamp-2 leading-relaxed">
                  {product.description}
                </p>
              </div>
            </div>

            <div className="p-6 pt-0 flex items-center justify-between border-t border-[#EAE1D5] dark:border-[#2A2826] mt-4 pt-4">
              <span className="font-serif text-2xl font-light text-[#1C1B1A] dark:text-[#FAF8F5]">
                €{product.price}
              </span>

              <button
                onClick={() => addToCart(product)}
                className="px-5 py-2.5 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-[#C5A059] dark:hover:bg-[#C5A059] dark:hover:text-black transition-colors flex items-center space-x-2"
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Add to Bag</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Product Detail Modal */}
      {selectedProductDetail && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] dark:bg-[#121111] text-[#1C1B1A] dark:text-[#FAF8F5] max-w-3xl w-full rounded-3xl p-6 sm:p-10 border border-[#EAE1D5] dark:border-[#2A2826] shadow-2xl relative space-y-6">
            
            <button
              onClick={() => setSelectedProductDetail(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <div className="aspect-[4/3] rounded-2xl overflow-hidden bg-stone-200 dark:bg-stone-800">
                <img
                  src={selectedProductDetail.images[0]}
                  alt={selectedProductDetail.title}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="space-y-4">
                <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                  {selectedProductDetail.category}
                </span>

                <h2 className="font-serif text-3xl font-light">
                  {selectedProductDetail.title}
                </h2>

                <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-light leading-relaxed">
                  {selectedProductDetail.description}
                </p>

                <div className="space-y-2 pt-2 border-t border-[#EAE1D5] dark:border-[#2A2826] text-xs">
                  {selectedProductDetail.details.map((dt, i) => (
                    <div key={i} className="flex items-center space-x-2 text-[#8C827A]">
                      <Check className="w-3.5 h-3.5 text-[#C5A059]" />
                      <span>{dt}</span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[#EAE1D5] dark:border-[#2A2826]">
                  <span className="font-serif text-3xl font-light">€{selectedProductDetail.price}</span>

                  <button
                    onClick={() => {
                      addToCart(selectedProductDetail);
                      setSelectedProductDetail(null);
                    }}
                    className="px-6 py-3 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-[#C5A059] transition-colors"
                  >
                    ADD TO SHOPPING BAG
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
