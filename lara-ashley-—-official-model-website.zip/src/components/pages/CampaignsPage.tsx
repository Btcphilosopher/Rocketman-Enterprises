import React, { useState } from 'react';
import { CampaignItem } from '../../types';
import { CAMPAIGNS_DATA } from '../../data/mockData';
import { Play, Sparkles, UserCheck, Camera, Layers, ChevronRight } from 'lucide-react';

export const CampaignsPage: React.FC = () => {
  const [selectedCampaign, setSelectedCampaign] = useState<CampaignItem>(CAMPAIGNS_DATA[0]);
  const [playingVideo, setPlayingVideo] = useState(false);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          GLOBAL ADVERTISING
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          Campaign Showcase
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          High-fashion luxury house campaigns featuring creative direction, artistic story, photography teams, and behind-the-scenes video highlights.
        </p>
      </div>

      {/* Featured Active Campaign Spotlight */}
      <div className="bg-[#1C1B1A] text-[#FAF8F5] rounded-3xl overflow-hidden shadow-2xl border border-[#33302D] grid grid-cols-1 lg:grid-cols-12 gap-0">
        
        {/* Cover Photo / Video Hero */}
        <div className="lg:col-span-7 relative min-h-[420px] lg:min-h-[560px] bg-stone-900">
          {playingVideo && selectedCampaign.videoUrl ? (
            <video
              src={selectedCampaign.videoUrl}
              autoPlay
              controls
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="relative w-full h-full">
              <img
                src={selectedCampaign.coverImage}
                alt={selectedCampaign.title}
                className="w-full h-full object-cover opacity-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#1C1B1A] via-transparent to-transparent opacity-80" />
              
              {selectedCampaign.videoUrl && (
                <button
                  onClick={() => setPlayingVideo(true)}
                  className="absolute inset-0 m-auto w-20 h-20 bg-white/20 hover:bg-[#C5A059] backdrop-blur-md rounded-full border border-white/40 flex items-center justify-center text-white transition-all transform hover:scale-110 shadow-2xl"
                  title="Play Campaign Short Film"
                >
                  <Play className="w-8 h-8 fill-current ml-1" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Campaign Editorial Details */}
        <div className="lg:col-span-5 p-8 sm:p-12 flex flex-col justify-between space-y-8">
          <div className="space-y-6">
            <div className="flex items-center space-x-3 text-xs uppercase tracking-[0.2em] text-[#C5A059]">
              <Sparkles className="w-4 h-4" />
              <span>{selectedCampaign.brand} • {selectedCampaign.season}</span>
            </div>

            <h2 className="font-serif text-3xl sm:text-4xl font-light leading-tight">
              {selectedCampaign.title}
            </h2>

            <p className="text-xs text-white/80 font-light leading-relaxed">
              {selectedCampaign.story}
            </p>

            <div className="space-y-3 pt-4 border-t border-white/10 text-xs">
              <div className="flex items-center space-x-3 text-white/90">
                <UserCheck className="w-4 h-4 text-[#C5A059]" />
                <span>Creative Director: <strong className="text-white">{selectedCampaign.creativeDirector}</strong></span>
              </div>
              <div className="flex items-center space-x-3 text-white/90">
                <Camera className="w-4 h-4 text-[#C5A059]" />
                <span>Photographer: <strong className="text-white">{selectedCampaign.photographer}</strong></span>
              </div>
              <div className="flex items-center space-x-3 text-white/90">
                <Layers className="w-4 h-4 text-[#C5A059]" />
                <span>Publication: <strong className="text-white">{selectedCampaign.publication}</strong></span>
              </div>
            </div>
          </div>

          {/* Campaign Gallery Thumbnails */}
          <div>
            <span className="text-[10px] uppercase font-bold text-[#C5A059] tracking-widest block mb-2">Campaign Stills</span>
            <div className="flex space-x-3">
              {selectedCampaign.galleryImages.map((img, i) => (
                <img
                  key={i}
                  src={img}
                  alt="Campaign detail"
                  className="w-16 h-20 object-cover rounded-lg border border-white/20 hover:border-[#C5A059] transition-all cursor-pointer"
                />
              ))}
            </div>
          </div>
        </div>

      </div>

      {/* Other Campaigns Selection Grid */}
      <div className="space-y-6">
        <h2 className="font-serif text-3xl font-light text-center">Campaign Archive</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {CAMPAIGNS_DATA.map((camp) => (
            <div
              key={camp.id}
              onClick={() => {
                setSelectedCampaign(camp);
                setPlayingVideo(false);
                window.scrollTo({ top: 300, behavior: 'smooth' });
              }}
              className={`group p-6 rounded-2xl border transition-all cursor-pointer space-y-4 ${
                selectedCampaign.id === camp.id
                  ? 'bg-[#F5F0EB] dark:bg-[#1E1C1B] border-[#C5A059] shadow-xl'
                  : 'bg-[#FAF8F5] dark:bg-[#121111] border-[#EAE1D5] dark:border-[#2A2826] hover:border-[#C5A059]'
              }`}
            >
              <div className="aspect-[16/10] overflow-hidden rounded-xl bg-stone-200 dark:bg-stone-800">
                <img
                  src={camp.coverImage}
                  alt={camp.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#C5A059]">
                  {camp.brand}
                </span>
                <h3 className="font-serif text-xl font-light leading-snug group-hover:text-[#C5A059] transition-colors">
                  {camp.title}
                </h3>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
