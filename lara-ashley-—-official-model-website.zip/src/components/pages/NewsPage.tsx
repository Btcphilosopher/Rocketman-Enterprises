import React, { useState } from 'react';
import { NewsArticle } from '../../types';
import { NEWS_DATA } from '../../data/mockData';
import { BookOpen, Clock, Calendar, X, ArrowRight } from 'lucide-react';

interface NewsPageProps {
  initialArticleId?: string | null;
}

export const NewsPage: React.FC<NewsPageProps> = ({ initialArticleId }) => {
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(
    initialArticleId ? NEWS_DATA.find((a) => a.id === initialArticleId) || null : null
  );

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          JOURNAL & PRESS
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          News & Features
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          Magazine features, fashion week diaries, campaign announcements, press coverage, and personal reflections by Lara Ashley.
        </p>
      </div>

      {/* Featured News Hero */}
      <div className="bg-[#F5F0EB] dark:bg-[#181716] rounded-3xl p-8 lg:p-12 border border-[#EAE1D5] dark:border-[#2A2826] grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-6 space-y-6">
          <div className="flex items-center space-x-3 text-xs uppercase tracking-widest text-[#C5A059] font-bold">
            <span>FEATURED STORY</span>
            <span>•</span>
            <span>{NEWS_DATA[0].publication}</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl font-light leading-snug">
            {NEWS_DATA[0].title}
          </h2>

          <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-light leading-relaxed">
            {NEWS_DATA[0].excerpt}
          </p>

          <div className="flex items-center space-x-4 text-xs text-[#8C827A] font-medium pt-2">
            <span className="flex items-center space-x-1">
              <Calendar className="w-3.5 h-3.5" />
              <span>{NEWS_DATA[0].date}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Clock className="w-3.5 h-3.5" />
              <span>{NEWS_DATA[0].readTime}</span>
            </span>
          </div>

          <button
            onClick={() => setSelectedArticle(NEWS_DATA[0])}
            className="px-6 py-3 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-md hover:opacity-90 transition-opacity"
          >
            READ FULL ARTICLE
          </button>
        </div>

        <div className="lg:col-span-6 aspect-[4/3] rounded-2xl overflow-hidden bg-stone-200 dark:bg-stone-800 shadow-xl">
          <img
            src={NEWS_DATA[0].coverImage}
            alt={NEWS_DATA[0].title}
            className="w-full h-full object-cover"
          />
        </div>
      </div>

      {/* News Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {NEWS_DATA.map((article) => (
          <div
            key={article.id}
            onClick={() => setSelectedArticle(article)}
            className="group bg-[#FAF8F5] dark:bg-[#1C1B1A] rounded-2xl p-6 border border-[#EAE1D5] dark:border-[#2A2826] shadow-md hover:border-[#C5A059] transition-all cursor-pointer space-y-4 flex flex-col justify-between"
          >
            <div className="space-y-4">
              <div className="aspect-[16/10] overflow-hidden rounded-xl bg-stone-200 dark:bg-stone-800">
                <img
                  src={article.coverImage}
                  alt={article.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-[11px] text-[#8C827A] font-medium uppercase tracking-wider">
                  <span>{article.category}</span>
                  <span>{article.date}</span>
                </div>

                <h3 className="font-serif text-2xl font-light leading-snug group-hover:text-[#C5A059] transition-colors">
                  {article.title}
                </h3>

                <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-light leading-relaxed line-clamp-3">
                  {article.excerpt}
                </p>
              </div>
            </div>

            <div className="pt-4 border-t border-[#EAE1D5] dark:border-[#2A2826] flex items-center justify-between text-xs text-[#C5A059] font-bold uppercase tracking-wider">
              <span>Read Story</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* Full Article Modal Reader */}
      {selectedArticle && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
          <div className="bg-[#FAF8F5] dark:bg-[#121111] text-[#1C1B1A] dark:text-[#FAF8F5] max-w-3xl w-full max-h-[90vh] overflow-y-auto rounded-3xl p-6 sm:p-10 border border-[#EAE1D5] dark:border-[#2A2826] shadow-2xl relative space-y-6">
            
            <button
              onClick={() => setSelectedArticle(null)}
              className="absolute top-6 right-6 p-2 rounded-full bg-black/10 dark:bg-white/10 hover:bg-black/20 dark:hover:bg-white/20 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-3">
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                {selectedArticle.category} • {selectedArticle.publication}
              </span>
              <h1 className="font-serif text-3xl sm:text-4xl font-light leading-tight">
                {selectedArticle.title}
              </h1>
              <p className="text-xs text-[#8C827A] dark:text-[#A8A29E]">
                Published on {selectedArticle.date} • {selectedArticle.readTime}
              </p>
            </div>

            <div className="aspect-[16/9] rounded-2xl overflow-hidden bg-stone-200 dark:bg-stone-800">
              <img
                src={selectedArticle.coverImage}
                alt={selectedArticle.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="space-y-4 font-serif text-base leading-relaxed text-[#1C1B1A] dark:text-[#FAF8F5]">
              {selectedArticle.content.map((paragraph, i) => (
                <p key={i}>{paragraph}</p>
              ))}
            </div>

            <div className="pt-6 border-t border-[#EAE1D5] dark:border-[#2A2826] flex justify-end">
              <button
                onClick={() => setSelectedArticle(null)}
                className="px-6 py-2.5 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-widest rounded-lg"
              >
                Close Article
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
