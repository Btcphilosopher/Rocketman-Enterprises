import React, { useState } from 'react';
import { PhotoItem, PortfolioCategory } from '../../types';
import { PHOTOS_DATA } from '../../data/mockData';
import { Eye, LayoutGrid, Grid3x3, SlidersHorizontal } from 'lucide-react';

interface PortfolioPageProps {
  onSelectPhoto: (photo: PhotoItem) => void;
}

export const PortfolioPage: React.FC<PortfolioPageProps> = ({ onSelectPhoto }) => {
  const [selectedCategory, setSelectedCategory] = useState<PortfolioCategory>('All');
  const [gridColumns, setGridColumns] = useState<2 | 3 | 4>(3);

  const categories: PortfolioCategory[] = [
    'All',
    'Editorial',
    'Fashion',
    'Beauty',
    'Luxury',
    'Commercial',
    'Runway',
    'Lifestyle',
    'Campaigns',
    'BTS'
  ];

  const filteredPhotos = selectedCategory === 'All'
    ? PHOTOS_DATA
    : PHOTOS_DATA.filter((p) => p.category === selectedCategory);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title Header */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          SELECTED WORKS
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          Editorial Portfolio
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          High-fashion portraiture, haute couture runway moments, luxury house campaigns, and backstage stories shot by leading international photographers.
        </p>
      </div>

      {/* Categories Bar & View Switcher */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 border-y border-[#EAE1D5] dark:border-[#2A2826] py-4">
        
        {/* Category Pills */}
        <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider font-medium whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] shadow-md'
                  : 'bg-[#F5F0EB] text-[#4A4643] dark:bg-[#1E1C1B] dark:text-[#A8A29E] hover:bg-[#EAE1D5]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid Density Controls */}
        <div className="hidden sm:flex items-center space-x-2 text-xs text-[#8C827A] dark:text-[#A8A29E]">
          <span className="uppercase tracking-widest font-medium mr-2">Columns:</span>
          <button
            onClick={() => setGridColumns(2)}
            className={`p-2 rounded hover:bg-[#EAE1D5] dark:hover:bg-[#2A2826] transition-colors ${
              gridColumns === 2 ? 'text-[#1C1B1A] dark:text-[#FAF8F5] font-bold' : ''
            }`}
          >
            <LayoutGrid className="w-4 h-4" />
          </button>
          <button
            onClick={() => setGridColumns(3)}
            className={`p-2 rounded hover:bg-[#EAE1D5] dark:hover:bg-[#2A2826] transition-colors ${
              gridColumns === 3 ? 'text-[#1C1B1A] dark:text-[#FAF8F5] font-bold' : ''
            }`}
          >
            <Grid3x3 className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* Portfolio Grid */}
      <div
        className={`grid gap-6 ${
          gridColumns === 2
            ? 'grid-cols-1 md:grid-cols-2'
            : gridColumns === 3
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3'
            : 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
        }`}
      >
        {filteredPhotos.map((photo) => (
          <div
            key={photo.id}
            onClick={() => onSelectPhoto(photo)}
            className="group relative overflow-hidden rounded-xl bg-stone-200 dark:bg-stone-800 shadow-lg cursor-pointer transform transition-all duration-300 hover:-translate-y-1"
          >
            <div className="aspect-[3/4] overflow-hidden">
              <img
                src={photo.imageUrl}
                alt={photo.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
              />
            </div>

            {/* Hover Editorial Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6 text-[#FAF8F5]">
              <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-[#C5A059]">
                {photo.category} {photo.publication ? `• ${photo.publication}` : ''}
              </span>
              <h3 className="font-serif text-2xl font-light text-white leading-tight">
                {photo.title}
              </h3>
              <p className="text-xs text-white/70 pt-1">
                Photographer: {photo.photographer}
              </p>

              <div className="pt-3 flex items-center space-x-2 text-[11px] font-semibold text-white uppercase tracking-widest">
                <Eye className="w-3.5 h-3.5 text-[#C5A059]" />
                <span>Open Fullscreen</span>
              </div>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
