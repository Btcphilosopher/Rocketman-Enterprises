import React, { useState } from 'react';
import { EVENTS_DATA } from '../../data/mockData';
import { CalendarEvent } from '../../types';
import { Calendar as CalendarIcon, MapPin, Ticket, CheckCircle2, UserPlus } from 'lucide-react';

export const CalendarPage: React.FC = () => {
  const [rsvpEvents, setRsvpEvents] = useState<Record<string, boolean>>({});
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const handleRsvp = (eventId: string) => {
    setRsvpEvents((prev) => ({
      ...prev,
      [eventId]: !prev[eventId]
    }));
  };

  const categories = ['All', 'Fashion Week', 'Brand Event', 'Photoshoot', 'Meet & Greet', 'Charity Gala'];

  const filteredEvents = activeCategory === 'All'
    ? EVENTS_DATA
    : EVENTS_DATA.filter((e) => e.category === activeCategory);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          SCHEDULE & APPEARANCES
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          Official Calendar
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          Upcoming Paris, Milan, and New York Fashion Weeks, luxury campaign launches, charity galas, and fan club meet-and-greets.
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex items-center justify-center space-x-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-4 py-2 rounded-full text-xs uppercase tracking-wider font-medium transition-all ${
              activeCategory === cat
                ? 'bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A]'
                : 'bg-[#F5F0EB] text-[#4A4643] dark:bg-[#1E1C1B] dark:text-[#A8A29E] hover:bg-[#EAE1D5]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Events List */}
      <div className="space-y-4">
        {filteredEvents.map((event) => {
          const isRsvped = rsvpEvents[event.id];

          return (
            <div
              key={event.id}
              className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 sm:p-8 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-6 hover:border-[#C5A059] transition-all"
            >
              <div className="flex items-start space-x-6">
                
                {/* Date Badge */}
                <div className="w-20 h-20 bg-[#F5F0EB] dark:bg-[#1E1C1B] rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] flex flex-col items-center justify-center shrink-0 text-center">
                  <span className="font-serif text-2xl font-light text-[#C5A059]">
                    {event.date.split(' ')[1]}
                  </span>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-[#1C1B1A] dark:text-[#FAF8F5]">
                    {event.date.split(' ')[0]}
                  </span>
                </div>

                {/* Event Details */}
                <div className="space-y-1.5">
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] uppercase font-bold text-[#C5A059] border border-[#C5A059]/40 px-2.5 py-0.5 rounded-full">
                      {event.category}
                    </span>
                    <span className="text-xs text-[#8C827A] flex items-center space-x-1">
                      <MapPin className="w-3.5 h-3.5" />
                      <span>{event.location}</span>
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-light leading-snug">
                    {event.title}
                  </h3>

                  <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-light max-w-xl">
                    {event.description}
                  </p>
                </div>
              </div>

              {/* RSVP & Tickets */}
              <div className="w-full md:w-auto flex flex-col sm:flex-row items-center gap-3 shrink-0 pt-4 md:pt-0 border-t md:border-t-0 border-[#EAE1D5] dark:border-[#2A2826]">
                <button
                  onClick={() => handleRsvp(event.id)}
                  className={`w-full sm:w-auto px-5 py-3 rounded-xl text-xs uppercase font-bold tracking-wider flex items-center justify-center space-x-2 border transition-all ${
                    isRsvped
                      ? 'bg-emerald-600 text-white border-emerald-600'
                      : 'bg-transparent border-[#1C1B1A] dark:border-[#FAF8F5] text-[#1C1B1A] dark:text-[#FAF8F5] hover:bg-[#1C1B1A] hover:text-[#FAF8F5] dark:hover:bg-[#FAF8F5] dark:hover:text-[#1C1B1A]'
                  }`}
                >
                  {isRsvped ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>RSVP Confirmed</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-4 h-4" />
                      <span>Request Attendance</span>
                    </>
                  )}
                </button>

                {event.ticketsAvailable && (
                  <button
                    onClick={() => alert(`Tickets / Access Pass for ${event.title} generated!`)}
                    className="w-full sm:w-auto px-5 py-3 bg-[#C5A059] text-[#1C1B1A] text-xs font-bold uppercase tracking-wider rounded-xl hover:bg-[#b08d48] transition-colors flex items-center justify-center space-x-2 shadow-md"
                  >
                    <Ticket className="w-4 h-4" />
                    <span>Get Pass</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
