import React, { useState } from 'react';
import { AGENCY_LIST } from '../../data/mockData';
import { Globe, Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    email: '',
    phone: '',
    enquiryType: 'Campaign',
    dates: '',
    budget: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        name: '',
        company: '',
        email: '',
        phone: '',
        enquiryType: 'Campaign',
        dates: '',
        budget: '',
        message: ''
      });
    }, 5000);
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          PROFESSIONAL REPRESENTATION
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          Bookings & Enquiries
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          For global high-fashion campaigns, editorial shoots, runway shows, brand ambassadorships, and official press enquiries.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* Left Representation Network */}
        <div className="lg:col-span-5 space-y-6">
          <h2 className="font-serif text-3xl font-light">Global Management</h2>
          <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light">
            Please contact Lara Ashley's direct regional representation below for immediate schedule availability and rate cards.
          </p>

          <div className="space-y-4">
            {AGENCY_LIST.map((ag, i) => (
              <div key={i} className="p-5 bg-[#FAF8F5] dark:bg-[#1C1B1A] rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-2">
                <span className="text-[10px] uppercase font-bold tracking-widest text-[#C5A059]">{ag.region}</span>
                <h3 className="font-serif text-xl font-light">{ag.agency}</h3>
                <p className="text-xs text-[#8C827A]">Senior Agent: {ag.contactName}</p>
                <div className="pt-2 text-xs text-[#4A4643] dark:text-[#A8A29E] space-y-1">
                  <p className="flex items-center space-x-2">
                    <Mail className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>{ag.email}</span>
                  </p>
                  <p className="flex items-center space-x-2">
                    <Phone className="w-3.5 h-3.5 text-[#C5A059]" />
                    <span>{ag.phone}</span>
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Form */}
        <div className="lg:col-span-7 bg-[#F5F0EB] dark:bg-[#181716] p-8 sm:p-10 rounded-3xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-6 shadow-xl">
          <div className="space-y-1">
            <h2 className="font-serif text-3xl font-light">Direct Commercial Inquiry</h2>
            <p className="text-xs text-[#8C827A] font-light">
              Submit your project scope directly to management.
            </p>
          </div>

          {submitted ? (
            <div className="p-8 bg-emerald-500/10 border border-emerald-500/30 rounded-2xl text-center space-y-3 animate-in fade-in">
              <CheckCircle className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="font-serif text-2xl font-light text-emerald-600 dark:text-emerald-400">
                Enquiry Transmitted
              </h3>
              <p className="text-xs text-[#8C827A]">
                Thank you. Elite Model Management & IMG NYC will review your booking details and respond within 24 hours.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Genevieve Dupont"
                    className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Company / Brand</label>
                  <input
                    type="text"
                    required
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    placeholder="e.g. Vogue France / Saint Laurent"
                    className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="name@company.com"
                    className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Enquiry Type</label>
                  <select
                    value={formData.enquiryType}
                    onChange={(e) => setFormData({ ...formData, enquiryType: e.target.value })}
                    className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                  >
                    <option value="Campaign">Global Advertising Campaign</option>
                    <option value="Editorial">Magazine Cover / Editorial</option>
                    <option value="Runway">Fashion Week Runway</option>
                    <option value="Commercial">Commercial & Beauty</option>
                    <option value="Press/Interview">Press / Keynote Appearance</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Proposed Dates & Location</label>
                  <input
                    type="text"
                    value={formData.dates}
                    onChange={(e) => setFormData({ ...formData, dates: e.target.value })}
                    placeholder="e.g. Sept 12-15 in Paris"
                    className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Estimated Budget Range</label>
                  <input
                    type="text"
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    placeholder="e.g. €50,000+"
                    className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold uppercase tracking-wider text-[#8C827A] block mb-1">Project Message & Creative Scope</label>
                <textarea
                  rows={4}
                  required
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Provide project outline, creative director, photographer, and distribution rights..."
                  className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-xl hover:opacity-90 transition-opacity flex items-center justify-center space-x-2 shadow-xl"
              >
                <Send className="w-4 h-4 text-[#C5A059]" />
                <span>SUBMIT OFFICIAL ENQUIRY</span>
              </button>
            </form>
          )}

        </div>

      </div>

    </div>
  );
};
