import React, { useState } from 'react';
import { PhotoItem } from '../../types';
import { PHOTOS_DATA } from '../../data/mockData';
import { Search, Filter, Sparkles, Moon } from 'lucide-react';

interface PhotosPageProps {
  onSelectPhoto: (photo: PhotoItem) => void;
}

export const PhotosPage: React.FC<PhotosPageProps> = ({ onSelectPhoto }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [onlyBlackAndWhite, setOnlyBlackAndWhite] = useState(false);
  const [selectedSeason, setSelectedSeason] = useState<string>('All');

  const seasons = ['All', 'Spring/Summer', 'Autumn/Winter', 'Resort', 'Haute Couture'];

  const filteredPhotos = PHOTOS_DATA.filter((photo) => {
    const matchesSearch =
      photo.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      photo.photographer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (photo.publication && photo.publication.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesBW = onlyBlackAndWhite ? photo.isBlackAndWhite === true : true;
    const matchesSeason = selectedSeason === 'All' ? true : photo.season === selectedSeason;

    return matchesSearch && matchesBW && matchesSeason;
  });

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-10 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          MUSEUM-QUALITY GALLERY
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          Photo Gallery Engine
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          High-definition photography collections. Filter by seasonal portfolios, monochrome portraiture, or search by photographer and publication.
        </p>
      </div>

      {/* Filter Controls */}
      <div className="bg-[#F5F0EB] dark:bg-[#181716] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Search Field */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-[#8C827A]" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search photographer, Vogue, Paris..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
            />
          </div>

          {/* Seasonal Filters & Monochrome Toggle */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            
            <div className="flex items-center space-x-1 bg-[#FAF8F5] dark:bg-[#121111] p-1 rounded-xl border border-[#D8D2C9] dark:border-[#383533]">
              {seasons.map((season) => (
                <button
                  key={season}
                  onClick={() => setSelectedSeason(season)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium tracking-wider uppercase transition-colors ${
                    selectedSeason === season
                      ? 'bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A]'
                      : 'text-[#8C827A] hover:text-[#1C1B1A] dark:hover:text-[#FAF8F5]'
                  }`}
                >
                  {season}
                </button>
              ))}
            </div>

            <button
              onClick={() => setOnlyBlackAndWhite(!onlyBlackAndWhite)}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs uppercase tracking-wider font-medium border transition-colors ${
                onlyBlackAndWhite
                  ? 'bg-[#1C1B1A] text-[#FAF8F5] border-[#1C1B1A] dark:bg-[#FAF8F5] dark:text-[#1C1B1A]'
                  : 'bg-[#FAF8F5] dark:bg-[#121111] text-[#4A4643] dark:text-[#A8A29E] border-[#D8D2C9] dark:border-[#383533]'
              }`}
            >
              <Moon className="w-3.5 h-3.5" />
              <span>Monochrome Only</span>
            </button>

          </div>

        </div>
      </div>

      {/* Masonry / Grid Gallery */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredPhotos.map((photo) => (
          <div
            key={photo.id}
            onClick={() => onSelectPhoto(photo)}
            className="group relative overflow-hidden rounded-xl bg-stone-200 dark:bg-stone-800 shadow-md cursor-pointer"
          >
            <div className="aspect-[3/4] overflow-hidden">
              <img
                src={photo.imageUrl}
                alt={photo.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>

            <div className="p-4 bg-[#FAF8F5] dark:bg-[#1C1B1A] border-t border-[#EAE1D5] dark:border-[#2A2826] flex items-center justify-between">
              <div>
                <h3 className="font-serif text-lg font-light leading-snug group-hover:text-[#C5A059] transition-colors">
                  {photo.title}
                </h3>
                <p className="text-[11px] text-[#8C827A] dark:text-[#A8A29E]">
                  {photo.photographer} {photo.publication ? `• ${photo.publication}` : ''}
                </p>
              </div>
              <span className="text-[10px] uppercase font-bold text-[#C5A059] border border-[#C5A059]/40 px-2 py-0.5 rounded">
                {photo.year}
              </span>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
