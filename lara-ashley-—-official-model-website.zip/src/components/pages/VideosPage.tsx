import React, { useState } from 'react';
import { VideoItem } from '../../types';
import { VIDEOS_DATA } from '../../data/mockData';
import { Play, Film, Clock, X } from 'lucide-react';

export const VideosPage: React.FC = () => {
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto space-y-3">
        <p className="text-xs uppercase tracking-[0.3em] text-[#C5A059] font-medium">
          CINEMATIC EXPERIENCE
        </p>
        <h1 className="font-serif text-5xl sm:text-6xl font-light tracking-wide">
          Video & Runway Film
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          Short editorial films, fashion week catwalk highlights, backstage footage, and press appearances.
        </p>
      </div>

      {/* Videos Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
        {VIDEOS_DATA.map((video) => (
          <div
            key={video.id}
            onClick={() => setActiveVideo(video)}
            className="group bg-[#FAF8F5] dark:bg-[#1C1B1A] rounded-2xl overflow-hidden border border-[#EAE1D5] dark:border-[#2A2826] shadow-lg hover:border-[#C5A059] transition-all cursor-pointer space-y-4"
          >
            {/* Thumbnail with Play Overlay */}
            <div className="relative aspect-[16/9] overflow-hidden bg-stone-900">
              <img
                src={video.thumbnailUrl}
                alt={video.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90"
              />
              <div className="absolute inset-0 bg-black/30 group-hover:bg-black/50 transition-colors flex items-center justify-center">
                <div className="w-16 h-16 bg-white/20 group-hover:bg-[#C5A059] backdrop-blur-md rounded-full border border-white/40 flex items-center justify-center text-white transition-all transform group-hover:scale-110 shadow-2xl">
                  <Play className="w-7 h-7 fill-current ml-1" />
                </div>
              </div>

              <div className="absolute bottom-3 right-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded text-[11px] text-white flex items-center space-x-1">
                <Clock className="w-3 h-3 text-[#C5A059]" />
                <span>{video.duration}</span>
              </div>

              <div className="absolute top-3 left-3 bg-[#1C1B1A]/80 backdrop-blur-md px-3 py-1 rounded-full text-[10px] uppercase tracking-widest text-[#C5A059] font-bold border border-[#C5A059]/40">
                {video.category}
              </div>
            </div>

            {/* Video Meta */}
            <div className="p-6 pt-0 space-y-2">
              <span className="text-[11px] text-[#8C827A] dark:text-[#A8A29E] font-medium uppercase tracking-wider">
                {video.date}
              </span>
              <h3 className="font-serif text-2xl font-light leading-snug group-hover:text-[#C5A059] transition-colors">
                {video.title}
              </h3>
              <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-light leading-relaxed">
                {video.description}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Video Overlay Player Modal */}
      {activeVideo && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-2xl flex items-center justify-center p-4 sm:p-8 animate-in fade-in duration-200">
          <div className="relative max-w-5xl w-full bg-[#1C1B1A] rounded-2xl overflow-hidden border border-white/20 shadow-2xl space-y-4">
            
            <div className="flex items-center justify-between p-4 border-b border-white/10 text-white">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-[#C5A059]">
                  {activeVideo.category} • {activeVideo.date}
                </span>
                <h2 className="font-serif text-xl font-light">{activeVideo.title}</h2>
              </div>

              <button
                onClick={() => setActiveVideo(null)}
                className="p-2 hover:bg-white/10 rounded-full transition-colors text-white"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="aspect-[16/9] w-full bg-black">
              <video
                src={activeVideo.videoUrl}
                autoPlay
                controls
                className="w-full h-full object-cover"
              />
            </div>

            <div className="p-6 pt-0 text-xs text-white/80 font-light">
              <p>{activeVideo.description}</p>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
