import React, { useState } from 'react';
import { WALLPAPERS_DATA } from '../../data/mockData';
import { Crown, Download, Lock, Check, Sparkles, Mail, ShieldAlert } from 'lucide-react';

export const FanClubPage: React.FC = () => {
  const [isMember, setIsMember] = useState(false);
  const [memberEmail, setMemberEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleJoinAtelier = (e: React.FormEvent) => {
    e.preventDefault();
    if (memberEmail && password) {
      setIsMember(true);
    }
  };

  const clubPerks = [
    { title: 'Exclusive Photography', desc: 'Unreleased high-definition studio session photos & film stills before publication.' },
    { title: 'Private Monthly Letters', desc: 'Personal reflections, book recommendations, and travel diaries written directly by Lara.' },
    { title: 'Behind The Scenes Access', desc: 'Raw unedited video logs from backstage at Paris and Milan Fashion Weeks.' },
    { title: 'Digital Wallpapers', desc: '4K ultra-high-definition desktop and mobile wallpapers released seasonally.' },
    { title: 'Private Event Invitations', desc: 'Early access and reserved guest passes for book signings, pop-ups, and meet-and-greets.' }
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center space-x-2 px-4 py-1.5 rounded-full bg-[#C5A059]/10 border border-[#C5A059]/40 text-[#C5A059] text-xs font-bold uppercase tracking-[0.2em]">
          <Crown className="w-4 h-4" />
          <span>EXCLUSIVE FAN CLUB</span>
        </div>
        <h1 className="font-serif text-5xl sm:text-6xl lg:text-7xl font-light tracking-wide">
          The Atelier Club
        </h1>
        <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light max-w-lg mx-auto">
          An intimate private sanctuary for fans, collectors, and fashion aficionados. Enjoy unreleased editorial photography, private letters, and exclusive merchandise.
        </p>
      </div>

      {/* Member Portal Content OR Signup Portal */}
      {isMember ? (
        <div className="space-y-12 animate-in fade-in duration-300">
          
          {/* Welcome Banner */}
          <div className="bg-[#1C1B1A] text-[#FAF8F5] rounded-3xl p-8 sm:p-12 border border-[#C5A059] shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2">
              <span className="text-xs font-bold uppercase tracking-widest text-[#C5A059]">
                ATELIER MEMBER ACCESS ACTIVE
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-light">
                Welcome to the Atelier, {memberEmail.split('@')[0]}
              </h2>
              <p className="text-xs text-white/70 font-light">
                Thank you for your ongoing inspiration and support.
              </p>
            </div>

            <button
              onClick={() => setIsMember(false)}
              className="px-6 py-2.5 border border-white/30 hover:bg-white/10 text-xs font-bold uppercase tracking-widest rounded-xl transition-colors shrink-0"
            >
              Sign Out
            </button>
          </div>

          {/* Member Exclusive Digital Wallpapers */}
          <div className="space-y-6">
            <div className="flex items-center space-x-3 text-[#C5A059]">
              <Sparkles className="w-5 h-5" />
              <h2 className="font-serif text-3xl font-light">4K Digital Wallpapers (Spring 2026 Release)</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {WALLPAPERS_DATA.map((wall) => (
                <div key={wall.id} className="bg-[#FAF8F5] dark:bg-[#1C1B1A] rounded-2xl p-4 border border-[#EAE1D5] dark:border-[#2A2826] space-y-4 shadow-lg">
                  <div className="aspect-[16/10] overflow-hidden rounded-xl bg-stone-900">
                    <img src={wall.imageUrl} alt={wall.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-serif text-lg font-light">{wall.title}</h3>
                      <p className="text-[11px] text-[#8C827A]">{wall.resolution}</p>
                    </div>
                    <a
                      href={wall.downloadUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="p-3 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] rounded-xl hover:bg-[#C5A059] transition-colors"
                      title="Download 4K"
                    >
                      <Download className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Private Letter From Lara */}
          <div className="bg-[#F5F0EB] dark:bg-[#181716] p-8 sm:p-12 rounded-3xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-4 max-w-3xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-widest text-[#C5A059]">
              PRIVATE MONTHLY LETTER • MAY 2026
            </span>
            <h3 className="font-serif text-3xl font-light">"On Quiet Luxury and Paris Mornings"</h3>
            <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-serif leading-relaxed text-sm">
              Dearest Atelier Members,
            </p>
            <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] font-serif leading-relaxed text-sm">
              As I write this from my studio in Saint-Germain, Paris is awakening in soft golden light. Over the past month walking for Saint Laurent and Chanel, I was reminded how true fashion isn't about chaos—it's about finding harmony in simple, beautifully made things...
            </p>
            <p className="text-xs font-serif italic text-[#C5A059] pt-2">
              With warmth and gratitude,<br />Lara Ashley
            </p>
          </div>

        </div>
      ) : (
        /* Sign In / Join Form */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Perks List */}
          <div className="lg:col-span-7 space-y-6">
            <h2 className="font-serif text-3xl sm:text-4xl font-light">
              Atelier Club Member Privileges
            </h2>

            <div className="space-y-4">
              {clubPerks.map((perk, i) => (
                <div key={i} className="flex items-start space-x-4 p-4 rounded-xl bg-[#FAF8F5] dark:bg-[#1C1B1A] border border-[#EAE1D5] dark:border-[#2A2826]">
                  <div className="w-8 h-8 rounded-full bg-[#C5A059]/20 flex items-center justify-center text-[#C5A059] shrink-0 mt-0.5">
                    <Check className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-serif text-lg font-light text-[#1C1B1A] dark:text-[#FAF8F5]">{perk.title}</h3>
                    <p className="text-xs text-[#8C827A] dark:text-[#A8A29E] font-light leading-relaxed">{perk.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right Membership Form */}
          <div className="lg:col-span-5 bg-[#FAF8F5] dark:bg-[#1C1B1A] p-8 rounded-3xl border border-[#EAE1D5] dark:border-[#2A2826] shadow-2xl space-y-6">
            <div className="text-center space-y-2">
              <Lock className="w-8 h-8 text-[#C5A059] mx-auto" />
              <h3 className="font-serif text-2xl font-light">Join The Atelier Club</h3>
              <p className="text-xs text-[#8C827A] font-light">Instant access to wallpapers, letters & private BTS</p>
            </div>

            <form onSubmit={handleJoinAtelier} className="space-y-4">
              <div>
                <label className="text-xs uppercase font-bold tracking-wider text-[#8C827A] block mb-1.5">
                  Email Address
                </label>
                <input
                  type="email"
                  required
                  value={memberEmail}
                  onChange={(e) => setMemberEmail(e.target.value)}
                  placeholder="your.email@example.com"
                  className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <div>
                <label className="text-xs uppercase font-bold tracking-wider text-[#8C827A] block mb-1.5">
                  Passcode / Password
                </label>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-4 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-xl hover:opacity-90 transition-opacity shadow-lg"
              >
                ACCESS ATELIER PORTAL
              </button>
            </form>
          </div>

        </div>
      )}

    </div>
  );
};
