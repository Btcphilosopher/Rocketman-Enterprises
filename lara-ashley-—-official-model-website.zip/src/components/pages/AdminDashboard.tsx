import React, { useState } from 'react';
import {
  PHOTOS_DATA,
  CAMPAIGNS_DATA,
  NEWS_DATA,
  EVENTS_DATA,
  MOCK_BOOKING_ENQUIRIES
} from '../../data/mockData';
import { PhotoItem, BookingEnquiry } from '../../types';
import {
  ShieldCheck,
  TrendingUp,
  Image as ImageIcon,
  FileText,
  Calendar,
  Users,
  DollarSign,
  Plus,
  CheckCircle2,
  XCircle,
  Eye,
  Lock
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'analytics' | 'photos' | 'news' | 'enquiries'>('analytics');
  
  // State for enquiries moderation
  const [enquiries, setEnquiries] = useState<BookingEnquiry[]>(MOCK_BOOKING_ENQUIRIES);

  // New photo form state
  const [newPhotoTitle, setNewPhotoTitle] = useState('');
  const [newPhotoCategory, setNewPhotoCategory] = useState<any>('Editorial');
  const [newPhotoUrl, setNewPhotoUrl] = useState('');
  const [newPhotoPhotographer, setNewPhotoPhotographer] = useState('');
  const [photoAdded, setPhotoAdded] = useState(false);

  const handleApproveEnquiry = (id: string) => {
    setEnquiries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, status: 'Accepted' } : e))
    );
  };

  const handleDeclineEnquiry = (id: string) => {
    setEnquiries((prev) =>
      prev.map((e) => (e.id === id ? { ...e, status: 'Declined' } : e))
    );
  };

  const handleAddPhoto = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPhotoTitle && newPhotoUrl) {
      const created: PhotoItem = {
        id: `photo-${Date.now()}`,
        title: newPhotoTitle,
        category: newPhotoCategory,
        year: 2026,
        imageUrl: newPhotoUrl,
        photographer: newPhotoPhotographer || 'Unknown',
        featured: true
      };
      PHOTOS_DATA.unshift(created);
      setPhotoAdded(true);
      setNewPhotoTitle('');
      setNewPhotoUrl('');
      setNewPhotoPhotographer('');
      setTimeout(() => setPhotoAdded(false), 4000);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12 text-[#1C1B1A] dark:text-[#FAF8F5]">
      
      {/* Header */}
      <div className="bg-[#1C1B1A] text-[#FAF8F5] rounded-3xl p-8 sm:p-10 border border-[#C5A059] shadow-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-[#C5A059] text-xs uppercase font-bold tracking-widest">
            <ShieldCheck className="w-4 h-4" />
            <span>EXECUTIVE MANAGEMENT CMS</span>
          </div>
          <h1 className="font-serif text-4xl sm:text-5xl font-light">
            Lara Ashley — Control Portal
          </h1>
          <p className="text-xs text-white/70 font-light">
            Manage portfolio galleries, campaigns, fashion week events, press releases, and commercial booking enquiries.
          </p>
        </div>

        <div className="px-4 py-2 bg-white/10 rounded-xl border border-white/20 text-xs font-mono text-[#C5A059]">
          System Status: Online (Connected)
        </div>
      </div>

      {/* Analytics Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-2 shadow-md">
          <div className="flex items-center justify-between text-[#C5A059]">
            <ImageIcon className="w-5 h-5" />
            <span className="text-[10px] font-bold uppercase tracking-wider bg-[#C5A059]/10 px-2 py-0.5 rounded">Live</span>
          </div>
          <p className="text-xs text-[#8C827A] font-medium uppercase tracking-wider">High-Res Photos</p>
          <h3 className="font-serif text-3xl font-light">{PHOTOS_DATA.length} Items</h3>
        </div>

        <div className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-2 shadow-md">
          <div className="flex items-center justify-between text-[#C5A059]">
            <Users className="w-5 h-5" />
            <span className="text-[10px] font-bold uppercase tracking-wider bg-[#C5A059]/10 px-2 py-0.5 rounded">+18% MoM</span>
          </div>
          <p className="text-xs text-[#8C827A] font-medium uppercase tracking-wider">Atelier Subscribers</p>
          <h3 className="font-serif text-3xl font-light">12,480 Members</h3>
        </div>

        <div className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-2 shadow-md">
          <div className="flex items-center justify-between text-[#C5A059]">
            <FileText className="w-5 h-5" />
            <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-500 px-2 py-0.5 rounded">2 Action</span>
          </div>
          <p className="text-xs text-[#8C827A] font-medium uppercase tracking-wider">Pending Enquiries</p>
          <h3 className="font-serif text-3xl font-light">{enquiries.length} Requests</h3>
        </div>

        <div className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-2 shadow-md">
          <div className="flex items-center justify-between text-[#C5A059]">
            <DollarSign className="w-5 h-5" />
            <span className="text-[10px] font-bold uppercase tracking-wider bg-[#C5A059]/10 px-2 py-0.5 rounded">This Month</span>
          </div>
          <p className="text-xs text-[#8C827A] font-medium uppercase tracking-wider">Store Gross Volume</p>
          <h3 className="font-serif text-3xl font-light">€28,450</h3>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#EAE1D5] dark:border-[#2A2826] space-x-8 text-xs uppercase tracking-widest font-bold">
        <button
          onClick={() => setActiveTab('analytics')}
          className={`pb-3 relative transition-colors ${
            activeTab === 'analytics'
              ? 'text-[#1C1B1A] dark:text-[#FAF8F5]'
              : 'text-[#8C827A] hover:text-[#1C1B1A] dark:hover:text-[#FAF8F5]'
          }`}
        >
          Overview & Traffic
          {activeTab === 'analytics' && <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C5A059]" />}
        </button>

        <button
          onClick={() => setActiveTab('photos')}
          className={`pb-3 relative transition-colors ${
            activeTab === 'photos'
              ? 'text-[#1C1B1A] dark:text-[#FAF8F5]'
              : 'text-[#8C827A] hover:text-[#1C1B1A] dark:hover:text-[#FAF8F5]'
          }`}
        >
          Gallery Uploader
          {activeTab === 'photos' && <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C5A059]" />}
        </button>

        <button
          onClick={() => setActiveTab('enquiries')}
          className={`pb-3 relative transition-colors ${
            activeTab === 'enquiries'
              ? 'text-[#1C1B1A] dark:text-[#FAF8F5]'
              : 'text-[#8C827A] hover:text-[#1C1B1A] dark:hover:text-[#FAF8F5]'
          }`}
        >
          Booking Enquiries ({enquiries.filter(e => e.status === 'Pending').length})
          {activeTab === 'enquiries' && <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#C5A059]" />}
        </button>
      </div>

      {/* Tab Panels */}
      {activeTab === 'analytics' && (
        <div className="bg-[#F5F0EB] dark:bg-[#181716] p-8 rounded-3xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-6">
          <h2 className="font-serif text-3xl font-light">Global Traffic & Campaign Performance</h2>
          <p className="text-xs text-[#8C827A] font-light">
            Top visiting regions: France (32%), United States (28%), United Kingdom (15%), Japan (12%), Italy (8%).
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-4">
              <h3 className="font-serif text-xl font-light">Active Campaign Reach</h3>
              <div className="space-y-3 text-xs">
                <div>
                  <div className="flex justify-between text-[#8C827A] mb-1">
                    <span>Saint Laurent SS26 Campaign</span>
                    <span>1.4M Impressions</span>
                  </div>
                  <div className="w-full h-2 bg-stone-200 dark:bg-stone-800 rounded-full overflow-hidden">
                    <div className="h-full bg-[#C5A059] w-[88%]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-[#8C827A] mb-1">
                    <span>Chanel Haute Couture Paris</span>
                    <span>920K Impressions</span>
                  </div>
                  <div className="w-full h-2 bg-stone-200 dark:bg-stone-800 rounded-full overflow-hidden">
                    <div className="h-full bg-[#C5A059] w-[65%]" />
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-4">
              <h3 className="font-serif text-xl font-light">Store Merchandise Inventory</h3>
              <ul className="text-xs space-y-2 text-[#8C827A]">
                <li className="flex justify-between">
                  <span>'Presence' Hardcover Monograph</span>
                  <strong className="text-emerald-500">42 Copies Left</strong>
                </li>
                <li className="flex justify-between">
                  <span>Deauville Fine Art Print</span>
                  <strong className="text-amber-500">12 Copies Left (Low Stock)</strong>
                </li>
                <li className="flex justify-between">
                  <span>French Linen Journal</span>
                  <strong className="text-[#1C1B1A] dark:text-[#FAF8F5]">150 Units</strong>
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'photos' && (
        <div className="bg-[#F5F0EB] dark:bg-[#181716] p-8 sm:p-10 rounded-3xl border border-[#EAE1D5] dark:border-[#2A2826] space-y-6">
          <h2 className="font-serif text-3xl font-light">Publish New Portfolio Photo</h2>

          {photoAdded && (
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-600 dark:text-emerald-400 text-xs font-bold uppercase rounded-xl flex items-center space-x-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>Photo Published Successfully to Official Gallery!</span>
            </div>
          )}

          <form onSubmit={handleAddPhoto} className="space-y-4 max-w-2xl">
            <div>
              <label className="text-xs font-bold uppercase text-[#8C827A] block mb-1">Photo Title</label>
              <input
                type="text"
                required
                value={newPhotoTitle}
                onChange={(e) => setNewPhotoTitle(e.target.value)}
                placeholder="e.g. Sculptural Silk in Versailles"
                className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold uppercase text-[#8C827A] block mb-1">Category</label>
                <select
                  value={newPhotoCategory}
                  onChange={(e) => setNewPhotoCategory(e.target.value)}
                  className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                >
                  <option value="Editorial">Editorial</option>
                  <option value="Fashion">Fashion</option>
                  <option value="Beauty">Beauty</option>
                  <option value="Luxury">Luxury</option>
                  <option value="Runway">Runway</option>
                  <option value="BTS">Behind The Scenes</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold uppercase text-[#8C827A] block mb-1">Photographer</label>
                <input
                  type="text"
                  value={newPhotoPhotographer}
                  onChange={(e) => setNewPhotoPhotographer(e.target.value)}
                  placeholder="e.g. Mario Testino"
                  className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold uppercase text-[#8C827A] block mb-1">High-Res Image URL</label>
              <input
                type="url"
                required
                value={newPhotoUrl}
                onChange={(e) => setNewPhotoUrl(e.target.value)}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-4 py-3 bg-[#FAF8F5] dark:bg-[#121111] border border-[#D8D2C9] dark:border-[#383533] text-xs text-[#1C1B1A] dark:text-[#FAF8F5] rounded-xl focus:outline-none focus:border-[#C5A059]"
              />
            </div>

            <button
              type="submit"
              className="px-8 py-3.5 bg-[#1C1B1A] text-[#FAF8F5] dark:bg-[#FAF8F5] dark:text-[#1C1B1A] text-xs font-bold uppercase tracking-[0.2em] rounded-xl hover:opacity-90 transition-opacity flex items-center space-x-2"
            >
              <Plus className="w-4 h-4 text-[#C5A059]" />
              <span>Publish Photo</span>
            </button>
          </form>
        </div>
      )}

      {activeTab === 'enquiries' && (
        <div className="space-y-6">
          <h2 className="font-serif text-3xl font-light">Commercial Booking Enquiries</h2>

          <div className="space-y-4">
            {enquiries.map((enq) => (
              <div
                key={enq.id}
                className="bg-[#FAF8F5] dark:bg-[#1C1B1A] p-6 rounded-2xl border border-[#EAE1D5] dark:border-[#2A2826] shadow-md flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
              >
                <div className="space-y-2">
                  <div className="flex items-center space-x-3">
                    <span className="text-[10px] uppercase font-bold tracking-widest text-[#C5A059] border border-[#C5A059]/40 px-2 py-0.5 rounded">
                      {enq.enquiryType}
                    </span>
                    <span className="text-xs text-[#8C827A]">{enq.dateSubmitted}</span>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        enq.status === 'Accepted'
                          ? 'bg-emerald-500/20 text-emerald-600'
                          : enq.status === 'Declined'
                          ? 'bg-red-500/20 text-red-600'
                          : 'bg-amber-500/20 text-amber-600'
                      }`}
                    >
                      {enq.status}
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-light">
                    {enq.name} • <strong className="font-normal">{enq.company}</strong>
                  </h3>

                  <p className="text-xs text-[#4A4643] dark:text-[#A8A29E] max-w-2xl font-light leading-relaxed">
                    "{enq.message}"
                  </p>

                  <p className="text-xs text-[#8C827A]">
                    Dates: <strong>{enq.dates}</strong> | Budget: <strong>{enq.budget}</strong> | Email: <strong>{enq.email}</strong>
                  </p>
                </div>

                {enq.status === 'Pending' && (
                  <div className="flex items-center space-x-3 shrink-0">
                    <button
                      onClick={() => handleApproveEnquiry(enq.id)}
                      className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold uppercase rounded-xl hover:bg-emerald-700 transition-colors flex items-center space-x-1"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Accept</span>
                    </button>
                    <button
                      onClick={() => handleDeclineEnquiry(enq.id)}
                      className="px-4 py-2 bg-stone-200 dark:bg-stone-800 text-[#1C1B1A] dark:text-[#FAF8F5] text-xs font-bold uppercase rounded-xl hover:bg-red-600 hover:text-white transition-colors flex items-center space-x-1"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>Decline</span>
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
