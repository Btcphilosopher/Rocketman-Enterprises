import {
  PhotoItem,
  CampaignItem,
  VideoItem,
  NewsArticle,
  CalendarEvent,
  MerchandiseItem,
  AgencyInfo,
  DigitalWallpaper,
  BookingEnquiry
} from '../types';

export const HERO_IMAGE = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=2000&q=85";
export const ABOUT_PORTRAIT_BW = "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=85";
export const BEAUTY_PORTRAIT = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=1200&q=85";

export const AGENCY_LIST: AgencyInfo[] = [
  {
    region: "Paris (Mother Agency)",
    agency: "Elite Model Management",
    contactName: "Jean-Luc Moreau",
    email: "lara.ashley@eliteparis.fr",
    phone: "+33 1 40 44 32 00",
    location: "53 Avenue Montaigne, 75008 Paris, France"
  },
  {
    region: "New York",
    agency: "IMG Models NYC",
    contactName: "Claire Sterling",
    email: "c.sterling@imgmodels.com",
    phone: "+1 212 253 8888",
    location: "304 Hudson Street, 6th Floor, New York, NY 10013"
  },
  {
    region: "London",
    agency: "Storm Model Management",
    contactName: "Alistair Vance",
    email: "a.vance@stormmodels.com",
    phone: "+44 20 7376 7700",
    location: "53 Redcliffe Gardens, London SW10 9JH, UK"
  },
  {
    region: "Milan",
    agency: "Women Management Milan",
    contactName: "Beatrice Rossi",
    email: "b.rossi@womenmilan.it",
    phone: "+39 02 8909 3600",
    location: "Via San Gregorio, 29, 20124 Milano, Italy"
  },
  {
    region: "Tokyo",
    agency: "Donna Models Tokyo",
    contactName: "Kenji Sato",
    email: "k.sato@donnamodels.jp",
    phone: "+81 3 5414 1155",
    location: "Minami-Aoyama, Minato-ku, Tokyo 107-0062"
  }
];

export const PHOTOS_DATA: PhotoItem[] = [
  {
    id: "photo-1",
    title: "Minimalist Soft Sunlight",
    category: "Beauty",
    year: 2026,
    imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1400&q=85",
    photographer: "Mario Testino",
    publication: "Vogue Paris",
    location: "Nice, France",
    season: "Spring/Summer",
    featured: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-2",
    title: "Monochrome Contemplation",
    category: "Editorial",
    year: 2026,
    imageUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1400&q=85",
    photographer: "Peter Lindbergh Estate",
    publication: "Harper's Bazaar",
    location: "Deauville Beach, France",
    isBlackAndWhite: true,
    season: "Autumn/Winter",
    featured: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-3",
    title: "Golden Hour Glow",
    category: "Beauty",
    year: 2025,
    imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=1400&q=85",
    photographer: "Cass Bird",
    publication: "Elle International",
    location: "Santorini, Greece",
    season: "Resort",
    featured: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-4",
    title: "Black Velvet Silhouette",
    category: "Fashion",
    year: 2025,
    imageUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1400&q=85",
    photographer: "Mert & Marcus",
    publication: "Vogue Italia",
    location: "Studio 4, Milan",
    season: "Autumn/Winter",
    featured: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-5",
    title: "The Sculptural Gown",
    category: "Runway",
    year: 2026,
    imageUrl: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1400&q=85",
    photographer: "Inez & Vinoodh",
    publication: "Dior Haute Couture",
    location: "Grand Palais, Paris",
    season: "Haute Couture",
    featured: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-6",
    title: "Sunkissed Terracotta",
    category: "Lifestyle",
    year: 2025,
    imageUrl: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=1400&q=85",
    photographer: "Lachlan Bailey",
    publication: "Kinfolk Magazine",
    location: "Marrakech, Morocco",
    season: "Spring/Summer",
    featured: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-7",
    title: "Oversized Tailoring in Motion",
    category: "Luxury",
    year: 2026,
    imageUrl: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1400&q=85",
    photographer: "David Sims",
    publication: "The Row Campaign",
    location: "New York City",
    season: "Autumn/Winter",
    aspectRatio: "portrait"
  },
  {
    id: "photo-8",
    title: "Pure Atelier Noir",
    category: "BTS",
    year: 2026,
    imageUrl: "https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=1400&q=85",
    photographer: "Antoine Dubois",
    publication: "Chanel Behind The Scenes",
    location: "Rue Cambon, Paris",
    isBlackAndWhite: true,
    season: "Spring/Summer",
    aspectRatio: "portrait"
  },
  {
    id: "photo-9",
    title: "High Contrast Shadowplay",
    category: "Editorial",
    year: 2025,
    imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=1400&q=85",
    photographer: "Steven Meisel",
    publication: "W Magazine",
    location: "London Studio",
    isBlackAndWhite: true,
    aspectRatio: "portrait"
  },
  {
    id: "photo-10",
    title: "Nordic Winter Solstice",
    category: "Commercial",
    year: 2025,
    imageUrl: "https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=crop&w=1400&q=85",
    photographer: "Søren Hansen",
    publication: "COS Campaign",
    location: "Copenhagen",
    season: "Autumn/Winter",
    aspectRatio: "portrait"
  }
];

export const CAMPAIGNS_DATA: CampaignItem[] = [
  {
    id: "camp-1",
    title: "Saint Laurent SS26 — The Architecture of Noir",
    brand: "Saint Laurent Paris",
    year: 2026,
    season: "Spring/Summer 2026",
    creativeDirector: "Anthony Vaccarello",
    photographer: "David Sims",
    publication: "Global Campaign & Vogue Worldwide",
    coverImage: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1600&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1400&q=85",
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1400&q=85",
      "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1400&q=85"
    ],
    story: "Shot on location in the brutalist concrete structures of suburban Paris, this campaign explores razor-sharp tailoring, silk outerwear, and dramatic noir contrast. Lara Ashley embodies the modern Saint Laurent heroine—effortlessly confident, enigmatic, and powerful.",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-fashion-model-posing-in-a-black-outfit-39833-large.mp4",
    featured: true
  },
  {
    id: "camp-2",
    title: "Chanel Haute Couture — Whispers of Camellia",
    brand: "Chanel",
    year: 2026,
    season: "Haute Couture 2026",
    creativeDirector: "Virginie Viard",
    photographer: "Inez & Vinoodh",
    publication: "Chanel Magazine & Global Flagships",
    coverImage: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1600&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1400&q=85",
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=1400&q=85"
    ],
    story: "Set inside the historic salons of 31 Rue Cambon, Lara showcases delicate hand-embroidered lace, tweed outerwear, and pearl embellishments. A tribute to Coco Chanel's timeless elegance with a contemporary Scandinavian minimalism.",
    featured: true
  },
  {
    id: "camp-3",
    title: "The Row — Minimalist Serenity AW25",
    brand: "The Row",
    year: 2025,
    season: "Autumn/Winter 2025",
    creativeDirector: "Ashley & Mary-Kate Olsen",
    photographer: "Lachlan Bailey",
    publication: "Harper's Bazaar & The Row Dossier",
    coverImage: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1600&q=85",
    galleryImages: [
      "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1400&q=85",
      "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?auto=format&fit=crop&w=1400&q=85"
    ],
    story: "Focusing on immaculate cashmere, quiet luxury, and voluminous proportions, this campaign captures the essence of restrained elegance.",
    featured: false
  }
];

export const VIDEOS_DATA: VideoItem[] = [
  {
    id: "video-1",
    title: "Lara Ashley — The Paris Monologue",
    category: "Editorial Film",
    duration: "03:42",
    thumbnailUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-woman-posing-for-the-camera-in-a-studio-39832-large.mp4",
    date: "March 2026",
    description: "An intimate short film directed by Jean-Pierre Jeunet capturing Lara wandering through Montmartre at dawn ahead of Paris Fashion Week.",
    featured: true
  },
  {
    id: "video-2",
    title: "Saint Laurent Runway Opener — Palais de Chaillot",
    category: "Runway",
    duration: "05:15",
    thumbnailUrl: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1200&q=85",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-fashion-model-posing-in-a-black-outfit-39833-large.mp4",
    date: "February 2026",
    description: "Full runway coverage of Lara Ashley opening the Saint Laurent SS26 show under the illuminated Eiffel Tower.",
    featured: true
  },
  {
    id: "video-3",
    title: "Vogue 73 Questions with Lara Ashley",
    category: "Interviews",
    duration: "11:20",
    thumbnailUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=1200&q=85",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-woman-posing-for-the-camera-in-a-studio-39832-large.mp4",
    date: "January 2026",
    description: "Vogue visits Lara in her light-filled Paris apartment to talk morning rituals, favorite vintage books, travel essential skincare, and runway secrets.",
    featured: true
  },
  {
    id: "video-4",
    title: "Behind the Scenes — Dior Beauty Campaign",
    category: "Behind the Scenes",
    duration: "02:50",
    thumbnailUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=85",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-fashion-model-posing-in-a-black-outfit-39833-large.mp4",
    date: "December 2025",
    description: "Raw footage from the studio set in Chateau de Versailles during the filming of Dior Rouge.",
    featured: false
  }
];

export const NEWS_DATA: NewsArticle[] = [
  {
    id: "news-1",
    title: "New Campaign Out Now: Saint Laurent SS26 Architectural Series",
    date: "10 MAY 2026",
    publication: "Vogue Global & Saint Laurent",
    category: "Campaign Launch",
    excerpt: "I'm so excited to share my new campaign with you. Shot in Paris by David Sims, this collection celebrates clean structure, dramatic silhouettes, and quiet confidence.",
    content: [
      "I am thrilled to announce the global release of the Saint Laurent SS26 campaign shot by the legendary David Sims under the direction of Anthony Vaccarello.",
      "Working on this campaign was a dream realized. We spent three days in Paris exploring the juxtaposition of soft silk against raw concrete structures.",
      "Thank you to Anthony, David, the entire Elite team, and all of you for your continuous support. Hope you love this campaign as much as I do!"
    ],
    coverImage: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=85",
    readTime: "3 min read",
    author: "Lara Ashley",
    featured: true
  },
  {
    id: "news-2",
    title: "Cover Story: Lara Ashley on Redefining Modern Glamour",
    date: "28 APR 2026",
    publication: "Harper's Bazaar UK",
    category: "Magazine Feature",
    excerpt: "In an exclusive interview with Harper's Bazaar, Lara reflects on seven years in high fashion, her Scandinavian design philosophy, and navigating international runway seasons.",
    content: [
      "'Elegance isn't about being noticed; it's about being remembered.' - Lara Ashley.",
      "In this month's cover issue, writer Sarah Jenkins sits down with Lara in Copenhagen during a rare break between Milan and Paris fashion weeks.",
      "Lara discusses her passion for architectural design, art curation, and her upcoming coffee table book 'Presence'."
    ],
    coverImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85",
    readTime: "6 min read",
    author: "Sarah Jenkins",
    featured: true
  },
  {
    id: "news-3",
    title: "Paris Fashion Week Diary: From Backstage to the Grand Palais",
    date: "15 MAR 2026",
    publication: "Journal de Lara",
    category: "Travel Journal",
    excerpt: "A personal reflection on the high energy, early morning call times, and electric moments of the Autumn/Winter Paris shows.",
    content: [
      "Paris in March is magical—crisp air, golden morning light on the Seine, and the frantic heartbeat of fashion week.",
      "My day starts at 5:00 AM with green tea, facial massage, and reviewing show schedules. Walking for Chanel, Dior, and Saint Laurent in a single week requires stamina and focus.",
      "Here are my favorite personal snapshots from backstage."
    ],
    coverImage: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=85",
    readTime: "4 min read",
    author: "Lara Ashley",
    featured: false
  }
];

export const EVENTS_DATA: CalendarEvent[] = [
  {
    id: "event-1",
    title: "Paris Fashion Week — Women's SS27",
    date: "MAY 20",
    isoDate: "2026-05-20",
    location: "Paris, France",
    country: "France",
    category: "Fashion Week",
    description: "Runway walks for leading Haute Couture and Prêt-à-Porter luxury houses across Paris.",
    status: "Upcoming",
    ticketsAvailable: true,
    rsvpCount: 1420
  },
  {
    id: "event-2",
    title: "Milan Brand Event — Saint Laurent Flagship",
    date: "JUN 05",
    isoDate: "2026-06-05",
    location: "Milan, Italy",
    country: "Italy",
    category: "Brand Event",
    description: "Exclusive campaign launch party and private cocktail reception at Via Montenapeleone.",
    status: "Upcoming",
    ticketsAvailable: true,
    rsvpCount: 890
  },
  {
    id: "event-3",
    title: "New York Editorial Photoshoot & Cover Reveal",
    date: "JUN 18",
    isoDate: "2026-06-18",
    location: "New York, USA",
    country: "USA",
    category: "Photoshoot",
    description: "Vogue US September Issue cover shoot and studio presentation in Soho.",
    status: "Upcoming",
    ticketsAvailable: false,
    rsvpCount: 410
  },
  {
    id: "event-4",
    title: "Los Angeles Fan Club Meet & Greet",
    date: "JUN 30",
    isoDate: "2026-06-30",
    location: "Los Angeles, USA",
    country: "USA",
    category: "Meet & Greet",
    description: "Private book signing and intimate meet-and-greet for 'The Atelier Club' members at Beverly Hills Hotel.",
    status: "Upcoming",
    ticketsAvailable: true,
    rsvpCount: 2300
  },
  {
    id: "event-5",
    title: "Copenhagen Fashion & Design Summit",
    date: "JUL 14",
    isoDate: "2026-07-14",
    location: "Copenhagen, Denmark",
    country: "Denmark",
    category: "Charity Gala",
    description: "Keynote presentation on sustainable luxury and Scandinavian minimalism.",
    status: "Upcoming",
    ticketsAvailable: true,
    rsvpCount: 650
  }
];

export const PRODUCTS_DATA: MerchandiseItem[] = [
  {
    id: "prod-1",
    title: "LARA ASHLEY — 'Presence' Monograph (Hardcover)",
    category: "Books",
    price: 145,
    description: "A 320-page museum-quality linen-bound coffee table book featuring unseen portraiture, personal essays, and photography from seven years on international runways.",
    details: [
      "320 heavy silk paper pages",
      "Linen hardcover with debossed gold foil typography",
      "Foreword by Mario Testino",
      "Includes signed archival bookplate",
      "Printed in Verona, Italy"
    ],
    images: [
      "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=1000&q=85",
      "https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=1000&q=85"
    ],
    isLimited: true,
    isSigned: true,
    stock: 42
  },
  {
    id: "prod-2",
    title: "Limited Edition Fine Art Print — 'Deauville Monochrome'",
    category: "Prints",
    price: 280,
    description: "Archival giclée print on Hahnemühle Cotton Rag paper. Stamped, hand-numbered, and signed by Lara Ashley and Peter Lindbergh Estate.",
    details: [
      "Edition of 100 copies worldwide",
      "Image size: 50 x 70 cm (20 x 28 in)",
      "Certificate of Authenticity included",
      "Shipped in museum protective tube"
    ],
    images: [
      "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1000&q=85"
    ],
    isLimited: true,
    isSigned: true,
    stock: 12
  },
  {
    id: "prod-3",
    title: "The Atelier Journal — Raw Linen Notebook",
    category: "Stationery",
    price: 48,
    description: "Minimalist grid journal bound in natural French linen, crafted for sketches, thoughts, and travel reflections.",
    details: [
      "192 fountain-pen friendly 120gsm pages",
      "Ribbon bookmark & elastic closure",
      "Debossed monogram emblem"
    ],
    images: [
      "https://images.unsplash.com/photo-1516962215378-7fa2e137ae93?auto=format&fit=crop&w=1000&q=85"
    ],
    isLimited: false,
    stock: 150
  },
  {
    id: "prod-4",
    title: "Collector's Postcard Box Set — 24 Fashion Moments",
    category: "Stationery",
    price: 35,
    description: "A luxury tactile box containing 24 matte postcards showcasing iconic editorial magazine covers and backstage photography.",
    details: [
      "24 ultra-heavy cardstock prints",
      "Keepsake presentation box",
      "Suitable for framing or correspondence"
    ],
    images: [
      "https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=1000&q=85"
    ],
    isLimited: false,
    stock: 85
  },
  {
    id: "prod-5",
    title: "The Signature Silk Scarf — 'Champagne Dunes'",
    category: "Apparel",
    price: 190,
    description: "100% Organic Mulberry Silk twill scarf featuring hand-rolled edges and an abstract architectural print designed in Paris.",
    details: [
      "90 x 90 cm (35 x 35 in)",
      "100% Mulberry Silk Twill",
      "Hand-finished in Lyon, France",
      "Custom gift box packaging"
    ],
    images: [
      "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?auto=format&fit=crop&w=1000&q=85"
    ],
    isLimited: true,
    stock: 25
  },
  {
    id: "prod-6",
    title: "Atelier Official Gift Card",
    category: "Gift Cards",
    price: 100,
    description: "Digital gift voucher valid for all books, fine art prints, and limited merchandise in the Lara Ashley store.",
    details: [
      "Instant digital delivery with custom message",
      "No expiration date",
      "Redeemable online"
    ],
    images: [
      "https://images.unsplash.com/photo-1556742049-0a670f4a4591?auto=format&fit=crop&w=1000&q=85"
    ],
    isLimited: false,
    stock: 999
  }
];

export const WALLPAPERS_DATA: DigitalWallpaper[] = [
  {
    id: "wall-1",
    title: "Saint Laurent Noir Editorial",
    resolution: "4K Ultra HD (3840 x 2160)",
    imageUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=85",
    downloadUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=2400&q=95",
    season: "Spring 2026"
  },
  {
    id: "wall-2",
    title: "Golden Hour Sunlight Portrait",
    resolution: "4K Ultra HD (3840 x 2160)",
    imageUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=85",
    downloadUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=2400&q=95",
    season: "Summer 2026"
  },
  {
    id: "wall-3",
    title: "Minimalist Terracotta Glow",
    resolution: "4K Mobile & Desktop",
    imageUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=1200&q=85",
    downloadUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=2400&q=95",
    season: "Autumn 2025"
  }
];

export const MOCK_BOOKING_ENQUIRIES: BookingEnquiry[] = [
  {
    id: "enq-1",
    name: "Genevieve Dupont",
    company: "Vogue France",
    email: "g.dupont@vogue.fr",
    phone: "+33 1 70 38 00 00",
    enquiryType: "Editorial",
    dates: "September 12 - 15, 2026",
    budget: "€45,000",
    message: "Requesting Lara Ashley for the September issue cover story in Arles, France with photographer Mario Sorrenti.",
    dateSubmitted: "2026-08-01",
    status: "Pending"
  },
  {
    id: "enq-2",
    name: "Marcus Vance",
    company: "Balenciaga Paris",
    email: "m.vance@balenciaga.com",
    phone: "+33 1 47 20 21 11",
    enquiryType: "Runway",
    dates: "October 2, 2026",
    budget: "€60,000",
    message: "Inquiry for Lara to walk in Paris Fashion Week SS27 runway show as look opener.",
    dateSubmitted: "2026-07-28",
    status: "Reviewed"
  }
];
