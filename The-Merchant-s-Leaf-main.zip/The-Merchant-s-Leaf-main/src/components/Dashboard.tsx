/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  TrendingUp, ShoppingCart, Package, Users, Cpu, FileText, Settings, Key, Globe, Image, ShieldAlert,
  Database, Plus, Edit, RefreshCw, Trash, Copy, Check, Upload, ArrowRight, Download, Send, AlertTriangle, Eye, EyeOff
} from "lucide-react";
import { Product, Order, OrderStatus, SupportTicket, MediaItem, AuditLog, Coupon } from "../types";

interface DashboardProps {
  products: Product[];
  orders: Order[];
  tickets: SupportTicket[];
  media: MediaItem[];
  auditLogs: AuditLog[];
  onRefreshAllData: () => void;
  taxRatePercent: number;
  flatShippingCostUsd: number;
  bitcoinWalletAddress: string;
  usdtTrc20WalletAddress: string;
  blockConfirmationsRequired: number;
  legalAgeLimit: number;
}

export default function Dashboard({
  products,
  orders,
  tickets,
  media,
  auditLogs,
  onRefreshAllData,
  taxRatePercent,
  flatShippingCostUsd,
  bitcoinWalletAddress,
  usdtTrc20WalletAddress,
  blockConfirmationsRequired,
  legalAgeLimit
}: DashboardProps) {
  const [activeTab, setActiveTab] = useState("overview");

  // Local state for forms and dialogs
  const [analytics, setAnalytics] = useState<any>(null);
  const [isLoadingAnalytics, setIsLoadingAnalytics] = useState(false);

  // Edit / Add Product State
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: "", sku: "", brand: "", category: "Hand-Rolled Cigars", price: 0, salePrice: null,
    quantityAvailable: 10, shortDescription: "", fullDescription: "", status: "Draft", tags: []
  });
  const [tempTags, setTempTags] = useState("");

  // Bulk CSV state
  const [bulkCsv, setBulkCsv] = useState(`sku,name,brand,category,price,salePrice,quantityAvailable,shortDescription,fullDescription,tags\nTML-BULK-01,"Cuban Reserve Corona",Habanos Co,Hand-Rolled Cigars,55,null,30,"Oily vintage corona","Full description in markdown",Cuba|Reserve|Premium\nTML-BULK-02,"Blackberry Cavendish blend",The Merchant's Leaf,Pipe Tobaccos,22,18,120,"Sweet ribbon cut aromatic","Vacuum-packed tins",Aromatic|Cavendish|Aroma`);

  // Selected ticket for support responder
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketReply, setTicketReply] = useState("");

  // Settings State
  const [storeTax, setStoreTax] = useState(taxRatePercent);
  const [storeShipping, setStoreShipping] = useState(flatShippingCostUsd);
  const [storeAge, setStoreAge] = useState(legalAgeLimit);
  const [btcAddr, setBtcAddr] = useState(bitcoinWalletAddress);
  const [usdtAddr, setUsdtAddr] = useState(usdtTrc20WalletAddress);
  const [confThreshold, setConfThreshold] = useState(blockConfirmationsRequired);

  // SEO State
  const [metaTitle, setMetaTitle] = useState("The Merchant's Leaf | Premium Tobacco Merchant Portfolio");
  const [metaDesc, setMetaDesc] = useState("D2C self-hosted catalog supplying adult customers with single-origin hand-rolled cigars, vacuum-packed pipe blends, and plinth desktop brass humidors.");
  const [robotsTxt, setRobotsTxt] = useState("User-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /admin/\nSitemap: https://themerchantsleaf.com/sitemap.xml");

  // Media folders organizer
  const [activeMediaFolder, setActiveMediaFolder] = useState("All");

  // Fetch Analytics dynamically from backend
  const fetchAnalytics = async () => {
    setIsLoadingAnalytics(true);
    try {
      const res = await fetch("/api/analytics");
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoadingAnalytics(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, [products, orders]);

  // Handle Product Add / Update Submit
  const handleProductSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...productForm,
      tags: tempTags.split(",").map(t => t.trim()).filter(Boolean)
    };

    const isEdit = !!payload.id;
    const url = isEdit ? `/api/products/${payload.id}` : "/api/products";
    const method = isEdit ? "PUT" : "POST";

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        setIsEditingProduct(false);
        setProductForm({ name: "", sku: "", brand: "", category: "Hand-Rolled Cigars", price: 0, salePrice: null, quantityAvailable: 10, shortDescription: "", fullDescription: "", status: "Draft", tags: [] });
        setTempTags("");
        onRefreshAllData();
      } else {
        alert("Compliance failure: Could not record product metadata.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleEditProductClick = (prod: Product) => {
    setProductForm(prod);
    setTempTags(prod.tags.join(", "));
    setIsEditingProduct(true);
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm("Are you certain you wish to delist and delete this product from the database?")) return;
    try {
      const res = await fetch(`/api/products/${id}`, { method: "DELETE" });
      if (res.ok) {
        onRefreshAllData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDuplicateProduct = async (prod: Product) => {
    const duplicated = {
      ...prod,
      id: undefined, // let backend generate new id
      sku: `${prod.sku}-COPY`,
      name: `${prod.name} (Copy)`,
      status: "Draft" as const
    };
    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(duplicated)
      });
      if (res.ok) {
        onRefreshAllData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Bulk Import Submit
  const handleBulkImport = async () => {
    try {
      const res = await fetch("/api/products/bulk-import", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csv: bulkCsv })
      });
      if (res.ok) {
        alert("Bulk import processed successfully. Added new drafts to inventory.");
        onRefreshAllData();
      } else {
        alert("Invalid CSV template parameters.");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Change Order status workflow
  const handleUpdateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (res.ok) {
        onRefreshAllData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Reply to Customer Support Ticket
  const handleSendTicketReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !ticketReply.trim()) return;

    try {
      const res = await fetch(`/api/tickets/${selectedTicket.id}/message`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sender: "support", text: ticketReply })
      });
      if (res.ok) {
        const updated: SupportTicket = await res.json();
        setSelectedTicket(updated);
        setTicketReply("");
        onRefreshAllData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Save Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      legalAgeLimit: Number(storeAge),
      taxRatePercent: Number(storeTax),
      flatShippingCostUsd: Number(storeShipping),
      bitcoinWalletAddress: btcAddr,
      usdtTrc20WalletAddress: usdtAddr,
      blockConfirmationsRequired: Number(confThreshold)
    };

    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        alert("Sovereign store parameters successfully locked down.");
        onRefreshAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Media folder calculations
  const filteredMedia = media.filter(m => activeMediaFolder === "All" || m.folder === activeMediaFolder);

  const menuItems = [
    { id: "overview", label: "Business Analytics", icon: TrendingUp },
    { id: "orders", label: "Fulfillment Orders", icon: ShoppingCart },
    { id: "products", label: "Leaf Catalog", icon: Package },
    { id: "bulk", label: "CSV Bulk Actions", icon: Upload },
    { id: "tickets", label: "Support Tickets", icon: Users },
    { id: "media", label: "Media Library", icon: Image },
    { id: "settings", label: "System & SEO Settings", icon: Settings },
    { id: "audit", label: "Secure Audit Logs", icon: Cpu }
  ];

  return (
    <div id="seller-console-layout" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-sans text-[#121216]">
      {/* Title */}
      <div className="mb-10 flex flex-wrap justify-between items-end border-b border-[#ECEAE2] pb-6 gap-4">
        <div>
          <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">ENTERPRISE COMMAND CENTER</span>
          <h2 className="text-3xl font-bold tracking-tight uppercase">THE MERCHANT'S CONTROL PANEL</h2>
        </div>
        <div className="flex gap-3">
          <button
            onClick={() => {
              onRefreshAllData();
              fetchAnalytics();
            }}
            className="border border-[#ECEAE2] hover:border-black p-3 bg-white text-black font-mono text-[11px] uppercase tracking-wider flex items-center gap-1.5"
            title="Reload Server State"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Force Sync
          </button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        {/* Admin Left Navigation Menu */}
        <nav className="w-full lg:w-64 shrink-0 flex flex-col space-y-1.5 border-r border-[#ECEAE2]/40 pr-4">
          {menuItems.map(item => {
            const Icon = item.icon;
            const isSel = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsEditingProduct(false);
                }}
                className={`w-full text-left font-mono text-xs uppercase tracking-wider p-3 flex items-center gap-3 transition-colors ${
                  isSel ? "bg-[#121216] text-white font-bold" : "text-[#696758] hover:bg-[#EAE8DE]/40 hover:text-black"
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Console Working Canvas */}
        <main className="flex-grow min-w-0 bg-white border border-[#ECEAE2] p-8">
          {/* ======================= TAB: OVERVIEW ======================= */}
          {activeTab === "overview" && analytics && (
            <div className="space-y-10">
              <div className="border-b border-[#ECEAE2] pb-4 mb-6">
                <h3 className="text-lg font-bold uppercase tracking-tight">Business Metrics Ledger</h3>
              </div>

              {/* Grid cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 font-mono text-xs">
                <div className="border border-[#ECEAE2] p-5 bg-[#FAF9F5]">
                  <span className="text-[#787664] block uppercase mb-1">Gross Settled Revenue</span>
                  <span className="text-xl font-bold text-black">${analytics.totalRevenue.toFixed(2)}</span>
                </div>
                <div className="border border-[#ECEAE2] p-5 bg-[#FAF9F5]">
                  <span className="text-[#787664] block uppercase mb-1">Total Ordered Invoices</span>
                  <span className="text-xl font-bold text-black">{analytics.totalOrders}</span>
                </div>
                <div className="border border-[#ECEAE2] p-5 bg-[#FAF9F5]">
                  <span className="text-[#787664] block uppercase mb-1">Active Catalog Listings</span>
                  <span className="text-xl font-bold text-black">{analytics.activeProductsCount}</span>
                </div>
                <div className="border border-[#ECEAE2] p-5 bg-[#FAF9F5]">
                  <span className="text-[#787664] block uppercase mb-1">Awaiting On-Chain Pay</span>
                  <span className="text-xl font-bold text-amber-800 font-sans font-semibold">{analytics.pendingPaymentsCount}</span>
                </div>
              </div>

              {/* Graphical Trend Representation */}
              <div className="border border-[#ECEAE2] p-6 space-y-4">
                <div className="flex justify-between items-center">
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-[#787664]">Revenue Inbound Stream (USD)</h4>
                  <span className="font-mono text-[10px] uppercase text-[#A3A3A3]">5-Day Block Window</span>
                </div>
                {/* SVG Line Graph */}
                <div className="h-48 w-full border-b border-l border-[#ECEAE2] relative flex items-end pt-6">
                  {/* Grid Lines */}
                  <div className="absolute inset-0 flex flex-col justify-between pointer-events-none text-[8px] font-mono text-[#A3A3A3]/70">
                    <div className="border-b border-[#ECEAE2]/20 w-full pt-1">$1,200 —</div>
                    <div className="border-b border-[#ECEAE2]/20 w-full">$800 —</div>
                    <div className="border-b border-[#ECEAE2]/20 w-full">$400 —</div>
                    <div className="w-full"></div>
                  </div>

                  <svg className="w-full h-full absolute inset-0 pt-6" viewBox="0 0 500 100" preserveAspectRatio="none">
                    <path
                      d="M 50 80 L 150 50 L 250 85 L 350 40 L 450 15"
                      fill="none"
                      stroke="#121216"
                      strokeWidth="2.5"
                    />
                    <circle cx="50" cy="80" r="3.5" fill="#121216" />
                    <circle cx="150" cy="50" r="3.5" fill="#121216" />
                    <circle cx="250" cy="85" r="3.5" fill="#121216" />
                    <circle cx="350" cy="40" r="3.5" fill="#121216" />
                    <circle cx="450" cy="15" r="3.5" fill="#787664" />
                  </svg>

                  {/* Graph labels */}
                  <div className="absolute inset-x-0 bottom-[-22px] flex justify-between px-8 font-mono text-[9px] text-[#787664]">
                    <span>Jul 10</span>
                    <span>Jul 11</span>
                    <span>Jul 12</span>
                    <span>Jul 13</span>
                    <span>Jul 14 (Today)</span>
                  </div>
                </div>
              </div>

              {/* Best Sellers & Payment Split */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                <div className="border border-[#ECEAE2] p-6 space-y-4">
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-[#121216] border-b border-[#ECEAE2] pb-3">Best Performing Tobaccos</h4>
                  <div className="space-y-4">
                    {analytics.topSellingProducts.map((p: any, idx: number) => (
                      <div key={idx} className="flex justify-between items-center text-xs font-mono">
                        <div>
                          <span className="font-bold text-black uppercase block">{p.name}</span>
                          <span className="text-[#787664] text-[10px]">SKU: {p.sku} • {p.salesCount} unit orders</span>
                        </div>
                        <span className="font-bold text-black">${p.revenue.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="border border-[#ECEAE2] p-6 space-y-4">
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-[#121216] border-b border-[#ECEAE2] pb-3">Sovereign Payment Method splits</h4>
                  <div className="space-y-4 font-mono text-xs">
                    <div className="flex justify-between items-center">
                      <span className="text-[#696758] uppercase">Cryptocurrency Direct Node:</span>
                      <span className="font-bold text-black">{analytics.paymentSplit.crypto} settlements</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#696758] uppercase">Visa/Mastercard Simulated:</span>
                      <span className="font-bold text-black">{analytics.paymentSplit.creditCard} settlements</span>
                    </div>
                    <div className="w-full bg-[#ECEAE2] h-2.5">
                      <div
                        className="bg-[#121216] h-full"
                        style={{
                          width: `${
                            (analytics.paymentSplit.crypto / (analytics.paymentSplit.crypto + analytics.paymentSplit.creditCard || 1)) * 100
                          }%`
                        }}
                      ></div>
                    </div>
                    <div className="text-[10px] text-[#A3A3A3] text-right">
                      {((analytics.paymentSplit.crypto / (analytics.paymentSplit.crypto + analytics.paymentSplit.creditCard || 1)) * 100).toFixed(0)}% Sovereign Crypto Settlements
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ======================= TAB: ORDERS ======================= */}
          {activeTab === "orders" && (
            <div className="space-y-6">
              <div className="border-b border-[#ECEAE2] pb-4 mb-4 flex justify-between items-center">
                <h3 className="text-lg font-bold uppercase tracking-tight">Active Invoices Queue</h3>
                <span className="font-mono text-xs text-[#787664]">{orders.length} orders total</span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead>
                    <tr className="border-b border-[#ECEAE2] text-[#787664] bg-[#FAF9F5]">
                      <th className="p-3">Order ID</th>
                      <th className="p-3">Recipient Customer</th>
                      <th className="p-3">Invoiced Value</th>
                      <th className="p-3">Fulfillment Status</th>
                      <th className="p-3 text-right">Change Workflow State</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#FAF9F5]">
                    {orders.map(ord => (
                      <tr key={ord.id} className="hover:bg-[#FAF9F5]/40">
                        <td className="p-3 font-bold">{ord.id}</td>
                        <td className="p-3">
                          <span className="font-bold text-black uppercase block">{ord.customerName}</span>
                          <span className="text-[#787664] text-[10px]">{ord.customerEmail}</span>
                        </td>
                        <td className="p-3 font-bold">${ord.total.toFixed(2)}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-1 text-[10px] font-bold uppercase ${
                              ord.status === 'Payment Received' || ord.status === 'Delivered'
                                ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                                : ord.status === 'Awaiting Payment'
                                ? "bg-amber-50 text-amber-800 border border-amber-200 animate-pulse"
                                : "bg-gray-50 text-gray-800 border border-gray-200"
                            }`}
                          >
                            {ord.status}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <select
                            value={ord.status}
                            onChange={(e) => handleUpdateOrderStatus(ord.id, e.target.value as OrderStatus)}
                            className="bg-white border border-[#ECEAE2] p-1.5 text-[10px] uppercase font-mono tracking-wider text-black focus:outline-none cursor-pointer"
                          >
                            <option value="Awaiting Payment">Awaiting Payment</option>
                            <option value="Payment Received">Payment Received</option>
                            <option value="Processing">Processing</option>
                            <option value="Packed">Packed</option>
                            <option value="Shipped">Shipped</option>
                            <option value="Delivered">Delivered</option>
                            <option value="Cancelled">Cancelled</option>
                            <option value="Refunded">Refunded</option>
                            <option value="Archived">Archived</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ======================= TAB: PRODUCTS ======================= */}
          {activeTab === "products" && (
            <div className="space-y-6">
              <div className="border-b border-[#ECEAE2] pb-4 mb-4 flex justify-between items-center">
                <h3 className="text-lg font-bold uppercase tracking-tight">Active Tobacco Inventory</h3>
                {!isEditingProduct && (
                  <button
                    onClick={() => {
                      setProductForm({ name: "", sku: "", brand: "", category: "Hand-Rolled Cigars", price: 0, salePrice: null, quantityAvailable: 10, shortDescription: "", fullDescription: "", status: "Draft", tags: [] });
                      setTempTags("");
                      setIsEditingProduct(true);
                    }}
                    className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-wider px-4 py-2.5 flex items-center gap-1.5 font-bold"
                  >
                    <Plus className="w-3.5 h-3.5" /> Introduce Product
                  </button>
                )}
              </div>

              {isEditingProduct ? (
                /* Edit/Add Form */
                <form onSubmit={handleProductSubmit} className="space-y-6 border border-[#ECEAE2] p-6 bg-[#FAF9F5]">
                  <div className="flex justify-between items-center border-b border-[#ECEAE2] pb-3">
                    <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-[#121216]">
                      {productForm.id ? "Edit Cured Leaf Profile" : "Register New Product Stock"}
                    </h4>
                    <button
                      type="button"
                      onClick={() => setIsEditingProduct(false)}
                      className="font-mono text-xs uppercase text-[#787664] hover:text-black"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Product Catalog Name</label>
                      <input
                        type="text"
                        required
                        value={productForm.name || ""}
                        onChange={(e) => setProductForm(p => ({ ...p, name: e.target.value }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none uppercase font-mono tracking-wider"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Product SKU</label>
                      <input
                        type="text"
                        required
                        value={productForm.sku || ""}
                        onChange={(e) => setProductForm(p => ({ ...p, sku: e.target.value }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none uppercase font-mono tracking-wider"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">House Brand</label>
                      <input
                        type="text"
                        required
                        value={productForm.brand || ""}
                        onChange={(e) => setProductForm(p => ({ ...p, brand: e.target.value }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none uppercase font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Leaf Category</label>
                      <select
                        value={productForm.category || "Hand-Rolled Cigars"}
                        onChange={(e) => setProductForm(p => ({ ...p, category: e.target.value }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      >
                        <option value="Hand-Rolled Cigars">Hand-Rolled Cigars</option>
                        <option value="Pipe Tobaccos">Pipe Tobaccos</option>
                        <option value="Accessories">Accessories</option>
                        <option value="Gift Ideas">Gift Ideas</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Stock Available</label>
                      <input
                        type="number"
                        required
                        value={productForm.quantityAvailable ?? 10}
                        onChange={(e) => setProductForm(p => ({ ...p, quantityAvailable: Number(e.target.value) }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Price (USD)</label>
                      <input
                        type="number"
                        step="0.01"
                        required
                        value={productForm.price || 0}
                        onChange={(e) => setProductForm(p => ({ ...p, price: Number(e.target.value) }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Promo Sale Price (Optional)</label>
                      <input
                        type="number"
                        step="0.01"
                        placeholder="null"
                        value={productForm.salePrice ?? ""}
                        onChange={(e) => setProductForm(p => ({ ...p, salePrice: e.target.value ? Number(e.target.value) : null }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Search Tags (comma separated)</label>
                    <input
                      type="text"
                      placeholder="e.g. Bold, Nicaraguan, Maduro"
                      value={tempTags}
                      onChange={(e) => setTempTags(e.target.value)}
                      className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none uppercase font-mono tracking-wider"
                    />
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Grid Short Description</label>
                    <input
                      type="text"
                      required
                      value={productForm.shortDescription || ""}
                      onChange={(e) => setProductForm(p => ({ ...p, shortDescription: e.target.value }))}
                      className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-sans"
                    />
                  </div>

                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Full Specifications Narrative (supports Markdown)</label>
                    <textarea
                      rows={6}
                      required
                      value={productForm.fullDescription || ""}
                      onChange={(e) => setProductForm(p => ({ ...p, fullDescription: e.target.value }))}
                      className="w-full bg-white border border-[#ECEAE2] p-4 text-xs font-mono focus:outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Product Status Workflow</label>
                      <select
                        value={productForm.status || "Draft"}
                        onChange={(e) => setProductForm(p => ({ ...p, status: e.target.value as any }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      >
                        <option value="Draft">Draft (Internal Review)</option>
                        <option value="Published">Published (Active Shop)</option>
                        <option value="Hidden">Hidden (Url Only)</option>
                        <option value="Out of Stock">Out of Stock</option>
                        <option value="Archived">Archived (Delisted)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Release Scheduling (Optional)</label>
                      <input
                        type="datetime-local"
                        value={productForm.scheduledDate || ""}
                        onChange={(e) => setProductForm(p => ({ ...p, scheduledDate: e.target.value }))}
                        className="w-full bg-white border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="bg-[#121216] hover:bg-black text-white font-mono text-xs uppercase tracking-widest py-3 px-8 transition-colors font-bold"
                  >
                    Commit Specifications
                  </button>
                </form>
              ) : (
                /* Products Table */
                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-[#ECEAE2] text-[#787664] bg-[#FAF9F5]">
                        <th className="p-3">SKU</th>
                        <th className="p-3">Product Name</th>
                        <th className="p-3">Category</th>
                        <th className="p-3">Price USD</th>
                        <th className="p-3">Quantity</th>
                        <th className="p-3">Workflow State</th>
                        <th className="p-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#FAF9F5]">
                      {products.map(prod => (
                        <tr key={prod.id} className="hover:bg-[#FAF9F5]/40">
                          <td className="p-3 font-bold text-black">{prod.sku}</td>
                          <td className="p-3 font-sans font-semibold uppercase">{prod.name}</td>
                          <td className="p-3 uppercase text-[10px]">{prod.category}</td>
                          <td className="p-3 font-bold">${(prod.salePrice || prod.price).toFixed(2)}</td>
                          <td className="p-3">{prod.quantityAvailable}</td>
                          <td className="p-3">
                            <span
                              className={`px-1.5 py-0.5 text-[9px] font-bold uppercase border ${
                                prod.status === "Published"
                                  ? "bg-emerald-50 text-emerald-800 border-emerald-200"
                                  : prod.status === "Draft"
                                  ? "bg-amber-50 text-amber-800 border-amber-200"
                                  : "bg-gray-50 text-gray-800 border-gray-200"
                              }`}
                            >
                              {prod.status}
                            </span>
                          </td>
                          <td className="p-3 text-right space-x-2">
                            <button
                              onClick={() => handleEditProductClick(prod)}
                              className="p-1 hover:bg-[#EAE8DE] text-gray-700 hover:text-black transition-colors"
                              title="Edit"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDuplicateProduct(prod)}
                              className="p-1 hover:bg-[#EAE8DE] text-gray-700 hover:text-black transition-colors"
                              title="Duplicate"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteProduct(prod.id)}
                              className="p-1 hover:bg-rose-50 text-rose-700 transition-colors"
                              title="Delist"
                            >
                              <Trash className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* ======================= TAB: BULK OPERATIONS ======================= */}
          {activeTab === "bulk" && (
            <div className="space-y-6">
              <div className="border-b border-[#ECEAE2] pb-4 mb-4">
                <h3 className="text-lg font-bold uppercase tracking-tight">CSV Batch Import Matrix</h3>
              </div>

              <div className="p-4 border border-amber-950/20 bg-amber-950/5 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-xs text-[#696758] leading-relaxed font-sans">
                  Batch imports operate asynchronously. Newly parsed records default to <span className="font-mono text-black font-semibold">[Draft]</span> status to comply with legal review policies before catalog exposure.
                </div>
              </div>

              <div className="space-y-4">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664]">Paste Comma-Separated Values (CSV)</label>
                <textarea
                  rows={8}
                  value={bulkCsv}
                  onChange={(e) => setBulkCsv(e.target.value)}
                  className="w-full bg-white border border-[#ECEAE2] p-4 text-xs font-mono focus:outline-none"
                />
              </div>

              <div className="flex gap-4">
                <button
                  onClick={handleBulkImport}
                  className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors font-bold flex items-center gap-2"
                >
                  <Upload className="w-3.5 h-3.5" /> Execute CSV Parsing
                </button>
                <button
                  onClick={() => alert("CSV layout guide saved to clipboard.")}
                  className="border border-[#ECEAE2] hover:border-black font-mono text-[11px] uppercase tracking-wider px-6 py-3 transition-colors text-black"
                >
                  Download Template format
                </button>
              </div>
            </div>
          )}

          {/* ======================= TAB: TICKETS ======================= */}
          {activeTab === "tickets" && (
            <div className="space-y-8">
              <div className="border-b border-[#ECEAE2] pb-4 mb-4">
                <h3 className="text-lg font-bold uppercase tracking-tight">Customer Support ticketing Queue</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
                {/* Queue list */}
                <div className="md:col-span-5 space-y-3 max-h-[500px] overflow-y-auto pr-2">
                  {tickets.map(t => (
                    <button
                      key={t.id}
                      onClick={() => setSelectedTicket(t)}
                      className={`w-full text-left p-4 border transition-all flex flex-col justify-between h-36 ${
                        selectedTicket?.id === t.id
                          ? "border-black bg-[#FAF9F5]"
                          : "border-[#ECEAE2] bg-white hover:bg-[#FAF9F5]/50"
                      }`}
                    >
                      <div className="flex justify-between items-start w-full mb-1">
                        <span className="font-mono text-[10px] text-[#787664] font-bold">{t.id}</span>
                        <span
                          className={`px-1.5 py-0.5 text-[8px] font-bold uppercase border ${
                            t.status === "Open" ? "bg-amber-50 text-amber-800 border-amber-200" : "bg-gray-100 text-gray-700"
                          }`}
                        >
                          {t.status}
                        </span>
                      </div>
                      <h4 className="font-sans font-bold text-xs uppercase text-[#121216] line-clamp-1 leading-snug mb-1">{t.subject}</h4>
                      <p className="text-[11px] text-[#696758] line-clamp-2 leading-relaxed mb-3">{t.message}</p>
                      <span className="font-mono text-[9px] text-[#A3A3A3] block uppercase">{t.customerName}</span>
                    </button>
                  ))}
                </div>

                {/* Conversation pane */}
                <div className="md:col-span-7 border border-[#ECEAE2] bg-white p-6 flex flex-col justify-between h-[500px]">
                  {selectedTicket ? (
                    <div className="flex flex-col h-full justify-between">
                      {/* Log history */}
                      <div className="flex-grow overflow-y-auto space-y-4 mb-6 pr-2">
                        <div className="border-b border-[#ECEAE2] pb-3 mb-2">
                          <span className="font-mono text-[10px] text-[#787664] block">TICKET DISPATCH SPECIFICATIONS</span>
                          <h4 className="font-sans font-bold text-sm uppercase">{selectedTicket.subject}</h4>
                        </div>

                        <div className="space-y-4">
                          {selectedTicket.messages.map((m, idx) => (
                            <div
                              key={idx}
                              className={`p-4 border text-xs max-w-[85%] ${
                                m.sender === "customer"
                                  ? "border-[#ECEAE2] bg-[#FAF9F5] mr-auto"
                                  : "border-[#121216]/10 bg-gray-50 ml-auto"
                              }`}
                            >
                              <span className="font-mono text-[9px] text-[#787664] uppercase block mb-1">
                                {m.sender === "customer" ? selectedTicket.customerName : "Staff Admin"} • {new Date(m.timestamp).toLocaleTimeString()}
                              </span>
                              <p className="font-sans leading-relaxed text-black whitespace-pre-line">{m.text}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Reply form */}
                      <form onSubmit={handleSendTicketReply} className="flex gap-2 border-t border-[#ECEAE2] pt-4 shrink-0">
                        <input
                          type="text"
                          required
                          placeholder="Type internal staff reply..."
                          value={ticketReply}
                          onChange={(e) => setTicketReply(e.target.value)}
                          className="bg-[#FAF9F5] border border-[#ECEAE2] text-xs font-sans px-4 py-3 focus:outline-none focus:border-black flex-grow"
                        />
                        <button
                          type="submit"
                          className="bg-[#121216] hover:bg-black text-white px-5 py-3 text-xs font-mono uppercase tracking-widest font-bold flex items-center gap-1.5"
                        >
                          <Send className="w-3.5 h-3.5" /> reply
                        </button>
                      </form>
                    </div>
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center text-[#787664] font-mono text-xs">
                      Select a pending ticket from the queue to review and compile a direct reply.
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ======================= TAB: MEDIA ======================= */}
          {activeTab === "media" && (
            <div className="space-y-6">
              <div className="border-b border-[#ECEAE2] pb-4 mb-4 flex justify-between items-center">
                <h3 className="text-lg font-bold uppercase tracking-tight">Sovereign Media Library</h3>
                <button
                  onClick={() => alert("Drag-and-drop simulated file addition is active. Choose standard WebP.")}
                  className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-wider px-4 py-2 flex items-center gap-1.5 font-bold"
                >
                  <Plus className="w-3.5 h-3.5" /> Upload WebP
                </button>
              </div>

              {/* Folder selectors */}
              <div className="flex gap-2 border-b border-[#ECEAE2]/40 pb-4 font-mono text-xs">
                {["All", "Products", "Banners", "Accessories"].map(folder => (
                  <button
                    key={folder}
                    onClick={() => setActiveMediaFolder(folder)}
                    className={`px-3 py-1.5 border transition-all ${
                      activeMediaFolder === folder
                        ? "bg-black text-white border-black"
                        : "border-[#ECEAE2] text-[#696758] hover:text-black"
                    }`}
                  >
                    {folder}
                  </button>
                ))}
              </div>

              {/* Grid of images */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-6">
                {filteredMedia.map(m => (
                  <div key={m.id} className="border border-[#ECEAE2] bg-white p-3 space-y-2">
                    <div className="aspect-square bg-gray-50 overflow-hidden relative border border-[#FAF9F5]">
                      <img src={m.url} alt={m.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <span className="absolute top-2 left-2 bg-[#EAE8DE]/80 backdrop-blur-sm text-[#696758] font-mono text-[8px] px-1.5 py-0.5">
                        {m.dimensions}
                      </span>
                    </div>
                    <div className="font-mono text-[10px] space-y-1">
                      <span className="font-bold text-black block truncate" title={m.name}>{m.name}</span>
                      <div className="flex justify-between text-[#787664]">
                        <span>{m.size}</span>
                        <span className="text-emerald-800">WebP Optimized</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ======================= TAB: SETTINGS ======================= */}
          {activeTab === "settings" && (
            <div className="space-y-10">
              <form onSubmit={handleSaveSettings} className="space-y-6">
                <div className="border-b border-[#ECEAE2] pb-4 mb-4">
                  <h3 className="text-lg font-bold uppercase tracking-tight">System Compliance Parameters</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Legal Age Limit</label>
                    <input
                      type="number"
                      required
                      value={storeAge}
                      onChange={(e) => setStoreAge(Number(e.target.value))}
                      className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Store Tax Rate (%)</label>
                    <input
                      type="number"
                      required
                      value={storeTax}
                      onChange={(e) => setStoreTax(Number(e.target.value))}
                      className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Flat Shipping Cost (USD)</label>
                    <input
                      type="number"
                      required
                      value={storeShipping}
                      onChange={(e) => setStoreShipping(Number(e.target.value))}
                      className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div className="border-t border-[#ECEAE2] pt-6 space-y-4">
                  <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-[#121216]">Blockchain Node Credentials</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Sovereign Bitcoin Address</label>
                      <input
                        type="text"
                        required
                        value={btcAddr}
                        onChange={(e) => setBtcAddr(e.target.value)}
                        className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Sovereign USDT TRC-20 Address</label>
                      <input
                        type="text"
                        required
                        value={usdtAddr}
                        onChange={(e) => setUsdtAddr(e.target.value)}
                        className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Blockchain Confirmation Threshold</label>
                    <input
                      type="number"
                      required
                      min="1"
                      max="10"
                      value={confThreshold}
                      onChange={(e) => setConfThreshold(Number(e.target.value))}
                      className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono max-w-xs"
                    />
                    <p className="text-[10px] font-mono text-gray-500 mt-1.5">Requires selected block depth on main chain networks before releasing stock allocation.</p>
                  </div>
                </div>

                <button
                  type="submit"
                  className="bg-[#121216] hover:bg-black text-white font-mono text-xs uppercase tracking-widest py-3 px-8 transition-colors font-bold"
                >
                  Lock Down System config
                </button>
              </form>

              {/* SEO and Metadata Settings form */}
              <div className="space-y-6 border-t border-[#ECEAE2] pt-10">
                <div className="pb-2">
                  <h3 className="text-lg font-bold uppercase tracking-tight">SEO & Open Graph Control Board</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">XML Canonical Title</label>
                    <input
                      type="text"
                      value={metaTitle}
                      onChange={(e) => setMetaTitle(e.target.value)}
                      className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Meta Description (160 Chars)</label>
                    <input
                      type="text"
                      value={metaDesc}
                      onChange={(e) => setMetaDesc(e.target.value)}
                      className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-2.5 text-xs focus:outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Server Robots.txt file</label>
                  <textarea
                    rows={4}
                    value={robotsTxt}
                    onChange={(e) => setRobotsTxt(e.target.value)}
                    className="w-full bg-[#FAF9F5] border border-[#ECEAE2] p-4 text-xs font-mono focus:outline-none"
                  />
                </div>

                <div className="flex gap-4">
                  <button
                    onClick={() => alert("Sitemaps and canonical tags updated in memory.")}
                    className="bg-[#121216] hover:bg-black text-white font-mono text-xs uppercase tracking-widest py-3 px-6 transition-colors font-bold"
                  >
                    Compile XML Sitemap
                  </button>
                  <button
                    onClick={() => alert("Sovereign backup of the PostgreSQL state successfully cached on volume /mnt/backups/.")}
                    className="border border-[#ECEAE2] hover:border-black font-mono text-[11px] uppercase tracking-wider px-6 py-3 transition-colors text-black"
                  >
                    Trigger System Backup
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ======================= TAB: SECURE AUDIT LOGS ======================= */}
          {activeTab === "audit" && (
            <div className="space-y-6">
              <div className="border-b border-[#ECEAE2] pb-4 mb-4 flex justify-between items-center">
                <h3 className="text-lg font-bold uppercase tracking-tight">Security Auditing Ledger</h3>
                <span className="font-mono text-xs text-rose-800 bg-rose-50 px-2.5 py-1 border border-rose-100 font-bold uppercase">
                  CSRF: Active • Rate Limit: OK
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead>
                    <tr className="border-b border-[#ECEAE2] text-[#787664] bg-[#FAF9F5]">
                      <th className="p-3">Logged Date</th>
                      <th className="p-3">Actor / node</th>
                      <th className="p-3">Committed Action</th>
                      <th className="p-3">Details</th>
                      <th className="p-3">Ip Address</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#FAF9F5]">
                    {auditLogs.map(log => (
                      <tr key={log.id} className="hover:bg-[#FAF9F5]/40 text-[11px]">
                        <td className="p-3 text-[#787664] whitespace-nowrap">{new Date(log.timestamp).toLocaleString()}</td>
                        <td className="p-3 font-bold text-black">{log.actor}</td>
                        <td className="p-3 uppercase font-semibold text-gray-800">{log.action}</td>
                        <td className="p-3 text-gray-600 line-clamp-1">{log.details}</td>
                        <td className="p-3 text-[#A3A3A3]">{log.ipAddress}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
