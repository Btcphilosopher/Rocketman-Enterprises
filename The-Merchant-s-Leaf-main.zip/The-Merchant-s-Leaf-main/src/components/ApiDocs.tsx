/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Terminal, Play, Check, Copy, HelpCircle, Key, RefreshCw, Send, AlertTriangle } from "lucide-react";

export default function ApiDocs() {
  const [selectedEndpoint, setSelectedEndpoint] = useState("GET_PRODUCTS");
  const [requestBody, setRequestBody] = useState("");
  const [apiResponse, setApiResponse] = useState<string>("");
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const endpoints = {
    GET_PRODUCTS: {
      method: "GET",
      path: "/api/products",
      description: "Retrieve a complete collection of published, draft, and scheduled tobacco products.",
      bodyTemplate: ""
    },
    CREATE_PRODUCT: {
      method: "POST",
      path: "/api/products",
      description: "Introduce a new tobacco product, cigar vitola, or accessory. Returns the parsed database object.",
      bodyTemplate: JSON.stringify({
        sku: "TML-CIG-99",
        name: "Imperial Gran Reserva",
        brand: "Ebon & Ash",
        category: "Hand-Rolled Cigars",
        price: 65.00,
        quantityAvailable: 15,
        shortDescription: "Exclusive 10-year aged wrapper.",
        fullDescription: "Reserved single-origin blend."
      }, null, 2)
    },
    GET_ORDERS: {
      method: "GET",
      path: "/api/orders",
      description: "Retrieve complete order fulfillment lines, including linked cryptocurrency transactions and logs.",
      bodyTemplate: ""
    },
    GET_ANALYTICS: {
      method: "GET",
      path: "/api/analytics",
      description: "Retrieve dynamic gross revenues, 5-day history indexes, best sellers, and blockchain method splits.",
      bodyTemplate: ""
    },
    GET_AUDIT_LOGS: {
      method: "GET",
      path: "/api/audit-logs",
      description: "Query real-time security headers, admin changes, rate limit triggers, and system audits.",
      bodyTemplate: ""
    }
  };

  const handleSelectEndpoint = (key: string) => {
    setSelectedEndpoint(key);
    setRequestBody((endpoints as any)[key].bodyTemplate);
    setApiResponse("");
  };

  const handleTriggerApiRequest = async () => {
    const end = (endpoints as any)[selectedEndpoint];
    setIsLoading(true);
    setApiResponse("");

    try {
      const options: RequestInit = {
        method: end.method,
        headers: {
          "Content-Type": "application/json"
        }
      };
      if (end.method === "POST" && requestBody) {
        options.body = requestBody;
      }

      const res = await fetch(end.path, options);
      if (res.ok) {
        const json = await res.json();
        setApiResponse(JSON.stringify(json, null, 2));
      } else {
        const err = await res.json();
        setApiResponse(JSON.stringify(err, null, 2));
      }
    } catch (e) {
      setApiResponse(`Network socket failure. Express server returned:\n${String(e)}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyEndpoint = (path: string) => {
    navigator.clipboard.writeText(`https://themerchantsleaf.com${path}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="api-portal-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-sans text-[#121216]">
      {/* Header */}
      <div className="mb-10 border-b border-[#ECEAE2] pb-6">
        <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SOVEREIGN API LAYER</span>
        <h2 className="text-3xl font-bold tracking-tight uppercase">THE MERCHANTS LEAF REST API v1</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Endpoint Selector panel */}
        <aside className="lg:col-span-4 space-y-4">
          <div className="border border-[#ECEAE2] bg-white p-6 space-y-4">
            <h3 className="font-mono text-xs font-bold uppercase tracking-wider border-b border-[#ECEAE2] pb-3 text-black">Available Endpoints</h3>
            <div className="space-y-1.5">
              {Object.keys(endpoints).map((key) => {
                const end = (endpoints as any)[key];
                const isSelected = selectedEndpoint === key;
                return (
                  <button
                    key={key}
                    onClick={() => handleSelectEndpoint(key)}
                    className={`w-full text-left p-3 border transition-all flex flex-col justify-between h-20 ${
                      isSelected ? "border-black bg-[#FAF9F5]" : "border-[#ECEAE2] bg-white hover:bg-[#FAF9F5]/40"
                    }`}
                  >
                    <div className="flex justify-between items-center w-full mb-1">
                      <span className="font-mono text-[9px] font-bold text-[#787664] uppercase">{key}</span>
                      <span
                        className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded-none uppercase ${
                          end.method === "POST" ? "bg-emerald-50 text-emerald-800 border border-emerald-200" : "bg-blue-50 text-blue-800 border border-blue-200"
                        }`}
                      >
                        {end.method}
                      </span>
                    </div>
                    <span className="font-mono text-xs text-black block truncate font-semibold">{end.path}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="border border-[#ECEAE2] bg-[#FAF9F5] p-6 space-y-3 font-mono text-[11px] leading-relaxed text-[#696758]">
            <div className="flex items-center gap-2 text-black font-bold uppercase">
              <Key className="w-4 h-4 text-gray-700" /> API Authentication
            </div>
            <p>
              By default, this self-hosted API enforces a Bearer Token signature. To curl or verify requests, append your generated hash key:
            </p>
            <div className="bg-white border border-[#ECEAE2] p-2 text-black text-[10px] select-all truncate">
              Authorization: Bearer tml_live_683e921bc4fa7
            </div>
          </div>
        </aside>

        {/* Try it Now terminal console */}
        <main className="lg:col-span-8 space-y-6">
          <div className="border border-[#ECEAE2] bg-white p-8 space-y-6">
            <div className="border-b border-[#ECEAE2] pb-4 flex justify-between items-center">
              <div>
                <span className="font-mono text-[9px] text-[#787664] uppercase block mb-0.5">INTERACTIVE PLAYGROUND</span>
                <h3 className="text-base font-bold uppercase tracking-tight">Try Endpoint Console</h3>
              </div>
              <button
                onClick={() => handleCopyEndpoint((endpoints as any)[selectedEndpoint].path)}
                className="font-mono text-[11px] uppercase text-[#696758] hover:text-black flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Copy className="w-3.5 h-3.5" />}
                Copy Curl URL
              </button>
            </div>

            {/* Path and Description */}
            <div className="space-y-2">
              <div className="flex items-center gap-3 font-mono text-xs">
                <span className="bg-black text-white px-2.5 py-1 font-bold uppercase">
                  {(endpoints as any)[selectedEndpoint].method}
                </span>
                <span className="text-black font-semibold">https://themerchantsleaf.com{(endpoints as any)[selectedEndpoint].path}</span>
              </div>
              <p className="text-xs text-[#696758] leading-relaxed font-sans pt-1">
                {(endpoints as any)[selectedEndpoint].description}
              </p>
            </div>

            {/* Request Body Edit */}
            {(endpoints as any)[selectedEndpoint].method === "POST" && (
              <div className="space-y-2">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664]">JSON Request Payload</label>
                <textarea
                  rows={6}
                  value={requestBody}
                  onChange={(e) => setRequestBody(e.target.value)}
                  className="w-full bg-white border border-[#ECEAE2] p-4 text-xs font-mono focus:outline-none focus:border-black"
                />
              </div>
            )}

            {/* Run Button */}
            <button
              disabled={isLoading}
              onClick={handleTriggerApiRequest}
              className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3.5 transition-colors font-bold flex items-center gap-2"
            >
              {isLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
              Execute Socket Request
            </button>

            {/* Response Console */}
            <div className="space-y-2 pt-4 border-t border-[#ECEAE2]">
              <span className="block font-mono text-[10px] uppercase tracking-wider text-[#787664]">Terminal Response Output</span>
              <div className="bg-[#121216] text-[#A3A3A3] p-5 font-mono text-xs rounded-none h-64 overflow-y-auto relative select-all whitespace-pre">
                {isLoading ? (
                  <span className="text-white animate-pulse">Requesting self-hosted sockets...</span>
                ) : apiResponse ? (
                  apiResponse
                ) : (
                  <span className="text-gray-500">Terminal idle. Click "Execute Socket Request" to dispatch API queries.</span>
                )}
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
