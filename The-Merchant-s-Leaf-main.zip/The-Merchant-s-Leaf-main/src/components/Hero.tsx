/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Bitcoin, ShieldCheck, Cpu, ArrowDown, HelpCircle, ArrowUpRight, Newspaper } from "lucide-react";

interface HeroProps {
  onScrollToCatalog: () => void;
  onSelectCategory: (category: string) => void;
}

export default function Hero({ onScrollToCatalog, onSelectCategory }: HeroProps) {
  const collections = [
    { name: "Hand-Rolled Cigars", count: "12 custom vitolas", img: "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=400&q=80", tag: "Hand-Rolled Cigars" },
    { name: "Pipe Tobaccos", count: "8 curated blends", img: "https://images.unsplash.com/photo-1614850523011-8f49fc9ee6fd?auto=format&fit=crop&w=400&q=80", tag: "Pipe Tobaccos" },
    { name: "Premium Accessories", count: "14 architectural tools", img: "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=400&q=80", tag: "Accessories" }
  ];

  const testimonials = [
    {
      quote: "The Slab Brass Humidor is a staggering piece of heavy architectural steel. The vacuum seal maintains a constant 69.1% relative humidity in dry Nevada climate. Unrivalled craft.",
      author: "Marcus Vance",
      title: "Senior Partner, Studio Monolith"
    },
    {
      quote: "Sovereign trade at its peak. Ordering was verified instantly on-chain on the Bitcoin network with zero friction. Delivery was expedited in vacuum insulated sleeves.",
      author: "L. K. Aris",
      title: "Private Collector"
    }
  ];

  const articles = [
    {
      title: "The Physics of Relative Humidity: Spanish Cedar vs Carbon Composites",
      category: "Curation & Science",
      readTime: "7 min read",
      summary: "An in-depth thermodynamic analysis of moisture absorption rates in porous woods and why desktop humidors demand architectural cedar drawers."
    },
    {
      title: "The Estelí Revolution: Nicaraguan Soil Profiles and Wrapper Fermentation",
      category: "Soil & Craft",
      readTime: "11 min read",
      summary: "How modern soil chemistry and multi-stage triple fermentation under high pressure created the legendary oily Obsidian wrapper."
    }
  ];

  return (
    <section id="homepage-showcase" className="bg-[#FAF9F5] text-[#121216] font-sans">
      {/* 1. ARCHITECTURAL HERO BANNER */}
      <div className="border-b border-zinc-800 min-h-[70vh] flex flex-col justify-between relative overflow-hidden bg-[#0A0A0A]">
        {/* Abstract structural grid line overlay */}
        <div className="absolute inset-0 grid grid-cols-4 pointer-events-none divide-x divide-zinc-800/30">
          <div></div><div></div><div></div><div></div>
        </div>

        {/* Decorative corner block */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#050505] border-l border-b border-zinc-800 hidden md:flex flex-col justify-between p-6">
          <div className="font-mono text-[10px] tracking-widest uppercase text-zinc-500">LATITUDE: 41.8781° N<br/>LONGITUDE: 87.6298° W</div>
          <div className="font-mono text-4xl font-light text-zinc-800">01 / 07</div>
        </div>

        {/* Hero content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16 w-full z-10 flex-grow flex flex-col justify-center">
          <div className="max-w-3xl">
            <span className="font-mono text-xs tracking-[0.35em] text-zinc-400 block uppercase mb-4 font-semibold">SOVEREIGN DIRECT-TO-CONSUMER PORTFOLIO</span>
            <h1 className="text-5xl sm:text-7xl lg:text-8xl font-serif-editorial font-normal tracking-tight uppercase leading-[0.85] text-white mb-8">
              The<br/>Merchant's<br/>Leaf
            </h1>
            <p className="text-base sm:text-lg text-zinc-400 font-normal leading-relaxed max-w-xl mb-10">
              An independent, self-hosted sanctuary for the adult tobacco connoisseur. We supply architectural humidors, precision cutters, and exceptional single-origin tobacco leaves directly from source to your private collection.
            </p>
            <div className="flex flex-wrap gap-4">
              <button
                onClick={onScrollToCatalog}
                className="bg-white text-black hover:bg-zinc-200 font-mono text-xs uppercase tracking-widest px-8 py-4 transition-colors flex items-center gap-2 group cursor-pointer"
              >
                Explore Catalogue
                <ArrowDown className="w-3.5 h-3.5 group-hover:translate-y-1 transition-transform" />
              </button>
              <button
                onClick={() => onSelectCategory("Accessories")}
                className="border border-zinc-700 hover:border-white font-mono text-xs uppercase tracking-widest px-8 py-4 transition-colors text-white cursor-pointer"
              >
                Browse Accessories
              </button>
            </div>
          </div>
        </div>

        {/* Bitcoin & USDT accepted banner */}
        <div className="bg-[#121216] text-[#FAF9F5] py-4 border-t border-[#ECEAE2]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-wrap justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <span className="flex items-center justify-center bg-[#FAF9F5] text-[#121216] w-6 h-6 rounded-full font-mono text-xs font-bold font-serif">₿</span>
              <span className="font-mono text-xs tracking-wider uppercase">Sovereign Crypto Network Active</span>
            </div>
            <div className="flex items-center gap-8 text-[11px] font-mono text-[#A3A3A3] overflow-x-auto">
              <span>ACCEPTED METRICS:</span>
              <span className="text-white">BITCOIN (BTC) • DIRECT MAINNET</span>
              <span className="text-white">TETHER (USDT) • TRC-20 & ERC-20</span>
              <span className="text-white">LIGHTNING NETWORK • COMPATIBILITY PREPPED</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. TRUSTED MERCHANT MESSAGING */}
      <div className="border-b border-[#ECEAE2] py-16 bg-[#FDFDFB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-12">
          <div className="flex items-start gap-4">
            <ShieldCheck className="w-6 h-6 text-[#787664] shrink-0" />
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-[#121216] font-bold mb-2">Self-Hosted Infrastructure</h3>
              <p className="text-xs text-[#696758] leading-relaxed">
                Operating fully outside central SaaS ecosystems. Our customer databases, inventory tracks, and transaction histories reside on secured standalone Linux server layers.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <Cpu className="w-6 h-6 text-[#787664] shrink-0" />
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-[#121216] font-bold mb-2">Instant Node Audits</h3>
              <p className="text-xs text-[#696758] leading-relaxed">
                Blockchain checkout automatically computes optimal network fees, establishes direct p2p sockets, and releases item allocations immediately upon single confirmation.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4">
            <div className="w-6 h-6 text-[#787664] font-mono text-sm font-semibold tracking-wider shrink-0">21+</div>
            <div>
              <h3 className="font-mono text-xs uppercase tracking-widest text-[#121216] font-bold mb-2">Sovereign Compliance</h3>
              <p className="text-xs text-[#696758] leading-relaxed">
                Strict age-gating aligned with jurisdictional legal boundaries. We verify age details prior to compiling shipping invoices. No proxy orders.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 3. FEATURED COLLECTIONS */}
      <div className="border-b border-[#ECEAE2] py-20 bg-[#FAF9F5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-2">02 / CORE PORTFOLIO</span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight uppercase text-[#121216]">CURATED COLLECTIONS</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {collections.map((col, index) => (
              <button
                key={index}
                onClick={() => onSelectCategory(col.tag)}
                className="group text-left border border-[#ECEAE2] hover:border-[#121216] bg-white transition-all overflow-hidden p-4 flex flex-col justify-between h-96 relative cursor-pointer"
              >
                {/* Visual Image */}
                <div className="w-full h-48 bg-gray-100 overflow-hidden mb-6 relative">
                  <img
                    src={col.img}
                    alt={col.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>

                <div>
                  <span className="font-mono text-[10px] text-[#787664] uppercase tracking-wider block mb-1">{col.count}</span>
                  <h3 className="text-lg font-bold uppercase tracking-tight text-[#121216] group-hover:translate-x-1 transition-transform flex items-center justify-between">
                    {col.name}
                    <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h3>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 4. CUSTOMER REVIEWS */}
      <div className="border-b border-[#ECEAE2] py-20 bg-[#FAF9F5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-16">
            <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-2">03 / REAL REVIEWS</span>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight uppercase text-[#121216]">COLLECTOR TESTIMONIALS</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {testimonials.map((test, index) => (
              <div key={index} className="border-l-2 border-[#121216] pl-6 py-2">
                <p className="text-sm italic text-[#525043] leading-relaxed mb-6 font-sans">
                  "{test.quote}"
                </p>
                <div>
                  <h4 className="font-mono text-xs font-bold text-[#121216] uppercase">{test.author}</h4>
                  <p className="text-[11px] font-mono uppercase text-[#787664]">{test.title}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 5. EDUCATIONAL ARTICLES */}
      <div className="border-b border-[#ECEAE2] py-20 bg-[#FDFDFB]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-between items-end mb-12 gap-4">
            <div>
              <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-2">04 / THE JOURNAL</span>
              <h2 className="text-2xl sm:text-3xl font-bold tracking-tight uppercase text-[#121216]">EDUCATIONAL PERSPECTIVES</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {articles.map((art, index) => (
              <div key={index} className="border border-[#ECEAE2] p-8 hover:border-[#121216] transition-all flex flex-col justify-between h-72">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-mono text-[10px] tracking-wider uppercase bg-[#EAE8DE] text-[#696758] px-2.5 py-1">
                      {art.category}
                    </span>
                    <span className="font-mono text-[10px] text-[#A3A3A3]">
                      {art.readTime}
                    </span>
                  </div>
                  <h3 className="text-base font-bold uppercase tracking-tight text-[#121216] mb-3 leading-snug">
                    {art.title}
                  </h3>
                  <p className="text-xs text-[#696758] leading-relaxed">
                    {art.summary}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-[#121216] hover:underline cursor-pointer">
                  <Newspaper className="w-3.5 h-3.5" />
                  Read full analysis
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* 6. NEWSLETTER SIGNUP */}
      <div className="py-20 bg-[#121216] text-[#FAF9F5]">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <span className="font-mono text-[10px] tracking-widest text-[#A3A3A3] uppercase block mb-4">SUBSCRIBE TO DIRECT DISPATCH</span>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight uppercase text-white mb-4">RESTOCK INTEL & CURED BLENDS</h2>
          <p className="text-xs text-[#A3A3A3] leading-relaxed max-w-lg mx-auto mb-8 font-sans">
            Our inventory releases in small structured drops. Get real-time notifications on hand-rolled shipments, limited brass cutters, and custom reserve leaves.
          </p>
          <form onSubmit={(e) => { e.preventDefault(); alert("Successfully subscribed to sovereign dispatches."); }} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              required
              placeholder="COLLECTOR_EMAIL@DOM.COM"
              className="bg-[#1A1A20] border border-[#2B2B33] text-white px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-white flex-grow text-center sm:text-left"
            />
            <button
              type="submit"
              className="bg-white hover:bg-gray-100 text-[#121216] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors font-bold shrink-0"
            >
              Secure Register
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
