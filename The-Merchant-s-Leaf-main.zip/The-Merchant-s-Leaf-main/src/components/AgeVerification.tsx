/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { ShieldAlert, CheckCircle2, AlertTriangle } from "lucide-react";

interface AgeVerificationProps {
  onVerify: () => void;
  requiredAge: number;
}

export default function AgeVerification({ onVerify, requiredAge }: AgeVerificationProps) {
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [error, setError] = useState("");
  const [jurisdiction, setJurisdiction] = useState("US");
  const [localAgeLimit, setLocalAgeLimit] = useState(requiredAge);

  useEffect(() => {
    // Dynamic age limit by jurisdiction
    if (jurisdiction === "US" || jurisdiction === "JP") {
      setLocalAgeLimit(21);
    } else if (jurisdiction === "CA" || jurisdiction === "KR") {
      setLocalAgeLimit(19);
    } else {
      setLocalAgeLimit(18); // Default European/International age limit
    }
  }, [jurisdiction]);

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!day || !month || !year) {
      setError("Please input a complete birthdate.");
      return;
    }

    const birthDate = new Date(Number(year), Number(month) - 1, Number(day));
    const today = new Date();
    
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (isNaN(birthDate.getTime()) || birthDate.getFullYear() < 1900 || birthDate.getFullYear() > today.getFullYear()) {
      setError("Please enter a valid Gregorian birthdate.");
      return;
    }

    if (age >= localAgeLimit) {
      setError("");
      sessionStorage.setItem("tml_verified_age", "true");
      sessionStorage.setItem("tml_user_age_limit", String(localAgeLimit));
      sessionStorage.setItem("tml_user_jurisdiction", jurisdiction);
      onVerify();
    } else {
      setError(`Access denied. You must be at least ${localAgeLimit} years old to enter under the laws of ${jurisdiction === "US" ? "the United States (21)" : jurisdiction === "CA" ? "Canada (19)" : jurisdiction === "JP" ? "Japan (21)" : "your jurisdiction"}.`);
    }
  };

  return (
    <div id="age-verification-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-[#0E0E11] text-[#F9F9FB] p-4 font-sans">
      <div id="age-container" className="w-full max-w-lg border border-[#222226] bg-[#121216] p-8 md:p-12 relative overflow-hidden">
        {/* Subtle architectural background accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#F9F9FB]/2 shadow-[0_0_80px_20px_rgba(249,249,251,0.03)] rotate-45 pointer-events-none"></div>
        
        {/* Brand identity header */}
        <div className="text-center mb-8">
          <span className="font-mono text-xs tracking-[0.3em] text-[#A3A3A3] block uppercase mb-2">Established 2026</span>
          <h1 className="text-3xl font-light tracking-tight text-white uppercase font-serif-editorial">
            The Merchant's Leaf
          </h1>
          <div className="h-[1px] w-12 bg-[#F9F9FB]/20 mx-auto mt-4"></div>
        </div>

        {/* Dynamic warning banner */}
        <div className="mb-6 p-4 border border-amber-950/40 bg-amber-950/10 flex items-start gap-3">
          <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-xs font-mono tracking-wider uppercase text-amber-400 font-semibold mb-1">Government Compliance Mandate</h4>
            <p className="text-xs text-amber-200/80 leading-relaxed font-sans">
              Tobacco sales on this platform are strictly restricted to legal-age adults. Age verification is mandatory prior to browsing or ordering.
            </p>
          </div>
        </div>

        <form onSubmit={handleVerify} className="space-y-6">
          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-[#A3A3A3] mb-2">Select Jurisdiction</label>
            <select
              value={jurisdiction}
              onChange={(e) => setJurisdiction(e.target.value)}
              className="w-full bg-[#1A1A20] border border-[#2B2B33] px-4 py-3 text-sm rounded-none focus:outline-none focus:border-white text-white font-sans"
            >
              <option value="US">United States (Age 21+)</option>
              <option value="CA">Canada (Age 19+)</option>
              <option value="EU">European Union / International (Age 18+)</option>
              <option value="JP">Japan (Age 21+)</option>
              <option value="KR">South Korea (Age 19+)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-mono uppercase tracking-wider text-[#A3A3A3] mb-2">Date of Birth</label>
            <div className="grid grid-cols-3 gap-3">
              <input
                type="number"
                placeholder="DD"
                min="1"
                max="31"
                value={day}
                onChange={(e) => setDay(e.target.value)}
                className="bg-[#1A1A20] border border-[#2B2B33] px-4 py-3 text-center text-sm focus:outline-none focus:border-white text-white"
              />
              <input
                type="number"
                placeholder="MM"
                min="1"
                max="12"
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="bg-[#1A1A20] border border-[#2B2B33] px-4 py-3 text-center text-sm focus:outline-none focus:border-white text-white"
              />
              <input
                type="number"
                placeholder="YYYY"
                min="1900"
                max="2026"
                value={year}
                onChange={(e) => setYear(e.target.value)}
                className="bg-[#1A1A20] border border-[#2B2B33] px-4 py-3 text-center text-sm focus:outline-none focus:border-white text-white col-span-1"
              />
            </div>
            <p className="text-[11px] font-mono text-[#737373] mt-2">Required minimum age for {jurisdiction}: <span className="text-white font-bold">{localAgeLimit}</span></p>
          </div>

          {error && (
            <div className="p-3 bg-red-950/20 border border-red-900/30 text-red-400 text-xs flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-red-500" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-[#F9F9FB] hover:bg-white text-[#0E0E11] font-mono uppercase tracking-widest text-xs py-4 transition-colors focus:outline-none font-bold"
          >
            Access Merchant Portfolio
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-[#222226] text-center">
          <p className="text-[10px] font-mono uppercase tracking-[0.1em] text-[#737373] leading-relaxed">
            SURGEON GENERAL'S WARNING: Smoking Causes Lung Cancer, Heart Disease, Emphysema, And May Complicate Pregnancy.
          </p>
        </div>
      </div>
    </div>
  );
}
