/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useMemo } from "react";
import { Search, SlidersHorizontal, BookOpen, Video, Plus, Heart, HelpCircle, Check, Sparkles, X, ChevronRight } from "lucide-react";
import { Product } from "../types";

interface ProductsListProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onAddToWishlist: (product: Product) => void;
  wishlistIds: string[];
  activeCategory?: string;
  onClearActiveCategory?: () => void;
}

export default function ProductsList({
  products,
  onAddToCart,
  onAddToWishlist,
  wishlistIds,
  activeCategory,
  onClearActiveCategory
}: ProductsListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState(activeCategory || "All");
  const [selectedBrand, setSelectedBrand] = useState("All");
  const [priceRange, setPriceRange] = useState<number>(350);
  const [sortBy, setSortBy] = useState("default");
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Sync parent-driven category changes
  useMemo(() => {
    if (activeCategory) {
      setSelectedCategory(activeCategory);
    }
  }, [activeCategory]);

  const categories = useMemo(() => {
    const list = new Set(products.map(p => p.category));
    return ["All", ...Array.from(list)];
  }, [products]);

  const brands = useMemo(() => {
    const list = new Set(products.map(p => p.brand));
    return ["All", ...Array.from(list)];
  }, [products]);

  // Filter products based on parameters
  const filteredProducts = useMemo(() => {
    return products
      .filter(p => {
        // Only show published listings to guests
        if (p.status !== "Published") return false;

        const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
        const matchesBrand = selectedBrand === "All" || p.brand === selectedBrand;
        const currentPrice = p.salePrice || p.price;
        const matchesPrice = currentPrice <= priceRange;
        const matchesStock = !onlyInStock || p.quantityAvailable > 0;

        return matchesSearch && matchesCategory && matchesBrand && matchesPrice && matchesStock;
      })
      .sort((a, b) => {
        if (sortBy === "price-asc") {
          return (a.salePrice || a.price) - (b.salePrice || b.price);
        }
        if (sortBy === "price-desc") {
          return (b.salePrice || b.price) - (a.salePrice || a.price);
        }
        if (sortBy === "newest") {
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        }
        return 0; // default
      });
  }, [products, searchQuery, selectedCategory, selectedBrand, priceRange, sortBy, onlyInStock]);

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
  };

  const clearFilters = () => {
    setSearchQuery("");
    setSelectedCategory("All");
    setSelectedBrand("All");
    setPriceRange(350);
    setOnlyInStock(false);
    if (onClearActiveCategory) onClearActiveCategory();
  };

  return (
    <div id="shop-catalog-view" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-sans text-[#121216]">
      {/* Search Header */}
      <div className="mb-12 border-b border-[#ECEAE2] pb-8">
        <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-2">INSTANT INVENTORY INDEX</span>
        <h2 className="text-3xl font-bold tracking-tight uppercase mb-6 text-[#121216]">Sovereign Stock Search</h2>
        
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-3.5 h-4 w-4 text-[#A3A3A3]" />
            <input
              type="text"
              placeholder="Instant Search by SKU, product, leaf origins..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white border border-[#ECEAE2] px-12 py-3.5 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-[#121216] text-[#121216]"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-4 top-3 text-[#A3A3A3] hover:text-[#121216]"
              >
                Clear
              </button>
            )}
          </div>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-white border border-[#ECEAE2] px-6 py-3.5 font-mono text-xs uppercase tracking-wider text-[#696758] focus:outline-none focus:border-[#121216]"
          >
            <option value="default">Default Catalogue Order</option>
            <option value="newest">Recently Acquired</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
          </select>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-10">
        {/* Left Side Filters Bar */}
        <aside className="w-full lg:w-64 shrink-0 space-y-8">
          <div className="border border-[#ECEAE2] bg-white p-6">
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-[#ECEAE2]">
              <span className="font-mono text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                <SlidersHorizontal className="w-3.5 h-3.5" /> Filter Matrix
              </span>
              <button
                onClick={clearFilters}
                className="font-mono text-[10px] uppercase text-[#787664] hover:text-black hover:underline"
              >
                Reset All
              </button>
            </div>

            {/* Category Filter */}
            <div className="mb-6">
              <h4 className="font-mono text-[11px] font-bold uppercase tracking-wider text-[#787664] mb-3">Categories</h4>
              <div className="space-y-1.5">
                {categories.map(cat => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      if (onClearActiveCategory) onClearActiveCategory();
                    }}
                    className={`w-full text-left font-mono text-xs uppercase tracking-wide py-1 px-2.5 flex justify-between items-center transition-colors ${
                      selectedCategory === cat ? "bg-[#121216] text-white font-bold" : "text-[#696758] hover:bg-[#FAF9F5] hover:text-black"
                    }`}
                  >
                    <span>{cat}</span>
                    {selectedCategory === cat && <Check className="w-3 h-3" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Brand Filter */}
            <div className="mb-6">
              <h4 className="font-mono text-[11px] font-bold uppercase tracking-wider text-[#787664] mb-3">House Brands</h4>
              <div className="space-y-1.5">
                {brands.map(brand => (
                  <button
                    key={brand}
                    onClick={() => setSelectedBrand(brand)}
                    className={`w-full text-left font-mono text-xs uppercase tracking-wide py-1 px-2.5 flex justify-between items-center transition-colors ${
                      selectedBrand === brand ? "bg-[#121216] text-white font-bold" : "text-[#696758] hover:bg-[#FAF9F5] hover:text-black"
                    }`}
                  >
                    <span>{brand}</span>
                    {selectedBrand === brand && <Check className="w-3 h-3" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range Filter */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-3">
                <h4 className="font-mono text-[11px] font-bold uppercase tracking-wider text-[#787664]">Price Ceiling</h4>
                <span className="font-mono text-xs font-bold">${priceRange} USD</span>
              </div>
              <input
                type="range"
                min="10"
                max="350"
                step="5"
                value={priceRange}
                onChange={(e) => setPriceRange(Number(e.target.value))}
                className="w-full accent-[#121216] cursor-pointer"
              />
              <div className="flex justify-between font-mono text-[9px] text-[#A3A3A3] mt-1.5">
                <span>$10</span>
                <span>$350</span>
              </div>
            </div>

            {/* Availability Switch */}
            <div className="flex items-center justify-between pt-2 border-t border-[#ECEAE2]">
              <span className="font-mono text-[11px] uppercase text-[#696758]">Only In-Stock</span>
              <button
                onClick={() => setOnlyInStock(!onlyInStock)}
                className={`w-9 h-5 flex items-center p-0.5 rounded-full transition-colors ${
                  onlyInStock ? "bg-[#121216]" : "bg-[#ECEAE2]"
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-sm transform duration-300 ${
                    onlyInStock ? "translate-x-4" : "translate-x-0"
                  }`}
                ></div>
              </button>
            </div>
          </div>
        </aside>

        {/* Right Side Grid */}
        <main className="flex-grow">
          {filteredProducts.length === 0 ? (
            <div className="border border-[#ECEAE2] bg-white text-center py-24 px-4">
              <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase block mb-3">0 RESULTS FOUND</span>
              <h3 className="text-lg font-bold uppercase mb-2">No Compliant Match</h3>
              <p className="text-xs text-[#696758] max-w-sm mx-auto mb-6">
                Adjust your instant filter values or reset all boundaries to re-crawl our tobacco collections.
              </p>
              <button
                onClick={clearFilters}
                className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors"
              >
                Reset Filter Board
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProducts.map((prod) => {
                const isSale = prod.salePrice !== null;
                const currentPrice = prod.salePrice || prod.price;
                const isInWishlist = wishlistIds.includes(prod.id);
                const outOfStock = prod.quantityAvailable === 0;

                return (
                  <div
                    key={prod.id}
                    className="group border border-[#ECEAE2] bg-white p-4 hover:border-[#121216] transition-all flex flex-col justify-between"
                  >
                    <div>
                      {/* Product Image Stage */}
                      <div className="w-full h-48 bg-[#FAF9F5] overflow-hidden mb-4 relative cursor-pointer" onClick={() => handleSelectProduct(prod)}>
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          referrerPolicy="no-referrer"
                        />
                        {/* Status badging */}
                        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
                          {isSale && (
                            <span className="font-mono text-[9px] font-bold tracking-wider uppercase bg-amber-800 text-[#FAF9F5] px-2 py-0.5">
                              OFFER
                            </span>
                          )}
                          {outOfStock && (
                            <span className="font-mono text-[9px] font-bold tracking-wider uppercase bg-red-950 text-red-200 px-2 py-0.5">
                              ALLOCATED OUT
                            </span>
                          )}
                        </div>

                        {/* Top-right quick wishlist */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onAddToWishlist(prod);
                          }}
                          className="absolute top-3 right-3 z-10 bg-white/80 backdrop-blur-sm p-1.5 hover:bg-white text-[#121216] transition-colors shadow-sm"
                        >
                          <Heart className={`w-3.5 h-3.5 ${isInWishlist ? "fill-rose-600 text-rose-600" : "text-[#121216]"}`} />
                        </button>
                      </div>

                      {/* Info block */}
                      <div className="space-y-1 mb-6">
                        <div className="flex justify-between items-start">
                          <span className="font-mono text-[9px] tracking-widest text-[#787664] uppercase font-bold">{prod.brand}</span>
                          <span className="font-mono text-[9px] text-[#A3A3A3]">{prod.sku}</span>
                        </div>
                        <h3
                          onClick={() => handleSelectProduct(prod)}
                          className="text-sm font-bold uppercase tracking-tight text-[#121216] line-clamp-1 hover:underline cursor-pointer"
                        >
                          {prod.name}
                        </h3>
                        <p className="text-[11px] text-[#696758] line-clamp-2 leading-relaxed">
                          {prod.shortDescription}
                        </p>
                      </div>
                    </div>

                    {/* Pricing and Cart block */}
                    <div className="pt-4 border-t border-[#FAF9F5] space-y-3">
                      <div className="flex justify-between items-baseline">
                        <span className="font-mono text-xs uppercase text-[#787664]">Price:</span>
                        <div className="flex items-center gap-2">
                          {isSale && (
                            <span className="font-mono text-[11px] line-through text-[#A3A3A3]">${prod.price.toFixed(2)}</span>
                          )}
                          <span className="font-mono text-sm font-bold text-[#121216]">
                            ${currentPrice.toFixed(2)} USD
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => handleSelectProduct(prod)}
                          className="border border-[#ECEAE2] hover:border-black font-mono text-[10px] uppercase tracking-wider py-2.5 text-[#121216] transition-colors text-center"
                        >
                          View Specs
                        </button>
                        <button
                          disabled={outOfStock}
                          onClick={() => onAddToCart(prod)}
                          className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-[10px] uppercase tracking-wider py-2.5 transition-colors font-bold disabled:bg-[#ECEAE2] disabled:text-[#A3A3A3] disabled:cursor-not-allowed"
                        >
                          {outOfStock ? "Allocated" : "Buy Direct"}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>

      {/* LATERAL CRAWL DRAWER - SLIDES ON SELECTION */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans text-[#121216]" aria-labelledby="slide-over-title" role="dialog" aria-modal="true">
          <div className="absolute inset-0 overflow-hidden">
            {/* Dark overlay backdrop */}
            <div onClick={() => setSelectedProduct(null)} className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" aria-hidden="true"></div>

            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <div className="pointer-events-auto w-screen max-w-xl border-l border-[#ECEAE2] bg-[#FAF9F5] shadow-2xl">
                <div className="flex h-full flex-col overflow-y-scroll py-6">
                  {/* Header */}
                  <div className="px-6 border-b border-[#ECEAE2] pb-6 flex items-center justify-between">
                    <div>
                      <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">CRAWLED SPECIFICATION SHEET</span>
                      <h2 className="text-lg font-bold uppercase tracking-tight">{selectedProduct.name}</h2>
                    </div>
                    <button
                      onClick={() => setSelectedProduct(null)}
                      className="p-2 hover:bg-[#ECEAE2] text-[#696758] hover:text-black transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Main Content */}
                  <div className="flex-1 px-6 py-6 space-y-8">
                    {/* Visual Media Showcase */}
                    <div className="aspect-[4/3] bg-white border border-[#ECEAE2] overflow-hidden relative">
                      <img
                        src={selectedProduct.image}
                        alt={selectedProduct.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute bottom-3 right-3 font-mono text-[9px] uppercase bg-black text-white px-2 py-0.5">
                        SKU: {selectedProduct.sku}
                      </span>
                    </div>

                    {/* Metadata specs list */}
                    <div className="grid grid-cols-2 gap-4 border-b border-t border-[#ECEAE2] py-6 font-mono text-xs">
                      <div>
                        <span className="text-[#787664] block uppercase mb-1">Manufacturer Brand</span>
                        <span className="text-[#121216] font-bold uppercase">{selectedProduct.brand}</span>
                      </div>
                      <div>
                        <span className="text-[#787664] block uppercase mb-1">Catalog Category</span>
                        <span className="text-[#121216] font-bold uppercase">{selectedProduct.category}</span>
                      </div>
                      <div>
                        <span className="text-[#787664] block uppercase mb-1">Sovereign Stock Status</span>
                        <span className={`font-bold uppercase ${selectedProduct.quantityAvailable > 0 ? "text-emerald-700" : "text-red-700"}`}>
                          {selectedProduct.quantityAvailable > 0 ? `In Stock (${selectedProduct.quantityAvailable})` : "Allocated Out"}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#787664] block uppercase mb-1">Price Verification</span>
                        <span className="text-[#121216] font-bold text-sm">
                          ${(selectedProduct.salePrice || selectedProduct.price).toFixed(2)} USD
                        </span>
                      </div>
                    </div>

                    {/* Full Description (Markdown Representation) */}
                    <div className="space-y-4">
                      <h4 className="font-mono text-xs font-bold uppercase tracking-widest text-[#787664] flex items-center gap-2">
                        <Sparkles className="w-3.5 h-3.5" /> Product Curation Analysis
                      </h4>
                      {/* Rich representation of custom descriptive blocks */}
                      <div className="text-xs text-[#525043] leading-relaxed space-y-3 prose max-w-none">
                        <p className="font-sans italic border-l-2 border-[#121216] pl-3 py-0.5 bg-[#FAF9F5] text-sm">
                          {selectedProduct.shortDescription}
                        </p>
                        <div className="pt-2 font-sans whitespace-pre-wrap">
                          {selectedProduct.fullDescription}
                        </div>
                      </div>
                    </div>

                    {/* Video and PDF Guides */}
                    {(selectedProduct.videoUrl || selectedProduct.pdfGuides.length > 0) && (
                      <div className="space-y-4 pt-4 border-t border-[#ECEAE2]">
                        <h4 className="font-mono text-xs font-bold uppercase tracking-widest text-[#787664]">Sovereign Multimedia Attachments</h4>
                        
                        {selectedProduct.videoUrl && (
                          <div className="border border-[#ECEAE2] p-4 bg-white space-y-2">
                            <span className="font-mono text-[10px] text-[#787664] uppercase flex items-center gap-1.5">
                              <Video className="w-3.5 h-3.5 text-amber-800" /> Interactive Vitola Curing Clip
                            </span>
                            <div className="aspect-video bg-black flex items-center justify-center text-[#FAF9F5] text-[11px] font-mono relative overflow-hidden">
                              {/* Simple loop video component */}
                              <video controls src={selectedProduct.videoUrl} className="w-full h-full object-cover" poster={selectedProduct.image}></video>
                            </div>
                          </div>
                        )}

                        {selectedProduct.pdfGuides.length > 0 && (
                          <div className="space-y-2">
                            <span className="font-mono text-[10px] text-[#787664] uppercase block">Technical Curing Guides (PDF)</span>
                            <div className="space-y-2">
                              {selectedProduct.pdfGuides.map((guide, idx) => (
                                <a
                                  key={idx}
                                  href={guide.url}
                                  onClick={(e) => { e.preventDefault(); alert(`Sovereign file "${guide.name}" download initiated.`); }}
                                  className="flex items-center justify-between border border-[#ECEAE2] hover:border-black p-3 bg-white hover:bg-[#FAF9F5] transition-all cursor-pointer font-mono text-[11px] text-[#121216] uppercase"
                                >
                                  <span className="flex items-center gap-2">
                                    <BookOpen className="w-3.5 h-3.5 text-gray-500" /> {guide.name}
                                  </span>
                                  <ChevronRight className="w-3.5 h-3.5" />
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Associated tags */}
                    <div className="flex flex-wrap gap-2 pt-2">
                      {selectedProduct.tags.map((tag, idx) => (
                        <span key={idx} className="font-mono text-[9px] tracking-wider uppercase bg-[#EAE8DE] text-[#696758] px-2 py-1">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Foot Actions */}
                  <div className="px-6 border-t border-[#ECEAE2] pt-6 flex items-center gap-3 bg-white mt-auto">
                    <button
                      onClick={() => {
                        onAddToWishlist(selectedProduct);
                      }}
                      className="border border-[#ECEAE2] hover:border-[#121216] hover:bg-[#FAF9F5] text-black font-mono text-xs uppercase tracking-wider px-6 py-4 transition-all flex items-center gap-2"
                    >
                      <Heart className={`w-4 h-4 ${wishlistIds.includes(selectedProduct.id) ? "fill-rose-600 text-rose-600" : ""}`} />
                      Wishlist
                    </button>
                    <button
                      disabled={selectedProduct.quantityAvailable === 0}
                      onClick={() => {
                        onAddToCart(selectedProduct);
                        setSelectedProduct(null);
                      }}
                      className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest py-4 transition-colors flex-grow font-bold text-center disabled:bg-[#ECEAE2] disabled:text-[#A3A3A3] disabled:cursor-not-allowed"
                    >
                      {selectedProduct.quantityAvailable > 0 ? "Dispatch Direct to Wallet" : "Allocated Out"}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
