/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Landmark, Terminal, Check, Copy, Code, Server, Shield } from "lucide-react";

export default function DeploymentDocs() {
  const [selectedFile, setSelectedFile] = useState("DOCKER_COMPOSE");
  const [copied, setCopied] = useState(false);

  const configFiles: any = {
    DOCKER_COMPOSE: {
      title: "docker-compose.yml",
      language: "yaml",
      description: "Complete orchestration stack detailing PostgreSQL, Redis, Elasticsearch, Django REST backend, Next.js frontend, and Nginx ingress router.",
      code: `version: "3.8"

services:
  db:
    image: postgres:15-alpine
    container_name: tml_postgres_db
    restart: always
    environment:
      POSTGRES_DB: tml_sovereign_db
      POSTGRES_USER: merchant_adm
      POSTGRES_PASSWORD: tml_secure_db_pass_2026
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U merchant_adm -d tml_sovereign_db"]
      interval: 10s
      timeout: 5s
      retries: 5

  redis:
    image: redis:7-alpine
    container_name: tml_redis_cache
    restart: always
    ports:
      - "6379:6379"

  elasticsearch:
    image: elasticsearch:8.8.2
    container_name: tml_elastic_search
    restart: always
    environment:
      - discovery.type=single-node
      - xpack.security.enabled=false
      - "ES_JAVA_OPTS=-Xms512m -Xmx512m"
    volumes:
      - elastic_data:/usr/share/elasticsearch/data
    ports:
      - "9200:9200"

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: tml_django_backend
    restart: always
    environment:
      - DATABASE_URL=postgres://merchant_adm:tml_secure_db_pass_2026@db:5432/tml_sovereign_db
      - REDIS_URL=redis://redis:6379/0
      - ELASTICSEARCH_URL=http://elasticsearch:9200
      - SECRET_KEY=tml_django_hyper_secret_hash_key_2026
      - DEBUG=False
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_started
      elasticsearch:
        condition: service_started
    ports:
      - "8000:8000"

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: tml_nextjs_frontend
    restart: always
    ports:
      - "3000:3000"

  nginx:
    image: nginx:alpine
    container_name: tml_nginx_proxy
    restart: always
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf:ro
      - ./certs:/etc/nginx/certs:ro
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - backend
      - frontend

volumes:
  postgres_data:
  elastic_data:
`
    },
    NGINX_CONF: {
      title: "nginx.conf",
      language: "nginx",
      description: "Nginx reverse proxy establishing SSL connections, rate-limiting against brute force, and routing traffic between Next.js and Django REST API.",
      code: `user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;

    # Rate Limiting Zones
    limit_req_zone $binary_remote_addr zone=api_limit:10m rate=30r/m;

    # Security Headers
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    upstream frontend_server {
        server frontend:3000;
    }

    upstream backend_server {
        server backend:8000;
    }

    server {
        listen 80;
        server_name themerchantsleaf.com www.themerchantsleaf.com;
        return 301 https://$host$request_uri;
    }

    server {
        listen 443 ssl http2;
        server_name themerchantsleaf.com www.themerchantsleaf.com;

        ssl_certificate /etc/nginx/certs/tml_live.crt;
        ssl_certificate_key /etc/nginx/certs/tml_live.key;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;

        # Gzip Compression
        gzip on;
        gzip_types text/plain text/css application/json application/javascript text/xml;

        # Ingress Frontend Routing
        location / {
            proxy_pass http://frontend_server;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        # Ingress API Rate-Limited Routing
        location /api/ {
            limit_req zone=api_limit burst=10 nodelay;
            proxy_pass http://backend_server;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
    }
}
`
    },
    GITHUB_CI: {
      title: "ci-cd.yml",
      language: "yaml",
      description: "GitHub Actions workflow running automatic lints, executing Django pytest, compiling the Next.js assets, and deploying to Ubuntu Server via SSH.",
      code: `name: Sovereign CI/CD Pipeline

on:
  push:
    branches: [ main ]

jobs:
  lint-and-test:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout Repository
        uses: actions/checkout@v3

      - name: Setup Python Runtime
        uses: actions/setup-python@v4
        with:
          python-version: "3.11"

      - name: Install Python Dependencies
        run: |
          cd backend
          pip install -r requirements.txt
          pip install flake8 pytest

      - name: Run Pytest Tests
        run: |
          cd backend
          pytest

      - name: Setup Node.js Runtime
        uses: actions/setup-node@v3
        with:
          node-version: 18

      - name: Compile Frontend Assets
        run: |
          cd frontend
          npm ci
          npm run build

  deploy:
    needs: lint-and-test
    runs-on: ubuntu-latest
    steps:
      - name: Deploy Stack via SSH Remote
        uses: appleboy/ssh-action@master
        with:
          host: \${{ secrets.SSH_HOST }}
          username: \${{ secrets.SSH_USERNAME }}
          key: \${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            cd /srv/themerchantsleaf
            git pull origin main
            docker-compose down
            docker-compose up -d --build
            docker system prune -f
`
    },
    UBUNTU_PROVISION: {
      title: "ubuntu_provision.sh",
      language: "bash",
      description: "Bare-metal Ubuntu Linux provisioning bash script installing Docker, Nginx, configuring firewalls, and managing server security headers.",
      code: `#!/usr/bin/env bash
# ===================================================================
# THE MERCHANT'S LEAF BARE-METAL PROVISIONING BASH SCRIPT
# RUN AS ROOT ON UBUNTU SERVER 22.04 LTS
# ===================================================================

set -euo pipefail

echo "==> 1. Updating APT Package Lists..."
apt-get update && apt-get upgrade -y

echo "==> 2. Installing Core Utility Packages..."
apt-get install -y curl git ufw fail2ban certbot python3-certbot-nginx

echo "==> 3. Configuring Fail2Ban Intrusion Prevention..."
systemctl enable fail2ban
systemctl start fail2ban

echo "==> 4. Configuring Uncomplicated Firewall (UFW)..."
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow http
ufw allow https
ufw --force enable

echo "==> 5. Installing Docker Engine & Compose plugin..."
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
apt-get install -y docker-compose-plugin

echo "==> 6. Establishing Secure Directories..."
mkdir -p /srv/themerchantsleaf
mkdir -p /srv/themerchantsleaf/certs
mkdir -p /mnt/backups/tml_postgres

echo "==> Provisioning complete. Clone repository into /srv/themerchantsleaf."
`
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(configFiles[selectedFile].code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const currFile = configFiles[selectedFile];

  return (
    <div id="deployment-docs-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-sans text-[#121216]">
      {/* Header */}
      <div className="mb-10 border-b border-[#ECEAE2] pb-6 flex flex-wrap justify-between items-end gap-4">
        <div>
          <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">INFRASTRUCTURE MANIFEST</span>
          <h2 className="text-3xl font-bold tracking-tight uppercase">Sovereign Deployment Stack</h2>
        </div>
        <button
          onClick={handleCopyCode}
          className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors font-bold flex items-center gap-2"
        >
          {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          Copy File Code
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* File selector list */}
        <aside className="lg:col-span-4 space-y-4">
          <div className="border border-[#ECEAE2] bg-white p-6 space-y-4">
            <h3 className="font-mono text-xs font-bold uppercase tracking-wider border-b border-[#ECEAE2] pb-3 text-black flex items-center gap-2">
              <Server className="w-4 h-4 text-gray-700" /> Infrastructure files
            </h3>
            <div className="space-y-1.5">
              {Object.keys(configFiles).map((key) => (
                <button
                  key={key}
                  onClick={() => setSelectedFile(key)}
                  className={`w-full text-left p-3 border transition-all flex flex-col justify-center h-16 ${
                    selectedFile === key ? "border-black bg-[#FAF9F5] font-bold" : "border-[#ECEAE2] bg-white hover:bg-[#FAF9F5]/40"
                  }`}
                >
                  <span className="font-mono text-[9px] text-[#787664] uppercase block mb-1">{key}</span>
                  <span className="font-mono text-xs text-black block truncate">{configFiles[key].title}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="border border-[#ECEAE2] bg-[#FAF9F5] p-6 space-y-3 font-mono text-[11px] leading-relaxed text-[#696758]">
            <div className="flex items-center gap-2 text-black font-bold uppercase">
              <Shield className="w-4 h-4 text-gray-700" /> Fail-Safe Caching
            </div>
            <p>
              Elasticsearch optimizes instant autocompletes by indexing products under an index. Redis is configured with standard keys eviction caching Django REST view response objects for sub-30ms loads.
            </p>
          </div>
        </aside>

        {/* Code display pane */}
        <main className="lg:col-span-8 space-y-6">
          <div className="border border-[#ECEAE2] bg-white p-8 space-y-6">
            <div className="border-b border-[#ECEAE2] pb-4">
              <span className="font-mono text-[9px] text-[#787664] uppercase block mb-1">CONFIGURATION SPECIFICATION</span>
              <h3 className="text-base font-bold uppercase tracking-tight font-mono text-amber-800">{currFile.title}</h3>
              <p className="text-xs text-[#696758] leading-relaxed font-sans pt-1.5">
                {currFile.description}
              </p>
            </div>

            {/* Syntax-colored code box */}
            <div className="relative">
              <div className="absolute top-3 right-3 font-mono text-[9px] uppercase bg-white/10 text-white/60 px-2 py-0.5 z-10">
                {currFile.language}
              </div>
              <pre className="bg-[#121216] text-[#FAF9F5] p-5 font-mono text-xs rounded-none h-96 overflow-y-auto select-all whitespace-pre leading-relaxed border border-[#2B2B33]">
                {currFile.code}
              </pre>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
