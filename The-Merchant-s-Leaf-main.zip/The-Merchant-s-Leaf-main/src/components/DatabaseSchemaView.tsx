/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from "react";
import { Database, FileText, Check, Copy, Key, Link2, Sparkles } from "lucide-react";

export default function DatabaseSchemaView() {
  const [selectedTable, setSelectedTable] = useState("products");
  const [copiedSql, setCopiedSql] = useState(false);

  // Group of all 20 tables requested
  const tableClusters = {
    "Catalog Stock": ["products", "categories", "brands", "tags", "inventory", "images"],
    "Sales & Crypto": ["orders", "order_items", "payments", "cryptocurrency_transactions", "wallets", "coupons"],
    "Users & Access": ["customers", "addresses", "users", "permissions"],
    "System Logs": ["analytics", "messages", "settings", "audit_logs"]
  };

  const tablesMetadata: any = {
    products: {
      name: "products",
      description: "Stores individual tobacco products, pricing brackets, vitola measurements, and scheduling.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique product catalog identifier" },
        { name: "sku", type: "VARCHAR(50)", nullable: "NO", desc: "Unique Stock Keeping Unit (SKU)" },
        { name: "name", type: "VARCHAR(255)", nullable: "NO", desc: "Catalog item title" },
        { name: "brand_id", type: "UUID (FK)", nullable: "NO", desc: "Link to brands.id" },
        { name: "category_id", type: "UUID (FK)", nullable: "NO", desc: "Link to categories.id" },
        { name: "price", type: "NUMERIC(10,2)", nullable: "NO", desc: "Standard selling price" },
        { name: "sale_price", type: "NUMERIC(10,2)", nullable: "YES", desc: "Promo price, overrides price if active" },
        { name: "quantity_available", type: "INT4", nullable: "NO", desc: "Active count in physical warehouse" },
        { name: "status", type: "VARCHAR(30)", nullable: "NO", desc: "Draft, Published, Hidden, Out of Stock, Archived" },
        { name: "full_description", type: "TEXT", nullable: "YES", desc: "Markdown formatted curation description" }
      ]
    },
    categories: {
      name: "categories",
      description: "Tobacco categories such as Hand-Rolled, Pipe Blends, Accessories, and Gift Boxes.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique category identifier" },
        { name: "name", type: "VARCHAR(100)", nullable: "NO", desc: "Title of category (e.g. Pipe Tobaccos)" },
        { name: "slug", type: "VARCHAR(100)", nullable: "NO", desc: "Url-friendly descriptor code" }
      ]
    },
    brands: {
      name: "brands",
      description: "Tobacco manufacturers, local boutique houses, and custom blenders.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique brand identifier" },
        { name: "name", type: "VARCHAR(100)", nullable: "NO", desc: "Brand title (e.g. Plinth Design)" },
        { name: "origin_country", type: "VARCHAR(100)", nullable: "YES", desc: "Origin (e.g. Nicaragua, Cuba)" }
      ]
    },
    tags: {
      name: "tags",
      description: "Search tags for granular index queries (e.g. #Maduro, #Creamy).",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique tag ID" },
        { name: "name", type: "VARCHAR(50)", nullable: "NO", desc: "Tag value, stored lowercase" }
      ]
    },
    inventory: {
      name: "inventory",
      description: "Maintains physical location maps, batch control codes, and purchase history records.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique inventory audit key" },
        { name: "product_id", type: "UUID (FK)", nullable: "NO", desc: "Link to products.id" },
        { name: "batch_code", type: "VARCHAR(50)", nullable: "NO", desc: "Custom import shipment code" },
        { name: "restock_threshold", type: "INT4", nullable: "NO", desc: "Re-order alert watermark level" }
      ]
    },
    images: {
      name: "images",
      description: "Media storage catalogs, including high-res WebP links and dimensions.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique image identifier" },
        { name: "product_id", type: "UUID (FK)", nullable: "YES", desc: "Link to products.id if associated" },
        { name: "url", type: "VARCHAR(512)", nullable: "NO", desc: "Secure WebP bucket path URL" },
        { name: "dimensions", type: "VARCHAR(30)", nullable: "YES", desc: "E.g. 1200x800" }
      ]
    },
    orders: {
      name: "orders",
      description: "Core sales orders detailing customer, totals, and transaction methods.",
      columns: [
        { name: "id", type: "VARCHAR(20) (PK)", nullable: "NO", desc: "Human readable invoice ID (e.g. ord-4921)" },
        { name: "customer_id", type: "UUID (FK)", nullable: "YES", desc: "Link to customers.id if logged-in" },
        { name: "customer_name", type: "VARCHAR(255)", nullable: "NO", desc: "Recipient name" },
        { name: "customer_email", type: "VARCHAR(255)", nullable: "NO", desc: "Primary invoice recipient email" },
        { name: "subtotal", type: "NUMERIC(10,2)", nullable: "NO", desc: "Items cost sum" },
        { name: "discount_amount", type: "NUMERIC(10,2)", nullable: "NO", desc: "Rebates from coupon codes" },
        { name: "tax", type: "NUMERIC(10,2)", nullable: "NO", desc: "Calculated jurisdiction tax" },
        { name: "shipping_cost", type: "NUMERIC(10,2)", nullable: "NO", desc: "Insulated cargo rates" },
        { name: "total", type: "NUMERIC(10,2)", nullable: "NO", desc: "Final invoice sum total" },
        { name: "status", type: "VARCHAR(30)", nullable: "NO", desc: "Awaiting Payment, Payment Received, processing, Shipped..." }
      ]
    },
    order_items: {
      name: "order_items",
      description: "Lines of individual product SKU counts bought in an order record.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique item line ID" },
        { name: "order_id", type: "VARCHAR(20) (FK)", nullable: "NO", desc: "Link to orders.id" },
        { name: "product_id", type: "UUID (FK)", nullable: "NO", desc: "Link to products.id" },
        { name: "price", type: "NUMERIC(10,2)", nullable: "NO", desc: "Historic purchase price" },
        { name: "quantity", type: "INT4", nullable: "NO", desc: "Quantity ordered" }
      ]
    },
    payments: {
      name: "payments",
      description: "Direct mapping of payments made, including fiat or cryptocurrency methods.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique payment transaction audit ID" },
        { name: "order_id", type: "VARCHAR(20) (FK)", nullable: "NO", desc: "Link to orders.id" },
        { name: "payment_type", type: "VARCHAR(50)", nullable: "NO", desc: "Crypto_BTC, Crypto_USDT, Credit_Card" },
        { name: "amount_usd", type: "NUMERIC(10,2)", nullable: "NO", desc: "Exact invoice dollar size" },
        { name: "cleared_at", type: "TIMESTAMP", nullable: "YES", desc: "Date transaction was flagged settled" }
      ]
    },
    cryptocurrency_transactions: {
      name: "cryptocurrency_transactions",
      description: "Tracks direct blockchain transactions for on-chain audit and confirmation checks.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique blockchain track UUID" },
        { name: "order_id", type: "VARCHAR(20) (FK)", nullable: "NO", desc: "Link to orders.id" },
        { name: "currency", type: "VARCHAR(10)", nullable: "NO", desc: "BTC or USDT" },
        { name: "network", type: "VARCHAR(20)", nullable: "NO", desc: "Mainnet or TRC-20" },
        { name: "wallet_address", type: "VARCHAR(100)", nullable: "NO", desc: "Target receiving deposit wallet" },
        { name: "amount_crypto", type: "NUMERIC(18,8)", nullable: "NO", desc: "Exact coin/token decimal quantity" },
        { name: "tx_hash", type: "VARCHAR(128)", nullable: "YES", desc: "Raw blockchain transaction hash code" },
        { name: "block_confirmations", type: "INT4", nullable: "NO", desc: "Number of block depth met" }
      ]
    },
    wallets: {
      name: "wallets",
      description: "Self-hosted hot/cold wallet nodes and balances monitored by the system daemon.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique wallet register id" },
        { name: "currency", type: "VARCHAR(10)", nullable: "NO", desc: "BTC, USDT" },
        { name: "public_address", type: "VARCHAR(100)", nullable: "NO", desc: "Deposit monitoring address" },
        { name: "hd_path", type: "VARCHAR(50)", nullable: "YES", desc: "Sovereign key generation indices" }
      ]
    },
    coupons: {
      name: "coupons",
      description: "Active discount codes with required minimum spend caps.",
      columns: [
        { name: "code", type: "VARCHAR(50) (PK)", nullable: "NO", desc: "Discount key (e.g. HYPERMODERN)" },
        { name: "discount_percent", type: "INT4", nullable: "NO", desc: "Percentage rebate (1-100%)" },
        { name: "min_spend", type: "NUMERIC(10,2)", nullable: "NO", desc: "Minimum cart spend ceiling" },
        { name: "active", type: "BOOLEAN", nullable: "NO", desc: "Active boolean toggle status" }
      ]
    },
    customers: {
      name: "customers",
      description: "Customer directory profiles including 2FA status indicators.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique customer register ID" },
        { name: "name", type: "VARCHAR(255)", nullable: "NO", desc: "Recipient customer full name" },
        { name: "email", type: "VARCHAR(255)", nullable: "NO", desc: "Unique profile email address" },
        { name: "two_factor_secret", type: "VARCHAR(100)", nullable: "YES", desc: "Encrypted 2FA authentication token" },
        { name: "created_at", type: "TIMESTAMP", nullable: "NO", desc: "Profile register timestamp" }
      ]
    },
    addresses: {
      name: "addresses",
      description: "Saved delivery addresses mapping back to customers.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique address register ID" },
        { name: "customer_id", type: "UUID (FK)", nullable: "NO", desc: "Link to customers.id" },
        { name: "street", type: "VARCHAR(255)", nullable: "NO", desc: "Full street name" },
        { name: "city", type: "VARCHAR(100)", nullable: "NO", desc: "City jurisdiction" },
        { name: "postal_code", type: "VARCHAR(20)", nullable: "NO", desc: "ZIP code" }
      ]
    },
    users: {
      name: "users",
      description: "Seller administration staff profiles for console login.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique admin staff identifier" },
        { name: "email", type: "VARCHAR(255)", nullable: "NO", desc: "Staff email login" },
        { name: "password_hash", type: "VARCHAR(255)", nullable: "NO", desc: "Bcrypt secure password string" },
        { name: "role", type: "VARCHAR(30)", nullable: "NO", desc: "Superadmin, InventoryManager, SupportStaff" }
      ]
    },
    permissions: {
      name: "permissions",
      description: "Role-Based Access Control matrix maps for staff privileges.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique permission entry key" },
        { name: "role", type: "VARCHAR(30)", nullable: "NO", desc: "System staff role key" },
        { name: "module", type: "VARCHAR(50)", nullable: "NO", desc: "Restricted tab e.g. Products, Settings" },
        { name: "can_write", type: "BOOLEAN", nullable: "NO", desc: "Toggle privilege" }
      ]
    },
    analytics: {
      name: "analytics",
      description: "Stores compiled sales graphs, 5-day revenue, and turnover ratios.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique log indicator" },
        { name: "metric_date", type: "DATE", nullable: "NO", desc: "Date record" },
        { name: "fiat_revenue", type: "NUMERIC(12,2)", nullable: "NO", desc: "Total USD values" },
        { name: "conversion_ratio", type: "NUMERIC(4,2)", nullable: "NO", desc: "Visits vs purchases percentage" }
      ]
    },
    messages: {
      name: "messages",
      description: "Internal message dispatches and customer support tickets.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique ticket ID" },
        { name: "customer_email", type: "VARCHAR(255)", nullable: "NO", desc: "Customer sender" },
        { name: "subject", type: "VARCHAR(255)", nullable: "NO", desc: "Subject header" },
        { name: "message_payload", type: "TEXT", nullable: "NO", desc: "Full text message details" }
      ]
    },
    settings: {
      name: "settings",
      description: "Store tax percentages, legal age thresholds, and backup timelines.",
      columns: [
        { name: "id", type: "INT2 (PK)", nullable: "NO", desc: "Fixed configuration row code (usually 1)" },
        { name: "legal_age_limit", type: "INT2", nullable: "NO", desc: "Age limit constraint (e.g. 21)" },
        { name: "tax_rate_percent", type: "NUMERIC(4,2)", nullable: "NO", desc: "Default sales tax rate" },
        { name: "backup_hours", type: "INT2", nullable: "NO", desc: "Backup interval cycle hour metrics" }
      ]
    },
    audit_logs: {
      name: "audit_logs",
      description: "System and human changes detailing action, time, and source IP.",
      columns: [
        { name: "id", type: "UUID (PK)", nullable: "NO", desc: "Unique log record key" },
        { name: "timestamp", type: "TIMESTAMP", nullable: "NO", desc: "Logged event timestamp" },
        { name: "actor", type: "VARCHAR(150)", nullable: "NO", desc: "E.g. tom@ahyx.org" },
        { name: "action", type: "VARCHAR(255)", nullable: "NO", desc: "Description of modification" },
        { name: "ip_address", type: "VARCHAR(45)", nullable: "NO", desc: "Client IP network endpoint" }
      ]
    }
  };

  const getRawPostgresDdl = () => {
    return `-- ===================================================================
-- THE MERCHANT'S LEAF SOVEREIGN POSTGRESQL SCHEMA DESIGN
-- GENERATED ON: 2026-07-14 (COMPLIANT ENTERPRISE SPECIFICATION)
-- ===================================================================

-- EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. CATEGORIES TABLE
CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    slug VARCHAR(100) NOT NULL UNIQUE
);

-- 2. BRANDS TABLE
CREATE TABLE brands (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL UNIQUE,
    origin_country VARCHAR(100)
);

-- 3. PRODUCTS TABLE (CORE CATALOG)
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sku VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(255) NOT NULL,
    brand_id UUID NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
    category_id UUID NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0),
    sale_price NUMERIC(10, 2) CHECK (sale_price >= 0),
    quantity_available INTEGER NOT NULL DEFAULT 0 CHECK (quantity_available >= 0),
    short_description VARCHAR(512),
    full_description TEXT,
    video_url VARCHAR(512),
    status VARCHAR(30) NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft', 'Published', 'Hidden', 'Out of Stock', 'Archived')),
    scheduled_date TIMESTAMP,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 4. TAGS TABLE
CREATE TABLE tags (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(50) NOT NULL UNIQUE
);

-- 5. PRODUCTS_TAGS RELATION MATRIX
CREATE TABLE products_tags (
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    tag_id UUID REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (product_id, tag_id)
);

-- 6. INVENTORY HISTORY ARCHIVE
CREATE TABLE inventory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    batch_code VARCHAR(50) NOT NULL,
    restock_threshold INTEGER NOT NULL DEFAULT 10,
    recorded_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 7. IMAGES ARCHIVE
CREATE TABLE images (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    product_id UUID REFERENCES products(id) ON DELETE CASCADE,
    url VARCHAR(512) NOT NULL,
    dimensions VARCHAR(30),
    webp_optimized BOOLEAN NOT NULL DEFAULT TRUE
);

-- 8. CUSTOMERS TABLE
CREATE TABLE customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    two_factor_secret VARCHAR(100),
    joined_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 9. ADDRESSES TABLE
CREATE TABLE addresses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_id UUID NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
    street VARCHAR(255) NOT NULL,
    city VARCHAR(100) NOT NULL,
    state VARCHAR(50) NOT NULL,
    postal_code VARCHAR(20) NOT NULL,
    country VARCHAR(100) NOT NULL,
    is_default BOOLEAN NOT NULL DEFAULT FALSE
);

-- 10. ORDERS FULFILLMENT QUEUE
CREATE TABLE orders (
    id VARCHAR(20) PRIMARY KEY,
    customer_id UUID REFERENCES customers(id) ON DELETE SET NULL,
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    subtotal NUMERIC(10, 2) NOT NULL,
    discount_amount NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    tax NUMERIC(10, 2) NOT NULL,
    shipping_cost NUMERIC(10, 2) NOT NULL,
    total NUMERIC(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'Awaiting Payment',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT NOW()
);

-- 11. ORDER ITEMS DETAILS
CREATE TABLE order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id VARCHAR(20) NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id UUID NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
    price NUMERIC(10, 2) NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0)
);

-- 12. PAYMENTS AUDIT
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id VARCHAR(20) NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    payment_type VARCHAR(50) NOT NULL,
    amount_usd NUMERIC(10, 2) NOT NULL,
    cleared_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 13. CRYPTOCURRENCY TRANSACTIONS NODE RECORD
CREATE TABLE cryptocurrency_transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id VARCHAR(20) NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    currency VARCHAR(10) NOT NULL,
    network VARCHAR(20) NOT NULL,
    wallet_address VARCHAR(100) NOT NULL,
    amount_crypto NUMERIC(18, 8) NOT NULL,
    tx_hash VARCHAR(128) UNIQUE,
    block_confirmations INTEGER NOT NULL DEFAULT 0
);

-- 14. SOVEREIGN WALLETS REGISTRATION
CREATE TABLE wallets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    currency VARCHAR(10) NOT NULL,
    public_address VARCHAR(100) NOT NULL UNIQUE,
    hd_path VARCHAR(50)
);

-- 15. USERS (STAFF PRIVILEGES)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(30) NOT NULL DEFAULT 'SupportStaff'
);

-- 16. PERMISSIONS RULESET
CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role VARCHAR(30) NOT NULL,
    module VARCHAR(50) NOT NULL,
    can_write BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (role, module)
);

-- 17. ANALYTICS BUCKET
CREATE TABLE analytics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_date DATE NOT NULL UNIQUE,
    fiat_revenue NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    conversion_ratio NUMERIC(4, 2) NOT NULL DEFAULT 0.00
);

-- 18. MESSAGES (SUPPORT INBOX)
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    customer_email VARCHAR(255) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    message_payload TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT NOW()
);

-- 19. COUPONS TABLE
CREATE TABLE coupons (
    code VARCHAR(50) PRIMARY KEY,
    discount_percent INTEGER NOT NULL CHECK (discount_percent BETWEEN 1 AND 100),
    min_spend NUMERIC(10, 2) NOT NULL DEFAULT 0.00,
    active BOOLEAN NOT NULL DEFAULT TRUE
);

-- 20. AUDIT LOGS (SECURITY TAMPER-PROOF)
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
    actor VARCHAR(150) NOT NULL,
    action VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NOT NULL
);

-- INDEXES FOR PERFORMANCE OPTIMISATION
CREATE INDEX idx_products_sku ON products(sku);
CREATE INDEX idx_products_status ON products(status);
CREATE INDEX idx_orders_customer ON orders(customer_email);
CREATE INDEX idx_crypto_tx_hash ON cryptocurrency_transactions(tx_hash);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp);
`;
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(getRawPostgresDdl());
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const currTable = tablesMetadata[selectedTable] || tablesMetadata.products;

  return (
    <div id="db-schemas-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-sans text-[#121216]">
      {/* Header */}
      <div className="mb-10 border-b border-[#ECEAE2] pb-6 flex flex-wrap justify-between items-end gap-4">
        <div>
          <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SOVEREIGN STORAGE ENGINE</span>
          <h2 className="text-3xl font-bold tracking-tight uppercase">PostgreSQL Database Schema</h2>
        </div>
        <button
          onClick={handleCopySql}
          className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors font-bold flex items-center gap-2"
        >
          {copiedSql ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
          Copy Full SQL DDL
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
        {/* Table clusters directory */}
        <aside className="lg:col-span-4 space-y-6">
          <div className="border border-[#ECEAE2] bg-white p-6 space-y-4">
            <h3 className="font-mono text-xs font-bold uppercase tracking-wider border-b border-[#ECEAE2] pb-3 text-black flex items-center gap-2">
              <Database className="w-4 h-4 text-gray-700" /> 20 Database Tables
            </h3>

            {Object.keys(tableClusters).map((clusterName) => (
              <div key={clusterName} className="space-y-1.5">
                <span className="font-mono text-[9px] font-bold text-[#787664] uppercase tracking-wider block mb-1.5">
                  {clusterName}
                </span>
                <div className="space-y-1 pl-2">
                  {(tableClusters as any)[clusterName].map((tbl: string) => {
                    const isSelected = selectedTable === tbl;
                    return (
                      <button
                        key={tbl}
                        onClick={() => setSelectedTable(tbl)}
                        className={`w-full text-left font-mono text-xs uppercase tracking-wide py-1.5 px-3 flex justify-between items-center transition-colors border-l-2 ${
                          isSelected
                            ? "border-[#121216] text-[#121216] bg-[#FAF9F5] font-bold"
                            : "border-transparent text-[#696758] hover:border-[#ECEAE2] hover:text-black"
                        }`}
                      >
                        {tbl}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </aside>

        {/* Selected Table details */}
        <main className="lg:col-span-8 space-y-6">
          <div className="border border-[#ECEAE2] bg-white p-8 space-y-6">
            <div className="border-b border-[#ECEAE2] pb-4">
              <span className="font-mono text-[9px] text-[#787664] uppercase block mb-1">RELATIONAL MATRIX SPECS</span>
              <h3 className="text-lg font-bold uppercase tracking-tight flex items-center gap-1.5">
                Table: <span className="font-mono text-amber-800 lowercase">{currTable.name}</span>
              </h3>
              <p className="text-xs text-[#696758] leading-relaxed font-sans pt-1.5">
                {currTable.description}
              </p>
            </div>

            {/* Table schema Columns */}
            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs">
                <thead>
                  <tr className="border-b border-[#ECEAE2] text-[#787664] bg-[#FAF9F5]">
                    <th className="p-3">Column Name</th>
                    <th className="p-3">Data Type</th>
                    <th className="p-3">Nullable</th>
                    <th className="p-3">Audit Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FAF9F5]">
                  {currTable.columns.map((col: any, idx: number) => {
                    const isPK = col.type.includes("(PK)");
                    const isFK = col.type.includes("(FK)");
                    return (
                      <tr key={idx} className="hover:bg-[#FAF9F5]/40">
                        <td className="p-3 font-bold text-black flex items-center gap-1.5">
                          {isPK && <Key className="w-3 h-3 text-amber-800" />}
                          {isFK && <Link2 className="w-3 h-3 text-blue-800" />}
                          <span>{col.name}</span>
                        </td>
                        <td className="p-3 font-semibold text-gray-800 uppercase text-[11px]">{col.type}</td>
                        <td className="p-3 text-gray-500">{col.nullable}</td>
                        <td className="p-3 text-gray-600 font-sans leading-relaxed text-xs">{col.desc}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Visual DB diagram snippet */}
            <div className="p-4 border border-emerald-950/20 bg-emerald-950/5 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-emerald-800 shrink-0 mt-0.5" />
              <div className="text-xs text-[#525043] leading-relaxed font-sans">
                <strong>Optimal Relational Indexing Keys Active</strong>: Foreign key relations are constrained with cascade delete protocols. Standard indices are pre-mapped for rapid retrieval cycles.
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
