/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ShoppingBag, Heart, Shield, Terminal, Database, HelpCircle, Menu, X, Landmark } from "lucide-react";
import { useState } from "react";

interface NavbarProps {
  currentTab: string;
  onChangeTab: (tab: string) => void;
  cartCount: number;
  wishlistCount: number;
  onOpenCart: () => void;
  userAgeLimit?: string;
  userJurisdiction?: string;
}

export default function Navbar({
  currentTab,
  onChangeTab,
  cartCount,
  wishlistCount,
  onOpenCart,
  userAgeLimit = "21",
  userJurisdiction = "US"
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "shop", label: "Catalog", icon: ShoppingBag },
    { id: "dashboard", label: "Seller Console", icon: Shield },
    { id: "api-docs", label: "REST API Docs", icon: Terminal },
    { id: "db-schema", label: "PostgreSQL Schemas", icon: Database },
    { id: "deployment", label: "Deployment", icon: Landmark },
    { id: "help", label: "Merchant Info & FAQ", icon: HelpCircle }
  ];

  const handleTabClick = (tabId: string) => {
    onChangeTab(tabId);
    setMobileMenuOpen(false);
  };

  return (
    <header id="app-header" className="sticky top-0 z-40 w-full bg-[#050505] border-b border-zinc-800 backdrop-blur-md transition-colors">
      {/* Top Banner indicating compliant verification status */}
      <div className="w-full bg-[#0A0A0A] text-zinc-500 text-[10px] font-mono tracking-[0.2em] uppercase py-2.5 px-6 border-b border-zinc-800/60 flex justify-between items-center overflow-x-auto gap-4">
        <span>Verified Adult Guest: {userJurisdiction} (Age {userAgeLimit}+)</span>
        <div className="flex items-center gap-2">
          <div className="h-1.5 w-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]"></div>
          <span className="hidden sm:inline-block text-zinc-500">Cryptocurrency Node: Online</span>
        </div>
        <span>Secure Session Secured</span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => handleTabClick("shop")}
          className="text-left select-none outline-none focus:ring-0 group cursor-pointer flex flex-col"
        >
          <span className="text-[10px] tracking-[0.4em] font-bold uppercase text-zinc-500 mb-0.5 leading-none">INDEPENDENT MERCHANT</span>
          <h1 className="text-xl font-bold tracking-tighter uppercase text-white leading-none group-hover:text-zinc-300 transition-colors">
            THE MERCHANT'S LEAF
          </h1>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-8">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
               <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`flex items-center gap-1.5 font-mono text-xs uppercase tracking-wider transition-colors ${
                  isActive
                    ? "text-white font-bold border-b border-white pb-1"
                    : "text-zinc-400 hover:text-white"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action Indicators */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => handleTabClick("wishlist")}
            className={`p-2 hover:bg-zinc-900 text-zinc-400 hover:text-white transition-colors relative ${
              currentTab === "wishlist" ? "bg-zinc-900 text-white" : ""
            }`}
            title="Wishlist"
          >
            <Heart className="w-4 h-4" />
            {wishlistCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-600 rounded-full"></span>
            )}
          </button>

          <button
            onClick={onOpenCart}
            className="p-2 hover:bg-zinc-900 text-zinc-400 hover:text-white transition-colors relative flex items-center gap-2"
            title="Cart"
          >
            <ShoppingBag className="w-4 h-4 text-white" />
            <span className="font-mono text-xs font-semibold bg-white text-black px-1.5 py-0.5 rounded-none leading-none">
              {cartCount}
            </span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-zinc-400 hover:text-white hover:bg-zinc-900 transition-colors"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-zinc-800 bg-[#050505] px-4 py-4 space-y-3 animate-fade-in">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabClick(item.id)}
                className={`w-full flex items-center gap-3 font-mono text-xs uppercase tracking-wider p-2.5 transition-colors ${
                  isActive
                    ? "bg-zinc-900 text-white font-bold"
                    : "text-zinc-400 hover:bg-zinc-900/60"
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </button>
            );
          })}
          <button
            onClick={() => handleTabClick("wishlist")}
            className={`w-full flex items-center gap-3 font-mono text-xs uppercase tracking-wider p-2.5 transition-colors ${
              currentTab === "wishlist" ? "bg-zinc-900 text-white font-bold" : "text-zinc-400 hover:bg-zinc-900/60"
            }`}
          >
            <Heart className="w-4 h-4" />
            Wishlist ({wishlistCount})
          </button>
        </div>
      )}
    </header>
  );
}
