/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { CreditCard, ArrowRight, ShieldCheck, Download, Sparkles, CheckCircle2, Ticket, Bitcoin, Clock, RefreshCw, AlertTriangle, ArrowLeft } from "lucide-react";
import { Product, Order, OrderItem, CryptoTransaction, Coupon } from "../types";

interface CheckoutFlowProps {
  cart: Array<{ product: Product; quantity: number }>;
  onClearCart: () => void;
  taxRatePercent: number;
  flatShippingCostUsd: number;
  bitcoinWalletAddress: string;
  usdtTrc20WalletAddress: string;
  onOrderCreated: (order: Order) => void;
  activeOrder: Order | null;
  onCloseCheckout: () => void;
  coupons: Coupon[];
}

export default function CheckoutFlow({
  cart,
  onClearCart,
  taxRatePercent,
  flatShippingCostUsd,
  bitcoinWalletAddress,
  usdtTrc20WalletAddress,
  onOrderCreated,
  activeOrder: initialActiveOrder,
  onCloseCheckout,
  coupons
}: CheckoutFlowProps) {
  const [activeOrder, setActiveOrder] = useState<Order | null>(initialActiveOrder);
  const [paymentMethod, setPaymentMethod] = useState<'Crypto_BTC' | 'Crypto_USDT' | 'Credit_Card_Simulated'>('Crypto_BTC');
  
  // Shipping Form State
  const [name, setName] = useState("Alexander Gray");
  const [email, setEmail] = useState("alexander@grayarchitects.co");
  const [street, setStreet] = useState("455 Brutalist Boulevard");
  const [city, setCity] = useState("Chicago");
  const [state, setState] = useState("IL");
  const [zip, setZip] = useState("60601");
  const [country, setCountry] = useState("USA");
  const [notes, setNotes] = useState("Please package with extra humidity-buffered sleeves.");
  
  // Coupon State
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState("");

  // Countdown clock state
  const [secondsRemaining, setSecondsRemaining] = useState(900); // 15 mins
  const [isSimulatingPayment, setIsSimulatingPayment] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<string[]>([]);

  // Calculate totals
  const subtotal = cart.reduce((sum, item) => sum + (item.product.salePrice || item.product.price) * item.quantity, 0);
  const discountAmount = appliedCoupon ? Number((subtotal * (appliedCoupon.discountPercent / 100)).toFixed(2)) : 0;
  const taxAmount = Number(((subtotal - discountAmount) * (taxRatePercent / 100)).toFixed(2));
  const shippingCost = subtotal > 150 ? 0 : flatShippingCostUsd; // free shipping above $150
  const grandTotal = Number((subtotal - discountAmount + taxAmount + shippingCost).toFixed(2));

  // Sync active order if changed externally
  useEffect(() => {
    if (initialActiveOrder) {
      setActiveOrder(initialActiveOrder);
      if (initialActiveOrder.cryptoTransaction) {
        setSecondsRemaining(900);
      }
    }
  }, [initialActiveOrder]);

  // Countdown timer effect
  useEffect(() => {
    let timer: any;
    if (activeOrder && activeOrder.cryptoTransaction && activeOrder.status === 'Awaiting Payment' && secondsRemaining > 0) {
      timer = setInterval(() => {
        setSecondsRemaining(prev => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [activeOrder, secondsRemaining]);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError("");
    const matched = coupons.find(c => c.code.toUpperCase() === couponCode.trim().toUpperCase());
    if (!matched) {
      setCouponError("Invalid or expired coupon code.");
      setAppliedCoupon(null);
      return;
    }
    if (!matched.active) {
      setCouponError("This coupon is no longer active.");
      setAppliedCoupon(null);
      return;
    }
    if (subtotal < matched.minSpend) {
      setCouponError(`This coupon requires a minimum spend of $${matched.minSpend}.`);
      setAppliedCoupon(null);
      return;
    }
    setAppliedCoupon(matched);
    setCouponCode("");
  };

  const handleCreateOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const orderPayload = {
      customerName: name,
      customerEmail: email,
      shippingAddress: {
        street,
        city,
        state,
        postalCode: zip,
        country
      },
      items: cart.map(item => ({
        productId: item.product.id,
        name: item.product.name,
        sku: item.product.sku,
        price: item.product.salePrice || item.product.price,
        quantity: item.quantity
      })),
      subtotal,
      discountCode: appliedCoupon ? appliedCoupon.code : null,
      discountAmount,
      tax: taxAmount,
      shippingCost,
      total: grandTotal,
      paymentMethod,
      notes
    };

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderPayload)
      });
      if (res.ok) {
        const createdOrder: Order = await res.json();
        setActiveOrder(createdOrder);
        onOrderCreated(createdOrder);
        onClearCart();
      } else {
        alert("Failed to submit compliant order.");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Simulated node confirmation webhook caller
  const handleTriggerPaymentSimulation = async () => {
    if (!activeOrder) return;
    setIsSimulatingPayment(true);
    setSimulationLogs(["2026-07-14T07:12:00Z: Establishing secure socket tunnel to self-hosted blockchain node..."]);
    
    // Simulate steps of blockchain confirmations
    setTimeout(() => {
      setSimulationLogs(prev => [...prev, "2026-07-14T07:12:05Z: Scanning transaction pool (Mempool)..."]);
    }, 1000);

    setTimeout(() => {
      setSimulationLogs(prev => [...prev, `2026-07-14T07:12:10Z: Found transaction paying ${activeOrder.cryptoTransaction?.amountCrypto} ${activeOrder.cryptoTransaction?.currency} to ${activeOrder.cryptoTransaction?.address}.`]);
    }, 2500);

    setTimeout(async () => {
      try {
        const res = await fetch(`/api/orders/${activeOrder.id}/detect-payment`, {
          method: "POST"
        });
        if (res.ok) {
          const result = await res.json();
          setActiveOrder(result.order);
          setSimulationLogs(prev => [
            ...prev,
            `2026-07-14T07:12:15Z: Threshold confirmation Met (1/${taxRatePercent > 0 ? "1" : "2"} confirmations).`,
            `2026-07-14T07:12:16Z: ORDER STATUS PROMOTED TO [PAYMENT RECEIVED].`
          ]);
          setIsSimulatingPayment(false);
        }
      } catch (err) {
        console.error(err);
        setIsSimulatingPayment(false);
      }
    }, 4000);
  };

  // Convert seconds to MM:SS format
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const s = secs % 60;
    return `${mins.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`;
  };

  const handleDownloadInvoice = () => {
    alert(`Successfully generated and downloaded PDF Tax Invoice for Order ID ${activeOrder?.id}. Saved to device.`);
  };

  // Order Complete Screen
  if (activeOrder && activeOrder.status === 'Payment Received') {
    return (
      <div id="checkout-receipt" className="max-w-3xl mx-auto py-16 px-4 text-[#121216] font-sans text-center">
        <div className="border border-[#ECEAE2] bg-white p-8 md:p-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#EAE8DE] rotate-45 transform translate-x-12 -translate-y-12"></div>
          
          <CheckCircle2 className="w-12 h-12 text-[#121216] mx-auto mb-6" />
          <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase block mb-1">SOVEREIGN TRADE CLEARED</span>
          <h2 className="text-2xl font-bold uppercase tracking-tight mb-3">Order Invoice {activeOrder.id}</h2>
          <p className="text-xs text-[#696758] max-w-md mx-auto mb-8 leading-relaxed">
            Payment has been successfully detected on the blockchain node. Your tobacco allocation is secured and currently processing in our warehouse.
          </p>

          {/* Quick Invoice Details */}
          <div className="border border-[#FAF9F5] bg-[#FAF9F5] p-6 text-left space-y-4 mb-8 font-mono text-xs">
            <div className="flex justify-between border-b border-[#ECEAE2] pb-3 font-bold">
              <span>METRICS VALUE</span>
              <span>CONFIRMED STATE</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#696758]">Customer Email:</span>
              <span className="text-black">{activeOrder.customerEmail}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#696758]">Delivery Address:</span>
              <span className="text-black text-right">{activeOrder.shippingAddress.street}, {activeOrder.shippingAddress.city}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-[#696758]">Items Selected:</span>
              <span className="text-black font-sans font-semibold">{activeOrder.items.reduce((s,i) => s + i.quantity, 0)} items</span>
            </div>
            <div className="flex justify-between border-t border-[#ECEAE2] pt-3 font-bold text-sm">
              <span>Total Paid Amount:</span>
              <span>${activeOrder.total.toFixed(2)} USD</span>
            </div>
            {activeOrder.cryptoTransaction && (
              <div className="border-t border-[#ECEAE2] pt-3 text-[11px] leading-relaxed space-y-1">
                <div className="flex justify-between text-[#787664]">
                  <span>On-Chain Asset:</span>
                  <span className="text-black font-bold uppercase">{activeOrder.cryptoTransaction.currency} ({activeOrder.cryptoTransaction.network})</span>
                </div>
                <div className="flex justify-between text-[#787664]">
                  <span>Total Crypto Cleared:</span>
                  <span className="text-[#121216] font-bold">{activeOrder.cryptoTransaction.amountCrypto} {activeOrder.cryptoTransaction.currency}</span>
                </div>
                <div className="text-[10px] text-gray-500 line-clamp-1 select-all break-all text-center pt-2 font-mono bg-[#EAE8DE]/40 p-2">
                  TxHash: {activeOrder.cryptoTransaction.txHash}
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-4 justify-center">
            <button
              onClick={handleDownloadInvoice}
              className="border border-[#121216]/15 hover:border-black font-mono text-xs uppercase tracking-widest px-8 py-3.5 transition-colors flex items-center gap-2 text-[#121216]"
            >
              <Download className="w-3.5 h-3.5" /> Download PDF Invoice
            </button>
            <button
              onClick={onCloseCheckout}
              className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-8 py-3.5 transition-colors font-bold"
            >
              Back to Catalog
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="checkout-container" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 font-sans text-[#121216]">
      <button
        onClick={onCloseCheckout}
        className="flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-[#696758] hover:text-black mb-8"
      >
        <ArrowLeft className="w-4 h-4" /> Return to Catalog
      </button>

      {activeOrder && activeOrder.cryptoTransaction && activeOrder.status === "Awaiting Payment" ? (
        /* ================= CRYPTO GATEWAY COUNTDOWN SCREEN ================= */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7 border border-[#ECEAE2] bg-white p-8 relative">
            <div className="flex justify-between items-start mb-6 pb-4 border-b border-[#ECEAE2]">
              <div>
                <span className="font-mono text-[9px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SOVEREIGN NODE ACCOUNT</span>
                <h3 className="text-xl font-bold uppercase tracking-tight">Direct Cryptocurrency Gateway</h3>
              </div>
              <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-wider text-amber-700 bg-amber-50 px-3 py-1.5 border border-amber-200">
                <Clock className="w-4 h-4 text-amber-700 animate-pulse" />
                <span>Timer: {formatTime(secondsRemaining)}</span>
              </div>
            </div>

            {/* Currency Choice details */}
            <div className="space-y-6">
              <div className="p-4 border border-[#ECEAE2] bg-[#FAF9F5] flex justify-between items-center font-mono text-xs">
                <div>
                  <span className="text-[#787664] uppercase block text-[10px] mb-1">Total Sovereign Invoice</span>
                  <span className="text-lg font-bold">${activeOrder.total.toFixed(2)} USD</span>
                </div>
                <div className="text-right">
                  <span className="text-[#787664] uppercase block text-[10px] mb-1">Payable Crypto Value</span>
                  <span className="text-lg font-bold text-amber-800">
                    {activeOrder.cryptoTransaction.amountCrypto} {activeOrder.cryptoTransaction.currency}
                  </span>
                </div>
              </div>

              {/* Wallet block with copyable details */}
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  {/* Styled QR Code Box */}
                  <div className="md:col-span-4 flex flex-col items-center justify-center p-3 bg-white border border-[#ECEAE2]">
                    <div className="w-32 h-32 bg-[#121216] p-2 flex flex-col justify-between items-center relative overflow-hidden">
                      {/* Geometric grid lines representing a vector QR */}
                      <div className="absolute inset-2 grid grid-cols-6 grid-rows-6 gap-1 opacity-90">
                        {Array.from({ length: 36 }).map((_, idx) => (
                          <div
                            key={idx}
                            className={`bg-white rounded-sm ${
                              (idx < 5 && idx % 2 === 0) || (idx > 30 && idx % 3 === 0) || idx === 15 || idx === 20 || idx === 22
                                ? "opacity-20"
                                : ""
                            }`}
                          ></div>
                        ))}
                      </div>
                      <div className="w-6 h-6 bg-white shrink-0 z-10 flex items-center justify-center rounded-sm font-mono text-[9px] font-bold font-serif text-black select-none">
                        {activeOrder.cryptoTransaction.currency === 'BTC' ? '₿' : 'T'}
                      </div>
                      <span className="text-[7px] font-mono tracking-widest text-white/50 z-10 leading-none">THE LEAF</span>
                    </div>
                    <span className="font-mono text-[9px] tracking-wider text-[#787664] uppercase mt-2">Scan Address QR</span>
                  </div>

                  {/* Address and Network details */}
                  <div className="md:col-span-8 space-y-3 font-mono text-xs">
                    <div>
                      <span className="text-[#787664] uppercase block mb-1">Target Network Address</span>
                      <div className="bg-[#FAF9F5] border border-[#ECEAE2] p-3 text-black text-[11px] break-all select-all flex justify-between items-center font-mono">
                        <span>{activeOrder.cryptoTransaction.address}</span>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[#787664] uppercase block mb-1">Payment Asset</span>
                        <span className="font-bold text-black uppercase">{activeOrder.cryptoTransaction.currency}</span>
                      </div>
                      <div>
                        <span className="text-[#787664] uppercase block mb-1">Target Blockchain Network</span>
                        <span className="font-bold text-amber-800 uppercase">{activeOrder.cryptoTransaction.network}</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Automatic Blockchain simulator console */}
              <div className="border border-amber-950/20 bg-amber-950/5 p-6 space-y-4">
                <div className="flex items-start gap-3">
                  <Bitcoin className="w-5 h-5 text-amber-600 shrink-0 mt-0.5 animate-spin" />
                  <div>
                    <h4 className="font-mono text-xs font-bold uppercase tracking-wider text-amber-700">Self-Hosted Node Webhook Simulator</h4>
                    <p className="text-xs text-[#696758] leading-relaxed font-sans mt-1">
                      Normally, our self-hosted backend scans the blockchain mempool for inbound tx hashes matching the wallet criteria. Use our test trigger to mock immediate blockchain confirmation!
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    disabled={isSimulatingPayment}
                    onClick={handleTriggerPaymentSimulation}
                    className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors font-bold flex items-center gap-2 shrink-0 disabled:bg-gray-400"
                  >
                    {isSimulatingPayment ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : "Trigger Node Webhook"}
                    <span>Mock Blockchain Pay</span>
                  </button>
                </div>

                {/* Simulated Webhook logs */}
                {simulationLogs.length > 0 && (
                  <div className="bg-black text-[#A3A3A3] font-mono text-[10px] p-4 rounded-none h-32 overflow-y-auto space-y-1.5 border border-[#2B2B33]">
                    {simulationLogs.map((log, idx) => (
                      <div key={idx} className={log.includes("ORDER STATUS PROMOTED") ? "text-emerald-400 font-bold" : ""}>
                        {log}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Summary */}
          <div className="lg:col-span-5 space-y-6">
            <div className="border border-[#ECEAE2] bg-white p-6 font-mono text-xs space-y-4">
              <h4 className="font-bold uppercase tracking-wider border-b border-[#ECEAE2] pb-3 text-sm">Order Parameters</h4>
              <div className="flex justify-between">
                <span className="text-[#696758]">Allocated ID:</span>
                <span className="font-bold text-black">{activeOrder.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#696758]">Customer:</span>
                <span className="text-black font-sans">{activeOrder.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#696758]">Email:</span>
                <span className="text-black select-all">{activeOrder.customerEmail}</span>
              </div>
              <div className="border-t border-[#ECEAE2] pt-4 font-sans font-semibold text-xs text-[#525043] leading-relaxed">
                Your selected products are temporarily reserved for <span className="font-mono text-[#121216] font-bold">15:00</span> minutes awaiting transaction broadcast. If expired without confirmations, stocks return to the open pool.
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* ================= SHIPPMENT ADDRESS AND INVOICE CHECKOUT FORM ================= */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Checkout billing form */}
          <form onSubmit={handleCreateOrder} className="lg:col-span-7 border border-[#ECEAE2] bg-white p-8 space-y-6">
            <div className="border-b border-[#ECEAE2] pb-4 mb-4">
              <span className="font-mono text-[9px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SECURE PORTAL</span>
              <h3 className="text-xl font-bold uppercase tracking-tight">Adult Customer Curing Invoice</h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Recipient Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
                />
              </div>
              <div>
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Recipient Contact Email</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
                />
              </div>
            </div>

            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Street Address</label>
              <input
                type="text"
                required
                value={street}
                onChange={(e) => setStreet(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="col-span-2">
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">City</label>
                <input
                  type="text"
                  required
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
                />
              </div>
              <div>
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">State / Prov</label>
                <input
                  type="text"
                  required
                  value={state}
                  onChange={(e) => setState(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
                />
              </div>
              <div>
                <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Postal ZIP</label>
                <input
                  type="text"
                  required
                  value={zip}
                  onChange={(e) => setZip(e.target.value)}
                  className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
                />
              </div>
            </div>

            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Country Jurisdiction</label>
              <input
                type="text"
                required
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#ECEAE2] px-4 py-3 text-xs uppercase font-mono tracking-wider focus:outline-none focus:border-black text-[#121216]"
              />
            </div>

            <div>
              <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664] mb-2">Order Curation Notes (Optional)</label>
              <textarea
                rows={3}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full bg-[#FAF9F5] border border-[#ECEAE2] p-4 text-xs font-sans focus:outline-none focus:border-black text-[#121216]"
              />
            </div>

            {/* Cryptocurrency Payment Methods Select */}
            <div className="space-y-3 pt-4 border-t border-[#ECEAE2]">
              <label className="block font-mono text-[10px] uppercase tracking-wider text-[#787664]">Sovereign Payment Infrastructure</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Crypto_BTC')}
                  className={`border p-4 text-left flex flex-col justify-between h-28 cursor-pointer transition-all ${
                    paymentMethod === 'Crypto_BTC' ? "border-black bg-[#FAF9F5]" : "border-[#ECEAE2] bg-white hover:bg-[#FAF9F5]"
                  }`}
                >
                  <span className="font-mono text-sm font-bold text-[#121216]">BITCOIN (BTC)</span>
                  <span className="font-mono text-[9px] text-[#787664] uppercase leading-relaxed">Direct peer-to-peer mainnet settlement.</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Crypto_USDT')}
                  className={`border p-4 text-left flex flex-col justify-between h-28 cursor-pointer transition-all ${
                    paymentMethod === 'Crypto_USDT' ? "border-black bg-[#FAF9F5]" : "border-[#ECEAE2] bg-white hover:bg-[#FAF9F5]"
                  }`}
                >
                  <span className="font-mono text-sm font-bold text-[#121216]">TETHER (USDT)</span>
                  <span className="font-mono text-[9px] text-[#787664] uppercase leading-relaxed">Stablecoin via TRC-20 high speed channel.</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('Credit_Card_Simulated')}
                  className={`border p-4 text-left flex flex-col justify-between h-28 cursor-pointer transition-all ${
                    paymentMethod === 'Credit_Card_Simulated' ? "border-black bg-[#FAF9F5]" : "border-[#ECEAE2] bg-white hover:bg-[#FAF9F5]"
                  }`}
                >
                  <span className="font-mono text-sm font-bold text-[#121216]">MOCK VISA/CARD</span>
                  <span className="font-mono text-[9px] text-[#787664] uppercase leading-relaxed">Simulated instant credit checkout.</span>
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={cart.length === 0}
              className="w-full bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest py-4 transition-colors font-bold text-center flex items-center justify-center gap-3 disabled:bg-[#ECEAE2] disabled:text-[#A3A3A3] disabled:cursor-not-allowed"
            >
              Compile & Sign Sovereign Invoice
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Checkout sidebar order summary */}
          <aside className="lg:col-span-5 space-y-6">
            <div className="border border-[#ECEAE2] bg-white p-6 space-y-6">
              <h4 className="font-mono text-xs font-bold uppercase tracking-wider border-b border-[#ECEAE2] pb-3">Allocated Items Summary</h4>
              
              {cart.length === 0 ? (
                <p className="text-xs text-[#696758] italic py-4 text-center font-sans">Your sovereign checkout is empty.</p>
              ) : (
                <div className="divide-y divide-[#FAF9F5] max-h-60 overflow-y-auto pr-2">
                  {cart.map((item) => (
                    <div key={item.product.id} className="py-3 flex justify-between gap-3 text-xs font-mono">
                      <div>
                        <span className="font-bold text-[#121216] uppercase line-clamp-1">{item.product.name}</span>
                        <span className="text-[#787664] block">QTY: {item.quantity} x ${(item.product.salePrice || item.product.price).toFixed(2)}</span>
                      </div>
                      <span className="font-bold text-black shrink-0">
                        ${((item.product.salePrice || item.product.price) * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {/* Coupons form */}
              <form onSubmit={handleApplyCoupon} className="flex gap-2 pt-4 border-t border-[#ECEAE2]">
                <input
                  type="text"
                  placeholder="COUPON_CODE"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="bg-[#FAF9F5] border border-[#ECEAE2] text-xs uppercase font-mono tracking-wider px-3 py-2 focus:outline-none focus:border-black flex-grow text-center"
                />
                <button
                  type="submit"
                  className="bg-[#121216] hover:bg-black text-white px-4 py-2 text-xs font-mono uppercase tracking-widest font-bold"
                >
                  Apply
                </button>
              </form>

              {appliedCoupon && (
                <div className="p-2 border border-emerald-200 bg-emerald-50 text-emerald-800 text-[11px] font-mono uppercase flex justify-between items-center">
                  <span>Applied Coupon: {appliedCoupon.code}</span>
                  <span>-{appliedCoupon.discountPercent}%</span>
                </div>
              )}

              {couponError && (
                <div className="p-2 border border-red-200 bg-red-50 text-red-700 text-[11px] font-mono flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" /> {couponError}
                </div>
              )}

              {/* Pricing breakdown ledger */}
              <div className="pt-4 border-t border-[#ECEAE2] font-mono text-xs space-y-2.5">
                <div className="flex justify-between text-[#696758]">
                  <span>Subtotal:</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                {appliedCoupon && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Discount Applied:</span>
                    <span>-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-[#696758]">
                  <span>Jurisdiction Tax ({taxRatePercent}%):</span>
                  <span>${taxAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[#696758]">
                  <span>Secure Insulated Shipping:</span>
                  <span>{shippingCost === 0 ? "FREE" : `$${shippingCost.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between border-t border-[#121216] pt-3.5 text-sm font-bold text-black">
                  <span>Grand Invoice Total:</span>
                  <span>${grandTotal.toFixed(2)} USD</span>
                </div>
              </div>
            </div>

            {/* Trust and safety details */}
            <div className="border border-[#ECEAE2] bg-[#FAF9F5] p-6 flex gap-3 items-start">
              <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
              <div className="font-sans text-[11px] text-[#696758] leading-relaxed">
                Our checkout is self-contained. Your email and shipping address remain isolated in our standalone server database. They are never exported, integrated into advertising platforms, or analyzed outside internal fulfillment logs.
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
