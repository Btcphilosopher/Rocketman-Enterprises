/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { ShoppingBag, Heart, Trash, X, ArrowRight, ShieldCheck, AlertTriangle } from "lucide-react";
import AgeVerification from "./components/AgeVerification";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import ProductsList from "./components/ProductsList";
import CheckoutFlow from "./components/CheckoutFlow";
import Dashboard from "./components/Dashboard";
import ApiDocs from "./components/ApiDocs";
import DatabaseSchemaView from "./components/DatabaseSchemaView";
import DeploymentDocs from "./components/DeploymentDocs";
import { Product, Order, SupportTicket, MediaItem, AuditLog, Coupon } from "./types";

export default function App() {
  // Compliance verification gate
  const [verifiedAge, setVerifiedAge] = useState(false);
  const [jurisdiction, setJurisdiction] = useState("US");
  const [ageLimit, setAgeLimit] = useState("21");

  // Global Sync States from full-stack Express server
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [media, setMedia] = useState<MediaItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [settings, setSettings] = useState<any>(null);

  // Client shopping states
  const [currentTab, setCurrentTab] = useState("shop");
  const [cart, setCart] = useState<Array<{ product: Product; quantity: number }>>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Sync data from Express API
  const refreshAllData = async () => {
    try {
      const pRes = await fetch("/api/products");
      const oRes = await fetch("/api/orders");
      const tRes = await fetch("/api/tickets");
      const mRes = await fetch("/api/media");
      const lRes = await fetch("/api/audit-logs");
      const cRes = await fetch("/api/coupons");
      const sRes = await fetch("/api/settings");

      if (pRes.ok) setProducts(await pRes.json());
      if (oRes.ok) setOrders(await oRes.json());
      if (tRes.ok) setTickets(await tRes.json());
      if (mRes.ok) setMedia(await mRes.json());
      if (lRes.ok) setAuditLogs(await lRes.json());
      if (cRes.ok) setCoupons(await cRes.json());
      if (sRes.ok) setSettings(await sRes.json());
    } catch (e) {
      console.warn("Failed to fetch full-stack server endpoints. Running in memory fallback:", e);
    }
  };

  useEffect(() => {
    // Check local session age verification
    const verified = sessionStorage.getItem("tml_verified_age") === "true";
    if (verified) {
      setVerifiedAge(true);
      setJurisdiction(sessionStorage.getItem("tml_user_jurisdiction") || "US");
      setAgeLimit(sessionStorage.getItem("tml_user_age_limit") || "21");
    }

    refreshAllData();
  }, []);

  // Handle Cart interactions
  const handleAddToCart = (product: Product) => {
    setCart(prev => {
      const index = prev.findIndex(item => item.product.id === product.id);
      if (index > -1) {
        const updated = [...prev];
        updated[index].quantity += 1;
        return updated;
      }
      return [...prev, { product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const handleUpdateCartQty = (productId: string, delta: number) => {
    setCart(prev => {
      return prev.map(item => {
        if (item.product.id === productId) {
          const nextQty = Math.max(1, item.quantity + delta);
          return { ...item, quantity: nextQty };
        }
        return item;
      });
    });
  };

  // Handle Wishlist interactions
  const handleAddToWishlist = (product: Product) => {
    setWishlist(prev => {
      const exists = prev.some(p => p.id === product.id);
      if (exists) {
        return prev.filter(p => p.id !== product.id); // Toggle off
      }
      return [...prev, product];
    });
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + (item.product.salePrice || item.product.price) * item.quantity, 0);

  const handleTriggerCheckoutFromCart = () => {
    setIsCartOpen(false);
    setActiveOrder(null);
    setCurrentTab("checkout");
  };

  const handleOrderComplete = (order: Order) => {
    setActiveOrder(order);
    refreshAllData();
  };

  return (
    <div className="min-h-screen bg-[#FAF9F5] flex flex-col justify-between font-sans selection:bg-[#121216] selection:text-[#FAF9F5]">
      {/* 1. COMPLIANT MANDATORY AGE GATE OVERLAY */}
      {!verifiedAge && (
        <AgeVerification
          requiredAge={settings?.legalAgeLimit ?? 21}
          onVerify={() => {
            setVerifiedAge(true);
            setJurisdiction(sessionStorage.getItem("tml_user_jurisdiction") || "US");
            setAgeLimit(sessionStorage.getItem("tml_user_age_limit") || "21");
          }}
        />
      )}

      {/* 2. CORE SYSTEM HEADER */}
      <Navbar
        currentTab={currentTab}
        onChangeTab={(tab) => {
          setCurrentTab(tab);
          // Auto-scroll to catalog list if clicked on Catalog from Homepage
          if (tab === "shop") {
            window.scrollTo({ top: 0, behavior: "smooth" });
          }
        }}
        cartCount={cartCount}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        userAgeLimit={ageLimit}
        userJurisdiction={jurisdiction}
      />

      {/* 3. SCENE CONTAINER */}
      <main className="flex-grow">
        {/* TAB: SHOP (Landing Home + Catalog Grid) */}
        {currentTab === "shop" && (
          <div className="animate-fade-in">
            {/* Show landing showcase hero, scrolling to catalog on action */}
            <Hero
              onScrollToCatalog={() => {
                const catalogEl = document.getElementById("shop-catalog-view");
                if (catalogEl) {
                  catalogEl.scrollIntoView({ behavior: "smooth" });
                }
              }}
              onSelectCategory={(catName) => {
                const catalogEl = document.getElementById("shop-catalog-view");
                if (catalogEl) {
                  catalogEl.scrollIntoView({ behavior: "smooth" });
                }
              }}
            />
            {/* Enterprise products grid with filters and search */}
            <ProductsList
              products={products}
              onAddToCart={handleAddToCart}
              onAddToWishlist={handleAddToWishlist}
              wishlistIds={wishlist.map(p => p.id)}
            />
          </div>
        )}

        {/* TAB: SELLER CONSOLE (Dashboard) */}
        {currentTab === "dashboard" && (
          <div className="animate-fade-in">
            <Dashboard
              products={products}
              orders={orders}
              tickets={tickets}
              media={media}
              auditLogs={auditLogs}
              onRefreshAllData={refreshAllData}
              taxRatePercent={settings?.taxRatePercent ?? 8}
              flatShippingCostUsd={settings?.flatShippingCostUsd ?? 15}
              bitcoinWalletAddress={settings?.bitcoinWalletAddress ?? "1MLK7sz6Wp1b9tXz8y8P3r82gR9gD9N7k8"}
              usdtTrc20WalletAddress={settings?.usdtTrc20WalletAddress ?? "TYG1vX8S7R2j89P3r82gR9gD9N7k8Z7H5M"}
              blockConfirmationsRequired={settings?.blockConfirmationsRequired ?? 1}
              legalAgeLimit={settings?.legalAgeLimit ?? 21}
            />
          </div>
        )}

        {/* TAB: REST API PORTAL */}
        {currentTab === "api-docs" && (
          <div className="animate-fade-in">
            <ApiDocs />
          </div>
        )}

        {/* TAB: POSTGRES SCHEMAS */}
        {currentTab === "db-schema" && (
          <div className="animate-fade-in">
            <DatabaseSchemaView />
          </div>
        )}

        {/* TAB: DEPLOYMENT STACK */}
        {currentTab === "deployment" && (
          <div className="animate-fade-in">
            <DeploymentDocs />
          </div>
        )}

        {/* TAB: CHECKOUT FUNNEL */}
        {currentTab === "checkout" && (
          <div className="animate-fade-in">
            <CheckoutFlow
              cart={cart}
              onClearCart={handleClearCart}
              taxRatePercent={settings?.taxRatePercent ?? 8}
              flatShippingCostUsd={settings?.flatShippingCostUsd ?? 15}
              bitcoinWalletAddress={settings?.bitcoinWalletAddress ?? "1MLK7sz6Wp1b9tXz8y8P3r82gR9gD9N7k8"}
              usdtTrc20WalletAddress={settings?.usdtTrc20WalletAddress ?? "TYG1vX8S7R2j89P3r82gR9gD9N7k8Z7H5M"}
              onOrderCreated={handleOrderComplete}
              activeOrder={activeOrder}
              onCloseCheckout={() => {
                setCurrentTab("shop");
              }}
              coupons={coupons}
            />
          </div>
        )}

        {/* TAB: WISHLIST VIEW */}
        {currentTab === "wishlist" && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 animate-fade-in text-[#121216]">
            <div className="border-b border-[#ECEAE2] pb-6 mb-10">
              <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SAVED IN-MEMORY ITEMS</span>
              <h2 className="text-3xl font-bold tracking-tight uppercase">Your Private Wishlist</h2>
            </div>

            {wishlist.length === 0 ? (
              <div className="border border-[#ECEAE2] bg-white text-center py-20">
                <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase block mb-3">0 WISHLIST SAVES</span>
                <h3 className="text-lg font-bold uppercase mb-2">No Curated Choices</h3>
                <p className="text-xs text-[#696758] max-w-sm mx-auto mb-6">Explore our tobacco leaf collections and tap the heart icon to save products here.</p>
                <button
                  onClick={() => setCurrentTab("shop")}
                  className="bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest px-6 py-3 transition-colors"
                >
                  Return to Portfolio
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {wishlist.map(p => (
                  <div key={p.id} className="border border-[#ECEAE2] bg-white p-4 flex flex-col justify-between">
                    <div>
                      <div className="w-full h-48 bg-[#FAF9F5] overflow-hidden mb-4 relative">
                        <img src={p.image} alt={p.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                      <div className="space-y-1 mb-6">
                        <span className="font-mono text-[9px] tracking-widest text-[#787664] uppercase block">{p.brand}</span>
                        <h3 className="text-sm font-bold uppercase tracking-tight">{p.name}</h3>
                        <p className="text-xs text-[#696758] line-clamp-2 leading-relaxed">{p.shortDescription}</p>
                      </div>
                    </div>
                    <div className="pt-4 border-t border-[#FAF9F5] flex justify-between items-center gap-3">
                      <span className="font-mono text-sm font-bold">${(p.salePrice || p.price).toFixed(2)} USD</span>
                      <div className="flex gap-2">
                        <button
                          onClick={() => handleAddToWishlist(p)}
                          className="p-2 border border-[#ECEAE2] hover:bg-rose-50 hover:text-rose-700 transition-colors"
                          title="Remove from saved"
                        >
                          <Trash className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleAddToCart(p)}
                          className="bg-[#121216] hover:bg-black text-white font-mono text-xs uppercase tracking-wider px-4 py-2"
                        >
                          Buy Direct
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB: HELP & COMPLIANCE RULES */}
        {currentTab === "help" && (
          <div className="max-w-4xl mx-auto px-4 py-12 animate-fade-in text-[#121216]">
            <div className="border-b border-[#ECEAE2] pb-6 mb-10">
              <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SOVEREIGN FAQ & COVENANTS</span>
              <h2 className="text-3xl font-bold tracking-tight uppercase">Merchant Guidelines & Help</h2>
            </div>

            <div className="space-y-8 text-xs leading-relaxed font-sans text-[#525043]">
              <div className="border border-[#ECEAE2] bg-white p-6 space-y-3">
                <h3 className="font-mono text-sm font-bold uppercase text-[#121216] border-b border-[#FAF9F5] pb-2">1. Secure Insulated Shipping</h3>
                <p>
                  To preserve optimal relative humidity (RH) thresholds, all hand-rolled cigars are sealed inside 2-mil vacuum airtight dispatches equipped with 72-hour 69% Boveda moisture packs. Shipping fees are a flat $15.00 globally, waived automatically for all order invoices exceeding $150.00 USD.
                </p>
              </div>

              <div className="border border-[#ECEAE2] bg-white p-6 space-y-3">
                <h3 className="font-mono text-sm font-bold uppercase text-[#121216] border-b border-[#FAF9F5] pb-2">2. Tobacco Compliance Covenant</h3>
                <p>
                  Our merchant is strictly prohibited from shipping tobacco items to minor customers. We enforce a robust, legally validated age-gating framework at session creation and cross-reference buyer metadata before clearing physical warehouse dispatches. Under US federal guidelines, customers must be 21+ years of age. CA/KR demands 19+, EU requires 18+.
                </p>
              </div>

              <div className="border border-[#ECEAE2] bg-white p-6 space-y-3">
                <h3 className="font-mono text-sm font-bold uppercase text-[#121216] border-b border-[#FAF9F5] pb-2">3. Delisting, Relisting & Refund Policy</h3>
                <p>
                  Due to compliance mandates concerning organic agricultural commodities, all direct sales are final. If an ordered item is allocated out of stock or cancelled prior to packing, a direct on-chain manual refund is processed back to the originating wallet address within 12 block confirmations.
                </p>
              </div>

              <div className="border border-[#ECEAE2] bg-white p-6 space-y-3">
                <h3 className="font-mono text-sm font-bold uppercase text-[#121216] border-b border-[#FAF9F5] pb-2">4. Support Ticket Protocol</h3>
                <p>
                  If you encounter calibration faults on humidors or want to schedule box drops, you can dispatch a ticket directly from the Admin console ticket simulator or contact our core node team via dispatches.
                </p>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* 4. SHOPPING CART POPUP DRAWER */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-sans text-[#121216]" aria-labelledby="cart-drawer-title" role="dialog" aria-modal="true">
          <div className="absolute inset-0 overflow-hidden">
            <div onClick={() => setIsCartOpen(false)} className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity" aria-hidden="true"></div>

            <div className="pointer-events-none fixed inset-y-0 right-0 flex max-w-full pl-10">
              <div className="pointer-events-auto w-screen max-w-md border-l border-[#ECEAE2] bg-[#FAF9F5] shadow-2xl flex flex-col justify-between">
                <div className="flex h-full flex-col overflow-y-scroll py-6">
                  {/* Header */}
                  <div className="px-6 border-b border-[#ECEAE2] pb-6 flex items-center justify-between">
                    <div>
                      <span className="font-mono text-[10px] tracking-widest text-[#787664] uppercase font-bold block mb-1">SECURE ALLOCATION DRAWER</span>
                      <h2 className="text-lg font-bold uppercase tracking-tight flex items-center gap-2">
                        <ShoppingBag className="w-5 h-5 text-black" /> Your Cart ({cartCount})
                      </h2>
                    </div>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="p-2 hover:bg-[#ECEAE2] text-[#696758] hover:text-black transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Cart Items List */}
                  <div className="flex-grow px-6 py-6 overflow-y-auto space-y-4">
                    {cart.length === 0 ? (
                      <div className="h-full flex flex-col items-center justify-center text-center text-xs font-mono text-[#787664] space-y-4">
                        <span>Your secured allocation is empty.</span>
                        <button
                          onClick={() => setIsCartOpen(false)}
                          className="border border-[#ECEAE2] px-4 py-2 hover:bg-[#EAE8DE]/40 text-[#121216] transition-colors"
                        >
                          Return to Browse
                        </button>
                      </div>
                    ) : (
                      <div className="divide-y divide-[#ECEAE2]/40">
                        {cart.map((item) => (
                          <div key={item.product.id} className="py-4 flex gap-4 text-xs font-mono">
                            <div className="w-16 h-16 bg-[#FAF9F5] border border-[#ECEAE2] overflow-hidden shrink-0">
                              <img src={item.product.image} alt={item.product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            </div>
                            <div className="flex-grow space-y-1">
                              <span className="font-bold text-black uppercase block truncate max-w-[200px]">{item.product.name}</span>
                              <span className="text-[#787664] text-[10px] block">{item.product.sku}</span>
                              
                              {/* Quantity selectors */}
                              <div className="flex items-center gap-2 pt-1">
                                <button
                                  onClick={() => handleUpdateCartQty(item.product.id, -1)}
                                  className="w-5 h-5 border border-[#ECEAE2] flex items-center justify-center hover:bg-[#EAE8DE]"
                                >
                                  -
                                </button>
                                <span className="font-bold text-black w-6 text-center">{item.quantity}</span>
                                <button
                                  onClick={() => handleUpdateCartQty(item.product.id, 1)}
                                  className="w-5 h-5 border border-[#ECEAE2] flex items-center justify-center hover:bg-[#EAE8DE]"
                                >
                                  +
                                </button>
                              </div>
                            </div>

                            <div className="text-right flex flex-col justify-between shrink-0">
                              <span className="font-bold text-black">
                                ${((item.product.salePrice || item.product.price) * item.quantity).toFixed(2)}
                              </span>
                              <button
                                onClick={() => handleRemoveFromCart(item.product.id)}
                                className="text-red-700 hover:underline text-[10px]"
                              >
                                Remove
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Foot total calculations */}
                  {cart.length > 0 && (
                    <div className="px-6 border-t border-[#ECEAE2] pt-6 bg-white shrink-0 space-y-4">
                      <div className="flex justify-between items-baseline font-mono text-xs">
                        <span className="text-[#787664] uppercase">Secure Allocation Total:</span>
                        <span className="text-lg font-bold text-black">${cartTotal.toFixed(2)} USD</span>
                      </div>
                      <p className="font-sans text-[11px] text-[#696758] leading-relaxed">
                        Taxes, insulated shipping options, and cryptographic coupons are computed on the next screen. Stocks are allocated upon broadcast.
                      </p>
                      <button
                        onClick={handleTriggerCheckoutFromCart}
                        className="w-full bg-[#121216] hover:bg-black text-[#FAF9F5] font-mono text-xs uppercase tracking-widest py-4 transition-colors font-bold text-center flex items-center justify-center gap-2"
                      >
                        Proceed to Checkout
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. FOOTER */}
      <footer id="app-footer" className="bg-[#FAF9F5] border-t border-[#ECEAE2] py-12 text-[#121216]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4 col-span-1 md:col-span-2">
            <h4 className="font-mono text-xs font-bold uppercase tracking-widest text-[#121216]">THE MERCHANT'S LEAF</h4>
            <p className="text-xs text-[#696758] max-w-sm leading-relaxed font-sans">
              An independent, self-hosted enterprise platform curated for adult collectors. We supply premium single-origin cigars, pipe blends, and plinth brass humidor containers globally under secure cryptographic payment networks.
            </p>
            <div className="font-mono text-[9px] text-[#A3A3A3] uppercase">
              REVISION: TML_ENTERPRISE_1.04.4 • COMPILED SECURELY
            </div>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <h4 className="font-bold uppercase tracking-wider text-[#121216]">Sovereign Portals</h4>
            <div className="flex flex-col space-y-2">
              <button onClick={() => setCurrentTab("shop")} className="text-left text-[#696758] hover:text-black">Catalog</button>
              <button onClick={() => setCurrentTab("dashboard")} className="text-left text-[#696758] hover:text-black">Seller Dashboard</button>
              <button onClick={() => setCurrentTab("api-docs")} className="text-left text-[#696758] hover:text-black">REST API Portal</button>
              <button onClick={() => setCurrentTab("db-schema")} className="text-left text-[#696758] hover:text-black">PostgreSQL Schema</button>
            </div>
          </div>

          <div className="space-y-3 font-mono text-xs">
            <h4 className="font-bold uppercase tracking-wider text-[#121216]">Legal & Compliance</h4>
            <div className="flex flex-col space-y-2 text-[#696758]">
              <button onClick={() => setCurrentTab("help")} className="text-left hover:text-black">Terms of Covenant</button>
              <button onClick={() => setCurrentTab("help")} className="text-left hover:text-black">Privacy Isolation</button>
              <button onClick={() => setCurrentTab("help")} className="text-left hover:text-black">Fulfillment Rules</button>
              <span className="text-[#A3A3A3]">AGE GATE: REQUIRED</span>
            </div>
          </div>
        </div>

        {/* Surgeon General warning margin bar */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-6 border-t border-[#ECEAE2] text-center">
          <p className="text-[10px] font-mono uppercase tracking-[0.15em] text-[#787664] leading-relaxed max-w-4xl mx-auto font-semibold">
            SURGEON GENERAL'S WARNING: Tobacco Use Increases The Risk Of Lung Cancer, Heart Disease, Emphysema, And May Complicate Pregnancy. Sales Strictly Limited To Adults Over {ageLimit} Years.
          </p>
        </div>
      </footer>
    </div>
  );
}
