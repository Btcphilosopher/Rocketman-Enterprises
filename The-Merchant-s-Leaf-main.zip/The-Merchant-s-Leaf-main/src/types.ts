/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  category: string;
  tags: string[];
  price: number;
  salePrice: number | null;
  quantityAvailable: number;
  shortDescription: string;
  fullDescription: string; // supports Markdown
  image: string;
  images: string[];
  videoUrl: string | null;
  pdfGuides: Array<{ name: string; url: string }>;
  status: 'Draft' | 'Published' | 'Hidden' | 'Out of Stock' | 'Archived';
  scheduledDate: string | null;
  created_at: string;
}

export type OrderStatus =
  | 'Awaiting Payment'
  | 'Payment Received'
  | 'Processing'
  | 'Packed'
  | 'Shipped'
  | 'Delivered'
  | 'Cancelled'
  | 'Refunded'
  | 'Archived';

export interface OrderItem {
  productId: string;
  name: string;
  sku: string;
  price: number;
  quantity: number;
}

export interface CryptoTransaction {
  currency: 'BTC' | 'USDT';
  network: string; // e.g. "Mainnet" for BTC, "TRC-20" or "ERC-20" for USDT
  address: string;
  amountCrypto: number;
  rateUsd: number;
  txHash: string | null;
  countdownMinutes: number;
  secondsRemaining: number;
  logs: string[];
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  items: OrderItem[];
  subtotal: number;
  discountCode: string | null;
  discountAmount: number;
  tax: number;
  shippingCost: number;
  total: number;
  paymentMethod: 'Crypto_BTC' | 'Crypto_USDT' | 'Credit_Card_Simulated';
  cryptoTransaction: CryptoTransaction | null;
  status: OrderStatus;
  created_at: string;
  notes?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  joined: string;
  ordersCount: number;
  totalSpent: number;
  twoFactorEnabled: boolean;
  addresses: Array<{
    id: string;
    label: string;
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
    isDefault: boolean;
  }>;
}

export interface SupportTicket {
  id: string;
  orderId?: string;
  customerName: string;
  customerEmail: string;
  subject: string;
  message: string;
  status: 'Open' | 'In Progress' | 'Resolved' | 'Closed';
  created_at: string;
  messages: Array<{
    sender: 'customer' | 'support';
    text: string;
    timestamp: string;
  }>;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  folder: string; // e.g. "Products", "Banners", "Accessories"
  size: string;
  dimensions: string;
  type: string;
  webpOptimized: boolean;
}

export interface Coupon {
  code: string;
  discountPercent: number;
  active: boolean;
  minSpend: number;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  category: 'Products' | 'Orders' | 'Security' | 'Payments' | 'System';
  details: string;
  ipAddress: string;
}

export interface SchemaTable {
  name: string;
  description: string;
  columns: Array<{
    name: string;
    type: string;
    nullable: boolean;
    primaryKey: boolean;
    foreignKey?: { table: string; column: string };
    description: string;
  }>;
}
