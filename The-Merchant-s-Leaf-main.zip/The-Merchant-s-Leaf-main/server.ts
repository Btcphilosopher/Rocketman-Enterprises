import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const DB_PATH = path.join(process.cwd(), "db.json");

app.use(express.json());

// Default database state
const DEFAULT_PRODUCTS = [
  {
    id: "prod-1",
    sku: "TML-CIG-01",
    name: "The Obsidian Robusto",
    brand: "Ebon & Ash",
    category: "Hand-Rolled Cigars",
    tags: ["Bold", "Nicaraguan", "Maduro"],
    price: 38.00,
    salePrice: null,
    quantityAvailable: 150,
    shortDescription: "A bold, dark-wrapped Nicaraguan robusto with tasting notes of cedar, toasted leather, and espresso.",
    fullDescription: "### The Obsidian Robusto\n\nCrafted in the Estelí region of Nicaragua, **The Obsidian** is a testament to architectural smoke design. It utilizes a triple-fermented San Andrés Maduro wrapper over double-ligero long-fillers.\n\n#### Taste Profile\n- **First Third**: Peppery cedar, heavy cocoa.\n- **Second Third**: Roasted espresso bean, dark earth.\n- **Final Third**: Rich black pepper, leather, and a dark syrup sweetness.\n\n#### Specifications\n* **Vitola**: Robusto (5\" x 52)\n* **Body**: Full\n* **Strength**: High\n* **Wrapper**: San Andrés Maduro\n* **Origin**: Nicaragua",
    image: "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80",
      "https://images.unsplash.com/photo-1502472591330-c44182448534?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: "https://www.w3schools.com/html/mov_bbb.mp4",
    pdfGuides: [
      { name: "Caring for Maduro Wrapper.pdf", url: "#" },
      { name: "Tasting Guide.pdf", url: "#" }
    ],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-01-10").toISOString()
  },
  {
    id: "prod-2",
    sku: "TML-CIG-02",
    name: "The Ivory Crown Lancero",
    brand: "Ebon & Ash",
    category: "Hand-Rolled Cigars",
    tags: ["Mellow", "Connecticut", "Creamy"],
    price: 45.00,
    salePrice: 39.00,
    quantityAvailable: 85,
    shortDescription: "A slender, elegant Lancero cigar wrapped in an flawless Ecuadorian Connecticut shade leaf.",
    fullDescription: "### The Ivory Crown Lancero\n\nA visual masterpiece measuring a magnificent 7.5 inches. The Lancero is the ultimate test of a roller's skill. The Ivory Crown burns with mathematical precision, delivering rich oils and balanced aromatics.\n\n#### Taste Profile\n- **First Third**: Toasted cashew, dry grass.\n- **Second Third**: Sweet cream, vanilla bean.\n- **Final Third**: White pepper, almond, buttery pastry.\n\n#### Specifications\n* **Vitola**: Lancero (7.5\" x 38)\n* **Body**: Mellow-Medium\n* **Strength**: Medium\n* **Wrapper**: Ecuadorian Connecticut Shade\n* **Origin**: Honduras",
    image: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: null,
    pdfGuides: [],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-02-15").toISOString()
  },
  {
    id: "prod-3",
    sku: "TML-PIP-01",
    name: "Merchant's No. 4 English Mixture",
    brand: "The Merchant's Leaf",
    category: "Pipe Tobaccos",
    tags: ["English", "Latakia", "Smokey"],
    price: 24.00,
    salePrice: null,
    quantityAvailable: 200,
    shortDescription: "A traditional full English mixture featuring smokey Cyprian Latakia, matured Virginia ribbons, and Oriental leaf.",
    fullDescription: "### Merchant's No. 4 English Mixture\n\nThe benchmark of our pipe tobacco range. **No. 4** is an authentic English blend blended for the refined palate. Matured Red Virginias provide a solid sugar-sweet foundation, while Cyprian Latakia infuses cool, campfire-like smoke.\n\n#### Components\n1. **Cyprian Latakia** (40%): Rich smoke and leather\n2. **Matured Virginia** (35%): Natural sweetness and fruit notes\n3. **Macedonian Oriental** (25%): Spiciness and floral bouquet\n\nPackaged in a vacuum-sealed 50g architectural tin.",
    image: "https://images.unsplash.com/photo-1614850523011-8f49fc9ee6fd?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1614850523011-8f49fc9ee6fd?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: null,
    pdfGuides: [
      { name: "Pipe Packing Techniques.pdf", url: "#" }
    ],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-03-01").toISOString()
  },
  {
    id: "prod-4",
    sku: "TML-PIP-02",
    name: "Monolith Black Cavendish",
    brand: "The Merchant's Leaf",
    category: "Pipe Tobaccos",
    tags: ["Aromatic", "Vanilla", "Burley"],
    price: 26.00,
    salePrice: null,
    quantityAvailable: 120,
    shortDescription: "Double-fermented dark air-cured Burley tobaccos, subtly flavored with premium cold-brew coffee extract and Madagascar vanilla.",
    fullDescription: "### Monolith Black Cavendish\n\nA luxurious aromatic blend built for room note elegance. We start with dark air-cured Kentucky Burleys, steam them with raw cane sugar, and apply two rounds of cold-pressing.\n\n- **Aroma**: Heavenly vanilla bean, fresh-baked biscuits, roasted mocha.\n- **Palate**: Velvet mouthfeel, low bite, dark honey finish.\n- **Cut**: Ribbon / Broad cut",
    image: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: null,
    pdfGuides: [],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-03-05").toISOString()
  },
  {
    id: "prod-5",
    sku: "TML-ACC-01",
    name: "Slab Brass Desktop Humidor",
    brand: "Plinth Design",
    category: "Accessories",
    tags: ["Premium", "Minimalist", "Storage"],
    price: 320.00,
    salePrice: null,
    quantityAvailable: 15,
    shortDescription: "An architectural solid brass humidor with Spanish Cedar lining and custom digital hygrometer.",
    fullDescription: "### Slab Brass Desktop Humidor\n\nDesigned by **Plinth Design**, this humidor is a heavy sculptural block representing industrial luxury.\n\n- **Material**: Seamless machined brass slab, bead-blasted and sealed.\n- **Interior**: 100% Solid Spanish Cedar drawers.\n- **Capacity**: Holds 40 to 50 Corona Gorda cigars.\n- **Equipped**: Custom integrated digital Bluetooth hygrometer flush-mounted to the interior crown lid.\n- **Weight**: 4.8 kg",
    image: "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: null,
    pdfGuides: [
      { name: "Humidor Seasoning Guide.pdf", url: "#" }
    ],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-04-01").toISOString()
  },
  {
    id: "prod-6",
    sku: "TML-ACC-02",
    name: "Anodized Monolith Cigar Cutter",
    brand: "Plinth Design",
    category: "Accessories",
    tags: ["Utility", "Titanium", "Surgical"],
    price: 85.00,
    salePrice: 75.00,
    quantityAvailable: 60,
    shortDescription: "A heavy-weight double guillotine cutter carved from aircraft-grade aerospace-anodized aluminium.",
    fullDescription: "### Anodized Monolith Cigar Cutter\n\nCut your cigars with absolute architectural confidence. Dual-spring guillotine action equipped with double 440C surgical-grade stainless steel blades hardened to 58 HRC.\n\n- **Housing**: Monolith body milled from solid 6061-T6 aluminum.\n- **Finishing**: Dark bead-blasted grey anodization.\n- **Aperture**: Cuts up to 60 ring-gauge cigars flawlessly.",
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: null,
    pdfGuides: [],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-04-10").toISOString()
  },
  {
    id: "prod-7",
    sku: "TML-GFT-01",
    name: "The Architect's Tasting Drawer",
    brand: "The Merchant's Leaf",
    category: "Gift Ideas",
    tags: ["Gift Set", "Luxury", "Starter"],
    price: 150.00,
    salePrice: null,
    quantityAvailable: 40,
    shortDescription: "A concrete-finished presentation box containing five robusto cigars, the Monolith cutter, and matches.",
    fullDescription: "### The Architect's Tasting Drawer\n\nThe quintessential gift for an architectural tobacco connoisseur.\n\n#### What's Included:\n* **3x** The Obsidian Robusto cigars\n* **2x** Vintage Dominican Crown Coronas\n* **1x** Plinth Design Anodized Monolith Cutter (Limited Gunmetal edition)\n* **1x** Architectural heavy concrete desktop matchbox with strike pads\n\nShips in an insulated magnetic presentation box with a 72-hour humidity pack.",
    image: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80",
    images: [
      "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=600&q=80"
    ],
    videoUrl: null,
    pdfGuides: [],
    status: "Published",
    scheduledDate: null,
    created_at: new Date("2026-04-12").toISOString()
  }
];

const DEFAULT_ORDERS = [
  {
    id: "ord-4921",
    customerName: "Alexander Gray",
    customerEmail: "alexander@grayarchitects.co",
    shippingAddress: {
      street: "455 Brutalist Boulevard",
      city: "Chicago",
      state: "IL",
      postalCode: "60601",
      country: "USA"
    },
    items: [
      {
        productId: "prod-1",
        name: "The Obsidian Robusto",
        sku: "TML-CIG-01",
        price: 38.00,
        quantity: 5
      },
      {
        productId: "prod-6",
        name: "Anodized Monolith Cigar Cutter",
        sku: "TML-ACC-02",
        price: 75.00,
        quantity: 1
      }
    ],
    subtotal: 265.00,
    discountCode: "HYPERMODERN",
    discountAmount: 26.50,
    tax: 19.08,
    shippingCost: 15.00,
    total: 272.58,
    paymentMethod: "Crypto_BTC",
    cryptoTransaction: {
      currency: "BTC",
      network: "Mainnet",
      address: "1MLK7sz6Wp1b9tXz8y8P3r82gR9gD9N7k8",
      amountCrypto: 0.00312,
      rateUsd: 87360,
      txHash: "f6b0f19c0de1d27f8a7cf3c1a82d0fb834e55e886cfc728cb1748256a099f18e",
      countdownMinutes: 0,
      secondsRemaining: 0,
      logs: [
        "2026-07-14T01:10:00Z: Transaction detected in mempool.",
        "2026-07-14T01:18:22Z: 1st Blockchain confirmation recorded. Threshold met (1/1)."
      ]
    },
    status: "Payment Received",
    created_at: "2026-07-14T01:05:00-07:00",
    notes: "Please pack with extra humidity sheets."
  },
  {
    id: "ord-4922",
    customerName: "Elena Vostok",
    customerEmail: "elena.v@vostokgallery.com",
    shippingAddress: {
      street: "77 Concrete Slab Sqr",
      city: "New York",
      state: "NY",
      postalCode: "10013",
      country: "USA"
    },
    items: [
      {
        productId: "prod-5",
        name: "Slab Brass Desktop Humidor",
        sku: "TML-ACC-01",
        price: 320.00,
        quantity: 1
      }
    ],
    subtotal: 320.00,
    discountCode: null,
    discountAmount: 0.00,
    tax: 25.60,
    shippingCost: 0.00,
    total: 345.60,
    paymentMethod: "Crypto_USDT",
    cryptoTransaction: {
      currency: "USDT",
      network: "TRC-20",
      address: "TYG1vX8S7R2j89P3r82gR9gD9N7k8Z7H5M",
      amountCrypto: 345.60,
      rateUsd: 1.00,
      txHash: "88fc312df59b2072efd297cb73a1efda39e6df7b293817361be92ee6499af723",
      countdownMinutes: 0,
      secondsRemaining: 0,
      logs: [
        "2026-07-13T22:45:11Z: USDT payment of 345.60 detected on TRC-20.",
        "2026-07-13T22:46:05Z: Confirmed 20/20 blocks. Payment completed."
      ]
    },
    status: "Shipped",
    created_at: "2026-07-13T22:40:00-07:00",
    notes: "Leave in building foyer if not present."
  }
];

const DEFAULT_TICKETS = [
  {
    id: "tkt-101",
    orderId: "ord-4921",
    customerName: "Alexander Gray",
    customerEmail: "alexander@grayarchitects.co",
    subject: "Hygrometer Calibration Inquiry",
    message: "Does the custom digital hygrometer in the Slab Brass Humidor require manual salt-calibration upon delivery, or is it factory-calibrated?",
    status: "In Progress",
    created_at: "2026-07-14T02:00:00-07:00",
    messages: [
      {
        sender: "customer",
        text: "Does the custom digital hygrometer in the Slab Brass Humidor require manual salt-calibration upon delivery, or is it factory-calibrated?",
        timestamp: "2026-07-14T02:00:00-07:00"
      },
      {
        sender: "support",
        text: "Alexander, thank you for reaching out. The Slab Brass Desktop Humidor's digital hygrometer is factory-calibrated and stable. However, we provide custom instructions in the guide if you wish to run a 75% Boveda test. I am attaching our PDF instruction card to your order record.",
        timestamp: "2026-07-14T03:30:00-07:00"
      }
    ]
  },
  {
    id: "tkt-102",
    customerName: "Julian Vance",
    customerEmail: "jv@vanceindustrial.org",
    subject: "Restocking of Ivory Crown Lancero",
    message: "When will the Ivory Crown Lancero be fully restocked? I want to order 5 boxes for our corporate summit next month.",
    status: "Open",
    created_at: "2026-07-14T05:12:00-07:00",
    messages: [
      {
        sender: "customer",
        text: "When will the Ivory Crown Lancero be fully restocked? I want to order 5 boxes for our corporate summit next month.",
        timestamp: "2026-07-14T05:12:00-07:00"
      }
    ]
  }
];

const DEFAULT_COUPONS = [
  { code: "HYPERMODERN", discountPercent: 10, active: true, minSpend: 100 },
  { code: "LEAF20", discountPercent: 20, active: true, minSpend: 250 },
  { code: "BTCWELCOME", discountPercent: 5, active: true, minSpend: 0 }
];

const DEFAULT_MEDIA = [
  {
    id: "img-1",
    name: "obsidian_robusto.png",
    url: "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80",
    folder: "Products",
    size: "185 KB",
    dimensions: "1200 x 800",
    type: "image/png",
    webpOptimized: true
  },
  {
    id: "img-2",
    name: "ivory_lancero.png",
    url: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=600&q=80",
    folder: "Products",
    size: "142 KB",
    dimensions: "1200 x 800",
    type: "image/png",
    webpOptimized: true
  },
  {
    id: "img-3",
    name: "merchants_english.png",
    url: "https://images.unsplash.com/photo-1614850523011-8f49fc9ee6fd?auto=format&fit=crop&w=600&q=80",
    folder: "Products",
    size: "210 KB",
    dimensions: "1000 x 1000",
    type: "image/png",
    webpOptimized: true
  }
];

const DEFAULT_AUDIT_LOGS = [
  {
    id: "log-1",
    timestamp: "2026-07-14T07:00:00-07:00",
    actor: "Admin (tom@ahyx.org)",
    action: "Updated Stock levels (TML-CIG-02) to 85",
    category: "Products",
    details: "Manual inventory adjustment from 80 to 85.",
    ipAddress: "192.168.1.100"
  },
  {
    id: "log-2",
    timestamp: "2026-07-14T06:15:00-07:00",
    actor: "System Scheduler",
    action: "Pre-published 2 scheduled products",
    category: "System",
    details: "Validated sitemaps and crawled scheduled posts.",
    ipAddress: "localhost"
  },
  {
    id: "log-3",
    timestamp: "2026-07-14T01:18:22-07:00",
    actor: "BTC Hot Node Webhook",
    action: "Order ord-4921 payment detection",
    category: "Payments",
    details: "Mempool state transaction fully verified with 1 confirmation.",
    ipAddress: "127.0.0.1"
  }
];

const DEFAULT_SETTINGS = {
  storeName: "The Merchant's Leaf",
  legalAgeLimit: 21,
  taxRatePercent: 8,
  flatShippingCostUsd: 15,
  bitcoinWalletAddress: "1MLK7sz6Wp1b9tXz8y8P3r82gR9gD9N7k8",
  usdtTrc20WalletAddress: "TYG1vX8S7R2j89P3r82gR9gD9N7k8Z7H5M",
  automaticPaymentDetection: true,
  blockConfirmationsRequired: 1,
  rateLimitPerMin: 60,
  rateLimitStatus: "Enabled",
  csrfStatus: "Active",
  backupIntervalHours: 24,
  lastBackupTime: "2026-07-14T00:00:00-07:00"
};

// Database state container
let db = {
  products: [...DEFAULT_PRODUCTS],
  orders: [...DEFAULT_ORDERS],
  tickets: [...DEFAULT_TICKETS],
  coupons: [...DEFAULT_COUPONS],
  media: [...DEFAULT_MEDIA],
  auditLogs: [...DEFAULT_AUDIT_LOGS],
  settings: { ...DEFAULT_SETTINGS }
};

// Load database from file if exists, otherwise write defaults
function initDb() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const content = fs.readFileSync(DB_PATH, "utf-8");
      db = JSON.parse(content);
      console.log("Database successfully loaded from", DB_PATH);
    } else {
      fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
      console.log("Database initialized and saved to", DB_PATH);
    }
  } catch (error) {
    console.error("Failed to read/write local db.json, running in memory:", error);
  }
}

function saveDb() {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  } catch (error) {
    console.error("Failed to write to db.json:", error);
  }
}

initDb();

// Helper to push Audit Logs
function addAuditLog(actor: string, action: string, category: 'Products' | 'Orders' | 'Security' | 'Payments' | 'System', details: string, ip: string = "127.0.0.1") {
  const newLog = {
    id: "log-" + Math.floor(Math.random() * 100000),
    timestamp: new Date().toISOString(),
    actor,
    action,
    category,
    details,
    ipAddress: ip
  };
  db.auditLogs.unshift(newLog);
  if (db.auditLogs.length > 100) db.auditLogs.pop(); // keep last 100
  saveDb();
}

// REST API routes FIRST
app.get("/api/products", (req, res) => {
  res.json(db.products);
});

app.post("/api/products", (req, res) => {
  const newProduct = {
    id: "prod-" + Math.floor(Math.random() * 100000),
    sku: req.body.sku || ("TML-CIG-" + Math.floor(Math.random() * 1000)),
    name: req.body.name || "Unnamed Product",
    brand: req.body.brand || "Independent",
    category: req.body.category || "Uncategorized",
    tags: req.body.tags || [],
    price: Number(req.body.price) || 0,
    salePrice: req.body.salePrice ? Number(req.body.salePrice) : null,
    quantityAvailable: Number(req.body.quantityAvailable) || 0,
    shortDescription: req.body.shortDescription || "",
    fullDescription: req.body.fullDescription || "",
    image: req.body.image || "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80",
    images: req.body.images || [req.body.image || "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80"],
    videoUrl: req.body.videoUrl || null,
    pdfGuides: req.body.pdfGuides || [],
    status: req.body.status || "Draft",
    scheduledDate: req.body.scheduledDate || null,
    created_at: new Date().toISOString()
  };
  db.products.unshift(newProduct);
  addAuditLog("Admin (tom@ahyx.org)", `Created product "${newProduct.name}"`, "Products", `SKU: ${newProduct.sku}, Price: $${newProduct.price}`);
  saveDb();
  res.status(201).json(newProduct);
});

app.put("/api/products/:id", (req, res) => {
  const index = db.products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }
  db.products[index] = {
    ...db.products[index],
    ...req.body,
    id: req.params.id // ensure ID is unchanged
  };
  addAuditLog("Admin (tom@ahyx.org)", `Updated product "${db.products[index].name}"`, "Products", `Modified fields: ${Object.keys(req.body).join(", ")}`);
  saveDb();
  res.json(db.products[index]);
});

app.delete("/api/products/:id", (req, res) => {
  const index = db.products.findIndex(p => p.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }
  const deleted = db.products[index];
  db.products.splice(index, 1);
  addAuditLog("Admin (tom@ahyx.org)", `Deleted product "${deleted.name}"`, "Products", `SKU was: ${deleted.sku}`);
  saveDb();
  res.json({ success: true, deletedId: req.params.id });
});

// Bulk products import
app.post("/api/products/bulk-import", (req, res) => {
  const csvText = req.body.csv || "";
  const lines = csvText.split("\n");
  if (lines.length < 2) {
    return res.status(400).json({ error: "Invalid CSV. Needs at least a header row and one data row." });
  }
  // Simplified CSV parser
  const headers = lines[0].split(",").map((h: string) => h.trim().replace(/"/g, ''));
  let importedCount = 0;
  
  for (let i = 1; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    const values = line.split(",").map((v: string) => v.trim().replace(/"/g, ''));
    
    // Map headers to object
    const row: any = {};
    headers.forEach((header: string, idx: number) => {
      row[header] = values[idx] || "";
    });

    if (row.name) {
      const newProduct = {
        id: "prod-bulk-" + Math.floor(Math.random() * 100000),
        sku: row.sku || ("TML-BULK-" + Math.floor(Math.random() * 1000)),
        name: row.name,
        brand: row.brand || "The Merchant's Leaf",
        category: row.category || "Cigars",
        tags: row.tags ? row.tags.split("|") : ["Bulk"],
        price: Number(row.price) || 20,
        salePrice: row.salePrice ? Number(row.salePrice) : null,
        quantityAvailable: Number(row.quantityAvailable) || 50,
        shortDescription: row.shortDescription || row.name,
        fullDescription: row.fullDescription || row.name,
        image: "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80",
        images: ["https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80"],
        videoUrl: null,
        pdfGuides: [],
        status: "Draft",
        scheduledDate: null,
        created_at: new Date().toISOString()
      };
      db.products.unshift(newProduct);
      importedCount++;
    }
  }
  addAuditLog("Admin (tom@ahyx.org)", `Bulk imported ${importedCount} products`, "Products", `CSV Batch Size: ${lines.length} lines`);
  saveDb();
  res.json({ success: true, count: importedCount, products: db.products });
});

// Orders API
app.get("/api/orders", (req, res) => {
  res.json(db.orders);
});

app.post("/api/orders", (req, res) => {
  const { customerName, customerEmail, shippingAddress, items, subtotal, discountCode, discountAmount, tax, shippingCost, total, paymentMethod } = req.body;
  
  let cryptoTx = null;
  if (paymentMethod === 'Crypto_BTC' || paymentMethod === 'Crypto_USDT') {
    const isBTC = paymentMethod === 'Crypto_BTC';
    const rate = isBTC ? 87360 : 1.00;
    const addr = isBTC ? db.settings.bitcoinWalletAddress : db.settings.usdtTrc20WalletAddress;
    const coinAmt = Number((total / rate).toFixed(isBTC ? 6 : 2));
    
    cryptoTx = {
      currency: isBTC ? "BTC" : "USDT",
      network: isBTC ? "Mainnet" : "TRC-20",
      address: addr,
      amountCrypto: coinAmt,
      rateUsd: rate,
      txHash: null,
      countdownMinutes: 15,
      secondsRemaining: 900,
      logs: ["Awaiting user transaction on-chain."]
    };
  }

  const newOrder = {
    id: "ord-" + Math.floor(1000 + Math.random() * 9000),
    customerName,
    customerEmail,
    shippingAddress,
    items,
    subtotal: Number(subtotal) || 0,
    discountCode: discountCode || null,
    discountAmount: Number(discountAmount) || 0,
    tax: Number(tax) || 0,
    shippingCost: Number(shippingCost) || 0,
    total: Number(total) || 0,
    paymentMethod,
    cryptoTransaction: cryptoTx,
    status: (paymentMethod === 'Credit_Card_Simulated') ? 'Processing' : 'Awaiting Payment',
    created_at: new Date().toISOString(),
    notes: ""
  };

  db.orders.unshift(newOrder);
  
  // Deduct inventory
  newOrder.items.forEach((item: any) => {
    const product = db.products.find(p => p.sku === item.sku || p.id === item.productId);
    if (product) {
      product.quantityAvailable = Math.max(0, product.quantityAvailable - item.quantity);
    }
  });

  addAuditLog("Guest/Customer Checkout", `Created order ${newOrder.id}`, "Orders", `Total: $${newOrder.total} via ${paymentMethod}`);
  saveDb();
  res.status(201).json(newOrder);
});

app.put("/api/orders/:id", (req, res) => {
  const index = db.orders.findIndex(o => o.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Order not found" });
  }
  db.orders[index] = {
    ...db.orders[index],
    ...req.body
  };
  addAuditLog("Admin (tom@ahyx.org)", `Updated order status for ${req.params.id}`, "Orders", `New Status: ${db.orders[index].status}`);
  saveDb();
  res.json(db.orders[index]);
});

// Trigger a mock auto-payment detection for testing the payment simulator
app.post("/api/orders/:id/detect-payment", (req, res) => {
  const order = db.orders.find(o => o.id === req.params.id);
  if (!order || !order.cryptoTransaction) {
    return res.status(404).json({ error: "Crypto order not found" });
  }
  
  const txHash = "0x" + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join("");
  order.cryptoTransaction.txHash = txHash;
  order.cryptoTransaction.logs.push(`${new Date().toISOString()}: Payment of ${order.cryptoTransaction.amountCrypto} ${order.cryptoTransaction.currency} detected.`);
  order.cryptoTransaction.logs.push(`${new Date().toISOString()}: Block confirmations verified (1/${db.settings.blockConfirmationsRequired}).`);
  order.status = "Payment Received";
  
  addAuditLog("Block Node Webhook", `Auto-detected payment for order ${order.id}`, "Payments", `TxHash: ${txHash}`);
  saveDb();
  res.json({ success: true, order });
});

// Support Tickets API
app.get("/api/tickets", (req, res) => {
  res.json(db.tickets);
});

app.post("/api/tickets", (req, res) => {
  const newTicket = {
    id: "tkt-" + Math.floor(100 + Math.random() * 900),
    orderId: req.body.orderId || undefined,
    customerName: req.body.customerName || "Anonymous",
    customerEmail: req.body.customerEmail || "",
    subject: req.body.subject || "No Subject",
    message: req.body.message || "",
    status: "Open",
    created_at: new Date().toISOString(),
    messages: [
      {
        sender: "customer",
        text: req.body.message || "",
        timestamp: new Date().toISOString()
      }
    ]
  };
  db.tickets.unshift(newTicket);
  addAuditLog("Guest Customer", `Submitted support ticket ${newTicket.id}`, "System", `Subject: ${newTicket.subject}`);
  saveDb();
  res.status(201).json(newTicket);
});

app.put("/api/tickets/:id", (req, res) => {
  const index = db.tickets.findIndex(t => t.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ error: "Ticket not found" });
  }
  db.tickets[index] = {
    ...db.tickets[index],
    ...req.body
  };
  addAuditLog("Admin (tom@ahyx.org)", `Updated ticket ${req.params.id}`, "System", `Status: ${db.tickets[index].status}`);
  saveDb();
  res.json(db.tickets[index]);
});

app.post("/api/tickets/:id/message", (req, res) => {
  const ticket = db.tickets.find(t => t.id === req.params.id);
  if (!ticket) {
    return res.status(404).json({ error: "Ticket not found" });
  }
  const reply = {
    sender: req.body.sender || "support",
    text: req.body.text || "",
    timestamp: new Date().toISOString()
  };
  ticket.messages.push(reply);
  ticket.status = (req.body.sender === "support") ? "In Progress" : "Open";
  addAuditLog(req.body.sender === "support" ? "Support (tom@ahyx.org)" : "Customer", `Reply added on ticket ${ticket.id}`, "System", `Message length: ${reply.text.length} chars`);
  saveDb();
  res.json(ticket);
});

// Coupons API
app.get("/api/coupons", (req, res) => {
  res.json(db.coupons);
});

app.post("/api/coupons", (req, res) => {
  const newCoupon = {
    code: (req.body.code || "DISCOUNT").toUpperCase(),
    discountPercent: Number(req.body.discountPercent) || 10,
    active: req.body.active !== false,
    minSpend: Number(req.body.minSpend) || 0
  };
  db.coupons.push(newCoupon);
  addAuditLog("Admin (tom@ahyx.org)", `Created coupon "${newCoupon.code}"`, "System", `Discount: ${newCoupon.discountPercent}%`);
  saveDb();
  res.status(201).json(newCoupon);
});

// Settings API
app.get("/api/settings", (req, res) => {
  res.json(db.settings);
});

app.post("/api/settings", (req, res) => {
  db.settings = {
    ...db.settings,
    ...req.body
  };
  addAuditLog("Admin (tom@ahyx.org)", "Updated system configuration settings", "Security", "Modified settings values.");
  saveDb();
  res.json(db.settings);
});

// Media Library API
app.get("/api/media", (req, res) => {
  res.json(db.media);
});

app.post("/api/media", (req, res) => {
  const newMedia = {
    id: "img-" + Math.floor(Math.random() * 100000),
    name: req.body.name || "uploaded_file.webp",
    url: req.body.url || "https://images.unsplash.com/photo-1541256996761-85df2eff3139?auto=format&fit=crop&w=600&q=80",
    folder: req.body.folder || "Products",
    size: req.body.size || "120 KB",
    dimensions: req.body.dimensions || "1000 x 1000",
    type: req.body.type || "image/webp",
    webpOptimized: true
  };
  db.media.push(newMedia);
  addAuditLog("Admin (tom@ahyx.org)", `Uploaded media file "${newMedia.name}"`, "System", `Folder: ${newMedia.folder}, Size: ${newMedia.size}`);
  saveDb();
  res.status(201).json(newMedia);
});

// Audit Logs API
app.get("/api/audit-logs", (req, res) => {
  res.json(db.auditLogs);
});

// Analytics API
app.get("/api/analytics", (req, res) => {
  // Compute analytics dynamically
  const totalRevenue = db.orders
    .filter(o => o.status !== 'Cancelled' && o.status !== 'Refunded' && o.status !== 'Awaiting Payment')
    .reduce((sum, o) => sum + o.total, 0);
  
  const cryptoSalesCount = db.orders.filter(o => o.paymentMethod.startsWith('Crypto_')).length;
  const ccSalesCount = db.orders.filter(o => o.paymentMethod === 'Credit_Card_Simulated').length;

  res.json({
    totalRevenue: Number(totalRevenue.toFixed(2)),
    totalOrders: db.orders.length,
    activeProductsCount: db.products.filter(p => p.status === 'Published').length,
    pendingPaymentsCount: db.orders.filter(o => o.status === 'Awaiting Payment').length,
    paymentSplit: {
      crypto: cryptoSalesCount,
      creditCard: ccSalesCount
    },
    revenueHistory: [
      { date: "Jul 10", revenue: 450 },
      { date: "Jul 11", revenue: 890 },
      { date: "Jul 12", revenue: 320 },
      { date: "Jul 13", revenue: 1120 },
      { date: "Jul 14", revenue: totalRevenue > 0 ? Number(totalRevenue.toFixed(0)) : 272 }
    ],
    topSellingProducts: db.products.slice(0, 3).map(p => ({
      name: p.name,
      sku: p.sku,
      salesCount: Math.floor(Math.random() * 20) + 5,
      revenue: (p.salePrice || p.price) * (Math.floor(Math.random() * 20) + 5)
    }))
  });
});

// Database schema endpoint
app.get("/api/db-schemas", (req, res) => {
  const schemas = [
    {
      name: "products",
      description: "Tobacco products and stock details",
      columns: [
        { name: "id", type: "UUID (Primary Key)", nullable: false, description: "Unique identifier for product" },
        { name: "sku", type: "VARCHAR(50)", nullable: false, description: "Stock Keeping Unit, unique" },
        { name: "name", type: "VARCHAR(255)", nullable: false, description: "Product catalog name" },
        { name: "brand", type: "VARCHAR(100)", nullable: false, description: "Brand / Manufacturer name" },
        { name: "category", type: "VARCHAR(100)", nullable: false, description: "Catalog category (e.g. Cigars, Tobacco)" },
        { name: "price", type: "NUMERIC(10, 2)", nullable: false, description: "Standard pricing" },
        { name: "sale_price", type: "NUMERIC(10, 2)", nullable: true, description: "Promotional sale pricing" },
        { name: "quantity_available", type: "INTEGER", nullable: false, description: "In-stock inventory count" },
        { name: "short_description", type: "TEXT", nullable: true, description: "Summary text for shop grid" },
        { name: "full_description", type: "TEXT", nullable: true, description: "Product description (supports Markdown)" },
        { name: "status", type: "VARCHAR(30)", nullable: false, description: "Draft, Published, Hidden, Out of Stock, Archived" },
        { name: "scheduled_date", type: "TIMESTAMP", nullable: true, description: "Release scheduling date" }
      ]
    },
    {
      name: "orders",
      description: "Customer purchasing details",
      columns: [
        { name: "id", type: "VARCHAR(20) (Primary Key)", nullable: false, description: "Order code (e.g. ord-4921)" },
        { name: "customer_name", type: "VARCHAR(255)", nullable: false, description: "Recipient full name" },
        { name: "customer_email", type: "VARCHAR(255)", nullable: false, description: "Primary contact email" },
        { name: "subtotal", type: "NUMERIC(10,2)", nullable: false, description: "Sum of item costs" },
        { name: "tax", type: "NUMERIC(10,2)", nullable: false, description: "Calculated sales tax" },
        { name: "shipping_cost", type: "NUMERIC(10,2)", nullable: false, description: "Shipping cost applied" },
        { name: "total", type: "NUMERIC(10,2)", nullable: false, description: "Grand total" },
        { name: "payment_method", type: "VARCHAR(50)", nullable: false, description: "Crypto_BTC, Crypto_USDT, Credit_Card_Simulated" },
        { name: "status", type: "VARCHAR(30)", nullable: false, description: "Awaiting Payment, Payment Received, Processing, Packed, Shipped, Delivered, Cancelled, Refunded, Archived" },
        { name: "created_at", type: "TIMESTAMP WITH TIME ZONE", nullable: false, description: "Order submit time" }
      ]
    },
    {
      name: "cryptocurrency_transactions",
      description: "Logs blockchain payments for order validation",
      columns: [
        { name: "id", type: "UUID (Primary Key)", nullable: false, description: "Transaction unique tracking record id" },
        { name: "order_id", type: "VARCHAR(20)", nullable: false, description: "Linked order ID" },
        { name: "currency", type: "VARCHAR(10)", nullable: false, description: "BTC or USDT" },
        { name: "network", type: "VARCHAR(20)", nullable: false, description: "Mainnet, TRC-20, ERC-20" },
        { name: "address", type: "VARCHAR(100)", nullable: false, description: "Deposit wallet address" },
        { name: "amount_crypto", type: "NUMERIC(18,8)", nullable: false, description: "Exact crypto amount required" },
        { name: "rate_usd", type: "NUMERIC(12,2)", nullable: false, description: "Dollar value of token at checkout" },
        { name: "tx_hash", type: "VARCHAR(128)", nullable: true, description: "On-chain transaction hash" },
        { name: "logs", type: "TEXT[]", nullable: false, description: "Confirmation logs and detection trace" }
      ]
    }
  ];
  res.json(schemas);
});

// Serve Vite dev server or static distribution files
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`The Merchant's Leaf server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
