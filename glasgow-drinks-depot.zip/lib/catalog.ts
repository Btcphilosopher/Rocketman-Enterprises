// Fictional Glasgow Drinks Depot Catalog Generator and Types
export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  category: 'BEER' | 'CIDER' | 'WINE' | 'SPIRITS' | 'MIXERS' | 'SOFT DRINKS' | 'ENERGY' | 'SNACKS';
  subcategory: string;
  size: string; // e.g. "4 x 440ml", "75cl", "1 Litre", "500ml"
  price: number; // in GBP, e.g. 5.49
  prevPrice?: number; // for displaying discount strike-throughs
  abv?: number; // alcohol by volume in %, e.g. 4.0
  origin: string; // e.g. "Scotland", "Italy", "Belgium"
  producer: string; // Fictional brand name
  stock: number; // current simulated stock
  tags: string[]; // e.g. ["local", "multipack", "deal", "award-winner"]
  description: string;
  volumeLiters: number; // for unit price calculation
}

export interface PromotionRule {
  id: string;
  name: string;
  type: 'MULTIBUY' | 'CASE_SAVING' | 'FLAT_DISCOUNT';
  productId?: string; // Applies to single product
  productIds?: string[]; // Applies to group of products (e.g. mix & match)
  requiredQty: number;
  promoPrice: number; // target price for requiredQty (e.g. "2 for £10")
  savingMessage: string;
}

// Generate a rich set of 150+ realistic fictional drink products deterministically
export function generateCatalog(): Product[] {
  const products: Product[] = [];
  
  const categories = {
    BEER: [
      { sub: 'Lager', brands: ['Clyde Castle', 'St. Mungo', 'Depot Value', 'High Street Lager', 'Broomielaw'], origins: ['Scotland', 'Germany', 'Czech Republic'] },
      { sub: 'IPA', brands: ['Kelvingrove Hop', 'Necropolis Pale', 'Gallowgate Pale', 'Finnieston Haze'], origins: ['Scotland', 'USA'] },
      { sub: 'Stout', brands: ['Clyde Coal Stout', 'Glasgow Oyster Stout', 'Merchant City Dark'], origins: ['Scotland', 'Ireland'] },
      { sub: 'Ale', brands: ['Red Tenement Ale', 'Barras Amber', 'Highland Heather Ale'], origins: ['Scotland', 'England'] }
    ],
    CIDER: [
      { sub: 'Apple', brands: ['Carse of Gowrie Cider', 'Orchard Depot', 'Glasgow Crisp Apple'], origins: ['Scotland', 'England'] },
      { sub: 'Fruit Cider', brands: ['Loch Ness Berry Cider', 'Strathclyde Pear & Bramble', 'Depot Dark Fruits'], origins: ['Scotland'] }
    ],
    WINE: [
      { sub: 'Red', brands: ['Depot House Red', 'Château Govan', 'Tollcross Shiraz', 'Tenement Malbec'], origins: ['Chile', 'France', 'Australia', 'Argentina'] },
      { sub: 'White', brands: ['Depot House White', 'Shawlands Sauvignon', 'Sauchiehall Pinot'], origins: ['New Zealand', 'Italy', 'South Africa'] },
      { sub: 'Rosé', brands: ['West End Blush', 'Glasgow Green Rosé'], origins: ['France', 'Spain'] },
      { sub: 'Sparkling', brands: ['Prosecco di Partick', 'Clyde Fizz', 'Glasgow Grand Reserve'], origins: ['Italy', 'France'] }
    ],
    SPIRITS: [
      { sub: 'Scotch Whisky', brands: ['Loch Katrine Single Malt', 'Barrowlands Peated Malt', 'Clydeside Cooper\'s Blend', 'Glengoyne Hillside'], origins: ['Scotland'] },
      { sub: 'Gin', brands: ['Glasgow Botanic Gin', 'Kelvin Dry Gin', 'Merchant City Bramble Gin'], origins: ['Scotland'] },
      { sub: 'Vodka', brands: ['Glasgow Grain Vodka', 'Clyde Pure Vodka', 'Depot Value Vodka'], origins: ['Scotland', 'Poland'] },
      { sub: 'Rum', brands: ['Gallowgate Spiced Rum', 'Clyde Anchor Navy Rum'], origins: ['Scotland', 'Caribbean'] }
    ],
    MIXERS: [
      { sub: 'Tonic', brands: ['Kelvin Water Premium Tonic', 'Depot Crisp Tonic', 'Shawlands Botanicals'], origins: ['Scotland', 'UK'] },
      { sub: 'Soda & Cola', brands: ['Depot Club Soda', 'Govan Ginger Beer', 'Merchant Tonic Cola'], origins: ['UK'] }
    ],
    'SOFT DRINKS': [
      { sub: 'Scottish Soft Drinks', brands: ['Iron Brew Depot', 'Glasgow Ginger Classic', 'Cairngorm Berry'], origins: ['Scotland'] },
      { sub: 'Cola & Lemonade', brands: ['Depot Classic Cola', 'Tenement Cloudy Lemonade', 'Clyde Diet Cola'], origins: ['UK'] },
      { sub: 'Water', brands: ['Loch Katrine Spring', 'Clyde Sparkling Mineral'], origins: ['Scotland'] }
    ],
    ENERGY: [
      { sub: 'Energy Drinks', brands: ['Depot Bolt Red', 'Glasgow Charge Sour Blue', 'Clyde Speed Orange'], origins: ['UK'] },
      { sub: 'Sports Drinks', brands: ['Electrolyte Depot Blue', 'Hydrate Glasgow Lemon'], origins: ['UK'] }
    ],
    SNACKS: [
      { sub: 'Crisps', brands: ['Highland Ridge Crisps', 'Glasgow Chippy Salt & Vinegar', 'Depot Cheese & Onion'], origins: ['Scotland', 'UK'] },
      { sub: 'Nuts & Seeds', brands: ['Depot Roasted Peanuts', 'Barrowlands Chilli Cashews'], origins: ['UK'] },
      { sub: 'Chocolate & Sweet', brands: ['Depot Caramel Shortbread', 'Glasgow Green Mint Crisp', 'Tunnock-Style Teacakes'], origins: ['Scotland'] }
    ]
  };

  let idCounter = 1;

  // Generate 160 deterministic products (approx 15-25 per category)
  Object.entries(categories).forEach(([categoryKey, subcats]) => {
    const category = categoryKey as Product['category'];
    
    subcats.forEach((subcatGroup) => {
      const subcategory = subcatGroup.sub;
      
      subcatGroup.brands.forEach((brand) => {
        subcatGroup.origins.forEach((origin) => {
          // Generate 2 variations of product for this brand/origin combination to build deep variety
          for (let variant = 1; variant <= 2; variant++) {
            const id = `gd-${idCounter++}`;
            const sku = `GD-${category.substring(0, 3)}-${idCounter.toString().padStart(4, '0')}`;
            
            let name = '';
            let size = '500ml';
            let price = 4.99;
            let abv: number | undefined = undefined;
            let tags: string[] = [];
            let volumeLiters = 0.5;

            // Tailor characteristics per category
            if (category === 'BEER') {
              abv = subcategory === 'Lager' ? 4.0 + (variant * 0.5) : subcategory === 'IPA' ? 5.2 + (variant * 0.4) : subcategory === 'Stout' ? 4.5 + (variant * 0.3) : 4.2;
              if (variant === 1) {
                name = `${brand} ${subcategory}`;
                size = '500ml Can';
                price = Number((1.19 + (abv * 0.15)).toFixed(2));
                volumeLiters = 0.5;
              } else {
                name = `${brand} Premium Multipack`;
                size = '4 x 440ml Cans';
                price = Number((4.49 + (abv * 0.5)).toFixed(2));
                volumeLiters = 1.76;
                tags.push('multipack');
              }
            } else if (category === 'CIDER') {
              abv = 4.5 + (variant * 0.5);
              if (variant === 1) {
                name = `${brand} Crisp Cider`;
                size = '500ml Bottle';
                price = Number((1.49 + variant * 0.2).toFixed(2));
                volumeLiters = 0.5;
              } else {
                name = `${brand} Orchard Multipack`;
                size = '4 x 440ml Cans';
                price = Number((4.99 + variant * 0.3).toFixed(2));
                volumeLiters = 1.76;
                tags.push('multipack');
              }
            } else if (category === 'WINE') {
              abv = subcategory === 'Sparkling' ? 11.5 : 12.5 + (variant * 0.5);
              if (variant === 1) {
                name = `${brand} Reserve`;
                size = '75cl Bottle';
                price = Number((5.49 + (abv * 0.1)).toFixed(2));
                volumeLiters = 0.75;
              } else {
                name = `${brand} Depot Value Case`;
                size = '3 Litre Wine Box';
                price = Number((12.99 + variant).toFixed(2));
                volumeLiters = 3.0;
                tags.push('case-saving');
              }
            } else if (category === 'SPIRITS') {
              abv = subcategory === 'Scotch Whisky' ? 40.0 + (variant * 3.0) : 37.5 + (variant * 2.0);
              if (variant === 1) {
                name = `${brand} Standard Edition`;
                size = '70cl Bottle';
                price = subcategory === 'Scotch Whisky' ? Number((18.49 + (abv * 0.1)).toFixed(2)) : Number((11.99 + (abv * 0.1)).toFixed(2));
                volumeLiters = 0.70;
              } else {
                name = `${brand} Depot Liter Saver`;
                size = '1 Litre Bottle';
                price = subcategory === 'Scotch Whisky' ? Number((24.99 + (abv * 0.15)).toFixed(2)) : Number((15.99 + (abv * 0.15)).toFixed(2));
                volumeLiters = 1.0;
                tags.push('liter-saver');
              }
            } else if (category === 'MIXERS') {
              if (variant === 1) {
                name = `${brand} Tonic Premium`;
                size = '500ml Bottle';
                price = 0.89;
                volumeLiters = 0.5;
              } else {
                name = `${brand} Saver Multipack`;
                size = '8 x 150ml Mini Cans';
                price = 2.99;
                volumeLiters = 1.2;
                tags.push('multipack');
              }
            } else if (category === 'SOFT DRINKS') {
              if (variant === 1) {
                name = `${brand} Original`;
                size = '500ml Bottle';
                price = 1.25;
                volumeLiters = 0.5;
              } else {
                name = `${brand} Depot Multipack`;
                size = '24 x 330ml Bulk Case';
                price = 7.99;
                volumeLiters = 7.92;
                tags.push('multipack', 'bulk-case');
              }
            } else if (category === 'ENERGY') {
              if (variant === 1) {
                name = `${brand} Active Power`;
                size = '500ml Can';
                price = 1.15;
                volumeLiters = 0.5;
              } else {
                name = `${brand} Depot Charger Multipack`;
                size = '4 x 500ml Cans';
                price = 3.49;
                volumeLiters = 2.0;
                tags.push('multipack');
              }
            } else if (category === 'SNACKS') {
              if (variant === 1) {
                name = `${brand} Hand Cooked Bags`;
                size = '150g Share Bag';
                price = 1.49;
                volumeLiters = 0.15; // use L/kg proxy
              } else {
                name = `${brand} Depot Multi-pack Box`;
                size = '12 x 25g Pack';
                price = 2.79;
                volumeLiters = 0.3;
                tags.push('multipack');
              }
            }

            // Mark some products with promotions
            let prevPrice: number | undefined = undefined;
            if (idCounter % 5 === 0) {
              prevPrice = Number((price * 1.25).toFixed(2));
              tags.push('deal');
            }
            if (origin === 'Scotland') {
              tags.push('local');
            }

            const stock = Math.floor(Math.sin(idCounter) * 45) + 50; // realistic randomized stock 5-95

            products.push({
              id,
              sku,
              name,
              brand,
              category,
              subcategory,
              size,
              price,
              prevPrice,
              abv,
              origin,
              producer: `${brand} Distillery & Brewery`,
              stock: stock < 10 ? 0 : stock, // create a few "out of stock"
              tags,
              description: `A quality beverage produced with care by ${brand}. Perfect for regular stock up or special get-togethers in Glasgow. Genuine local retail value without compromise.`,
              volumeLiters
            });
          }
        });
      });
    });
  });

  return products;
}

// Generate promotion rules for the pricing engine
export function getPromotionRules(products: Product[]): PromotionRule[] {
  const rules: PromotionRule[] = [];

  // Rule 1: Mix & Match Red/White Wines: Any 2 House/Reserve Bottles for £10.00
  const wineIds = products.filter(p => p.category === 'WINE' && p.size === '75cl Bottle' && p.price < 8).map(p => p.id);
  if (wineIds.length > 0) {
    rules.push({
      id: 'promo-wine-2-for-10',
      name: 'Wine Mix & Match: 2 for £10',
      type: 'MULTIBUY',
      productIds: wineIds,
      requiredQty: 2,
      promoPrice: 10.00,
      savingMessage: 'Mix & Match Wine: Save with 2 for £10!'
    });
  }

  // Rule 2: Single-product discount (e.g. Clyde Castle Lager Cans 4-pack: 2 for £8.00)
  const mainBeer = products.find(p => p.category === 'BEER' && p.size === '4 x 440ml Cans');
  if (mainBeer) {
    rules.push({
      id: `promo-beer-${mainBeer.id}`,
      name: `${mainBeer.name} Double Saver`,
      type: 'MULTIBUY',
      productId: mainBeer.id,
      requiredQty: 2,
      promoPrice: 8.00,
      savingMessage: `Double up on ${mainBeer.name} and get 2 for £8!`
    });
  }

  // Rule 3: Mix & Match Soft Drinks: Any 3 Iron Brew/Glasgow Ginger 500ml for £3.00
  const softDrinkIds = products.filter(p => p.category === 'SOFT DRINKS' && p.size === '500ml Bottle').map(p => p.id);
  if (softDrinkIds.length > 0) {
    rules.push({
      id: 'promo-soft-3-for-3',
      name: 'Soft Drinks Special: 3 for £3.00',
      type: 'MULTIBUY',
      productIds: softDrinkIds,
      requiredQty: 3,
      promoPrice: 3.00,
      savingMessage: 'Stock up on Softs: 3 for £3.00!'
    });
  }

  // Rule 4: Flat case-saving on large bulk boxes (e.g. Save £3 when buying any bulk crate)
  const bulkCases = products.filter(p => p.tags.includes('bulk-case'));
  bulkCases.forEach(p => {
    rules.push({
      id: `promo-flat-${p.id}`,
      name: `Crate Bulk Discount`,
      type: 'CASE_SAVING',
      productId: p.id,
      requiredQty: 1,
      promoPrice: Number((p.price - 1.50).toFixed(2)),
      savingMessage: 'Bulk Case Savings Applied!'
    });
  });

  return rules;
}

// Pricing Engine calculation function
export interface CartItem {
  product: Product;
  quantity: number;
}

export interface PriceBreakdown {
  subtotal: number; // raw price before discount
  discount: number; // total discount applied
  total: number; // final total price
  unitSavingDetails: { [productId: string]: string }; // details per item
  appliedPromoMessages: string[];
  vatAmount: number; // 20% Scottish VAT included
}

export function calculateCartPrice(items: CartItem[], rules: PromotionRule[]): PriceBreakdown {
  let subtotal = 0;
  let discount = 0;
  const appliedPromoMessagesSet = new Set<string>();
  const unitSavingDetails: { [productId: string]: string } = {};

  // Track quantities available for mix-and-match rules
  const mixAndMatchCounts: { [ruleId: string]: { count: number; items: { product: Product; price: number; qtyInCart: number }[] } } = {};

  // First calculate normal subtotal and isolate bulk flat discounts or single-product multibuys
  items.forEach(item => {
    const itemSub = item.product.price * item.quantity;
    subtotal += itemSub;
  });

  // Deep copy cart item quantities for rule application
  const remainingQtyMap: { [productId: string]: number } = {};
  items.forEach(item => {
    remainingQtyMap[item.product.id] = item.quantity;
  });

  // Apply single-product rules first
  rules.forEach(rule => {
    if (rule.productId && !rule.productIds) {
      const qty = remainingQtyMap[rule.productId] || 0;
      if (qty >= rule.requiredQty) {
        const item = items.find(it => it.product.id === rule.productId);
        if (item) {
          const timesApplied = Math.floor(qty / rule.requiredQty);
          const basePriceForPromoQty = item.product.price * rule.requiredQty;
          const promoPriceForQty = rule.promoPrice;
          const savingPerApplication = basePriceForPromoQty - promoPriceForQty;
          
          if (savingPerApplication > 0) {
            discount += savingPerApplication * timesApplied;
            remainingQtyMap[rule.productId] -= timesApplied * rule.requiredQty;
            appliedPromoMessagesSet.add(rule.name);
            unitSavingDetails[rule.productId] = `Saved £${(savingPerApplication * timesApplied).toFixed(2)} on multibuy`;
          }
        }
      }
    }
  });

  // Apply group/mix-and-match rules
  rules.forEach(rule => {
    if (rule.productIds && rule.productIds.length > 0) {
      // Find total items in cart that qualify for this group rule
      const qualifyingItemsInCart = items.filter(it => rule.productIds!.includes(it.product.id));
      let totalQualifyingQty = qualifyingItemsInCart.reduce((sum, it) => sum + remainingQtyMap[it.product.id], 0);

      if (totalQualifyingQty >= rule.requiredQty) {
        const timesApplied = Math.floor(totalQualifyingQty / rule.requiredQty);
        appliedPromoMessagesSet.add(rule.name);

        // We want to apply the rule. To be fair, let's group eligible items in order of price (highest first or lowest first)
        // Usually supermarkets discount the cheapest items, but we can do a simplified average pricing or flat subtraction
        // Let's list all eligible individual items in a list and group them in sets of `requiredQty`
        const eligibleList: { id: string; price: number }[] = [];
        qualifyingItemsInCart.forEach(it => {
          const qtyRemaining = remainingQtyMap[it.product.id];
          for (let i = 0; i < qtyRemaining; i++) {
            eligibleList.push({ id: it.product.id, price: it.product.price });
          }
        });

        // Apply rules to sets of `requiredQty`
        for (let t = 0; t < timesApplied; t++) {
          const set = eligibleList.slice(t * rule.requiredQty, (t + 1) * rule.requiredQty);
          const originalSetSum = set.reduce((sum, item) => sum + item.price, 0);
          const promoDiff = originalSetSum - rule.promoPrice;
          if (promoDiff > 0) {
            discount += promoDiff;
            // Subtract from remaining quantities
            set.forEach(item => {
              remainingQtyMap[item.id]--;
              unitSavingDetails[item.id] = (unitSavingDetails[item.id] || '') + ` Group promo discount applied.`;
            });
          }
        }
      }
    }
  });

  const total = Math.max(0, Number((subtotal - discount).toFixed(2)));
  const vatAmount = Number((total * 0.20).toFixed(2)); // Standard 20% VAT included in ticket prices

  return {
    subtotal: Number(subtotal.toFixed(2)),
    discount: Number(discount.toFixed(2)),
    total,
    unitSavingDetails,
    appliedPromoMessages: Array.from(appliedPromoMessagesSet),
    vatAmount
  };
}
