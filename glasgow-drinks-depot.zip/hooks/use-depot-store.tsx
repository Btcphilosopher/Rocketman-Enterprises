'use client';

import React, { useState, useEffect, createContext, useContext } from 'react';
import { generateCatalog, getPromotionRules, Product, CartItem, PromotionRule, calculateCartPrice, PriceBreakdown } from '@/lib/catalog';

// Fictional delivery zones in Glasgow
export const DEPUT_DELIVERY_ZONES = [
  { area: 'Glasgow City Centre', postcodes: ['G1', 'G2', 'G3', 'G4'] },
  { area: 'West End', postcodes: ['G11', 'G12', 'G20'] },
  { area: 'Southside', postcodes: ['G41', 'G42', 'G43', 'G44'] },
  { area: 'East End', postcodes: ['G31', 'G32'] },
  { area: 'North Glasgow', postcodes: ['G21', 'G22'] },
  { area: 'Paisley & Renfrew', postcodes: ['PA1', 'PA2', 'PA3'] },
  { area: 'Clydebank', postcodes: ['G81'] },
  { area: 'East Kilbride', postcodes: ['G74', 'G75'] },
  { area: 'Bearsden & Milngavie', postcodes: ['G61', 'G62'] }
];

// Fictional stores
export interface DepotStore {
  id: string;
  name: string;
  address: string;
  hours: string;
  services: string[];
  parking: string;
  lat: number;
  lng: number;
}

export const DEPOT_STORES: DepotStore[] = [
  {
    id: 'glasgow-city',
    name: 'Glasgow City Centre Depot',
    address: '120 Broomielaw, Glasgow G1 4QD (Near River Clyde)',
    hours: 'Mon-Sat: 08:00 - 22:00, Sun: 09:00 - 20:00',
    services: ['Click & Collect', 'Local Delivery Depot', 'Chilled Spirits Cellar', 'Bulk Pallet Sales'],
    parking: 'Free customers car park (50 spaces)',
    lat: 55.8569,
    lng: -4.2625
  },
  {
    id: 'south-glasgow',
    name: 'South Glasgow Depot',
    address: '45 Shawlands Way, Shawlands, Glasgow G41 3RY',
    hours: 'Mon-Sat: 08:00 - 22:00, Sun: 09:00 - 20:00',
    services: ['Click & Collect', 'Direct Crate Drive-Thru', 'Keg Fill Station'],
    parking: 'Underground customer parking (120 spaces)',
    lat: 55.8281,
    lng: -4.2792
  },
  {
    id: 'west-glasgow',
    name: 'West Glasgow Depot',
    address: '15 Crow Road, Partick, Glasgow G11 7RT',
    hours: 'Mon-Sat: 08:00 - 23:00, Sun: 09:00 - 21:00',
    services: ['Click & Collect', 'Scottish Craft Showcase', 'Chilled Wine Vault'],
    parking: 'Free customer parking (75 spaces)',
    lat: 55.8710,
    lng: -4.3120
  },
  {
    id: 'east-glasgow',
    name: 'East Glasgow Depot',
    address: '88 Duke Street, Barrowlands, Glasgow G31 1QB',
    hours: 'Mon-Sat: 08:00 - 22:00, Sun: 09:00 - 20:00',
    services: ['Click & Collect', 'Bulk Case Savings Center', 'Event Supply Hire'],
    parking: 'Adjacent multi-story free for customers (200 spaces)',
    lat: 55.8595,
    lng: -4.2345
  }
];

export interface SimulatedOrder {
  id: string;
  items: CartItem[];
  totals: PriceBreakdown;
  deliveryType: 'delivery' | 'collection';
  storeId?: string;
  postcode?: string;
  status: 'CONFIRMED' | 'PICKING' | 'PACKED' | 'OUT_FOR_DELIVERY' | 'DELIVERED' | 'READY_FOR_COLLECTION' | 'COMPLETED';
  date: string;
  createdAt: number;
}

interface DepotStoreContextType {
  catalog: Product[];
  promotions: PromotionRule[];
  cart: CartItem[];
  cartPricing: PriceBreakdown;
  ageVerified: boolean;
  activeTab: 'SHOP' | 'DEALS' | 'STORES' | 'ABOUT' | 'TRACKING' | 'DIAGNOSTICS';
  deliveryType: 'delivery' | 'collection';
  selectedStore: DepotStore;
  postcode: string;
  deliveryEligible: 'idle' | 'eligible' | 'collection-only' | 'outside';
  searchQuery: string;
  selectedCategory: string;
  selectedSubcategory: string;
  sortBy: string;
  activeOrder: SimulatedOrder | null;
  orders: SimulatedOrder[];
  isCartOpen: boolean;
  setAgeVerified: (verified: boolean) => void;
  setActiveTab: (tab: 'SHOP' | 'DEALS' | 'STORES' | 'ABOUT' | 'TRACKING' | 'DIAGNOSTICS') => void;
  addToCart: (product: Product, qty?: number) => void;
  removeFromCart: (productId: string) => void;
  updateCartQty: (productId: string, qty: number) => void;
  clearCart: () => void;
  setDeliveryType: (type: 'delivery' | 'collection') => void;
  setSelectedStore: (store: DepotStore) => void;
  checkPostcode: (postcode: string) => void;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (cat: string) => void;
  setSelectedSubcategory: (subcat: string) => void;
  setSortBy: (sort: string) => void;
  submitOrder: (customerInfo: { name: string; phone: string; address: string; postcode: string; email: string }) => SimulatedOrder;
  updateOrderStatus: (orderId: string, status: SimulatedOrder['status']) => void;
  setCartOpen: (open: boolean) => void;
  resetAll: () => void;
}

const DepotStoreContext = createContext<DepotStoreContextType | undefined>(undefined);

export function DepotStoreProvider({ children }: { children: React.ReactNode }) {
  const [catalog] = useState<Product[]>(() => generateCatalog());
  const [promotions] = useState<PromotionRule[]>(() => getPromotionRules(generateCatalog()));
  const [cart, setCart] = useState<CartItem[]>([]);
  const [ageVerified, setAgeVerifiedState] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'SHOP' | 'DEALS' | 'STORES' | 'ABOUT' | 'TRACKING' | 'DIAGNOSTICS'>('SHOP');
  const [deliveryType, setDeliveryType] = useState<'delivery' | 'collection'>('collection');
  const [selectedStore, setSelectedStore] = useState<DepotStore>(() => DEPOT_STORES[0]);
  const [postcode, setPostcode] = useState<string>('');
  const [deliveryEligible, setDeliveryEligible] = useState<'idle' | 'eligible' | 'collection-only' | 'outside'>('idle');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<string>('popular');
  const [activeOrder, setActiveOrder] = useState<SimulatedOrder | null>(null);
  const [orders, setOrders] = useState<SimulatedOrder[]>([]);
  const [isCartOpen, setCartOpen] = useState<boolean>(false);

  // Read initial states from localStorage if in browser safely
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const savedAge = localStorage.getItem('gd_age_verified');
      if (savedAge === 'true') {
        setTimeout(() => {
          setAgeVerifiedState(true);
        }, 0);
      }

      const savedCart = localStorage.getItem('gd_cart');
      if (savedCart) {
        try {
          const parsed = JSON.parse(savedCart);
          setTimeout(() => {
            setCart(parsed);
          }, 0);
        } catch (_) {}
      }

      const savedOrders = localStorage.getItem('gd_orders');
      if (savedOrders) {
        try {
          const parsed = JSON.parse(savedOrders);
          setTimeout(() => {
            setOrders(parsed);
            if (parsed.length > 0) {
              setActiveOrder(parsed[parsed.length - 1]);
            }
          }, 0);
        } catch (_) {}
      }
    }
  }, []);

  // Save changes to localStorage safely
  useEffect(() => {
    if (typeof window !== 'undefined' && cart.length > 0) {
      localStorage.setItem('gd_cart', JSON.stringify(cart));
    }
  }, [cart]);

  useEffect(() => {
    if (typeof window !== 'undefined' && orders.length > 0) {
      localStorage.setItem('gd_orders', JSON.stringify(orders));
    }
  }, [orders]);

  const setAgeVerified = (verified: boolean) => {
    setAgeVerifiedState(verified);
    if (typeof window !== 'undefined') {
      localStorage.setItem('gd_age_verified', verified ? 'true' : 'false');
    }
  };

  // Pricing calculations
  const cartPricing = calculateCartPrice(cart, promotions);

  // Cart actions
  const addToCart = (product: Product, qty: number = 1) => {
    if (product.stock === 0) return;
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        const newQty = Math.min(product.stock, existing.quantity + qty);
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: newQty } : item);
      }
      return [...prev, { product, quantity: Math.min(product.stock, qty) }];
    });
    setCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateCartQty = (productId: string, qty: number) => {
    const product = catalog.find(p => p.id === productId);
    if (!product) return;
    if (qty <= 0) {
      removeFromCart(productId);
      return;
    }
    const finalQty = Math.min(product.stock, qty);
    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity: finalQty } : item));
  };

  const clearCart = () => {
    setCart([]);
  };

  const checkPostcode = (pCode: string) => {
    const formatted = pCode.trim().toUpperCase().replace(/\s+/g, '');
    setPostcode(pCode);
    if (!formatted) {
      setDeliveryEligible('idle');
      return;
    }

    const match = DEPUT_DELIVERY_ZONES.find(zone => 
      zone.postcodes.some(p => formatted.startsWith(p))
    );

    if (match) {
      setDeliveryEligible('eligible');
    } else {
      if (formatted.startsWith('G')) {
        setDeliveryEligible('collection-only');
      } else {
        setDeliveryEligible('outside');
      }
    }
  };

  const submitOrder = (info: { name: string; phone: string; address: string; postcode: string; email: string }) => {
    const orderId = `GD-${Math.floor(100000 + Math.random() * 900000)}`;
    const newOrder: SimulatedOrder = {
      id: orderId,
      items: [...cart],
      totals: { ...cartPricing },
      deliveryType,
      storeId: deliveryType === 'collection' ? selectedStore.id : undefined,
      postcode: deliveryType === 'delivery' ? info.postcode : undefined,
      status: 'CONFIRMED',
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }),
      createdAt: Date.now()
    };

    setOrders(prev => [...prev, newOrder]);
    setActiveOrder(newOrder);
    setCart([]);
    setActiveTab('TRACKING');
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: SimulatedOrder['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    if (activeOrder && activeOrder.id === orderId) {
      setActiveOrder(prev => prev ? { ...prev, status } : null);
    }
  };

  const resetAll = () => {
    setCart([]);
    setOrders([]);
    setActiveOrder(null);
    setAgeVerified(false);
    setPostcode('');
    setDeliveryEligible('idle');
    setDeliveryType('collection');
  };

  return (
    <DepotStoreContext.Provider value={{
      catalog,
      promotions,
      cart,
      cartPricing,
      ageVerified,
      activeTab,
      deliveryType,
      selectedStore,
      postcode,
      deliveryEligible,
      searchQuery,
      selectedCategory,
      selectedSubcategory,
      sortBy,
      activeOrder,
      orders,
      isCartOpen,
      setAgeVerified,
      setActiveTab,
      addToCart,
      removeFromCart,
      updateCartQty,
      clearCart,
      setDeliveryType,
      setSelectedStore,
      checkPostcode,
      setSearchQuery,
      setSelectedCategory,
      setSelectedSubcategory,
      setSortBy,
      submitOrder,
      updateOrderStatus,
      setCartOpen,
      resetAll
    }}>
      {children}
    </DepotStoreContext.Provider>
  );
}

export function useDepotStore() {
  const context = useContext(DepotStoreContext);
  if (context === undefined) {
    throw new Error('useDepotStore must be used within a DepotStoreProvider');
  }
  return context;
}
