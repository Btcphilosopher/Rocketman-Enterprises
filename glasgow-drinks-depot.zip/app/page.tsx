'use client';

import { useDepotStore } from '@/hooks/use-depot-store';
import AgeVerificationModal from '@/components/AgeVerificationModal';
import DepotHeader from '@/components/DepotHeader';
import SearchBar from '@/components/SearchBar';
import ProductCard from '@/components/ProductCard';
import BasketDrawer from '@/components/BasketDrawer';
import StoreMap from '@/components/StoreMap';
import DeliveryEstimator from '@/components/DeliveryEstimator';
import OrderTracker from '@/components/OrderTracker';
import DiagnosticsPanel from '@/components/DiagnosticsPanel';
import Image from 'next/image';
import { Beer, Flame, Award, ShieldAlert, ArrowRight, MapPin, Truck, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

// Hero Background & Category image paths we generated:
const HERO_IMAGE_PATH = '/src/assets/images/hero_glasgow_depot_1790955994326.jpg';
const CATEGORY_IMAGE_PATH = '/src/assets/images/beverage_crates_industrial_1790956008538.jpg';
const SCOTTISH_DRINKS_PATH = '/src/assets/images/scottish_drinks_sandstone_179095621826.jpg'; // or similar generated path, let's use the exact names from tool responses:
const GENERATED_HERO = '/src/assets/images/hero_glasgow_depot_1790955994326.jpg';
const GENERATED_CRATES = '/src/assets/images/beverage_crates_industrial_1790956008538.jpg';
const GENERATED_SCOTTISH = '/src/assets/images/scottish_drinks_sandstone_1790956021826.jpg';

export default function Home() {
  const {
    catalog,
    activeTab,
    setActiveTab,
    searchQuery,
    selectedCategory,
    setSelectedCategory,
    sortBy,
    cart,
    resetAll
  } = useDepotStore();

  // Filter & Sort catalog items for shop view
  const filteredCatalog = catalog.filter((product) => {
    // 1. Category Filter
    if (selectedCategory !== 'ALL' && product.category !== selectedCategory) {
      return false;
    }
    // 2. Search query filter
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const matchName = product.name.toLowerCase().includes(q);
      const matchBrand = product.brand.toLowerCase().includes(q);
      const matchSub = product.subcategory.toLowerCase().includes(q);
      const matchTag = product.tags.some(t => t.toLowerCase().includes(q));
      if (!matchName && !matchBrand && !matchSub && !matchTag) return false;
    }
    return true;
  });

  // Apply Sorting
  const sortedCatalog = [...filteredCatalog].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'abv-desc') return (b.abv || 0) - (a.abv || 0);
    if (sortBy === 'saving') {
      const savingA = a.prevPrice ? a.prevPrice - a.price : 0;
      const savingB = b.prevPrice ? b.prevPrice - b.price : 0;
      return savingB - savingA;
    }
    return b.stock - a.stock; // Default popularity proxy by stock volume
  });

  // "From Scotland" items list (12 curated local items)
  const scottishProducts = catalog.filter(p => p.tags.includes('local')).slice(0, 8);

  // Deals items list (all products with prevPrice)
  const dealsProducts = catalog.filter(p => p.prevPrice !== undefined);

  return (
    <div className="min-h-screen bg-zinc-950 text-white selection:bg-red-600 selection:text-white flex flex-col justify-between">
      {/* Age Gate compliance modal */}
      <AgeVerificationModal />

      {/* Cart Slider drawer */}
      <BasketDrawer />

      {/* Structured Site Header */}
      <DepotHeader />

      {/* Render selected Tabs / Pages */}
      <main className="flex-1 pb-16">
        {/* VIEW 1: SHOP CATALOG (And Hero Landing homepage) */}
        {activeTab === 'SHOP' && (
          <div className="space-y-12">
            
            {/* LARGE WAREHOUSE RETAIL HERO */}
            <section className="relative min-h-[500px] flex items-center bg-zinc-950 overflow-hidden border-b border-zinc-800">
              <div className="absolute inset-0 z-0 opacity-40">
                <Image
                  src={GENERATED_HERO}
                  alt="Glasgow Drinks Depot Warehouse"
                  fill
                  className="object-cover object-center scale-105"
                  priority
                  referrerPolicy="no-referrer"
                />
                {/* Clean dark overlay vignette */}
                <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent" />
              </div>

              <div className="max-w-7xl mx-auto px-4 md:px-8 py-16 relative z-10 w-full grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="space-y-6">
                  {/* Local Tag line */}
                  <div className="inline-flex items-center gap-2 bg-red-600 text-white px-3 py-1 text-[10px] font-bold uppercase tracking-widest">
                    GLASGOW&apos;S EVERYDAY DRINKS DEPOT
                  </div>

                  <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-white leading-tight">
                    BIG DRINKS.<br />
                    <span className="text-red-500">SMALL PRICES.</span>
                  </h1>

                  <p className="text-zinc-300 text-sm md:text-base max-w-lg leading-relaxed font-semibold">
                    Everyday drinks, serious choice, and Glasgow prices. Straightforward high-volume economics direct to the public. No nonsense, just value.
                  </p>

                  <div className="flex flex-wrap gap-3 pt-4">
                    <a
                      href="#catalog-grid"
                      className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider transition-colors duration-200"
                    >
                      SHOP CATALOGUE
                    </a>
                    <button
                      onClick={() => setActiveTab('DEALS')}
                      className="px-6 py-3 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-white font-bold text-xs uppercase tracking-wider transition-colors duration-200"
                    >
                      SEE THIS WEEK&apos;S DEALS
                    </button>
                  </div>
                </div>

                {/* Industrial pallet block promo card */}
                <div className="hidden lg:flex items-center justify-end">
                  <div className="bg-zinc-900 border border-zinc-800 p-6 max-w-sm text-left shadow-2xl relative">
                    <div className="absolute top-0 right-0 bg-red-600 text-white text-[10px] font-bold px-2 py-1 tracking-widest uppercase">
                      BULK SAVINGS
                    </div>
                    <span className="text-[10px] text-zinc-500 font-bold uppercase block mb-1">DEPOT BUYING CO.</span>
                    <h3 className="text-base font-black text-white uppercase tracking-wider mb-2">BUY MORE. PAY LESS.</h3>
                    <p className="text-xs text-zinc-400 leading-relaxed mb-4">
                      Stock up on our private-label <span className="text-white">Depot Lager</span> and <span className="text-white">Depot Soft Drinks</span>. Big boxes, bulk cases, and real saving rules applied live in your basket.
                    </p>
                    <div className="border-t border-zinc-800 pt-3 flex items-center justify-between">
                      <span className="text-[10px] text-zinc-500 font-bold uppercase">Glasgow City Wide Pilot</span>
                      <span className="text-xs font-bold text-red-500">CHALLENGE 25 ✓</span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* QUICK LINK CATEGORY GRID */}
            <section className="max-w-7xl mx-auto px-4 md:px-8">
              <span className="text-[10px] text-red-500 font-extrabold uppercase tracking-widest block mb-1">
                FAST REQUISITION
              </span>
              <h2 className="text-xl font-black text-white uppercase tracking-wide mb-6">
                BROWSE BY PALLET DEPT
              </h2>

              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
                {['BEER', 'CIDER', 'WINE', 'SPIRITS', 'MIXERS', 'SOFT DRINKS', 'ENERGY', 'SNACKS'].map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      setSelectedCategory(cat);
                      document.getElementById('catalog-grid')?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className={`p-4 border text-center transition-all cursor-pointer ${
                      selectedCategory === cat
                        ? 'bg-red-600 border-red-600'
                        : 'bg-zinc-900/60 border-zinc-850 hover:border-zinc-700'
                    }`}
                  >
                    <Beer className="w-5 h-5 mx-auto text-zinc-400 group-hover:text-white mb-2" />
                    <span className="text-[10px] font-bold uppercase tracking-wider block text-white">
                      {cat}
                    </span>
                  </button>
                ))}
              </div>
            </section>

            {/* DEDICATED SECTION: FROM SCOTLAND */}
            <section className="bg-zinc-900 border-y border-zinc-850 py-12">
              <div className="max-w-7xl mx-auto px-4 md:px-8">
                <div className="flex flex-col md:flex-row gap-8 items-stretch mb-8">
                  <div className="flex-1 space-y-3">
                    <div className="inline-flex items-center gap-1.5 text-xs text-red-500 font-extrabold uppercase tracking-wider">
                      <MapPin className="w-4 h-4 text-red-500 animate-pulse" />
                      <span>LOCAL ROOTS. DEPOT PRICES.</span>
                    </div>
                    <h2 className="text-3xl font-black tracking-tight text-white uppercase">
                      FROM SCOTLAND
                    </h2>
                    <p className="text-zinc-400 text-xs leading-relaxed max-w-xl">
                      Contemporary Scottish craft drinks direct from Glasgow, Clydeside, Gowrie, and the Highlands. Real local malt ingredients without the expensive boutique markup.
                    </p>
                  </div>
                  <div className="w-full md:w-72 relative h-40 md:h-auto border border-zinc-800 opacity-80 shrink-0">
                    <Image
                      src={GENERATED_SCOTTISH}
                      alt="Scottish Craft spirits"
                      fill
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                </div>

                {/* Local Grid Showcase */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {scottishProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </div>
            </section>

            {/* CORE CATALOG DIRECTORY SECTION */}
            <section id="catalog-grid" className="max-w-7xl mx-auto px-4 md:px-8 space-y-6 scroll-mt-20">
              <div className="flex flex-col sm:flex-row justify-between items-baseline gap-3 border-b border-zinc-900 pb-3">
                <div>
                  <h2 className="text-xl font-black text-white uppercase tracking-wide">
                    {selectedCategory === 'ALL' ? 'ALL STOCK DIRECTORY' : `${selectedCategory} SECTION`}
                  </h2>
                  <p className="text-[11px] text-zinc-500 font-semibold tracking-wider uppercase mt-1">
                    DISPLAYING {sortedCatalog.length} DETERMINISTIC SYNTHETIC DRINK PRODUCTS
                  </p>
                </div>
              </div>

              {/* Autocomplete & Sorting Toolbar */}
              <SearchBar />

              {/* Main Catalog Grid */}
              {sortedCatalog.length === 0 ? (
                <div className="py-12 border border-zinc-900 text-center space-y-3">
                  <p className="text-sm font-bold text-zinc-500">NO PRODUCTS MATCH THOSE SELECTIONS</p>
                  <button
                    onClick={() => {
                      setSelectedCategory('ALL');
                      resetAll();
                    }}
                    className="text-xs text-red-500 font-extrabold underline cursor-pointer"
                  >
                    RESET DIRECTORY FILTERS
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                  {sortedCatalog.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}
            </section>

            {/* WAREHOUSE ESTIMATION DRAWER / SELECTOR */}
            <section className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-2 gap-6 pt-6">
              <DeliveryEstimator />
              <div className="bg-zinc-900 border border-zinc-800 p-6 flex flex-col justify-between space-y-4">
                <div>
                  <div className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider block mb-1">DEPOT INFRASTRUCTURE</div>
                  <h3 className="text-lg font-black text-white uppercase tracking-wide">CLICK & COLLECT FROM THE WAREHOUSE</h3>
                  <p className="text-xs text-zinc-400 leading-relaxed mt-2">
                    Select your local warehouse, order online, and pick up in under 1 hour. No loading fees, no hassle, no minimum spend limits. Drive right into our designated Crate Loading bays!
                  </p>
                </div>
                <button
                  onClick={() => setActiveTab('STORES')}
                  className="w-full sm:w-fit py-2.5 px-6 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider text-center transition-colors cursor-pointer"
                >
                  FIND YOUR NEAREST DEPOT
                </button>
              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: DEPOT DEALS (WEEKLY DISCOUNT DEALS ENGINE) */}
        {activeTab === 'DEALS' && (
          <div className="max-w-7xl mx-auto px-4 md:px-8 space-y-8 mt-8">
            <div className="bg-zinc-900 border border-zinc-800 p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-red-600 text-white font-bold text-[10px] tracking-widest uppercase px-3 py-1">
                ACTIVE CAMPAIGN
              </div>
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 text-xs text-red-500 font-bold uppercase tracking-wider">
                  <Flame className="w-4 h-4 text-red-500" />
                  <span>DEPOT DEALS</span>
                </div>
                <h1 className="text-2xl md:text-3xl font-black text-white uppercase">WEEKLY DISCOUNTS ENGINE</h1>
                <p className="text-zinc-400 text-xs leading-relaxed max-w-xl">
                  These items carry direct price strike-throughs or bundle multipliers. Combine items into your basket and let the calculation engines solve your savings on final check out!
                </p>
              </div>
              <div className="font-mono text-zinc-500 text-[10px] font-bold">
                GLASGOW-DEPOT-DEMO-001
              </div>
            </div>

            {/* Deals Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {dealsProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          </div>
        )}

        {/* VIEW 3: STORE MAP LOCATOR */}
        {activeTab === 'STORES' && (
          <div className="max-w-7xl mx-auto px-4 md:px-8 mt-8">
            <StoreMap />
          </div>
        )}

        {/* VIEW 4: TRACKING STAGE MONITOR */}
        {activeTab === 'TRACKING' && (
          <div className="max-w-7xl mx-auto px-4 md:px-8 mt-8">
            <OrderTracker />
          </div>
        )}

        {/* VIEW 5: DIAGNOSTICS & SYSTEM Assertion Unit Tests */}
        {activeTab === 'DIAGNOSTICS' && (
          <div className="max-w-7xl mx-auto px-4 md:px-8 mt-8">
            <DiagnosticsPanel />
          </div>
        )}

        {/* VIEW 6: BRAND STORY / ABOUT */}
        {activeTab === 'ABOUT' && (
          <div className="max-w-3xl mx-auto px-4 py-8 space-y-8 mt-8 bg-zinc-900 border border-zinc-800 p-8">
            <div className="space-y-4">
              <div className="text-[10px] text-red-500 font-bold uppercase tracking-widest block">
                DEPOT HERITAGE
              </div>
              <h1 className="text-3xl font-black text-white uppercase tracking-wide">
                BUILT FOR GLASGOW
              </h1>
              <p className="text-zinc-300 text-sm leading-relaxed">
                Glasgow Drinks Depot began life as a series of industrial storage bays near the Broomielaw and River Clyde docklands. From unloading merchant shipping vessels and freight carriages, we recognized a simple truth: Glasgow retailers and families paid too much for simple, everyday refreshments because of inefficient logistics and middle-man margins.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border border-zinc-800 p-4">
                <h4 className="text-xs font-black text-white uppercase tracking-wider mb-2">
                  THE INDUSTRIAL VALUE PILOT
                </h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  We designed a high-volume warehouse retail facility with no carpets, no fancy marketing screens, and no premium styling markups. Our customers pick straight off heavy pine timber pallets and steel shipping wire.
                </p>
              </div>

              <div className="border border-zinc-800 p-4">
                <h4 className="text-xs font-black text-white uppercase tracking-wider mb-2">
                  CONVENIENT MODERN DIGITAL COMMERCE
                </h4>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  In the late-2020s, digital ordering and same-day delivery shouldn&apos;t be a luxury. We built a fast, straightforward e-commerce model that combines our warehouse margins with instant Click & Collect and direct postal delivery.
                </p>
              </div>
            </div>

            <div className="border-t border-zinc-800 pt-6 space-y-2">
              <h3 className="text-xs font-black text-white uppercase tracking-wider">
                OUR SOCIAL COOPERATION CONTRACT
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                As a proud Scottish business, we hire locally from Govan, Partick, Shawlands, and East Glasgow, pay living wages, and maintain 100% compliance with safe drinking standards.
              </p>
            </div>
          </div>
        )}
      </main>

      {/* COMPLIANT RESPONSIBLE RETAIL CARD BAR */}
      <section className="bg-zinc-900 border-t border-zinc-800 py-8 px-4 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-red-500 font-extrabold text-xs uppercase tracking-wide">
              <ShieldAlert className="w-4 h-4 text-red-500" />
              <span>SCOTTISH LICENSING COMPLIANCE & SECURE DELIVERY</span>
            </div>
            <p className="text-[11px] text-zinc-400 max-w-xl leading-relaxed">
              We operate a strict Challenge 25 policy across our entire Glasgow delivery and pick-up infrastructure. All online alcohol orders are subject to age verification by trained couriers and collection clerks.
            </p>
          </div>

          <div className="text-[10px] text-zinc-500 font-semibold space-y-1 font-mono uppercase text-left md:text-right">
            <div>LICENSING (SCOTLAND) ACT 2005 DIRECTIVE</div>
            <div>PLEASE DRINK RESPONSIBLY · DRINKAWARE.CO.UK</div>
          </div>
        </div>
      </section>

      {/* STRUCTURED FOOTER */}
      <footer className="bg-zinc-950 border-t border-zinc-900 py-12 px-4 md:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="font-sans font-extrabold tracking-tighter flex flex-col">
              <span className="text-[9px] tracking-[0.25em] text-red-600">GLASGOW</span>
              <span className="text-lg font-black text-white">DRINKS DEPOT</span>
            </div>
            <p className="text-[10px] text-zinc-500 leading-relaxed font-semibold max-w-xs">
              Glasgow&apos;s Everyday Low-Cost Drinks Supermarket. Standardized crate shipping. Bulk pallet economics. Straightforward service.
            </p>
          </div>

          {/* Footer sections */}
          <div>
            <h4 className="text-xs font-black text-white uppercase tracking-widest mb-4">SHOP DEPTS</h4>
            <ul className="space-y-2 text-[11px] text-zinc-500 font-semibold uppercase tracking-wider">
              <li><button onClick={() => { setSelectedCategory('BEER'); setActiveTab('SHOP'); }} className="hover:text-white cursor-pointer">Beer</button></li>
              <li><button onClick={() => { setSelectedCategory('CIDER'); setActiveTab('SHOP'); }} className="hover:text-white cursor-pointer">Cider</button></li>
              <li><button onClick={() => { setSelectedCategory('WINE'); setActiveTab('SHOP'); }} className="hover:text-white cursor-pointer">Wine</button></li>
              <li><button onClick={() => { setSelectedCategory('SPIRITS'); setActiveTab('SHOP'); }} className="hover:text-white cursor-pointer">Spirits</button></li>
              <li><button onClick={() => { setSelectedCategory('SOFT DRINKS'); setActiveTab('SHOP'); }} className="hover:text-white cursor-pointer">Soft Drinks</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black text-white uppercase tracking-widest mb-4">DEPOT SERVICES</h4>
            <ul className="space-y-2 text-[11px] text-zinc-500 font-semibold uppercase tracking-wider">
              <li><button onClick={() => setActiveTab('ABOUT')} className="hover:text-white cursor-pointer">Our Story</button></li>
              <li><button onClick={() => setActiveTab('STORES')} className="hover:text-white cursor-pointer">Stores Locator</button></li>
              <li><button onClick={() => setActiveTab('SHOP')} className="hover:text-white cursor-pointer">Delivery Zones</button></li>
              <li><button onClick={() => setActiveTab('DIAGNOSTICS')} className="hover:text-white cursor-pointer font-mono text-[10px]">Test Lab Panel</button></li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-black text-white uppercase tracking-widest mb-4">LEGAL STATEMENT</h4>
            <p className="text-[10px] text-zinc-500 leading-relaxed font-medium">
              This site is a fictional demo commerce store built for Glasgow, Scotland. No real purchases, real-money transactions, or alcohol orders are fulfilled. Fictional inventory is simulated deterministically under local system diagnostics.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto mt-12 pt-6 border-t border-zinc-900 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] text-zinc-500 uppercase tracking-widest font-semibold">
          <span>© 2026 GLASGOW DRINKS DEPOT LTD. ALL RIGHTS RESERVED.</span>
          <span>DEVELOPER PILOT MODE (GLASGOW-DEPOT-DEMO-001)</span>
        </div>
      </footer>
    </div>
  );
}
