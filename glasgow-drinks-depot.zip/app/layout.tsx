import type {Metadata} from 'next';
import './globals.css'; // Global styles
import { DepotStoreProvider } from '@/hooks/use-depot-store';

export const metadata: Metadata = {
  title: 'Glasgow Drinks Depot — Low-Cost Drinks Supermarket',
  description: 'Everyday drinks, serious choice, and Glasgow prices. Find cheap beer, cider, wine, spirits, and soft drinks with fast Click & Collect or local van delivery.',
  openGraph: {
    title: 'Glasgow Drinks Depot — Low-Cost Drinks Supermarket',
    description: 'Everyday drinks, serious choice, and Glasgow prices. Find cheap beer, cider, wine, spirits, and soft drinks with fast Click & Collect or local van delivery.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Glasgow Drinks Depot — Low-Cost Drinks Supermarket',
    description: 'Everyday drinks, serious choice, and Glasgow prices. Find cheap beer, cider, wine, spirits, and soft drinks with fast Click & Collect or local van delivery.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body suppressHydrationWarning className="bg-zinc-950 min-h-screen text-white antialiased">
        <DepotStoreProvider>
          {children}
        </DepotStoreProvider>
      </body>
    </html>
  );
}
