'use client';

import { useState, useRef, useEffect } from 'react';
import { useDepotStore } from '@/hooks/use-depot-store';
import { Search, X, Beer, Filter, SlidersHorizontal, CornerDownRight } from 'lucide-react';

const POPULAR_SEARCHES = ['lager', 'whisky', 'case', 'local', 'soft drinks', 'red wine', 'multipack'];

export default function SearchBar() {
  const {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    sortBy,
    setSortBy,
    catalog
  } = useDepotStore();

  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Categories extracted from catalog
  const categories = ['ALL', 'BEER', 'CIDER', 'WINE', 'SPIRITS', 'MIXERS', 'SOFT DRINKS', 'ENERGY', 'SNACKS'];

  // Handle autocomplete matching on the fly during render to prevent cascading renders
  const suggestions = searchQuery.trim() === ''
    ? []
    : Array.from(
        new Set(
          catalog
            .filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.brand.toLowerCase().includes(searchQuery.toLowerCase()) || p.subcategory.toLowerCase().includes(searchQuery.toLowerCase()))
            .map(p => p.name)
            .slice(0, 5)
        )
      );

  // Handle outside click to close suggestions
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectSuggestion = (value: string) => {
    setSearchQuery(value);
    setIsOpen(false);
  };

  const handleClear = () => {
    setSearchQuery('');
  };

  return (
    <div ref={containerRef} className="w-full bg-zinc-900 border border-zinc-800 p-4 md:p-6 mb-8 flex flex-col gap-4 relative">
      <div className="flex flex-col md:flex-row gap-3 items-stretch">
        
        {/* Input area */}
        <div className="flex-1 relative">
          <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-zinc-500">
            <Search className="w-4 h-4" />
          </div>
          
          <input
            type="text"
            value={searchQuery}
            onFocus={() => setIsOpen(true)}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setIsOpen(true);
            }}
            placeholder="Search catalog... (e.g. 'St. Mungo', 'Lager', 'Whisky', 'Save')"
            className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none pl-10 pr-10 py-3 text-sm font-semibold tracking-wide text-white placeholder-zinc-500 rounded-none transition-colors duration-150"
          />

          {searchQuery && (
            <button
              onClick={handleClear}
              className="absolute inset-y-0 right-3 flex items-center text-zinc-400 hover:text-white cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}

          {/* Autocomplete dropdown */}
          {isOpen && (suggestions.length > 0 || searchQuery.trim() !== '') && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-zinc-950 border border-zinc-800 shadow-2xl z-20">
              {suggestions.length > 0 ? (
                <div className="p-2 border-b border-zinc-900">
                  <div className="text-[10px] text-zinc-500 font-bold uppercase px-3 py-1 tracking-wider">MATCHING PRODUCTS</div>
                  {suggestions.map((sug, idx) => (
                    <button
                      key={idx}
                      onClick={() => handleSelectSuggestion(sug)}
                      className="w-full text-left px-3 py-2 text-xs font-semibold text-zinc-300 hover:bg-zinc-900 hover:text-white flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <CornerDownRight className="w-3.5 h-3.5 text-red-500" />
                      {sug}
                    </button>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-center text-xs text-zinc-500 font-medium">No direct matches. Press Enter to search broadly.</div>
              )}
            </div>
          )}
        </div>

        {/* Category quick selectors */}
        <div className="flex flex-wrap gap-1.5 max-w-full overflow-x-auto pb-1 md:pb-0">
          {categories.slice(0, 5).map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-2 text-xs font-bold uppercase tracking-wider transition-all duration-150 rounded-none border cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'bg-red-600 text-white border-red-600'
                  : 'bg-zinc-950 text-zinc-400 border-zinc-800 hover:border-zinc-700 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
          {/* Categories dropdown for remaining categories */}
          <select
            value={categories.includes(selectedCategory) && categories.indexOf(selectedCategory) >= 5 ? selectedCategory : 'MORE'}
            onChange={(e) => {
              if (e.target.value !== 'MORE') setSelectedCategory(e.target.value);
            }}
            className="px-3 py-2 bg-zinc-950 text-zinc-400 border border-zinc-800 hover:border-zinc-700 hover:text-white text-xs font-bold uppercase tracking-wider rounded-none focus:outline-none focus:border-red-600"
          >
            <option value="MORE" disabled>MORE CATEGORIES</option>
            {categories.slice(5).map((cat) => (
              <option key={cat} value={cat} className="bg-zinc-950 text-white">
                {cat}
              </option>
            ))}
          </select>
        </div>

        {/* Sort option */}
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-zinc-500" />
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-zinc-950 text-zinc-300 border border-zinc-800 focus:border-red-600 focus:outline-none text-xs font-bold uppercase tracking-wider py-3 px-3 min-w-[130px] rounded-none cursor-pointer"
          >
            <option value="popular">POPULARITY</option>
            <option value="price-asc">PRICE: LOW TO HIGH</option>
            <option value="price-desc">PRICE: HIGH TO LOW</option>
            <option value="saving">BIGGEST SAVING</option>
            <option value="abv-desc">ALCOHOL CONTENT</option>
          </select>
        </div>
      </div>

      {/* Popular search tags */}
      <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-zinc-850">
        <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">SUGGESTIONS:</span>
        <div className="flex flex-wrap gap-2">
          {POPULAR_SEARCHES.map((term) => (
            <button
              key={term}
              onClick={() => handleSelectSuggestion(term)}
              className="text-[11px] font-semibold text-zinc-400 hover:text-red-500 transition-colors cursor-pointer"
            >
              {term.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
