'use client';

import { useEffect } from 'react';
import { useDepotStore, SimulatedOrder } from '@/hooks/use-depot-store';
import { Truck, Check, Package, Clock, ShieldCheck, Box } from 'lucide-react';
import { motion } from 'motion/react';

export default function OrderTracker() {
  const { activeOrder, updateOrderStatus, orders } = useDepotStore();

  // Dynamic status simulation hook
  useEffect(() => {
    if (!activeOrder) return;
    
    const isDelivery = activeOrder.deliveryType === 'delivery';
    const statusSequence: SimulatedOrder['status'][] = isDelivery
      ? ['CONFIRMED', 'PICKING', 'PACKED', 'OUT_FOR_DELIVERY', 'DELIVERED']
      : ['CONFIRMED', 'PICKING', 'PACKED', 'READY_FOR_COLLECTION'];

    const currentIndex = statusSequence.indexOf(activeOrder.status);
    
    // If order is completed or fully delivered, stop simulating
    if (currentIndex === -1 || currentIndex === statusSequence.length - 1) return;

    // Set a timer to advance status every 12 seconds
    const timer = setTimeout(() => {
      const nextStatus = statusSequence[currentIndex + 1];
      updateOrderStatus(activeOrder.id, nextStatus);
    }, 12000);

    return () => clearTimeout(timer);
  }, [activeOrder, updateOrderStatus]);

  if (!activeOrder) {
    return (
      <div className="bg-zinc-950 border border-zinc-800 p-8 text-center space-y-4">
        <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600 mx-auto">
          <Truck className="w-6 h-6" />
        </div>
        <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider">NO ACTIVE ORDERS</h3>
        <p className="text-xs text-zinc-500 max-w-xs mx-auto leading-relaxed">
          Place a simulated checkout order to watch our real-time picking, packing, and dispatch tracker in action.
        </p>
      </div>
    );
  }

  const isDelivery = activeOrder.deliveryType === 'delivery';
  const stages = isDelivery
    ? [
        { label: 'CONFIRMED', desc: 'Order received at depot database' },
        { label: 'PICKING', desc: 'Depot floor assistants picking goods' },
        { label: 'PACKED', desc: 'Crates secured on transport pallet' },
        { label: 'OUT_FOR_DELIVERY', desc: 'Loaded into local Drinks Depot van' },
        { label: 'DELIVERED', desc: 'Package hand-delivered & age-verified' }
      ]
    : [
        { label: 'CONFIRMED', desc: 'Order received at depot database' },
        { label: 'PICKING', desc: 'Store floor assistants picking items' },
        { label: 'PACKED', desc: 'Packed securely in reusable crate bags' },
        { label: 'READY_FOR_COLLECTION', desc: 'Awaiting your pickup at selected depot' }
      ];

  const currentStageIndex = stages.findIndex(s => s.label === activeOrder.status);

  return (
    <div className="bg-zinc-950 border border-zinc-800 p-6 space-y-6">
      {/* Tracking Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-zinc-900 pb-4">
        <div>
          <span className="text-[10px] text-red-500 font-extrabold uppercase tracking-widest block mb-0.5">
            REAL-TIME DEPOT dispatch
          </span>
          <h2 className="text-xl font-black text-white tracking-tight">
            ORDER {activeOrder.id}
          </h2>
        </div>
        <div className="text-right sm:text-right">
          <span className="text-xs text-zinc-400 font-bold block uppercase tracking-wide">
            {activeOrder.deliveryType === 'delivery' ? 'LOCAL VAN DELIVERY' : 'STORE CLICK & COLLECT'}
          </span>
          <span className="text-[10px] text-zinc-500 font-mono tracking-wider">
            PLACED ON: {activeOrder.date}
          </span>
        </div>
      </div>

      {/* Progress Stepper Graph */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
        {stages.map((stage, idx) => {
          const isCompleted = idx <= currentStageIndex;
          const isCurrent = idx === currentStageIndex;
          
          return (
            <div
              key={stage.label}
              className={`p-4 border transition-all relative ${
                isCurrent
                  ? 'bg-zinc-900 border-red-600 shadow-md'
                  : isCompleted
                  ? 'bg-zinc-950 border-zinc-800'
                  : 'bg-zinc-950 border-zinc-900 opacity-40'
              }`}
            >
              {/* Stage Line connection indicators */}
              {idx < stages.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-2.5 w-5 h-0.5 bg-zinc-800 z-10" />
              )}

              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="font-mono text-[10px] font-black text-zinc-500">STAGE 0{idx + 1}</span>
                {isCompleted && (
                  <Check className="w-3.5 h-3.5 text-green-500 shrink-0" />
                )}
              </div>

              <h4 className="text-xs font-black text-white uppercase tracking-wider mb-1">
                {stage.label.replace(/_/g, ' ')}
              </h4>
              <p className="text-[10px] text-zinc-500 leading-normal font-medium">
                {stage.desc}
              </p>
            </div>
          );
        })}
      </div>

      {/* Real-time ticker info */}
      <div className="flex flex-col sm:flex-row items-center gap-4 bg-zinc-900 border border-zinc-850 p-4">
        <Clock className="w-5 h-5 text-red-500 animate-pulse shrink-0" />
        <div className="text-xs text-zinc-400 leading-relaxed flex-1">
          <span className="font-extrabold text-white uppercase block mb-0.5">STATUS SIMULATOR ACTIVE</span>
          Your order state will automatically advance every 12 seconds to showcase picking, packing and dispatch logistics. Real depot clerks pick and check products inside modern climate-controlled vaults.
        </div>
        <div className="text-xs font-bold font-mono text-zinc-500 shrink-0">
          STOCKED BY DEPOT CLERKS
        </div>
      </div>

      {/* Item Summary Checklist */}
      <div className="pt-4 border-t border-zinc-900">
        <h3 className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-3">ORDER PRODUCTS CHECKLIST</h3>
        <div className="divide-y divide-zinc-900">
          {activeOrder.items.map((item) => (
            <div key={item.product.id} className="flex items-center justify-between py-2.5 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-red-500">[{item.quantity}x]</span>
                <span className="font-semibold text-zinc-300">{item.product.name}</span>
                <span className="text-[10px] text-zinc-500">· {item.product.size}</span>
              </div>
              <span className="font-mono text-zinc-400 font-bold">£{(item.product.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
