'use client';

import { Product } from '@/lib/catalog';
import { useDepotStore } from '@/hooks/use-depot-store';
import { ShoppingBag, Flame, MapPin } from 'lucide-react';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const { addToCart, cart } = useDepotStore();

  // Find if this product is already in the cart to show quantity
  const cartItem = cart.find(it => it.product.id === product.id);
  const qtyInCart = cartItem ? cartItem.quantity : 0;

  // Stock indicator styling
  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= 15;

  // Unit Price calculation
  const unitPricePerLitre = product.volumeLiters > 0 
    ? (product.price / product.volumeLiters).toFixed(2)
    : '0.00';

  return (
    <motion.div
      whileHover={{ y: -2 }}
      transition={{ duration: 0.15, ease: 'easeOut' }}
      className="bg-zinc-950 border border-zinc-800 p-4 relative flex flex-col justify-between group h-full shadow-md select-none rounded-none"
    >
      {/* Top action / brand info with Zero-Pill tags */}
      <div>
        <div className="flex items-center justify-between gap-2 mb-2 text-[10px] text-zinc-500 font-bold uppercase tracking-widest">
          <div className="flex items-center gap-1.5">
            <span>{product.category}</span>
            <span aria-hidden="true" className="text-zinc-700">·</span>
            <span>{product.origin}</span>
          </div>
          {product.tags.includes('local') && (
            <span className="text-red-500 flex items-center gap-1 font-extrabold">
              <MapPin className="w-3 h-3" />
              SCOTTISH
            </span>
          )}
        </div>

        {/* Product Title & Brand */}
        <div className="mb-2">
          <h4 className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider mb-0.5 leading-none">
            {product.brand}
          </h4>
          <h3 className="text-sm font-extrabold text-white group-hover:text-red-500 transition-colors leading-snug tracking-wide line-clamp-2">
            {product.name}
          </h3>
        </div>

        {/* Product Size & ABV */}
        <div className="flex items-center gap-2 text-xs text-zinc-500 font-semibold mb-4">
          <span>{product.size}</span>
          {product.abv !== undefined && (
            <>
              <span aria-hidden="true" className="text-zinc-700">·</span>
              <span className="text-red-500/85">{product.abv.toFixed(1)}% ABV</span>
            </>
          )}
        </div>
      </div>

      {/* Pricing and Buying Section */}
      <div>
        {/* Deal info if any */}
        {product.prevPrice && (
          <div className="text-xs font-bold text-red-500 flex items-center gap-1 mb-1 animate-pulse">
            <Flame className="w-3.5 h-3.5" />
            <span>SPECIAL DEPOT DEAL</span>
          </div>
        )}

        {/* Price display with unit pricing */}
        <div className="flex items-baseline justify-between gap-2 mb-4">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-white font-mono tracking-tight tabular-nums">
              £{product.price.toFixed(2)}
            </span>
            {product.prevPrice && (
              <span className="text-xs text-zinc-500 font-semibold line-through font-mono tabular-nums">
                £{product.prevPrice.toFixed(2)}
              </span>
            )}
          </div>
          <span className="text-[10px] text-zinc-500 font-mono tracking-wider">
            £{unitPricePerLitre}/L
          </span>
        </div>

        {/* Stock Alert Label */}
        <div className="text-[10px] font-bold tracking-wider uppercase mb-3 flex items-center justify-between">
          {isOutOfStock ? (
            <span className="text-zinc-600">OUT OF STOCK</span>
          ) : isLowStock ? (
            <span className="text-yellow-600">LOW STOCK · ONLY {product.stock} LEFT</span>
          ) : (
            <span className="text-zinc-500">IN STOCK · AVAILABLE</span>
          )}
          
          {qtyInCart > 0 && (
            <span className="text-red-500 font-black">{qtyInCart} IN BASKET</span>
          )}
        </div>

        {/* Buy CTA */}
        <button
          onClick={() => addToCart(product, 1)}
          disabled={isOutOfStock}
          className={`w-full py-2.5 px-3 font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer rounded-none border ${
            isOutOfStock
              ? 'bg-zinc-900 text-zinc-600 border-zinc-850 cursor-not-allowed'
              : 'bg-zinc-900 hover:bg-red-600 text-white border-zinc-800 hover:border-red-600'
          }`}
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          {isOutOfStock ? 'OUT OF STOCK' : 'ADD TO BASKET'}
        </button>
      </div>
    </motion.div>
  );
}
