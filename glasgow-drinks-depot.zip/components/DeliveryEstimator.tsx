'use client';

import { useState } from 'react';
import { useDepotStore, DEPUT_DELIVERY_ZONES } from '@/hooks/use-depot-store';
import { Truck, Check, HelpCircle, MapPin, Building, ShieldCheck } from 'lucide-react';

export default function DeliveryEstimator() {
  const { postcode, checkPostcode, deliveryEligible } = useDepotStore();
  const [inputVal, setInputVal] = useState(postcode);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    checkPostcode(inputVal);
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 p-6 space-y-6">
      <div>
        <h2 className="text-lg font-black text-white tracking-wide uppercase flex items-center gap-2">
          <Truck className="w-5 h-5 text-red-500" />
          <span>DEPOT DELIVERY ESTIMATOR</span>
        </h2>
        <p className="text-xs text-zinc-500 font-semibold mt-1 uppercase tracking-wider">
          ENTER YOUR GLASGOW POSTCODE TO SEE SERVICES & ESTIMATED WINDOWS
        </p>
      </div>

      <form onSubmit={handleSubmit} className="flex gap-2">
        <input
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder="e.g. G11, G12, G41, PA1"
          className="bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-4 py-2.5 text-xs font-semibold uppercase tracking-widest text-white font-mono placeholder-zinc-500 rounded-none w-full max-w-xs transition-colors"
        />
        <button
          type="submit"
          className="px-6 py-2.5 bg-red-600 hover:bg-red-700 active:bg-red-850 text-white font-bold text-xs uppercase tracking-wider transition-colors rounded-none cursor-pointer"
        >
          CHECK POSTCODE
        </button>
      </form>

      {/* Result UI */}
      {deliveryEligible !== 'idle' && (
        <div className="border border-zinc-850 p-4 bg-zinc-900/50">
          {deliveryEligible === 'eligible' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-green-500 font-extrabold text-xs uppercase tracking-wider">
                <Check className="w-4 h-4" />
                <span>DIRECT VAN DELIVERY AVAILABLE!</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                Your address is within our core Glasgow delivery zone. Order before 4:00 PM for same-day delivery. Standard delivery £3.50, or **FREE when you spend £40 or more!**
              </p>
            </div>
          )}

          {deliveryEligible === 'collection-only' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-yellow-600 font-extrabold text-xs uppercase tracking-wider">
                <Building className="w-4 h-4" />
                <span>CLICK & COLLECT ONLY AVAILABLE</span>
              </div>
              <p className="text-xs text-zinc-300 leading-relaxed">
                Your postcode is slightly outside our local van delivery zone but within Glasgow territory. You can place your order online and pick up **FREE** at any of our 4 local depots within 1 hour!
              </p>
            </div>
          )}

          {deliveryEligible === 'outside' && (
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-zinc-500 font-extrabold text-xs uppercase tracking-wider">
                <HelpCircle className="w-4 h-4" />
                <span>OUTSIDE DEMO AREA</span>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                This postcode falls outside our current Western Scotland pilot zone. However, as this is a **DEMO SITE**, you are free to check out using simulated addresses or collections!
              </p>
            </div>
          )}
        </div>
      )}

      {/* Zone list details */}
      <div className="pt-4 border-t border-zinc-900">
        <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest block mb-2">GLASGOW SERVICE PILOT ZONES:</span>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-[11px] font-semibold text-zinc-400">
          {DEPUT_DELIVERY_ZONES.map((zone, idx) => (
            <div key={idx} className="flex items-start gap-1.5">
              <span className="text-red-500">•</span>
              <div>
                <span className="text-white block uppercase tracking-wide">{zone.area}</span>
                <span className="text-[10px] text-zinc-500 font-mono">{zone.postcodes.join(', ')}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
