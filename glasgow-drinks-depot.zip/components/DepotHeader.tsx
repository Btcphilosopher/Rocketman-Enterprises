'use client';

import { useDepotStore } from '@/hooks/use-depot-store';
import { ShoppingBag, Search, BarChart3, HelpCircle } from 'lucide-react';

export default function DepotHeader() {
  const { cart, activeTab, setActiveTab, setCartOpen } = useDepotStore();
  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-zinc-950 text-white border-b border-zinc-800">
      {/* Top Announcement Bar - Only 30px high, clean & subtle */}
      <div className="bg-red-600 text-white text-[10px] font-bold uppercase tracking-widest text-center py-1.5 px-4 h-[30px] flex items-center justify-center">
        GLASGOW DRINKS DEPOT · LOW PRICES EVERY DAY · FREE CLICK & COLLECT
      </div>

      {/* Main Top Bar Contract - Exactly One Row, Three Zones */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark (Single element) */}
        <button
          onClick={() => setActiveTab('SHOP')}
          className="text-left select-none group cursor-pointer focus:outline-none"
        >
          <div className="font-sans font-extrabold tracking-tighter leading-none flex flex-col">
            <span className="text-[10px] tracking-[0.25em] text-red-600 leading-none">GLASGOW</span>
            <span className="text-xl md:text-2xl font-black text-white group-hover:text-red-500 transition-colors leading-none mt-0.5">DRINKS DEPOT</span>
          </div>
        </button>

        {/* Zone 2: 5 Clean Text Navigation Links */}
        <nav className="hidden lg:flex items-center gap-8 text-xs font-semibold uppercase tracking-wider text-zinc-400">
          <button
            onClick={() => setActiveTab('SHOP')}
            className={`transition-colors py-1 cursor-pointer relative hover:text-white ${
              activeTab === 'SHOP' ? 'text-white border-b border-red-600' : ''
            }`}
          >
            SHOP
          </button>
          
          <button
            onClick={() => setActiveTab('DEALS')}
            className={`transition-colors py-1 cursor-pointer relative hover:text-white ${
              activeTab === 'DEALS' ? 'text-white border-b border-red-600' : ''
            }`}
          >
            DEALS
          </button>
          
          <button
            onClick={() => setActiveTab('STORES')}
            className={`transition-colors py-1 cursor-pointer relative hover:text-white ${
              activeTab === 'STORES' ? 'text-white border-b border-red-600' : ''
            }`}
          >
            STORES
          </button>

          <button
            onClick={() => setActiveTab('TRACKING')}
            className={`transition-colors py-1 cursor-pointer relative hover:text-white ${
              activeTab === 'TRACKING' ? 'text-white border-b border-red-600' : ''
            }`}
          >
            TRACKING
          </button>

          <button
            onClick={() => setActiveTab('ABOUT')}
            className={`transition-colors py-1 cursor-pointer relative hover:text-white ${
              activeTab === 'ABOUT' ? 'text-white border-b border-red-600' : ''
            }`}
          >
            ABOUT
          </button>

          <button
            onClick={() => setActiveTab('DIAGNOSTICS')}
            className={`transition-colors py-1 cursor-pointer relative hover:text-white ${
              activeTab === 'DIAGNOSTICS' ? 'text-white border-b border-red-600 font-mono text-[10px]' : 'font-mono text-[10px]'
            }`}
          >
            TEST_SUITE
          </button>
        </nav>

        {/* Zone 3: Direct Actions (Basket, Search/View toggle) */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setCartOpen(true)}
            className="flex items-center gap-2 px-3 py-2 bg-zinc-900 border border-zinc-800 hover:border-zinc-700 hover:bg-zinc-800 text-white font-bold text-xs uppercase tracking-wider transition-all cursor-pointer relative"
          >
            <ShoppingBag className="w-4 h-4 text-red-500" />
            <span className="hidden sm:inline">BASKET</span>
            <span className="bg-red-600 text-white font-mono font-bold text-[10px] px-1.5 py-0.5 rounded-none min-w-[1.5rem] text-center ml-1">
              {totalCartItems}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
}
