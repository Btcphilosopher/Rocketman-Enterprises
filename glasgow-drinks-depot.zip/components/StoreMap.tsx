'use client';

import { useDepotStore, DEPOT_STORES, DepotStore } from '@/hooks/use-depot-store';
import { MapPin, Navigation, Clock, ShieldCheck, SquareTerminal } from 'lucide-react';

export default function StoreMap() {
  const { selectedStore, setSelectedStore, setDeliveryType } = useDepotStore();

  const handleSelectStore = (store: DepotStore) => {
    setSelectedStore(store);
    setDeliveryType('collection');
  };

  return (
    <div className="bg-zinc-950 border border-zinc-800 p-6 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-zinc-900 pb-4">
        <div>
          <h2 className="text-xl font-black text-white tracking-wide uppercase">
            GLASGOW DEPOT STORE FINDER
          </h2>
          <p className="text-xs text-zinc-500 font-semibold mt-1 uppercase tracking-wider">
            LOCAL ROOTS · 4 WAREHOUSES CONVENIENTLY SPANNING THE CLYDE
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-bold uppercase text-red-500">
          <Clock className="w-4 h-4 text-red-500" />
          <span>OPEN EVERY DAY UNTIL 10PM / 11PM</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Store Cards List */}
        <div className="lg:col-span-5 space-y-3 max-h-[500px] overflow-y-auto pr-2">
          {DEPOT_STORES.map((store) => {
            const isSelected = selectedStore.id === store.id;
            return (
              <div
                key={store.id}
                onClick={() => handleSelectStore(store)}
                className={`p-4 border cursor-pointer transition-all duration-200 ${
                  isSelected
                    ? 'bg-zinc-900 border-red-600 shadow-lg'
                    : 'bg-zinc-950 border-zinc-850 hover:border-zinc-700'
                }`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-sm font-black text-white uppercase tracking-wider">
                    {store.name}
                  </h3>
                  {isSelected && (
                    <span className="text-[9px] font-bold bg-red-600 text-white px-1.5 py-0.5 uppercase tracking-widest">
                      SELECTED
                    </span>
                  )}
                </div>
                
                <p className="text-xs text-zinc-400 font-semibold leading-relaxed mb-3">
                  {store.address}
                </p>

                <div className="space-y-1 text-[11px] font-semibold text-zinc-500">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-zinc-600" />
                    <span>{store.hours}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Navigation className="w-3.5 h-3.5 text-zinc-600" />
                    <span>{store.parking}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 mt-4">
                  {store.services.map((service, sIdx) => (
                    <span
                      key={sIdx}
                      className="text-[9px] font-bold text-zinc-400 border border-zinc-850 px-2 py-0.5"
                    >
                      {service.toUpperCase()}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Right Side: Beautiful Vector Interactive Map of Glasgow */}
        <div className="lg:col-span-7 bg-zinc-900 border border-zinc-850 p-4 relative flex flex-col justify-between h-[350px] md:h-[450px]">
          {/* Map Title/Tagline */}
          <div className="absolute top-4 left-4 z-10 bg-zinc-950/90 border border-zinc-800 px-3 py-1.5">
            <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block">GLASGOW VECTOR COORDINATES</span>
            <span className="text-[11px] font-black text-red-500 uppercase">DEPOT LOCATOR MAP</span>
          </div>

          {/* SVG Map Canvas */}
          <div className="w-full h-full flex items-center justify-center relative overflow-hidden bg-zinc-950 select-none">
            <svg
              viewBox="0 0 600 400"
              className="w-full h-full max-w-full max-h-full stroke-zinc-850 fill-none"
            >
              {/* Grid Lines */}
              <defs>
                <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(255,255,255,0.02)" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* The River Clyde (winding through Glasgow) */}
              <path
                d="M 50 250 Q 150 240 250 210 T 450 180 T 550 150"
                stroke="rgba(37, 99, 235, 0.4)"
                strokeWidth="18"
                strokeLinecap="round"
                className="transition-all"
              />
              <path
                d="M 50 250 Q 150 240 250 210 T 450 180 T 550 150"
                stroke="rgba(37, 99, 235, 0.2)"
                strokeWidth="28"
                strokeLinecap="round"
              />

              {/* Major Glasgow Roads */}
              {/* M8 Motorway */}
              <path
                d="M 100 50 L 250 120 L 300 200 L 280 350"
                stroke="rgba(255,255,255,0.06)"
                strokeWidth="4"
                strokeLinecap="round"
              />
              {/* Great Western Road */}
              <path
                d="M 50 100 L 250 170"
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="2"
                strokeLinecap="round"
              />
              {/* Gallowgate / Duke Street */}
              <path
                d="M 300 200 L 550 180"
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="2"
                strokeLinecap="round"
              />

              {/* Store Map Pins */}
              {/* 1. Glasgow City Centre Depot (Center, G1) */}
              <g
                className="cursor-pointer group"
                onClick={() => handleSelectStore(DEPOT_STORES[0])}
                transform="translate(290, 190)"
              >
                <circle r={selectedStore.id === 'glasgow-city' ? 14 : 8} fill="rgba(220, 38, 38, 0.15)" />
                <circle r="4" fill={selectedStore.id === 'glasgow-city' ? '#dc2626' : '#71717a'} className="transition-all duration-300" />
                <text x="12" y="4" className="fill-zinc-400 font-sans font-bold text-[9px] uppercase tracking-wide opacity-80 group-hover:opacity-100">
                  CITY
                </text>
              </g>

              {/* 2. South Glasgow Depot (Bottom-Middle, G41) */}
              <g
                className="cursor-pointer group"
                onClick={() => handleSelectStore(DEPOT_STORES[1])}
                transform="translate(270, 290)"
              >
                <circle r={selectedStore.id === 'south-glasgow' ? 14 : 8} fill="rgba(220, 38, 38, 0.15)" />
                <circle r="4" fill={selectedStore.id === 'south-glasgow' ? '#dc2626' : '#71717a'} className="transition-all duration-300" />
                <text x="12" y="4" className="fill-zinc-400 font-sans font-bold text-[9px] uppercase tracking-wide opacity-80 group-hover:opacity-100">
                  SOUTHSIDE
                </text>
              </g>

              {/* 3. West Glasgow Depot (Top-Left, G11) */}
              <g
                className="cursor-pointer group"
                onClick={() => handleSelectStore(DEPOT_STORES[2])}
                transform="translate(140, 160)"
              >
                <circle r={selectedStore.id === 'west-glasgow' ? 14 : 8} fill="rgba(220, 38, 38, 0.15)" />
                <circle r="4" fill={selectedStore.id === 'west-glasgow' ? '#dc2626' : '#71717a'} className="transition-all duration-300" />
                <text x="12" y="4" className="fill-zinc-400 font-sans font-bold text-[9px] uppercase tracking-wide opacity-80 group-hover:opacity-100">
                  WEST END
                </text>
              </g>

              {/* 4. East Glasgow Depot (Middle-Right, G31) */}
              <g
                className="cursor-pointer group"
                onClick={() => handleSelectStore(DEPOT_STORES[3])}
                transform="translate(420, 180)"
              >
                <circle r={selectedStore.id === 'east-glasgow' ? 14 : 8} fill="rgba(220, 38, 38, 0.15)" />
                <circle r="4" fill={selectedStore.id === 'east-glasgow' ? '#dc2626' : '#71717a'} className="transition-all duration-300" />
                <text x="12" y="4" className="fill-zinc-400 font-sans font-bold text-[9px] uppercase tracking-wide opacity-80 group-hover:opacity-100">
                  EAST END
                </text>
              </g>
            </svg>
          </div>

          {/* Map Footer status */}
          <div className="flex items-center justify-between border-t border-zinc-850 pt-2 text-[10px] text-zinc-500 font-bold uppercase">
            <span>ACTIVE STORE VIEW: {selectedStore.name.toUpperCase()}</span>
            <span className="text-red-500 font-extrabold animate-pulse">● LIVE INTERACTIVE COORDS</span>
          </div>
        </div>
      </div>
    </div>
  );
}
