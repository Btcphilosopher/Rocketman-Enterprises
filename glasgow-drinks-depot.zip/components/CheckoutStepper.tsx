'use client';

import { useState } from 'react';
import { useDepotStore } from '@/hooks/use-depot-store';
import { CreditCard, CheckCircle, ShieldAlert, ArrowLeft, ArrowRight, User, ShoppingBag } from 'lucide-react';

interface CheckoutStepperProps {
  onBackToCart: () => void;
}

export default function CheckoutStepper({ onBackToCart }: CheckoutStepperProps) {
  const {
    cart,
    cartPricing,
    deliveryType,
    selectedStore,
    postcode: savedPostcode,
    submitOrder,
    setCartOpen
  } = useDepotStore();

  const [step, setStep] = useState(1); // 1: Delivery/Details, 2: Age Verification, 3: Simulated Payment
  const [form, setForm] = useState({
    name: 'Tom Glasgow',
    phone: '07712345678',
    address: '45 Sauchiehall Street',
    postcode: savedPostcode || 'G1 3DX',
    email: 'tom@ahyx.org'
  });
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [paymentType, setPaymentType] = useState<'card' | 'apple' | 'google'>('card');
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8812');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const deliveryFee = deliveryType === 'delivery' ? (cartPricing.total >= 40 ? 0 : 3.50) : 0;
  const finalTotal = cartPricing.total + deliveryFee;

  const handleNext = () => {
    if (step === 1) {
      if (!form.name || !form.phone || (deliveryType === 'delivery' && (!form.address || !form.postcode))) {
        alert('Please fill out all required details.');
        return;
      }
      setStep(2);
    } else if (step === 2) {
      if (!ageConfirmed) {
        alert('You must confirm that you are at least 18 years of age and understand our compliance rules.');
        return;
      }
      setStep(3);
    }
  };

  const handleBack = () => {
    if (step === 1) {
      onBackToCart();
    } else {
      setStep(step - 1);
    }
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    // Simulate payment authorization
    setTimeout(() => {
      submitOrder(form);
      setIsSubmitting(false);
      setCartOpen(false); // Close cart drawer
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Visual Stepper Indicators */}
      <div className="flex items-center justify-between border-b border-zinc-900 pb-4">
        {['DETAILS', 'COMPLIANCE', 'PAYMENT'].map((label, index) => {
          const currentStep = index + 1;
          const isActive = step === currentStep;
          const isDone = step > currentStep;
          return (
            <div key={label} className="flex items-center gap-2">
              <span
                className={`w-5 h-5 flex items-center justify-center font-mono text-[10px] font-bold ${
                  isActive
                    ? 'bg-red-600 text-white'
                    : isDone
                    ? 'bg-zinc-800 text-green-500 border border-green-500'
                    : 'bg-zinc-900 text-zinc-500 border border-zinc-800'
                }`}
              >
                {isDone ? '✓' : currentStep}
              </span>
              <span
                className={`text-[10px] font-bold tracking-wider uppercase hidden sm:inline ${
                  isActive ? 'text-white' : 'text-zinc-500'
                }`}
              >
                {label}
              </span>
            </div>
          );
        })}
      </div>

      {/* STEP 1: Customer details */}
      {step === 1 && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-2">
            {deliveryType === 'delivery' ? '1. Local Delivery Details' : '1. Click & Collect Contact Details'}
          </h3>

          <div className="space-y-3">
            <div>
              <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Full Name *</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white rounded-none"
                placeholder="Full Name"
              />
            </div>

            <div>
              <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Email Address *</label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white rounded-none"
                placeholder="email@address.com"
              />
            </div>

            <div>
              <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Mobile Number (Delivery/Collection Alerts) *</label>
              <input
                type="text"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white rounded-none"
                placeholder="e.g. 07712345678"
              />
            </div>

            {deliveryType === 'delivery' ? (
              <>
                <div>
                  <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Glasgow Street Address *</label>
                  <input
                    type="text"
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white rounded-none"
                    placeholder="e.g. 15 Gallowgate Rd"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Glasgow Postcode *</label>
                  <input
                    type="text"
                    value={form.postcode}
                    onChange={(e) => setForm({ ...form, postcode: e.target.value })}
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white rounded-none font-mono"
                    placeholder="e.g. G11 6NU"
                  />
                </div>
              </>
            ) : (
              <div className="bg-zinc-900 border border-zinc-800 p-3">
                <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider block mb-1">SELECTED DEPOT FOR COLLECTION:</span>
                <span className="text-xs font-bold text-white block">{selectedStore.name}</span>
                <span className="text-[10px] text-zinc-500 block leading-normal mt-0.5">{selectedStore.address}</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* STEP 2: Age Verification Check on checkout */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="bg-yellow-600/10 border border-yellow-600/20 p-4 flex gap-3 text-yellow-600 mb-2">
            <ShieldAlert className="w-5 h-5 shrink-0" />
            <div className="text-xs leading-relaxed">
              <span className="font-extrabold uppercase block mb-1">SCOTTISH COMPLIANCE & CHALLENGE 25</span>
              By law, we operate a strict Challenge 25 policy on all deliveries and collections. You must display valid photo ID (Passport or Driving Licence) to receive or collect liquor order products.
            </div>
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              2. Age-Restricted Consent
            </h3>
            
            <p className="text-xs text-zinc-400 leading-relaxed">
              Under the Licensing (Scotland) Act 2005, it is an offence to attempt to buy alcohol if you are under 18, or to buy alcohol for someone under 18.
            </p>

            <label className="flex items-start gap-3 p-3 bg-zinc-900 border border-zinc-800 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={ageConfirmed}
                onChange={(e) => setAgeConfirmed(e.target.checked)}
                className="mt-0.5 accent-red-600 cursor-pointer"
              />
              <span className="text-xs text-zinc-300 font-semibold leading-normal">
                I certify that I am 18 years of age or older, and I consent that our delivery driver / collection clerk will verify my age on arrival.
              </span>
            </label>
          </div>
        </div>
      )}

      {/* STEP 3: Simulated Payment */}
      {step === 3 && (
        <div className="space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">
            3. Safe Simulated Payment
          </h3>
          <p className="text-xs text-zinc-400 leading-normal">
            No real credit card is required. All transactions are purely virtual and demo-only.
          </p>

          {/* Payment Type Tabs */}
          <div className="grid grid-cols-3 gap-2 bg-zinc-900 p-1 border border-zinc-850">
            {['card', 'apple', 'google'].map((type) => (
              <button
                key={type}
                onClick={() => setPaymentType(type as any)}
                className={`py-2 text-[10px] font-bold uppercase tracking-wider text-center cursor-pointer ${
                  paymentType === type ? 'bg-zinc-950 text-white border border-zinc-800' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {type === 'card' ? 'CARD' : type === 'apple' ? 'APPLE PAY' : 'GOOGLE PAY'}
              </button>
            ))}
          </div>

          {paymentType === 'card' ? (
            <div className="space-y-3">
              <div>
                <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Card Number</label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white font-mono rounded-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">Expiry</label>
                  <input
                    type="text"
                    defaultValue="12 / 29"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white font-mono rounded-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-zinc-500 font-bold uppercase mb-1">CVV</label>
                  <input
                    type="password"
                    defaultValue="•••"
                    className="w-full bg-zinc-950 border border-zinc-800 focus:border-red-600 focus:outline-none px-3 py-2 text-xs font-semibold text-white font-mono rounded-none"
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="border border-zinc-850 p-6 bg-zinc-900/50 text-center text-xs font-bold uppercase tracking-wider text-zinc-400">
              SIMULATED {paymentType.toUpperCase()} AUTHORIZATION READY
            </div>
          )}

          {/* Secure details reminder */}
          <div className="flex items-center gap-2 text-[10px] text-zinc-500 font-semibold uppercase justify-center mt-4 pt-4 border-t border-zinc-900">
            <CreditCard className="w-3.5 h-3.5" />
            <span>Pure Demo-Mode · No money charged</span>
          </div>
        </div>
      )}

      {/* Button Stepper Actions */}
      <div className="flex items-center justify-between gap-3 pt-6 border-t border-zinc-900">
        <button
          onClick={handleBack}
          className="px-4 py-2 bg-transparent hover:bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
        >
          {step === 1 ? 'BACK TO CART' : 'BACK'}
        </button>

        {step < 3 ? (
          <button
            onClick={handleNext}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-1 cursor-pointer"
          >
            <span>CONTINUE</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="px-6 py-2.5 bg-green-600 hover:bg-green-750 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? 'PROCESSING...' : `PLACE DEMO ORDER (£${finalTotal.toFixed(2)})`}
          </button>
        )}
      </div>
    </div>
  );
}
