'use client';

import { useDepotStore } from '@/hooks/use-depot-store';
import { motion, AnimatePresence } from 'motion/react';
import { X, Plus, Minus, Trash2, ShoppingBag, ShieldAlert, BadgePercent } from 'lucide-react';
import { useState } from 'react';
import CheckoutStepper from './CheckoutStepper';

export default function BasketDrawer() {
  const {
    cart,
    cartPricing,
    isCartOpen,
    setCartOpen,
    updateCartQty,
    removeFromCart,
    clearCart,
    deliveryType,
    setDeliveryType
  } = useDepotStore();

  const [showCheckout, setShowCheckout] = useState(false);

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);
  const deliveryFee = deliveryType === 'delivery' ? (cartPricing.total >= 40 ? 0 : 3.50) : 0;
  const finalTotal = cartPricing.total + deliveryFee;

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Overlay background */}
          <div
            className="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm z-50 transition-opacity"
            onClick={() => {
              setCartOpen(false);
              setShowCheckout(false);
            }}
          />

          {/* Drawer Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'tween', duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-y-0 right-0 w-full max-w-md md:max-w-lg bg-zinc-950 border-l border-zinc-800 z-50 flex flex-col justify-between shadow-2xl"
          >
            {/* Header */}
            <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <ShoppingBag className="w-5 h-5 text-red-500" />
                <h2 className="text-lg font-black text-white tracking-wide uppercase">
                  YOUR DEPOT BASKET ({totalCartItems})
                </h2>
              </div>
              <button
                onClick={() => {
                  setCartOpen(false);
                  setShowCheckout(false);
                }}
                className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-900 border border-transparent hover:border-zinc-800 cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content Container (Cart List vs Checkout Stepper) */}
            <div className="flex-1 overflow-y-auto p-6">
              {showCheckout ? (
                <CheckoutStepper onBackToCart={() => setShowCheckout(false)} />
              ) : (
                <>
                  {cart.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-center py-12">
                      <div className="w-16 h-16 bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-600 mb-4">
                        <ShoppingBag className="w-8 h-8" />
                      </div>
                      <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-wider mb-1">YOUR BASKET IS EMPTY</h3>
                      <p className="text-xs text-zinc-500 max-w-xs leading-relaxed">
                        Stock up on your favorite lagers, craft beers, wines, and local Scottish soft drinks at unbeatable wholesale pricing.
                      </p>
                      <button
                        onClick={() => setCartOpen(false)}
                        className="mt-6 px-6 py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs uppercase tracking-wider transition-colors cursor-pointer"
                      >
                        BROWSE RETAIL DEPOT
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Delivery/Collection Selector */}
                      <div className="grid grid-cols-2 gap-2 bg-zinc-900 p-1 border border-zinc-850 mb-6">
                        <button
                          onClick={() => setDeliveryType('collection')}
                          className={`py-2 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                            deliveryType === 'collection'
                              ? 'bg-zinc-950 text-white border border-zinc-800'
                              : 'text-zinc-500 hover:text-zinc-300'
                          }`}
                        >
                          CLICK & COLLECT (FREE)
                        </button>
                        <button
                          onClick={() => setDeliveryType('delivery')}
                          className={`py-2 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                            deliveryType === 'delivery'
                              ? 'bg-zinc-950 text-white border border-zinc-800'
                              : 'text-zinc-500 hover:text-zinc-300'
                          }`}
                        >
                          LOCAL DELIVERY (£3.50)
                        </button>
                      </div>

                      {/* Items List */}
                      <div className="space-y-4">
                        {cart.map((item) => (
                          <div
                            key={item.product.id}
                            className="flex items-start justify-between gap-4 py-4 border-b border-zinc-900 last:border-b-0"
                          >
                            <div className="flex-1 min-w-0">
                              <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest block mb-0.5">
                                {item.product.brand} · {item.product.size}
                              </span>
                              <h4 className="text-sm font-bold text-white truncate mb-2">
                                {item.product.name}
                              </h4>
                              <div className="flex items-center gap-2">
                                {/* Quantity Adjuster */}
                                <div className="flex items-center border border-zinc-800 bg-zinc-950">
                                  <button
                                    onClick={() => updateCartQty(item.product.id, item.quantity - 1)}
                                    className="p-1 hover:bg-zinc-900 text-zinc-400 hover:text-white cursor-pointer"
                                  >
                                    <Minus className="w-3.5 h-3.5" />
                                  </button>
                                  <span className="px-3 text-xs font-bold text-white font-mono tabular-nums">
                                    {item.quantity}
                                  </span>
                                  <button
                                    onClick={() => updateCartQty(item.product.id, item.quantity + 1)}
                                    className="p-1 hover:bg-zinc-900 text-zinc-400 hover:text-white cursor-pointer"
                                  >
                                    <Plus className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                                <button
                                  onClick={() => removeFromCart(item.product.id)}
                                  className="text-zinc-500 hover:text-red-500 p-1 cursor-pointer transition-colors"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>

                            {/* Item Price */}
                            <div className="text-right flex flex-col items-end shrink-0">
                              <span className="text-sm font-bold text-white font-mono tabular-nums">
                                £{(item.product.price * item.quantity).toFixed(2)}
                              </span>
                              <span className="text-[10px] text-zinc-500 font-mono">
                                £{item.product.price.toFixed(2)} each
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Clear cart option */}
                      <button
                        onClick={clearCart}
                        className="text-xs font-semibold text-zinc-500 hover:text-white transition-colors flex items-center gap-1.5 pt-4 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        CLEAR ALL BASKET ITEMS
                      </button>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* Footer Summary (Only visible when cart has items) */}
            {cart.length > 0 && !showCheckout && (
              <div className="p-6 bg-zinc-900 border-t border-zinc-800 space-y-4">
                {/* Applied discounts panel */}
                {cartPricing.discount > 0 && (
                  <div className="bg-red-650/10 border border-red-600/20 p-3 flex flex-col gap-1.5">
                    <div className="flex items-center gap-1.5 text-xs text-red-500 font-extrabold uppercase tracking-wider">
                      <BadgePercent className="w-4 h-4" />
                      <span>DEPOT SAVINGS APPLIED!</span>
                    </div>
                    {cartPricing.appliedPromoMessages.map((msg, idx) => (
                      <div key={idx} className="text-[11px] text-zinc-400 font-semibold pl-5 list-disc">
                        • {msg}
                      </div>
                    ))}
                  </div>
                )}

                {/* Subtotals & Fees */}
                <div className="space-y-1.5 text-xs font-semibold text-zinc-400">
                  <div className="flex justify-between">
                    <span>DEPOT MERCHANDISE SUBTOTAL</span>
                    <span className="font-mono text-zinc-200">£{cartPricing.subtotal.toFixed(2)}</span>
                  </div>

                  {cartPricing.discount > 0 && (
                    <div className="flex justify-between text-red-500 font-bold">
                      <span>DEPOT MULTIBUY DISCOUNTS</span>
                      <span className="font-mono">-£{cartPricing.discount.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>
                      {deliveryType === 'delivery' ? 'LOCAL VAN DELIVERY FEE' : 'DEPOT CLICK & COLLECT'}
                    </span>
                    <span className="font-mono text-zinc-200">
                      {deliveryFee === 0 ? 'FREE' : `£${deliveryFee.toFixed(2)}`}
                    </span>
                  </div>

                  {deliveryType === 'delivery' && cartPricing.total < 40 && (
                    <p className="text-[10px] text-yellow-600 italic mt-1 leading-normal">
                      Spend £{(40 - cartPricing.total).toFixed(2)} more for FREE local delivery!
                    </p>
                  )}
                </div>

                {/* Main Total Callout */}
                <div className="pt-3 border-t border-zinc-800 flex items-baseline justify-between">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-white">TOTAL PAYABLE</span>
                    <span className="text-[10px] text-zinc-500 block">Includes £{cartPricing.vatAmount.toFixed(2)} Scottish VAT</span>
                  </div>
                  <span className="text-3xl font-black text-white font-mono tracking-tighter">
                    £{finalTotal.toFixed(2)}
                  </span>
                </div>

                {/* Action Buttons */}
                <button
                  onClick={() => setShowCheckout(true)}
                  className="w-full py-3 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-sm uppercase tracking-wider text-center transition-colors cursor-pointer"
                >
                  SECURE DEMO CHECKOUT
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
