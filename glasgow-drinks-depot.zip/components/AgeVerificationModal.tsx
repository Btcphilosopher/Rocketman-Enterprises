'use client';

import { motion, AnimatePresence } from 'motion/react';
import { useDepotStore } from '@/hooks/use-depot-store';
import { ShieldCheck, LogOut, Beer } from 'lucide-react';

export default function AgeVerificationModal() {
  const { ageVerified, setAgeVerified } = useDepotStore();

  const handleVerify = () => {
    setAgeVerified(true);
  };

  const handleExit = () => {
    if (typeof window !== 'undefined') {
      window.location.href = 'https://www.drinkaware.co.uk';
    }
  };

  return (
    <AnimatePresence>
      {!ageVerified && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/95 backdrop-blur-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-md bg-zinc-900 border border-zinc-800 p-8 rounded-none flex flex-col items-center text-center shadow-2xl relative"
          >
            {/* Top accent price marker bar */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-red-600" />
            
            <div className="w-16 h-16 bg-red-600/10 border border-red-600/30 flex items-center justify-center mb-6 text-red-500">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <h1 className="font-sans text-2xl font-bold tracking-tight text-white mb-2 uppercase">
              AGE VERIFICATION REQUIRED
            </h1>
            <p className="font-sans text-xs text-zinc-400 tracking-wider mb-6">
              GLASGOW DRINKS DEPOT · LICENSED SCOTTISH RETAILER
            </p>

            <p className="text-zinc-300 text-sm mb-8 leading-relaxed">
              This website contains liquor sales and delivery offerings. Under the Licensing (Scotland) Act 2005, you must be 18 years of age or older to purchase alcohol.
            </p>

            <div className="w-full flex flex-col gap-3">
              <button
                onClick={handleVerify}
                className="w-full py-3 px-4 bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-sm uppercase tracking-wider transition-colors duration-200 cursor-pointer"
              >
                I AM 18 OR OVER
              </button>
              
              <button
                onClick={handleExit}
                className="w-full py-3 px-4 bg-transparent hover:bg-zinc-800 text-zinc-400 hover:text-white font-medium text-xs uppercase tracking-wider border border-zinc-800 transition-colors duration-200 cursor-pointer"
              >
                EXIT SITE
              </button>
            </div>

            <div className="mt-8 pt-6 border-t border-zinc-800 w-full flex items-center justify-center gap-2 text-[10px] text-zinc-500 tracking-wider">
              <Beer className="w-4 h-4" />
              <span>PLEASE DRINK RESPONSIBLY · DRINKAWARE.CO.UK</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
