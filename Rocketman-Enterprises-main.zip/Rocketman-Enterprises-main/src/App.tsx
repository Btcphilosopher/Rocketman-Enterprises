/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Layers, HelpCircle, Monitor, ShieldAlert, Cpu } from 'lucide-react';
import { Product, Order, Message, AuditLog } from './types';
import StoreFront from './components/StoreFront';
import SellerDashboard from './components/SellerDashboard';

export default function App() {
  // Navigation layout switcher: 'shop' (Digital Flagship) | 'dashboard' (Seller ERP)
  const [activeWorkspace, setActiveWorkspace] = useState<'shop' | 'dashboard'>('shop');

  // Master Relational States
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [logs, setLogs] = useState<AuditLog[]>([]);
  
  // Invoice states for customer checkout
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Network pricing mock rates for display
  const [btcRate, setBtcRate] = useState<number>(64231.02);
  const [usdtRate, setUsdtRate] = useState<number>(1.0001);

  // 1. Core State Sync Engine
  const syncState = async () => {
    try {
      const [prodsRes, ordersRes, msgsRes, logsRes] = await Promise.all([
        fetch('/api/products'),
        fetch('/api/orders'),
        fetch('/api/messages'),
        fetch('/api/logs')
      ]);

      const [prodsData, ordersData, msgsData, logsData] = await Promise.all([
        prodsRes.json(),
        ordersRes.json(),
        msgsRes.json(),
        logsRes.json()
      ]);

      setProducts(prodsData);
      setOrders(ordersData);
      setMessages(msgsData);
      setLogs(logsData);

      // If user is tracking an active invoice, sync its latest status from database
      if (activeOrder) {
        const currentInDb = ordersData.find((o: Order) => o.id === activeOrder.id);
        if (currentInDb) {
          setActiveOrder(currentInDb);
        }
      }
    } catch (e) {
      console.error('Error syncing State with Express server:', e);
    }
  };

  useEffect(() => {
    syncState();
    
    // Refresh states and simulate ticker price changes
    const interval = setInterval(() => {
      syncState();
      setBtcRate(prev => prev + (Math.random() * 20 - 10));
    }, 5000);

    return () => clearInterval(interval);
  }, [activeOrder?.id]);

  // 2. Direct API Mutation Bindings

  // PRODUCTS MUTATIONS
  const handleCreateProduct = async (prodPayload: any) => {
    const res = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(prodPayload)
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleUpdateProduct = async (id: string, prodPayload: any) => {
    const res = await fetch(`/api/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(prodPayload)
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleDuplicateProduct = async (id: string) => {
    const res = await fetch(`/api/products/${id}/duplicate`, { method: 'POST' });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleRelistProduct = async (id: string) => {
    const res = await fetch(`/api/products/${id}/relist`, { method: 'POST' });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleDeleteProduct = async (id: string) => {
    const res = await fetch(`/api/products/${id}`, { method: 'DELETE' });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleBulkEditProducts = async (ids: string[], update: any) => {
    const res = await fetch('/api/products/bulk-edit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids, update })
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleBulkDeleteProducts = async (ids: string[]) => {
    const res = await fetch('/api/products/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids })
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleImportCSVProducts = async (rows: any[]) => {
    const res = await fetch('/api/products/import-csv', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ rows })
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  // ORDERS & MESSAGING MUTATIONS
  const handleCreateOrder = async (orderPayload: any) => {
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderPayload)
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleUpdateOrderStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleSendMessage = async (msgPayload: any) => {
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msgPayload)
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  const handleReadMessage = async (id: string) => {
    const res = await fetch(`/api/messages/${id}/read`, { method: 'PUT' });
    const data = await res.json();
    await syncState();
    return data;
  };

  // SYSTEM SETTINGS & WALLETS MUTATION
  const handleUpdateSettings = async (settings: any, wallets: any) => {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings, wallets })
    });
    const data = await res.json();
    await syncState();
    return data;
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#050505] text-white font-sans overflow-x-hidden selection:bg-brand-accent selection:text-black">
      {/* 1. UNIVERSAL HYPERMODERN NAVIGATION HEADER */}
      <nav className="h-20 border-b border-white/10 flex items-center justify-between px-6 md:px-10 bg-black/60 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-8">
          <span 
            className="text-2xl font-black tracking-tighter uppercase font-display italic hover:text-brand-accent cursor-pointer transition-colors"
            onClick={() => setActiveWorkspace('shop')}
          >
            Rocketman
          </span>
          <div className="hidden lg:flex gap-6 text-[10px] font-bold tracking-[0.2em] text-white/50 uppercase font-mono">
            <span className="text-white border-b border-white pb-1">Sovereign D2C Enterprise</span>
          </div>
        </div>

        {/* Middle Switch Controls */}
        <div className="flex bg-brand-border/40 p-1 rounded-sm border border-brand-border">
          <button
            onClick={() => setActiveWorkspace('shop')}
            className={`px-4 py-1.5 text-[10px] font-mono uppercase font-bold rounded-sm transition-all flex items-center gap-1.5 ${activeWorkspace === 'shop' ? 'bg-white text-black' : 'text-white/60 hover:text-white'}`}
          >
            <Monitor className="w-3.5 h-3.5" /> Flagship Shop
          </button>
          <button
            onClick={() => setActiveWorkspace('dashboard')}
            className={`px-4 py-1.5 text-[10px] font-mono uppercase font-bold rounded-sm transition-all flex items-center gap-1.5 ${activeWorkspace === 'dashboard' ? 'bg-white text-black' : 'text-white/60 hover:text-white'}`}
          >
            <Cpu className="w-3.5 h-3.5" /> Seller ERP
          </button>
        </div>

        <div className="flex items-center gap-6">
          {/* Node Active State Indicator */}
          <div className="hidden md:flex flex-col items-end font-mono">
            <span className="text-[9px] text-white/40 tracking-widest uppercase">Self-Hosted Node</span>
            <span className="text-[10px] text-brand-accent tracking-tighter uppercase flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-brand-accent animate-pulse"></span>
              ● Connected
            </span>
          </div>
          <div className="h-8 w-[1px] bg-white/10 hidden md:block"></div>
          
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono font-bold tracking-widest uppercase text-white/70">Terminal</span>
            <div className="w-8 h-8 rounded-full border border-white/20 flex items-center justify-center bg-brand-border/40">
              <span className="text-xs font-mono font-bold text-brand-accent">RM</span>
            </div>
          </div>
        </div>
      </nav>

      {/* 2. SWITCHABLE PRIMARY WORKSPACE STAGE */}
      <div className="flex flex-1 flex-col">
        {activeWorkspace === 'shop' ? (
          <StoreFront 
            products={products}
            onCreateOrder={handleCreateOrder}
            onSendMessage={handleSendMessage}
            activeOrder={activeOrder}
            setActiveOrder={setActiveOrder}
            orders={orders}
          />
        ) : (
          <SellerDashboard 
            products={products}
            orders={orders}
            messages={messages}
            logs={logs}
            onCreateProduct={handleCreateProduct}
            onUpdateProduct={handleUpdateProduct}
            onDuplicateProduct={handleDuplicateProduct}
            onRelistProduct={handleRelistProduct}
            onDeleteProduct={handleDeleteProduct}
            onBulkEdit={handleBulkEditProducts}
            onBulkDelete={handleBulkDeleteProducts}
            onImportCSV={handleImportCSVProducts}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onUpdateSettings={handleUpdateSettings}
            onReadMessage={handleReadMessage}
          />
        )}
      </div>

      {/* 3. UNIVERSAL FOOTER STATS TICKER */}
      <footer className="h-14 border-t border-white/10 flex flex-col md:flex-row items-center justify-between px-6 md:px-10 bg-black text-[9px] font-mono tracking-widest uppercase text-white/40 gap-2 py-2 md:py-0">
        <div className="flex gap-4 md:gap-8 text-center md:text-left">
          <span>© 2026 Rocketman Trading Corp.</span>
          <span className="hidden sm:inline">Secure. Autonomous. Fast.</span>
        </div>
        
        <div className="flex gap-6 items-center flex-wrap justify-center">
          <div className="flex gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-orange"></span> 
              BTC: ${btcRate.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-brand-accent"></span> 
              USDT: ${usdtRate.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 4 })}
            </span>
          </div>
          <div className="h-4 w-[1px] bg-white/10 hidden sm:block"></div>
          <span className="text-white/80">Platform Uptime: 99.998%</span>
        </div>
      </footer>
    </div>
  );
}
