/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, Message, AuditLog } from './types';

export const SEED_PRODUCTS: Product[] = [
  {
    id: 'rm-01',
    sku: 'RM-TI-KBD-01',
    title: 'Titanium Mechanical Keyboard',
    subtitle: 'Machined grade-5 titanium enclosure with tactile switches',
    description: `### Pure Mechanical Engineering
Crafted from a single block of Grade 5 Titanium, the Rocketman RM-01 Mechanical Keyboard redefines industrial premium design. Each case is precision CNC-machined for 4.5 hours and finished with an ultra-fine bead blast.

#### Core Features
- **Monolithic Enclosure:** Zero flexing, weighted with an internal brass damper block (total keyboard weight: 2.8 kg).
- **Tactile Perfection:** Equipped with our custom Rocketman Tactile Slate switches (63.5g bottom-out, pre-lubed).
- **Connectivity:** Low-latency USB-C with complete electro-static discharge protection.
- **Hot-swappable PCB:** Support for 3-pin and 5-pin MX switches with custom plate configurations.

#### Package Includes
1. Machined titanium keycap puller
2. Custom braided black paracord cable
3. Individual inspection card signed by the lead machinist`,
    specifications: [
      { name: 'Enclosure Material', value: 'Grade 5 Titanium (Ti-6Al-4V)' },
      { name: 'Form Factor', value: '75% Layout (82 Keys)' },
      { name: 'Switch Mount', value: 'Gasket Mounted with Poron Dampeners' },
      { name: 'Keycaps', value: 'Double-shot PBT Matte Anthracite' },
      { name: 'Backlight', value: 'Understated Warm White (3000K) LEDs' },
      { name: 'Polling Rate', value: '1000Hz (1ms response)' }
    ],
    condition: 'Brand New',
    category: 'Hardware',
    subcategory: 'Input Devices',
    brand: 'Rocketman',
    tags: ['Titanium', 'Input', 'Premium', 'Minimal', 'Mechanical'],
    price: 850.00,
    salePrice: 799.00,
    quantity: 12,
    weight: 2.8,
    dimensions: '318 x 135 x 42 mm',
    shippingClass: 'Premium Tracked',
    countryOfOrigin: 'United States',
    images: [
      'https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1595225476474-87563907a212?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: ['https://rocketman.store/docs/rm01_user_manual.pdf'],
    status: 'Live',
    relistCount: 0,
    createdAt: '2026-07-10T12:00:00Z',
    updatedAt: '2026-07-10T12:00:00Z'
  },
  {
    id: 'rm-02',
    sku: 'RM-SLR-PCK-02',
    title: 'Modular Solar Power Station',
    subtitle: 'Deployable 120W crystalline panel and lithium charging core',
    description: `### Independent Power Generation
Designed for high-performance off-grid exploration, the RM-02 delivers robust, architectural solar harvest. Encased in a rugged military-spec anodized aluminum frame, it survives extreme environmental temperatures and drops.

#### Technical Capabilities
- **High-Efficiency Crystalline Cells:** 22.4% conversion efficiency with scratch-resistant ETFE coating.
- **Intelligent Power Hub:** Built-in MPPT controller offering rapid USB-C Power Delivery up to 100W and dual DC outputs.
- **Modular Expansion:** Chain up to three stations in series to scale harvesting up to 360W.

Ideal for field research, wilderness operations, or backup emergency systems.`,
    specifications: [
      { name: 'Solar Output', value: '120 Watts Peak' },
      { name: 'Core Capacity', value: '450 Watt-hours (LiFePO4)' },
      { name: 'Charging Protocol', value: 'Integrated Maximum Power Point Tracking (MPPT)' },
      { name: 'IP Rating', value: 'IP67 Dust and Water Resistant' },
      { name: 'Dimensions Folded', value: '420 x 360 x 50 mm' }
    ],
    condition: 'Brand New',
    category: 'Power',
    subcategory: 'Solar',
    brand: 'Rocketman',
    tags: ['Solar', 'Power', 'Modular', 'Field Gear'],
    price: 490.00,
    quantity: 8,
    weight: 4.5,
    dimensions: '1120 x 420 x 18 mm (Unfolded)',
    shippingClass: 'Heavy Freight',
    countryOfOrigin: 'United States',
    images: [
      'https://images.unsplash.com/photo-1509391366360-2e959784a276?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1620038614149-02970d8bf7f6?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: [],
    status: 'Live',
    relistCount: 1,
    createdAt: '2026-07-11T09:15:00Z',
    updatedAt: '2026-07-12T14:20:00Z'
  },
  {
    id: 'rm-03',
    sku: 'RM-TIT-PEN-03',
    title: 'Machined Bolt Action Pen',
    subtitle: 'Understated titanium writer with satisfying mechanical action',
    description: `### Analogue Fluidity
An everyday carry masterpiece. The RM-03 is engineered from Grade 5 Solid Titanium, featuring a heavy-duty tactical bolt action mechanism. Built for engineers, designers, and traders who value material substance.

#### Highlights
- **Balanced Gravity Center:** Precision counterweighted to match natural finger grip, reducing fatigue during long sessions.
- **Extreme Tolerances:** Gapless construction between body parts. Fits Schmidt EasyFlow 9000 and standard Parker refills.
- **Industrial Clip:** Wire-cut titanium clip that stays secure to heavy denim, canvas, or leather.`,
    specifications: [
      { name: 'Diameter', value: '10 mm' },
      { name: 'Length', value: '136 mm' },
      { name: 'Refill Compatibility', value: 'Parker Style & Schmidt EasyFlow' },
      { name: 'Clip Style', value: 'Integrated Machined Clip' }
    ],
    condition: 'Brand New',
    category: 'Lifestyle',
    subcategory: 'Writing Instruments',
    brand: 'Rocketman',
    tags: ['Titanium', 'Everyday Carry', 'Writing', 'Minimal'],
    price: 185.00,
    salePrice: 159.00,
    quantity: 45,
    weight: 0.042,
    dimensions: '136 x 10 mm',
    shippingClass: 'Standard Secure',
    countryOfOrigin: 'United States',
    images: [
      'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1569003339405-ea396a5a8a90?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: [],
    status: 'Live',
    relistCount: 0,
    createdAt: '2026-07-12T10:00:00Z',
    updatedAt: '2026-07-12T10:00:00Z'
  },
  {
    id: 'rm-04',
    sku: 'RM-ALM-STND-04',
    title: 'Monolithic Aluminum Desktop Stand',
    subtitle: 'Anodized block desktop riser for devices and tablets',
    description: `### Sculpted Desk Architecture
Create a structural focus on your workspace. The Rocketman Desktop Stand is machined from a massive single block of 6061-T6 Aerospace-Grade Aluminum, weighted to stay permanently planted.

#### Attributes
- **Ultra-Clean Routing:** Precision rear-cut oval path allows thick power and high-speed data cables to pass without clutter.
- **Secure Grip:** Soft micro-suction silicone pads prevent slide and protect titanium or ceramic hardware finishes.
- **Dual Angle:** Rotate 180 degrees to shift viewing tilt from 12° to 22°.`,
    specifications: [
      { name: 'Anodization Spec', value: 'Type III Hardcoat (Satin Silver)' },
      { name: 'Compatibility', value: 'All laptops and tablets up to 16"' },
      { name: 'Base Padding', value: 'Laser-etched high-density polyurethane' }
    ],
    condition: 'Like New',
    category: 'Hardware',
    subcategory: 'Desk Accessories',
    brand: 'Rocketman',
    tags: ['Aluminum', 'Hardware', 'Minimal', 'Desk'],
    price: 125.00,
    quantity: 3,
    weight: 1.4,
    dimensions: '220 x 180 x 110 mm',
    shippingClass: 'Standard Secure',
    countryOfOrigin: 'Taiwan',
    images: [
      'https://images.unsplash.com/photo-1616440347437-b1c73416efc2?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: [],
    status: 'Live',
    relistCount: 2,
    createdAt: '2026-07-13T08:30:00Z',
    updatedAt: '2026-07-13T08:30:00Z'
  },
  {
    id: 'rm-05',
    sku: 'RM-FLD-WTC-05',
    title: 'Field Operator Watch',
    subtitle: 'Military-style mechanical timepiece with durable canvas strap',
    description: `### Time Under Hard Conditions
The RM-05 Field Operator Watch combines military utility with modern architectural styling. Driven by a highly reliable 24-jewel automatic self-winding movement, keeping you accurate without ever needing a battery.

#### Build Quality
- **Stainless Steel Shell:** Sandblasted 316L Stainless Steel case (40mm diameter).
- **Sapphire Crystal:** Double-domed scratch-resistant sapphire glass with interior anti-reflective treatment.
- **Legibility:** Matte black high-contrast face with Super-LumiNova® C3 hands and numerals.
- **Nylon Canvas Band:** Industrial olive green dual-layer canvas band with titanium buckle.`,
    specifications: [
      { name: 'Movement Type', value: 'Automatic Self-Winding NH35A' },
      { name: 'Power Reserve', value: '41 Hours' },
      { name: 'Water Resistance', value: '10 ATM (100 Meters)' },
      { name: 'Case Size', value: '40 mm Diameter, 12 mm Thickness' },
      { name: 'Lug Width', value: '20 mm' }
    ],
    condition: 'Brand New',
    category: 'Lifestyle',
    subcategory: 'Timepieces',
    brand: 'Rocketman',
    tags: ['Watch', 'Tactical', 'Mechanical', 'Lifestyle'],
    price: 360.00,
    quantity: 15,
    weight: 0.12,
    dimensions: '40 x 40 x 12 mm',
    shippingClass: 'Premium Tracked',
    countryOfOrigin: 'Japan',
    images: [
      'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?q=80&w=800&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1547996160-81dfa63595aa?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: [],
    status: 'Live',
    relistCount: 0,
    createdAt: '2026-07-14T01:00:00Z',
    updatedAt: '2026-07-14T01:00:00Z'
  },
  {
    id: 'rm-06',
    sku: 'RM-TCH-SLG-06',
    title: 'Field Tech Sling Bag',
    subtitle: 'X-Pac water-resistant tactical carry for gadgets',
    description: `### Architectural Tactical Carry
Constructed from laminated X-Pac® VX21 sailcloth, the RM-06 is ultra-lightweight, extremely durable, and completely impervious to heavy rain storms. Developed to protect sensitive electronic items during urban or field missions.

#### Key Details
- **Multi-Compartment Utility:** Lined with high-contrast light grey ripstop fabric to quickly identify cables, dongles, and flash drives.
- **Fidlock® Buckle:** German magnetic quick-release buckle for easy chest mounting and removal.
- **Concealed Pocket:** Rear-facing zippered pocket for secure travel passports, currency, and cold-storage wallets.`,
    specifications: [
      { name: 'Shell Fabric', value: 'X-Pac® VX21 Sailcloth' },
      { name: 'Hardware', value: 'YKK AquaGuard® Zippers & Fidlock® V-Buckle' },
      { name: 'Capacity', value: '4.5 Liters' }
    ],
    condition: 'Excellent',
    category: 'Lifestyle',
    subcategory: 'Bags & Carry',
    brand: 'Rocketman',
    tags: ['Tactical', 'Carry', 'Water-Resistant', 'Everyday Carry'],
    price: 145.00,
    quantity: 18,
    weight: 0.38,
    dimensions: '280 x 170 x 90 mm',
    shippingClass: 'Standard Secure',
    countryOfOrigin: 'United States',
    images: [
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: [],
    status: 'Live',
    relistCount: 0,
    createdAt: '2026-07-09T15:00:00Z',
    updatedAt: '2026-07-09T15:00:00Z'
  },
  {
    id: 'rm-07',
    sku: 'RM-TI-MUG-07',
    title: 'Titanium Double-Wall Cup',
    subtitle: 'Thermal insulated vacuum mug with folding handles',
    description: `### Extreme Insulation
A lightweight thermal mug that keeps your coffee or tea hot in the field, while remaining cool to touch. Made from 99.8% pure titanium, it imparts no metallic taste or smell to your beverage.

#### Highlights
- **Folding Handles:** Lay flat against the cup profile for ultra-compact packing.
- **Double-Wall Design:** Hand-welded dual layers isolate thermal energy.
- **Featherweight:** Weighs only 118g, making it virtually unnoticeable in your pack.`,
    specifications: [
      { name: 'Material', value: '99.8% Pure Titanium' },
      { name: 'Volume Capacity', value: '450 ml' },
      { name: 'Thermal Insulation', value: 'Double-Wall Vacuum Sealed' }
    ],
    condition: 'Brand New',
    category: 'Lifestyle',
    subcategory: 'Camp Gear',
    brand: 'Rocketman',
    tags: ['Titanium', 'Camp Gear', 'Lifestyle', 'Minimal'],
    price: 65.00,
    quantity: 25,
    weight: 0.118,
    dimensions: '95 x 85 mm',
    shippingClass: 'Standard Secure',
    countryOfOrigin: 'Japan',
    images: [
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800&auto=format&fit=crop'
    ],
    videos: [],
    pdfs: [],
    status: 'Coming Soon',
    relistCount: 0,
    createdAt: '2026-07-14T02:00:00Z',
    updatedAt: '2026-07-14T02:00:00Z'
  }
];

export const SEED_MESSAGES: Message[] = [
  {
    id: 'm-01',
    sender: 'Customer',
    customerEmail: 'alex@fieldops.com',
    orderReference: 'RM-2026-8941',
    subject: 'Crypto transaction confirmation delay',
    body: `Hello Rocketman staff, I completed my manual USDT payment on the Solana network about 15 minutes ago. Transaction Hash is 3aXb7F... The explorer shows 32 confirmations, but my status is still showing Awaiting Payment. Could you please double-check? Highly appreciate your help. Great platform design by the way!`,
    createdAt: '2026-07-14T03:40:00Z',
    read: false
  },
  {
    id: 'm-02',
    sender: 'Customer',
    customerEmail: 'sarah.k@industrials.io',
    subject: 'Requesting specifications of custom plate assembly',
    body: `We are interested in buying a bulk quantity of your Titanium Mechanical Keyboard (RM-TI-KBD-01) for our operational office desks. Do you supply custom plate options or brass weights? Please send us the detailed dimensions file if available. Thank you!`,
    createdAt: '2026-07-13T11:20:00Z',
    read: true
  }
];

export const SEED_LOGS: AuditLog[] = [
  {
    id: 'log-01',
    userId: 'admin-01',
    userEmail: 'tom@ahyx.org',
    action: 'Product Relisted',
    details: 'Relisted Titanium Mechanical Keyboard (SKU: RM-TI-KBD-01). Increased base price slightly to match market rate.',
    ipAddress: '198.51.100.42',
    createdAt: '2026-07-14T06:10:00Z'
  },
  {
    id: 'log-02',
    userId: 'admin-01',
    userEmail: 'tom@ahyx.org',
    action: 'Crypto Wallet Saved',
    details: 'Updated merchant wallet settings. Enabled Solana network for USDT payments.',
    ipAddress: '198.51.100.42',
    createdAt: '2026-07-14T05:45:00Z'
  },
  {
    id: 'log-03',
    userId: 'system',
    userEmail: 'system-node@rocketman',
    action: 'Automatic Payment Sync',
    details: 'Connected to Solana RPC. Synced address generation queues successfully.',
    ipAddress: '127.0.0.1',
    createdAt: '2026-07-14T00:00:05Z'
  }
];
