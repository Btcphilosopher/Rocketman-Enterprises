/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Product {
  id: string;
  sku: string;
  title: string;
  subtitle: string;
  description: string; // Markdown supported
  specifications: { name: string; value: string }[];
  condition: 'Brand New' | 'Like New' | 'Excellent' | 'Good' | 'Fair';
  category: string;
  subcategory: string;
  brand: string;
  tags: string[];
  price: number;
  salePrice?: number;
  quantity: number;
  weight: number; // in kg
  dimensions: string; // e.g., "120x60x10 mm"
  shippingClass: string;
  countryOfOrigin: string;
  images: string[];
  videos: string[];
  pdfs: string[];
  status: 'Draft' | 'Live' | 'Hidden' | 'Sold Out' | 'Archived' | 'Deleted' | 'Coming Soon';
  relistCount: number;
  scheduledPublish?: string; // ISO Date String
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  productId: string;
  sku: string;
  title: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Address {
  name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
}

export interface PaymentInfo {
  method: 'crypto';
  currency: 'BTC' | 'USDT';
  network?: 'Ethereum (ERC-20)' | 'Tron (TRC-20)' | 'Solana';
  walletAddress: string;
  amountCrypto: number;
  qrCodeData: string;
  paymentTimerSeconds: number; // starts at 1800 (30 mins)
  txHash?: string;
  confirmations: number;
  requiredConfirmations: number;
}

export interface Order {
  id: string;
  orderReference: string; // e.g., RM-2026-8941
  customerId: string;
  customerEmail: string;
  customerName: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  shippingFee: number;
  total: number;
  status: 'Pending' | 'Awaiting Payment' | 'Paid' | 'Packing' | 'Shipped' | 'Delivered' | 'Refunded' | 'Cancelled' | 'Archived';
  shippingAddress: Address;
  payment: PaymentInfo;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'Customer' | 'Admin' | 'Staff';
  twoFactorEnabled: boolean;
  twoFactorSecret?: string;
  createdAt: string;
}

export interface Message {
  id: string;
  sender: 'Customer' | 'Seller' | string;
  customerEmail: string;
  orderReference?: string;
  subject: string;
  body: string;
  createdAt: string;
  read: boolean;
}

export interface AuditLog {
  id: string;
  userId: string;
  userEmail: string;
  action: string;
  details: string;
  ipAddress: string;
  createdAt: string;
}

export interface MediaItem {
  id: string;
  name: string;
  originalName: string;
  url: string;
  size: string;
  type: string;
  optimized: boolean;
  webpUrl: string;
  createdAt: string;
}

export interface Coupon {
  code: string;
  discountType: 'Percentage' | 'Fixed';
  value: number;
  active: boolean;
}
