/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Search, SlidersHorizontal, ShoppingCart, ArrowRight, ShieldCheck, 
  HelpCircle, Eye, RefreshCw, Layers, Sparkles, Check, CheckCircle, 
  FileText, Clock, AlertTriangle, MessageSquare, ChevronRight, X, Minus, Plus
} from 'lucide-react';
import { Product, Order, Address } from '../types';

interface StoreFrontProps {
  products: Product[];
  onCreateOrder: (orderData: any) => Promise<Order>;
  onSendMessage: (msgData: any) => Promise<any>;
  activeOrder: Order | null;
  setActiveOrder: (order: Order | null) => void;
  orders: Order[];
}

export default function StoreFront({
  products,
  onCreateOrder,
  onSendMessage,
  activeOrder,
  setActiveOrder,
  orders
}: StoreFrontProps) {
  // Views: 'home' | 'shop' | 'product' | 'checkout' | 'order-tracking' | 'about' | 'contact'
  const [view, setView] = useState<'home' | 'shop' | 'product' | 'checkout' | 'order-tracking' | 'about' | 'contact'>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Shop states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCondition, setSelectedCondition] = useState<string>('All');
  const [priceRange, setPriceRange] = useState<number>(1000);
  const [sortBy, setSortBy] = useState<string>('newest');

  // Cart state
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [cartOpen, setCartOpen] = useState(false);

  // Checkout states
  const [email, setEmail] = useState('');
  const [fullName, setFullName] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [zip, setZip] = useState('');
  const [phone, setPhone] = useState('');
  const [cryptoCurrency, setCryptoCurrency] = useState<'BTC' | 'USDT'>('USDT');
  const [cryptoNetwork, setCryptoNetwork] = useState<'Solana' | 'Ethereum (ERC-20)' | 'Tron (TRC-20)'>('Solana');
  const [couponCode, setCouponCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [submittingOrder, setSubmittingOrder] = useState(false);

  // Contact state
  const [contactEmail, setContactEmail] = useState('');
  const [contactSubject, setContactSubject] = useState('');
  const [contactBody, setContactBody] = useState('');
  const [contactSent, setContactSent] = useState(false);

  // Newsletter signup
  const [newsEmail, setNewsEmail] = useState('');
  const [newsSubscribed, setNewsSubscribed] = useState(false);

  // Calculate cart totals
  const cartSubtotal = cart.reduce((sum, item) => {
    const price = item.product.salePrice || item.product.price;
    return sum + (price * item.quantity);
  }, 0);
  const discountAmount = (cartSubtotal * appliedDiscount) / 100;
  const subtotalAfterDiscount = cartSubtotal - discountAmount;
  const taxAmount = subtotalAfterDiscount * 0.08;
  const shippingFee = cart.length > 0 ? 15.00 : 0;
  const cartTotal = subtotalAfterDiscount + taxAmount + shippingFee;

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))];

  const addToCart = (product: Product) => {
    if (product.quantity <= 0 && product.status === 'Sold Out') return;
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { product, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const updateCartQuantity = (productId: string, val: number) => {
    setCart(prev => prev.map(item => {
      if (item.product.id === productId) {
        const nextQ = item.quantity + val;
        return nextQ > 0 ? { ...item, quantity: nextQ } : null;
      }
      return item;
    }).filter(Boolean) as any);
  };

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;
    setSubmittingOrder(true);

    // Crypto rate simulator: BTC = $64,000, USDT = $1.00
    const btcRate = 64000;
    const cryptoAmount = cryptoCurrency === 'BTC' ? Number((cartTotal / btcRate).toFixed(6)) : cartTotal;

    const orderData = {
      customerEmail: email,
      customerName: fullName,
      items: cart.map(item => ({
        productId: item.product.id,
        sku: item.product.sku,
        title: item.product.title,
        price: item.product.salePrice || item.product.price,
        quantity: item.quantity,
        image: item.product.images[0]
      })),
      subtotal: cartSubtotal,
      tax: taxAmount,
      shippingFee: shippingFee,
      total: cartTotal,
      paymentCurrency: cryptoCurrency,
      paymentNetwork: cryptoCurrency === 'USDT' ? cryptoNetwork : undefined,
      amountCrypto: cryptoAmount,
      shippingAddress: {
        name: fullName,
        line1: addressLine1,
        line2: addressLine2,
        city,
        state,
        postalCode: zip,
        country: 'United States',
        phone
      }
    };

    try {
      const order = await onCreateOrder(orderData);
      setActiveOrder(order);
      setCart([]);
      setView('order-tracking');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmittingOrder(false);
    }
  };

  const handleApplyCoupon = () => {
    if (couponCode.toUpperCase() === 'ROCKETLAUNCH') {
      setAppliedDiscount(10);
    } else if (couponCode.toUpperCase() === 'TITANIUM50') {
      setAppliedDiscount(15);
    } else {
      alert('Invalid coupon code');
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSendMessage({
      sender: 'Customer',
      customerEmail: contactEmail,
      subject: contactSubject,
      body: contactBody
    });
    setContactSent(true);
    setContactEmail('');
    setContactSubject('');
    setContactBody('');
  };

  // Filters and search list
  const filteredProducts = products.filter(p => {
    if (p.status !== 'Live' && p.status !== 'Coming Soon') return false;
    const matchesSearch = p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.tags.some(t => t.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesCondition = selectedCondition === 'All' || p.condition === selectedCondition;
    const matchesPrice = (p.salePrice || p.price) <= priceRange;
    return matchesSearch && matchesCategory && matchesCondition && matchesPrice;
  }).sort((a, b) => {
    if (sortBy === 'price-asc') return (a.salePrice || a.price) - (b.salePrice || b.price);
    if (sortBy === 'price-desc') return (b.salePrice || b.price) - (a.salePrice || a.price);
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  return (
    <div className="flex-1 overflow-y-auto" id="storefront-main">
      {/* 1. HERO HOME VIEW */}
      {view === 'home' && (
        <div>
          {/* Main Hero Block */}
          <div className="border-b border-white/10 grid grid-cols-1 lg:grid-cols-5 bg-black relative">
            <div className="lg:col-span-3 p-8 md:p-16 flex flex-col justify-between border-r border-white/10 min-h-[480px]">
              <div className="space-y-6">
                <div className="flex gap-2 items-center">
                  <span className="px-2 py-0.5 bg-brand-accent text-black text-[9px] font-bold tracking-widest uppercase">Established 2026</span>
                  <span className="text-[10px] text-white/40 font-mono">ID: RM-8820-ENT</span>
                </div>
                <h1 className="text-4xl md:text-7xl font-bold tracking-tighter uppercase font-display leading-[0.9]">
                  Modern <br/>American <br/>Inventory.
                </h1>
                <p className="text-base md:text-lg text-white/60 max-w-md font-light leading-relaxed">
                  The self-hosted, sovereign e-commerce flagship. Featuring high-velocity turnover of precision gear, titanium everyday carry tools, and modular power gear.
                </p>
              </div>

              <div className="flex flex-wrap gap-4 mt-8">
                <button 
                  onClick={() => setView('shop')}
                  className="px-8 py-4 bg-white text-black font-bold text-xs tracking-widest uppercase hover:bg-brand-accent hover:text-black transition-all flex items-center gap-2"
                >
                  Browse drops <ArrowRight className="w-4 h-4" />
                </button>
                <button 
                  onClick={() => setView('about')}
                  className="px-8 py-4 border border-white/20 text-white font-bold text-xs tracking-widest uppercase hover:bg-white/5 transition-all"
                >
                  Our Philosophy
                </button>
              </div>
            </div>

            {/* Right Featured Spot */}
            <div className="lg:col-span-2 p-8 flex flex-col justify-between bg-gradient-to-br from-[#111] to-[#050505]">
              <div>
                <span className="text-[10px] tracking-widest text-brand-orange font-bold uppercase block mb-1">Featured Mechanical Hardware</span>
                <h3 className="text-2xl font-bold uppercase tracking-tight">RM-01 Keyboard series</h3>
                <p className="text-xs text-white/40 mt-1 font-mono">CNC grade-5 titanium. Hot-swappable tactile switch matrix.</p>
              </div>

              <div className="my-8 flex justify-center">
                <div className="w-48 h-48 border border-white/10 relative flex items-center justify-center bg-black/40 rounded-sm overflow-hidden group">
                  <img 
                    src="https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop"
                    className="object-cover w-full h-full opacity-65 group-hover:scale-105 transition-transform"
                    alt="RM-01 Keyboard"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-2 left-2 right-2 flex justify-between items-end">
                    <span className="text-xs font-mono text-brand-accent font-semibold">$799.00</span>
                    <span className="text-[9px] bg-white/10 px-1 font-mono text-white/60">Live</span>
                  </div>
                </div>
              </div>

              <div className="flex justify-between items-center border-t border-white/10 pt-4">
                <div className="flex gap-2">
                  <span className="text-[10px] border border-white/20 px-2 py-0.5 font-mono">₿ BTC</span>
                  <span className="text-[10px] border border-white/20 px-2 py-0.5 font-mono">₮ USDT</span>
                </div>
                <button 
                  onClick={() => {
                    const p = products.find(prod => prod.id === 'rm-01');
                    if (p) {
                      setSelectedProduct(p);
                      setView('product');
                    }
                  }}
                  className="text-xs text-white underline hover:text-brand-accent tracking-widest uppercase font-bold"
                >
                  Explore Spec
                </button>
              </div>
            </div>
          </div>

          {/* Accept Crypto Horizontal Banner */}
          <div className="bg-brand-black border-b border-white/10 py-4 px-8 overflow-hidden relative">
            <div className="flex flex-wrap justify-between items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-brand-accent rounded-full animate-ping"></div>
                <span className="text-xs font-mono tracking-wider text-white/70 uppercase">Sovereign Node Detection active</span>
              </div>
              <div className="flex items-center gap-6 text-[11px] font-mono text-white/50">
                <span className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-brand-accent" /> Direct Bitcoin Core (BTC)</span>
                <span className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-brand-accent" /> Solana USDT</span>
                <span className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-brand-accent" /> TRC-20 Fast Transfer</span>
                <span className="flex items-center gap-2"><Check className="w-3.5 h-3.5 text-brand-accent" /> Zero Custodial Middleware</span>
              </div>
            </div>
          </div>

          {/* New Arrivals & Inventory Sections */}
          <div className="p-8 md:p-12 space-y-12">
            <div className="flex justify-between items-end border-b border-white/10 pb-4">
              <div>
                <h2 className="text-2xl font-bold uppercase tracking-tight">Active Releases</h2>
                <p className="text-xs text-brand-text-muted mt-1">High-velocity stock. Instant automated delivery routing.</p>
              </div>
              <button 
                onClick={() => setView('shop')}
                className="text-xs font-mono text-brand-accent uppercase tracking-widest hover:underline flex items-center gap-1"
              >
                View Catalog ({products.length}) <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Catalog Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {products.slice(0, 4).map(product => (
                <div key={product.id} className="border border-brand-border bg-brand-card hover:border-white/30 transition-colors flex flex-col justify-between rounded-sm overflow-hidden">
                  <div 
                    className="h-48 bg-black relative cursor-pointer overflow-hidden group"
                    onClick={() => {
                      setSelectedProduct(product);
                      setView('product');
                    }}
                  >
                    <img 
                      src={product.images[0]} 
                      alt={product.title}
                      className="object-cover w-full h-full group-hover:scale-105 transition-transform opacity-75"
                    />
                    <div className="absolute top-2 left-2 flex gap-1">
                      <span className="text-[8px] font-bold tracking-widest uppercase bg-black text-white px-2 py-0.5 border border-white/10">
                        {product.condition}
                      </span>
                      {product.salePrice && (
                        <span className="text-[8px] font-bold tracking-widest uppercase bg-brand-orange text-white px-2 py-0.5">
                          Sale
                        </span>
                      )}
                    </div>
                    {product.status === 'Coming Soon' && (
                      <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
                        <span className="text-xs font-mono text-brand-orange font-bold uppercase tracking-widest">Coming Soon</span>
                      </div>
                    )}
                  </div>

                  <div className="p-5 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="text-[10px] text-brand-accent uppercase font-mono tracking-wider block mb-1">
                        {product.category} &rsaquo; {product.subcategory}
                      </span>
                      <h4 
                        className="font-bold uppercase tracking-tight text-white hover:text-brand-accent cursor-pointer transition-colors line-clamp-1"
                        onClick={() => {
                          setSelectedProduct(product);
                          setView('product');
                        }}
                      >
                        {product.title}
                      </h4>
                      <p className="text-xs text-brand-text-muted mt-2 line-clamp-2 min-h-[32px]">{product.subtitle}</p>
                    </div>

                    <div className="mt-4 pt-4 border-t border-brand-border flex items-center justify-between">
                      <div>
                        {product.salePrice ? (
                          <div className="flex items-center gap-2">
                            <span className="text-base font-bold font-mono text-brand-accent">${product.salePrice}</span>
                            <span className="text-xs text-white/40 line-through font-mono">${product.price}</span>
                          </div>
                        ) : (
                          <span className="text-base font-bold font-mono text-white">${product.price}</span>
                        )}
                        <span className="text-[9px] text-brand-text-muted font-mono block mt-0.5">SKU: {product.sku}</span>
                      </div>

                      {product.status !== 'Coming Soon' ? (
                        <button 
                          onClick={() => addToCart(product)}
                          className="p-2 border border-brand-border bg-black hover:border-white hover:text-brand-accent transition-colors text-white"
                          title="Add to Cart"
                        >
                          <ShoppingCart className="w-4 h-4" />
                        </button>
                      ) : (
                        <button 
                          disabled
                          className="px-2 py-1 text-[9px] border border-brand-border font-mono text-white/40"
                        >
                          Reserve
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Custom Bento Design Reviews */}
          <div className="border-y border-white/10 bg-brand-black grid grid-cols-1 md:grid-cols-3">
            <div className="p-8 md:p-12 border-b md:border-b-0 md:border-r border-white/10 space-y-4">
              <div className="flex text-brand-accent text-sm">★★★★★</div>
              <h5 className="font-bold uppercase tracking-wider text-sm">"Flawless Independent Checkout"</h5>
              <p className="text-xs text-brand-text-muted leading-relaxed">
                "Not having to deal with traditional processors is liberating. The automated transaction confirmation detected my Solana USDT within seconds. Highly reliable software assembly."
              </p>
              <div className="text-[10px] font-mono text-white/40">— Marcus D., Operations Lead</div>
            </div>
            <div className="p-8 md:p-12 border-b md:border-b-0 md:border-r border-white/10 space-y-4">
              <div className="flex text-brand-accent text-sm">★★★★★</div>
              <h5 className="font-bold uppercase tracking-wider text-sm">"Architectural Hardware Quality"</h5>
              <p className="text-xs text-brand-text-muted leading-relaxed">
                "The RM-01 keyboard is monolithic block gold. Extremely premium heavy design. Rocketman delivers robust shipping across continents without custom hiccups. Recommended."
              </p>
              <div className="text-[10px] font-mono text-white/40">— Clara O., Brutalist Architect</div>
            </div>
            <div className="p-8 md:p-12 space-y-4">
              <div className="flex text-brand-accent text-sm">★★★★★</div>
              <h5 className="font-bold uppercase tracking-wider text-sm">"Exceptional Support Direct Route"</h5>
              <p className="text-xs text-brand-text-muted leading-relaxed">
                "Needed a replacement custom plate for my field power core. Used the internal messaging terminal and the merchant team approved and dispatched my cargo in 12 hours flat."
              </p>
              <div className="text-[10px] font-mono text-white/40">— Alexander F., Field Contractor</div>
            </div>
          </div>

          {/* Subscriptions & Footer Newsletter */}
          <div className="p-8 md:p-16 border-b border-white/10 flex flex-col md:flex-row justify-between items-center bg-black gap-6">
            <div className="space-y-2 text-center md:text-left">
              <h4 className="text-xl font-bold uppercase tracking-tight">Access Early Stock Drops</h4>
              <p className="text-xs text-brand-text-muted">Enter your secure operational email terminal to register for priority inventory notices.</p>
            </div>
            <div className="w-full md:w-auto flex max-w-md">
              {newsSubscribed ? (
                <div className="text-brand-accent font-mono text-xs flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" /> Operational Terminal Registered Successfully.
                </div>
              ) : (
                <form 
                  onSubmit={(e) => { e.preventDefault(); setNewsSubscribed(true); }}
                  className="flex w-full border border-brand-border bg-brand-card rounded-sm overflow-hidden"
                >
                  <input 
                    type="email" 
                    required
                    placeholder="operator@domain.com"
                    value={newsEmail}
                    onChange={(e) => setNewsEmail(e.target.value)}
                    className="px-4 py-3 bg-transparent text-white placeholder-white/30 text-xs focus:outline-none flex-1 font-mono"
                  />
                  <button type="submit" className="px-6 py-3 bg-white text-black font-bold text-xs uppercase tracking-widest hover:bg-brand-accent">
                    Register
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 2. CATALOG SHOP VIEW */}
      {view === 'shop' && (
        <div className="p-8 space-y-8">
          <div>
            <h2 className="text-3xl font-bold uppercase tracking-tight font-display">Store Drops</h2>
            <p className="text-xs text-brand-text-muted mt-1">Sovereign, non-custodial direct merchant pipeline.</p>
          </div>

          {/* Search, Categorization and Filtering Bar */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
            <div className="space-y-6 lg:col-span-1 border border-brand-border bg-brand-card p-6 rounded-sm">
              <div className="flex justify-between items-center border-b border-brand-border pb-3">
                <span className="text-xs font-bold tracking-widest uppercase font-mono text-white/50">Filters & Sorting</span>
                <SlidersHorizontal className="w-4 h-4 text-white/40" />
              </div>

              {/* Keyword search */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase text-brand-text-muted">Search SKU / Tag</label>
                <div className="relative">
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Enter keywords..."
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                  />
                  <Search className="w-3.5 h-3.5 absolute right-3 top-3 text-white/30" />
                </div>
              </div>

              {/* Category */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase text-brand-text-muted block">Category</label>
                <div className="flex flex-col gap-1.5">
                  {categories.map(cat => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`text-left px-3 py-1.5 rounded-sm text-xs transition-colors ${selectedCategory === cat ? 'bg-white text-black font-semibold' : 'hover:bg-white/5 text-white/60'}`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Condition */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase text-brand-text-muted block">Condition</label>
                <div className="grid grid-cols-2 gap-1">
                  {['All', 'Brand New', 'Like New', 'Excellent'].map(cond => (
                    <button
                      key={cond}
                      onClick={() => setSelectedCondition(cond)}
                      className={`px-2 py-1 border text-[10px] uppercase font-mono rounded-sm transition-colors ${selectedCondition === cond ? 'border-brand-accent bg-brand-accent/10 text-brand-accent' : 'border-brand-border hover:border-white/25 text-white/60'}`}
                    >
                      {cond}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price limit slider */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[10px] font-mono uppercase">
                  <span className="text-brand-text-muted">Price range</span>
                  <span className="text-brand-accent font-semibold">${priceRange} MAX</span>
                </div>
                <input 
                  type="range" 
                  min="50" 
                  max="1200" 
                  step="50"
                  value={priceRange}
                  onChange={(e) => setPriceRange(Number(e.target.value))}
                  className="w-full h-1 bg-brand-border rounded-lg appearance-none cursor-pointer accent-brand-accent"
                />
              </div>

              {/* Sort by */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono uppercase text-brand-text-muted block">Order Arrangement</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-accent rounded-sm font-mono"
                >
                  <option value="newest">Recently Listed</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                </select>
              </div>
            </div>

            {/* Results Grid */}
            <div className="lg:col-span-3 space-y-6">
              <div className="flex justify-between items-center text-xs font-mono text-white/40">
                <span>Displaying {filteredProducts.length} items</span>
                <span>Currency Index: BTC/USDT</span>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="border border-dashed border-brand-border p-16 text-center space-y-4">
                  <AlertTriangle className="w-8 h-8 text-brand-orange mx-auto" />
                  <p className="text-sm text-brand-text-muted">No products found matching active terminal filter variables.</p>
                  <button 
                    onClick={() => { setSelectedCategory('All'); setSelectedCondition('All'); setSearchQuery(''); setPriceRange(1200); }}
                    className="px-4 py-2 border border-white/20 text-xs font-mono text-white uppercase hover:bg-white/5"
                  >
                    Reset filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map(product => (
                    <div key={product.id} className="border border-brand-border bg-brand-card hover:border-white/30 transition-colors flex flex-col justify-between rounded-sm overflow-hidden">
                      <div 
                        className="h-44 bg-black relative cursor-pointer overflow-hidden group"
                        onClick={() => {
                          setSelectedProduct(product);
                          setView('product');
                        }}
                      >
                        <img 
                          src={product.images[0]} 
                          alt={product.title}
                          className="object-cover w-full h-full group-hover:scale-105 transition-transform opacity-75"
                        />
                        <div className="absolute top-2 left-2">
                          <span className="text-[8px] font-bold tracking-widest uppercase bg-black text-white px-2 py-0.5 border border-white/10">
                            {product.condition}
                          </span>
                        </div>
                        {product.status === 'Coming Soon' && (
                          <div className="absolute inset-0 bg-black/80 flex items-center justify-center">
                            <span className="text-xs font-mono text-brand-orange font-bold uppercase tracking-widest">Coming Soon</span>
                          </div>
                        )}
                      </div>

                      <div className="p-5 flex-1 flex flex-col justify-between">
                        <div>
                          <span className="text-[10px] text-brand-accent uppercase font-mono tracking-wider block mb-1">
                            {product.category}
                          </span>
                          <h4 
                            className="font-bold uppercase tracking-tight text-white hover:text-brand-accent cursor-pointer transition-colors line-clamp-1"
                            onClick={() => {
                              setSelectedProduct(product);
                              setView('product');
                            }}
                          >
                            {product.title}
                          </h4>
                          <p className="text-xs text-brand-text-muted mt-2 line-clamp-2 min-h-[32px]">{product.subtitle}</p>
                        </div>

                        <div className="mt-4 pt-4 border-t border-brand-border flex items-center justify-between">
                          <div>
                            {product.salePrice ? (
                              <div className="flex items-center gap-2">
                                <span className="text-base font-bold font-mono text-brand-accent">${product.salePrice}</span>
                                <span className="text-xs text-white/40 line-through font-mono">${product.price}</span>
                              </div>
                            ) : (
                              <span className="text-base font-bold font-mono text-white">${product.price}</span>
                            )}
                            <span className="text-[9px] text-brand-text-muted font-mono block mt-0.5">SKU: {product.sku}</span>
                          </div>

                          {product.status !== 'Coming Soon' ? (
                            <button 
                              onClick={() => addToCart(product)}
                              className="p-2 border border-brand-border bg-black hover:border-white hover:text-brand-accent transition-colors text-white"
                            >
                              <ShoppingCart className="w-4 h-4" />
                            </button>
                          ) : (
                            <span className="text-[9px] font-mono text-brand-orange">Coming Soon</span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 3. PRODUCT DETAIL VIEW */}
      {view === 'product' && selectedProduct && (
        <div className="p-8 md:p-12 space-y-12">
          {/* Breadcrumbs */}
          <div className="text-xs font-mono text-white/40 flex items-center gap-2">
            <span className="hover:text-white cursor-pointer" onClick={() => setView('home')}>Home</span>
            <span>&rsaquo;</span>
            <span className="hover:text-white cursor-pointer" onClick={() => setView('shop')}>Catalog</span>
            <span>&rsaquo;</span>
            <span className="text-white">{selectedProduct.title}</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Gallery (Left - 5 columns) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="border border-brand-border bg-black h-96 flex items-center justify-center overflow-hidden rounded-sm relative">
                <img 
                  src={selectedProduct.images[0]} 
                  alt={selectedProduct.title}
                  className="object-cover w-full h-full"
                />
              </div>
              {selectedProduct.images.length > 1 && (
                <div className="grid grid-cols-4 gap-2">
                  {selectedProduct.images.map((img, idx) => (
                    <div key={idx} className="border border-brand-border bg-black h-20 overflow-hidden cursor-pointer hover:border-brand-accent">
                      <img src={img} className="object-cover w-full h-full opacity-60 hover:opacity-100 transition-opacity" alt="" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Specifications & Purchasing Terminal (Right - 7 columns) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-2">
                <div className="flex gap-2 items-center">
                  <span className="px-2 py-0.5 bg-white text-black text-[9px] font-mono font-bold uppercase tracking-widest">{selectedProduct.condition}</span>
                  <span className="text-xs text-brand-accent font-mono">{selectedProduct.brand}</span>
                </div>
                <h1 className="text-3xl font-bold uppercase tracking-tight font-display">{selectedProduct.title}</h1>
                <p className="text-base text-white/70 italic font-light">{selectedProduct.subtitle}</p>
              </div>

              {/* Pricing card */}
              <div className="border border-brand-border bg-brand-card p-6 flex flex-wrap justify-between items-center rounded-sm">
                <div>
                  <span className="text-[10px] text-brand-text-muted font-mono uppercase block mb-1">Direct Merchant pricing</span>
                  {selectedProduct.salePrice ? (
                    <div className="flex items-baseline gap-3">
                      <span className="text-2xl font-bold font-mono text-brand-accent">${selectedProduct.salePrice}</span>
                      <span className="text-sm text-white/40 line-through font-mono">${selectedProduct.price}</span>
                    </div>
                  ) : (
                    <span className="text-2xl font-bold font-mono text-white">${selectedProduct.price}</span>
                  )}
                  <span className="text-[10px] text-white/40 font-mono mt-1 block">Excl. local taxes | Calculated shipping</span>
                </div>

                <div className="space-y-2 mt-4 md:mt-0">
                  <div className="text-right text-[10px] font-mono text-white/50">
                    STATUS: <span className="text-brand-accent font-bold uppercase">{selectedProduct.status}</span>
                  </div>
                  {selectedProduct.status !== 'Coming Soon' ? (
                    <button 
                      onClick={() => addToCart(selectedProduct)}
                      className="px-8 py-3.5 bg-white text-black font-bold text-xs uppercase tracking-widest hover:bg-brand-accent hover:text-black transition-all flex items-center gap-2"
                    >
                      <ShoppingCart className="w-4 h-4" /> Add to checkout cargo
                    </button>
                  ) : (
                    <button 
                      disabled
                      className="px-8 py-3.5 border border-brand-border text-white/40 text-xs uppercase font-mono tracking-widest"
                    >
                      Release Pending
                    </button>
                  )}
                </div>
              </div>

              {/* Description Markdown Rendering */}
              <div className="space-y-4">
                <span className="text-[10px] text-brand-text-muted font-mono uppercase tracking-wider block border-b border-brand-border pb-1">Product Details</span>
                <div className="markdown-body text-sm text-white/80 leading-relaxed whitespace-pre-line">
                  {selectedProduct.description}
                </div>
              </div>

              {/* Specifications details */}
              {selectedProduct.specifications.length > 0 && (
                <div className="space-y-3">
                  <span className="text-[10px] text-brand-text-muted font-mono uppercase tracking-wider block border-b border-brand-border pb-1 font-semibold">Technical Specifications</span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {selectedProduct.specifications.map((spec, sIdx) => (
                      <div key={sIdx} className="border border-brand-border bg-black/40 p-3 rounded-sm flex justify-between font-mono text-xs">
                        <span className="text-white/40 uppercase">{spec.name}</span>
                        <span className="text-white font-medium text-right">{spec.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Physical details & origin */}
              <div className="border-t border-brand-border pt-6 grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-[10px]">
                <div>
                  <span className="text-white/40 uppercase block">SKU Code</span>
                  <span className="text-white mt-1 block">{selectedProduct.sku}</span>
                </div>
                <div>
                  <span className="text-white/40 uppercase block">Total Weight</span>
                  <span className="text-white mt-1 block">{selectedProduct.weight} kg</span>
                </div>
                <div>
                  <span className="text-white/40 uppercase block">Dimensions</span>
                  <span className="text-white mt-1 block">{selectedProduct.dimensions || 'N/A'}</span>
                </div>
                <div>
                  <span className="text-white/40 uppercase block">Origin Country</span>
                  <span className="text-white mt-1 block">{selectedProduct.countryOfOrigin}</span>
                </div>
              </div>

              {/* Manual Documents */}
              {selectedProduct.pdfs && selectedProduct.pdfs.length > 0 && (
                <div className="border-t border-brand-border pt-4">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-brand-accent" />
                    <span className="text-xs text-white/70 font-mono">Documentation Available:</span>
                    <a 
                      href={selectedProduct.pdfs[0]} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-xs text-brand-accent underline font-mono hover:text-white"
                    >
                      RM-Manual-Spec-Sheet.pdf
                    </a>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 4. GUEST / REGISTERED USERS CHECKOUT VIEW */}
      {view === 'checkout' && (
        <div className="p-8 md:p-12 space-y-12">
          <div>
            <h2 className="text-3xl font-bold uppercase tracking-tight font-display">Merchant Checkout</h2>
            <p className="text-xs text-brand-text-muted mt-1">Sovereign peer-to-peer crypto payment pipeline. No credit card required.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
            {/* Form Fields (Left - 7 columns) */}
            <form onSubmit={handleCheckoutSubmit} className="lg:col-span-7 space-y-8">
              <div className="space-y-4">
                <h3 className="text-xs font-bold tracking-wider uppercase font-mono text-white/50 border-b border-brand-border pb-1">1. Customer Credentials</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-brand-text-muted uppercase">Operational Email Address</label>
                    <input 
                      type="email" 
                      required
                      placeholder="e.g. operator@domain.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-brand-text-muted uppercase">Full Name</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Alexander Fieldman"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-bold tracking-wider uppercase font-mono text-white/50 border-b border-brand-border pb-1">2. Cargo Dispatch Location</h3>
                <div className="space-y-4">
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-brand-text-muted uppercase">Street Address Line 1</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. 142 Monolith Parkway"
                      value={addressLine1}
                      onChange={(e) => setAddressLine1(e.target.value)}
                      className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-brand-text-muted uppercase">Street Address Line 2 (Optional)</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Suite 40B"
                      value={addressLine2}
                      onChange={(e) => setAddressLine2(e.target.value)}
                      className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-2 space-y-1">
                      <label className="text-[10px] font-mono text-brand-text-muted uppercase">City</label>
                      <input 
                        type="text" 
                        required
                        placeholder="Austin"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-brand-text-muted uppercase">State</label>
                      <input 
                        type="text" 
                        required
                        placeholder="TX"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[10px] font-mono text-brand-text-muted uppercase">Postal Code</label>
                      <input 
                        type="text" 
                        required
                        placeholder="78701"
                        value={zip}
                        onChange={(e) => setZip(e.target.value)}
                        className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono text-brand-text-muted uppercase">Operational Phone</label>
                    <input 
                      type="text" 
                      required
                      placeholder="+1 (512) 555-0192"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-black border border-brand-border px-3 py-2.5 rounded-sm text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-bold tracking-wider uppercase font-mono text-white/50 border-b border-brand-border pb-1">3. Direct Peer-To-Peer Currency</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div 
                    onClick={() => setCryptoCurrency('USDT')}
                    className={`border p-4 cursor-pointer rounded-sm flex items-center justify-between transition-colors ${cryptoCurrency === 'USDT' ? 'border-brand-accent bg-brand-accent/5' : 'border-brand-border hover:border-white/20 bg-brand-card'}`}
                  >
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-white uppercase block">₮ Tether Stablecoin</span>
                      <span className="text-[9px] text-brand-text-muted font-mono">Fast settlements. Multiple networks.</span>
                    </div>
                    <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${cryptoCurrency === 'USDT' ? 'border-brand-accent' : 'border-brand-border'}`}>
                      {cryptoCurrency === 'USDT' && <div className="w-2 h-2 bg-brand-accent rounded-full"></div>}
                    </div>
                  </div>

                  <div 
                    onClick={() => setCryptoCurrency('BTC')}
                    className={`border p-4 cursor-pointer rounded-sm flex items-center justify-between transition-colors ${cryptoCurrency === 'BTC' ? 'border-brand-accent bg-brand-accent/5' : 'border-brand-border hover:border-white/20 bg-brand-card'}`}
                  >
                    <div className="space-y-1">
                      <span className="text-xs font-bold text-white uppercase block">₿ Bitcoin Native</span>
                      <span className="text-[9px] text-brand-text-muted font-mono">Proof-of-work baseline sovereign currency.</span>
                    </div>
                    <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${cryptoCurrency === 'BTC' ? 'border-brand-accent' : 'border-brand-border'}`}>
                      {cryptoCurrency === 'BTC' && <div className="w-2 h-2 bg-brand-accent rounded-full"></div>}
                    </div>
                  </div>
                </div>

                {cryptoCurrency === 'USDT' && (
                  <div className="p-4 border border-brand-border bg-black/50 space-y-3 rounded-sm">
                    <label className="text-[9px] font-mono text-white/50 uppercase block">Select Blockchain Network for USDT</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['Solana', 'Ethereum (ERC-20)', 'Tron (TRC-20)'].map((net) => (
                        <button
                          key={net}
                          type="button"
                          onClick={() => setCryptoNetwork(net as any)}
                          className={`px-3 py-2 border text-[10px] font-mono uppercase transition-colors rounded-sm ${cryptoNetwork === net ? 'border-brand-accent bg-brand-accent/10 text-brand-accent' : 'border-brand-border hover:border-white/10 text-white/60'}`}
                        >
                          {net.replace(' (ERC-20)', '').replace(' (TRC-20)', '')}
                        </button>
                      ))}
                    </div>
                    <span className="text-[9px] text-brand-text-muted font-mono block">Ensure your transfer origin wallet matches the selected target chain.</span>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-brand-border">
                <button
                  type="submit"
                  disabled={submittingOrder || cart.length === 0}
                  className="w-full py-4 bg-brand-accent text-black font-bold uppercase tracking-widest text-xs rounded-sm hover:bg-white transition-all font-mono"
                >
                  {submittingOrder ? 'Generating secure nodes wallet...' : `PROCEED TO CRYPTO PAYMENT (Timer Active)`}
                </button>
              </div>
            </form>

            {/* Summary Block (Right - 5 columns) */}
            <div className="lg:col-span-5 space-y-6">
              <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-6">
                <h3 className="text-xs font-bold tracking-wider uppercase font-mono text-white/50 border-b border-brand-border pb-2">Order Review</h3>
                
                {/* Items List */}
                <div className="space-y-4 max-h-64 overflow-y-auto pr-2">
                  {cart.map(item => {
                    const price = item.product.salePrice || item.product.price;
                    return (
                      <div key={item.product.id} className="flex justify-between items-start text-xs font-mono">
                        <div className="space-y-1">
                          <span className="text-white uppercase font-bold block">{item.product.title}</span>
                          <span className="text-[9px] text-brand-text-muted">SKU: {item.product.sku} &times; {item.quantity}</span>
                        </div>
                        <span className="text-white">${(price * item.quantity).toFixed(2)}</span>
                      </div>
                    );
                  })}
                  {cart.length === 0 && (
                    <div className="text-xs font-mono text-white/40 text-center py-4">No cargo added to terminal.</div>
                  )}
                </div>

                {/* Coupon Code Section */}
                <div className="pt-4 border-t border-brand-border flex gap-2">
                  <input 
                    type="text"
                    placeholder="PROMO CODE"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    className="bg-black border border-brand-border px-3 py-1.5 text-xs font-mono uppercase text-white flex-1 focus:outline-none focus:border-brand-accent"
                  />
                  <button 
                    type="button"
                    onClick={handleApplyCoupon}
                    className="px-4 py-1.5 border border-white text-xs font-mono font-bold text-black bg-white hover:bg-brand-accent hover:border-brand-accent uppercase"
                  >
                    Apply
                  </button>
                </div>

                {/* Pricing summary details */}
                <div className="border-t border-brand-border pt-4 space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between">
                    <span className="text-white/50">Subtotal Cargo</span>
                    <span className="text-white">${cartSubtotal.toFixed(2)}</span>
                  </div>
                  {appliedDiscount > 0 && (
                    <div className="flex justify-between text-brand-accent">
                      <span>Promo Discount ({appliedDiscount}%)</span>
                      <span>-${discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-white/50">Standard Tax (8%)</span>
                    <span className="text-white">${taxAmount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/50">Standard Secure Carrier</span>
                    <span className="text-white">${shippingFee.toFixed(2)}</span>
                  </div>
                  <div className="border-t border-brand-border pt-3 flex justify-between font-bold text-sm">
                    <span className="text-white">Total Amount Due</span>
                    <span className="text-brand-accent">${cartTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Secure Node Info */}
              <div className="p-4 border border-brand-border bg-black/40 rounded-sm flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-brand-accent shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <h5 className="text-xs font-bold text-white uppercase font-mono">Sovereign Encryption Guard</h5>
                  <p className="text-[10px] text-brand-text-muted leading-relaxed font-mono">
                    Transactions are mapped to unique direct public wallet keys generated securely from system hardware nodes.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. ORDER TRACKING & PAYMENT SIMULATION VIEW */}
      {view === 'order-tracking' && activeOrder && (
        <div className="p-8 md:p-12 space-y-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-brand-border pb-6 gap-4">
            <div>
              <span className="text-[10px] font-mono text-brand-accent uppercase tracking-widest block">SECURE GATEWAY ENVELOPE</span>
              <h2 className="text-3xl font-bold uppercase tracking-tight font-display mt-1">Invoice: {activeOrder.orderReference}</h2>
              <p className="text-xs text-brand-text-muted mt-1">Direct cryptographic payment session active. Updated in real time.</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono text-white/50">Status:</span>
              <span className={`px-2 py-1 text-xs font-mono font-bold uppercase rounded-sm ${activeOrder.status === 'Paid' ? 'bg-brand-accent/20 text-brand-accent border border-brand-accent' : 'bg-brand-orange/20 text-brand-orange border border-brand-orange'}`}>
                {activeOrder.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Payment Details Card (Left - 5 columns) */}
            <div className="lg:col-span-5 border border-brand-border bg-brand-card p-6 rounded-sm space-y-6">
              <div className="text-center space-y-4">
                <span className="text-xs font-mono text-white/50 uppercase block">TARGET RECEIVING GATEWAY ({activeOrder.payment.currency})</span>
                
                {/* Big QR Display */}
                <div className="w-48 h-48 bg-white p-3 mx-auto flex flex-col justify-between rounded-sm border border-brand-border relative">
                  <div className="flex-1 flex flex-wrap gap-1 p-2 justify-center items-center">
                    {/* Simulated pixel QR block */}
                    {Array.from({ length: 144 }).map((_, i) => (
                      <div 
                        key={i} 
                        className={`w-2 h-2 ${((i * 7 + 13) % 4 === 0 || (i % 9 === 0) || (i < 24 && i % 3 === 0)) ? 'bg-black' : 'bg-transparent'}`}
                      ></div>
                    ))}
                  </div>
                  <span className="text-[7px] text-black font-bold font-mono uppercase tracking-widest mt-2">{activeOrder.payment.currency} QR TERMINAL</span>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] text-brand-text-muted font-mono uppercase">Send exactly this cryptocurrency amount:</span>
                  <div className="text-2xl font-bold font-mono text-brand-accent">
                    {activeOrder.payment.amountCrypto} {activeOrder.payment.currency}
                  </div>
                  <span className="text-[10px] text-white/40 font-mono block">≈ ${activeOrder.total.toFixed(2)} USD</span>
                </div>
              </div>

              {/* Wallet Address Copy Block */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono text-brand-text-muted uppercase block">Merchant Public Key Address</label>
                <div className="bg-black border border-brand-border p-3 font-mono text-[10px] text-brand-accent select-all break-all rounded-sm flex items-center justify-between">
                  <span>{activeOrder.payment.walletAddress}</span>
                </div>
                {activeOrder.payment.network && (
                  <span className="text-[9px] text-brand-orange font-mono block uppercase">REQUIRED BLOCKCHAIN: {activeOrder.payment.network}</span>
                )}
              </div>

              {/* Confirmations Progress Stream (Automatic blockchain updates simulated) */}
              <div className="border-t border-brand-border pt-4 space-y-3 font-mono">
                <div className="flex justify-between text-xs">
                  <span className="text-white/50 uppercase">Sync confirmations:</span>
                  <span className="text-brand-accent font-bold">{activeOrder.payment.confirmations} / {activeOrder.payment.requiredConfirmations}</span>
                </div>
                
                <div className="h-2 w-full bg-black border border-brand-border rounded-sm overflow-hidden">
                  <div 
                    className="h-full bg-brand-accent transition-all duration-1000"
                    style={{ width: `${Math.min((activeOrder.payment.confirmations / activeOrder.payment.requiredConfirmations) * 100, 100)}%` }}
                  ></div>
                </div>

                {activeOrder.payment.txHash ? (
                  <div className="space-y-1">
                    <span className="text-[8px] text-white/30 uppercase block">TX Hash Signature Detected:</span>
                    <span className="text-[9px] text-brand-accent select-all break-all block">{activeOrder.payment.txHash}</span>
                  </div>
                ) : (
                  <div className="text-[9px] text-white/40 italic flex items-center gap-1.5">
                    <RefreshCw className="w-3 h-3 animate-spin" /> Node polling blocks for incoming transaction broadcast...
                  </div>
                )}
              </div>
            </div>

            {/* Invoice & Shipping Overview (Right - 7 columns) */}
            <div className="lg:col-span-7 space-y-6">
              <div className="border border-brand-border bg-black/40 p-6 rounded-sm space-y-6">
                <h3 className="text-xs font-bold tracking-wider uppercase font-mono text-white/50 border-b border-brand-border pb-2">Operational Invoice Details</h3>
                
                {/* Shipping address details */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
                  <div className="space-y-1.5">
                    <span className="text-white/40 uppercase block">Delivery Target:</span>
                    <span className="text-white font-bold block">{activeOrder.shippingAddress.name}</span>
                    <span className="text-white/80 block">{activeOrder.shippingAddress.line1}</span>
                    {activeOrder.shippingAddress.line2 && <span className="text-white/80 block">{activeOrder.shippingAddress.line2}</span>}
                    <span className="text-white/80 block">{activeOrder.shippingAddress.city}, {activeOrder.shippingAddress.state} {activeOrder.shippingAddress.postalCode}</span>
                    <span className="text-white/60 block">Phone: {activeOrder.shippingAddress.phone}</span>
                  </div>

                  <div className="space-y-1.5">
                    <span className="text-white/40 uppercase block">Receipt details:</span>
                    <div className="flex justify-between text-[11px] border-b border-brand-border pb-1">
                      <span className="text-white/60">Subtotal Cargo</span>
                      <span className="text-white">${activeOrder.subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] border-b border-brand-border pb-1">
                      <span className="text-white/60">Local Tax (8%)</span>
                      <span className="text-white">${activeOrder.tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-[11px] border-b border-brand-border pb-1">
                      <span className="text-white/60">Carrier Fee</span>
                      <span className="text-white">${activeOrder.shippingFee.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-xs pt-1.5 font-bold">
                      <span className="text-brand-accent">Total Invoice</span>
                      <span className="text-brand-accent">${activeOrder.total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {/* Cargo breakdown */}
                <div className="space-y-3 pt-4 border-t border-brand-border">
                  <span className="text-[10px] text-white/30 font-mono uppercase block">Cargo Checklist</span>
                  <div className="space-y-2">
                    {activeOrder.items.map((item, idx) => (
                      <div key={idx} className="flex justify-between items-center bg-black/30 p-2.5 rounded-sm border border-brand-border font-mono text-xs">
                        <span className="text-white uppercase">{item.title} (SKU: {item.sku})</span>
                        <span className="text-brand-accent font-semibold">&times;{item.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Troubleshooting action block */}
              <div className="p-5 border border-brand-border bg-brand-card rounded-sm space-y-4">
                <h4 className="text-xs font-bold font-mono text-white uppercase flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-brand-orange" /> Transaction Support Desk
                </h4>
                <p className="text-[10px] font-mono text-brand-text-muted leading-relaxed">
                  Has your network wallet dispatched funds but confirmations have not synced? Submit a diagnostic transaction hash request to our merchant node staff.
                </p>
                <div className="flex gap-4">
                  <button 
                    onClick={() => setView('contact')}
                    className="px-4 py-2 border border-brand-border hover:border-white text-[10px] font-mono uppercase text-white rounded-sm"
                  >
                    Send Support Message
                  </button>
                  <button 
                    onClick={() => {
                      const updated = orders.find(o => o.id === activeOrder.id);
                      if (updated) setActiveOrder(updated);
                    }}
                    className="px-4 py-2 bg-white text-black text-[10px] font-mono font-bold uppercase rounded-sm hover:bg-brand-accent transition-colors"
                  >
                    Force Node Refresh
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 6. ABOUT PAGE VIEW */}
      {view === 'about' && (
        <div className="p-8 md:p-16 max-w-4xl mx-auto space-y-12">
          <div className="space-y-4 text-center">
            <span className="text-xs font-mono text-brand-accent uppercase tracking-widest block">SOVEREIGN COMMERCE PROTOCOLS</span>
            <h2 className="text-4xl font-bold uppercase tracking-tight font-display">The Rocketman Blueprint</h2>
            <p className="text-base text-brand-text-muted max-w-xl mx-auto">
              "An established American trader returning to self-hosted technology. No licensing. No SaaS commissions. Pure hardware sovereign pipelines."
            </p>
          </div>

          <div className="border border-brand-border bg-brand-card p-8 space-y-6 rounded-sm">
            <h3 className="text-lg font-bold uppercase tracking-tight">Our Operational Philosophy</h3>
            <div className="space-y-4 text-sm text-white/70 leading-relaxed font-light">
              <p>
                Rocketman represents a clean rejection of SaaS e-commerce models that rent you access to your own customer base and tax your digital turnovers.
              </p>
              <p>
                Every listing we host represents physical, verified gear in our direct warehouse facilities. We process currency payments peer-to-peer using direct Bitcoin nodes and high-speed Tether networks, eliminating custodial intermediaries and arbitrary account blocks.
              </p>
              <p>
                We do not collect customer tracking cookies. We do not upsell marketing subscriptions. We assemble premium, monolithic hardware products designed for longevity.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs text-center">
            <div className="border border-brand-border p-6 rounded-sm bg-black/40 space-y-2">
              <span className="text-brand-accent font-bold text-lg block">99.9%</span>
              <span className="text-white/40 uppercase block">Node Uptime</span>
            </div>
            <div className="border border-brand-border p-6 rounded-sm bg-black/40 space-y-2">
              <span className="text-brand-accent font-bold text-lg block">100%</span>
              <span className="text-white/40 uppercase block">Direct Custody</span>
            </div>
            <div className="border border-brand-border p-6 rounded-sm bg-black/40 space-y-2">
              <span className="text-brand-accent font-bold text-lg block">&lt; 15 mins</span>
              <span className="text-white/40 uppercase block">Packing Dispatch</span>
            </div>
          </div>
        </div>
      )}

      {/* 7. SECURE SUPPORT MESSAGES CONTACT VIEW */}
      {view === 'contact' && (
        <div className="p-8 md:p-16 max-w-2xl mx-auto space-y-8">
          <div>
            <h2 className="text-3xl font-bold uppercase tracking-tight font-display text-center">Support Terminal</h2>
            <p className="text-xs text-brand-text-muted mt-1 text-center font-mono">Submit secure encrypted inquiries directly to our merchant administration panel.</p>
          </div>

          {contactSent ? (
            <div className="border border-brand-accent bg-brand-accent/5 p-8 text-center space-y-4 rounded-sm">
              <CheckCircle className="w-10 h-10 text-brand-accent mx-auto" />
              <h3 className="text-lg font-bold uppercase tracking-tight">Message Logged to Database</h3>
              <p className="text-xs text-brand-text-muted font-mono">
                Your communication has been received by our terminal staff. Check the seller panel or your email for confirmation updates.
              </p>
              <button 
                onClick={() => setContactSent(false)}
                className="px-6 py-2 border border-brand-border text-xs font-mono uppercase text-white hover:bg-white/5 rounded-sm"
              >
                Send another message
              </button>
            </div>
          ) : (
            <form onSubmit={handleSendMessage} className="border border-brand-border bg-brand-card p-8 rounded-sm space-y-6">
              <div className="space-y-1">
                <label className="text-[10px] font-mono text-brand-text-muted uppercase block">Your Email Address</label>
                <input 
                  type="email" 
                  required
                  placeholder="operator@domain.com"
                  value={contactEmail}
                  onChange={(e) => setContactEmail(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono text-brand-text-muted uppercase block">Subject / Invoice reference</label>
                <input 
                  type="text" 
                  required
                  placeholder="e.g. Confirm Solana transfer for invoice"
                  value={contactSubject}
                  onChange={(e) => setContactSubject(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono text-brand-text-muted uppercase block">Communication Body</label>
                <textarea 
                  rows={5}
                  required
                  placeholder="Enter detailed message specification..."
                  value={contactBody}
                  onChange={(e) => setContactBody(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 text-xs text-white focus:outline-none focus:border-brand-accent font-mono"
                ></textarea>
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-white text-black font-bold uppercase tracking-widest text-xs hover:bg-brand-accent transition-all font-mono"
              >
                Broadcast to Merchant Node
              </button>
            </form>
          )}
        </div>
      )}

      {/* --- CART SLIDE OUT DRAWER OVERLAY --- */}
      {cartOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-[9999] flex justify-end">
          <div className="w-full max-w-md bg-brand-black border-l border-white/10 h-full flex flex-col justify-between p-6">
            <div className="space-y-6 flex-1 overflow-y-auto">
              <div className="flex justify-between items-center border-b border-white/10 pb-4">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-brand-accent" />
                  <h3 className="text-base font-bold uppercase tracking-tight">Active Cargo Cart</h3>
                </div>
                <button 
                  onClick={() => setCartOpen(false)}
                  className="p-1 border border-brand-border hover:border-white text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-4">
                {cart.map(item => {
                  const price = item.product.salePrice || item.product.price;
                  return (
                    <div key={item.product.id} className="border border-brand-border bg-brand-card p-3 rounded-sm flex items-start gap-3">
                      <img src={item.product.images[0]} className="w-12 h-12 object-cover rounded-sm border border-brand-border" alt="" />
                      <div className="flex-1 space-y-1">
                        <span className="text-xs font-bold text-white uppercase block line-clamp-1">{item.product.title}</span>
                        <span className="text-[10px] text-brand-accent font-mono block">${price.toFixed(2)} each</span>
                        
                        <div className="flex items-center gap-2 pt-1">
                          <button 
                            onClick={() => updateCartQuantity(item.product.id, -1)}
                            className="p-1 bg-black border border-brand-border rounded-sm hover:border-white"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-mono font-bold text-white">{item.quantity}</span>
                          <button 
                            onClick={() => updateCartQuantity(item.product.id, 1)}
                            className="p-1 bg-black border border-brand-border rounded-sm hover:border-white"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                      <span className="text-xs font-mono font-bold text-white">${(price * item.quantity).toFixed(2)}</span>
                    </div>
                  );
                })}

                {cart.length === 0 && (
                  <div className="text-center py-12 space-y-2">
                    <ShoppingCart className="w-8 h-8 text-white/20 mx-auto" />
                    <p className="text-xs font-mono text-white/40">Your cargo list is currently vacant.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Cart summary and checkout checkout button */}
            <div className="pt-6 border-t border-white/10 space-y-4">
              <div className="space-y-2 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-white/40">Subtotal Cargo</span>
                  <span className="text-white">${cartSubtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/40">Shipping Carrier Target</span>
                  <span className="text-white">${shippingFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between border-t border-brand-border pt-2 text-sm font-bold">
                  <span className="text-white">Est. Total</span>
                  <span className="text-brand-accent">${cartTotal.toFixed(2)}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button 
                  onClick={() => setCartOpen(false)}
                  className="py-3 border border-brand-border hover:border-white text-xs font-mono font-bold uppercase rounded-sm text-white"
                >
                  Continue Drops
                </button>
                <button 
                  disabled={cart.length === 0}
                  onClick={() => {
                    setCartOpen(false);
                    setView('checkout');
                  }}
                  className="py-3 bg-brand-accent text-black font-bold text-xs font-mono uppercase rounded-sm hover:bg-white transition-colors"
                >
                  Secure Checkout
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Cart Launcher Button */}
      {cart.length > 0 && !cartOpen && (
        <button 
          onClick={() => setCartOpen(true)}
          className="fixed bottom-6 right-6 z-[999] bg-brand-orange text-white p-4 rounded-full border-2 border-brand-border hover:scale-105 transition-transform flex items-center gap-2 shadow-lg"
        >
          <ShoppingCart className="w-5 h-5" />
          <span className="font-mono text-xs font-bold bg-white text-black rounded-full w-5 h-5 flex items-center justify-center">
            {cart.reduce((sum, item) => sum + item.quantity, 0)}
          </span>
        </button>
      )}
    </div>
  );
}
