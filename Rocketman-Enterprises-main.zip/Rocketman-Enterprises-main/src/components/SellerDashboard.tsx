/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  DollarSign, ShoppingBag, BarChart3, Users, MessageSquare, ClipboardList,
  Plus, Edit2, Copy, RefreshCw, Trash2, ShieldCheck, Download, Upload,
  Database, ToggleLeft, ToggleRight, Check, CheckCircle, Save, Settings, Search, AlertCircle
} from 'lucide-react';
import { Product, Order, Message, AuditLog, Coupon } from '../types';

interface SellerDashboardProps {
  products: Product[];
  orders: Order[];
  messages: Message[];
  logs: AuditLog[];
  onUpdateProduct: (id: string, update: any) => Promise<any>;
  onCreateProduct: (data: any) => Promise<any>;
  onDuplicateProduct: (id: string) => Promise<any>;
  onRelistProduct: (id: string) => Promise<any>;
  onDeleteProduct: (id: string) => Promise<any>;
  onBulkEdit: (ids: string[], update: any) => Promise<any>;
  onBulkDelete: (ids: string[]) => Promise<any>;
  onImportCSV: (rows: any[]) => Promise<any>;
  onUpdateOrderStatus: (id: string, status: string) => Promise<any>;
  onUpdateSettings: (settings: any, wallets: any) => Promise<any>;
  onReadMessage: (id: string) => Promise<any>;
}

export default function SellerDashboard({
  products,
  orders,
  messages,
  logs,
  onUpdateProduct,
  onCreateProduct,
  onDuplicateProduct,
  onRelistProduct,
  onDeleteProduct,
  onBulkEdit,
  onBulkDelete,
  onImportCSV,
  onUpdateOrderStatus,
  onUpdateSettings,
  onReadMessage
}: SellerDashboardProps) {
  // Tab selectors: 'overview' | 'products' | 'orders' | 'messages' | 'settings' | 'logs'
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'messages' | 'settings' | 'logs'>('overview');
  
  // Analytics State
  const [analytics, setAnalytics] = useState<any>({
    totalRevenue: 1154.44,
    salesCount: 1,
    pendingCount: 1,
    visitorCount: 1512,
    conversionRate: '0.07',
    averageOrderValue: '1154.44',
    paymentStats: { BTC: 1, USDT: 1 },
    recentTraffic: [
      { source: 'Direct/Search Node', value: 45 },
      { source: 'GitHub Repositories', value: 25 },
      { source: 'Crypto Forums', value: 18 }
    ],
    monthlySales: [
      { month: 'Jul', sales: 1154 }
    ]
  });

  // Products CRUD State
  const [productSearch, setProductSearch] = useState('');
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  
  // CSV Import State
  const [csvText, setCsvText] = useState('');
  const [csvStatus, setCsvStatus] = useState<string | null>(null);

  // Form inputs for Create / Edit
  const [formSku, setFormSku] = useState('');
  const [formTitle, setFormTitle] = useState('');
  const [formSubtitle, setFormSubtitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formCondition, setFormCondition] = useState<'Brand New' | 'Like New' | 'Excellent' | 'Good' | 'Fair'>('Brand New');
  const [formCategory, setFormCategory] = useState('Hardware');
  const [formSubcategory, setFormSubcategory] = useState('');
  const [formBrand, setFormBrand] = useState('Rocketman');
  const [formPrice, setFormPrice] = useState(99);
  const [formQty, setFormQty] = useState(5);
  const [formWeight, setFormWeight] = useState(1);
  const [formDimensions, setFormDimensions] = useState('100x100x20 mm');
  const [formShippingClass, setFormShippingClass] = useState('Standard Secure');
  const [formStatus, setFormStatus] = useState<'Draft' | 'Live' | 'Hidden' | 'Sold Out'>('Draft');
  const [formTags, setFormTags] = useState('');
  const [formImages, setFormImages] = useState('');

  // Settings State
  const [storeName, setStoreName] = useState('Rocketman');
  const [allowGuest, setAllowGuest] = useState(true);
  const [taxRate, setTaxRate] = useState(8.0);
  const [baseShipping, setBaseShipping] = useState(15.0);
  const [reqConfBtc, setReqConfBtc] = useState(3);
  const [reqConfUsdt, setReqConfUsdt] = useState(12);
  const [walletBtc, setWalletBtc] = useState('1RocketBitcoinMerchantAddress22222222');
  const [walletUsdtSol, setWalletUsdtSol] = useState('RocketSolMerchantUSDT111111111111111111');
  const [walletUsdtErc, setWalletUsdtErc] = useState('0xRocketMerchantUSDT333333333333333333');
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Fetch updated analytics metrics from real Express endpoint
  const fetchAnalytics = async () => {
    try {
      const res = await fetch('/api/analytics');
      const data = await res.json();
      setAnalytics(data);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchAnalytics();
    
    // Fetch current system settings to prepopulate settings form
    fetch('/api/settings')
      .then(r => r.json())
      .then(d => {
        setStoreName(d.systemSettings.storeName);
        setAllowGuest(d.systemSettings.allowGuestCheckout);
        setTaxRate(d.systemSettings.taxRate);
        setBaseShipping(d.systemSettings.baseShippingFee);
        setReqConfBtc(d.systemSettings.requiredConfirmationsBTC);
        setReqConfUsdt(d.systemSettings.requiredConfirmationsUSDT);
        setWalletBtc(d.merchantWallets.BTC);
        setWalletUsdtSol(d.merchantWallets.USDT_SOL);
        setWalletUsdtErc(d.merchantWallets.USDT_ERC20);
      }).catch(console.error);
  }, [products, orders]);

  // Product form handlers
  const handleEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setIsCreating(false);
    setFormSku(prod.sku);
    setFormTitle(prod.title);
    setFormSubtitle(prod.subtitle);
    setFormDesc(prod.description);
    setFormCondition(prod.condition);
    setFormCategory(prod.category);
    setFormSubcategory(prod.subcategory);
    setFormBrand(prod.brand);
    setFormPrice(prod.price);
    setFormQty(prod.quantity);
    setFormWeight(prod.weight);
    setFormDimensions(prod.dimensions);
    setFormShippingClass(prod.shippingClass);
    setFormStatus(prod.status as any);
    setFormTags(prod.tags.join(', '));
    setFormImages(prod.images.join(', '));
  };

  const handleStartCreate = () => {
    setEditingProduct(null);
    setIsCreating(true);
    setFormSku(`RM-SKU-${Math.floor(1000 + Math.random() * 9000)}`);
    setFormTitle('');
    setFormSubtitle('');
    setFormDesc('');
    setFormCondition('Brand New');
    setFormCategory('Hardware');
    setFormSubcategory('');
    setFormBrand('Rocketman');
    setFormPrice(150);
    setFormQty(10);
    setFormWeight(1.2);
    setFormDimensions('120x60x10 mm');
    setFormShippingClass('Standard Secure');
    setFormStatus('Live');
    setFormTags('Titanium, Minimal');
    setFormImages('https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop');
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const productPayload = {
      sku: formSku,
      title: formTitle,
      subtitle: formSubtitle,
      description: formDesc,
      condition: formCondition,
      category: formCategory,
      subcategory: formSubcategory,
      brand: formBrand,
      price: Number(formPrice),
      quantity: Number(formQty),
      weight: Number(formWeight),
      dimensions: formDimensions,
      shippingClass: formShippingClass,
      status: formStatus,
      tags: formTags.split(',').map(t => t.trim()).filter(Boolean),
      images: formImages.split(',').map(i => i.trim()).filter(Boolean)
    };

    if (editingProduct) {
      await onUpdateProduct(editingProduct.id, productPayload);
      setEditingProduct(null);
    } else {
      await onCreateProduct(productPayload);
      setIsCreating(false);
    }
  };

  // Bulk operation triggers
  const handleToggleProductSelection = (id: string) => {
    setSelectedProductIds(prev => 
      prev.includes(id) ? prev.filter(pId => pId !== id) : [...prev, id]
    );
  };

  const handleSelectAllProducts = () => {
    if (selectedProductIds.length === filteredProducts.length) {
      setSelectedProductIds([]);
    } else {
      setSelectedProductIds(filteredProducts.map(p => p.id));
    }
  };

  const handleBulkStatusChange = async (status: 'Live' | 'Draft' | 'Archived') => {
    if (selectedProductIds.length === 0) return;
    await onBulkEdit(selectedProductIds, { status });
    setSelectedProductIds([]);
    alert(`Bulk changed status of selected products to ${status}`);
  };

  const handleBulkArchiveDelete = async () => {
    if (selectedProductIds.length === 0) return;
    if (confirm(`Archive and delist ${selectedProductIds.length} selected items?`)) {
      await onBulkDelete(selectedProductIds);
      setSelectedProductIds([]);
    }
  };

  // CSV Import simulation
  const handleCSVImportSubmit = async () => {
    if (!csvText) return;
    try {
      // Simple parser: columns Title, SKU, Price, Quantity, Category, Description
      const lines = csvText.split('\n').map(l => l.trim()).filter(Boolean);
      if (lines.length < 2) {
        setCsvStatus('Error: Invalid CSV columns structure. Requires a Header row.');
        return;
      }
      const headers = lines[0].split(',').map(h => h.trim());
      const parsedRows = lines.slice(1).map(line => {
        const values = line.split(',');
        const obj: any = {};
        headers.forEach((header, index) => {
          obj[header] = values[index] ? values[index].trim() : '';
        });
        return obj;
      });

      await onImportCSV(parsedRows);
      setCsvStatus(`Success: Imported ${parsedRows.length} inventory products cleanly!`);
      setCsvText('');
    } catch (e) {
      setCsvStatus('Error: Faulty CSV formatting variables detected.');
    }
  };

  // Settings modification
  const handleSettingsSaveSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onUpdateSettings(
      {
        storeName,
        allowGuestCheckout: allowGuest,
        taxRate,
        baseShippingFee: baseShipping,
        requiredConfirmationsBTC: reqConfBtc,
        requiredConfirmationsUSDT: reqConfUsdt
      },
      {
        BTC: walletBtc,
        USDT_SOL: walletUsdtSol,
        USDT_ERC20: walletUsdtErc
      }
    );
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
  };

  // State Backup Download Trigger
  const handleTriggerDatabaseDownload = () => {
    fetch('/api/system/export')
      .then(res => res.json())
      .then(data => {
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
        const dlAnchorElem = document.createElement('a');
        dlAnchorElem.setAttribute("href",     dataStr     );
        dlAnchorElem.setAttribute("download", `rocketman_erp_backup_${Date.now()}.json`);
        dlAnchorElem.click();
      }).catch(console.error);
  };

  const filteredProducts = products.filter(p => 
    p.title.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.sku.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.category.toLowerCase().includes(productSearch.toLowerCase())
  );

  return (
    <div className="flex-1 overflow-y-auto bg-black text-white p-6 space-y-8" id="seller-dashboard-root">
      {/* Header and Telemetry Toggle */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-brand-border pb-6 gap-4">
        <div>
          <span className="text-[10px] text-brand-orange font-bold font-mono uppercase tracking-widest block">ADMINISTRATION ERP WORKSPACE</span>
          <h2 className="text-3xl font-bold uppercase tracking-tight font-display mt-1">Sovereign Seller Console</h2>
          <p className="text-xs text-brand-text-muted mt-1">Aggregate physical inventory, custom direct payments telemetry, and log tracking.</p>
        </div>

        <div className="flex gap-2 font-mono text-xs">
          {['overview', 'products', 'orders', 'messages', 'settings', 'logs'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as any)}
              className={`px-3 py-1.5 uppercase font-semibold border transition-colors rounded-sm ${activeTab === tab ? 'bg-white text-black border-white' : 'border-brand-border text-white/60 hover:text-white'}`}
            >
              {tab}
            </button>
          ))}
        </div>
      </div>

      {/* 1. OVERVIEW ANALYTICS TAB */}
      {activeTab === 'overview' && (
        <div className="space-y-8">
          {/* Top telemetry bento metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-2">
              <div className="flex justify-between items-center text-white/40 font-mono text-[10px] uppercase">
                <span>Direct Revenue</span>
                <DollarSign className="w-4 h-4 text-brand-accent" />
              </div>
              <div className="text-2xl font-bold font-mono tracking-tight">${analytics.totalRevenue.toFixed(2)}</div>
              <span className="text-[9px] text-brand-accent font-mono">P2P Crypto Settled (100% Custody)</span>
            </div>

            <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-2">
              <div className="flex justify-between items-center text-white/40 font-mono text-[10px] uppercase">
                <span>Orders Dispatched</span>
                <ShoppingBag className="w-4 h-4 text-brand-accent" />
              </div>
              <div className="text-2xl font-bold font-mono tracking-tight">{analytics.salesCount} / {orders.length}</div>
              <span className="text-[9px] text-white/40 font-mono">Awaiting: {analytics.pendingCount} operational</span>
            </div>

            <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-2">
              <div className="flex justify-between items-center text-white/40 font-mono text-[10px] uppercase">
                <span>Direct Visitors</span>
                <Users className="w-4 h-4 text-brand-accent" />
              </div>
              <div className="text-2xl font-bold font-mono tracking-tight">{analytics.visitorCount}</div>
              <span className="text-[9px] text-white/40 font-mono">Real-time unique node sessions</span>
            </div>

            <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-2">
              <div className="flex justify-between items-center text-white/40 font-mono text-[10px] uppercase">
                <span>Avg Conversion Rate</span>
                <BarChart3 className="w-4 h-4 text-brand-accent" />
              </div>
              <div className="text-2xl font-bold font-mono tracking-tight">{analytics.conversionRate}%</div>
              <span className="text-[9px] text-brand-accent font-mono">Average order: ${analytics.averageOrderValue}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Visual Custom Chart Panel */}
            <div className="lg:col-span-2 border border-brand-border bg-brand-card p-6 rounded-sm space-y-6">
              <div className="flex justify-between items-center border-b border-brand-border pb-3">
                <span className="text-xs font-bold font-mono uppercase tracking-widest text-white/60">Revenue Settlement Flow (UTC)</span>
                <span className="text-[10px] text-brand-accent font-mono uppercase">Node online</span>
              </div>
              
              {/* Dynamic bar charts with HTML structure */}
              <div className="h-64 flex items-end justify-between pt-4 pb-2 px-6">
                {[
                  { m: 'Jan', val: 0 },
                  { m: 'Feb', val: 320 },
                  { m: 'Mar', val: 560 },
                  { m: 'Apr', val: 780 },
                  { m: 'May', val: 990 },
                  { m: 'Jun', val: 1200 },
                  { m: 'Jul', val: analytics.totalRevenue }
                ].map((col, idx) => {
                  const percent = Math.min((col.val / 1600) * 100, 100);
                  return (
                    <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end flex-1">
                      <span className="text-[9px] font-mono text-brand-accent">${col.val.toFixed(0)}</span>
                      <div className="w-8 bg-brand-accent hover:bg-white transition-colors rounded-t-sm" style={{ height: `${percent}%` }}></div>
                      <span className="text-[10px] font-mono text-white/40 uppercase">{col.m}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Blockchain payment methods breakdown & traffic */}
            <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-6">
              <div className="flex justify-between items-center border-b border-brand-border pb-3">
                <span className="text-xs font-bold font-mono uppercase tracking-widest text-white/60">Network Split</span>
                <ShieldCheck className="w-4 h-4 text-brand-accent" />
              </div>

              <div className="space-y-4">
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-white/70">₿ Bitcoin Native Settlements</span>
                    <span className="text-white font-bold">{orders.filter(o => o.payment.currency === 'BTC').length} Orders</span>
                  </div>
                  <div className="h-2 w-full bg-black border border-brand-border rounded-sm overflow-hidden">
                    <div className="h-full bg-brand-orange" style={{ width: `${(orders.filter(o => o.payment.currency === 'BTC').length / (orders.length || 1)) * 100}%` }}></div>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-white/70">₮ Tether (USDT) Stablecoin</span>
                    <span className="text-white font-bold">{orders.filter(o => o.payment.currency === 'USDT').length} Orders</span>
                  </div>
                  <div className="h-2 w-full bg-black border border-brand-border rounded-sm overflow-hidden">
                    <div className="h-full bg-brand-accent" style={{ width: `${(orders.filter(o => o.payment.currency === 'USDT').length / (orders.length || 1)) * 100}%` }}></div>
                  </div>
                </div>

                <div className="border-t border-brand-border pt-4 space-y-3 font-mono text-[10px]">
                  <span className="text-white/30 uppercase block font-semibold">Node Traffic routing sources</span>
                  {analytics.recentTraffic?.map((tr: any, tIdx: number) => (
                    <div key={tIdx} className="flex justify-between items-center border-b border-brand-border/5 pb-1.5">
                      <span className="text-white/60">{tr.source}</span>
                      <span className="text-white font-bold">{tr.value}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. PRODUCTS INVENTORY WORKSPACE TAB */}
      {activeTab === 'products' && (
        <div className="space-y-6">
          {/* Operations and form layout switcher */}
          {!isCreating && !editingProduct ? (
            <div className="space-y-6">
              {/* Controls bar */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-brand-card p-4 border border-brand-border rounded-sm">
                <div className="flex flex-wrap items-center gap-3">
                  <button 
                    onClick={handleStartCreate}
                    className="px-4 py-2 bg-white text-black font-bold text-xs uppercase tracking-wider font-mono rounded-sm hover:bg-brand-accent flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" /> Add custom product
                  </button>

                  <div className="h-6 w-[1px] bg-white/10 hidden md:block"></div>

                  {/* Bulk edit buttons */}
                  {selectedProductIds.length > 0 && (
                    <div className="flex items-center gap-2 font-mono text-[10px]">
                      <span className="text-brand-accent font-bold uppercase">{selectedProductIds.length} Selected:</span>
                      <button 
                        onClick={() => handleBulkStatusChange('Live')}
                        className="px-2 py-1 border border-brand-border hover:border-white uppercase rounded-sm"
                      >
                        Publish
                      </button>
                      <button 
                        onClick={() => handleBulkStatusChange('Draft')}
                        className="px-2 py-1 border border-brand-border hover:border-white uppercase rounded-sm"
                      >
                        Draft
                      </button>
                      <button 
                        onClick={handleBulkArchiveDelete}
                        className="px-2 py-1 bg-brand-orange/20 text-brand-orange border border-brand-orange/30 hover:bg-brand-orange/30 uppercase rounded-sm"
                      >
                        Archive/Delist
                      </button>
                    </div>
                  )}
                </div>

                <div className="relative w-full md:w-64">
                  <input 
                    type="text"
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    placeholder="Search SKU, title, category..."
                    className="w-full bg-black border border-brand-border px-3 py-1.5 text-xs text-white rounded-sm focus:outline-none focus:border-brand-accent font-mono"
                  />
                  <Search className="w-3.5 h-3.5 absolute right-3 top-2 text-white/30" />
                </div>
              </div>

              {/* Products Table */}
              <div className="border border-brand-border bg-brand-card rounded-sm overflow-hidden">
                <table className="w-full text-left border-collapse font-mono text-xs">
                  <thead>
                    <tr className="bg-black border-b border-brand-border text-white/40 text-[10px] uppercase">
                      <th className="p-4 w-10">
                        <input 
                          type="checkbox" 
                          checked={selectedProductIds.length === filteredProducts.length && filteredProducts.length > 0}
                          onChange={handleSelectAllProducts}
                          className="accent-brand-accent cursor-pointer"
                        />
                      </th>
                      <th className="p-4">SKU / Code</th>
                      <th className="p-4">Listing Title</th>
                      <th className="p-4">Category</th>
                      <th className="p-4">Direct Price</th>
                      <th className="p-4 text-center">In Stock</th>
                      <th className="p-4 text-center">Status</th>
                      <th className="p-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-brand-border/60">
                    {filteredProducts.map(product => (
                      <tr key={product.id} className="hover:bg-white/5 transition-colors">
                        <td className="p-4">
                          <input 
                            type="checkbox"
                            checked={selectedProductIds.includes(product.id)}
                            onChange={() => handleToggleProductSelection(product.id)}
                            className="accent-brand-accent cursor-pointer"
                          />
                        </td>
                        <td className="p-4 font-bold text-brand-accent">{product.sku}</td>
                        <td className="p-4 uppercase max-w-xs truncate">{product.title}</td>
                        <td className="p-4 uppercase text-white/60">{product.category}</td>
                        <td className="p-4">
                          {product.salePrice ? (
                            <div className="flex flex-col">
                              <span className="text-brand-accent font-bold">${product.salePrice}</span>
                              <span className="text-[9px] text-white/40 line-through">${product.price}</span>
                            </div>
                          ) : (
                            <span className="text-white">${product.price}</span>
                          )}
                        </td>
                        <td className="p-4 text-center">
                          <span className={`font-bold ${product.quantity <= 2 ? 'text-brand-orange animate-pulse' : 'text-white'}`}>
                            {product.quantity} units
                          </span>
                        </td>
                        <td className="p-4 text-center">
                          <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-sm border ${product.status === 'Live' ? 'bg-brand-accent/10 border-brand-accent/30 text-brand-accent' : (product.status === 'Draft' ? 'bg-white/10 border-white/20 text-white/60' : 'bg-brand-orange/10 border-brand-orange/20 text-brand-orange')}`}>
                            {product.status}
                          </span>
                        </td>
                        <td className="p-4 text-right space-x-1.5">
                          <button 
                            onClick={() => handleEditProduct(product)}
                            className="p-1 border border-brand-border rounded-sm hover:border-white hover:text-brand-accent text-white"
                            title="Edit specs"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={async () => {
                              await onDuplicateProduct(product.id);
                              alert('Listing duplicated as draft');
                            }}
                            className="p-1 border border-brand-border rounded-sm hover:border-white text-white"
                            title="Duplicate listing"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                          {product.status === 'Sold Out' || product.status === 'Archived' ? (
                            <button 
                              onClick={async () => {
                                await onRelistProduct(product.id);
                                alert('Listing manually relisted to Live');
                              }}
                              className="p-1 border border-brand-border rounded-sm hover:border-white text-brand-accent"
                              title="Instant Relist"
                            >
                              <RefreshCw className="w-3.5 h-3.5" />
                            </button>
                          ) : null}
                          <button 
                            onClick={async () => {
                              if (confirm(`Delete and delist listing ${product.sku}?`)) {
                                await onDeleteProduct(product.id);
                              }
                            }}
                            className="p-1 border border-brand-border rounded-sm hover:border-brand-orange text-brand-orange"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}

                    {filteredProducts.length === 0 && (
                      <tr>
                        <td colSpan={8} className="p-12 text-center text-white/30 italic">
                          No physical inventory mapped to searching constraints.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Bulk paste CSV Block */}
              <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-4">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider font-display text-white">Automated Barcode & CSV Importer</h4>
                  <p className="text-[10px] text-brand-text-muted mt-1 font-mono">Format: Title, SKU, Price, Quantity, Category, Description. First row must be header labels.</p>
                </div>
                
                <textarea 
                  rows={4}
                  placeholder="Title,SKU,Price,Quantity,Category,Description&#10;Tactile Keycaps V3,RM-CAP-03,85,20,Hardware,PBT single dye caps&#10;Solar Adapter Pin,RM-PIN-02,30,50,Power,12V DC converter core"
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-brand-accent"
                ></textarea>

                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-mono text-brand-orange">{csvStatus}</span>
                  <button 
                    onClick={handleCSVImportSubmit}
                    className="px-6 py-2 bg-white text-black font-bold font-mono text-xs uppercase hover:bg-brand-accent flex items-center gap-1"
                  >
                    <Upload className="w-3.5 h-3.5" /> Process CSV stream
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* CREATE OR EDIT FORM */
            <form onSubmit={handleSaveProduct} className="border border-brand-border bg-brand-card p-8 rounded-sm space-y-6">
              <div className="flex justify-between items-center border-b border-brand-border pb-4">
                <h3 className="text-sm font-bold uppercase tracking-widest font-mono text-brand-accent">
                  {editingProduct ? `Modify listing: ${editingProduct.sku}` : 'Deploy new custom drop'}
                </h3>
                <button 
                  type="button"
                  onClick={() => { setEditingProduct(null); setIsCreating(false); }}
                  className="px-4 py-1.5 border border-brand-border text-xs font-mono uppercase text-white hover:border-white"
                >
                  Cancel
                </button>
              </div>

              {/* Fields Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">SKU Reference</label>
                  <input 
                    type="text" required value={formSku} onChange={(e) => setFormSku(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Title Name</label>
                  <input 
                    type="text" required value={formTitle} onChange={(e) => setFormTitle(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Subheading Description</label>
                  <input 
                    type="text" required value={formSubtitle} onChange={(e) => setFormSubtitle(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Category Name</label>
                  <input 
                    type="text" required value={formCategory} onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Brand</label>
                  <input 
                    type="text" required value={formBrand} onChange={(e) => setFormBrand(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Base Price (USD)</label>
                  <input 
                    type="number" required value={formPrice} onChange={(e) => setFormPrice(Number(e.target.value))}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Operational Stock Level</label>
                  <input 
                    type="number" required value={formQty} onChange={(e) => setFormQty(Number(e.target.value))}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Weight (KG)</label>
                  <input 
                    type="number" step="0.01" required value={formWeight} onChange={(e) => setFormWeight(Number(e.target.value))}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Dimensions (W x H x D)</label>
                  <input 
                    type="text" value={formDimensions} onChange={(e) => setFormDimensions(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Condition State</label>
                  <select 
                    value={formCondition} onChange={(e) => setFormCondition(e.target.value as any)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  >
                    <option value="Brand New">Brand New</option>
                    <option value="Like New">Like New</option>
                    <option value="Excellent">Excellent</option>
                    <option value="Good">Good</option>
                    <option value="Fair">Fair</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Listing status</label>
                  <select 
                    value={formStatus} onChange={(e) => setFormStatus(e.target.value as any)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  >
                    <option value="Live">Live</option>
                    <option value="Draft">Draft</option>
                    <option value="Hidden">Hidden</option>
                    <option value="Sold Out">Sold Out</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-brand-text-muted uppercase">Search tags (comma split)</label>
                  <input 
                    type="text" value={formTags} onChange={(e) => setFormTags(e.target.value)}
                    className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                  />
                </div>
              </div>

              <div className="space-y-1 font-mono text-xs">
                <label className="text-[10px] text-brand-text-muted uppercase block">Image URL gallery (Comma split)</label>
                <input 
                  type="text" value={formImages} onChange={(e) => setFormImages(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                />
              </div>

              <div className="space-y-1 font-mono text-xs">
                <label className="text-[10px] text-brand-text-muted uppercase block font-semibold">Markdown Description Details</label>
                <textarea 
                  rows={5} required value={formDesc} onChange={(e) => setFormDesc(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:border-brand-accent focus:outline-none"
                ></textarea>
              </div>

              <button 
                type="submit"
                className="px-8 py-3 bg-white text-black font-bold font-mono text-xs uppercase hover:bg-brand-accent"
              >
                Deploy inventory specification
              </button>
            </form>
          )}
        </div>
      )}

      {/* 3. ORDERS MANAGER WORKSPACE TAB */}
      {activeTab === 'orders' && (
        <div className="space-y-6">
          <div className="border border-brand-border bg-brand-card rounded-sm overflow-hidden">
            <table className="w-full text-left border-collapse font-mono text-xs">
              <thead>
                <tr className="bg-black border-b border-brand-border text-white/40 text-[10px] uppercase">
                  <th className="p-4">Reference</th>
                  <th className="p-4">Customer Credentials</th>
                  <th className="p-4">Total Price</th>
                  <th className="p-4 text-center">Settled Currency</th>
                  <th className="p-4 text-center">Blockchain confirmations</th>
                  <th className="p-4 text-center">Dispatch status</th>
                  <th className="p-4 text-right">Admin overrides</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brand-border/60">
                {orders.map(order => (
                  <tr key={order.id} className="hover:bg-white/5 transition-colors">
                    <td className="p-4 font-bold text-white">{order.orderReference}</td>
                    <td className="p-4">
                      <div className="flex flex-col text-xs font-semibold">
                        <span>{order.customerName}</span>
                        <span className="text-[10px] text-white/40">{order.customerEmail}</span>
                      </div>
                    </td>
                    <td className="p-4 font-bold text-brand-accent">${order.total.toFixed(2)}</td>
                    <td className="p-4 text-center">
                      <span className="px-2 py-0.5 bg-black border border-brand-border rounded-sm">
                        {order.payment.currency}
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <span className={`font-semibold ${order.payment.confirmations >= order.payment.requiredConfirmations ? 'text-brand-accent' : 'text-brand-orange'}`}>
                        {order.payment.confirmations} / {order.payment.requiredConfirmations} ({order.status === 'Paid' ? 'Verified' : 'Syncing'})
                      </span>
                    </td>
                    <td className="p-4 text-center">
                      <span className={`px-2 py-0.5 text-[10px] font-bold uppercase rounded-sm ${order.status === 'Paid' ? 'bg-brand-accent/20 text-brand-accent border border-brand-accent/30' : (order.status === 'Pending' || order.status === 'Awaiting Payment' ? 'bg-brand-orange/20 text-brand-orange border border-brand-orange/30' : 'bg-white/10 text-white/60')}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="p-4 text-right">
                      <select
                        value={order.status}
                        onChange={(e) => onUpdateOrderStatus(order.id, e.target.value)}
                        className="bg-black border border-brand-border text-[10px] py-1 px-2 focus:outline-none focus:border-brand-accent font-mono text-white"
                      >
                        <option value="Awaiting Payment">Awaiting Payment</option>
                        <option value="Paid">Mark as Paid</option>
                        <option value="Packing">Packing</option>
                        <option value="Shipped">Shipped</option>
                        <option value="Delivered">Delivered</option>
                        <option value="Refunded">Refunded</option>
                        <option value="Cancelled">Cancelled</option>
                      </select>
                    </td>
                  </tr>
                ))}

                {orders.length === 0 && (
                  <tr>
                    <td colSpan={7} className="p-12 text-center text-white/30 italic">
                      No operational orders logged in target project database.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. CUSTOMER SUPPORT MESSAGES TAB */}
      {activeTab === 'messages' && (
        <div className="space-y-6">
          <div className="space-y-4">
            {messages.map(msg => (
              <div 
                key={msg.id} 
                onClick={() => onReadMessage(msg.id)}
                className={`border p-6 rounded-sm space-y-3 cursor-pointer transition-colors ${msg.read ? 'border-brand-border bg-brand-card/30' : 'border-brand-accent/40 bg-brand-card'}`}
              >
                <div className="flex justify-between items-start font-mono text-xs">
                  <div className="space-y-1">
                    <span className="text-white font-bold uppercase block">{msg.subject}</span>
                    <span className="text-[10px] text-white/50">Sender Terminal: {msg.customerEmail}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[9px] text-white/40">{new Date(msg.createdAt).toLocaleString()}</span>
                    {!msg.read && (
                      <span className="px-1.5 py-0.5 bg-brand-accent text-black text-[9px] font-bold uppercase rounded-sm">NEW</span>
                    )}
                  </div>
                </div>

                <p className="text-xs text-white/80 whitespace-pre-line leading-relaxed font-light pl-2 border-l-2 border-brand-border">
                  {msg.body}
                </p>

                {msg.orderReference && (
                  <div className="text-[10px] font-mono text-brand-orange uppercase">
                    Linked Invoice Reference: <span className="font-bold underline">{msg.orderReference}</span>
                  </div>
                )}
              </div>
            ))}

            {messages.length === 0 && (
              <div className="border border-dashed border-brand-border p-12 text-center text-white/30 italic">
                Support messages registry vacant. No customer tickets logged.
              </div>
            )}
          </div>
        </div>
      )}

      {/* 5. SYSTEM SETTINGS & NODE BACKUPS TAB */}
      {activeTab === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          {/* Settings Config Form */}
          <form onSubmit={handleSettingsSaveSubmit} className="lg:col-span-2 border border-brand-border bg-brand-card p-6 rounded-sm space-y-6">
            <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-white/50 border-b border-brand-border pb-2">Operational Node Variables</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-brand-text-muted uppercase">Brand Name Prefix</label>
                <input 
                  type="text" value={storeName} onChange={(e) => setStoreName(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:outline-none focus:border-brand-accent"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-brand-text-muted uppercase">Standard Tax Multiplier (%)</label>
                <input 
                  type="number" step="0.1" value={taxRate} onChange={(e) => setTaxRate(Number(e.target.value))}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:outline-none focus:border-brand-accent"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-brand-text-muted uppercase">Carrier base fee ($)</label>
                <input 
                  type="number" value={baseShipping} onChange={(e) => setBaseShipping(Number(e.target.value))}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:outline-none focus:border-brand-accent"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-brand-text-muted uppercase">Allow guest checkout</label>
                <div className="flex items-center gap-3 pt-1">
                  <button 
                    type="button"
                    onClick={() => setAllowGuest(!allowGuest)}
                    className="text-brand-accent"
                  >
                    {allowGuest ? <ToggleRight className="w-8 h-8" /> : <ToggleLeft className="w-8 h-8 text-white/40" />}
                  </button>
                  <span className="text-[11px] text-white/60">{allowGuest ? 'Enabled' : 'Disabled'}</span>
                </div>
              </div>
            </div>

            <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-white/50 border-b border-brand-border pt-4 pb-2">Target Receivers Public Keys</h3>
            
            <div className="space-y-4 font-mono text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-brand-orange uppercase">₿ Bitcoin Wallet Base Address</label>
                <input 
                  type="text" value={walletBtc} onChange={(e) => setWalletBtc(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:outline-none focus:border-brand-accent"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-brand-accent uppercase">Solana chain public receiver (USDT)</label>
                <input 
                  type="text" value={walletUsdtSol} onChange={(e) => setWalletUsdtSol(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:outline-none focus:border-brand-accent"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-brand-accent uppercase">Ethereum (ERC-20) public receiver (USDT)</label>
                <input 
                  type="text" value={walletUsdtErc} onChange={(e) => setWalletUsdtErc(e.target.value)}
                  className="w-full bg-black border border-brand-border px-3 py-2 rounded-sm text-white focus:outline-none focus:border-brand-accent"
                />
              </div>
            </div>

            <div className="flex justify-between items-center pt-4">
              {settingsSaved ? (
                <span className="text-xs font-mono text-brand-accent flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4" /> Node configurations synchronized successfully.
                </span>
              ) : <span></span>}
              <button 
                type="submit"
                className="px-6 py-2.5 bg-white text-black font-bold font-mono text-xs uppercase hover:bg-brand-accent flex items-center gap-1.5"
              >
                <Save className="w-4 h-4" /> Synchronize variables
              </button>
            </div>
          </form>

          {/* Database download backup console */}
          <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-4">
            <h3 className="text-xs font-bold font-mono uppercase tracking-widest text-white/50 border-b border-brand-border pb-2">Platform Exports</h3>
            <p className="text-[11px] font-mono text-brand-text-muted leading-relaxed">
              Generate a physical, decrypted JSON export of the relational database catalog including products, orders, coupons, and messages logs.
            </p>
            <button 
              onClick={handleTriggerDatabaseDownload}
              className="w-full py-3 bg-black border border-brand-border hover:border-white text-white font-mono text-xs font-bold uppercase rounded-sm flex items-center justify-center gap-2"
            >
              <Database className="w-4 h-4 text-brand-accent" /> DOWNLOAD DATABASE BACKUP (.JSON)
            </button>
          </div>
        </div>
      )}

      {/* 6. SYSTEM AUDIT LOGS TAB */}
      {activeTab === 'logs' && (
        <div className="space-y-6">
          <div className="border border-brand-border bg-brand-card p-6 rounded-sm space-y-4">
            <div className="flex justify-between items-center border-b border-brand-border pb-2">
              <span className="text-xs font-bold font-mono uppercase tracking-widest text-white/50">Chronological Audit Ledger</span>
              <span className="text-[10px] text-white/40 font-mono">Immutable Log Stream</span>
            </div>

            <div className="space-y-2 max-h-[480px] overflow-y-auto pr-2">
              {logs.map(log => (
                <div key={log.id} className="p-3 bg-black border border-brand-border font-mono text-xs flex justify-between items-start rounded-sm gap-4 hover:bg-white/5">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-brand-orange font-bold uppercase">{log.action}</span>
                      <span className="text-[9px] text-white/30">IP: {log.ipAddress}</span>
                    </div>
                    <p className="text-white/80 leading-relaxed font-light">{log.details}</p>
                    <span className="text-[9px] text-brand-accent block">Executor: {log.userEmail}</span>
                  </div>
                  <span className="text-[9px] text-white/30 shrink-0">{new Date(log.createdAt).toLocaleString()}</span>
                </div>
              ))}

              {logs.length === 0 && (
                <div className="p-8 text-center text-white/30 italic">No system logs loaded.</div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
