/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { fileURLToPath } from 'url';
import { SEED_PRODUCTS, SEED_MESSAGES, SEED_LOGS } from './src/data.js';
import { Product, Order, Message, AuditLog, MediaItem, Coupon } from './src/types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  // JSON Body Parser with elevated limits for bulk operations
  app.use(express.json({ limit: '20mb' }));

  // In-memory relational state representations
  let products: Product[] = [...SEED_PRODUCTS];
  let orders: Order[] = [
    {
      id: 'o-01',
      orderReference: 'RM-2026-8941',
      customerId: 'cust-91',
      customerEmail: 'alex@fieldops.com',
      customerName: 'Alex Fieldman',
      items: [
        {
          productId: 'rm-01',
          sku: 'RM-TI-KBD-01',
          title: 'Titanium Mechanical Keyboard',
          price: 799.00,
          quantity: 1,
          image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop'
        }
      ],
      subtotal: 799.00,
      tax: 63.92,
      shippingFee: 25.00,
      total: 887.92,
      status: 'Awaiting Payment',
      shippingAddress: {
        name: 'Alex Fieldman',
        line1: '142 Monolith Parkway',
        line2: 'Suite 40B',
        city: 'Austin',
        state: 'TX',
        postalCode: '78701',
        country: 'United States',
        phone: '+1 (512) 555-0192'
      },
      payment: {
        method: 'crypto',
        currency: 'USDT',
        network: 'Solana',
        walletAddress: 'RocketSolMerchantUSDT111111111111111111',
        amountCrypto: 887.92,
        qrCodeData: 'solana:RocketSolMerchantUSDT111111111111111111?amount=887.92',
        paymentTimerSeconds: 1200,
        confirmations: 12,
        requiredConfirmations: 30
      },
      createdAt: '2026-07-14T03:30:00Z',
      updatedAt: '2026-07-14T03:30:00Z'
    },
    {
      id: 'o-02',
      orderReference: 'RM-2026-3814',
      customerId: 'cust-42',
      customerEmail: 'clara@architex.com',
      customerName: 'Clara Oswald',
      items: [
        {
          productId: 'rm-03',
          sku: 'RM-TIT-PEN-03',
          title: 'Machined Bolt Action Pen',
          price: 159.00,
          quantity: 2,
          image: 'https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?q=80&w=800&auto=format&fit=crop'
        }
      ],
      subtotal: 318.00,
      tax: 25.44,
      shippingFee: 12.00,
      total: 355.44,
      status: 'Paid',
      shippingAddress: {
        name: 'Clara Oswald',
        line1: '909 Brutalist Arch',
        city: 'Portland',
        state: 'OR',
        postalCode: '97205',
        country: 'United States',
        phone: '+1 (503) 555-8942'
      },
      payment: {
        method: 'crypto',
        currency: 'BTC',
        walletAddress: '1RocketBitcoinMerchantAddress22222222',
        amountCrypto: 0.0053,
        qrCodeData: 'bitcoin:1RocketBitcoinMerchantAddress22222222?amount=0.0053',
        paymentTimerSeconds: 0,
        confirmations: 6,
        requiredConfirmations: 3,
        txHash: 'e683416fd1df08940989bca7df7c8df817117462cd998fb98471b0db22df81c8'
      },
      createdAt: '2026-07-13T10:15:00Z',
      updatedAt: '2026-07-13T10:45:00Z'
    }
  ];

  let messages: Message[] = [...SEED_MESSAGES];
  let logs: AuditLog[] = [...SEED_LOGS];
  let coupons: Coupon[] = [
    { code: 'ROCKETLAUNCH', discountType: 'Percentage', value: 10, active: true },
    { code: 'TITANIUM50', discountType: 'Fixed', value: 50, active: true }
  ];

  let mediaLibrary: MediaItem[] = [
    {
      id: 'med-01',
      name: 'rm01_titanium_keyboard_main.jpg',
      originalName: 'rm01_titanium_keyboard_main.jpg',
      url: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop',
      webpUrl: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?q=80&w=800&auto=format&fit=crop',
      size: '242 KB',
      type: 'image/jpeg',
      optimized: true,
      createdAt: '2026-07-10T11:45:00Z'
    },
    {
      id: 'med-02',
      name: 'rm02_solar_station.jpg',
      originalName: 'rm02_solar_station.jpg',
      url: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?q=80&w=800&auto=format&fit=crop',
      webpUrl: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?q=80&w=800&auto=format&fit=crop',
      size: '412 KB',
      type: 'image/jpeg',
      optimized: true,
      createdAt: '2026-07-11T09:00:00Z'
    }
  ];

  // Configurable merchant wallets
  let merchantWallets = {
    BTC: '1RocketBitcoinMerchantAddress22222222',
    USDT_ERC20: '0xRocketMerchantUSDT333333333333333333',
    USDT_TRC20: 'TRocketMerchantUSDT444444444444444444',
    USDT_SOL: 'RocketSolMerchantUSDT111111111111111111'
  };

  // Base system configuration
  let systemSettings = {
    storeName: 'Rocketman',
    allowGuestCheckout: true,
    taxRate: 8.0, // 8% default
    baseShippingFee: 15.0,
    requiredConfirmationsBTC: 3,
    requiredConfirmationsUSDT: 12,
    underConstruction: false
  };

  // Helper to add system audit logs
  function logAction(action: string, details: string, email = 'tom@ahyx.org') {
    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId: 'admin-01',
      userEmail: email,
      action,
      details,
      ipAddress: '198.51.100.42',
      createdAt: new Date().toISOString()
    };
    logs.unshift(newLog);
  }

  // --- API ROUTES ---

  // 1. PRODUCTS CRUD
  app.get('/api/products', (req, res) => {
    res.json(products);
  });

  app.get('/api/products/:id', (req, res) => {
    const product = products.find(p => p.id === req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  });

  app.post('/api/products', (req, res) => {
    const data = req.body;
    const newProduct: Product = {
      id: `rm-${Date.now()}`,
      sku: data.sku || `RM-NEW-${Math.floor(Math.random() * 10000)}`,
      title: data.title || 'Untitled Product',
      subtitle: data.subtitle || '',
      description: data.description || '',
      specifications: data.specifications || [],
      condition: data.condition || 'Brand New',
      category: data.category || 'Hardware',
      subcategory: data.subcategory || '',
      brand: data.brand || 'Rocketman',
      tags: data.tags || [],
      price: Number(data.price) || 0,
      salePrice: data.salePrice ? Number(data.salePrice) : undefined,
      quantity: Number(data.quantity) || 0,
      weight: Number(data.weight) || 0,
      dimensions: data.dimensions || '',
      shippingClass: data.shippingClass || 'Standard Secure',
      countryOfOrigin: data.countryOfOrigin || 'United States',
      images: data.images && data.images.length ? data.images : ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop'],
      videos: data.videos || [],
      pdfs: data.pdfs || [],
      status: data.status || 'Draft',
      relistCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    products.unshift(newProduct);
    logAction('Product Created', `Created product "${newProduct.title}" (SKU: ${newProduct.sku})`);
    res.status(201).json(newProduct);
  });

  app.put('/api/products/:id', (req, res) => {
    const idx = products.findIndex(p => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Product not found' });
    
    const updated = {
      ...products[idx],
      ...req.body,
      updatedAt: new Date().toISOString()
    };
    products[idx] = updated;
    logAction('Product Updated', `Updated product details for "${updated.title}"`);
    res.json(updated);
  });

  app.post('/api/products/:id/relist', (req, res) => {
    const idx = products.findIndex(p => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Product not found' });
    
    const product = products[idx];
    product.status = 'Live';
    product.relistCount += 1;
    product.updatedAt = new Date().toISOString();
    logAction('Product Relisted', `Manually relisted "${product.title}" (total relists: ${product.relistCount})`);
    res.json(product);
  });

  app.post('/api/products/:id/duplicate', (req, res) => {
    const product = products.find(p => p.id === req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });

    const duplicate: Product = {
      ...product,
      id: `rm-dup-${Date.now()}`,
      sku: `${product.sku}-DUP`,
      title: `${product.title} (Copy)`,
      status: 'Draft',
      relistCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    products.unshift(duplicate);
    logAction('Product Duplicated', `Duplicated "${product.title}" to create "${duplicate.title}"`);
    res.json(duplicate);
  });

  app.delete('/api/products/:id', (req, res) => {
    const idx = products.findIndex(p => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Product not found' });
    
    const product = products[idx];
    product.status = 'Deleted';
    logAction('Product Deleted', `Set status of product "${product.title}" to Deleted`);
    res.json({ success: true, message: 'Product archived as deleted' });
  });

  // Bulk Operations on Products
  app.post('/api/products/bulk-edit', (req, res) => {
    const { ids, update } = req.body;
    if (!ids || !Array.isArray(ids)) return res.status(400).json({ error: 'Invalid IDs array' });

    products = products.map(p => {
      if (ids.includes(p.id)) {
        return {
          ...p,
          ...update,
          updatedAt: new Date().toISOString()
        };
      }
      return p;
    });

    logAction('Bulk Products Edit', `Modified ${ids.length} products simultaneously.`);
    res.json({ success: true });
  });

  app.post('/api/products/bulk-delete', (req, res) => {
    const { ids } = req.body;
    if (!ids || !Array.isArray(ids)) return res.status(400).json({ error: 'Invalid IDs array' });

    products = products.map(p => {
      if (ids.includes(p.id)) {
        return { ...p, status: 'Deleted', updatedAt: new Date().toISOString() };
      }
      return p;
    });

    logAction('Bulk Products Deleted', `Deleted ${ids.length} products.`);
    res.json({ success: true });
  });

  // CSV Import / Export endpoints
  app.post('/api/products/import-csv', (req, res) => {
    const { rows } = req.body; // array of objects
    if (!rows || !Array.isArray(rows)) return res.status(400).json({ error: 'Invalid CSV parsed structure' });

    rows.forEach(r => {
      const p: Product = {
        id: `rm-csv-${Date.now()}-${Math.floor(Math.random()*1000)}`,
        sku: r.SKU || `RM-CSV-${Math.floor(Math.random()*10000)}`,
        title: r.Title || 'CSV Imported Product',
        subtitle: r.Subtitle || '',
        description: r.Description || '',
        specifications: r.Specifications ? JSON.parse(r.Specifications) : [],
        condition: r.Condition || 'Brand New',
        category: r.Category || 'Hardware',
        subcategory: r.Subcategory || '',
        brand: r.Brand || 'Rocketman',
        tags: r.Tags ? r.Tags.split(',').map((t: string) => t.trim()) : [],
        price: Number(r.Price) || 99,
        quantity: Number(r.Quantity) || 1,
        weight: Number(r.Weight) || 1,
        dimensions: r.Dimensions || '',
        shippingClass: r.ShippingClass || 'Standard Secure',
        countryOfOrigin: r.CountryOfOrigin || 'United States',
        images: r.Images ? r.Images.split(',').map((img: string) => img.trim()) : ['https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop'],
        videos: [],
        pdfs: [],
        status: 'Draft',
        relistCount: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      products.unshift(p);
    });

    logAction('CSV Import', `Imported ${rows.length} products from inventory list`);
    res.json({ success: true, count: rows.length });
  });

  // 2. ORDERS CRUD
  app.get('/api/orders', (req, res) => {
    res.json(orders);
  });

  app.post('/api/orders', (req, res) => {
    const orderData = req.body;
    const ref = `RM-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    
    const newOrder: Order = {
      id: `o-${Date.now()}`,
      orderReference: ref,
      customerId: orderData.customerId || 'guest-user',
      customerEmail: orderData.customerEmail,
      customerName: orderData.customerName,
      items: orderData.items,
      subtotal: orderData.subtotal,
      tax: orderData.tax,
      shippingFee: orderData.shippingFee,
      total: orderData.total,
      status: 'Pending',
      shippingAddress: orderData.shippingAddress,
      payment: {
        method: 'crypto',
        currency: orderData.paymentCurrency || 'BTC',
        network: orderData.paymentNetwork,
        walletAddress: orderData.paymentCurrency === 'BTC' ? merchantWallets.BTC : (
          orderData.paymentNetwork === 'Ethereum (ERC-20)' ? merchantWallets.USDT_ERC20 : (
            orderData.paymentNetwork === 'Tron (TRC-20)' ? merchantWallets.USDT_TRC20 : merchantWallets.USDT_SOL
          )
        ),
        amountCrypto: orderData.amountCrypto,
        qrCodeData: `${orderData.paymentCurrency.toLowerCase()}:${orderData.paymentCurrency === 'BTC' ? merchantWallets.BTC : merchantWallets.USDT_SOL}?amount=${orderData.amountCrypto}`,
        paymentTimerSeconds: 1800,
        confirmations: 0,
        requiredConfirmations: orderData.paymentCurrency === 'BTC' ? systemSettings.requiredConfirmationsBTC : systemSettings.requiredConfirmationsUSDT
      },
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    orders.unshift(newOrder);
    logAction('Order Created', `Placed order ${newOrder.orderReference} for ${newOrder.customerEmail} (${newOrder.total} USD)`);
    res.status(201).json(newOrder);
  });

  app.put('/api/orders/:id/status', (req, res) => {
    const { status } = req.body;
    const idx = orders.findIndex(o => o.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Order not found' });
    
    orders[idx].status = status;
    orders[idx].updatedAt = new Date().toISOString();
    logAction('Order Status Updated', `Set order ${orders[idx].orderReference} status to "${status}"`);
    res.json(orders[idx]);
  });

  // Cryptocurrency Simulation Engine
  // Periodically increment confirmations on "Awaiting Payment" orders to simulate blockchain activity (Method 2)
  setInterval(() => {
    let changed = false;
    orders = orders.map(order => {
      if (order.status === 'Awaiting Payment' || order.status === 'Pending') {
        const conf = order.payment.confirmations + Math.floor(Math.random() * 3) + 1;
        const limit = order.payment.requiredConfirmations;
        const newConf = Math.min(conf, limit);
        
        let newStatus: Order['status'] = order.status;
        let txHash = order.payment.txHash;
        if (!txHash && Math.random() > 0.4) {
          txHash = '0x' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('');
        }

        if (newConf >= limit) {
          newStatus = 'Paid';
          logAction('Blockchain Auto Detect', `Detected total confirmations (${newConf}/${limit}) for order ${order.orderReference}. Marked as Paid.`, 'system-node@rocketman');
        }

        changed = true;
        return {
          ...order,
          status: newStatus,
          payment: {
            ...order.payment,
            confirmations: newConf,
            txHash
          },
          updatedAt: new Date().toISOString()
        };
      }
      return order;
    });
  }, 15000);

  // 3. MESSAGES / SUPPORT TICKETS
  app.get('/api/messages', (req, res) => {
    res.json(messages);
  });

  app.post('/api/messages', (req, res) => {
    const data = req.body;
    const newMsg: Message = {
      id: `m-${Date.now()}`,
      sender: data.sender || 'Customer',
      customerEmail: data.customerEmail,
      orderReference: data.orderReference,
      subject: data.subject || 'Order Inquiry',
      body: data.body,
      createdAt: new Date().toISOString(),
      read: false
    };
    messages.unshift(newMsg);
    logAction('Message Received', `New message from ${newMsg.customerEmail}: "${newMsg.subject}"`);
    res.status(201).json(newMsg);
  });

  app.put('/api/messages/:id/read', (req, res) => {
    const idx = messages.findIndex(m => m.id === req.params.id);
    if (idx !== -1) {
      messages[idx].read = true;
      res.json(messages[idx]);
    } else {
      res.status(404).json({ error: 'Message not found' });
    }
  });

  // 4. WALLETS AND SETTINGS
  app.get('/api/settings', (req, res) => {
    res.json({ systemSettings, merchantWallets });
  });

  app.put('/api/settings', (req, res) => {
    const { settings, wallets } = req.body;
    if (settings) systemSettings = { ...systemSettings, ...settings };
    if (wallets) merchantWallets = { ...merchantWallets, ...wallets };
    logAction('Settings Updated', 'Modified store system configurations and crypto nodes address layout.');
    res.json({ success: true, systemSettings, merchantWallets });
  });

  // 5. AUDIT LOGS
  app.get('/api/logs', (req, res) => {
    res.json(logs);
  });

  // 6. MEDIA LIBRARY
  app.get('/api/media', (req, res) => {
    res.json(mediaLibrary);
  });

  app.post('/api/media/upload', (req, res) => {
    const { name, size, type, url } = req.body;
    const newItem: MediaItem = {
      id: `med-${Date.now()}`,
      name: name || 'uploaded_image.jpg',
      originalName: name || 'uploaded_image.jpg',
      url: url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop',
      webpUrl: url || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop',
      size: size || '180 KB',
      type: type || 'image/jpeg',
      optimized: true,
      createdAt: new Date().toISOString()
    };
    mediaLibrary.unshift(newItem);
    logAction('Media Uploaded', `Uploaded and optimized WebP image "${newItem.name}"`);
    res.status(201).json(newItem);
  });

  // 7. COUPONS
  app.get('/api/coupons', (req, res) => {
    res.json(coupons);
  });

  app.post('/api/coupons', (req, res) => {
    const newC: Coupon = {
      code: req.body.code.toUpperCase(),
      discountType: req.body.discountType || 'Percentage',
      value: Number(req.body.value) || 10,
      active: true
    };
    coupons.push(newC);
    logAction('Coupon Created', `Created promo discount code: ${newC.code}`);
    res.status(201).json(newC);
  });

  // 8. BACKUPS EXPORTS
  app.get('/api/system/export', (req, res) => {
    res.json({
      timestamp: new Date().toISOString(),
      productsCount: products.length,
      ordersCount: orders.length,
      couponsCount: coupons.length,
      settings: systemSettings,
      wallets: merchantWallets,
      data: {
        products,
        orders,
        messages,
        logs,
        coupons
      }
    });
  });

  // ANALYTICS CALCULATION ENGINE
  app.get('/api/analytics', (req, res) => {
    // calculate actual figures
    const totalRevenue = orders
      .filter(o => o.status === 'Paid' || o.status === 'Packing' || o.status === 'Shipped' || o.status === 'Delivered')
      .reduce((sum, o) => sum + o.total, 0);

    const pendingOrdersCount = orders.filter(o => o.status === 'Pending' || o.status === 'Awaiting Payment').length;
    const paidOrdersCount = orders.filter(o => o.status === 'Paid' || o.status === 'Packing' || o.status === 'Shipped' || o.status === 'Delivered').length;

    // payment methods
    const btcOrders = orders.filter(o => o.payment.currency === 'BTC').length;
    const usdtOrders = orders.filter(o => o.payment.currency === 'USDT').length;

    res.json({
      totalRevenue,
      salesCount: paidOrdersCount,
      pendingCount: pendingOrdersCount,
      visitorCount: 1482 + orders.length * 15,
      conversionRate: ((paidOrdersCount / (1482 + orders.length * 15)) * 100).toFixed(2),
      averageOrderValue: paidOrdersCount > 0 ? (totalRevenue / paidOrdersCount).toFixed(2) : '0.00',
      paymentStats: {
        BTC: btcOrders,
        USDT: usdtOrders
      },
      recentTraffic: [
        { source: 'Direct/Search Node', value: 45 },
        { source: 'GitHub Repositories', value: 25 },
        { source: 'Crypto Forums', value: 18 },
        { source: 'Engineering Blogs', value: 12 }
      ],
      monthlySales: [
        { month: 'Feb', sales: totalRevenue * 0.4 },
        { month: 'Mar', sales: totalRevenue * 0.6 },
        { month: 'Apr', sales: totalRevenue * 0.75 },
        { month: 'May', sales: totalRevenue * 0.9 },
        { month: 'Jun', sales: totalRevenue * 0.95 },
        { month: 'Jul', sales: totalRevenue }
      ]
    });
  });


  // --- VITE DEV OR PROD COMPILATION HANDLER ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Rocketman Core Server] initialized on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('[Rocketman Startup Error]:', err);
});
