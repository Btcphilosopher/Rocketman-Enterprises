import { Botanical, GinExpression, Cocktail, JournalArticle } from './types';

export const GIN_EXPRESSIONS: GinExpression[] = [
  {
    id: 'london-dry',
    number: '01',
    name: 'LONDON DRY',
    tagline: 'CLASSIC / CRISP / TIMELESS',
    concept: 'The architectural benchmark of British distillation. Pure geometric precision and laser-sharp clarity.',
    abv: '41.2% vol',
    volume: '70cl e',
    price: 48,
    colorName: 'Clear Glass / Ice Blue',
    hexColor: '#38bdf8',
    glassStyle: 'Ultra-clear flint glass with silver bevels',
    capFinish: 'Machined brushed aluminium with midnight naval lacquer',
    labelArtwork: 'London skyline and modern bridge suspension cables',
    botanicals: ['Juniper', 'Coriander', 'Angelica', 'Lemon Peel'],
    tastingNotes: {
      nose: 'Bright Macedonian and British wild juniper, crystalline lemon oils, and crushed coriander seeds with pine freshness.',
      palate: 'Dry, structured, exceptionally linear and clean. Angelica root provides deep grounding architecture beneath bright citrus oils.',
      finish: 'Long, mineral, and lightly citrus-led with a crisp, diamond-cut dry finish.'
    },
    tastingRadar: {
      juniper: 95,
      citrus: 80,
      floral: 45,
      herbal: 65,
      spice: 55,
      mineral: 90
    },
    technicalSpecs: {
      stillType: 'Copper Column Still 04 with Cold Vacuum Reflux',
      columnCut: 'Heart cut narrow 78.4°C – 80.1°C',
      vacuumPressure: '0.12 bar low-temperature distillation',
      extractionTemp: '42.4°C Botanical vapor infusion',
      waterSource: 'Deep Sussex chalk aquifer demineralised spring water',
      filtration: 'Sub-micron cross-flow ceramic filtration',
      batchSize: 'Limited 1,200 bottles per precision run'
    },
    perfectServe: 'Northbridge & Tonic with hand-cut lemon twist and bruised juniper berries'
  },
  {
    id: 'wild-coast',
    number: '02',
    name: 'WILD COAST',
    tagline: 'SEAWEED / CITRUS / SALT',
    concept: 'British coastline meets modern distillation. Sourced from the Atlantic intertidal surge of Cornwall and the Hebrides.',
    abv: '41.2% vol',
    volume: '70cl e',
    price: 54,
    colorName: 'Deep Sea Teal',
    hexColor: '#0d9488',
    glassStyle: 'Deep ocean teal fluted architectural bottle',
    capFinish: 'Brushed brass with laser-engraved coordinate collar',
    labelArtwork: 'Cornish coastal cliffs and breaking Atlantic surge waves',
    botanicals: ['Seaweed', 'Lemon', 'Coriander', 'Samphire'],
    tastingNotes: {
      nose: 'Fresh saline sea spray, ozonic coastal breezes, mineral green samphire, and vibrant lemon zest.',
      palate: 'Crisp maritime salinity balanced by oily citrus and savory bladderwrack kelp richness with underlying juniper backbone.',
      finish: 'Persistent brine, subtle coastal umami, and an invigorating cold citrus snap.'
    },
    tastingRadar: {
      juniper: 70,
      citrus: 85,
      floral: 30,
      herbal: 88,
      spice: 40,
      mineral: 98
    },
    technicalSpecs: {
      stillType: 'Hybrid Copper Pot & Packed Vacuum Column',
      columnCut: 'Dual-phase botanical extraction',
      vacuumPressure: '0.10 bar maritime vacuum',
      extractionTemp: '38.0°C cold-bath kelp infusion',
      waterSource: 'Highland granite filtered coastal aquifer',
      filtration: 'Activated diatomaceous earth cold filtration',
      batchSize: '850 individually numbered bottles'
    },
    perfectServe: 'Wild Coast Highball with artisanal soda, sea samphire sprig, and pink grapefruit ribbon'
  },
  {
    id: 'heath-blossom',
    number: '03',
    name: 'HEATH & BLOSSOM',
    tagline: 'FLORAL / HONEY / HAWTHORN',
    concept: 'British heathland in late spring. Delicate wild flora captured at morning dew point across the Yorkshire moors.',
    abv: '41.2% vol',
    volume: '70cl e',
    price: 56,
    colorName: 'Restrained Rose & Heather Pink',
    hexColor: '#f43f5e',
    glassStyle: 'Subtle blush rose optical flint glass',
    capFinish: 'Pure warm rose copper with milled micro-knurling',
    labelArtwork: 'Rolling moorland contours and wild blooming heather hills',
    botanicals: ['Hawthorn', 'Heather', 'Honey', 'Rose Petal'],
    tastingNotes: {
      nose: 'Subtle hedgerow hawthorn blossoms, wild heather honey nectar, delicate English rose petal, and sweet citrus rind.',
      palate: 'Silky, aromatic, and round. Honeyed floral warmth harmonises with botanical dry pine without synthetic sweetness.',
      finish: 'Ethereal, floral-dry, and deeply fragrant with lingering elderflower and wild rose.'
    },
    tastingRadar: {
      juniper: 65,
      citrus: 60,
      floral: 96,
      herbal: 75,
      spice: 45,
      mineral: 60
    },
    technicalSpecs: {
      stillType: 'Gentle Hydro-Sonic Vapor Chamber',
      columnCut: 'Low-shear floral vapor stream',
      vacuumPressure: '0.08 bar ultra-low thermal impact',
      extractionTemp: '34.5°C cryogenic flower extraction',
      waterSource: 'Pennine moorland peat-purified soft spring water',
      filtration: 'Gentle gravity cellulose pad filtration',
      batchSize: '950 seasonal micro-distillation bottles'
    },
    perfectServe: 'Blossom French 75 with English sparkling wine and a single fresh rose petal'
  },
  {
    id: 'midnight',
    number: '04',
    name: 'MIDNIGHT',
    tagline: 'BLACKBERRY / OAK / SPICE',
    concept: 'British ancient woodland after dark. Deep forest canopy, damp oak moss, wild berries, and nocturnal warmth.',
    abv: '41.2% vol',
    volume: '70cl e',
    price: 58,
    colorName: 'Midnight Navy & Violet Black',
    hexColor: '#6366f1',
    glassStyle: 'Heavy obsidian violet-navy tinted architectural glass',
    capFinish: 'Diamond-like carbon (DLC) matte black anodised cap',
    labelArtwork: 'Moonlit forest canopy, silent pines and starlit ridges',
    botanicals: ['Blackberry', 'Oak', 'Vanilla', 'Winter Spice'],
    tastingNotes: {
      nose: 'Macerated wild hedgerow blackberries, toasted English oak shavings, cracked black pepper, and warm vanilla bean.',
      palate: 'Dark, velvety, and complex. Tannic oak structure frames rich dark fruit, dark chocolate undertones, and gentle winter warmth.',
      finish: 'Deep, warming, and resonant with drying oak tannins and sweet spiced berry lingering long after.'
    },
    tastingRadar: {
      juniper: 75,
      citrus: 40,
      floral: 35,
      herbal: 80,
      spice: 92,
      mineral: 70
    },
    technicalSpecs: {
      stillType: 'Traditional Direct-Fired Copper Alembic Pot Still',
      columnCut: 'Extended tail separation for deep phenolic fractions',
      vacuumPressure: 'Atmospheric distillation with charred oak rest',
      extractionTemp: '84.0°C botanical maceration',
      waterSource: 'Ancient Sherwood Forest sandstone boreholes',
      filtration: 'Double charcoal chill-proofed filtration',
      batchSize: '800 collector edition bottles'
    },
    perfectServe: 'Midnight Negroni with English bitter aperitif, sweet red vermouth, and expressed orange oil'
  },
  {
    id: 'citrus-copper',
    number: '05',
    name: 'CITRUS & COPPER',
    tagline: 'ORANGE / LEMON / COPPER',
    concept: 'British industrial engineering meets citrus luminescence. Modernist bridges, warm sunset reflections, and bright botanical electricity.',
    abv: '41.2% vol',
    volume: '70cl e',
    price: 56,
    colorName: 'Amber Champagne & Bright Copper',
    hexColor: '#f59e0b',
    glassStyle: 'Champagne-tinted prismatic glass with copper foil base',
    capFinish: 'High-polish mirror electrolytic copper',
    labelArtwork: 'Geometric architectural suspension bridge arches in golden light',
    botanicals: ['Orange', 'Lemon', 'Juniper', 'Copper Bitters'],
    tastingNotes: {
      nose: 'Intense Seville bitter orange oils, Meyer lemon brightness, aromatic bergamot, and metallic mineral freshness.',
      palate: 'Vibrant, electrifying citrus explosion anchored by peppery Macedonian juniper and warm copper-still warmth.',
      finish: 'Brilliant, zesty, and bittersweet. Mouth-watering Seville orange marmalade note with clean dry snap.'
    },
    tastingRadar: {
      juniper: 78,
      citrus: 98,
      floral: 40,
      herbal: 60,
      spice: 68,
      mineral: 85
    },
    technicalSpecs: {
      stillType: 'Bespoke Quad-Column Micro-Perforated Copper Still',
      columnCut: 'Triple-rectified citrus fraction heart',
      vacuumPressure: '0.15 bar high-reflux vacuum cycle',
      extractionTemp: '46.0°C fresh peel vapor column',
      waterSource: 'Lake District fell mountain stream mineral water',
      filtration: 'Polishing paper plate cold filtration',
      batchSize: '1,100 numbered expressions'
    },
    perfectServe: 'Citrus Martini with bone-dry British vermouth and atomised copper bitters'
  }
];

export const BOTANICALS: Botanical[] = [
  {
    id: 'juniper',
    name: 'Juniper',
    scientificName: 'Juniperus communis',
    origin: 'Cairngorms National Park, Scotland & North Downs',
    coordinates: '57.067° N, 3.733° W',
    extractionMethod: 'Cryo-crushed vapor infusion at 42°C',
    temperature: '42.4°C',
    profile: 'Crisp pine needles, resinous woodland, vibrant dry backbone',
    description: 'Harvested by hand from wild British juniper scrublands. We cold-crush the berries immediately prior to distillation to protect the delicate monoterpenes from atmospheric oxidation.',
    expressionsUsed: ['London Dry', 'Wild Coast', 'Heath & Blossom', 'Midnight', 'Citrus & Copper']
  },
  {
    id: 'samphire',
    name: 'Marsh Samphire',
    scientificName: 'Salicornia europaea',
    origin: 'Norfolk Tidal Marshes & Romney Marsh',
    coordinates: '52.965° N, 0.852° E',
    extractionMethod: 'Cold hydro-sonic vacuum extraction',
    temperature: '36.0°C',
    profile: 'Saline crispness, mineral sea air, vibrant green succulent snap',
    description: 'Hand-cut along the brackish tidal estuaries of North Norfolk during the spring tides. Brings pure Atlantic salinity and structured maritime freshness.',
    expressionsUsed: ['Wild Coast']
  },
  {
    id: 'seaweed',
    name: 'Bladderwrack Seaweed',
    scientificName: 'Fucus vesiculosus',
    origin: 'Hebridean Coast & Mounts Bay, Cornwall',
    coordinates: '50.119° N, 5.538° W',
    extractionMethod: 'Flash-dried botanical maceration',
    temperature: '40.0°C',
    profile: 'Deep maritime umami, ocean spray, subtle iodine richness',
    description: 'Sustainably harvested from wild rocky shores where the Atlantic surge oxygenates the kelp beds. Imparts a luxurious textural salinity and depth.',
    expressionsUsed: ['Wild Coast']
  },
  {
    id: 'heather',
    name: 'Purple Heather',
    scientificName: 'Calluna vulgaris',
    origin: 'North York Moors & Speyside Highlands',
    coordinates: '54.383° N, 0.908° W',
    extractionMethod: 'Vapor-phase basket suspension',
    temperature: '34.5°C',
    profile: 'Dry floral honey, wild moorland blossom, sweet earthy herbal',
    description: 'Gathered during late August when the Yorkshire moors turn into an ocean of violet blooms. Captures the intoxicating floral aromatics of Britain in summer.',
    expressionsUsed: ['Heath & Blossom']
  },
  {
    id: 'hawthorn',
    name: 'Common Hawthorn',
    scientificName: 'Crataegus monogyna',
    origin: 'Cotswolds Ancient Hedgerows',
    coordinates: '51.833° N, 1.833° W',
    extractionMethod: 'Sub-zero cryo-maceration',
    temperature: '32.0°C',
    profile: 'Almond blossom, crisp green apple note, delicate wood sap',
    description: 'Sourced from century-old hedgerows dividing British pastoral fields. Adds an elegant, silky almond-blossom top note that lingers on the palate.',
    expressionsUsed: ['Heath & Blossom']
  },
  {
    id: 'blackberries',
    name: 'Wild Hedgerow Blackberry',
    scientificName: 'Rubus fruticosus',
    origin: 'Sussex Weald Ancient Woodland',
    coordinates: '51.018° N, 0.174° E',
    extractionMethod: 'Extended dark spirit botanical rest',
    temperature: '24.0°C',
    profile: 'Rich bramble fruit, sweet-tart tannin, forest floor depth',
    description: 'Foraged after the first autumn frost when sugars concentrate. Infuses a dark, luxurious berry core without cloying syrupiness.',
    expressionsUsed: ['Midnight']
  },
  {
    id: 'oak',
    name: 'English Pedunculate Oak',
    scientificName: 'Quercus robur',
    origin: 'Forest of Dean, Gloucestershire',
    coordinates: '51.789° N, 2.548° W',
    extractionMethod: 'Light toasted stave extraction',
    temperature: '65.0°C',
    profile: 'Structured wood tannin, sweet vanillin, delicate smoke',
    description: 'Crafted using sustainably thinned British native oak staves lightly toasted over beech fires. Adds architectural structure and a warm, velvety finish.',
    expressionsUsed: ['Midnight']
  },
  {
    id: 'coriander',
    name: 'British Seed Coriander',
    scientificName: 'Coriandrum sativum',
    origin: 'Suffolk Agricultural Fens',
    coordinates: '52.196° N, 1.012° E',
    extractionMethod: 'Roller-crushed basket infusion',
    temperature: '44.0°C',
    profile: 'Cracked citrus spice, spicy linalool, warm peppery brightness',
    description: 'Grown on the sunny silt soils of East Anglia. Rich in essential linalool oils that marry the sharpness of citrus with the resin of juniper.',
    expressionsUsed: ['London Dry', 'Wild Coast']
  },
  {
    id: 'lemon',
    name: 'Fresh English Lemon Peel',
    scientificName: 'Citrus limon',
    origin: 'Kentish Solar Glasshouses',
    coordinates: '51.278° N, 0.521° E',
    extractionMethod: 'Cold manual zesting & direct vapor column',
    temperature: '41.0°C',
    profile: 'Diamond-bright lemon zest, crystalline acidity, clean zest oils',
    description: 'Zested fresh within hours of distillation to preserve the volatile limonene oils, delivering a vibrant snap of British-grown citrus.',
    expressionsUsed: ['London Dry', 'Wild Coast', 'Citrus & Copper']
  },
  {
    id: 'orange',
    name: 'Bitter Seville Orange Peel',
    scientificName: 'Citrus aurantium',
    origin: 'Heritage Winter Conserve Orchards',
    coordinates: '50.822° N, 0.137° W',
    extractionMethod: 'Dual copper column vapor charge',
    temperature: '46.0°C',
    profile: 'Aromatic marmalade peel, bittersweet oils, electric citrus spark',
    description: 'Sun-ripened thick rinds cured with British copper botanical bitters to create an unforgettable golden luminescence.',
    expressionsUsed: ['Citrus & Copper']
  }
];

export const SIGNATURE_COCKTAILS: Cocktail[] = [
  {
    id: 'northbridge-tonic',
    name: 'NORTHBRIDGE & TONIC',
    ginExpression: 'London Dry',
    glassware: 'Bespoke Crystal Stemmed Copa',
    iceType: 'Single 50mm hand-carved directional ice cube',
    garnish: 'Expressed yellow lemon twist and bruised juniper berries',
    flavorProfile: 'Crisp, crystalline, mineral, perfectly dry',
    description: 'The definitive architectural serve. Designed to showcase the laser precision and pure botanical balance of our London Dry.',
    ingredients: [
      { amount: '50ml', item: 'Northbridge London Dry Gin' },
      { amount: '150ml', item: 'Chilled Premium British Indian Tonic Water' },
      { amount: '1 strip', item: 'Hand-cut Kentish Lemon peel' },
      { amount: '3 drops', item: 'Saline botanical mist' }
    ],
    steps: [
      'Pre-chill an architectural crystal copa glass to -18°C.',
      'Place a single block of clear hand-carved ice into the vessel.',
      'Pour 50ml of Northbridge London Dry directly over the crystalline ice.',
      'Gently charge with 150ml chilled Indian tonic water along a twisted barspoon.',
      'Express lemon peel oils over the surface and drop into the drink with three cracked juniper berries.'
    ]
  },
  {
    id: 'wild-coast-highball',
    name: 'WILD COAST HIGHBALL',
    ginExpression: 'Wild Coast',
    glassware: 'Fluted Heavy-Base Crystal Highball',
    iceType: 'Spear ice column frozen at -12°C',
    garnish: 'Fresh sea samphire sprig and pink grapefruit ribbon',
    flavorProfile: 'Invigorating, maritime, salty-citrus, refreshing',
    description: 'A vibrant tribute to the untamed British coastline. Effervescent, briny, and electrifyingly fresh.',
    ingredients: [
      { amount: '50ml', item: 'Northbridge Wild Coast Gin' },
      { amount: '120ml', item: 'Highland Carbonated Spring Soda' },
      { amount: '10ml', item: 'Freshly pressed pink grapefruit juice' },
      { amount: '1 sprig', item: 'Norfolk coastal samphire' }
    ],
    steps: [
      'Fill a tall fluted highball glass with a clear ice spear.',
      'Add Northbridge Wild Coast Gin and grapefruit juice.',
      'Top slowly with effervescent carbonated spring soda to preserve carbonation.',
      'Gently lift with barspoon once from bottom to integrate.',
      'Garnish with a fresh sprig of tidal samphire and a fine ribbon of grapefruit.'
    ]
  },
  {
    id: 'midnight-negroni',
    name: 'MIDNIGHT NEGRONI',
    ginExpression: 'Midnight',
    glassware: 'Facet-Cut Heavy Obsidian Rocks Glass',
    iceType: 'Single 60mm stamped crystal sphere',
    garnish: 'Smoked orange peel and scorched rosemary needle',
    flavorProfile: 'Complex, bitter-sweet, dark berry, toasted oak',
    description: 'An Anglo-futurist reimagining of the classic Negroni. Dark British hedgerow blackberries and English oak tannins bring nocturnal depth.',
    ingredients: [
      { amount: '35ml', item: 'Northbridge Midnight Gin' },
      { amount: '25ml', item: 'Artisanal English Red Vermouth' },
      { amount: '25ml', item: 'British Walnut & Rhubarb Bitter Aperitif' },
      { amount: '2 dashes', item: 'Blackberry & Cacao bitters' }
    ],
    steps: [
      'Combine all spirits in a heavy laboratory mixing beaker with cracked ice.',
      'Stir smoothly for 35 revolutions until velvety cold and properly diluted.',
      'Strain over a stamped crystal sphere in a faceted rocks glass.',
      'Flame an orange peel over the glass and place gently upon the ice.'
    ]
  },
  {
    id: 'citrus-martini',
    name: 'CITRUS & COPPER MARTINI',
    ginExpression: 'Citrus & Copper',
    glassware: 'Angular Modernist Nick & Nora Glass',
    iceType: 'Cryo-stirred at -8°C (no ice in glass)',
    garnish: 'Atomised copper citrus bitters and expressed Seville orange oil',
    flavorProfile: 'Bright, electrifying, bone-dry, aromatic citrus',
    description: 'Engineering excellence captured in crystal. Clean, crisp, and charged with Seville citrus brilliance.',
    ingredients: [
      { amount: '60ml', item: 'Northbridge Citrus & Copper Gin' },
      { amount: '10ml', item: 'Bone-Dry British Vermouth' },
      { amount: '1 spray', item: 'Copper botanical citrus mist' },
      { amount: '1 twist', item: 'Seville orange peel disk' }
    ],
    steps: [
      'Pre-chill the Nick & Nora glass in a cryogenic freezer.',
      'Stir Northbridge Citrus & Copper Gin and dry vermouth in an insulated copper mixing vessel with cubed ice for 40 seconds.',
      'Double strain into the chilled glass.',
      'Express orange oils across the surface and mist with copper bitters.'
    ]
  }
];

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'new-british-distillery',
    title: 'The New British Distillery: Architecture, Automation and Alchemy',
    subtitle: 'Inside the carbon-neutral Northbridge flagship facility on the banks of the Thames.',
    category: 'Architecture & Engineering',
    readTime: '6 min read',
    date: '14 September 2031',
    author: 'Alistair Vance, Design & Technology Editor',
    excerpt: 'How modern British industrial architecture, Industry 4.0 robotic precision, and sustainable closed-loop thermodynamic distillation are setting a new world standard for spirits.',
    content: [
      'Standing at the threshold of the Northbridge distillery on the south bank of the Thames, the first sensation is not of heat or steam, but of cathedral-like silence. The blackened British engineering brick and floor-to-ceiling ultra-clear glass form an austere, modernist envelope around our four towering copper column stills.',
      'Where 19th-century distillation relied on roaring fires and manual hydrometers, Northbridge represents the 2030s realization of spirit production: low-temperature thermal vacuum circuits, automated density sensors measuring fractions every 200 milliseconds, and bespoke robotic bottling arms that serialize every bottle with laser accuracy.',
      '“We did not want a pastiche of Victorian industrial nostalgia,” explains Lead Engineer Dr. Clara Sterling. “Britain has always been at its best when marrying deep metallurgical craftsmanship with pioneering science. Northbridge is engineered like an aerospace laboratory, but driven by the sensory poetry of British botanical heritage.”'
    ]
  },
  {
    id: 'why-juniper-matters',
    title: 'Why Juniper Still Matters: The Biochemistry of Wild British Berries',
    subtitle: 'Mapping pinene, myrcene, and sabinene across ancient Scottish scrublands.',
    category: 'Botanical Science',
    readTime: '5 min read',
    date: '28 August 2031',
    author: 'Dr. Helen Rowe, Botanical Chemist',
    excerpt: 'In an era of endless flavored spirits, we investigate why wild Juniperus communis remains the uncompromising structural backbone of true British gin.',
    content: [
      'The modern spirits landscape is crowded with ephemeral novelty. Yet when you strip away the trends, gin lives or dies by a single botanical: Juniperus communis. It provides the architectural keystone without which the arch collapses.',
      'At Northbridge, our research team spent three years gas-chromatographing wild juniper populations across the Cairngorms and the North Downs. What we discovered was a microclimate-dependent terpene profile: high alpine frost yields pinene molecules that impart sharp, crystalline freshness, while southern chalk downs produce warm, balsamic myrcene.',
      'By vacuum-extracting these berries at precisely 42.4°C, we capture the pure, unbroken essential oils without the harsh cooked tannins of conventional boiling pots.'
    ]
  },
  {
    id: 'architecture-of-the-bottle',
    title: 'The Architecture of the Perfect Gin Bottle',
    subtitle: 'From industrial geometry to tactile weight: designing our bespoke 2030s vessel.',
    category: 'Industrial Design',
    readTime: '4 min read',
    date: '10 August 2031',
    author: 'Marcus Thorne, Head of Design',
    excerpt: 'The story behind the heavy octagonal flint glass, diamond-beveled shoulders, and machined metal cap of Northbridge Gin.',
    content: [
      'A luxury spirit bottle should feel substantial, permanent, and architectural. When designing the Northbridge vessel, we drew inspiration from the cantilevered bridges of the Thames and the geometric precision of British modernist towers.',
      'Every bottle is cast with extra-thick base flint glass, providing low center of gravity and crystal-grade optical brilliance. The cap is milled from solid aircraft-grade brushed aluminium, knurled to 0.5mm precision for an immaculate tactile feedback upon opening.',
      'The tactile sensation of unsealing a bottle is the first chapter of the tasting experience.'
    ]
  },
  {
    id: 'coastal-botanicals',
    title: "Britain's Coastal Botanicals: Foraging the Cornish Intertidal Zone",
    subtitle: 'Exploring the saline biology of samphire, kelp, and sea campion along the Atlantic shelf.',
    category: 'Field Expedition',
    readTime: '7 min read',
    date: '22 July 2031',
    author: 'Fiona MacLeod, Master Forager',
    excerpt: 'How we sustainably collect intertidal flora at low tide in Cornwall to create the mineral, maritime character of Wild Coast.',
    content: [
      'At dawn on the Lizard Peninsula, the tide retreats three hundred meters, exposing a glistening world of succulent seaweeds and marsh samphire. Here, where Atlantic swells crash against ancient serpentine rock, nature creates an intensely saline, mineral terroir.',
      'Samphire holds moisture by accumulating natural sea salts and iodine. Distilled under cold vacuum, these maritime compounds do not taste briny or heavy; they taste like a burst of Atlantic sea breeze caught on a bright summer morning.',
      'Wild Coast is Britain’s rugged coastline distilled into a glass.'
    ]
  },
  {
    id: 'london-after-dark',
    title: 'London After Dark: The Twilight Skyline of Thameside Distillation',
    subtitle: 'How the energy of a 2030s metropolis informs the spirit of our flagship London Dry.',
    category: 'Culture & Metropolis',
    readTime: '5 min read',
    date: '04 July 2031',
    author: 'Edward Sterling, Founder',
    excerpt: 'The Thames has carried trade, ideas, and botanicals into Britain for a thousand years. Today, London remains the beating heart of global spirit innovation.',
    content: [
      'As twilight settles over the Thames, the towers of the City, Westminster, and the South Bank illuminate like luminous crystal pillars. Watching the reflection of the bridges shimmer on the dark water is the aesthetic genesis of Northbridge.',
      'London is not a museum piece. It is a dynamic, forward-looking global capital where heritage stone sits shoulder-to-shoulder with cutting-edge engineering. That duality—past and future in perfect harmony—is the soul of Northbridge Gin.'
    ]
  },
  {
    id: 'engineering-better-spirit',
    title: 'Engineering a Better Spirit: Low-Temperature Vacuum Refinement',
    subtitle: 'Demystifying the physics of thermodynamic distillation at 0.12 bar.',
    category: 'Technical Innovation',
    readTime: '6 min read',
    date: '18 June 2031',
    author: 'Dr. Clara Sterling, Master Distiller',
    excerpt: 'Why boiling botanicals at 100°C destroys delicate floral aromatics, and how aerospace vacuum technology solves the problem.',
    content: [
      'In conventional distillation, botanicals are boiled inside copper pots at temperatures nearing 100°C. For heavy roots like angelica or orris, heat is beneficial; but for delicate rose petals, sea samphire, or citrus blossom, high heat cooks and degrades the essential monoterpenes.',
      'By dropping the atmospheric pressure within our stills to 0.12 bar, ethanol and aromatic vaporise at just 42.4°C. The result is botanical preservation that simply cannot be achieved in a traditional Victorian pot still.',
      'Precision engineering doesn’t replace nature. It elevates it.'
    ]
  }
];

export const BRITISH_LANDSCAPES = [
  {
    id: 'london',
    name: 'London Metropolis',
    region: 'Greater London',
    expression: '01 London Dry',
    coordinates: '51.5074° N, 0.1278° W',
    elevation: '11m above sea level',
    description: 'The historic and contemporary epicenter of British spirit culture. The Thames, illuminated suspension bridges, and modernist architectural skylines inspiring our crystalline dry profile.',
    sensoryNotes: ['Diamond-cut clarity', 'River breeze', 'Urban precision', 'Crystalline citrus']
  },
  {
    id: 'cornwall',
    name: 'Cornish Atlantic Shelf',
    region: 'Cornwall & Isles of Scilly',
    expression: '02 Wild Coast',
    coordinates: '50.119° N, 5.538° W',
    elevation: 'Sea level intertidal zone',
    description: 'Rugged granite and serpentine cliffs beaten by the North Atlantic swell. Intertidal flora, marsh samphire, and nutrient-dense kelp beds imparting oceanic salinity.',
    sensoryNotes: ['Crashing sea spray', 'Saline samphire', 'Briny kelp', 'Zesty coastal lemon']
  },
  {
    id: 'yorkshire',
    name: 'North York Moors',
    region: 'Yorkshire & Humber',
    expression: '03 Heath & Blossom',
    coordinates: '54.383° N, 0.908° W',
    elevation: '420m moorland plateau',
    description: 'Vast purple heather moorland blooming under late summer sunsets. Wild hawthorn hedgerows, heather honey, and gentle evening winds.',
    sensoryNotes: ['Wild purple heather', 'Hedgerow hawthorn', 'Heather honey', 'Late sunset warmth']
  },
  {
    id: 'ancient-woodland',
    name: 'Ancient Sherwood & Dean',
    region: 'Midlands & Gloucestershire',
    expression: '04 Midnight',
    coordinates: '51.789° N, 2.548° W',
    elevation: '185m forest canopy',
    description: 'Deep canopy of 500-year-old native British oaks, damp pine needles, wild hedgerow brambles, and starlit midnight clearings.',
    sensoryNotes: ['Toasted English oak', 'Dark bramble blackberry', 'Vanilla bean', 'Forest canopy']
  },
  {
    id: 'highland-fells',
    name: 'Cumbrian Fells & Lake District',
    region: 'Cumbria & Scottish Borders',
    expression: '05 Citrus & Copper',
    coordinates: '54.460° N, 3.088° W',
    elevation: '978m fell peaks',
    description: 'Dramatic architectural valley bridges, pure glacial mountain streams, and glowing copper sunsets over pristine British waterways.',
    sensoryNotes: ['Seville orange oils', 'Sunlit copper warmth', 'Bergamot spice', 'Glacial water snap']
  }
];

export const DISTILLERY_STEPS = [
  {
    step: '01',
    code: 'EXTR-42',
    name: 'Botanical Cryo-Selection & Hydro-Sonic Maceration',
    detail: 'Heritage botanicals are cryogenically stabilized upon harvest. High-frequency sound waves gently dislodge essential aromatic oils without cellular thermal stress.',
    telemetry: 'Sonic Frequency: 28.4 kHz | Temperature: 18.2°C | Oxidation: 0.00 ppm'
  },
  {
    step: '02',
    code: 'VAC-012',
    name: 'Dual-Phase Vapor Infusion & 0.12 Bar Vacuum Reflux',
    detail: 'Our custom four-column copper distillation suite maintains low-pressure atmospheric conditions, allowing low-temperature vaporisation of delicate volatile aromatics.',
    telemetry: 'Column Still: 04 | Head Pressure: 0.124 bar | Still Temp: 42.4°C'
  },
  {
    step: '03',
    code: 'CHALK-AQ',
    name: 'Chalk Aquifer Hydration & Sub-Micron Filtration',
    detail: 'The pure spirit heart is gently brought to 41.2% ABV using naturally mineralised water drawn from a 200-meter deep Sussex chalk aquifer, followed by cross-flow ceramic filtration.',
    telemetry: 'Mineral Balance: 42 TDS | pH: 7.34 | Cross-Flow Porosity: 0.2 µm'
  },
  {
    step: '04',
    code: 'ROBO-LASER',
    name: 'Robotic Architectural Bottling & Laser Serialization',
    detail: 'Every bottle is filled in a sterile positive-pressure cleanroom, sealed with a knurled metal cap, and laser-engraved with individual bottle, batch, and harvest coordinates.',
    telemetry: 'Seal Torque: 2.8 Nm | Nitrogen Purge: 99.98% | Laser Depth: 120 µm'
  }
];
