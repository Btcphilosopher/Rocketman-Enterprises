export interface Botanical {
  id: string;
  name: string;
  scientificName: string;
  origin: string;
  coordinates: string;
  extractionMethod: string;
  temperature: string;
  profile: string;
  description: string;
  expressionsUsed: string[];
}

export interface GinExpression {
  id: string;
  number: string;
  name: string;
  tagline: string;
  concept: string;
  abv: string;
  volume: string;
  price: number;
  colorName: string;
  hexColor: string;
  glassStyle: string;
  capFinish: string;
  labelArtwork: string;
  botanicals: string[];
  tastingNotes: {
    nose: string;
    palate: string;
    finish: string;
  };
  tastingRadar: {
    juniper: number;
    citrus: number;
    floral: number;
    herbal: number;
    spice: number;
    mineral: number;
  };
  technicalSpecs: {
    stillType: string;
    columnCut: string;
    vacuumPressure: string;
    extractionTemp: string;
    waterSource: string;
    filtration: string;
    batchSize: string;
  };
  perfectServe: string;
}

export interface Cocktail {
  id: string;
  name: string;
  ginExpression: string;
  glassware: string;
  iceType: string;
  garnish: string;
  flavorProfile: string;
  description: string;
  ingredients: { amount: string; item: string }[];
  steps: string[];
}

export interface JournalArticle {
  id: string;
  title: string;
  subtitle: string;
  category: string;
  readTime: string;
  date: string;
  author: string;
  excerpt: string;
  content: string[];
}

export interface CartItem {
  id: string;
  expressionId?: string;
  name: string;
  price: number;
  quantity: number;
  volume: string;
  isGiftBox?: boolean;
}
