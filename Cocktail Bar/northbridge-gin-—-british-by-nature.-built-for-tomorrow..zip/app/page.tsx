'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import BrandBar from '@/components/BrandBar';
import CollectionSection from '@/components/CollectionSection';
import InteractiveBottleMorph from '@/components/InteractiveBottleMorph';
import BotanicalsGallery from '@/components/BotanicalsGallery';
import DistillerySection from '@/components/DistillerySection';
import LandscapeSection from '@/components/LandscapeSection';
import CocktailSection from '@/components/CocktailSection';
import JournalSection from '@/components/JournalSection';
import ShopSection from '@/components/ShopSection';
import Footer from '@/components/Footer';
import CartDrawer from '@/components/CartDrawer';
import BottleDetailModal from '@/components/BottleDetailModal';
import AgeVerificationModal from '@/components/AgeVerificationModal';
import { GIN_EXPRESSIONS } from '@/lib/data';
import { CartItem, GinExpression } from '@/lib/types';

export default function HomePage() {
  const [selectedBottleId, setSelectedBottleId] = useState<string | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const stored = localStorage.getItem('northbridge_cart');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Save cart to localStorage
  const saveCart = (items: CartItem[]) => {
    setCartItems(items);
    try {
      localStorage.setItem('northbridge_cart', JSON.stringify(items));
    } catch {}
  };

  const handleAddToCart = (expression: GinExpression, isGiftBox = false) => {
    const itemId = `${expression.id}${isGiftBox ? '-gift' : ''}`;
    const existing = cartItems.find((i) => i.id === itemId);

    let updated: CartItem[];
    if (existing) {
      updated = cartItems.map((i) =>
        i.id === itemId ? { ...i, quantity: i.quantity + 1 } : i
      );
    } else {
      updated = [
        ...cartItems,
        {
          id: itemId,
          expressionId: expression.id,
          name: isGiftBox ? `${expression.name} (Gift Presentation)` : expression.name,
          price: expression.price,
          quantity: 1,
          volume: expression.volume,
          isGiftBox
        }
      ];
    }
    saveCart(updated);
    setCartOpen(true);
  };

  const handleAddCompleteCollection = () => {
    const itemId = 'complete-collection';
    const existing = cartItems.find((i) => i.id === itemId);

    let updated: CartItem[];
    if (existing) {
      updated = cartItems.map((i) =>
        i.id === itemId ? { ...i, quantity: i.quantity + 1 } : i
      );
    } else {
      updated = [
        ...cartItems,
        {
          id: itemId,
          name: 'The Complete Collection (5x 70cl In Oak Plinth)',
          price: 245,
          quantity: 1,
          volume: '5 × 70cl'
        }
      ];
    }
    saveCart(updated);
    setCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    const updated = cartItems
      .map((item) => {
        if (item.id === id) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      })
      .filter(Boolean) as CartItem[];

    saveCart(updated);
  };

  const handleRemoveItem = (id: string) => {
    const updated = cartItems.filter((i) => i.id !== id);
    saveCart(updated);
  };

  const handleClearCart = () => {
    saveCart([]);
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const selectedExpression = selectedBottleId
    ? GIN_EXPRESSIONS.find((g) => g.id === selectedBottleId) || null
    : null;

  return (
    <div className="min-h-screen bg-[#040811] text-slate-100 flex flex-col font-sans selection:bg-[#d4af37]/30 selection:text-white">
      {/* Age Verification Compliance Modal */}
      <AgeVerificationModal />

      {/* Fixed Luxury Minimalist Header */}
      <Header
        cartCount={totalCartCount}
        onOpenCart={() => setCartOpen(true)}
      />

      {/* Main Flagship Experiences */}
      <main className="flex-1">
        {/* 1. Cinematic Hero Section */}
        <Hero
          onSelectBottle={(id) => setSelectedBottleId(id)}
          onExploreCollection={() => {
            const el = document.getElementById('collection');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* Brand Philosophy Architectural Bar */}
        <BrandBar />

        {/* 2. Collection Section (5 Horizontal Expressions) */}
        <CollectionSection
          onSelectBottle={(id) => setSelectedBottleId(id)}
          onAddToCart={(exp) => handleAddToCart(exp)}
        />

        {/* 3. Interactive Pinned Expression Morpher (Art-directed Sequence) */}
        <InteractiveBottleMorph
          onSelectBottle={(id) => setSelectedBottleId(id)}
        />

        {/* 4. Heritage Botanicals Natural History Specimen Section */}
        <BotanicalsGallery />

        {/* 5. Modern British Thameside Distillery & Process */}
        <DistillerySection />

        {/* 6. A Spirit of a New Britain - Landscape & Terroir Map */}
        <LandscapeSection />

        {/* 7. The Northbridge Serve - Modernist Cocktail Bar Rituals */}
        <CocktailSection />

        {/* 8. Editorial Journal Magazine */}
        <JournalSection />

        {/* 9. Flagship E-Commerce Shop & Complete Suite */}
        <ShopSection
          onAddToCart={handleAddToCart}
          onAddCompleteCollection={handleAddCompleteCollection}
          onSelectBottle={(id) => setSelectedBottleId(id)}
        />
      </main>

      {/* 10. Footer with Minimalist Union Jack Geometry & Legal Notices */}
      <Footer />

      {/* Full-Screen 3D Interactive Bottle Detail Modal */}
      <BottleDetailModal
        expression={selectedExpression}
        onClose={() => setSelectedBottleId(null)}
        onAddToCart={(exp) => handleAddToCart(exp)}
      />

      {/* Slide-in E-Commerce Shopping Bag Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />
    </div>
  );
}
