import type { Metadata } from 'next';
import { Cormorant_Garamond, Inter } from 'next/font/google';
import './globals.css';

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-serif',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Northbridge Gin — British by Nature. Built for Tomorrow.',
  description: 'The digital flagship of Northbridge Gin, a 2030s British luxury spirits brand featuring five architectural expressions crafted with heritage botanicals and modern distillation.',
  openGraph: {
    title: 'Northbridge Gin — British by Nature. Built for Tomorrow.',
    description: 'The digital flagship of Northbridge Gin, a 2030s British luxury spirits brand featuring five architectural expressions crafted with heritage botanicals and modern distillation.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Northbridge Gin — British by Nature. Built for Tomorrow.',
    description: 'The digital flagship of Northbridge Gin, a 2030s British luxury spirits brand featuring five architectural expressions crafted with heritage botanicals and modern distillation.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${cormorant.variable} ${inter.variable} scroll-smooth dark`}>
      <body
        className="bg-[#040811] text-slate-100 font-sans antialiased selection:bg-[#d4af37]/30 selection:text-white"
        suppressHydrationWarning
      >
        {children}
      </body>
    </html>
  );
}
