'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { DISTILLERY_STEPS } from '@/lib/data';
import { Activity, Cpu, Thermometer, ShieldAlert, CheckCircle2 } from 'lucide-react';

export default function DistillerySection() {
  const [activeStep, setActiveStep] = useState(0);

  return (
    <section id="distillery" className="relative min-h-screen bg-[#03060c] py-24 px-6 md:px-10 border-t border-white/10 overflow-hidden">
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/10 pb-8 mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-[1px] bg-[#d4af37]" />
              <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37]">
                THE THAMESIDE FACILITY &middot; EST. 2031
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-white tracking-tight">
              PRECISION, <span className="italic font-normal">DISTILLED.</span>
            </h2>
          </div>

          {/* Real-time Telemetry Pills (Understated Aerospace/Industrial UI) */}
          <div className="flex flex-wrap items-center gap-3 text-[10px] font-mono">
            <div className="px-3 py-1.5 border border-white/10 bg-[#060c18] text-slate-300 flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>COPPER STILL 04: ONLINE</span>
            </div>
            <div className="px-3 py-1.5 border border-white/10 bg-[#060c18] text-slate-300">
              VACUUM: 0.124 BAR
            </div>
            <div className="px-3 py-1.5 border border-white/10 bg-[#060c18] text-[#38bdf8]">
              EXTRACTION: 42.4°C
            </div>
          </div>
        </div>

        {/* Distillery Architectural Hero Photo with Technical Overlay Annotations */}
        <div className="relative border border-white/15 bg-[#060c18] overflow-hidden mb-16 shadow-2xl group">
          <img
            src="/images/distillery_arch_1790506426376.jpg"
            alt="Northbridge Modern British Distillery Architecture"
            className="w-full h-[400px] sm:h-[500px] md:h-[600px] object-cover object-center filter brightness-90 contrast-110 group-hover:scale-102 transition-transform duration-700"
            referrerPolicy="no-referrer"
          />

          {/* Understated Technical Interface HUD Overlays */}
          <div className="absolute inset-0 p-6 md:p-8 flex flex-col justify-between pointer-events-none">
            {/* Top HUD Markers */}
            <div className="flex items-center justify-between">
              <div className="p-3 bg-[#040811]/90 border border-white/20 backdrop-blur-md text-[10px] font-mono space-y-1">
                <span className="text-[#d4af37] block font-semibold">UNIT ARCHITECTURE: NORTHBRIDGE LONDON HQ</span>
                <span className="text-slate-400 block">BLACKENED BRICK / LOW-E ACOUSTIC FLINT GLASS</span>
              </div>

              <div className="p-3 bg-[#040811]/90 border border-white/20 backdrop-blur-md text-[10px] font-mono text-right space-y-1">
                <span className="text-slate-300 block">INDUSTRY 4.0 CLOSED-LOOP RECOVERY</span>
                <span className="text-emerald-400 block">THERMODYNAMIC EFFICIENCY: 99.4%</span>
              </div>
            </div>

            {/* Bottom HUD Annotations */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-2.5 bg-[#040811]/85 border border-white/15 backdrop-blur-md text-[9px] font-mono">
                <span className="text-slate-500 block">COPPER STILL 04</span>
                <span className="text-white">BESPOKE QUAD COLUMN</span>
              </div>
              <div className="p-2.5 bg-[#040811]/85 border border-white/15 backdrop-blur-md text-[9px] font-mono">
                <span className="text-slate-500 block">BOTANICAL EXTRACTION</span>
                <span className="text-[#38bdf8]">CRYOGENIC VAPOR CHAMBER</span>
              </div>
              <div className="p-2.5 bg-[#040811]/85 border border-white/15 backdrop-blur-md text-[9px] font-mono">
                <span className="text-slate-500 block">MICRO-DISTILLATION</span>
                <span className="text-white">LOW-TEMPERATURE 42°C</span>
              </div>
              <div className="p-2.5 bg-[#040811]/85 border border-white/15 backdrop-blur-md text-[9px] font-mono">
                <span className="text-slate-500 block">PRECISION FILTRATION</span>
                <span className="text-white">SUB-MICRON CERAMIC 0.2µm</span>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive 4-Phase Engineering Sequence */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-slate-400">
              THE 2030s DISTILLATION ARCHITECTURE
            </span>
            <span className="text-[10px] font-mono tracking-widest text-[#d4af37]">
              CONTINUOUS AUTOMATED CONTROL
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {DISTILLERY_STEPS.map((phase, idx) => {
              const isActive = activeStep === idx;

              return (
                <button
                  key={phase.step}
                  onClick={() => setActiveStep(idx)}
                  className={`p-5 border text-left transition-all duration-300 flex flex-col justify-between h-56 cursor-pointer ${
                    isActive
                      ? 'border-[#d4af37] bg-[#0c1628] shadow-2xl'
                      : 'border-white/10 bg-[#060c18] hover:border-white/30 hover:bg-[#08101d]'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-white/10 pb-2">
                    <span className="text-xs font-mono font-medium text-slate-400">
                      PHASE {phase.step}
                    </span>
                    <span className="text-[10px] font-mono text-[#d4af37]">
                      {phase.code}
                    </span>
                  </div>

                  <div>
                    <h4 className="font-serif text-base text-white leading-snug mb-2">
                      {phase.name}
                    </h4>
                    <p className="text-xs text-slate-400 font-light line-clamp-2 leading-relaxed">
                      {phase.detail}
                    </p>
                  </div>

                  <div className="text-[9px] font-mono text-slate-500 truncate pt-2 border-t border-white/5">
                    {phase.telemetry.split('|')[0]}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Phase Detailed Telemetry View */}
          <div className="mt-6 p-6 bg-[#060c18] border border-white/10 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="space-y-1">
              <span className="text-[9px] font-mono uppercase tracking-[0.3em] text-[#38bdf8]">
                ACTIVE TELEMETRY STREAM &middot; {DISTILLERY_STEPS[activeStep].code}
              </span>
              <p className="text-sm font-mono text-white">
                {DISTILLERY_STEPS[activeStep].telemetry}
              </p>
            </div>
            <div className="text-right text-xs text-slate-400 font-light max-w-sm">
              All batches are monitored with spectrometry in real time. Heads and tails fractions are separated with millisecond robotic valve precision.
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
