'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BOTANICALS } from '@/lib/data';
import { Botanical } from '@/lib/types';
import { Compass, Thermometer, Filter, Layers, ArrowRight } from 'lucide-react';

export default function BotanicalsGallery() {
  const [selectedBotanical, setSelectedBotanical] = useState<Botanical>(BOTANICALS[0]);

  return (
    <section id="botanicals" className="relative min-h-screen bg-[#040811] py-24 px-6 md:px-10 border-t border-white/10 overflow-hidden">
      
      {/* Background Macro Banner Layer */}
      <div className="absolute top-0 right-0 w-full lg:w-1/2 h-96 pointer-events-none opacity-20 select-none overflow-hidden">
        <img
          src="/images/botanicals_macro_1790506441609.jpg"
          alt="Macro Botanicals Specimen Archive"
          className="w-full h-full object-cover filter contrast-125"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-transparent via-[#040811]/70 to-[#040811]" />
        <div className="absolute inset-0 bg-gradient-to-b from-[#040811] via-transparent to-[#040811]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="border-b border-white/10 pb-8 mb-12 max-w-3xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-[1px] bg-[#38bdf8]" />
            <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#38bdf8]">
              NATURAL HISTORY ARCHIVE &middot; TERROIR TAXONOMY
            </span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-serif font-light text-white tracking-tight">
            BOTANICALS FROM A <span className="italic font-normal">MODERN BRITAIN</span>
          </h2>

          <p className="text-xs md:text-sm text-slate-400 font-light mt-4 leading-relaxed">
            Every botanical in Northbridge is sustainably collected across Britain&apos;s ancient forests, chalk downs, tidal marshes and moorlands. Documented with scientific rigor and refined under low-temperature vacuum extraction.
          </p>
        </div>

        {/* Specimen Showcase Layout: Active Inspector & Horizontal Strip */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          
          {/* Left: Active Botanical Scientific Dossier */}
          <div className="lg:col-span-6 bg-[#060c18] border border-white/15 p-6 md:p-8 space-y-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div>
                <span className="text-[9px] font-mono tracking-[0.3em] text-[#d4af37] uppercase block">
                  SPECIMEN DOSSIER &middot; NO. {selectedBotanical.id.toUpperCase()}
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif text-white tracking-wide mt-1">
                  {selectedBotanical.name}
                </h3>
              </div>
              <span className="text-xs font-serif italic text-slate-400">
                {selectedBotanical.scientificName}
              </span>
            </div>

            <p className="text-xs text-slate-300 font-light leading-relaxed">
              {selectedBotanical.description}
            </p>

            {/* Scientific Parameters Card */}
            <div className="grid grid-cols-2 gap-4 pt-2 text-xs font-mono">
              <div className="p-3 bg-[#030710] border border-white/5 space-y-1">
                <div className="flex items-center gap-1.5 text-slate-500 text-[9px] uppercase tracking-wider">
                  <Compass className="w-3 h-3 text-[#38bdf8]" />
                  <span>HARVEST COORDINATES</span>
                </div>
                <div className="text-white text-[11px]">{selectedBotanical.coordinates}</div>
                <div className="text-slate-400 text-[10px] truncate">{selectedBotanical.origin}</div>
              </div>

              <div className="p-3 bg-[#030710] border border-white/5 space-y-1">
                <div className="flex items-center gap-1.5 text-slate-500 text-[9px] uppercase tracking-wider">
                  <Thermometer className="w-3 h-3 text-[#d4af37]" />
                  <span>EXTRACTION THERMAL</span>
                </div>
                <div className="text-[#38bdf8] text-[11px]">{selectedBotanical.temperature}</div>
                <div className="text-slate-400 text-[10px] truncate">{selectedBotanical.extractionMethod}</div>
              </div>
            </div>

            {/* Sensory Aroma Profile */}
            <div className="p-3.5 bg-[#030710] border border-white/10 space-y-1.5">
              <span className="text-[9px] font-mono uppercase tracking-widest text-[#d4af37] block">
                ORGANIC AROMATIC CHROMATOGRAM
              </span>
              <p className="text-xs font-mono text-slate-200">
                {selectedBotanical.profile}
              </p>
            </div>

            {/* Expressions utilizing this botanical */}
            <div className="pt-2 flex items-center justify-between text-xs font-mono text-slate-400 border-t border-white/5">
              <span>FEATURED IN:</span>
              <div className="flex flex-wrap gap-1.5">
                {selectedBotanical.expressionsUsed.map((expr) => (
                  <span key={expr} className="px-2 py-0.5 bg-white/10 text-white text-[10px]">
                    {expr}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Macro Image Display with Specimen Grid */}
          <div className="lg:col-span-6 space-y-6">
            <div className="relative border border-white/10 bg-[#070e1b] overflow-hidden group">
              <img
                src="/images/botanicals_macro_1790506441609.jpg"
                alt="Heritage British Botanicals Specimen Photography"
                className="w-full h-80 object-cover object-center filter contrast-110 group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#060c18] via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-[10px] font-mono tracking-widest uppercase text-slate-300">
                <span>PHOTO REF: BRITISH ARCHIVE 2031</span>
                <span>MACRO DETAIL 8K</span>
              </div>
            </div>

            <div className="p-4 bg-[#050b14] border border-white/10">
              <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-slate-400 block mb-2">
                SELECT A BOTANICAL SPECIMEN TO EXAMINE:
              </span>
              <p className="text-xs text-slate-400 font-light">
                Browse our ten primary botanical pillars collected across Britain below to view coordinates and distillation profiles.
              </p>
            </div>
          </div>

        </div>

        {/* Horizontal Specimen Selector Strip (All 10 Botanicals) */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-slate-400">
              TEN HERITAGE BOTANICAL PILLARS
            </span>
            <span className="text-[10px] font-mono tracking-widest text-[#d4af37]">
              10 SPECIMENS CATALOGUED
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {BOTANICALS.map((botanical) => {
              const isSelected = selectedBotanical.id === botanical.id;

              return (
                <button
                  key={botanical.id}
                  onClick={() => setSelectedBotanical(botanical)}
                  className={`p-3.5 border text-left transition-all duration-300 flex flex-col justify-between h-36 cursor-pointer ${
                    isSelected
                      ? 'border-[#d4af37] bg-[#0c1626] shadow-xl'
                      : 'border-white/10 bg-[#060c18] hover:border-white/30 hover:bg-[#091120]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[9px] font-mono text-slate-500">
                      #{botanical.id.slice(0, 3).toUpperCase()}
                    </span>
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37] animate-ping" />
                    )}
                  </div>

                  <div>
                    <h4 className="font-serif text-sm text-white tracking-wide">
                      {botanical.name}
                    </h4>
                    <span className="text-[9px] font-serif italic text-slate-400 block truncate">
                      {botanical.scientificName}
                    </span>
                  </div>

                  <div className="text-[9px] font-mono text-slate-500 truncate border-t border-white/5 pt-1">
                    {botanical.temperature} &middot; {botanical.origin.split(',')[0]}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
