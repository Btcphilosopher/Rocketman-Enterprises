'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GIN_EXPRESSIONS } from '@/lib/data';
import ArchitecturalBottleGraphic from './ArchitecturalBottleGraphic';
import { ChevronLeft, ChevronRight, Eye, Sparkles } from 'lucide-react';

interface InteractiveBottleMorphProps {
  onSelectBottle: (expressionId: string) => void;
}

export default function InteractiveBottleMorph({ onSelectBottle }: InteractiveBottleMorphProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const currentExpression = GIN_EXPRESSIONS[currentIndex];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % GIN_EXPRESSIONS.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + GIN_EXPRESSIONS.length) % GIN_EXPRESSIONS.length);
  };

  return (
    <section className="relative min-h-[90vh] bg-[#02050c] border-t border-white/10 flex flex-col justify-between py-20 px-6 md:px-12 overflow-hidden">
      {/* Dynamic Ambient Background Environment that transitions with the expression */}
      <div
        className="absolute inset-0 pointer-events-none transition-all duration-1000 opacity-25 blur-3xl"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${currentExpression.hexColor} 0%, transparent 65%)`
        }}
      />

      <div className="max-w-7xl mx-auto w-full relative z-10 flex-1 flex flex-col justify-between">
        
        {/* Top Control Bar */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6 mb-8">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37] block mb-1">
              DYNAMIC ARCHITECTURAL MORPH
            </span>
            <h2 className="text-2xl md:text-4xl font-serif text-white tracking-wide">
              THE FIVE GUISES OF NORTHBRIDGE
            </h2>
          </div>

          {/* Stepper Buttons */}
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrev}
              className="p-3 border border-white/20 hover:border-white/50 text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Previous Expression"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            {/* Expression Indicator Dots */}
            <div className="flex items-center gap-2 px-3 py-2 bg-white/5 border border-white/10">
              {GIN_EXPRESSIONS.map((exp, idx) => (
                <button
                  key={exp.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={`w-2.5 h-2.5 rounded-full transition-all duration-300 cursor-pointer ${
                    currentIndex === idx ? 'scale-125' : 'opacity-40 hover:opacity-80'
                  }`}
                  style={{ backgroundColor: exp.hexColor }}
                  title={exp.name}
                />
              ))}
            </div>

            <button
              onClick={handleNext}
              className="p-3 border border-white/20 hover:border-white/50 text-white bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
              aria-label="Next Expression"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Central Morph Stage */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center my-auto py-6">
          
          {/* Left Column: Tasting Notes & Botanical Essence */}
          <div className="lg:col-span-4 space-y-6 order-2 lg:order-1">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentExpression.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.5 }}
                className="space-y-4"
              >
                <div className="inline-flex items-center gap-2 text-[10px] font-mono tracking-widest uppercase text-slate-400">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: currentExpression.hexColor }} />
                  EXPRESSION {currentExpression.number} / 05
                </div>

                <h3 className="text-3xl sm:text-4xl font-serif text-white tracking-wide">
                  {currentExpression.name}
                </h3>

                <p className="text-xs font-mono tracking-widest text-[#d4af37] uppercase">
                  {currentExpression.tagline}
                </p>

                <p className="text-xs text-slate-300 font-light leading-relaxed">
                  {currentExpression.concept}
                </p>

                {/* Botanical Badges */}
                <div className="pt-2">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-2">
                    KEY HERITAGE BOTANICALS
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {currentExpression.botanicals.map((b) => (
                      <span
                        key={b}
                        className="px-2.5 py-1 text-[10px] font-mono border border-white/15 bg-white/5 text-slate-200"
                      >
                        {b}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Button to Launch Full 3D Inspection */}
                <div className="pt-4">
                  <button
                    onClick={() => onSelectBottle(currentExpression.id)}
                    className="flex items-center gap-2.5 px-5 py-3 bg-white text-slate-950 hover:bg-slate-200 text-xs font-medium font-mono tracking-widest uppercase transition-all duration-200 cursor-pointer shadow-xl"
                  >
                    <Eye className="w-3.5 h-3.5 text-slate-900" />
                    <span>LAUNCH 3D BOTTLE VIEWER</span>
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Center Column: The Pinned Architectural Bottle Graphic */}
          <div className="lg:col-span-4 flex justify-center items-center order-1 lg:order-2 py-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentExpression.id}
                initial={{ opacity: 0, scale: 0.94, y: 15 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.94, y: -15 }}
                transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className="relative"
              >
                <ArchitecturalBottleGraphic
                  expression={currentExpression}
                  isHovered={false}
                  size="xl"
                />
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Right Column: Technical Distillation & Flavor Breakdown */}
          <div className="lg:col-span-4 space-y-5 order-3">
            <AnimatePresence mode="wait">
              <motion.div
                key={`specs-${currentExpression.id}`}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ duration: 0.5 }}
                className="p-5 border border-white/10 bg-[#060c17]/80 backdrop-blur-md space-y-4"
              >
                <div className="text-[10px] font-mono uppercase tracking-[0.25em] text-slate-400 border-b border-white/10 pb-2">
                  DISTILLATION TELEMETRY
                </div>

                <div className="space-y-2.5 text-xs">
                  <div>
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">EXTRACTION STILL</span>
                    <span className="text-slate-200 font-mono text-[11px]">
                      {currentExpression.technicalSpecs.stillType}
                    </span>
                  </div>

                  <div>
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">VACUUM PRESSURE</span>
                    <span className="text-slate-200 font-mono text-[11px]">
                      {currentExpression.technicalSpecs.vacuumPressure}
                    </span>
                  </div>

                  <div>
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">EXTRACTION TEMP</span>
                    <span className="text-[#38bdf8] font-mono text-[11px]">
                      {currentExpression.technicalSpecs.extractionTemp}
                    </span>
                  </div>

                  <div>
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">WATER SOURCE</span>
                    <span className="text-slate-300 font-mono text-[11px]">
                      {currentExpression.technicalSpecs.waterSource}
                    </span>
                  </div>
                </div>

                {/* Radar Breakdown Sliders */}
                <div className="pt-3 border-t border-white/10 space-y-2">
                  <span className="text-[9px] font-mono text-slate-400 uppercase tracking-wider block">
                    FLAVOR PROFILE MATRIX
                  </span>

                  <div className="space-y-1.5 text-[10px] font-mono">
                    <div className="flex justify-between text-slate-300">
                      <span>Juniper</span>
                      <span>{currentExpression.tastingRadar.juniper}%</span>
                    </div>
                    <div className="w-full bg-white/10 h-1">
                      <div
                        className="h-1 transition-all duration-700"
                        style={{
                          width: `${currentExpression.tastingRadar.juniper}%`,
                          backgroundColor: currentExpression.hexColor
                        }}
                      />
                    </div>

                    <div className="flex justify-between text-slate-300 pt-1">
                      <span>Citrus Luminescence</span>
                      <span>{currentExpression.tastingRadar.citrus}%</span>
                    </div>
                    <div className="w-full bg-white/10 h-1">
                      <div
                        className="h-1 transition-all duration-700"
                        style={{
                          width: `${currentExpression.tastingRadar.citrus}%`,
                          backgroundColor: currentExpression.hexColor
                        }}
                      />
                    </div>

                    <div className="flex justify-between text-slate-300 pt-1">
                      <span>Terroir Salinity & Herb</span>
                      <span>{currentExpression.tastingRadar.mineral}%</span>
                    </div>
                    <div className="w-full bg-white/10 h-1">
                      <div
                        className="h-1 transition-all duration-700"
                        style={{
                          width: `${currentExpression.tastingRadar.mineral}%`,
                          backgroundColor: currentExpression.hexColor
                        }}
                      />
                    </div>
                  </div>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>

        {/* Bottom expression navigation bar */}
        <div className="border-t border-white/10 pt-6 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
          <span className="text-slate-500 uppercase tracking-widest text-[10px]">
            ACTIVE SELECTION: {currentExpression.number} &middot; {currentExpression.name}
          </span>
          <div className="flex items-center gap-4 text-slate-400">
            <span>VOLUME: {currentExpression.volume}</span>
            <span>&middot;</span>
            <span>ABV: {currentExpression.abv}</span>
            <span>&middot;</span>
            <span className="text-white font-medium">£{currentExpression.price}</span>
          </div>
        </div>

      </div>
    </section>
  );
}
