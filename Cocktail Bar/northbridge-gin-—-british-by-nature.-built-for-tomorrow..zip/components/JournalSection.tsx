'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { JOURNAL_ARTICLES } from '@/lib/data';
import { JournalArticle } from '@/lib/types';
import { BookOpen, X, ArrowRight, Clock, Calendar, User } from 'lucide-react';

export default function JournalSection() {
  const [selectedArticle, setSelectedArticle] = useState<JournalArticle | null>(null);

  return (
    <section id="journal" className="relative min-h-screen bg-[#040811] py-24 px-6 md:px-10 border-t border-white/10 overflow-hidden">
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/10 pb-8 mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-[1px] bg-[#d4af37]" />
              <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37]">
                THE NORTHBRIDGE GAZETTE &middot; ESSAYS & RESEARCH
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-white tracking-tight">
              EDITORIAL <span className="italic font-normal">JOURNAL</span>
            </h2>
          </div>

          <p className="text-xs md:text-sm text-slate-400 font-light max-w-md leading-relaxed">
            Essays on distillation physics, British architectural history, wild foraging expeditions, and the evolution of spirits culture for the 2030s.
          </p>
        </div>

        {/* Featured Article + Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          
          {/* Featured Major Article */}
          <div
            onClick={() => setSelectedArticle(JOURNAL_ARTICLES[0])}
            className="lg:col-span-7 bg-[#060c18] border border-white/15 p-8 md:p-10 flex flex-col justify-between hover:border-white/40 transition-all duration-300 cursor-pointer group shadow-2xl"
          >
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400">
                <span className="text-[#d4af37] uppercase tracking-widest">{JOURNAL_ARTICLES[0].category}</span>
                <span>{JOURNAL_ARTICLES[0].readTime}</span>
              </div>

              <h3 className="text-2xl sm:text-4xl font-serif text-white group-hover:text-slate-200 transition-colors leading-tight">
                {JOURNAL_ARTICLES[0].title}
              </h3>

              <p className="text-sm font-serif italic text-slate-300">
                {JOURNAL_ARTICLES[0].subtitle}
              </p>

              <p className="text-xs sm:text-sm text-slate-400 font-light leading-relaxed">
                {JOURNAL_ARTICLES[0].excerpt}
              </p>
            </div>

            <div className="pt-8 mt-6 border-t border-white/10 flex items-center justify-between text-xs font-mono">
              <span className="text-slate-500">{JOURNAL_ARTICLES[0].author}</span>
              <span className="text-white group-hover:translate-x-1.5 transition-transform flex items-center gap-1.5">
                READ ARTICLE <ArrowRight className="w-3.5 h-3.5 text-[#d4af37]" />
              </span>
            </div>
          </div>

          {/* Secondary Articles Stack */}
          <div className="lg:col-span-5 flex flex-col justify-between gap-4">
            {JOURNAL_ARTICLES.slice(1, 4).map((art) => (
              <div
                key={art.id}
                onClick={() => setSelectedArticle(art)}
                className="p-5 border border-white/10 bg-[#060c18] hover:border-white/30 hover:bg-[#081120] transition-all duration-300 cursor-pointer group flex-1 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-1">
                    <span className="text-[#38bdf8] uppercase tracking-wider">{art.category}</span>
                    <span>{art.readTime}</span>
                  </div>
                  <h4 className="font-serif text-base sm:text-lg text-white group-hover:text-[#d4af37] transition-colors leading-snug">
                    {art.title}
                  </h4>
                  <p className="text-xs text-slate-400 font-light line-clamp-2 mt-1">
                    {art.excerpt}
                  </p>
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-500 mt-2">
                  <span>{art.date}</span>
                  <span className="group-hover:translate-x-1 transition-transform text-white">READ →</span>
                </div>
              </div>
            ))}
          </div>

        </div>

        {/* Remaining Articles Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {JOURNAL_ARTICLES.slice(4).map((art) => (
            <div
              key={art.id}
              onClick={() => setSelectedArticle(art)}
              className="p-6 border border-white/10 bg-[#060c18] hover:border-white/30 hover:bg-[#081120] transition-all duration-300 cursor-pointer group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-2">
                  <span className="text-[#d4af37] uppercase tracking-wider">{art.category}</span>
                  <span>{art.readTime}</span>
                </div>
                <h4 className="font-serif text-xl text-white group-hover:text-slate-200 transition-colors">
                  {art.title}
                </h4>
                <p className="text-xs text-slate-400 font-light leading-relaxed mt-2">
                  {art.excerpt}
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[10px] font-mono text-slate-500 mt-4">
                <span>{art.author}</span>
                <span className="group-hover:translate-x-1 transition-transform text-white flex items-center gap-1">
                  READ ESSAY →
                </span>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Full Article Reader Modal */}
      <AnimatePresence>
        {selectedArticle && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-[#03060d]/95 backdrop-blur-2xl overflow-y-auto"
          >
            <motion.div
              initial={{ scale: 0.96, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 20 }}
              className="w-full max-w-3xl bg-[#060c18] border border-white/20 p-8 md:p-12 shadow-2xl relative my-auto max-h-[90vh] overflow-y-auto"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute top-6 right-6 p-2 border border-white/10 hover:border-white/40 text-slate-400 hover:text-white transition-colors cursor-pointer"
                aria-label="Close Article"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-6">
                <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
                  <span className="text-[#d4af37] uppercase tracking-widest">{selectedArticle.category}</span>
                  <span>&middot;</span>
                  <span>{selectedArticle.readTime}</span>
                  <span>&middot;</span>
                  <span>{selectedArticle.date}</span>
                </div>

                <h2 className="text-3xl sm:text-5xl font-serif text-white tracking-tight leading-tight">
                  {selectedArticle.title}
                </h2>

                <p className="text-base font-serif italic text-slate-300 border-l-2 border-[#d4af37] pl-4">
                  {selectedArticle.subtitle}
                </p>

                <div className="text-xs font-mono text-slate-400 pt-2 border-b border-white/10 pb-4">
                  By {selectedArticle.author}
                </div>

                {/* Article Body */}
                <div className="space-y-4 text-sm sm:text-base text-slate-300 font-light leading-relaxed">
                  {selectedArticle.content.map((paragraph, idx) => (
                    <p key={idx}>{paragraph}</p>
                  ))}
                </div>

                <div className="pt-8 border-t border-white/10 flex items-center justify-between text-xs font-mono text-slate-500">
                  <span>NORTHBRIDGE EDITORIAL ARCHIVE &middot; LONDON</span>
                  <button
                    onClick={() => setSelectedArticle(null)}
                    className="text-white hover:text-[#d4af37] transition-colors cursor-pointer"
                  >
                    CLOSE ESSAY [X]
                  </button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
