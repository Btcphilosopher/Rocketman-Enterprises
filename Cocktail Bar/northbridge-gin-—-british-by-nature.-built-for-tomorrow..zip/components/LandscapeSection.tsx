'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { BRITISH_LANDSCAPES } from '@/lib/data';
import { MapPin, Mountain, Wind, Sparkles } from 'lucide-react';

export default function LandscapeSection() {
  const [selectedLandscape, setSelectedLandscape] = useState(BRITISH_LANDSCAPES[0]);

  return (
    <section id="britain" className="relative min-h-screen bg-[#040811] py-24 px-6 md:px-10 border-t border-white/10 overflow-hidden">
      
      {/* Background Cinematic Panoramic Layer */}
      <div className="absolute inset-0 pointer-events-none opacity-25 select-none overflow-hidden">
        <img
          src="/images/landscape_britain_1790506459707.jpg"
          alt="Cinematic British Landscape"
          className="w-full h-full object-cover object-center filter contrast-125 brightness-75"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#040811] via-[#040811]/60 to-[#040811]" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#040811] via-transparent to-[#040811]" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="max-w-3xl mb-16 space-y-4">
          <div className="flex items-center gap-2">
            <span className="w-2 h-[1px] bg-[#d4af37]" />
            <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37]">
              TERROIR & CONTEMPORARY GEOGRAPHY
            </span>
          </div>

          <h2 className="text-3xl sm:text-5xl md:text-6xl font-serif font-light text-white tracking-tight leading-tight">
            A SPIRIT OF A <span className="italic font-normal">NEW BRITAIN</span>
          </h2>

          <p className="text-sm md:text-base text-slate-300 font-light leading-relaxed pt-2">
            “Northbridge Gin is rooted in the landscapes, gardens and cities of Britain — interpreted through modern distillation and a distinctly contemporary eye.”
          </p>
        </div>

        {/* Interactive British Terroir Explorer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          
          {/* Left Column: Terroir Selection Tabs */}
          <div className="lg:col-span-5 space-y-3">
            <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-slate-400 block mb-2">
              SELECT A BRITISH REGION:
            </span>

            {BRITISH_LANDSCAPES.map((landscape) => {
              const isSelected = selectedLandscape.id === landscape.id;

              return (
                <button
                  key={landscape.id}
                  onClick={() => setSelectedLandscape(landscape)}
                  className={`w-full p-4 border text-left transition-all duration-300 flex items-center justify-between cursor-pointer ${
                    isSelected
                      ? 'border-[#d4af37] bg-[#0c1626] shadow-xl'
                      : 'border-white/10 bg-[#060c18]/80 hover:border-white/30 hover:bg-[#091120]'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono text-[#d4af37] uppercase tracking-wider">
                        {landscape.expression}
                      </span>
                    </div>
                    <h3 className="font-serif text-lg text-white tracking-wide mt-0.5">
                      {landscape.name}
                    </h3>
                    <span className="text-[10px] font-mono text-slate-400">
                      {landscape.region} &middot; {landscape.elevation}
                    </span>
                  </div>

                  <span className={`text-xs font-mono transition-transform duration-300 ${
                    isSelected ? 'translate-x-1 text-[#d4af37]' : 'text-slate-600'
                  }`}>
                    →
                  </span>
                </button>
              );
            })}
          </div>

          {/* Right Column: Active Terroir Detailed Dossier */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedLandscape.id}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -12 }}
                transition={{ duration: 0.4 }}
                className="bg-[#070e1b] border border-white/15 p-8 space-y-6 shadow-2xl relative overflow-hidden"
              >
                {/* Decorative coordinate watermark */}
                <div className="text-[10px] font-mono text-[#38bdf8] uppercase tracking-[0.3em] flex items-center justify-between border-b border-white/10 pb-4">
                  <span>GPS COORDINATES: {selectedLandscape.coordinates}</span>
                  <span>ELEVATION: {selectedLandscape.elevation}</span>
                </div>

                <div className="space-y-2">
                  <span className="text-xs font-mono uppercase tracking-widest text-[#d4af37]">
                    REGIONAL EXPRESSION: {selectedLandscape.expression}
                  </span>
                  <h3 className="text-3xl font-serif text-white tracking-wide">
                    {selectedLandscape.name}
                  </h3>
                  <p className="text-xs md:text-sm text-slate-300 font-light leading-relaxed">
                    {selectedLandscape.description}
                  </p>
                </div>

                {/* Sensory Terroir Markers */}
                <div className="pt-2 border-t border-white/10">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-3">
                    DISTILLATION SENSORY IMPRINT
                  </span>
                  <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                    {selectedLandscape.sensoryNotes.map((note) => (
                      <div
                        key={note}
                        className="p-2.5 bg-[#03060d] border border-white/5 text-slate-300 flex items-center gap-2"
                      >
                        <span className="w-1.5 h-1.5 bg-[#d4af37]" />
                        <span>{note}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* British Flag Linear Modernist Geometry */}
                <div className="pt-4 border-t border-white/5 flex items-center justify-between text-[9px] font-mono text-slate-500">
                  <span>BRITISH BOTANICAL HERITAGE</span>
                  <span>PREMIUM SPIRITS OF GREAT BRITAIN</span>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
