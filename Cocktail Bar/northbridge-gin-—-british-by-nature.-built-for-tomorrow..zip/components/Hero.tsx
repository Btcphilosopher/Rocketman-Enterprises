'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ChevronDown, Compass, Award } from 'lucide-react';
import { GIN_EXPRESSIONS } from '@/lib/data';

interface HeroProps {
  onSelectBottle: (expressionId: string) => void;
  onExploreCollection: () => void;
}

export default function Hero({ onSelectBottle, onExploreCollection }: HeroProps) {
  const [loadStage, setLoadStage] = useState(0);

  // Cinematic launch sequence on page load (2.8s total)
  useEffect(() => {
    const t1 = setTimeout(() => setLoadStage(1), 300);  // Monogram fades in
    const t2 = setTimeout(() => setLoadStage(2), 900);  // Typography appears
    const t3 = setTimeout(() => setLoadStage(3), 1500); // London photograph slowly reveals
    const t4 = setTimeout(() => setLoadStage(4), 2100); // Bottles rise & atmospheric light sweeps
    const t5 = setTimeout(() => setLoadStage(5), 2800); // Complete interactive state

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
      clearTimeout(t5);
    };
  }, []);

  return (
    <section id="hero" className="relative min-h-screen w-full flex flex-col justify-between overflow-hidden bg-[#040811] text-white pt-24 pb-10">
      {/* Background Photography Layer with Dusk London Skyline */}
      <motion.div
        initial={{ opacity: 0, scale: 1.06 }}
        animate={{
          opacity: loadStage >= 3 ? 0.75 : 0,
          scale: loadStage >= 3 ? 1 : 1.06
        }}
        transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
        className="absolute inset-0 pointer-events-none select-none z-0"
      >
        <img
          src="/images/hero_flagship_1790506478274.jpg"
          alt="Northbridge London Dusk Skyline Flagship"
          className="w-full h-full object-cover object-center filter brightness-[0.78] contrast-[1.12]"
          referrerPolicy="no-referrer"
        />
        {/* Architectural atmospheric gradient overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#040811] via-[#040811]/40 to-[#040811]/70" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#040811]/90 via-transparent to-[#040811]/85" />
      </motion.div>

      {/* Atmospheric moving light sweep across glass on reveal */}
      <motion.div
        initial={{ x: '-100%', opacity: 0 }}
        animate={{
          x: loadStage >= 4 ? '200%' : '-100%',
          opacity: loadStage >= 4 ? [0, 0.4, 0] : 0
        }}
        transition={{ duration: 2.2, ease: 'easeInOut' }}
        className="absolute inset-0 z-10 pointer-events-none bg-gradient-to-r from-transparent via-white/10 to-transparent skew-x-12"
      />

      {/* Main Container */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 md:px-10 w-full flex-1 flex flex-col justify-between">
        
        {/* Top Header Labeling & Monogram Reveal */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6 pt-4">
          <div className="flex items-center gap-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{
                opacity: loadStage >= 1 ? 1 : 0,
                scale: loadStage >= 1 ? 1 : 0.8
              }}
              transition={{ duration: 0.8 }}
              className="w-10 h-10 border border-[#d4af37]/60 flex items-center justify-center bg-[#050b14]/80 shadow-lg"
            >
              <span className="font-serif text-[#d4af37] text-sm tracking-widest font-normal">
                NH
              </span>
            </motion.div>
            <div>
              <motion.span
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: loadStage >= 2 ? 1 : 0, y: loadStage >= 2 ? 0 : 10 }}
                transition={{ duration: 0.6 }}
                className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37] block"
              >
                PREMIUM BRITISH GIN &middot; EST. 2031
              </motion.span>
              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: loadStage >= 2 ? 1 : 0, y: loadStage >= 2 ? 0 : 10 }}
                transition={{ duration: 0.6, delay: 0.1 }}
                className="text-lg md:text-xl font-serif tracking-[0.25em] text-white"
              >
                NORTHBRIDGE GIN
              </motion.h1>
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: loadStage >= 3 ? 1 : 0 }}
            transition={{ duration: 0.8 }}
            className="flex items-center gap-6 text-[10px] text-slate-400 font-mono tracking-widest uppercase"
          >
            <span>LONDON HQ / 51.5074° N, 0.1278° W</span>
            <span className="hidden sm:inline">&middot;</span>
            <span className="hidden sm:inline">THERMAL VACUUM 0.12 BAR</span>
          </motion.div>
        </div>

        {/* Hero Editorial Statement & Main Headlines */}
        <div className="my-auto py-10 max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{
              opacity: loadStage >= 3 ? 1 : 0,
              y: loadStage >= 3 ? 0 : 24
            }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="space-y-4"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 border border-white/10 bg-white/5 backdrop-blur-sm text-[10px] font-mono tracking-[0.25em] text-[#93c5fd]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#38bdf8] animate-pulse" />
              FIVE EXPRESSIONS &middot; ONE VISION
            </div>

            <h2 className="text-4xl sm:text-6xl md:text-7xl font-serif font-light tracking-tight text-white leading-[1.08]">
              BRITISH BY NATURE.
              <span className="block italic text-slate-200 font-normal">BUILT FOR TOMORROW.</span>
            </h2>

            <p className="text-sm sm:text-base text-slate-300 font-light max-w-xl leading-relaxed pt-2">
              Heritage botanicals. Modern science. A more extraordinary tomorrow. Sourced across Britain’s coasts, moors and ancient woodlands, distilled under low-temperature vacuum precision.
            </p>

            {/* CTAs */}
            <div className="pt-6 flex flex-wrap items-center gap-4">
              <button
                onClick={onExploreCollection}
                className="group flex items-center gap-3 px-6 py-3.5 bg-white hover:bg-slate-100 text-slate-950 text-xs font-medium tracking-[0.2em] uppercase transition-all duration-300 shadow-xl cursor-pointer"
              >
                <span>EXPLORE THE COLLECTION</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1.5" />
              </button>

              <a
                href="#distillery"
                className="group flex items-center gap-2 px-6 py-3.5 border border-white/20 hover:border-white/50 bg-[#060c18]/60 hover:bg-[#0c1626] text-white text-xs font-light tracking-[0.2em] uppercase transition-all duration-300 cursor-pointer"
              >
                <span>DISCOVER OUR DISTILLERY</span>
              </a>
            </div>
          </motion.div>
        </div>

        {/* Five Bottles Interactive Preview Bar (Direct Tribute to Reference Art) */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{
            opacity: loadStage >= 4 ? 1 : 0,
            y: loadStage >= 4 ? 0 : 40
          }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="pt-6 border-t border-white/10"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-slate-400">
              CLICK AN EXPRESSION TO ENTER 3D INSPECTION
            </span>
            <span className="text-[10px] font-mono tracking-widest text-[#d4af37]">
              70cl &middot; 41.2% ABV
            </span>
          </div>

          {/* 5 Expression Horizontal Quick Selectors */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {GIN_EXPRESSIONS.map((gin) => (
              <button
                key={gin.id}
                onClick={() => onSelectBottle(gin.id)}
                className="group relative p-3 border border-white/10 hover:border-white/40 bg-[#070e1b]/70 hover:bg-[#0c172a]/80 backdrop-blur-md transition-all duration-300 text-left flex flex-col justify-between h-28 cursor-pointer overflow-hidden"
              >
                {/* Expression color accent highlight */}
                <div
                  className="absolute top-0 left-0 right-0 h-[2px] transition-all duration-300 group-hover:h-[3px]"
                  style={{ backgroundColor: gin.hexColor }}
                />

                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono text-slate-400 group-hover:text-white transition-colors">
                    {gin.number}
                  </span>
                  <div
                    className="w-2 h-2 rounded-full opacity-70 group-hover:opacity-100 transition-opacity"
                    style={{ backgroundColor: gin.hexColor }}
                  />
                </div>

                <div>
                  <h3 className="font-serif text-sm tracking-wider text-white group-hover:text-[#f8fafc] transition-colors">
                    {gin.name}
                  </h3>
                  <p className="text-[9px] font-mono text-slate-400 tracking-wider truncate">
                    {gin.tagline}
                  </p>
                </div>

                <div className="flex items-center justify-between text-[9px] text-slate-400 border-t border-white/5 pt-1 mt-1">
                  <span>£{gin.price}</span>
                  <span className="group-hover:translate-x-1 transition-transform text-white">VIEW →</span>
                </div>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Scroll Indicator */}
        <div className="flex justify-center pt-8">
          <a
            href="#collection"
            className="flex flex-col items-center gap-1 text-[9px] font-mono tracking-[0.25em] text-slate-400 hover:text-white transition-colors uppercase"
          >
            <span>SCROLL TO EXPLORE</span>
            <ChevronDown className="w-3.5 h-3.5 animate-bounce text-slate-400" />
          </a>
        </div>

      </div>
    </section>
  );
}
