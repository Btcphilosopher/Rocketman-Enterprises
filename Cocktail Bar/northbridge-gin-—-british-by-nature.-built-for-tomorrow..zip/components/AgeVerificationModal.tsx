'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldCheck, Compass } from 'lucide-react';

export default function AgeVerificationModal() {
  const [isOpen, setIsOpen] = useState(() => {
    if (typeof window === 'undefined') return false;
    try {
      return !localStorage.getItem('northbridge_age_verified');
    } catch {
      return false;
    }
  });
  const [declined, setDeclined] = useState(false);

  const handleConfirm = () => {
    try {
      localStorage.setItem('northbridge_age_verified', 'true');
    } catch {}
    setIsOpen(false);
  };

  const handleDecline = () => {
    setDeclined(true);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#050b14]/90 backdrop-blur-xl"
        >
          <motion.div
            initial={{ scale: 0.96, opacity: 0, y: 16 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.96, opacity: 0, y: 16 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="w-full max-w-md bg-[#0a1220] border border-white/10 p-8 shadow-2xl relative overflow-hidden"
          >
            {/* Subtle decorative architectural lines */}
            <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#d4af37]/60 to-transparent" />
            <div className="absolute -top-12 -right-12 w-28 h-28 bg-[#38bdf8]/5 rounded-full blur-2xl pointer-events-none" />

            {/* Monogram */}
            <div className="flex justify-center mb-6">
              <div className="w-12 h-12 border border-[#d4af37]/40 flex items-center justify-center bg-[#070e1b]">
                <span className="font-serif text-[#d4af37] text-xl tracking-widest font-light">NH</span>
              </div>
            </div>

            <div className="text-center space-y-3 mb-8">
              <span className="text-[10px] tracking-[0.3em] uppercase text-[#94a3b8] font-mono">
                Verification / Legal Drinking Age
              </span>
              <h2 className="text-2xl font-serif tracking-wide text-white font-normal">
                WELCOME TO NORTHBRIDGE
              </h2>
              <p className="text-xs text-slate-400 font-light leading-relaxed max-w-xs mx-auto">
                You must be of legal drinking age in your country of residence to enter. Please confirm you are 18 years of age or older.
              </p>
            </div>

            {declined ? (
              <div className="text-center py-4 bg-red-950/20 border border-red-500/20 text-red-300 text-xs font-light">
                Access is restricted to individuals of legal drinking age. Please return when you are of legal age.
              </div>
            ) : (
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleConfirm}
                  className="flex-1 py-3 px-4 bg-white hover:bg-slate-100 text-slate-950 text-xs font-medium tracking-[0.15em] uppercase transition-all duration-200 cursor-pointer shadow-lg hover:shadow-white/10"
                >
                  I Am 18 Or Older
                </button>
                <button
                  onClick={handleDecline}
                  className="py-3 px-4 border border-white/15 hover:border-white/30 text-slate-400 hover:text-white text-xs font-light tracking-[0.15em] uppercase transition-all duration-200 cursor-pointer"
                >
                  Exit
                </button>
              </div>
            )}

            <div className="mt-8 pt-4 border-t border-white/5 flex items-center justify-between text-[9px] text-slate-500 font-mono tracking-wider">
              <span>BRITISH SPIRITS ACT 2031</span>
              <span>RESPONSIBLE DRINKING</span>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
