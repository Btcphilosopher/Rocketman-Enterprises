'use client';

import React from 'react';
import { GinExpression } from '@/lib/types';

interface ArchitecturalBottleGraphicProps {
  expression: GinExpression;
  isHovered?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

export default function ArchitecturalBottleGraphic({
  expression,
  isHovered = false,
  size = 'md'
}: ArchitecturalBottleGraphicProps) {
  // Dimension profiles
  const dimensions = {
    sm: { width: 100, height: 260 },
    md: { width: 140, height: 360 },
    lg: { width: 200, height: 500 },
    xl: { width: 280, height: 680 }
  }[size];

  // Specific cap gradient & metallic styling per expression
  const capGradients: Record<string, { start: string; mid: string; end: string; highlight: string }> = {
    'london-dry': { start: '#334155', mid: '#64748b', end: '#0f172a', highlight: '#94a3b8' },
    'wild-coast': { start: '#78350f', mid: '#b45309', end: '#451a03', highlight: '#f59e0b' },
    'heath-blossom': { start: '#881337', mid: '#be123c', end: '#4c0519', highlight: '#fb7185' },
    'midnight': { start: '#090d16', mid: '#1e293b', end: '#020617', highlight: '#475569' },
    'citrus-copper': { start: '#7c2d12', mid: '#c2410c', end: '#431407', highlight: '#fb923c' }
  };

  // Liquid gradients & tints
  const liquidGradients: Record<string, { top: string; mid: string; base: string; opacity: number }> = {
    'london-dry': { top: '#f0f9ff', mid: '#bae6fd', base: '#7dd3fc', opacity: 0.15 },
    'wild-coast': { top: '#0f766e', mid: '#0d9488', base: '#115e59', opacity: 0.8 },
    'heath-blossom': { top: '#f43f5e', mid: '#fb7185', base: '#e11d48', opacity: 0.65 },
    'midnight': { top: '#1e1b4b', mid: '#0f172a', base: '#020617', opacity: 0.92 },
    'citrus-copper': { top: '#f59e0b', mid: '#d97706', base: '#b45309', opacity: 0.78 }
  };

  const cap = capGradients[expression.id] || capGradients['london-dry'];
  const liquid = liquidGradients[expression.id] || liquidGradients['london-dry'];

  return (
    <div
      className="relative flex items-center justify-center select-none"
      style={{ width: dimensions.width, height: dimensions.height }}
    >
      <svg
        width="100%"
        height="100%"
        viewBox="0 0 200 520"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`transition-transform duration-500 ease-out drop-shadow-2xl ${
          isHovered ? 'scale-105 -translate-y-2' : ''
        }`}
      >
        <defs>
          {/* Glass Outer Edge Gradient */}
          <linearGradient id={`glass-edge-${expression.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.45" />
            <stop offset="8%" stopColor="#ffffff" stopOpacity="0.15" />
            <stop offset="50%" stopColor="#ffffff" stopOpacity="0.03" />
            <stop offset="92%" stopColor="#ffffff" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.45" />
          </linearGradient>

          {/* Liquid Tint Gradient */}
          <linearGradient id={`liquid-fill-${expression.id}`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={liquid.top} stopOpacity={liquid.opacity * 0.9} />
            <stop offset="45%" stopColor={liquid.mid} stopOpacity={liquid.opacity} />
            <stop offset="100%" stopColor={liquid.base} stopOpacity={liquid.opacity * 1.1} />
          </linearGradient>

          {/* Cap Metallic Gradient */}
          <linearGradient id={`cap-metal-${expression.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor={cap.start} />
            <stop offset="25%" stopColor={cap.highlight} />
            <stop offset="50%" stopColor={cap.mid} />
            <stop offset="80%" stopColor={cap.start} />
            <stop offset="100%" stopColor={cap.end} />
          </linearGradient>

          {/* Label Background Metallic Tint */}
          <linearGradient id={`label-bg-${expression.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#050a14" stopOpacity="0.88" />
            <stop offset="100%" stopColor="#08101d" stopOpacity="0.94" />
          </linearGradient>

          {/* Heavy Glass Base Reflection */}
          <linearGradient id={`base-glass-${expression.id}`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.1" />
            <stop offset="60%" stopColor="#ffffff" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.6" />
          </linearGradient>
        </defs>

        {/* --- 1. AMBIENT GLOW BEHIND BOTTLE --- */}
        <ellipse
          cx="100"
          cy="360"
          rx={isHovered ? '75' : '55'}
          ry="150"
          fill={expression.hexColor}
          opacity={isHovered ? 0.35 : 0.18}
          className="transition-all duration-700 blur-xl"
        />

        {/* --- 2. BOTTLE SHADOW / BAR SURFACE REFLECTION --- */}
        <ellipse cx="100" cy="510" rx="55" ry="8" fill="#000000" opacity="0.75" />
        <ellipse cx="100" cy="510" rx="40" ry="4" fill={expression.hexColor} opacity="0.3" />

        {/* --- 3. BOTTLE GLASS SILHOUETTE (OCTAGONAL / ARCHITECTURAL) --- */}
        {/* Base to Shoulder Path */}
        <path
          d="M50 495 L40 475 L40 180 L52 145 L85 130 L85 70 L115 70 L115 130 L148 145 L160 180 L160 475 L150 495 Z"
          fill={`url(#liquid-fill-${expression.id})`}
        />

        {/* Extra Thick Crystal Glass Base Plate */}
        <path
          d="M50 495 L40 475 L160 475 L150 495 Z"
          fill={`url(#base-glass-${expression.id})`}
        />
        <line x1="52" y1="482" x2="148" y2="482" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="1" />
        <line x1="60" y1="490" x2="140" y2="490" stroke="#ffffff" strokeOpacity="0.25" strokeWidth="1" />

        {/* Outer Glass Shell & Faceted Edge Reflection */}
        <path
          d="M50 495 L40 475 L40 180 L52 145 L85 130 L85 70 L115 70 L115 130 L148 145 L160 180 L160 475 L150 495 Z"
          fill={`url(#glass-edge-${expression.id})`}
          stroke="rgba(255, 255, 255, 0.3)"
          strokeWidth="1.2"
        />

        {/* Vertical Prismatic Bevel Lines (Left & Right chamfers) */}
        <line x1="54" y1="180" x2="54" y2="475" stroke="#ffffff" strokeOpacity="0.2" strokeWidth="1.5" />
        <line x1="146" y1="180" x2="146" y2="475" stroke="#ffffff" strokeOpacity="0.15" strokeWidth="1.5" />
        
        {/* Left Crystalline Highlight Glare */}
        <path
          d="M44 190 L44 470"
          stroke="#ffffff"
          strokeOpacity="0.4"
          strokeWidth="1.8"
          strokeLinecap="round"
        />

        {/* Right Edge Reflection */}
        <path
          d="M156 190 L156 470"
          stroke="#ffffff"
          strokeOpacity="0.25"
          strokeWidth="1.2"
          strokeLinecap="round"
        />

        {/* --- 4. ARCHITECTURAL LABEL (Engraved Artwork) --- */}
        <g transform="translate(48, 200)">
          {/* Label Container Panel */}
          <rect
            x="0"
            y="0"
            width="104"
            height="230"
            fill={`url(#label-bg-${expression.id})`}
            stroke="rgba(255,255,255,0.18)"
            strokeWidth="0.8"
          />

          {/* Inner Accent Hairline */}
          <rect
            x="3"
            y="3"
            width="98"
            height="224"
            fill="none"
            stroke="rgba(255,255,255,0.08)"
            strokeWidth="0.5"
          />

          {/* NH Monogram Stamp */}
          <g transform="translate(42, 16)">
            <rect x="0" y="0" width="20" height="20" fill="none" stroke="rgba(255,255,255,0.4)" strokeWidth="0.6" />
            <text
              x="10"
              y="14"
              fill="#ffffff"
              fontSize="8"
              fontFamily="serif"
              textAnchor="middle"
              letterSpacing="1"
            >
              NH
            </text>
          </g>

          {/* Brand Name on Label */}
          <text
            x="52"
            y="48"
            fill="#ffffff"
            fontSize="7"
            fontFamily="serif"
            textAnchor="middle"
            letterSpacing="2.5"
            fontWeight="bold"
          >
            NORTHBRIDGE
          </text>
          <text
            x="52"
            y="57"
            fill="#94a3b8"
            fontSize="5.5"
            fontFamily="serif"
            textAnchor="middle"
            letterSpacing="2"
          >
            GIN
          </text>

          {/* Expression-Specific Architectural Vector Art */}
          <g transform="translate(10, 68)">
            {expression.id === 'london-dry' && (
              /* London Skyline & Bridge Cables */
              <svg width="84" height="60" viewBox="0 0 84 60" fill="none">
                <path d="M4 52L20 40L38 48L52 28L68 36L80 52" stroke="#38bdf8" strokeWidth="0.8" strokeOpacity="0.8" />
                <path d="M12 52V30H18V52M42 52V20H48V52M62 52V35H68V52" stroke="#ffffff" strokeWidth="0.6" strokeOpacity="0.5" />
                <path d="M0 52C28 35 56 35 84 52" stroke="#38bdf8" strokeWidth="1" />
                <line x1="20" y1="40" x2="20" y2="52" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="0.5" />
                <line x1="42" y1="36" x2="42" y2="52" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="0.5" />
                <line x1="64" y1="40" x2="64" y2="52" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="0.5" />
              </svg>
            )}

            {expression.id === 'wild-coast' && (
              /* Cornish Ocean Waves & Coastal Cliff lines */
              <svg width="84" height="60" viewBox="0 0 84 60" fill="none">
                <path d="M2 50C15 42 25 45 42 38C58 32 70 36 82 50" stroke="#0d9488" strokeWidth="1.2" />
                <path d="M2 42C18 35 32 40 48 30C62 22 72 28 82 42" stroke="#2dd4bf" strokeWidth="0.8" />
                <path d="M2 34C15 26 28 30 45 22C60 16 70 20 82 34" stroke="#ffffff" strokeOpacity="0.5" strokeWidth="0.6" />
                <path d="M4 18L18 35L24 50" stroke="#5eead4" strokeWidth="0.8" strokeDasharray="1 1" />
              </svg>
            )}

            {expression.id === 'heath-blossom' && (
              /* Yorkshire Moorland Contour Lines & Heather Peaks */
              <svg width="84" height="60" viewBox="0 0 84 60" fill="none">
                <path d="M4 48Q24 20 42 34Q60 48 80 26" stroke="#f43f5e" strokeWidth="1" />
                <path d="M4 40Q30 18 52 30Q68 40 80 20" stroke="#fb7185" strokeWidth="0.8" />
                <circle cx="62" cy="18" r="6" stroke="#f43f5e" strokeOpacity="0.6" strokeWidth="0.8" fill="none" />
                <path d="M12 50L20 42L28 50M50 50L58 38L66 50" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="0.6" />
              </svg>
            )}

            {expression.id === 'midnight' && (
              /* Midnight Moon & Ancient Pine Canopy */
              <svg width="84" height="60" viewBox="0 0 84 60" fill="none">
                <circle cx="42" cy="16" r="8" fill="#ffffff" fillOpacity="0.85" />
                <path d="M8 50L18 32L28 50M24 50L34 26L44 50M40 50L50 24L60 50M56 50L66 30L76 50" stroke="#818cf8" strokeWidth="0.8" />
                <line x1="0" y1="52" x2="84" y2="52" stroke="#6366f1" strokeWidth="1" />
              </svg>
            )}

            {expression.id === 'citrus-copper' && (
              /* Modernist Arched Bridge & Copper Rays */
              <svg width="84" height="60" viewBox="0 0 84 60" fill="none">
                <path d="M2 50C24 16 60 16 82 50" stroke="#f59e0b" strokeWidth="1.4" />
                <path d="M10 50C28 26 56 26 74 50" stroke="#fbbf24" strokeWidth="0.8" />
                <line x1="42" y1="18" x2="42" y2="50" stroke="#ffffff" strokeOpacity="0.6" strokeWidth="0.8" />
                <line x1="28" y1="28" x2="28" y2="50" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="0.6" />
                <line x1="56" y1="28" x2="56" y2="50" stroke="#ffffff" strokeOpacity="0.4" strokeWidth="0.6" />
              </svg>
            )}
          </g>

          {/* Product Name on Label */}
          <text
            x="52"
            y="152"
            fill="#ffffff"
            fontSize="7"
            fontFamily="serif"
            textAnchor="middle"
            letterSpacing="1.8"
            fontWeight="bold"
          >
            {expression.name}
          </text>

          {/* Tagline descriptors on Label */}
          <text
            x="52"
            y="164"
            fill="#94a3b8"
            fontSize="4"
            fontFamily="monospace"
            textAnchor="middle"
            letterSpacing="0.8"
          >
            {expression.tagline}
          </text>

          {/* Volume and ABV */}
          <g transform="translate(14, 204)">
            <text x="0" y="0" fill="#64748b" fontSize="4.5" fontFamily="monospace">
              70cl e
            </text>
            <text x="76" y="0" fill="#64748b" fontSize="4.5" fontFamily="monospace" textAnchor="end">
              41.2% vol
            </text>
          </g>
        </g>

        {/* --- 5. METALLIC NECK & CAP --- */}
        {/* Neck Band / Collar */}
        <rect
          x="83"
          y="68"
          width="34"
          height="12"
          fill={`url(#cap-metal-${expression.id})`}
          stroke="rgba(255,255,255,0.3)"
          strokeWidth="0.5"
        />

        {/* Cap Body (Machined Knurled Metal) */}
        <rect
          x="80"
          y="18"
          width="40"
          height="50"
          rx="2"
          fill={`url(#cap-metal-${expression.id})`}
          stroke="rgba(255,255,255,0.4)"
          strokeWidth="0.8"
        />

        {/* Milled Vertical Knurling Lines on Cap */}
        <g stroke="rgba(255,255,255,0.3)" strokeWidth="0.6">
          <line x1="86" y1="24" x2="86" y2="60" />
          <line x1="92" y1="24" x2="92" y2="60" />
          <line x1="98" y1="24" x2="98" y2="60" />
          <line x1="104" y1="24" x2="104" y2="60" />
          <line x1="110" y1="24" x2="110" y2="60" />
          <line x1="114" y1="24" x2="114" y2="60" />
        </g>

        {/* Cap Top Chamfer */}
        <path
          d="M80 20 L84 14 L116 14 L120 20 Z"
          fill={`url(#cap-metal-${expression.id})`}
          stroke="rgba(255,255,255,0.4)"
          strokeWidth="0.6"
        />

        {/* Monogram on Cap Top */}
        <text
          x="100"
          y="42"
          fill="#ffffff"
          fontSize="7"
          fontFamily="serif"
          textAnchor="middle"
          letterSpacing="1"
        >
          NH
        </text>

        {/* Dynamic Sweep Light on Hover */}
        {isHovered && (
          <path
            d="M50 145 L130 130 L90 495 L40 475 Z"
            fill="url(#sweep-light)"
            opacity="0.25"
            className="animate-pulse pointer-events-none"
          />
        )}
      </svg>
    </div>
  );
}
