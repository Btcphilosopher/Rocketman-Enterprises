'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { SIGNATURE_COCKTAILS } from '@/lib/data';
import { Cocktail } from '@/lib/types';
import { Wine, Sparkles, Check, ChevronRight } from 'lucide-react';

export default function CocktailSection() {
  const [selectedCocktail, setSelectedCocktail] = useState<Cocktail>(SIGNATURE_COCKTAILS[0]);

  return (
    <section id="cocktails" className="relative min-h-screen bg-[#030710] py-24 px-6 md:px-10 border-t border-white/10 overflow-hidden">
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/10 pb-8 mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-[1px] bg-[#d4af37]" />
              <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37]">
                THE MODERNIST BAR ARCHIVE
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-white tracking-tight">
              THE NORTHBRIDGE <span className="italic font-normal">SERVE</span>
            </h2>
          </div>

          <p className="text-xs md:text-sm text-slate-400 font-light max-w-md leading-relaxed">
            Crafted for high-end hospitality and modern mixology. Each ritual is engineered to highlight the volatile botanicals and structural dryness of our five expressions.
          </p>
        </div>

        {/* Main Cocktail Experience Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center mb-16">
          
          {/* Left: Editorial Cocktail Photography Showcase */}
          <div className="lg:col-span-6 relative border border-white/15 bg-[#060c18] overflow-hidden group shadow-2xl">
            <img
              src="/images/cocktail_serve_1790506488610.jpg"
              alt="The Northbridge Serve Editorial Cocktail Photography"
              className="w-full h-[440px] sm:h-[520px] object-cover object-center filter contrast-110 brightness-95 group-hover:scale-103 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-[#040811] via-transparent to-transparent opacity-90" />
            
            <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between text-[10px] font-mono tracking-widest uppercase text-slate-200">
              <div className="flex items-center gap-2">
                <Wine className="w-4 h-4 text-[#d4af37]" />
                <span>GLASSWARE: {selectedCocktail.glassware}</span>
              </div>
              <span className="text-[#38bdf8]">{selectedCocktail.iceType}</span>
            </div>
          </div>

          {/* Right: Selected Cocktail Ritual Recipe Dossier */}
          <div className="lg:col-span-6 space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedCocktail.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="bg-[#070e1b] border border-white/15 p-6 md:p-8 space-y-6 shadow-2xl"
              >
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div>
                    <span className="text-[10px] font-mono tracking-[0.25em] text-[#d4af37] uppercase block">
                      EXPRESSION PAIRING: {selectedCocktail.ginExpression}
                    </span>
                    <h3 className="text-2xl sm:text-3xl font-serif text-white tracking-wide mt-1">
                      {selectedCocktail.name}
                    </h3>
                  </div>
                  <span className="text-xs font-mono text-slate-400">
                    {selectedCocktail.flavorProfile}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-300 font-light leading-relaxed">
                  {selectedCocktail.description}
                </p>

                {/* Ingredients Spec */}
                <div className="space-y-2 border-t border-white/10 pt-4">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">
                    ARCHITECTURAL MEASUREMENTS:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono">
                    {selectedCocktail.ingredients.map((ing) => (
                      <div
                        key={ing.item}
                        className="p-2.5 bg-[#03060d] border border-white/5 flex items-center justify-between"
                      >
                        <span className="text-slate-300">{ing.item}</span>
                        <span className="text-[#38bdf8] font-medium ml-2">{ing.amount}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Step by Step Ritual */}
                <div className="space-y-2 border-t border-white/10 pt-4">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block">
                    SERVICE RITUAL:
                  </span>
                  <ol className="space-y-2 text-xs font-light text-slate-300 list-decimal list-inside leading-relaxed">
                    {selectedCocktail.steps.map((step, idx) => (
                      <li key={idx} className="pl-1">
                        {step}
                      </li>
                    ))}
                  </ol>
                </div>

                {/* Garnish */}
                <div className="flex items-center justify-between text-xs font-mono border-t border-white/5 pt-3 text-slate-400">
                  <span>GARNISH:</span>
                  <span className="text-[#d4af37]">{selectedCocktail.garnish}</span>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

        </div>

        {/* 4 Signature Serve Selectors */}
        <div>
          <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-slate-400 block mb-4">
            SELECT A SIGNATURE SERVE:
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {SIGNATURE_COCKTAILS.map((cocktail) => {
              const isSelected = selectedCocktail.id === cocktail.id;

              return (
                <button
                  key={cocktail.id}
                  onClick={() => setSelectedCocktail(cocktail)}
                  className={`p-5 border text-left transition-all duration-300 flex flex-col justify-between h-44 cursor-pointer ${
                    isSelected
                      ? 'border-[#d4af37] bg-[#0c1626] shadow-xl'
                      : 'border-white/10 bg-[#060c18] hover:border-white/30 hover:bg-[#091120]'
                  }`}
                >
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="text-[9px] font-mono uppercase text-[#d4af37]">
                      {cocktail.ginExpression}
                    </span>
                    {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]" />}
                  </div>

                  <div>
                    <h4 className="font-serif text-base text-white tracking-wide mt-1">
                      {cocktail.name}
                    </h4>
                    <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider truncate mt-0.5">
                      {cocktail.flavorProfile}
                    </p>
                  </div>

                  <div className="text-[9px] font-mono text-slate-500 truncate pt-2 border-t border-white/5">
                    {cocktail.glassware}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
}
