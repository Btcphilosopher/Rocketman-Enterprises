'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GinExpression } from '@/lib/types';
import ThreeBottleViewer from './ThreeBottleViewer';
import { X, ArrowLeft, Plus, Check, ShieldCheck, Sparkles, Sliders } from 'lucide-react';

interface BottleDetailModalProps {
  expression: GinExpression | null;
  onClose: () => void;
  onAddToCart: (expression: GinExpression) => void;
}

export default function BottleDetailModal({ expression, onClose, onAddToCart }: BottleDetailModalProps) {
  const [added, setAdded] = useState(false);
  const [activeTab, setActiveTab] = useState<'tasting' | 'specs' | 'serve'>('tasting');

  if (!expression) return null;

  const handleAdd = () => {
    onAddToCart(expression);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center bg-[#03060d]/95 backdrop-blur-2xl overflow-y-auto p-4 md:p-8"
      >
        {/* Expression Color Ambient Atmosphere in background */}
        <div
          className="absolute inset-0 pointer-events-none opacity-20 blur-3xl"
          style={{
            background: `radial-gradient(circle at 40% 50%, ${expression.hexColor} 0%, transparent 60%)`
          }}
        />

        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="relative w-full max-w-6xl bg-[#060c18] border border-white/15 shadow-2xl overflow-hidden my-auto"
        >
          {/* Top Return & Close Controls */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-[#040811]/90">
            <button
              onClick={onClose}
              className="group flex items-center gap-2 text-xs font-mono tracking-widest text-slate-400 hover:text-white uppercase transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4 transition-transform duration-200 group-hover:-translate-x-1" />
              <span>RETURN TO COLLECTION</span>
            </button>

            <div className="flex items-center gap-3">
              <span className="text-[10px] font-mono tracking-widest text-slate-500 uppercase">
                EXPRESSION {expression.number} / 05
              </span>
              <button
                onClick={onClose}
                className="p-1.5 border border-white/15 hover:border-white/40 text-slate-400 hover:text-white transition-colors cursor-pointer"
                aria-label="Close Modal"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Modal Main Content Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 md:p-10 items-center">
            
            {/* Left Column: Interactive 3D Bottle Canvas */}
            <div className="lg:col-span-6 relative flex flex-col items-center justify-center bg-[#030710]/60 border border-white/5 p-4">
              {/* Monogram watermark */}
              <div className="absolute top-6 left-6 font-serif text-white/5 text-7xl select-none pointer-events-none">
                NH
              </div>

              {/* Real-time 3D Three.js Bottle Viewer */}
              <ThreeBottleViewer expression={expression} />

              <div className="w-full flex items-center justify-between pt-3 border-t border-white/5 text-[9px] font-mono text-slate-500 uppercase tracking-widest">
                <span>MODEL: ARCHITECTURAL FLINT 70CL</span>
                <span>ORIGIN: LONDON &middot; EST. 2031</span>
              </div>
            </div>

            {/* Right Column: Identity, Tasting Profile, Specs, CTA */}
            <div className="lg:col-span-6 space-y-6">
              
              {/* Product Header */}
              <div className="space-y-2 border-b border-white/10 pb-5">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: expression.hexColor }}
                  />
                  <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#d4af37]">
                    NORTHBRIDGE GIN ARCHIVE
                  </span>
                </div>

                <div className="flex flex-wrap items-baseline justify-between gap-4">
                  <h2 className="text-3xl md:text-5xl font-serif text-white tracking-wide">
                    {expression.name}
                  </h2>
                  <div className="text-right">
                    <span className="text-2xl font-mono text-white font-medium">£{expression.price}</span>
                    <span className="text-[10px] text-slate-400 font-mono block">INCL. VAT</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono text-slate-400 pt-1">
                  <span>{expression.abv}</span>
                  <span>&middot;</span>
                  <span>{expression.volume}</span>
                  <span>&middot;</span>
                  <span className="text-slate-300">{expression.tagline}</span>
                </div>
              </div>

              {/* Concept statement */}
              <p className="text-xs md:text-sm text-slate-300 font-light leading-relaxed">
                {expression.concept}
              </p>

              {/* Tab Navigation: Tasting vs Specs vs Perfect Serve */}
              <div className="flex border-b border-white/10 text-xs font-mono">
                <button
                  onClick={() => setActiveTab('tasting')}
                  className={`pb-2.5 px-4 tracking-widest uppercase transition-colors cursor-pointer border-b-2 ${
                    activeTab === 'tasting'
                      ? 'border-[#d4af37] text-white font-medium'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  TASTING PROFILE
                </button>
                <button
                  onClick={() => setActiveTab('specs')}
                  className={`pb-2.5 px-4 tracking-widest uppercase transition-colors cursor-pointer border-b-2 ${
                    activeTab === 'specs'
                      ? 'border-[#d4af37] text-white font-medium'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  DISTILLATION SPECS
                </button>
                <button
                  onClick={() => setActiveTab('serve')}
                  className={`pb-2.5 px-4 tracking-widest uppercase transition-colors cursor-pointer border-b-2 ${
                    activeTab === 'serve'
                      ? 'border-[#d4af37] text-white font-medium'
                      : 'border-transparent text-slate-400 hover:text-slate-200'
                  }`}
                >
                  PERFECT SERVE
                </button>
              </div>

              {/* Tab 1: Tasting Profile (NOSE, PALATE, FINISH) */}
              {activeTab === 'tasting' && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-4"
                >
                  {/* Heritage Botanicals */}
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-widest text-slate-400 block mb-2">
                      BOTANICAL COMPOSITION
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {expression.botanicals.map((botanical) => (
                        <span
                          key={botanical}
                          className="px-3 py-1 bg-white/5 border border-white/15 text-white text-xs font-mono"
                        >
                          {botanical}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Nose, Palate, Finish Breakdown */}
                  <div className="space-y-3 pt-2">
                    <div className="p-3 bg-[#030710] border-l-2 border-[#38bdf8]">
                      <span className="text-[10px] font-mono text-[#38bdf8] uppercase tracking-wider block font-medium">
                        NOSE
                      </span>
                      <p className="text-xs text-slate-300 font-light leading-relaxed mt-0.5">
                        {expression.tastingNotes.nose}
                      </p>
                    </div>

                    <div className="p-3 bg-[#030710] border-l-2 border-[#d4af37]">
                      <span className="text-[10px] font-mono text-[#d4af37] uppercase tracking-wider block font-medium">
                        PALATE
                      </span>
                      <p className="text-xs text-slate-300 font-light leading-relaxed mt-0.5">
                        {expression.tastingNotes.palate}
                      </p>
                    </div>

                    <div className="p-3 bg-[#030710] border-l-2 border-slate-400">
                      <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block font-medium">
                        FINISH
                      </span>
                      <p className="text-xs text-slate-300 font-light leading-relaxed mt-0.5">
                        {expression.tastingNotes.finish}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Tab 2: Technical Distillation Specs */}
              {activeTab === 'specs' && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid grid-cols-2 gap-3 text-xs"
                >
                  <div className="p-3 bg-[#030710] border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">COLUMN STILL</span>
                    <span className="text-white font-mono text-[11px]">{expression.technicalSpecs.stillType}</span>
                  </div>
                  <div className="p-3 bg-[#030710] border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">HEAD PRESSURE</span>
                    <span className="text-[#38bdf8] font-mono text-[11px]">{expression.technicalSpecs.vacuumPressure}</span>
                  </div>
                  <div className="p-3 bg-[#030710] border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">VAPOR EXTRACTION</span>
                    <span className="text-white font-mono text-[11px]">{expression.technicalSpecs.extractionTemp}</span>
                  </div>
                  <div className="p-3 bg-[#030710] border border-white/5 space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">FILTRATION MATRIX</span>
                    <span className="text-slate-300 font-mono text-[11px]">{expression.technicalSpecs.filtration}</span>
                  </div>
                  <div className="p-3 bg-[#030710] border border-white/5 space-y-1 col-span-2">
                    <span className="text-[9px] font-mono text-slate-500 uppercase block">WATER SOURCE TERROIR</span>
                    <span className="text-slate-300 font-mono text-[11px]">{expression.technicalSpecs.waterSource}</span>
                  </div>
                </motion.div>
              )}

              {/* Tab 3: Perfect Serve */}
              {activeTab === 'serve' && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-[#030710] border border-white/10 space-y-3"
                >
                  <span className="text-[10px] font-mono uppercase tracking-widest text-[#d4af37] block">
                    RECOMMENDED RITUAL
                  </span>
                  <p className="text-sm font-serif text-white leading-relaxed">
                    {expression.perfectServe}
                  </p>
                  <p className="text-xs text-slate-400 font-light">
                    Serve in crystal glassware over a single hand-carved directional ice block to maintain temperature without premature dilution.
                  </p>
                </motion.div>
              )}

              {/* Add to Collection Button */}
              <div className="pt-4 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleAdd}
                  className={`flex-1 py-3.5 px-6 text-xs font-mono tracking-[0.2em] uppercase transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-xl ${
                    added
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white hover:bg-slate-100 text-slate-950 font-medium'
                  }`}
                >
                  {added ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>ADDED TO COLLECTION</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      <span>ADD TO COLLECTION &middot; £{expression.price}</span>
                    </>
                  )}
                </button>
              </div>

              {/* Dispatch Guarantee */}
              <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500 pt-2 border-t border-white/5">
                <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
                <span>COMPLIMENTARY UK SIGNED COURIER DELIVERY &middot; SECURE BESPOKE PACKAGING</span>
              </div>

            </div>

          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
