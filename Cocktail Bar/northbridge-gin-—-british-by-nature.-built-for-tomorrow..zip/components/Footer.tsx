'use client';

import React from 'react';

export default function Footer() {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-[#02050b] border-t border-white/10 pt-20 pb-12 px-6 md:px-10 text-white relative overflow-hidden">
      
      {/* Background Subtle Monogram Watermark */}
      <div className="absolute right-12 bottom-12 font-serif text-white/[0.02] text-[180px] pointer-events-none select-none">
        NH
      </div>

      <div className="max-w-7xl mx-auto relative z-10 space-y-16">
        
        {/* Top Massive Brand Statement */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between border-b border-white/10 pb-12 gap-8">
          <div className="space-y-3">
            {/* NH Monogram Stamp */}
            <div className="w-10 h-10 border border-[#d4af37]/60 flex items-center justify-center bg-[#050b14]">
              <span className="font-serif text-[#d4af37] text-sm tracking-widest font-normal">
                NH
              </span>
            </div>

            <h2 className="text-4xl sm:text-6xl md:text-7xl font-serif tracking-[0.15em] text-white font-medium">
              NORTHBRIDGE
            </h2>
            
            <p className="text-xs sm:text-sm font-mono tracking-[0.25em] text-[#d4af37] uppercase">
              BRITISH BY NATURE. BUILT FOR TOMORROW.
            </p>
          </div>

          {/* Understated Minimalist Union Jack Linear Geometry */}
          <div className="flex flex-col items-start lg:items-end gap-3">
            <span className="text-[10px] font-mono tracking-[0.25em] text-slate-500 uppercase">
              GREAT BRITAIN &middot; EST. 2031
            </span>

            {/* Geometric Vector Linear Union Jack */}
            <div className="w-20 h-12 border border-white/20 relative bg-[#040810]/50 p-1 flex items-center justify-center">
              <svg width="100%" height="100%" viewBox="0 0 60 36" fill="none" xmlns="http://www.w3.org/2000/svg">
                {/* Diagonal lines */}
                <line x1="0" y1="0" x2="60" y2="36" stroke="rgba(255,255,255,0.25)" strokeWidth="1" />
                <line x1="60" y1="0" x2="0" y2="36" stroke="rgba(255,255,255,0.25)" strokeWidth="1" />
                {/* Cross */}
                <rect x="27" y="0" width="6" height="36" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="0.8" />
                <rect x="0" y="15" width="60" height="6" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="0.8" />
                <line x1="30" y1="0" x2="30" y2="36" stroke="#d4af37" strokeWidth="0.8" strokeOpacity="0.8" />
                <line x1="0" y1="18" x2="60" y2="18" stroke="#d4af37" strokeWidth="0.8" strokeOpacity="0.8" />
              </svg>
            </div>
          </div>
        </div>

        {/* Navigation & Archival Links */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-8 text-xs font-mono">
          
          <div className="space-y-3">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest block">
              COLLECTIONS
            </span>
            <ul className="space-y-2 text-slate-400">
              <li>
                <a href="#collection" onClick={(e) => handleNavClick(e, '#collection')} className="hover:text-white transition-colors">
                  01 London Dry
                </a>
              </li>
              <li>
                <a href="#collection" onClick={(e) => handleNavClick(e, '#collection')} className="hover:text-white transition-colors">
                  02 Wild Coast
                </a>
              </li>
              <li>
                <a href="#collection" onClick={(e) => handleNavClick(e, '#collection')} className="hover:text-white transition-colors">
                  03 Heath &amp; Blossom
                </a>
              </li>
              <li>
                <a href="#collection" onClick={(e) => handleNavClick(e, '#collection')} className="hover:text-white transition-colors">
                  04 Midnight
                </a>
              </li>
              <li>
                <a href="#collection" onClick={(e) => handleNavClick(e, '#collection')} className="hover:text-white transition-colors">
                  05 Citrus &amp; Copper
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest block">
              EXPERIENCES
            </span>
            <ul className="space-y-2 text-slate-400">
              <li>
                <a href="#botanicals" onClick={(e) => handleNavClick(e, '#botanicals')} className="hover:text-white transition-colors">
                  Botanical Archives
                </a>
              </li>
              <li>
                <a href="#distillery" onClick={(e) => handleNavClick(e, '#distillery')} className="hover:text-white transition-colors">
                  Thameside Distillery
                </a>
              </li>
              <li>
                <a href="#cocktails" onClick={(e) => handleNavClick(e, '#cocktails')} className="hover:text-white transition-colors">
                  The Northbridge Serve
                </a>
              </li>
              <li>
                <a href="#britain" onClick={(e) => handleNavClick(e, '#britain')} className="hover:text-white transition-colors">
                  British Terroir Map
                </a>
              </li>
              <li>
                <a href="#journal" onClick={(e) => handleNavClick(e, '#journal')} className="hover:text-white transition-colors">
                  Editorial Journal
                </a>
              </li>
            </ul>
          </div>

          <div className="space-y-3">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest block">
              DISTILLERY CONTACT
            </span>
            <ul className="space-y-2 text-slate-400">
              <li>Northbridge Flagship Distillers</li>
              <li>South Bank, London SE1 9SG</li>
              <li>United Kingdom</li>
              <li className="pt-2 text-white">allocations@northbridgegin.co.uk</li>
              <li className="text-slate-500">+44 (0)20 7946 0831</li>
            </ul>
          </div>

          <div className="space-y-3">
            <span className="text-[10px] text-slate-500 uppercase tracking-widest block">
              ALLOCATION &amp; COMPLIANCE
            </span>
            <ul className="space-y-2 text-slate-400">
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Responsible Drinking Pledge
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Privacy &amp; Data Security
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Terms of Supply
                </span>
              </li>
              <li>
                <span className="hover:text-white transition-colors cursor-pointer">
                  Cookie Preferences
                </span>
              </li>
            </ul>
          </div>

        </div>

        {/* Legal & Age Notice */}
        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] font-mono text-slate-500">
          <div>
            &copy; 2031&ndash;2032 NORTHBRIDGE SPIRITS CO. LTD. ALL RIGHTS RESERVED. REGISTERED IN ENGLAND &amp; WALES.
          </div>
          <div className="flex items-center gap-4">
            <span>PLEASE DRINK RESPONSIBLY</span>
            <span>&middot;</span>
            <span>BEDRINKAWARE.CO.UK</span>
            <span>&middot;</span>
            <span className="text-slate-400">41.2% ABV</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
