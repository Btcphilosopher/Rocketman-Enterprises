'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GIN_EXPRESSIONS } from '@/lib/data';
import { GinExpression } from '@/lib/types';
import ArchitecturalBottleGraphic from './ArchitecturalBottleGraphic';
import { Plus, Eye, Sparkles, ArrowRight } from 'lucide-react';

interface CollectionSectionProps {
  onSelectBottle: (expressionId: string) => void;
  onAddToCart: (expression: GinExpression) => void;
}

export default function CollectionSection({ onSelectBottle, onAddToCart }: CollectionSectionProps) {
  const [activeHoverId, setActiveHoverId] = useState<string | null>(null);

  return (
    <section
      id="collection"
      className={`relative min-h-screen py-24 px-6 md:px-10 transition-colors duration-700 overflow-hidden ${
        activeHoverId ? 'bg-[#03060d]' : 'bg-[#050b14]'
      }`}
    >
      {/* Dynamic Background Glow matching hovered expression */}
      <AnimatePresence>
        {activeHoverId && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.2 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="absolute inset-0 pointer-events-none blur-3xl"
            style={{
              background: `radial-gradient(circle at 50% 60%, ${
                GIN_EXPRESSIONS.find((g) => g.id === activeHoverId)?.hexColor
              } 0%, transparent 70%)`
            }}
          />
        )}
      </AnimatePresence>

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/10 pb-8 mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-[1px] bg-[#d4af37]" />
              <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37]">
                THE NORTHBRIDGE ARCHIVES
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-serif font-light tracking-tight text-white">
              FIVE EXPRESSIONS. <span className="italic font-normal">ONE VISION.</span>
            </h2>
          </div>

          <p className="text-xs md:text-sm text-slate-400 font-light max-w-md leading-relaxed">
            From the timeless geometric clarity of London Dry to the untamed coastal surge of Wild Coast, each expression captures a distinct landscape of Britain. Refined under low-temperature vacuum science.
          </p>
        </div>

        {/* Desktop 5-Bottle Horizontal Showcase */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 xl:gap-8 items-stretch">
          {GIN_EXPRESSIONS.map((expression) => {
            const isHovered = activeHoverId === expression.id;

            return (
              <div
                key={expression.id}
                onMouseEnter={() => setActiveHoverId(expression.id)}
                onMouseLeave={() => setActiveHoverId(null)}
                className="group relative flex flex-col justify-between p-5 md:p-6 border border-white/10 hover:border-white/40 bg-[#070e1b]/80 hover:bg-[#0a1426]/90 backdrop-blur-xl transition-all duration-500 cursor-pointer overflow-hidden shadow-2xl"
                onClick={() => onSelectBottle(expression.id)}
              >
                {/* Top expression number and color beacon */}
                <div className="flex items-center justify-between mb-4 border-b border-white/5 pb-3">
                  <span className="text-xs font-mono font-medium text-slate-400 group-hover:text-white transition-colors">
                    {expression.number}
                  </span>
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2 h-2 rounded-full transition-transform duration-300 group-hover:scale-125"
                      style={{ backgroundColor: expression.hexColor }}
                    />
                    <span className="text-[9px] font-mono tracking-widest text-slate-500 uppercase">
                      {expression.abv}
                    </span>
                  </div>
                </div>

                {/* Floating Botanical Pills appearing on Hover */}
                <div className="h-10 mb-2 overflow-hidden flex flex-wrap gap-1.5 items-center">
                  <span className="text-[10px] font-mono tracking-wider text-slate-400 uppercase">
                    Botanicals:
                  </span>
                  {expression.botanicals.slice(0, 3).map((botanical) => (
                    <span
                      key={botanical}
                      className={`text-[9px] font-mono px-2 py-0.5 border transition-all duration-300 ${
                        isHovered
                          ? 'border-white/30 text-white bg-white/10'
                          : 'border-white/5 text-slate-500 bg-white/2'
                      }`}
                    >
                      {botanical}
                    </span>
                  ))}
                </div>

                {/* Architectural Center Bottle Graphic with 3D Float/Rotate */}
                <div className="py-4 my-auto flex justify-center relative">
                  <ArchitecturalBottleGraphic
                    expression={expression}
                    isHovered={isHovered}
                    size="md"
                  />
                  
                  {/* Subtle 3D inspect overlay trigger on hover */}
                  <div
                    className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 pointer-events-none ${
                      isHovered ? 'opacity-100' : 'opacity-0'
                    }`}
                  >
                    <div className="px-3 py-1.5 bg-[#050b14]/90 border border-white/30 text-[9px] font-mono tracking-widest uppercase text-white shadow-xl flex items-center gap-1.5 backdrop-blur-md">
                      <Eye className="w-3 h-3 text-[#d4af37]" />
                      <span>INSPECT 3D</span>
                    </div>
                  </div>
                </div>

                {/* Bottle Identity & Pricing Footer */}
                <div className="pt-4 border-t border-white/10 space-y-2">
                  <div className="flex items-baseline justify-between">
                    <h3 className="font-serif text-lg tracking-wider text-white group-hover:text-slate-100 transition-colors">
                      {expression.name}
                    </h3>
                    <span className="font-mono text-sm text-[#d4af37] font-medium">
                      £{expression.price}
                    </span>
                  </div>

                  <p className="text-[10px] font-mono tracking-wider text-slate-400 group-hover:text-slate-300 uppercase transition-colors line-clamp-1">
                    {expression.tagline}
                  </p>

                  <p className="text-[11px] text-slate-400 font-light line-clamp-2 leading-relaxed pt-1">
                    {expression.tastingNotes.nose}
                  </p>

                  {/* Actions: View in 3D & Quick Add to Bag */}
                  <div className="pt-3 flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onAddToCart(expression);
                      }}
                      className="flex-1 py-2 px-2.5 bg-white/10 hover:bg-white text-white hover:text-slate-950 border border-white/20 text-[9px] font-mono tracking-widest uppercase transition-all duration-200 cursor-pointer text-center"
                    >
                      ADD TO BAG
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectBottle(expression.id);
                      }}
                      className="p-2 border border-white/20 hover:border-white/50 text-slate-300 hover:text-white transition-colors cursor-pointer"
                      title="Inspect 3D Experience"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Reference Image Tribute: Bottom 5 Landscape & Botanical Specimen Panels */}
        <div className="mt-16 pt-12 border-t border-white/10">
          <div className="flex items-center justify-between mb-8">
            <span className="text-[10px] uppercase font-mono tracking-[0.25em] text-slate-400">
              BRITISH TERROIR & BOTANICAL CORRELATION
            </span>
            <span className="text-[10px] font-mono tracking-widest text-[#d4af37]">
              ARCHIVAL SPECIMEN SUITE
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            {GIN_EXPRESSIONS.map((expression) => (
              <div
                key={`panel-${expression.id}`}
                onClick={() => onSelectBottle(expression.id)}
                className="p-4 border border-white/10 bg-[#060c18] hover:border-white/30 transition-all duration-300 flex flex-col justify-between h-56 cursor-pointer group"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[9px] font-mono text-slate-500">EXPRESSION {expression.number}</span>
                    <span className="text-[9px] font-mono tracking-wider" style={{ color: expression.hexColor }}>
                      {expression.abv}
                    </span>
                  </div>
                  <h4 className="font-serif text-sm text-white tracking-wide group-hover:text-[#d4af37] transition-colors">
                    {expression.name}
                  </h4>
                  <p className="text-[9px] font-mono text-slate-400 uppercase tracking-wider mb-3">
                    {expression.tagline}
                  </p>
                </div>

                <div className="space-y-1.5 border-t border-white/5 pt-2">
                  <div className="text-[9px] text-slate-400 font-mono tracking-wider">HERITAGE BOTANICALS:</div>
                  <div className="flex flex-wrap gap-1">
                    {expression.botanicals.map((b) => (
                      <span key={b} className="text-[9px] text-slate-300 font-mono">
                        {b}&middot;
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-white/5 flex items-center justify-between text-[9px] font-mono text-slate-500 group-hover:text-white transition-colors">
                  <span>DISCOVER SPECIFICATION</span>
                  <span>→</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
