'use client';

import React from 'react';

export default function BrandBar() {
  return (
    <div className="w-full bg-[#03060d] border-y border-white/10 py-5 px-6 md:px-10 overflow-hidden">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6">
        {/* Left: British mountain / highland contour sketch */}
        <div className="hidden md:flex items-center gap-3 opacity-60">
          <svg
            width="120"
            height="24"
            viewBox="0 0 120 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="stroke-[#d4af37]/60"
          >
            <path
              d="M1 22L24 14L42 18L64 4L82 12L96 8L119 22"
              strokeWidth="1.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <span className="text-[9px] font-mono tracking-[0.25em] uppercase text-slate-500">
            HIGHLANDS &middot; MOORS
          </span>
        </div>

        {/* Center: Brand Philosophy Axiom */}
        <div className="flex-1 flex items-center justify-center gap-4 text-center">
          <span className="text-[10px] md:text-xs font-mono tracking-[0.28em] uppercase text-slate-300">
            BRITISH BOTANICALS
          </span>
          <span className="text-slate-600 font-mono">/</span>
          <span className="text-[10px] md:text-xs font-mono tracking-[0.28em] uppercase text-white font-medium">
            MODERN DISTILLATION
          </span>
          <span className="text-slate-600 font-mono">/</span>
          <span className="text-[10px] md:text-xs font-mono tracking-[0.28em] uppercase text-slate-300">
            A HIGHER STANDARD
          </span>
        </div>

        {/* Right: London architectural skyline contour sketch */}
        <div className="hidden md:flex items-center gap-3 opacity-60">
          <span className="text-[9px] font-mono tracking-[0.25em] uppercase text-slate-500">
            LONDON METROPOLIS
          </span>
          <svg
            width="120"
            height="24"
            viewBox="0 0 120 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="stroke-[#38bdf8]/60"
          >
            <path
              d="M1 22H18V12H28V7L34 2L40 7V22H52V14H62V9H72V22H84V5L92 12V22H119"
              strokeWidth="1.2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
