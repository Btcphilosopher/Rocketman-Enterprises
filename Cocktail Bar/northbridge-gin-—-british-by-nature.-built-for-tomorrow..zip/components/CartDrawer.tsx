'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem } from '@/lib/types';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}: CartDrawerProps) {
  const [isCheckingOut, setIsCheckingOut] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [giftNote, setGiftNote] = useState('');

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal > 0 ? 0 : 0; // Complimentary
  const total = subtotal + shipping;

  const handleCheckout = (e: React.FormEvent) => {
    e.preventDefault();
    setIsCheckingOut(false);
    setOrderNumber(`NB-${Math.floor(100000 + Math.random() * 900000)}`);
    setOrderComplete(true);
  };

  const handleReset = () => {
    setOrderComplete(false);
    setOrderNumber('');
    onClearCart();
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-[#03060d]/80 backdrop-blur-md cursor-pointer"
          />

          {/* Drawer Slide-over Panel */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 30, stiffness: 300 }}
            className="relative z-10 w-full max-w-md bg-[#050b14] border-l border-white/10 h-full flex flex-col justify-between shadow-2xl p-6 sm:p-8"
          >
            {/* Top Bar */}
            <div className="flex items-center justify-between border-b border-white/10 pb-4">
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
                <h3 className="font-serif text-lg text-white tracking-wider">YOUR COLLECTION BAG</h3>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 border border-white/10 hover:border-white/40 text-slate-400 hover:text-white transition-colors cursor-pointer"
                aria-label="Close Shopping Bag"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Content Area */}
            {orderComplete ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 py-8">
                <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h4 className="text-2xl font-serif text-white">ORDER CONFIRMED</h4>
                <p className="text-xs font-mono text-[#d4af37]">
                  ORDER NUMBER: {orderNumber}
                </p>
                <p className="text-xs text-slate-400 font-light leading-relaxed max-w-xs">
                  Thank you for securing your allocation of Northbridge Gin. Your order has been dispatched to our London archive for white-glove packing.
                </p>
                <button
                  onClick={handleReset}
                  className="mt-4 px-6 py-3 bg-white text-slate-950 font-mono text-xs uppercase tracking-widest hover:bg-slate-200 transition-colors cursor-pointer"
                >
                  RETURN TO FLAGSHIP
                </button>
              </div>
            ) : items.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 py-12">
                <div className="w-12 h-12 border border-white/10 flex items-center justify-center text-slate-600">
                  <ShoppingBag className="w-6 h-6" />
                </div>
                <p className="text-sm font-serif text-slate-400">Your collection bag is currently empty.</p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 border border-white/20 text-xs font-mono text-white tracking-widest uppercase hover:bg-white/10 transition-colors cursor-pointer"
                >
                  EXPLORE ARCHIVE
                </button>
              </div>
            ) : isCheckingOut ? (
              <form onSubmit={handleCheckout} className="flex-1 overflow-y-auto py-6 space-y-4 text-xs font-mono">
                <div className="border-b border-white/10 pb-2 text-slate-300 font-medium uppercase tracking-wider">
                  DELIVERY &amp; ALLOCATION DISPATCH
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 block text-[10px]">RECIPIENT EMAIL</label>
                  <input
                    type="email"
                    required
                    placeholder="name@example.co.uk"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full p-2.5 bg-[#03060c] border border-white/15 text-white focus:outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 block text-[10px]">DELIVERY ADDRESS (UK)</label>
                  <input
                    type="text"
                    required
                    placeholder="Street, City, Postal Code"
                    className="w-full p-2.5 bg-[#03060c] border border-white/15 text-white focus:outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 block text-[10px]">BESPOKE GIFT NOTE (OPTIONAL)</label>
                  <textarea
                    rows={3}
                    placeholder="Handwritten on midnight parchment with brass wax seal..."
                    value={giftNote}
                    onChange={(e) => setGiftNote(e.target.value)}
                    className="w-full p-2.5 bg-[#03060c] border border-white/15 text-white focus:outline-none focus:border-[#d4af37] resize-none"
                  />
                </div>

                <div className="p-3 bg-[#030710] border border-white/10 space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>ALLOCATION TOTAL:</span>
                    <span className="text-white font-medium">£{total}</span>
                  </div>
                  <div className="text-[10px] text-emerald-400">
                    COMPLIMENTARY SECURE CARBON-NEUTRAL COURIER
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsCheckingOut(false)}
                    className="w-1/3 py-3 border border-white/20 text-slate-300 hover:text-white uppercase tracking-widest text-[10px] cursor-pointer"
                  >
                    BACK
                  </button>
                  <button
                    type="submit"
                    className="w-2/3 py-3 bg-white hover:bg-slate-100 text-slate-950 uppercase tracking-widest text-[10px] font-medium cursor-pointer shadow-lg"
                  >
                    CONFIRM &amp; DISPATCH
                  </button>
                </div>
              </form>
            ) : (
              <div className="flex-1 overflow-y-auto py-4 space-y-4">
                {items.map((item) => (
                  <div
                    key={item.id}
                    className="p-3.5 bg-[#070e1b] border border-white/10 flex items-center justify-between gap-3"
                  >
                    <div className="flex-1 space-y-1">
                      <h4 className="font-serif text-sm text-white tracking-wide">{item.name}</h4>
                      <div className="text-[10px] font-mono text-slate-400 flex items-center gap-2">
                        <span>{item.volume}</span>
                        {item.isGiftBox && <span className="text-[#d4af37]">&middot; Gift Box</span>}
                      </div>
                      <div className="text-xs font-mono text-white font-medium">
                        £{item.price * item.quantity}
                      </div>
                    </div>

                    {/* Quantity controls */}
                    <div className="flex items-center gap-2 border border-white/15 px-2 py-1 bg-[#040811]">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="text-slate-400 hover:text-white cursor-pointer"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-mono text-white w-4 text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="text-slate-400 hover:text-white cursor-pointer"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1 text-slate-500 hover:text-red-400 transition-colors cursor-pointer"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Bottom Checkout Summary */}
            {!orderComplete && items.length > 0 && !isCheckingOut && (
              <div className="border-t border-white/10 pt-4 space-y-3">
                <div className="space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between text-slate-400">
                    <span>SUBTOTAL</span>
                    <span className="text-white">£{subtotal}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>UK SIGNED DISPATCH</span>
                    <span className="text-emerald-400 uppercase font-medium">COMPLIMENTARY</span>
                  </div>
                  <div className="flex justify-between text-base font-serif text-white pt-2 border-t border-white/5">
                    <span>TOTAL</span>
                    <span className="font-mono font-medium">£{total}</span>
                  </div>
                </div>

                <button
                  onClick={() => setIsCheckingOut(true)}
                  className="w-full py-3.5 bg-white hover:bg-slate-100 text-slate-950 text-xs font-mono tracking-[0.2em] uppercase font-medium transition-all duration-200 cursor-pointer shadow-xl flex items-center justify-center gap-2"
                >
                  <span>PROCEED TO ALLOCATION</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="flex items-center justify-center gap-2 text-[9px] font-mono text-slate-500">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>256-BIT ENCRYPTED &middot; BRITISH CRAFT GUARANTEE</span>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
