'use client';

import React, { useRef, useEffect, useState } from 'react';
import * as THREE from 'three';
import { GinExpression } from '@/lib/types';
import { RotateCcw, Play, Pause, ZoomIn, ZoomOut } from 'lucide-react';

interface ThreeBottleViewerProps {
  expression: GinExpression;
}

export default function ThreeBottleViewer({ expression }: ThreeBottleViewerProps) {
  const mountRef = useRef<HTMLDivElement>(null);
  const [isRotating, setIsRotating] = useState(true);
  const [zoomLevel, setZoomLevel] = useState(1);
  const rotationRef = useRef<boolean>(true);

  useEffect(() => {
    rotationRef.current = isRotating;
  }, [isRotating]);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Dimensions
    const width = container.clientWidth || 400;
    const height = container.clientHeight || 500;

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(40, width / height, 0.1, 100);
    camera.position.set(0, 0, 8.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.3;
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Group for the entire bottle assembly
    const bottleGroup = new THREE.Group();
    scene.add(bottleGroup);

    // Lighting Setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.2);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xffffff, 2.5);
    keyLight.position.set(5, 8, 6);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0xffffff, 3.0);
    rimLight.position.set(-6, 4, -4);
    scene.add(rimLight);

    const colorAccentLight = new THREE.PointLight(expression.hexColor, 3.5, 12);
    colorAccentLight.position.set(0, -1, 3);
    scene.add(colorAccentLight);

    // Materials
    // Liquid Color Material
    const liquidColor = new THREE.Color(expression.hexColor);
    const isLondonDry = expression.id === 'london-dry';
    
    const liquidMaterial = new THREE.MeshPhysicalMaterial({
      color: isLondonDry ? 0xe0f2fe : liquidColor,
      transmission: isLondonDry ? 0.95 : 0.65,
      opacity: 1,
      transparent: true,
      roughness: 0.1,
      ior: 1.33,
      metalness: 0.05,
      clearcoat: 1.0,
      clearcoatRoughness: 0.05
    });

    // Glass Outer Shell Material
    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transmission: 0.96,
      opacity: 1,
      transparent: true,
      roughness: 0.04,
      ior: 1.52,
      thickness: 0.5,
      clearcoat: 1.0,
      clearcoatRoughness: 0.02
    });

    // Metallic Cap Material
    let capColor = 0xc0c0c0; // silver default
    let capRoughness = 0.25;
    let capMetalness = 0.95;

    if (expression.id === 'wild-coast') {
      capColor = 0xd4af37; // brass/gold
    } else if (expression.id === 'heath-blossom') {
      capColor = 0xe07a5f; // rose copper
    } else if (expression.id === 'midnight') {
      capColor = 0x1e293b; // dlc black
      capRoughness = 0.4;
    } else if (expression.id === 'citrus-copper') {
      capColor = 0xb45309; // bright copper
    }

    const capMaterial = new THREE.MeshStandardMaterial({
      color: capColor,
      roughness: capRoughness,
      metalness: capMetalness
    });

    // 1. Heavy Octagonal Glass Base & Body
    // Using an 8-sided cylinder geometry to replicate the architectural bottle
    const bodyGeometry = new THREE.CylinderGeometry(1.2, 1.25, 3.8, 8);
    const bodyMesh = new THREE.Mesh(bodyGeometry, glassMaterial);
    bodyMesh.position.y = 0;
    bottleGroup.add(bodyMesh);

    // 2. Liquid Core Mesh inside bottle
    const liquidGeometry = new THREE.CylinderGeometry(1.08, 1.12, 3.2, 8);
    const liquidMesh = new THREE.Mesh(liquidGeometry, liquidMaterial);
    liquidMesh.position.y = -0.15;
    bottleGroup.add(liquidMesh);

    // 3. Heavy Glass Base Plug (low center of gravity)
    const baseGeometry = new THREE.CylinderGeometry(1.22, 1.28, 0.5, 8);
    const baseMesh = new THREE.Mesh(baseGeometry, glassMaterial);
    baseMesh.position.y = -2.1;
    bottleGroup.add(baseMesh);

    // 4. Sloping Architectural Shoulders
    const shoulderGeometry = new THREE.CylinderGeometry(0.48, 1.2, 0.7, 8);
    const shoulderMesh = new THREE.Mesh(shoulderGeometry, glassMaterial);
    shoulderMesh.position.y = 2.25;
    bottleGroup.add(shoulderMesh);

    // 5. Glass Neck
    const neckGeometry = new THREE.CylinderGeometry(0.46, 0.48, 0.9, 16);
    const neckMesh = new THREE.Mesh(neckGeometry, glassMaterial);
    neckMesh.position.y = 2.95;
    bottleGroup.add(neckMesh);

    // 6. Metallic Collar
    const collarGeometry = new THREE.CylinderGeometry(0.5, 0.5, 0.25, 16);
    const collarMesh = new THREE.Mesh(collarGeometry, capMaterial);
    collarMesh.position.y = 2.75;
    bottleGroup.add(collarMesh);

    // 7. Milled Metallic Knurled Cap
    const capGeometry = new THREE.CylinderGeometry(0.54, 0.54, 0.85, 24);
    const capMesh = new THREE.Mesh(capGeometry, capMaterial);
    capMesh.position.y = 3.4;
    bottleGroup.add(capMesh);

    // 8. Dynamic Label Creation on HTML5 Canvas Texture
    const labelCanvas = document.createElement('canvas');
    labelCanvas.width = 512;
    labelCanvas.height = 768;
    const ctx = labelCanvas.getContext('2d');
    if (ctx) {
      // Label Background
      ctx.fillStyle = '#060c18';
      ctx.fillRect(0, 0, 512, 768);

      // Border & Hairlines
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 4;
      ctx.strokeRect(16, 16, 480, 736);

      ctx.strokeStyle = 'rgba(255,255,255,0.3)';
      ctx.lineWidth = 2;
      ctx.strokeRect(32, 32, 448, 704);

      // Monogram Box
      ctx.strokeRect(226, 60, 60, 60);
      ctx.font = '32px serif';
      ctx.fillStyle = '#ffffff';
      ctx.textAlign = 'center';
      ctx.fillText('NH', 256, 102);

      // Brand Wordmark
      ctx.font = '32px serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText('NORTHBRIDGE', 256, 175);

      ctx.font = '22px serif';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('GIN', 256, 210);

      // Accent Artwork Line
      ctx.strokeStyle = expression.hexColor;
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(80, 250);
      ctx.lineTo(432, 250);
      ctx.stroke();

      // Expression Name
      ctx.font = 'bold 36px serif';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(expression.name, 256, 320);

      // Tagline
      ctx.font = '16px monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText(expression.tagline, 256, 360);

      // Heritage Botanicals
      ctx.font = '18px monospace';
      ctx.fillStyle = '#cbd5e1';
      ctx.fillText(expression.botanicals.join('  •  '), 256, 440);

      // Architectural line drawing
      ctx.strokeStyle = 'rgba(255,255,255,0.4)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(120, 520);
      ctx.lineTo(256, 470);
      ctx.lineTo(392, 520);
      ctx.stroke();

      // ABV & Vol
      ctx.font = '20px monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.fillText('70cl e                 41.2% vol', 256, 660);
    }

    const labelTexture = new THREE.CanvasTexture(labelCanvas);
    const labelMaterial = new THREE.MeshBasicMaterial({
      map: labelTexture,
      transparent: true,
      opacity: 0.95
    });

    const labelGeometry = new THREE.PlaneGeometry(1.6, 2.4);
    const labelMesh = new THREE.Mesh(labelGeometry, labelMaterial);
    labelMesh.position.set(0, -0.05, 1.22);
    bottleGroup.add(labelMesh);

    // Initial orientation
    bottleGroup.position.y = -0.3;

    // Mouse Interaction for 3D Drag
    let isDragging = false;
    let previousMousePosition = { x: 0, y: 0 };

    const onMouseDown = (e: MouseEvent) => {
      isDragging = true;
      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging) return;
      const deltaX = e.clientX - previousMousePosition.x;
      const deltaY = e.clientY - previousMousePosition.y;

      bottleGroup.rotation.y += deltaX * 0.008;
      bottleGroup.rotation.x = Math.max(-0.4, Math.min(0.4, bottleGroup.rotation.x + deltaY * 0.005));

      previousMousePosition = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging = false;
    };

    // Touch support for mobile
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging = true;
        previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging || e.touches.length !== 1) return;
      const deltaX = e.touches[0].clientX - previousMousePosition.x;
      bottleGroup.rotation.y += deltaX * 0.01;
      previousMousePosition = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    };

    const onTouchEnd = () => {
      isDragging = false;
    };

    const dom = renderer.domElement;
    dom.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    dom.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    // Animation Loop
    let animationFrameId: number;
    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (rotationRef.current && !isDragging) {
        bottleGroup.rotation.y += 0.006;
      }

      renderer.render(scene, camera);
    };

    animate();

    // Handle Resize
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationFrameId);
      dom.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      dom.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      window.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      scene.clear();
    };
  }, [expression]);

  const resetRotation = () => {
    setIsRotating(true);
  };

  return (
    <div className="relative w-full h-[380px] sm:h-[480px] md:h-[540px] flex items-center justify-center select-none overflow-hidden">
      {/* 3D WebGL Canvas Container */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Floating 3D Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between pointer-events-none">
        <div className="flex items-center gap-2 pointer-events-auto">
          <button
            onClick={() => setIsRotating(!isRotating)}
            className="p-2.5 bg-[#050b14]/80 hover:bg-[#0c1626] border border-white/20 text-white text-xs font-mono transition-colors flex items-center gap-1.5 backdrop-blur-md cursor-pointer"
            title={isRotating ? 'Pause Rotation' : 'Resume Auto Spin'}
          >
            {isRotating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span className="text-[10px] uppercase tracking-widest hidden sm:inline">
              {isRotating ? 'PAUSE' : 'AUTO-SPIN'}
            </span>
          </button>

          <button
            onClick={resetRotation}
            className="p-2.5 bg-[#050b14]/80 hover:bg-[#0c1626] border border-white/20 text-white text-xs transition-colors backdrop-blur-md cursor-pointer"
            title="Reset Orientation"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="px-3 py-1.5 bg-[#050b14]/80 border border-white/10 text-[9px] font-mono tracking-widest text-slate-400 backdrop-blur-md uppercase">
          DRAG TO ROTATE 360°
        </div>
      </div>
    </div>
  );
}
