'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { GIN_EXPRESSIONS } from '@/lib/data';
import { GinExpression, CartItem } from '@/lib/types';
import ArchitecturalBottleGraphic from './ArchitecturalBottleGraphic';
import { ShoppingBag, Gift, ShieldCheck, Check, Sparkles, Plus } from 'lucide-react';

interface ShopSectionProps {
  onAddToCart: (expression: GinExpression, isGiftBox?: boolean) => void;
  onAddCompleteCollection: () => void;
  onSelectBottle: (expressionId: string) => void;
}

export default function ShopSection({
  onAddToCart,
  onAddCompleteCollection,
  onSelectBottle
}: ShopSectionProps) {
  const [giftBoxToggles, setGiftBoxToggles] = useState<Record<string, boolean>>({});
  const [justAddedId, setJustAddedId] = useState<string | null>(null);

  const toggleGift = (id: string) => {
    setGiftBoxToggles((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const handleAdd = (expression: GinExpression) => {
    const isGift = !!giftBoxToggles[expression.id];
    onAddToCart(expression, isGift);
    setJustAddedId(expression.id);
    setTimeout(() => setJustAddedId(null), 1800);
  };

  return (
    <section id="shop" className="relative min-h-screen bg-[#03060c] py-24 px-6 md:px-10 border-t border-white/10 overflow-hidden">
      
      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/10 pb-8 mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-2 h-[1px] bg-[#d4af37]" />
              <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#d4af37]">
                THE DIGITAL FLAGSHIP BOUTIQUE
              </span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-light text-white tracking-tight">
              BOTTLED <span className="italic font-normal">EXPRESSIONS</span>
            </h2>
          </div>

          <div className="text-xs font-mono text-slate-400 space-y-1">
            <div className="text-white">COMPLIMENTARY UK DIRECT DISPATCH</div>
            <div>ORDERS PLACED BEFORE 14:00 DISPATCH NEXT BUSINESS DAY</div>
          </div>
        </div>

        {/* The 5 Individual Bottles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-16">
          {GIN_EXPRESSIONS.map((expression) => {
            const isGift = !!giftBoxToggles[expression.id];
            const isAdded = justAddedId === expression.id;

            return (
              <div
                key={expression.id}
                className="bg-[#060c18] border border-white/10 hover:border-white/35 transition-all duration-300 p-5 flex flex-col justify-between group shadow-xl relative"
              >
                {/* Top expression meta */}
                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <span className="text-[10px] font-mono text-slate-400 font-medium">
                    {expression.number} &middot; {expression.abv}
                  </span>
                  <span className="text-base font-mono text-white font-medium">
                    £{expression.price}
                  </span>
                </div>

                {/* Bottle Presentation with 3D Graphic */}
                <div
                  onClick={() => onSelectBottle(expression.id)}
                  className="py-4 my-2 flex justify-center cursor-pointer relative"
                  title="Click to view in 3D"
                >
                  <ArchitecturalBottleGraphic
                    expression={expression}
                    isHovered={false}
                    size="sm"
                  />
                </div>

                {/* Details */}
                <div className="space-y-2 pt-2 border-t border-white/10">
                  <div className="flex items-baseline justify-between">
                    <h3
                      onClick={() => onSelectBottle(expression.id)}
                      className="font-serif text-base text-white group-hover:text-slate-200 transition-colors cursor-pointer"
                    >
                      {expression.name}
                    </h3>
                    <span className="text-[9px] font-mono text-slate-400">{expression.volume}</span>
                  </div>

                  <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wider truncate">
                    {expression.tagline}
                  </p>

                  <p className="text-[11px] text-slate-400 font-light line-clamp-2 leading-relaxed">
                    {expression.tastingNotes.nose}
                  </p>

                  {/* Gift Presentation Checkbox */}
                  <label className="flex items-center gap-2 text-[10px] font-mono text-slate-300 cursor-pointer pt-1 select-none">
                    <input
                      type="checkbox"
                      checked={isGift}
                      onChange={() => toggleGift(expression.id)}
                      className="accent-[#d4af37]"
                    />
                    <Gift className="w-3 h-3 text-[#d4af37]" />
                    <span>Include Navy Gift Box</span>
                  </label>

                  {/* Add to Bag CTA */}
                  <div className="pt-2">
                    <button
                      onClick={() => handleAdd(expression)}
                      className={`w-full py-2.5 px-3 text-[10px] font-mono tracking-widest uppercase transition-all duration-200 flex items-center justify-center gap-1.5 cursor-pointer shadow-lg ${
                        isAdded
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white hover:bg-slate-200 text-slate-950 font-medium'
                      }`}
                    >
                      {isAdded ? (
                        <>
                          <Check className="w-3 h-3" />
                          <span>IN BAG</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3 h-3 text-slate-900" />
                          <span>ADD TO BAG &middot; £{expression.price}</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Master Box: The Complete Collection (Special Architectural Presentation Case) */}
        <div className="bg-[#070e1d] border border-[#d4af37]/40 p-8 md:p-12 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#d4af37]/10 border border-[#d4af37]/30 text-[10px] font-mono tracking-[0.25em] text-[#d4af37] uppercase">
                <Sparkles className="w-3 h-3 text-[#d4af37]" />
                FLAGSHIP PRESENTATION &middot; LIMITED COHORT
              </div>

              <h3 className="text-3xl sm:text-5xl font-serif text-white tracking-wide">
                THE COMPLETE COLLECTION
              </h3>

              <p className="text-sm font-serif italic text-slate-300">
                Five 70cl architectural bottles housed in a solid blackened-oak and brushed brass collector&apos;s presentation case.
              </p>

              <p className="text-xs sm:text-sm text-slate-400 font-light leading-relaxed max-w-2xl">
                Contains London Dry, Wild Coast, Heath &amp; Blossom, Midnight, and Citrus &amp; Copper. Includes an individually numbered laser-engraved brass certificate of origin, five crystal tasting copas, and a leather-bound tasting journal from Master Distiller Dr. Clara Sterling.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs font-mono text-slate-300">
                <div className="p-3 bg-[#03060c] border border-white/5">
                  <span className="text-[9px] text-slate-500 uppercase block">VOLUME</span>
                  <span>5 &times; 70cl (3.5L)</span>
                </div>
                <div className="p-3 bg-[#03060c] border border-white/5">
                  <span className="text-[9px] text-slate-500 uppercase block">ALCOHOL</span>
                  <span>41.2% ABV</span>
                </div>
                <div className="p-3 bg-[#03060c] border border-white/5">
                  <span className="text-[9px] text-slate-500 uppercase block">PRESENTATION</span>
                  <span>Blackened Oak Plinth</span>
                </div>
                <div className="p-3 bg-[#03060c] border border-white/5">
                  <span className="text-[9px] text-slate-500 uppercase block">EDITION</span>
                  <span>Laser Serialized</span>
                </div>
              </div>
            </div>

            <div className="lg:col-span-4 flex flex-col items-center lg:items-end justify-between space-y-6">
              <div className="text-center lg:text-right">
                <div className="text-4xl sm:text-5xl font-mono text-white font-medium">£245</div>
                <span className="text-xs font-mono text-[#d4af37] block mt-1">
                  SAVE £27 VS INDIVIDUAL BOTTLES
                </span>
                <span className="text-[10px] font-mono text-slate-500 block">
                  FREE WHITE-GLOVE COURIER DISPATCH
                </span>
              </div>

              <button
                onClick={onAddCompleteCollection}
                className="w-full py-4 px-8 bg-white hover:bg-slate-100 text-slate-950 text-xs font-medium font-mono tracking-[0.2em] uppercase transition-all duration-300 cursor-pointer shadow-2xl flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4 text-slate-900" />
                <span>ACQUIRE COMPLETE SUITE</span>
              </button>
            </div>

          </div>
        </div>

        {/* Customer Experience Guarantees */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 pt-12 border-t border-white/10 text-xs font-mono text-slate-400">
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
            <div>
              <span className="text-white block font-medium">CARBON NEUTRAL DISPATCH</span>
              <span>All orders packed in 100% recyclable sculpted pulp packaging with tamper-evident seal.</span>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Gift className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
            <div>
              <span className="text-white block font-medium">BESPOKE GIFT SERVICE</span>
              <span>Complimentary handwritten calligraphic message card included upon request.</span>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <Sparkles className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
            <div>
              <span className="text-white block font-medium">AUTHENTICITY GUARANTEE</span>
              <span>Each bottle verified and serialized directly from our London distillery archive.</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
