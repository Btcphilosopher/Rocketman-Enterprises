'use client';

import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, ArrowUpRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onSelectNav?: (sectionId: string) => void;
}

export default function Header({ cartCount, onOpenCart, onSelectNav }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'COLLECTION', href: '#collection' },
    { label: 'BOTANICALS', href: '#botanicals' },
    { label: 'DISTILLERY', href: '#distillery' },
    { label: 'COCKTAILS', href: '#cocktails' },
    { label: 'OUR BRITAIN', href: '#britain' },
    { label: 'JOURNAL', href: '#journal' },
    { label: 'SHOP', href: '#shop' }
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
    if (onSelectNav) {
      onSelectNav(href.replace('#', ''));
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
          scrolled
            ? 'bg-[#050b14]/90 backdrop-blur-md border-b border-white/10 shadow-2xl py-3.5'
            : 'bg-transparent border-b border-white/5 py-6'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-10 flex items-center justify-between">
          {/* Left: Brand Monogram and Wordmark */}
          <a
            href="#hero"
            onClick={(e) => handleNavClick(e, '#hero')}
            className="group flex items-center gap-3.5"
          >
            {/* NH Monogram */}
            <div className="w-8 h-8 border border-white/30 group-hover:border-[#d4af37] flex items-center justify-center transition-colors duration-300 bg-[#050b14]/40 backdrop-blur-sm">
              <span className="font-serif text-[11px] text-white/90 group-hover:text-[#d4af37] tracking-widest font-normal">
                NH
              </span>
            </div>
            <div className="flex flex-col">
              <span className="text-sm md:text-base font-serif tracking-[0.25em] text-white font-medium group-hover:text-slate-100 transition-colors">
                NORTHBRIDGE
              </span>
              <span className="text-[8px] tracking-[0.35em] text-slate-400 uppercase font-mono">
                GIN &middot; LONDON
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className="text-[11px] tracking-[0.2em] font-medium text-slate-300 hover:text-white transition-colors relative py-1 group"
              >
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#d4af37] transition-all duration-300 group-hover:w-full" />
              </a>
            ))}
          </nav>

          {/* Right Action: Shopping Bag & Mobile Hamburger */}
          <div className="flex items-center gap-4">
            <button
              onClick={onOpenCart}
              className="group relative flex items-center gap-2.5 px-3.5 py-2 border border-white/20 hover:border-white/50 bg-[#08101d]/60 hover:bg-[#0c1626] transition-all duration-200 cursor-pointer"
              aria-label="Open Shopping Bag"
            >
              <ShoppingBag className="w-3.5 h-3.5 text-slate-300 group-hover:text-white transition-colors" />
              <span className="text-[11px] font-mono tracking-widest text-slate-200 uppercase">
                BAG
              </span>
              {cartCount > 0 && (
                <span className="ml-1 px-1.5 py-0.2 bg-[#d4af37] text-slate-950 text-[10px] font-mono font-bold">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-300 hover:text-white focus:outline-none"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Fullscreen Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-30 bg-[#050b14]/98 backdrop-blur-2xl flex flex-col justify-between pt-28 pb-10 px-8 lg:hidden"
          >
            <div className="flex flex-col space-y-6">
              <span className="text-[10px] font-mono tracking-[0.3em] uppercase text-slate-500">
                DIRECT NAVIGATION
              </span>
              {navItems.map((item) => (
                <a
                  key={item.label}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className="flex items-center justify-between text-2xl font-serif text-white hover:text-[#d4af37] transition-colors py-2 border-b border-white/10"
                >
                  <span>{item.label}</span>
                  <ArrowUpRight className="w-4 h-4 text-slate-500" />
                </a>
              ))}
            </div>

            <div className="pt-6 border-t border-white/10 flex flex-col gap-3">
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>EST. 2031 &middot; LONDON</span>
                <span>41.2% VOL</span>
              </div>
              <p className="text-[11px] text-slate-500 font-light leading-relaxed">
                BRITISH BY NATURE. BUILT FOR TOMORROW.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
