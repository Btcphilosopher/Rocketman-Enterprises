"""
NEUROSHAKE // Cost Model
Full cost accounting per cocktail.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

from config import ECONOMICS

if TYPE_CHECKING:
    from core.cocktail import Cocktail


def compute_total_cost(cocktail: Cocktail) -> float:
    """
    total_cost = (ingredient_cost × waste_factor_multiplier) + labour_cost
    """
    ingredient_cost_with_waste = cocktail.ingredient_cost * (1.0 + ECONOMICS.waste_factor)
    return ingredient_cost_with_waste + ECONOMICS.base_labour_cost


def breakdown(cocktail: Cocktail) -> dict[str, float]:
    raw = cocktail.ingredient_cost
    waste = raw * ECONOMICS.waste_factor
    labour = ECONOMICS.base_labour_cost
    total = raw + waste + labour
    return {
        "raw_ingredient_cost": round(raw, 4),
        "waste_cost": round(waste, 4),
        "labour_cost": round(labour, 4),
        "total_cost": round(total, 4),
    }
