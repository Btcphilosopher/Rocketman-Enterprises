"""
NEUROSHAKE // Profit Engine
profit_score = (price - cost) × demand_probability
The central economic objective function.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

from utils.math_utils import clamp

if TYPE_CHECKING:
    from core.cocktail import Cocktail


# Maximum theoretical gross profit per cocktail (used for normalisation)
MAX_THEORETICAL_GP: float = 25.0


def compute_profit_score(cocktail: Cocktail) -> float:
    """
    Normalised profit score 0.0–1.0.
    profit = (price - cost) × demand_probability
    """
    if cocktail.suggested_price <= 0.0:
        return 0.0

    gross_profit = cocktail.suggested_price - cocktail.total_cost
    raw_profit = gross_profit * cocktail.demand_score

    return clamp(raw_profit / MAX_THEORETICAL_GP)


def economic_metrics(cocktail: Cocktail) -> dict:
    """Full economic reporting dict."""
    gp = cocktail.suggested_price - cocktail.total_cost
    margin_pct = gp / max(cocktail.suggested_price, 0.01)
    weekly_covers = 200           # assumed weekly cover count for simulation
    est_weekly_orders = cocktail.demand_score * weekly_covers
    est_weekly_gp = est_weekly_orders * gp

    return {
        "gross_profit": round(gp, 2),
        "margin_pct": round(margin_pct * 100, 1),
        "demand_score": round(cocktail.demand_score, 4),
        "profit_score": round(cocktail.profit_score, 4),
        "est_weekly_orders": round(est_weekly_orders, 1),
        "est_weekly_gp": round(est_weekly_gp, 2),
        "payback_efficiency": round(cocktail.profit_score * cocktail.flavour_score, 4),
    }


def price_elasticity_curve(cocktail: Cocktail, price_points: list[float]) -> list[dict]:
    """Simulate demand at different price points (holding everything else constant)."""
    from economics.demand_model import demand_probability
    import copy

    results = []
    for price in price_points:
        sim = copy.copy(cocktail)
        sim.suggested_price = price
        sim.demand_score = demand_probability(sim)
        gp = price - cocktail.total_cost
        results.append({
            "price": price,
            "demand": round(sim.demand_score, 4),
            "gross_profit": round(gp, 2),
            "revenue_score": round(gp * sim.demand_score, 4),
        })
    return results
