"""
NEUROSHAKE // Demand Model
Stochastic demand simulation across customer archetypes.
"""
from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from config import FLAVOUR_DIMS
from utils.math_utils import clamp, cosine_similarity, sigmoid

if TYPE_CHECKING:
    from core.cocktail import Cocktail


@dataclass
class CustomerArchetype:
    """A customer segment with distinct cocktail preferences."""
    key: str
    name: str
    description: str
    preference_vector: list[float]    # desired flavour profile
    price_sensitivity: float           # 0.0 = price-insensitive, 1.0 = very sensitive
    novelty_tolerance: float           # 0.0 = classic-only, 1.0 = loves experimental
    abv_preference: float              # preferred ABV 0.0–0.40
    abv_tolerance: float               # ±tolerance around preference
    population_share: float            # fraction of bar's customer base


def _make_vec(**kwargs) -> list[float]:
    return [kwargs.get(d, 0.0) for d in FLAVOUR_DIMS]


# ── Archetype Definitions ──────────────────────────────────────────────────────

ARCHETYPES: list[CustomerArchetype] = [
    CustomerArchetype(
        key="luxury_seeker",
        name="Luxury Seeker",
        description="High-spend, brand-conscious, prefers complex prestige cocktails",
        preference_vector=_make_vec(
            sweetness=0.3, bitterness=0.45, herbal=0.6,
            aroma_complexity=0.85, finish_length=0.75, body=0.6,
            smoke=0.2, floral=0.3,
        ),
        price_sensitivity=0.15,
        novelty_tolerance=0.60,
        abv_preference=0.28,
        abv_tolerance=0.10,
        population_share=0.25,
    ),
    CustomerArchetype(
        key="experimental_drinker",
        name="Experimental Drinker",
        description="Cocktail enthusiast who seeks unique, challenging flavours",
        preference_vector=_make_vec(
            bitterness=0.5, herbal=0.7, smoke=0.4, floral=0.5,
            umami=0.25, aroma_complexity=0.9, spice=0.5,
        ),
        price_sensitivity=0.35,
        novelty_tolerance=0.95,
        abv_preference=0.25,
        abv_tolerance=0.15,
        population_share=0.20,
    ),
    CustomerArchetype(
        key="classic_drinker",
        name="Classic Cocktail Drinker",
        description="Appreciates tradition, familiar flavour archetypes",
        preference_vector=_make_vec(
            sweetness=0.35, sourness=0.35, bitterness=0.35,
            citrus=0.5, herbal=0.4, aroma_complexity=0.55,
            finish_length=0.5, body=0.4,
        ),
        price_sensitivity=0.50,
        novelty_tolerance=0.30,
        abv_preference=0.22,
        abv_tolerance=0.08,
        population_share=0.30,
    ),
    CustomerArchetype(
        key="high_strength_seeker",
        name="High-Strength Seeker",
        description="Prefers boozy, spirit-forward drinks with strong ABV",
        preference_vector=_make_vec(
            alcohol_heat=0.75, bitterness=0.4, herbal=0.4,
            spice=0.5, aroma_complexity=0.6, finish_length=0.7,
            body=0.55,
        ),
        price_sensitivity=0.45,
        novelty_tolerance=0.45,
        abv_preference=0.35,
        abv_tolerance=0.07,
        population_share=0.15,
    ),
    CustomerArchetype(
        key="social_drinker",
        name="Social Drinker",
        description="Approachable, sweet, refreshing cocktails. Price-sensitive.",
        preference_vector=_make_vec(
            sweetness=0.65, tropical=0.6, citrus=0.5,
            freshness_proxy=0.0,  # not a real dim, ignored
            sourness=0.3, body=0.25,
        ),
        price_sensitivity=0.70,
        novelty_tolerance=0.40,
        abv_preference=0.12,
        abv_tolerance=0.10,
        population_share=0.10,
    ),
]


# ── Demand Computation ─────────────────────────────────────────────────────────

def archetype_affinity(cocktail: Cocktail, archetype: CustomerArchetype) -> float:
    """How well does this cocktail match this archetype's preferences?"""
    # Flavour similarity
    flavour_sim = cosine_similarity(
        cocktail.flavour_vector, archetype.preference_vector
    )

    # ABV fit: Gaussian around preference
    abv_delta = abs(cocktail.abv - archetype.abv_preference)
    abv_fit = math.exp(-(abv_delta ** 2) / (2 * max(archetype.abv_tolerance, 0.05) ** 2))

    # Novelty: experimental drinkers love novel; classic drinkers penalise it
    novelty_fit = (
        archetype.novelty_tolerance * cocktail.novelty_score +
        (1.0 - archetype.novelty_tolerance) * (1.0 - cocktail.novelty_score * 0.5)
    )

    return clamp(flavour_sim * 0.55 + abv_fit * 0.25 + novelty_fit * 0.20)


def demand_probability(cocktail: Cocktail) -> float:
    """
    Weighted average demand probability across all archetypes.
    Incorporates price sensitivity.
    """
    if not cocktail.flavour_vector:
        return 0.0

    total_demand = 0.0
    total_weight = 0.0

    price = cocktail.suggested_price

    for arch in ARCHETYPES:
        affinity = archetype_affinity(cocktail, arch)

        # Price sensitivity: logistic penalty above £12
        if price > 0:
            price_penalty = sigmoid(-(price - 12.0) * arch.price_sensitivity * 0.4)
        else:
            price_penalty = 0.5

        demand = affinity * price_penalty
        total_demand += demand * arch.population_share
        total_weight += arch.population_share

    return clamp(total_demand / max(total_weight, 0.01))


def per_archetype_demand(cocktail: Cocktail) -> dict[str, float]:
    """Detailed demand breakdown by archetype."""
    return {
        arch.key: round(archetype_affinity(cocktail, arch), 4)
        for arch in ARCHETYPES
    }
