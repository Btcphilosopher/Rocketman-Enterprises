"""
NEUROSHAKE // Pricing Model
Luxury-adjusted cocktail pricing engine.
Inspired by von Hippel value-based pricing with brand premium.
"""
from __future__ import annotations
import math
from typing import TYPE_CHECKING

from config import ECONOMICS
from utils.math_utils import clamp

if TYPE_CHECKING:
    from core.cocktail import Cocktail


def compute_price(cocktail: Cocktail) -> float:
    """
    Price = cost × multiplier + quality_premium + luxury_premium
    Multiplier ranges from luxury_floor to luxury_ceiling
    based on brand alignment + complexity.
    """
    # Base multiplier driven by brand score and complexity
    brand_mult = cocktail.brand_alignment_score * 0.4 + cocktail.complexity_score * 0.3
    multiplier = ECONOMICS.luxury_floor_multiplier + brand_mult * (
        ECONOMICS.luxury_ceiling_multiplier - ECONOMICS.luxury_floor_multiplier
    )

    cost_based_price = cocktail.total_cost * multiplier

    # Quality premium: excellent flavour → justifies higher price
    quality_premium = cocktail.flavour_score * 2.50

    # Novelty premium: innovative = collectible
    novelty_premium = cocktail.novelty_score * 1.20

    # Luxury ingredient uplift
    luxury_ings = sum(1 for ing, _ in cocktail.ingredients if ing.luxury_tier() >= 2)
    luxury_premium = luxury_ings * 0.80

    raw_price = cost_based_price + quality_premium + novelty_premium + luxury_premium

    # Round to nearest 0.50
    rounded = math.ceil(raw_price * 2) / 2.0

    return clamp(rounded, ECONOMICS.min_price, ECONOMICS.max_price)


def target_cost_check(cocktail: Cocktail) -> dict:
    """Is the drink economically viable at the target cost ratio?"""
    if cocktail.suggested_price <= 0:
        return {"viable": False, "reason": "no price set"}
    cost_ratio = cocktail.total_cost / cocktail.suggested_price
    return {
        "viable": cost_ratio <= ECONOMICS.target_cost_ratio + 0.05,
        "cost_ratio": round(cost_ratio, 4),
        "target_ratio": ECONOMICS.target_cost_ratio,
        "above_target": cost_ratio > ECONOMICS.target_cost_ratio,
    }
