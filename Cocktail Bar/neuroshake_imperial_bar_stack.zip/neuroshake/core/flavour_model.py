"""
NEUROSHAKE // Flavour Model
Scientific flavour vector computation.
Cocktail flavour = weighted sum of ingredient flavour vectors.
"""
from __future__ import annotations
import math
from typing import TYPE_CHECKING

from config import FLAVOUR_DIMS, NUM_FLAVOUR_DIMS
from utils.math_utils import clamp, balance_score, entropy, normalise_vector

if TYPE_CHECKING:
    from core.ingredients import Ingredient
    from core.cocktail import Cocktail


def compute_flavour_vector(
    ingredients: list[tuple[Ingredient, float]]
) -> list[float]:
    """
    Weighted combination of ingredient flavour vectors.
    Each ingredient contributes proportional to its volume ratio.
    Non-linear interaction: high-intensity ingredients amplify complexity.
    """
    if not ingredients:
        return [0.0] * NUM_FLAVOUR_DIMS

    vec = [0.0] * NUM_FLAVOUR_DIMS

    for ing, ratio in ingredients:
        ing_vec = ing.flavour_vector()
        for i in range(NUM_FLAVOUR_DIMS):
            vec[i] += ing_vec[i] * ratio

    # Clamp to [0, 1]
    vec = [clamp(v) for v in vec]

    return vec


def compute_abv(ingredients: list[tuple[Ingredient, float]]) -> float:
    """Volume-weighted ABV."""
    if not ingredients:
        return 0.0
    abv = sum(ing.abv * ratio for ing, ratio in ingredients)
    return clamp(abv, 0.0, 1.0)


def compute_ingredient_cost(
    ingredients: list[tuple[Ingredient, float]],
    total_volume_ml: float = 90.0,
) -> float:
    """Raw ingredient cost in £."""
    cost = 0.0
    for ing, ratio in ingredients:
        volume_ml = ratio * total_volume_ml
        # cost_per_25ml → scale to actual volume
        cost += ing.cost_per_25ml * (volume_ml / 25.0)
    return cost


# ── Flavour Analysis ───────────────────────────────────────────────────────────

def analyse_flavour_profile(vec: list[float]) -> dict[str, float]:
    """
    Derive high-level descriptors from a flavour vector.
    Returns a dict of characterisation scores.
    """
    dims = {d: v for d, v in zip(FLAVOUR_DIMS, vec)}

    # Primary flavour balance: sweet-sour-bitter triangle
    primary = [dims["sweetness"], dims["sourness"], dims["bitterness"]]
    primary_balance = balance_score(primary)

    # Complexity = entropy of the full flavour vector (how many dimensions active)
    complexity = entropy([v + 0.01 for v in vec])
    complexity_norm = clamp(complexity / math.log(NUM_FLAVOUR_DIMS + 1))

    # Intensity = mean flavour vector magnitude
    intensity = sum(vec) / NUM_FLAVOUR_DIMS

    # Alcohol smoothness: high ABV heat penalises smoothness
    alcohol_heat = dims["alcohol_heat"]
    alcohol_smoothness = 1.0 - alcohol_heat * 0.6

    # Aroma depth
    aroma = dims["aroma_complexity"] * 0.7 + dims["finish_length"] * 0.3

    # Freshness = citrus + sourness - smoke - bitterness * 0.3
    freshness = clamp(
        dims["citrus"] * 0.4 + dims["sourness"] * 0.3 - dims["smoke"] * 0.3
        - dims["bitterness"] * 0.2 + 0.3
    )

    # Richness = body + tropical + sweetness * 0.5
    richness = clamp(dims["body"] * 0.4 + dims["tropical"] * 0.3 + dims["sweetness"] * 0.3)

    return {
        "primary_balance": primary_balance,
        "complexity": complexity_norm,
        "intensity": intensity,
        "alcohol_smoothness": alcohol_smoothness,
        "aroma_depth": aroma,
        "freshness": freshness,
        "richness": richness,
    }


def flavour_profile_label(analysis: dict[str, float]) -> str:
    """Generate a human-readable flavour descriptor."""
    labels = []

    if analysis["freshness"] > 0.6:
        labels.append("Fresh & Citrus-Driven")
    elif analysis["richness"] > 0.5:
        labels.append("Rich & Full-Bodied")

    if analysis["complexity"] > 0.6:
        labels.append("Complex")
    elif analysis["complexity"] < 0.35:
        labels.append("Clean & Focused")

    if analysis["aroma_depth"] > 0.65:
        labels.append("Aromatic")

    if analysis["alcohol_smoothness"] < 0.45:
        labels.append("Spirit-Forward")
    elif analysis["alcohol_smoothness"] > 0.75:
        labels.append("Smooth")

    if not labels:
        labels.append("Balanced")

    return " · ".join(labels)


def dominant_flavour_notes(vec: list[float], top_n: int = 4) -> list[str]:
    """Return the top-N dominant flavour dimension names."""
    ranked = sorted(
        zip(FLAVOUR_DIMS, vec),
        key=lambda x: -x[1]
    )
    return [dim.replace("_", " ").title() for dim, _ in ranked[:top_n] if _ > 0.05]
