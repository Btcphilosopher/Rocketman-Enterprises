"""
NEUROSHAKE // Scoring System
Multi-dimensional cocktail quality evaluator.
Produces normalised scores 0.0–1.0 for each dimension.
"""
from __future__ import annotations
import math
from typing import TYPE_CHECKING

from config import FLAVOUR_DIMS, SCORING
from utils.math_utils import clamp, balance_score, smooth_step, sigmoid
from core.flavour_model import analyse_flavour_profile

if TYPE_CHECKING:
    from core.cocktail import Cocktail


# ── Individual Dimension Scorers ───────────────────────────────────────────────

def score_flavour_balance(cocktail: Cocktail) -> float:
    """
    How harmoniously sweet, sour, bitter interact.
    Penalise extreme dominance of any single primary flavour.
    """
    vec = cocktail.flavour_vector
    dims = {d: v for d, v in zip(FLAVOUR_DIMS, vec)}

    sweet = dims["sweetness"]
    sour = dims["sourness"]
    bitter = dims["bitterness"]

    # The golden triangle: 3 primary taste drivers
    primary_balance = balance_score([sweet, sour, bitter])

    # Penalty for totally missing one primary note
    min_primary = min(sweet, sour, bitter)
    coverage_bonus = smooth_step(min_primary * 2.0)

    # Secondary balance: herbal, spice, floral shouldn't dominate
    secondary = [dims.get(d, 0) for d in ["herbal", "spice", "floral", "smoke"]]
    secondary_harmony = 1.0 - max(secondary) * 0.3

    return clamp(primary_balance * 0.6 + coverage_bonus * 0.25 + secondary_harmony * 0.15)


def score_intensity_curve(cocktail: Cocktail) -> float:
    """
    Evaluate whether the drink has a satisfying arc:
    attack → mid-palate → finish.
    """
    vec = cocktail.flavour_vector
    dims = {d: v for d, v in zip(FLAVOUR_DIMS, vec)}

    # Attack: alcohol heat + citrus + bitterness
    attack = (dims["alcohol_heat"] + dims["citrus"] + dims["bitterness"]) / 3.0

    # Mid-palate: sweetness + body + tropical
    mid = (dims["sweetness"] + dims["body"] + dims["tropical"]) / 3.0

    # Finish: finish_length + herbal + spice + aroma_complexity
    finish = (dims["finish_length"] + dims["herbal"] + dims["spice"] * 0.5 + dims["aroma_complexity"]) / 3.5

    # Ideal: moderate attack → fuller mid → sustained finish
    ideal_attack = 0.45
    ideal_mid = 0.50
    ideal_finish = 0.55

    def proximity(actual: float, ideal: float, tolerance: float = 0.3) -> float:
        return math.exp(-((actual - ideal) ** 2) / (2 * tolerance ** 2))

    score = (
        proximity(attack, ideal_attack) * 0.30 +
        proximity(mid, ideal_mid) * 0.35 +
        proximity(finish, ideal_finish) * 0.35
    )
    return clamp(score)


def score_alcohol_smoothness(cocktail: Cocktail) -> float:
    """
    Is the alcohol integrated or rough?
    Very high ABV with no balancing sweetness/body = harsh.
    """
    vec = cocktail.flavour_vector
    dims = {d: v for d, v in zip(FLAVOUR_DIMS, vec)}

    heat = dims["alcohol_heat"]
    body = dims["body"]
    sweet = dims["sweetness"]

    # Heat balanced by body and sweetness
    integration = (body * 0.5 + sweet * 0.5) / max(heat + 0.1, 0.1)
    score = sigmoid((integration - 1.0) * 2.0)

    # Very low ABV cocktails score well automatically
    if cocktail.abv < 0.10:
        score = max(score, 0.75)

    return clamp(score)


def score_sensory_complexity(cocktail: Cocktail) -> float:
    """
    How many sensory dimensions are meaningfully engaged?
    """
    vec = cocktail.flavour_vector
    analysis = analyse_flavour_profile(vec)
    return clamp(analysis["complexity"] * 0.7 + analysis["aroma_depth"] * 0.3)


def score_novelty(cocktail: Cocktail, population_archive: list[Cocktail] | None = None) -> float:
    """
    Novelty relative to known cocktail space.
    Without archive: estimate from ingredient diversity and unusual combinations.
    With archive: use sparseness in flavour space.
    """
    from utils.math_utils import euclidean_distance, clamp

    if population_archive:
        # Average distance to k nearest neighbours
        k = min(10, len(population_archive))
        distances = sorted(
            euclidean_distance(cocktail.flavour_vector, other.flavour_vector)
            for other in population_archive
            if other.id != cocktail.id
        )
        if distances:
            avg_dist = sum(distances[:k]) / k
            # Normalise by max possible distance in flavour space (sqrt(15) ≈ 3.87)
            return clamp(avg_dist / 1.5)

    # Fallback: ingredient combination novelty
    n_ing = len(cocktail.ingredients)
    ingredient_diversity = clamp(n_ing / 7.0)

    # Check for unusual combinations (e.g. smoke + floral)
    vec = cocktail.flavour_vector
    dims = {d: v for d, v in zip(FLAVOUR_DIMS, vec)}
    unusual_combos = [
        (dims["smoke"] > 0.3 and dims["floral"] > 0.3),
        (dims["smoke"] > 0.3 and dims["citrus"] > 0.5),
        (dims["herbal"] > 0.6 and dims["tropical"] > 0.4),
        (dims["bitterness"] > 0.6 and dims["sweetness"] > 0.6),
        (dims["umami"] > 0.3 and dims["floral"] > 0.4),
    ]
    unusual_bonus = sum(0.12 for c in unusual_combos if c)
    return clamp(ingredient_diversity * 0.5 + unusual_bonus + 0.15)


def score_brand_alignment(cocktail: Cocktail) -> float:
    """
    Anglo-futurist brand identity score.
    Prefers: sophisticated complexity, dark/smoky/herbal notes,
    premium ingredients, architectural precision.
    """
    vec = cocktail.flavour_vector
    dims = {d: v for d, v in zip(FLAVOUR_DIMS, vec)}

    # Anglo-futurist identity vector: complexity, herbal depth, dark notes
    af_preferences = {
        "aroma_complexity": 0.80,
        "herbal": 0.55,
        "bitterness": 0.45,
        "finish_length": 0.70,
        "smoke": 0.30,
        "body": 0.50,
    }

    score = 0.0
    total_w = 0.0
    for dim, target in af_preferences.items():
        actual = dims.get(dim, 0.0)
        # Gaussian proximity to target
        w = 1.0
        score += w * math.exp(-((actual - target) ** 2) / 0.15)
        total_w += w

    base_score = score / total_w if total_w > 0 else 0.0

    # Luxury ingredient bonus
    luxury_ings = [
        ing for ing, _ in cocktail.ingredients
        if ing.luxury_tier() >= 1
    ]
    luxury_bonus = clamp(len(luxury_ings) * 0.08)

    # Penalty for overly simple or very cheap cocktails
    cheapness_penalty = max(0.0, 0.20 - cocktail.ingredient_cost) * 0.5

    return clamp(base_score * 0.75 + luxury_bonus - cheapness_penalty)


# ── Composite Scorer ────────────────────────────────────────────────────────────

def score_cocktail(
    cocktail: Cocktail,
    population_archive: list[Cocktail] | None = None,
) -> None:
    """
    Compute and assign all scores to the cocktail in-place.
    """
    cocktail.balance_score = score_flavour_balance(cocktail)
    cocktail.complexity_score = score_sensory_complexity(cocktail)
    cocktail.novelty_score = score_novelty(cocktail, population_archive)
    cocktail.brand_alignment_score = score_brand_alignment(cocktail)

    intensity_score = score_intensity_curve(cocktail)
    smoothness_score = score_alcohol_smoothness(cocktail)

    # Composite flavour score
    cocktail.flavour_score = (
        cocktail.balance_score * 0.35 +
        intensity_score * 0.25 +
        smoothness_score * 0.20 +
        cocktail.complexity_score * 0.20
    )


def compute_fitness(
    cocktail: Cocktail,
    weights: type | None = None,
) -> float:
    """
    Evolutionary fitness = weighted sum of all scoring dimensions.
    Incorporates profit as a first-class objective.
    """
    w = weights or SCORING

    fitness = (
        cocktail.flavour_score * w.flavour_balance +
        cocktail.complexity_score * w.sensory_complexity +
        cocktail.novelty_score * w.novelty +
        cocktail.brand_alignment_score * w.brand_alignment +
        cocktail.profit_score * w.cost_efficiency
    )
    # Bonus for drinks that are both complex AND profitable
    synergy = cocktail.complexity_score * cocktail.profit_score * 0.1
    return clamp(fitness + synergy)
