"""
NEUROSHAKE // Ingredients
Ingredient dataclass and database loader.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import ClassVar

from config import FLAVOUR_DIMS


@dataclass(frozen=True)
class Ingredient:
    key: str
    name: str
    category: str          # spirit | liqueur | mixer | garnish
    abv: float             # 0.0 – 1.0
    cost_per_25ml: float   # £
    flavour: dict[str, float]
    tags: tuple[str, ...]

    # ── convenience ────────────────────────────────────────────────────────────
    def flavour_vector(self) -> list[float]:
        return [self.flavour.get(dim, 0.0) for dim in FLAVOUR_DIMS]

    def is_base_spirit(self) -> bool:
        return self.category == "spirit" and "base" in self.tags

    def is_modifier(self) -> bool:
        return self.category in ("liqueur", "mixer") or "modifier" in self.tags

    def is_garnish(self) -> bool:
        return self.category == "garnish"

    def luxury_tier(self) -> int:
        """0=standard, 1=premium, 2=luxury"""
        if "luxury" in self.tags or "premium" in self.tags:
            return 2
        if self.cost_per_25ml >= 0.80:
            return 1
        return 0

    def __repr__(self) -> str:
        return f"<Ingredient {self.key}: {self.name} [{self.category}] ABV={self.abv:.0%}>"


class IngredientDB:
    """Singleton ingredient registry."""

    _instance: ClassVar[IngredientDB | None] = None
    _loaded: ClassVar[bool] = False

    def __new__(cls) -> IngredientDB:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if IngredientDB._loaded:
            return
        self._ingredients: dict[str, Ingredient] = {}
        self._load()
        IngredientDB._loaded = True

    # ── Loading ────────────────────────────────────────────────────────────────
    def _load(self) -> None:
        db_path = Path(__file__).parent.parent / "data" / "ingredient_db.json"
        with open(db_path, encoding="utf-8") as f:
            raw: dict[str, dict] = json.load(f)

        for _category, items in raw.items():
            for key, data in items.items():
                ing = Ingredient(
                    key=key,
                    name=data["name"],
                    category=data["category"],
                    abv=data["abv"],
                    cost_per_25ml=data["cost_per_25ml"],
                    flavour=data["flavour"],
                    tags=tuple(data.get("tags", [])),
                )
                self._ingredients[key] = ing

    # ── Queries ────────────────────────────────────────────────────────────────
    def all(self) -> list[Ingredient]:
        return list(self._ingredients.values())

    def get(self, key: str) -> Ingredient | None:
        return self._ingredients.get(key)

    def by_category(self, category: str) -> list[Ingredient]:
        return [i for i in self._ingredients.values() if i.category == category]

    def base_spirits(self) -> list[Ingredient]:
        return [i for i in self._ingredients.values() if i.is_base_spirit()]

    def modifiers(self) -> list[Ingredient]:
        return [i for i in self._ingredients.values() if i.is_modifier()]

    def garnishes(self) -> list[Ingredient]:
        return [i for i in self._ingredients.values() if i.is_garnish()]

    def by_tag(self, tag: str) -> list[Ingredient]:
        return [i for i in self._ingredients.values() if tag in i.tags]

    def keys(self) -> list[str]:
        return list(self._ingredients.keys())

    def __len__(self) -> int:
        return len(self._ingredients)

    def __contains__(self, key: str) -> bool:
        return key in self._ingredients

    def add(self, ingredient: Ingredient) -> None:
        """Extend the database at runtime."""
        self._ingredients[ingredient.key] = ingredient
