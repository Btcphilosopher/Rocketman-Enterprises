"""
NEUROSHAKE // Cocktail
Core cocktail dataclass — immutable value object.
"""
from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from config import FLAVOUR_DIMS

if TYPE_CHECKING:
    from core.ingredients import Ingredient


@dataclass
class Cocktail:
    """
    A cocktail is defined by:
    - a set of ingredients with volume ratios
    - derived properties (flavour vector, cost, abv, scores)
    - branding metadata
    """
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    name: str = "Unnamed"
    description: str = ""

    # ── Recipe ─────────────────────────────────────────────────────────────────
    ingredients: list[tuple[Ingredient, float]] = field(default_factory=list)
    # each tuple: (Ingredient, ratio) — ratios are normalised to sum 1.0

    # ── Derived Vectors ────────────────────────────────────────────────────────
    flavour_vector: list[float] = field(default_factory=list)
    abv: float = 0.0
    ingredient_cost: float = 0.0   # £ raw ingredient cost per serving

    # ── Serving Parameters ──────────────────────────────────────────────────────
    total_volume_ml: float = 90.0  # typical short cocktail

    # ── Scores (computed by scoring module) ────────────────────────────────────
    flavour_score: float = 0.0
    balance_score: float = 0.0
    complexity_score: float = 0.0
    novelty_score: float = 0.0
    brand_alignment_score: float = 0.0
    fitness: float = 0.0           # evolutionary fitness

    # ── Economics (set by profit engine) ───────────────────────────────────────
    total_cost: float = 0.0        # incl. labour + waste
    suggested_price: float = 0.0
    profit_score: float = 0.0
    demand_score: float = 0.0

    # ── Menu Tier ───────────────────────────────────────────────────────────────
    menu_tier: str = "volume"      # hero | volume | experimental

    # ── Generation Metadata ─────────────────────────────────────────────────────
    generation: int = 0
    parent_ids: tuple[str, str] = ("", "")

    # ── Convenience ────────────────────────────────────────────────────────────
    def ingredient_keys(self) -> list[str]:
        return [ing.key for ing, _ in self.ingredients]

    def flavour_dim(self, dim: str) -> float:
        try:
            idx = FLAVOUR_DIMS.index(dim)
            return self.flavour_vector[idx] if idx < len(self.flavour_vector) else 0.0
        except ValueError:
            return 0.0

    def recipe_str(self) -> str:
        lines = []
        total_v = self.total_volume_ml
        for ing, ratio in sorted(self.ingredients, key=lambda x: -x[1]):
            ml = ratio * total_v
            lines.append(f"  {ing.name:<30} {ml:5.0f} ml  ({ratio:.1%})")
        return "\n".join(lines)

    def cost_breakdown(self) -> dict[str, float]:
        return {
            "ingredient_cost": self.ingredient_cost,
            "total_cost": self.total_cost,
            "suggested_price": self.suggested_price,
            "gross_margin": self.suggested_price - self.total_cost,
            "margin_pct": (self.suggested_price - self.total_cost) / max(self.suggested_price, 0.01),
        }

    def summary(self) -> str:
        return (
            f"[{self.id}] {self.name}\n"
            f"  ABV: {self.abv:.1%} | Cost: £{self.total_cost:.2f} | "
            f"Price: £{self.suggested_price:.2f} | Profit Score: {self.profit_score:.3f}\n"
            f"  Flavour: {self.flavour_score:.3f} | Balance: {self.balance_score:.3f} | "
            f"Complexity: {self.complexity_score:.3f} | Novelty: {self.novelty_score:.3f}\n"
            f"  Tier: {self.menu_tier.upper()}"
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "ingredients": [
                {
                    "key": ing.key,
                    "name": ing.name,
                    "ratio": ratio,
                    "ml": round(ratio * self.total_volume_ml, 1),
                }
                for ing, ratio in self.ingredients
            ],
            "abv": round(self.abv, 4),
            "flavour_vector": {dim: round(v, 4) for dim, v in zip(FLAVOUR_DIMS, self.flavour_vector)},
            "scores": {
                "flavour": round(self.flavour_score, 4),
                "balance": round(self.balance_score, 4),
                "complexity": round(self.complexity_score, 4),
                "novelty": round(self.novelty_score, 4),
                "brand_alignment": round(self.brand_alignment_score, 4),
                "fitness": round(self.fitness, 4),
            },
            "economics": {
                "ingredient_cost": round(self.ingredient_cost, 4),
                "total_cost": round(self.total_cost, 4),
                "suggested_price": round(self.suggested_price, 2),
                "profit_score": round(self.profit_score, 4),
                "demand_score": round(self.demand_score, 4),
            },
            "menu_tier": self.menu_tier,
            "generation": self.generation,
        }
