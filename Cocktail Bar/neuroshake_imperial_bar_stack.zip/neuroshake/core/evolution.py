"""
NEUROSHAKE // Evolutionary Engine
Genetic algorithm for cocktail recipe generation and optimisation.

Population → Evaluate → Select → Crossover → Mutate → Repeat

Fitness incorporates: taste, balance, novelty, cost efficiency, brand alignment.
"""
from __future__ import annotations
import copy
import time
from dataclasses import dataclass, field
from typing import Callable

from config import EVOLUTION, FLAVOUR_DIMS
from core.cocktail import Cocktail
from core.ingredients import Ingredient, IngredientDB
from core.flavour_model import (
    compute_flavour_vector,
    compute_abv,
    compute_ingredient_cost,
)
from core.scoring import score_cocktail, compute_fitness
from core.constraints import is_valid, apply_penalties
from economics.cost_model import compute_total_cost
from economics.pricing import compute_price
from economics.demand_model import demand_probability
from economics.profit_engine import compute_profit_score
from bar.brand_engine import generate_name, generate_description
from bar.archetypes import classify_tier
from utils.random_utils import (
    rand, rand_range, rand_int, choice, sample, shuffle,
    gaussian_mutation, dirichlet_sample, tournament_select,
    seed as seed_rng,
)
from utils.math_utils import clamp


# ── Cocktail Factory ───────────────────────────────────────────────────────────

def _normalise_ratios(ratios: list[float]) -> list[float]:
    total = sum(ratios)
    if total < 1e-9:
        n = len(ratios)
        return [1.0 / n] * n
    return [r / total for r in ratios]


def random_cocktail(
    db: IngredientDB,
    generation: int = 0,
) -> Cocktail:
    """Generate a random valid cocktail."""
    bases = db.base_spirits()
    modifiers = db.modifiers()
    garnishes = db.garnishes()

    if not bases:
        raise ValueError("No base spirits in ingredient database")

    # Pick 1–2 base spirits
    n_bases = rand_int(1, min(2, len(bases)))
    chosen_bases = sample(bases, n_bases)

    # Pick 1–5 modifiers/mixers
    n_mod = rand_int(
        max(1, EVOLUTION.min_ingredients - n_bases),
        min(EVOLUTION.max_ingredients - n_bases, len(modifiers))
    )
    chosen_mods = sample(modifiers, n_mod)

    # Optional garnish (30% chance)
    if rand() < 0.30 and garnishes:
        chosen_garnish = [choice(garnishes)]
    else:
        chosen_garnish = []

    all_ings = chosen_bases + chosen_mods + chosen_garnish
    n = len(all_ings)

    # Ratios: bases dominate (Dirichlet-sampled for naturalism)
    # Bases typically get 0.35–0.60 total
    base_total = rand_range(0.35, 0.65)
    base_ratios = dirichlet_sample(n_bases, alpha=2.0)
    base_ratios = [r * base_total for r in base_ratios]

    mod_total = 1.0 - base_total
    if len(chosen_mods) + len(chosen_garnish) > 0:
        mod_ratios = dirichlet_sample(len(chosen_mods) + len(chosen_garnish), alpha=1.0)
        mod_ratios = [r * mod_total for r in mod_ratios]
    else:
        mod_ratios = []

    ratios = base_ratios + mod_ratios
    ratios = _normalise_ratios(ratios)

    ingredients = list(zip(all_ings, ratios))

    cocktail = Cocktail(
        ingredients=ingredients,
        generation=generation,
    )
    return _compute_all(cocktail)


def _compute_all(
    cocktail: Cocktail,
    archive: list[Cocktail] | None = None,
) -> Cocktail:
    """Compute derived properties, scores, economics for a cocktail."""
    cocktail.flavour_vector = compute_flavour_vector(cocktail.ingredients)
    cocktail.abv = compute_abv(cocktail.ingredients)
    cocktail.ingredient_cost = compute_ingredient_cost(
        cocktail.ingredients, cocktail.total_volume_ml
    )
    cocktail.total_cost = compute_total_cost(cocktail)
    score_cocktail(cocktail, archive)
    cocktail.suggested_price = compute_price(cocktail)
    cocktail.demand_score = demand_probability(cocktail)
    cocktail.profit_score = compute_profit_score(cocktail)
    cocktail.fitness = compute_fitness(cocktail)
    apply_penalties(cocktail)
    cocktail.menu_tier = classify_tier(cocktail)
    cocktail.name = generate_name(cocktail)
    cocktail.description = generate_description(cocktail)
    return cocktail


# ── Genetic Operators ──────────────────────────────────────────────────────────

def mutate(cocktail: Cocktail, db: IngredientDB, generation: int) -> Cocktail:
    """
    Mutation operator: produces a new cocktail variant.
    Applies one or more of: ratio mutation, ingredient swap, ingredient addition/removal.
    """
    child = copy.deepcopy(cocktail)
    child.id = child.id[:4] + f"m{generation:02d}"
    child.generation = generation
    child.parent_ids = (cocktail.id, "")

    if not child.ingredients:
        return child

    mutation_type = rand()

    if mutation_type < 0.40:
        # ── Ratio Drift: nudge all ratios slightly ─────────────────────────────
        new_ratios = []
        for ing, ratio in child.ingredients:
            new_ratio = gaussian_mutation(ratio, EVOLUTION.mutation_strength, 0.02, 0.80)
            new_ratios.append(new_ratio)
        new_ratios = _normalise_ratios(new_ratios)
        child.ingredients = [(ing, r) for (ing, _), r in zip(child.ingredients, new_ratios)]

    elif mutation_type < 0.65:
        # ── Ingredient Swap: replace one non-base modifier ─────────────────────
        non_bases = [(i, ing, r) for i, (ing, r) in enumerate(child.ingredients)
                     if not ing.is_base_spirit()]
        if non_bases:
            idx, _, ratio = choice(non_bases)
            pool = db.modifiers() + db.garnishes()
            # Don't pick same ingredient
            current_keys = {ing.key for ing, _ in child.ingredients}
            pool = [p for p in pool if p.key not in current_keys]
            if pool:
                new_ing = choice(pool)
                child.ingredients[idx] = (new_ing, ratio)

    elif mutation_type < 0.80:
        # ── Add Ingredient ─────────────────────────────────────────────────────
        if len(child.ingredients) < EVOLUTION.max_ingredients:
            current_keys = {ing.key for ing, _ in child.ingredients}
            pool = db.modifiers() + db.garnishes()
            pool = [p for p in pool if p.key not in current_keys]
            if pool:
                new_ing = choice(pool)
                new_ratio = rand_range(0.05, 0.15)
                child.ingredients.append((new_ing, new_ratio))
                # Re-normalise
                ratios = _normalise_ratios([r for _, r in child.ingredients])
                child.ingredients = [(ing, r) for (ing, _), r in zip(child.ingredients, ratios)]

    else:
        # ── Remove Ingredient (if > 2 total) ───────────────────────────────────
        if len(child.ingredients) > 2:
            # Remove a low-ratio ingredient that isn't a base spirit
            non_bases = [(i, ing, r) for i, (ing, r) in enumerate(child.ingredients)
                         if not ing.is_base_spirit()]
            if non_bases:
                # Remove the smallest contributor
                idx, _, _ = min(non_bases, key=lambda x: x[2])
                child.ingredients.pop(idx)
                ratios = _normalise_ratios([r for _, r in child.ingredients])
                child.ingredients = [(ing, r) for (ing, _), r in zip(child.ingredients, ratios)]

    return child


def crossover(parent_a: Cocktail, parent_b: Cocktail, generation: int) -> tuple[Cocktail, Cocktail]:
    """
    Crossover operator: exchange ingredient components between two parents.
    """
    # Strategy: take bases from one parent, modifiers from the other
    def split_ingredients(c: Cocktail):
        bases = [(ing, r) for ing, r in c.ingredients if ing.is_base_spirit()]
        mods = [(ing, r) for ing, r in c.ingredients if not ing.is_base_spirit()]
        return bases, mods

    bases_a, mods_a = split_ingredients(parent_a)
    bases_b, mods_b = split_ingredients(parent_b)

    def build_child(bases, mods, pid_a, pid_b):
        ings = bases + mods
        if not ings:
            return None
        ratios = _normalise_ratios([r for _, r in ings])
        child = Cocktail(
            ingredients=[(ing, r) for (ing, _), r in zip(ings, ratios)],
            generation=generation,
            parent_ids=(pid_a, pid_b),
        )
        child.id = child.id[:4] + f"x{generation:02d}"
        return child

    child_a = build_child(bases_a, mods_b, parent_a.id, parent_b.id)
    child_b = build_child(bases_b, mods_a, parent_b.id, parent_a.id)

    return child_a, child_b


# ── Evolutionary Engine ────────────────────────────────────────────────────────

@dataclass
class EvolutionResult:
    best_cocktail: Cocktail
    population: list[Cocktail]
    generation_stats: list[dict]
    archive: list[Cocktail]
    elapsed_seconds: float


def evolve(
    db: IngredientDB | None = None,
    on_progress: Callable[[int, int, float], None] | None = None,
    config=None,
) -> EvolutionResult:
    """
    Run the full evolutionary loop.

    Args:
        db: Ingredient database (uses global if None)
        on_progress: callback(generation, total, best_fitness)
        config: EvolutionConfig override

    Returns:
        EvolutionResult with best cocktail, full population, and statistics
    """
    if db is None:
        db = IngredientDB()
    if config is None:
        config = EVOLUTION

    seed_rng(42)

    t_start = time.time()

    # ── Initialise population ──────────────────────────────────────────────────
    population: list[Cocktail] = []
    while len(population) < config.population_size:
        c = random_cocktail(db, generation=0)
        if is_valid(c):
            population.append(c)
        # safety valve
        if len(population) >= config.population_size * 3:
            break

    population = population[:config.population_size]

    archive: list[Cocktail] = []    # novelty archive
    generation_stats: list[dict] = []
    best_ever: Cocktail = max(population, key=lambda c: c.fitness)

    for gen in range(config.generations):
        # ── Re-score with archive for novelty ─────────────────────────────────
        for c in population:
            score_cocktail(c, archive)
            c.fitness = compute_fitness(c)
            apply_penalties(c)

        # ── Archive update (novelty search) ────────────────────────────────────
        if len(archive) < config.archive_size:
            archive.extend(population[:5])
        else:
            archive.extend(population[:2])

        archive = archive[-config.archive_size:]

        # ── Statistics ────────────────────────────────────────────────────────
        fitnesses = [c.fitness for c in population]
        best_gen = max(population, key=lambda c: c.fitness)
        if best_gen.fitness > best_ever.fitness:
            best_ever = best_gen

        gen_stat = {
            "generation": gen,
            "best_fitness": round(best_gen.fitness, 4),
            "mean_fitness": round(sum(fitnesses) / len(fitnesses), 4),
            "worst_fitness": round(min(fitnesses), 4),
            "best_profit": round(best_gen.profit_score, 4),
            "best_name": best_gen.name,
        }
        generation_stats.append(gen_stat)

        if on_progress:
            on_progress(gen + 1, config.generations, best_gen.fitness)

        # ── Selection: elitism + tournament ───────────────────────────────────
        n_elite = max(1, int(len(population) * config.elite_fraction))
        population.sort(key=lambda c: c.fitness, reverse=True)
        elites = population[:n_elite]

        # ── Reproduction ──────────────────────────────────────────────────────
        offspring: list[Cocktail] = list(elites)  # elites survive unchanged

        while len(offspring) < config.population_size:
            if rand() < config.crossover_rate and len(population) >= 2:
                # Tournament selection × 2
                pa = tournament_select(population, fitnesses, config.tournament_size)
                pb = tournament_select(population, fitnesses, config.tournament_size)
                ca, cb = crossover(pa, pb, gen + 1)
                for child in (ca, cb):
                    if child is not None:
                        child = _compute_all(child, archive)
                        if is_valid(child):
                            offspring.append(child)
            else:
                # Mutation
                parent = tournament_select(population, fitnesses, config.tournament_size)
                child = mutate(parent, db, gen + 1)
                child = _compute_all(child, archive)
                if is_valid(child):
                    offspring.append(child)

            if len(offspring) >= config.population_size * 2:
                break   # safety

        population = offspring[:config.population_size]

    # Final sort
    population.sort(key=lambda c: c.fitness, reverse=True)
    best_ever = population[0] if population else best_ever

    return EvolutionResult(
        best_cocktail=best_ever,
        population=population,
        generation_stats=generation_stats,
        archive=archive,
        elapsed_seconds=time.time() - t_start,
    )
