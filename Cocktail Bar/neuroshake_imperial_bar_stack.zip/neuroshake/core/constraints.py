"""
NEUROSHAKE // Constraints
Hard constraints and soft penalties for cocktail validation.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

from config import MENU, ECONOMICS

if TYPE_CHECKING:
    from core.cocktail import Cocktail


def is_valid(cocktail: Cocktail) -> bool:
    """
    Hard constraint check — cocktail must pass ALL of these.
    """
    # Must have at least one base spirit
    from core.ingredients import Ingredient
    has_base = any(ing.is_base_spirit() for ing, _ in cocktail.ingredients)
    if not has_base:
        return False

    # Must have at least 2 ingredients
    if len(cocktail.ingredients) < 2:
        return False

    # Ingredient ratios must sum to approximately 1.0
    total_ratio = sum(r for _, r in cocktail.ingredients)
    if abs(total_ratio - 1.0) > 0.01:
        return False

    # ABV must be in range
    if not (MENU.min_abv <= cocktail.abv <= MENU.max_abv):
        return False

    # No negative ratios
    if any(r < 0.0 for _, r in cocktail.ingredients):
        return False

    # Must have a cost above zero
    if cocktail.ingredient_cost <= 0.0:
        return False

    return True


def constraint_penalty(cocktail: Cocktail) -> float:
    """
    Soft penalty applied to fitness for near-violations.
    Returns a penalty 0.0 (no penalty) → 1.0 (maximum penalty).
    """
    penalty = 0.0

    # ── Too much of one ingredient ─────────────────────────────────────────────
    if cocktail.ingredients:
        max_ratio = max(r for _, r in cocktail.ingredients)
        if max_ratio > 0.70:
            penalty += (max_ratio - 0.70) * 0.5

    # ── Excessive sweetness without acid balance ────────────────────────────────
    from config import FLAVOUR_DIMS
    vec = cocktail.flavour_vector
    if vec:
        dims = dict(zip(FLAVOUR_DIMS, vec))
        if dims.get("sweetness", 0) > 0.7 and dims.get("sourness", 0) < 0.2:
            penalty += 0.15

        # Too boozy without body
        if dims.get("alcohol_heat", 0) > 0.7 and dims.get("body", 0) < 0.2:
            penalty += 0.12

        # All smoke, no complexity
        if dims.get("smoke", 0) > 0.7 and dims.get("aroma_complexity", 0) < 0.4:
            penalty += 0.10

    # ── Too many ingredients causes complexity penalty ──────────────────────────
    n = len(cocktail.ingredients)
    if n > 6:
        penalty += (n - 6) * 0.05

    return min(1.0, penalty)


def apply_penalties(cocktail: Cocktail) -> None:
    """Reduce fitness by constraint violations."""
    penalty = constraint_penalty(cocktail)
    cocktail.fitness *= (1.0 - penalty * 0.5)
