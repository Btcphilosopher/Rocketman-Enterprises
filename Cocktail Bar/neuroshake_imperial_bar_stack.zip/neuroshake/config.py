"""
NEUROSHAKE // IMPERIAL BAR STACK
Central configuration module.
"""

from dataclasses import dataclass, field
from typing import Final

# ── System Identity ────────────────────────────────────────────────────────────
SYSTEM_NAME: Final = "NEUROSHAKE // IMPERIAL BAR STACK"
VERSION: Final = "1.0.0"
TAGLINE: Final = "Computational Cocktail Intelligence · Anglo-Futurist Edition"

# ── Flavour Vector Dimensions ─────────────────────────────────────────────────
FLAVOUR_DIMS: Final[list[str]] = [
    "sweetness",
    "sourness",
    "bitterness",
    "saltiness",
    "umami",
    "alcohol_heat",
    "herbal",
    "spice",
    "floral",
    "smoke",
    "citrus",
    "tropical",
    "aroma_complexity",
    "finish_length",
    "body",
]

NUM_FLAVOUR_DIMS: Final = len(FLAVOUR_DIMS)

# ── Evolutionary Algorithm ─────────────────────────────────────────────────────
@dataclass
class EvolutionConfig:
    population_size: int = 60
    generations: int = 40
    elite_fraction: float = 0.15
    mutation_rate: float = 0.25
    mutation_strength: float = 0.18
    crossover_rate: float = 0.70
    tournament_size: int = 5
    min_ingredients: int = 2
    max_ingredients: int = 7
    novelty_weight: float = 0.20
    archive_size: int = 100          # for novelty search


# ── Economic Parameters ────────────────────────────────────────────────────────
@dataclass
class EconomicsConfig:
    base_labour_cost: float = 1.80          # £ per cocktail preparation
    waste_factor: float = 0.08              # 8% ingredient waste
    target_cost_ratio: float = 0.22         # industry standard ≈ 22% food cost
    luxury_floor_multiplier: float = 2.8
    luxury_ceiling_multiplier: float = 5.5
    vat_rate: float = 0.20                  # UK VAT
    min_price: float = 8.00
    max_price: float = 28.00


# ── Scoring Weights ────────────────────────────────────────────────────────────
@dataclass
class ScoringWeights:
    flavour_balance: float = 0.25
    intensity_curve: float = 0.15
    alcohol_smoothness: float = 0.12
    sensory_complexity: float = 0.15
    novelty: float = 0.15
    cost_efficiency: float = 0.10
    brand_alignment: float = 0.08


# ── Menu Composition Targets ───────────────────────────────────────────────────
@dataclass
class MenuConfig:
    total_cocktails: int = 12
    hero_count: int = 3          # high-margin prestige
    volume_count: int = 5        # high-demand, low cost
    experimental_count: int = 4  # identity + branding
    min_abv: float = 0.0         # allow zero-ABV
    max_abv: float = 0.40


# ── Brand Engine ───────────────────────────────────────────────────────────────
ANGLO_FUTURIST_PREFIXES: Final[list[str]] = [
    "The", "Operation", "Protocol", "Directive", "Sequence",
    "Project", "Signal", "Circuit", "Axis", "Cipher",
    "Mandate", "Vector", "Codex", "Theorem", "Edict",
]

ANGLO_FUTURIST_NOUNS: Final[list[str]] = [
    "Whitehall", "Albion", "Meridian", "Regency", "Admiralty",
    "Sovereign", "Britannia", "Imperial", "Nocturne", "Criterion",
    "Clockwork", "Bastion", "Irongate", "Vaultline", "Gridlock",
    "Sector", "Dominion", "Zenith", "Parallax", "Cascade",
    "Threshold", "Nexus", "Monolith", "Terminus", "Citadel",
]

ANGLO_FUTURIST_SUFFIXES: Final[list[str]] = [
    "No. 1", "Protocol", "Sequence", "Amendment", "Index",
    "Directive", "Edition", "Revision", "Accord", "Manifesto",
    "Nocturne", "Overture", "Dispatch", "Communiqué", "Stratagem",
    "Theorem", "Axiom", "Codex", "Cipher", "Vector",
]

THEMATIC_MODIFIERS: Final[list[str]] = [
    "Neon", "Black", "Obsidian", "Gold", "Crimson",
    "Ivory", "Steel", "Cobalt", "Amber", "Onyx",
    "Silver", "Chrome", "Bronze", "Argent", "Sable",
]

# ── Global Singletons ──────────────────────────────────────────────────────────
EVOLUTION = EvolutionConfig()
ECONOMICS = EconomicsConfig()
SCORING = ScoringWeights()
MENU = MenuConfig()
