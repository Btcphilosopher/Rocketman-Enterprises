"""
NEUROSHAKE // Brand Engine
Anglo-futurist cocktail naming and description generation.
Procedural identity system for the Imperial Bar aesthetic.
"""
from __future__ import annotations
import hashlib
from typing import TYPE_CHECKING

from config import (
    ANGLO_FUTURIST_PREFIXES,
    ANGLO_FUTURIST_NOUNS,
    ANGLO_FUTURIST_SUFFIXES,
    THEMATIC_MODIFIERS,
    FLAVOUR_DIMS,
)
from utils.random_utils import choice, choices, rand_int, rand

if TYPE_CHECKING:
    from core.cocktail import Cocktail

# ── Name Templates ─────────────────────────────────────────────────────────────

_TEMPLATES = [
    "{prefix} {noun} {suffix}",
    "{modifier} {noun}",
    "{prefix} {noun}",
    "{noun} {suffix}",
    "{modifier} {noun} {suffix}",
    "{prefix} {modifier} {noun}",
]

_FLAVOUR_ADJECTIVES = {
    "smoke":   ["Dark", "Obscure", "Ashen", "Onyx", "Shadow"],
    "herbal":  ["Botanical", "Verdant", "Apothecary", "Green"],
    "citrus":  ["Solar", "Gilt", "Acid", "Bright"],
    "floral":  ["Ivory", "Petal", "Argent", "Gossamer"],
    "spice":   ["Spice Route", "Eastern", "Imperial", "Hot"],
    "tropical":["Colonial", "Meridian", "Southern"],
    "bitterness": ["Bitter", "Austere", "Tonic", "Quinine"],
    "sweetness": ["Golden", "Amber", "Velvet", "Honeyed"],
}

_MENU_THEMES = [
    "The Imperial Commission",
    "Signals from the Meridian",
    "Black Papers — Vol. I",
    "The Anglo Protocol",
    "Nocturnal Dispatches",
    "State Vectors",
    "The Governing Body",
    "Encrypted Pleasures",
]

_DESCRIPTIONS = [
    "A precisely calculated encounter between {a} and {b}, delivering measured complexity.",
    "Institutional in structure, anarchic in spirit. {a} commands; {b} negotiates.",
    "The {adj} version of a considered moment. Smoke-threaded, precision-engineered.",
    "Architecture in glass: {a} as foundation, {b} as flourish.",
    "Designed for {adj} occasions. Unapologetically Anglo-futurist.",
    "A bureaucratic triumph of {a} over the mundane. {b} provides counterpoint.",
    "An encrypted message rendered in flavour. Transmission complete.",
    "The Committee approved this formula after {n} iterations. It survived.",
]


def _seed_from_id(cocktail_id: str) -> int:
    """Deterministic seed from cocktail ID."""
    return int(hashlib.md5(cocktail_id.encode()).hexdigest()[:8], 16)


def generate_name(cocktail: Cocktail) -> str:
    """Generate an Anglo-futurist cocktail name."""
    import random
    rng = random.Random(_seed_from_id(cocktail.id))

    # Dominant flavour note influences naming
    if cocktail.flavour_vector:
        vec = cocktail.flavour_vector
        dims_dict = dict(zip(FLAVOUR_DIMS, vec))
        dominant_dim = max(dims_dict, key=lambda d: dims_dict[d])
        adj_pool = _FLAVOUR_ADJECTIVES.get(dominant_dim, THEMATIC_MODIFIERS)
        modifier = rng.choice(adj_pool)
    else:
        modifier = rng.choice(THEMATIC_MODIFIERS)

    template = rng.choice(_TEMPLATES)
    name = template.format(
        prefix=rng.choice(ANGLO_FUTURIST_PREFIXES),
        noun=rng.choice(ANGLO_FUTURIST_NOUNS),
        suffix=rng.choice(ANGLO_FUTURIST_SUFFIXES),
        modifier=modifier,
    )
    return name


def generate_description(cocktail: Cocktail) -> str:
    """Generate branded flavour description."""
    import random
    rng = random.Random(_seed_from_id(cocktail.id + "_desc"))

    if not cocktail.ingredients:
        return "An undefined formula awaiting specification."

    # Pick two dominant ingredients for flavour narrative
    sorted_ings = sorted(cocktail.ingredients, key=lambda x: -x[1])
    a_name = sorted_ings[0][0].name if len(sorted_ings) > 0 else "The Base"
    b_name = sorted_ings[1][0].name if len(sorted_ings) > 1 else "The Modifier"

    vec = cocktail.flavour_vector
    dims = dict(zip(FLAVOUR_DIMS, vec)) if vec else {}
    dominant_dim = max(dims, key=lambda d: dims[d]) if dims else "complexity"
    adj_pool = _FLAVOUR_ADJECTIVES.get(dominant_dim, ["distinguished"])
    adj = rng.choice(adj_pool).lower()

    template = rng.choice(_DESCRIPTIONS)
    return template.format(
        a=a_name, b=b_name, adj=adj,
        n=rng.randint(12, 48),
    )


def generate_menu_theme() -> str:
    import random
    return random.choice(_MENU_THEMES)


def generate_bar_identity() -> dict[str, str]:
    """Generate a full bar identity system."""
    import random as rng
    theme = rng.choice(_MENU_THEMES)
    colour_scheme = rng.choice([
        "Obsidian & Gold", "Midnight Blue & Copper",
        "Charcoal & Ivory", "British Racing Green & Chrome",
        "Onyx & Neon Cyan", "Storm Grey & Amber",
    ])
    font_pairing = rng.choice([
        "Bebas Neue / DM Mono", "Neue Haas Grotesk / Courier",
        "GT Sectra / IBM Plex Mono", "Canela / Space Mono",
    ])
    tagline = rng.choice([
        "Precision. Pleasure. Protocol.",
        "Engineered for distinction.",
        "The future arrived via the tradesman's entrance.",
        "Formally dressed. Informally consumed.",
        "Algorithmic excellence in every glass.",
        "Where flavour meets legislation.",
    ])

    return {
        "theme": theme,
        "colour_scheme": colour_scheme,
        "font_pairing": font_pairing,
        "tagline": tagline,
        "establishment": "The Imperial Bar",
    }
