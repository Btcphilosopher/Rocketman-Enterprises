"""
NEUROSHAKE // Customer Simulator
Simulate customer choices and spending patterns across archetypes.
"""
from __future__ import annotations
import math
from typing import TYPE_CHECKING

from economics.demand_model import ARCHETYPES, archetype_affinity
from utils.math_utils import clamp

if TYPE_CHECKING:
    from core.cocktail import Cocktail


def simulate_customer_session(
    menu: list[Cocktail],
    n_customers: int = 100,
) -> dict:
    """
    Simulate n_customers visiting the bar and ordering.
    Returns aggregated metrics.
    """
    if not menu:
        return {}

    import random
    rng = random.Random(42)

    total_revenue = 0.0
    total_profit = 0.0
    order_counts = {c.id: 0 for c in menu}
    archetype_orders = {arch.key: 0 for arch in ARCHETYPES}

    for _ in range(n_customers):
        # Sample customer archetype
        arch = rng.choices(ARCHETYPES, weights=[a.population_share for a in ARCHETYPES], k=1)[0]

        # Score each cocktail for this archetype
        affinities = [archetype_affinity(c, arch) for c in menu]

        # Stochastic selection weighted by affinity × price-adjusted appeal
        weights = []
        for c, aff in zip(menu, affinities):
            price_penalty = math.exp(-arch.price_sensitivity * max(0, c.suggested_price - 12) * 0.1)
            weights.append(max(aff * price_penalty, 0.01))

        chosen = rng.choices(menu, weights=weights, k=1)[0]
        order_counts[chosen.id] += 1
        archetype_orders[arch.key] += 1
        total_revenue += chosen.suggested_price
        total_profit += (chosen.suggested_price - chosen.total_cost)

    avg_spend = total_revenue / n_customers
    avg_profit = total_profit / n_customers

    # Sort menu by orders descending
    ranked_menu = sorted(menu, key=lambda c: -order_counts[c.id])

    return {
        "n_customers": n_customers,
        "total_revenue": round(total_revenue, 2),
        "total_profit": round(total_profit, 2),
        "avg_spend_per_customer": round(avg_spend, 2),
        "avg_profit_per_customer": round(avg_profit, 2),
        "order_counts": order_counts,
        "archetype_distribution": archetype_orders,
        "top_cocktail": ranked_menu[0].name if ranked_menu else "N/A",
        "bottom_cocktail": ranked_menu[-1].name if ranked_menu else "N/A",
    }
