"""
NEUROSHAKE // Bar Archetypes
Cocktail tier classification — hero, volume, experimental.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core.cocktail import Cocktail


@dataclass
class MenuTierCriteria:
    """Scoring thresholds that define membership in a tier."""
    name: str
    key: str
    min_margin_pct: float
    min_demand_score: float
    min_complexity_score: float
    description: str


HERO_CRITERIA = MenuTierCriteria(
    name="Hero", key="hero",
    min_margin_pct=0.70,
    min_demand_score=0.30,
    min_complexity_score=0.55,
    description="High-margin prestige. Anchors the brand. Justifies premium pricing.",
)

VOLUME_CRITERIA = MenuTierCriteria(
    name="Volume", key="volume",
    min_margin_pct=0.55,
    min_demand_score=0.50,
    min_complexity_score=0.0,
    description="High-velocity revenue drivers. Crowd appeal. Consistent GP.",
)

EXPERIMENTAL_CRITERIA = MenuTierCriteria(
    name="Experimental", key="experimental",
    min_margin_pct=0.0,
    min_demand_score=0.0,
    min_complexity_score=0.60,
    description="Identity cocktails. Brand storytelling. Low volume, high prestige.",
)

ALL_TIERS = [HERO_CRITERIA, VOLUME_CRITERIA, EXPERIMENTAL_CRITERIA]


def classify_tier(cocktail: Cocktail) -> str:
    """
    Assign the most appropriate menu tier based on cocktail economics + quality.
    """
    if cocktail.suggested_price <= 0:
        return "experimental"

    margin = (cocktail.suggested_price - cocktail.total_cost) / cocktail.suggested_price

    # Hero: high margin + reasonable demand + complexity
    if (margin >= HERO_CRITERIA.min_margin_pct and
            cocktail.demand_score >= HERO_CRITERIA.min_demand_score and
            cocktail.complexity_score >= HERO_CRITERIA.min_complexity_score):
        return "hero"

    # Volume: strong demand + acceptable margin
    if (margin >= VOLUME_CRITERIA.min_margin_pct and
            cocktail.demand_score >= VOLUME_CRITERIA.min_demand_score):
        return "volume"

    # Experimental: complexity + brand identity
    if cocktail.complexity_score >= EXPERIMENTAL_CRITERIA.min_complexity_score:
        return "experimental"

    # Default: volume
    return "volume"
