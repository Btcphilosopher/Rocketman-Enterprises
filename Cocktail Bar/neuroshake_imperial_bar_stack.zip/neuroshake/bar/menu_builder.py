"""
NEUROSHAKE // Menu Builder
Assembles a complete, economically-optimised, stylistically coherent bar menu.

Target composition:
  Hero cocktails  (3): high margin, prestige, complex
  Volume cocktails (5): high demand, efficient GP
  Experimental (4): brand identity, storytelling

Total: 12 cocktails with flavour diversity enforcement.
"""
from __future__ import annotations
import copy
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from config import MENU, FLAVOUR_DIMS
from bar.archetypes import classify_tier
from bar.brand_engine import generate_menu_theme
from utils.math_utils import euclidean_distance, clamp

if TYPE_CHECKING:
    from core.cocktail import Cocktail


@dataclass
class BarMenu:
    theme: str = ""
    hero_cocktails: list[Cocktail] = field(default_factory=list)
    volume_cocktails: list[Cocktail] = field(default_factory=list)
    experimental_cocktails: list[Cocktail] = field(default_factory=list)

    @property
    def all_cocktails(self) -> list[Cocktail]:
        return self.hero_cocktails + self.volume_cocktails + self.experimental_cocktails

    @property
    def total_count(self) -> int:
        return len(self.all_cocktails)

    def avg_price(self) -> float:
        cocktails = self.all_cocktails
        if not cocktails:
            return 0.0
        return sum(c.suggested_price for c in cocktails) / len(cocktails)

    def avg_margin(self) -> float:
        cocktails = self.all_cocktails
        if not cocktails:
            return 0.0
        margins = [
            (c.suggested_price - c.total_cost) / max(c.suggested_price, 0.01)
            for c in cocktails
        ]
        return sum(margins) / len(margins)

    def total_weekly_profit_estimate(self, weekly_covers: int = 200) -> float:
        return sum(
            c.demand_score * weekly_covers * (c.suggested_price - c.total_cost)
            for c in self.all_cocktails
        )

    def summary(self) -> str:
        lines = [
            f"╔══ {self.theme} ══╗",
            f"  Cocktails: {self.total_count}",
            f"  Avg Price: £{self.avg_price():.2f}",
            f"  Avg Margin: {self.avg_margin():.1%}",
            f"  Est. Weekly GP (200 covers): £{self.total_weekly_profit_estimate():.2f}",
            "",
            "  HERO COCKTAILS:",
        ]
        for c in self.hero_cocktails:
            lines.append(f"    ★ {c.name:<35} £{c.suggested_price:.2f} | "
                         f"Fitness: {c.fitness:.3f}")
        lines.append("  VOLUME COCKTAILS:")
        for c in self.volume_cocktails:
            lines.append(f"    ◆ {c.name:<35} £{c.suggested_price:.2f} | "
                         f"Demand: {c.demand_score:.3f}")
        lines.append("  EXPERIMENTAL COCKTAILS:")
        for c in self.experimental_cocktails:
            lines.append(f"    ◇ {c.name:<35} £{c.suggested_price:.2f} | "
                         f"Complexity: {c.complexity_score:.3f}")
        return "\n".join(lines)


def _flavour_diversity_filter(
    candidates: list[Cocktail],
    selected: list[Cocktail],
    n: int,
    min_distance: float = 0.25,
) -> list[Cocktail]:
    """
    Select n cocktails from candidates that are maximally diverse
    in flavour space, relative to already-selected cocktails.
    """
    chosen: list[Cocktail] = []
    remaining = list(candidates)

    while len(chosen) < n and remaining:
        if not selected and not chosen:
            # Pick best fitness first
            best = max(remaining, key=lambda c: c.fitness)
            chosen.append(best)
            remaining.remove(best)
            continue

        all_selected_vectors = [c.flavour_vector for c in selected + chosen]

        # Score each candidate by min distance to all selected
        def novelty_to_selected(c: Cocktail) -> float:
            if not c.flavour_vector:
                return 0.0
            min_dist = min(
                euclidean_distance(c.flavour_vector, sv)
                for sv in all_selected_vectors
            )
            return min_dist

        # Rank by combined fitness + diversity
        scored = [
            (c, c.fitness * 0.6 + novelty_to_selected(c) * 0.4)
            for c in remaining
        ]
        scored.sort(key=lambda x: -x[1])
        best_candidate = scored[0][0]
        chosen.append(best_candidate)
        remaining.remove(best_candidate)

    return chosen


def build_menu(
    population: list[Cocktail],
    hero_count: int | None = None,
    volume_count: int | None = None,
    experimental_count: int | None = None,
) -> BarMenu:
    """
    Build a balanced, profitable bar menu from an evolved population.
    """
    hero_count = hero_count or MENU.hero_count
    volume_count = volume_count or MENU.volume_count
    experimental_count = experimental_count or MENU.experimental_count

    if not population:
        return BarMenu(theme="Empty Menu")

    # ── Re-classify all cocktails ──────────────────────────────────────────────
    for c in population:
        c.menu_tier = classify_tier(c)

    hero_pool = [c for c in population if c.menu_tier == "hero"]
    volume_pool = [c for c in population if c.menu_tier == "volume"]
    experimental_pool = [c for c in population if c.menu_tier == "experimental"]

    # Fallback: if a tier is under-populated, pull from fitness-ranked population
    def fill_pool(pool, tier_key, fallback_n):
        if len(pool) < fallback_n:
            used_ids = {c.id for c in pool}
            extras = [c for c in sorted(population, key=lambda x: -x.fitness)
                      if c.id not in used_ids]
            pool.extend(extras[:fallback_n - len(pool)])
        return pool

    hero_pool = fill_pool(hero_pool, "hero", hero_count * 3)
    volume_pool = fill_pool(volume_pool, "volume", volume_count * 3)
    experimental_pool = fill_pool(experimental_pool, "experimental", experimental_count * 2)

    # ── Select with flavour diversity ──────────────────────────────────────────
    # Sort pools by primary tier criteria
    hero_pool.sort(key=lambda c: -(
        (c.suggested_price - c.total_cost) / max(c.suggested_price, 0.01) * 0.6 +
        c.complexity_score * 0.4
    ))
    volume_pool.sort(key=lambda c: -(c.demand_score * 0.7 + c.profit_score * 0.3))
    experimental_pool.sort(key=lambda c: -(c.complexity_score * 0.6 + c.novelty_score * 0.4))

    selected_heroes = _flavour_diversity_filter(hero_pool, [], hero_count)
    selected_volumes = _flavour_diversity_filter(volume_pool, selected_heroes, volume_count)
    selected_experiments = _flavour_diversity_filter(
        experimental_pool, selected_heroes + selected_volumes, experimental_count
    )

    # Assign definitive tiers
    for c in selected_heroes:
        c.menu_tier = "hero"
    for c in selected_volumes:
        c.menu_tier = "volume"
    for c in selected_experiments:
        c.menu_tier = "experimental"

    theme = generate_menu_theme()
    menu = BarMenu(
        theme=theme,
        hero_cocktails=selected_heroes,
        volume_cocktails=selected_volumes,
        experimental_cocktails=selected_experiments,
    )
    return menu


def optimise_menu_pricing(menu: BarMenu) -> BarMenu:
    """
    Post-hoc price optimisation: find the price point that maximises
    GP × demand for each cocktail via discrete search.
    """
    from economics.demand_model import demand_probability
    from utils.math_utils import clamp

    import numpy as np_sub  # we use only basic Python here

    for cocktail in menu.all_cocktails:
        best_score = -1.0
        best_price = cocktail.suggested_price
        step = 0.50
        lo = max(cocktail.total_cost * 2.5, 8.0)
        hi = 28.0

        price = lo
        while price <= hi:
            cocktail.suggested_price = price
            cocktail.demand_score = demand_probability(cocktail)
            score = (price - cocktail.total_cost) * cocktail.demand_score
            if score > best_score:
                best_score = score
                best_price = price
            price += step

        cocktail.suggested_price = best_price
        cocktail.demand_score = demand_probability(cocktail)
        from economics.profit_engine import compute_profit_score
        cocktail.profit_score = compute_profit_score(cocktail)

    return menu
