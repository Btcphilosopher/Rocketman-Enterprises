"""
NEUROSHAKE // Random Utilities
Seeded randomness, sampling, mutation helpers.
"""
from __future__ import annotations
import random
import math
from typing import TypeVar, Sequence

T = TypeVar("T")

_rng = random.Random()


def seed(s: int) -> None:
    _rng.seed(s)


def rand() -> float:
    return _rng.random()


def rand_range(lo: float, hi: float) -> float:
    return _rng.uniform(lo, hi)


def rand_int(lo: int, hi: int) -> int:
    return _rng.randint(lo, hi)


def choice(seq: Sequence[T]) -> T:
    return _rng.choice(seq)


def choices(seq: Sequence[T], k: int, weights: Sequence[float] | None = None) -> list[T]:
    return _rng.choices(seq, weights=weights, k=k)


def sample(seq: Sequence[T], k: int) -> list[T]:
    return _rng.sample(seq, min(k, len(seq)))


def shuffle(seq: list[T]) -> None:
    _rng.shuffle(seq)


def gaussian(mean: float = 0.0, std: float = 1.0) -> float:
    return _rng.gauss(mean, std)


def gaussian_mutation(value: float, strength: float, lo: float = 0.0, hi: float = 1.0) -> float:
    """Apply Gaussian mutation and clamp to [lo, hi]."""
    delta = _rng.gauss(0.0, strength)
    return max(lo, min(hi, value + delta))


def dirichlet_sample(n: int, alpha: float = 1.0) -> list[float]:
    """Sample from Dirichlet distribution — produces n values summing to 1."""
    gamma_samples = [_rng.gammavariate(alpha, 1.0) for _ in range(n)]
    total = sum(gamma_samples)
    return [g / total for g in gamma_samples]


def tournament_select(population: list[T], fitness: list[float], k: int) -> T:
    """Tournament selection — pick best from k random candidates."""
    indices = sample(list(range(len(population))), k)
    best_idx = max(indices, key=lambda i: fitness[i])
    return population[best_idx]


def exponential_decay(initial: float, rate: float, step: int) -> float:
    return initial * math.exp(-rate * step)
