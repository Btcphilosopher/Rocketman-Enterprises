"""
NEUROSHAKE // Math Utilities
Vector mathematics, normalisation, distance metrics.
"""
from __future__ import annotations
import math
import statistics
from typing import Sequence


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


def normalise_vector(v: list[float]) -> list[float]:
    """L2 normalisation."""
    mag = math.sqrt(sum(x * x for x in v))
    return [x / mag for x in v] if mag > 1e-9 else v[:]


def dot_product(a: Sequence[float], b: Sequence[float]) -> float:
    return sum(x * y for x, y in zip(a, b))


def cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
    dot = dot_product(a, b)
    mag_a = math.sqrt(dot_product(a, a))
    mag_b = math.sqrt(dot_product(b, b))
    if mag_a < 1e-9 or mag_b < 1e-9:
        return 0.0
    return clamp(dot / (mag_a * mag_b), -1.0, 1.0)


def euclidean_distance(a: Sequence[float], b: Sequence[float]) -> float:
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def weighted_sum(values: Sequence[float], weights: Sequence[float]) -> float:
    total_w = sum(weights)
    if total_w < 1e-9:
        return 0.0
    return sum(v * w for v, w in zip(values, weights)) / total_w


def softmax(values: Sequence[float], temperature: float = 1.0) -> list[float]:
    shifted = [v / temperature for v in values]
    max_v = max(shifted)
    exps = [math.exp(v - max_v) for v in shifted]
    total = sum(exps)
    return [e / total for e in exps]


def entropy(probs: Sequence[float]) -> float:
    """Shannon entropy — measure of diversity."""
    return -sum(p * math.log(p + 1e-12) for p in probs)


def balance_score(values: Sequence[float]) -> float:
    """
    Measures how balanced/harmonious a set of values is.
    Returns 1.0 for perfectly equal values, 0.0 for extreme imbalance.
    """
    if not values:
        return 0.0
    mean_v = statistics.mean(values)
    if mean_v < 1e-9:
        return 0.0
    std_v = statistics.pstdev(values)
    cv = std_v / mean_v          # coefficient of variation
    return math.exp(-cv)          # high CV → low balance score


def lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


def smooth_step(x: float) -> float:
    x = clamp(x)
    return x * x * (3 - 2 * x)
