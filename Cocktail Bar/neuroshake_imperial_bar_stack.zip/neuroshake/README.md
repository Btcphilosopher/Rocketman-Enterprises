# NEUROSHAKE // IMPERIAL BAR STACK
### Computational Cocktail Intelligence · Anglo-Futurist Edition

> *"Where flavour meets legislation."*

A hypermodern cocktail intelligence platform that uses evolutionary computation, vector-based flavour modelling, and economic simulation to design, optimise, and validate full cocktail bar menus.

---

## System Overview

NEUROSHAKE is not a recipe generator. It is a **generative mixology + profit optimisation engine** that treats cocktail design as a multi-objective optimisation problem across five dimensions simultaneously:

| Dimension | Description |
|---|---|
| **Flavour** | 15-dimensional vector representation of sensory profile |
| **Balance** | Harmonic convergence of sweet / sour / bitter primary notes |
| **Novelty** | Sparseness in flavour space relative to a novelty archive |
| **Brand** | Anglo-futurist identity alignment score |
| **Profit** | `(price - cost) × demand_probability` |

The system evolves populations of cocktails using a genetic algorithm, builds economically-optimised menus, simulates customer behaviour across demographic archetypes, and provides an expert AI mixologist for tasting notes and improvement recommendations.

---

## Architecture

```
neuroshake/
├── main.py                    CLI entry point + UI launcher
├── config.py                  System constants, evolution/economics config
├── requirements.txt
│
├── core/
│   ├── ingredients.py         Ingredient dataclass + database loader
│   ├── flavour_model.py       Vector flavour computation + analysis
│   ├── cocktail.py            Immutable cocktail dataclass
│   ├── evolution.py           ★ Genetic algorithm engine
│   ├── scoring.py             Multi-dimensional quality scorer
│   └── constraints.py        Hard constraints + soft penalties
│
├── economics/
│   ├── cost_model.py          Ingredient + labour + waste cost model
│   ├── pricing.py             Luxury-adjusted value-based pricing
│   ├── demand_model.py        Customer archetype demand simulation
│   └── profit_engine.py       ★ Profit score computation
│
├── bar/
│   ├── menu_builder.py        ★ Optimised menu assembly
│   ├── brand_engine.py        Anglo-futurist naming + identity
│   ├── archetypes.py          Menu tier classification
│   └── customer_simulator.py  Monte Carlo customer session simulation
│
├── ai/
│   ├── mixologist.py          Expert tasting notes + improvement recommendations
│   ├── optimiser.py           Portfolio-level menu optimisation
│   └── insight_engine.py      Narrative intelligence report generation
│
├── data/
│   ├── ingredient_db.json     ★ 44-ingredient database with flavour vectors
│   ├── flavour_profiles.json  Reference flavour profiles
│   └── sample_menu.json       Sample exported menu
│
├── ui/
│   ├── dashboard.py           ★ Streamlit dashboard (7 tabbed views)
│   ├── recipe_view.py         Cocktail card renderer
│   ├── menu_view.py           Menu table renderer
│   └── charts.py              Plotly chart data preparation
│
└── utils/
    ├── math_utils.py          Vector maths, cosine similarity, balance scoring
    └── random_utils.py        Seeded RNG, Dirichlet sampling, tournament selection
```

---

## How to Run

### Install dependencies
```bash
pip install -r requirements.txt
```

### Launch Streamlit Dashboard (recommended)
```bash
python main.py --ui
# or directly:
streamlit run ui/dashboard.py
```

### CLI Mode (full pipeline)
```bash
python main.py
```

### Demo Mode (fast, reduced parameters)
```bash
python main.py --demo
```

### Export menu to JSON
```bash
python main.py --export
```

---

## How the Evolution Engine Works

The genetic algorithm runs in `core/evolution.py`:

### 1. Initialisation
A random population of `N` cocktails is generated. Each cocktail:
- Has 1–2 base spirits selected from the ingredient database
- Has 1–5 modifiers/mixers
- Has an optional garnish (30% probability)
- Ingredient ratios are sampled from a **Dirichlet distribution** — ensuring naturalistic proportions where bases dominate (35–65% of total volume)

### 2. Evaluation
Every cocktail is scored across 7 dimensions:

| Score | Formula |
|---|---|
| **Balance** | Primary taste balance (sweet/sour/bitter triangle) + secondary harmony |
| **Intensity Curve** | Proximity to ideal attack → mid-palate → finish arc |
| **Alcohol Smoothness** | Body + sweetness offset against alcohol heat |
| **Complexity** | Shannon entropy of the flavour vector |
| **Novelty** | Average distance to k-nearest neighbours in flavour space |
| **Brand Alignment** | Cosine proximity to Anglo-futurist target flavour vector |
| **Profit** | `(price - cost) × demand` normalised to [0, 1] |

**Fitness** = weighted sum of all dimensions. A synergy bonus is applied for cocktails that are simultaneously complex *and* profitable.

### 3. Selection
Tournament selection of size `k=5`. The best individual from each random tournament advances. Elite fraction (15%) survives unchanged to the next generation.

### 4. Crossover (70% probability)
Ingredient components are exchanged between two parents:
- Child A: bases from Parent A + modifiers from Parent B
- Child B: bases from Parent B + modifiers from Parent A
- Ratios are re-normalised via Dirichlet sampling

### 5. Mutation (30% probability)
Four mutation operators, selected stochastically:
- **Ratio Drift** (40%): Gaussian perturbation of all ratios
- **Ingredient Swap** (25%): Replace one modifier with a random alternative
- **Add Ingredient** (15%): Inject a new low-ratio modifier
- **Remove Ingredient** (20%): Remove the smallest-contributing non-base

### 6. Novelty Archive
A novelty archive of up to 100 cocktails prevents premature convergence. Novelty score is computed as average distance to the `k=10` nearest archived neighbours in flavour space.

---

## How the Profit Engine Works

```
profit_score = (suggested_price - total_cost) × demand_probability
               ──────────────────────────────────────────────────
                       MAX_THEORETICAL_GP (£25)
```

### Cost Model
```
total_cost = (ingredient_cost × 1.08_waste) + £1.80_labour
```

### Pricing Model
Price is computed using **luxury value-based pricing**:
```
multiplier = floor + (brand_alignment × 0.4 + complexity × 0.3) × (ceiling - floor)
price = cost × multiplier + quality_premium + novelty_premium + luxury_ingredient_uplift
```
The multiplier ranges from `2.8×` to `5.5×` cost, calibrated by brand alignment and complexity scores. Prices are capped between £8 and £28 and rounded to the nearest £0.50.

### Demand Model
Five customer archetypes contribute to demand probability:

| Archetype | Share | Price Sensitivity | Novelty Tolerance |
|---|---|---|---|
| Luxury Seeker | 25% | 15% | 60% |
| Experimental Drinker | 20% | 35% | 95% |
| Classic Cocktail Drinker | 30% | 50% | 30% |
| High-Strength Seeker | 15% | 45% | 45% |
| Social Drinker | 10% | 70% | 40% |

Each archetype has:
- A **preference vector** in flavour space
- A **price penalty function** (logistic decay above £12)
- An **ABV preference** with Gaussian tolerance

Demand = weighted average of `flavour_affinity × abv_fit × novelty_fit × price_penalty` across all archetypes.

---

## How to Extend the Ingredient Database

Edit `data/ingredient_db.json`. Each ingredient follows this schema:

```json
"my_ingredient_key": {
  "name": "Display Name",
  "category": "spirit",
  "abv": 0.40,
  "cost_per_25ml": 0.75,
  "flavour": {
    "sweetness": 0.3,
    "sourness": 0.1,
    "bitterness": 0.4,
    "saltiness": 0.0,
    "umami": 0.0,
    "alcohol_heat": 0.6,
    "herbal": 0.5,
    "spice": 0.3,
    "floral": 0.1,
    "smoke": 0.0,
    "citrus": 0.2,
    "tropical": 0.0,
    "aroma_complexity": 0.7,
    "finish_length": 0.6,
    "body": 0.45
  },
  "tags": ["base", "botanical"]
}
```

**Categories:** `spirit` | `liqueur` | `mixer` | `garnish`

**Tags that affect behaviour:**
- `base` — marks as a base spirit (every cocktail needs at least one)
- `modifier` — eligible as a supporting ingredient
- `luxury` / `premium` — triggers luxury pricing uplift
- `high-abv` — flags for alcohol constraint checking

All flavour dimensions are floats `[0.0, 1.0]`.

---

## Dashboard Views

| Tab | Contents |
|---|---|
| **Evolution** | Fitness curve, generation stats, top-10 evolved cocktails, evolution report |
| **Cocktails** | Flavour radar, recipe breakdown, ingredient cost pie, score metrics |
| **Menu** | Menu overview, performance bar chart, tier breakdowns, JSON export |
| **Economics** | Profit heatmap (demand × margin), price distribution, elasticity curve |
| **Flavour Space** | Configurable 2D scatter of population in flavour space, multi-cocktail radar |
| **AI Mixologist** | Tasting assessment, improvement protocol, variant generation, portfolio recs |
| **Customer Sim** | Monte Carlo order simulation, archetype distribution, per-cocktail volumes |

---

## Configuration

All system parameters are in `config.py`:

```python
EVOLUTION = EvolutionConfig(
    population_size=60,
    generations=40,
    mutation_rate=0.25,
    crossover_rate=0.70,
    novelty_weight=0.20,
)

ECONOMICS = EconomicsConfig(
    base_labour_cost=1.80,      # £ per cocktail
    waste_factor=0.08,           # 8%
    luxury_floor_multiplier=2.8,
    luxury_ceiling_multiplier=5.5,
)

MENU = MenuConfig(
    total_cocktails=12,
    hero_count=3,
    volume_count=5,
    experimental_count=4,
)
```

---

## Design Principles

- **Everything is a vector.** Flavour, preference, demand — all computed as high-dimensional vector operations.
- **Simulation over hardcoding.** Demand, pricing, quality — all emerge from models, never from lookup tables.
- **Optimisation over static design.** The algorithm finds solutions; humans curate them.
- **Graceful degradation.** Every module has fallbacks. The system never crashes on missing data.
- **Modular by design.** Every module is independently testable and replaceable.

---

## Example Output

```
╔══ The Imperial Commission ══╗
  Cocktails: 12
  Avg Price: £15.63
  Avg Margin: 70.9%
  Est. Weekly GP (200 covers): £6,634

  HERO COCKTAILS:
    ★ Project Monolith              £25.50 | Fitness: 0.439
    ★ Onyx Nexus Directive          £18.50 | Fitness: 0.418
    ★ Cipher Meridian Protocol      £16.00 | Fitness: 0.423
```

---

*NEUROSHAKE // IMPERIAL BAR STACK — Engineered for distinction.*
