"""
NEUROSHAKE // Charts
Data preparation utilities for Streamlit visualisations.
Returns dicts/lists that Streamlit + Plotly can consume directly.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

from config import FLAVOUR_DIMS

if TYPE_CHECKING:
    from core.cocktail import Cocktail
    from bar.menu_builder import BarMenu


def flavour_radar_data(cocktail: Cocktail) -> dict:
    """Data for a polar/radar chart of a single cocktail's flavour vector."""
    dims = FLAVOUR_DIMS
    vals = cocktail.flavour_vector or [0.0] * len(dims)
    return {
        "dimensions": [d.replace("_", " ").title() for d in dims],
        "values": [round(v, 4) for v in vals],
        "name": cocktail.name,
    }


def multi_radar_data(cocktails: list[Cocktail]) -> list[dict]:
    return [flavour_radar_data(c) for c in cocktails]


def evolution_chart_data(generation_stats: list[dict]) -> dict:
    """Line chart data: fitness over generations."""
    gens = [s["generation"] for s in generation_stats]
    return {
        "generation": gens,
        "best_fitness": [s["best_fitness"] for s in generation_stats],
        "mean_fitness": [s["mean_fitness"] for s in generation_stats],
        "worst_fitness": [s["worst_fitness"] for s in generation_stats],
        "best_profit": [s["best_profit"] for s in generation_stats],
    }


def profit_heatmap_data(cocktails: list[Cocktail]) -> dict:
    """
    Heatmap: X=demand_score, Y=margin_pct, colour=profit_score
    """
    return {
        "name": [c.name for c in cocktails],
        "demand": [round(c.demand_score, 4) for c in cocktails],
        "margin": [
            round((c.suggested_price - c.total_cost) / max(c.suggested_price, 0.01), 4)
            for c in cocktails
        ],
        "profit_score": [round(c.profit_score, 4) for c in cocktails],
        "price": [round(c.suggested_price, 2) for c in cocktails],
        "tier": [c.menu_tier for c in cocktails],
    }


def flavour_space_data(cocktails: list[Cocktail]) -> dict:
    """
    2-D projection for flavour space scatter.
    Uses sweetness vs bitterness as axes (human-interpretable).
    """
    dims = dict(enumerate(FLAVOUR_DIMS))
    sweet_idx = FLAVOUR_DIMS.index("sweetness")
    bitter_idx = FLAVOUR_DIMS.index("bitterness")
    complex_idx = FLAVOUR_DIMS.index("aroma_complexity")
    smoke_idx = FLAVOUR_DIMS.index("smoke")

    return {
        "name": [c.name for c in cocktails],
        "sweetness": [round(c.flavour_vector[sweet_idx], 4) if c.flavour_vector else 0 for c in cocktails],
        "bitterness": [round(c.flavour_vector[bitter_idx], 4) if c.flavour_vector else 0 for c in cocktails],
        "complexity": [round(c.flavour_vector[complex_idx], 4) if c.flavour_vector else 0 for c in cocktails],
        "smoke": [round(c.flavour_vector[smoke_idx], 4) if c.flavour_vector else 0 for c in cocktails],
        "fitness": [round(c.fitness, 4) for c in cocktails],
        "tier": [c.menu_tier for c in cocktails],
        "price": [round(c.suggested_price, 2) for c in cocktails],
    }


def menu_performance_bar_data(menu: BarMenu) -> dict:
    """Bar chart: cocktail names vs profit score + demand."""
    cocktails = menu.all_cocktails
    return {
        "name": [c.name for c in cocktails],
        "profit_score": [round(c.profit_score, 4) for c in cocktails],
        "demand_score": [round(c.demand_score, 4) for c in cocktails],
        "price": [round(c.suggested_price, 2) for c in cocktails],
        "tier": [c.menu_tier for c in cocktails],
    }


def ingredient_cost_breakdown(cocktail: Cocktail) -> dict:
    """Pie/bar data for ingredient cost breakdown."""
    labels = []
    costs = []
    vol = cocktail.total_volume_ml
    for ing, ratio in sorted(cocktail.ingredients, key=lambda x: -x[1]):
        labels.append(ing.name)
        costs.append(round(ing.cost_per_25ml * ratio * vol / 25.0, 4))
    return {"labels": labels, "costs": costs}
