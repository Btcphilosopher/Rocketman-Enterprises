"""
NEUROSHAKE // Recipe View
Streamlit rendering helpers for individual cocktail display.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from core.cocktail import Cocktail


def render_recipe_card(cocktail, st) -> None:
    """Render a full cocktail recipe card in Streamlit."""
    from config import FLAVOUR_DIMS

    tier_colour = {"hero": "🥇", "volume": "💎", "experimental": "🔬"}.get(cocktail.menu_tier, "🍸")
    tier_label = cocktail.menu_tier.upper()

    st.markdown(f"## {tier_colour} {cocktail.name}")
    st.caption(cocktail.description)

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Price", f"£{cocktail.suggested_price:.2f}")
    col2.metric("ABV", f"{cocktail.abv:.1%}")
    col3.metric("Fitness", f"{cocktail.fitness:.3f}")
    col4.metric("Profit Score", f"{cocktail.profit_score:.3f}")

    st.markdown("### Recipe")
    total_vol = cocktail.total_volume_ml
    for ing, ratio in sorted(cocktail.ingredients, key=lambda x: -x[1]):
        ml = ratio * total_vol
        st.markdown(
            f"- **{ing.name}** — {ml:.0f}ml _{ratio:.1%}_ "
            f"&nbsp;&nbsp;`£{ing.cost_per_25ml * ml / 25:.2f}`"
        )

    st.markdown("### Economics")
    c1, c2, c3 = st.columns(3)
    margin = (cocktail.suggested_price - cocktail.total_cost) / max(cocktail.suggested_price, 0.01)
    c1.metric("Ingredient Cost", f"£{cocktail.ingredient_cost:.2f}")
    c2.metric("Total Cost", f"£{cocktail.total_cost:.2f}")
    c3.metric("Gross Margin", f"{margin:.1%}")

    st.markdown("### Scores")
    sc1, sc2, sc3, sc4 = st.columns(4)
    sc1.metric("Balance", f"{cocktail.balance_score:.3f}")
    sc2.metric("Complexity", f"{cocktail.complexity_score:.3f}")
    sc3.metric("Novelty", f"{cocktail.novelty_score:.3f}")
    sc4.metric("Brand", f"{cocktail.brand_alignment_score:.3f}")
