"""
NEUROSHAKE // Menu View
Streamlit rendering helpers for complete menu display.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bar.menu_builder import BarMenu


TIER_ICONS = {"hero": "★", "volume": "◆", "experimental": "◇"}
TIER_COLOURS = {"hero": "#FFD700", "volume": "#00CFFF", "experimental": "#CF9FFF"}


def render_menu_overview(menu, st) -> None:
    """High-level menu summary metrics."""
    st.markdown(f"## 📋 {menu.theme}")

    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Total Cocktails", menu.total_count)
    col2.metric("Avg Price", f"£{menu.avg_price():.2f}")
    col3.metric("Avg Margin", f"{menu.avg_margin():.1%}")
    col4.metric("Est. Weekly GP", f"£{menu.total_weekly_profit_estimate():.0f}")


def render_menu_table(menu, st) -> None:
    """Render a full menu as a formatted table."""
    import pandas as pd

    rows = []
    for cocktail in menu.all_cocktails:
        icon = TIER_ICONS.get(cocktail.menu_tier, "·")
        margin = (cocktail.suggested_price - cocktail.total_cost) / max(cocktail.suggested_price, 0.01)
        rows.append({
            "Tier": f"{icon} {cocktail.menu_tier.title()}",
            "Name": cocktail.name,
            "Price": f"£{cocktail.suggested_price:.2f}",
            "Cost": f"£{cocktail.total_cost:.2f}",
            "Margin": f"{margin:.1%}",
            "ABV": f"{cocktail.abv:.1%}",
            "Demand": f"{cocktail.demand_score:.3f}",
            "Fitness": f"{cocktail.fitness:.3f}",
        })

    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)
