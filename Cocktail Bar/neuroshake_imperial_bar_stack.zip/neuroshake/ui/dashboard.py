"""
NEUROSHAKE // IMPERIAL BAR STACK
Main Streamlit Dashboard

Run with:
    streamlit run ui/dashboard.py
or from project root:
    python main.py --ui
"""
from __future__ import annotations
import sys
import os
import json
import time
import copy

# Ensure project root is on path when run directly
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import streamlit as st

# ── Page Config (must be first Streamlit call) ─────────────────────────────────
st.set_page_config(
    page_title="NEUROSHAKE // IMPERIAL BAR STACK",
    page_icon="🍸",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Custom CSS: Anglo-Futurist Dark Theme ──────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Mono:wght@300;400;500&family=Inter:wght@300;400;600&display=swap');

:root {
    --gold: #C9A84C;
    --cyan: #00CFFF;
    --bg: #0A0A0F;
    --surface: #12121A;
    --surface2: #1A1A26;
    --border: #2A2A3E;
    --text: #E8E8F0;
    --muted: #6B6B8A;
    --hero: #FFD700;
    --volume: #00CFFF;
    --experimental: #CF9FFF;
    --danger: #FF4B6E;
    --success: #00E5A0;
}

html, body, [class*="css"] {
    background-color: var(--bg) !important;
    color: var(--text) !important;
    font-family: 'Inter', sans-serif;
}

/* Header */
h1 {
    font-family: 'Bebas Neue', sans-serif !important;
    font-size: 3.2rem !important;
    letter-spacing: 0.08em !important;
    color: var(--gold) !important;
    text-transform: uppercase;
    border-bottom: 1px solid var(--border);
    padding-bottom: 0.4rem;
}
h2 {
    font-family: 'Bebas Neue', sans-serif !important;
    font-size: 1.8rem !important;
    letter-spacing: 0.06em !important;
    color: var(--cyan) !important;
}
h3 {
    font-family: 'DM Mono', monospace !important;
    font-size: 1rem !important;
    color: var(--gold) !important;
    letter-spacing: 0.04em;
    text-transform: uppercase;
}

/* Metrics */
[data-testid="metric-container"] {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    border-radius: 4px !important;
    padding: 1rem !important;
}
[data-testid="metric-container"] label {
    font-family: 'DM Mono', monospace !important;
    font-size: 0.7rem !important;
    color: var(--muted) !important;
    text-transform: uppercase;
    letter-spacing: 0.08em;
}
[data-testid="metric-container"] [data-testid="metric-value"] {
    font-family: 'Bebas Neue', sans-serif !important;
    font-size: 1.8rem !important;
    color: var(--gold) !important;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background-color: var(--surface) !important;
    border-right: 1px solid var(--border) !important;
}
[data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2 {
    font-size: 1rem !important;
    color: var(--cyan) !important;
}

/* Buttons */
.stButton > button {
    background: transparent !important;
    border: 1px solid var(--gold) !important;
    color: var(--gold) !important;
    font-family: 'DM Mono', monospace !important;
    font-size: 0.8rem !important;
    letter-spacing: 0.1em;
    text-transform: uppercase;
    border-radius: 2px !important;
    padding: 0.5rem 1.5rem !important;
    transition: all 0.2s;
}
.stButton > button:hover {
    background: var(--gold) !important;
    color: var(--bg) !important;
}

/* Dataframe / Table */
[data-testid="stDataFrame"] {
    border: 1px solid var(--border) !important;
}

/* Code / Monospace blocks */
code, pre {
    font-family: 'DM Mono', monospace !important;
    background: var(--surface2) !important;
    color: var(--cyan) !important;
    border: 1px solid var(--border) !important;
    border-radius: 2px;
}

/* Selectbox / inputs */
[data-testid="stSelectbox"], [data-testid="stSlider"] {
    background: var(--surface) !important;
}

/* Tab styling */
[data-baseweb="tab-list"] {
    background: var(--surface) !important;
    border-bottom: 1px solid var(--border) !important;
    gap: 0 !important;
}
[data-baseweb="tab"] {
    font-family: 'DM Mono', monospace !important;
    font-size: 0.75rem !important;
    letter-spacing: 0.08em !important;
    text-transform: uppercase !important;
    color: var(--muted) !important;
    padding: 0.75rem 1.25rem !important;
    border-radius: 0 !important;
}
[aria-selected="true"] {
    color: var(--gold) !important;
    border-bottom: 2px solid var(--gold) !important;
}

/* Progress bar */
.stProgress > div > div {
    background: var(--cyan) !important;
}

/* Expander */
[data-testid="stExpander"] {
    border: 1px solid var(--border) !important;
    border-radius: 2px !important;
    background: var(--surface) !important;
}

/* Caption / small text */
.stCaption, small {
    font-family: 'DM Mono', monospace !important;
    color: var(--muted) !important;
    font-size: 0.72rem !important;
}

/* Custom badges */
.tier-hero { color: #FFD700; font-weight: 600; }
.tier-volume { color: #00CFFF; font-weight: 600; }
.tier-experimental { color: #CF9FFF; font-weight: 600; }

/* Top header bar */
.top-bar {
    background: var(--surface);
    border-bottom: 1px solid var(--gold);
    padding: 0.5rem 1rem;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.system-id {
    font-family: 'DM Mono', monospace;
    font-size: 0.65rem;
    color: var(--muted);
    letter-spacing: 0.12em;
    text-transform: uppercase;
}
</style>
""", unsafe_allow_html=True)

# ── Imports ────────────────────────────────────────────────────────────────────
from config import SYSTEM_NAME, VERSION, TAGLINE, EVOLUTION, ECONOMICS, MENU
from core.ingredients import IngredientDB
from core.evolution import evolve, EvolutionResult
from bar.menu_builder import build_menu, optimise_menu_pricing
from bar.brand_engine import generate_bar_identity
from bar.customer_simulator import simulate_customer_session
from ai.mixologist import explain_cocktail, suggest_improvements, generate_variants
from ai.insight_engine import generate_evolution_report, generate_menu_intelligence_report
from ai.optimiser import analyse_menu_portfolio, recommend_replacements
from ui.charts import (
    flavour_radar_data, evolution_chart_data,
    profit_heatmap_data, flavour_space_data,
    menu_performance_bar_data, ingredient_cost_breakdown,
)
from ui.recipe_view import render_recipe_card
from ui.menu_view import render_menu_overview, render_menu_table

try:
    import plotly.graph_objects as go
    import plotly.express as px
    import pandas as pd
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False

# ── Session State ──────────────────────────────────────────────────────────────
if "evolution_result" not in st.session_state:
    st.session_state.evolution_result = None
if "menu" not in st.session_state:
    st.session_state.menu = None
if "bar_identity" not in st.session_state:
    st.session_state.bar_identity = generate_bar_identity()
if "selected_cocktail_idx" not in st.session_state:
    st.session_state.selected_cocktail_idx = 0

db = IngredientDB()

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown(f"""
<div class="top-bar">
  <span class="system-id">SYS: {SYSTEM_NAME} · VER {VERSION} · INGREDIENTS: {len(db)}</span>
  <span class="system-id">STATUS: OPERATIONAL · ALGO: GENETIC · MODE: IMPERIAL</span>
</div>
""", unsafe_allow_html=True)

st.title(SYSTEM_NAME)
st.caption(TAGLINE)

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙ SYSTEM CONTROL")

    st.markdown("### Evolution Parameters")
    pop_size = st.slider("Population Size", 20, 120, EVOLUTION.population_size, 10)
    generations = st.slider("Generations", 5, 80, EVOLUTION.generations, 5)
    mutation_rate = st.slider("Mutation Rate", 0.05, 0.60, EVOLUTION.mutation_rate, 0.05)
    novelty_weight = st.slider("Novelty Weight", 0.0, 0.5, EVOLUTION.novelty_weight, 0.05)

    st.markdown("### Menu Composition")
    hero_n = st.slider("Hero Cocktails", 1, 5, MENU.hero_count)
    volume_n = st.slider("Volume Cocktails", 2, 8, MENU.volume_count)
    exp_n = st.slider("Experimental", 1, 6, MENU.experimental_count)

    st.markdown("### Bar Identity")
    identity = st.session_state.bar_identity
    st.markdown(f"**{identity['establishment']}**")
    st.caption(identity["theme"])
    st.caption(identity["tagline"])
    if st.button("↻ NEW IDENTITY"):
        st.session_state.bar_identity = generate_bar_identity()
        st.rerun()

    st.divider()
    run_evolution = st.button("▶ RUN EVOLUTION ENGINE", type="primary", use_container_width=True)
    build_menu_btn = st.button("📋 BUILD MENU", use_container_width=True)

# ── Run Evolution ──────────────────────────────────────────────────────────────
if run_evolution:
    EVOLUTION.population_size = pop_size
    EVOLUTION.generations = generations
    EVOLUTION.mutation_rate = mutation_rate
    EVOLUTION.novelty_weight = novelty_weight

    progress_bar = st.progress(0)
    status_text = st.empty()

    def on_progress(gen, total, best_fit):
        progress_bar.progress(gen / total)
        status_text.markdown(
            f"<span class='system-id'>GEN {gen:03d}/{total} · BEST FITNESS: {best_fit:.4f}</span>",
            unsafe_allow_html=True,
        )

    with st.spinner("Evolutionary computation in progress..."):
        result = evolve(db, on_progress=on_progress)

    progress_bar.empty()
    status_text.empty()
    st.session_state.evolution_result = result

    st.success(
        f"Evolution complete — {len(result.population)} cocktails "
        f"across {len(result.generation_stats)} generations "
        f"in {result.elapsed_seconds:.1f}s"
    )

if build_menu_btn and st.session_state.evolution_result:
    population = st.session_state.evolution_result.population
    menu = build_menu(population, hero_n, volume_n, exp_n)
    menu = optimise_menu_pricing(menu)
    st.session_state.menu = menu
    st.success(f"Menu '{menu.theme}' compiled — {menu.total_count} cocktails")
elif build_menu_btn:
    st.warning("Run the evolution engine first.")

# ── Main Tabs ──────────────────────────────────────────────────────────────────
tabs = st.tabs([
    "🧬 EVOLUTION",
    "🍸 COCKTAILS",
    "📋 MENU",
    "💰 ECONOMICS",
    "🔬 FLAVOUR SPACE",
    "🧠 AI MIXOLOGIST",
    "👥 CUSTOMER SIM",
])

# ════════════════════════════════════════════════════════════════════════════════
# TAB 1: EVOLUTION
# ════════════════════════════════════════════════════════════════════════════════
with tabs[0]:
    st.markdown("## Evolutionary Computation Dashboard")

    result = st.session_state.evolution_result

    if result is None:
        st.info("Configure parameters in the sidebar and press **▶ RUN EVOLUTION ENGINE** to begin.")
        st.markdown("""
        **How the algorithm works:**
        1. A random population of cocktails is generated from the ingredient database
        2. Each cocktail is scored on flavour balance, complexity, novelty, brand alignment, and profitability
        3. The fittest individuals are selected via tournament selection
        4. Crossover exchanges ingredient components between parent cocktails
        5. Mutation drifts ratios, swaps ingredients, or adds/removes components
        6. A novelty archive prevents the population from converging to identical solutions
        7. After N generations, the highest-fitness cocktails are extracted
        """)
    else:
        stats = result.generation_stats
        r1, r2, r3, r4 = st.columns(4)
        r1.metric("Best Fitness", f"{result.best_cocktail.fitness:.4f}")
        r2.metric("Generations", len(stats))
        r3.metric("Population", len(result.population))
        r4.metric("Time", f"{result.elapsed_seconds:.1f}s")

        if PLOTLY_AVAILABLE and stats:
            chart_data = evolution_chart_data(stats)
            df_ev = pd.DataFrame(chart_data)

            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=df_ev["generation"], y=df_ev["best_fitness"],
                name="Best", line=dict(color="#FFD700", width=2),
            ))
            fig.add_trace(go.Scatter(
                x=df_ev["generation"], y=df_ev["mean_fitness"],
                name="Mean", line=dict(color="#00CFFF", width=1, dash="dot"),
            ))
            fig.add_trace(go.Scatter(
                x=df_ev["generation"], y=df_ev["worst_fitness"],
                name="Worst", line=dict(color="#6B6B8A", width=1, dash="dash"),
            ))
            fig.update_layout(
                title="Fitness Curve",
                paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
                font=dict(family="DM Mono", color="#E8E8F0"),
                xaxis=dict(title="Generation", gridcolor="#2A2A3E"),
                yaxis=dict(title="Fitness", gridcolor="#2A2A3E"),
                legend=dict(bgcolor="#12121A"),
                height=380,
            )
            st.plotly_chart(fig, use_container_width=True)

        st.markdown("### Evolution Intelligence Report")
        st.code(generate_evolution_report(stats), language=None)

        st.markdown("### Top 10 Evolved Cocktails")
        top10 = result.population[:10]
        top_data = []
        for c in top10:
            margin = (c.suggested_price - c.total_cost) / max(c.suggested_price, 0.01)
            top_data.append({
                "Name": c.name,
                "Tier": c.menu_tier.title(),
                "Fitness": f"{c.fitness:.4f}",
                "Flavour": f"{c.flavour_score:.3f}",
                "Complexity": f"{c.complexity_score:.3f}",
                "Profit": f"{c.profit_score:.3f}",
                "Price": f"£{c.suggested_price:.2f}",
                "Margin": f"{margin:.1%}",
                "ABV": f"{c.abv:.1%}",
            })
        st.dataframe(pd.DataFrame(top_data), use_container_width=True, hide_index=True)


# ════════════════════════════════════════════════════════════════════════════════
# TAB 2: COCKTAILS
# ════════════════════════════════════════════════════════════════════════════════
with tabs[1]:
    st.markdown("## Cocktail Inspector")

    result = st.session_state.evolution_result
    if result is None:
        st.info("Run the evolution engine to generate cocktails.")
    else:
        population = result.population
        cocktail_names = [f"[{i:02d}] {c.name} ({c.menu_tier})" for i, c in enumerate(population)]

        selected = st.selectbox("Select Cocktail", cocktail_names)
        idx = int(selected.split("]")[0][1:])
        cocktail = population[idx]

        render_recipe_card(cocktail, st)

        # Flavour radar
        if PLOTLY_AVAILABLE and cocktail.flavour_vector:
            st.markdown("### Flavour Radar")
            radar = flavour_radar_data(cocktail)
            dims = radar["dimensions"]
            vals = radar["values"]
            vals_closed = vals + [vals[0]]
            dims_closed = dims + [dims[0]]

            fig = go.Figure(go.Scatterpolar(
                r=vals_closed, theta=dims_closed,
                fill="toself",
                line=dict(color="#C9A84C", width=2),
                fillcolor="rgba(201,168,76,0.15)",
            ))
            fig.update_layout(
                polar=dict(
                    bgcolor="#12121A",
                    radialaxis=dict(visible=True, range=[0, 1], gridcolor="#2A2A3E", color="#6B6B8A"),
                    angularaxis=dict(gridcolor="#2A2A3E", color="#E8E8F0"),
                ),
                paper_bgcolor="#12121A",
                font=dict(family="DM Mono", size=10, color="#E8E8F0"),
                height=450,
                showlegend=False,
            )
            st.plotly_chart(fig, use_container_width=True)

        # Ingredient cost pie
        if PLOTLY_AVAILABLE:
            st.markdown("### Ingredient Cost Breakdown")
            cost_data = ingredient_cost_breakdown(cocktail)
            fig2 = go.Figure(go.Pie(
                labels=cost_data["labels"],
                values=cost_data["costs"],
                hole=0.45,
                marker=dict(colors=px.colors.sequential.Plasma),
            ))
            fig2.update_layout(
                paper_bgcolor="#12121A",
                font=dict(family="DM Mono", color="#E8E8F0"),
                height=300,
            )
            st.plotly_chart(fig2, use_container_width=True)


# ════════════════════════════════════════════════════════════════════════════════
# TAB 3: MENU
# ════════════════════════════════════════════════════════════════════════════════
with tabs[2]:
    st.markdown("## Bar Menu")

    menu = st.session_state.menu
    if menu is None:
        st.info("Build a menu using the sidebar button after running evolution.")
    else:
        render_menu_overview(menu, st)
        st.divider()

        render_menu_table(menu, st)

        st.markdown("### Menu Intelligence Report")
        st.code(generate_menu_intelligence_report(menu), language=None)

        if PLOTLY_AVAILABLE:
            st.markdown("### Menu Performance")
            perf = menu_performance_bar_data(menu)
            df_perf = pd.DataFrame(perf)
            tier_colour_map = {"hero": "#FFD700", "volume": "#00CFFF", "experimental": "#CF9FFF"}
            df_perf["colour"] = df_perf["tier"].map(tier_colour_map)

            fig = go.Figure()
            fig.add_trace(go.Bar(
                name="Profit Score",
                x=df_perf["name"],
                y=df_perf["profit_score"],
                marker_color=df_perf["colour"],
                opacity=0.85,
            ))
            fig.add_trace(go.Scatter(
                name="Demand Score",
                x=df_perf["name"],
                y=df_perf["demand_score"],
                mode="markers+lines",
                marker=dict(color="#E8E8F0", size=8),
                line=dict(color="#E8E8F0", dash="dot"),
                yaxis="y2",
            ))
            fig.update_layout(
                paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
                font=dict(family="DM Mono", color="#E8E8F0"),
                xaxis=dict(tickangle=-35, gridcolor="#2A2A3E"),
                yaxis=dict(title="Profit Score", gridcolor="#2A2A3E"),
                yaxis2=dict(title="Demand Score", overlaying="y", side="right", gridcolor="#2A2A3E"),
                legend=dict(bgcolor="#12121A"),
                height=400,
                barmode="group",
            )
            st.plotly_chart(fig, use_container_width=True)

        # Detailed cocktail cards
        st.markdown("### Hero Cocktails")
        for c in menu.hero_cocktails:
            with st.expander(f"★ {c.name} — £{c.suggested_price:.2f}"):
                render_recipe_card(c, st)

        st.markdown("### Volume Cocktails")
        for c in menu.volume_cocktails:
            with st.expander(f"◆ {c.name} — £{c.suggested_price:.2f}"):
                render_recipe_card(c, st)

        st.markdown("### Experimental Cocktails")
        for c in menu.experimental_cocktails:
            with st.expander(f"◇ {c.name} — £{c.suggested_price:.2f}"):
                render_recipe_card(c, st)

        # Export
        st.divider()
        st.markdown("### Export")
        menu_dict = {
            "theme": menu.theme,
            "identity": st.session_state.bar_identity,
            "hero": [c.to_dict() for c in menu.hero_cocktails],
            "volume": [c.to_dict() for c in menu.volume_cocktails],
            "experimental": [c.to_dict() for c in menu.experimental_cocktails],
        }
        st.download_button(
            label="⬇ EXPORT MENU (JSON)",
            data=json.dumps(menu_dict, indent=2),
            file_name="neuroshake_menu.json",
            mime="application/json",
        )


# ════════════════════════════════════════════════════════════════════════════════
# TAB 4: ECONOMICS
# ════════════════════════════════════════════════════════════════════════════════
with tabs[3]:
    st.markdown("## Economic Analysis")

    result = st.session_state.evolution_result
    if result is None:
        st.info("Run the evolution engine to generate economic data.")
    else:
        population = result.population
        if PLOTLY_AVAILABLE:
            # Profit Heatmap
            st.markdown("### Profit Heatmap — Demand × Margin")
            hmap = profit_heatmap_data(population[:60])
            df_hmap = pd.DataFrame(hmap)
            tier_colour_map = {"hero": "#FFD700", "volume": "#00CFFF", "experimental": "#CF9FFF"}
            df_hmap["colour"] = df_hmap["tier"].map(tier_colour_map)

            fig = px.scatter(
                df_hmap,
                x="demand", y="margin",
                color="profit_score",
                size="profit_score",
                text="name",
                color_continuous_scale="Plasma",
                size_max=20,
                hover_data=["name", "price", "tier"],
            )
            fig.update_traces(textposition="top center", textfont_size=8)
            fig.update_layout(
                paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
                font=dict(family="DM Mono", color="#E8E8F0"),
                xaxis=dict(title="Demand Score", gridcolor="#2A2A3E"),
                yaxis=dict(title="Gross Margin", gridcolor="#2A2A3E", tickformat=".0%"),
                coloraxis_colorbar=dict(title="Profit Score"),
                height=500,
            )
            st.plotly_chart(fig, use_container_width=True)

            # Price distribution
            st.markdown("### Price Distribution")
            prices = [c.suggested_price for c in population]
            fig2 = px.histogram(
                x=prices, nbins=20,
                color_discrete_sequence=["#C9A84C"],
                labels={"x": "Price (£)", "y": "Count"},
            )
            fig2.update_layout(
                paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
                font=dict(family="DM Mono", color="#E8E8F0"),
                height=300,
            )
            st.plotly_chart(fig2, use_container_width=True)

        # Price elasticity for best cocktail
        if result.best_cocktail:
            st.markdown(f"### Price Elasticity — {result.best_cocktail.name}")
            from economics.profit_engine import price_elasticity_curve
            price_pts = [p / 2 for p in range(16, 58)]  # £8 to £29 in £0.50 steps
            elasticity = price_elasticity_curve(result.best_cocktail, price_pts)
            df_el = pd.DataFrame(elasticity)
            if PLOTLY_AVAILABLE:
                fig3 = go.Figure()
                fig3.add_trace(go.Scatter(
                    x=df_el["price"], y=df_el["revenue_score"],
                    name="GP × Demand", line=dict(color="#00CFFF"),
                ))
                fig3.add_trace(go.Scatter(
                    x=df_el["price"], y=df_el["demand"],
                    name="Demand", line=dict(color="#FFD700", dash="dot"),
                    yaxis="y2",
                ))
                fig3.update_layout(
                    paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
                    font=dict(family="DM Mono", color="#E8E8F0"),
                    xaxis=dict(title="Price (£)", gridcolor="#2A2A3E"),
                    yaxis=dict(title="GP × Demand", gridcolor="#2A2A3E"),
                    yaxis2=dict(title="Demand", overlaying="y", side="right"),
                    height=320,
                )
                st.plotly_chart(fig3, use_container_width=True)


# ════════════════════════════════════════════════════════════════════════════════
# TAB 5: FLAVOUR SPACE
# ════════════════════════════════════════════════════════════════════════════════
with tabs[4]:
    st.markdown("## Flavour Space Visualisation")

    result = st.session_state.evolution_result
    if result is None:
        st.info("Run the evolution engine to plot the flavour space.")
    elif PLOTLY_AVAILABLE:
        population = result.population[:80]
        space = flavour_space_data(population)
        df_space = pd.DataFrame(space)

        col_x = st.selectbox("X Axis", ["sweetness", "bitterness", "citrus", "smoke", "herbal", "floral"], index=0)
        col_y = st.selectbox("Y Axis", ["bitterness", "sweetness", "herbal", "smoke", "complexity", "floral"], index=0)

        x_data = df_space.get(col_x, df_space["sweetness"])
        y_data = df_space.get(col_y, df_space["bitterness"])

        tier_colour_map = {"hero": "#FFD700", "volume": "#00CFFF", "experimental": "#CF9FFF"}
        df_space["colour"] = df_space["tier"].map(tier_colour_map)

        fig = px.scatter(
            df_space,
            x=x_data, y=y_data,
            color="tier",
            size="fitness",
            text="name",
            color_discrete_map=tier_colour_map,
            size_max=18,
            hover_data=["name", "fitness", "price"],
        )
        fig.update_traces(textposition="top center", textfont_size=7)
        fig.update_layout(
            paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
            font=dict(family="DM Mono", color="#E8E8F0"),
            xaxis=dict(title=col_x.replace("_", " ").title(), gridcolor="#2A2A3E"),
            yaxis=dict(title=col_y.replace("_", " ").title(), gridcolor="#2A2A3E"),
            height=550,
        )
        st.plotly_chart(fig, use_container_width=True)

        # Multi-radar comparison
        st.markdown("### Multi-Cocktail Radar Comparison")
        top5 = result.population[:5]
        if PLOTLY_AVAILABLE:
            from config import FLAVOUR_DIMS
            fig_r = go.Figure()
            colours = ["#FFD700", "#00CFFF", "#CF9FFF", "#00E5A0", "#FF4B6E"]
            for i, c in enumerate(top5):
                dims = [d.replace("_", " ").title() for d in FLAVOUR_DIMS]
                vals = (c.flavour_vector or [0.0] * len(FLAVOUR_DIMS)) + [c.flavour_vector[0] if c.flavour_vector else 0.0]
                dims_closed = dims + [dims[0]]
                fig_r.add_trace(go.Scatterpolar(
                    r=vals, theta=dims_closed,
                    name=c.name[:25],
                    line=dict(color=colours[i % len(colours)], width=1.5),
                    fillcolor=f"rgba({','.join(str(int(c_v,16)) for c_v in [colours[i % len(colours)][1:3], colours[i % len(colours)][3:5], colours[i % len(colours)][5:7]])},0.05)" if len(colours[i % len(colours)]) == 7 else "rgba(0,0,0,0.05)",
                ))
            fig_r.update_layout(
                polar=dict(
                    bgcolor="#12121A",
                    radialaxis=dict(visible=True, range=[0, 1], gridcolor="#2A2A3E", color="#6B6B8A"),
                    angularaxis=dict(gridcolor="#2A2A3E", color="#E8E8F0"),
                ),
                paper_bgcolor="#12121A",
                font=dict(family="DM Mono", size=9, color="#E8E8F0"),
                height=500,
                legend=dict(bgcolor="#12121A"),
            )
            st.plotly_chart(fig_r, use_container_width=True)


# ════════════════════════════════════════════════════════════════════════════════
# TAB 6: AI MIXOLOGIST
# ════════════════════════════════════════════════════════════════════════════════
with tabs[5]:
    st.markdown("## AI Mixologist")
    st.caption("Expert system analysis: explanations, improvements, variants, profitable modifications.")

    result = st.session_state.evolution_result
    if result is None:
        st.info("Run the evolution engine to activate the AI Mixologist.")
    else:
        population = result.population
        cocktail_names = [f"[{i:02d}] {c.name}" for i, c in enumerate(population)]
        selected = st.selectbox("Analyse Cocktail", cocktail_names, key="ai_select")
        idx = int(selected.split("]")[0][1:])
        cocktail = population[idx]

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("### Tasting Assessment")
            st.code(explain_cocktail(cocktail), language=None)

        with col2:
            st.markdown("### Improvement Protocol")
            suggestions = suggest_improvements(cocktail)
            for i, s in enumerate(suggestions, 1):
                st.markdown(f"**{i}.** {s}")

            st.markdown("### Profitable Modifications")
            mods = suggest_improvements(cocktail)
            from ai.mixologist import identify_profitable_modifications
            profit_mods = identify_profitable_modifications(cocktail)
            if profit_mods:
                for mod in profit_mods:
                    with st.expander(f"[{mod['action']}] {mod['ingredient']}"):
                        st.markdown(mod["detail"])
                        st.caption(f"Profit impact: **{mod['profit_impact']}** | Flavour impact: **{mod['flavour_impact']}**")
            else:
                st.success("No urgent modifications identified.")

        st.markdown("### Variant Generation")
        variants = generate_variants(cocktail, n=4)
        v_cols = st.columns(len(variants))
        for col, v in zip(v_cols, variants):
            with col:
                st.markdown(f"**{v['name']}**")
                st.caption(f"Type: {v['type']}")
                st.markdown(v["modification"])
                st.metric("Price Delta", v["expected_price_delta"])

        if st.session_state.menu:
            st.divider()
            st.markdown("### Menu Optimisation Recommendations")
            recs = recommend_replacements(st.session_state.menu, population)
            if recs:
                for r in recs:
                    st.markdown(
                        f"**Remove:** {r['remove']} (profit: {r['remove_profit']:.3f}) → "
                        f"**Add:** {r['add']} (profit: {r['add_profit']:.3f}) · "
                        f"Improvement: **+{r['improvement']}%**"
                    )
            else:
                st.success("Menu portfolio is optimally composed.")


# ════════════════════════════════════════════════════════════════════════════════
# TAB 7: CUSTOMER SIMULATOR
# ════════════════════════════════════════════════════════════════════════════════
with tabs[6]:
    st.markdown("## Customer Archetype Simulator")
    st.caption("Monte Carlo simulation of customer behaviour across demographic segments.")

    menu = st.session_state.menu
    if menu is None:
        st.info("Build a menu to run the customer simulation.")
    else:
        n_customers = st.slider("Simulated Customers", 50, 2000, 500, 50)

        if st.button("▶ RUN SIMULATION"):
            with st.spinner("Simulating customer sessions..."):
                sim_result = simulate_customer_session(menu.all_cocktails, n_customers)

            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Total Revenue", f"£{sim_result['total_revenue']:,.2f}")
            c2.metric("Total GP", f"£{sim_result['total_profit']:,.2f}")
            c3.metric("Avg Spend", f"£{sim_result['avg_spend_per_customer']:.2f}")
            c4.metric("Avg GP/Customer", f"£{sim_result['avg_profit_per_customer']:.2f}")

            st.markdown(f"**Top Seller:** {sim_result['top_cocktail']}")
            st.markdown(f"**Bottom Seller:** {sim_result['bottom_cocktail']}")

            if PLOTLY_AVAILABLE:
                # Order distribution
                order_data = sim_result["order_counts"]
                id_to_name = {c.id: c.name for c in menu.all_cocktails}
                orders_named = {id_to_name.get(k, k): v for k, v in order_data.items()}
                df_orders = pd.DataFrame({
                    "cocktail": list(orders_named.keys()),
                    "orders": list(orders_named.values()),
                }).sort_values("orders", ascending=True)

                fig = px.bar(
                    df_orders, x="orders", y="cocktail",
                    orientation="h",
                    color="orders",
                    color_continuous_scale="Plasma",
                    labels={"orders": "Orders", "cocktail": ""},
                )
                fig.update_layout(
                    paper_bgcolor="#12121A", plot_bgcolor="#0A0A0F",
                    font=dict(family="DM Mono", color="#E8E8F0"),
                    height=400,
                    showlegend=False,
                )
                st.plotly_chart(fig, use_container_width=True)

                # Archetype breakdown
                arch_data = sim_result["archetype_distribution"]
                arch_labels = {
                    "luxury_seeker": "Luxury Seeker",
                    "experimental_drinker": "Experimental",
                    "classic_drinker": "Classic",
                    "high_strength_seeker": "High Strength",
                    "social_drinker": "Social",
                }
                fig2 = go.Figure(go.Pie(
                    labels=[arch_labels.get(k, k) for k in arch_data.keys()],
                    values=list(arch_data.values()),
                    hole=0.4,
                    marker=dict(colors=["#FFD700", "#00CFFF", "#CF9FFF", "#FF4B6E", "#00E5A0"]),
                ))
                fig2.update_layout(
                    title="Customer Archetype Distribution",
                    paper_bgcolor="#12121A",
                    font=dict(family="DM Mono", color="#E8E8F0"),
                    height=320,
                )
                st.plotly_chart(fig2, use_container_width=True)

        # Archetype reference
        st.markdown("### Customer Archetype Reference")
        from economics.demand_model import ARCHETYPES
        for arch in ARCHETYPES:
            with st.expander(f"{arch.name} ({arch.population_share:.0%} of traffic)"):
                st.markdown(arch.description)
                ac1, ac2, ac3 = st.columns(3)
                ac1.metric("Price Sensitivity", f"{arch.price_sensitivity:.0%}")
                ac2.metric("Novelty Tolerance", f"{arch.novelty_tolerance:.0%}")
                ac3.metric("ABV Preference", f"{arch.abv_preference:.0%}")


# ── Footer ─────────────────────────────────────────────────────────────────────
st.divider()
st.markdown(
    f"<div class='system-id' style='text-align:center;padding:0.5rem'>"
    f"{SYSTEM_NAME} v{VERSION} · Computational Cocktail Intelligence · Anglo-Futurist Edition · "
    f"Ingredient Database: {len(db)} items"
    f"</div>",
    unsafe_allow_html=True,
)
