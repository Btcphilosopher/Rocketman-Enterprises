"""
NEUROSHAKE // IMPERIAL BAR STACK
Main entry point.

Usage:
    python main.py              # CLI mode: run evolution + print menu
    python main.py --ui         # Launch Streamlit dashboard
    python main.py --demo       # Quick demo (5 gens, small population)
    python main.py --export     # Run evolution + export menu to JSON
"""
from __future__ import annotations
import sys
import os
import json
import argparse
import time

# ── Ensure project root on path ────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))


def print_banner() -> None:
    banner = r"""
 ███╗   ██╗███████╗██╗   ██╗██████╗  ██████╗ ███████╗██╗  ██╗ █████╗ ██╗  ██╗███████╗
 ████╗  ██║██╔════╝██║   ██║██╔══██╗██╔═══██╗██╔════╝██║  ██║██╔══██╗██║ ██╔╝██╔════╝
 ██╔██╗ ██║█████╗  ██║   ██║██████╔╝██║   ██║███████╗███████║███████║█████╔╝ █████╗
 ██║╚██╗██║██╔══╝  ██║   ██║██╔══██╗██║   ██║╚════██║██╔══██║██╔══██║██╔═██╗ ██╔══╝
 ██║ ╚████║███████╗╚██████╔╝██║  ██║╚██████╔╝███████║██║  ██║██║  ██║██║  ██╗███████╗
 ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝

 ██╗███╗   ███╗██████╗ ███████╗██████╗ ██╗ █████╗ ██╗      ██████╗  █████╗ ██████╗
 ██║████╗ ████║██╔══██╗██╔════╝██╔══██╗██║██╔══██╗██║      ██╔══██╗██╔══██╗██╔══██╗
 ██║██╔████╔██║██████╔╝█████╗  ██████╔╝██║███████║██║      ██████╔╝███████║██████╔╝
 ██║██║╚██╔╝██║██╔═══╝ ██╔══╝  ██╔══██╗██║██╔══██║██║      ██╔══██╗██╔══██║██╔══██╗
 ██║██║ ╚═╝ ██║██║     ███████╗██║  ██║██║██║  ██║███████╗ ██████╔╝██║  ██║██║  ██║
 ╚═╝╚═╝     ╚═╝╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝

              ══ S T A C K ══
   Computational Cocktail Intelligence · Anglo-Futurist Edition
"""
    print(banner)
    print("─" * 90)


def cli_run(demo: bool = False) -> None:
    """Run the full pipeline in CLI mode."""
    from config import EVOLUTION, MENU
    from core.ingredients import IngredientDB
    from core.evolution import evolve
    from bar.menu_builder import build_menu, optimise_menu_pricing
    from bar.brand_engine import generate_bar_identity
    from bar.customer_simulator import simulate_customer_session
    from ai.mixologist import explain_cocktail, suggest_improvements
    from ai.insight_engine import generate_evolution_report, generate_menu_intelligence_report

    print_banner()

    if demo:
        EVOLUTION.population_size = 20
        EVOLUTION.generations = 8
        print("[ DEMO MODE: reduced parameters ]")

    db = IngredientDB()
    print(f"[ LOADED: {len(db)} ingredients ]\n")

    # ── Evolution ──────────────────────────────────────────────────────────────
    print("EVOLUTION ENGINE — INITIATING")
    print(f"  Population: {EVOLUTION.population_size}  |  Generations: {EVOLUTION.generations}")
    print(f"  Mutation rate: {EVOLUTION.mutation_rate}  |  Novelty weight: {EVOLUTION.novelty_weight}")
    print("─" * 60)

    last_gen = [0]
    def on_progress(gen, total, best_fit):
        if gen % max(1, total // 10) == 0 or gen == total:
            bar = "█" * int(20 * gen / total) + "░" * (20 - int(20 * gen / total))
            print(f"  [{bar}] GEN {gen:03d}/{total}  BEST: {best_fit:.4f}", end="\r")
        last_gen[0] = gen

    t = time.time()
    result = evolve(db, on_progress=on_progress)
    print(f"\n\n  Completed in {result.elapsed_seconds:.2f}s\n")

    # ── Evolution Report ───────────────────────────────────────────────────────
    print(generate_evolution_report(result.generation_stats))
    print()

    # ── Best Cocktail ──────────────────────────────────────────────────────────
    best = result.best_cocktail
    print(explain_cocktail(best))
    print()

    print("IMPROVEMENT RECOMMENDATIONS:")
    for i, s in enumerate(suggest_improvements(best), 1):
        print(f"  {i}. {s}")
    print()

    # ── Menu Build ─────────────────────────────────────────────────────────────
    print("═" * 60)
    print("MENU BUILDER — ASSEMBLING OPTIMISED BAR MENU")
    print("═" * 60)

    menu = build_menu(result.population)
    menu = optimise_menu_pricing(menu)
    print(menu.summary())
    print()

    # ── Intelligence Report ────────────────────────────────────────────────────
    print(generate_menu_intelligence_report(menu))
    print()

    # ── Customer Simulation ────────────────────────────────────────────────────
    print("═" * 60)
    print("CUSTOMER SIMULATION — 500 COVERS")
    print("═" * 60)
    sim = simulate_customer_session(menu.all_cocktails, 500)
    print(f"  Total Revenue:       £{sim['total_revenue']:,.2f}")
    print(f"  Total Gross Profit:  £{sim['total_profit']:,.2f}")
    print(f"  Avg Spend/Customer:  £{sim['avg_spend_per_customer']:.2f}")
    print(f"  Avg GP/Customer:     £{sim['avg_profit_per_customer']:.2f}")
    print(f"  Top Seller:          {sim['top_cocktail']}")
    print(f"  Bottom Seller:       {sim['bottom_cocktail']}")

    # ── Bar Identity ──────────────────────────────────────────────────────────
    print()
    identity = generate_bar_identity()
    print("═" * 60)
    print("BAR IDENTITY")
    print("═" * 60)
    for k, v in identity.items():
        print(f"  {k.title():<20} {v}")

    return result, menu


def export_run() -> None:
    """Run evolution and export menu to JSON."""
    result, menu = cli_run()

    output = {
        "metadata": {
            "system": "NEUROSHAKE // IMPERIAL BAR STACK",
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "generations": len(result.generation_stats),
            "final_best_fitness": result.best_cocktail.fitness,
        },
        "menu": {
            "theme": menu.theme,
            "hero": [c.to_dict() for c in menu.hero_cocktails],
            "volume": [c.to_dict() for c in menu.volume_cocktails],
            "experimental": [c.to_dict() for c in menu.experimental_cocktails],
        },
        "top_10_population": [c.to_dict() for c in result.population[:10]],
    }

    fname = f"neuroshake_export_{int(time.time())}.json"
    with open(fname, "w", encoding="utf-8") as f:
        json.dump(output, f, indent=2)
    print(f"\n[ EXPORTED: {fname} ]")


def launch_ui() -> None:
    """Launch the Streamlit dashboard."""
    import subprocess
    dashboard_path = os.path.join(os.path.dirname(__file__), "ui", "dashboard.py")
    print("Launching NEUROSHAKE dashboard...")
    subprocess.run(
        [sys.executable, "-m", "streamlit", "run", dashboard_path,
         "--server.headless", "false",
         "--theme.base", "dark"],
        cwd=os.path.dirname(__file__),
    )


# ── Argument Parser ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="NEUROSHAKE // Imperial Bar Stack",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py             # Full CLI pipeline
  python main.py --demo      # Quick demo (fast, reduced parameters)
  python main.py --ui        # Launch Streamlit dashboard
  python main.py --export    # Run + export menu to JSON
        """,
    )
    parser.add_argument("--ui", action="store_true", help="Launch Streamlit dashboard")
    parser.add_argument("--demo", action="store_true", help="Demo mode (faster, smaller)")
    parser.add_argument("--export", action="store_true", help="Run + export JSON")

    args = parser.parse_args()

    if args.ui:
        launch_ui()
    elif args.export:
        export_run()
    else:
        cli_run(demo=args.demo)
