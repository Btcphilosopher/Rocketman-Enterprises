"""
NEUROSHAKE // AI Mixologist
Reasoning layer that explains cocktails, suggests improvements,
identifies profitable modifications, and generates variant recipes.
No external API required — rule-based expert system.
"""
from __future__ import annotations
import textwrap
from typing import TYPE_CHECKING

from config import FLAVOUR_DIMS, ECONOMICS
from core.flavour_model import analyse_flavour_profile, dominant_flavour_notes, flavour_profile_label
from utils.math_utils import clamp

if TYPE_CHECKING:
    from core.cocktail import Cocktail
    from core.ingredients import Ingredient


# ── Flavour Vocabulary ─────────────────────────────────────────────────────────

_INTENSITY_LABELS = {
    (0.0, 0.2): "whisper of",
    (0.2, 0.4): "subtle",
    (0.4, 0.6): "clear",
    (0.6, 0.8): "pronounced",
    (0.8, 1.0): "dominant",
}

def _intensity_label(v: float) -> str:
    for (lo, hi), label in _INTENSITY_LABELS.items():
        if lo <= v < hi:
            return label
    return "intense"


_COCKTAIL_PRAISE = [
    "architecturally sound",
    "remarkably coherent",
    "calibrated with precision",
    "exhibiting structural integrity",
    "tastefully resolved",
    "demonstrating compelling logic",
]

_COCKTAIL_CRITIQUE = [
    "structurally compromised",
    "tonally inconsistent",
    "requiring editorial intervention",
    "exhibiting flavour dysregulation",
    "in breach of palatial protocol",
]


# ── Core Analysis Functions ────────────────────────────────────────────────────

def explain_cocktail(cocktail: Cocktail) -> str:
    """
    Generate a detailed, Anglo-futurist tasting note and technical analysis.
    """
    if not cocktail.flavour_vector:
        return "Insufficient data. Formula unresolved."

    analysis = analyse_flavour_profile(cocktail.flavour_vector)
    dims = dict(zip(FLAVOUR_DIMS, cocktail.flavour_vector))
    notes = dominant_flavour_notes(cocktail.flavour_vector, top_n=5)
    profile_label = flavour_profile_label(analysis)

    # Tasting note
    tasting_parts = []
    if dims.get("citrus", 0) > 0.4:
        tasting_parts.append(f"a {_intensity_label(dims['citrus'])} citrus attack")
    if dims.get("herbal", 0) > 0.4:
        tasting_parts.append(f"{_intensity_label(dims['herbal'])} botanical depth")
    if dims.get("smoke", 0) > 0.3:
        tasting_parts.append(f"a {_intensity_label(dims['smoke'])} smoky undertone")
    if dims.get("sweetness", 0) > 0.4:
        tasting_parts.append(f"{_intensity_label(dims['sweetness'])} sweetness")
    if dims.get("bitterness", 0) > 0.4:
        tasting_parts.append(f"a {_intensity_label(dims['bitterness'])} bitter counterpoint")
    if dims.get("floral", 0) > 0.35:
        tasting_parts.append(f"{_intensity_label(dims['floral'])} floral elevation")
    if dims.get("spice", 0) > 0.35:
        tasting_parts.append(f"{_intensity_label(dims['spice'])} spice warmth")
    if dims.get("tropical", 0) > 0.3:
        tasting_parts.append(f"{_intensity_label(dims['tropical'])} tropical resonance")

    tasting_note = (
        ", ".join(tasting_parts[:3]) + ". " +
        (", ".join(tasting_parts[3:]) + "." if len(tasting_parts) > 3 else "")
    ).strip()

    if not tasting_note or tasting_note == ".":
        tasting_note = "A clean, direct expression. Minimal interference."

    # Quality assessment
    overall_quality = (cocktail.flavour_score + cocktail.balance_score + cocktail.complexity_score) / 3.0
    if overall_quality > 0.65:
        quality_stmt = f"This formula is {_COCKTAIL_PRAISE[hash(cocktail.id) % len(_COCKTAIL_PRAISE)]}."
    elif overall_quality > 0.45:
        quality_stmt = "This formula performs adequately within its parameters."
    else:
        quality_stmt = f"This formula is {_COCKTAIL_CRITIQUE[hash(cocktail.id) % len(_COCKTAIL_CRITIQUE)]}."

    # Economic assessment
    margin_pct = (cocktail.suggested_price - cocktail.total_cost) / max(cocktail.suggested_price, 0.01)
    if margin_pct > 0.72:
        econ_stmt = f"Economically exceptional: {margin_pct:.0%} gross margin at £{cocktail.suggested_price:.2f}."
    elif margin_pct > 0.60:
        econ_stmt = f"Commercially viable: {margin_pct:.0%} margin at £{cocktail.suggested_price:.2f}."
    else:
        econ_stmt = f"Margin under pressure: {margin_pct:.0%} at £{cocktail.suggested_price:.2f}. Review ingredient costs."

    # ABV note
    abv_note = ""
    if cocktail.abv > 0.30:
        abv_note = f"Spirit-forward at {cocktail.abv:.0%} ABV. Serve with discipline."
    elif cocktail.abv > 0.15:
        abv_note = f"Moderate at {cocktail.abv:.0%} ABV. Sessionable."
    else:
        abv_note = f"Low ABV at {cocktail.abv:.0%}. Accessible format."

    lines = [
        f"═══ MIXOLOGIST'S ASSESSMENT: {cocktail.name.upper()} ═══",
        "",
        f"PROFILE:    {profile_label}",
        f"NOTES:      {', '.join(notes)}",
        "",
        f"TASTING:    {tasting_note}",
        "",
        f"VERDICT:    {quality_stmt}",
        f"ECONOMICS:  {econ_stmt}",
        f"STRENGTH:   {abv_note}",
        "",
        f"SCORES ─────────────────────────────",
        f"  Flavour Balance:   {cocktail.balance_score:.3f}",
        f"  Complexity:        {cocktail.complexity_score:.3f}",
        f"  Novelty:           {cocktail.novelty_score:.3f}",
        f"  Brand Alignment:   {cocktail.brand_alignment_score:.3f}",
        f"  Profit Score:      {cocktail.profit_score:.3f}",
        f"  Fitness:           {cocktail.fitness:.3f}",
        "",
        f"RECIPE ─────────────────────────────",
        cocktail.recipe_str(),
        "",
        f"DESCRIPTION: {cocktail.description}",
    ]
    return "\n".join(lines)


def suggest_improvements(cocktail: Cocktail) -> list[str]:
    """
    Identify weaknesses and suggest targeted modifications.
    Returns a list of actionable improvement suggestions.
    """
    from core.ingredients import IngredientDB
    db = IngredientDB()

    suggestions = []
    dims = dict(zip(FLAVOUR_DIMS, cocktail.flavour_vector)) if cocktail.flavour_vector else {}

    # ── Balance Issues ─────────────────────────────────────────────────────────
    sweet = dims.get("sweetness", 0)
    sour = dims.get("sourness", 0)
    bitter = dims.get("bitterness", 0)

    if sweet > 0.65 and sour < 0.20:
        suggestions.append(
            "BALANCE: Excessive sweetness detected. Add fresh lime or lemon juice "
            "(ratio 0.08–0.12) to introduce acid balance."
        )
    if sour > 0.65 and sweet < 0.15:
        suggestions.append(
            "BALANCE: Over-acidic profile. Increase simple syrup or honey syrup "
            "(ratio +0.05) to soften the sour edge."
        )
    if bitter > 0.70 and sweet < 0.25:
        suggestions.append(
            "BALANCE: Bitterness unmitigated. A small measure of gomme syrup or "
            "triple sec would provide structural contrast."
        )

    # ── Complexity ────────────────────────────────────────────────────────────
    if cocktail.complexity_score < 0.40:
        suggestions.append(
            "COMPLEXITY: Formula lacks sensory depth. Consider adding Green Chartreuse "
            "or Bénédictine (ratio 0.05–0.08) to elevate aroma complexity."
        )

    # ── Alcohol integration ────────────────────────────────────────────────────
    heat = dims.get("alcohol_heat", 0)
    body = dims.get("body", 0)
    if heat > 0.65 and body < 0.25:
        suggestions.append(
            "TEXTURE: High alcohol heat with insufficient body. Egg white or coconut "
            "cream (ratio 0.08) would provide mouthfeel integration."
        )

    # ── Aroma ─────────────────────────────────────────────────────────────────
    aroma = dims.get("aroma_complexity", 0)
    if aroma < 0.35:
        suggestions.append(
            "AROMA: Low aromatic complexity. A few dashes of Angostura bitters would "
            "dramatically expand the nose without altering balance."
        )

    # ── Profit ────────────────────────────────────────────────────────────────
    margin_pct = (cocktail.suggested_price - cocktail.total_cost) / max(cocktail.suggested_price, 0.01)
    if margin_pct < 0.60:
        high_cost = [(ing, r) for ing, r in cocktail.ingredients if ing.cost_per_25ml > 0.90]
        if high_cost:
            names = [ing.name for ing, _ in high_cost]
            suggestions.append(
                f"PROFIT: Margin at {margin_pct:.0%}. Premium ingredient(s) "
                f"{', '.join(names)} are compressing GP. "
                "Reduce ratio or substitute for a cost-equivalent modifier."
            )
        else:
            suggestions.append(
                f"PROFIT: Margin at {margin_pct:.0%}. Consider reducing "
                f"total_volume_ml or removing low-impact ingredients."
            )

    # ── Brand ─────────────────────────────────────────────────────────────────
    if cocktail.brand_alignment_score < 0.45:
        suggestions.append(
            "BRAND: Below Anglo-futurist identity threshold. The formula lacks the "
            "herbal depth and complexity expected of the Imperial Bar aesthetic. "
            "Consider Islay whisky, absinthe, or green chartreuse as character anchors."
        )

    if not suggestions:
        suggestions.append(
            "ASSESSMENT: Formula operating within acceptable parameters. "
            "No critical modifications required. Minor ratio refinements may be explored."
        )

    return suggestions


def generate_variants(
    cocktail: Cocktail,
    n: int = 3,
) -> list[dict]:
    """
    Propose named variant recipes without running full evolution.
    Returns descriptions of suggested modifications.
    """
    dims = dict(zip(FLAVOUR_DIMS, cocktail.flavour_vector)) if cocktail.flavour_vector else {}

    variants = []

    # Variant 1: Smoky Edition
    if dims.get("smoke", 0) < 0.30:
        variants.append({
            "name": f"{cocktail.name} — Smoke Protocol",
            "modification": "Replace base spirit with Islay Single Malt or Artisanal Mezcal. "
                           "Add smoked rosemary garnish. Expected: +0.25 smoke, +0.15 brand alignment.",
            "expected_price_delta": "+£1.50–£2.50",
            "type": "premium_upgrade",
        })

    # Variant 2: Low-ABV Edition
    if cocktail.abv > 0.18:
        variants.append({
            "name": f"{cocktail.name} — Temperance Edition",
            "modification": "Reduce base spirit ratio by 40%. Compensate with tonic water or "
                           "premium soda. Target ABV: 8–10%. Same flavour architecture, "
                           "accessible format.",
            "expected_price_delta": "-£2.00",
            "type": "accessibility",
        })

    # Variant 3: Seasonal
    variants.append({
        "name": f"{cocktail.name} — Winter Commission",
        "modification": "Add 5ml Bénédictine + 3 dashes Angostura bitters. "
                       "Reduce fresh juice by half. Serve warm. "
                       "Transforms the formula into a hot toddy format for cold service.",
        "expected_price_delta": "+£0.50",
        "type": "seasonal",
    })

    # Variant 4: Luxury Upgrade
    if cocktail.ingredient_cost < 3.0:
        variants.append({
            "name": f"{cocktail.name} — Imperial Reserve",
            "modification": "Upgrade base spirit to VSOP Cognac or Navy Strength Gin. "
                           "Add edible gold garnish. Reposition price to menu ceiling. "
                           "Transforms volume cocktail into hero tier.",
            "expected_price_delta": "+£4.00–£7.00",
            "type": "luxury_upgrade",
        })

    return variants[:n]


def identify_profitable_modifications(cocktail: Cocktail) -> list[dict]:
    """
    Find modifications that increase profit_score × flavour_score simultaneously.
    Returns ranked list of cost-reducing or price-increasing interventions.
    """
    ops = []

    # Check each ingredient's cost contribution
    total_cost = cocktail.total_cost
    for ing, ratio in sorted(cocktail.ingredients, key=lambda x: -x[0].cost_per_25ml):
        contribution = ing.cost_per_25ml * ratio * cocktail.total_volume_ml / 25.0
        cost_share = contribution / max(total_cost, 0.01)
        if cost_share > 0.30 and not ing.is_garnish():
            ops.append({
                "action": "RATIO_REDUCE",
                "ingredient": ing.name,
                "detail": f"Reduce {ing.name} ratio by 15%. "
                         f"Current cost contribution: {cost_share:.0%}. "
                         f"Estimated GP improvement: +£{contribution * 0.15:.2f}/cocktail.",
                "profit_impact": "medium",
                "flavour_impact": "low",
            })

    # Demand improvement
    if cocktail.demand_score < 0.40:
        ops.append({
            "action": "ADD_SWEETNESS",
            "ingredient": "Simple Syrup / Gomme",
            "detail": "Demand score below 0.40. A touch of sweetness (ratio 0.05) "
                     "would increase appeal to social drinkers and classic drinkers, "
                     "boosting demand by an estimated +0.08.",
            "profit_impact": "high",
            "flavour_impact": "low",
        })

    # Price justification
    if cocktail.brand_alignment_score > 0.60 and cocktail.suggested_price < 16.0:
        ops.append({
            "action": "PRICE_INCREASE",
            "ingredient": "—",
            "detail": f"Brand alignment score {cocktail.brand_alignment_score:.2f} supports "
                     f"premium positioning. Current price £{cocktail.suggested_price:.2f} "
                     f"may be undervalued by £2–3. Test at £{cocktail.suggested_price + 2:.2f}.",
            "profit_impact": "high",
            "flavour_impact": "none",
        })

    return ops
