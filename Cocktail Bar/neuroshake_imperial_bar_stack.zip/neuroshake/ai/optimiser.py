"""
NEUROSHAKE // AI Optimiser
Portfolio-level menu optimisation strategies.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from bar.menu_builder import BarMenu
    from core.cocktail import Cocktail


def analyse_menu_portfolio(menu: BarMenu) -> dict:
    """High-level portfolio analysis of a complete menu."""
    cocktails = menu.all_cocktails
    if not cocktails:
        return {}

    prices = [c.suggested_price for c in cocktails]
    margins = [(c.suggested_price - c.total_cost) / max(c.suggested_price, 0.01) for c in cocktails]
    demands = [c.demand_score for c in cocktails]
    profits = [c.profit_score for c in cocktails]

    avg = lambda lst: sum(lst) / len(lst)

    # Identify outliers
    profit_threshold = avg(profits) * 0.6
    demand_threshold = avg(demands) * 0.6
    underperformers = [c for c in cocktails if c.profit_score < profit_threshold]
    stars = [c for c in cocktails if c.profit_score > avg(profits) * 1.3]

    return {
        "total_cocktails": len(cocktails),
        "avg_price": round(avg(prices), 2),
        "avg_margin_pct": round(avg(margins) * 100, 1),
        "avg_demand": round(avg(demands), 4),
        "avg_profit_score": round(avg(profits), 4),
        "price_range": (round(min(prices), 2), round(max(prices), 2)),
        "star_performers": [c.name for c in stars],
        "underperformers": [c.name for c in underperformers],
        "weekly_gp_estimate": round(menu.total_weekly_profit_estimate(), 2),
        "portfolio_health": _portfolio_health_score(menu),
    }


def _portfolio_health_score(menu: BarMenu) -> str:
    avg_margin = menu.avg_margin()
    if avg_margin > 0.72:
        return "EXCELLENT — Menu operating at premium margin"
    elif avg_margin > 0.62:
        return "GOOD — Solid commercial performance"
    elif avg_margin > 0.52:
        return "ACCEPTABLE — Margin optimisation recommended"
    else:
        return "CRITICAL — Immediate cost review required"


def recommend_replacements(menu: BarMenu, candidates: list[Cocktail]) -> list[dict]:
    """
    Identify which cocktails should be replaced and with what.
    """
    recommendations = []
    cocktails = menu.all_cocktails
    if not cocktails or not candidates:
        return recommendations

    avg_profit = sum(c.profit_score for c in cocktails) / len(cocktails)

    for current in sorted(cocktails, key=lambda c: c.profit_score)[:3]:
        # Find best replacement from candidates not already in menu
        current_ids = {c.id for c in cocktails}
        replacements = [c for c in candidates if c.id not in current_ids]
        if not replacements:
            continue
        best = max(replacements, key=lambda c: c.profit_score * 0.6 + c.fitness * 0.4)
        if best.profit_score > current.profit_score * 1.1:
            recommendations.append({
                "remove": current.name,
                "remove_profit": round(current.profit_score, 4),
                "add": best.name,
                "add_profit": round(best.profit_score, 4),
                "improvement": round((best.profit_score - current.profit_score) * 100, 1),
                "reason": f"Profit uplift +{(best.profit_score - current.profit_score):.3f}",
            })

    return recommendations
