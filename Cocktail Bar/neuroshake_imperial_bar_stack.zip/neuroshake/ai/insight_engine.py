"""
NEUROSHAKE // Insight Engine
Generates narrative intelligence reports about cocktails and menus.
"""
from __future__ import annotations
from typing import TYPE_CHECKING

from ai.optimiser import analyse_menu_portfolio

if TYPE_CHECKING:
    from core.cocktail import Cocktail
    from bar.menu_builder import BarMenu


def generate_evolution_report(stats: list[dict]) -> str:
    if not stats:
        return "No evolution data available."

    first = stats[0]
    last = stats[-1]
    peak = max(stats, key=lambda s: s["best_fitness"])

    improvement = ((last["best_fitness"] - first["best_fitness"]) / max(first["best_fitness"], 0.01)) * 100

    lines = [
        "╔══ EVOLUTIONARY COMPUTATION REPORT ══╗",
        f"  Generations run:    {len(stats)}",
        f"  Initial best:       {first['best_fitness']:.4f}",
        f"  Final best:         {last['best_fitness']:.4f}",
        f"  Peak fitness:       {peak['best_fitness']:.4f}  (gen {peak['generation']})",
        f"  Total improvement:  +{improvement:.1f}%",
        f"  Final mean fitness: {last['mean_fitness']:.4f}",
        "",
        f"  Peak cocktail:      {peak['best_name']}",
        "",
        "  CONVERGENCE: " + (
            "Strong convergence detected." if last["mean_fitness"] > last["best_fitness"] * 0.85
            else "Healthy diversity maintained."
        ),
    ]
    return "\n".join(lines)


def generate_menu_intelligence_report(menu: BarMenu) -> str:
    analysis = analyse_menu_portfolio(menu)
    if not analysis:
        return "Insufficient data for intelligence report."

    lines = [
        "╔══ MENU INTELLIGENCE REPORT ══╗",
        f"  Theme:              {menu.theme}",
        f"  Portfolio Health:   {analysis['portfolio_health']}",
        "",
        f"  Cocktails:          {analysis['total_cocktails']}",
        f"  Avg Price:          £{analysis['avg_price']}",
        f"  Avg Margin:         {analysis['avg_margin_pct']}%",
        f"  Price Range:        £{analysis['price_range'][0]} – £{analysis['price_range'][1]}",
        f"  Est. Weekly GP:     £{analysis['weekly_gp_estimate']} (200 covers)",
        "",
        "  STAR PERFORMERS:",
    ]
    for name in analysis["star_performers"]:
        lines.append(f"    ★ {name}")
    if not analysis["star_performers"]:
        lines.append("    None identified above threshold.")

    lines.append("  UNDERPERFORMERS:")
    for name in analysis["underperformers"]:
        lines.append(f"    ⚠ {name}")
    if not analysis["underperformers"]:
        lines.append("    None below threshold. Portfolio balanced.")

    return "\n".join(lines)
