package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Anglo-Futurism Color Palette
val MidnightBlack = Color(0xFF0A0B0C)
val DeepMidnight = Color(0xFF121417)
val BritishRacingGreen = Color(0xFF0D321F)
val DeepNavy = Color(0xFF101B2B)
val WarmCream = Color(0xFFFBF9F4)
val OffWhite = Color(0xFFF3F0E8)
val WarmOak = Color(0xFF3E2E25)
val BrassGold = Color(0xFFC5A059)
val RichCopper = Color(0xFFC06D44)
val SlateGrey = Color(0xFF373E43)
val GlassWhite = Color(0xE6FFFFFF)
val TranslucentBrass = Color(0x1AC5A059)

// Theme primary colors for standard dark/light mappings
val PrimaryGold = Color(0xFFC5A059)
val SecondaryGreen = Color(0xFF12432B)
val TertiaryCopper = Color(0xFFC06D44)
