package com.example.data

import android.util.Log
import com.example.data.api.CocktailApi
import com.example.data.api.FavoriteRequest
import com.example.data.db.CocktailDao
import com.example.data.db.IngredientDao
import com.example.data.db.CocktailCollectionDao
import com.example.data.model.Cocktail
import com.example.data.model.Ingredient
import com.example.data.model.CocktailCollection
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.onStart
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CocktailRepository(
    private val cocktailDao: CocktailDao,
    private val ingredientDao: IngredientDao,
    private val collectionDao: CocktailCollectionDao,
    private val api: CocktailApi
) {
    private val TAG = "CocktailRepository"

    val allCocktails: Flow<List<Cocktail>> = cocktailDao.getAllCocktails()
        .onStart { checkAndSeedDatabase() }

    val favoriteCocktails: Flow<List<Cocktail>> = cocktailDao.getFavoriteCocktails()

    val allIngredients: Flow<List<Ingredient>> = ingredientDao.getAllIngredients()
        .onStart { checkAndSeedDatabase() }

    val allCollections: Flow<List<CocktailCollection>> = collectionDao.getAllCollections()
        .onStart { checkAndSeedDatabase() }

    fun getCocktailById(id: String): Flow<Cocktail?> {
        return cocktailDao.getCocktailById(id)
    }

    fun getCollectionById(id: String): Flow<CocktailCollection?> {
        return collectionDao.getCollectionById(id)
    }

    private suspend fun checkAndSeedDatabase() = withContext(Dispatchers.IO) {
        try {
            val cocktailsCount = cocktailDao.getAllCocktails().first().size
            if (cocktailsCount == 0) {
                Log.d(TAG, "Database is empty. Seeding beautiful Anglo-Futurist assets...")
                cocktailDao.insertCocktails(MockData.seedCocktails)
                ingredientDao.insertIngredients(MockData.seedIngredients)
                collectionDao.insertCollections(MockData.seedCollections)
                Log.d(TAG, "Database seeded successfully.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error checking/seeding database", e)
        }
    }

    suspend fun refreshData(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Refreshing data from API...")
            // Fetch from Retrofit
            val remoteCocktails = api.getCocktails()
            val remoteIngredients = api.getIngredients()
            val remoteCollections = api.getCollections()

            if (remoteCocktails.isNotEmpty()) {
                cocktailDao.insertCocktails(remoteCocktails)
            }
            if (remoteIngredients.isNotEmpty()) {
                ingredientDao.insertIngredients(remoteIngredients)
            }
            if (remoteCollections.isNotEmpty()) {
                collectionDao.insertCollections(remoteCollections)
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "API call failed (expected if backend URL is not live), utilizing cached Room database. Error: ${e.message}")
            // Fallback to local seeding if empty
            checkAndSeedDatabase()
            Result.failure(e)
        }
    }

    suspend fun toggleFavorite(id: String, isFavorite: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Update local Room database immediately
            cocktailDao.updateFavoriteStatus(id, isFavorite)

            // Try to sync with server
            try {
                api.toggleFavorite(FavoriteRequest(id, isFavorite))
            } catch (e: Exception) {
                Log.w(TAG, "Failed to sync favorite with server, maintained offline favorite status.")
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun search(query: String): Flow<List<Cocktail>> {
        // Local fuzzy filter for rapid response, or we can use SQLite LIKE queries
        // Let's return local cocktails filtered by query
        // The API also supports: GET /search?q=query
        return cocktailDao.getAllCocktails() // We will do search mapping in the ViewModel
    }
}
