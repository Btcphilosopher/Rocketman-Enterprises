package com.example.data.db

import androidx.room.*
import com.example.data.model.Cocktail
import kotlinx.coroutines.flow.Flow

@Dao
interface CocktailDao {
    @Query("SELECT * FROM cocktails")
    fun getAllCocktails(): Flow<List<Cocktail>>

    @Query("SELECT * FROM cocktails WHERE id = :id")
    fun getCocktailById(id: String): Flow<Cocktail?>

    @Query("SELECT * FROM cocktails WHERE isFavorite = 1")
    fun getFavoriteCocktails(): Flow<List<Cocktail>>

    @Query("SELECT * FROM cocktails WHERE category = :category")
    fun getCocktailsByCategory(category: String): Flow<List<Cocktail>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCocktails(cocktails: List<Cocktail>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCocktail(cocktail: Cocktail)

    @Query("UPDATE cocktails SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavoriteStatus(id: String, isFavorite: Boolean)

    @Query("DELETE FROM cocktails")
    suspend fun clearAll()
}
