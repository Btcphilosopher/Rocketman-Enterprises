package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Cocktail
import com.example.ui.MainUiState
import com.example.ui.components.CocktailCard
import com.example.ui.components.CollectionCard
import com.example.ui.components.EmptyState
import com.example.ui.theme.BrassGold
import com.example.ui.theme.RichCopper

@Composable
fun CollectionsScreen(
    uiState: MainUiState,
    onCollectionSelect: (String?) -> Unit,
    onCocktailClick: (String) -> Unit,
    onFavoriteToggle: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedCollection = uiState.collections.find { it.id == uiState.selectedCollectionId }

    val collectionCocktails = remember(uiState.cocktails, selectedCollection) {
        if (selectedCollection == null) emptyList()
        else uiState.cocktails.filter { it.id in selectedCollection.cocktailIds }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (selectedCollection == null) {
            // Display Grid/List of all Curated Collections
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "CURATED COMPILATIONS",
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Aesthetic Taste Bundles",
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("collections_grid_list"),
                contentPadding = PaddingValues(start = 20.dp, top = 0.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(uiState.collections) { collection ->
                    CollectionCard(
                        collection = collection,
                        onCollectionClick = { onCollectionSelect(it) }
                    )
                }
            }
        } else {
            // Detail view of a selected collection
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "COLLECTION COMPILATION",
                        style = MaterialTheme.typography.labelLarge,
                        color = BrassGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.2.sp
                    )
                    TextButton(onClick = { onCollectionSelect(null) }) {
                        Text("All Collections", color = RichCopper, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = selectedCollection.name,
                    style = MaterialTheme.typography.displaySmall,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = selectedCollection.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (collectionCocktails.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyState(
                        message = "This curated collection is currently undergoing revision. Check back shortly.",
                        onActionClick = { onCollectionSelect(null) },
                        actionText = "Go Back"
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .testTag("collection_cocktails_list"),
                    contentPadding = PaddingValues(start = 20.dp, top = 0.dp, end = 20.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(collectionCocktails) { cocktail ->
                        CocktailCard(
                            cocktail = cocktail,
                            onCocktailClick = onCocktailClick,
                            onFavoriteToggle = onFavoriteToggle
                        )
                    }
                }
            }
        }
    }
}
