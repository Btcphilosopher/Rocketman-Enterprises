package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainUiState
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.RichCopper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    uiState: MainUiState,
    onLoginClick: (String, String) -> Boolean,
    onLogoutClick: () -> Unit,
    onThemeToggle: (Boolean) -> Unit,
    onUnitToggle: (Boolean) -> Unit,
    onNotificationsToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    var usernameInput by remember { mutableStateOf("") }
    var pinInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
            .padding(bottom = 32.dp)
    ) {
        // Title Block
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "PRIVATE CHAMBER",
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Member Club Card",
                style = MaterialTheme.typography.displaySmall,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Profile Membership Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .height(180.dp),
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.4f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                BritishRacingGreen,
                                MidnightBlack,
                                BritishRacingGreen.copy(alpha = 0.8f)
                            )
                        )
                    )
            ) {
                // Design aesthetics (Brass logo ornament)
                Box(
                    modifier = Modifier
                        .size(120.dp)
                        .offset(x = 220.dp, y = (-20).dp)
                        .background(BrassGold.copy(alpha = 0.08f), CircleShape)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "THE ANGLO CLUB".uppercase(),
                            style = MaterialTheme.typography.labelMedium,
                            color = BrassGold,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )

                        Icon(
                            imageVector = Icons.Default.Casino,
                            contentDescription = null,
                            tint = BrassGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = if (uiState.isLoggedIn) uiState.username.uppercase() else "GUEST BARTENDER",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (uiState.isLoggedIn) Icons.Default.VerifiedUser else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (uiState.isLoggedIn) BrassGold else RichCopper,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (uiState.isLoggedIn) "PRO MEMBER RESERVES SYNCED" else "UNAUTHORIZED ACCESS (GUEST)",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (uiState.isLoggedIn) BrassGold else RichCopper,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Authorize / Sign In Section if guest
        if (!uiState.isLoggedIn) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Text(
                    text = "VINTAGE ACCESS PRIVILEGES",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrassGold,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Provide your Speakeasy credentials to unlock professional recipes and sync favourites online.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = usernameInput,
                    onValueChange = { usernameInput = it },
                    label = { Text("Bar Member Username") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_username_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrassGold,
                        focusedLabelColor = BrassGold
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = pinInput,
                    onValueChange = { pinInput = it },
                    label = { Text("Access Pin (e.g., 1923)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_pin_input"),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = BrassGold,
                        focusedLabelColor = BrassGold
                    ),
                    shape = RoundedCornerShape(8.dp)
                )

                if (uiState.loginError != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = uiState.loginError,
                        color = RichCopper,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val success = onLoginClick(usernameInput, pinInput)
                        if (success) {
                            usernameInput = ""
                            pinInput = ""
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("login_submit_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = BritishRacingGreen,
                        contentColor = BrassGold
                    ),
                    border = BorderStroke(1.dp, BrassGold),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("AUTHORIZE MEMBER PASS", fontWeight = FontWeight.Bold)
                }
            }
        } else {
            // Logout option
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
            ) {
                Button(
                    onClick = onLogoutClick,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("logout_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = RichCopper,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("REVOKE SESSION ACCESS", fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // System Settings
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = "APPLICATION SETTINGS",
                style = MaterialTheme.typography.titleMedium,
                color = BrassGold,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Dark Mode Switch
            SettingsRow(
                icon = Icons.Outlined.DarkMode,
                title = "Anglo-Futurist Dark Mode",
                subtitle = "Deep Midnight Black aesthetic with warm lighting filters.",
                action = {
                    Switch(
                        checked = uiState.isDarkMode,
                        onCheckedChange = onThemeToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BrassGold,
                            checkedTrackColor = BritishRacingGreen
                        )
                    )
                }
            )

            // Measurement Switch
            SettingsRow(
                icon = Icons.Outlined.Scale,
                title = "Metric Measurements",
                subtitle = "Toggle between British metric (ml/cl) and Imperial (oz).",
                action = {
                    Switch(
                        checked = uiState.isMetric,
                        onCheckedChange = onUnitToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BrassGold,
                            checkedTrackColor = BritishRacingGreen
                        )
                    )
                }
            )

            // Notifications Switch
            SettingsRow(
                icon = Icons.Outlined.Notifications,
                title = "Club Notifications",
                subtitle = "Receive alerts when special vintage recipes are released.",
                action = {
                    Switch(
                        checked = uiState.isNotificationsEnabled,
                        onCheckedChange = onNotificationsToggle,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = BrassGold,
                            checkedTrackColor = BritishRacingGreen
                        )
                    )
                }
            )

            // Offline Check
            SettingsRow(
                icon = Icons.Outlined.CloudDownload,
                title = "Offline Recipe Reserves",
                subtitle = "Checked cocktails are loaded into persistent local SQLite.",
                action = {
                    Box(
                        modifier = Modifier
                            .background(BritishRacingGreen.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "SECURE LOCAL",
                            style = MaterialTheme.typography.labelSmall,
                            color = BrassGold,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )

            // Accessibility Check
            SettingsRow(
                icon = Icons.Outlined.Accessibility,
                title = "TalkBack & Large Typography",
                subtitle = "Fully compatible with system font-scaling and screen readers.",
                action = {
                    Box(
                        modifier = Modifier
                            .background(RichCopper.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "WCAG OK",
                            style = MaterialTheme.typography.labelSmall,
                            color = RichCopper,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            )
        }
    }
}

@Composable
fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    action: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = BrassGold,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        action()
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
}
