package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "cocktail_collections")
@JsonClass(generateAdapter = true)
data class CocktailCollection(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val imageUrl: String,
    val cocktailIds: List<String> = emptyList()
)
