package com.example.data.api

import com.example.data.model.Cocktail
import com.example.data.model.Ingredient
import com.example.data.model.CocktailCollection
import retrofit2.http.*

interface CocktailApi {

    @GET("cocktails")
    suspend fun getCocktails(): List<Cocktail>

    @GET("cocktail/{id}")
    suspend fun getCocktailById(@Path("id") id: String): Cocktail

    @GET("categories")
    suspend fun getCategories(): List<String>

    @GET("ingredients")
    suspend fun getIngredients(): List<Ingredient>

    @GET("collections")
    suspend fun getCollections(): List<CocktailCollection>

    @GET("search")
    suspend fun searchCocktails(@Query("q") query: String): List<Cocktail>

    @POST("favourites")
    suspend fun toggleFavorite(@Body request: FavoriteRequest): FavoriteResponse

    @POST("login")
    suspend fun login(@Body request: LoginRequest): LoginResponse
}

data class FavoriteRequest(
    val id: String,
    val isFavorite: Boolean
)

data class FavoriteResponse(
    val success: Boolean,
    val id: String,
    val isFavorite: Boolean
)

data class LoginRequest(
    val username: String,
    val pin: String
)

data class LoginResponse(
    val token: String,
    val username: String,
    val success: Boolean
)
