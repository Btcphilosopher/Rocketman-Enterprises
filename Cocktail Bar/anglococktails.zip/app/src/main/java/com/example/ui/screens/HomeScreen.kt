package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.RestaurantMenu
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Cocktail
import com.example.ui.MainUiState
import com.example.ui.components.CategoryTile
import com.example.ui.components.CocktailCard
import com.example.ui.components.CollectionCard
import com.example.ui.components.HeroBanner
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.RichCopper

@Composable
fun HomeScreen(
    uiState: MainUiState,
    onCocktailClick: (String) -> Unit,
    onCollectionClick: (String) -> Unit,
    onCategorySelect: (String) -> Unit,
    onFavoriteToggle: (String, Boolean) -> Unit,
    onDiscoverNavigate: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val featuredCocktail = uiState.cocktails.firstOrNull { it.id == "royal_jubilee" } 
        ?: uiState.cocktails.firstOrNull()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Welcome and Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "AngloCocktails".uppercase(),
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Craft Perfect Drinks.",
                style = MaterialTheme.typography.displayMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )
        }

        // Hero Banner
        if (featuredCocktail != null) {
            Box(modifier = Modifier.padding(horizontal = 20.dp)) {
                HeroBanner(
                    featuredCocktail = featuredCocktail,
                    onHeroClick = onCocktailClick
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Spirit Categories Row
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Classic Base Spirits",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onDiscoverNavigate) {
                    Text("View All", color = BrassGold)
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = BrassGold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            val spiritCategories = listOf("Gin", "Whisky", "Rum", "Vodka", "Champagne", "Non-Alcoholic")
            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(spiritCategories) { category ->
                    CategoryTile(
                        category = category,
                        isSelected = uiState.selectedCategory == category,
                        onClick = { onCategorySelect(category) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Curated Collections Carousels
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "Curated Collections",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            LazyRow(
                contentPadding = PaddingValues(horizontal = 20.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(uiState.collections) { collection ->
                    Box(modifier = Modifier.width(300.dp)) {
                        CollectionCard(
                            collection = collection,
                            onCollectionClick = onCollectionClick
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Professional Bartender Quote
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.2f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Outlined.AutoAwesome,
                    contentDescription = null,
                    tint = BrassGold,
                    modifier = Modifier.size(28.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "\"A superb cocktail isn't merely mixed; it is engineered. The balance between the dilution of frozen ice and the sharp botanical botanics of London Dry Gin requires patience, quality glassware, and precise temperature execution.\"",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    fontFamily = FontFamily.Serif,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 24.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "— HEAD BARTENDER, THE ANGLO CLUB, SOHO",
                    style = MaterialTheme.typography.labelMedium,
                    color = RichCopper,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Popular Recipes Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            Text(
                text = "Popular Recipes",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            val popularList = uiState.cocktails.take(4)
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                popularList.forEach { cocktail ->
                    CocktailCard(
                        cocktail = cocktail,
                        onCocktailClick = onCocktailClick,
                        onFavoriteToggle = onFavoriteToggle
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}
