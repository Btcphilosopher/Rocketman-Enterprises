package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.with
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.LibraryBooks
import androidx.compose.material.icons.outlined.LocalBar
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.CocktailViewModel
import com.example.ui.CocktailViewModelFactory
import com.example.ui.screens.*
import com.example.ui.theme.AngloCocktailsTheme
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BritishRacingGreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val appContainer = (application as AngloCocktailsApplication).container
            val viewModel: CocktailViewModel = viewModel(
                factory = CocktailViewModelFactory(appContainer.cocktailRepository)
            )
            val uiState by viewModel.uiState.collectAsState()

            AngloCocktailsTheme(darkTheme = uiState.isDarkMode) {
                MainAppScreen(
                    viewModel = viewModel,
                    uiState = uiState
                )
            }
        }
    }
}

sealed class Screen(
    val route: String,
    val title: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector,
    val testTag: String
) {
    object Home : Screen("home", "Home", Icons.Filled.Home, Icons.Outlined.Home, "bottom_nav_home")
    object Discover : Screen("discover", "Discover", Icons.Filled.LocalBar, Icons.Outlined.LocalBar, "bottom_nav_discover")
    object Collections : Screen("collections", "Collections", Icons.Filled.LibraryBooks, Icons.Outlined.LibraryBooks, "bottom_nav_collections")
    object Saved : Screen("saved", "Saved", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "bottom_nav_saved")
    object Profile : Screen("profile", "Profile", Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle, "bottom_nav_profile")
}

@Composable
fun MainAppScreen(
    viewModel: CocktailViewModel,
    uiState: com.example.ui.MainUiState
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val navigationItems = listOf(
        Screen.Home,
        Screen.Discover,
        Screen.Collections,
        Screen.Saved,
        Screen.Profile
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            // Show BottomBar only on core navigation destinations
            val isCoreDestination = currentRoute in navigationItems.map { it.route }
            if (isCoreDestination) {
                NavigationBar(
                    modifier = Modifier.testTag("app_bottom_navigation"),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    navigationItems.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            modifier = Modifier.testTag(screen.testTag),
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.activeIcon else screen.inactiveIcon,
                                    contentDescription = screen.title,
                                    tint = if (isSelected) BrassGold else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    color = if (isSelected) BrassGold else MaterialTheme.colorScheme.onSurfaceVariant,
                                    style = MaterialTheme.typography.labelMedium
                                )
                            },
                            selected = isSelected,
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = BritishRacingGreen.copy(alpha = 0.25f)
                            ),
                            onClick = {
                                if (currentRoute != screen.route) {
                                    // Reset screen selectors when switching tabs
                                    if (screen == Screen.Discover) viewModel.selectCategory(null)
                                    if (screen == Screen.Collections) viewModel.selectCollection(null)

                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (uiState.isLoading) {
                com.example.ui.components.LoadingSkeleton()
            } else if (uiState.error != null) {
                com.example.ui.components.ErrorState(
                    errorMessage = uiState.error,
                    onRetryClick = { viewModel.refresh() }
                )
            } else {
                NavHost(
                    navController = navController,
                    startDestination = Screen.Home.route,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable(Screen.Home.route) {
                        HomeScreen(
                            uiState = uiState,
                            onCocktailClick = { id ->
                                viewModel.selectCocktail(id)
                                navController.navigate("cocktail_detail")
                            },
                            onCollectionClick = { id ->
                                viewModel.selectCollection(id)
                                navController.navigate(Screen.Collections.route)
                            },
                            onCategorySelect = { category ->
                                viewModel.selectCategory(category)
                                navController.navigate(Screen.Discover.route)
                            },
                            onFavoriteToggle = { id, isFav ->
                                viewModel.toggleFavorite(id, isFav)
                            },
                            onDiscoverNavigate = {
                                viewModel.selectCategory(null)
                                navController.navigate(Screen.Discover.route)
                            }
                        )
                    }

                    composable(Screen.Discover.route) {
                        BrowserScreen(
                            uiState = uiState,
                            onSearchQueryChange = { q -> viewModel.updateSearchQuery(q) },
                            onCategorySelect = { cat -> viewModel.selectCategory(cat) },
                            onCocktailClick = { id ->
                                viewModel.selectCocktail(id)
                                navController.navigate("cocktail_detail")
                            },
                            onFavoriteToggle = { id, isFav -> viewModel.toggleFavorite(id, isFav) }
                        )
                    }

                    composable(Screen.Collections.route) {
                        CollectionsScreen(
                            uiState = uiState,
                            onCollectionSelect = { id -> viewModel.selectCollection(id) },
                            onCocktailClick = { id ->
                                viewModel.selectCocktail(id)
                                navController.navigate("cocktail_detail")
                            },
                            onFavoriteToggle = { id, isFav -> viewModel.toggleFavorite(id, isFav) }
                        )
                    }

                    composable(Screen.Saved.route) {
                        FavouritesScreen(
                            uiState = uiState,
                            onCocktailClick = { id ->
                                viewModel.selectCocktail(id)
                                navController.navigate("cocktail_detail")
                            },
                            onFavoriteToggle = { id, isFav -> viewModel.toggleFavorite(id, isFav) }
                        )
                    }

                    composable(Screen.Profile.route) {
                        ProfileScreen(
                            uiState = uiState,
                            onLoginClick = { username, pin -> viewModel.login(username, pin) },
                            onLogoutClick = { viewModel.logout() },
                            onThemeToggle = { viewModel.setDarkMode(it) },
                            onUnitToggle = { viewModel.setMetric(it) },
                            onNotificationsToggle = { viewModel.setNotificationsEnabled(it) }
                        )
                    }

                    composable("cocktail_detail") {
                        DetailScreen(
                            cocktailId = uiState.selectedCocktailId,
                            cocktails = uiState.cocktails,
                            onBackClick = { navController.popBackStack() },
                            onFavoriteToggle = { id, isFav -> viewModel.toggleFavorite(id, isFav) },
                            onIngredientClick = { ingredientId ->
                                viewModel.selectIngredient(ingredientId)
                                navController.navigate("ingredient_detail")
                            }
                        )
                    }

                    composable("ingredient_detail") {
                        IngredientDetailScreen(
                            ingredientId = uiState.selectedIngredientId,
                            ingredients = uiState.ingredients,
                            cocktails = uiState.cocktails,
                            onBackClick = { navController.popBackStack() },
                            onCocktailClick = { id ->
                                viewModel.selectCocktail(id)
                                navController.navigate("cocktail_detail")
                            },
                            onFavoriteToggle = { id, isFav -> viewModel.toggleFavorite(id, isFav) }
                        )
                    }
                }
            }
        }
    }
}
