package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.model.Cocktail
import com.example.ui.components.EmptyState
import com.example.ui.theme.BrassGold
import com.example.ui.theme.BritishRacingGreen
import com.example.ui.theme.MidnightBlack
import com.example.ui.theme.RichCopper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    cocktailId: String?,
    cocktails: List<Cocktail>,
    onBackClick: () -> Unit,
    onFavoriteToggle: (String, Boolean) -> Unit,
    onIngredientClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val cocktail = cocktails.find { it.id == cocktailId }
    val scrollState = rememberScrollState()

    if (cocktail == null) {
        Box(
            modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
            contentAlignment = Alignment.Center
        ) {
            EmptyState(
                message = "The requested cocktail recipe could not be recovered.",
                onActionClick = onBackClick,
                actionText = "Go Back"
            )
        }
        return
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
            ) {
                // Header Image block
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(LocalContext.current)
                            .data(cocktail.imageUrl)
                            .crossfade(true)
                            .build(),
                        contentDescription = cocktail.name,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    // Overlay gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        MidnightBlack.copy(alpha = 0.4f),
                                        MidnightBlack.copy(alpha = 0.9f)
                                    )
                                )
                            )
                    )

                    // Title block over picture bottom
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(20.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(BritishRacingGreen, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = cocktail.category.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = BrassGold,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = cocktail.name,
                            style = MaterialTheme.typography.displayLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Details Content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Description
                    Text(
                        text = cocktail.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    // Key details row (Glass type, strength, diff, temp, prep)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                            .border(1.dp, BrassGold.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        DetailItem("GLASS", cocktail.glassType)
                        DetailItem("STRENGTH", cocktail.strength)
                        DetailItem("DIFFICULTY", cocktail.difficulty)
                        DetailItem("PREPARATION", cocktail.prepTime)
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Ingredients checklist section
                    Text(
                        text = "INGREDIENTS",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrassGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        cocktail.ingredients.forEach { rawIngredient ->
                            // Attempt to parse out quick matches for clickable ingredients
                            val matchingId = when {
                                rawIngredient.contains("Gin", ignoreCase = true) -> "gin"
                                rawIngredient.contains("Scotch", ignoreCase = true) || rawIngredient.contains("Whisky", ignoreCase = true) -> "scotch"
                                rawIngredient.contains("Earl Grey", ignoreCase = true) -> "earl_grey"
                                rawIngredient.contains("Elderflower", ignoreCase = true) -> "elderflower"
                                rawIngredient.contains("Vermouth", ignoreCase = true) -> "sweet_vermouth"
                                else -> null
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.4f))
                                    .then(
                                        if (matchingId != null) {
                                            Modifier
                                                .border(BorderStroke(0.5.dp, BrassGold.copy(alpha = 0.2f)), RoundedCornerShape(6.dp))
                                                .clickable { onIngredientClick(matchingId) }
                                                .padding(12.dp)
                                        } else {
                                            Modifier.padding(12.dp)
                                        }
                                    ),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(BrassGold)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = rawIngredient,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )

                                if (matchingId != null) {
                                    Text(
                                        text = "VIEW INFO",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = RichCopper,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Preparation Method (Step Card list)
                    Text(
                        text = "PREPARATION METHOD",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrassGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    cocktail.steps.forEachIndexed { index, step ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = String.format("%02d", index + 1),
                                style = MaterialTheme.typography.headlineLarge,
                                color = RichCopper,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(36.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = step,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.05f))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Garnish and Serving Temperature Info Box
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(BritishRacingGreen.copy(alpha = 0.05f), RoundedCornerShape(8.dp))
                            .border(1.dp, BritishRacingGreen.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Text(
                                text = "RECOMMENDED GARNISH",
                                style = MaterialTheme.typography.labelSmall,
                                color = RichCopper,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = cocktail.garnish,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.Medium
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "SERVING TEMPERATURE",
                                style = MaterialTheme.typography.labelSmall,
                                color = RichCopper,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = cocktail.servingTemp,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // History Section
                    Text(
                        text = "HISTORICAL ANTECEDENTS",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrassGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = cocktail.history,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                        fontFamily = FontFamily.Serif,
                        lineHeight = 24.sp
                    )

                    Spacer(modifier = Modifier.height(28.dp))

                    // Professional Bartender Notes
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "PROFESSIONAL TECHNIQUE",
                                style = MaterialTheme.typography.labelLarge,
                                color = BrassGold,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = cocktail.professionalNotes,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                                lineHeight = 20.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(28.dp))

                    // Food Pairings
                    Text(
                        text = "SUGGESTED FOOD PAIRINGS",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrassGold,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = cocktail.foodPairings,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f)
                    )

                    Spacer(modifier = Modifier.height(40.dp))
                }
            }

            // Top overlay bar buttons (Back & Fav)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Floating Back Button
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier
                        .size(44.dp)
                        .background(MidnightBlack.copy(alpha = 0.6f), CircleShape)
                        .testTag("detail_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Go back",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Floating Favorite Button
                IconButton(
                    onClick = { onFavoriteToggle(cocktail.id, !cocktail.isFavorite) },
                    modifier = Modifier
                        .size(44.dp)
                        .background(MidnightBlack.copy(alpha = 0.6f), CircleShape)
                        .testTag("detail_favorite_button")
                ) {
                    Icon(
                        imageVector = if (cocktail.isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = if (cocktail.isFavorite) "Remove from favorites" else "Add to favorites",
                        tint = if (cocktail.isFavorite) RichCopper else Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DetailItem(
    label: String,
    value: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 4.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = RichCopper,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}
