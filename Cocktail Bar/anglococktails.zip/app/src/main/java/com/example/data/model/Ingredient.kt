package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "ingredients")
@JsonClass(generateAdapter = true)
data class Ingredient(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val origin: String, // "London, England", "Jalisco, Mexico"
    val flavorProfile: String, // "Juniper-forward, citrus", "Peaty, smoky"
    val alcoholPercentage: Double,
    val suggestedSubstitutes: List<String> = emptyList(),
    val imageUrl: String
)
