package com.example.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.model.Cocktail
import com.example.data.model.Ingredient
import com.example.data.model.CocktailCollection

@Database(
    entities = [
        Cocktail::class,
        Ingredient::class,
        CocktailCollection::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun cocktailDao(): CocktailDao
    abstract fun ingredientDao(): IngredientDao
    abstract fun cocktailCollectionDao(): CocktailCollectionDao
}
