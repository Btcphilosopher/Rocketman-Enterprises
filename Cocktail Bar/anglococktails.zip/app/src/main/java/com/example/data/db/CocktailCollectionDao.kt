package com.example.data.db

import androidx.room.*
import com.example.data.model.CocktailCollection
import kotlinx.coroutines.flow.Flow

@Dao
interface CocktailCollectionDao {
    @Query("SELECT * FROM cocktail_collections")
    fun getAllCollections(): Flow<List<CocktailCollection>>

    @Query("SELECT * FROM cocktail_collections WHERE id = :id")
    fun getCollectionById(id: String): Flow<CocktailCollection?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCollections(collections: List<CocktailCollection>)

    @Query("DELETE FROM cocktail_collections")
    suspend fun clearAll()
}
