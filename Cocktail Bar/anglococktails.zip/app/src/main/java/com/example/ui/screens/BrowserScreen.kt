package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Cocktail
import com.example.ui.MainUiState
import com.example.ui.components.CategoryTile
import com.example.ui.components.CocktailCard
import com.example.ui.components.EmptyState
import com.example.ui.components.SearchBar
import com.example.ui.theme.BrassGold
import com.example.ui.theme.RichCopper

@Composable
fun BrowserScreen(
    uiState: MainUiState,
    onSearchQueryChange: (String) -> Unit,
    onCategorySelect: (String?) -> Unit,
    onCocktailClick: (String) -> Unit,
    onFavoriteToggle: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val filteredCocktails = remember(uiState.cocktails, uiState.searchQuery, uiState.selectedCategory) {
        uiState.cocktails.filter { cocktail ->
            val matchesSearch = cocktail.name.contains(uiState.searchQuery, ignoreCase = true) ||
                    cocktail.tagline.contains(uiState.searchQuery, ignoreCase = true) ||
                    cocktail.description.contains(uiState.searchQuery, ignoreCase = true) ||
                    cocktail.ingredients.any { it.contains(uiState.searchQuery, ignoreCase = true) }

            val matchesCategory = uiState.selectedCategory == null ||
                    cocktail.category.equals(uiState.selectedCategory, ignoreCase = true)

            matchesSearch && matchesCategory
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Sticky Header / Search Bar area
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "COCKTAIL BROWSER",
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            SearchBar(
                query = uiState.searchQuery,
                onQueryChange = onSearchQueryChange,
                placeholder = "Search name, spirit, or ingredient..."
            )
        }

        // Quick Filter row
        val spiritFilters = listOf("All", "Gin", "Whisky", "Rum", "Vodka", "Champagne", "Non-Alcoholic")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(spiritFilters) { filter ->
                val isSelected = if (filter == "All") uiState.selectedCategory == null else uiState.selectedCategory == filter
                CategoryTile(
                    category = filter,
                    isSelected = isSelected,
                    onClick = {
                        if (filter == "All") {
                            onCategorySelect(null)
                        } else {
                            onCategorySelect(filter)
                        }
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Search Results indicator
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (uiState.selectedCategory == null) "All Curations" else "${uiState.selectedCategory} Selections",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "${filteredCocktails.size} recipes matched",
                style = MaterialTheme.typography.bodyMedium,
                color = RichCopper,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Results list
        if (filteredCocktails.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                EmptyState(
                    message = "We found no vintage mixtures matching those criteria in our library.",
                    onActionClick = {
                        onSearchQueryChange("")
                        onCategorySelect(null)
                    },
                    actionText = "Clear Filters"
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .testTag("browser_cocktails_list"),
                contentPadding = PaddingValues(start = 20.dp, top = 0.dp, end = 20.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(
                    items = filteredCocktails,
                    key = { it.id }
                ) { cocktail ->
                    CocktailCard(
                        cocktail = cocktail,
                        onCocktailClick = onCocktailClick,
                        onFavoriteToggle = onFavoriteToggle
                    )
                }
            }
        }
    }
}
