package com.example.data

import com.example.data.model.Cocktail
import com.example.data.model.Ingredient
import com.example.data.model.CocktailCollection

object MockData {
    val seedIngredients = listOf(
        Ingredient(
            id = "gin",
            name = "London Dry Gin",
            description = "A premium, clear spirit distilled with juniper berries, coriander seeds, and fresh citrus peels. It forms the crisp backbone of British mixology.",
            origin = "London, England",
            flavorProfile = "Sharp juniper, bright coriander, clean citrus, dry finish",
            alcoholPercentage = 40.0,
            suggestedSubstitutes = listOf("Plymouth Gin", "Botanical Vodka"),
            imageUrl = "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600&auto=format&fit=crop"
        ),
        Ingredient(
            id = "scotch",
            name = "Single Malt Scotch Whisky",
            description = "A sophisticated, smoky malt whisky aged in oak casks. Sourced from Scotland's historic distilleries for unparalleled depth.",
            origin = "Islay, Scotland",
            flavorProfile = "Intense peat smoke, sea salt, rich oak, vanilla sweetness",
            alcoholPercentage = 43.0,
            suggestedSubstitutes = listOf("Irish Whiskey", "Rye Whiskey"),
            imageUrl = "https://images.unsplash.com/photo-1527281400683-1aae777175f8?w=600&auto=format&fit=crop"
        ),
        Ingredient(
            id = "earl_grey",
            name = "Earl Grey Infusion",
            description = "Traditional British black tea leaves infused with the aromatic oil of bergamot oranges, creating a sweet, floral flavor layer.",
            origin = "Assam, India (Blended in UK)",
            flavorProfile = "Robust black tea, citrusy bergamot, subtle tannins",
            alcoholPercentage = 0.0,
            suggestedSubstitutes = listOf("Lady Grey Tea", "English Breakfast"),
            imageUrl = "https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=600&auto=format&fit=crop"
        ),
        Ingredient(
            id = "elderflower",
            name = "Elderflower Liqueur",
            description = "An exquisite, floral liqueur made from wild elderflowers hand-picked in the European spring. Brings a delicate sweetness.",
            origin = "Loire Valley, France",
            flavorProfile = "Fresh elderflower, pear, white grape, honeyed sweetness",
            alcoholPercentage = 20.0,
            suggestedSubstitutes = listOf("Rose Syrup", "Pear Nectar"),
            imageUrl = "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&auto=format&fit=crop"
        ),
        Ingredient(
            id = "sweet_vermouth",
            name = "Sweet Vermouth",
            description = "A fortified, botanically infused sweet wine. Adds depth, herbal bitterness, and spicy notes to classic cocktails.",
            origin = "Turin, Italy",
            flavorProfile = "Warming spices, dark cherry, herbal bitterness, caramel",
            alcoholPercentage = 16.5,
            suggestedSubstitutes = listOf("Dry Vermouth with simple syrup", "Port Wine"),
            imageUrl = "https://images.unsplash.com/photo-1569058242253-92a9c755a0ec?w=600&auto=format&fit=crop"
        )
    )

    val seedCocktails = listOf(
        Cocktail(
            id = "royal_jubilee",
            name = "The Royal Jubilee",
            tagline = "Royal elegance in a crystal glass.",
            description = "A majestic celebratory cocktail pairing the citrus-floral notes of Earl Grey tea and elderflower with the effervescence of fine English sparkling wine. Clean, regal, and refreshing.",
            imageUrl = "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=600&auto=format&fit=crop",
            difficulty = "Medium",
            prepTime = "5 mins",
            glassType = "Coupe",
            strength = "Medium",
            garnish = "Thin lemon spiral and edible gold leaf",
            servingTemp = "Ice cold (4°C)",
            foodPairings = "Fresh oysters, smoked salmon blinis, lemon tarts",
            history = "Created in Mayfair, London, to celebrate the rich tradition of tea drinking combined with local distillery craftsmanship during royal garden events.",
            professionalNotes = "Ensure the Earl Grey tea is cold-steeped to avoid bitterness. Shake the gin and tea vigorously to lock in the aromatics.",
            category = "British",
            isFavorite = true,
            ingredients = listOf(
                "35ml London Dry Gin",
                "15ml Elderflower Liqueur",
                "25ml Cold-Steeped Earl Grey Tea",
                "10ml Fresh Lemon Juice",
                "Top with English Sparkling Wine (or Prosecco)"
            ),
            steps = listOf(
                "Chill your coupe glass with crushed ice.",
                "Combine London Dry Gin, elderflower liqueur, lemon juice, and cold-steeped Earl Grey tea in a copper cocktail shaker filled with solid ice cubes.",
                "Shake vigorously for 12 seconds until the shaker is frosted on the outside.",
                "Discard the ice from the coupe glass and double strain the liquid into the glass.",
                "Gently top with English sparkling wine.",
                "Garnish with a delicate lemon twist and float gold leaf on top."
            )
        ),
        Cocktail(
            id = "the_winston",
            name = "The Winston",
            tagline = "A bold, spirit-forward statement.",
            description = "A robust, deeply complex tribute to the classic British statesman. Combining Islay single malt with the herbal depth of sweet vermouth and the warm, smoky hint of burnt rosemary.",
            imageUrl = "https://images.unsplash.com/photo-1527281400683-1aae777175f8?w=600&auto=format&fit=crop",
            difficulty = "Expert",
            prepTime = "7 mins",
            glassType = "Tumbler (Double Rock)",
            strength = "Strong",
            garnish = "A smoking sprig of organic rosemary",
            servingTemp = "Slightly chilled over a single large ice sphere (8°C)",
            foodPairings = "Aged cheddar, dark chocolate truffles, premium beef jerky",
            history = "Concocted in an exclusive London private members' club. It channels the legendary Prime Minister's love for fine spirits and robust cigars.",
            professionalNotes = "Light the rosemary sprig right before serving. The smoke should gather inside the glass dome for a dramatic aroma release.",
            category = "Whisky",
            isFavorite = false,
            ingredients = listOf(
                "45ml Single Malt Scotch Whisky",
                "20ml Sweet Vermouth",
                "10ml Grand Marnier",
                "2 dashes Angostura Bitters",
                "1 fresh sprig of Rosemary"
            ),
            steps = listOf(
                "Place a single large clear ice sphere in a heavy-bottomed lead crystal tumbler.",
                "In a mixing glass, combine the Scotch, sweet vermouth, Grand Marnier, and bitters.",
                "Fill the mixing glass 3/4 with ice and stir smoothly for 30 seconds to achieve optimal chilling and dilution without aeration.",
                "Strain the liquid carefully over the ice sphere.",
                "Use a culinary torch to gently toast the tip of the rosemary sprig until it smokes, then immediately place it resting on the glass."
            )
        ),
        Cocktail(
            id = "soho_bramble",
            name = "Soho Bramble",
            tagline = "Vibrant berries meet crisp botanicals.",
            description = "A modern classic from the streets of London's Soho. Fresh, tart blackberries bring a striking crimson bleed into a clean gin-sour canvas.",
            imageUrl = "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=600&auto=format&fit=crop",
            difficulty = "Easy",
            prepTime = "4 mins",
            glassType = "Tumbler (Old Fashioned)",
            strength = "Medium",
            garnish = "Two fresh blackberries and a mint sprig",
            servingTemp = "Frigid, served over crushed ice",
            foodPairings = "Lemon sponge cakes, fresh berries, goat cheese crostini",
            history = "Invented in London in the mid-1980s, the Bramble was designed to capture the taste of fresh English blackberries harvested from countryside gardens.",
            professionalNotes = "The drizzle of blackberry liqueur must be done at the very end. Let it naturally bleed down the crushed ice for the perfect visual bleed.",
            category = "Gin",
            isFavorite = false,
            ingredients = listOf(
                "50ml London Dry Gin",
                "20ml Fresh Lemon Juice",
                "15ml Simple Syrup",
                "15ml Blackberry Liqueur (Crème de Mûre)",
                "Crushed ice"
            ),
            steps = listOf(
                "Fill an Old Fashioned glass to the brim with crushed ice.",
                "Add London Dry Gin, fresh lemon juice, and simple syrup to a cocktail shaker with ice cubes. Shake briefly.",
                "Strain the mixture into the glass over the crushed ice.",
                "Slowly drizzle the blackberry liqueur over the top, allowing it to weave down the sides of the ice.",
                "Garnish with blackberries and a small, spanked mint sprig."
            )
        ),
        Cocktail(
            id = "kensington_garden",
            name = "Kensington Garden",
            tagline = "Brisk, botanical, and alcohol-free.",
            description = "A sophisticated non-alcoholic beverage celebrating British summer gardens. Clean cucumber, fragrant mint, and crisp elderflower soda form a perfect botanic highball.",
            imageUrl = "https://images.unsplash.com/photo-1536935338788-846bb9981813?w=600&auto=format&fit=crop",
            difficulty = "Easy",
            prepTime = "3 mins",
            glassType = "Highball",
            strength = "Non-Alcoholic",
            garnish = "Thin vertical cucumber ribbon and fresh mint bouquet",
            servingTemp = "Chilled (2°C)",
            foodPairings = "Cucumber sandwiches, scones with clotted cream",
            history = "Curated for daytime garden parties in Kensington's royal parks, offering an alcohol-free sensory alternative that matches the sophistication of premium gin highballs.",
            professionalNotes = "Press the cucumber ribbon firmly against the inner wall of the glass before adding ice. This locks in the aesthetic presentation.",
            category = "Non-Alcoholic",
            isFavorite = true,
            ingredients = listOf(
                "50ml Seedlip Spice (Non-alcoholic spirit)",
                "15ml Fresh Lime Juice",
                "15ml Cucumber Juice",
                "Top with Premium Elderflower Tonic Water",
                "4 Fresh Mint Leaves"
            ),
            steps = listOf(
                "Gently slide a long, thin cucumber ribbon along the inner wall of a chilled highball glass.",
                "Muddle the mint leaves lightly with the lime juice in the bottom of the glass.",
                "Fill the glass with large, block ice cubes.",
                "Pour in the Seedlip and cucumber juice.",
                "Top slowly with elderflower tonic water.",
                "Stir gently from the bottom with a long barspoon to integrate the botanicals without losing carbonation."
            )
        ),
        Cocktail(
            id = "mayfair_martini",
            name = "Mayfair Dry Martini",
            tagline = "The absolute zenith of crispness.",
            description = "An ultra-dry, crystal-clear Martini inspired by the grand hotel bars of Mayfair. Perfectly chilled, botanical-forward, served with precise hospitality standards.",
            imageUrl = "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=600&auto=format&fit=crop",
            difficulty = "Medium",
            prepTime = "5 mins",
            glassType = "Martini / Nick & Nora",
            strength = "Strong",
            garnish = "Three blue cheese stuffed olives or clean lemon peel",
            servingTemp = "Extremely cold (-2°C)",
            foodPairings = "Caviar, salted almonds, truffle fries",
            history = "Martinis became synonymous with high-end London hospitality at the turn of the century. The Mayfair standard represents the pinnacle of temperature control.",
            professionalNotes = "Store your martini glass, mixing glass, and spirits in the freezer. Dilute precisely: 30 stirs is the sweet spot for 40% ABV spirits.",
            category = "Classic",
            isFavorite = false,
            ingredients = listOf(
                "60ml Premium London Dry Gin",
                "10ml Extra Dry Vermouth",
                "1 dash Orange Bitters",
                "Ice block for stirring"
            ),
            steps = listOf(
                "Verify your glassware is frozen solid.",
                "Add dry vermouth and gin into a frozen crystal mixing glass.",
                "Fill the mixing glass with large, hard ice blocks from the freezer.",
                "Stir smoothly with a long brass barspoon for exactly 30 rotations.",
                "Strain through a Julep strainer into the frozen Martini glass.",
                "Zest a lemon peel over the surface of the drink to release essential oils, then discard, or add cheese-stuffed olives on a silver pick."
            )
        )
    )

    val seedCollections = listOf(
        CocktailCollection(
            id = "british_classics",
            name = "British Classics",
            description = "A curated journey through the golden ages of London's finest hotels and private members' clubs.",
            imageUrl = "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=800&auto=format&fit=crop",
            cocktailIds = listOf("royal_jubilee", "mayfair_martini", "soho_bramble")
        ),
        CocktailCollection(
            id = "summer_garden",
            name = "Summer Garden Specials",
            description = "Bright, refreshing botanical profiles designed to evoke sunny afternoons in traditional English country estates.",
            imageUrl = "https://images.unsplash.com/photo-1536935338788-846bb9981813?w=800&auto=format&fit=crop",
            cocktailIds = listOf("royal_jubilee", "kensington_garden", "soho_bramble")
        ),
        CocktailCollection(
            id = "winter_evenings",
            name = "Winter Evenings",
            description = "Spirit-forward, warming blends designed for cozy firesides, deep oak-paneled libraries, and cold nights.",
            imageUrl = "https://images.unsplash.com/photo-1527281400683-1aae777175f8?w=800&auto=format&fit=crop",
            cocktailIds = listOf("the_winston", "mayfair_martini")
        )
    )
}
