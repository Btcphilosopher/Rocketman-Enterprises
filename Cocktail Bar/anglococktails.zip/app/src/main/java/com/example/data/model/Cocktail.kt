package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.squareup.moshi.JsonClass

@Entity(tableName = "cocktails")
@JsonClass(generateAdapter = true)
data class Cocktail(
    @PrimaryKey val id: String,
    val name: String,
    val tagline: String,
    val description: String,
    val imageUrl: String,
    val difficulty: String, // "Easy", "Medium", "Expert"
    val prepTime: String, // "5 mins"
    val glassType: String, // "Coupe", "Highball", "Tumbler"
    val strength: String, // "Strong", "Medium", "Non-Alcoholic"
    val garnish: String,
    val servingTemp: String, // "Ice cold", "Chilled"
    val foodPairings: String, // "Oysters", "Dark Chocolate"
    val history: String,
    val professionalNotes: String,
    val category: String, // "Gin", "Whisky", "Rum", "Vodka", "Champagne", "Non-Alcoholic"
    val isFavorite: Boolean = false,
    val ingredients: List<String> = emptyList(), // e.g. ["50ml London Dry Gin", "25ml Lemon Juice"]
    val steps: List<String> = emptyList() // e.g. ["Shake with ice", "Strain into coupe"]
)
