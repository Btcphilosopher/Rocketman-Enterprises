package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
  primary = BrassGold,
  onPrimary = MidnightBlack,
  secondary = RichCopper,
  onSecondary = WarmCream,
  tertiary = BritishRacingGreen,
  onTertiary = WarmCream,
  background = MidnightBlack,
  onBackground = WarmCream,
  surface = DeepMidnight,
  onSurface = WarmCream,
  surfaceVariant = SlateGrey,
  onSurfaceVariant = WarmCream,
  outline = BrassGold
)

private val LightColorScheme = lightColorScheme(
  primary = BritishRacingGreen,
  onPrimary = WarmCream,
  secondary = BrassGold,
  onSecondary = MidnightBlack,
  tertiary = RichCopper,
  onTertiary = WarmCream,
  background = WarmCream,
  onBackground = MidnightBlack,
  surface = OffWhite,
  onSurface = MidnightBlack,
  surfaceVariant = SlateGrey,
  onSurfaceVariant = MidnightBlack,
  outline = BritishRacingGreen
)

@Composable
fun AngloCocktailsTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
