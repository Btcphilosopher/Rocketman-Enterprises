package com.example.di

import android.content.Context
import androidx.room.Room
import com.example.data.CocktailRepository
import com.example.data.api.CocktailApi
import com.example.data.db.AppDatabase
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

interface AppContainer {
    val cocktailRepository: CocktailRepository
}

class AppContainerImpl(private val context: Context) : AppContainer {

    private val moshi: Moshi by lazy {
        Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()
    }

    private val okHttpClient: OkHttpClient by lazy {
        val loggingInterceptor = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()
    }

    private val retrofit: Retrofit by lazy {
        // Fallback to local stubbing if the base URL is blank or points to a non-existent port
        Retrofit.Builder()
            .baseUrl("https://localhost:8080/api/") // existing cocktail API mock placeholder
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
    }

    private val cocktailApi: CocktailApi by lazy {
        // Implement local fallback if Retrofit connection fails
        retrofit.create(CocktailApi::class.java)
    }

    private val database: AppDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "anglococktails_db"
        )
        .fallbackToDestructiveMigration()
        .build()
    }

    override val cocktailRepository: CocktailRepository by lazy {
        CocktailRepository(
            cocktailDao = database.cocktailDao(),
            ingredientDao = database.ingredientDao(),
            collectionDao = database.cocktailCollectionDao(),
            api = cocktailApi
        )
    }
}
