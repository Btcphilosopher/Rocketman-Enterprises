package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.CocktailRepository
import com.example.data.model.Cocktail
import com.example.data.model.Ingredient
import com.example.data.model.CocktailCollection
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class MainUiState(
    val cocktails: List<Cocktail> = emptyList(),
    val ingredients: List<Ingredient> = emptyList(),
    val collections: List<CocktailCollection> = emptyList(),
    val favorites: List<Cocktail> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val searchQuery: String = "",
    val selectedCategory: String? = null,
    val selectedCocktailId: String? = null,
    val selectedIngredientId: String? = null,
    val selectedCollectionId: String? = null,
    
    // User Settings & Profile
    val isDarkMode: Boolean = true, // Defaults to elegant dark mode
    val isMetric: Boolean = true,
    val isNotificationsEnabled: Boolean = true,
    val isLoggedIn: Boolean = false,
    val username: String = "Guest Bartender",
    val loginPin: String = "",
    val loginError: String? = null
)

class CocktailViewModel(private val repository: CocktailRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(MainUiState())
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, error = null) }
            
            // Trigger background API refresh (with Room fallback)
            repository.refreshData()

            // Combine local Room data flows
            combine(
                repository.allCocktails,
                repository.allIngredients,
                repository.allCollections,
                repository.favoriteCocktails
            ) { cocktails, ingredients, collections, favorites ->
                _uiState.update {
                    it.copy(
                        cocktails = cocktails,
                        ingredients = ingredients,
                        collections = collections,
                        favorites = favorites,
                        isLoading = false
                    )
                }
            }.catch { e ->
                _uiState.update { it.copy(isLoading = false, error = e.localizedMessage) }
            }.collect()
        }
    }

    fun refresh() {
        loadData()
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun selectCategory(category: String?) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun selectCocktail(id: String?) {
        _uiState.update { it.copy(selectedCocktailId = id) }
    }

    fun selectIngredient(id: String?) {
        _uiState.update { it.copy(selectedIngredientId = id) }
    }

    fun selectCollection(id: String?) {
        _uiState.update { it.copy(selectedCollectionId = id) }
    }

    fun toggleFavorite(id: String, isFav: Boolean) {
        viewModelScope.launch {
            repository.toggleFavorite(id, isFav)
        }
    }

    fun setDarkMode(enabled: Boolean) {
        _uiState.update { it.copy(isDarkMode = enabled) }
    }

    fun setMetric(enabled: Boolean) {
        _uiState.update { it.copy(isMetric = enabled) }
    }

    fun setNotificationsEnabled(enabled: Boolean) {
        _uiState.update { it.copy(isNotificationsEnabled = enabled) }
    }

    fun login(username: String, pin: String): Boolean {
        return if (pin == "1923") { // The vintage speakeasy pin
            _uiState.update {
                it.copy(
                    isLoggedIn = true,
                    username = username,
                    loginPin = "",
                    loginError = null
                )
            }
            true
        } else {
            _uiState.update { it.copy(loginError = "Invalid Vintage Access PIN (Try '1923')") }
            false
        }
    }

    fun logout() {
        _uiState.update {
            it.copy(
                isLoggedIn = false,
                username = "Guest Bartender",
                loginError = null
            )
        }
    }
}

class CocktailViewModelFactory(private val repository: CocktailRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CocktailViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CocktailViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
