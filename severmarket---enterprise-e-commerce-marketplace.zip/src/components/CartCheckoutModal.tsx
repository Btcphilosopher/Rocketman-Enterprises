import React, { useState } from 'react';
import { CartItem, Order } from '../types';
import { 
  X, ShoppingBag, Trash2, Plus, Minus, ShieldCheck, Truck, MapPin, 
  CreditCard, QrCode, CheckCircle2, ArrowRight, ArrowLeft, Percent, Gift, FileText
} from 'lucide-react';

interface CartCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, variantId: string | undefined, delta: number) => void;
  onRemoveItem: (productId: string, variantId?: string) => void;
  onClearCart: () => void;
  onOrderPlaced: (order: Order) => void;
  selectedCity: string;
}

export const CartCheckoutModal: React.FC<CartCheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onOrderPlaced,
  selectedCity
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'cart' | 'delivery' | 'recipient' | 'payment' | 'confirmation'>('cart');
  
  // Checkout Form State
  const [promoCode, setPromoCode] = useState('');
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [promoApplied, setPromoApplied] = useState(false);

  const [deliveryMethod, setDeliveryMethod] = useState<'pickup' | 'courier' | 'post'>('pickup');
  const [pickupPvi, setPickupPvi] = useState(`ПВЗ №104 (${selectedCity}, ул. Центральная, д. 15)`);
  const [courierStreet, setCourierStreet] = useState('');
  const [courierApt, setCourierApt] = useState('');

  const [recipientName, setRecipientName] = useState('Иван Петров');
  const [recipientPhone, setRecipientPhone] = useState('+7 (916) 555-43-21');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'sbp' | 'sberpay' | 'installments'>('sbp');

  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Calculations
  const subtotal = cartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discountAmount = Math.round(subtotal * (promoDiscount / 100));
  const shippingFee = subtotal > 3000 || deliveryMethod === 'pickup' ? 0 : 290;
  const totalAmount = subtotal - discountAmount + shippingFee;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.trim().toUpperCase() === 'SEVER2026' || promoCode.trim().toUpperCase() === 'СЕВЕР2026') {
      setPromoDiscount(10);
      setPromoApplied(true);
    } else {
      alert('Промокод недействителен. Попробуйте промокод: SEVER2026');
    }
  };

  const handleFinalSubmit = async () => {
    const addressStr = deliveryMethod === 'pickup' 
      ? pickupPvi 
      : `${selectedCity}, ул. ${courierStreet}, кв. ${courierApt}`;

    const newOrderData = {
      items: cartItems,
      deliveryMethod,
      recipientName,
      recipientPhone,
      paymentMethod,
      address: addressStr
    };

    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newOrderData)
      });
      const order: Order = await res.json();
      setCreatedOrder(order);
      onOrderPlaced(order);
      setStep('confirmation');
      onClearCart();
    } catch {
      alert('Ошибка оформления заказа.');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#141414] text-[#F5F5F0] rounded-2xl max-w-3xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-white/10 p-6 relative my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 bg-white/5 text-[#FF6321] rounded-xl border border-white/10">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-normal font-serif-editorial italic text-white">
                {step === 'cart' && 'Корзина покупателя'}
                {step === 'delivery' && 'Шаг 1 из 3: Способ получения'}
                {step === 'recipient' && 'Шаг 2 из 3: Данные получателя'}
                {step === 'payment' && 'Шаг 3 из 3: Способ оплаты'}
                {step === 'confirmation' && 'Заказ успешно оформлен!'}
              </h2>
              <p className="text-xs text-white/50">
                {cartItems.length} позиций в корзине • Город: {selectedCity}
              </p>
            </div>
          </div>

          <button onClick={onClose} className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition border border-white/10 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* STEP 1: CART ITEMS */}
        {step === 'cart' && (
          <div>
            {cartItems.length === 0 ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-16 h-16 bg-white/5 text-[#FF6321] rounded-full flex items-center justify-center mx-auto border border-white/10">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-white">Ваша корзина пуста</h3>
                <p className="text-xs text-white/50 max-w-sm mx-auto">
                  Ищите товары с помощью поиска или в каталоге категорий и добавляйте их в корзину.
                </p>
                <button
                  onClick={onClose}
                  className="px-6 py-2.5 bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-white hover:text-black transition"
                >
                  Перейти в каталог
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                {/* List of cart items */}
                <div className="divide-y divide-white/10 max-h-80 overflow-y-auto pr-1">
                  {cartItems.map((item, idx) => (
                    <div key={idx} className="py-3 flex items-center justify-between gap-4">
                      <div className="flex items-center space-x-3 min-w-0 flex-1">
                        <img src={item.product.images[0]} alt="" className="w-14 h-14 object-contain rounded-lg border border-white/10 p-1 bg-black" />
                        <div className="min-w-0">
                          <div className="text-xs font-bold text-white truncate">{item.product.title}</div>
                          <div className="text-[11px] text-white/40">
                            Продавец: {item.product.merchantName}
                          </div>
                          {item.selectedVariantName && (
                            <div className="text-[10px] text-[#FF6321] font-bold uppercase tracking-wider bg-[#FF6321]/10 border border-[#FF6321]/20 px-2 py-0.5 rounded-full inline-block mt-0.5">
                              {item.selectedVariantName}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Quantity & Controls */}
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center border border-white/15 rounded-lg overflow-hidden bg-black">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.variantId, -1)}
                            className="p-1 hover:bg-white/10 text-white/70 hover:text-white transition"
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="px-3 text-xs font-bold text-white">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, item.variantId, 1)}
                            className="p-1 hover:bg-white/10 text-white/70 hover:text-white transition"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="text-right min-w-[90px]">
                          <div className="text-xs font-black text-white">
                            {(item.product.price * item.quantity).toLocaleString('ru-RU')} ₽
                          </div>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.product.id, item.variantId)}
                          className="p-1.5 text-white/40 hover:text-[#FF6321] rounded-lg transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Promo code form */}
                <form onSubmit={handleApplyPromo} className="flex items-center space-x-2 bg-black p-3 rounded-xl border border-white/10">
                  <Percent className="w-4 h-4 text-[#FF6321] ml-1" />
                  <input
                    type="text"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    placeholder="Промокод (попробуйте SEVER2026)"
                    className="bg-transparent border-0 text-xs font-bold text-white placeholder-white/30 focus:outline-hidden flex-1"
                  />
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-white/10 hover:bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-lg transition cursor-pointer"
                  >
                    Применить
                  </button>
                </form>

                {promoApplied && (
                  <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-xs font-semibold text-emerald-400 flex items-center justify-between">
                    <span>Промокод SEVER2026 применен! Скидка -10%</span>
                    <span>-{discountAmount.toLocaleString('ru-RU')} ₽</span>
                  </div>
                )}

                {/* Totals Summary */}
                <div className="bg-black text-white p-4 rounded-2xl border border-white/10 space-y-2">
                  <div className="flex justify-between text-xs text-white/60">
                    <span>Товары ({cartItems.length}):</span>
                    <span>{subtotal.toLocaleString('ru-RU')} ₽</span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-xs text-emerald-400">
                      <span>Скидка по промокоду:</span>
                      <span>-{discountAmount.toLocaleString('ru-RU')} ₽</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs text-white/60">
                    <span>Доставка:</span>
                    <span>{shippingFee === 0 ? 'Бесплатно' : `${shippingFee} ₽`}</span>
                  </div>
                  <div className="pt-2 border-t border-white/10 flex justify-between text-base font-black text-white">
                    <span>Итого к оплате:</span>
                    <span className="text-[#FF6321]">{totalAmount.toLocaleString('ru-RU')} ₽</span>
                  </div>
                </div>

                <button
                  onClick={() => setStep('delivery')}
                  className="w-full py-3.5 bg-[#FF6321] hover:bg-white hover:text-black text-white font-bold text-xs uppercase tracking-wider rounded-full transition shadow-lg shadow-[#FF6321]/30 flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <span>Перейти к оформлению</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* STEP 2: DELIVERY */}
        {step === 'delivery' && (
          <div className="space-y-6">
            <div className="grid grid-cols-3 gap-3">
              <button
                onClick={() => setDeliveryMethod('pickup')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                  deliveryMethod === 'pickup' ? 'border-[#FF6321] bg-[#FF6321]/20 text-white ring-1 ring-[#FF6321]' : 'border-white/10 bg-black text-white/70'
                }`}
              >
                <MapPin className="w-5 h-5 text-[#FF6321] mb-1" />
                <div className="text-xs font-bold text-white">Пункт выдачи</div>
                <div className="text-[10px] text-white/50 mt-0.5">Бесплатно • Завтра</div>
              </button>

              <button
                onClick={() => setDeliveryMethod('courier')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                  deliveryMethod === 'courier' ? 'border-[#FF6321] bg-[#FF6321]/20 text-white ring-1 ring-[#FF6321]' : 'border-white/10 bg-black text-white/70'
                }`}
              >
                <Truck className="w-5 h-5 text-[#FF6321] mb-1" />
                <div className="text-xs font-bold text-white">Курьером до двери</div>
                <div className="text-[10px] text-white/50 mt-0.5">290 ₽ • До двери</div>
              </button>

              <button
                onClick={() => setDeliveryMethod('post')}
                className={`p-3.5 rounded-xl border text-left transition cursor-pointer ${
                  deliveryMethod === 'post' ? 'border-[#FF6321] bg-[#FF6321]/20 text-white ring-1 ring-[#FF6321]' : 'border-white/10 bg-black text-white/70'
                }`}
              >
                <ShieldCheck className="w-5 h-5 text-[#FF6321] mb-1" />
                <div className="text-xs font-bold text-white">Почта России</div>
                <div className="text-[10px] text-white/50 mt-0.5">2-4 дня • Отделение</div>
              </button>
            </div>

            {deliveryMethod === 'pickup' && (
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block">Выберите ближайший ПВЗ в г. {selectedCity}:</label>
                <select
                  value={pickupPvi}
                  onChange={(e) => setPickupPvi(e.target.value)}
                  className="w-full p-3 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden cursor-pointer"
                >
                  <option value={`ПВЗ №104 (${selectedCity}, ул. Центральная, д. 15)`}>ПВЗ №104 ({selectedCity}, ул. Центральная, д. 15)</option>
                  <option value={`ПВЗ №210 (${selectedCity}, пр. Ленина, д. 88)`}>ПВЗ №210 ({selectedCity}, пр. Ленина, д. 88)</option>
                  <option value={`ПВЗ №305 (${selectedCity}, ул. Тверская, д. 42)`}>ПВЗ №305 ({selectedCity}, ул. Тверская, д. 42)</option>
                </select>
              </div>
            )}

            {deliveryMethod === 'courier' && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Улица, дом *</label>
                  <input
                    type="text"
                    value={courierStreet}
                    onChange={(e) => setCourierStreet(e.target.value)}
                    placeholder="ул. Пушкина, д. 10"
                    className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Квартира / Офис *</label>
                  <input
                    type="text"
                    value={courierApt}
                    onChange={(e) => setCourierApt(e.target.value)}
                    placeholder="кв. 45"
                    className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>
              </div>
            )}

            <div className="flex space-x-3 pt-4 border-t border-white/10">
              <button
                onClick={() => setStep('cart')}
                className="px-5 py-3 bg-white/10 text-white font-bold text-xs uppercase tracking-wider rounded-full flex items-center space-x-1 hover:bg-white/20"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Назад</span>
              </button>
              <button
                onClick={() => setStep('recipient')}
                className="flex-1 py-3 bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-white hover:text-black transition"
              >
                Далее: Получатель
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: RECIPIENT */}
        {step === 'recipient' && (
          <div className="space-y-4">
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">ФИО Получателя *</label>
              <input
                type="text"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                className="w-full p-3 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
              />
            </div>
            <div>
              <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Телефон для SMS-уведомления *</label>
              <input
                type="text"
                value={recipientPhone}
                onChange={(e) => setRecipientPhone(e.target.value)}
                className="w-full p-3 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
              />
            </div>

            <div className="flex space-x-3 pt-4 border-t border-white/10">
              <button
                onClick={() => setStep('delivery')}
                className="px-5 py-3 bg-white/10 text-white font-bold text-xs uppercase tracking-wider rounded-full flex items-center space-x-1 hover:bg-white/20"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Назад</span>
              </button>
              <button
                onClick={() => setStep('payment')}
                className="flex-1 py-3 bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-white hover:text-black transition"
              >
                Далее: Оплата
              </button>
            </div>
          </div>
        )}

        {/* STEP 4: PAYMENT */}
        {step === 'payment' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setPaymentMethod('sbp')}
                className={`p-4 rounded-xl border text-left transition cursor-pointer ${
                  paymentMethod === 'sbp' ? 'border-[#FF6321] bg-[#FF6321]/20 text-white ring-1 ring-[#FF6321]' : 'border-white/10 bg-black text-white/70'
                }`}
              >
                <QrCode className="w-6 h-6 text-[#FF6321] mb-2" />
                <div className="text-xs font-bold text-white">СБП (Система Быстрых Платежей)</div>
                <div className="text-[10px] text-white/50">Без комиссии по QR-коду</div>
              </button>

              <button
                onClick={() => setPaymentMethod('card')}
                className={`p-4 rounded-xl border text-left transition cursor-pointer ${
                  paymentMethod === 'card' ? 'border-[#FF6321] bg-[#FF6321]/20 text-white ring-1 ring-[#FF6321]' : 'border-white/10 bg-black text-white/70'
                }`}
              >
                <CreditCard className="w-6 h-6 text-[#FF6321] mb-2" />
                <div className="text-xs font-bold text-white">Банковская карта МИР / Visa</div>
                <div className="text-[10px] text-white/50">Мгновенный платеж</div>
              </button>
            </div>

            <div className="bg-black p-4 rounded-2xl border border-white/10 space-y-2 text-xs">
              <div className="font-bold text-white uppercase tracking-wider text-[11px]">Итоговая сводка перед оплатой:</div>
              <div className="flex justify-between text-white/60">
                <span>Сумма заказа:</span>
                <span className="font-bold text-white">{totalAmount.toLocaleString('ru-RU')} ₽</span>
              </div>
              <div className="flex justify-between text-white/60">
                <span>Получатель:</span>
                <span className="text-white">{recipientName} ({recipientPhone})</span>
              </div>
            </div>

            <div className="flex space-x-3 pt-2">
              <button
                onClick={() => setStep('recipient')}
                className="px-5 py-3.5 bg-white/10 text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-white/20"
              >
                Назад
              </button>
              <button
                onClick={handleFinalSubmit}
                className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs uppercase tracking-wider rounded-full transition shadow-lg shadow-emerald-600/30 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <CheckCircle2 className="w-5 h-5" />
                <span>Оплатить {totalAmount.toLocaleString('ru-RU')} ₽</span>
              </button>
            </div>
          </div>
        )}

        {/* CONFIRMATION */}
        {step === 'confirmation' && createdOrder && (
          <div className="text-center py-6 space-y-5">
            <div className="w-16 h-16 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto border-4 border-emerald-500/30 animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <h3 className="text-xl sm:text-2xl font-normal font-serif-editorial italic text-white">Заказ № {createdOrder.orderNumber} оформлен!</h3>
              <p className="text-xs text-white/50 mt-1">
                Мы отправили подтверждение и трек-код на номер {createdOrder.recipientPhone}
              </p>
            </div>

            <div className="bg-black p-4 rounded-2xl border border-white/10 text-xs text-left max-w-md mx-auto space-y-2">
              <div className="flex justify-between">
                <span className="text-white/50">Трекинг-код:</span>
                <span className="font-bold font-mono text-[#FF6321]">{createdOrder.trackingCode}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Ориентировочная доставка:</span>
                <span className="font-bold text-white">{createdOrder.estimatedDelivery}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-white/50">Сумма заказа:</span>
                <span className="font-black text-white">{createdOrder.totalAmount.toLocaleString('ru-RU')} ₽</span>
              </div>
            </div>

            <div className="flex justify-center space-x-3">
              <button
                onClick={onClose}
                className="px-6 py-3 bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-white hover:text-black transition cursor-pointer"
              >
                Продолжить покупки
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
