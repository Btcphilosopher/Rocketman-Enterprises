import React, { useState, useEffect, useRef } from 'react';
import { 
  MapPin, ShoppingCart, Heart, Search, User, Menu, X, ChevronDown, 
  Sparkles, ShieldCheck, Truck, Percent, Store, HelpCircle, Smartphone,
  Layers, Package, BarChart3, Code2, Globe, ArrowRight, Check
} from 'lucide-react';
import { NavigationTab, Product } from '../types';

interface HeaderProps {
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  cartCount: number;
  cartTotal: number;
  favoritesCount: number;
  compareCount: number;
  onOpenCart: () => void;
  onOpenCompare: () => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSelectCategory: (catId: string | null) => void;
  isCatalogOpen: boolean;
  setIsCatalogOpen: (open: boolean) => void;
  selectedCity: string;
  setSelectedCity: (city: string) => void;
  onProductClick: (product: Product) => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  cartCount,
  cartTotal,
  favoritesCount,
  compareCount,
  onOpenCart,
  onOpenCompare,
  searchQuery,
  setSearchQuery,
  onSelectCategory,
  isCatalogOpen,
  setIsCatalogOpen,
  selectedCity,
  setSelectedCity,
  onProductClick
}) => {
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [autocompleteResults, setAutocompleteResults] = useState<{ suggestions: any[]; categories: any[]; brands: string[] }>({ suggestions: [], categories: [], brands: [] });
  const [isSearching, setIsSearching] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const CITIES = ['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань', 'Нижний Новгород', 'Челябинск', 'Самара', 'Уфа', 'Краснодар'];

  // Handle click outside search autocomplete
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearching(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Autocomplete search API call
  useEffect(() => {
    if (searchQuery.trim().length >= 2) {
      setIsSearching(true);
      fetch(`/api/search/autocomplete?q=${encodeURIComponent(searchQuery)}`)
        .then(res => res.json())
        .then(data => setAutocompleteResults(data))
        .catch(() => {});
    } else {
      setAutocompleteResults({ suggestions: [], categories: [], brands: [] });
      setIsSearching(false);
    }
  }, [searchQuery]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(false);
    onSelectCategory(null);
    setActiveTab('catalog');
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0A0A0A] border-b border-white/10 shadow-2xl">
      {/* Top Bar */}
      <div className="bg-[#050505] text-white/60 text-[11px] uppercase tracking-[0.2em] py-2 px-4 border-b border-white/5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Left links & location */}
          <div className="flex items-center space-x-6">
            <button
              onClick={() => setShowLocationModal(true)}
              className="flex items-center space-x-1.5 text-white/80 hover:text-[#FF6321] transition font-medium cursor-pointer"
            >
              <MapPin className="w-3.5 h-3.5 text-[#FF6321]" />
              <span className="tracking-widest">{selectedCity}</span>
              <ChevronDown className="w-3 h-3 text-white/40" />
            </button>
            <nav className="hidden md:flex items-center space-x-6 text-white/50">
              <a href="#delivery" onClick={(e) => { e.preventDefault(); setActiveTab('storefront'); }} className="hover:text-white transition">Доставка</a>
              <a href="#promos" onClick={(e) => { e.preventDefault(); setActiveTab('catalog'); }} className="hover:text-white transition flex items-center space-x-1">
                <Percent className="w-3 h-3 text-[#FF6321]" />
                <span className="text-[#FF6321] font-bold">Акции</span>
              </a>
              <a href="#brands" onClick={(e) => { e.preventDefault(); setActiveTab('catalog'); }} className="hover:text-white transition">Бренды</a>
              <a href="#merchant" onClick={(e) => { e.preventDefault(); setActiveTab('merchant'); }} className="hover:text-white transition">Продавцам</a>
              <a href="#support" onClick={(e) => { e.preventDefault(); alert('Служба поддержки СеверМаркет: 8 (800) 555-01-99 (24/7 бесплатно по РФ)'); }} className="hover:text-white transition">Поддержка</a>
              <a href="#mobile" onClick={(e) => { e.preventDefault(); alert('Приложение СеверМаркет доступно в RuStore, App Store и Google Play!'); }} className="hover:text-white transition flex items-center space-x-1 text-white/70">
                <Smartphone className="w-3 h-3 text-emerald-400" />
                <span>Приложение</span>
              </a>
            </nav>
          </div>

          {/* Right currency & language */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1 bg-white/5 px-2.5 py-0.5 rounded-full border border-white/10 text-[10px] tracking-widest text-white">
              <span className="font-bold">RUB</span>
              <span className="text-[#FF6321]">₽</span>
            </div>
            <div className="flex items-center space-x-1 text-white/60 text-[10px] tracking-widest">
              <Globe className="w-3 h-3 text-white/40" />
              <span>Русский</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header Row */}
      <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => {
              onSelectCategory(null);
              setActiveTab('storefront');
            }}
            className="flex items-center space-x-3 group text-left cursor-pointer"
          >
            <div className="w-10 h-10 bg-[#FF6321] rounded-none flex items-center justify-center text-white shadow-lg group-hover:bg-white group-hover:text-black transition-colors">
              <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                <path d="M12 2L2 19h20L12 2zm0 3.8L18.5 17H5.5L12 5.8z" />
                <path d="M12 8l-4 7h8l-4-7z" opacity="0.6" />
              </svg>
            </div>
            <div>
              <div className="text-2xl font-black tracking-tighter uppercase text-white leading-none">
                СЕВЕР<span className="font-serif-editorial italic font-normal text-white/90 ml-1">MARKET</span>
              </div>
              <div className="text-[9px] font-bold uppercase tracking-[0.3em] text-[#FF6321] leading-none mt-1">
                National Ecosystem
              </div>
            </div>
          </button>

          {/* Catalog Button */}
          <button
            onClick={() => setIsCatalogOpen(!isCatalogOpen)}
            className={`hidden sm:flex items-center space-x-2 px-5 py-2.5 rounded-full text-xs font-bold uppercase tracking-[0.15em] transition-all cursor-pointer ${
              isCatalogOpen 
                ? 'bg-white text-black' 
                : 'bg-white/10 border border-white/20 text-white hover:bg-[#FF6321] hover:border-[#FF6321]'
            }`}
          >
            {isCatalogOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            <span>Каталог</span>
          </button>
        </div>

        {/* Search Bar */}
        <div ref={searchRef} className="flex-1 max-w-xl relative">
          <form onSubmit={handleSearchSubmit} className="flex items-center">
            <div className="relative w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => { if (searchQuery.trim().length >= 2) setIsSearching(true); }}
                placeholder="Поиск по каталогу 1.2M+ товаров..."
                className="w-full pl-4 pr-12 py-2.5 bg-[#141414] border border-white/15 rounded-full text-xs text-white placeholder-white/30 focus:outline-hidden focus:border-[#FF6321] focus:ring-1 focus:ring-[#FF6321] transition"
              />
              <button
                type="submit"
                className="absolute right-1 top-1 bottom-1 px-4 bg-[#FF6321] hover:bg-[#e05316] text-white rounded-full flex items-center justify-center transition cursor-pointer"
              >
                <Search className="w-3.5 h-3.5" />
                <span className="ml-1.5 hidden md:inline text-[11px] font-bold uppercase tracking-wider">Найти</span>
              </button>
            </div>
          </form>

          {/* Autocomplete Dropdown */}
          {isSearching && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-[#141414] rounded-2xl shadow-2xl border border-white/10 z-50 overflow-hidden divide-y divide-white/5 text-white">
              {/* Product suggestions */}
              {autocompleteResults.suggestions.length > 0 && (
                <div className="p-3">
                  <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2 px-2">Товары</div>
                  {autocompleteResults.suggestions.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => {
                        setIsSearching(false);
                        onProductClick(p);
                      }}
                      className="w-full flex items-center space-x-3 p-2 hover:bg-white/5 rounded-xl transition text-left cursor-pointer"
                    >
                      <img src={p.image} alt={p.title} className="w-9 h-9 object-cover rounded-lg border border-white/10 bg-black" />
                      <div className="flex-1 min-w-0">
                        <div className="text-xs font-medium text-white/90 truncate">{p.title}</div>
                        <div className="text-xs font-bold text-[#FF6321]">{p.price.toLocaleString('ru-RU')} ₽</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Categories matches */}
              {autocompleteResults.categories.length > 0 && (
                <div className="p-3 bg-white/5">
                  <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2 px-2">Категории</div>
                  <div className="flex flex-wrap gap-1.5 px-2">
                    {autocompleteResults.categories.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => {
                          setIsSearching(false);
                          onSelectCategory(c.id);
                          setActiveTab('catalog');
                        }}
                        className="px-3 py-1 bg-black border border-white/10 hover:border-[#FF6321] rounded-full text-xs text-white/80 hover:text-[#FF6321] transition cursor-pointer"
                      >
                        {c.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Brands matches */}
              {autocompleteResults.brands.length > 0 && (
                <div className="p-3">
                  <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2 px-2">Бренды</div>
                  <div className="flex flex-wrap gap-2 px-2">
                    {autocompleteResults.brands.map((b) => (
                      <span key={b} className="text-[11px] font-medium text-white/70 bg-white/5 border border-white/10 px-2.5 py-0.5 rounded-full">
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center space-x-2">
          {/* User Account / Navigation Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center space-x-2 px-3 py-2 rounded-full border border-white/15 hover:border-white/40 text-white transition cursor-pointer bg-white/5"
            >
              <div className="w-6 h-6 rounded-full bg-[#FF6321] flex items-center justify-center text-white font-bold text-xs">
                <User className="w-3.5 h-3.5" />
              </div>
              <div className="hidden lg:block text-left">
                <div className="text-[10px] uppercase tracking-[0.15em] text-white/50 leading-none">Аккаунт</div>
                <div className="text-xs font-bold text-white flex items-center mt-0.5">
                  <span>Меню</span>
                  <ChevronDown className="w-3 h-3 ml-1 text-white/40" />
                </div>
              </div>
            </button>

            {/* Portal Switcher Dropdown */}
            {showUserMenu && (
              <div className="absolute right-0 mt-2 w-72 bg-[#141414] rounded-2xl shadow-2xl border border-white/10 py-2 z-50 text-white divide-y divide-white/5">
                <div className="px-4 py-3">
                  <p className="text-[10px] uppercase tracking-[0.2em] font-bold text-[#FF6321]">Выбор роли в системе</p>
                  <p className="text-xs font-bold text-white mt-0.5">Переключение панелей</p>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => { setActiveTab('storefront'); setShowUserMenu(false); }}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 text-xs font-medium hover:bg-white/5 transition cursor-pointer ${activeTab === 'storefront' ? 'text-[#FF6321] font-bold bg-white/5' : 'text-white/80'}`}
                  >
                    <Store className="w-4 h-4 text-[#FF6321]" />
                    <span>Витрина (Покупатель)</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('orders'); setShowUserMenu(false); }}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 text-xs font-medium hover:bg-white/5 transition cursor-pointer ${activeTab === 'orders' ? 'text-[#FF6321] font-bold bg-white/5' : 'text-white/80'}`}
                  >
                    <Package className="w-4 h-4 text-blue-400" />
                    <span>Мои заказы & Трекинг</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('merchant'); setShowUserMenu(false); }}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 text-xs font-medium hover:bg-white/5 transition cursor-pointer ${activeTab === 'merchant' ? 'text-[#FF6321] font-bold bg-white/5' : 'text-white/80'}`}
                  >
                    <Layers className="w-4 h-4 text-amber-400" />
                    <span>Кабинет продавца</span>
                  </button>

                  <button
                    onClick={() => { setActiveTab('admin'); setShowUserMenu(false); }}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 text-xs font-medium hover:bg-white/5 transition cursor-pointer ${activeTab === 'admin' ? 'text-[#FF6321] font-bold bg-white/5' : 'text-white/80'}`}
                  >
                    <BarChart3 className="w-4 h-4 text-emerald-400" />
                    <span>Панель администратора</span>
                  </button>
                </div>

                <div className="py-1">
                  <button
                    onClick={() => { setActiveTab('architecture'); setShowUserMenu(false); }}
                    className={`w-full flex items-center space-x-3 px-4 py-2.5 text-xs font-medium text-indigo-400 hover:bg-white/5 cursor-pointer ${activeTab === 'architecture' ? 'bg-white/5' : ''}`}
                  >
                    <Code2 className="w-4 h-4 text-indigo-400" />
                    <span>Rust / gRPC / k8s Architecture</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Compare Button */}
          <button
            onClick={onOpenCompare}
            className="relative px-3 py-2 rounded-full border border-white/15 hover:border-white/40 text-white transition cursor-pointer bg-white/5 flex items-center space-x-1.5"
            title="Сравнение товаров"
          >
            <BarChart3 className="w-4 h-4 text-white/80" />
            <span className="hidden xl:inline text-[11px] font-bold uppercase tracking-wider text-white/80">Сравнение</span>
            {compareCount > 0 && (
              <span className="bg-[#FF6321] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {compareCount}
              </span>
            )}
          </button>

          {/* Favorites */}
          <button
            onClick={() => { onSelectCategory(null); setActiveTab('catalog'); }}
            className="relative px-3 py-2 rounded-full border border-white/15 hover:border-white/40 text-white transition cursor-pointer bg-white/5 flex items-center space-x-1.5"
          >
            <Heart className="w-4 h-4 text-white/80" />
            <span className="hidden xl:inline text-[11px] font-bold uppercase tracking-wider text-white/80">Избранное</span>
            {favoritesCount > 0 && (
              <span className="bg-[#FF6321] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {favoritesCount}
              </span>
            )}
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center space-x-2 bg-[#FF6321] hover:bg-[#e05316] text-white px-4 py-2 rounded-full transition cursor-pointer shadow-lg shadow-[#FF6321]/20 border border-[#FF6321]"
          >
            <ShoppingCart className="w-4 h-4 text-white" />
            <div className="text-left">
              <span className="text-[11px] font-extrabold uppercase tracking-wider">
                {cartTotal > 0 ? `${cartTotal.toLocaleString('ru-RU')} ₽` : 'Корзина'}
              </span>
            </div>
            {cartCount > 0 && (
              <span className="bg-white text-black text-[10px] font-black px-1.5 py-0.2 rounded-full ml-1">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* City Selector Modal */}
      {showLocationModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#141414] rounded-2xl max-w-md w-full p-6 shadow-2xl border border-white/10 text-white">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-bold text-white flex items-center space-x-2 uppercase tracking-wider">
                <MapPin className="w-5 h-5 text-[#FF6321]" />
                <span>Выберите ваш город</span>
              </h3>
              <button onClick={() => setShowLocationModal(false)} className="text-white/40 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <p className="text-xs text-white/60 mb-4">
              От выбранного города зависят сроки логистики и доступность товаров на хабах.
            </p>
            <div className="grid grid-cols-2 gap-2">
              {CITIES.map((city) => (
                <button
                  key={city}
                  onClick={() => {
                    setSelectedCity(city);
                    setShowLocationModal(false);
                  }}
                  className={`p-2.5 rounded-xl text-xs font-semibold text-left transition flex items-center justify-between cursor-pointer ${
                    selectedCity === city
                      ? 'bg-[#FF6321] text-white'
                      : 'bg-white/5 border border-white/10 text-white/80 hover:bg-white/10'
                  }`}
                >
                  <span>{city}</span>
                  {selectedCity === city && <Check className="w-4 h-4" />}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
