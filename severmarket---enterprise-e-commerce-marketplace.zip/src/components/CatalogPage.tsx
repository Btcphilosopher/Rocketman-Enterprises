import React, { useState, useMemo } from 'react';
import { Product, Category } from '../types';
import { ProductCard } from './ProductCard';
import { Filter, SlidersHorizontal, ArrowUpDown, RefreshCw, X, Check } from 'lucide-react';

interface CatalogPageProps {
  products: Product[];
  categories: Category[];
  selectedCategoryId: string | null;
  onSelectCategory: (catId: string | null) => void;
  searchQuery: string;
  onProductClick: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  favorites: string[];
  onToggleFavorite: (product: Product, e: React.MouseEvent) => void;
  comparedProducts: string[];
  onToggleCompare: (product: Product, e: React.MouseEvent) => void;
}

export const CatalogPage: React.FC<CatalogPageProps> = ({
  products,
  categories,
  selectedCategoryId,
  onSelectCategory,
  searchQuery,
  onProductClick,
  onAddToCart,
  favorites,
  onToggleFavorite,
  comparedProducts,
  onToggleCompare
}) => {
  const [minPrice, setMinPrice] = useState<number>(0);
  const [maxPrice, setMaxPrice] = useState<number>(100000);
  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [onlyFlashSale, setOnlyFlashSale] = useState(false);
  const [minRating, setMinRating] = useState<number>(0);
  const [sortOption, setSortOption] = useState<'popular' | 'price_asc' | 'price_desc' | 'rating' | 'discount'>('popular');

  // All unique brands
  const allBrands = useMemo(() => Array.from(new Set(products.map(p => p.brand))), [products]);

  const toggleBrand = (brand: string) => {
    setSelectedBrands(prev => 
      prev.includes(brand) ? prev.filter(b => b !== brand) : [...prev, brand]
    );
  };

  // Filtered & Sorted products
  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      if (selectedCategoryId && selectedCategoryId !== 'all' && p.categoryId !== selectedCategoryId) {
        return false;
      }
      if (searchQuery.trim().length > 0) {
        const q = searchQuery.toLowerCase();
        if (!p.title.toLowerCase().includes(q) && !p.brand.toLowerCase().includes(q) && !p.categoryName.toLowerCase().includes(q)) {
          return false;
        }
      }
      if (p.price < minPrice || p.price > maxPrice) return false;
      if (selectedBrands.length > 0 && !selectedBrands.includes(p.brand)) return false;
      if (onlyFlashSale && !p.isFlashSale) return false;
      if (minRating > 0 && p.rating < minRating) return false;
      return true;
    }).sort((a, b) => {
      if (sortOption === 'price_asc') return a.price - b.price;
      if (sortOption === 'price_desc') return b.price - a.price;
      if (sortOption === 'rating') return b.rating - a.rating;
      if (sortOption === 'discount') return (b.discountPercent || 0) - (a.discountPercent || 0);
      return (b.isPopular ? 1 : 0) - (a.isPopular ? 1 : 0);
    });
  }, [products, selectedCategoryId, searchQuery, minPrice, maxPrice, selectedBrands, onlyFlashSale, minRating, sortOption]);

  const currentCategoryObj = categories.find(c => c.id === selectedCategoryId);

  return (
    <div className="py-6">
      {/* Category Header */}
      <div className="bg-[#121212] rounded-2xl border border-white/10 p-6 mb-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#FF6321] mb-1">
              {searchQuery ? `Поиск: "${searchQuery}"` : currentCategoryObj ? 'Раздел каталога' : 'Все категории'}
            </div>
            <h1 className="text-2xl sm:text-3xl font-normal font-serif-editorial italic text-white leading-tight">
              {currentCategoryObj ? currentCategoryObj.name : searchQuery ? `Результаты поиска (${filteredProducts.length})` : 'Полный каталог товаров'}
            </h1>
          </div>

          <div className="flex items-center space-x-3">
            <span className="text-xs font-bold uppercase tracking-wider text-white/50">Сортировка:</span>
            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as any)}
              className="bg-black border border-white/15 rounded-full px-4 py-2 text-xs font-bold text-white focus:outline-hidden focus:border-[#FF6321] cursor-pointer"
            >
              <option value="popular">Популярность</option>
              <option value="price_asc">Сначала дешевле</option>
              <option value="price_desc">Сначала дороже</option>
              <option value="discount">Размер скидки</option>
              <option value="rating">Высокий рейтинг</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sidebar Filters (3 cols) */}
        <div className="lg:col-span-3 space-y-6">
          <div className="bg-[#121212] rounded-2xl border border-white/10 p-5 space-y-5 shadow-xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white flex items-center space-x-2">
                <SlidersHorizontal className="w-4 h-4 text-[#FF6321]" />
                <span>Фильтры</span>
              </h3>
              {(selectedCategoryId || selectedBrands.length > 0 || minPrice > 0 || maxPrice < 100000 || onlyFlashSale || minRating > 0) && (
                <button
                  onClick={() => {
                    onSelectCategory(null);
                    setSelectedBrands([]);
                    setMinPrice(0);
                    setMaxPrice(100000);
                    setOnlyFlashSale(false);
                    setMinRating(0);
                  }}
                  className="text-xs text-[#FF6321] font-bold uppercase tracking-wider hover:underline flex items-center space-x-1"
                >
                  <RefreshCw className="w-3 h-3" />
                  <span>Сбросить</span>
                </button>
              )}
            </div>

            {/* Category Filter List */}
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2">Категория</h4>
              <div className="space-y-1 max-h-56 overflow-y-auto pr-1">
                <button
                  onClick={() => onSelectCategory(null)}
                  className={`w-full text-left px-3 py-2 rounded-full text-xs font-semibold transition cursor-pointer ${
                    !selectedCategoryId ? 'bg-[#FF6321] text-white' : 'text-white/70 hover:bg-white/5'
                  }`}
                >
                  Все товары ({products.length})
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => onSelectCategory(cat.id)}
                    className={`w-full text-left px-3 py-2 rounded-full text-xs font-semibold transition flex items-center justify-between cursor-pointer ${
                      selectedCategoryId === cat.id ? 'bg-[#FF6321] text-white' : 'text-white/70 hover:bg-white/5'
                    }`}
                  >
                    <span>{cat.name}</span>
                    <span className="text-[10px] opacity-60">{cat.itemCount.toLocaleString('ru-RU')}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Price Filter */}
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2">Цена, ₽</h4>
              <div className="flex items-center space-x-2 mb-2">
                <input
                  type="number"
                  value={minPrice}
                  onChange={(e) => setMinPrice(Number(e.target.value))}
                  placeholder="От"
                  className="w-full px-3 py-2 bg-black border border-white/15 rounded-xl text-xs font-bold text-white placeholder-white/30 focus:border-[#FF6321] outline-hidden"
                />
                <span className="text-white/30">—</span>
                <input
                  type="number"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  placeholder="До"
                  className="w-full px-3 py-2 bg-black border border-white/15 rounded-xl text-xs font-bold text-white placeholder-white/30 focus:border-[#FF6321] outline-hidden"
                />
              </div>
            </div>

            {/* Brand Filter */}
            <div>
              <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2">Бренд</h4>
              <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                {allBrands.map((brand) => (
                  <label key={brand} className="flex items-center space-x-2 text-xs font-medium text-white/80 hover:text-white cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedBrands.includes(brand)}
                      onChange={() => toggleBrand(brand)}
                      className="rounded-sm border-white/20 bg-black text-[#FF6321] focus:ring-[#FF6321]"
                    />
                    <span>{brand}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Toggles */}
            <div className="space-y-3 border-t border-white/10 pt-4">
              <label className="flex items-center space-x-2 text-xs font-semibold text-white/80 cursor-pointer">
                <input
                  type="checkbox"
                  checked={onlyFlashSale}
                  onChange={(e) => setOnlyFlashSale(e.target.checked)}
                  className="rounded-sm border-white/20 bg-black text-[#FF6321] focus:ring-[#FF6321]"
                />
                <span>Только акции & скидки</span>
              </label>

              <label className="flex items-center space-x-2 text-xs font-semibold text-white/80 cursor-pointer">
                <input
                  type="checkbox"
                  checked={minRating === 4.5}
                  onChange={(e) => setMinRating(e.target.checked ? 4.5 : 0)}
                  className="rounded-sm border-white/20 bg-black text-[#FF6321] focus:ring-[#FF6321]"
                />
                <span>Рейтинг 4.5 ★ и выше</span>
              </label>
            </div>
          </div>
        </div>

        {/* Product Grid Area (9 cols) */}
        <div className="lg:col-span-9">
          {filteredProducts.length === 0 ? (
            <div className="bg-[#121212] rounded-2xl border border-white/10 p-12 text-center space-y-4">
              <div className="w-16 h-16 bg-white/5 text-[#FF6321] rounded-2xl flex items-center justify-center mx-auto border border-white/10">
                <Filter className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-white">Товары не найдены</h3>
              <p className="text-xs text-white/50 max-w-md mx-auto">
                Попробуйте изменить параметры фильтрации или очистить поиск.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onProductClick={onProductClick}
                  onAddToCart={onAddToCart}
                  isFavorite={favorites.includes(product.id)}
                  onToggleFavorite={onToggleFavorite}
                  isCompared={comparedProducts.includes(product.id)}
                  onToggleCompare={onToggleCompare}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
