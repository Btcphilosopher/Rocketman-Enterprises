import React, { useState } from 'react';
import { Order } from '../types';
import { 
  Package, Truck, MapPin, CheckCircle2, Clock, RotateCcw, FileText, ChevronRight, ShieldCheck, Download
} from 'lucide-react';

interface CustomerOrdersViewProps {
  orders: Order[];
  onRequestReturn: (orderId: string) => void;
}

export const CustomerOrdersView: React.FC<CustomerOrdersViewProps> = ({ orders, onRequestReturn }) => {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(orders[0] || null);

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'placed':
        return <span className="bg-blue-500/20 text-blue-400 border border-blue-500/30 text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">Создан</span>;
      case 'confirmed':
        return <span className="bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">Подтвержден</span>;
      case 'shipped':
        return <span className="bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">В пути</span>;
      case 'pickup_point':
        return <span className="bg-purple-500/20 text-purple-400 border border-purple-500/30 text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">Ожидает в ПВЗ</span>;
      case 'delivered':
        return <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">Доставлен</span>;
      case 'returned':
        return <span className="bg-red-500/20 text-red-400 border border-red-500/30 text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">Возврат</span>;
      default:
        return null;
    }
  };

  const handlePrintReceipt = (order: Order) => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Кассовый Чек № ${order.orderNumber} - SeverMarket</title>
          <style>
            body { font-family: sans-serif; padding: 20px; color: #1e293b; }
            .header { text-align: center; border-bottom: 2px solid #0284c7; padding-bottom: 10px; }
            .row { display: flex; justify-content: space-between; margin: 8px 0; font-size: 14px; }
            .total { font-size: 18px; font-weight: bold; margin-top: 15px; border-top: 1px solid #ccc; pt: 10px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h2>СеверМаркет (ООО "СЕВЕР МАРКЕТ")</h2>
            <p>Кассовый электронный чек № ${order.orderNumber}</p>
            <p>Дата: ${order.date}</p>
          </div>
          <h3>Состав заказа:</h3>
          ${order.items.map(i => `<div class="row"><span>${i.product.title} (x${i.quantity})</span><span>${(i.product.price * i.quantity).toLocaleString('ru-RU')} RUB</span></div>`).join('')}
          <div class="total row"><span>Итого к оплате:</span><span>${order.totalAmount.toLocaleString('ru-RU')} RUB</span></div>
          <p style="text-align: center; margin-top: 30px; font-size: 12px; color: #64748b;">Спасибо за покупки на СеверМаркет!</p>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <div className="py-6 max-w-7xl mx-auto space-y-6">
      {/* Title */}
      <div className="bg-[#141414] rounded-2xl border border-white/10 p-6 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-white/5 text-[#FF6321] rounded-xl border border-white/10">
            <Package className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-normal font-serif-editorial italic text-white">Мои заказы & Отслеживание</h1>
            <p className="text-xs text-white/50">История покупок и отслеживание доставки в реальном времени</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Order List (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          {orders.map((order) => (
            <button
              key={order.id}
              onClick={() => setSelectedOrder(order)}
              className={`w-full text-left p-4 rounded-2xl border transition cursor-pointer ${
                selectedOrder?.id === order.id
                  ? 'border-[#FF6321] bg-[#FF6321]/15 shadow-md ring-1 ring-[#FF6321]'
                  : 'border-white/10 bg-[#141414] hover:border-white/20'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-white">{order.orderNumber}</span>
                {getStatusBadge(order.status)}
              </div>
              <div className="text-xs text-white/50 mb-2">
                Дата заказа: {order.date} • {order.items.length} товаров
              </div>
              <div className="text-sm font-black text-[#FF6321]">
                {order.totalAmount.toLocaleString('ru-RU')} ₽
              </div>
            </button>
          ))}
        </div>

        {/* Order Details Panel (8 cols) */}
        <div className="lg:col-span-8">
          {selectedOrder ? (
            <div className="bg-[#141414] rounded-2xl border border-white/10 p-6 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
                <div>
                  <h2 className="text-xl font-normal font-serif-editorial italic text-white">Заказ {selectedOrder.orderNumber}</h2>
                  <p className="text-xs text-white/50">
                    Трек-номер: <span className="font-mono text-[#FF6321] font-bold">{selectedOrder.trackingCode}</span>
                  </p>
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handlePrintReceipt(selectedOrder)}
                    className="px-4 py-2 bg-white/10 hover:bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-full flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    <FileText className="w-4 h-4 text-white" />
                    <span>Чек (PDF)</span>
                  </button>

                  {selectedOrder.status === 'delivered' && (
                    <button
                      onClick={() => {
                        onRequestReturn(selectedOrder.id);
                        alert(`Заявка на возврат заказа ${selectedOrder.orderNumber} успешно подана.`);
                      }}
                      className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 text-red-400 font-bold text-xs uppercase tracking-wider rounded-full flex items-center space-x-1.5 transition cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>Оформить возврат</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Progress Timeline Tracker */}
              <div className="bg-black p-4 rounded-2xl border border-white/10">
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-4">Статус доставки</h3>
                <div className="flex items-center justify-between text-xs font-semibold relative">
                  <div className="flex flex-col items-center z-10">
                    <div className="w-8 h-8 rounded-full bg-[#FF6321] text-white flex items-center justify-center font-bold">1</div>
                    <span className="mt-1 text-white text-[11px]">Оформлен</span>
                  </div>
                  <div className="h-0.5 bg-[#FF6321] flex-1 mx-2" />
                  <div className="flex flex-col items-center z-10">
                    <div className="w-8 h-8 rounded-full bg-[#FF6321] text-white flex items-center justify-center font-bold">2</div>
                    <span className="mt-1 text-white text-[11px]">Сборка</span>
                  </div>
                  <div className="h-0.5 bg-[#FF6321] flex-1 mx-2" />
                  <div className="flex flex-col items-center z-10">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      ['shipped', 'pickup_point', 'delivered'].includes(selectedOrder.status) ? 'bg-[#FF6321] text-white' : 'bg-white/10 text-white/40'
                    }`}>3</div>
                    <span className="mt-1 text-white text-[11px]">В пути</span>
                  </div>
                  <div className="h-0.5 bg-white/10 flex-1 mx-2" />
                  <div className="flex flex-col items-center z-10">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                      selectedOrder.status === 'delivered' ? 'bg-emerald-500 text-white' : 'bg-white/10 text-white/40'
                    }`}>4</div>
                    <span className="mt-1 text-white text-[11px]">Вручен</span>
                  </div>
                </div>
              </div>

              {/* Order Items Table */}
              <div>
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-white/40 mb-3">Состав заказа</h3>
                <div className="divide-y divide-white/10 border border-white/10 rounded-xl overflow-hidden p-2 bg-black">
                  {selectedOrder.items.map((item, idx) => (
                    <div key={idx} className="p-3 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <img src={item.product.images[0]} alt="" className="w-12 h-12 object-contain rounded-lg border border-white/10 p-1 bg-white/5" />
                        <div>
                          <div className="text-xs font-bold text-white">{item.product.title}</div>
                          <div className="text-[11px] text-white/40">Количество: {item.quantity} шт.</div>
                        </div>
                      </div>
                      <div className="text-xs font-black text-white">
                        {(item.product.price * item.quantity).toLocaleString('ru-RU')} ₽
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-[#141414] rounded-2xl border border-white/10 p-8 text-center text-white/40 text-xs">
              Выберите заказ слева для просмотра подробной информации.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
