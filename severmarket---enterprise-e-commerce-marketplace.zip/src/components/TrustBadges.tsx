import React from 'react';
import { Truck, ShieldCheck, RotateCcw, Lock, Award } from 'lucide-react';

export const TrustBadges: React.FC = () => {
  const BADGES = [
    {
      icon: <Truck className="w-5 h-5 text-[#FF6321]" />,
      title: 'Быстрая доставка',
      subtitle: 'По всей России'
    },
    {
      icon: <ShieldCheck className="w-5 h-5 text-[#FF6321]" />,
      title: 'Верифицированные ТСП',
      subtitle: 'Рейтинги и проверки'
    },
    {
      icon: <RotateCcw className="w-5 h-5 text-[#FF6321]" />,
      title: 'Лёгкий возврат',
      subtitle: '14 дней без вопросов'
    },
    {
      icon: <Lock className="w-5 h-5 text-[#FF6321]" />,
      title: 'Безопасная оплата',
      subtitle: 'Защита данных SSL'
    },
    {
      icon: <Award className="w-5 h-5 text-[#FF6321]" />,
      title: 'Бонусный кэшбэк',
      subtitle: 'СеверМаркет Плюс'
    }
  ];

  return (
    <div className="my-6 bg-[#121212] rounded-2xl border border-white/10 p-4 sm:p-6 shadow-xl">
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {BADGES.map((b, idx) => (
          <div key={idx} className="flex items-center space-x-3.5 p-2 rounded-xl hover:bg-white/5 transition border border-transparent hover:border-white/5">
            <div className="p-2.5 bg-white/5 rounded-full border border-white/10 flex-shrink-0">
              {b.icon}
            </div>
            <div>
              <div className="text-xs font-bold text-white uppercase tracking-wider leading-tight">{b.title}</div>
              <div className="text-[11px] text-white/40 leading-tight mt-0.5">{b.subtitle}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
