import React, { useState } from 'react';
import { MOCK_ARCHITECTURE_DOCS } from '../data/mockData';
import { Code2, Server, Database, Container, FileCode, Layers, Shield, Cpu, Terminal } from 'lucide-react';

export const ArchitectureDocs: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'diagram' | 'openapi' | 'grpc' | 'docker' | 'k8s' | 'sql'>('diagram');

  return (
    <div className="py-6 max-w-7xl mx-auto space-y-6">
      {/* Title */}
      <div className="bg-[#141414] text-white rounded-2xl p-6 shadow-xl border border-white/10 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-white/5 text-[#FF6321] rounded-xl border border-white/10">
            <Code2 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-normal font-serif-editorial italic text-white">Архитектура & API Specifications (Rust Axum Engine)</h1>
            <p className="text-xs text-white/50">Техническая документация, REST OpenAPI, gRPC Proto и Kubernetes манифесты</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/10 pb-2">
        <button
          onClick={() => setActiveTab('diagram')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'diagram' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          Схема сервисов
        </button>
        <button
          onClick={() => setActiveTab('openapi')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'openapi' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          OpenAPI REST Spec
        </button>
        <button
          onClick={() => setActiveTab('grpc')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'grpc' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          gRPC Protobuf (.proto)
        </button>
        <button
          onClick={() => setActiveTab('docker')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'docker' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          Docker & Compose
        </button>
        <button
          onClick={() => setActiveTab('k8s')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'k8s' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          Kubernetes YAML
        </button>
        <button
          onClick={() => setActiveTab('sql')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'sql' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          PostgreSQL Migrations
        </button>
      </div>

      {/* Content */}
      <div className="bg-black text-[#F5F5F0] rounded-2xl p-6 border border-white/10 shadow-2xl font-mono text-xs overflow-x-auto">
        {activeTab === 'diagram' && (
          <div className="space-y-6 font-sans text-white">
            <h3 className="text-base font-bold text-white uppercase tracking-wider flex items-center space-x-2">
              <Layers className="w-5 h-5 text-[#FF6321]" />
              <span>СеверМаркет: Высоконагруженная микросервисная архитектура</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-[#141414] rounded-xl border border-white/10 space-y-2">
                <div className="font-bold text-[#FF6321] text-xs uppercase tracking-wider">1. Edge Layer & Gateway</div>
                <p className="text-xs text-white/60">
                  Nginx Reverse Proxy & Cloud Run Ingress. Осуществляет балансировку нагрузок, TLS-терминацию и фильтрацию DDOS-атак.
                </p>
              </div>

              <div className="p-4 bg-[#141414] rounded-xl border border-white/10 space-y-2">
                <div className="font-bold text-[#FF6321] text-xs uppercase tracking-wider">2. Core Engine (Rust / Axum)</div>
                <p className="text-xs text-white/60">
                  Высокопроизводительное ядро на языке Rust с асинхронным рантаймом Tokio. Реализует REST и gRPC микросервисы каталога, заказов и поиска.
                </p>
              </div>

              <div className="p-4 bg-[#141414] rounded-xl border border-white/10 space-y-2">
                <div className="font-bold text-emerald-400 text-xs uppercase tracking-wider">3. Storage & Cache Tier</div>
                <p className="text-xs text-white/60">
                  PostgreSQL 16 с JSONB индексацией, Redis Cluster для сессий и горячего кеша, OpenSearch для опечатокоустойчивого поиска.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'openapi' && (
          <pre className="text-amber-300 whitespace-pre-wrap leading-relaxed font-mono">
            {JSON.stringify({
              openapi: "3.0.3",
              info: {
                title: "SeverMarket Enterprise API",
                version: "2.4.0",
                description: "High-performance Rust Axum Microservices REST API Spec"
              },
              endpoints: [
                "GET /api/products - Full text search & multi-faceted filtering",
                "GET /api/products/:id - Single product spec detail & reviews",
                "POST /api/orders - Place checkout order with tracking generator",
                "GET /api/analytics - GMV and platform system metrics",
                "GET /api/categories - Full taxonomy tree"
              ]
            }, null, 2)}
          </pre>
        )}

        {activeTab === 'grpc' && (
          <pre className="text-emerald-400 whitespace-pre-wrap leading-relaxed font-mono">
            {MOCK_ARCHITECTURE_DOCS.grpcProto}
          </pre>
        )}

        {activeTab === 'docker' && (
          <div className="space-y-6 font-mono">
            <div>
              <div className="text-white/40 font-bold mb-2">// Multi-stage Dockerfile (Rust Alpine)</div>
              <pre className="text-sky-300 whitespace-pre-wrap">{MOCK_ARCHITECTURE_DOCS.dockerfile}</pre>
            </div>
            <div>
              <div className="text-white/40 font-bold mb-2">// docker-compose.yml</div>
              <pre className="text-emerald-400 whitespace-pre-wrap">{MOCK_ARCHITECTURE_DOCS.dockerCompose}</pre>
            </div>
          </div>
        )}

        {activeTab === 'k8s' && (
          <pre className="text-[#FF6321] whitespace-pre-wrap leading-relaxed font-mono">
            {MOCK_ARCHITECTURE_DOCS.k8sManifest}
          </pre>
        )}

        {activeTab === 'sql' && (
          <pre className="text-purple-300 whitespace-pre-wrap leading-relaxed font-mono">
            {MOCK_ARCHITECTURE_DOCS.sqlSchema}
          </pre>
        )}
      </div>
    </div>
  );
};
