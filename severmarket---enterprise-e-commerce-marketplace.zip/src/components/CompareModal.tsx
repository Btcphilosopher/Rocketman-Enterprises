import React, { useState } from 'react';
import { Product } from '../types';
import { X, Trash2, Check, BarChart3, ShoppingCart } from 'lucide-react';

interface CompareModalProps {
  products: Product[];
  onClose: () => void;
  onRemoveProduct: (productId: string) => void;
  onAddToCart: (product: Product) => void;
}

export const CompareModal: React.FC<CompareModalProps> = ({
  products,
  onClose,
  onRemoveProduct,
  onAddToCart
}) => {
  const [highlightDiff, setHighlightDiff] = useState(false);

  if (products.length === 0) {
    return (
      <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-md w-full p-6 text-center space-y-4">
          <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-full flex items-center justify-center mx-auto">
            <BarChart3 className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">Список сравнения пуст</h3>
          <p className="text-xs text-slate-500">
            Добавляйте товары к сравнению с помощью иконки графиков на карточках товаров.
          </p>
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-blue-600 text-white font-bold text-xs rounded-xl hover:bg-blue-700 transition"
          >
            Вернуться к покупкам
          </button>
        </div>
      </div>
    );
  }

  // Extract all unique spec keys across compared products
  const allSpecKeys = Array.from(
    new Set(products.flatMap(p => Object.keys(p.specs)))
  );

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-6xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 p-6 relative my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-6">
          <div className="flex items-center space-x-3">
            <div className="p-2 bg-blue-50 text-blue-600 rounded-xl">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900">Сравнение характеристик товаров</h2>
              <p className="text-xs text-slate-500">Сравнительный анализ {products.length} позиций</p>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={highlightDiff}
                onChange={(e) => setHighlightDiff(e.target.checked)}
                className="rounded-sm border-slate-300 text-blue-600 focus:ring-blue-500"
              />
              <span>Показывать только различия</span>
            </label>

            <button onClick={onClose} className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-700">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Matrix Table */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="p-3 text-left text-xs font-bold uppercase tracking-wider text-slate-400 bg-slate-50 w-48 rounded-l-xl">
                  Параметр
                </th>
                {products.map((p) => (
                  <th key={p.id} className="p-3 text-center min-w-[200px] max-w-[240px] align-top">
                    <div className="space-y-2 bg-slate-50 p-3 rounded-xl border border-slate-200 relative group">
                      <button
                        onClick={() => onRemoveProduct(p.id)}
                        className="absolute top-1 right-1 p-1 text-slate-400 hover:text-red-500 rounded-md transition"
                        title="Удалить из сравнения"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                      <img src={p.images[0]} alt="" className="w-20 h-20 object-contain mx-auto" />
                      <div className="text-xs font-bold text-slate-900 line-clamp-2 h-8">{p.title}</div>
                      <div className="text-sm font-black text-blue-600">{p.price.toLocaleString('ru-RU')} ₽</div>
                      <button
                        onClick={() => onAddToCart(p)}
                        className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold text-xs rounded-lg transition flex items-center justify-center space-x-1"
                      >
                        <ShoppingCart className="w-3.5 h-3.5" />
                        <span>В корзину</span>
                      </button>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {/* General rows */}
              <tr>
                <td className="p-3 font-semibold text-slate-500 bg-slate-50">Бренд</td>
                {products.map(p => (
                  <td key={p.id} className="p-3 text-center font-medium text-slate-900">{p.brand}</td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-slate-500 bg-slate-50">Рейтинг</td>
                {products.map(p => (
                  <td key={p.id} className="p-3 text-center font-medium text-slate-900">★ {p.rating} ({p.reviewCount})</td>
                ))}
              </tr>

              <tr>
                <td className="p-3 font-semibold text-slate-500 bg-slate-50">Продавец</td>
                {products.map(p => (
                  <td key={p.id} className="p-3 text-center font-medium text-slate-900">{p.merchantName}</td>
                ))}
              </tr>

              {/* Dynamic specs rows */}
              {allSpecKeys.map((key) => {
                const values = products.map(p => p.specs[key] || '—');
                const isDifferent = new Set(values).size > 1;

                if (highlightDiff && !isDifferent) return null;

                return (
                  <tr key={key} className={isDifferent ? 'bg-amber-50/30' : ''}>
                    <td className="p-3 font-semibold text-slate-500 bg-slate-50">{key}</td>
                    {values.map((val, idx) => (
                      <td key={idx} className="p-3 text-center font-medium text-slate-800">
                        {val}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
