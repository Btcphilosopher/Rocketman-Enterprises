import React, { useState, useEffect } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, ShieldCheck, Zap, Sparkles } from 'lucide-react';

interface HeroCarouselProps {
  onOpenPromos: () => void;
}

const SLIDES = [
  {
    id: 1,
    title: 'Всё, что нужно.\nВ одном месте.',
    subtitle: 'Миллионы товаров, быстрая доставка и проверенные продавцы по всей России',
    buttonText: 'Смотреть акции',
    bgGradient: 'from-slate-950 via-slate-900 to-blue-950',
    tag: 'Флагманская распродажа',
    tagColor: 'bg-blue-600 text-white',
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 2,
    title: 'Техника и Электроника\nсо скидкой до -40%',
    subtitle: 'Смартфоны, ноутбуки и бытовая техника с официальной гарантией бренда',
    buttonText: 'Перейти к гаджетам',
    bgGradient: 'from-indigo-950 via-slate-900 to-slate-950',
    tag: 'Техно-Неделя',
    tagColor: 'bg-amber-500 text-slate-950',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=1200&q=80'
  },
  {
    id: 3,
    title: 'Летние коллекции\nОдежды и Дома',
    subtitle: 'Стильный текстиль, брендовые вещи и уютные аксессуары со свободным возвратом',
    buttonText: 'Узнать больше',
    bgGradient: 'from-blue-950 via-slate-900 to-slate-950',
    tag: 'Новый Сезон',
    tagColor: 'bg-emerald-500 text-slate-950',
    image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=1200&q=80'
  }
];

export const HeroCarousel: React.FC<HeroCarouselProps> = ({ onOpenPromos }) => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % SLIDES.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  const slide = SLIDES[currentSlide];

  return (
    <div className="relative rounded-3xl overflow-hidden bg-[#0F0F0F] text-white shadow-2xl border border-white/10 my-6">
      <div className={`relative min-h-[400px] lg:min-h-[460px] flex items-center bg-gradient-to-r from-black via-[#0F0F0F] to-[#141414] p-8 lg:p-14 transition-all duration-700`}>
        {/* Subtle Background Image Overlay */}
        <div className="absolute inset-0 opacity-15 bg-cover bg-center mix-blend-luminosity" style={{ backgroundImage: `url(${slide.image})` }} />

        {/* Vertical Editorial Branding */}
        <div className="hidden md:block absolute left-4 top-1/2 -translate-y-1/2 -rotate-90 origin-center text-[9px] uppercase tracking-[0.4em] font-bold text-white/20 select-none">
          NATIONAL LOGISTICS NETWORK
        </div>

        {/* Content Box */}
        <div className="relative z-10 max-w-2xl md:ml-6">
          <div className="inline-flex items-center space-x-3 text-xs font-bold tracking-[0.2em] uppercase mb-4">
            <span className="bg-[#FF6321] text-white px-3 py-1 rounded-full flex items-center space-x-1.5 shadow-lg">
              <Zap className="w-3 h-3" />
              <span>{slide.tag}</span>
            </span>
            <span className="text-white/40">СеверМаркет v2.4</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-none text-white whitespace-pre-line mb-6">
            <span className="font-serif-editorial italic font-normal text-white/90">
              {slide.title.split('\n')[0]}
            </span>
            <br />
            <span className="uppercase text-white">
              {slide.title.split('\n')[1] || ''}
            </span>
          </h1>

          <p className="text-sm sm:text-base text-white/60 font-light leading-relaxed mb-8 max-w-lg">
            {slide.subtitle}
          </p>

          <div className="flex items-center space-x-4">
            <button
              onClick={onOpenPromos}
              className="px-8 py-4 bg-[#FF6321] hover:bg-[#e05316] text-white font-bold text-xs uppercase tracking-[0.2em] rounded-full transition shadow-xl shadow-[#FF6321]/20 flex items-center space-x-3 group cursor-pointer border border-[#FF6321]"
            >
              <span>{slide.buttonText}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Graphic Box */}
        <div className="hidden lg:block absolute right-10 bottom-0 top-0 w-5/12 overflow-hidden pointer-events-none">
          <div className="relative w-full h-full flex items-center justify-center">
            <div className="w-80 bg-black/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl p-6 relative overflow-hidden">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <span className="text-[10px] uppercase font-bold tracking-[0.2em] text-[#FF6321]">СЕВЕР EXPRESS</span>
                <span className="text-[10px] text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-800/60 font-mono">1 день</span>
              </div>
              <div className="space-y-3 my-4">
                <div className="text-xs font-bold text-white uppercase tracking-wider">Национальный хаб #74</div>
                <div className="bg-white/5 p-3 rounded-xl border border-white/10 flex items-center justify-between">
                  <span className="text-xs text-white/70">Трекинг: #SM-88401</span>
                  <span className="text-xs font-mono font-bold text-[#FF6321]">АКТИВЕН</span>
                </div>
              </div>
              <div className="bg-white/5 p-3 rounded-xl border border-white/10 flex items-center space-x-3">
                <div className="w-8 h-8 rounded-full bg-[#FF6321] flex items-center justify-center font-bold text-white text-xs">
                  SM
                </div>
                <div className="text-[11px] text-white/70 leading-tight">
                  <span className="font-bold text-white block">Свыше 45 000 пунктов</span>
                  Покрываем 100% регионов РФ
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Indicators */}
      <div className="absolute bottom-5 left-10 z-20 flex items-center space-x-2">
        {SLIDES.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-1.5 rounded-full transition-all cursor-pointer ${
              currentSlide === idx ? 'w-10 bg-[#FF6321]' : 'w-2 bg-white/20 hover:bg-white/40'
            }`}
          />
        ))}
      </div>

      {/* Slide Navigation Arrows */}
      <div className="absolute right-6 bottom-5 z-20 flex items-center space-x-2">
        <button
          onClick={() => setCurrentSlide((prev) => (prev === 0 ? SLIDES.length - 1 : prev - 1))}
          className="p-2.5 bg-black/60 hover:bg-black text-white rounded-full transition border border-white/10 cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>
        <button
          onClick={() => setCurrentSlide((prev) => (prev + 1) % SLIDES.length)}
          className="p-2.5 bg-black/60 hover:bg-black text-white rounded-full transition border border-white/10 cursor-pointer"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
