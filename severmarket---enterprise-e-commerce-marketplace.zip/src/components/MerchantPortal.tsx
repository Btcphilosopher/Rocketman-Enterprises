import React, { useState } from 'react';
import { Product, Merchant, Order } from '../types';
import { 
  Store, Package, TrendingUp, Plus, Edit2, Trash2, ShieldCheck, 
  DollarSign, BarChart2, Tag, Check, MessageSquare
} from 'lucide-react';

interface MerchantPortalProps {
  products: Product[];
  merchants: Merchant[];
  orders: Order[];
  onAddProduct: (product: Omit<Product, 'id'>) => void;
  onUpdateProductStock: (productId: string, newStock: number) => void;
}

export const MerchantPortal: React.FC<MerchantPortalProps> = ({
  products,
  merchants,
  orders,
  onAddProduct,
  onUpdateProductStock
}) => {
  const currentMerchant = merchants[0]; // SeverMarket Official Store
  const merchantProducts = products.filter(p => p.merchantId === currentMerchant.id || p.merchantName === currentMerchant.name);

  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'promos'>('overview');
  const [showAddForm, setShowAddForm] = useState(false);

  // New Product Form State
  const [newTitle, setNewTitle] = useState('');
  const [newPrice, setNewPrice] = useState(9990);
  const [newOldPrice, setNewOldPrice] = useState(12990);
  const [newStock, setNewStock] = useState(50);
  const [newBrand, setNewBrand] = useState('Xiaomi');
  const [newCategory, setNewCategory] = useState('Электроника');
  const [newSku, setNewSku] = useState(`SKU-${Math.floor(100000 + Math.random() * 900000)}`);
  const [newImage, setNewImage] = useState('https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80');

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    onAddProduct({
      title: newTitle,
      titleRu: newTitle,
      slug: newTitle.toLowerCase().replace(/\s+/g, '-'),
      description: 'Новый товар от продавца в СеверМаркет.',
      categoryId: 'cat-electronics',
      categoryName: newCategory,
      price: newPrice,
      oldPrice: newOldPrice,
      discountPercent: Math.round(((newOldPrice - newPrice) / newOldPrice) * 100),
      rating: 5.0,
      reviewCount: 0,
      isPopular: true,
      images: [newImage],
      brand: newBrand,
      merchantId: currentMerchant.id,
      merchantName: currentMerchant.name,
      merchantRating: currentMerchant.rating,
      merchantDeliveryDays: 1,
      stock: newStock,
      sku: newSku,
      specs: {
        'Страна производства': 'Китай',
        'Гарантия': '12 месяцев'
      },
      tags: ['Новинка']
    });

    setNewTitle('');
    setShowAddForm(false);
    alert('Товар успешно добавлен в ваш магазин!');
  };

  return (
    <div className="py-6 max-w-7xl mx-auto space-y-6">
      {/* Merchant Header */}
      <div className="bg-[#141414] text-white rounded-2xl p-6 shadow-xl border border-white/10 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-14 h-14 rounded-2xl bg-[#FF6321] flex items-center justify-center font-bold text-white text-xl shadow-lg font-serif-editorial italic">
            SM
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-2xl font-normal font-serif-editorial italic text-white">{currentMerchant.name}</h1>
              <ShieldCheck className="w-5 h-5 text-[#FF6321]" />
            </div>
            <p className="text-xs text-white/50 mt-0.5">
              Рейтинг: ★ {currentMerchant.rating} • {currentMerchant.totalOrders.toLocaleString('ru-RU')} выполненных заказов
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddForm(true)}
          className="px-5 py-2.5 bg-[#FF6321] hover:bg-white hover:text-black text-white font-bold text-xs uppercase tracking-wider rounded-full shadow-md transition flex items-center space-x-2 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Добавить товар</span>
        </button>
      </div>

      {/* Navigation tabs */}
      <div className="flex items-center space-x-2 border-b border-white/10 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'overview' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          Обзор & Продажи
        </button>
        <button
          onClick={() => setActiveTab('products')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'products' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          Товары ({merchantProducts.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition cursor-pointer border ${
            activeTab === 'orders' ? 'bg-[#FF6321] border-[#FF6321] text-white' : 'bg-black border-white/10 text-white/70 hover:bg-white/10 hover:text-white'
          }`}
        >
          Заказы магазина
        </button>
      </div>

      {/* Overview stats */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
              <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Выручка за месяц</div>
              <div className="text-2xl font-black text-white mt-1">14 280 000 ₽</div>
              <div className="text-[11px] text-emerald-400 font-bold mt-1">+18.4% к прошлому месяцу</div>
            </div>

            <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
              <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Активных карточек</div>
              <div className="text-2xl font-black text-white mt-1">{merchantProducts.length}</div>
              <div className="text-[11px] text-white/50 mt-1">В наличии на складах</div>
            </div>

            <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
              <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Комиссия СеверМаркет</div>
              <div className="text-2xl font-black text-[#FF6321] mt-1">{currentMerchant.commissionRate}%</div>
              <div className="text-[11px] text-white/50 mt-1">Льготная ставка</div>
            </div>

            <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
              <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Индекс качества</div>
              <div className="text-2xl font-black text-emerald-400 mt-1">99.2%</div>
              <div className="text-[11px] text-emerald-400 font-bold mt-1">Премиум статус</div>
            </div>
          </div>
        </div>
      )}

      {/* Products list */}
      {activeTab === 'products' && (
        <div className="bg-[#141414] rounded-2xl border border-white/10 p-6 space-y-4 text-white">
          <h3 className="text-sm font-bold uppercase tracking-wider text-white">Управление ассортиментом</h3>
          <div className="divide-y divide-white/10 overflow-x-auto">
            {merchantProducts.map((p) => (
              <div key={p.id} className="py-3 flex items-center justify-between gap-4 text-xs min-w-[600px]">
                <div className="flex items-center space-x-3 w-72">
                  <img src={p.images[0]} alt="" className="w-10 h-10 object-contain rounded-lg border border-white/10 p-1 bg-black" />
                  <div>
                    <div className="font-bold text-white truncate">{p.title}</div>
                    <div className="text-[10px] text-white/40 font-mono">SKU: {p.sku}</div>
                  </div>
                </div>

                <div className="font-bold text-[#FF6321]">{p.price.toLocaleString('ru-RU')} ₽</div>

                <div className="flex items-center space-x-2">
                  <span className="text-white/50">Остаток:</span>
                  <input
                    type="number"
                    value={p.stock}
                    onChange={(e) => onUpdateProductStock(p.id, Number(e.target.value))}
                    className="w-16 px-2 py-1 bg-black border border-white/15 rounded-lg font-bold text-center text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>

                <span className="text-emerald-400 font-bold uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full text-[10px]">
                  Активен
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Orders Tab */}
      {activeTab === 'orders' && (
        <div className="bg-[#141414] rounded-2xl border border-white/10 p-6 text-white text-xs space-y-4">
          <h3 className="text-sm font-bold uppercase tracking-wider text-white">Заказы продавца</h3>
          <p className="text-white/50">Все заказы клиентов на товары вашего магазина переданы в распределительный центр СеверМаркет.</p>
        </div>
      )}

      {/* Add Product Modal */}
      {showAddForm && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#141414] text-white rounded-2xl max-w-lg w-full p-6 space-y-4 shadow-2xl border border-white/10">
            <h3 className="text-lg font-normal font-serif-editorial italic text-white">Добавить новый товар в магазин</h3>
            <form onSubmit={handleCreateProduct} className="space-y-3">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Название товара *</label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
                  placeholder="Смартфон Xiaomi Redmi Note 13 8/256GB"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Цена продажи (₽) *</label>
                  <input
                    type="number"
                    required
                    value={newPrice}
                    onChange={(e) => setNewPrice(Number(e.target.value))}
                    className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Старая цена (₽)</label>
                  <input
                    type="number"
                    value={newOldPrice}
                    onChange={(e) => setNewOldPrice(Number(e.target.value))}
                    className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Количество на складе *</label>
                  <input
                    type="number"
                    required
                    value={newStock}
                    onChange={(e) => setNewStock(Number(e.target.value))}
                    className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Бренд *</label>
                  <input
                    type="text"
                    required
                    value={newBrand}
                    onChange={(e) => setNewBrand(e.target.value)}
                    className="w-full p-2.5 bg-black border border-white/15 rounded-xl text-xs font-semibold text-white focus:border-[#FF6321] outline-hidden"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddForm(false)}
                  className="px-4 py-2 bg-white/10 text-white text-xs font-bold uppercase tracking-wider rounded-full hover:bg-white/20 transition cursor-pointer"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-[#FF6321] text-white text-xs font-bold uppercase tracking-wider rounded-full hover:bg-white hover:text-black transition cursor-pointer"
                >
                  Сохранить товар
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
