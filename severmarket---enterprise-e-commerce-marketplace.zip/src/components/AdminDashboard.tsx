import React, { useState } from 'react';
import { SystemMetrics, Merchant } from '../types';
import { 
  BarChart3, Users, DollarSign, Activity, ShieldAlert, CheckCircle2, 
  Download, Database, Cpu, Server, FileSpreadsheet, Lock
} from 'lucide-react';

interface AdminDashboardProps {
  metrics: SystemMetrics;
  merchants: Merchant[];
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ metrics, merchants }) => {
  const [selectedPeriod, setSelectedPeriod] = useState<'day' | 'week' | 'month'>('month');

  const handleExportCsv = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Метрика,Значение\n"
      + `Товарный оборот GMV,${metrics.totalGmv} RUB\n`
      + `Всего заказов,${metrics.totalOrders}\n`
      + `Активных продавцов,${metrics.totalMerchants}\n`
      + `Аптайм сервисов,99.99%\n`
      + `Задержка API,${metrics.apiLatencyMs} ms\n`;

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `SeverMarket_Analytics_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="py-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-[#141414] text-white rounded-2xl p-6 shadow-xl border border-white/10 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-3 bg-white/5 text-[#FF6321] rounded-xl border border-white/10">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl font-normal font-serif-editorial italic text-white">Панель управления SeverMarket Enterprise</h1>
            <p className="text-xs text-white/50">Мониторинг национальной платформы и продавцов</p>
          </div>
        </div>

        <button
          onClick={handleExportCsv}
          className="px-5 py-2.5 bg-[#FF6321] hover:bg-white hover:text-black text-white font-bold text-xs uppercase tracking-wider rounded-full shadow-md transition flex items-center space-x-2 cursor-pointer"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Экспорт отчета (CSV)</span>
        </button>
      </div>

      {/* Top Metrics Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
          <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Оборот платформы (GMV)</div>
          <div className="text-2xl font-black text-white mt-1">4.28 млрд ₽</div>
          <div className="text-[11px] text-emerald-400 font-bold mt-1">+24.5% за год</div>
        </div>

        <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
          <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Всего заказов</div>
          <div className="text-2xl font-black text-white mt-1">{metrics.totalOrders.toLocaleString('ru-RU')}</div>
          <div className="text-[11px] text-emerald-400 font-bold mt-1">+12 400 за сутки</div>
        </div>

        <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
          <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Зарегистрированных мерчантов</div>
          <div className="text-2xl font-black text-white mt-1">{metrics.totalMerchants.toLocaleString('ru-RU')}</div>
          <div className="text-[11px] text-[#FF6321] font-bold mt-1">45 на модерации</div>
        </div>

        <div className="bg-[#141414] p-5 rounded-2xl border border-white/10 shadow-xs">
          <div className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Комиссионный доход</div>
          <div className="text-2xl font-black text-emerald-400 mt-1">299.6 млн ₽</div>
          <div className="text-[11px] text-white/50 mt-1">Средняя ставка 7.0%</div>
        </div>
      </div>

      {/* System Performance Status */}
      <div className="bg-[#141414] rounded-2xl border border-white/10 p-6 space-y-4">
        <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center space-x-2">
          <Activity className="w-4 h-4 text-[#FF6321]" />
          <span>Статус распределенной инфраструктуры (Rust / Axum / OpenSearch)</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 bg-black rounded-xl border border-white/10 flex items-center space-x-3">
            <Server className="w-8 h-8 text-[#FF6321]" />
            <div>
              <div className="text-xs text-white/50">Задержка ответов (p99)</div>
              <div className="text-sm font-bold text-white">{metrics.apiLatencyMs} ms</div>
            </div>
          </div>

          <div className="p-4 bg-black rounded-xl border border-white/10 flex items-center space-x-3">
            <Database className="w-8 h-8 text-amber-500" />
            <div>
              <div className="text-xs text-white/50">Кеш Redis Hit Rate</div>
              <div className="text-sm font-bold text-white">{metrics.redisHitRate}%</div>
            </div>
          </div>

          <div className="p-4 bg-black rounded-xl border border-white/10 flex items-center space-x-3">
            <Cpu className="w-8 h-8 text-emerald-400" />
            <div>
              <div className="text-xs text-white/50">Соединения PostgreSQL</div>
              <div className="text-sm font-bold text-white">{metrics.dbConnections} / 200 pool</div>
            </div>
          </div>
        </div>
      </div>

      {/* Verified Merchants Table */}
      <div className="bg-[#141414] rounded-2xl border border-white/10 p-6 space-y-4 text-white">
        <h3 className="text-sm font-bold uppercase tracking-wider text-white">Продавцы платформы</h3>
        <div className="divide-y divide-white/10 overflow-x-auto">
          {merchants.map((m) => (
            <div key={m.id} className="py-3 flex items-center justify-between gap-4 text-xs min-w-[600px]">
              <div className="font-bold text-white w-60">{m.name}</div>
              <div className="text-white/50">{m.email}</div>
              <div className="font-bold text-white">Рейтинг: ★ {m.rating}</div>
              <div className="text-emerald-400 font-bold uppercase tracking-wider bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-0.5 rounded-full text-[10px]">
                Верифицирован
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
