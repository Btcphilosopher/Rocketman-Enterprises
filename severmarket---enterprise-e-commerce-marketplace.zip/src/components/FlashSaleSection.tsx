import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { ProductCard } from './ProductCard';
import { Flame, ChevronRight } from 'lucide-react';

interface FlashSaleSectionProps {
  products: Product[];
  onProductClick: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  favorites: string[];
  onToggleFavorite: (product: Product, e: React.MouseEvent) => void;
  comparedProducts: string[];
  onToggleCompare: (product: Product, e: React.MouseEvent) => void;
  onViewAllPromos: () => void;
}

export const FlashSaleSection: React.FC<FlashSaleSectionProps> = ({
  products,
  onProductClick,
  onAddToCart,
  favorites,
  onToggleFavorite,
  comparedProducts,
  onToggleCompare,
  onViewAllPromos
}) => {
  const flashProducts = products.filter(p => p.isFlashSale).slice(0, 6);

  // Countdown timer state
  const [timeLeft, setTimeLeft] = useState({ hours: 12, minutes: 45, seconds: 30 });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) return { ...prev, seconds: prev.seconds - 1 };
        if (prev.minutes > 0) return { ...prev, minutes: 59, seconds: 59 };
        if (prev.hours > 0) return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        return { hours: 24, minutes: 0, seconds: 0 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="my-10">
      {/* Header bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 mb-6 border-b border-white/10 pb-4">
        <div className="flex items-center space-x-4">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#FF6321] flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 fill-current" />
              <span>Ограниченный тираж</span>
            </span>
            <h2 className="text-2xl sm:text-3xl font-normal font-serif-editorial italic text-white leading-tight">Специальные предложения</h2>
          </div>

          {/* Countdown timer */}
          <div className="hidden sm:flex items-center space-x-2 bg-white/5 border border-white/10 text-white px-3.5 py-1.5 rounded-full text-xs font-bold">
            <span className="text-white/40 font-light text-[11px] uppercase tracking-wider">До конца:</span>
            <span className="font-mono bg-[#FF6321] text-white px-2 py-0.5 rounded-full text-[11px]">
              {String(timeLeft.hours).padStart(2, '0')}
            </span>
            <span className="text-[#FF6321]">:</span>
            <span className="font-mono bg-[#FF6321] text-white px-2 py-0.5 rounded-full text-[11px]">
              {String(timeLeft.minutes).padStart(2, '0')}
            </span>
            <span className="text-[#FF6321]">:</span>
            <span className="font-mono bg-[#FF6321] text-white px-2 py-0.5 rounded-full text-[11px]">
              {String(timeLeft.seconds).padStart(2, '0')}
            </span>
          </div>
        </div>

        <button
          onClick={onViewAllPromos}
          className="text-xs font-bold uppercase tracking-[0.15em] text-[#FF6321] hover:text-white flex items-center space-x-1 cursor-pointer transition"
        >
          <span>Все акции</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Grid of flash sale products */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {flashProducts.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onProductClick={onProductClick}
            onAddToCart={onAddToCart}
            isFavorite={favorites.includes(product.id)}
            onToggleFavorite={onToggleFavorite}
            isCompared={comparedProducts.includes(product.id)}
            onToggleCompare={onToggleCompare}
          />
        ))}
      </div>
    </section>
  );
};
