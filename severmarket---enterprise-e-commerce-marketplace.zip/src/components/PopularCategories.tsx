import React from 'react';
import { Category } from '../types';
import { ChevronRight } from 'lucide-react';

interface PopularCategoriesProps {
  categories: Category[];
  onSelectCategory: (catId: string) => void;
}

export const PopularCategories: React.FC<PopularCategoriesProps> = ({ categories, onSelectCategory }) => {
  const popularCats = categories.filter(c => c.image).slice(0, 7);

  return (
    <section className="my-10">
      <div className="flex items-center justify-between mb-6 border-b border-white/10 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-[0.25em] text-[#FF6321]">Каталог & Навигация</span>
          <h2 className="text-2xl sm:text-3xl font-normal font-serif-editorial italic text-white leading-tight">Популярные категории</h2>
        </div>
        <button
          onClick={() => onSelectCategory('all')}
          className="text-xs font-bold uppercase tracking-[0.15em] text-[#FF6321] hover:text-white flex items-center space-x-1 cursor-pointer transition"
        >
          <span>Все категории</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {popularCats.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className="group bg-[#121212] hover:bg-[#181818] border border-white/10 hover:border-[#FF6321]/50 rounded-2xl p-3 flex flex-col items-center text-center transition duration-300 cursor-pointer shadow-lg"
          >
            <div className="w-full h-28 mb-3 rounded-xl overflow-hidden bg-black flex items-center justify-center p-2 border border-white/5">
              <img
                src={cat.image}
                alt={cat.name}
                className="w-full h-full object-cover rounded-lg group-hover:scale-105 transition duration-300 opacity-85 group-hover:opacity-100"
              />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-white/90 group-hover:text-[#FF6321] transition leading-tight">
              {cat.name}
            </span>
          </button>
        ))}
      </div>
    </section>
  );
};
