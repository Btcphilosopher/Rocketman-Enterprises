import React, { useState } from 'react';
import { Product, Review } from '../types';
import { 
  X, Star, Heart, ShoppingCart, ShieldCheck, Truck, RotateCcw, 
  Store, Check, ChevronRight, MessageSquare, ThumbsUp, Play, Sparkles, BarChart3
} from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  reviews: Review[];
  onClose: () => void;
  onAddToCart: (product: Product, selectedVariantId?: string) => void;
  isFavorite: boolean;
  onToggleFavorite: (product: Product, e: React.MouseEvent) => void;
  isCompared: boolean;
  onToggleCompare: (product: Product, e: React.MouseEvent) => void;
  onAddReview: (review: Omit<Review, 'id' | 'date' | 'helpfulCount'>) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  reviews,
  onClose,
  onAddToCart,
  isFavorite,
  onToggleFavorite,
  isCompared,
  onToggleCompare,
  onAddReview
}) => {
  if (!product) return null;

  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedVariantId, setSelectedVariantId] = useState<string | undefined>(
    product.variants?.[0]?.id
  );
  const [activeTab, setActiveTab] = useState<'specs' | 'reviews' | 'qa'>('specs');

  // Review Form state
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [newRating, setNewRating] = useState(5);
  const [newAuthor, setNewAuthor] = useState('');
  const [newText, setNewText] = useState('');
  const [newPros, setNewPros] = useState('');
  const [newCons, setNewCons] = useState('');

  const currentVariant = product.variants?.find(v => v.id === selectedVariantId);
  const currentPrice = currentVariant ? currentVariant.price : product.price;
  const currentOldPrice = currentVariant ? currentVariant.oldPrice : product.oldPrice;

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAuthor.trim() || !newText.trim()) return;
    onAddReview({
      productId: product.id,
      authorName: newAuthor,
      rating: newRating,
      text: newText,
      pros: newPros,
      cons: newCons,
      verifiedPurchase: true
    });
    setNewAuthor('');
    setNewText('');
    setNewPros('');
    setNewCons('');
    setShowReviewForm(false);
    alert('Спасибо! Ваш отзыв успешно отправлен.');
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="bg-[#141414] text-[#F5F5F0] rounded-2xl max-w-5xl w-full max-h-[92vh] overflow-y-auto shadow-2xl border border-white/10 relative my-auto">
        {/* Sticky Top Close Bar */}
        <div className="sticky top-0 bg-[#141414]/90 backdrop-blur-md z-30 px-6 py-3.5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs font-bold uppercase tracking-wider text-white/50">
            <span>{product.categoryName}</span>
            <ChevronRight className="w-3 h-3 text-[#FF6321]" />
            <span className="text-white">{product.brand}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-white/60 hover:text-white transition cursor-pointer border border-white/10"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Main Grid: Gallery vs Info */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
            {/* Gallery Left (5 cols) */}
            <div className="lg:col-span-5 space-y-4">
              <div className="relative h-80 bg-black rounded-2xl border border-white/10 p-4 flex items-center justify-center overflow-hidden">
                <img
                  src={product.images[activeImageIdx] || product.images[0]}
                  alt={product.title}
                  className="max-h-full max-w-full object-contain"
                />
                {product.discountPercent && (
                  <span className="absolute top-3 left-3 bg-[#FF6321] text-white font-bold text-[10px] uppercase tracking-wider px-3 py-1 rounded-full shadow-lg">
                    -{product.discountPercent}%
                  </span>
                )}
              </div>

              {/* Thumbnails */}
              <div className="flex space-x-2 overflow-x-auto pb-2">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIdx(idx)}
                    className={`w-16 h-16 rounded-xl border p-1 bg-black overflow-hidden flex-shrink-0 cursor-pointer transition ${
                      activeImageIdx === idx ? 'border-[#FF6321] ring-2 ring-[#FF6321]/30' : 'border-white/10 hover:border-white/30'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-contain opacity-80 hover:opacity-100" />
                  </button>
                ))}
              </div>
            </div>

            {/* Info Right (7 cols) */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <div className="flex items-center space-x-2 text-[10px] uppercase tracking-wider font-bold text-[#FF6321] mb-1">
                  <span>Артикул: {currentVariant ? currentVariant.sku : product.sku}</span>
                  <span>•</span>
                  <span className="text-emerald-400 font-semibold flex items-center">
                    <Check className="w-3.5 h-3.5 mr-0.5" />
                    В наличии ({product.stock} шт.)
                  </span>
                </div>

                <h1 className="text-xl sm:text-2xl font-normal font-serif-editorial italic text-white leading-snug mb-2">
                  {product.title}
                </h1>

                {/* Rating summary */}
                <div className="flex items-center space-x-4 text-xs">
                  <div className="flex items-center text-[#FF6321]">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="font-bold text-white ml-1 text-sm">{product.rating.toFixed(1)}</span>
                  </div>
                  <span className="text-white/40">На основе {reviews.length || product.reviewCount} отзывов</span>
                  <button
                    onClick={(e) => onToggleCompare(product, e)}
                    className="text-amber-400 font-bold uppercase tracking-wider text-[11px] hover:underline flex items-center space-x-1 cursor-pointer"
                  >
                    <BarChart3 className="w-3.5 h-3.5" />
                    <span>{isCompared ? 'В сравнении' : 'Сравнить'}</span>
                  </button>
                </div>
              </div>

              {/* Variants Selector */}
              {product.variants && product.variants.length > 0 && (
                <div className="space-y-2 pt-3 border-t border-white/10">
                  <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block">Выберите модификацию:</label>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((variant) => (
                      <button
                        key={variant.id}
                        onClick={() => setSelectedVariantId(variant.id)}
                        className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition cursor-pointer ${
                          selectedVariantId === variant.id
                            ? 'border-[#FF6321] bg-[#FF6321]/20 text-white ring-1 ring-[#FF6321]'
                            : 'border-white/10 bg-black text-white/70 hover:border-white/30'
                        }`}
                      >
                        <div>{variant.name}</div>
                        <div className="text-[11px] font-bold text-white mt-0.5">
                          {variant.price.toLocaleString('ru-RU')} ₽
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Price & Action Box */}
              <div className="bg-black p-5 rounded-2xl border border-white/10 space-y-4 shadow-xl">
                <div className="flex items-baseline space-x-3">
                  <span className="text-3xl font-black text-white">
                    {currentPrice.toLocaleString('ru-RU')} ₽
                  </span>
                  {currentOldPrice && (
                    <span className="text-sm text-white/30 line-through">
                      {currentOldPrice.toLocaleString('ru-RU')} ₽
                    </span>
                  )}
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => onAddToCart(product, selectedVariantId)}
                    className="flex-1 min-w-[180px] py-3.5 px-6 bg-[#FF6321] hover:bg-white hover:text-black text-white font-bold text-xs uppercase tracking-wider rounded-full transition shadow-lg shadow-[#FF6321]/25 flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>Добавить в корзину</span>
                  </button>

                  <button
                    onClick={(e) => onToggleFavorite(product, e)}
                    className={`p-3.5 rounded-full border transition cursor-pointer ${
                      isFavorite 
                        ? 'bg-[#FF6321] text-white border-[#FF6321]' 
                        : 'bg-white/5 text-white/70 border-white/10 hover:bg-white/10 hover:text-white'
                    }`}
                  >
                    <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
                  </button>
                </div>

                {/* Delivery Perks */}
                <div className="grid grid-cols-2 gap-2 text-xs pt-3 border-t border-white/10">
                  <div className="flex items-center space-x-2 text-white/70">
                    <Truck className="w-4 h-4 text-[#FF6321] flex-shrink-0" />
                    <span>Доставка курьером завтра</span>
                  </div>
                  <div className="flex items-center space-x-2 text-white/70">
                    <RotateCcw className="w-4 h-4 text-[#FF6321] flex-shrink-0" />
                    <span>Возврат 14 дней бесплатно</span>
                  </div>
                </div>
              </div>

              {/* Merchant Card */}
              <div className="flex items-center justify-between p-3.5 bg-black border border-white/10 rounded-xl">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center font-bold text-[#FF6321] text-sm">
                    <Store className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white flex items-center space-x-1">
                      <span>{product.merchantName}</span>
                      <ShieldCheck className="w-4 h-4 text-[#FF6321]" />
                    </div>
                    <div className="text-[11px] text-white/40 flex items-center space-x-2 mt-0.5">
                      <span>★ {product.merchantRating}</span>
                      <span>•</span>
                      <span>Проверенный продавец</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Tabs: Specs / Reviews / Q&A */}
          <div className="border-t border-white/10 pt-6">
            <div className="flex items-center space-x-6 border-b border-white/10 mb-6">
              <button
                onClick={() => setActiveTab('specs')}
                className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 transition cursor-pointer ${
                  activeTab === 'specs' ? 'border-[#FF6321] text-[#FF6321]' : 'border-transparent text-white/40 hover:text-white'
                }`}
              >
                Характеристики
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 transition cursor-pointer ${
                  activeTab === 'reviews' ? 'border-[#FF6321] text-[#FF6321]' : 'border-transparent text-white/40 hover:text-white'
                }`}
              >
                Отзывы покупателей ({reviews.length})
              </button>
              <button
                onClick={() => setActiveTab('qa')}
                className={`pb-3 text-xs font-bold uppercase tracking-wider border-b-2 transition cursor-pointer ${
                  activeTab === 'qa' ? 'border-[#FF6321] text-[#FF6321]' : 'border-transparent text-white/40 hover:text-white'
                }`}
              >
                Вопросы и ответы
              </button>
            </div>

            {/* Specs View */}
            {activeTab === 'specs' && (
              <div className="space-y-4">
                <p className="text-xs text-white/70 leading-relaxed max-w-3xl mb-4">
                  {product.description}
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-2">
                  {Object.entries(product.specs).map(([key, val]) => (
                    <div key={key} className="flex justify-between py-2 border-b border-white/5 text-xs">
                      <span className="text-white/40">{key}</span>
                      <span className="font-semibold text-white text-right">{val}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Reviews View */}
            {activeTab === 'reviews' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold uppercase tracking-wider text-white">Отзывы о товаре</h3>
                  <button
                    onClick={() => setShowReviewForm(!showReviewForm)}
                    className="px-4 py-2 bg-[#FF6321] text-white font-bold text-xs uppercase tracking-wider rounded-full hover:bg-white hover:text-black transition cursor-pointer"
                  >
                    Написать отзыв
                  </button>
                </div>

                {/* Review Form */}
                {showReviewForm && (
                  <form onSubmit={handleReviewSubmit} className="bg-black p-5 rounded-2xl border border-white/10 space-y-4">
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">Оставить свой отзыв</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Ваше имя *</label>
                        <input
                          type="text"
                          required
                          value={newAuthor}
                          onChange={e => setNewAuthor(e.target.value)}
                          className="w-full px-3 py-2 bg-[#121212] border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                          placeholder="Иван Петров"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Оценка *</label>
                        <select
                          value={newRating}
                          onChange={e => setNewRating(Number(e.target.value))}
                          className="w-full px-3 py-2 bg-[#121212] border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                        >
                          <option value={5}>5 ★★★★★ (Отлично)</option>
                          <option value={4}>4 ★★★★☆ (Хорошо)</option>
                          <option value={3}>3 ★★★☆☆ (Удовлетворительно)</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Достоинства</label>
                      <input
                        type="text"
                        value={newPros}
                        onChange={e => setNewPros(e.target.value)}
                        className="w-full px-3 py-2 bg-[#121212] border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                        placeholder="Качество, быстрая доставка"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Недостатки</label>
                      <input
                        type="text"
                        value={newCons}
                        onChange={e => setNewCons(e.target.value)}
                        className="w-full px-3 py-2 bg-[#121212] border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                        placeholder="Не обнаружено"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-wider text-white/50 block mb-1">Текст отзыва *</label>
                      <textarea
                        required
                        rows={3}
                        value={newText}
                        onChange={e => setNewText(e.target.value)}
                        className="w-full px-3 py-2 bg-[#121212] border border-white/15 rounded-xl text-xs text-white focus:border-[#FF6321] outline-hidden"
                        placeholder="Поделитесь своими впечатлениями от товара..."
                      />
                    </div>
                    <div className="flex justify-end space-x-2">
                      <button
                        type="button"
                        onClick={() => setShowReviewForm(false)}
                        className="px-4 py-2 bg-white/10 text-white text-xs font-bold uppercase tracking-wider rounded-full hover:bg-white/20"
                      >
                        Отмена
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-2 bg-[#FF6321] text-white text-xs font-bold uppercase tracking-wider rounded-full hover:bg-white hover:text-black"
                      >
                        Опубликовать
                      </button>
                    </div>
                  </form>
                )}

                {/* Reviews List */}
                <div className="space-y-4">
                  {reviews.length === 0 ? (
                    <p className="text-xs text-white/40 py-4 text-center">Будьте первым, кто оставит отзыв о данном товаре!</p>
                  ) : (
                    reviews.map((r) => (
                      <div key={r.id} className="p-4 bg-black rounded-2xl border border-white/10 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-xs text-white">{r.authorName}</span>
                            {r.verifiedPurchase && (
                              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-semibold">
                                Проверенная покупка
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-white/40">{r.date}</span>
                        </div>

                        <div className="flex text-[#FF6321] text-xs">
                          {Array.from({ length: 5 }).map((_, idx) => (
                            <Star key={idx} className={`w-3.5 h-3.5 ${idx < r.rating ? 'fill-current' : 'text-white/20'}`} />
                          ))}
                        </div>

                        <p className="text-xs text-white/80">{r.text}</p>

                        {r.pros && (
                          <div className="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 p-2 rounded-lg">
                            <span className="font-bold">Плюсы: </span>{r.pros}
                          </div>
                        )}

                        {r.merchantReply && (
                          <div className="ml-4 pl-4 border-l-2 border-[#FF6321] bg-white/5 p-3 rounded-r-xl text-xs space-y-1">
                            <div className="font-bold text-white flex items-center space-x-1">
                              <Store className="w-3.5 h-3.5 text-[#FF6321]" />
                              <span>Ответ продавца ({r.merchantReply.date})</span>
                            </div>
                            <p className="text-white/70">{r.merchantReply.text}</p>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Q&A View */}
            {activeTab === 'qa' && (
              <div className="space-y-4 text-xs text-white/80">
                <div className="p-4 bg-black rounded-xl border border-white/10 space-y-2">
                  <div className="font-bold text-white">В: Имеется ли официальная гарантия в РФ?</div>
                  <div className="text-white/60">О: Да, на все товары предоставляется официальная гарантия производителя и поддержка сервисных центров СеверМаркет.</div>
                </div>
                <div className="p-4 bg-black rounded-xl border border-white/10 space-y-2">
                  <div className="font-bold text-white">В: Можно ли забрать заказ из ближайшего ПВЗ?</div>
                  <div className="text-white/60">О: Да, при оформлении заказа вы можете выбрать любой из 45 000 пунктов выдачи заказов по всей России.</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
