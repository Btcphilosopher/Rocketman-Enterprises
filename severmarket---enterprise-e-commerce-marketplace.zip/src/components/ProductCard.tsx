import React from 'react';
import { Product } from '../types';
import { Star, Heart, ShoppingCart, BarChart3, ShieldCheck } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onProductClick: (product: Product) => void;
  onAddToCart: (product: Product, e: React.MouseEvent) => void;
  isFavorite: boolean;
  onToggleFavorite: (product: Product, e: React.MouseEvent) => void;
  isCompared: boolean;
  onToggleCompare: (product: Product, e: React.MouseEvent) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onProductClick,
  onAddToCart,
  isFavorite,
  onToggleFavorite,
  isCompared,
  onToggleCompare
}) => {
  return (
    <div
      onClick={() => onProductClick(product)}
      className="group bg-[#121212] rounded-2xl border border-white/10 hover:border-[#FF6321]/50 hover:shadow-2xl transition-all duration-300 flex flex-col justify-between overflow-hidden relative cursor-pointer p-3.5"
    >
      <div>
        {/* Top Image Box */}
        <div className="relative w-full h-44 bg-black rounded-xl overflow-hidden mb-3 flex items-center justify-center p-2 border border-white/5">
          {/* Discount Badge */}
          {product.discountPercent && (
            <span className="absolute top-2 left-2 z-10 bg-[#FF6321] text-white font-bold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full shadow-md">
              -{product.discountPercent}%
            </span>
          )}

          {/* Top Right Action Icons */}
          <div className="absolute top-2 right-2 z-10 flex flex-col space-y-1">
            <button
              onClick={(e) => onToggleFavorite(product, e)}
              className={`p-1.5 rounded-full backdrop-blur-md transition cursor-pointer ${
                isFavorite 
                  ? 'bg-[#FF6321] text-white border border-[#FF6321]' 
                  : 'bg-black/60 hover:bg-black text-white/60 hover:text-white border border-white/10'
              }`}
              title="Добавить в избранное"
            >
              <Heart className={`w-3.5 h-3.5 ${isFavorite ? 'fill-current' : ''}`} />
            </button>

            <button
              onClick={(e) => onToggleCompare(product, e)}
              className={`p-1.5 rounded-full backdrop-blur-md transition cursor-pointer ${
                isCompared 
                  ? 'bg-amber-500 text-black border border-amber-400' 
                  : 'bg-black/60 hover:bg-black text-white/60 hover:text-white border border-white/10'
              }`}
              title="Сравнить характеристики"
            >
              <BarChart3 className="w-3.5 h-3.5" />
            </button>
          </div>

          <img
            src={product.images[0]}
            alt={product.title}
            className="max-h-full max-w-full object-contain group-hover:scale-105 transition duration-300 opacity-90 group-hover:opacity-100"
          />
        </div>

        {/* Brand & Merchant info */}
        <div className="flex items-center justify-between text-[10px] uppercase tracking-wider text-white/40 mb-1">
          <span className="font-bold text-white/70">{product.brand}</span>
          <span className="flex items-center text-emerald-400 font-medium">
            <ShieldCheck className="w-3 h-3 mr-0.5" />
            <span>{product.merchantDeliveryDays} дн.</span>
          </span>
        </div>

        {/* Title */}
        <h3 className="text-xs font-medium text-white line-clamp-2 leading-snug mb-2 group-hover:text-[#FF6321] transition">
          {product.title}
        </h3>

        {/* Rating & Reviews */}
        <div className="flex items-center space-x-1.5 mb-3 text-xs">
          <div className="flex items-center text-[#FF6321]">
            <Star className="w-3.5 h-3.5 fill-current" />
            <span className="font-bold text-white ml-1 text-xs">{product.rating.toFixed(1)}</span>
          </div>
          <span className="text-white/40 text-[11px]">({product.reviewCount})</span>
        </div>
      </div>

      {/* Bottom Pricing & Add Button */}
      <div className="pt-2 border-t border-white/10 flex items-end justify-between">
        <div>
          <div className="flex items-baseline space-x-2">
            <span className="text-base font-black text-white">
              {product.price.toLocaleString('ru-RU')} ₽
            </span>
          </div>
          {product.oldPrice && (
            <span className="text-xs text-white/30 line-through">
              {product.oldPrice.toLocaleString('ru-RU')} ₽
            </span>
          )}
        </div>

        <button
          onClick={(e) => onAddToCart(product, e)}
          className="p-2.5 bg-[#FF6321] hover:bg-white hover:text-black text-white rounded-full transition shadow-md shadow-[#FF6321]/20 flex items-center justify-center cursor-pointer"
          title="Добавить в корзину"
        >
          <ShoppingCart className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
