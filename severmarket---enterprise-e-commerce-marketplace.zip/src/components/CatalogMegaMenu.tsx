import React, { useState } from 'react';
import { 
  Smartphone, Laptop, Home, Shirt, Sparkles, Dumbbell, Car, Baby, 
  BookOpen, Tv, ChevronRight, Zap, ShoppingBag, Grid, Shield, Star
} from 'lucide-react';
import { Category } from '../types';

interface CatalogMegaMenuProps {
  categories: Category[];
  isOpen: boolean;
  onClose: () => void;
  onSelectCategory: (catId: string) => void;
  onSelectSubcategory?: (sub: string) => void;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  Smartphone: <Smartphone className="w-4 h-4" />,
  Laptop: <Laptop className="w-4 h-4" />,
  Home: <Home className="w-4 h-4" />,
  Shirt: <Shirt className="w-4 h-4" />,
  Sparkles: <Sparkles className="w-4 h-4" />,
  Dumbbell: <Dumbbell className="w-4 h-4" />,
  Car: <Car className="w-4 h-4" />,
  Baby: <Baby className="w-4 h-4" />,
  BookOpen: <BookOpen className="w-4 h-4" />,
  Tv: <Tv className="w-4 h-4" />
};

export const CatalogMegaMenu: React.FC<CatalogMegaMenuProps> = ({
  categories,
  isOpen,
  onClose,
  onSelectCategory,
  onSelectSubcategory
}) => {
  const [activeCategoryId, setActiveCategoryId] = useState<string>(categories[0]?.id || 'cat-electronics');

  if (!isOpen) return null;

  const activeCategory = categories.find(c => c.id === activeCategoryId) || categories[0];

  return (
    <div className="relative z-30">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity" 
        onClick={onClose}
      />

      {/* Flyout Catalog Container */}
      <div className="absolute top-0 left-0 right-0 bg-white border-b border-slate-200 shadow-2xl z-40 max-w-7xl mx-auto rounded-b-2xl overflow-hidden">
        <div className="flex h-[480px]">
          {/* Left Category Sidebar */}
          <div className="w-72 bg-slate-50 border-r border-slate-200 overflow-y-auto py-2 divide-y divide-slate-100">
            {categories.map((cat) => {
              const isActive = cat.id === activeCategoryId;
              return (
                <button
                  key={cat.id}
                  onMouseEnter={() => setActiveCategoryId(cat.id)}
                  onClick={() => {
                    onSelectCategory(cat.id);
                    onClose();
                  }}
                  className={`w-full flex items-center justify-between px-4 py-2.5 text-xs font-semibold text-left transition cursor-pointer ${
                    isActive 
                      ? 'bg-blue-600 text-white shadow-xs' 
                      : 'text-slate-700 hover:bg-slate-200/60 hover:text-blue-600'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <span className={isActive ? 'text-white' : 'text-slate-500'}>
                      {ICON_MAP[cat.icon] || <Grid className="w-4 h-4" />}
                    </span>
                    <span>{cat.name}</span>
                  </div>
                  <ChevronRight className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                </button>
              );
            })}
          </div>

          {/* Right Subcategories & Brands Area */}
          <div className="flex-1 p-6 overflow-y-auto bg-white flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                    {ICON_MAP[activeCategory.icon] || <Grid className="w-5 h-5" />}
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">{activeCategory.name}</h3>
                    <p className="text-xs text-slate-500">
                      Более {activeCategory.itemCount.toLocaleString('ru-RU')} товаров с доставкой по России
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    onSelectCategory(activeCategory.id);
                    onClose();
                  }}
                  className="px-4 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-semibold text-xs rounded-lg transition cursor-pointer flex items-center space-x-1"
                >
                  <span>Смотреть все</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Subcategories Grid */}
              <div className="grid grid-cols-3 gap-6">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Популярные разделы</h4>
                  <ul className="space-y-2">
                    {activeCategory.subcategories?.slice(0, 6).map((sub) => (
                      <li key={sub}>
                        <button
                          onClick={() => {
                            if (onSelectSubcategory) onSelectSubcategory(sub);
                            onSelectCategory(activeCategory.id);
                            onClose();
                          }}
                          className="text-xs text-slate-700 hover:text-blue-600 font-medium transition cursor-pointer flex items-center space-x-1"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-slate-300 hover:bg-blue-600" />
                          <span>{sub}</span>
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Спецпредложения</h4>
                  <ul className="space-y-2.5">
                    <li className="flex items-center space-x-2 text-xs font-semibold text-amber-600 bg-amber-50 p-2 rounded-lg">
                      <Zap className="w-4 h-4 text-amber-500" />
                      <span>Скидки до -50% на раздел</span>
                    </li>
                    <li className="flex items-center space-x-2 text-xs font-semibold text-blue-600 bg-blue-50 p-2 rounded-lg">
                      <Shield className="w-4 h-4 text-blue-500" />
                      <span>Гарантия от проверенных продавцов</span>
                    </li>
                  </ul>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">Популярные бренды</h4>
                  <div className="flex flex-wrap gap-2">
                    {['Xiaomi', 'ASUS', 'De\'Longhi', 'Apple', 'Samsung', 'Nordic', 'Continental'].map((b) => (
                      <span key={b} className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded-md cursor-pointer transition">
                        {b}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Promo Strip */}
            <div className="mt-6 pt-4 border-t border-slate-100 bg-gradient-to-r from-blue-900 to-indigo-900 rounded-xl p-4 text-white flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center text-amber-300">
                  <Star className="w-5 h-5 fill-current" />
                </div>
                <div>
                  <div className="text-xs font-bold">Кешбэк 10% бонусами SeverMarket</div>
                  <div className="text-[11px] text-blue-200">Оплачивайте до 99% покупки при следующем заказе</div>
                </div>
              </div>
              <button
                onClick={() => {
                  onSelectCategory(activeCategory.id);
                  onClose();
                }}
                className="px-4 py-2 bg-amber-400 hover:bg-amber-500 text-slate-950 text-xs font-bold rounded-lg transition cursor-pointer"
              >
                Перейти к подборке
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
