import { Category, Product, Merchant, Order, Review, SystemMetrics } from '../types';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-electronics',
    name: 'Электроника',
    slug: 'electronics',
    icon: 'Smartphone',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=600&q=80',
    itemCount: 421500,
    subcategories: ['Смартфоны', 'Наушники', 'Смарт-часы', 'Планшеты', 'Аудиосистемы', 'Аксессуары']
  },
  {
    id: 'cat-computers',
    name: 'Компьютеры',
    slug: 'computers',
    icon: 'Laptop',
    image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=600&q=80',
    itemCount: 284000,
    subcategories: ['Ноутбуки', 'Мониторы', 'Комплектующие', 'Периферия', 'Сетевое оборудование']
  },
  {
    id: 'cat-home',
    name: 'Дом и кухня',
    slug: 'home-kitchen',
    icon: 'Home',
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
    itemCount: 890000,
    subcategories: ['Посуда', 'Мебель', 'Декор', 'Освещение', 'Текстиль', 'Уборка']
  },
  {
    id: 'cat-fashion',
    name: 'Одежда и обувь',
    slug: 'fashion',
    icon: 'Shirt',
    image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&w=600&q=80',
    itemCount: 1540000,
    subcategories: ['Мужская одежда', 'Женская одежда', 'Детская одежда', 'Обувь', 'Сумки']
  },
  {
    id: 'cat-beauty',
    name: 'Красота и здоровье',
    slug: 'beauty',
    icon: 'Sparkles',
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80',
    itemCount: 620000,
    subcategories: ['Уход за кожей', 'Парфюмерия', 'Макияж', 'Уход за волосами', 'Витамины']
  },
  {
    id: 'cat-sports',
    name: 'Спорт и отдых',
    slug: 'sports',
    icon: 'Dumbbell',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=600&q=80',
    itemCount: 310000,
    subcategories: ['Фитнес', 'Туризм и кемпинг', 'Велоспорт', 'Зимние виды', 'Спортивное питание']
  },
  {
    id: 'cat-auto',
    name: 'Автотовары',
    slug: 'auto',
    icon: 'Car',
    image: 'https://images.unsplash.com/photo-1552519507-da3b142c6e3d?auto=format&fit=crop&w=600&q=80',
    itemCount: 780000,
    subcategories: ['Шины и диски', 'Автохимия', 'Видеорегистраторы', 'Запчасти', 'Аксессуары']
  },
  {
    id: 'cat-kids',
    name: 'Детские товары',
    slug: 'kids',
    icon: 'Baby',
    image: 'https://images.unsplash.com/photo-1566454825481-4e48f80aa4d7?auto=format&fit=crop&w=600&q=80',
    itemCount: 490000,
    subcategories: ['Игрушки', 'Коляски', 'Детское питание', 'Детская комната', 'Школа']
  },
  {
    id: 'cat-books',
    name: 'Книги',
    slug: 'books',
    icon: 'BookOpen',
    itemCount: 340000,
    subcategories: ['Художественная', 'Бизнес-литература', 'Учебная', 'Детские книги']
  },
  {
    id: 'cat-appliances',
    name: 'Бытовая техника',
    slug: 'appliances',
    icon: 'Tv',
    itemCount: 230000,
    subcategories: ['Холодильники', 'Стиральные машины', 'Пылесосы', 'Кофемашины', 'Климат']
  }
];

export const INITIAL_MERCHANTS: Merchant[] = [
  {
    id: 'm-1',
    name: 'СеверМаркет Официальный Store',
    logo: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=120&q=80',
    rating: 4.9,
    reviewCount: 48200,
    verified: true,
    productCount: 1540,
    totalOrders: 320000,
    joinedDate: '2022-01-15',
    email: 'official@severmarket.ru',
    phone: '+7 (800) 555-01-99',
    commissionRate: 5
  },
  {
    id: 'm-2',
    name: 'ТехноПарк Россия',
    logo: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
    rating: 4.8,
    reviewCount: 12400,
    verified: true,
    productCount: 820,
    totalOrders: 94000,
    joinedDate: '2022-06-10',
    email: 'contact@technopark-rus.ru',
    phone: '+7 (495) 777-12-34',
    commissionRate: 7
  },
  {
    id: 'm-3',
    name: 'Дом & Уют Премиум',
    logo: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&q=80',
    rating: 4.7,
    reviewCount: 5600,
    verified: true,
    productCount: 450,
    totalOrders: 41000,
    joinedDate: '2023-02-01',
    email: 'sales@homecozy.ru',
    phone: '+7 (800) 200-44-55',
    commissionRate: 8
  },
  {
    id: 'm-4',
    name: 'СпортМастер Плюс',
    logo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&q=80',
    rating: 4.9,
    reviewCount: 18900,
    verified: true,
    productCount: 1100,
    totalOrders: 135000,
    joinedDate: '2022-09-18',
    email: 'info@sportmaster-plus.ru',
    phone: '+7 (800) 333-88-99',
    commissionRate: 6
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    title: 'Смартфон Xiaomi 14 12/256 ГБ, черный',
    titleRu: 'Смартфон Xiaomi 14 12/256 ГБ, черный',
    slug: 'xiaomi-14-12-256gb-black',
    description: 'Флагманский смартфон с оптикой Leica, мощным процессором Snapdragon 8 Gen 3 и сверхчетким AMOLED-дисплеем 120 Гц. Поддерживает быструю зарядку 90 Вт.',
    categoryId: 'cat-electronics',
    categoryName: 'Электроника',
    price: 49990,
    oldPrice: 64990,
    discountPercent: 23,
    rating: 4.9,
    reviewCount: 342,
    isFlashSale: true,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Xiaomi',
    merchantId: 'm-1',
    merchantName: 'СеверМаркет Официальный Store',
    merchantRating: 4.9,
    merchantDeliveryDays: 1,
    stock: 84,
    sku: 'XIA-14-BLK-256',
    specs: {
      'Процессор': 'Qualcomm Snapdragon 8 Gen 3',
      'Оперативная память': '12 ГБ LPDDR5X',
      'Встроенная память': '256 ГБ UFS 4.0',
      'Экран': '6.36" AMOLED CrystalRes 120Hz',
      'Основная камера': '50 Мп + 50 Мп + 50 Мп Leica',
      'Аккумулятор': '4610 мАч, Зарядка 90 Вт',
      'ОС': 'Xiaomi HyperOS (Android 14)',
      'Гарантия': '12 месяцев'
    },
    variants: [
      { id: 'v1-1', name: '12/256 ГБ Черный', sku: 'XIA-14-BLK-256', price: 49990, oldPrice: 64990, stock: 45, attributes: { color: 'Черный', storage: '256 ГБ' } },
      { id: 'v1-2', name: '12/512 ГБ Зеленый', sku: 'XIA-14-GRN-512', price: 57990, oldPrice: 72990, stock: 22, attributes: { color: 'Зеленый', storage: '512 ГБ' } },
      { id: 'v1-3', name: '16/1 ТБ Белый', sku: 'XIA-14-WHT-1TB', price: 68990, oldPrice: 84990, stock: 17, attributes: { color: 'Белый', storage: '1 ТБ' } }
    ],
    tags: ['Бестселлер', 'Быстрая доставка', 'Скидка 23%']
  },
  {
    id: 'prod-2',
    title: 'Ноутбук ASUS VivoBook 15 OLED 16 ГБ / 512 ГБ SSD',
    titleRu: 'Ноутбук ASUS VivoBook 15 OLED 16 ГБ / 512 ГБ SSD',
    slug: 'asus-vivobook-15-oled',
    description: 'Ультрабук с 15.6-дюймовым OLED-экраном 2.8K, процессором Intel Core i5 13-го поколения и легким металлическим корпусом.',
    categoryId: 'cat-computers',
    categoryName: 'Компьютеры',
    price: 54990,
    oldPrice: 64990,
    discountPercent: 15,
    rating: 4.8,
    reviewCount: 189,
    isFlashSale: true,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1531297484001-80022131f5a1?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'ASUS',
    merchantId: 'm-2',
    merchantName: 'ТехноПарк Россия',
    merchantRating: 4.8,
    merchantDeliveryDays: 2,
    stock: 35,
    sku: 'ASU-VB15-OLED',
    specs: {
      'Процессор': 'Intel Core i5-13500H (12 ядер, до 4.7 ГГц)',
      'ОЗУ': '16 ГБ DDR5 4800 МГц',
      'Накопитель': '512 ГБ PCIe 4.0 NVMe SSD',
      'Дисплей': '15.6" OLED 1920x1080 100% DCI-P3',
      'Графика': 'Intel Iris Xe Graphics',
      'Вес': '1.65 кг',
      'Автономность': 'До 9 часов'
    },
    tags: ['OLED экран', 'Рассрочка 0-0-12']
  },
  {
    id: 'prod-3',
    title: 'Робот-пылесос Xiaomi Robot Vacuum S10 с влажной уборкой',
    titleRu: 'Робот-пылесос Xiaomi Robot Vacuum S10 с влажной уборкой',
    slug: 'xiaomi-robot-vacuum-s10',
    description: 'Интеллектуальный робот-пылесос с лазерной навигацией LDS, мощностью всасывания 4000 Па и управлением через Mi Home.',
    categoryId: 'cat-home',
    categoryName: 'Дом и кухня',
    price: 13990,
    oldPrice: 19990,
    discountPercent: 30,
    rating: 4.9,
    reviewCount: 512,
    isFlashSale: true,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1558317374-067fb5f30001?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Xiaomi',
    merchantId: 'm-1',
    merchantName: 'СеверМаркет Официальный Store',
    merchantRating: 4.9,
    merchantDeliveryDays: 1,
    stock: 120,
    sku: 'XIA-RVC-S10',
    specs: {
      'Тип уборки': 'Сухая и влажная',
      'Мощность всасывания': '4000 Па',
      'Навигация': 'LDS Лазерный лидар 360°',
      'Емкость аккумулятора': '3200 мАч',
      'Управление со смартфона': 'Да (Mi Home, Алиса)',
      'Объем пылесборника': '300 мл',
      'Объем бака для воды': '170 мл'
    },
    tags: ['Лидер продаж', 'Хит сезона']
  },
  {
    id: 'prod-4',
    title: 'Кофемашина автоматическая De\'Longhi ECAM22.110',
    titleRu: 'Кофемашина автоматическая De\'Longhi ECAM22.110',
    slug: 'delonghi-ecam-22110',
    description: 'Компактная автоматическая зерновая кофемашина с механической панелью управления и ручным капучинатором для идеального эспрессо и капучино.',
    categoryId: 'cat-appliances',
    categoryName: 'Бытовая техника',
    price: 34990,
    oldPrice: 43990,
    discountPercent: 20,
    rating: 4.9,
    reviewCount: 890,
    isFlashSale: true,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1517668808822-9e428824603b?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80'
    ],
    brand: "De'Longhi",
    merchantId: 'm-3',
    merchantName: 'Дом & Уют Премиум',
    merchantRating: 4.7,
    merchantDeliveryDays: 2,
    stock: 42,
    sku: 'DEL-ECAM22110',
    specs: {
      'Давление': '15 бар',
      'Используемый кофе': 'Зерновой / Молотый',
      'Объем резервуара для воды': '1.8 л',
      'Емкость контейнера для зерен': '250 г',
      'Капучинатор': 'Ручной (панарелло)',
      'Мощность': '1450 Вт',
      'Гарантия': '36 месяцев'
    },
    tags: ['Итальянское качество', 'Гарантия 3 года']
  },
  {
    id: 'prod-5',
    title: 'Наушники Apple AirPods Pro 2 (USB-C)',
    titleRu: 'Наушники Apple AirPods Pro 2 (USB-C)',
    slug: 'apple-airpods-pro-2-usbc',
    description: 'Беспроводные наушники с активным шумоподавлением в 2 раза мощнее, режимом прозрачности, чипом H2 и кейсом MagSafe (USB-C).',
    categoryId: 'cat-electronics',
    categoryName: 'Электроника',
    price: 21990,
    oldPrice: 29490,
    discountPercent: 25,
    rating: 4.9,
    reviewCount: 1250,
    isFlashSale: true,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1588423771073-b8903fbb85b5?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Apple',
    merchantId: 'm-1',
    merchantName: 'СеверМаркет Официальный Store',
    merchantRating: 4.9,
    merchantDeliveryDays: 1,
    stock: 190,
    sku: 'APP-AIR-PRO2-USBC',
    specs: {
      'Чип': 'Apple H2',
      'Шумоподавление': 'Активное ANC + Адаптивная прозрачность',
      'Разъем зарядки': 'USB-C / MagSafe / Qi',
      'Время работы': 'До 6 часов (до 30 часов с кейсом)',
      'Влагозащита': 'IP54',
      'Пространственное аудио': 'Персонализированное с трекингом головы'
    },
    tags: ['Оригинал 100%', 'Экспресс доставка']
  },
  {
    id: 'prod-6',
    title: 'Смарт-часы Samsung Galaxy Watch6 44mm, графит',
    titleRu: 'Смарт-часы Samsung Galaxy Watch6 44mm, графит',
    slug: 'samsung-galaxy-watch-6-44mm',
    description: 'Интеллектуальный помощник для здоровья и спорта с сапфировым стеклом, увеличенным экраном, мониторингом сна и ЭКГ.',
    categoryId: 'cat-electronics',
    categoryName: 'Электроника',
    price: 15990,
    oldPrice: 19490,
    discountPercent: 18,
    rating: 4.8,
    reviewCount: 210,
    isFlashSale: true,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Samsung',
    merchantId: 'm-2',
    merchantName: 'ТехноПарк Россия',
    merchantRating: 4.8,
    merchantDeliveryDays: 2,
    stock: 60,
    sku: 'SAM-GW6-44-GRP',
    specs: {
      'Дисплей': '1.5" Super AMOLED 480x480 Сапфировое стекло',
      'Операционная система': 'Wear OS Powered by Samsung',
      'Датчики': 'ЭКГ, Состав тела BioActive, Пульс, SpO2',
      'Водонепроницаемость': '5 ATM / IP68 / MIL-STD-810H',
      'Бесконтактная оплата': 'Samsung Pay / Mir Pay'
    },
    tags: ['Сапфировое стекло', 'ECG Sensor']
  },
  {
    id: 'prod-7',
    title: 'Пальто двубортное шерстяное классическое Oversize',
    titleRu: 'Пальто двубортное шерстяное классическое Oversize',
    slug: 'wool-trench-coat-oversize',
    description: 'Элегантное пальто из натуральной шерсти (80%) с кашемиром. Отличный силуэт, заниженная линия плеч и пояс в комплекте.',
    categoryId: 'cat-fashion',
    categoryName: 'Одежда и обувь',
    price: 12490,
    oldPrice: 17990,
    discountPercent: 30,
    rating: 4.9,
    reviewCount: 88,
    isPopular: true,
    images: [
      'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Nordic Heritage',
    merchantId: 'm-3',
    merchantName: 'Дом & Уют Премиум',
    merchantRating: 4.7,
    merchantDeliveryDays: 2,
    stock: 28,
    sku: 'NOR-COAT-WOL-BEI',
    specs: {
      'Состав': '80% Мериносовая шерсть, 15% Кашемир, 5% Полиамид',
      'Подкладка': '100% Вискоза',
      'Сезон': 'Демисезон (до -5°C)',
      'Страна производства': 'Россия',
      'Застежка': 'Пуговицы, пояс'
    },
    variants: [
      { id: 'v7-1', name: 'Бежевый / S (42-44)', sku: 'NOR-COAT-BEI-S', price: 12490, stock: 10, attributes: { color: 'Бежевый', size: 'S' } },
      { id: 'v7-2', name: 'Бежевый / M (44-46)', sku: 'NOR-COAT-BEI-M', price: 12490, stock: 12, attributes: { color: 'Бежевый', size: 'M' } },
      { id: 'v7-3', name: 'Черный / M (44-46)', sku: 'NOR-COAT-BLK-M', price: 12490, stock: 6, attributes: { color: 'Черный', size: 'M' } }
    ],
    tags: ['Премиум шерсть', 'Новая коллекция']
  },
  {
    id: 'prod-8',
    title: 'Набор гантелей разборных разборные 20 кг (2 х 10 кг)',
    titleRu: 'Набор гантелей разборных разборные 20 кг (2 х 10 кг)',
    slug: 'dumbbell-set-20kg-steel',
    description: 'Универсальный спортивный комплект гантелей в кейсе с хромированными блинами и соединительным грифом для превращения в штангу.',
    categoryId: 'cat-sports',
    categoryName: 'Спорт и отдых',
    price: 4990,
    oldPrice: 6990,
    discountPercent: 28,
    rating: 4.8,
    reviewCount: 310,
    images: [
      'https://images.unsplash.com/photo-1584735935682-2f2b69dff9d2?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'ProSports',
    merchantId: 'm-4',
    merchantName: 'СпортМастер Плюс',
    merchantRating: 4.9,
    merchantDeliveryDays: 1,
    stock: 75,
    sku: 'SPO-DMB-20KG',
    specs: {
      'Общий вес': '20 кг (пара)',
      'Материал': 'Хромированная сталь',
      'Комплектация': '8 блинов х 1.25 кг, 4 блина х 2.5 кг, 2 грифа, соединитель, кейс',
      'Покрытие грифа': 'Прорезиненный противоскользящий хват'
    },
    tags: ['Спорт дома', '2 в 1 Штанга']
  },
  {
    id: 'prod-9',
    title: 'Шина зимняя Continental WinterContact TS870 205/55 R16 91T',
    titleRu: 'Шина зимняя Continental WinterContact TS870 205/55 R16 91T',
    slug: 'continental-wintercontact-ts870-205-55-r16',
    description: 'Премиальная нешипованная зимняя шина («липучка») с высочайшим сцеплением на обледенелом и мокром асфальте. Производство Германия.',
    categoryId: 'cat-auto',
    categoryName: 'Автотовары',
    price: 8490,
    oldPrice: 10990,
    discountPercent: 22,
    rating: 5.0,
    reviewCount: 142,
    images: [
      'https://images.unsplash.com/photo-1578844251758-2f71da64c96f?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Continental',
    merchantId: 'm-2',
    merchantName: 'ТехноПарк Россия',
    merchantRating: 4.8,
    merchantDeliveryDays: 2,
    stock: 200,
    sku: 'CON-WTS870-2055516',
    specs: {
      'Типоразмер': '205/55 R16',
      'Сезонность': 'Зимняя нешипованная (фрикционная)',
      'Индекс нагрузки': '91 (615 кг)',
      'Индекс скорости': 'T (до 190 км/ч)',
      'Страна производства': 'Германия'
    },
    tags: ['Немецкое качество', 'Тесты ADAC #1']
  },
  {
    id: 'prod-10',
    title: 'Плюшевый мишка СеверМаркет XXL 120 см',
    titleRu: 'Плюшевый мишка СеверМаркет XXL 120 см',
    slug: 'teddy-bear-xxl-120cm',
    description: 'Огромный мягкий медведь из гипоаллергенного плюша с наполнением из премиального холлофайбера. Отличный подарок ребенку и любимым.',
    categoryId: 'cat-kids',
    categoryName: 'Детские товары',
    price: 3290,
    oldPrice: 4500,
    discountPercent: 26,
    rating: 4.9,
    reviewCount: 95,
    images: [
      'https://images.unsplash.com/photo-1559454403-b8fb88521f11?auto=format&fit=crop&w=800&q=80'
    ],
    brand: 'Nordic Toys',
    merchantId: 'm-3',
    merchantName: 'Дом & Уют Премиум',
    merchantRating: 4.7,
    merchantDeliveryDays: 1,
    stock: 40,
    sku: 'KID-TED-120-WHT',
    specs: {
      'Высота': '120 см',
      'Материал': 'Гипоаллергенный плюш',
      'Наполнитель': 'Первичный холлофайбер 100%',
      'Безопасность': 'Сертификат ЕАЭС 0+'
    },
    tags: ['Гипоаллергенно', 'Подарочный бант']
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    authorName: 'Александр М.',
    rating: 5,
    date: '2026-07-28',
    text: 'Телефон просто пушка! Камера Leica делает потрясающие снимки даже ночью. Зарядка от 0 до 100% буквально за 30 минут. Доставили курьером СеверМаркета на следующий день.',
    pros: 'Камера, экран, быстрая зарядка, компактный размер',
    cons: 'Комплектный чехол хотелось бы посветлее',
    verifiedPurchase: true,
    merchantReply: {
      date: '2026-07-29',
      text: 'Спасибо за отзыв, Александр! Рады, что смартфон оправдал ожидания. Желаем отличных снимков!'
    },
    helpfulCount: 24
  },
  {
    id: 'rev-2',
    productId: 'prod-1',
    authorName: 'Елена К.',
    rating: 5,
    date: '2026-07-25',
    text: 'Брала муж на подарок. Он в восторге от быстродействия в играх и работы HyperOS. Оригинальный продукт с официальной гарантией.',
    pros: 'Экран супер четкий, автономность',
    cons: 'Нет',
    verifiedPurchase: true,
    helpfulCount: 12
  },
  {
    id: 'rev-3',
    productId: 'prod-3',
    authorName: 'Дмитрий В.',
    rating: 5,
    date: '2026-07-20',
    text: 'Робот отлично справляется с коврами и ламинатом. Строит точную карту квартиры через LDS лидар. На 60 кв.м уходит минут 35.',
    pros: 'Мощный, тихий, отлично убирает шерсть кота',
    cons: 'Порог в балконе 2.5 см переехать не смог',
    verifiedPurchase: true,
    helpfulCount: 45
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-1001',
    orderNumber: 'RU-892304-SM',
    date: '2026-08-01',
    status: 'shipped',
    items: [
      {
        product: INITIAL_PRODUCTS[0],
        variantId: 'v1-1',
        quantity: 1,
        selectedVariantName: '12/256 ГБ Черный'
      },
      {
        product: INITIAL_PRODUCTS[4],
        quantity: 1
      }
    ],
    totalAmount: 71980,
    shippingFee: 0,
    discountAmount: 1500,
    deliveryMethod: 'courier',
    courierAddress: 'г. Москва, ул. Тверская, д. 12, кв. 45',
    recipientName: 'Иван Петров',
    recipientPhone: '+7 (916) 555-43-21',
    paymentMethod: 'sbp',
    trackingCode: 'SM-TRACK-994102',
    estimatedDelivery: '2026-08-04'
  },
  {
    id: 'ord-1002',
    orderNumber: 'RU-741029-SM',
    date: '2026-07-20',
    status: 'delivered',
    items: [
      {
        product: INITIAL_PRODUCTS[2],
        quantity: 1
      }
    ],
    totalAmount: 13990,
    shippingFee: 0,
    discountAmount: 0,
    deliveryMethod: 'pickup',
    pickupAddress: 'ПВЗ СеверМаркет №104 (Москва, Ленинградский пр-кт 31)',
    recipientName: 'Иван Петров',
    recipientPhone: '+7 (916) 555-43-21',
    paymentMethod: 'card',
    trackingCode: 'SM-TRACK-882015',
    estimatedDelivery: '2026-07-22'
  }
];

export const MOCK_SYSTEM_METRICS: SystemMetrics = {
  activeUsers: 142850,
  totalGmv: 4289500000, // 4.28B Rubles
  totalOrders: 1842000,
  totalMerchants: 4850,
  apiLatencyMs: 14.2,
  redisHitRate: 98.6,
  dbConnections: 84,
  uptimeSeconds: 9845000
};

export const MOCK_ARCHITECTURE_DOCS = {
  dockerfile: `FROM rust:1.78-alpine AS builder
WORKDIR /app
RUN apk add --no-libc-dev build-base openssl-dev
COPY Cargo.toml Cargo.lock ./
COPY src ./src
RUN cargo build --release --bin severmarket-backend

FROM alpine:3.19
WORKDIR /app
RUN apk add --no-cache ca-certificates libssl3 tzdata
COPY --from=builder /app/target/release/severmarket-backend /app/severmarket-backend
COPY config /app/config
EXPOSE 8080 50051
ENTRYPOINT ["/app/severmarket-backend"]`,

  dockerCompose: `version: '3.8'

services:
  api-gateway:
    build: .
    ports:
      - "8080:8080"
      - "50051:50051"
    environment:
      - RUST_LOG=info,severmarket=debug
      - DATABASE_URL=postgres://sever_user:sever_pass@postgres:5432/severmarket
      - REDIS_URL=redis://redis:6379
      - OPENSEARCH_URL=http://opensearch:9200
    depends_on:
      - postgres
      - redis
      - opensearch

  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: severmarket
      POSTGRES_USER: sever_user
      POSTGRES_PASSWORD: sever_pass
    ports:
      - "5432:5432"
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./migrations/001_init.sql:/docker-entrypoint-initdb.d/001_init.sql

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

  opensearch:
    image: opensearchproject/opensearch:2.12.0
    environment:
      - discovery.type=single-node
      - DISABLE_SECURITY_PLUGIN=true
    ports:
      - "9200:9200"

volumes:
  pgdata:`,

  k8sManifest: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: severmarket-core-backend
  namespace: production
  labels:
    app.kubernetes.io/name: severmarket-backend
    tier: api
spec:
  replicas: 8
  selector:
    matchLabels:
      app: severmarket-backend
  template:
    metadata:
      labels:
        app: severmarket-backend
    spec:
      containers:
      - name: axum-server
        image: registry.severmarket.ru/severmarket-core:v2.4.0
        ports:
        - containerPort: 8080
          name: http-rest
        - containerPort: 50051
          name: grpc
        resources:
          limits:
            cpu: "2000m"
            memory: "2Gi"
          requests:
            cpu: "500m"
            memory: "512Mi"
        readinessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 5
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /health
            port: 8080
          initialDelaySeconds: 15
          periodSeconds: 20`,

  sqlSchema: `-- SeverMarket Enterprise Database Migration 001_init.sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE merchants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    logo_url TEXT,
    rating NUMERIC(3,2) DEFAULT 5.00,
    review_count INT DEFAULT 0,
    verified BOOLEAN DEFAULT FALSE,
    commission_rate NUMERIC(4,2) DEFAULT 7.00,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(255) UNIQUE NOT NULL,
    parent_id UUID REFERENCES categories(id),
    item_count INT DEFAULT 0
);

CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    merchant_id UUID NOT NULL REFERENCES merchants(id),
    category_id UUID NOT NULL REFERENCES categories(id),
    title VARCHAR(500) NOT NULL,
    slug VARCHAR(500) UNIQUE NOT NULL,
    description TEXT,
    brand VARCHAR(100),
    sku VARCHAR(100) UNIQUE NOT NULL,
    price_kopecks BIGINT NOT NULL,
    old_price_kopecks BIGINT,
    stock INT NOT NULL DEFAULT 0,
    rating NUMERIC(3,2) DEFAULT 5.00,
    review_count INT DEFAULT 0,
    specs JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_merchant ON products(merchant_id);
CREATE INDEX idx_products_specs ON products USING gin (specs);`,

  grpcProto: `syntax = "proto3";

package severmarket.v1;

option go_package = "severmarket/v1/pb";

service CatalogService {
  rpc GetProduct (GetProductRequest) returns (ProductResponse);
  rpc SearchProducts (SearchRequest) returns (SearchResponse);
  rpc CheckStock (CheckStockRequest) returns (CheckStockResponse);
}

service OrderService {
  rpc CreateOrder (CreateOrderRequest) returns (OrderResponse);
  rpc GetOrderStatus (OrderStatusRequest) returns (OrderStatusResponse);
}

message GetProductRequest {
  string product_id = 1;
}

message ProductResponse {
  string id = 1;
  string title = 2;
  int64 price_kopecks = 3;
  int32 stock = 4;
  string merchant_name = 5;
  repeated string images = 6;
}

message SearchRequest {
  string query = 1;
  string category_id = 2;
  int64 min_price = 3;
  int64 max_price = 4;
  int32 page = 5;
  int32 limit = 6;
}

message SearchResponse {
  repeated ProductResponse products = 1;
  int32 total_found = 2;
  int32 page = 3;
}`
};
