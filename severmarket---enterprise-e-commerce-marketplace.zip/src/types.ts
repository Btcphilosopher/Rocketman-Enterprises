export type NavigationTab = 'storefront' | 'catalog' | 'compare' | 'orders' | 'merchant' | 'admin' | 'architecture';

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  image?: string;
  itemCount: number;
  subcategories?: string[];
}

export interface ProductVariant {
  id: string;
  name: string;
  sku: string;
  price: number;
  oldPrice?: number;
  stock: number;
  attributes: Record<string, string>;
}

export interface Review {
  id: string;
  productId: string;
  authorName: string;
  authorAvatar?: string;
  rating: number; // 1-5
  date: string;
  text: string;
  pros?: string;
  cons?: string;
  verifiedPurchase: boolean;
  merchantReply?: {
    date: string;
    text: string;
  };
  helpfulCount: number;
}

export interface Product {
  id: string;
  title: string;
  titleRu: string;
  slug: string;
  description: string;
  categoryId: string;
  categoryName: string;
  price: number;
  oldPrice?: number;
  discountPercent?: number;
  rating: number;
  reviewCount: number;
  isFlashSale?: boolean;
  isPopular?: boolean;
  images: string[];
  brand: string;
  merchantId: string;
  merchantName: string;
  merchantRating: number;
  merchantDeliveryDays: number;
  stock: number;
  sku: string;
  specs: Record<string, string>;
  variants?: ProductVariant[];
  tags: string[];
}

export interface Merchant {
  id: string;
  name: string;
  logo: string;
  rating: number;
  reviewCount: number;
  verified: boolean;
  productCount: number;
  totalOrders: number;
  joinedDate: string;
  email: string;
  phone: string;
  commissionRate: number; // e.g., 8%
}

export interface CartItem {
  product: Product;
  variantId?: string;
  quantity: number;
  selectedVariantName?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  date: string;
  status: 'placed' | 'confirmed' | 'shipped' | 'pickup_point' | 'delivered' | 'cancelled' | 'returned';
  items: CartItem[];
  totalAmount: number;
  shippingFee: number;
  discountAmount: number;
  deliveryMethod: 'pickup' | 'courier' | 'post';
  pickupAddress?: string;
  courierAddress?: string;
  recipientName: string;
  recipientPhone: string;
  paymentMethod: 'card' | 'sbp' | 'sberpay' | 'installments';
  trackingCode: string;
  estimatedDelivery: string;
}

export interface SystemMetrics {
  activeUsers: number;
  totalGmv: number;
  totalOrders: number;
  totalMerchants: number;
  apiLatencyMs: number;
  redisHitRate: number;
  dbConnections: number;
  uptimeSeconds: number;
}

export interface ArchitectureDoc {
  dockerfile: string;
  dockerCompose: string;
  k8sManifest: string;
  sqlSchema: string;
  grpcProto: string;
  openApiJson: object;
}
