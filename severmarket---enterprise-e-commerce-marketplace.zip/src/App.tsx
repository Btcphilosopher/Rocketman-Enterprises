import React, { useState, useEffect } from 'react';
import { 
  NavigationTab, Product, Category, Merchant, Order, Review, CartItem 
} from './types';
import { 
  INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_MERCHANTS, 
  INITIAL_ORDERS, INITIAL_REVIEWS, MOCK_SYSTEM_METRICS 
} from './data/mockData';

import { Header } from './components/Header';
import { CatalogMegaMenu } from './components/CatalogMegaMenu';
import { HeroCarousel } from './components/HeroCarousel';
import { TrustBadges } from './components/TrustBadges';
import { PopularCategories } from './components/PopularCategories';
import { FlashSaleSection } from './components/FlashSaleSection';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CompareModal } from './components/CompareModal';
import { CatalogPage } from './components/CatalogPage';
import { CartCheckoutModal } from './components/CartCheckoutModal';
import { CustomerOrdersView } from './components/CustomerOrdersView';
import { MerchantPortal } from './components/MerchantPortal';
import { AdminDashboard } from './components/AdminDashboard';
import { ArchitectureDocs } from './components/ArchitectureDocs';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('storefront');

  // Core Data State
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [categories, setCategories] = useState<Category[]>(INITIAL_CATEGORIES);
  const [merchants, setMerchants] = useState<Merchant[]>(INITIAL_MERCHANTS);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);

  // User Interactive State
  const [cartItems, setCartItems] = useState<CartItem[]>([
    { product: INITIAL_PRODUCTS[0], quantity: 1, selectedVariantName: '12/256 ГБ Черный' },
    { product: INITIAL_PRODUCTS[4], quantity: 1 }
  ]);
  const [favorites, setFavorites] = useState<string[]>(['prod-1', 'prod-3']);
  const [comparedProducts, setComparedProducts] = useState<string[]>(['prod-1', 'prod-2']);

  // Filters & Modal State
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCity, setSelectedCity] = useState('Москва');

  const [selectedProductForDetail, setSelectedProductForDetail] = useState<Product | null>(null);
  const [isCatalogMegaOpen, setIsCatalogMegaOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCompareOpen, setIsCompareOpen] = useState(false);

  // Fetch initial API data from server
  useEffect(() => {
    fetch('/api/products')
      .then(res => res.json())
      .then(data => {
        if (data.products && data.products.length > 0) {
          setProducts(data.products);
        }
      })
      .catch(() => {});

    fetch('/api/categories')
      .then(res => res.json())
      .then(data => {
        if (data && data.length > 0) {
          setCategories(data);
        }
      })
      .catch(() => {});
  }, []);

  // Cart Calculations
  const cartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cartItems.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  // Handlers
  const handleAddToCart = (product: Product, selectedVariantId?: string) => {
    setCartItems(prev => {
      const existingIdx = prev.findIndex(item => item.product.id === product.id && item.variantId === selectedVariantId);
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += 1;
        return updated;
      }
      const variantObj = product.variants?.find(v => v.id === selectedVariantId);
      return [
        ...prev,
        {
          product,
          variantId: selectedVariantId,
          quantity: 1,
          selectedVariantName: variantObj ? variantObj.name : undefined
        }
      ];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, variantId: string | undefined, delta: number) => {
    setCartItems(prev => {
      return prev.map(item => {
        if (item.product.id === productId && item.variantId === variantId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      }).filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveCartItem = (productId: string, variantId?: string) => {
    setCartItems(prev => prev.filter(item => !(item.product.id === productId && item.variantId === variantId)));
  };

  const handleToggleFavorite = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites(prev => 
      prev.includes(product.id) ? prev.filter(id => id !== product.id) : [...prev, product.id]
    );
  };

  const handleToggleCompare = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    setComparedProducts(prev => {
      if (prev.includes(product.id)) {
        return prev.filter(id => id !== product.id);
      }
      if (prev.length >= 4) {
        alert('К сравнению можно добавить не более 4 товаров одновременно.');
        return prev;
      }
      return [...prev, product.id];
    });
  };

  const handleAddMerchantProduct = (newProductData: Omit<Product, 'id'>) => {
    const created: Product = {
      ...newProductData,
      id: `prod-${Date.now()}`
    };
    setProducts(prev => [created, ...prev]);
  };

  const handleUpdateStock = (productId: string, newStock: number) => {
    setProducts(prev => prev.map(p => p.id === productId ? { ...p, stock: newStock } : p));
  };

  const handleAddReview = (newReview: Omit<Review, 'id' | 'date' | 'helpfulCount'>) => {
    const created: Review = {
      ...newReview,
      id: `rev-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      helpfulCount: 0
    };
    setReviews(prev => [created, ...prev]);
  };

  const handleOrderPlaced = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartCount}
        cartTotal={cartTotal}
        favoritesCount={favorites.length}
        compareCount={comparedProducts.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenCompare={() => setIsCompareOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onSelectCategory={(catId) => {
          setSelectedCategoryId(catId);
          if (catId) setActiveTab('catalog');
        }}
        isCatalogOpen={isCatalogMegaOpen}
        setIsCatalogOpen={setIsCatalogMegaOpen}
        selectedCity={selectedCity}
        setSelectedCity={setSelectedCity}
        onProductClick={(p) => setSelectedProductForDetail(p)}
      />

      {/* Catalog Mega Menu Flyout */}
      <CatalogMegaMenu
        categories={categories}
        isOpen={isCatalogMegaOpen}
        onClose={() => setIsCatalogMegaOpen(false)}
        onSelectCategory={(catId) => {
          setSelectedCategoryId(catId);
          setActiveTab('catalog');
        }}
      />

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4">
        {activeTab === 'storefront' && (
          <div>
            {/* Hero Carousel */}
            <HeroCarousel onOpenPromos={() => { setSelectedCategoryId(null); setActiveTab('catalog'); }} />

            {/* Trust Badges */}
            <TrustBadges />

            {/* Popular Categories Grid */}
            <PopularCategories
              categories={categories}
              onSelectCategory={(catId) => {
                setSelectedCategoryId(catId);
                setActiveTab('catalog');
              }}
            />

            {/* Flash Sales & Special Offers */}
            <FlashSaleSection
              products={products}
              onProductClick={(p) => setSelectedProductForDetail(p)}
              onAddToCart={(p, e) => { e.stopPropagation(); handleAddToCart(p); }}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
              comparedProducts={comparedProducts}
              onToggleCompare={handleToggleCompare}
              onViewAllPromos={() => { setSelectedCategoryId(null); setActiveTab('catalog'); }}
            />

            {/* Main Featured Showcase */}
            <section className="my-8">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">Популярное в категории "Электроника"</h2>
                <button
                  onClick={() => { setSelectedCategoryId('cat-electronics'); setActiveTab('catalog'); }}
                  className="text-xs font-semibold text-blue-600 hover:text-blue-700 cursor-pointer"
                >
                  Смотреть все →
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {products.slice(0, 6).map((p) => (
                  <ProductCard
                    key={p.id}
                    product={p}
                    onProductClick={(prod) => setSelectedProductForDetail(prod)}
                    onAddToCart={(prod, e) => { e.stopPropagation(); handleAddToCart(prod); }}
                    isFavorite={favorites.includes(p.id)}
                    onToggleFavorite={handleToggleFavorite}
                    isCompared={comparedProducts.includes(p.id)}
                    onToggleCompare={handleToggleCompare}
                  />
                ))}
              </div>
            </section>
          </div>
        )}

        {/* Full Filtered Catalog Page */}
        {activeTab === 'catalog' && (
          <CatalogPage
            products={products}
            categories={categories}
            selectedCategoryId={selectedCategoryId}
            onSelectCategory={setSelectedCategoryId}
            searchQuery={searchQuery}
            onProductClick={(p) => setSelectedProductForDetail(p)}
            onAddToCart={(p, e) => { e.stopPropagation(); handleAddToCart(p); }}
            favorites={favorites}
            onToggleFavorite={handleToggleFavorite}
            comparedProducts={comparedProducts}
            onToggleCompare={handleToggleCompare}
          />
        )}

        {/* Customer Account & Order Tracking */}
        {activeTab === 'orders' && (
          <CustomerOrdersView
            orders={orders}
            onRequestReturn={(ordId) => {
              setOrders(prev => prev.map(o => o.id === ordId ? { ...o, status: 'returned' } : o));
            }}
          />
        )}

        {/* Merchant Seller Portal */}
        {activeTab === 'merchant' && (
          <MerchantPortal
            products={products}
            merchants={merchants}
            orders={orders}
            onAddProduct={handleAddMerchantProduct}
            onUpdateProductStock={handleUpdateStock}
          />
        )}

        {/* Administrator Dashboard */}
        {activeTab === 'admin' && (
          <AdminDashboard
            metrics={MOCK_SYSTEM_METRICS}
            merchants={merchants}
          />
        )}

        {/* Architecture & API Docs */}
        {activeTab === 'architecture' && <ArchitectureDocs />}
      </main>

      {/* Global Modals */}
      <ProductDetailModal
        product={selectedProductForDetail}
        reviews={selectedProductForDetail ? reviews.filter(r => r.productId === selectedProductForDetail.id) : []}
        onClose={() => setSelectedProductForDetail(null)}
        onAddToCart={(p, variantId) => {
          handleAddToCart(p, variantId);
          setSelectedProductForDetail(null);
        }}
        isFavorite={selectedProductForDetail ? favorites.includes(selectedProductForDetail.id) : false}
        onToggleFavorite={handleToggleFavorite}
        isCompared={selectedProductForDetail ? comparedProducts.includes(selectedProductForDetail.id) : false}
        onToggleCompare={handleToggleCompare}
        onAddReview={handleAddReview}
      />

      {/* Comparison Modal */}
      {isCompareOpen && (
        <CompareModal
          products={products.filter(p => comparedProducts.includes(p.id))}
          onClose={() => setIsCompareOpen(false)}
          onRemoveProduct={(id) => setComparedProducts(prev => prev.filter(pId => pId !== id))}
          onAddToCart={(p) => handleAddToCart(p)}
        />
      )}

      {/* Shopping Cart Drawer & Checkout */}
      <CartCheckoutModal
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={() => setCartItems([])}
        onOrderPlaced={handleOrderPlaced}
        selectedCity={selectedCity}
      />

      {/* Global Footer */}
      <footer className="bg-slate-900 text-slate-400 text-xs py-12 px-4 mt-16 border-t border-slate-800">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 space-y-3">
            <div className="flex items-center space-x-2 text-white font-black text-lg">
              <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                SM
              </div>
              <span>СеверМаркет</span>
            </div>
            <p className="text-slate-400 leading-relaxed max-w-sm">
              Национальная e-commerce экосистема и маркетплейс. Доставка миллионов товаров во все регионы России.
            </p>
            <p className="text-[11px] text-slate-500">
              © 2026 ООО «СЕВЕР МАРКЕТ». Все права защищены. ОГРН 1227700184920.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider mb-3">Покупателям</h4>
            <ul className="space-y-2">
              <li><a href="#delivery" onClick={(e) => { e.preventDefault(); setActiveTab('storefront'); }} className="hover:text-white transition">Как оформить заказ</a></li>
              <li><a href="#payment" onClick={(e) => { e.preventDefault(); setActiveTab('storefront'); }} className="hover:text-white transition">Способы оплаты</a></li>
              <li><a href="#orders" onClick={(e) => { e.preventDefault(); setActiveTab('orders'); }} className="hover:text-white transition">Отслеживание заказа</a></li>
              <li><a href="#returns" onClick={(e) => { e.preventDefault(); setActiveTab('orders'); }} className="hover:text-white transition">Возврат и гарантия</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider mb-3">Продавцам</h4>
            <ul className="space-y-2">
              <li><a href="#merchant" onClick={(e) => { e.preventDefault(); setActiveTab('merchant'); }} className="hover:text-white transition">Личный кабинет продавца</a></li>
              <li><a href="#merchant" onClick={(e) => { e.preventDefault(); setActiveTab('merchant'); }} className="hover:text-white transition">Комиссии и тарифы</a></li>
              <li><a href="#merchant" onClick={(e) => { e.preventDefault(); setActiveTab('merchant'); }} className="hover:text-white transition">Логистика FBO / FBS</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase tracking-wider mb-3">Система</h4>
            <ul className="space-y-2">
              <li><a href="#admin" onClick={(e) => { e.preventDefault(); setActiveTab('admin'); }} className="hover:text-white transition">Панель управления</a></li>
              <li><a href="#architecture" onClick={(e) => { e.preventDefault(); setActiveTab('architecture'); }} className="hover:text-white transition">Rust / gRPC Architecture</a></li>
              <li><a href="#architecture" onClick={(e) => { e.preventDefault(); setActiveTab('architecture'); }} className="hover:text-white transition">OpenAPI Spec</a></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  );
}
