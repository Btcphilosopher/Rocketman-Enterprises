import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_MERCHANTS, INITIAL_ORDERS, INITIAL_REVIEWS, MOCK_SYSTEM_METRICS, MOCK_ARCHITECTURE_DOCS } from './src/data/mockData.js';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'SeverMarket Core Engine (Rust / Axum Proxy)',
      timestamp: new Date().toISOString(),
      uptimeSeconds: MOCK_SYSTEM_METRICS.uptimeSeconds
    });
  });

  // Get Products with filtering & search
  app.get('/api/products', (req, res) => {
    let products = [...INITIAL_PRODUCTS];
    const { q, category, minPrice, maxPrice, brand, flashSale, sort } = req.query;

    if (q && typeof q === 'string') {
      const queryLower = q.toLowerCase();
      products = products.filter(p =>
        p.title.toLowerCase().includes(queryLower) ||
        p.brand.toLowerCase().includes(queryLower) ||
        p.categoryName.toLowerCase().includes(queryLower) ||
        p.description.toLowerCase().includes(queryLower)
      );
    }

    if (category && typeof category === 'string') {
      products = products.filter(p => p.categoryId === category || p.categoryName === category);
    }

    if (minPrice) {
      products = products.filter(p => p.price >= Number(minPrice));
    }

    if (maxPrice) {
      products = products.filter(p => p.price <= Number(maxPrice));
    }

    if (brand && typeof brand === 'string') {
      products = products.filter(p => p.brand.toLowerCase() === brand.toLowerCase());
    }

    if (flashSale === 'true') {
      products = products.filter(p => p.isFlashSale);
    }

    if (sort === 'price_asc') {
      products.sort((a, b) => a.price - b.price);
    } else if (sort === 'price_desc') {
      products.sort((a, b) => b.price - a.price);
    } else if (sort === 'rating') {
      products.sort((a, b) => b.rating - a.rating);
    } else if (sort === 'discount') {
      products.sort((a, b) => (b.discountPercent || 0) - (a.discountPercent || 0));
    }

    res.json({
      total: products.length,
      products
    });
  });

  // Get Single Product by ID
  app.get('/api/products/:id', (req, res) => {
    const product = INITIAL_PRODUCTS.find(p => p.id === req.params.id || p.slug === req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    const reviews = INITIAL_REVIEWS.filter(r => r.productId === product.id);
    const related = INITIAL_PRODUCTS.filter(p => p.categoryId === product.categoryId && p.id !== product.id).slice(0, 4);
    res.json({ product, reviews, related });
  });

  // Categories Taxonomy
  app.get('/api/categories', (req, res) => {
    res.json(INITIAL_CATEGORIES);
  });

  // Autocomplete Suggestions
  app.get('/api/search/autocomplete', (req, res) => {
    const q = (req.query.q as string || '').toLowerCase();
    if (!q || q.length < 2) {
      return res.json({ suggestions: [], categories: [], brands: [] });
    }

    const suggestions = INITIAL_PRODUCTS
      .filter(p => p.title.toLowerCase().includes(q))
      .slice(0, 5)
      .map(p => ({ id: p.id, title: p.title, price: p.price, image: p.images[0] }));

    const categories = INITIAL_CATEGORIES
      .filter(c => c.name.toLowerCase().includes(q) || c.subcategories?.some(s => s.toLowerCase().includes(q)))
      .slice(0, 3);

    const brands = Array.from(new Set(INITIAL_PRODUCTS.map(p => p.brand)))
      .filter(b => b.toLowerCase().includes(q))
      .slice(0, 3);

    res.json({ suggestions, categories, brands });
  });

  // Merchants API
  app.get('/api/merchants', (req, res) => {
    res.json(INITIAL_MERCHANTS);
  });

  // Orders API
  app.get('/api/orders', (req, res) => {
    res.json(INITIAL_ORDERS);
  });

  app.post('/api/orders', (req, res) => {
    const { items, deliveryMethod, recipientName, recipientPhone, paymentMethod, address } = req.body;
    const newOrder = {
      id: `ord-${Date.now()}`,
      orderNumber: `RU-${Math.floor(100000 + Math.random() * 900000)}-SM`,
      date: new Date().toISOString().split('T')[0],
      status: 'placed' as const,
      items: items || [],
      totalAmount: items.reduce((acc: number, item: any) => acc + (item.product.price * item.quantity), 0),
      shippingFee: 0,
      discountAmount: 0,
      deliveryMethod: deliveryMethod || 'pickup',
      pickupAddress: deliveryMethod === 'pickup' ? address : undefined,
      courierAddress: deliveryMethod === 'courier' ? address : undefined,
      recipientName: recipientName || 'Клиент SeverMarket',
      recipientPhone: recipientPhone || '+7 (999) 000-00-00',
      paymentMethod: paymentMethod || 'card',
      trackingCode: `SM-TRACK-${Math.floor(100000 + Math.random() * 900000)}`,
      estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    };
    INITIAL_ORDERS.unshift(newOrder);
    res.status(201).json(newOrder);
  });

  // Analytics Metrics API
  app.get('/api/analytics', (req, res) => {
    res.json({
      metrics: MOCK_SYSTEM_METRICS,
      dailySales: [
        { date: '07-28', sales: 142000000, orders: 48200 },
        { date: '07-29', sales: 168000000, orders: 54100 },
        { date: '07-30', sales: 155000000, orders: 51000 },
        { date: '07-31', sales: 189000000, orders: 62400 },
        { date: '08-01', sales: 210000000, orders: 69800 },
        { date: '08-02', sales: 235000000, orders: 74200 },
        { date: '08-03', sales: 242000000, orders: 78900 }
      ]
    });
  });

  // OpenAPI Specification endpoint
  app.get('/api/docs/openapi', (req, res) => {
    res.json({
      openapi: '3.0.3',
      info: {
        title: 'SeverMarket Enterprise API',
        version: '2.4.0',
        description: 'High-performance Rust/Axum marketplace REST specification for SeverMarket (СеверМаркет)'
      },
      paths: {
        '/api/products': {
          get: {
            summary: 'Search & filter marketplace catalogue',
            parameters: [
              { name: 'q', in: 'query', schema: { type: 'string' }, description: 'Full text search query' },
              { name: 'category', in: 'query', schema: { type: 'string' } },
              { name: 'minPrice', in: 'query', schema: { type: 'number' } },
              { name: 'maxPrice', in: 'query', schema: { type: 'number' } }
            ],
            responses: {
              '200': { description: 'Filtered product array with total count' }
            }
          }
        },
        '/api/orders': {
          post: {
            summary: 'Place new checkout order',
            responses: {
              '201': { description: 'Created order payload with tracking code' }
            }
          }
        }
      }
    });
  });

  // Architecture Specs
  app.get('/api/docs/architecture', (req, res) => {
    res.json(MOCK_ARCHITECTURE_DOCS);
  });

  // Vite middleware or production static build serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SeverMarket Enterprise Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
