/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Commodity, Supplier, Rfq, Order, PlatformAnalytics } from '../types';

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-1',
    name: 'Nordic Timber & Lumber Co.',
    logo: 'N',
    rating: 4.9,
    yearsOperating: 42,
    capacityAnnually: '1,200,000 m³',
    certifications: ['FSC-C012345', 'PEFC', 'ISO 14001', 'EUTR Compliant'],
    location: 'Gävle, Sweden',
    warehouses: ['Gothenburg Hub A', 'Hamburg Dock 4', 'Rotterdam Sector F'],
    verified: true,
    transactionCount: 3450,
    complianceStatus: 'Verified',
    description: 'Premier Scandinavian timber producer specializing in sustainably harvested structural softwood, engineered wood products, and premium spruce/pine lumbers.',
  },
  {
    id: 'sup-2',
    name: 'Apex Metallurgy & Steelworks',
    logo: 'A',
    rating: 4.8,
    yearsOperating: 28,
    capacityAnnually: '4,500,000 Metric Tons',
    certifications: ['ASTM A6', 'ISO 9001', 'BSI Kitemark', 'EN 10025'],
    location: 'Duisburg, Germany',
    warehouses: ['Ruhr Valley Depot', 'Antwerp Terminal 12', 'Houston Port Yard'],
    verified: true,
    transactionCount: 5120,
    complianceStatus: 'Verified',
    description: 'Leading European manufacturer of structural steel, heavy plates, carbon steel sheets, and reinforced bars (rebar) for commercial infrastructure.',
  },
  {
    id: 'sup-3',
    name: 'Andes Copper & Brass Syndicate',
    logo: 'C',
    rating: 4.9,
    yearsOperating: 35,
    capacityAnnually: '850,000 Metric Tons',
    certifications: ['LME Grade A Registered', 'ISO 9001', 'CopperMark'],
    location: 'Calama, Chile',
    warehouses: ['Antofagasta Port Terminal', 'Shanghai Bonded Zone', 'Baltimore Marine Wharf'],
    verified: true,
    transactionCount: 2890,
    complianceStatus: 'Verified',
    description: 'State-of-the-art mining and refining conglomerate providing high-purity copper cathodes, brass alloys, and premium non-ferrous raw materials.',
  },
  {
    id: 'sup-4',
    name: 'Carrara Architectural Stone Group',
    logo: 'S',
    rating: 4.7,
    yearsOperating: 60,
    capacityAnnually: '400,000 Slabs',
    certifications: ['SWA Certified', 'CE Mark', 'ISO 9001'],
    location: 'Massa-Carrara, Italy',
    warehouses: ['La Spezia Port Depot', 'New York Architectural Terminal'],
    verified: true,
    transactionCount: 1240,
    complianceStatus: 'Verified',
    description: 'Legacy Italian quarry operator and fabricator exporting elite-grade marble, granite, limestone, and high-density aggregates worldwide.',
  },
  {
    id: 'sup-5',
    name: 'Amazonas Sustainable Agro-Corp',
    logo: 'Z',
    rating: 4.6,
    yearsOperating: 18,
    capacityAnnually: '180,000 Tons',
    certifications: ['Rainforest Alliance', 'USDA Organic', 'Fairtrade International'],
    location: 'Pará, Brazil',
    warehouses: ['Santos Export Hub', 'Rotterdam Multi-Agri Terminal', 'Singapore Tuas Yard'],
    verified: true,
    transactionCount: 1680,
    complianceStatus: 'Verified',
    description: 'Pioneering agricultural cooperative focusing on zero-deforestation coffee, high-specification cocoa beans, organic soy, and natural extracts.',
  },
  {
    id: 'sup-6',
    name: 'Indo-Malayan Rubber & Industrial Materials',
    logo: 'I',
    rating: 4.5,
    yearsOperating: 22,
    capacityAnnually: '350,000 Metric Tons',
    certifications: ['ASTM D1218', 'Halal Certified', 'ISO 9001'],
    location: 'Selangor, Malaysia',
    warehouses: ['Port Klang Terminal B', 'Tokyo Bay Industrial Hub'],
    verified: true,
    transactionCount: 1420,
    complianceStatus: 'Verified',
    description: 'High-volume manufacturer and distributor of natural TSR rubber, industrial grade adhesives, lubricants, and packaging raw materials.',
  }
];

export const INITIAL_COMMODITIES: Commodity[] = [
  // --- FORESTRY & TIMBER ---
  {
    id: 'com-1',
    name: 'Structural Softwood Spruce Timber',
    sku: 'TIM-SPR-SWE-C24',
    category: 'Forestry & Timber',
    subcategory: 'Softwood lumber',
    supplierId: 'sup-1',
    supplierName: 'Nordic Timber & Lumber Co.',
    originCountry: 'Sweden',
    productionRegion: 'Norrland Forest Belt',
    grade: 'C24 Structural Grade',
    specification: 'KD (Kiln Dried) 15% MC, Planed S4S, 45mm x 145mm x 4800mm',
    certification: ['FSC-C012345', 'PEFC', 'EN 14081-1'],
    availableQty: 18500,
    unit: 'm³ (Cubic Meters)',
    moq: 50,
    pricePerUnit: 345.00,
    bulkDiscounts: [
      { qty: 100, discountPercent: 3 },
      { qty: 500, discountPercent: 6 },
      { qty: 1000, discountPercent: 10 }
    ],
    leadTimeDays: 21,
    packaging: 'Steel-banded industrial bundles, heavy-duty UV poly-wrap',
    shippingTerms: ['FOB', 'CIF', 'EXW', 'DDP'],
    description: 'High-latitude, slow-grown Northern Spruce timber with dense ring structure, offering outstanding structural stability and high load-bearing capacity. Ideal for timber-frame housing construction and heavy carpentry.',
    warehouseLocation: 'Gothenburg Hub A',
    images: ['https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'Technical_Declaration_C24.pdf', type: 'PDF Specification', size: '1.2 MB' },
      { name: 'FSC_Certificate_Nordic.pdf', type: 'Certification', size: '840 KB' },
      { name: 'EPD_Spruce_Sustain.pdf', type: 'Environmental Product Decl.', size: '2.4 MB' }
    ]
  },
  {
    id: 'com-2',
    name: 'Sustainably Harvested American Walnut Slabs',
    sku: 'TIM-WAL-USA-FAS',
    category: 'Forestry & Timber',
    subcategory: 'Walnut',
    supplierId: 'sup-1',
    supplierName: 'Nordic Timber & Lumber Co.',
    originCountry: 'United States',
    productionRegion: 'Appalachian Highlands',
    grade: 'NHLA FAS (First and Seconds)',
    specification: 'Air-dried & Kiln-dried, 8/4 Thickness (50.8mm), Random Widths 150mm+, Lengths 2.4m - 3.6m',
    certification: ['FSC Certified', 'NHLA Certified'],
    availableQty: 1200,
    unit: 'BF (Board Feet)',
    moq: 200,
    pricePerUnit: 8.50,
    bulkDiscounts: [
      { qty: 500, discountPercent: 2 },
      { qty: 1000, discountPercent: 5 }
    ],
    leadTimeDays: 35,
    packaging: 'Palette stacked with protective side-runners and heavy wrapping',
    shippingTerms: ['FOB', 'EXW', 'CIF'],
    description: 'Premium hardwood timber showcasing magnificent rich chocolate tones and elegant growth ring figure. Prized for luxury interior architectural fitouts, high-end furniture manufacture, and bespoke cabinetry.',
    warehouseLocation: 'Hamburg Dock 4',
    images: ['https://images.unsplash.com/photo-1541123437800-1bb1317badc2?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'Hardwood_FAS_GradeSheet.pdf', type: 'Grade Certificate', size: '1.1 MB' },
      { name: 'FSC_Chain_of_Custody.pdf', type: 'Certification', size: '920 KB' }
    ]
  },

  // --- METALS (FERROUS) ---
  {
    id: 'com-3',
    name: 'Heavy Structural Steel H-Beams HEB 300',
    sku: 'MET-STE-GER-HEB300',
    category: 'Metals',
    subcategory: 'Steel beams',
    supplierId: 'sup-2',
    supplierName: 'Apex Metallurgy & Steelworks',
    originCountry: 'Germany',
    productionRegion: 'North Rhine-Westphalia',
    grade: 'S355J2+M Structural Steel',
    specification: 'EN 10025-2, HEB 300 European Standard Wide Flange H-Beam, Length 12m',
    certification: ['CE 0035', 'Mill Test Certificate (EN 10204 3.1)', 'ISO 9001'],
    availableQty: 4500,
    unit: 'Metric Tons',
    moq: 10,
    pricePerUnit: 890.00,
    bulkDiscounts: [
      { qty: 50, discountPercent: 4 },
      { qty: 100, discountPercent: 8 }
    ],
    leadTimeDays: 14,
    packaging: 'Loose bundled, secure containerized steel rigging',
    shippingTerms: ['FOB', 'CIF', 'EXW'],
    description: 'Premium mill-produced structural steel beams with excellent yield strengths. Perfect for high-rise steel structures, heavy industrial framing, civil engineering bridges, and modular warehouse architecture.',
    warehouseLocation: 'Ruhr Valley Depot',
    images: ['https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'MTC_HEB300_S355J2.pdf', type: 'Mill Test Report (3.1)', size: '3.1 MB' },
      { name: 'Structural_Load_Calculations.pdf', type: 'Engineering Spec Sheet', size: '4.7 MB' }
    ]
  },

  // --- METALS (NON-FERROUS) ---
  {
    id: 'com-4',
    name: 'High-Purity Copper Cathodes Grade A',
    sku: 'MET-COP-CHI-CU99',
    category: 'Metals',
    subcategory: 'Copper',
    supplierId: 'sup-3',
    supplierName: 'Andes Copper & Brass Syndicate',
    originCountry: 'Chile',
    productionRegion: 'Atacama Desert Mining Block',
    grade: 'LME Grade A (99.9935% Purity)',
    specification: 'BS EN 1978:1998, Sheet Size 960mm x 930mm x 10mm, approx 100kg per sheet',
    certification: ['LME Approved Brand', 'ISO 9001', 'ISO 14001'],
    availableQty: 2400,
    unit: 'Metric Tons',
    moq: 25,
    pricePerUnit: 8450.00,
    bulkDiscounts: [
      { qty: 100, discountPercent: 1.5 },
      { qty: 500, discountPercent: 3.5 }
    ],
    leadTimeDays: 30,
    packaging: 'Bundled with aluminum strapping (approx 2.5 MT per bundle), steel reinforced skid',
    shippingTerms: ['FOB', 'CIF'],
    description: 'Premium electrowon copper cathode sheets with industry-leading electrical conductivity. Essential raw input material for wiring, high-voltage equipment, industrial copper piping, and next-generation battery components.',
    warehouseLocation: 'Antofagasta Port Terminal',
    images: ['https://images.unsplash.com/photo-1535498730771-e735b998cd64?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'Chemical_Assay_Report_Copper.pdf', type: 'Laboratory Assay', size: '1.4 MB' },
      { name: 'LME_Brand_Registration_Andes.pdf', type: 'Exchange Document', size: '750 KB' }
    ]
  },

  // --- CONSTRUCTION MATERIALS ---
  {
    id: 'com-5',
    name: 'Premium Carrara White Marble Slabs',
    sku: 'CON-MAR-ITA-CD01',
    category: 'Construction Materials',
    subcategory: 'Marble',
    supplierId: 'sup-4',
    supplierName: 'Carrara Architectural Stone Group',
    originCountry: 'Italy',
    productionRegion: 'Apuan Alps Quarry Section VII',
    grade: 'Extra Premium Statuario / CD Grade',
    specification: 'Polished surface, Bookmatched pairs, Thickness 20mm (+/- 1mm), Average Slab Size 2.8m x 1.6m',
    certification: ['CE Standard EN 1469', 'Quarry Origin Certificate', 'ASTM C503'],
    availableQty: 480,
    unit: 'm² (Square Meters)',
    moq: 100,
    pricePerUnit: 185.00,
    bulkDiscounts: [
      { qty: 250, discountPercent: 5 },
      { qty: 500, discountPercent: 12 }
    ],
    leadTimeDays: 45,
    packaging: 'Fumigated wooden A-frames, foam padded, moisture-proof wrapping',
    shippingTerms: ['FOB', 'CIF', 'EXW', 'DDP'],
    description: 'Breathtaking white Italian marble featuring elegant, subtle smoky-gray veining distributed harmoniously. This material represents the pinnacle of luxury architectural flooring, wall cladding, and high-end vanity installations.',
    warehouseLocation: 'La Spezia Port Depot',
    images: ['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'Stone_Petrographic_Analysis.pdf', type: 'Laboratory Report', size: '2.1 MB' },
      { name: 'ASTM_Hardness_WearTest.pdf', type: 'Technical Spec Sheet', size: '1.8 MB' }
    ]
  },

  // --- AGRICULTURAL COMMODITIES ---
  {
    id: 'com-6',
    name: 'Specialty Brazilian Arabica Coffee Beans',
    sku: 'AGR-COF-BRA-NY2',
    category: 'Agricultural Commodities',
    subcategory: 'Coffee',
    supplierId: 'sup-5',
    supplierName: 'Amazonas Sustainable Agro-Corp',
    originCountry: 'Brazil',
    productionRegion: 'Sul de Minas Highlands',
    grade: 'NY 2/3, Screen 17/18, Fine Cup',
    specification: '100% Arabica Green Coffee, Strictly Soft, Moisture Content 11.5% max, Defect count < 4',
    certification: ['Rainforest Alliance', 'UTZ Certified', 'SCA Score: 84.5'],
    availableQty: 180,
    unit: 'MT (Metric Tons)',
    moq: 15,
    pricePerUnit: 4850.00,
    bulkDiscounts: [
      { qty: 50, discountPercent: 3 },
      { qty: 100, discountPercent: 7 }
    ],
    leadTimeDays: 28,
    packaging: '60kg GrainPro hermetic barrier bags inside high-tensile jute sacks',
    shippingTerms: ['FOB', 'CIF'],
    description: 'Exquisite green coffee crop displaying exceptional sweetness, mild acidity, and a smooth buttery-caramel flavor profile. Processed via the natural pulped method, ensuring uniform roasting properties.',
    warehouseLocation: 'Santos Export Hub',
    images: ['https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'SCA_Cupping_Scorecard.pdf', type: 'Assay Report', size: '1.2 MB' },
      { name: 'Phytosanitary_Cert_Coffee.pdf', type: 'Health Certificate', size: '940 KB' },
      { name: 'Rainforest_Alliance_Audit.pdf', type: 'Sustainability Doc', size: '1.5 MB' }
    ]
  },

  // --- ENERGY & INDUSTRIAL MATERIALS ---
  {
    id: 'com-7',
    name: 'Premium Wood Pellets Industrial Grade ENplus-A1',
    sku: 'ENE-PEL-SWE-A1',
    category: 'Energy & Industrial Materials',
    subcategory: 'Biomass',
    supplierId: 'sup-1',
    supplierName: 'Nordic Timber & Lumber Co.',
    originCountry: 'Sweden',
    productionRegion: 'Värmland Bioenergy Terminal',
    grade: 'ENplus A1 Quality Standard',
    specification: 'Diameter: 6mm (+/- 1mm), Net Calorific Value >= 4.6 kWh/kg, Ash Content <= 0.7%, Moisture <= 10%',
    certification: ['ENplus A1', 'PEFC Biomass', 'FSC Mix'],
    availableQty: 12000,
    unit: 'Metric Tons',
    moq: 100,
    pricePerUnit: 295.00,
    bulkDiscounts: [
      { qty: 250, discountPercent: 2 },
      { qty: 1000, discountPercent: 5 },
      { qty: 5000, discountPercent: 8.5 }
    ],
    leadTimeDays: 14,
    packaging: '15kg bags (65 bags/pallet) or 1000kg industrial Big Bags (FIBC)',
    shippingTerms: ['FOB', 'CIF', 'DDP'],
    description: 'Premium wood pellets compressed from 100% virgin softwood saw dust, entirely free of synthetic chemical additives or binders. Engineered for highly efficient combustion in industrial thermal power systems and commercial heating grids.',
    warehouseLocation: 'Rotterdam Sector F',
    images: ['https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'ENplus_A1_Compliance_Test.pdf', type: 'Quality Report', size: '1.7 MB' },
      { name: 'Calorific_Calorimetry_Report.pdf', type: 'Laboratory Report', size: '1.3 MB' }
    ]
  },

  // --- MANUFACTURING INPUTS ---
  {
    id: 'com-8',
    name: 'Technically Specified Natural Rubber TSR-20',
    sku: 'MAN-RUB-MAL-TSR20',
    category: 'Manufacturing Inputs',
    subcategory: 'Rubber',
    supplierId: 'sup-6',
    supplierName: 'Indo-Malayan Rubber & Industrial Materials',
    originCountry: 'Malaysia',
    productionRegion: 'Kedah Estate Network',
    grade: 'TSR-20 Standard Malaysian Rubber (SMR 20)',
    specification: 'Dirt Content <= 0.16 wt%, Ash Content <= 1.00 wt%, Volatile Matter <= 0.80 wt%, Nitrogen <= 0.60 wt%',
    certification: ['MRB Approved Laboratory Cert', 'ISO 9001'],
    availableQty: 850,
    unit: 'Metric Tons',
    moq: 20,
    pricePerUnit: 1680.00,
    bulkDiscounts: [
      { qty: 100, discountPercent: 4 },
      { qty: 250, discountPercent: 7 }
    ],
    leadTimeDays: 25,
    packaging: '35kg blocks, wrapped in polythene shrink wrap, packed in metal crate crates (1.26 MT/crate)',
    shippingTerms: ['FOB', 'CIF'],
    description: 'Premier grade technically specified natural Hevea rubber with robust viscoelastic properties. Excellent mechanical strength and tearing resistance, widely demanded for heavy-duty commercial truck tire treads, conveyor belt systems, and industrial seals.',
    warehouseLocation: 'Port Klang Terminal B',
    images: ['https://images.unsplash.com/photo-1535813547-99c456a41d4a?q=80&w=600&auto=format&fit=crop'],
    documents: [
      { name: 'SMR20_Viscosity_Assay.pdf', type: 'Technical Spec Sheet', size: '2.2 MB' },
      { name: 'Rubber_Board_Quality_Stamp.pdf', type: 'State Certificate', size: '890 KB' }
    ]
  }
];

export const INITIAL_RFQS: Rfq[] = [
  {
    id: 'rfq-201',
    buyerCompany: 'Global Infrastructure Partners Ltd',
    commodityName: 'Grade 60 Structural Steel Rebar',
    category: 'Metals',
    quantity: 150,
    unit: 'Metric Tons',
    deliveryLocation: 'Houston Port Terminal, USA',
    specifications: 'ASTM A615 Grade 60, Size #5 (16mm diameter), length 12m, bundle strapped. Must include Mill Test Certificates.',
    budgetRange: '$120,000 - $140,000',
    deadline: '2026-08-10',
    status: 'open',
    bids: [
      {
        id: 'bid-301',
        rfqId: 'rfq-201',
        supplierId: 'sup-2',
        supplierName: 'Apex Metallurgy & Steelworks',
        pricePerUnit: 875,
        deliveryTerms: 'CIF',
        leadTimeDays: 18,
        notes: 'We can supply premium Duisburg-milled ASTM rebar immediately. Our price includes CIF ocean freight to Houston Port. Premium seaworthy bundle wrapping included.',
        status: 'pending',
        documents: [{ name: 'Apex_ASTM_Rebar_Spec.pdf', size: '1.4 MB' }]
      }
    ],
    createdAt: '2026-07-12'
  },
  {
    id: 'rfq-202',
    buyerCompany: 'Nordic Eco-Housing AB',
    commodityName: 'Premium Softwood Lumber Pine',
    category: 'Forestry & Timber',
    quantity: 200,
    unit: 'm³ (Cubic Meters)',
    deliveryLocation: 'Oslo Construction Yard, Norway',
    specifications: 'Pine Lumber C24, Kiln-Dried 15% MC, S4S, 45x195mm, Length 4.5m. Must be FSC certified.',
    budgetRange: '$65,000 - $75,000',
    deadline: '2026-08-01',
    status: 'negotiating',
    bids: [
      {
        id: 'bid-302',
        rfqId: 'rfq-202',
        supplierId: 'sup-1',
        supplierName: 'Nordic Timber & Lumber Co.',
        pricePerUnit: 330,
        deliveryTerms: 'DDP',
        leadTimeDays: 10,
        notes: 'DDP Oslo construction yard is our specialty. FSC fully certified pine wood, dispatched from Gothenburg Hub. Delivery by zero-emission biofuel heavy freight.',
        status: 'pending',
        documents: [{ name: 'Pine_C24_FSC_Verification.pdf', size: '1.1 MB' }]
      }
    ],
    createdAt: '2026-07-14'
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-1001',
    buyerCompany: 'Continental Tire Group',
    supplierId: 'sup-6',
    supplierName: 'Indo-Malayan Rubber & Industrial Materials',
    commodityId: 'com-8',
    commodityName: 'Technically Specified Natural Rubber TSR-20',
    quantity: 50,
    unit: 'Metric Tons',
    totalPrice: 84000,
    paymentMethod: 'Bank Transfer',
    shippingTerms: 'CIF',
    status: 'shipped',
    trackingNumber: 'MSK-990142801',
    eta: '2026-07-28',
    warehouse: 'Port Klang Terminal B',
    paymentStatus: 'cleared',
    createdAt: '2026-07-01'
  },
  {
    id: 'ord-1002',
    buyerCompany: 'Metropolitan Luxury Devs',
    supplierId: 'sup-4',
    supplierName: 'Carrara Architectural Stone Group',
    commodityId: 'com-5',
    commodityName: 'Premium Carrara White Marble Slabs',
    quantity: 120,
    unit: 'm² (Square Meters)',
    totalPrice: 22200,
    paymentMethod: 'Escrow',
    shippingTerms: 'DDP',
    status: 'processing',
    warehouse: 'La Spezia Port Depot',
    paymentStatus: 'escrowed',
    createdAt: '2026-07-10'
  }
];

export const INITIAL_ANALYTICS: PlatformAnalytics = {
  gmv: 34509000,
  orderCount: 4580,
  activeBuyers: 1250,
  activeSuppliers: 140,
  categoryDistribution: [
    { category: 'Forestry & Timber', value: 28 },
    { category: 'Metals', value: 34 },
    { category: 'Construction Materials', value: 18 },
    { category: 'Agricultural Commodities', value: 12 },
    { category: 'Energy & Industrial', value: 8 }
  ],
  marketTrends: [
    { date: 'Jan 26', indexValue: 100.0, change: 0.0 },
    { date: 'Feb 26', indexValue: 102.4, change: 2.4 },
    { date: 'Mar 26', indexValue: 105.1, change: 2.7 },
    { date: 'Apr 26', indexValue: 104.2, change: -0.9 },
    { date: 'May 26', indexValue: 108.6, change: 4.4 },
    { date: 'Jun 26', indexValue: 111.3, change: 2.7 },
    { date: 'Jul 26', indexValue: 113.8, change: 2.5 }
  ]
};
