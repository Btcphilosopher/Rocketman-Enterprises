/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Commodity {
  id: string;
  name: string;
  sku: string;
  category: string;
  subcategory: string;
  supplierId: string;
  supplierName: string;
  originCountry: string;
  productionRegion: string;
  grade: string;
  specification: string;
  certification: string[];
  availableQty: number;
  unit: string;
  moq: number;
  pricePerUnit: number;
  bulkDiscounts: { qty: number; discountPercent: number }[];
  leadTimeDays: number;
  packaging: string;
  shippingTerms: ('FOB' | 'CIF' | 'EXW' | 'DDP')[];
  description: string;
  warehouseLocation: string;
  images: string[];
  documents: { name: string; type: string; size: string }[];
}

export interface Supplier {
  id: string;
  name: string;
  logo: string;
  rating: number;
  yearsOperating: number;
  capacityAnnually: string;
  certifications: string[];
  location: string;
  warehouses: string[];
  verified: boolean;
  transactionCount: number;
  complianceStatus: 'Verified' | 'Audit Pending' | 'Suspended';
  description: string;
}

export interface Bid {
  id: string;
  rfqId: string;
  supplierId: string;
  supplierName: string;
  pricePerUnit: number;
  deliveryTerms: 'FOB' | 'CIF' | 'EXW' | 'DDP';
  leadTimeDays: number;
  notes: string;
  status: 'pending' | 'accepted' | 'rejected';
  documents: { name: string; size: string }[];
}

export interface Rfq {
  id: string;
  buyerCompany: string;
  commodityName: string;
  category: string;
  quantity: number;
  unit: string;
  deliveryLocation: string;
  specifications: string;
  budgetRange: string;
  deadline: string;
  status: 'open' | 'negotiating' | 'accepted' | 'closed';
  bids: Bid[];
  createdAt: string;
}

export interface Order {
  id: string;
  buyerCompany: string;
  supplierId: string;
  supplierName: string;
  commodityId: string;
  commodityName: string;
  quantity: number;
  unit: string;
  totalPrice: number;
  paymentMethod: 'Bank Transfer' | 'Escrow' | 'Credit Account' | 'Purchase Order' | 'Bitcoin (BTC)' | 'USDT';
  shippingTerms: 'FOB' | 'CIF' | 'EXW' | 'DDP';
  status: 'pending_approval' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  trackingNumber?: string;
  eta?: string;
  warehouse: string;
  paymentStatus: 'pending' | 'escrowed' | 'cleared' | 'failed';
  createdAt: string;
}

export interface PlatformAnalytics {
  gmv: number;
  orderCount: number;
  activeBuyers: number;
  activeSuppliers: number;
  categoryDistribution: { category: string; value: number }[];
  marketTrends: { date: string; indexValue: number; change: number }[];
}
