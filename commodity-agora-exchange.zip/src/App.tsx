/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import Marketplace from './components/Marketplace';
import RfqMarketplace from './components/RfqMarketplace';
import BuyerDashboard from './components/BuyerDashboard';
import SupplierDashboard from './components/SupplierDashboard';
import AdminPortal from './components/AdminPortal';
import ApiConsole from './components/ApiConsole';
import GeneralInfo from './components/GeneralInfo';

import { Commodity, Supplier, Rfq, Order, PlatformAnalytics, Bid } from './types';
import { 
  INITIAL_COMMODITIES, 
  INITIAL_SUPPLIERS, 
  INITIAL_RFQS, 
  INITIAL_ORDERS, 
  INITIAL_ANALYTICS 
} from './data/mockData';

export default function App() {
  
  // Persistent State Init
  const [activeView, setActiveView] = useState<string>('marketplace');
  const [activeRole, setActiveRole] = useState<'buyer' | 'supplier' | 'admin'>('buyer');

  const [commodities, setCommodities] = useState<Commodity[]>(() => {
    const saved = localStorage.getItem('agora_commodities');
    return saved ? JSON.parse(saved) : INITIAL_COMMODITIES;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem('agora_suppliers');
    return saved ? JSON.parse(saved) : INITIAL_SUPPLIERS;
  });

  const [rfqs, setRfqs] = useState<Rfq[]>(() => {
    const saved = localStorage.getItem('agora_rfqs');
    return saved ? JSON.parse(saved) : INITIAL_RFQS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('agora_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [analytics, setAnalytics] = useState<PlatformAnalytics>(() => {
    const saved = localStorage.getItem('agora_analytics');
    return saved ? JSON.parse(saved) : INITIAL_ANALYTICS;
  });

  // Pre-fill state when transitioning catalog item -> RFQ Form
  const [rfqPreFill, setRfqPreFill] = useState<{ name: string; category: string } | null>(null);

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('agora_commodities', JSON.stringify(commodities));
  }, [commodities]);

  useEffect(() => {
    localStorage.setItem('agora_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);

  useEffect(() => {
    localStorage.setItem('agora_rfqs', JSON.stringify(rfqs));
  }, [rfqs]);

  useEffect(() => {
    localStorage.setItem('agora_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('agora_analytics', JSON.stringify(analytics));
  }, [analytics]);

  // Core Ledger Mutation Handlers
  
  // 1. Place / Add standard Order
  const handleAddOrder = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    
    // Deduct stock if there is a matching commodity catalog listing
    if (newOrder.commodityId && newOrder.commodityId !== 'com-custom') {
      setCommodities(prevComs => 
        prevComs.map(c => 
          c.id === newOrder.commodityId 
            ? { ...c, availableQty: Math.max(0, c.availableQty - newOrder.quantity) }
            : c
        )
      );
    }
  };

  // 2. Co-Sign / Approve order (Net 30/PO approval)
  const handleApproveOrder = (orderId: string) => {
    setOrders(prev => 
      prev.map(o => o.id === orderId ? { ...o, status: 'processing' } : o)
    );
  };

  // 3. Void / Cancel order
  const handleCancelOrder = (orderId: string) => {
    setOrders(prev => 
      prev.map(o => o.id === orderId ? { ...o, status: 'cancelled' } : o)
    );
  };

  // 4. Update Order status (Logistics Tracking/Mark Delivered)
  const handleUpdateOrderStatus = (orderId: string, status: Order['status'], trackingNumber?: string, eta?: string) => {
    setOrders(prev => 
      prev.map(o => {
        if (o.id === orderId) {
          const update: Partial<Order> = { status };
          if (trackingNumber) update.trackingNumber = trackingNumber;
          if (eta) update.eta = eta;
          if (status === 'delivered') update.paymentStatus = 'cleared';
          return { ...o, ...update };
        }
        return o;
      })
    );
  };

  // 5. Add / Register Commodity (Supplier upload)
  const handleAddCommodity = (newCom: Commodity) => {
    setCommodities(prev => [newCom, ...prev]);
  };

  // 6. Adjust Supplier Stock levels
  const handleUpdateStock = (commodityId: string, delta: number) => {
    setCommodities(prev => 
      prev.map(c => c.id === commodityId ? { ...c, availableQty: Math.max(0, c.availableQty + delta) } : c)
    );
  };

  // 7. Submit / Create RFQ tender
  const handleAddRfq = (newRfq: Rfq) => {
    setRfqs(prev => [newRfq, ...prev]);
  };

  // 8. Submit quote bid against RFQ
  const handleAddBid = (rfqId: string, newBid: Bid) => {
    setRfqs(prev => 
      prev.map(r => r.id === rfqId ? { ...r, bids: [newBid, ...r.bids] } : r)
    );
  };

  // 9. Transition RFQ status
  const handleUpdateRfqStatus = (rfqId: string, status: Rfq['status']) => {
    setRfqs(prev => 
      prev.map(r => r.id === rfqId ? { ...r, status } : r)
    );
  };

  // 10. Confirm Bid Status (Accept/Reject)
  const handleUpdateBidStatus = (rfqId: string, bidId: string, status: Bid['status']) => {
    setRfqs(prev => 
      prev.map(r => {
        if (r.id === rfqId) {
          return {
            ...r,
            bids: r.bids.map(b => b.id === bidId ? { ...b, status } : b)
          };
        }
        return r;
      })
    );
  };

  // 11. Admin verify / Certify supplier compliance
  const handleVerifySupplier = (supplierId: string) => {
    setSuppliers(prev => 
      prev.map(s => s.id === supplierId ? { ...s, verified: true, complianceStatus: 'Verified' } : s)
    );
  };

  // Render view router based on state selection
  const renderActiveView = () => {
    switch (activeView) {
      case 'marketplace':
        return (
          <Marketplace
            commodities={commodities}
            suppliers={suppliers}
            orders={orders}
            onAddOrder={handleAddOrder}
            setActiveView={setActiveView}
            setRfqPreFill={setRfqPreFill}
          />
        );
      case 'rfq':
        return (
          <RfqMarketplace
            rfqs={rfqs}
            onAddRfq={handleAddRfq}
            onAddBid={handleAddBid}
            onUpdateRfqStatus={handleUpdateRfqStatus}
            onUpdateBidStatus={handleUpdateBidStatus}
            onAddOrder={handleAddOrder}
            activeRole={activeRole}
            suppliers={suppliers}
            rfqPreFill={rfqPreFill}
            setRfqPreFill={setRfqPreFill}
          />
        );
      case 'buyer-dashboard':
        return (
          <BuyerDashboard
            orders={orders}
            suppliers={suppliers}
            rfqs={rfqs}
            onApproveOrder={handleApproveOrder}
            onCancelOrder={handleCancelOrder}
          />
        );
      case 'supplier-dashboard':
        return (
          <SupplierDashboard
            commodities={commodities}
            orders={orders}
            onAddCommodity={handleAddCommodity}
            onUpdateStock={handleUpdateStock}
            onUpdateOrderStatus={handleUpdateOrderStatus}
          />
        );
      case 'admin-portal':
        return (
          <AdminPortal
            commodities={commodities}
            orders={orders}
            suppliers={suppliers}
            rfqs={rfqs}
            analytics={analytics}
            onVerifySupplier={handleVerifySupplier}
            onResolveDispute={handleApproveOrder}
          />
        );
      case 'api-console':
        return (
          <ApiConsole
            commodities={commodities}
            orders={orders}
            suppliers={suppliers}
            rfqs={rfqs}
          />
        );
      case 'documentation':
        return <GeneralInfo />;
      default:
        return (
          <Marketplace
            commodities={commodities}
            suppliers={suppliers}
            orders={orders}
            onAddOrder={handleAddOrder}
            setActiveView={setActiveView}
            setRfqPreFill={setRfqPreFill}
          />
        );
    }
  };

  return (
    <div className="bg-[#0A0A0B] text-[#F0F0F0] min-h-screen flex flex-col font-sans">
      <Navigation 
        activeView={activeView}
        setActiveView={setActiveView}
        activeRole={activeRole}
        setActiveRole={setActiveRole}
      />
      
      {/* Active Worksite viewport */}
      <main className="flex-1 bg-[#0A0A0B]">
        {renderActiveView()}
      </main>

      {/* Industrial Footer */}
      <footer className="bg-[#0E0E10] text-[#888] py-8 border-t border-[#2A2A2E] font-mono text-[11px] text-center">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <div>© 2026 AGORA EXCHANGE INC. ALL PHYSICAL SHIPMENTS PROTECTED BY ACCREDITED ESCROW LANES.</div>
          <div className="text-[#555]">STATE LICENSE: #AE-2026-990812 | COMPLIANCE ACT: EXW_CIF_FOB_DDP_INCOTERMS</div>
        </div>
      </footer>
    </div>
  );
}
