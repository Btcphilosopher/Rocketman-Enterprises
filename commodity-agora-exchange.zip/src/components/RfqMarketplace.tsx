/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Rfq, Bid, Order, Supplier } from '../types';
import { 
  FileText, 
  Send, 
  ShieldAlert, 
  CheckCircle, 
  PlusCircle, 
  MapPin, 
  Calendar, 
  Layers, 
  TrendingUp, 
  ArrowRight,
  Clipboard,
  DollarSign
} from 'lucide-react';

interface RfqMarketplaceProps {
  rfqs: Rfq[];
  onAddRfq: (rfq: Rfq) => void;
  onAddBid: (rfqId: string, bid: Bid) => void;
  onUpdateRfqStatus: (rfqId: string, status: Rfq['status']) => void;
  onUpdateBidStatus: (rfqId: string, bidId: string, status: Bid['status']) => void;
  onAddOrder: (order: Order) => void;
  activeRole: 'buyer' | 'supplier' | 'admin';
  suppliers: Supplier[];
  rfqPreFill: { name: string; category: string } | null;
  setRfqPreFill: (data: null) => void;
}

export default function RfqMarketplace({
  rfqs,
  onAddRfq,
  onAddBid,
  onUpdateRfqStatus,
  onUpdateBidStatus,
  onAddOrder,
  activeRole,
  suppliers,
  rfqPreFill,
  setRfqPreFill
}: RfqMarketplaceProps) {
  
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedRfq, setSelectedRfq] = useState<Rfq | null>(null);

  // Form States - RFQ Creation
  const [commodityName, setCommodityName] = useState('');
  const [category, setCategory] = useState('Forestry & Timber');
  const [quantity, setQuantity] = useState<number>(100);
  const [unit, setUnit] = useState('Metric Tons');
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [specifications, setSpecifications] = useState('');
  const [budgetRange, setBudgetRange] = useState('');
  const [deadline, setDeadline] = useState('');

  // Form States - Bid Submission (For Supplier Role)
  const [bidPrice, setBidPrice] = useState<number>(0);
  const [bidTerms, setBidTerms] = useState<'FOB' | 'CIF' | 'EXW' | 'DDP'>('FOB');
  const [bidLeadTime, setBidLeadTime] = useState<number>(14);
  const [bidNotes, setBidNotes] = useState('');

  // Pre-fill fields if we navigated from the Marketplace
  useEffect(() => {
    if (rfqPreFill) {
      setCommodityName(rfqPreFill.name);
      setCategory(rfqPreFill.category);
      // Determine default units based on category
      if (rfqPreFill.category === 'Forestry & Timber') {
        setUnit('m³ (Cubic Meters)');
        setQuantity(100);
      } else {
        setUnit('Metric Tons');
        setQuantity(50);
      }
      setIsCreateModalOpen(true);
      setRfqPreFill(null); // Clear pre-fill
    }
  }, [rfqPreFill]);

  // Handle RFQ creation
  const handleCreateRfq = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commodityName || !deliveryLocation || !specifications) return;

    const rfqId = `RFQ-${Math.floor(200 + Math.random() * 800)}`;
    const newRfq: Rfq = {
      id: rfqId,
      buyerCompany: 'Tom @ AHYX Procurement',
      commodityName,
      category,
      quantity,
      unit,
      deliveryLocation,
      specifications,
      budgetRange: budgetRange || 'Negotiable',
      deadline: deadline || '2026-08-30',
      status: 'open',
      bids: [],
      createdAt: new Date().toISOString().split('T')[0]
    };

    onAddRfq(newRfq);
    setIsCreateModalOpen(false);

    // Auto-generate competitive supplier bids after 2 seconds to make the UI interactive!
    setTimeout(() => {
      // Find a matching supplier based on category
      let matchedSupplier = suppliers[0];
      if (category === 'Metals') matchedSupplier = suppliers[1] || suppliers[2];
      else if (category === 'Construction Materials') matchedSupplier = suppliers[3];
      else if (category === 'Agricultural Commodities') matchedSupplier = suppliers[4];

      const generatedBid: Bid = {
        id: `BID-${Math.floor(400 + Math.random() * 599)}`,
        rfqId: rfqId,
        supplierId: matchedSupplier.id,
        supplierName: matchedSupplier.name,
        pricePerUnit: Math.round((70 + Math.random() * 40) * 100) / 100, // Random reasonable price
        deliveryTerms: 'CIF',
        leadTimeDays: Math.floor(10 + Math.random() * 15),
        notes: `We can fulfill this custom order from our ${matchedSupplier.warehouses[0]} site. High-fidelity grade certificate and ISO safety records attached. Spec sheets confirm full structural compliance.`,
        status: 'pending',
        documents: [{ name: `${matchedSupplier.name.replace(/\s+/g, '_')}_Assay.pdf`, size: '1.2 MB' }]
      };

      onAddBid(rfqId, generatedBid);
    }, 2000);
  };

  // Handle Bid Submission (When active role is Supplier)
  const handleSupplierSubmitBid = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRfq || bidPrice <= 0) return;

    const bidId = `BID-${Math.floor(400 + Math.random() * 599)}`;
    const newBid: Bid = {
      id: bidId,
      rfqId: selectedRfq.id,
      supplierId: 'sup-1', // Nordic Timber
      supplierName: 'Nordic Timber & Lumber Co.',
      pricePerUnit: bidPrice,
      deliveryTerms: bidTerms,
      leadTimeDays: bidLeadTime,
      notes: bidNotes || 'We guarantee FSC certified raw materials and Net-30 invoicing with full tracking.',
      status: 'pending',
      documents: [{ name: 'Nordic_Forestry_GradeSpecification.pdf', size: '1.8 MB' }]
    };

    onAddBid(selectedRfq.id, newBid);
    onUpdateRfqStatus(selectedRfq.id, 'negotiating');

    // Reset bid form
    setBidPrice(0);
    setBidNotes('');
    
    // Refresh selected rfq focus
    setSelectedRfq(prev => prev ? { ...prev, bids: [...prev.bids, newBid], status: 'negotiating' } : null);
  };

  // Accept a bid & convert RFQ to order
  const handleAcceptBid = (rfq: Rfq, bid: Bid) => {
    // 1. Update Bid Status
    onUpdateBidStatus(rfq.id, bid.id, 'accepted');
    
    // 2. Reject all other bids
    rfq.bids.forEach(b => {
      if (b.id !== bid.id) {
        onUpdateBidStatus(rfq.id, b.id, 'rejected');
      }
    });

    // 3. Update RFQ Status to accepted
    onUpdateRfqStatus(rfq.id, 'accepted');

    // 4. Create an active order
    const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOrder: Order = {
      id: orderId,
      buyerCompany: rfq.buyerCompany,
      supplierId: bid.supplierId,
      supplierName: bid.supplierName,
      commodityId: 'com-custom', // Custom RFQ Order
      commodityName: rfq.commodityName,
      quantity: rfq.quantity,
      unit: rfq.unit,
      totalPrice: Math.round((rfq.quantity * bid.pricePerUnit) * 100) / 100,
      paymentMethod: 'Escrow', // Default safe escrow for RFQ
      shippingTerms: bid.deliveryTerms,
      status: 'processing',
      warehouse: 'Supplier Production Plant',
      paymentStatus: 'escrowed',
      createdAt: new Date().toISOString().split('T')[0]
    };

    onAddOrder(newOrder);

    // Refresh selected RFQ
    setSelectedRfq(prev => {
      if (!prev) return null;
      return {
        ...prev,
        status: 'accepted',
        bids: prev.bids.map(b => b.id === bid.id ? { ...b, status: 'accepted' } : { ...b, status: 'rejected' })
      };
    });
  };

  return (
    <div className="bg-[#0A0A0B] text-[#F0F0F0] min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#2A2A2E] pb-5 mb-6">
          <div>
            <span className="text-[10px] font-mono text-[#E2FF00] uppercase tracking-widest font-bold">PROCUREMENT TENDER BOARD</span>
            <h1 className="text-2xl font-mono font-bold text-white tracking-tight mt-0.5">RFQ MARKETPLACE</h1>
            <p className="text-xs text-gray-400 font-sans mt-1">
              Submit raw material specifications to elicit and compare bulk commercial bids directly from verified mills.
            </p>
          </div>
          
          {activeRole === 'buyer' && (
            <button
              id="create-rfq-trigger"
              onClick={() => setIsCreateModalOpen(true)}
              className="mt-4 md:mt-0 bg-[#E2FF00] hover:bg-[#f0ff66] text-black px-4 py-2.5 rounded font-mono text-xs font-bold uppercase tracking-wider flex items-center shadow-md transition-colors"
            >
              <PlusCircle className="w-4 h-4 mr-2 text-black" />
              CREATE_NEW_TENDER_RFQ
            </button>
          )}
        </div>

        {/* Outer Split Layout */}
        <div className="grid lg:grid-cols-3 gap-6">
          
          {/* Left Column: List of Active RFQs */}
          <div className="lg:col-span-1 space-y-3">
            <span className="text-[11px] font-mono tracking-wider text-gray-500 block font-bold uppercase">ACTIVE PROCUREMENTS ({rfqs.length})</span>
            
            <div className="space-y-3.5">
              {rfqs.map((rfq) => {
                const isActive = selectedRfq?.id === rfq.id;
                return (
                  <div
                    key={rfq.id}
                    id={`rfq-card-${rfq.id}`}
                    onClick={() => {
                      setSelectedRfq(rfq);
                      // Pre-fill supplier bid values with safe defaults
                      setBidPrice(rfq.budgetRange !== 'Negotiable' ? parseFloat(rfq.budgetRange.replace(/[^0-9.]/g, '')) / rfq.quantity : 100);
                    }}
                    className={`p-4 border rounded cursor-pointer transition-all duration-150 ${
                      isActive 
                        ? 'bg-[#0E0E10] border-[#E2FF00] ring-1 ring-[#E2FF00] shadow-md' 
                        : 'bg-[#0E0E10] border-[#2A2A2E] hover:border-gray-500 shadow-sm'
                    }`}
                  >
                    <div className="flex justify-between items-center text-[10px] font-mono text-gray-500 mb-1">
                      <span>{rfq.id}</span>
                      <span>{rfq.createdAt}</span>
                    </div>

                    <h3 className="font-mono font-bold text-sm text-white leading-tight">
                      {rfq.commodityName}
                    </h3>
                    
                    <div className="mt-2.5 grid grid-cols-2 gap-2 text-[11px] font-mono text-gray-400">
                      <div>
                        <span>QTY NEEDED:</span>
                        <span className="block text-gray-200 font-semibold">{rfq.quantity.toLocaleString()} {rfq.unit.split(' ')[0]}</span>
                      </div>
                      <div>
                        <span>BUDGET:</span>
                        <span className="block text-gray-200 font-semibold">{rfq.budgetRange}</span>
                      </div>
                    </div>

                    <div className="mt-3.5 border-t border-[#2A2A2E] pt-2.5 flex items-center justify-between">
                      {/* Bid Count badge */}
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono bg-[#E2FF00]/10 text-[#E2FF00] border border-[#E2FF00]/20">
                        {rfq.bids.length} ACTIVE BIDS
                      </span>

                      {/* Status Tracker */}
                      <span className={`text-[10px] font-mono font-semibold uppercase ${
                        rfq.status === 'open' ? 'text-emerald-400' :
                        rfq.status === 'negotiating' ? 'text-amber-400' :
                        rfq.status === 'accepted' ? 'text-blue-400' : 'text-gray-500'
                      }`}>
                        ● {rfq.status}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Detailed RFQ Viewer & Compare Workbench */}
          <div className="lg:col-span-2">
            {selectedRfq ? (
              <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded p-6 shadow-sm space-y-6 text-white">
                
                {/* Meta details */}
                <div className="flex justify-between items-start border-b border-[#2A2A2E] pb-4">
                  <div>
                    <span className="text-[10px] font-mono text-gray-500 block uppercase">COMMERCIAL REQUISITION ID: {selectedRfq.id}</span>
                    <h2 className="text-xl font-mono font-bold text-white leading-tight">{selectedRfq.commodityName}</h2>
                    <span className="text-xs text-gray-400 font-sans mt-1 block">Tendered by: {selectedRfq.buyerCompany}</span>
                  </div>

                  <span className={`px-2.5 py-1 rounded text-xs font-mono font-bold uppercase ${
                    selectedRfq.status === 'open' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                    selectedRfq.status === 'negotiating' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                    selectedRfq.status === 'accepted' ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20' : 'bg-gray-500/10 text-gray-400'
                  }`}>
                    {selectedRfq.status.toUpperCase()}
                  </span>
                </div>

                {/* Core Specifications Sheet */}
                <div className="bg-[#151518] p-4 border border-[#2A2A2E] rounded space-y-3.5">
                  <span className="text-[10px] font-mono text-gray-400 block font-bold uppercase">Specification Requirements</span>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs font-mono">
                    <div>
                      <span className="text-gray-500 block">VOLUME TARGET:</span>
                      <span className="font-semibold text-gray-200">{selectedRfq.quantity.toLocaleString()} {selectedRfq.unit}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">DELIVERY LOCATION:</span>
                      <span className="font-semibold text-gray-200 flex items-center">
                        <MapPin className="w-3.5 h-3.5 mr-0.5 text-[#E2FF00]" />
                        {selectedRfq.deliveryLocation}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">BUDGET RANGE:</span>
                      <span className="font-semibold text-gray-200">{selectedRfq.budgetRange}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">CLOSING DEADLINE:</span>
                      <span className="font-semibold text-gray-200 flex items-center">
                        <Calendar className="w-3.5 h-3.5 mr-1 text-gray-400" />
                        {selectedRfq.deadline}
                      </span>
                    </div>
                    <div>
                      <span className="text-gray-500 block">COMMODITY CATEGORY:</span>
                      <span className="font-semibold text-gray-200">{selectedRfq.category}</span>
                    </div>
                  </div>

                  <div className="border-t border-[#2A2A2E] pt-3 text-xs">
                    <span className="text-gray-500 font-mono block">DETAILED MECHANICAL / GRADE SPECS:</span>
                    <p className="text-gray-300 font-sans mt-1 leading-relaxed bg-[#0E0E10] p-2.5 rounded border border-[#2A2A2E]">{selectedRfq.specifications}</p>
                  </div>
                </div>

                {/* List of Incoming Quotes/Bids */}
                <div className="space-y-3">
                  <span className="text-[11px] font-mono tracking-wider text-gray-500 block font-bold uppercase">INCOMING SUPPLIER BIDS ({selectedRfq.bids.length})</span>
                  
                  <div className="space-y-3">
                    {selectedRfq.bids.map((bid) => {
                      const bidTotal = selectedRfq.quantity * bid.pricePerUnit;
                      return (
                        <div key={bid.id} className={`p-4 border rounded shadow-sm ${
                          bid.status === 'accepted' 
                            ? 'border-emerald-500 bg-emerald-500/5' 
                            : 'border-[#2A2A2E] bg-[#0E0E10]'
                        }`}>
                          <div className="flex justify-between items-start">
                            <div>
                              <span className="inline-flex items-center text-xs font-mono font-bold text-white">
                                <Layers className="w-3.5 h-3.5 text-[#E2FF00] mr-1.5" />
                                {bid.supplierName}
                              </span>
                              <span className="text-[10px] font-mono text-gray-500 block mt-0.5">BID REFERENCE: {bid.id}</span>
                            </div>
                            
                            <div className="text-right">
                              <span className="text-[10px] font-mono text-gray-500 uppercase tracking-wider block">Commercial Total</span>
                              <span className="text-base font-mono font-bold text-white">${bidTotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                              <span className="text-[10px] text-gray-400 block font-mono">(${bid.pricePerUnit.toFixed(2)} / unit)</span>
                            </div>
                          </div>

                          <div className="mt-3 grid grid-cols-2 md:grid-cols-3 gap-2 bg-[#151518] p-2 rounded text-xs font-mono text-gray-400">
                            <div>
                              <span>SHIP TERMS:</span>
                              <span className="block font-semibold text-gray-200">{bid.deliveryTerms}</span>
                            </div>
                            <div>
                              <span>LEAD TIME:</span>
                              <span className="block font-semibold text-gray-200">{bid.leadTimeDays} days</span>
                            </div>
                            <div>
                              <span>TECHNICAL PACK:</span>
                              <span className="block text-[#E2FF00] underline cursor-pointer hover:text-white">Spec_Cert.pdf</span>
                            </div>
                          </div>

                          <p className="mt-3 text-xs text-gray-400 font-sans leading-relaxed border-l-2 border-[#2A2A2E] pl-2.5">{bid.notes}</p>

                          {/* Bid Action */}
                          {activeRole === 'buyer' && selectedRfq.status !== 'accepted' && (
                            <div className="mt-4 flex justify-end">
                              <button
                                id={`accept-bid-${bid.id}`}
                                onClick={() => handleAcceptBid(selectedRfq, bid)}
                                className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black px-3 py-1.5 rounded font-mono text-xs font-bold uppercase tracking-wider flex items-center shadow-sm transition-colors"
                              >
                                ACCEPT_PROPOSAL_&_PURCHASE
                              </button>
                            </div>
                          )}

                          {bid.status === 'accepted' && (
                            <div className="mt-4 flex items-center text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 p-2 rounded border border-emerald-500/20">
                              <CheckCircle className="w-4 h-4 mr-1.5" />
                              PROPOSAL ACCEPTED. CONTRACT CONVERTED INTO ACTIVE PROCUREMENT ORDER.
                            </div>
                          )}
                        </div>
                      );
                    })}

                    {selectedRfq.bids.length === 0 && (
                      <div className="text-center py-8 border border-dashed border-[#2A2A2E] rounded text-gray-500 text-xs font-mono bg-[#0E0E10]">
                        WAITING FOR INTERNATIONAL MILLS TO DISPATCH BIDS... <br />
                        <span className="text-[10px] text-gray-600 font-sans mt-1 block">Competitive bid algorithms usually dispatch a reply in 2-5 seconds.</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Supplier Bid Submission Block (Only active when persona is Supplier and status is open) */}
                {activeRole === 'supplier' && selectedRfq.status !== 'accepted' && (
                  <form onSubmit={handleSupplierSubmitBid} className="border-t border-[#2A2A2E] pt-5 mt-4 space-y-4">
                    <span className="text-[11px] font-mono tracking-wider text-[#E2FF00] block font-bold uppercase">SUPPLIER RESPONSE CONSOLE</span>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      <div>
                        <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Price Per Unit (USD)</label>
                        <input
                          type="number"
                          id="bid-price-input"
                          value={bidPrice}
                          onChange={(e) => setBidPrice(parseFloat(e.target.value) || 0)}
                          className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Shipping Term</label>
                        <select
                          id="bid-terms-select"
                          value={bidTerms}
                          onChange={(e) => setBidTerms(e.target.value as any)}
                          className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                        >
                          <option value="FOB">FOB</option>
                          <option value="CIF">CIF</option>
                          <option value="EXW">EXW</option>
                          <option value="DDP">DDP</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Lead Time (Days)</label>
                        <input
                          type="number"
                          id="bid-lead-input"
                          value={bidLeadTime}
                          onChange={(e) => setBidLeadTime(parseInt(e.target.value) || 14)}
                          className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Bid Specifications & Technical Notes</label>
                      <textarea
                        id="bid-notes-input"
                        value={bidNotes}
                        onChange={(e) => setBidNotes(e.target.value)}
                        placeholder="Detail standard grade compliance, mill location, packaging formats..."
                        className="w-full h-18 text-xs font-sans bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      />
                    </div>

                    <button
                      type="submit"
                      id="submit-bid-btn"
                      className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black text-xs font-mono font-semibold px-4 py-2 rounded uppercase tracking-wider shadow-md transition-colors"
                    >
                      DISPATCH_BINDING_BID_PROPOSAL
                    </button>
                  </form>
                )}

              </div>
            ) : (
              <div className="bg-[#0E0E10] border border-dashed border-[#2A2A2E] rounded p-16 flex flex-col items-center justify-center text-center">
                <FileText className="w-10 h-10 text-gray-600 mb-3" />
                <span className="text-sm font-mono text-gray-400">NO TENDER TICKET SELECTED</span>
                <p className="text-xs text-gray-500 max-w-sm mt-1">Select an active RFQ tender on the left sidebar to examine commercial specifications, download laboratory sheets, or review competitive supplier bids.</p>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* RFQ Creation Modal */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-[#0A0A0B]/80 transition-opacity" onClick={() => setIsCreateModalOpen(false)}></div>

            <span className="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

            <div className="inline-block align-bottom bg-[#0E0E10] rounded text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full border border-[#2A2A2E]">
              
              <div className="bg-[#0A0A0B] text-white px-6 py-4 flex items-center justify-between border-b border-[#2A2A2E]">
                <span className="font-mono text-xs font-bold tracking-wider flex items-center uppercase text-white">
                  <Clipboard className="w-4 h-4 mr-1.5 text-[#E2FF00]" />
                  ESTABLISH PROCUREMENT REQUEST
                </span>
                <button onClick={() => setIsCreateModalOpen(false)} className="text-gray-400 hover:text-white font-mono text-xs">CLOSE</button>
              </div>

              <form onSubmit={handleCreateRfq} className="p-6 space-y-4">
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="col-span-2">
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Commodity Spec Title</label>
                    <input
                      type="text"
                      id="rfq-title-input"
                      value={commodityName}
                      onChange={(e) => setCommodityName(e.target.value)}
                      placeholder="e.g. S355 Structural Steel Beams"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Category Group</label>
                    <select
                      id="rfq-category-select"
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                    >
                      <option value="Forestry & Timber">Timber</option>
                      <option value="Metals">Metals</option>
                      <option value="Construction Materials">Construction</option>
                      <option value="Agricultural Commodities">Agriculture</option>
                      <option value="Energy & Industrial Materials">Energy</option>
                      <option value="Manufacturing Inputs">Manufacturing</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Target Quantity</label>
                    <input
                      type="number"
                      id="rfq-quantity-input"
                      value={quantity}
                      onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 0))}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Unit Type</label>
                    <input
                      type="text"
                      id="rfq-unit-input"
                      value={unit}
                      onChange={(e) => setUnit(e.target.value)}
                      placeholder="e.g. Metric Tons"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Delivery Destination</label>
                    <input
                      type="text"
                      id="rfq-delivery-input"
                      value={deliveryLocation}
                      onChange={(e) => setDeliveryLocation(e.target.value)}
                      placeholder="e.g. Antwerp Port Terminal"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Target Budget Range</label>
                    <input
                      type="text"
                      id="rfq-budget-input"
                      value={budgetRange}
                      onChange={(e) => setBudgetRange(e.target.value)}
                      placeholder="e.g. $100,000 - $120,000"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Tender Closure Deadline</label>
                    <input
                      type="date"
                      id="rfq-deadline-input"
                      value={deadline}
                      onChange={(e) => setDeadline(e.target.value)}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Detailed Mechanical specs / Grades / Certs required</label>
                  <textarea
                    id="rfq-specs-input"
                    value={specifications}
                    onChange={(e) => setSpecifications(e.target.value)}
                    placeholder="Provide ASTM specs, wood moisture limits, thickness, or testing protocols required..."
                    className="w-full h-24 text-xs font-sans bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                    required
                  />
                </div>

                <div className="border-t border-[#2A2A2E] pt-4 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setIsCreateModalOpen(false)}
                    className="border border-[#2A2A2E] text-gray-400 hover:text-white text-xs font-mono font-semibold px-4 py-2 rounded"
                  >
                    CANCEL
                  </button>
                  <button
                    type="submit"
                    id="submit-rfq-btn"
                    className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black text-xs font-mono font-bold px-4 py-2 rounded uppercase tracking-wider transition-colors"
                  >
                    DISPATCH_TENDER_TICKET
                  </button>
                </div>

              </form>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
