/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Commodity, Order, Supplier, Rfq, PlatformAnalytics } from '../types';
import { 
  ShieldCheck, 
  Users, 
  TrendingUp, 
  Activity, 
  SlidersHorizontal, 
  AlertTriangle, 
  CheckCircle, 
  BarChart2, 
  Database,
  Search,
  Check,
  X
} from 'lucide-react';

interface AdminPortalProps {
  commodities: Commodity[];
  orders: Order[];
  suppliers: Supplier[];
  rfqs: Rfq[];
  analytics: PlatformAnalytics;
  onVerifySupplier: (supplierId: string) => void;
  onResolveDispute: (orderId: string) => void;
}

export default function AdminPortal({
  commodities,
  orders,
  suppliers,
  rfqs,
  analytics,
  onVerifySupplier,
  onResolveDispute
}: AdminPortalProps) {

  const [activeAdminTab, setActiveAdminTab] = useState<'analytics' | 'compliance' | 'orders' | 'disputes'>('analytics');
  const [supplierSearch, setSupplierSearch] = useState('');

  // Filtering suppliers that are pending full audit approval
  const complianceSuppliers = suppliers.filter(s => 
    s.name.toLowerCase().includes(supplierSearch.toLowerCase())
  );

  // Calculate platform metrics
  const totalGMV = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((acc, c) => acc + c.totalPrice, 0) + analytics.gmv;

  const activeOrdersCount = orders.length;

  return (
    <div className="bg-[#fcfbf9] text-[#1a1c20] min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Deck */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-200 pb-5 mb-6">
          <div>
            <span className="text-[10px] font-mono text-[#b38a38] uppercase tracking-widest font-bold">SYSTEM OVERSEER CAPABILITY: LEVEL_1_ROOT</span>
            <h1 className="text-2xl font-mono font-bold text-gray-900 tracking-tight mt-0.5">ADMINISTRATION PORTAL</h1>
            <p className="text-xs text-gray-500 font-sans mt-1">
              Platform-wide contract auditing, global supplier compliance vetting, and Gross Merchandise Volume (GMV) telemetry.
            </p>
          </div>

          <div className="mt-4 md:mt-0 flex space-x-6 text-right">
            <div>
              <span className="text-[10px] font-mono text-gray-400 block uppercase">TOTAL CONSOLIDATED GMV</span>
              <span className="text-lg font-mono font-bold text-[#b38a38]">${totalGMV.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            <div>
              <span className="text-[10px] font-mono text-gray-400 block uppercase">SYSTEM RUNNING IN</span>
              <span className="text-lg font-mono font-bold text-emerald-600">LIVE_AUDIT MODE</span>
            </div>
          </div>
        </div>

        {/* Navigation tabs */}
        <div className="border-b border-gray-200 mb-6 flex space-x-1">
          {[
            { id: 'analytics', label: 'VOLUME TELEMETRY', icon: BarChart2 },
            { id: 'compliance', label: 'SUPPLIER COMPLIANCE VETTING', icon: ShieldCheck },
            { id: 'orders', label: 'COMMERCE LOG AUDITS', icon: Database },
            { id: 'disputes', label: 'DISPUTE RESOLUTION BOARD', icon: AlertTriangle }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                id={`admin-tab-${tab.id}`}
                onClick={() => setActiveAdminTab(tab.id as any)}
                className={`flex items-center px-4 py-2 text-xs font-mono font-bold transition-all relative border-b-2 ${
                  activeAdminTab === tab.id 
                    ? 'border-[#b38a38] text-[#b38a38] bg-white' 
                    : 'border-transparent text-gray-500 hover:text-gray-900'
                }`}
              >
                <Icon className="w-4 h-4 mr-1.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        {activeAdminTab === 'analytics' && (
          <div className="space-y-6">
            
            {/* Analytics Stats Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                <span className="text-[9px] font-mono text-gray-400 block tracking-widest uppercase">CONSOLIDATED VOLUMES</span>
                <span className="text-2xl font-mono font-bold text-gray-900 block mt-1">${(totalGMV / 1000000).toFixed(2)}M</span>
                <span className="text-[10px] text-emerald-600 block mt-1">↑ 14.2% MoM GROW RATE</span>
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                <span className="text-[9px] font-mono text-gray-400 block tracking-widest uppercase">TRANSACTION LOGS</span>
                <span className="text-2xl font-mono font-bold text-gray-900 block mt-1">{(analytics.orderCount + activeOrdersCount).toLocaleString()}</span>
                <span className="text-[10px] text-gray-500 block mt-1">Double-Entry Ledger Verified</span>
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                <span className="text-[9px] font-mono text-gray-400 block tracking-widest uppercase">ACTIVE MEMBERS COHORT</span>
                <span className="text-2xl font-mono font-bold text-gray-900 block mt-1">{(analytics.activeBuyers).toLocaleString()}</span>
                <span className="text-[10px] text-emerald-600 block mt-1">✓ 100% KYB (Business KYC)</span>
              </div>
              <div className="bg-white border border-gray-200 p-4 rounded shadow-sm">
                <span className="text-[9px] font-mono text-gray-400 block tracking-widest uppercase">CATALOGED LISTINGS</span>
                <span className="text-2xl font-mono font-bold text-gray-900 block mt-1">{commodities.length} SPEC SLABS</span>
                <span className="text-[10px] text-gray-500 block mt-1">All with tracing certificates</span>
              </div>
            </div>

            {/* Visual analytics block using CSS bar diagrams (bulletproof, beautiful and responsive!) */}
            <div className="grid md:grid-cols-2 gap-6">
              
              {/* Category distribution */}
              <div className="bg-white border border-gray-200 rounded p-6 shadow-sm">
                <span className="text-xs font-mono text-gray-400 block mb-4 uppercase">GMV DISTRIBUTION BY SECTOR</span>
                
                <div className="space-y-4">
                  {analytics.categoryDistribution.map((item, idx) => (
                    <div key={idx} className="space-y-1.5 font-mono">
                      <div className="flex justify-between text-xs font-semibold text-gray-700">
                        <span>{item.category.toUpperCase()}</span>
                        <span>{item.value}%</span>
                      </div>
                      <div className="w-full bg-gray-100 h-2.5 rounded-full overflow-hidden">
                        <div 
                          className="bg-[#b38a38] h-full" 
                          style={{ width: `${item.value}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Demand index over time */}
              <div className="bg-white border border-gray-200 rounded p-6 shadow-sm flex flex-col justify-between">
                <div>
                  <span className="text-xs font-mono text-gray-400 block mb-4 uppercase">COMMODITY AGORA DEMAND INDEX (2026)</span>
                  <div className="flex items-baseline space-x-2">
                    <span className="text-2xl font-mono font-bold text-gray-900">113.80</span>
                    <span className="text-xs font-mono text-emerald-600 font-bold">↑ 2.5% Spot Change</span>
                  </div>
                </div>

                {/* Simulated Sparkline / Demand graph with divs */}
                <div className="mt-6 flex items-end justify-between h-32 pt-4 border-b border-l border-gray-200 pl-2 pb-2">
                  {analytics.marketTrends.map((trend, idx) => {
                    // Normalize index values (range ~ 100 to 115) to percentages (height 40% to 100%)
                    const heightPercent = 40 + ((trend.indexValue - 100) / 15) * 60;
                    return (
                      <div key={idx} className="flex flex-col items-center flex-grow group cursor-help" title={`Index: ${trend.indexValue}`}>
                        <div 
                          className="w-4 bg-slate-900 group-hover:bg-[#b38a38] transition-colors rounded-t-sm"
                          style={{ height: `${heightPercent}px` }}
                        />
                        <span className="text-[9px] font-mono text-gray-400 mt-2 block tracking-tighter uppercase">{trend.date}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Compliance management panel */}
        {activeAdminTab === 'compliance' && (
          <div className="space-y-6">
            
            <div className="flex items-center justify-between bg-gray-50 p-4 border border-gray-200 rounded">
              <span className="text-xs font-mono text-gray-700 font-bold uppercase">SUPPLIER VERIFICATION BOARD</span>
              
              <div className="relative w-64">
                <Search className="w-3.5 h-3.5 text-gray-400 absolute left-2.5 top-2.5" />
                <input
                  type="text"
                  placeholder="Search supplier list..."
                  value={supplierSearch}
                  onChange={(e) => setSupplierSearch(e.target.value)}
                  className="w-full text-xs font-mono bg-white border border-gray-300 rounded pl-8 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#b38a38]"
                />
              </div>
            </div>

            {/* List of suppliers pending / active */}
            <div className="space-y-4">
              {complianceSuppliers.map((sup) => (
                <div key={sup.id} className="bg-white border border-gray-200 p-5 rounded shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div className="space-y-1.5">
                    <div className="flex items-center space-x-2">
                      <span className="w-6 h-6 rounded-full bg-slate-900 text-[#b38a38] flex items-center justify-center font-mono text-xs font-bold">{sup.logo}</span>
                      <h3 className="font-mono font-bold text-sm text-gray-900">{sup.name}</h3>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold uppercase ${
                        sup.complianceStatus === 'Verified' ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800 animate-pulse'
                      }`}>
                        ● {sup.complianceStatus}
                      </span>
                    </div>

                    <p className="text-xs text-gray-500 font-sans max-w-xl leading-relaxed">{sup.description}</p>
                    
                    {/* Cert list */}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {sup.certifications.map((c, i) => (
                        <span key={i} className="text-[10px] font-mono bg-gray-50 border border-gray-100 rounded px-2 py-0.5 text-gray-500">{c}</span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 md:mt-0 text-left md:text-right font-mono text-xs space-y-2 self-stretch flex flex-col justify-between items-end">
                    <div>
                      <span className="text-gray-400 block text-[9px] uppercase">CAPACITY ANNUALLY</span>
                      <span className="font-semibold text-gray-800 block">{sup.capacityAnnually}</span>
                    </div>

                    {sup.complianceStatus !== 'Verified' ? (
                      <button
                        id={`verify-btn-${sup.id}`}
                        onClick={() => onVerifySupplier(sup.id)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-mono text-[10px] font-bold uppercase px-3 py-1.5 rounded flex items-center"
                      >
                        <Check className="w-3.5 h-3.5 mr-1" />
                        CERTIFY_&_ACTIVATE
                      </button>
                    ) : (
                      <span className="text-emerald-600 font-bold flex items-center text-[10px] uppercase">
                        ✓ SECURE FOR TRADE
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* Global Orders Audit Log */}
        {activeAdminTab === 'orders' && (
          <div className="bg-white border border-gray-200 rounded shadow-sm overflow-hidden">
            <div className="bg-gray-50 border-b border-gray-200 px-6 py-4 flex justify-between items-center">
              <span className="font-mono text-xs font-bold tracking-wider text-gray-700">CENTRAL TRANSACTION AUDIT TELEMETRY</span>
              <span className="text-[10px] font-mono text-gray-400">DOUBLE_ENTRY LEDGER CRYPTO COMPLIANT</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-gray-50 border-b border-gray-200 text-[10px] text-gray-400 uppercase tracking-widest">
                  <tr>
                    <th className="px-6 py-3">Contract Code</th>
                    <th className="px-6 py-3">Buyer Enterprise</th>
                    <th className="px-6 py-3">Supplier Plant</th>
                    <th className="px-6 py-3">Commodity Spec</th>
                    <th className="px-6 py-3">Settle Amt</th>
                    <th className="px-6 py-3">Method</th>
                    <th className="px-6 py-3">Fulfillment Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-gray-700">
                  {orders.map((order) => (
                    <tr key={order.id} className="hover:bg-gray-50/50">
                      <td className="px-6 py-3.5 font-bold text-gray-900">{order.id}</td>
                      <td className="px-6 py-3.5 font-semibold text-gray-900">{order.buyerCompany}</td>
                      <td className="px-6 py-3.5 text-gray-500">{order.supplierName}</td>
                      <td className="px-6 py-3.5">{order.commodityName}</td>
                      <td className="px-6 py-3.5 font-bold">${order.totalPrice.toLocaleString()}</td>
                      <td className="px-6 py-3.5">{order.paymentMethod}</td>
                      <td className="px-6 py-3.5">
                        <span className={`inline-flex px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                          order.status === 'delivered' ? 'bg-emerald-50 text-emerald-800' :
                          order.status === 'shipped' ? 'bg-blue-50 text-blue-800' : 'bg-amber-50 text-amber-800 animate-pulse'
                        }`}>
                          {order.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Dispute Resolution Deck */}
        {activeAdminTab === 'disputes' && (
          <div className="space-y-4">
            <span className="text-[11px] font-mono tracking-wider text-gray-400 block font-bold uppercase">PHYSICAL CARGO DISPUTES BOARD</span>
            
            {/* Standard pre-populated dispute for fidelity */}
            <div className="bg-white border border-red-200 rounded p-5 shadow-sm space-y-4">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-100 pb-3">
                <div>
                  <span className="text-[9px] font-mono text-red-600 block font-bold uppercase tracking-wider">⚠️ DISPUTE ACTIVE: DENSITY TESTING ANOMALY</span>
                  <h3 className="font-mono font-bold text-sm text-gray-900 mt-1">S355 Structural Steel H-Beams HEB 300</h3>
                  <span className="text-[10px] font-mono text-gray-400 block">CONTRACT REF: ORD-1092 | DISPUTED BY: Global Infrastructure Partners Ltd</span>
                </div>

                <div className="text-right mt-2 md:mt-0 font-mono">
                  <span className="text-[9px] text-gray-400 block">ESCROW RECORD LOCK</span>
                  <span className="text-sm font-bold text-gray-900 block">$133,500.00</span>
                </div>
              </div>

              <div className="bg-gray-50 p-3.5 rounded text-xs font-sans text-gray-700 leading-relaxed">
                <span className="font-mono font-bold text-gray-800 block mb-1">DISPUTE STATEMENT:</span>
                "Fulfillment shipment arrived at Houston Port Yard. Independent third-party metallurgical lab assay indicated yield strengths slightly below mill certification sheet parameters (S355 limit anomaly). Settle escrow lock requested until compliance is resolved."
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  onClick={() => alert('Contract audit reports dispatched to both legal counsels.')}
                  className="border border-gray-300 text-gray-700 text-xs font-mono px-3 py-1.5 rounded uppercase"
                >
                  DISPATCH_LEGAL_AUDIT_DOCKET
                </button>
                <button
                  id="resolve-dispute-btn"
                  onClick={() => onVerifySupplier('sup-2')} // Re-approve
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-mono font-bold px-4 py-2 rounded uppercase tracking-wider"
                >
                  RELEASE_ESCROW_TO_SUPPLIER
                </button>
              </div>
            </div>

            <div className="bg-white border border-dashed border-gray-300 rounded p-12 text-center text-gray-400 text-xs font-mono">
              NO OTHER OUTSTANDING QUALITY ASSAY DISPUTES REGISTERED ON THE PLATFORM
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
