/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Commodity, Supplier, Order } from '../types';
import { 
  Search, 
  SlidersHorizontal, 
  MapPin, 
  ShieldCheck, 
  Package, 
  FileText, 
  Truck, 
  ArrowRight,
  TrendingUp,
  Download,
  CheckCircle,
  QrCode,
  DollarSign
} from 'lucide-react';

interface MarketplaceProps {
  commodities: Commodity[];
  suppliers: Supplier[];
  orders: Order[];
  onAddOrder: (order: Order) => void;
  setActiveView: (view: string) => void;
  setRfqPreFill: (data: { name: string; category: string }) => void;
}

export default function Marketplace({
  commodities,
  suppliers,
  orders,
  onAddOrder,
  setActiveView,
  setRfqPreFill
}: MarketplaceProps) {
  
  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedOrigin, setSelectedOrigin] = useState('All');
  const [selectedCert, setSelectedCert] = useState('All');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<Commodity | null>(null);

  // Buy Flow Drawer State
  const [isBuyDrawerOpen, setIsBuyDrawerOpen] = useState(false);
  const [buyQuantity, setBuyQuantity] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'Bank Transfer' | 'Escrow' | 'Credit Account' | 'Purchase Order' | 'Bitcoin (BTC)' | 'USDT'>('Bank Transfer');
  const [shippingTerm, setShippingTerm] = useState<'FOB' | 'CIF' | 'EXW' | 'DDP'>('FOB');
  const [orderSuccess, setOrderSuccess] = useState(false);
  const [lastOrderNumber, setLastOrderNumber] = useState('');

  // Categories
  const categories = ['All', 'Forestry & Timber', 'Metals', 'Construction Materials', 'Agricultural Commodities', 'Energy & Industrial Materials', 'Manufacturing Inputs'];

  // Origins
  const origins = ['All', 'Sweden', 'Germany', 'Chile', 'Italy', 'United States', 'Brazil', 'Malaysia'];

  // Certifications
  const certs = ['All', 'FSC', 'PEFC', 'ISO 9001', 'ASTM', 'LME', 'CE', 'Rainforest Alliance'];

  // Filter Commodities
  const filteredCommodities = commodities.filter(item => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.supplierName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.subcategory.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesOrigin = selectedOrigin === 'All' || item.originCountry === selectedOrigin;
    
    const matchesCert = selectedCert === 'All' || item.certification.some(c => c.includes(selectedCert));
    
    const matchesMinPrice = minPrice === '' || item.pricePerUnit >= parseFloat(minPrice);
    const matchesMaxPrice = maxPrice === '' || item.pricePerUnit <= parseFloat(maxPrice);

    return matchesSearch && matchesCategory && matchesOrigin && matchesCert && matchesMinPrice && matchesMaxPrice;
  });

  // Calculate bulk discount
  const getAppliedDiscount = (qty: number, item: Commodity) => {
    let bestDiscount = 0;
    // Sort discounts descending by quantity
    const sortedDiscounts = [...item.bulkDiscounts].sort((a, b) => b.qty - a.qty);
    for (const d of sortedDiscounts) {
      if (qty >= d.qty) {
        bestDiscount = d.discountPercent;
        break;
      }
    }
    return bestDiscount;
  };

  const handleOpenProduct = (product: Commodity) => {
    setSelectedProduct(product);
    setBuyQuantity(product.moq);
    setOrderSuccess(false);
  };

  const handleExecutePurchase = () => {
    if (!selectedProduct) return;
    if (buyQuantity < selectedProduct.moq) return;

    const discount = getAppliedDiscount(buyQuantity, selectedProduct);
    const rawTotal = buyQuantity * selectedProduct.pricePerUnit;
    const finalTotal = rawTotal * (1 - discount / 100);

    const orderId = `ORD-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: orderId,
      buyerCompany: 'Tom @ AHYX Procurement',
      supplierId: selectedProduct.supplierId,
      supplierName: selectedProduct.supplierName,
      commodityId: selectedProduct.id,
      commodityName: selectedProduct.name,
      quantity: buyQuantity,
      unit: selectedProduct.unit,
      totalPrice: Math.round(finalTotal * 100) / 100,
      paymentMethod: paymentMethod,
      shippingTerms: shippingTerm,
      status: paymentMethod === 'Credit Account' || paymentMethod === 'Purchase Order' ? 'pending_approval' : 'processing',
      warehouse: selectedProduct.warehouseLocation,
      paymentStatus: paymentMethod === 'Escrow' ? 'escrowed' : 'pending',
      createdAt: new Date().toISOString().split('T')[0]
    };

    onAddOrder(newOrder);
    setLastOrderNumber(orderId);
    setOrderSuccess(true);
    
    // Close Buy Drawer after short timeout
    setTimeout(() => {
      setIsBuyDrawerOpen(false);
      setSelectedProduct(null);
      setOrderSuccess(false);
    }, 4000);
  };

  const startRfqProcurement = (product: Commodity) => {
    setRfqPreFill({
      name: product.name,
      category: product.category
    });
    setActiveView('rfq');
  };

  return (
    <div className="bg-[#0A0A0B] text-[#F0F0F0] min-h-screen pb-16 font-sans">
      
      {/* 1. Hero Block */}
      <section className="bg-[#0E0E10] border-b border-[#2A2A2E] text-white py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="lg:grid lg:grid-cols-12 lg:gap-8 items-center">
            
            <div className="lg:col-span-7">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded text-xs font-mono font-medium bg-[#E2FF00]/10 text-[#E2FF00] border border-[#E2FF00]/20 mb-4 uppercase tracking-wider">
                AGORA CORE TRADING FLOOR
              </span>
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-mono font-bold tracking-tight text-white leading-none">
                SOURCE THE WORLD'S <br />
                <span className="text-[#E2FF00]">ESSENTIAL COMMODITIES</span>
              </h1>
              <p className="mt-3 text-sm sm:text-base text-gray-400 max-w-xl font-sans font-normal leading-relaxed">
                Premium digital infrastructure connecting producers, mills, and mines directly with enterprise builders. Built for transparency, structural compliance, and raw material optimization.
              </p>

              {/* Quick Search */}
              <div className="mt-6 max-w-xl flex">
                <div className="relative flex-grow">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Search className="h-4 w-4 text-gray-400" />
                  </div>
                  <input
                    type="text"
                    id="search-input"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search standard metals, timber species, chemical specs..."
                    className="block w-full pl-10 pr-3 py-3 border border-[#2A2A2E] rounded-l bg-[#151518] text-sm text-white placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-[#E2FF00] focus:border-[#E2FF00]"
                  />
                </div>
                <button 
                  onClick={() => {}}
                  className="bg-[#E2FF00] text-black hover:bg-[#f0ff66] px-5 py-3 text-sm font-mono font-semibold rounded-r transition-colors"
                >
                  EXECUTE_SEARCH
                </button>
              </div>

              {/* Quick Filters category pill slider */}
              <div className="mt-4 flex flex-wrap gap-1.5">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className={`px-3 py-1 text-[11px] font-mono rounded border transition-all ${
                      selectedCategory === cat 
                        ? 'bg-[#E2FF00] text-black border-[#E2FF00] font-bold' 
                        : 'border-[#2A2A2E] text-gray-300 hover:border-[#E2FF00] hover:bg-[#151518]'
                    }`}
                  >
                    {cat === 'All' ? 'ALL_CATEGORIES' : cat.toUpperCase().replace('&', '+')}
                  </button>
                ))}
              </div>
            </div>

            {/* Platform Stats Panels - McMaster style density */}
            <div className="mt-8 lg:mt-0 lg:col-span-5 grid grid-cols-2 gap-3">
              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-4 rounded shadow-md">
                <span className="text-[10px] font-mono text-gray-400 block tracking-widest">ACTIVE_PRODUCERS</span>
                <span className="text-2xl font-mono font-bold text-white block mt-1">140+</span>
                <span className="text-[10px] text-emerald-400 mt-1 block">✓ FSC/LME Verified</span>
              </div>
              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-4 rounded shadow-md">
                <span className="text-[10px] font-mono text-gray-400 block tracking-widest">SPOT_INVENTORY</span>
                <span className="text-2xl font-mono font-bold text-white block mt-1">45,820</span>
                <span className="text-[10px] text-gray-400 mt-1 block">Metric Tons / m³</span>
              </div>
              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-4 rounded shadow-md">
                <span className="text-[10px] font-mono text-gray-400 block tracking-widest">MONTHLY_TRADE_VOLUME</span>
                <span className="text-2xl font-mono font-bold text-[#E2FF00] block mt-1">$42.8M</span>
                <span className="text-[10px] text-gray-400 mt-1 block">SECURED ESCROW</span>
              </div>
              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-4 rounded shadow-md">
                <span className="text-[10px] font-mono text-gray-400 block tracking-widest">WAREHOUSES</span>
                <span className="text-2xl font-mono font-bold text-white block mt-1">12 GLOBAL</span>
                <span className="text-[10px] text-emerald-400 mt-1 block">Rotterdam, Antwerp, Santos...</span>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. Main Catalog Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
        <div className="lg:grid lg:grid-cols-4 lg:gap-8">
          
          {/* Side Filter Column - Technical McMaster Panel */}
          <aside className="lg:col-span-1 bg-[#0E0E10] p-4 border border-[#2A2A2E] rounded shadow-sm self-start text-[#F0F0F0]">
            <div className="flex items-center justify-between border-b border-[#2A2A2E] pb-3 mb-4">
              <span className="font-mono text-xs font-bold tracking-wider flex items-center text-gray-300">
                <SlidersHorizontal className="w-3.5 h-3.5 mr-1.5 text-[#E2FF00]" />
                FILTER_PARAMETERS
              </span>
              <button 
                onClick={() => {
                  setSelectedCategory('All');
                  setSelectedOrigin('All');
                  setSelectedCert('All');
                  setMinPrice('');
                  setMaxPrice('');
                }}
                className="text-[10px] font-mono text-[#E2FF00] hover:underline"
              >
                RESET_ALL
              </button>
            </div>

            {/* Origin Country */}
            <div className="mb-4">
              <label className="text-[11px] font-mono tracking-wider font-bold text-gray-500 uppercase block mb-1.5">Origin Country</label>
              <select
                id="origin-filter"
                value={selectedOrigin}
                onChange={(e) => setSelectedOrigin(e.target.value)}
                className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] rounded p-2 text-white focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
              >
                {origins.map(o => (
                  <option key={o} value={o}>{o === 'All' ? 'ANY ORIGIN' : o.toUpperCase()}</option>
                ))}
              </select>
            </div>

            {/* Certification Standard */}
            <div className="mb-4">
              <label className="text-[11px] font-mono tracking-wider font-bold text-gray-500 uppercase block mb-1.5">Certification Standards</label>
              <select
                id="cert-filter"
                value={selectedCert}
                onChange={(e) => setSelectedCert(e.target.value)}
                className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] rounded p-2 text-white focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
              >
                {certs.map(c => (
                  <option key={c} value={c}>{c === 'All' ? 'ANY SPEC' : c}</option>
                ))}
              </select>
            </div>

            {/* Price Range */}
            <div className="mb-4">
              <label className="text-[11px] font-mono tracking-wider font-bold text-gray-500 uppercase block mb-1.5">Price Range (USD / Unit)</label>
              <div className="flex space-x-2">
                <input
                  type="number"
                  id="min-price-input"
                  placeholder="Min"
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value)}
                  className="w-1/2 text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:outline-none focus:ring-1 focus:ring-[#E2FF00]"
                />
                <input
                  type="number"
                  id="max-price-input"
                  placeholder="Max"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value)}
                  className="w-1/2 text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:outline-none focus:ring-1 focus:ring-[#E2FF00]"
                />
              </div>
            </div>

            {/* Help Callout */}
            <div className="mt-6 bg-[#151518] border border-[#E2FF00]/20 p-3 rounded text-[11px] text-gray-400 leading-normal">
              <span className="font-mono font-bold text-[#E2FF00] block mb-1">✓ INDUSTRIAL COMPLIANCE</span>
              All catalog listings must possess fully traceble mill test sheets, certified grade reports, and verified warehouse releases. Specimen test sheets can be fetched instantly inside product sheets.
            </div>
          </aside>

          {/* Commodity Grid List */}
          <main className="lg:col-span-3 mt-4 lg:mt-0">
            <div className="flex items-center justify-between border-b border-[#2A2A2E] pb-3 mb-4">
              <span className="text-xs font-mono tracking-tight text-gray-400">
                SHOWING <span className="text-white font-semibold">{filteredCommodities.length}</span> PREMIUM COMMODITY ENTRIES
              </span>
              <div className="flex items-center space-x-2 text-xs font-mono">
                <span className="text-gray-500">SORT:</span>
                <span className="font-bold text-white border-b border-white cursor-pointer">ALPHABETICAL</span>
              </div>
            </div>

            {/* Product Card Container */}
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredCommodities.map((item) => {
                const appliedDiscount = getAppliedDiscount(item.moq, item);
                return (
                  <div
                    key={item.id}
                    id={`commodity-card-${item.id}`}
                    onClick={() => handleOpenProduct(item)}
                    className="bg-[#0E0E10] border border-[#2A2A2E] hover:border-[#E2FF00] rounded p-4 flex flex-col justify-between transition-all duration-150 cursor-pointer shadow-md text-white"
                  >
                    <div>
                      {/* Subcategory & Origin */}
                      <div className="flex justify-between items-center text-[10px] font-mono text-gray-500 mb-1">
                        <span>{item.subcategory.toUpperCase()}</span>
                        <span className="flex items-center">
                          <MapPin className="w-2.5 h-2.5 mr-0.5" />
                          {item.originCountry.toUpperCase()}
                        </span>
                      </div>

                      {/* Name */}
                      <h3 className="font-mono font-bold text-sm text-white leading-tight tracking-tight line-clamp-2 hover:text-[#E2FF00] min-h-[40px]">
                        {item.name}
                      </h3>

                      {/* Technical Specs Summary */}
                      <div className="mt-2 bg-[#151518] p-2 rounded text-[11px] font-mono text-gray-400 space-y-1">
                        <div className="flex justify-between">
                          <span>GRADE:</span>
                          <span className="text-gray-200 font-semibold">{item.grade}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>MOQ:</span>
                          <span className="text-gray-200">{item.moq} {item.unit.split(' ')[0]}</span>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 border-t border-[#2A2A2E] pt-3">
                      {/* Price Section */}
                      <div className="flex items-baseline justify-between">
                        <div>
                          <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">PRICE_EST</span>
                          <span className="text-base font-mono font-bold text-white">
                            ${item.pricePerUnit.toFixed(2)}
                          </span>
                          <span className="text-[10px] text-gray-500 font-mono"> / {item.unit.split(' ')[0]}</span>
                        </div>

                        {/* Direct Stock Indicator */}
                        <div className="text-right">
                          <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">AVAILABLE</span>
                          <span className="text-xs font-mono font-semibold text-emerald-400">
                            {item.availableQty.toLocaleString()} {item.unit.split(' ')[0]}
                          </span>
                        </div>
                      </div>

                      {/* Action trigger */}
                      <div className="mt-3 flex items-center justify-between text-xs font-mono font-semibold text-[#E2FF00] group">
                        <span>VIEW_SPECIFICATION_SHEET</span>
                        <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {filteredCommodities.length === 0 && (
              <div className="text-center py-16 bg-[#0E0E10] border border-dashed border-[#2A2A2E] rounded">
                <span className="text-sm font-mono text-gray-400 block mb-2">NO RECORDS MATCH THE SEARCH PARAMS</span>
                <button 
                  onClick={() => {
                    setSearchQuery('');
                    setSelectedCategory('All');
                    setSelectedOrigin('All');
                    setSelectedCert('All');
                  }}
                  className="bg-[#E2FF00] text-black text-xs font-mono font-semibold px-4 py-2 rounded"
                >
                  CLEAR_SEARCH_FILTERS
                </button>
              </div>
            )}
          </main>

        </div>
      </div>

      {/* 3. Product Specification Drawer / Details Sheet Modal */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 overflow-hidden" aria-labelledby="modal-title" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-[#0A0A0B]/80 transition-opacity" onClick={() => setSelectedProduct(null)}></div>

          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-2xl bg-[#0E0E10] border-l border-[#2A2A2E] flex flex-col shadow-2xl text-white">
              
              {/* Header */}
              <div className="bg-[#0A0A0B] text-white px-6 py-4 flex items-center justify-between border-b border-[#2A2A2E]">
                <div>
                  <span className="text-[10px] font-mono text-[#E2FF00] uppercase tracking-widest">{selectedProduct.category.toUpperCase()}</span>
                  <h2 className="text-lg font-mono font-bold text-white leading-tight mt-0.5">{selectedProduct.name}</h2>
                </div>
                <button 
                  onClick={() => setSelectedProduct(null)} 
                  className="text-gray-400 hover:text-white font-mono text-xs border border-[#2A2A2E] px-2 py-1 rounded"
                >
                  CLOSE [ESC]
                </button>
              </div>

              {/* Specs Scroll Panel */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                
                {/* Visual Header / Subtitle */}
                <div className="grid grid-cols-2 gap-4 border-b border-[#2A2A2E] pb-4">
                  <div>
                    <span className="text-[9px] font-mono text-gray-500 block uppercase">CATALOG SKU</span>
                    <span className="text-xs font-mono font-bold text-gray-300 block">{selectedProduct.sku}</span>
                  </div>
                  <div>
                    <span className="text-[9px] font-mono text-gray-500 block uppercase">ORIGIN / REGION</span>
                    <span className="text-xs font-mono font-semibold text-gray-300 block flex items-center">
                      <MapPin className="w-3.5 h-3.5 text-[#E2FF00] mr-1" />
                      {selectedProduct.productionRegion}, {selectedProduct.originCountry}
                    </span>
                  </div>
                </div>

                {/* Description */}
                <div>
                  <h4 className="text-[11px] font-mono uppercase tracking-widest text-gray-500 mb-1.5">Description</h4>
                  <p className="text-xs text-gray-400 leading-relaxed font-sans">{selectedProduct.description}</p>
                </div>

                {/* Grid of technical metrics */}
                <div>
                  <h4 className="text-[11px] font-mono uppercase tracking-widest text-gray-500 mb-2">Technical Properties</h4>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-[#151518] p-2.5 border border-[#2A2A2E] rounded">
                      <span className="text-[9px] font-mono text-gray-500 block">STANDARD GRADE</span>
                      <span className="text-xs font-mono font-bold text-gray-300">{selectedProduct.grade}</span>
                    </div>
                    <div className="bg-[#151518] p-2.5 border border-[#2A2A2E] rounded">
                      <span className="text-[9px] font-mono text-gray-500 block">AVAILABLE QUANTITY</span>
                      <span className="text-xs font-mono font-bold text-emerald-400">{selectedProduct.availableQty.toLocaleString()} {selectedProduct.unit}</span>
                    </div>
                    <div className="bg-[#151518] p-2.5 border border-[#2A2A2E] rounded">
                      <span className="text-[9px] font-mono text-gray-500 block">DIMENSION / TYPE SPEC</span>
                      <span className="text-xs font-mono font-normal text-gray-300">{selectedProduct.specification}</span>
                    </div>
                    <div className="bg-[#151518] p-2.5 border border-[#2A2A2E] rounded">
                      <span className="text-[9px] font-mono text-gray-500 block">MINIMUM ORDER (MOQ)</span>
                      <span className="text-xs font-mono font-bold text-gray-300">{selectedProduct.moq} {selectedProduct.unit.split(' ')[0]}</span>
                    </div>
                    <div className="bg-[#151518] p-2.5 border border-[#2A2A2E] rounded">
                      <span className="text-[9px] font-mono text-gray-500 block">PACKAGING SPEC</span>
                      <span className="text-xs font-mono text-gray-300">{selectedProduct.packaging}</span>
                    </div>
                    <div className="bg-[#151518] p-2.5 border border-[#2A2A2E] rounded">
                      <span className="text-[9px] font-mono text-gray-500 block">WAREHOUSE PICKUP</span>
                      <span className="text-xs font-mono text-gray-300">{selectedProduct.warehouseLocation}</span>
                    </div>
                  </div>
                </div>

                {/* Bulk Pricing Tiers */}
                <div>
                  <h4 className="text-[11px] font-mono uppercase tracking-widest text-gray-500 mb-2">Wholesale Bulk Tiers</h4>
                  <div className="border border-[#2A2A2E] rounded divide-y divide-[#2A2A2E]">
                    <div className="bg-[#151518] grid grid-cols-3 p-2 text-[10px] font-mono font-bold text-gray-400">
                      <span>ORDER THRESHOLD</span>
                      <span>APPLICABLE DISCOUNT</span>
                      <span>NET PRICE PER UNIT</span>
                    </div>
                    <div className="grid grid-cols-3 p-2.5 text-xs font-mono bg-[#0E0E10]">
                      <span>Standard MOQ ({selectedProduct.moq}+)</span>
                      <span className="text-gray-500">0.0%</span>
                      <span className="font-bold text-white">${selectedProduct.pricePerUnit.toFixed(2)}</span>
                    </div>
                    {selectedProduct.bulkDiscounts.map((tier, i) => (
                      <div key={i} className="grid grid-cols-3 p-2.5 text-xs font-mono bg-[#0E0E10]">
                        <span>{tier.qty}+ {selectedProduct.unit.split(' ')[0]}</span>
                        <span className="text-emerald-400 font-semibold">{tier.discountPercent.toFixed(1)}% OFF</span>
                        <span className="font-bold text-white">${(selectedProduct.pricePerUnit * (1 - tier.discountPercent / 100)).toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Documentation Downloads */}
                <div>
                  <h4 className="text-[11px] font-mono uppercase tracking-widest text-gray-500 mb-2">Verified Mill Documentation & Safety Data</h4>
                  <div className="space-y-1.5">
                    {selectedProduct.documents.map((doc, idx) => (
                      <div key={idx} className="flex items-center justify-between p-2.5 border border-[#2A2A2E] rounded bg-[#151518] hover:bg-black/40">
                        <div className="flex items-center space-x-2">
                          <FileText className="w-4 h-4 text-[#E2FF00]" />
                          <span className="text-xs font-mono text-gray-300">{doc.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] font-mono text-gray-500">{doc.type} ({doc.size})</span>
                          <button className="text-[#E2FF00] hover:text-[#f0ff66] p-1">
                            <Download className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Regulatory Compliance / Cert Badging */}
                <div>
                  <h4 className="text-[11px] font-mono uppercase tracking-widest text-gray-500 mb-1.5">Industry Certifications</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedProduct.certification.map((cert, idx) => (
                      <span key={idx} className="inline-flex items-center px-2.5 py-1 rounded text-xs font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                        <ShieldCheck className="w-3.5 h-3.5 mr-1 text-emerald-400" />
                        {cert}
                      </span>
                    ))}
                  </div>
                </div>

              </div>

              {/* Action footer */}
              <div className="border-t border-[#2A2A2E] p-6 bg-[#0E0E10] flex space-x-4">
                <button
                  id="direct-purchase-btn"
                  onClick={() => setIsBuyDrawerOpen(true)}
                  className="flex-1 bg-[#E2FF00] hover:bg-[#f0ff66] text-black text-center py-3 text-xs font-mono font-bold rounded uppercase tracking-wider transition-colors"
                >
                  DIRECT_SECURE_PURCHASE
                </button>
                <button
                  onClick={() => startRfqProcurement(selectedProduct)}
                  className="flex-1 bg-[#151518] hover:bg-black/50 text-white border border-[#2A2A2E] text-center py-3 text-xs font-mono font-bold rounded uppercase tracking-wider transition-all"
                >
                  NEGOTIATE_CUSTOM_RFQ
                </button>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* 4. Direct Purchase Execution Drawer (Slides inside Drawer) */}
      {isBuyDrawerOpen && selectedProduct && (
        <div className="fixed inset-0 z-55 overflow-hidden" aria-labelledby="buy-title" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-[#0A0A0B]/90 transition-opacity" onClick={() => setIsBuyDrawerOpen(false)}></div>

          <div className="absolute inset-y-0 right-0 max-w-full flex pl-10">
            <div className="w-screen max-w-lg bg-[#0E0E10] border-l border-[#2A2A2E] flex flex-col shadow-2xl text-white">
              
              <div className="bg-[#0A0A0B] text-white px-6 py-4 flex items-center justify-between border-b border-[#2A2A2E]">
                <span className="font-mono text-sm font-bold flex items-center">
                  <Package className="w-4 h-4 text-[#E2FF00] mr-2" />
                  INITIATE BILLING PROCEDURES
                </span>
                <button onClick={() => setIsBuyDrawerOpen(false)} className="text-gray-400 font-mono text-xs border border-[#2A2A2E] px-2 py-0.5 rounded">BACK</button>
              </div>

              {orderSuccess ? (
                <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mb-4">
                    <CheckCircle className="w-6 h-6 text-emerald-400 animate-bounce" />
                  </div>
                  <h3 className="font-mono font-bold text-lg text-white uppercase">Transaction Dispatched</h3>
                  <p className="text-xs text-gray-500 font-mono mt-1">ORDER ID: {lastOrderNumber}</p>
                  
                  {paymentMethod.includes('BTC') || paymentMethod.includes('USDT') ? (
                    <div className="mt-6 p-4 border border-[#2A2A2E] rounded bg-[#151518] flex flex-col items-center">
                      <span className="text-[9px] font-mono text-[#E2FF00] uppercase tracking-wider font-bold mb-2">Crypto Payment Invoice Generated</span>
                      <div className="bg-white p-2 border border-gray-300 rounded shadow-sm">
                        <QrCode className="w-24 h-24 text-black" />
                      </div>
                      <span className="text-[9px] font-mono text-gray-500 mt-2">Scan QR code or dispatch exact value to standard ledger. Platform waiting for blockchain confirmation.</span>
                    </div>
                  ) : (
                    <div className="mt-4 p-4 border border-dashed border-[#2A2A2E] rounded text-xs text-gray-400 font-sans max-w-sm">
                      Procurement request registered. Invoice dispatched to accounts payable. Payment settlement window pending as defined in standard terms.
                    </div>
                  )}

                  <span className="text-[10px] text-gray-500 font-mono mt-6">This window will close automatically...</span>
                </div>
              ) : (
                <div className="flex-1 overflow-y-auto p-6 space-y-5">
                  {/* Summary */}
                  <div className="bg-[#151518] border border-[#2A2A2E] p-4 rounded text-xs">
                    <span className="font-mono font-bold text-gray-400 uppercase">SPECIFICATION UNDER REVIEW</span>
                    <h4 className="font-mono text-white mt-1">{selectedProduct.name}</h4>
                    <span className="text-[10px] font-mono text-gray-500 mt-1 block">SKU: {selectedProduct.sku}</span>
                  </div>

                  {/* Quantity selector */}
                  <div>
                    <label className="text-[11px] font-mono font-bold uppercase text-gray-500 block mb-1">PROCURMENT QUANTITY</label>
                    <div className="flex items-center space-x-2">
                      <input
                        type="number"
                        id="buy-quantity-input"
                        value={buyQuantity}
                        onChange={(e) => setBuyQuantity(Math.max(selectedProduct.moq, parseInt(e.target.value) || 0))}
                        min={selectedProduct.moq}
                        className="flex-grow text-sm font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2.5 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      />
                      <span className="text-xs font-mono text-gray-400 font-semibold">{selectedProduct.unit}</span>
                    </div>
                    <span className="text-[10px] text-gray-500 font-mono mt-1 block">Minimum Order Requirement (MOQ) is {selectedProduct.moq} {selectedProduct.unit.split(' ')[0]}</span>
                  </div>

                  {/* Shipping terms */}
                  <div>
                    <label className="text-[11px] font-mono font-bold uppercase text-gray-500 block mb-1">INCOTERMS 2020 SHIPPING TERM</label>
                    <div className="grid grid-cols-4 gap-2">
                      {['FOB', 'CIF', 'EXW', 'DDP'].map((term) => {
                        const isAvailable = selectedProduct.shippingTerms.includes(term as any);
                        return (
                          <button
                            key={term}
                            onClick={() => isAvailable && setShippingTerm(term as any)}
                            disabled={!isAvailable}
                            className={`p-2 text-xs font-mono rounded text-center border transition-all ${
                              !isAvailable 
                                ? 'border-[#2A2A2E] bg-[#151518]/20 text-gray-600 cursor-not-allowed'
                                : shippingTerm === term
                                  ? 'bg-[#E2FF00] text-black border-[#E2FF00] font-bold'
                                  : 'border-[#2A2A2E] text-gray-300 hover:border-[#E2FF00] bg-[#151518]'
                            }`}
                          >
                            {term}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Payment settlement method */}
                  <div>
                    <label className="text-[11px] font-mono font-bold uppercase text-gray-500 block mb-1">SETTLEMENT METHOD</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { id: 'Bank Transfer', label: 'Bank Wire (SWIFT)' },
                        { id: 'Escrow', label: 'Escrow (Protected)' },
                        { id: 'Credit Account', label: 'Trade Credit (Net 30)' },
                        { id: 'Purchase Order', label: 'PO Approval' },
                        { id: 'Bitcoin (BTC)', label: 'Bitcoin (BTC)' },
                        { id: 'USDT', label: 'Tether (USDT TRC20)' }
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => setPaymentMethod(item.id as any)}
                          className={`p-2.5 text-xs text-left font-mono rounded border flex flex-col justify-between transition-all ${
                            paymentMethod === item.id
                              ? 'bg-[#151518] text-[#E2FF00] border-[#E2FF00] font-semibold shadow-sm'
                              : 'border-[#2A2A2E] text-gray-300 bg-[#0E0E10] hover:border-[#E2FF00]'
                          }`}
                        >
                          <span>{item.label}</span>
                          {item.id.includes('BTC') || item.id.includes('USDT') ? (
                            <span className="text-[8px] text-[#E2FF00] tracking-widest mt-1 block font-bold">CRYPTO</span>
                          ) : (
                            <span className="text-[8px] text-gray-500 mt-1 block">ENTERPRISE</span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Financial Settlement Breakdown */}
                  <div className="bg-[#0A0A0B] text-white p-4 rounded font-mono text-xs space-y-2 border border-[#2A2A2E]">
                    <span className="text-[9px] text-[#E2FF00] font-bold tracking-wider block">LEDGER CALCULATION</span>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Base Unit Rate:</span>
                      <span>${selectedProduct.pricePerUnit.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Total Units:</span>
                      <span>{buyQuantity.toLocaleString()} {selectedProduct.unit.split(' ')[0]}</span>
                    </div>
                    
                    {getAppliedDiscount(buyQuantity, selectedProduct) > 0 && (
                      <div className="flex justify-between text-emerald-400">
                        <span>Bulk Discount Applied:</span>
                        <span>-{getAppliedDiscount(buyQuantity, selectedProduct)}%</span>
                      </div>
                    )}
                    
                    <div className="border-t border-[#2A2A2E] pt-2 flex justify-between font-bold text-sm text-white">
                      <span>ESTIMATED TOTAL:</span>
                      <span className="text-[#E2FF00]">
                        ${(buyQuantity * selectedProduct.pricePerUnit * (1 - getAppliedDiscount(buyQuantity, selectedProduct) / 100)).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </span>
                    </div>
                  </div>

                </div>
              )}

              {/* Action Button */}
              {!orderSuccess && (
                <div className="p-6 border-t border-[#2A2A2E] bg-[#0E0E10]">
                  <button
                    id="confirm-dispatch-btn"
                    onClick={handleExecutePurchase}
                    className="w-full bg-[#E2FF00] text-black text-center py-3 text-xs font-mono font-bold rounded uppercase tracking-wider hover:bg-[#f0ff66] transition-colors"
                  >
                    CONFIRM_DISPATCH_ORDER
                  </button>
                </div>
              )}

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
