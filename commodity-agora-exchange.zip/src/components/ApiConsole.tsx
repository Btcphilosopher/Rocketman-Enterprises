/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Commodity, Order, Supplier, Rfq } from '../types';
import { 
  Terminal, 
  Database, 
  Send, 
  RefreshCw, 
  Layers, 
  Key, 
  FileCode, 
  Play, 
  CheckCircle,
  Code
} from 'lucide-react';

interface ApiConsoleProps {
  commodities: Commodity[];
  orders: Order[];
  suppliers: Supplier[];
  rfqs: Rfq[];
}

export default function ApiConsole({
  commodities,
  orders,
  suppliers,
  rfqs
}: ApiConsoleProps) {

  const [activeTab, setActiveTab] = useState<'api' | 'db'>('api');
  
  // API State
  const [selectedEndpoint, setSelectedEndpoint] = useState<'get-commodities' | 'get-suppliers' | 'post-rfq' | 'get-orders'>('get-commodities');
  const [apiResponse, setApiResponse] = useState<string>('// Select an endpoint and click execute to query the live ledger...');
  const [isApiLoading, setIsApiLoading] = useState(false);

  // DB State
  const [activeTable, setActiveTable] = useState<'companies' | 'commodities' | 'rfqs' | 'orders'>('commodities');
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM commodities WHERE available_qty > 1000;');
  const [sqlResults, setSqlResults] = useState<any[]>([]);
  const [sqlColumns, setSqlColumns] = useState<string[]>([]);
  const [sqlTerminalMsg, setSqlTerminalMsg] = useState('Agora Database Engine v12.4 running on localhost:5432...');

  // Endpoint documentation
  const endpoints = [
    {
      id: 'get-commodities',
      method: 'GET',
      path: '/api/v1/commodities',
      desc: 'Fetch all active certified commodities listings on the global trading board.',
      payload: 'None required. Supports query filters: category, origin, cert, moq_max.'
    },
    {
      id: 'get-suppliers',
      method: 'GET',
      path: '/api/v1/suppliers',
      desc: 'Retrieve verified profiles, annual capacities, and KYB statuses of global partners.',
      payload: 'None required.'
    },
    {
      id: 'post-rfq',
      method: 'POST',
      path: '/api/v1/rfq',
      desc: 'Dispatch a binding commercial requisition tender ticket (RFQ) to matching mills.',
      payload: '{\n  "commodityName": "string",\n  "category": "string",\n  "quantity": 100,\n  "unit": "string",\n  "deliveryLocation": "string",\n  "specifications": "string",\n  "budgetRange": "string"\n}'
    },
    {
      id: 'get-orders',
      method: 'GET',
      path: '/api/v1/orders',
      desc: 'Retrieve full audit log, payments, and shipping Incoterms for corporate accounts.',
      payload: 'Header Authorization Bearer token required.'
    }
  ];

  // Execute API Request Simulation
  const handleExecuteApi = () => {
    setIsApiLoading(true);
    setApiResponse('Connecting to secure gateway...');
    
    setTimeout(() => {
      setIsApiLoading(false);
      if (selectedEndpoint === 'get-commodities') {
        setApiResponse(JSON.stringify({
          status: 'success',
          timestamp: new Date().toISOString(),
          record_count: commodities.length,
          data: commodities.map(c => ({
            id: c.id,
            name: c.name,
            sku: c.sku,
            grade: c.grade,
            price_per_unit: c.pricePerUnit,
            unit_measure: c.unit,
            origin: c.originCountry,
            warehouse: c.warehouseLocation
          }))
        }, null, 2));
      } else if (selectedEndpoint === 'get-suppliers') {
        setApiResponse(JSON.stringify({
          status: 'success',
          timestamp: new Date().toISOString(),
          record_count: suppliers.length,
          data: suppliers.map(s => ({
            id: s.id,
            company_name: s.name,
            kyb_verified: s.verified,
            annual_capacity: s.capacityAnnually,
            certs: s.certifications,
            compliance_status: s.complianceStatus
          }))
        }, null, 2));
      } else if (selectedEndpoint === 'post-rfq') {
        setApiResponse(JSON.stringify({
          status: 'success',
          timestamp: new Date().toISOString(),
          message: 'Procurement tender ticket registered successfully. Competitive bidding triggered.',
          rfq_reference_id: 'RFQ-' + Math.floor(200 + Math.random() * 800),
          estimated_bidding_dispatch_seconds: 3
        }, null, 2));
      } else if (selectedEndpoint === 'get-orders') {
        setApiResponse(JSON.stringify({
          status: 'success',
          timestamp: new Date().toISOString(),
          record_count: orders.length,
          orders: orders.map(o => ({
            order_id: o.id,
            buyer: o.buyerCompany,
            supplier: o.supplierName,
            commodity: o.commodityName,
            total_price_usd: o.totalPrice,
            shipping_incoterm: o.shippingTerms,
            shipping_status: o.status
          }))
        }, null, 2));
      }
    }, 800);
  };

  // Run SQL Emulator Presets
  const handleRunPresetSql = (type: 'all-metals' | 'escrow-totals' | 'pending-audits' | 'walnut-specs') => {
    if (type === 'all-metals') {
      setSqlQuery("SELECT sku, name, price_per_unit, available_qty FROM commodities WHERE category = 'Metals';");
      setSqlColumns(['sku', 'name', 'price_per_unit', 'available_qty']);
      setSqlResults(
        commodities
          .filter(c => c.category === 'Metals')
          .map(c => ({
            sku: c.sku,
            name: c.name.substring(0, 30) + '...',
            price_per_unit: `$${c.pricePerUnit.toFixed(2)}`,
            available_qty: c.availableQty.toLocaleString()
          }))
      );
      setSqlTerminalMsg('Query executed successfully. (2 rows returned in 1.4ms)');
    } else if (type === 'escrow-totals') {
      setSqlQuery("SELECT SUM(total_price) AS escrow_totals_usd FROM orders WHERE payment_status = 'escrowed';");
      setSqlColumns(['escrow_totals_usd']);
      const sum = orders.filter(o => o.paymentStatus === 'escrowed').reduce((acc, c) => acc + c.totalPrice, 0);
      setSqlResults([{ escrow_totals_usd: `$${sum.toLocaleString(undefined, { minimumFractionDigits: 2 })}` }]);
      setSqlTerminalMsg('Aggregation query complete. (1 row returned in 0.8ms)');
    } else if (type === 'pending-audits') {
      setSqlQuery("SELECT name, location, compliance_status FROM companies WHERE compliance_status != 'Verified';");
      setSqlColumns(['name', 'location', 'compliance_status']);
      const nonVerified = suppliers.filter(s => s.complianceStatus !== 'Verified');
      setSqlResults(
        nonVerified.length > 0 
          ? nonVerified.map(s => ({ name: s.name, location: s.location, compliance_status: s.complianceStatus }))
          : [{ name: 'None', location: 'N/A', compliance_status: 'All clear' }]
      );
      setSqlTerminalMsg('Audit select scan finalized. (0-1 rows returned in 2.1ms)');
    } else if (type === 'walnut-specs') {
      setSqlQuery("SELECT name, grade, origin_country, moq FROM commodities WHERE name LIKE '%Walnut%';");
      setSqlColumns(['name', 'grade', 'origin_country', 'moq']);
      setSqlResults(
        commodities
          .filter(c => c.name.includes('Walnut'))
          .map(c => ({
            name: c.name.substring(0, 25),
            grade: c.grade,
            origin_country: c.originCountry,
            moq: `${c.moq} BF`
          }))
      );
      setSqlTerminalMsg('Text pattern scanning finalized. (1 row returned in 1.9ms)');
    }
  };

  // Run Custom typed SQL (simulated)
  const handleExecuteCustomSql = (e: React.FormEvent) => {
    e.preventDefault();
    setSqlTerminalMsg('Analyzing abstract syntax tree...');
    
    setTimeout(() => {
      // Direct execution simulation for standard query inputs
      if (sqlQuery.toLowerCase().includes('commodities')) {
        handleRunPresetSql('all-metals');
      } else if (sqlQuery.toLowerCase().includes('orders') || sqlQuery.toLowerCase().includes('escrow')) {
        handleRunPresetSql('escrow-totals');
      } else if (sqlQuery.toLowerCase().includes('companies') || sqlQuery.toLowerCase().includes('compliance')) {
        handleRunPresetSql('pending-audits');
      } else {
        setSqlTerminalMsg("ERROR: table or column match failure. Check schema map on sidebar.");
        setSqlResults([]);
        setSqlColumns([]);
      }
    }, 400);
  };

  return (
    <div className="bg-[#fcfbf9] text-[#1a1c20] min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Card */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-gray-200 pb-5 mb-6">
          <div>
            <span className="text-[10px] font-mono text-[#b38a38] uppercase tracking-widest font-bold">DEVELOPER TOOLKIT & SCHEMA AUDITING</span>
            <h1 className="text-2xl font-mono font-bold text-gray-900 tracking-tight mt-0.5">API & DATABASE WORKSPACE</h1>
            <p className="text-xs text-gray-500 font-sans mt-1">
              Verify database relational mappings, inspect standard SQL schemas, and run live interactive REST API triggers.
            </p>
          </div>
        </div>

        {/* Console View Tabs */}
        <div className="border-b border-gray-200 mb-6 flex space-x-1">
          {[
            { id: 'api', label: 'INTERACTIVE REST API DOCS', icon: Code },
            { id: 'db', label: 'POSTGRESQL SCHEMA WORKBENCH', icon: Database }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                id={`developer-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center px-4 py-2 text-xs font-mono font-bold transition-all relative border-b-2 ${
                  activeTab === tab.id 
                    ? 'border-[#b38a38] text-[#b38a38] bg-white' 
                    : 'border-transparent text-gray-500 hover:text-gray-900'
                }`}
              >
                <Icon className="w-4 h-4 mr-1.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* REST API PANEL */}
        {activeTab === 'api' && (
          <div className="grid lg:grid-cols-5 gap-6">
            
            {/* Left: Endpoint selector */}
            <div className="lg:col-span-2 space-y-3.5">
              <span className="text-[11px] font-mono tracking-wider text-gray-400 block font-bold uppercase">AVAILABLE B2B INTERFACES</span>
              
              <div className="space-y-2">
                {endpoints.map((ep) => (
                  <div
                    key={ep.id}
                    id={`api-ep-${ep.id}`}
                    onClick={() => {
                      setSelectedEndpoint(ep.id as any);
                      setApiResponse('// Click execute query to invoke live ledger endpoint...');
                    }}
                    className={`p-3.5 border rounded cursor-pointer transition-all ${
                      selectedEndpoint === ep.id
                        ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                        : 'bg-white border-gray-200 hover:border-gray-400'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-mono font-bold ${
                        ep.method === 'GET' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-blue-500/10 text-blue-400'
                      }`}>
                        {ep.method}
                      </span>
                      <span className="font-mono text-xs font-semibold">{ep.path}</span>
                    </div>
                    <p className={`text-[11px] font-sans mt-2 leading-relaxed ${
                      selectedEndpoint === ep.id ? 'text-gray-300' : 'text-gray-500'
                    }`}>
                      {ep.desc}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Right: API Interactive terminal */}
            <div className="lg:col-span-3 flex flex-col justify-between bg-[#0f1115] border border-gray-800 rounded shadow-lg overflow-hidden h-[480px]">
              
              {/* Terminal header */}
              <div className="bg-[#0b0c0e] px-4 py-3 border-b border-gray-800 flex justify-between items-center">
                <span className="font-mono text-[10px] text-gray-400 tracking-wider">SECURE ENDPOINT PLAYGROUND gateway:3000</span>
                <button
                  id="execute-api-btn"
                  onClick={handleExecuteApi}
                  disabled={isApiLoading}
                  className="bg-[#b38a38] text-black text-[10px] font-mono font-bold px-3 py-1 rounded flex items-center hover:bg-[#c99f48] transition-colors"
                >
                  <Play className="w-3 h-3 mr-1" />
                  {isApiLoading ? 'CONNECTING...' : 'RUN_QUERY'}
                </button>
              </div>

              {/* Endpoint configuration / body detail */}
              <div className="p-4 bg-[#141820] border-b border-gray-800/80 text-[11px] font-mono text-gray-400">
                <div className="flex justify-between">
                  <span>PAYLOAD PARAMS:</span>
                  <span className="text-[#b38a38] font-bold">TYPE: application/json</span>
                </div>
                <pre className="text-[10px] text-gray-300 bg-[#0f1115] p-2 rounded border border-gray-800 mt-1.5 overflow-x-auto whitespace-pre-wrap">
                  {endpoints.find(e => e.id === selectedEndpoint)?.payload}
                </pre>
              </div>

              {/* Console log outputs */}
              <div className="flex-1 p-4 overflow-y-auto font-mono text-[11px] text-emerald-400">
                <pre className="whitespace-pre-wrap font-mono text-[10px] leading-relaxed">
                  {apiResponse}
                </pre>
              </div>

            </div>

          </div>
        )}

        {/* POSTGRESQL SCHEMA WORKBENCH */}
        {activeTab === 'db' && (
          <div className="grid lg:grid-cols-4 gap-6">
            
            {/* Database schema layout sidebar */}
            <div className="lg:col-span-1 bg-white p-4 border border-gray-200 rounded shadow-sm space-y-4">
              <span className="text-[11px] font-mono tracking-wider text-gray-400 block font-bold uppercase">DATABASE SCHEMA (PostgreSQL)</span>
              
              <div className="space-y-3 font-mono text-xs text-gray-600">
                
                {/* Users Table */}
                <div className="border border-gray-100 p-2 rounded bg-gray-50/50">
                  <span className="font-bold text-gray-800 flex items-center">
                    <Database className="w-3.5 h-3.5 mr-1 text-[#b38a38]" />
                    companies
                  </span>
                  <div className="mt-1.5 pl-4 border-l border-gray-200 text-[10px] space-y-1 text-gray-400">
                    <div>id <span className="text-[#b38a38]">UUID [PK]</span></div>
                    <div>name <span className="text-gray-500">VARCHAR</span></div>
                    <div>verified <span className="text-gray-500">BOOLEAN</span></div>
                    <div>compliance_status <span className="text-gray-500">VARCHAR</span></div>
                  </div>
                </div>

                {/* Commodities Table */}
                <div className="border border-gray-100 p-2 rounded bg-gray-50/50">
                  <span className="font-bold text-gray-800 flex items-center">
                    <Database className="w-3.5 h-3.5 mr-1 text-[#b38a38]" />
                    commodities
                  </span>
                  <div className="mt-1.5 pl-4 border-l border-gray-200 text-[10px] space-y-1 text-gray-400">
                    <div>id <span className="text-[#b38a38]">UUID [PK]</span></div>
                    <div>sku <span className="text-gray-500">VARCHAR [Unique]</span></div>
                    <div>name <span className="text-gray-500">VARCHAR</span></div>
                    <div>price_per_unit <span className="text-gray-500">NUMERIC</span></div>
                    <div>available_qty <span className="text-gray-500">NUMERIC</span></div>
                    <div>supplier_id <span className="text-blue-500">UUID [FK]</span></div>
                  </div>
                </div>

                {/* Orders Table */}
                <div className="border border-gray-100 p-2 rounded bg-gray-50/50">
                  <span className="font-bold text-gray-800 flex items-center">
                    <Database className="w-3.5 h-3.5 mr-1 text-[#b38a38]" />
                    orders
                  </span>
                  <div className="mt-1.5 pl-4 border-l border-gray-200 text-[10px] space-y-1 text-gray-400">
                    <div>id <span className="text-[#b38a38]">UUID [PK]</span></div>
                    <div>buyer_company <span className="text-gray-500">VARCHAR</span></div>
                    <div>total_price <span className="text-gray-500">NUMERIC</span></div>
                    <div>payment_status <span className="text-gray-500">VARCHAR</span></div>
                  </div>
                </div>

              </div>
            </div>

            {/* SQL Terminal Sandbox Console */}
            <div className="lg:col-span-3 space-y-4">
              
              {/* Sandbox terminal */}
              <div className="bg-[#0f1115] border border-gray-800 rounded shadow-lg overflow-hidden flex flex-col justify-between">
                
                {/* Terminal Header */}
                <div className="bg-[#0b0c0e] px-4 py-3 border-b border-gray-800 flex justify-between items-center text-[10px] font-mono text-gray-400">
                  <span>SQL INTERACTIVE RUNTIME TERMINAL</span>
                  <span className="text-[#b38a38] font-bold">PostgreSQL Localhost:5432</span>
                </div>

                {/* Quick select presets */}
                <div className="bg-[#141820] border-b border-gray-800 px-4 py-2.5 flex flex-wrap gap-2 text-[10px] font-mono">
                  <span className="text-gray-400 self-center">EXEC PRESET:</span>
                  <button 
                    onClick={() => handleRunPresetSql('all-metals')} 
                    className="bg-[#242d3c] hover:bg-slate-700 text-gray-200 px-2.5 py-1 rounded"
                  >
                    Select Metals
                  </button>
                  <button 
                    onClick={() => handleRunPresetSql('escrow-totals')} 
                    className="bg-[#242d3c] hover:bg-slate-700 text-gray-200 px-2.5 py-1 rounded"
                  >
                    Escrow Totals
                  </button>
                  <button 
                    onClick={() => handleRunPresetSql('pending-audits')} 
                    className="bg-[#242d3c] hover:bg-slate-700 text-gray-200 px-2.5 py-1 rounded"
                  >
                    Audit Compliance
                  </button>
                  <button 
                    onClick={() => handleRunPresetSql('walnut-specs')} 
                    className="bg-[#242d3c] hover:bg-slate-700 text-gray-200 px-2.5 py-1 rounded"
                  >
                    Walnut Slabs
                  </button>
                </div>

                {/* Form raw input */}
                <form onSubmit={handleExecuteCustomSql} className="bg-[#1a1f2c] p-4 flex space-x-3 border-b border-gray-800">
                  <span className="text-[#b38a38] font-mono font-bold self-center text-sm">agora=#</span>
                  <input
                    type="text"
                    id="sql-query-input"
                    value={sqlQuery}
                    onChange={(e) => setSqlQuery(e.target.value)}
                    className="flex-grow bg-transparent text-xs text-white font-mono focus:outline-none placeholder-gray-600"
                    placeholder="Type raw SQL (e.g. SELECT * FROM commodities;)"
                  />
                  <button 
                    type="submit"
                    className="bg-[#b38a38] text-black font-mono text-[10px] font-bold px-3 py-1.5 rounded uppercase"
                  >
                    RUN_SQL
                  </button>
                </form>

                {/* Terminal status line */}
                <div className="p-3 bg-[#0d1017] text-[10px] font-mono text-gray-400 border-b border-gray-800">
                  {sqlTerminalMsg}
                </div>

                {/* Output results structured spreadsheet tab */}
                <div className="overflow-x-auto max-h-52 bg-[#0d1017] p-4 min-h-[140px]">
                  {sqlResults.length > 0 ? (
                    <table className="w-full text-left font-mono text-[10px] text-gray-300">
                      <thead className="border-b border-gray-800 text-[#b38a38] uppercase">
                        <tr>
                          {sqlColumns.map((col, idx) => (
                            <th key={idx} className="pb-2 px-2">{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-800/50">
                        {sqlResults.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-900/35">
                            {sqlColumns.map((col, cIdx) => (
                              <td key={cIdx} className="py-2 px-2">{row[col]}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    <div className="text-center py-8 text-gray-500 text-[10px] font-mono">
                      // Terminal waiting for query release. Enter a raw SQL execution above or pick one of the active presets.
                    </div>
                  )}
                </div>

              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
