/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Order, Supplier, Rfq } from '../types';
import { 
  Briefcase, 
  Truck, 
  CreditCard, 
  Users, 
  Award, 
  FileCheck, 
  FileText, 
  ArrowUpRight,
  TrendingUp,
  MapPin,
  Clock,
  ExternalLink
} from 'lucide-react';

interface BuyerDashboardProps {
  orders: Order[];
  suppliers: Supplier[];
  rfqs: Rfq[];
  onApproveOrder: (orderId: string) => void;
  onCancelOrder: (orderId: string) => void;
}

export default function BuyerDashboard({
  orders,
  suppliers,
  rfqs,
  onApproveOrder,
  onCancelOrder
}: BuyerDashboardProps) {

  const [activeTab, setActiveTab] = useState<'orders' | 'approvals' | 'ledger' | 'team'>('orders');

  // Simulated Team Members
  const teamMembers = [
    { name: 'Tom Higgins', role: 'Procurement Director', email: 'tom@ahyx.org', limit: '$500,000' },
    { name: 'Sarah Jenkins', role: 'Chief Financial Officer', email: 's.jenkins@ahyx.org', limit: 'UNLIMITED' },
    { name: 'Marcus Vance', role: 'Logistics Specialist', email: 'm.vance@ahyx.org', limit: '$50,000' }
  ];

  // Filtering orders that require approvals (amount > 100K or Net 30 with status pending_approval)
  const pendingApprovals = orders.filter(o => o.status === 'pending_approval');

  // Invoices summary
  const totalSpend = orders
    .filter(o => o.status !== 'cancelled')
    .reduce((acc, curr) => acc + curr.totalPrice, 0);

  return (
    <div className="bg-[#0A0A0B] text-[#F0F0F0] min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Dashboard Title Block */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#2A2A2E] pb-5 mb-6">
          <div>
            <span className="text-[10px] font-mono text-[#E2FF00] uppercase tracking-widest font-bold">ORGANIZATION: AHYX PROCUREMENT SOLUTIONS</span>
            <h1 className="text-2xl font-mono font-bold text-white tracking-tight mt-0.5">BUYER PROCURE_FLOW TERMINAL</h1>
            <p className="text-xs text-gray-400 font-sans mt-1">
              Verify pending physical contracts, authorize wire dispatches, manage logistics channels, and review audit logs.
            </p>
          </div>
          
          {/* Quick Metrics */}
          <div className="mt-4 md:mt-0 flex space-x-6 text-right">
            <div>
              <span className="text-[10px] font-mono text-gray-500 block uppercase">TOTAL PORTFOLIO SPEND</span>
              <span className="text-lg font-mono font-bold text-white">${totalSpend.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            <div>
              <span className="text-[10px] font-mono text-gray-500 block uppercase">COMMITTED ESCROWS</span>
              <span className="text-lg font-mono font-bold text-[#E2FF00]">
                ${orders.filter(o => o.paymentStatus === 'escrowed').reduce((acc, c) => acc + c.totalPrice, 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Dense Navigation Tabs */}
        <div className="border-b border-[#2A2A2E] mb-6 flex space-x-1">
          {[
            { id: 'orders', label: 'COMMODITY CONTRACTS', count: orders.length, icon: Truck },
            { id: 'approvals', label: 'SIGN-OFF APPROVALS', count: pendingApprovals.length, icon: FileCheck },
            { id: 'ledger', label: 'FINANCIAL LEDGER', count: null, icon: CreditCard },
            { id: 'team', label: 'PROCUREMENT TEAM', count: teamMembers.length, icon: Users }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                id={`buyer-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center px-4 py-2 text-xs font-mono font-bold transition-all relative border-b-2 ${
                  activeTab === tab.id 
                    ? 'border-[#E2FF00] text-[#E2FF00] bg-[#0E0E10]' 
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 mr-1.5" />
                {tab.label}
                {tab.count !== null && (
                  <span className={`ml-2 px-1.5 py-0.5 text-[9px] rounded-full font-mono ${
                    activeTab === tab.id ? 'bg-[#E2FF00]/20 text-[#E2FF00]' : 'bg-[#151518] text-gray-400'
                  }`}>
                    {tab.count}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            
            {/* Active Shipments Card Board */}
            <div className="grid md:grid-cols-2 gap-4">
              {orders.filter(o => o.status === 'shipped' || o.status === 'processing').map((order) => (
                <div key={order.id} className="bg-[#0E0E10] border border-[#2A2A2E] p-4 rounded shadow-sm text-white">
                  <div className="flex justify-between items-center text-[10px] font-mono text-gray-500 mb-2">
                    <span>CONTRACT REF: {order.id}</span>
                    <span className="flex items-center text-amber-400 font-bold uppercase">
                      <Clock className="w-3 h-3 mr-1" />
                      PHYSICAL_FLOW: {order.status}
                    </span>
                  </div>

                  <h3 className="font-mono font-bold text-sm text-white">{order.commodityName}</h3>
                  <p className="text-xs text-gray-400 font-mono mt-1">Supplier: {order.supplierName}</p>

                  <div className="mt-4 grid grid-cols-2 gap-3 bg-[#151518] p-2.5 rounded text-xs font-mono text-gray-400 border border-[#2A2A2E]">
                    <div>
                      <span>VOLUME DISPATCH:</span>
                      <span className="block text-gray-200 font-semibold">{order.quantity.toLocaleString()} {order.unit}</span>
                    </div>
                    <div>
                      <span>SHIPMENT PORT:</span>
                      <span className="block text-gray-200 font-semibold">{order.warehouse}</span>
                    </div>
                    {order.trackingNumber && (
                      <div className="col-span-2 border-t border-[#2A2A2E] pt-2 flex justify-between items-center text-[11px]">
                        <span>LOGISTICS ID: <span className="text-gray-200 font-semibold">{order.trackingNumber}</span></span>
                        <span>ETA: <span className="text-emerald-400 font-semibold">{order.eta}</span></span>
                      </div>
                    )}
                  </div>

                  <div className="mt-4 flex justify-between items-center text-xs font-mono pt-2 border-t border-[#2A2A2E]">
                    <div>
                      <span className="text-gray-500 block text-[9px] uppercase">CONTRACT VALUE</span>
                      <span className="text-white font-bold">${order.totalPrice.toLocaleString()}</span>
                    </div>
                    <span className="text-[#E2FF00] underline cursor-pointer hover:text-white flex items-center">
                      BILL_OF_LADING.PDF
                      <ExternalLink className="w-3 h-3 ml-1" />
                    </span>
                  </div>
                </div>
              ))}

              {orders.filter(o => o.status === 'shipped' || o.status === 'processing').length === 0 && (
                <div className="col-span-2 text-center py-12 border border-dashed border-[#2A2A2E] rounded text-gray-500 text-xs font-mono bg-[#0E0E10]">
                  NO ACTIVE PHYSICAL SHIPMENTS DISPATCHED IN CURRENT RUN
                </div>
              )}
            </div>

            {/* Standard Invoices / Historical Records Table */}
            <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded shadow-sm overflow-hidden">
              <div className="bg-[#0E0E10] border-b border-[#2A2A2E] px-6 py-4 flex justify-between items-center">
                <span className="font-mono text-xs font-bold tracking-wider text-white">HISTORICAL COMMERCIAL LEDGER</span>
                <span className="text-[10px] font-mono text-gray-500">DOUBLE_ENTRY COMPLIANT</span>
              </div>
              
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs font-mono">
                  <thead className="bg-[#0A0A0B] border-b border-[#2A2A2E] text-[10px] text-gray-500 uppercase tracking-widest">
                    <tr>
                      <th className="px-6 py-3">Contract Code</th>
                      <th className="px-6 py-3">Commodity Spec</th>
                      <th className="px-6 py-3">Supplier Name</th>
                      <th className="px-6 py-3">Vol</th>
                      <th className="px-6 py-3">Terms</th>
                      <th className="px-6 py-3">Settle Amt</th>
                      <th className="px-6 py-3">Status</th>
                      <th className="px-6 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#2A2A2E] text-gray-300">
                    {orders.map((order) => (
                      <tr key={order.id} className="hover:bg-[#151518]/50">
                        <td className="px-6 py-3.5 font-bold text-white">{order.id}</td>
                        <td className="px-6 py-3.5 font-semibold text-white">{order.commodityName}</td>
                        <td className="px-6 py-3.5 text-gray-400">{order.supplierName}</td>
                        <td className="px-6 py-3.5">{order.quantity} {order.unit.split(' ')[0]}</td>
                        <td className="px-6 py-3.5">{order.shippingTerms}</td>
                        <td className="px-6 py-3.5 font-bold text-white">${order.totalPrice.toLocaleString()}</td>
                        <td className="px-6 py-3.5">
                          <span className={`inline-flex px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                            order.status === 'delivered' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
                            order.status === 'shipped' ? 'bg-blue-500/10 text-blue-400' :
                            order.status === 'pending_approval' ? 'bg-amber-500/10 text-amber-400 animate-pulse' : 'bg-gray-800 text-gray-400'
                          }`}>
                            {order.status}
                          </span>
                        </td>
                        <td className="px-6 py-3.5 text-right">
                          <button 
                            onClick={() => onCancelOrder(order.id)}
                            className="text-red-400 hover:text-red-300 hover:underline font-semibold"
                            disabled={order.status === 'shipped' || order.status === 'delivered'}
                          >
                            {order.status === 'shipped' || order.status === 'delivered' ? '-' : 'VOID_CONTRACT'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {activeTab === 'approvals' && (
          <div className="space-y-4">
            <span className="text-[11px] font-mono tracking-wider text-gray-500 block font-bold uppercase">SIGN-OFF AUTHORIZATION DESK</span>
            
            {pendingApprovals.map((order) => (
              <div key={order.id} id={`approval-card-${order.id}`} className="bg-[#0E0E10] border border-[#2A2A2E] rounded p-5 shadow-sm space-y-4 text-white">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#2A2A2E] pb-3">
                  <div>
                    <span className="text-[9px] font-mono text-amber-400 block font-bold uppercase tracking-wider">▲ EXCEEDS STANDARD PROCUREMENT THRESHOLD</span>
                    <h3 className="font-mono font-bold text-sm text-white mt-1">{order.commodityName}</h3>
                    <span className="text-[10px] font-mono text-gray-500 block">CONTRACT REF: {order.id} | REQUESTED BY: Tom Higgins</span>
                  </div>

                  <div className="text-right mt-2 md:mt-0">
                    <span className="text-[9px] font-mono text-gray-500 uppercase tracking-wider block">CONTRACT VALUE</span>
                    <span className="text-lg font-mono font-bold text-white">${order.totalPrice.toLocaleString()}</span>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-4 text-xs font-mono text-gray-400">
                  <div className="bg-[#151518] p-2.5 rounded border border-[#2A2A2E]">
                    <span className="text-[9px] text-gray-500 block">SUPPLIER</span>
                    <span className="font-semibold text-gray-200">{order.supplierName}</span>
                  </div>
                  <div className="bg-[#151518] p-2.5 rounded border border-[#2A2A2E]">
                    <span className="text-[9px] text-gray-500 block">SETTLEMENT METHOD</span>
                    <span className="font-semibold text-gray-200">{order.paymentMethod}</span>
                  </div>
                  <div className="bg-[#151518] p-2.5 rounded border border-[#2A2A2E]">
                    <span className="text-[9px] text-gray-500 block">SHIPPING TERMS (INCOTERMS)</span>
                    <span className="font-semibold text-gray-200">{order.shippingTerms} ({order.warehouse})</span>
                  </div>
                </div>

                <div className="bg-[#151518] border border-dashed border-[#2A2A2E] p-3 rounded text-[11px] text-gray-400 font-sans">
                  <span className="font-mono font-bold text-[#E2FF00] block mb-1">AUDIT VERIFICATION GUIDELINE:</span>
                  This is a Net-30 Trade Credit or PO purchase. Placing this contract executes a corporate liability ledger. Check that shipping destinations hold active custom clearings.
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    onClick={() => onCancelOrder(order.id)}
                    className="border border-[#2A2A2E] text-gray-400 hover:text-white text-xs font-mono px-4 py-2 rounded uppercase hover:bg-[#151518]"
                  >
                    REJECT_CONTRACT_VOID
                  </button>
                  <button
                    id={`approve-btn-${order.id}`}
                    onClick={() => onApproveOrder(order.id)}
                    className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black text-xs font-mono font-bold px-4 py-2 rounded uppercase tracking-wider transition-colors"
                  >
                    AUTHORIZE_SIGN_OFF
                  </button>
                </div>
              </div>
            ))}

            {pendingApprovals.length === 0 && (
              <div className="bg-[#0E0E10] border border-dashed border-[#2A2A2E] rounded p-16 text-center text-gray-500 text-xs font-mono">
                NO CONTRACTS OUTSTANDING FOR CORPORATE SIGN-OFF
              </div>
            )}
          </div>
        )}

        {activeTab === 'ledger' && (
          <div className="space-y-6">
            
            {/* Ledger status cards */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-[#0E0E10] text-white p-5 rounded border border-[#2A2A2E]">
                <span className="text-[10px] font-mono text-[#E2FF00] block tracking-widest">SWIFT CORPORATE ACCOUNT</span>
                <span className="text-xs font-mono text-gray-400 block mt-1">Settle Account: Deutsche Bank AG</span>
                <span className="text-xl font-mono font-bold text-white block mt-3">$2,450,000.00</span>
                <span className="text-[9px] text-gray-500 block mt-1">AVAILABLE CREDIT LINE</span>
              </div>
              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-5 rounded text-white">
                <span className="text-[10px] font-mono text-gray-400 block tracking-widest">TOTAL ESCROWED RESERVE</span>
                <span className="text-xs font-mono text-gray-400 block mt-1">Safeguarded trade funds</span>
                <span className="text-xl font-mono font-bold text-[#E2FF00] block mt-3">
                  ${orders.filter(o => o.paymentStatus === 'escrowed').reduce((acc, c) => acc + c.totalPrice, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
                <span className="text-[9px] text-emerald-400 block mt-1">✓ Released on digital BOL signature</span>
              </div>
              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-5 rounded text-white">
                <span className="text-[10px] font-mono text-gray-400 block tracking-widest">OUTSTANDING INVOICES</span>
                <span className="text-xs font-mono text-gray-400 block mt-1">Pending payments due Net-30</span>
                <span className="text-xl font-mono font-bold text-white block mt-3">
                  ${orders.filter(o => o.paymentStatus === 'pending').reduce((acc, c) => acc + c.totalPrice, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                </span>
                <span className="text-[9px] text-amber-400 block mt-1">⚠️ Wire settlements pending processing</span>
              </div>
            </div>

            {/* Invoices list */}
            <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded p-6 shadow-sm">
              <span className="text-xs font-mono text-gray-400 block mb-4 uppercase">PENDING BANK SETTLEMENTS & DEPOSIT INSTRUCTIONS</span>
              
              <div className="space-y-3">
                {orders.filter(o => o.paymentStatus === 'pending').map((o) => (
                  <div key={o.id} className="p-4 border border-[#2A2A2E] rounded bg-[#151518] flex flex-col md:flex-row justify-between items-start md:items-center text-white">
                    <div className="font-mono text-xs">
                      <span className="font-bold text-white block">DEPOSIT SLIP REFERENCE: #DEP-{o.id}</span>
                      <span className="text-gray-400 block mt-0.5">Commodity: {o.commodityName} | Supplier: {o.supplierName}</span>
                    </div>

                    <div className="mt-2 md:mt-0 text-left md:text-right font-mono">
                      <span className="text-base font-bold text-white block">${o.totalPrice.toLocaleString()}</span>
                      <span className="text-[10px] text-[#E2FF00] font-bold block">Action Required: Settle Wire</span>
                    </div>
                  </div>
                ))}

                {orders.filter(o => o.paymentStatus === 'pending').length === 0 && (
                  <div className="text-center py-6 text-gray-500 text-xs font-mono border border-dashed border-[#2A2A2E] rounded bg-[#0E0E10]">
                    NO OUTSTANDING SETTLEMENT RECORDS IN CURRENT LEDGER
                  </div>
                )}
              </div>
            </div>

          </div>
        )}

        {activeTab === 'team' && (
          <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded p-6 shadow-sm text-white">
            <div className="flex justify-between items-center border-b border-[#2A2A2E] pb-4 mb-4">
              <div>
                <span className="text-xs font-mono text-gray-500 block uppercase">DELEGATED PURCHASING OFFICE</span>
                <h3 className="font-mono font-bold text-base text-white">AHYX ORGANIZATIONAL GROUP</h3>
              </div>
              <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                ACTIVE COHORT MEMBERS
              </span>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              {teamMembers.map((member, i) => (
                <div key={i} className="p-4 border border-[#2A2A2E] rounded bg-[#151518] flex flex-col justify-between min-h-[120px] text-white">
                  <div>
                    <span className="font-mono font-bold text-sm text-white block">{member.name}</span>
                    <span className="font-mono text-[11px] text-gray-400 block">{member.role}</span>
                    <span className="font-sans text-xs text-gray-500 mt-1 block">{member.email}</span>
                  </div>

                  <div className="border-t border-[#2A2A2E] pt-2.5 mt-3 text-[10px] font-mono flex justify-between">
                    <span className="text-gray-500 uppercase">SIGN-OFF LIMIT:</span>
                    <span className="text-[#E2FF00] font-bold">{member.limit}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
