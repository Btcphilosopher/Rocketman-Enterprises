/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { BookOpen, Scale, Landmark, Truck, ShieldAlert, Mail } from 'lucide-react';

export default function GeneralInfo() {
  const [activeTab, setActiveTab] = useState<'manifesto' | 'incoterms' | 'pricing' | 'faq'>('manifesto');

  return (
    <div className="bg-[#fcfbf9] text-[#1a1c20] min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title Block */}
        <div className="border-b border-gray-200 pb-5 mb-6">
          <span className="text-[10px] font-mono text-[#b38a38] uppercase tracking-widest font-bold">EDUCATIONAL DECK & PLATFORM STANDARDS</span>
          <h1 className="text-2xl font-mono font-bold text-gray-900 tracking-tight mt-0.5">DOCUMENTATION & RESOURCES</h1>
          <p className="text-xs text-gray-500 font-sans mt-1">
            Examine commodity settlement fees, study maritime logistics terms, or read the operational manifesto of Agora Exchange.
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-gray-200 mb-6 flex space-x-1">
          {[
            { id: 'manifesto', label: 'OPERATIONAL MANIFESTO', icon: BookOpen },
            { id: 'incoterms', label: 'INCOTERMS 2020 REFERENCE', icon: Truck },
            { id: 'pricing', label: 'TRANSACTION PRICING', icon: Landmark },
            { id: 'faq', label: 'FREQUENTLY ASKED QUESTIONS', icon: Scale }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                id={`doc-tab-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center px-4 py-2 text-xs font-mono font-bold transition-all relative border-b-2 ${
                  activeTab === tab.id 
                    ? 'border-[#b38a38] text-[#b38a38] bg-white' 
                    : 'border-transparent text-gray-500 hover:text-gray-900'
                }`}
              >
                <Icon className="w-4 h-4 mr-1.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        {activeTab === 'manifesto' && (
          <div className="bg-white border border-gray-200 rounded p-6 shadow-sm max-w-4xl space-y-6">
            
            <div className="space-y-3">
              <span className="text-[10px] font-mono text-[#b38a38] block tracking-widest font-bold">Æ CORE MISSION</span>
              <h2 className="font-mono font-bold text-xl text-gray-900">THE PHYSICAL OPERATING SYSTEM</h2>
              <p className="text-sm text-gray-600 leading-relaxed font-sans">
                Agora Exchange is an enterprise-grade physical commodities marketplace. We operate on the boundary where code meets heavy industrial logistics. The platform is engineered to eliminate friction from traditional commodity sourcing, replacing opaque phone brokers with structured data, transparent supplier compliance histories, and double-entry escrow ledger settlements.
              </p>
            </div>

            <div className="border-t border-gray-100 pt-6 grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <span className="font-mono text-xs font-bold text-gray-800 uppercase block">What We Are</span>
                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  A high-volume procurement platform for concrete builders, timber merchants, metallurgical manufacturers, and agricultural cooperatives who contract physical raw goods (lumber, copper cathodes, marble, rubber blocks, bulk coffee crop).
                </p>
              </div>

              <div className="space-y-2">
                <span className="font-mono text-xs font-bold text-gray-800 uppercase block">What We Are Not</span>
                <p className="text-xs text-gray-500 leading-relaxed font-sans">
                  We are not a financial trading platform. We do not provide futures, derivatives, margin leverage, options contracts, or speculative financial trading instruments. Every single transaction cleared on Agora results in real physical cargo being loaded onto a container and dispatched to a port.
                </p>
              </div>
            </div>

            <div className="bg-[#fbf9f4] border border-[#b38a38]/20 p-4 rounded text-xs leading-normal space-y-2">
              <span className="font-mono font-bold text-[#b38a38] block">DESIGN PRINCIPLE: AMERICAN HYPERMODERN INDUSTRIALISM</span>
              <p className="text-gray-600 font-sans">
                Our design aesthetics draw inspiration from industrial architecture magazines, McMaster-Carr catalogs, and high-density trading desks. We prioritize rigorous structural details, explicit data density, crisp geometric borders, and clear typographic hierarchy over generic ecommerce styling.
              </p>
            </div>

          </div>
        )}

        {activeTab === 'incoterms' && (
          <div className="space-y-6 max-w-4xl">
            <span className="text-[11px] font-mono tracking-wider text-gray-400 block font-bold uppercase">LOGISTICS RISK ANALYSIS</span>
            
            <div className="grid sm:grid-cols-2 gap-4">
              {[
                {
                  code: 'FOB',
                  name: 'Free On Board (Named Port of Shipment)',
                  desc: 'The seller delivers the goods on board the vessel nominated by the buyer at the named port of shipment. The risk of loss or damage transfers when the goods are on board the vessel, and the buyer bears all costs from that moment onward.',
                  bestFor: 'Dry Bulk, Metals, Timber Heavy Cargo'
                },
                {
                  code: 'CIF',
                  name: 'Cost, Insurance & Freight (Named Port of Destination)',
                  desc: 'The seller delivers the goods on board the vessel or procures the goods already so delivered. The seller pays for ocean freight and minimal marine insurance to the destination port, but risk transfers to the buyer upon loading at the origin port.',
                  bestFor: 'Inter-Continental Containerized Logistics'
                },
                {
                  code: 'EXW',
                  name: 'Ex Works (Named Place of Delivery)',
                  desc: 'The seller makes the goods available at their premises (e.g., works, factory, warehouse). The buyer bears all risks and costs of loading the goods and transporting them from the seller\'s site to the final destination.',
                  bestFor: 'Regional / Domestic Sourcing'
                },
                {
                  code: 'DDP',
                  name: 'Delivered Duty Paid (Named Place of Destination)',
                  desc: 'The seller delivers the goods cleared for import and ready for unloading at the named place of destination. The seller bears all risks and costs of transport, customs clearance, duties, taxes, and terminal charges.',
                  bestFor: 'Turnkey Enterprise Corporate Deliveries'
                }
              ].map((term, i) => (
                <div key={i} className="bg-white border border-gray-200 p-5 rounded shadow-sm flex flex-col justify-between">
                  <div>
                    <span className="text-lg font-mono font-bold text-[#b38a38] block">{term.code}</span>
                    <span className="text-xs font-mono font-bold text-gray-800 block mt-1">{term.name}</span>
                    <p className="text-xs text-gray-500 mt-2.5 leading-relaxed font-sans">{term.desc}</p>
                  </div>
                  <div className="border-t border-gray-100 pt-3 mt-4 text-[10px] font-mono text-gray-400 flex justify-between">
                    <span>SUITABLE SECTOR:</span>
                    <span className="text-gray-900 font-bold">{term.bestFor}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'pricing' && (
          <div className="bg-white border border-gray-200 rounded p-6 shadow-sm max-w-4xl space-y-6">
            <span className="text-xs font-mono text-gray-400 block uppercase">Agora Exchange Transaction Fee Structure</span>
            
            <div className="border border-gray-200 rounded divide-y divide-gray-100">
              <div className="bg-gray-50 grid grid-cols-3 p-3 text-[10px] font-mono font-bold text-gray-500">
                <span>SETTLEMENT SERVICE</span>
                <span>FEE THRESHOLD / BASIS</span>
                <span>COMMISSION RATE</span>
              </div>
              <div className="grid grid-cols-3 p-3.5 text-xs font-mono">
                <span className="font-bold">Standard Bank Wire (SWIFT)</span>
                <span>Per completed contract</span>
                <span className="text-gray-900 font-semibold">1.2% flat per transaction</span>
              </div>
              <div className="grid grid-cols-3 p-3.5 text-xs font-mono">
                <span className="font-bold">Protected Trade Escrow</span>
                <span>Escrow safeguarding & releasing</span>
                <span className="text-gray-900 font-semibold">1.5% flat per transaction</span>
              </div>
              <div className="grid grid-cols-3 p-3.5 text-xs font-mono">
                <span className="font-bold">Corporate Net-30 Accounts</span>
                <span>Trade line credit insurance</span>
                <span className="text-gray-900 font-semibold">0.5% underwriting surcharge</span>
              </div>
              <div className="grid grid-cols-3 p-3.5 text-xs font-mono">
                <span className="font-bold">Cryptocurrency Settlement</span>
                <span>Bitcoin (BTC) / USDT ledger transfers</span>
                <span className="text-emerald-600 font-bold">0.0% (Zero platform fees)</span>
              </div>
            </div>

            <div className="bg-gray-50 p-4 border border-gray-200 rounded text-xs font-sans leading-relaxed text-gray-600">
              <span className="font-mono font-bold text-gray-800 block mb-1">💡 NO CHARGE FOR LIQUIDITY BROWSING</span>
              Buyers do not pay registration fees, browsing dues, or RFQ dispatch costs. Platform monetization occurs strictly on completed contract clearances.
            </div>
          </div>
        )}

        {activeTab === 'faq' && (
          <div className="bg-white border border-gray-200 rounded p-6 shadow-sm max-w-4xl space-y-5">
            <span className="text-xs font-mono text-gray-400 block uppercase">KYB & SYSTEM SETTLEMENT POLICIES</span>
            
            <div className="space-y-4">
              {[
                {
                  q: 'How does Agora Exchange verify supplier legitimacy?',
                  a: 'Every seller applying to Agora must undergo rigorous Know-Your-Business (KYB) audits. This includes verifying state registration registries, proving active warehouse ownership or mill licenses, auditing physical cargo insurance policies, and verifying chain-of-custody compliance documents (like FSC or ISO certifications).'
                },
                {
                  q: 'How are physical quality disputes resolved?',
                  a: 'In B2B trade, material testing assays are commonplace. If a cargo arrival fails the agreed ASTM, LME or NHLA grade specifications (verified by accredited third-party surveyors at port), the buyer can trigger an escrow lock. Platform arbitrators inspect both lab assays, and can authorize a full refund or direct partial credits.'
                },
                {
                  q: 'Is there support for cryptocurrency accounting?',
                  a: 'Yes. Agora supports alternative payments via Bitcoin (BTC) and Tether (USDT TRC20). Choosing crypto skips SWIFT routing delays, settling in seconds. The platform automatically generates professional double-entry accounting ledgers and matches blockchain tx confirmations to the purchase orders.'
                }
              ].map((faq, i) => (
                <div key={i} className="space-y-1.5">
                  <h4 className="font-mono font-bold text-sm text-gray-900 flex items-start">
                    <span className="text-[#b38a38] mr-1.5 font-mono">Q:</span>
                    {faq.q}
                  </h4>
                  <p className="text-xs text-gray-500 font-sans pl-5 leading-relaxed">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Contact info block */}
        <div className="mt-8 border-t border-gray-200 pt-6 flex items-center space-x-3 text-xs text-gray-400 font-mono">
          <Mail className="w-4 h-4 text-gray-400" />
          <span>Need custom enterprise integrations or API sandbox keys? Contact: <span className="text-black font-semibold">support@agoraexchange.com</span></span>
        </div>

      </div>
    </div>
  );
}
