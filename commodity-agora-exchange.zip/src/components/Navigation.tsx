/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Compass, 
  FileText, 
  User, 
  Layers, 
  ShieldAlert, 
  Terminal, 
  BookOpen, 
  TrendingUp,
  Activity,
  Globe,
  Settings
} from 'lucide-react';

interface NavigationProps {
  activeView: string;
  setActiveView: (view: string) => void;
  activeRole: 'buyer' | 'supplier' | 'admin';
  setActiveRole: (role: 'buyer' | 'supplier' | 'admin') => void;
}

export default function Navigation({ 
  activeView, 
  setActiveView, 
  activeRole, 
  setActiveRole 
}: NavigationProps) {
  
  // Custom navigation items based on active role
  const navItems = [
    { id: 'marketplace', name: 'Global Marketplace', icon: Compass, roles: ['buyer', 'supplier', 'admin'] },
    { id: 'rfq', name: 'RFQ Marketplace', icon: FileText, roles: ['buyer', 'supplier', 'admin'] },
    { id: 'buyer-dashboard', name: 'Buyer Dashboard', icon: User, roles: ['buyer', 'admin'] },
    { id: 'supplier-dashboard', name: 'Supplier Dashboard', icon: Layers, roles: ['supplier', 'admin'] },
    { id: 'admin-portal', name: 'Administration Portal', icon: ShieldAlert, roles: ['admin'] },
    { id: 'api-console', name: 'API & DB Console', icon: Terminal, roles: ['buyer', 'supplier', 'admin'] },
    { id: 'documentation', name: 'Documentation & FAQ', icon: BookOpen, roles: ['buyer', 'supplier', 'admin'] }
  ];

  const filteredItems = navItems.filter(item => item.roles.includes(activeRole));

  return (
    <header className="sticky top-0 z-50 bg-[#0E0E10] text-[#F0F0F0] border-b border-[#2A2A2E] shadow-lg font-sans">
      {/* Top Meta Status Bar - American Hypermodern Industrialism Style */}
      <div className="bg-[#0A0A0B] border-b border-[#2A2A2E]/50 px-4 py-1.5 flex justify-between items-center text-[10px] font-mono tracking-wider text-gray-400">
        <div className="flex items-center space-x-4">
          <span className="flex items-center text-[#E2FF00]">
            <Globe className="w-3 h-3 mr-1 animate-pulse" />
            AGORA GLOBAL TERMINAL
          </span>
          <span className="hidden md:inline text-gray-600">|</span>
          <span className="hidden md:inline">SYSTEM: STABLE_SSL</span>
          <span className="hidden md:inline text-gray-600">|</span>
          <span className="hidden md:inline">DATABASE: PostgreSQL (LOCAL_SANDBOX)</span>
        </div>
        <div className="flex items-center space-x-4">
          <span className="hidden lg:inline">UTC: 2026-07-15 19:10:52</span>
          <span className="flex items-center text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse"></span>
            PORT_3000_ACTIVE
          </span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand/Logo Section */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveView('marketplace')}>
            <div className="bg-[#E2FF00] text-black font-mono font-bold p-2 text-lg rounded-sm tracking-tighter shadow-md">
              Æ
            </div>
            <div>
              <span className="font-mono text-xl font-bold tracking-tight text-white block">
                AGORA<span className="text-[#E2FF00]">_EXCHANGE</span>
              </span>
              <span className="text-[9px] font-mono tracking-widest text-[#888] uppercase -mt-1 block">
                B2B Physical Commodities
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden xl:flex space-x-1">
            {filteredItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeView === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-${item.id}`}
                  onClick={() => setActiveView(item.id)}
                  className={`flex items-center px-3 py-2 text-xs font-mono tracking-tight transition-all duration-150 relative ${
                    isActive 
                      ? 'text-[#E2FF00] border-b-2 border-[#E2FF00] bg-[#151518]' 
                      : 'text-gray-300 hover:text-white hover:bg-[#151518]/50'
                  }`}
                >
                  <Icon className="w-4 h-4 mr-1.5" />
                  {item.name}
                </button>
              );
            })}
          </nav>

          {/* Role Sandbox & Controls */}
          <div className="flex items-center space-x-3">
            <div className="bg-[#151518] border border-[#2A2A2E] rounded px-2.5 py-1 flex items-center space-x-2">
              <span className="text-[10px] font-mono text-gray-500">PROFILE:</span>
              <select
                id="active-role-selector"
                value={activeRole}
                onChange={(e) => {
                  const val = e.target.value as 'buyer' | 'supplier' | 'admin';
                  setActiveRole(val);
                  
                  // Redirect views gracefully if the view isn't allowed for the new role
                  if (val === 'buyer' && !['marketplace', 'rfq', 'buyer-dashboard', 'api-console', 'documentation'].includes(activeView)) {
                    setActiveView('buyer-dashboard');
                  } else if (val === 'supplier' && !['marketplace', 'rfq', 'supplier-dashboard', 'api-console', 'documentation'].includes(activeView)) {
                    setActiveView('supplier-dashboard');
                  } else if (val === 'admin' && !['marketplace', 'rfq', 'buyer-dashboard', 'supplier-dashboard', 'admin-portal', 'api-console', 'documentation'].includes(activeView)) {
                    setActiveView('admin-portal');
                  }
                }}
                className="bg-transparent text-xs text-[#E2FF00] font-mono font-semibold focus:outline-none cursor-pointer pr-1"
              >
                <option value="buyer">Tom @ AHYX (Buyer)</option>
                <option value="supplier">Nordic Timber (Supplier)</option>
                <option value="admin">Agora Administrator (Admin)</option>
              </select>
            </div>

            <div className="bg-[#151518] p-1.5 rounded text-[#E2FF00] border border-[#2A2A2E] cursor-help" title="Terminal Operational">
              <Activity className="w-4 h-4" />
            </div>
          </div>
        </div>
      </div>

      {/* Mobile/Sub-Header Navigation for small screens */}
      <div className="xl:hidden bg-[#0A0A0B] border-t border-[#2A2A2E] overflow-x-auto whitespace-nowrap scrollbar-none flex px-2 py-1.5">
        {filteredItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`inline-flex items-center px-3 py-1.5 text-[11px] font-mono rounded mr-1.5 transition-all ${
                isActive 
                  ? 'bg-[#E2FF00] text-black font-semibold' 
                  : 'text-gray-300 hover:bg-[#151518]'
              }`}
            >
              <Icon className="w-3.5 h-3.5 mr-1" />
              {item.name}
            </button>
          );
        })}
      </div>
    </header>
  );
}
