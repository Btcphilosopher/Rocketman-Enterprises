/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Commodity, Order, Supplier, Rfq } from '../types';
import { 
  Plus, 
  Settings, 
  TrendingUp, 
  Layers, 
  Truck, 
  DollarSign, 
  ShieldAlert, 
  CheckCircle,
  PackageCheck,
  Package,
  Activity,
  Edit2
} from 'lucide-react';

interface SupplierDashboardProps {
  commodities: Commodity[];
  orders: Order[];
  onAddCommodity: (commodity: Commodity) => void;
  onUpdateStock: (commodityId: string, delta: number) => void;
  onUpdateOrderStatus: (orderId: string, status: Order['status'], trackingNumber?: string, eta?: string) => void;
}

export default function SupplierDashboard({
  commodities,
  orders,
  onAddCommodity,
  onUpdateStock,
  onUpdateOrderStatus
}: SupplierDashboardProps) {

  // Active sub-navigation
  const [supplierTab, setSupplierTab] = useState<'inventory' | 'sales' | 'logistics'>('inventory');

  // Form states - Add Commodity
  const [newComName, setNewComName] = useState('');
  const [newComSku, setNewComSku] = useState('');
  const [newComCat, setNewComCat] = useState('Forestry & Timber');
  const [newComSub, setNewComSub] = useState('');
  const [newComGrade, setNewComGrade] = useState('');
  const [newComPrice, setNewComPrice] = useState<number>(0);
  const [newComQty, setNewComQty] = useState<number>(0);
  const [newComMoq, setNewComMoq] = useState<number>(10);
  const [newComUnit, setNewComUnit] = useState('m³ (Cubic Meters)');
  const [newComDesc, setNewComDesc] = useState('');
  const [newComWarehouse, setNewComWarehouse] = useState('Hamburg Dock 4');

  const [showAddForm, setShowAddForm] = useState(false);

  // Filter commodities uploaded by this supplier (e.g. Nordic Timber 'sup-1')
  const supplierCommodities = commodities.filter(c => c.supplierId === 'sup-1');

  // Filter orders routing to this supplier
  const supplierOrders = orders.filter(o => o.supplierId === 'sup-1');

  // Sales calculations
  const totalRevenue = supplierOrders
    .filter(o => o.status !== 'cancelled')
    .reduce((acc, c) => acc + c.totalPrice, 0);

  // Handle Dispatch shipping trigger
  const handleDispatchShipment = (orderId: string) => {
    const trackingCode = `MAERSK-${Math.floor(10000000 + Math.random() * 90000000)}`;
    const etaDate = new Date();
    etaDate.setDate(etaDate.getDate() + 12);
    const etaString = etaDate.toISOString().split('T')[0];

    onUpdateOrderStatus(orderId, 'shipped', trackingCode, etaString);
  };

  const handleMarkDelivered = (orderId: string) => {
    onUpdateOrderStatus(orderId, 'delivered');
  };

  const handleAddCommoditySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComName || !newComSku || newComPrice <= 0 || newComQty <= 0) return;

    const newCommodity: Commodity = {
      id: `com-custom-${Math.floor(100 + Math.random() * 900)}`,
      name: newComName,
      sku: newComSku,
      category: newComCat,
      subcategory: newComSub || 'Industrial Input',
      supplierId: 'sup-1',
      supplierName: 'Nordic Timber & Lumber Co.',
      originCountry: 'Sweden',
      productionRegion: 'Värmland Bioenergy Terminal',
      grade: newComGrade || 'Standard Mill Spec',
      specification: 'Custom Mill Cut, KD 12% MC',
      certification: ['FSC Certified', 'ISO 9001'],
      availableQty: newComQty,
      unit: newComUnit,
      moq: newComMoq,
      pricePerUnit: newComPrice,
      bulkDiscounts: [{ qty: newComMoq * 5, discountPercent: 5 }],
      leadTimeDays: 14,
      packaging: 'Steel strapping, polythene wraps',
      shippingTerms: ['FOB', 'CIF', 'DDP', 'EXW'],
      description: newComDesc || 'Premium bespoke physical supply contract dispatched with full traceable quality assay.',
      warehouseLocation: newComWarehouse,
      images: ['https://images.unsplash.com/photo-1518709268805-4e9042af9f23?q=80&w=600&auto=format&fit=crop'],
      documents: [{ name: 'Quality_Certificate_Custom.pdf', type: 'PDF Specification', size: '1.2 MB' }]
    };

    onAddCommodity(newCommodity);
    setShowAddForm(false);
    
    // Reset form fields
    setNewComName('');
    setNewComSku('');
    setNewComPrice(0);
    setNewComQty(0);
  };

  return (
    <div className="bg-[#0A0A0B] text-[#F0F0F0] min-h-screen py-8 font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Supplier Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b border-[#2A2A2E] pb-5 mb-6">
          <div>
            <span className="text-[10px] font-mono text-[#E2FF00] uppercase tracking-widest font-bold">SUPPLIER IDENT: NORDIC TIMBER & LUMBER CO.</span>
            <h1 className="text-2xl font-mono font-bold text-white tracking-tight mt-0.5">SELLER OPERATIONS CONSOLE</h1>
            <p className="text-xs text-gray-400 font-sans mt-1">
              Add products, adjust stock reserves, fulfill incoming wholesale orders, and track revenue metrics.
            </p>
          </div>

          <div className="mt-4 md:mt-0 flex space-x-6 text-right">
            <div>
              <span className="text-[10px] font-mono text-gray-500 block uppercase">NORDIC AGORA REVENUE</span>
              <span className="text-lg font-mono font-bold text-[#E2FF00]">${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
            </div>
            <div>
              <span className="text-[10px] font-mono text-gray-500 block uppercase">ACTIVE SALES COUNT</span>
              <span className="text-lg font-mono font-bold text-white">{supplierOrders.length} ORDERS</span>
            </div>
          </div>
        </div>

        {/* Dashboard sub tabs */}
        <div className="border-b border-[#2A2A2E] mb-6 flex space-x-1">
          {[
            { id: 'inventory', label: 'STOCK LEDGER', icon: Layers, count: supplierCommodities.length },
            { id: 'sales', label: 'SALES & ORDERS', icon: DollarSign, count: supplierOrders.length },
            { id: 'logistics', label: 'LOGISTICS & SHIPMENTS', icon: Truck, count: supplierOrders.filter(o => o.status === 'processing' || o.status === 'shipped').length }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                id={`supplier-tab-${tab.id}`}
                onClick={() => setSupplierTab(tab.id as any)}
                className={`flex items-center px-4 py-2 text-xs font-mono font-bold transition-all relative border-b-2 ${
                  supplierTab === tab.id 
                    ? 'border-[#E2FF00] text-[#E2FF00] bg-[#0E0E10]' 
                    : 'border-transparent text-gray-400 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 mr-1.5" />
                {tab.label}
                <span className={`ml-2 px-1.5 py-0.5 text-[9px] rounded-full font-mono ${
                  supplierTab === tab.id ? 'bg-[#E2FF00]/20 text-[#E2FF00]' : 'bg-[#151518] text-gray-400'
                }`}>
                  {tab.count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Inventory Control Room */}
        {supplierTab === 'inventory' && (
          <div className="space-y-6">
            
            {/* Header & Publisher Button */}
            <div className="flex justify-between items-center bg-[#0E0E10] p-4 border border-[#2A2A2E] rounded">
              <div>
                <span className="text-xs font-mono text-white font-bold block uppercase">Active Catalog Slabs</span>
                <span className="text-[11px] text-gray-400 font-sans block">Manage your physical product specifications listed on the global exchange board.</span>
              </div>
              <button
                id="add-product-form-trigger"
                onClick={() => setShowAddForm(!showAddForm)}
                className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black text-xs font-mono font-bold px-3 py-2 rounded flex items-center shadow-md transition-colors"
              >
                <Plus className="w-4 h-4 mr-1.5" />
                PUBLISH_NEW_COMMODITY
              </button>
            </div>

            {/* Add product wizard */}
            {showAddForm && (
              <form onSubmit={handleAddCommoditySubmit} className="bg-[#0E0E10] border-2 border-[#E2FF00] rounded p-6 shadow-md space-y-4 animate-fade-in text-white">
                <span className="text-xs font-mono text-white font-bold tracking-wider block uppercase">COMMODITY CONTRACT GENERATOR</span>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="col-span-2">
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Product Title</label>
                    <input
                      type="text"
                      id="supplier-product-name"
                      value={newComName}
                      onChange={(e) => setNewComName(e.target.value)}
                      placeholder="e.g. Nordic KD White Pine Timber"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">SKU identifier</label>
                    <input
                      type="text"
                      id="supplier-product-sku"
                      value={newComSku}
                      onChange={(e) => setNewComSku(e.target.value)}
                      placeholder="e.g. TIM-PIN-SWE-C18"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Standard Category</label>
                    <select
                      id="supplier-product-cat"
                      value={newComCat}
                      onChange={(e) => setNewComCat(e.target.value)}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                    >
                      <option value="Forestry & Timber">Forestry & Timber</option>
                      <option value="Metals">Metals</option>
                      <option value="Construction Materials">Construction Materials</option>
                      <option value="Agricultural Commodities">Agricultural Commodities</option>
                      <option value="Energy & Industrial Materials">Energy & Industrial</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Grade Level</label>
                    <input
                      type="text"
                      id="supplier-product-grade"
                      value={newComGrade}
                      onChange={(e) => setNewComGrade(e.target.value)}
                      placeholder="e.g. C18 Structural"
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Price Per Unit (USD)</label>
                    <input
                      type="number"
                      id="supplier-product-price"
                      value={newComPrice}
                      onChange={(e) => setNewComPrice(parseFloat(e.target.value) || 0)}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Initial Stock Reserve</label>
                    <input
                      type="number"
                      id="supplier-product-qty"
                      value={newComQty}
                      onChange={(e) => setNewComQty(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Minimum Order Qty</label>
                    <input
                      type="number"
                      id="supplier-product-moq"
                      value={newComMoq}
                      onChange={(e) => setNewComMoq(parseInt(e.target.value) || 0)}
                      className="w-full text-xs font-mono bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-gray-500 block uppercase mb-1">Description</label>
                  <textarea
                    id="supplier-product-desc"
                    value={newComDesc}
                    onChange={(e) => setNewComDesc(e.target.value)}
                    placeholder="Provide description of harvesting origin, kiln parameters, packaging, loading procedures..."
                    className="w-full h-16 text-xs font-sans bg-[#151518] border border-[#2A2A2E] text-white rounded p-2 focus:ring-1 focus:ring-[#E2FF00] focus:outline-none"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2 border-t border-[#2A2A2E]">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="border border-[#2A2A2E] text-gray-400 hover:text-white text-xs font-mono px-4 py-2 rounded"
                  >
                    CANCEL
                  </button>
                  <button
                    type="submit"
                    id="supplier-product-submit"
                    className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black text-xs font-mono font-bold px-4 py-2 rounded uppercase transition-colors"
                  >
                    DISPATCH_TO_EXCHANGE_BOARD
                  </button>
                </div>
              </form>
            )}

            {/* In-house stock management table */}
            <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded shadow-sm overflow-hidden">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#151518] border-b border-[#2A2A2E] text-[10px] text-gray-500 uppercase tracking-widest">
                  <tr>
                    <th className="px-6 py-3">SKU Identifier</th>
                    <th className="px-6 py-3">Commodity Spec</th>
                    <th className="px-6 py-3">Category</th>
                    <th className="px-6 py-3">Grade</th>
                    <th className="px-6 py-3">Current Stock</th>
                    <th className="px-6 py-3">Unit Price</th>
                    <th className="px-6 py-3 text-right">Stock Adjustment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A2A2E] text-gray-300">
                  {supplierCommodities.map((item) => (
                    <tr key={item.id} className="hover:bg-[#151518]/50">
                      <td className="px-6 py-3.5 font-bold text-white">{item.sku}</td>
                      <td className="px-6 py-3.5 font-semibold text-white">{item.name}</td>
                      <td className="px-6 py-3.5 text-gray-400">{item.category}</td>
                      <td className="px-6 py-3.5">{item.grade}</td>
                      <td className="px-6 py-3.5">
                        <span className={`font-semibold ${item.availableQty < 1000 ? 'text-amber-400' : 'text-emerald-400'}`}>
                          {item.availableQty.toLocaleString()} {item.unit.split(' ')[0]}
                        </span>
                      </td>
                      <td className="px-6 py-3.5 font-bold text-white">${item.pricePerUnit.toFixed(2)}</td>
                      <td className="px-6 py-3.5 text-right flex justify-end space-x-1.5">
                        <button
                          onClick={() => onUpdateStock(item.id, -250)}
                          className="px-2 py-1 bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/30 rounded font-bold text-[10px] transition-colors"
                        >
                          -250
                        </button>
                        <button
                          onClick={() => onUpdateStock(item.id, 1000)}
                          className="px-2 py-1 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/30 rounded font-bold text-[10px] transition-colors"
                        >
                          +1000
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* Sales & Orders Board */}
        {supplierTab === 'sales' && (
          <div className="space-y-4">
            <span className="text-[11px] font-mono tracking-wider text-gray-500 block font-bold uppercase">Wholesale Incoming Purchase orders</span>

            <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded shadow-sm overflow-hidden">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-[#151518] border-b border-[#2A2A2E] text-[10px] text-gray-500 uppercase tracking-widest">
                  <tr>
                    <th className="px-6 py-3">Order ID</th>
                    <th className="px-6 py-3">Buyer Enterprise</th>
                    <th className="px-6 py-3">Commodity Spec</th>
                    <th className="px-6 py-3">Volume</th>
                    <th className="px-6 py-3">Contract Value</th>
                    <th className="px-6 py-3">Terms / Incoterms</th>
                    <th className="px-6 py-3">State</th>
                    <th className="px-6 py-3 text-right">Fulfillment</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2A2A2E] text-gray-300">
                  {supplierOrders.map((o) => (
                    <tr key={o.id} className="hover:bg-[#151518]/50">
                      <td className="px-6 py-3.5 font-bold text-white">{o.id}</td>
                      <td className="px-6 py-3.5 text-white font-semibold">{o.buyerCompany}</td>
                      <td className="px-6 py-3.5 text-gray-400">{o.commodityName}</td>
                      <td className="px-6 py-3.5">{o.quantity.toLocaleString()} {o.unit.split(' ')[0]}</td>
                      <td className="px-6 py-3.5 font-bold text-white">${o.totalPrice.toLocaleString()}</td>
                      <td className="px-6 py-3.5">{o.shippingTerms}</td>
                      <td className="px-6 py-3.5">
                        <span className={`inline-flex px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                          o.status === 'delivered' ? 'bg-[#10b981]/15 text-[#10b981]' :
                          o.status === 'shipped' ? 'bg-blue-500/10 text-blue-400' :
                          o.status === 'pending_approval' ? 'bg-amber-500/10 text-amber-400 animate-pulse' : 'bg-[#2A2A2E] text-gray-400'
                        }`}>
                          {o.status}
                        </span>
                      </td>
                      <td className="px-6 py-3.5 text-right">
                        {o.status === 'pending_approval' && (
                          <span className="text-[10px] text-amber-400 font-bold uppercase">WAITING BUYER CO-SIGN</span>
                        )}
                        {o.status === 'processing' && (
                          <button
                            id={`dispatch-shipment-${o.id}`}
                            onClick={() => handleDispatchShipment(o.id)}
                            className="bg-[#E2FF00] hover:bg-[#f0ff66] text-black px-2 py-1 rounded text-[10px] font-mono font-bold uppercase transition-colors"
                          >
                            DISPATCH_SHIPMENT
                          </button>
                        )}
                        {o.status === 'shipped' && (
                          <button
                            onClick={() => handleMarkDelivered(o.id)}
                            className="bg-[#10b981] hover:bg-[#059669] text-white px-2 py-1 rounded text-[10px] font-mono font-bold uppercase transition-colors"
                          >
                            MARK_DELIVERED
                          </button>
                        )}
                        {o.status === 'delivered' && (
                          <span className="text-[#10b981] font-bold uppercase text-[10px]">✓ COMPLETE</span>
                        )}
                      </td>
                    </tr>
                  ))}

                  {supplierOrders.length === 0 && (
                    <tr>
                      <td colSpan={8} className="text-center py-12 text-gray-500 text-xs font-mono">
                        NO INCOMING CONTRACT REQUESTS RECORDED ON YOUR STOCK LEDGER
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* Logistics Operations Panel */}
        {supplierTab === 'logistics' && (
          <div className="space-y-6">
            
            {/* Carrier info */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="bg-[#0E0E10] text-white p-5 rounded border border-[#2A2A2E]">
                <span className="text-[10px] font-mono text-[#E2FF00] block tracking-widest font-bold">CARRIER PARTNERSHIPS</span>
                <p className="text-xs text-gray-400 mt-2 font-sans leading-relaxed">
                  Agora Exchange integrates directly with leading freight and shipping lanes (Maersk, MSC, Hapag-Lloyd, DHL Global) to auto-verify customs dispatchments and generate digital ocean Bills of Lading.
                </p>
                <div className="mt-4 flex space-x-3 text-xs font-mono text-[#E2FF00] font-bold">
                  <span className="border-b border-[#E2FF00] cursor-pointer">PORT_TREATY_INF.XML</span>
                  <span className="border-b border-[#E2FF00] cursor-pointer font-bold">INCOTERMS_2020.PDF</span>
                </div>
              </div>

              <div className="bg-[#0E0E10] border border-[#2A2A2E] p-5 rounded flex flex-col justify-between text-white">
                <div>
                  <span className="text-[10px] font-mono text-gray-400 block tracking-widest font-bold">CUSTOM DEPARTURES STATUS</span>
                  <span className="text-xs text-gray-400 block mt-1">Export clearance validation score</span>
                </div>
                <div className="mt-4 flex items-center text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 p-2.5 rounded border border-emerald-500/20">
                  <PackageCheck className="w-4 h-4 mr-1.5 text-emerald-400" />
                  NORDIC EXPORT CERTIFICATE: FSC_EUTR_VAL_100%
                </div>
              </div>
            </div>

            {/* List of shipments currently on water */}
            <div className="bg-[#0E0E10] border border-[#2A2A2E] rounded p-6 shadow-sm text-white">
              <span className="text-xs font-mono text-gray-500 block mb-4 uppercase">Ocean Freight Dispatch Tracker (On Water)</span>
              
              <div className="space-y-3">
                {supplierOrders.filter(o => o.status === 'shipped').map((order) => (
                  <div key={order.id} className="p-4 border border-[#2A2A2E] rounded bg-[#151518] flex flex-col md:flex-row justify-between items-start md:items-center text-white">
                    <div className="font-mono text-xs">
                      <span className="font-bold text-white block">CARRIER IDENT: {order.trackingNumber}</span>
                      <span className="text-gray-400 block mt-0.5">Commodity: {order.commodityName} | Port ETA: {order.eta}</span>
                    </div>

                    <div className="mt-2 md:mt-0 flex items-center space-x-4">
                      <div className="text-left md:text-right font-mono text-xs">
                        <span className="text-gray-500 block">DESTINATION:</span>
                        <span className="text-white font-semibold block">{order.buyerCompany.split(' ')[0]} Hub</span>
                      </div>
                      <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 text-[10px] font-mono font-bold uppercase px-2 py-1 rounded">
                        ON_WATER_TRANSIT
                      </span>
                    </div>
                  </div>
                ))}

                {supplierOrders.filter(o => o.status === 'shipped').length === 0 && (
                  <div className="text-center py-6 text-gray-500 text-xs font-mono border border-dashed border-[#2A2A2E] rounded bg-[#0E0E10]">
                    NO SHIPPED VESSELS CURRENTLY RECORDED ON WATER
                  </div>
                )}
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
