import React from "react";
import { useApp } from "../context/AppContext";
import { ArrowRight, Star, Heart, Leaf, Sun, Coffee } from "lucide-react";

export default function HomeSection() {
  const { setCurrentTab, setSelectedLocation } = useApp();

  const handleQuickLoc = (loc: string) => {
    setSelectedLocation(loc);
    setCurrentTab("LOCATIONS");
  };

  return (
    <div className="space-y-20 pb-20 font-ui">
      {/* 1. HERO AREA - Editorial Cinematics */}
      <section className="relative min-h-[80vh] flex items-center justify-center overflow-hidden bg-[#151515] text-[#F7F2EA] px-6 py-20 rounded-2xl mx-2 md:mx-6 shadow-2xl">
        {/* Cinematic Golden Hour Background */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1501979376754-2ff867a4f66e?q=80&w=1920"
            alt="Boston Harbor Skyline Golden Hour"
            className="w-full h-full object-cover opacity-35 scale-105 hover:scale-100 transition-transform duration-[10s] ease-out select-none"
            referrerPolicy="no-referrer"
          />
          {/* Subtle Golden-Amber Warm Sunbeams Overlay */}
          <div className="absolute inset-0 bg-gradient-to-tr from-[#151515] via-[#151515]/80 to-[#D4AF37]/20 mix-blend-color-burn"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-[#151515] via-transparent to-transparent"></div>
        </div>

        {/* Content Container */}
        <div className="relative z-10 max-w-5xl w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Heading, Subheading & CTAs */}
          <div className="lg:col-span-7 space-y-8 text-left">
            <div className="space-y-2">
              <span className="text-[11px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
                PROUDLY BOSTON. EST. MMXXIV
              </span>
              <h2 className="font-display text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.1] text-[#F7F2EA]">
                COFFEE <br />
                CRAFTED FOR <br />
                <span className="text-[#D4AF37]">THE CITY.</span>
              </h2>
            </div>

            {/* Custom line break divider */}
            <div className="w-16 h-0.5 bg-[#D4AF37]"></div>

            <p className="text-sm md:text-base text-[#F7F2EA]/85 leading-relaxed max-w-lg font-medium">
              Independent coffee, thoughtful design and New England hospitality—crafted fifty years into the future for people who value quality, conversation, and timeless craftsmanship.
            </p>

            <div className="flex flex-wrap gap-4 pt-2">
              <button
                onClick={() => setCurrentTab("MENU")}
                className="bg-[#D4AF37] hover:bg-[#F7F2EA] text-[#151515] font-bold text-xs tracking-[0.2em] px-8 py-4 rounded transition-all duration-300 shadow-lg hover:shadow-xl uppercase cursor-pointer"
              >
                ORDER COFFEE
              </button>
              <button
                onClick={() => setCurrentTab("LOCATIONS")}
                className="bg-transparent border border-[#F7F2EA]/35 hover:border-[#D4AF37] hover:bg-[#F7F2EA]/5 text-[#F7F2EA] font-semibold text-xs tracking-[0.2em] px-8 py-4 rounded transition-all duration-300 uppercase cursor-pointer"
              >
                FIND A CAFÉ
              </button>
            </div>
          </div>

          {/* Right Column: Hero Coffee Cup & Newspaper Overlay */}
          <div className="lg:col-span-5 flex justify-center relative">
            {/* Visual elements corresponding to design mock */}
            <div className="relative w-72 h-72 md:w-80 md:h-80 flex items-center justify-center bg-gradient-to-b from-white/5 to-white/0 rounded-full border border-white/10 p-4">
              
              {/* Glossy Espresso Cup & Saucer Overlay */}
              <div className="relative z-10 transform hover:scale-105 transition-transform duration-500">
                <img
                  src="https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800"
                  alt="Boston Coffee House Black Gold Monogrammed Mug"
                  className="w-48 h-48 object-cover rounded-full shadow-2xl border-4 border-[#151515]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Embedded BC Gold Monogram floating on cup */}
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-[#151515]/95 px-3 py-2 rounded border border-[#D4AF37]/50 shadow-xl flex flex-col items-center justify-center">
                  <span className="font-serif-logo text-xs font-bold text-[#D4AF37] tracking-widest leading-none">BC</span>
                  <span className="text-[6px] tracking-widest text-[#F7F2EA]/60 uppercase mt-0.5">BOSTON</span>
                </div>

                {/* Animated Rising Steam SVG */}
                <svg className="absolute -top-12 left-1/2 transform -translate-x-1/2 w-20 h-16 opacity-40 text-white pointer-events-none" viewBox="0 0 100 100">
                  <path d="M30,80 C30,50 45,60 45,30 C45,10 35,20 35,0" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse" />
                  <path d="M50,80 C50,55 62,65 62,35 C62,15 52,25 52,5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                  <path d="M70,80 C70,60 58,50 58,25 C58,5 68,15 68,0" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="animate-pulse" />
                </svg>
              </div>

              {/* Newspaper "The Boston Common" Mock Shadow Background */}
              <div className="absolute -bottom-6 -left-6 z-0 bg-[#E8E1D5] text-[#151515] p-3 rounded shadow-xl border border-black/10 max-w-[200px] transform -rotate-12 select-none pointer-events-none">
                <p className="font-serif-logo text-[8px] font-bold border-b border-black/20 pb-1 uppercase tracking-widest text-center">
                  The Boston Common
                </p>
                <p className="text-[6px] text-black/60 italic mt-1 font-semibold leading-tight">
                  "A timeless coffeehouse imagined fifty years in the future opens in Beacon Hill..."
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. THREE PROMO COLUMNS */}
      <section className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Column 1: COFFEE */}
        <div className="bg-[#151515]/2 border border-[#151515]/5 rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
          <div className="relative h-64 overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-151097252790b-a4817734857d?q=80&w=1200"
              alt="Pouring milk into a coffee cup with BC logo"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-[#151515]/10"></div>
          </div>
          <div className="p-8 text-center flex-1 flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">COFFEE</h3>
              <div className="w-8 h-0.5 bg-[#D4AF37] mx-auto"></div>
              <p className="text-xs text-[#151515]/75 leading-relaxed font-semibold max-w-xs mx-auto">
                Thoughtfully sourced. Expertly roasted. Beautifully prepared.
              </p>
            </div>
            <button
              onClick={() => setCurrentTab("MENU")}
              className="mt-6 inline-flex items-center justify-center gap-2 text-[10px] font-bold tracking-[0.2em] text-[#151515] hover:text-[#D4AF37] transition-colors uppercase cursor-pointer"
            >
              EXPLORE OUR MENU <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Column 2: OUR SPACE */}
        <div className="bg-[#151515]/2 border border-[#151515]/5 rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
          <div className="relative h-64 overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=1200"
              alt="Cozy Boston coffee house wooden interior"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-[#151515]/10"></div>
          </div>
          <div className="p-8 text-center flex-1 flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">OUR SPACE</h3>
              <div className="w-8 h-0.5 bg-[#D4AF37] mx-auto"></div>
              <p className="text-xs text-[#151515]/75 leading-relaxed font-semibold max-w-xs mx-auto">
                Designed for connection, creativity and quiet moments.
              </p>
            </div>
            <button
              onClick={() => setCurrentTab("LOCATIONS")}
              className="mt-6 inline-flex items-center justify-center gap-2 text-[10px] font-bold tracking-[0.2em] text-[#151515] hover:text-[#D4AF37] transition-colors uppercase cursor-pointer"
            >
              VIEW LOCATIONS <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

        {/* Column 3: CRAFTSMANSHIP */}
        <div className="bg-[#151515]/2 border border-[#151515]/5 rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col justify-between group">
          <div className="relative h-64 overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=1200"
              alt="Hands of a craftsman baking fresh pastries"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-[#151515]/10"></div>
          </div>
          <div className="p-8 text-center flex-1 flex flex-col justify-between">
            <div className="space-y-3">
              <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">CRAFTSMANSHIP</h3>
              <div className="w-8 h-0.5 bg-[#D4AF37] mx-auto"></div>
              <p className="text-xs text-[#151515]/75 leading-relaxed font-semibold max-w-xs mx-auto">
                We honour tradition by doing the ordinary, extraordinarily well.
              </p>
            </div>
            <button
              onClick={() => setCurrentTab("OUR_STORY")}
              className="mt-6 inline-flex items-center justify-center gap-2 text-[10px] font-bold tracking-[0.2em] text-[#151515] hover:text-[#D4AF37] transition-colors uppercase cursor-pointer"
            >
              LEARN OUR STORY <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* 3. SPLIT PANEL SECTION: COME HOME TO BOSTON */}
      <section className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-0 rounded-2xl overflow-hidden border border-[#151515]/10 shadow-lg">
        {/* Left Side text */}
        <div className="lg:col-span-5 bg-[#151515] text-[#F7F2EA] p-12 md:p-16 flex flex-col justify-center space-y-6">
          <span className="text-[10px] tracking-[0.3em] font-bold text-[#D4AF37] uppercase">
            COME HOME TO
          </span>
          <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#F7F2EA]">
            BOSTON
          </h2>
          <div className="w-12 h-0.5 bg-[#D4AF37]"></div>
          <p className="text-xs md:text-sm text-[#F7F2EA]/80 leading-relaxed font-semibold">
            From the South End and historic Beacon Hill to the scholastic chambers of Harvard Square, our coffee houses are designed to be part of the civic fabric of Boston. Find your sanctuary.
          </p>

          <div className="pt-4 space-y-2">
            <p className="text-[10px] tracking-widest text-[#D4AF37] uppercase font-bold">SELECT A HOUSE:</p>
            <div className="flex flex-wrap gap-2">
              {["Beacon Hill", "Harvard Square", "Boston Seaport", "South End"].map((l) => (
                <button
                  key={l}
                  onClick={() => handleQuickLoc(l)}
                  className="bg-[#F7F2EA]/10 hover:bg-[#D4AF37] hover:text-[#151515] text-[#F7F2EA] px-3 py-1.5 rounded text-[10px] tracking-wider font-bold uppercase transition-all duration-300 cursor-pointer"
                >
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Side Image */}
        <div className="lg:col-span-7 h-96 lg:h-auto min-h-[400px] relative">
          <img
            src="https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?q=80&w=1200"
            alt="Historic Boston corner cafe with beautiful window panes"
            className="w-full h-full object-cover absolute inset-0"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#151515]/30 to-transparent"></div>
        </div>
      </section>

      {/* 4. FOUR FEATURES GRID */}
      <section className="bg-[#151515]/2 border-y border-[#151515]/10 py-16 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-8 md:gap-12">
          {/* Feature 1 */}
          <div className="flex flex-col items-center text-center space-y-3 group">
            <div className="h-12 w-12 rounded-full border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#151515] transition-colors duration-500">
              <Leaf className="h-5 w-5" />
            </div>
            <h4 className="font-display text-sm font-extrabold tracking-wide text-[#151515] uppercase">
              ETHICALLY SOURCED
            </h4>
            <p className="text-[11px] text-[#151515]/70 max-w-[200px] font-semibold leading-relaxed">
              Direct relationships. Positive impact.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="flex flex-col items-center text-center space-y-3 group">
            <div className="h-12 w-12 rounded-full border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#151515] transition-colors duration-500">
              <Coffee className="h-5 w-5" />
            </div>
            <h4 className="font-display text-sm font-extrabold tracking-wide text-[#151515] uppercase">
              ARTISAN ROASTED
            </h4>
            <p className="text-[11px] text-[#151515]/70 max-w-[200px] font-semibold leading-relaxed">
              Small batches. Big flavour.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="flex flex-col items-center text-center space-y-3 group">
            <div className="h-12 w-12 rounded-full border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#151515] transition-colors duration-500">
              <Sun className="h-5 w-5" />
            </div>
            <h4 className="font-display text-sm font-extrabold tracking-wide text-[#151515] uppercase">
              LOCALLY INSPIRED
            </h4>
            <p className="text-[11px] text-[#151515]/70 max-w-[200px] font-semibold leading-relaxed">
              Rooted in Boston. Inspired by New England.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="flex flex-col items-center text-center space-y-3 group">
            <div className="h-12 w-12 rounded-full border border-[#D4AF37] flex items-center justify-center text-[#D4AF37] group-hover:bg-[#D4AF37] group-hover:text-[#151515] transition-colors duration-500">
              <Star className="h-5 w-5" />
            </div>
            <h4 className="font-display text-sm font-extrabold tracking-wide text-[#151515] uppercase">
              MADE FOR HUMANS
            </h4>
            <p className="text-[11px] text-[#151515]/70 max-w-[200px] font-semibold leading-relaxed">
              For early risers, dreamers, thinkers and doers.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
