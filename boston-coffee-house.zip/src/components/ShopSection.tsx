import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { StoreItem, SubscriptionConfig } from "../types";
import { ShoppingBag, Package, Check, RefreshCw, Sparkles, Filter, ChevronRight, Bookmark } from "lucide-react";

export default function ShopSection() {
  const { addToShopCart, subscriptions, createSubscription, toggleSubscriptionStatus } = useApp();
  const [storeItems, setStoreItems] = useState<StoreItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [selectedProduct, setSelectedProduct] = useState<StoreItem | null>(null);

  // Subscription Builder State
  const [subConfig, setSubConfig] = useState<SubscriptionConfig>({
    roast: "Medium",
    origin: "Signature Blend",
    frequency: "Bi-Weekly",
    quantity: "12oz (1 Bag)",
    grind: "Whole Bean"
  });
  const [subSuccess, setSubSuccess] = useState(false);
  const [subscribing, setSubscribing] = useState(false);

  const categories = ["All", "Beans", "Equipment", "Glassware", "Apparel"];

  useEffect(() => {
    fetch("/api/store")
      .then((res) => res.json())
      .then((data) => {
        setStoreItems(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const handleAddRetail = (item: StoreItem) => {
    addToShopCart(item, 1);
    alert(`${item.name} added to your retail bag.`);
  };

  const handleAddSubscription = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubscribing(true);
    try {
      await createSubscription(subConfig);
      setSubSuccess(true);
      setTimeout(() => {
        setSubSuccess(false);
      }, 3500);
    } catch (err) {
      console.log(err);
    } finally {
      setSubscribing(false);
    }
  };

  const filteredStore = storeItems.filter((i) => activeCategory === "All" || i.category === activeCategory);

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-20 font-ui">
      
      {/* 1. SECTION HEADER */}
      <div className="border-b border-[#151515]/10 pb-8 space-y-2 text-left">
        <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
          Luxury Provisions
        </span>
        <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
          RETAIL STORE & SUBSCRIPTIONS
        </h2>
        <p className="text-xs text-[#151515]/60 max-w-lg font-semibold">
          Equip your study and home bar with our custom unlacquered brass kettles, mouth-blown glassware, and freshly roasted micro-lot single origin beans.
        </p>
      </div>

      {/* 2. PREMIUM COFFEE SUBSCRIPTION ENGINE */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 bg-[#151515] text-[#F7F2EA] rounded-2xl p-8 md:p-12 shadow-2xl border border-white/5 relative overflow-hidden">
        
        {/* Subtle decorative background glowing gold dot */}
        <div className="absolute top-0 right-0 h-96 w-96 bg-[#D4AF37]/5 rounded-full filter blur-3xl pointer-events-none"></div>

        {/* Column Left: Promo Pitch */}
        <div className="lg:col-span-5 space-y-6 flex flex-col justify-center text-left relative z-10">
          <span className="text-[9px] tracking-[0.3em] font-black text-[#D4AF37] uppercase flex items-center gap-1.5">
            <RefreshCw className="h-3 w-3 animate-spin" style={{ animationDuration: '10s' }} />
            <span>NEVER RUN EMPTY</span>
          </span>
          <h3 className="font-display text-3xl md:text-4xl font-bold tracking-tight">
            THE ROASTER'S CHRONICLE SUBSCRIPTION
          </h3>
          <div className="w-12 h-0.5 bg-[#D4AF37]"></div>
          <p className="text-xs md:text-sm text-[#F7F2EA]/80 leading-relaxed font-semibold">
            Freshly roasted beans packaged in nitrogen-flushed, compostable bags, delivered to your door within 48 hours of cracking. Select your frequency, origin, and grind. Pausible or cancelable anytime.
          </p>

          {/* Subscriptions Count Display if any active */}
          {subscriptions.length > 0 && (
            <div className="bg-white/5 p-4 rounded-xl border border-white/10 space-y-2.5">
              <p className="text-[9px] font-bold tracking-widest text-[#D4AF37] uppercase">Your Active Subscriptions ({subscriptions.length})</p>
              <div className="space-y-1.5 divide-y divide-white/5">
                {subscriptions.map((sub) => (
                  <div key={sub.id} className="pt-1.5 flex justify-between items-center text-[10px]">
                    <div className="font-semibold text-white/95">
                      <span>{sub.config.roast} Roast • {sub.config.quantity}</span>
                      <span className="block text-[8px] text-white/40">{sub.config.frequency} ({sub.config.grind})</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.5 bg-green-900/40 text-green-400 border border-green-700/50 rounded-full font-bold text-[8px]">{sub.status.toUpperCase()}</span>
                      {sub.status === "Active" ? (
                        <button 
                          onClick={() => toggleSubscriptionStatus(sub.id, "Paused")}
                          className="text-red-400 font-bold hover:underline"
                        >
                          PAUSE
                        </button>
                      ) : (
                        <button 
                          onClick={() => toggleSubscriptionStatus(sub.id, "Active")}
                          className="text-[#D4AF37] font-bold hover:underline"
                        >
                          RESUME
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Column Right: Interactive Subscription Config Form */}
        <div className="lg:col-span-7 bg-white/5 border border-white/10 rounded-xl p-8 relative z-10 text-left">
          {subSuccess ? (
            <div className="py-16 text-center space-y-4 animate-scaleUp">
              <div className="h-12 w-12 rounded-full bg-[#D4AF37] text-[#151515] flex items-center justify-center mx-auto shadow-lg">
                <Check className="h-6 w-6 stroke-[3]" />
              </div>
              <h4 className="font-display text-2xl font-bold">Subscription Initiated</h4>
              <p className="text-xs font-semibold text-[#F7F2EA]/75 max-w-sm mx-auto uppercase tracking-widest">
                WELCOME TO THE SOCIETY. FIRST BAG DISPATCHES MONDAY MORNING.
              </p>
            </div>
          ) : (
            <form onSubmit={handleAddSubscription} className="space-y-5">
              
              {/* Row 1: Roast & Origin */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] tracking-wider font-extrabold uppercase text-[#F7F2EA]/60">Roast Characteristic</label>
                  <select
                    value={subConfig.roast}
                    onChange={(e) => setSubConfig({ ...subConfig, roast: e.target.value as any })}
                    className="w-full bg-[#151515] border border-white/20 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-white"
                  >
                    {["Light", "Medium", "Dark", "Roaster's Choice"].map((r) => (
                      <option key={r} value={r}>{r} Roast</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] tracking-wider font-extrabold uppercase text-[#F7F2EA]/60">Origin Selection</label>
                  <select
                    value={subConfig.origin}
                    onChange={(e) => setSubConfig({ ...subConfig, origin: e.target.value as any })}
                    className="w-full bg-[#151515] border border-white/20 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-white"
                  >
                    {["Single Origin", "Signature Blend", "Decaf Blend"].map((o) => (
                      <option key={o} value={o}>{o}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 2: Frequency & Quantity */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] tracking-wider font-extrabold uppercase text-[#F7F2EA]/60">Delivery Frequency</label>
                  <select
                    value={subConfig.frequency}
                    onChange={(e) => setSubConfig({ ...subConfig, frequency: e.target.value as any })}
                    className="w-full bg-[#151515] border border-white/20 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-white"
                  >
                    {["Weekly", "Bi-Weekly", "Monthly"].map((f) => (
                      <option key={f} value={f}>{f}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] tracking-wider font-extrabold uppercase text-[#F7F2EA]/60">Quantity (Per Cycle)</label>
                  <select
                    value={subConfig.quantity}
                    onChange={(e) => setSubConfig({ ...subConfig, quantity: e.target.value as any })}
                    className="w-full bg-[#151515] border border-white/20 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-white"
                  >
                    {["12oz (1 Bag)", "24oz (2 Bags)", "5lb (Bulk)"].map((q) => (
                      <option key={q} value={q}>{q}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Row 3: Grind Preference */}
              <div className="space-y-1.5">
                <label className="text-[9px] tracking-wider font-extrabold uppercase text-[#F7F2EA]/60">Grind Calibration</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {["Whole Bean", "French Press", "Drip", "Espresso"].map((g) => (
                    <button
                      key={g}
                      type="button"
                      onClick={() => setSubConfig({ ...subConfig, grind: g as any })}
                      className={`px-2 py-2 rounded border text-[10px] font-bold uppercase transition-all cursor-pointer ${
                        subConfig.grind === g
                          ? "bg-[#D4AF37] text-[#151515] border-transparent font-black shadow"
                          : "bg-transparent text-white/70 border-white/10 hover:bg-white/5"
                      }`}
                    >
                      {g}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={subscribing}
                className="w-full mt-4 bg-[#D4AF37] hover:bg-[#F7F2EA] text-[#151515] font-black py-4 text-[10px] tracking-widest uppercase rounded shadow transition-all duration-300 cursor-pointer"
              >
                {subscribing ? "ESTABLISHING ACCOUNT..." : "SUBSCRIBE TO COFFEE ARCHIVES — $18.00/BAG"}
              </button>
            </form>
          )}
        </div>
      </section>

      {/* 3. LUXURY PROVISIONS SHOP */}
      <section className="space-y-10">
        
        {/* Filters Header Bar */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-[#151515]/10 pb-4">
          <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">RETAIL PRODUCTS</h3>
          
          {/* Categories Filter pills */}
          <div className="flex items-center gap-1.5">
            <Filter className="h-3.5 w-3.5 text-[#151515]/40" />
            <div className="flex gap-1.5">
              {categories.map((c) => (
                <button
                  key={c}
                  onClick={() => setActiveCategory(c)}
                  className={`px-3.5 py-1.5 rounded-full text-[9px] tracking-widest font-black uppercase transition-all cursor-pointer ${
                    activeCategory === c
                      ? "bg-[#151515] text-[#F7F2EA]"
                      : "bg-[#151515]/3 text-[#151515]/60 hover:bg-[#151515]/8"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Store Grid */}
        {loading ? (
          <div className="py-12 text-center space-y-4">
            <div className="h-8 w-8 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-xs text-[#151515]/60 uppercase tracking-widest font-bold">Unpacking crates...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredStore.map((prod) => (
              <div
                key={prod.id}
                className="bg-white rounded-xl border border-[#151515]/10 overflow-hidden flex flex-col justify-between hover:shadow-lg transition-all duration-300 group cursor-pointer"
                onClick={() => setSelectedProduct(prod)}
              >
                {/* Photo frame */}
                <div className="relative h-60 bg-[#151515]/3 overflow-hidden">
                  <img
                    src={prod.image}
                    alt={prod.name}
                    className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="bg-[#151515] text-[#F7F2EA] px-2.5 py-1 text-[8px] font-black uppercase tracking-wider rounded border border-[#F7F2EA]/10 shadow">
                      {prod.category}
                    </span>
                  </div>
                </div>

                {/* Details card body */}
                <div className="p-6 space-y-4 text-left flex-1 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex justify-between items-baseline gap-2">
                      <h4 className="font-display text-lg font-extrabold tracking-tight text-[#151515] line-clamp-1 group-hover:text-[#D4AF37] transition-colors">
                        {prod.name}
                      </h4>
                      <span className="text-xs font-black text-[#151515]">${prod.price.toFixed(2)}</span>
                    </div>
                    <p className="text-xs text-[#151515]/70 leading-relaxed font-semibold line-clamp-2">
                      {prod.description}
                    </p>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddRetail(prod);
                    }}
                    className="w-full mt-2 bg-[#151515]/3 hover:bg-[#151515] text-[#151515] hover:text-[#F7F2EA] py-2.5 text-[9px] tracking-widest font-extrabold uppercase rounded transition-all duration-300 cursor-pointer font-ui flex items-center justify-center gap-2 border border-[#151515]/10"
                  >
                    <ShoppingBag className="h-3.5 w-3.5" />
                    <span>ADD TO SHOPPING BAG</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* 4. PRODUCT DETAIL HIGHLIGHT MODAL */}
      {selectedProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#151515]/60 backdrop-blur-sm animate-fadeIn">
          <div className="absolute inset-0" onClick={() => setSelectedProduct(null)}></div>

          <div className="relative bg-[#F7F2EA] w-full max-w-2xl rounded-2xl shadow-2xl border border-[#151515]/15 overflow-hidden flex flex-col md:flex-row z-10 animate-slideUp text-left">
            
            {/* Visual Column */}
            <div className="md:w-1/2 relative min-h-[300px]">
              <img
                src={selectedProduct.image}
                alt={selectedProduct.name}
                className="w-full h-full object-cover absolute inset-0"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#151515]/80 to-transparent"></div>
              <span className="absolute top-4 left-4 bg-white text-[#151515] px-3 py-1 text-[8px] font-black uppercase tracking-widest rounded border shadow">
                {selectedProduct.category}
              </span>
            </div>

            {/* Details Column */}
            <div className="md:w-1/2 p-8 space-y-6 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-display text-xl font-black text-[#151515] leading-tight">{selectedProduct.name}</h3>
                    <p className="text-[#D4AF37] font-black text-xs tracking-widest uppercase mt-0.5">${selectedProduct.price.toFixed(2)}</p>
                  </div>
                  <button onClick={() => setSelectedProduct(null)} className="text-xs font-bold text-[#151515]/40 hover:text-[#151515] uppercase cursor-pointer">
                    [X]
                  </button>
                </div>

                <div className="w-8 h-0.5 bg-[#D4AF37]"></div>

                <p className="text-xs font-semibold leading-relaxed text-[#151515]/85">
                  {selectedProduct.description}
                </p>

                {/* Technical details specs sheet */}
                <div className="bg-[#151515]/3 p-4 rounded-xl text-[10px] space-y-2 text-[#151515]/80 font-semibold border border-[#151515]/5">
                  <p className="text-[8px] font-bold tracking-widest text-[#151515]/50 uppercase border-b border-[#151515]/10 pb-1">Specifications</p>
                  <p className="leading-relaxed">{selectedProduct.details}</p>
                </div>
              </div>

              <div className="space-y-2 pt-4">
                <button
                  onClick={() => {
                    addToShopCart(selectedProduct, 1);
                    setSelectedProduct(null);
                  }}
                  className="w-full bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] py-3.5 text-[9px] tracking-widest font-extrabold uppercase rounded shadow transition-all duration-300 cursor-pointer flex items-center justify-center gap-2"
                >
                  <ShoppingBag className="h-4 w-4" />
                  <span>DISPATCH TO SHOPPING BAG</span>
                </button>
                <p className="text-[8px] font-semibold text-center text-[#151515]/40 uppercase tracking-widest">In stock, ready for immediate shipment across New England</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
