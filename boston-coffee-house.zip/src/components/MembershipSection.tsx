import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { Award, UserCheck, ShieldCheck, QrCode, ArrowRight, Gift, Check } from "lucide-react";

export default function MembershipSection() {
  const { membership, setMembership } = useApp();
  
  // Registration Form state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [tier, setTier] = useState<"Guild Member" | "Beacon Patron" | "Commonwealth Fellow">("Guild Member");
  const [registering, setRegistering] = useState(false);

  // Redemption state
  const [redeemSuccess, setRedeemSuccess] = useState<string | null>(null);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;
    setRegistering(true);

    fetch("/api/membership", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, email, tier })
    })
      .then((res) => res.json())
      .then((data) => {
        setMembership(data);
        setRegistering(false);
      })
      .catch((err) => {
        console.error(err);
        setRegistering(false);
      });
  };

  const handleRedeem = (cost: number, label: string) => {
    if (!membership) return;
    if (membership.points < cost) {
      alert("Insufficient points in your society ledger. Place more coffee orders to build your reserves.");
      return;
    }

    setMembership({
      ...membership,
      points: membership.points - cost
    });
    setRedeemSuccess(label);
    setTimeout(() => {
      setRedeemSuccess(null);
    }, 2500);
  };

  const tiersData = [
    {
      name: "Guild Member",
      price: "$50 / Annually",
      desc: "Perfect for daily Boston scholars seeking early access to limited provisions and priority mobile pickup.",
      perks: [
        "Priority mobile ordering with zero pickup queue",
        "10% off all retail coffee bags and brewing hardware",
        "Early access to seasonal tarts and limited micro-lots"
      ]
    },
    {
      name: "Beacon Patron",
      price: "$150 / Annually",
      desc: "For the refined New England coffee enthusiast seeking complimentary home-delivery bags and custom reading alcoves.",
      perks: [
        "Priority mobile ordering with zero pickup queue",
        "10% off all retail coffee bags and brewing hardware",
        "A complimentary 12oz signature blend bag every month",
        "Complimentary table reservations at any of our houses"
      ]
    },
    {
      name: "Commonwealth Fellow",
      price: "$300 / Annually",
      desc: "The pinnacle of our society. Unlimited V60 pours on Tuesday mornings and an annual private seminar with our Master Roasters.",
      perks: [
        "Priority mobile ordering with zero pickup queue",
        "10% off all retail coffee bags and brewing hardware",
        "A complimentary 12oz signature blend bag every month",
        "Complimentary table reservations at any of our houses",
        "Unlimited V60 single-origin pours on Tuesday mornings",
        "Annual private 1-on-1 tasting seminar with Roaster Director"
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-16 font-ui text-left">
      
      {/* Editorial Header */}
      <div className="border-b border-[#151515]/10 pb-8 space-y-2">
        <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
          Boston Coffee Society
        </span>
        <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
          SOCIETY FELLOWSHIP
        </h2>
        <p className="text-xs text-[#151515]/60 max-w-lg font-semibold">
          Unlock priority seating reservations, exclusive limited batch beans, and private roasting sessions in our Boston East harbor warehouse.
        </p>
      </div>

      {membership ? (
        // ACTIVE MEMBER DASHBOARD
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Side: Elegant Digital Member Card */}
          <div className="lg:col-span-5 space-y-6">
            <h3 className="font-display text-xl font-bold tracking-tight text-[#151515]">YOUR SOCIETY LEDGER</h3>
            
            {/* Holographic Premium Member Card (Dark theme) */}
            <div className="relative bg-gradient-to-b from-[#212121] to-[#151515] text-[#F7F2EA] rounded-2xl p-8 shadow-2xl border border-white/15 overflow-hidden flex flex-col justify-between h-[280px]">
              {/* Card top branding */}
              <div className="flex justify-between items-start">
                <div>
                  <p className="text-[8px] tracking-[0.2em] text-[#D4AF37] font-black uppercase">Boston Coffee Society</p>
                  <h4 className="font-serif-logo text-sm font-bold tracking-widest mt-1">FELLOWSHIP CARD</h4>
                </div>
                <span className="font-serif-logo text-lg text-[#D4AF37] font-bold tracking-wider">BC</span>
              </div>

              {/* Barcode / Member ID */}
              <div className="space-y-4">
                <div className="flex items-end gap-4">
                  <QrCode className="h-10 w-10 text-[#D4AF37]" />
                  <div className="space-y-0.5 text-left text-xs font-semibold">
                    <p className="text-[10px] text-white/50 uppercase tracking-widest">ID LEDGER</p>
                    <p className="font-mono text-sm text-white">{membership.memberId}</p>
                  </div>
                </div>

                {/* Card footer details */}
                <div className="flex justify-between items-end border-t border-white/10 pt-3.5 text-[10px] font-bold">
                  <div className="text-left">
                    <span className="text-white/40 uppercase text-[8px] tracking-widest block">PATRON NAME</span>
                    <span className="text-white uppercase tracking-wider">{membership.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-white/40 uppercase text-[8px] tracking-widest block">FELLOWSHIP TIER</span>
                    <span className="text-[#D4AF37] uppercase tracking-widest">{membership.tier}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Loyalty points ledger quick status card */}
            <div className="bg-[#151515]/3 border border-[#151515]/10 rounded-2xl p-6 text-left space-y-3">
              <span className="text-[8px] tracking-widest font-black text-[#D4AF37] uppercase">Points Wallet</span>
              <div className="flex justify-between items-baseline">
                <h4 className="text-3xl font-black text-[#151515] font-ui">{membership.points} <span className="text-xs font-semibold uppercase text-[#151515]/50">PTS</span></h4>
                <p className="text-[10px] font-semibold text-[#151515]/60 italic">Earn 10 points per $1 spent</p>
              </div>
              <p className="text-[11px] font-semibold text-[#151515]/75 leading-relaxed">
                Your points are updated in real-time after every online coffee or pastry checkout!
              </p>
            </div>
          </div>

          {/* Right Side: Points Redeemer & perks details */}
          <div className="lg:col-span-7 space-y-10">
            
            {/* Points Redeemer Shop */}
            <div className="bg-white border border-[#151515]/10 rounded-2xl p-8 shadow-sm text-left space-y-6">
              <div>
                <h4 className="font-display text-lg font-extrabold text-[#151515] flex items-center gap-2">
                  <Gift className="h-5 w-5 text-[#D4AF37]" />
                  <span>REDEEM SOCIETY REWARDS</span>
                </h4>
                <p className="text-[10px] text-[#151515]/50 uppercase tracking-widest font-semibold mt-1">
                  Exchange your loyal points for exclusive complimentary provisions
                </p>
              </div>

              {redeemSuccess ? (
                <div className="py-8 text-center space-y-3 bg-green-50 rounded-xl border border-green-200 animate-scaleUp">
                  <div className="h-10 w-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto">
                    <Check className="h-5 w-5" />
                  </div>
                  <h5 className="font-display text-md font-bold text-green-700">Reward Dispatched!</h5>
                  <p className="text-xs font-semibold text-[#151515]/60 uppercase">
                    REDEMPTION CONFIRMED FOR {redeemSuccess.toUpperCase()}
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {[
                    { label: "Complimentary Panama V60 Pour Over", cost: 500, desc: "A hand-poured single-origin pour over prepared at exactly 93.5°C." },
                    { label: "Limited Edition Gold Monogrammed Mug", cost: 1200, desc: "A custom double-walled borosilicate glass mug with gold monogram." },
                    { label: "Private Roasting & Cupping Masterclass", cost: 2500, desc: "An exclusive 2-hour roasting session with our Coffee Director in East Boston." }
                  ].map((reward) => (
                    <div key={reward.cost} className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 p-4 rounded-xl border border-[#151515]/5 bg-[#151515]/2 hover:bg-[#151515]/4 transition-colors">
                      <div className="space-y-0.5 max-w-[70%]">
                        <h5 className="text-xs font-extrabold text-[#151515]">{reward.label}</h5>
                        <p className="text-[11px] text-[#151515]/65 leading-relaxed font-semibold">{reward.desc}</p>
                      </div>

                      <button
                        onClick={() => handleRedeem(reward.cost, reward.label)}
                        className={`px-4 py-2.5 rounded text-[9px] font-black tracking-widest uppercase transition-all duration-300 cursor-pointer ${
                          membership.points >= reward.cost
                            ? "bg-[#151515] text-[#F7F2EA] hover:bg-[#D4AF37] hover:text-[#151515]"
                            : "bg-[#151515]/10 text-[#151515]/40 cursor-not-allowed"
                        }`}
                      >
                        REDEEM {reward.cost} PTS
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Specific Tiers Benefits details */}
            <div className="space-y-4">
              <h4 className="text-[10px] tracking-widest font-black text-[#151515]/50 uppercase border-b border-[#151515]/10 pb-2">Active Society Benefits</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {membership.benefits.map((benefit, idx) => (
                  <div key={idx} className="flex gap-2.5 items-start text-xs font-semibold text-[#151515]/85">
                    <ShieldCheck className="h-4 w-4 text-[#D4AF37] shrink-0 mt-0.5" />
                    <p>{benefit}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        // GUEST MEMBERSHIP SIGN-UP PORTAL
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Column: Register Form */}
          <div className="lg:col-span-5 bg-white border border-[#151515]/10 rounded-2xl p-8 shadow-sm flex flex-col justify-between">
            <div className="space-y-6">
              <div className="space-y-2 border-b border-[#151515]/5 pb-4">
                <span className="text-[9px] tracking-[0.25em] font-extrabold text-[#D4AF37] uppercase">Society Enrollment</span>
                <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">JOIN COFFEE GUILD</h3>
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Emerson Alcott"
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Email Address</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="emerson@harvard.edu"
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Select Fellowship Tier</label>
                  <select
                    value={tier}
                    onChange={(e) => setTier(e.target.value as any)}
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="Guild Member">Guild Member ($50/yr)</option>
                    <option value="Beacon Patron">Beacon Patron ($150/yr)</option>
                    <option value="Commonwealth Fellow">Commonwealth Fellow ($300/yr)</option>
                  </select>
                </div>

                <button
                  type="submit"
                  disabled={registering}
                  className="w-full mt-4 bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] py-3.5 text-[10px] tracking-widest font-extrabold uppercase rounded shadow transition-all duration-300 cursor-pointer"
                >
                  {registering ? "REGISTERING ACCOUNT..." : "SECURE SOCIETY FELLOWSHIP"}
                </button>
              </form>
            </div>

            <p className="text-[9px] font-semibold text-center text-[#151515]/40 uppercase tracking-widest mt-6">
              Ledgers are synchronized globally with priority mobile checkouts
            </p>
          </div>

          {/* Right Column: Tiers Presentation */}
          <div className="lg:col-span-7 space-y-6">
            <h3 className="font-display text-xl font-bold tracking-tight text-[#151515]">FELLOWSHIP TIERS</h3>
            
            <div className="space-y-6 divide-y divide-[#151515]/10">
              {tiersData.map((t) => (
                <div key={t.name} className={`pt-6 first:pt-0 grid grid-cols-1 md:grid-cols-12 gap-4 items-start ${tier === t.name ? "bg-[#D4AF37]/5 p-4 rounded-xl" : ""}`}>
                  {/* Tier Title and Price */}
                  <div className="md:col-span-4 space-y-1">
                    <h4 className="font-display text-md font-extrabold text-[#151515] uppercase tracking-wide">{t.name}</h4>
                    <span className="text-xs font-black text-[#D4AF37] block">{t.price}</span>
                  </div>

                  {/* Tier description and perks */}
                  <div className="md:col-span-8 space-y-3 text-xs font-semibold">
                    <p className="text-[#151515]/75 leading-relaxed font-semibold italic">{t.desc}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] text-[#151515]/70">
                      {t.perks.map((perk, idx) => (
                        <div key={idx} className="flex gap-1.5 items-start">
                          <Check className="h-3.5 w-3.5 text-[#D4AF37] shrink-0 mt-0.5 stroke-[3]" />
                          <span>{perk}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
