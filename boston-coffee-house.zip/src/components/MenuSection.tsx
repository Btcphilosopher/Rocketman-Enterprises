import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { MenuItem, CustomizationOptions } from "../types";
import { Coffee, ShoppingBag, Sliders, Check, Search, Sparkles, MessageCircleCode } from "lucide-react";

export default function MenuSection() {
  const { addToCart, currentTab, setCurrentTab } = useApp();
  const [items, setItems] = useState<MenuItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState("");
  
  // Customization Modal State
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [customization, setCustomization] = useState<CustomizationOptions>({
    milk: "Whole",
    sweetness: "Standard",
    espressoShots: 0,
    beans: "House Blend (Medium)",
    notes: ""
  });
  const [isSuccessAdded, setIsSuccessAdded] = useState(false);

  const categories = [
    "All",
    "Espresso",
    "Pour Over",
    "Filter Coffee",
    "Cold Brew",
    "Tea",
    "Breakfast",
    "Lunch",
    "Seasonal Specials",
    "Coffee Cocktails"
  ];

  useEffect(() => {
    fetch("/api/menu")
      .then((res) => res.json())
      .then((data) => {
        setItems(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const openCustomization = (item: MenuItem) => {
    setSelectedItem(item);
    setQuantity(1);
    // Reset defaults depending on category
    const isDrink = ["Espresso", "Pour Over", "Filter Coffee", "Cold Brew", "Tea", "Seasonal Specials"].includes(item.category);
    setCustomization({
      milk: isDrink && item.category !== "Tea" && item.category !== "Pour Over" ? "Whole" : "None",
      sweetness: "Standard",
      espressoShots: 0,
      beans: item.category === "Pour Over" ? "Harvard Square Single-Origin (Light)" : "House Blend (Medium)",
      notes: ""
    });
    setIsSuccessAdded(false);
  };

  const handleAddToCart = () => {
    if (!selectedItem) return;
    addToCart(selectedItem, quantity, { ...customization });
    setIsSuccessAdded(true);
    setTimeout(() => {
      setSelectedItem(null);
      setIsSuccessAdded(false);
    }, 1200);
  };

  const filteredItems = items.filter((item) => {
    const matchesCategory = activeCategory === "All" || item.category === activeCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          item.origin.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-12 font-ui">
      {/* Editorial Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-[#151515]/10 pb-8">
        <div className="space-y-2">
          <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
            House Specialties
          </span>
          <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
            THE COFFEEHOUSE MENU
          </h2>
          <p className="text-xs text-[#151515]/60 max-w-md font-semibold">
            Every cup is dialed in daily by our lead roasters. Pastries and provisions are organic, freshly sourced from local New England farms.
          </p>
        </div>

        {/* AI Sommelier Quick CTA */}
        <div className="bg-[#151515] text-[#F7F2EA] p-4 rounded-xl border border-[#D4AF37]/35 flex items-center justify-between gap-6 shadow-md max-w-sm">
          <div className="space-y-1">
            <p className="text-[10px] font-bold tracking-widest text-[#D4AF37] uppercase">Claire's Companion</p>
            <p className="text-[11px] text-[#F7F2EA]/80 font-medium">Need help picking the perfect origin?</p>
          </div>
          <button 
            onClick={() => setCurrentTab("AISOMMELIER")}
            className="bg-[#D4AF37] hover:bg-[#F7F2EA] text-[#151515] p-2 rounded-lg transition-all duration-300 flex items-center gap-1.5 text-[10px] font-black cursor-pointer uppercase tracking-wider"
          >
            <Sparkles className="h-4 w-4" />
            <span>ASK AI</span>
          </button>
        </div>
      </div>

      {/* Categories & Search Filter Bar */}
      <div className="flex flex-col lg:flex-row gap-6 items-stretch justify-between">
        {/* Categories Pills */}
        <div className="flex flex-wrap gap-2 overflow-x-auto pb-2 scrollbar-none max-w-4xl">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4.5 py-2.5 rounded text-[10px] tracking-[0.15em] font-bold uppercase transition-all duration-200 cursor-pointer whitespace-nowrap ${
                activeCategory === cat
                  ? "bg-[#151515] text-[#F7F2EA] shadow"
                  : "bg-[#151515]/4 text-[#151515]/60 hover:bg-[#151515]/8 hover:text-[#151515]"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Field */}
        <div className="relative min-w-[280px]">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-[#151515]/40" />
          <input
            type="text"
            placeholder="Search beans, origins, ingredients..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#151515]/4 border border-[#151515]/10 rounded pl-10 pr-4 py-2.5 text-xs font-semibold placeholder-[#151515]/40 text-[#151515] focus:outline-none focus:border-[#D4AF37] transition-all"
          />
        </div>
      </div>

      {/* Grid Menu Listing */}
      {loading ? (
        <div className="py-20 text-center space-y-4">
          <div className="h-8 w-8 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-[#151515]/60 uppercase tracking-widest font-bold">Grinding beans...</p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="py-20 text-center border border-dashed border-[#151515]/10 rounded-xl space-y-2">
          <p className="text-xs text-[#151515]/60 uppercase tracking-widest font-bold">No provisions match your filters</p>
          <button onClick={() => { setActiveCategory("All"); setSearchQuery(""); }} className="text-xs text-[#D4AF37] font-bold underline">Clear All Filters</button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-xl overflow-hidden border border-[#151515]/10 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col justify-between group"
            >
              {/* Product Card Header Image */}
              <div className="relative h-52 overflow-hidden bg-[#151515]/5">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-[1.03] transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Tags overlay */}
                <div className="absolute top-3 left-3 flex flex-col gap-1">
                  <span className="bg-[#151515] text-[#F7F2EA] px-2.5 py-1 text-[8px] font-black uppercase tracking-wider rounded border border-[#F7F2EA]/10">
                    {item.category}
                  </span>
                  {item.roastingProfile !== "None" && (
                    <span className="bg-[#D4AF37] text-[#151515] px-2.5 py-1 text-[8px] font-black uppercase tracking-wider rounded">
                      {item.roastingProfile}
                    </span>
                  )}
                </div>

                <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-sm text-[#151515] px-3 py-1 text-xs font-black rounded shadow">
                  ${item.price.toFixed(2)}
                </div>
              </div>

              {/* Product Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <h3 className="font-display text-xl font-extrabold tracking-tight text-[#151515] group-hover:text-[#D4AF37] transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-xs text-[#151515]/75 leading-relaxed font-semibold line-clamp-3">
                    {item.description}
                  </p>
                  
                  {/* Fine Print Specs */}
                  <div className="pt-3 divide-y divide-[#151515]/5 text-[10px] space-y-1.5 font-semibold text-[#151515]/60">
                    {item.origin && (
                      <div className="flex justify-between pt-1.5">
                        <span>ORIGIN:</span>
                        <span className="text-[#151515] font-bold text-right max-w-[180px] truncate">{item.origin}</span>
                      </div>
                    )}
                    <div className="flex justify-between pt-1.5">
                      <span>CAFFEINE:</span>
                      <span className="text-[#151515] font-bold">{item.caffeine === "0" ? "Decaf / Zero" : item.caffeine}</span>
                    </div>
                  </div>
                </div>

                {/* Card footer CTA button */}
                <button
                  onClick={() => openCustomization(item)}
                  className="w-full mt-4 bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] py-3 text-[10px] tracking-widest font-extrabold uppercase rounded transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer shadow-sm font-ui"
                >
                  <ShoppingBag className="h-3.5 w-3.5" />
                  <span>CUSTOMISE & ADD</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 5. DRINK CUSTOMIZATION & ADD MODAL */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#151515]/60 backdrop-blur-sm animate-fadeIn">
          {/* Backdrop Closer */}
          <div className="absolute inset-0" onClick={() => setSelectedItem(null)}></div>

          {/* Modal Container */}
          <div className="relative bg-[#F7F2EA] w-full max-w-2xl rounded-2xl shadow-2xl border border-[#151515]/15 overflow-hidden flex flex-col md:flex-row z-10 animate-slideUp">
            
            {/* Visual Thumbnail Column */}
            <div className="md:w-5/12 bg-[#151515] text-[#F7F2EA] relative min-h-[250px] md:min-h-full">
              <img
                src={selectedItem.image}
                alt={selectedItem.name}
                className="w-full h-full object-cover absolute inset-0 opacity-80"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 right-6 space-y-2">
                <span className="text-[9px] tracking-widest font-black text-[#D4AF37] uppercase">{selectedItem.category}</span>
                <h3 className="font-display text-2xl font-black tracking-tight">{selectedItem.name}</h3>
                <p className="text-[11px] font-bold text-[#F7F2EA]/90">${selectedItem.price.toFixed(2)}</p>
              </div>
            </div>

            {/* Customization Controls Column */}
            <div className="md:w-7/12 p-8 space-y-6 max-h-[85vh] overflow-y-auto">
              <div className="flex justify-between items-start">
                <div>
                  <h4 className="text-xs font-extrabold tracking-widest text-[#151515]/50 uppercase">Configure Beverage</h4>
                  <p className="text-[11px] text-[#151515]/60 font-medium italic mt-0.5">Customized to your exact preferences.</p>
                </div>
                <button
                  onClick={() => setSelectedItem(null)}
                  className="text-xs font-bold text-[#151515]/50 hover:text-[#151515] uppercase cursor-pointer"
                >
                  [CLOSE]
                </button>
              </div>

              {isSuccessAdded ? (
                <div className="py-12 text-center space-y-4 animate-scaleUp">
                  <div className="h-12 w-12 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto shadow-md">
                    <Check className="h-6 w-6 stroke-[3]" />
                  </div>
                  <h4 className="font-display text-lg font-black text-green-700">Added to Shopping Bag</h4>
                  <p className="text-xs font-bold text-[#151515]/60 uppercase">DIALED IN AND CONFIRMED</p>
                </div>
              ) : (
                <div className="space-y-5">
                  
                  {/* 1. Milk Type Selection (Conditional for drinks) */}
                  {customization.milk !== "None" && (
                    <div className="space-y-2">
                      <label className="text-[10px] tracking-wider font-extrabold text-[#151515] uppercase block">Milk Selection</label>
                      <div className="grid grid-cols-2 gap-2">
                        {["Whole", "Oat", "Almond", "Pistachio"].map((milkOpt) => (
                          <button
                            key={milkOpt}
                            onClick={() => setCustomization({ ...customization, milk: milkOpt as any })}
                            className={`px-3 py-2 text-[10px] font-bold uppercase rounded border transition-all cursor-pointer ${
                              customization.milk === milkOpt
                                ? "bg-[#151515] text-[#F7F2EA] border-transparent shadow"
                                : "bg-white text-[#151515]/70 border-[#151515]/15 hover:bg-[#151515]/5"
                            }`}
                          >
                            {milkOpt}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 2. Sweetness Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] tracking-wider font-extrabold text-[#151515] uppercase block">Sweetness Level</label>
                    <div className="grid grid-cols-3 gap-2">
                      {["Standard", "Less", "None"].map((sweetOpt) => (
                        <button
                          key={sweetOpt}
                          onClick={() => setCustomization({ ...customization, sweetness: sweetOpt as any })}
                          className={`px-3 py-2 text-[10px] font-bold uppercase rounded border transition-all cursor-pointer ${
                            customization.sweetness === sweetOpt
                              ? "bg-[#151515] text-[#F7F2EA] border-transparent shadow"
                              : "bg-white text-[#151515]/70 border-[#151515]/15 hover:bg-[#151515]/5"
                          }`}
                        >
                          {sweetOpt}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 3. Extra Espresso Shots */}
                  {["Espresso", "Cold Brew", "Seasonal Specials"].includes(selectedItem.category) && (
                    <div className="space-y-2">
                      <label className="text-[10px] tracking-wider font-extrabold text-[#151515] uppercase block">Extra Espresso Shots</label>
                      <div className="flex items-center gap-3">
                        {[0, 1, 2, 3].map((num) => (
                          <button
                            key={num}
                            onClick={() => setCustomization({ ...customization, espressoShots: num })}
                            className={`h-9 w-9 text-xs font-bold rounded-full border transition-all cursor-pointer flex items-center justify-center ${
                              customization.espressoShots === num
                                ? "bg-[#D4AF37] text-[#151515] border-transparent shadow font-black"
                                : "bg-white text-[#151515]/70 border-[#151515]/15 hover:bg-[#151515]/5"
                            }`}
                          >
                            +{num}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 4. Single-Origin Bean Customization */}
                  {["Espresso", "Pour Over"].includes(selectedItem.category) && (
                    <div className="space-y-2">
                      <label className="text-[10px] tracking-wider font-extrabold text-[#151515] uppercase block">Bean Single-Origin Profile</label>
                      <div className="space-y-1.5">
                        {[
                          "House Blend (Medium)",
                          "Harvard Square Single-Origin (Light)",
                          "Boston Harbor Dark (Dark)"
                        ].map((b) => (
                          <button
                            key={b}
                            onClick={() => setCustomization({ ...customization, beans: b as any })}
                            className={`w-full text-left px-3 py-2.5 text-[9px] font-bold uppercase rounded border transition-all cursor-pointer flex justify-between items-center ${
                              customization.beans === b
                                ? "bg-[#151515] text-[#F7F2EA] border-transparent shadow"
                                : "bg-white text-[#151515]/70 border-[#151515]/15 hover:bg-[#151515]/5"
                            }`}
                          >
                            <span>{b}</span>
                            {customization.beans === b && <Check className="h-3 w-3 text-[#D4AF37] stroke-[3]" />}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* 5. Order Notes */}
                  <div className="space-y-2">
                    <label className="text-[10px] tracking-wider font-extrabold text-[#151515] uppercase block">Barista Instructions</label>
                    <input
                      type="text"
                      placeholder="Extra hot, milk on side, allergy notes..."
                      value={customization.notes}
                      onChange={(e) => setCustomization({ ...customization, notes: e.target.value })}
                      className="w-full bg-white border border-[#151515]/15 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  {/* 6. Quantity Controls */}
                  <div className="flex items-center justify-between pt-4 border-t border-[#151515]/10 mt-4">
                    <div className="flex items-center gap-3 bg-white border border-[#151515]/15 rounded px-3 py-1.5">
                      <button
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="text-xs font-bold px-2 hover:text-[#D4AF37] cursor-pointer"
                      >
                        –
                      </button>
                      <span className="text-xs font-bold font-ui">{quantity}</span>
                      <button
                        onClick={() => setQuantity(quantity + 1)}
                        className="text-xs font-bold px-2 hover:text-[#D4AF37] cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <button
                      onClick={handleAddToCart}
                      className="bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] px-6 py-3 text-[10px] tracking-widest font-extrabold uppercase rounded shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer"
                    >
                      ADD TO ORDER BAG
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
