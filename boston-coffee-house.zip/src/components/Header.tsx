import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { MapPin, ShoppingBag, User, LogOut, ChevronDown } from "lucide-react";

export default function Header({ onCartClick }: { onCartClick: () => void }) {
  const { selectedLocation, setSelectedLocation, cart, shopCart, membership, setMembership, setCurrentTab } = useApp();
  const [showLocMenu, setShowLocMenu] = useState(false);

  const locations = ["Beacon Hill", "Harvard Square", "Boston Seaport", "South End"];

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0) + 
                    shopCart.reduce((acc, item) => acc + item.quantity, 0);

  const handleSignOut = () => {
    fetch("/api/membership/signout", { method: "POST" })
      .then(() => setMembership(null))
      .catch((err) => console.log(err));
  };

  return (
    <header className="sticky top-0 z-30 w-full bg-[#F7F2EA]/95 backdrop-blur-md border-b border-[#151515]/5 px-6 md:px-12 py-4 flex items-center justify-between">
      {/* Left: Location Selector */}
      <div className="relative">
        <button
          id="location-selector"
          onClick={() => setShowLocMenu(!showLocMenu)}
          className="flex items-center gap-2 text-xs font-bold tracking-[0.2em] text-[#151515]/80 hover:text-[#151515] transition-colors focus:outline-none cursor-pointer"
        >
          <MapPin className="h-4 w-4 text-[#D4AF37]" />
          <span className="uppercase">{selectedLocation}, BOSTON</span>
          <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${showLocMenu ? "rotate-180" : ""}`} />
        </button>

        {showLocMenu && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setShowLocMenu(false)}></div>
            <div className="absolute left-0 mt-3.5 z-20 w-52 bg-[#F7F2EA] border border-[#151515]/10 rounded shadow-xl py-1 divide-y divide-[#151515]/5 overflow-hidden">
              {locations.map((loc) => (
                <button
                  key={loc}
                  onClick={() => {
                    setSelectedLocation(loc);
                    setShowLocMenu(false);
                  }}
                  className={`w-full text-left px-4 py-3 text-[11px] tracking-[0.15em] uppercase font-semibold hover:bg-[#151515]/5 transition-colors cursor-pointer ${
                    selectedLocation === loc ? "text-[#D4AF37] bg-[#151515]/2 font-bold" : "text-[#151515]/70"
                  }`}
                >
                  {loc}
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Center: Brand Tagline */}
      <div className="hidden lg:block">
        <p className="text-[10px] tracking-[0.45em] font-extrabold text-[#151515]/50 uppercase text-center select-none font-ui">
          COFFEE. CULTURE. COMMONWEALTH.
        </p>
      </div>

      {/* Right: Actions (Cart & Membership) */}
      <div className="flex items-center gap-4 md:gap-6">
        {/* BCS Member Tag */}
        {membership ? (
          <div className="hidden sm:flex items-center gap-2.5 bg-[#151515] text-[#F7F2EA] px-3 py-1.5 rounded text-[10px] tracking-wider font-semibold border border-[#D4AF37]/30">
            <span className="h-1.5 w-1.5 rounded-full bg-[#D4AF37] animate-ping"></span>
            <span className="text-[#D4AF37]">{membership.tier.toUpperCase()}</span>
            <span className="opacity-50">|</span>
            <span>{membership.points} PTS</span>
            <button 
              onClick={handleSignOut} 
              className="text-[#F7F2EA]/50 hover:text-[#D4AF37] transition-colors ml-1 cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="h-3.5 w-3.5" />
            </button>
          </div>
        ) : (
          <button
            onClick={() => setCurrentTab("MEMBERSHIP")}
            className="hidden sm:flex items-center gap-1.5 text-xs font-semibold tracking-wider text-[#151515]/70 hover:text-[#151515] cursor-pointer"
          >
            <User className="h-4 w-4" />
            <span>JOIN SOCIETY</span>
          </button>
        )}

        {/* ORDER ONLINE Button */}
        <button
          onClick={() => setCurrentTab("MENU")}
          className="bg-[#151515] text-[#F7F2EA] hover:bg-[#D4AF37] hover:text-[#151515] text-[10px] tracking-[0.2em] font-bold px-4 py-2.5 rounded transition-all duration-300 shadow-md cursor-pointer uppercase font-ui"
        >
          ORDER ONLINE
        </button>

        {/* Cart Trigger */}
        <button
          id="cart-trigger"
          onClick={onCartClick}
          className="relative p-2 text-[#151515] hover:text-[#D4AF37] transition-colors focus:outline-none cursor-pointer"
          aria-label="View shopping bag"
        >
          <ShoppingBag className="h-5 w-5" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-[#D4AF37] text-[#151515] text-[9px] font-black h-4.5 w-4.5 flex items-center justify-center rounded-full shadow border-2 border-[#F7F2EA]">
              {cartCount}
            </span>
          )}
        </button>
      </div>
    </header>
  );
}
