import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { Story } from "../types";
import { Clock, BookOpen, Share2, Heart, ArrowLeft, ArrowRight, MessageSquare } from "lucide-react";

export default function JournalSection() {
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedStory, setSelectedStory] = useState<Story | null>(null);
  const [likes, setLikes] = useState<Record<string, number>>({});
  const [comments, setComments] = useState<Record<string, { author: string; text: string; date: string }[]>>({});
  const [newCommentAuthor, setNewCommentAuthor] = useState("");
  const [newCommentText, setNewCommentText] = useState("");

  useEffect(() => {
    fetch("/api/stories")
      .then((res) => res.json())
      .then((data) => {
        setStories(data);
        setLoading(false);
        // Set initial likes
        const defaultLikes: Record<string, number> = {};
        data.forEach((s: Story) => {
          defaultLikes[s.id] = Math.floor(10 + Math.random() * 90);
        });
        setLikes(defaultLikes);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const handleLike = (storyId: string) => {
    setLikes((prev) => ({
      ...prev,
      [storyId]: (prev[storyId] || 0) + 1
    }));
  };

  const handleCommentSubmit = (e: React.FormEvent, storyId: string) => {
    e.preventDefault();
    if (!newCommentAuthor.trim() || !newCommentText.trim()) return;

    const freshComment = {
      author: newCommentAuthor,
      text: newCommentText,
      date: "Just now"
    };

    setComments((prev) => ({
      ...prev,
      [storyId]: [...(prev[storyId] || []), freshComment]
    }));

    setNewCommentAuthor("");
    setNewCommentText("");
  };

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-16 font-ui">
      {/* Dynamic Editorial Detail Overlay or Grid */}
      {selectedStory ? (
        // Full Article expanded view
        <div className="max-w-3xl mx-auto space-y-10 animate-fadeIn text-left">
          {/* Back Button */}
          <button
            onClick={() => setSelectedStory(null)}
            className="inline-flex items-center gap-2 text-xs font-bold tracking-widest text-[#151515]/60 hover:text-[#151515] uppercase cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>BACK TO JOURNAL</span>
          </button>

          {/* Article Header */}
          <div className="space-y-4">
            <span className="bg-[#151515] text-[#F7F2EA] px-2.5 py-1 text-[8px] font-black uppercase tracking-wider rounded border border-[#F7F2EA]/10">
              {selectedStory.category}
            </span>
            <h2 className="font-display text-3xl md:text-5xl font-extrabold tracking-tight text-[#151515] leading-tight">
              {selectedStory.title}
            </h2>
            <div className="flex flex-wrap items-center gap-6 text-xs text-[#151515]/60 font-semibold pt-2">
              <span className="text-[#D4AF37] font-bold uppercase">BY {selectedStory.author}</span>
              <span>•</span>
              <span>{selectedStory.date}</span>
              <span>•</span>
              <span className="flex items-center gap-1.5"><Clock className="h-3.5 w-3.5" />{selectedStory.readTime}</span>
            </div>
          </div>

          {/* Big Cinematic Banner */}
          <div className="h-96 w-full rounded-2xl overflow-hidden shadow-md">
            <img
              src={selectedStory.image}
              alt={selectedStory.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Article Editorial Body */}
          <article className="prose prose-stone prose-lg max-w-none text-[#151515]/85">
            {/* Lead Paragraph with elegant Dropcap drop-letter */}
            <p className="text-lg md:text-xl font-medium leading-relaxed font-ui first-letter:text-5xl first-letter:font-extrabold first-letter:font-display first-letter:float-left first-letter:mr-2.5 first-letter:text-[#D4AF37] first-letter:leading-none">
              {selectedStory.content}
            </p>
            
            <p className="text-xs md:text-sm leading-relaxed font-semibold mt-6 italic text-[#151515]/75">
              "Crafted in Boston. Brewed for Tomorrow. Our commitment is to elevate the ordinary into the extraordinary, preserving the heritage of coffee roasters and New England designers."
            </p>
          </article>

          {/* Action Row: Like and Share */}
          <div className="flex items-center justify-between border-y border-[#151515]/10 py-4 mt-8">
            <div className="flex items-center gap-4">
              <button
                onClick={() => handleLike(selectedStory.id)}
                className="flex items-center gap-1.5 text-xs font-bold text-[#151515]/70 hover:text-red-500 transition-colors cursor-pointer"
              >
                <Heart className="h-4.5 w-4.5 stroke-[2] fill-transparent hover:fill-red-500" />
                <span>{likes[selectedStory.id] || 0} LIKES</span>
              </button>
              <span className="text-[#151515]/20">|</span>
              <button
                onClick={() => alert("Link copied to clipboard for dispatch.")}
                className="flex items-center gap-1.5 text-xs font-bold text-[#151515]/70 hover:text-[#D4AF37] transition-colors cursor-pointer"
              >
                <Share2 className="h-4.5 w-4.5" />
                <span>SHARE ARTICLE</span>
              </button>
            </div>
          </div>

          {/* Comments Section */}
          <div className="space-y-6 pt-6">
            <h4 className="font-display text-xl font-extrabold text-[#151515] flex items-center gap-2">
              <MessageSquare className="h-4.5 w-4.5 text-[#D4AF37]" />
              <span>SOCIETY DISCUSSION</span>
            </h4>

            {/* List of comments */}
            <div className="space-y-4">
              {/* Fallback comment */}
              <div className="bg-[#151515]/3 p-4.5 rounded-xl text-xs space-y-2 text-[#151515]/80">
                <div className="flex justify-between font-bold text-[#D4AF37]">
                  <span>DR. HAROLD WINTHROP (BOSTON ARCHITECTURAL FORUM)</span>
                  <span className="text-[#151515]/40 font-medium font-ui">July 30, 2026</span>
                </div>
                <p className="font-semibold leading-relaxed">
                  An absolutely outstanding articulation of preservation and futurism. The choice of solid unlacquered brass hardware will look even better as the decades pass. Boston needs more cafes built with this standard of physical permanence.
                </p>
              </div>

              {(comments[selectedStory.id] || []).map((comm, idx) => (
                <div key={idx} className="bg-[#151515]/3 p-4.5 rounded-xl text-xs space-y-2 text-[#151515]/80 animate-slideUp">
                  <div className="flex justify-between font-bold text-[#D4AF37]">
                    <span>{comm.author.toUpperCase()}</span>
                    <span className="text-[#151515]/40 font-medium font-ui">{comm.date}</span>
                  </div>
                  <p className="font-semibold leading-relaxed">{comm.text}</p>
                </div>
              ))}
            </div>

            {/* Add Comment Form */}
            <form onSubmit={(e) => handleCommentSubmit(e, selectedStory.id)} className="space-y-3 bg-[#151515]/2 p-6 rounded-xl border border-[#151515]/5">
              <p className="text-[10px] text-[#151515]/50 font-bold uppercase tracking-wider">Leave a thought</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input
                  type="text"
                  required
                  placeholder="Your Name (e.g. Scholar, Patron)"
                  value={newCommentAuthor}
                  onChange={(e) => setNewCommentAuthor(e.target.value)}
                  className="bg-white border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                />
              </div>
              <textarea
                required
                rows={3}
                placeholder="Share your perspective on New England craftsmanship..."
                value={newCommentText}
                onChange={(e) => setNewCommentText(e.target.value)}
                className="w-full bg-white border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
              ></textarea>
              <button
                type="submit"
                className="bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] px-5 py-2.5 text-[9px] tracking-widest font-black uppercase rounded shadow cursor-pointer transition-all duration-300"
              >
                SUBMIT DISCUSSION ENTRY
              </button>
            </form>
          </div>
        </div>
      ) : (
        // List Stories view
        <div className="space-y-12">
          {/* Editorial Header */}
          <div className="border-b border-[#151515]/10 pb-8 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div className="space-y-2 text-left">
              <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
                The Boston Coffee Society Gazette
              </span>
              <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
                COFFEE JOURNAL
              </h2>
              <p className="text-xs text-[#151515]/60 max-w-md font-semibold">
                An interactive editorial publication investigating high-altitude micro-lots, modern thermodynamic physics, and New England cultural design.
              </p>
            </div>
            <span className="text-[10px] text-[#151515]/40 font-bold uppercase tracking-widest border border-[#151515]/15 px-3 py-1.5 rounded select-none">
              ISSUE NO. 14 • SUMMER 2026
            </span>
          </div>

          {loading ? (
            <div className="py-20 text-center space-y-4">
              <div className="h-8 w-8 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs text-[#151515]/60 uppercase tracking-widest font-bold">Assembling editorial sheets...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
              {stories.map((story) => (
                <article
                  key={story.id}
                  className="flex flex-col justify-between space-y-4 group cursor-pointer text-left"
                  onClick={() => setSelectedStory(story)}
                >
                  {/* Photo cover */}
                  <div className="relative h-64 rounded-xl overflow-hidden shadow-sm bg-[#151515]/5">
                    <img
                      src={story.image}
                      alt={story.title}
                      className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-700"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-[#151515] text-[#F7F2EA] px-2.5 py-1 text-[8px] font-black uppercase tracking-wider rounded border border-[#F7F2EA]/10 shadow">
                        {story.category}
                      </span>
                    </div>
                  </div>

                  {/* Metadata & Title */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-3 text-[10px] font-extrabold text-[#151515]/45 tracking-wider uppercase">
                      <span>{story.date}</span>
                      <span>•</span>
                      <span>{story.readTime}</span>
                    </div>

                    <h3 className="font-display text-xl font-bold tracking-tight text-[#151515] group-hover:text-[#D4AF37] transition-colors leading-snug">
                      {story.title}
                    </h3>

                    <p className="text-xs text-[#151515]/70 leading-relaxed font-semibold">
                      {story.excerpt}
                    </p>
                  </div>

                  {/* Read story CTA link */}
                  <button
                    className="inline-flex items-center gap-1.5 text-[9px] font-black tracking-widest text-[#151515] group-hover:text-[#D4AF37] transition-colors uppercase self-start pt-2 cursor-pointer font-ui"
                  >
                    <span>READ ARTICLE</span>
                    <ArrowRight className="h-3 w-3 transition-transform group-hover:translate-x-1" />
                  </button>
                </article>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
