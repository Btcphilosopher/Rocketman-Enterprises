import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { MenuItem, CafeLocation, TableReservation, Subscription } from "../types";
import { Sliders, Plus, BookOpen, Calendar, Mail, FileText, Trash2, CheckCircle, RefreshCw } from "lucide-react";

export default function AdminPanel() {
  const { membership } = useApp();
  const [activeTab, setActiveTab] = useState<"Menu" | "Reservations" | "Subscriptions" | "Members">("Menu");
  
  // States
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [reservations, setReservations] = useState<TableReservation[]>([]);
  const [subscriptionsList, setSubscriptionsList] = useState<Subscription[]>([]);
  const [memberships, setMemberships] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  // New Menu Item Form state
  const [name, setName] = useState("");
  const [category, setCategory] = useState("Espresso");
  const [price, setPrice] = useState("4.50");
  const [description, setDescription] = useState("");
  const [origin, setOrigin] = useState("Yirgacheffe Ethiopia");
  const [caffeine, setCaffeine] = useState("120mg");
  const [roast, setRoast] = useState("Medium");
  const [image, setImage] = useState("https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=800");
  const [isAddedSuccess, setIsAddedSuccess] = useState(false);

  useEffect(() => {
    refreshData();
  }, []);

  const refreshData = () => {
    setLoading(true);
    
    // Fetch menu
    const fetchMenu = fetch("/api/menu").then(r => r.json());
    // Fetch reservations
    const fetchReservations = fetch("/api/locations/reservations").then(r => r.json());
    // Fetch subscriptions
    const fetchSubscriptions = fetch("/api/subscriptions/all").then(r => r.json());
    // Fetch memberships
    const fetchMemberships = fetch("/api/membership/all").then(r => r.json());

    Promise.all([fetchMenu, fetchReservations, fetchSubscriptions, fetchMemberships])
      .then(([menu, res, sub, mem]) => {
        setMenuItems(menu);
        setReservations(res);
        setSubscriptionsList(sub);
        setMemberships(mem);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setLoading(false);
      });
  };

  const handleAddMenuItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !price || !description) return;

    fetch("/api/admin/menu", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        category,
        price: parseFloat(price),
        description,
        origin,
        caffeine,
        roastingProfile: roast,
        image
      })
    })
      .then(res => res.json())
      .then(() => {
        setIsAddedSuccess(true);
        refreshData();
        // Reset form
        setName("");
        setPrice("4.50");
        setDescription("");
        setOrigin("");
        setTimeout(() => setIsAddedSuccess(false), 2000);
      })
      .catch(err => console.log(err));
  };

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-12 font-ui text-left">
      
      {/* Editorial Header */}
      <div className="border-b border-[#151515]/10 pb-8 flex justify-between items-end">
        <div className="space-y-2">
          <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
            House Calibration System
          </span>
          <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
            ADMINISTRATION COCKPIT
          </h2>
          <p className="text-xs text-[#151515]/60 max-w-lg font-semibold">
            Calibrate seasonal micro-lots, update beverage records, manage oak table reservations, and monitor society memberships in real-time.
          </p>
        </div>

        <button
          onClick={refreshData}
          className="bg-[#151515] hover:bg-[#D4AF37] text-white hover:text-black px-4 py-2 rounded text-[10px] tracking-widest font-black uppercase flex items-center gap-1.5 cursor-pointer transition-colors"
        >
          <RefreshCw className="h-3.5 w-3.5" />
          <span>SYNC DATASETS</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-[#151515]/5 pb-1">
        {["Menu", "Reservations", "Subscriptions", "Members"].map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab as any)}
            className={`px-4.5 py-3 text-[10px] tracking-wider font-extrabold uppercase border-b-2 transition-all cursor-pointer ${
              activeTab === tab
                ? "border-[#D4AF37] text-[#151515]"
                : "border-transparent text-[#151515]/45 hover:text-[#151515]"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-20 text-center space-y-4">
          <div className="h-8 w-8 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-[#151515]/60 uppercase tracking-widest font-bold">Synchronizing roaster telemetries...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start animate-fadeIn">
          
          {/* TAB CONTENT: MENU MANAGER */}
          {activeTab === "Menu" && (
            <>
              {/* Form to add item */}
              <div className="lg:col-span-4 bg-white border border-[#151515]/10 rounded-2xl p-6.5 shadow-sm space-y-4">
                <div className="space-y-1 border-b border-[#151515]/5 pb-3">
                  <span className="text-[8px] tracking-widest text-[#D4AF37] font-bold uppercase">Inventory Calibration</span>
                  <h4 className="font-display text-md font-extrabold text-[#151515]">ADD MENU PROVISION</h4>
                </div>

                {isAddedSuccess ? (
                  <div className="py-12 text-center space-y-3 bg-green-50 rounded-xl border border-green-200 animate-scaleUp">
                    <div className="h-10 w-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto">
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <h5 className="font-display text-sm font-bold text-green-700">Provision Enrolled</h5>
                    <p className="text-[10px] text-[#151515]/50 uppercase tracking-widest">DIALED IN AND REGISTERED SUCCESSFULLY</p>
                  </div>
                ) : (
                  <form onSubmit={handleAddMenuItem} className="space-y-3.5">
                    
                    {/* Item Name */}
                    <div className="space-y-1">
                      <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Provision Name</label>
                      <input
                        type="text"
                        required
                        placeholder="Panama Geisha Esmeralda"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>

                    {/* Cat & Price */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Category</label>
                        <select
                          value={category}
                          onChange={(e) => setCategory(e.target.value)}
                          className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                        >
                          {["Espresso", "Pour Over", "Filter Coffee", "Cold Brew", "Tea", "Breakfast", "Lunch", "Seasonal Specials", "Coffee Cocktails"].map((c) => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Price ($)</label>
                        <input
                          type="number"
                          step="0.01"
                          required
                          value={price}
                          onChange={(e) => setPrice(e.target.value)}
                          className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>
                    </div>

                    {/* Description */}
                    <div className="space-y-1">
                      <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Description</label>
                      <input
                        type="text"
                        required
                        placeholder="Bergamot, peach, honeysuckle fragrance..."
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                      />
                    </div>

                    {/* Origin & Caffeine */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Origin</label>
                        <input
                          type="text"
                          placeholder="Boquete Panama"
                          value={origin}
                          onChange={(e) => setOrigin(e.target.value)}
                          className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Caffeine</label>
                        <input
                          type="text"
                          placeholder="120mg"
                          value={caffeine}
                          onChange={(e) => setCaffeine(e.target.value)}
                          className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                        />
                      </div>
                    </div>

                    {/* Roast Profile */}
                    <div className="space-y-1">
                      <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Roasting Profile</label>
                      <select
                        value={roast}
                        onChange={(e) => setRoast(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                      >
                        {["Light", "Medium", "Dark", "None"].map((r) => (
                          <option key={r} value={r}>{r}</option>
                        ))}
                      </select>
                    </div>

                    {/* Image URL */}
                    <div className="space-y-1">
                      <label className="text-[9px] font-extrabold uppercase tracking-widest text-[#151515]">Photo URL</label>
                      <input
                        type="text"
                        value={image}
                        onChange={(e) => setImage(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]/60"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full mt-2 bg-[#151515] hover:bg-[#D4AF37] text-white hover:text-black py-3 text-[10px] tracking-widest font-black uppercase rounded shadow cursor-pointer transition-colors"
                    >
                      ENROLL PROVISION
                    </button>
                  </form>
                )}
              </div>

              {/* Items Grid */}
              <div className="lg:col-span-8 bg-white border border-[#151515]/10 rounded-2xl p-6 shadow-sm">
                <div className="space-y-1 border-b border-[#151515]/5 pb-3 mb-4">
                  <h4 className="font-display text-md font-extrabold text-[#151515]">DIALED BEVERAGES & PROVISIONS ({menuItems.length})</h4>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-semibold text-[#151515]/80 divide-y divide-[#151515]/10">
                    <thead>
                      <tr className="text-[9px] text-[#151515]/50 uppercase tracking-wider text-left">
                        <th className="py-2.5">Provision</th>
                        <th>Category</th>
                        <th>Profile</th>
                        <th>Origin</th>
                        <th>Price</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#151515]/5">
                      {menuItems.map((item) => (
                        <tr key={item.id} className="hover:bg-[#151515]/2 transition-colors">
                          <td className="py-3 font-bold text-[#151515]">{item.name}</td>
                          <td className="uppercase text-[9px] font-black text-white bg-[#151515] px-1.5 py-0.5 rounded max-w-min text-center scale-90 inline-block mt-2.5">{item.category}</td>
                          <td>{item.roastingProfile}</td>
                          <td>{item.origin || "None"}</td>
                          <td className="font-bold text-[#D4AF37]">${item.price.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

          {/* TAB CONTENT: RESERVATIONS VIEW */}
          {activeTab === "Reservations" && (
            <div className="lg:col-span-12 bg-white border border-[#151515]/10 rounded-2xl p-6.5 shadow-sm space-y-4">
              <div className="space-y-1 border-b border-[#151515]/5 pb-3 mb-2">
                <span className="text-[8px] tracking-widest text-[#D4AF37] font-bold uppercase">Oak Study Rooms ledger</span>
                <h4 className="font-display text-md font-extrabold text-[#151515]">ACTIVE TABLE RESERVATIONS</h4>
              </div>

              {reservations.length === 0 ? (
                <div className="py-12 text-center font-semibold text-[#151515]/50 uppercase tracking-wider">No active table reservations.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-semibold text-[#151515]/80 divide-y divide-[#151515]/10">
                    <thead>
                      <tr className="text-[9px] text-[#151515]/50 uppercase tracking-wider text-left">
                        <th className="py-3">Patron Name</th>
                        <th>Email Dispatch</th>
                        <th>House Node</th>
                        <th>Date</th>
                        <th>Slot</th>
                        <th>Patrons</th>
                        <th>Instructions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#151515]/5">
                      {reservations.map((res) => (
                        <tr key={res.id} className="hover:bg-[#151515]/2 transition-colors">
                          <td className="py-3.5 font-bold text-[#151515]">{res.customerName}</td>
                          <td className="font-mono">{res.email}</td>
                          <td className="font-bold text-[#D4AF37]">{res.locationName}</td>
                          <td>{res.date}</td>
                          <td className="font-bold">{res.time}</td>
                          <td>{res.guests} Pax</td>
                          <td className="text-left font-medium italic text-[#151515]/60 max-w-xs truncate">{res.specialRequests || "None"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB CONTENT: SUBSCRIPTIONS VIEW */}
          {activeTab === "Subscriptions" && (
            <div className="lg:col-span-12 bg-white border border-[#151515]/10 rounded-2xl p-6.5 shadow-sm space-y-4">
              <div className="space-y-1 border-b border-[#151515]/5 pb-3 mb-2">
                <span className="text-[8px] tracking-widest text-[#D4AF37] font-bold uppercase">Chronicle Subscriptions Ledger</span>
                <h4 className="font-display text-md font-extrabold text-[#151515]">ACTIVE COFFEE ARCHIVES</h4>
              </div>

              {subscriptionsList.length === 0 ? (
                <div className="py-12 text-center font-semibold text-[#151515]/50 uppercase tracking-wider">No active coffee subscriptions.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-semibold text-[#151515]/80 divide-y divide-[#151515]/10">
                    <thead>
                      <tr className="text-[9px] text-[#151515]/50 uppercase tracking-wider text-left">
                        <th className="py-3">Account Reference</th>
                        <th>Roast Calibration</th>
                        <th>Origin</th>
                        <th>Frequency</th>
                        <th>Quantity</th>
                        <th>Grind Mode</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#151515]/5">
                      {subscriptionsList.map((sub) => (
                        <tr key={sub.id} className="hover:bg-[#151515]/2 transition-colors">
                          <td className="py-3.5 font-mono">{sub.userId}</td>
                          <td className="font-bold">{sub.config.roast}</td>
                          <td>{sub.config.origin}</td>
                          <td className="font-bold text-[#D4AF37]">{sub.config.frequency}</td>
                          <td>{sub.config.quantity}</td>
                          <td>{sub.config.grind}</td>
                          <td>
                            <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold ${sub.status === "Active" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700"}`}>
                              {sub.status.toUpperCase()}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB CONTENT: MEMBERSHIP DIRECTORY */}
          {activeTab === "Members" && (
            <div className="lg:col-span-12 bg-white border border-[#151515]/10 rounded-2xl p-6.5 shadow-sm space-y-4">
              <div className="space-y-1 border-b border-[#151515]/5 pb-3 mb-2">
                <span className="text-[8px] tracking-widest text-[#D4AF37] font-bold uppercase">Society Archives directory</span>
                <h4 className="font-display text-md font-extrabold text-[#151515]">REGISTERED FELLOWSHIPS</h4>
              </div>

              {memberships.length === 0 ? (
                <div className="py-12 text-center font-semibold text-[#151515]/50 uppercase tracking-wider">No registered fellows. Enroll via Society Fellowship section.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs font-semibold text-[#151515]/80 divide-y divide-[#151515]/10">
                    <thead>
                      <tr className="text-[9px] text-[#151515]/50 uppercase tracking-wider text-left">
                        <th className="py-3">Fellow Name</th>
                        <th>Email Ledger</th>
                        <th>Society ID</th>
                        <th>Fellowship Tier</th>
                        <th>Ledger Points</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#151515]/5">
                      {memberships.map((mem, idx) => (
                        <tr key={idx} className="hover:bg-[#151515]/2 transition-colors">
                          <td className="py-3.5 font-bold text-[#151515]">{mem.name}</td>
                          <td className="font-mono">{mem.email}</td>
                          <td className="font-mono text-[#D4AF37]">{mem.memberId}</td>
                          <td className="font-bold">{mem.tier}</td>
                          <td className="font-bold text-[#D4AF37]">{mem.points} PTS</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
