import React from "react";
import { useApp } from "../context/AppContext";
import { KeyRound, Menu, X, Sparkles, MapPin, Coffee, HelpCircle, PhoneCall, Compass, ShoppingBag } from "lucide-react";

export default function Sidebar({ isOpen, setIsOpen }: { isOpen: boolean; setIsOpen: (o: boolean) => void }) {
  const { currentTab, setCurrentTab, isAdmin, setIsAdmin } = useApp();

  const links = [
    { label: "HOME", value: "HOME", icon: Compass },
    { label: "OUR STORY", value: "OUR_STORY", icon: Coffee },
    { label: "MENU", value: "MENU", icon: Sparkles },
    { label: "LOCATIONS", value: "LOCATIONS", icon: MapPin },
    { label: "JOURNAL", value: "JOURNAL", icon: Sparkles },
    { label: "SHOP", value: "SHOP", icon: ShoppingBag },
    { label: "CAREERS", value: "CAREERS", icon: HelpCircle },
    { label: "CONTACT", value: "CONTACT", icon: PhoneCall },
  ];

  const handleNav = (tab: string) => {
    setCurrentTab(tab);
    setIsOpen(false);
  };

  return (
    <>
      {/* Mobile Toggle Trigger */}
      <div className="md:hidden fixed top-4 left-4 z-50 bg-[#151515] text-[#F7F2EA] p-2.5 rounded shadow-lg border border-[#F7F2EA]/10">
        <button id="sidebar-toggle" onClick={() => setIsOpen(!isOpen)} aria-label="Toggle menu">
          {isOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Sidebar Container */}
      <aside
        id="app-sidebar"
        className={`fixed inset-y-0 left-0 z-40 w-64 bg-[#151515] text-[#F7F2EA] border-r border-[#F7F2EA]/10 flex flex-col justify-between transition-transform duration-300 ease-in-out md:translate-x-0 ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        {/* Top: Branding */}
        <div className="p-8 flex flex-col items-center border-b border-[#F7F2EA]/10">
          {/* Gold Monogram */}
          <div className="mb-4 relative w-16 h-16 flex items-center justify-center border border-[#F7F2EA]/20 rounded-full bg-[#151515] group cursor-pointer hover:border-[#D4AF37]/50 transition-all duration-300">
            <span className="font-serif-logo text-3xl font-bold text-[#D4AF37] tracking-widest leading-none relative z-10 select-none">BC</span>
            <div className="absolute inset-0.5 border border-[#F7F2EA]/5 rounded-full"></div>
            {/* Soft gold glow star above */}
            <span className="absolute -top-1.5 text-xs text-[#D4AF37] animate-pulse">★</span>
          </div>

          <h1 className="font-serif-logo text-lg font-bold tracking-[0.25em] text-center text-[#F7F2EA]">
            BOSTON
          </h1>
          <p className="font-ui text-[10px] tracking-[0.4em] font-medium text-[#F7F2EA]/60 uppercase mt-1">
            Coffeehouse
          </p>
        </div>

        {/* Middle: Navigation Links */}
        <nav className="flex-1 px-6 py-8 space-y-2 overflow-y-auto">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = currentTab === link.value;
            return (
              <button
                key={link.value}
                id={`nav-${link.value.toLowerCase()}`}
                onClick={() => handleNav(link.value)}
                className={`w-full flex items-center gap-3.5 px-4 py-3 font-ui text-xs font-semibold tracking-[0.2em] rounded transition-all duration-200 text-left cursor-pointer group ${
                  isActive
                    ? "bg-[#F7F2EA] text-[#151515] font-bold"
                    : "text-[#F7F2EA]/70 hover:text-[#F7F2EA] hover:bg-[#F7F2EA]/5"
                }`}
              >
                <Icon className={`h-4 w-4 transition-transform duration-300 group-hover:scale-110 ${isActive ? "text-[#151515]" : "text-[#D4AF37]"}`} />
                <span>{link.label}</span>
              </button>
            );
          })}

          <div className="pt-6 border-t border-[#F7F2EA]/5 mt-6">
            <button
              id="nav-admin"
              onClick={() => handleNav("ADMIN")}
              className={`w-full flex items-center gap-3.5 px-4 py-3 font-ui text-[11px] font-bold tracking-[0.15em] rounded transition-all duration-200 text-left cursor-pointer group ${
                currentTab === "ADMIN"
                  ? "bg-[#D4AF37] text-[#151515]"
                  : "text-[#D4AF37]/80 hover:text-[#D4AF37] hover:bg-[#D4AF37]/5"
              }`}
            >
              <KeyRound className="h-4 w-4" />
              <span>ADMIN CONSOLE</span>
            </button>
          </div>
        </nav>

        {/* Bottom: Steeples & Founding Tag */}
        <div className="p-8 border-t border-[#F7F2EA]/10 flex flex-col items-center">
          {/* Boston Old North Church Steeple Line Art SVG */}
          <svg
            className="w-12 h-20 text-[#F7F2EA]/30 hover:text-[#D4AF37]/60 transition-colors duration-500 mb-3"
            viewBox="0 0 100 200"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
          >
            {/* Spire tip */}
            <path d="M 50 10 L 50 40" strokeWidth="2" />
            <circle cx="50" cy="10" r="1.5" fill="currentColor" />
            {/* Spire body */}
            <path d="M 46 40 L 54 40 L 52 80 L 48 80 Z" />
            {/* Upper dome */}
            <path d="M 40 80 L 60 80 Q 60 70 50 70 Q 40 70 40 80 Z" fill="currentColor" fillOpacity="0.1" />
            {/* Arch columns */}
            <rect x="42" y="80" width="16" height="30" rx="1" />
            <line x1="50" y1="80" x2="50" y2="110" />
            {/* Clock tower base */}
            <rect x="36" y="110" width="28" height="40" rx="2" />
            {/* Clock face circle */}
            <circle cx="50" cy="130" r="6" strokeWidth="1" />
            <line x1="50" y1="130" x2="50" y2="127" strokeWidth="1" />
            <line x1="50" y1="130" x2="53" y2="132" strokeWidth="1" />
            {/* Solid stone foundation lines */}
            <line x1="28" y1="150" x2="72" y2="150" strokeWidth="2" />
            <line x1="20" y1="170" x2="80" y2="170" strokeWidth="2" />
          </svg>

          <span className="font-serif-logo text-[11px] tracking-[0.2em] text-[#F7F2EA]/50 font-medium">
            EST. MMXXIV
          </span>
          <span className="text-[10px] text-[#D4AF37]/60 mt-1 animate-pulse">★</span>
        </div>
      </aside>
    </>
  );
}
