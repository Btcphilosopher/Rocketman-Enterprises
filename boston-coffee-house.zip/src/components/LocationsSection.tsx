import React, { useState, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { CafeLocation, TableReservation } from "../types";
import { MapPin, Phone, Clock, Compass, CheckCircle, Calendar, Users, Coffee } from "lucide-react";

export default function LocationsSection() {
  const { selectedLocation, setSelectedLocation } = useApp();
  const [locations, setLocations] = useState<CafeLocation[]>([]);
  const [loading, setLoading] = useState(true);

  // Booking Form State
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("10:00 AM");
  const [guests, setGuests] = useState(2);
  const [notes, setNotes] = useState("");
  const [isSuccessBooked, setIsSuccessBooked] = useState(false);

  useEffect(() => {
    fetch("/api/locations")
      .then((res) => res.json())
      .then((data) => {
        setLocations(data);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, []);

  const activeLoc = locations.find((l) => l.name === selectedLocation) || locations[0];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !date) return;

    fetch("/api/locations/reserve", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        locationId: activeLoc.id,
        locationName: activeLoc.name,
        date,
        time,
        guests,
        specialRequests: notes,
        customerName: name,
        email
      })
    })
      .then((res) => res.json())
      .then(() => {
        setIsSuccessBooked(true);
        setTimeout(() => {
          setIsSuccessBooked(false);
          setName("");
          setEmail("");
          setDate("");
          setNotes("");
        }, 3000);
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-16 font-ui">
      {/* Editorial Header */}
      <div className="border-b border-[#151515]/10 pb-8 space-y-2">
        <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
          Aesthetic Sanctuaries
        </span>
        <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
          OUR COFFEE HOUSES
        </h2>
        <p className="text-xs text-[#151515]/60 max-w-lg font-semibold">
          Each house is structurally designed in response to its neighborhood's historical architectural legacy, curated with oak, stone, and burnished brass.
        </p>
      </div>

      {loading ? (
        <div className="py-20 text-center space-y-4">
          <div className="h-8 w-8 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-xs text-[#151515]/60 uppercase tracking-widest font-bold font-ui">Mapping Boston...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Column: House Selector & Interactive stylized Vector Map */}
          <div className="lg:col-span-5 space-y-8 flex flex-col justify-between">
            
            {/* Quick Select Buttons */}
            <div className="space-y-2">
              <p className="text-[10px] tracking-widest text-[#151515]/50 uppercase font-black">Select Coffee House</p>
              <div className="grid grid-cols-2 gap-2">
                {locations.map((loc) => (
                  <button
                    key={loc.id}
                    onClick={() => setSelectedLocation(loc.name)}
                    className={`px-4 py-3 text-[10px] tracking-[0.15em] font-bold uppercase rounded border transition-all cursor-pointer ${
                      selectedLocation === loc.name
                        ? "bg-[#151515] text-[#F7F2EA] border-transparent shadow-lg"
                        : "bg-white text-[#151515]/75 border-[#151515]/15 hover:bg-[#151515]/5"
                    }`}
                  >
                    {loc.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Stylized Vector Dark Map matching Anglo-Futurist design principles */}
            <div className="relative bg-[#151515] text-[#F7F2EA] p-6 rounded-2xl border border-white/5 shadow-xl h-80 overflow-hidden flex flex-col justify-between group">
              {/* Map Title overlay */}
              <div className="relative z-10 flex justify-between items-start">
                <div>
                  <p className="text-[8px] tracking-[0.25em] font-extrabold text-[#D4AF37] uppercase">Interactive Map</p>
                  <h4 className="font-display text-sm font-bold tracking-tight text-[#F7F2EA] mt-0.5">COMMONWEALTH DISTRICT</h4>
                </div>
                <span className="text-[8px] font-semibold text-white/40 tracking-widest">GPS BOUND: 42.3601° N</span>
              </div>

              {/* Vector Lines & Grid Design representing the Boston map layout */}
              <div className="absolute inset-0 z-0 opacity-20 pointer-events-none select-none">
                <svg className="w-full h-full" viewBox="0 0 400 300">
                  {/* Grid System lines */}
                  <line x1="0" y1="50" x2="400" y2="50" stroke="#F7F2EA" strokeWidth="0.5" strokeDasharray="3,3" />
                  <line x1="0" y1="150" x2="400" y2="150" stroke="#F7F2EA" strokeWidth="0.5" strokeDasharray="3,3" />
                  <line x1="0" y1="250" x2="400" y2="250" stroke="#F7F2EA" strokeWidth="0.5" strokeDasharray="3,3" />
                  <line x1="100" y1="0" x2="100" y2="300" stroke="#F7F2EA" strokeWidth="0.5" strokeDasharray="3,3" />
                  <line x1="250" y1="0" x2="250" y2="300" stroke="#F7F2EA" strokeWidth="0.5" strokeDasharray="3,3" />

                  {/* Topographic curves / River contour */}
                  <path d="M -10 180 Q 80 120 180 140 T 320 60 T 420 40" fill="none" stroke="#D4AF37" strokeWidth="1.5" strokeDasharray="2,5" />
                  <text x="220" y="90" fill="#F7F2EA" fontSize="8" letterSpacing="2" opacity="0.3">CHARLES RIVER</text>
                  <path d="M 280 200 Q 320 220 380 210" fill="none" stroke="#D4AF37" strokeWidth="1" />
                  <text x="320" y="240" fill="#F7F2EA" fontSize="8" letterSpacing="2" opacity="0.3">BOSTON HARBOR</text>

                  {/* Harvard Square line */}
                  <line x1="50" y1="60" x2="200" y2="150" stroke="#F7F2EA" strokeWidth="0.25" />
                  {/* Seaport line */}
                  <line x1="320" y1="210" x2="200" y2="150" stroke="#F7F2EA" strokeWidth="0.25" />
                </svg>
              </div>

              {/* Glowing Interactive Landmark Nodes */}
              <div className="absolute inset-0 z-10 pointer-events-none">
                {/* 1. Beacon Hill Node (Center Top) */}
                <div className="absolute top-[120px] left-[200px] flex flex-col items-center">
                  <div className={`h-4.5 w-4.5 rounded-full flex items-center justify-center transition-all duration-500 ${selectedLocation === "Beacon Hill" ? "bg-[#D4AF37] scale-125 shadow-[0_0_12px_rgba(212,175,55,0.7)]" : "bg-white/40"}`}>
                    <div className="h-1.5 w-1.5 bg-[#151515] rounded-full"></div>
                  </div>
                  <span className="text-[8px] font-bold tracking-wider uppercase mt-1 bg-[#151515]/90 px-1 py-0.5 rounded text-white/70">BEACON HILL</span>
                </div>

                {/* 2. Harvard Square Node (Top Left) */}
                <div className="absolute top-[60px] left-[60px] flex flex-col items-center">
                  <div className={`h-4.5 w-4.5 rounded-full flex items-center justify-center transition-all duration-500 ${selectedLocation === "Harvard Square" ? "bg-[#D4AF37] scale-125 shadow-[0_0_12px_rgba(212,175,55,0.7)]" : "bg-white/40"}`}>
                    <div className="h-1.5 w-1.5 bg-[#151515] rounded-full"></div>
                  </div>
                  <span className="text-[8px] font-bold tracking-wider uppercase mt-1 bg-[#151515]/90 px-1 py-0.5 rounded text-white/70">CAMBRIDGE</span>
                </div>

                {/* 3. Boston Seaport Node (Right Bottom) */}
                <div className="absolute top-[190px] left-[300px] flex flex-col items-center">
                  <div className={`h-4.5 w-4.5 rounded-full flex items-center justify-center transition-all duration-500 ${selectedLocation === "Boston Seaport" ? "bg-[#D4AF37] scale-125 shadow-[0_0_12px_rgba(212,175,55,0.7)]" : "bg-white/40"}`}>
                    <div className="h-1.5 w-1.5 bg-[#151515] rounded-full"></div>
                  </div>
                  <span className="text-[8px] font-bold tracking-wider uppercase mt-1 bg-[#151515]/90 px-1 py-0.5 rounded text-white/70">SEAPORT</span>
                </div>

                {/* 4. South End Node (Left Bottom) */}
                <div className="absolute top-[220px] left-[150px] flex flex-col items-center">
                  <div className={`h-4.5 w-4.5 rounded-full flex items-center justify-center transition-all duration-500 ${selectedLocation === "South End" ? "bg-[#D4AF37] scale-125 shadow-[0_0_12px_rgba(212,175,55,0.7)]" : "bg-white/40"}`}>
                    <div className="h-1.5 w-1.5 bg-[#151515] rounded-full"></div>
                  </div>
                  <span className="text-[8px] font-bold tracking-wider uppercase mt-1 bg-[#151515]/90 px-1 py-0.5 rounded text-white/70">SOUTH END</span>
                </div>
              </div>

              {/* Bottom Quick-Info status label */}
              <div className="relative z-10 text-[9px] font-semibold text-[#F7F2EA]/60 uppercase tracking-wider flex items-center gap-1">
                <Compass className="h-3.5 w-3.5 text-[#D4AF37] animate-spin" style={{ animationDuration: '6s' }} />
                <span>Showing node details for {selectedLocation}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Detailed House details & Custom Booking Form */}
          {activeLoc && (
            <div className="lg:col-span-7 space-y-10 animate-fadeIn">
              {/* Photo & Main Details Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                
                {/* Large Photo and Interior tour */}
                <div className="space-y-3">
                  <div className="relative h-64 rounded-xl overflow-hidden shadow">
                    <img
                      src={activeLoc.image}
                      alt={activeLoc.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  {/* Secondary interior tour photos */}
                  <div className="grid grid-cols-2 gap-2">
                    {activeLoc.interiorTour.map((tourUrl, idx) => (
                      <div key={idx} className="relative h-24 rounded-lg overflow-hidden shadow-sm">
                        <img
                          src={tourUrl}
                          alt="Cafe details"
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    ))}
                  </div>
                </div>

                {/* Location Quick Stats */}
                <div className="space-y-5 text-left">
                  <div>
                    <h3 className="font-display text-2xl font-black tracking-tight text-[#151515]">{activeLoc.name}</h3>
                    <p className="text-xs text-[#D4AF37] tracking-widest font-extrabold uppercase mt-1">{activeLoc.address}</p>
                  </div>

                  <p className="text-[11px] font-semibold leading-relaxed text-[#151515]/75">
                    {activeLoc.description}
                  </p>

                  <div className="space-y-2 text-xs font-semibold text-[#151515]/70 divide-y divide-[#151515]/5">
                    <div className="flex items-center gap-2.5 pt-2">
                      <Clock className="h-4 w-4 text-[#D4AF37]" />
                      <span>
                        WEEKDAYS: {activeLoc.hours.weekdays} <br />
                        WEEKENDS: {activeLoc.hours.weekends}
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5 pt-2.5">
                      <Phone className="h-4 w-4 text-[#D4AF37]" />
                      <span>{activeLoc.phone}</span>
                    </div>
                    <div className="pt-2.5">
                      <p className="text-[10px] text-[#151515]/40 uppercase tracking-widest font-extrabold">PARKING PROVISIONS:</p>
                      <p className="mt-0.5">{activeLoc.parking}</p>
                    </div>
                    <div className="pt-2.5">
                      <p className="text-[10px] text-[#151515]/40 uppercase tracking-widest font-extrabold">ACCESSIBILITY:</p>
                      <p className="mt-0.5">{activeLoc.accessibility}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Table reservation Engine */}
              <div className="bg-white border border-[#151515]/10 rounded-2xl p-8 shadow-sm">
                <div className="border-b border-[#151515]/5 pb-4 mb-6">
                  <h4 className="font-display text-lg font-extrabold text-[#151515] flex items-center gap-2">
                    <Calendar className="h-4.5 w-4.5 text-[#D4AF37]" />
                    <span>RESERVE AN OAK TABLE</span>
                  </h4>
                  <p className="text-[10px] text-[#151515]/60 uppercase tracking-widest font-semibold mt-1">
                    Book complimentary library seating, private alcoves or tasting tables
                  </p>
                </div>

                {isSuccessBooked ? (
                  <div className="text-center py-8 space-y-3 animate-scaleUp">
                    <div className="h-10 w-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto shadow-sm">
                      <CheckCircle className="h-5 w-5" />
                    </div>
                    <h5 className="font-display text-md font-extrabold text-green-700">Oak Table Confirmed</h5>
                    <p className="text-xs font-semibold text-[#151515]/60 max-w-sm mx-auto">
                      A quiet, polished space has been set aside for you at our {activeLoc.name} house. A confirmation has been dispatched to {email}.
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleBooking} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Full Name */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold tracking-widest uppercase text-[#151515]">Full Name</label>
                      <input
                        type="text"
                        required
                        placeholder="Emerson Alcott"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                      />
                    </div>

                    {/* Email */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold tracking-widest uppercase text-[#151515]">Email Dispatch</label>
                      <input
                        type="email"
                        required
                        placeholder="emerson@commonwealth.org"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                      />
                    </div>

                    {/* Date */}
                    <div className="space-y-1.5">
                      <label className="text-[10px] font-extrabold tracking-widest uppercase text-[#151515]">Desired Date</label>
                      <input
                        type="date"
                        required
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                      />
                    </div>

                    {/* Time & Guests */}
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-extrabold tracking-widest uppercase text-[#151515]">Time Slot</label>
                        <select
                          value={time}
                          onChange={(e) => setTime(e.target.value)}
                          className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                        >
                          {["8:00 AM", "10:00 AM", "12:00 PM", "2:00 PM", "4:00 PM", "6:00 PM"].map((t) => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-[10px] font-extrabold tracking-widest uppercase text-[#151515]">Patrons</label>
                        <select
                          value={guests}
                          onChange={(e) => setGuests(parseInt(e.target.value))}
                          className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                        >
                          {[1, 2, 3, 4, 6, 8].map((g) => (
                            <option key={g} value={g}>{g} {g === 1 ? "Patron" : "Patrons"}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Special requests */}
                    <div className="md:col-span-2 space-y-1.5">
                      <label className="text-[10px] font-extrabold tracking-widest uppercase text-[#151515]">Alcove Preference or Special Requests</label>
                      <input
                        type="text"
                        placeholder="Library reading chair, quiet study desk, wheelchair access table..."
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
                      />
                    </div>

                    <button
                      type="submit"
                      className="md:col-span-2 mt-4 bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] py-3.5 text-[10px] tracking-widest font-extrabold uppercase rounded shadow transition-all duration-300 cursor-pointer"
                    >
                      CONFIRM COMPLIMENTARY OAK SEATING
                    </button>
                  </form>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
