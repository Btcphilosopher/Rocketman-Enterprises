import React, { useState, useRef, useEffect } from "react";
import { useApp } from "../context/AppContext";
import { MenuItem } from "../types";
import { Sparkles, Send, Coffee, Bookmark, RefreshCw, MessageSquare } from "lucide-react";

interface ChatMessage {
  sender: "user" | "claire";
  text: string;
  recommendation?: MenuItem;
}

export default function AiSommelierSection() {
  const { addToCart } = useApp();
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: "claire",
      text: "Welcome to the Coffeehouse Library. I am Claire, your Artificial Sommelier. I have cataloged bean archives across the volcanic valley of Panama and the high plateaus of Ethiopia, alongside Boston's rich espresso traditions. How may I dial in your cup or pair your pastry today?"
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    const userMsg = textToSend;
    setInputText("");
    setMessages((prev) => [...prev, { sender: "user", text: userMsg }]);
    setLoading(true);

    try {
      const response = await fetch("/api/sommelier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsg })
      });
      const data = await response.json();

      setMessages((prev) => [
        ...prev,
        {
          sender: "claire",
          text: data.reply,
          recommendation: data.recommendation || undefined
        }
      ]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          sender: "claire",
          text: "Forgive me, the roaster telemetry seems momentarily disconnected. Let me try dialing the signal again."
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const presetQueries = [
    "Recommend a light origin matching high acidity and floral notes.",
    "Which bean matches an organic morning almond croissant?",
    "Tell me about Panama Volcano Valley Esmeralda Geisha.",
    "What espresso cocktail do you advise for an afternoon study?"
  ];

  const handleAddRecommended = (item: MenuItem) => {
    addToCart(item, 1, {
      milk: "Whole",
      sweetness: "Standard",
      espressoShots: 0,
      beans: "House Blend (Medium)",
      notes: "Recommended by Sommelier Claire"
    });
    alert(`Recommended ${item.name} has been added to your shopping bag.`);
  };

  return (
    <div className="max-w-5xl mx-auto px-6 pb-20 space-y-12 font-ui text-left">
      
      {/* Editorial Header */}
      <div className="border-b border-[#151515]/10 pb-8 space-y-2">
        <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
          Artificial Intelligence Companion
        </span>
        <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
          CLAIRE: COFFEE SOMMELIER
        </h2>
        <p className="text-xs text-[#151515]/60 max-w-lg font-semibold">
          Converse with our digital assistant. Powered by Gemini, Claire analyzes roasting curves, origins, and pastry pairings in real-time.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch h-[600px]">
        
        {/* Left Column: Preset Queries */}
        <div className="lg:col-span-4 space-y-6 flex flex-col justify-between bg-[#151515] text-[#F7F2EA] p-6 rounded-2xl border border-white/5 shadow-xl">
          <div className="space-y-4">
            <div className="space-y-1">
              <p className="text-[8px] tracking-[0.25em] font-extrabold text-[#D4AF37] uppercase">Claire's Prompt Archives</p>
              <h4 className="font-display text-md font-bold tracking-tight text-white">CHOOSE A DIALOG</h4>
            </div>
            <div className="space-y-2.5">
              {presetQueries.map((q) => (
                <button
                  key={q}
                  onClick={() => handleSend(q)}
                  disabled={loading}
                  className="w-full text-left bg-white/5 hover:bg-white/10 text-[10px] font-semibold p-3.5 rounded border border-white/10 hover:border-[#D4AF37] transition-all duration-300 uppercase tracking-wider leading-relaxed cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>

          <div className="text-[9px] text-white/50 border-t border-white/10 pt-4 font-semibold uppercase tracking-widest flex items-center gap-1.5 leading-none">
            <Sparkles className="h-3.5 w-3.5 text-[#D4AF37] animate-pulse" />
            <span>Telemetry calibrated with Gemini Pro</span>
          </div>
        </div>

        {/* Right Column: Chat Interface */}
        <div className="lg:col-span-8 bg-white border border-[#151515]/10 rounded-2xl overflow-hidden flex flex-col justify-between shadow-sm">
          
          {/* Messages Flow Area */}
          <div className="p-6 flex-1 overflow-y-auto space-y-6 bg-[#151515]/2">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex gap-3.5 max-w-[85%] ${
                  msg.sender === "user" ? "ml-auto flex-row-reverse" : "mr-auto"
                } animate-slideUp`}
              >
                {/* Profile Circle icon */}
                <div className={`h-8 w-8 rounded-full border flex items-center justify-center shrink-0 shadow-sm ${
                  msg.sender === "user" ? "bg-[#151515] border-transparent text-white" : "bg-white border-[#D4AF37] text-[#D4AF37]"
                }`}>
                  {msg.sender === "user" ? <Bookmark className="h-4 w-4" /> : <Coffee className="h-4 w-4" />}
                </div>

                {/* Message Body Bubble */}
                <div className="space-y-3">
                  <div className={`p-4 rounded-2xl text-xs font-semibold leading-relaxed shadow-sm ${
                    msg.sender === "user"
                      ? "bg-[#151515] text-[#F7F2EA] rounded-tr-none"
                      : "bg-white text-[#151515] rounded-tl-none border border-[#151515]/5"
                  }`}>
                    {msg.text}
                  </div>

                  {/* Recommended Beverage Card Overlay (Claire recommendations) */}
                  {msg.recommendation && (
                    <div className="bg-[#F7F2EA] border border-[#D4AF37]/45 rounded-xl p-4.5 shadow flex flex-col md:flex-row items-stretch gap-4 animate-scaleUp">
                      <div className="h-20 w-20 rounded-lg overflow-hidden shrink-0 bg-[#151515]/5 shadow-sm">
                        <img
                          src={msg.recommendation.image}
                          alt={msg.recommendation.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div className="flex-1 flex flex-col justify-between items-start text-left">
                        <div className="space-y-0.5">
                          <span className="text-[8px] tracking-widest font-black text-[#D4AF37] uppercase">{msg.recommendation.category}</span>
                          <h5 className="font-display text-sm font-black text-[#151515] leading-tight">{msg.recommendation.name}</h5>
                          <p className="text-[10px] text-[#151515]/65 leading-relaxed font-semibold line-clamp-1">{msg.recommendation.description}</p>
                        </div>
                        <button
                          onClick={() => handleAddRecommended(msg.recommendation!)}
                          className="mt-2 bg-[#151515] hover:bg-[#D4AF37] text-white hover:text-black px-3 py-1.5 rounded text-[9px] font-black tracking-wider uppercase transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <Coffee className="h-3 w-3" />
                          <span>ADD REC TO BAG</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {loading && (
              <div className="flex gap-3 max-w-[80%] animate-pulse mr-auto">
                <div className="h-8 w-8 rounded-full bg-white border border-[#D4AF37] text-[#D4AF37] flex items-center justify-center shrink-0 animate-spin">
                  <RefreshCw className="h-4 w-4" />
                </div>
                <div className="bg-white p-4 rounded-xl text-xs font-semibold text-[#151515]/50 border border-[#151515]/5 rounded-tl-none flex items-center gap-1.5 shadow-sm">
                  <span>Claire is sampling flavor ledgers...</span>
                </div>
              </div>
            )}
            
            <div ref={scrollRef}></div>
          </div>

          {/* Form message Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(inputText);
            }}
            className="p-4 border-t border-[#151515]/10 flex gap-2 items-center bg-white"
          >
            <input
              type="text"
              disabled={loading}
              placeholder="Ask Claire for bean pairing, roasting advice or origin facts..."
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="flex-1 bg-[#151515]/3 border border-[#151515]/10 rounded px-4 py-3.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37] text-[#151515]"
            />
            <button
              type="submit"
              disabled={loading || !inputText.trim()}
              className="bg-[#151515] hover:bg-[#D4AF37] text-white hover:text-black p-3.5 rounded transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <Send className="h-4.5 w-4.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
