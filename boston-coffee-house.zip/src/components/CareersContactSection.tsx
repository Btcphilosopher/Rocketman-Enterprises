import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { FileUp, CheckCircle, Mail, MapPin, Briefcase, ChevronRight, Compass } from "lucide-react";

export default function CareersContactSection() {
  const [activeJob, setActiveJob] = useState<any | null>(null);
  
  // Job apply state
  const [candidateName, setCandidateName] = useState("");
  const [candidateEmail, setCandidateEmail] = useState("");
  const [candidatePhone, setCandidatePhone] = useState("");
  const [candidateCover, setCandidateCover] = useState("");
  const [resumeName, setResumeName] = useState("");
  const [dragActive, setDragActive] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);

  // Contact state
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactSubject, setContactSubject] = useState("General Inquiry");
  const [contactMessage, setContactMessage] = useState("");
  const [contactSuccess, setContactSuccess] = useState(false);

  const jobs = [
    {
      id: "j1",
      title: "Master Roaster / Coffee Director",
      department: "Craftsmanship & Science",
      location: "East Boston Roastery",
      description: "Direct our micro-batch thermodynamic roasting curves. Require 5+ years of roasting experience with high-altitude micro-lots and deep familiarity with Loring or Probat roasting curves."
    },
    {
      id: "j2",
      title: "Senior Head Barista",
      department: "Hospitality & Service",
      location: "Beacon Hill House",
      description: "Lead our barista crew in Dialing, Latte Art calibration, and direct patron hospitality. Require an obsessive focus on detail and a genuine warmth matching New England values."
    },
    {
      id: "j3",
      title: "Pastry Chef De Partie",
      department: "Provisions & Pastry",
      location: "Boston Central Bakery",
      description: "Oversee the daily fermentation of our 36-hour wild yeast croissants and New England tarts. Require classic French/Swiss pastry training and a passion for local organic grains."
    },
    {
      id: "j4",
      title: "Architectural Space Designer",
      department: "Aesthetics & Design",
      location: "Boston Offices (Beacon Hill)",
      description: "Collaborate with lead creative directors to conceptualize physical cafe renovations combining mid-century modern, Swiss, and New England historic architectural frameworks."
    }
  ];

  // Drag and drop resume handler
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setResumeName(e.dataTransfer.files[0].name);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setResumeName(e.target.files[0].name);
    }
  };

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!candidateName || !candidateEmail || !resumeName) {
      alert("Please specify candidate details and upload a PDF CV.");
      return;
    }
    setApplySuccess(true);
    setTimeout(() => {
      setApplySuccess(false);
      setActiveJob(null);
      setCandidateName("");
      setCandidateEmail("");
      setCandidatePhone("");
      setCandidateCover("");
      setResumeName("");
    }, 3000);
  };

  const handleContact = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMessage) return;
    setContactSuccess(true);
    setTimeout(() => {
      setContactSuccess(false);
      setContactName("");
      setContactEmail("");
      setContactMessage("");
    }, 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 pb-20 space-y-20 font-ui text-left">
      
      {/* 1. SECTION HEADERS */}
      <div className="border-b border-[#151515]/10 pb-8 space-y-2">
        <span className="text-[10px] tracking-[0.35em] font-extrabold text-[#D4AF37] uppercase block">
          Work & Dialogue
        </span>
        <h2 className="font-display text-4xl font-extrabold tracking-tight text-[#151515]">
          CAREERS & PATRON INQUIRIES
        </h2>
        <p className="text-xs text-[#151515]/60 max-w-lg font-semibold">
          Join our architectural or roasting guild in Boston, or dispatch direct messages regarding corporate catering and general feedback.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left: Careers Panel */}
        <div className="lg:col-span-6 space-y-8">
          <div className="space-y-2">
            <span className="text-[9px] tracking-[0.25em] font-extrabold text-[#D4AF37] uppercase">Careers Guild</span>
            <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">JOIN BOSTON COFFEEHOUSE</h3>
            <p className="text-xs text-[#151515]/75 leading-relaxed font-semibold">
              We recruit meticulous individuals who respect craftsmanship, intellectual conversations, and absolute New England quality. View our open positions.
            </p>
          </div>

          <div className="space-y-4">
            {jobs.map((job) => (
              <div
                key={job.id}
                className="bg-white border border-[#151515]/10 rounded-xl p-5 hover:shadow-md transition-all duration-300 flex justify-between items-center group cursor-pointer"
                onClick={() => {
                  setActiveJob(job);
                  setApplySuccess(false);
                }}
              >
                <div className="space-y-1 max-w-[85%]">
                  <span className="text-[8px] font-bold tracking-widest text-[#D4AF37] uppercase">{job.department}</span>
                  <h4 className="font-display text-md font-extrabold text-[#151515] group-hover:text-[#D4AF37] transition-colors">
                    {job.title}
                  </h4>
                  <p className="text-[10px] font-semibold text-[#151515]/50 uppercase tracking-wider flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    <span>{job.location}</span>
                  </p>
                </div>
                <ChevronRight className="h-4.5 w-4.5 text-[#151515]/40 group-hover:translate-x-1 transition-transform" />
              </div>
            ))}
          </div>
        </div>

        {/* Right: Contact Form */}
        <div className="lg:col-span-6 bg-white border border-[#151515]/10 rounded-2xl p-8 shadow-sm">
          <div className="space-y-2 border-b border-[#151515]/5 pb-4 mb-6">
            <span className="text-[9px] tracking-[0.25em] font-extrabold text-[#D4AF37] uppercase">Contact Bureau</span>
            <h3 className="font-display text-2xl font-bold tracking-tight text-[#151515]">PATRON CORRESPONDENCE</h3>
          </div>

          {contactSuccess ? (
            <div className="py-12 text-center space-y-4 animate-scaleUp">
              <div className="h-10 w-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto">
                <CheckCircle className="h-5 w-5" />
              </div>
              <h4 className="font-display text-lg font-bold text-green-700">Dispatch Successful</h4>
              <p className="text-xs font-semibold text-[#151515]/60 max-w-sm mx-auto uppercase">
                YOUR CORRESPONDENCE IS PACKED AND SENT. Claire will respond shortly.
              </p>
            </div>
          ) : (
            <form onSubmit={handleContact} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Your Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Abigail Quincy"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Your Email</label>
                  <input
                    type="email"
                    required
                    placeholder="abigail@commonwealth.org"
                    value={contactEmail}
                    onChange={(e) => setContactEmail(e.target.value)}
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Subject Department</label>
                <select
                  value={contactSubject}
                  onChange={(e) => setContactSubject(e.target.value)}
                  className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                >
                  {["General Inquiry", "Catering & Private Events", "Wholesale Beans Partnership", "Press & Media Bureau"].map((opt) => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Your Message</label>
                <textarea
                  required
                  rows={4}
                  placeholder="Inquire regarding unlacquered brass provisions, V60 masterclasses, or corporate deliveries..."
                  value={contactMessage}
                  onChange={(e) => setContactMessage(e.target.value)}
                  className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                ></textarea>
              </div>

              <button
                type="submit"
                className="w-full bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] py-3 text-[10px] tracking-widest font-extrabold uppercase rounded shadow transition-all duration-300 cursor-pointer"
              >
                DISPATCH MESSAGE
              </button>
            </form>
          )}
        </div>
      </div>

      {/* 2. DYNAMIC CAREER SPECIFIC APPLICATION DIALOG */}
      {activeJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#151515]/60 backdrop-blur-sm animate-fadeIn">
          <div className="absolute inset-0" onClick={() => setActiveJob(null)}></div>

          <div className="relative bg-[#F7F2EA] w-full max-w-xl rounded-2xl shadow-2xl border border-[#151515]/15 overflow-hidden z-10 animate-slideUp text-left p-8 space-y-6 max-h-[90vh] overflow-y-auto">
            
            {/* Header */}
            <div className="flex justify-between items-start border-b border-[#151515]/10 pb-4">
              <div>
                <span className="text-[8px] font-bold tracking-widest text-[#D4AF37] uppercase">{activeJob.department}</span>
                <h3 className="font-display text-xl font-black text-[#151515] leading-tight mt-0.5">{activeJob.title}</h3>
                <p className="text-[10px] font-semibold text-[#151515]/50 uppercase tracking-wider">{activeJob.location}</p>
              </div>
              <button onClick={() => setActiveJob(null)} className="text-xs font-bold text-[#151515]/40 hover:text-[#151515] uppercase cursor-pointer">
                [X]
              </button>
            </div>

            {/* Description */}
            <p className="text-xs font-semibold leading-relaxed text-[#151515]/80">
              {activeJob.description}
            </p>

            {applySuccess ? (
              <div className="py-12 text-center space-y-3 animate-scaleUp">
                <div className="h-10 w-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center mx-auto">
                  <CheckCircle className="h-5 w-5" />
                </div>
                <h4 className="font-display text-lg font-bold text-green-700">Application Lodged</h4>
                <p className="text-xs font-semibold text-[#151515]/60 max-w-sm mx-auto uppercase">
                  THANK YOU FOR CONVOKING YOUR DETAILS. OUT ROASTER BOARD WILL RESPOND IN 72 HOURS.
                </p>
              </div>
            ) : (
              <form onSubmit={handleApply} className="space-y-4">
                
                {/* Form Inputs */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Full Name</label>
                    <input
                      type="text"
                      required
                      value={candidateName}
                      onChange={(e) => setCandidateName(e.target.value)}
                      placeholder="Nathaniel Hawthorne"
                      className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Email Address</label>
                    <input
                      type="email"
                      required
                      value={candidateEmail}
                      onChange={(e) => setCandidateEmail(e.target.value)}
                      placeholder="hawthorne@salem.org"
                      className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                    />
                  </div>
                </div>

                {/* Usability Pattern: Drag and Drop + Manual Select File Upload */}
                <div className="space-y-2">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Curriculum Vitae (PDF Resume)</label>
                  
                  <div
                    onDragEnter={handleDrag}
                    onDragOver={handleDrag}
                    onDragLeave={handleDrag}
                    onDrop={handleDrop}
                    className={`w-full bg-[#151515]/2 border-2 border-dashed rounded-xl p-6 flex flex-col items-center justify-center text-center transition-all cursor-pointer ${
                      dragActive ? "border-[#D4AF37] bg-[#D4AF37]/5" : "border-[#151515]/15"
                    }`}
                  >
                    <input
                      type="file"
                      id="resume-upload"
                      className="hidden"
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileSelect}
                    />
                    
                    <label htmlFor="resume-upload" className="cursor-pointer space-y-2 flex flex-col items-center">
                      <FileUp className="h-8 w-8 text-[#D4AF37] animate-bounce" style={{ animationDuration: '3s' }} />
                      
                      {resumeName ? (
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-green-700 uppercase">File Selected</p>
                          <p className="text-[10px] text-[#151515]/60 font-semibold italic">{resumeName}</p>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-[#151515] uppercase">Drag & Drop CV or Click to Browse</p>
                          <p className="text-[9px] text-[#151515]/40 font-semibold">Supports PDF, Word Format (Max 10MB)</p>
                        </div>
                      )}
                    </label>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]">Briefly, why do you value New England Craftsmanship?</label>
                  <textarea
                    rows={3}
                    placeholder="Detail your appreciation for unhurried, beautiful physical architecture and flavor dials..."
                    value={candidateCover}
                    onChange={(e) => setCandidateCover(e.target.value)}
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2.5 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#151515] hover:bg-[#D4AF37] text-[#F7F2EA] hover:text-[#151515] py-3 text-[10px] tracking-widest font-extrabold uppercase rounded shadow transition-all duration-300 cursor-pointer"
                >
                  SUBMIT FORM TO ROASTER COPT
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
