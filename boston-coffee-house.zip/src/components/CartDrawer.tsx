import React, { useState } from "react";
import { useApp } from "../context/AppContext";
import { X, Trash2, ShoppingBag, Clock, Sparkles, CheckCircle } from "lucide-react";

export default function CartDrawer({ isOpen, onClose }: { isOpen: boolean; onClose: () => void }) {
  const { cart, shopCart, removeFromCart, removeFromShopCart, updateCartQty, updateShopCartQty, clearCart, membership, setMembership } = useApp();
  const [scheduledTime, setScheduledTime] = useState("Immediate (10-15 mins)");
  const [paymentMethod, setPaymentMethod] = useState("Apple Pay / Credit Card");
  
  // Checkout states
  const [checkoutStep, setCheckoutStep] = useState<"Cart" | "Success">("Cart");
  const [orderId, setOrderId] = useState("");
  const [checkingOut, setCheckingOut] = useState(false);

  const subtotalDrinks = cart.reduce((acc, item) => acc + (item.menuItem.price + (item.customization.espressoShots * 0.8)) * item.quantity, 0);
  const subtotalShop = shopCart.reduce((acc, item) => acc + item.storeItem.price * item.quantity, 0);
  const subtotal = subtotalDrinks + subtotalShop;
  
  const tax = subtotal * 0.0625; // Boston Sales tax 6.25%
  const fee = subtotal > 0 ? 0.50 : 0;
  const total = subtotal + tax + fee;

  const handleCheckout = () => {
    if (subtotal === 0 || checkingOut) return;
    setCheckingOut(true);

    const drinksPayload = cart.map(item => ({
      itemId: item.menuItem.id,
      name: item.menuItem.name,
      quantity: item.quantity,
      customization: item.customization
    }));

    const retailPayload = shopCart.map(item => ({
      itemId: item.storeItem.id,
      name: item.storeItem.name,
      quantity: item.quantity
    }));

    fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        items: drinksPayload,
        retailItems: retailPayload,
        totalAmount: total,
        pickupTime: scheduledTime
      })
    })
      .then(res => res.json())
      .then(data => {
        setOrderId(data.orderId);
        
        // Award point to members!
        if (membership) {
          const awardedPoints = Math.floor(subtotal * 10);
          fetch("/api/membership/points", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              memberId: membership.memberId,
              points: awardedPoints
            })
          })
            .then(res => res.json())
            .then(updatedMem => {
              setMembership(updatedMem);
            })
            .catch(err => console.log(err));
        }

        setCheckingOut(false);
        setCheckoutStep("Success");
        clearCart();
      })
      .catch(err => {
        console.error(err);
        setCheckingOut(false);
      });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end font-ui">
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={onClose}></div>

      {/* Drawer Container */}
      <div className="relative bg-[#F7F2EA] w-full max-w-md h-full shadow-2xl flex flex-col justify-between z-10 border-l border-[#151515]/15 animate-slideLeft text-left">
        
        {/* Header */}
        <div className="p-6 border-b border-[#151515]/10 flex justify-between items-center bg-[#151515] text-[#F7F2EA]">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-[#D4AF37]" />
            <h3 className="font-display text-lg font-extrabold tracking-tight">YOUR ORDER BAG</h3>
          </div>
          <button onClick={onClose} className="text-white/60 hover:text-white cursor-pointer">[ CLOSE ]</button>
        </div>

        {/* Dynamic Steps */}
        {checkoutStep === "Success" ? (
          // SUCCESSFUL CHECKOUT SCREEN
          <div className="flex-1 p-8 flex flex-col justify-center items-center text-center space-y-6">
            <div className="h-16 w-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center shadow-lg animate-scaleUp">
              <CheckCircle className="h-10 w-10 stroke-[3]" />
            </div>

            <div className="space-y-2">
              <span className="text-[10px] tracking-[0.3em] font-black text-[#D4AF37] uppercase">PREPARATION STARTED</span>
              <h4 className="font-display text-2xl font-black text-[#151515]">Order Dispatched</h4>
              <p className="text-xs font-mono text-[#151515]/60 bg-white border border-[#151515]/10 px-3 py-1.5 rounded inline-block">ID: {orderId}</p>
            </div>

            <div className="w-16 h-0.5 bg-[#D4AF37]"></div>

            <p className="text-xs font-semibold leading-relaxed text-[#151515]/75 max-w-xs">
              Your micro-lot espresso is being ground and tamped. Head to your selected Boston house for collection in <span className="font-bold text-[#D4AF37]">{scheduledTime}</span>.
            </p>

            {membership && (
              <div className="bg-[#151515] text-[#F7F2EA] p-4.5 rounded-xl space-y-1 w-full border border-[#D4AF37]/35 text-left">
                <span className="text-[8px] font-black text-[#D4AF37] uppercase tracking-wider">Society Ledger</span>
                <p className="text-xs font-bold">Ledger points awarded! New balance:</p>
                <p className="font-mono text-sm font-black text-[#D4AF37]">{membership.points} POINTS</p>
              </div>
            )}

            <button
              onClick={() => {
                setCheckoutStep("Cart");
                onClose();
              }}
              className="bg-[#151515] hover:bg-[#D4AF37] text-white hover:text-black w-full py-3.5 text-[10px] tracking-widest font-black uppercase rounded shadow cursor-pointer transition-colors"
            >
              CONTINUE BROWSING
            </button>
          </div>
        ) : (
          // PRIMARY ORDER BAG FLOW
          <>
            {/* Scrollable Items Flow */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {cart.length === 0 && shopCart.length === 0 ? (
                <div className="py-20 text-center space-y-3 font-semibold text-[#151515]/50 uppercase tracking-wider">
                  <p>Your bag is empty.</p>
                  <p className="text-[10px] text-[#D4AF37] font-bold">Select some fresh cups or beans from the menu</p>
                </div>
              ) : (
                <div className="space-y-6 divide-y divide-[#151515]/10">
                  
                  {/* Drinks Items */}
                  {cart.length > 0 && (
                    <div className="space-y-4">
                      <p className="text-[9px] font-extrabold tracking-widest text-[#151515]/40 uppercase">BEVERAGES & FOOD</p>
                      {cart.map((item, index) => {
                        const itemPrice = item.menuItem.price + (item.customization.espressoShots * 0.8);
                        return (
                          <div key={index} className="flex gap-4 pt-4 first:pt-0">
                            <div className="h-16 w-16 rounded-lg overflow-hidden bg-[#151515]/5">
                              <img src={item.menuItem.image} alt={item.menuItem.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            </div>
                            <div className="flex-1 flex flex-col justify-between">
                              <div>
                                <div className="flex justify-between items-baseline">
                                  <h4 className="text-xs font-black text-[#151515]">{item.menuItem.name}</h4>
                                  <span className="text-xs font-extrabold text-[#D4AF37]">${(itemPrice * item.quantity).toFixed(2)}</span>
                                </div>
                                <p className="text-[9px] text-[#151515]/60 mt-1 font-semibold">
                                  {item.customization.milk !== "None" ? `${item.customization.milk} milk` : "No milk"} • {item.customization.sweetness} sweet 
                                  {item.customization.espressoShots > 0 && ` • +${item.customization.espressoShots} Shots`}
                                  {item.customization.notes && ` • "${item.customization.notes}"`}
                                </p>
                              </div>

                              <div className="flex justify-between items-center mt-2">
                                <div className="flex items-center gap-2 border border-[#151515]/15 bg-white rounded px-2 py-0.5">
                                  <button onClick={() => updateCartQty(index, Math.max(1, item.quantity - 1))} className="text-xs hover:text-[#D4AF37] cursor-pointer font-bold">–</button>
                                  <span className="text-[11px] font-bold">{item.quantity}</span>
                                  <button onClick={() => updateCartQty(index, item.quantity + 1)} className="text-xs hover:text-[#D4AF37] cursor-pointer font-bold">+</button>
                                </div>
                                <button onClick={() => removeFromCart(index)} className="text-[#151515]/40 hover:text-red-500 cursor-pointer">
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Retail Store Items */}
                  {shopCart.length > 0 && (
                    <div className="space-y-4 pt-4">
                      <p className="text-[9px] font-extrabold tracking-widest text-[#151515]/40 uppercase">RETAIL PROVISIONS</p>
                      {shopCart.map((item, index) => (
                        <div key={index} className="flex gap-4 pt-4 first:pt-0">
                          <div className="h-16 w-16 rounded-lg overflow-hidden bg-[#151515]/5">
                            <img src={item.storeItem.image} alt={item.storeItem.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          </div>
                          <div className="flex-1 flex flex-col justify-between">
                            <div>
                              <div className="flex justify-between items-baseline">
                                <h4 className="text-xs font-black text-[#151515]">{item.storeItem.name}</h4>
                                <span className="text-xs font-extrabold text-[#D4AF37]">${(item.storeItem.price * item.quantity).toFixed(2)}</span>
                              </div>
                              <p className="text-[9px] text-[#151515]/50 mt-0.5 font-semibold uppercase">{item.storeItem.category}</p>
                            </div>

                            <div className="flex justify-between items-center mt-2">
                              <div className="flex items-center gap-2 border border-[#151515]/15 bg-white rounded px-2 py-0.5">
                                <button onClick={() => updateShopCartQty(index, Math.max(1, item.quantity - 1))} className="text-xs hover:text-[#D4AF37] cursor-pointer font-bold">–</button>
                                <span className="text-[11px] font-bold">{item.quantity}</span>
                                <button onClick={() => updateShopCartQty(index, item.quantity + 1)} className="text-xs hover:text-[#D4AF37] cursor-pointer font-bold">+</button>
                              </div>
                              <button onClick={() => removeFromShopCart(index)} className="text-[#151515]/40 hover:text-red-500 cursor-pointer">
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Calculations & Checkout controls (Only if items exist) */}
            {(cart.length > 0 || shopCart.length > 0) && (
              <div className="p-6 bg-white border-t border-[#151515]/10 space-y-4">
                
                {/* Pickup scheduler */}
                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold tracking-widest uppercase text-[#151515]/60 block">Pickup Calibration</label>
                  <select
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                    className="w-full bg-[#151515]/3 border border-[#151515]/10 rounded px-3 py-2 text-xs font-semibold focus:outline-none focus:border-[#D4AF37]"
                  >
                    <option value="Immediate (10-15 mins)">Immediate (10-15 mins)</option>
                    <option value="In 30 Minutes">In 30 Minutes</option>
                    <option value="In 1 Hour">In 1 Hour</option>
                    <option value="Schedule for Tomorrow morning">Schedule for Tomorrow morning</option>
                  </select>
                </div>

                {/* Pricing sheet */}
                <div className="space-y-2 text-xs font-semibold text-[#151515]/80 border-t border-[#151515]/5 pt-3">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Commonwealth Tax (6.25%)</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Barista Care Fee</span>
                    <span>${fee.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between border-t border-[#151515]/10 pt-2.5 text-[#151515] font-black text-sm">
                    <span>Total sum</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>

                {/* CTA Checkout button */}
                <button
                  onClick={handleCheckout}
                  disabled={checkingOut}
                  className="w-full bg-[#151515] hover:bg-[#D4AF37] text-white hover:text-black py-4 text-[10px] tracking-widest font-black uppercase rounded shadow transition-all duration-300 cursor-pointer flex items-center justify-center gap-2"
                >
                  <Sparkles className="h-4 w-4 text-[#D4AF37] animate-pulse" />
                  <span>{checkingOut ? "ENCRYPTING TELEMETRY..." : "PROCEED TO SECURE CHECKOUT"}</span>
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
