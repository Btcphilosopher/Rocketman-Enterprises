import React, { useState } from "react";
import { AppProvider, useApp } from "./context/AppContext";
import Sidebar from "./components/Sidebar";
import Header from "./components/Header";
import CartDrawer from "./components/CartDrawer";

// Sections
import HomeSection from "./components/HomeSection";
import MenuSection from "./components/MenuSection";
import LocationsSection from "./components/LocationsSection";
import JournalSection from "./components/JournalSection";
import ShopSection from "./components/ShopSection";
import CareersContactSection from "./components/CareersContactSection";
import MembershipSection from "./components/MembershipSection";
import AiSommelierSection from "./components/AiSommelierSection";
import AdminPanel from "./components/AdminPanel";

import { motion, AnimatePresence } from "motion/react";
import { ArrowUp, Instagram, Facebook, Twitter, Shield, Heart } from "lucide-react";

function AppContent() {
  const { currentTab, setCurrentTab } = useApp();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const renderActiveSection = () => {
    switch (currentTab) {
      case "HOME":
        return <HomeSection />;
      case "MENU":
        return <MenuSection />;
      case "LOCATIONS":
        return <LocationsSection />;
      case "OUR_STORY":
        return <JournalSection />;
      case "RETAIL":
        return <ShopSection />;
      case "CAREERS":
        return <CareersContactSection />;
      case "FELLOWSHIP":
        return <MembershipSection />;
      case "AISOMMELIER":
        return <AiSommelierSection />;
      case "ADMIN":
        return <AdminPanel />;
      default:
        return <HomeSection />;
    }
  };

  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-[#F7F2EA] text-[#151515] flex flex-col md:flex-row relative">
      {/* 1. Left Sidebar - Sticky Navigation & Branded Art */}
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />

      {/* 2. Main Scrollable Container */}
      <div className="flex-1 flex flex-col min-w-0 md:pl-0 md:h-screen md:overflow-y-auto">
        {/* Header - Cart, Location picker, and responsive controls */}
        <Header onCartClick={() => setIsCartOpen(true)} />

        {/* 3. Main Dynamic Content with Framer Motion Fade-ins */}
        <main className="flex-1 px-4 md:px-8 py-8 md:py-12 relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentTab}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.35, ease: "easeInOut" }}
              className="h-full"
            >
              {renderActiveSection()}
            </motion.div>
          </AnimatePresence>
        </main>

        {/* 4. Sliding Shopping Bag Drawer */}
        <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />

        {/* 4. Elegant Literary Footer */}
        <footer className="bg-[#151515] text-[#F7F2EA] border-t border-white/5 py-12 px-6 md:px-12 mt-auto font-ui text-left">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-10">
            {/* Column 1: Editorial statement */}
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center gap-2">
                <span className="font-serif-logo text-xl font-bold text-[#D4AF37] tracking-widest leading-none">BC</span>
                <span className="text-[10px] tracking-[0.35em] font-extrabold uppercase text-[#F7F2EA]">
                  BOSTON COFFEE HOUSE
                </span>
              </div>
              <p className="text-[11px] text-[#F7F2EA]/75 leading-relaxed font-semibold max-w-sm">
                A modern New England institution blending historic Harvard craftsmanship, Swiss typographic design principles, and custom thermodynamic roasting technology. Built for early risers, scholars, and architects of the future.
              </p>
            </div>

            {/* Column 2: Quick Links */}
            <div className="md:col-span-3 space-y-4">
              <h5 className="text-[10px] tracking-[0.2em] font-extrabold text-[#D4AF37] uppercase">SOCIETY LINKS</h5>
              <div className="grid grid-cols-2 gap-2 text-[10px] font-bold uppercase text-[#F7F2EA]/80">
                <button onClick={() => setCurrentTab("HOME")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ HOME ]</button>
                <button onClick={() => setCurrentTab("MENU")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ MENU ]</button>
                <button onClick={() => setCurrentTab("LOCATIONS")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ HOUSES ]</button>
                <button onClick={() => setCurrentTab("OUR_STORY")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ GAZETTE ]</button>
                <button onClick={() => setCurrentTab("RETAIL")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ STORE ]</button>
                <button onClick={() => setCurrentTab("FELLOWSHIP")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ SOCIETY ]</button>
                <button onClick={() => setCurrentTab("CAREERS")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ CAREERS ]</button>
                <button onClick={() => setCurrentTab("ADMIN")} className="hover:text-[#D4AF37] transition-colors cursor-pointer text-left">[ COCKPIT ]</button>
              </div>
            </div>

            {/* Column 3: Contact & Legal */}
            <div className="md:col-span-4 space-y-4">
              <h5 className="text-[10px] tracking-[0.2em] font-extrabold text-[#D4AF37] uppercase">CONTACT BUREAU</h5>
              <p className="text-[10px] text-[#F7F2EA]/70 font-semibold leading-relaxed">
                Beacon Hill Coffeehouse: 88 Mt Vernon St, Boston, MA 02108 <br />
                Direct Dispatch: dispatch@bostoncoffeehouse.org <br />
                Telephony: (617) 555-0143
              </p>
              
              <div className="flex gap-4 pt-1">
                <Instagram className="h-4 w-4 text-white/50 hover:text-[#D4AF37] cursor-pointer transition-colors" />
                <Facebook className="h-4 w-4 text-white/50 hover:text-[#D4AF37] cursor-pointer transition-colors" />
                <Twitter className="h-4 w-4 text-white/50 hover:text-[#D4AF37] cursor-pointer transition-colors" />
              </div>
            </div>
          </div>

          <div className="max-w-7xl mx-auto border-t border-white/10 pt-8 mt-10 flex flex-col sm:flex-row justify-between items-center gap-4 text-[9px] font-bold text-[#F7F2EA]/40 uppercase tracking-widest">
            <div className="flex items-center gap-1.5">
              <Shield className="h-3.5 w-3.5 text-[#D4AF37]" />
              <span>© 2026 BOSTON COFFEEHOUSE CORP. ALL RIGHTS DIALED IN.</span>
            </div>
            <div className="flex items-center gap-4">
              <button onClick={handleScrollTop} className="hover:text-[#D4AF37] flex items-center gap-1 cursor-pointer">
                <span>SCROLL TO ZENITH</span>
                <ArrowUp className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
