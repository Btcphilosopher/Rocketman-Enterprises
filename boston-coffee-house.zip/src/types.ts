export interface MenuItem {
  id: string;
  name: string;
  description: string;
  category: "Espresso" | "Pour Over" | "Filter Coffee" | "Cold Brew" | "Tea" | "Breakfast" | "Lunch" | "Seasonal Specials" | "Fresh Bakery" | "Desserts" | "Coffee Cocktails";
  price: number;
  image: string;
  ingredients: string[];
  origin: string;
  roastingProfile: "Light Roast" | "Medium Roast" | "Dark Roast" | "None";
  pairingSuggestions: string[];
  calories: number;
  caffeine: string;
}

export interface CustomizationOptions {
  milk: "Whole" | "Oat" | "Almond" | "Pistachio" | "None";
  sweetness: "Standard" | "Less" | "None";
  espressoShots: number;
  beans: "House Blend (Medium)" | "Harvard Square Single-Origin (Light)" | "Boston Harbor Dark (Dark)";
  notes?: string;
}

export interface OrderItem {
  id: string; // unique for this selection instance
  menuItem: MenuItem;
  quantity: number;
  customization: CustomizationOptions;
}

export interface CafeLocation {
  id: string;
  name: string;
  address: string;
  hours: {
    weekdays: string;
    weekends: string;
  };
  phone: string;
  image: string;
  description: string;
  interiorTour: string[];
  parking: string;
  accessibility: string;
}

export interface Story {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: "Origin" | "Interview" | "Roasting" | "Design" | "Culture";
  author: string;
  date: string;
  image: string;
  readTime: string;
  photoEssay?: string[];
}

export interface StoreItem {
  id: string;
  name: string;
  price: number;
  description: string;
  image: string;
  category: "Beans" | "Equipment" | "Glassware" | "Apparel" | "Books" | "Gift Boxes";
  details: string;
}

export interface SubscriptionConfig {
  roast: "Light" | "Medium" | "Dark" | "Roaster's Choice";
  origin: "Single Origin" | "Signature Blend" | "Decaf Blend";
  frequency: "Weekly" | "Bi-Weekly" | "Monthly";
  quantity: "12oz (1 Bag)" | "24oz (2 Bags)" | "5lb (Bulk)";
  grind: "Whole Bean" | "French Press" | "Drip" | "Espresso";
}

export interface Subscription {
  id: string;
  config: SubscriptionConfig;
  status: "Active" | "Paused" | "Cancelled";
  nextDelivery: string;
  price: number;
}

export interface TableReservation {
  id: string;
  locationId: string;
  locationName: string;
  date: string;
  time: string;
  guests: number;
  specialRequests?: string;
}

export interface MembershipDetails {
  memberId: string;
  name: string;
  email: string;
  tier: "Guild Member" | "Beacon Patron" | "Commonwealth Fellow";
  points: number;
  memberSince: string;
  benefits: string[];
}
