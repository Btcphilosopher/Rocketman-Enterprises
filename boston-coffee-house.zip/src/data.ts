import { MenuItem, CafeLocation, Story, StoreItem } from "./types";

export const MENU_ITEMS: MenuItem[] = [
  {
    id: "m1",
    name: "Commonwealth Espresso",
    description: "Our signature double shot espresso. Bright stone fruit acidity with a rich, velvety dark chocolate finish and thick tiger-striped crema.",
    category: "Espresso",
    price: 4.5,
    image: "https://images.unsplash.com/photo-151097252790b-a4817734857d?q=80&w=1200",
    ingredients: ["Signature House Blend Espresso (2oz)"],
    origin: "50% Colombia Finca El Paraiso, 50% Ethiopia Yirgacheffe",
    roastingProfile: "Medium Roast",
    pairingSuggestions: ["Warm Butter Croissant", "Almond Financier"],
    calories: 5,
    caffeine: "150mg"
  },
  {
    id: "m2",
    name: "Harvard Yard Pour Over",
    description: "Meticulously brewed via V60. Showcases crisp jasmine aromatics, vibrant bergamot notes, and a crystalline, tea-like body.",
    category: "Pour Over",
    price: 6.0,
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?q=80&w=1200",
    ingredients: ["Single Origin Gesha Beans (20g)", "Filtered Spring Water (300ml)"],
    origin: "Panama Esmeralda Estate (Micro-lot)",
    roastingProfile: "Light Roast",
    pairingSuggestions: ["Lemon Tart", "Blueberry Scone"],
    calories: 2,
    caffeine: "120mg"
  },
  {
    id: "m3",
    name: "Beacon Hill Flat White",
    description: "Double shot of espresso combined with perfectly micro-foamed organic whole milk to create a rich, silky texture with intricate latté art.",
    category: "Espresso",
    price: 5.25,
    image: "https://images.unsplash.com/photo-1577968897966-3d4325b36b61?q=80&w=1200",
    ingredients: ["House Espresso (2oz)", "Micro-foamed Organic Whole Milk (5oz)"],
    origin: "Brazil Santa Inês & Sumatra Mandheling",
    roastingProfile: "Medium Roast",
    pairingSuggestions: ["Pain au Chocolat", "Cinnamon Bun"],
    calories: 120,
    caffeine: "150mg"
  },
  {
    id: "m4",
    name: "Atlantic Draft Cold Brew",
    description: "Steeped cold for 18 hours and charged with nitrogen for an ultra-smooth, creamy draft cascade with natural hints of molasses and dark cocoa.",
    category: "Cold Brew",
    price: 5.5,
    image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?q=80&w=1200",
    ingredients: ["Cold Steeped Boston Harbor Blend (12oz)", "Nitrogen Gas Charge"],
    origin: "Guatemala Huehuetenango",
    roastingProfile: "Dark Roast",
    pairingSuggestions: ["Sea Salt Chocolate Cookie", "Cardamom Bun"],
    calories: 3,
    caffeine: "200mg"
  },
  {
    id: "m5",
    name: "Old State House Black Coffee",
    description: "Our daily batch brew, featuring a perfectly balanced, robust profile with tasting notes of toasted hazelnut, red apple, and brown sugar.",
    category: "Filter Coffee",
    price: 3.75,
    image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?q=80&w=1200",
    ingredients: ["Freshly Brewed Drip Coffee (12oz)"],
    origin: "Honduras Marcala Organic",
    roastingProfile: "Medium Roast",
    pairingSuggestions: ["Apple Cider Donut", "Classic Coffee Cake"],
    calories: 2,
    caffeine: "160mg"
  },
  {
    id: "m6",
    name: "Earl Grey Cream Cloud",
    description: "Premium black tea infused with double-distilled Bergamot oil, topped with vanilla bean-infused cold foam and a dusting of cornflower petals.",
    category: "Tea",
    price: 5.0,
    image: "https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=1200",
    ingredients: ["High-Grown Ceylon Black Tea", "Bergamot Essence", "Vanilla Cold Foam (Milk)"],
    origin: "Sri Lanka (Ruhuna District)",
    roastingProfile: "None",
    pairingSuggestions: ["Lemon Poppyseed Muffin", "Scone with Clotted Cream"],
    calories: 90,
    caffeine: "60mg"
  },
  {
    id: "m7",
    name: "Beacon Hill Sourdough Tartine",
    description: "Locally baked, toasted 36-hour wild yeast sourdough, topped with organic heirloom tomatoes, hand-whipped ricotta, lemon zest, and fresh basil oil.",
    category: "Breakfast",
    price: 14.5,
    image: "https://images.unsplash.com/photo-1541532713592-79a0317b6b77?q=80&w=1200",
    ingredients: ["Wild Sourdough", "Whipped Ricotta", "Heirloom Tomatoes", "Lemon Zest", "Basil Infused Olive Oil"],
    origin: "New England Grains",
    roastingProfile: "None",
    pairingSuggestions: ["Commonwealth Espresso", "V60 Panama Gesha"],
    calories: 380,
    caffeine: "0"
  },
  {
    id: "m8",
    name: "The Lobster Roll Brioche",
    description: "Delicate knuckle and claw cold-water lobster meat, tossed in a whisper of house lemon chive aioli, served warm in a toasted brown butter brioche bun.",
    category: "Lunch",
    price: 24.0,
    image: "https://images.unsplash.com/photo-1553618551-fba689030290?q=80&w=1200",
    ingredients: ["Maine Lobster Meat", "Brioche Bun", "Clarified Butter", "Chive Lemon Aioli"],
    origin: "Gulf of Maine Sourced",
    roastingProfile: "None",
    pairingSuggestions: ["Atlantic Draft Cold Brew", "Sparkling Water"],
    calories: 520,
    caffeine: "0"
  },
  {
    id: "m9",
    name: "Cardamom Rose Latte",
    description: "A signature seasonal masterpiece. Ground green cardamom seeds and organic rosewater steamed with house espresso and creamy pistachio milk.",
    category: "Seasonal Specials",
    price: 6.5,
    image: "https://images.unsplash.com/photo-1534778101976-62847782c213?q=80&w=1200",
    ingredients: ["House Espresso (2oz)", "Organic Pistachio Milk", "Crushed Cardamom", "Rosewater Essence", "Dehydrated Rose Petals"],
    origin: "Estate India Cardamom & Colombian Coffee",
    roastingProfile: "Light Roast",
    pairingSuggestions: ["Pistachio Croissant", "Orange Cardamom Cake"],
    calories: 140,
    caffeine: "150mg"
  },
  {
    id: "m10",
    name: "Brown Butter Pecan Tart",
    description: "Flaky, press-in shortbread pastry crust filled with a deeply caramelized brown butter, maple syrup, and New England toasted pecan custard.",
    category: "Desserts",
    price: 8.5,
    image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?q=80&w=1200",
    ingredients: ["Flour", "Brown Butter", "Pecans", "Pure Vermont Maple Syrup", "Vanilla Extract"],
    origin: "Vermont Sourced Maple",
    roastingProfile: "None",
    pairingSuggestions: ["Harvard Yard Pour Over", "Commonwealth Espresso"],
    calories: 420,
    caffeine: "0"
  },
  {
    id: "m11",
    name: "The Anglo-Espresso Martini",
    description: "A refined cocktail. House cold brew concentrate, English grain vodka, craft coffee liqueur, and dark demerara syrup, shaken hard and served with a lemon twist.",
    category: "Coffee Cocktails",
    price: 15.0,
    image: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=1200",
    ingredients: ["Cold Brew Concentrate", "English Grain Vodka", "Demerara Syrup", "Espresso Beans garnish", "Lemon Twist"],
    origin: "Boston Roasted Blend & British Spirits",
    roastingProfile: "Dark Roast",
    pairingSuggestions: ["Warm Brown Butter Tart", "Dark Chocolate Truffles"],
    calories: 190,
    caffeine: "80mg"
  }
];

export const CAFE_LOCATIONS: CafeLocation[] = [
  {
    id: "loc1",
    name: "Beacon Hill",
    address: "82 Mt. Vernon St, Boston, MA 02108",
    hours: {
      weekdays: "6:30 AM – 7:00 PM",
      weekends: "7:00 AM – 8:00 PM"
    },
    phone: "(617) 555-0143",
    image: "https://images.unsplash.com/photo-1549488344-1f9b8d2bd1f3?q=80&w=1200",
    description: "Nestled among historic gas lanterns and cobblestones, our flagship Beacon Hill house features a mahogany-clad reading room, vintage Chesterfield seating, and a grand brass fireplace.",
    interiorTour: [
      "https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=1200",
      "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1200"
    ],
    parking: "Street Metered Parking (Highly Limited)",
    accessibility: "ADA Compliant ramp access, spacious main floor."
  },
  {
    id: "loc2",
    name: "Harvard Square",
    address: "14 Holyoke St, Cambridge, MA 02138",
    hours: {
      weekdays: "7:00 AM – 9:00 PM",
      weekends: "7:30 AM – 10:00 PM"
    },
    phone: "(617) 555-0188",
    image: "https://images.unsplash.com/photo-1559925393-8be0ec4767c8?q=80&w=1200",
    description: "Steps from Harvard Yard, this location features double-height library bookshelves, custom Herman Miller Eames chairs, and a silent reading mezzanine perfect for scholars and philosophers.",
    interiorTour: [
      "https://images.unsplash.com/photo-1445116572660-236099ec97a0?q=80&w=1200"
    ],
    parking: "Holyoke St Garage & Harvard Square Public Parking",
    accessibility: "Full ramp access and elevator service to study mezzanine."
  },
  {
    id: "loc3",
    name: "Boston Seaport",
    address: "250 Northern Ave, Boston, MA 02210",
    hours: {
      weekdays: "6:00 AM – 8:00 PM",
      weekends: "7:00 AM – 8:00 PM"
    },
    phone: "(617) 555-0199",
    image: "https://images.unsplash.com/photo-1521017432531-fbd92d768814?q=80&w=1200",
    description: "Our Anglo-Futurist hub. Designed with sleek polished concrete, brushed brass accents, marine-grade steel cables, and large architectural glass overlooking the historical Boston harbor docks.",
    interiorTour: [
      "https://images.unsplash.com/photo-1498804103079-a6351b050096?q=80&w=1200"
    ],
    parking: "Validated Garage Parking at Seaport Boulevard structure",
    accessibility: "All ground level, fully accessible entryways."
  },
  {
    id: "loc4",
    name: "South End",
    address: "540 Tremont St, Boston, MA 02116",
    hours: {
      weekdays: "7:00 AM – 6:00 PM",
      weekends: "7:30 AM – 7:00 PM"
    },
    phone: "(617) 555-0211",
    image: "https://images.unsplash.com/photo-1511920170033-f8396924c348?q=80&w=1200",
    description: "Framed by iconic brownstones, this location boasts high ceilings, exposed brick, live Ficus trees, and vintage French industrial lighting. A sanctuary of New England hospitality.",
    interiorTour: [
      "https://images.unsplash.com/photo-1453614512568-c4024d13c247?q=80&w=1200"
    ],
    parking: "Tremont St residential/visitor designated spaces",
    accessibility: "Flat street-level layout, broad aisles."
  }
];

export const STORIES: Story[] = [
  {
    id: "s1",
    title: "The Architecture of Coffee: Designing the Future Beacon Hill",
    excerpt: "How we blended a 19th-century Boston historic brownstone with Swiss minimalism and British engineering to create our flagship space.",
    category: "Design",
    author: "Claire Abernathy",
    date: "July 12, 2026",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?q=80&w=1200",
    readTime: "6 min read",
    content: "When we acquired 82 Mt. Vernon St., we knew we were custodying a piece of Beacon Hill history. The brickwork was laid in 1842; the window frames had watched over the generation of Emerson and Alcott. Our design goal was singular: respect the history while looking 50 years into the future. We stripped back decades of gypsum to reveal structural brick and New England heart pine. For furniture, we collaborated with British cabinetmakers to draft solid white-oak tables. Brass hardware was left unlacquered, ensuring it will oxidize naturally alongside the historic city. The result is a coffee house that breathes the intellectual, quiet confidence of Boston."
  },
  {
    id: "s2",
    title: "High-Altitude Integrity: A Journey to Panama's Volcano Valley",
    excerpt: "We visit the Esmeralda Estate to document the cultivation of the micro-lot Gesha beans behind our Harvard Yard Pour Over.",
    category: "Origin",
    author: "Richard Alpert",
    date: "June 28, 2026",
    image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?q=80&w=1200",
    readTime: "9 min read",
    content: "Sourcing premium coffee requires climbing. At 1,750 meters above sea level, nestled in the rich, volcanic soil surrounding Mount Baru, sits the Esmeralda Estate. It is here that Geisha (or Gesha) variety coffee trees find their optimal biosphere. We spent a week working alongside senior growers, observing the strict selective-harvesting practices where only cherries of a precise crimson shade are picked. This commitment to detail yields a coffee containing notes of jasmine, peach, and bergamot—a flavor complexity resembling fine wine. Our direct-trade model ensures growers are paid 140% above fair-trade standards, sustaining craftsmanship for decades to come."
  },
  {
    id: "s3",
    title: "The Alchemy of Steam: The Science of Modern Roasting",
    excerpt: "An inside look into the thermodynamics and chemical reactions during our micro-batch roasting process in East Boston.",
    category: "Roasting",
    author: "Dr. Marcus Vance",
    date: "May 15, 2026",
    image: "https://images.unsplash.com/photo-1511537190424-bbbab87ac5eb?q=80&w=1200",
    readTime: "5 min read",
    content: "Coffee roasting is often called an art, but its foundation is strict chemistry. When a green bean enters our custom British-made Loring roaster, it undergoes rapid physical and chemical shifts. At 160°C, the Maillard reaction begins, binding amino acids and reducing sugars to create deep caramelization and nutty flavor notes. At 196°C, the 'first crack' occurs, as pressurized moisture escapes the expanding cell walls. Our master roasters monitor the roast curve on high-precision digital monitors, tracking the rate of rise (RoR) within fractions of a degree. This guarantees that our signature Commonwealth Blend tastes uniform and exquisite, batch after batch."
  }
];

export const STORE_ITEMS: StoreItem[] = [
  {
    id: "p1",
    name: "Commonwealth Signature Espresso Blend (12oz)",
    price: 18.0,
    description: "Our signature house blend, featuring rich chocolate, molasses, and candied stone fruit tasting notes. Exceptional with milk or as a standalone double shot.",
    image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?q=80&w=1200",
    category: "Beans",
    details: "Origin: 50% Colombia, 50% Ethiopia. Process: Washed and Natural. Roast Level: Medium. Notes: Dark Chocolate, Plum, Caramel, Toasted Hazelnut."
  },
  {
    id: "p2",
    name: "Harvard Yard Geisha Micro-Lot Beans (8.8oz)",
    price: 45.0,
    description: "Our ultra-premium Panama Geisha. Highly prized for its intricate, floral aroma, crisp white peach flavor, and a long, silky lemon-tea finish.",
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?q=80&w=1200",
    category: "Beans",
    details: "Origin: Esmeralda Estate, Panama. Process: Wet-process / Washed. Roast Level: Light. Notes: Jasmine, Bergamot, Honeysuckle, White Peach."
  },
  {
    id: "p3",
    name: "Brushed Brass Coffee Kettle",
    price: 125.0,
    description: "Designed for precise pour-over flows. Custom engineered gooseneck spout, balanced counter-weighted oak handle, and a built-in analogue thermometer.",
    image: "https://images.unsplash.com/photo-1513530176992-0cf39c4cdb4a?q=80&w=1200",
    category: "Equipment",
    details: "Material: Solid Stainless Steel core with Burnished Brass plating and American White Oak accents. Capacity: 900ml. Compatibility: Induction, Electric, Gas."
  },
  {
    id: "p4",
    name: "Boston Coffee House Double-Walled Glasses (Set of 2)",
    price: 36.0,
    description: "Hand-blown borosilicate glassware with clean minimalist curves and our elegant BC gold monogram. Insulates temperature while staying cool to touch.",
    image: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=1200",
    category: "Glassware",
    details: "Material: Premium Borosilicate Glass. Capacity: 8oz (Ideal for flat whites and cortados). Safe for dishwasher and microwave."
  },
  {
    id: "p5",
    name: "The Boston Coffee Society Heavyweight Hoodie",
    price: 85.0,
    description: "Sleek, heavy 450GSM organic loopback cotton fleece. Featuring our embroidered crest on the chest and an understated custom label on the hem.",
    image: "https://images.unsplash.com/photo-1556911220-e15b29be8c8f?q=80&w=1200",
    category: "Apparel",
    details: "Material: 100% Organic Cotton. Color: Deep Espresso Black. Fit: Relaxed boxy silhouette. Pre-washed for zero shrinkage."
  }
];
