import React, { createContext, useContext, useState, useEffect } from "react";
import { MenuItem, OrderItem, CafeLocation, Subscription, MembershipDetails, StoreItem } from "../types";

interface AppContextType {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  selectedLocation: string;
  setSelectedLocation: (loc: string) => void;
  cart: OrderItem[];
  addToCart: (item: MenuItem, quantity: number, customization: any) => void;
  removeFromCart: (orderItemId: string) => void;
  clearCart: () => void;
  shopCart: { item: StoreItem; quantity: number }[];
  addToShopCart: (item: StoreItem, quantity: number) => void;
  removeFromShopCart: (itemId: string) => void;
  clearShopCart: () => void;
  membership: MembershipDetails | null;
  setMembership: (member: MembershipDetails | null) => void;
  orders: any[];
  fetchOrders: () => void;
  placeOrder: (customerDetails: { name: string; email: string; type: "collection" | "delivery"; time: string; address?: string; notes?: string }) => Promise<any>;
  subscriptions: Subscription[];
  createSubscription: (config: any) => Promise<any>;
  toggleSubscriptionStatus: (id: string, newStatus: string) => Promise<any>;
  fetchSubscriptions: () => void;
  isAdmin: boolean;
  setIsAdmin: (admin: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentTab, setCurrentTab] = useState<string>("HOME");
  const [selectedLocation, setSelectedLocation] = useState<string>("Beacon Hill");
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [shopCart, setShopCart] = useState<{ item: StoreItem; quantity: number }[]>([]);
  const [membership, setMembership] = useState<MembershipDetails | null>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  // Fetch initial membership status
  useEffect(() => {
    fetch("/api/membership")
      .then((res) => {
        if (res.ok) return res.json();
        return null;
      })
      .then((data) => {
        if (data && data.memberId) {
          setMembership(data);
        }
      })
      .catch((err) => console.log("No active membership found", err));

    fetchOrders();
    fetchSubscriptions();
  }, []);

  const fetchOrders = () => {
    fetch("/api/orders")
      .then((res) => res.json())
      .then((data) => setOrders(data))
      .catch((err) => console.log("Failed to fetch orders", err));
  };

  const fetchSubscriptions = () => {
    fetch("/api/subscriptions")
      .then((res) => res.json())
      .then((data) => setSubscriptions(data))
      .catch((err) => console.log("Failed to fetch subscriptions", err));
  };

  const addToCart = (menuItem: MenuItem, quantity: number, customization: any) => {
    const orderItemId = `cart_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`;
    const newCartItem: OrderItem = {
      id: orderItemId,
      menuItem,
      quantity,
      customization
    };
    setCart((prev) => [...prev, newCartItem]);
  };

  const removeFromCart = (orderItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== orderItemId));
  };

  const clearCart = () => setCart([]);

  const addToShopCart = (storeItem: StoreItem, quantity: number) => {
    setShopCart((prev) => {
      const existingIndex = prev.findIndex((i) => i.item.id === storeItem.id);
      if (existingIndex !== -1) {
        const updated = [...prev];
        updated[existingIndex].quantity += quantity;
        return updated;
      }
      return [...prev, { item: storeItem, quantity }];
    });
  };

  const removeFromShopCart = (itemId: string) => {
    setShopCart((prev) => prev.filter((i) => i.item.id !== itemId));
  };

  const clearShopCart = () => setShopCart([]);

  const placeOrder = async (customerDetails: { name: string; email: string; type: "collection" | "delivery"; time: string; address?: string; notes?: string }) => {
    // We combine beverage/food cart and shop retail cart for checkout
    const mergedItems = [
      ...cart,
      ...shopCart.map((sc) => ({
        id: `shop_${sc.item.id}`,
        menuItem: {
          id: sc.item.id,
          name: sc.item.name,
          description: sc.item.description,
          category: "Fresh Bakery" as any, // fallback
          price: sc.item.price,
          image: sc.item.image,
          ingredients: [],
          origin: "Store Retail",
          roastingProfile: "None" as any,
          pairingSuggestions: [],
          calories: 0,
          caffeine: "0"
        },
        quantity: sc.quantity,
        customization: {
          milk: "None" as any,
          sweetness: "None" as any,
          espressoShots: 0,
          beans: "House Blend (Medium)" as any
        }
      }))
    ];

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          items: mergedItems,
          ...customerDetails
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || "Order placement failed");
      }

      const result = await response.json();
      clearCart();
      clearShopCart();
      fetchOrders();
      
      // Update local membership points if email matches
      if (membership && membership.email === customerDetails.email) {
        setMembership(prev => {
          if (!prev) return null;
          let spent = 0;
          mergedItems.forEach(i => spent += i.menuItem.price * i.quantity);
          return {
            ...prev,
            points: prev.points + Math.floor(spent * 10)
          };
        });
      }

      return result;
    } catch (err: any) {
      console.error(err);
      throw err;
    }
  };

  const createSubscription = async (config: any) => {
    try {
      const response = await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ config })
      });
      if (!response.ok) throw new Error("Failed to create subscription");
      const result = await response.json();
      fetchSubscriptions();
      return result;
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  const toggleSubscriptionStatus = async (id: string, newStatus: string) => {
    try {
      const response = await fetch(`/api/subscriptions/${id}/status`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus })
      });
      if (!response.ok) throw new Error("Failed to update status");
      const result = await response.json();
      fetchSubscriptions();
      return result;
    } catch (err) {
      console.error(err);
      throw err;
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        selectedLocation,
        setSelectedLocation,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        shopCart,
        addToShopCart,
        removeFromShopCart,
        clearShopCart,
        membership,
        setMembership,
        orders,
        fetchOrders,
        placeOrder,
        subscriptions,
        createSubscription,
        toggleSubscriptionStatus,
        fetchSubscriptions,
        isAdmin,
        setIsAdmin
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
