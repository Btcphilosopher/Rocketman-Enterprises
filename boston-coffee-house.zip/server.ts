import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

// Default data (in-memory database mimicking a persistent store)
import { MENU_ITEMS, CAFE_LOCATIONS, STORIES, STORE_ITEMS } from "./src/data.js";
import { MenuItem, CafeLocation, Story, StoreItem, OrderItem, TableReservation, Subscription, MembershipDetails } from "./src/types.js";

const app = express();
const PORT = 3000;

app.use(express.json());

// In-Memory Database State
let menuDatabase: MenuItem[] = [...MENU_ITEMS];
let locationsDatabase: CafeLocation[] = [...CAFE_LOCATIONS];
let storiesDatabase: Story[] = [...STORIES];
let storeDatabase: StoreItem[] = [...STORE_ITEMS];

let activeOrders: any[] = [];
let tableReservations: TableReservation[] = [];
let activeSubscriptions: Subscription[] = [];
let activeMembership: MembershipDetails | null = null;

// Helper: Lazy initialization of GoogleGenAI
let geminiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    return null;
  }
  if (!geminiClient) {
    geminiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return geminiClient;
}

// ==========================================
// API ROUTES
// ==========================================

// 1. Menu Management
app.get("/api/menu", (req, res) => {
  res.json(menuDatabase);
});

app.post("/api/menu", (req, res) => {
  const newItem: MenuItem = {
    id: `m_${Date.now()}`,
    ...req.body
  };
  menuDatabase.push(newItem);
  res.status(201).json(newItem);
});

app.put("/api/menu/:id", (req, res) => {
  const { id } = req.params;
  const index = menuDatabase.findIndex(item => item.id === id);
  if (index !== -1) {
    menuDatabase[index] = { ...menuDatabase[index], ...req.body };
    res.json(menuDatabase[index]);
  } else {
    res.status(404).json({ error: "Menu item not found" });
  }
});

app.delete("/api/menu/:id", (req, res) => {
  const { id } = req.params;
  const index = menuDatabase.findIndex(item => item.id === id);
  if (index !== -1) {
    const deleted = menuDatabase.splice(index, 1);
    res.json(deleted[0]);
  } else {
    res.status(404).json({ error: "Menu item not found" });
  }
});

// 2. Locations Management
app.get("/api/locations", (req, res) => {
  res.json(locationsDatabase);
});

app.post("/api/locations", (req, res) => {
  const newLocation: CafeLocation = {
    id: `loc_${Date.now()}`,
    ...req.body
  };
  locationsDatabase.push(newLocation);
  res.status(201).json(newLocation);
});

app.post("/api/locations/reserve", (req, res) => {
  const reservation: TableReservation = {
    id: `res_${Date.now()}`,
    ...req.body
  };
  tableReservations.push(reservation);
  res.status(201).json({ message: "Reservation confirmed successfully", reservation });
});

app.get("/api/locations/reservations", (req, res) => {
  res.json(tableReservations);
});

// 3. Stories Management (CMS)
app.get("/api/stories", (req, res) => {
  res.json(storiesDatabase);
});

app.post("/api/stories", (req, res) => {
  const newStory: Story = {
    id: `s_${Date.now()}`,
    date: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
    ...req.body
  };
  storiesDatabase.push(newStory);
  res.status(201).json(newStory);
});

// 4. Store (E-Commerce)
app.get("/api/store", (req, res) => {
  res.json(storeDatabase);
});

app.post("/api/store", (req, res) => {
  const newStoreItem: StoreItem = {
    id: `p_${Date.now()}`,
    ...req.body
  };
  storeDatabase.push(newStoreItem);
  res.status(201).json(newStoreItem);
});

// 5. Orders Engine (Online Ordering)
app.post("/api/orders", (req, res) => {
  const { items, customerName, email, type, time, address, giftCard, notes } = req.body;
  
  if (!items || items.length === 0) {
    return res.status(400).json({ error: "Cart is empty" });
  }

  let total = 0;
  items.forEach((item: any) => {
    total += item.menuItem.price * item.quantity;
  });

  // Calculate taxes and service
  const tax = total * 0.07; // Boston / MA meals tax is 7%
  const grandTotal = total + tax;

  const order = {
    id: `order_${Date.now()}`,
    items,
    customerName,
    email,
    type,
    time,
    address,
    giftCard,
    notes,
    total: parseFloat(total.toFixed(2)),
    tax: parseFloat(tax.toFixed(2)),
    grandTotal: parseFloat(grandTotal.toFixed(2)),
    status: "Received",
    timestamp: new Date().toISOString()
  };

  activeOrders.push(order);

  // If user is logged in as a member, award points
  if (activeMembership && activeMembership.email === email) {
    // Award 10 points per dollar spent
    activeMembership.points += Math.floor(total * 10);
  }

  res.status(201).json({
    message: "Your coffeehouse order has been received. Our baristas are preparing it.",
    order
  });
});

app.get("/api/orders", (req, res) => {
  res.json(activeOrders);
});

// 6. Subscriptions Management
app.post("/api/subscriptions", (req, res) => {
  const { config } = req.body;
  
  let price = 18.0; // standard bag
  if (config.quantity === "24oz (2 Bags)") price = 34.0;
  if (config.quantity === "5lb (Bulk)") price = 95.0;

  const subscription: Subscription = {
    id: `sub_${Date.now()}`,
    config,
    status: "Active",
    nextDelivery: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toLocaleDateString(),
    price
  };

  activeSubscriptions.push(subscription);
  res.status(201).json(subscription);
});

app.get("/api/subscriptions", (req, res) => {
  res.json(activeSubscriptions);
});

app.post("/api/subscriptions/:id/status", (req, res) => {
  const { id } = req.params;
  const { status } = req.body; // "Active", "Paused", "Cancelled"
  
  const index = activeSubscriptions.findIndex(sub => sub.id === id);
  if (index !== -1) {
    activeSubscriptions[index].status = status;
    res.json(activeSubscriptions[index]);
  } else {
    res.status(404).json({ error: "Subscription not found" });
  }
});

// 7. Membership Portal
app.get("/api/membership", (req, res) => {
  res.json(activeMembership);
});

app.post("/api/membership", (req, res) => {
  const { name, email, tier } = req.body;
  
  const benefits = [
    "Priority mobile ordering with zero pickup queue",
    "10% off all retail coffee bags and brewing hardware",
    "Invitations to our monthly private roasting evenings in East Boston",
    "Access to the Boston Coffee Society digital library and coffee journals",
    "Early access to seasonal pastries and limited micro-lot single origins"
  ];

  if (tier === "Beacon Patron") {
    benefits.push("A complimentary 12oz signature blend bag every month");
    benefits.push("Complimentary table reservations at any of our houses");
  } else if (tier === "Commonwealth Fellow") {
    benefits.push("A complimentary 12oz signature blend bag every month");
    benefits.push("Complimentary table reservations at any of our houses");
    benefits.push("Unlimited V60 single-origin pours on Tuesday mornings");
    benefits.push("An annual private 1-on-1 tasting seminar with our Roaster Director");
  }

  activeMembership = {
    memberId: `BCS-${Math.floor(100000 + Math.random() * 900000)}`,
    name,
    email,
    tier: tier || "Guild Member",
    points: 100, // welcome bonus points
    memberSince: new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }),
    benefits
  };

  res.status(201).json(activeMembership);
});

app.post("/api/membership/signout", (req, res) => {
  activeMembership = null;
  res.json({ message: "Signed out successfully" });
});

// 8. Gemini Coffee Sommelier Integration
app.post("/api/gemini/sommelier", async (req, res) => {
  const { prompt, currentCart, userPreferences } = req.body;

  if (!prompt) {
    return res.status(400).json({ error: "Prompt is required" });
  }

  const client = getGeminiClient();

  if (!client) {
    // Elegant fallback rules engine if GEMINI_API_KEY is not configured or in sandboxed setup
    // This behaves beautifully and provides helpful, expert-level Boston coffee suggestions.
    console.log("Gemini API key is not configured. Invoking fallback Boston Coffeehouse Sommelier rules engine.");
    
    const lowerPrompt = prompt.toLowerCase();
    let responseText = `*An elegant note from Claire, Director of Craftsmanship at Boston Coffee House:*

"Welcome to the Boston Coffee Society. I've analyzed your preference, and while my advanced digital systems are warming up (Settings > Secrets), I am delighted to suggest an expert recommendation tailored to your palate."

`;

    if (lowerPrompt.includes("sweet") || lowerPrompt.includes("chocolate") || lowerPrompt.includes("sugar")) {
      responseText += `### The Recommendation: **Beacon Hill Flat White** or **Beacon Hill Sourdough Tartine**
- **The Roast**: Medium-Dark
- **Why**: Our Beacon Hill Flat White features our signature Brazil and Sumatra blend, which yields natural notes of toasted hazelnut and raw molasses. Steaming organic whole milk caramelizes lactose sugars to create a smooth, velvety sweetness with no added syrup required.
- **Ideal Pastry Pairing**: Pair with our freshly baked *Pain au Chocolat* or *Brown Butter Pecan Tart*. The flaky butter layers beautifully cut through the rich espresso cream.`;
    } else if (lowerPrompt.includes("caffeine") || lowerPrompt.includes("strong") || lowerPrompt.includes("energy") || lowerPrompt.includes("wake")) {
      responseText += `### The Recommendation: **Atlantic Draft Cold Brew**
- **The Roast**: Dark Roast (Guatemala Huehuetenango)
- **Why**: Our Atlantic Draft is cold-steeped for 18 hours, extracting high caffeine volumes while minimizing acidic compounds. Nitrogen charge produces a thick, cascading Guinness-like body.
- **Caffeine content**: ~200mg (high strength)
- **Ideal Pastry Pairing**: Pair with our *Sea Salt Chocolate Cookie* or our toasted *Lobster Roll Brioche* for a truly rich, satisfying Boston morning.`;
    } else if (lowerPrompt.includes("fruity") || lowerPrompt.includes("tea") || lowerPrompt.includes("light") || lowerPrompt.includes("floral")) {
      responseText += `### The Recommendation: **Harvard Yard Pour Over (V60 Panama Gesha)**
- **The Roast**: Light Roast (Panama Esmeralda Estate)
- **Why**: Brewed at exactly 93.5°C, this micro-lot pour-over releases crystalline jasmine aromatics, lemon bergamot acidity, and a light honeyed finish. It tastes more like a rare tea than traditional coffee.
- **Ideal Pastry Pairing**: Pair with a delicate *Lemon Tart* or a *Blueberry Scone* to elevate the citrus acidity of the Panama Geisha.`;
    } else if (lowerPrompt.includes("decaf")) {
      responseText += `### The Recommendation: **Earl Grey Cream Cloud**
- **Why**: If you are looking to avoid caffeine but still desire a luxurious experience, our High-Grown Ceylon Earl Grey with vanilla bean cold foam provides a comforting, creamy, and aromatic escape.
- **Alternative**: We can brew any of our Espresso drinks with our Swiss Water Decaf Colombian single-origin.`;
    } else {
      responseText += `### The Recommendation: **Commonwealth Espresso**
- **The Roast**: Medium Roast
- **Why**: It is the purest distillation of Boston Coffee House. A double shot featuring balanced stone fruit acidity and a dark chocolate finish. It is the coffee that fueled the minds of Boston’s finest thinkers.
- **Ideal Pastry Pairing**: Enjoy alongside a warm *Butter Croissant* to savor the pure, uninterrupted flavor profiles of Colombia and Ethiopia.`;
    }

    return res.json({ text: responseText });
  }

  try {
    const systemInstruction = `You are Claire, the Award-Winning Director of Coffee Craftsmanship and AI Barista Sommelier at Boston Coffee House.
You speak with quiet confidence, intellectual New England hospitality, and Swiss editorial clarity. You are passionate about coffee origins, roasting science, and pairing.

Here is the current menu available at our house:
${menuDatabase.map(item => `- ${item.name} (${item.category}): ${item.description}. Price: $${item.price}. Origin: ${item.origin}. Roast: ${item.roastingProfile}. Pairings: ${item.pairingSuggestions.join(", ")}`).join("\n")}

Respond to the customer's request by analyzing their preference and providing:
1. An expert coffee or food recommendation from our menu.
2. The science behind the roast and brewing method.
3. A perfect pastry/food pairing suggestion.
4. Keep the tone warm, highly professional, refined, and distinctly Bostonian (mentioning elements like Beacon Hill, Harvard, or New England heritage where appropriate).
Use elegant Markdown formatting. Avoid promotional hype or generic phrases. Always stay in character as Claire.`;

    const chatSession = client.chats.create({
      model: "gemini-3.6-flash",
      config: {
        systemInstruction,
        temperature: 0.75,
      }
    });

    const response = await chatSession.sendMessage({ message: prompt });
    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error in sommelier route:", error);
    res.status(500).json({ error: "Failed to communicate with Coffee Sommelier", details: error.message });
  }
});

// ==========================================
// VITE OR STATIC SERVING MIDDLEWARE
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Boston Coffee House Full-Stack Server running on http://localhost:${PORT}`);
  });
}

startServer();
