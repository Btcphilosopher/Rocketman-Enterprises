'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { ProductCard } from '@/components/ProductCard';
import { CLITerminal } from '@/components/CLITerminal';
import { CopilotDrawer } from '@/components/CopilotDrawer';
import { DigitalProduct } from '@/lib/types';
import { SlidersHorizontal, Search, Filter, RefreshCw, X } from 'lucide-react';

export default function CatalogPage() {
  const [products, setProducts] = useState<DigitalProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [cartCount, setCartCount] = useState(0);
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [userRole, setUserRole] = useState('PROCUREMENT');

  // Filters
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [productType, setProductType] = useState('');
  const [language, setLanguage] = useState('');
  const [verifiedOnly, setVerifiedOnly] = useState(false);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams();
      if (search) queryParams.set('q', search);
      if (category) queryParams.set('category', category);
      if (productType) queryParams.set('type', productType);
      if (language) queryParams.set('language', language);
      if (verifiedOnly) queryParams.set('verified', 'true');

      const res = await fetch(`/api/v1/products?${queryParams.toString()}`);
      const data = await res.json();
      if (data.products) setProducts(data.products);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [search, category, productType, language, verifiedOnly]);

  const clearFilters = () => {
    setSearch('');
    setCategory('');
    setProductType('');
    setLanguage('');
    setVerifiedOnly(false);
  };

  return (
    <div className="min-h-screen bg-[#0a0c10] text-slate-100 font-sans flex flex-col font-mono text-xs">
      <Header
        cartCount={cartCount}
        onOpenCart={() => (window.location.href = '/cart')}
        onOpenTerminal={() => setTerminalOpen(true)}
        onOpenCopilot={() => setCopilotOpen(true)}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full">
        {/* Page Title */}
        <div className="mb-6 pb-3 border-b border-[#2D2D30] flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-[#00FF80]" />
              SOFTWARE CATALOGUE & CODEBASE REPOSITORY
            </h1>
            <p className="text-[#6B7280] mt-0.5 text-[11px]">
              Filter by language, category, license model, runtime requirements, and security verification.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={clearFilters}
              className="px-3 py-1 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-[#94A3B8] hover:text-white transition flex items-center space-x-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset Filters</span>
            </button>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="bg-[#121214] border border-[#2D2D30] rounded p-3 mb-6 grid grid-cols-1 md:grid-cols-5 gap-3">
          {/* Search Box */}
          <div className="relative md:col-span-2">
            <Search className="w-3.5 h-3.5 absolute left-3 top-2.5 text-[#4B5563]" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by keyword, package, tag..."
              className="w-full bg-[#0A0A0B] border border-[#2D2D30] rounded pl-8 pr-3 py-1.5 text-[#D1D5DB] placeholder-[#6B7280] focus:outline-none focus:border-[#00FF80]"
            />
          </div>

          {/* Product Type Select */}
          <select
            value={productType}
            onChange={e => setProductType(e.target.value)}
            className="bg-[#0A0A0B] border border-[#2D2D30] rounded px-3 py-1.5 text-[#D1D5DB] focus:outline-none focus:border-[#00FF80]"
          >
            <option value="">All Product Types</option>
            <option value="CODEBASE">Codebase</option>
            <option value="LIBRARY">Library / SDK</option>
            <option value="COMPONENT_LIBRARY">Component Library / UI</option>
            <option value="DATABASE">Database / Engine</option>
            <option value="ENGINEERING_TOOL">Engineering / Simulation</option>
            <option value="INFRASTRUCTURE">Infrastructure / IaC</option>
          </select>

          {/* Language Select */}
          <select
            value={language}
            onChange={e => setLanguage(e.target.value)}
            className="bg-[#0A0A0B] border border-[#2D2D30] rounded px-3 py-1.5 text-[#D1D5DB] focus:outline-none focus:border-[#00FF80]"
          >
            <option value="">All Languages</option>
            <option value="Rust">Rust</option>
            <option value="Python">Python</option>
            <option value="TypeScript">TypeScript</option>
            <option value="C++">C++</option>
            <option value="Go">Go</option>
            <option value="C">C</option>
          </select>

          {/* Verified Toggle */}
          <label className="flex items-center space-x-2 bg-[#0A0A0B] border border-[#2D2D30] rounded px-3 py-1.5 cursor-pointer hover:bg-[#1A1A1C] transition select-none">
            <input
              type="checkbox"
              checked={verifiedOnly}
              onChange={e => setVerifiedOnly(e.target.checked)}
              className="rounded border-[#2D2D30] text-[#00FF80] focus:ring-0 accent-[#00FF80]"
            />
            <span className="text-white font-semibold">Verified Vendors</span>
          </label>
        </div>

        {/* Results Info */}
        <div className="mb-4 text-[#6B7280] flex items-center justify-between">
          <span>Showing <strong className="text-white">{products.length}</strong> verified software asset(s)</span>
          {verifiedOnly && (
            <span className="text-[#00FF80] bg-[#00FF80]/10 px-2 py-0.5 rounded border border-[#00FF80]/20 font-bold">
              ✓ Verified Vendors Only
            </span>
          )}
        </div>

        {/* Product Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-8">
            {[1, 2, 3].map(i => (
              <div
                key={i}
                className="h-64 bg-[#121214] border border-[#2D2D30] rounded animate-pulse"
              />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="p-10 text-center bg-[#121214] border border-[#2D2D30] rounded space-y-3">
            <p className="text-[#94A3B8] font-bold text-sm">No software assets match your search filters.</p>
            <button
              onClick={clearFilters}
              className="px-4 py-1.5 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition"
            >
              Clear Search Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {products.map(p => (
              <ProductCard
                key={p.id}
                product={p}
                onAddToCart={p => {
                  alert(`Added ${p.name} to cart.`);
                  setCartCount(prev => prev + 1);
                }}
              />
            ))}
          </div>
        )}
      </main>

      <Footer />
      <CLITerminal isOpen={terminalOpen} onClose={() => setTerminalOpen(false)} />
      <CopilotDrawer isOpen={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}
