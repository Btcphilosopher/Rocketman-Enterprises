'use client';

import React, { useState, useEffect, use } from 'react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { CodePreview } from '@/components/CodePreview';
import { DependencyGraph } from '@/components/DependencyGraph';
import { CompatibilityMatrix } from '@/components/CompatibilityMatrix';
import { CLITerminal } from '@/components/CLITerminal';
import { CopilotDrawer } from '@/components/CopilotDrawer';
import { DigitalProduct, Review } from '@/lib/types';
import { formatPrice, getSecurityBadgeColor } from '@/lib/utils';
import {
  ShieldCheck,
  Star,
  Download,
  Code2,
  Terminal,
  Cpu,
  GitFork,
  FileText,
  ShoppingBag,
  Building2,
  CheckCircle2,
  Lock,
  ExternalLink,
  ChevronRight,
  ArrowLeft,
  BookOpen
} from 'lucide-react';

export default function ProductDetailPage({
  params
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = use(params);
  const [product, setProduct] = useState<DigitalProduct | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'code' | 'compatibility' | 'dependencies' | 'releases' | 'docs'>('overview');
  const [seats, setSeats] = useState(1);
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [userRole, setUserRole] = useState('PROCUREMENT');

  // Procurement modal state
  const [procureReason, setProcureReason] = useState('');
  const [procureOpen, setProcureOpen] = useState(false);
  const [procureSubmitted, setProcureSubmitted] = useState(false);

  const fetchProduct = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/v1/products/${slug}`);
      const data = await res.json();
      if (data.product) {
        setProduct(data.product);
        if (data.reviews) setReviews(data.reviews);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProduct();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0c10] text-slate-100 font-mono flex items-center justify-center p-8">
        <div className="text-center space-y-3">
          <Code2 className="w-8 h-8 text-sky-400 animate-spin mx-auto" />
          <p className="text-xs text-slate-400">Loading Software Specification & Source Tree...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-[#0a0c10] text-slate-100 font-mono flex items-center justify-center p-8">
        <div className="text-center space-y-4 max-w-md">
          <p className="text-base text-red-400 font-bold">Software asset not found.</p>
          <Link
            href="/products"
            className="px-4 py-2 rounded bg-sky-500/10 text-sky-400 border border-sky-500/30 text-xs font-bold inline-block"
          >
            Back to Catalog
          </Link>
        </div>
      </div>
    );
  }

  const totalPrice = product.price * seats;

  const handleAddToCart = () => {
    alert(`Added ${product.name} (${seats} seat/s) to cart.`);
  };

  const handleSubmitProcurement = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/v1/procurement', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'CREATE',
          product_id: product.id,
          seats,
          reason: procureReason,
          requested_by_id: 'usr_dev_01',
          requested_by_name: 'Tom Reynolds',
          requested_by_email: 'tom@ahyx.org'
        })
      });
      const data = await res.json();
      if (data.success) {
        setProcureSubmitted(true);
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0c10] text-slate-100 font-sans flex flex-col font-mono text-xs">
      <Header
        cartCount={0}
        onOpenCart={() => (window.location.href = '/cart')}
        onOpenTerminal={() => setTerminalOpen(true)}
        onOpenCopilot={() => setCopilotOpen(true)}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      {/* Breadcrumb Navigation */}
      <div className="bg-[#12151e] border-b border-[#232838] py-2 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex items-center space-x-2 text-[11px] text-slate-400">
          <Link href="/products" className="hover:text-slate-200 transition flex items-center">
            <ArrowLeft className="w-3.5 h-3.5 mr-1" /> CATALOGUE
          </Link>
          <ChevronRight className="w-3 h-3 text-slate-600" />
          <span className="text-slate-300">{product.category}</span>
          <ChevronRight className="w-3 h-3 text-slate-600" />
          <span className="text-sky-400 font-bold">{product.name}</span>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        {/* Software Banner Header */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Main Info Header */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <span className="px-2.5 py-0.5 rounded bg-[#1a1e2b] border border-[#232838] text-slate-200 font-bold uppercase text-[10px]">
                {product.product_type}
              </span>
              <span className="text-slate-300 font-bold text-sm">v{product.version}</span>
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] border ${getSecurityBadgeColor(product.security_status)}`}>
                <ShieldCheck className="w-3.5 h-3.5 mr-1" />
                {product.vendor_verified ? 'VERIFIED PUBLISHER' : 'AUTOMATED SCAN PASSED'}
              </span>
            </div>

            <h1 className="text-3xl font-bold font-mono text-slate-100 leading-tight">
              {product.name}
            </h1>

            <div className="flex items-center space-x-2 text-slate-400 text-xs">
              <span>Vendor:</span>
              <span className="text-sky-400 font-bold">{product.vendor_name}</span>
              <span>•</span>
              <span className="text-amber-400 flex items-center">
                <Star className="w-3.5 h-3.5 fill-amber-400 mr-1" />
                {product.rating.toFixed(1)} ({product.review_count} verified reviews)
              </span>
              <span>•</span>
              <span className="text-slate-300">{product.download_count.toLocaleString()} Downloads</span>
            </div>

            <p className="text-sm font-sans text-slate-300 leading-relaxed">
              {product.description}
            </p>

            {/* Quick Metrics Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 rounded-lg bg-[#12151e] border border-[#232838]">
              <div>
                <div className="text-[10px] text-slate-500 uppercase">LANGUAGES</div>
                <div className="text-slate-200 font-bold">{product.languages.join(', ')}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase">FRAMEWORKS</div>
                <div className="text-slate-200 font-bold">{product.frameworks.join(', ')}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase">LICENSE TYPE</div>
                <div className="text-slate-200 font-bold">{product.license_type}</div>
              </div>
              <div>
                <div className="text-[10px] text-slate-500 uppercase">CODEBASE LOC</div>
                <div className="text-sky-400 font-bold">{product.loc ? product.loc.toLocaleString() : 'N/A'}</div>
              </div>
            </div>
          </div>

          {/* Sticky Purchase & Procurement Panel */}
          <div className="lg:col-span-1">
            <div className="bg-[#121214] border border-[#2D2D30] rounded p-5 shadow-2xl space-y-4 sticky top-20 font-mono">
              <div className="flex items-center justify-between pb-2.5 border-b border-[#2D2D30]">
                <div>
                  <div className="text-[9px] text-[#6B7280] uppercase tracking-wider font-bold">PRICING MODEL</div>
                  <div className="text-white font-bold">{product.pricing_model}</div>
                </div>
                <div className="text-right">
                  <div className="text-[9px] text-[#6B7280] uppercase tracking-wider font-bold">PRICE / SEAT</div>
                  <div className="text-xl font-bold text-[#00FF80]">
                    {formatPrice(product.price, product.currency)}
                  </div>
                </div>
              </div>

              {/* License Seat Selector */}
              <div className="space-y-1.5">
                <label className="text-[9px] text-[#6B7280] uppercase font-bold flex justify-between">
                  <span>Developer License Seats:</span>
                  <span className="text-[#00FF80]">{seats} Seats</span>
                </label>
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setSeats(Math.max(1, seats - 1))}
                    className="w-7 h-7 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-white font-bold"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min="1"
                    value={seats}
                    onChange={e => setSeats(Math.max(1, parseInt(e.target.value) || 1))}
                    className="flex-1 bg-[#0A0A0B] border border-[#2D2D30] rounded py-1 text-center text-white focus:outline-none focus:border-[#00FF80]"
                  />
                  <button
                    onClick={() => setSeats(seats + 1)}
                    className="w-7 h-7 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-white font-bold"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Total Calculation */}
              <div className="p-2.5 rounded bg-[#0A0A0B] border border-[#2D2D30] flex justify-between items-center text-xs">
                <span className="text-[#6B7280] text-[10px]">Total ({seats} seats + 20% VAT):</span>
                <span className="text-base font-bold text-[#00FF80]">
                  {formatPrice(Math.round(totalPrice * 1.2), product.currency)}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2">
                <button
                  onClick={handleAddToCart}
                  className="w-full py-2 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition flex items-center justify-center space-x-2 text-xs shadow-[0_0_15px_rgba(0,255,128,0.2)]"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  <span>BUY ENTITLEMENT</span>
                </button>

                <button
                  onClick={() => setProcureOpen(true)}
                  className="w-full py-2 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-white font-bold transition flex items-center justify-center space-x-2 text-xs"
                >
                  <Building2 className="w-3.5 h-3.5 text-[#00FF80]" />
                  <span>REQUEST QUOTE</span>
                </button>

                <a
                  href={`/api/v1/products/${product.id}/download`}
                  download
                  className="w-full py-2 rounded bg-[#0A0A0B] border border-[#2D2D30] hover:bg-[#121214] text-[#00FF80] font-bold transition flex items-center justify-center space-x-2 text-center text-xs"
                >
                  <Download className="w-3.5 h-3.5 text-[#00FF80]" />
                  <span>DOWNLOAD RELEASE ARCHIVE</span>
                </a>
              </div>

              <div className="text-[9px] text-[#6B7280] text-center space-y-0.5">
                <div>✔ SHA-256 Checksum verified on download</div>
                <div>✔ License pool seat allocation enabled</div>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="border-b border-[#2D2D30] mb-6 flex flex-wrap gap-2 text-xs">
          {[
            { id: 'overview', label: 'OVERVIEW & FEATURES', icon: FileText },
            { id: 'code', label: 'INTERACTIVE CODE EXPLORER', icon: Code2 },
            { id: 'compatibility', label: 'COMPATIBILITY MATRIX', icon: Cpu },
            { id: 'dependencies', label: 'DEPENDENCY TREE', icon: GitFork },
            { id: 'releases', label: 'RELEASES & CHANGELOG', icon: Terminal },
            { id: 'docs', label: 'MARKDOWN DOCS', icon: BookOpen }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-t transition flex items-center space-x-2 font-bold ${
                  isActive
                    ? 'bg-[#121214] text-[#00FF80] border-b-2 border-[#00FF80]'
                    : 'text-[#94A3B8] hover:text-white hover:bg-[#121214]/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Contents */}
        <div className="space-y-8">
          {activeTab === 'overview' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Features List */}
              <div className="bg-[#12151e] border border-[#232838] rounded-lg p-5 space-y-3">
                <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-[#232838] pb-2">
                  KEY ARCHITECTURAL FEATURES
                </h3>
                <div className="space-y-2 text-xs text-slate-300">
                  {product.features.map((feat, i) => (
                    <div key={i} className="flex items-start space-x-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Verified Customer Reviews */}
              <div className="bg-[#12151e] border border-[#232838] rounded-lg p-5 space-y-3">
                <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-[#232838] pb-2">
                  VERIFIED CUSTOMER REVIEWS ({reviews.length})
                </h3>
                {reviews.length === 0 ? (
                  <p className="text-slate-500 text-xs">No verified reviews submitted yet.</p>
                ) : (
                  <div className="space-y-3">
                    {reviews.map(rev => (
                      <div key={rev.id} className="p-3 rounded bg-[#0a0c10] border border-[#1f2434] space-y-1">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-bold text-slate-200">{rev.user_name} ({rev.user_role})</span>
                          <span className="text-amber-400">★ {rev.rating}.0</span>
                        </div>
                        <div className="text-xs font-bold text-sky-300">{rev.title}</div>
                        <p className="text-xs text-slate-300 leading-relaxed">{rev.body}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'code' && (
            <CodePreview files={product.code_files} title={`${product.name} Code Explorer`} />
          )}

          {activeTab === 'compatibility' && (
            <CompatibilityMatrix compatibility={product.compatibility} />
          )}

          {activeTab === 'dependencies' && (
            <DependencyGraph dependencies={product.dependencies} />
          )}

          {activeTab === 'releases' && (
            <div className="bg-[#12151e] border border-[#232838] rounded-lg p-5 space-y-4">
              <h3 className="font-bold text-slate-200 uppercase tracking-wider text-xs border-b border-[#232838] pb-2">
                RELEASE HISTORY & CHANGELOG
              </h3>
              {product.changelog.map((log, i) => (
                <div key={i} className="p-3 rounded bg-[#0a0c10] border border-[#1f2434] text-xs text-slate-200">
                  {log}
                </div>
              ))}
            </div>
          )}

          {activeTab === 'docs' && (
            <div className="bg-[#12151e] border border-[#232838] rounded-lg p-6 space-y-4 text-xs font-mono text-slate-300 leading-relaxed">
              <pre className="whitespace-pre-wrap font-mono">{product.documentation}</pre>
            </div>
          )}
        </div>
      </main>

      {/* Procurement Request Modal */}
      {procureOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 font-mono text-xs">
          <div className="w-full max-w-md bg-[#12151e] border border-[#232838] rounded-xl p-6 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-100 flex items-center space-x-2">
              <Building2 className="w-4 h-4 text-sky-400" />
              <span>SUBMIT B2B PURCHASE REQUEST</span>
            </h3>

            {procureSubmitted ? (
              <div className="p-4 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 space-y-2 text-center">
                <CheckCircle2 className="w-8 h-8 mx-auto" />
                <p className="font-bold">Purchase Request Submitted!</p>
                <p className="text-xs text-slate-300">
                  Request PR-2026-0502 sent to Northstar Engineering procurement manager for approval.
                </p>
                <button
                  onClick={() => setProcureOpen(false)}
                  className="px-4 py-1.5 rounded bg-emerald-500 text-slate-950 font-bold mt-2"
                >
                  Close Modal
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmitProcurement} className="space-y-3">
                <div>
                  <label className="text-slate-400 text-[10px] uppercase font-bold">Product Name:</label>
                  <input
                    type="text"
                    disabled
                    value={product.name}
                    className="w-full bg-[#0a0c10] border border-[#232838] rounded p-2 text-slate-200"
                  />
                </div>

                <div>
                  <label className="text-slate-400 text-[10px] uppercase font-bold">Estimated Cost:</label>
                  <input
                    type="text"
                    disabled
                    value={formatPrice(totalPrice, product.currency)}
                    className="w-full bg-[#0a0c10] border border-[#232838] rounded p-2 text-sky-400 font-bold"
                  />
                </div>

                <div>
                  <label className="text-slate-400 text-[10px] uppercase font-bold">Business Justification / Reason:</label>
                  <textarea
                    required
                    rows={3}
                    value={procureReason}
                    onChange={e => setProcureReason(e.target.value)}
                    placeholder="Required for Q4 flight control simulation..."
                    className="w-full bg-[#0a0c10] border border-[#232838] rounded p-2 text-slate-200 focus:outline-none focus:border-sky-500/50"
                  />
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setProcureOpen(false)}
                    className="px-3 py-1.5 rounded bg-[#1a1e2b] text-slate-300"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded bg-sky-500 text-slate-950 font-bold hover:bg-sky-400 transition"
                  >
                    Submit PR Request
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      <Footer />
      <CLITerminal isOpen={terminalOpen} onClose={() => setTerminalOpen(false)} />
      <CopilotDrawer isOpen={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}
