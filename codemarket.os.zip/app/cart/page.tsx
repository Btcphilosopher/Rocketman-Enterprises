'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { formatPrice } from '@/lib/utils';
import { ShoppingBag, Trash2, ArrowRight, ShieldCheck, Building2 } from 'lucide-react';

export default function CartPage() {
  const [items, setItems] = useState([
    {
      product_id: 'prod_rustflow',
      product_name: 'RustFlow Engine',
      version: '3.4.2',
      license_type: 'Commercial Developer',
      unit_price: 24900,
      seats: 5,
      currency: 'GBP'
    }
  ]);
  const [userRole, setUserRole] = useState('PROCUREMENT');

  const subtotal = items.reduce((acc, item) => acc + item.unit_price * item.seats, 0);
  const tax = Math.round(subtotal * 0.2);
  const total = subtotal + tax;

  const removeItem = (idx: number) => {
    setItems(prev => prev.filter((_, i) => i !== idx));
  };

  const updateSeats = (idx: number, newSeats: number) => {
    setItems(prev =>
      prev.map((item, i) => (i === idx ? { ...item, seats: Math.max(1, newSeats) } : item))
    );
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#D1D5DB] font-mono text-xs flex flex-col">
      <Header
        cartCount={items.length}
        onOpenCart={() => {}}
        onOpenTerminal={() => {}}
        onOpenCopilot={() => {}}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        <h1 className="text-lg font-bold text-white mb-6 flex items-center space-x-2 border-b border-[#2D2D30] pb-3">
          <ShoppingBag className="w-5 h-5 text-[#00FF80]" />
          <span>ENTERPRISE SOFTWARE CART & LICENSE CALCULATION</span>
        </h1>

        {items.length === 0 ? (
          <div className="p-10 text-center bg-[#121214] border border-[#2D2D30] rounded space-y-4">
            <p className="text-[#6B7280]">Your shopping cart is currently empty.</p>
            <Link
              href="/products"
              className="px-5 py-2 rounded bg-[#00FF80] text-black font-bold inline-block hover:bg-[#00E673] transition"
            >
              Browse Software Catalog
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Cart Items List */}
            <div className="lg:col-span-2 space-y-3">
              {items.map((item, idx) => (
                <div
                  key={idx}
                  className="bg-[#121214] border border-[#2D2D30] rounded p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="font-bold text-white text-sm">{item.product_name}</div>
                    <div className="text-[#6B7280] text-[11px]">
                      Version: <span className="text-[#00FF80]">v{item.version}</span> | License: {item.license_type}
                    </div>
                    <div className="text-[#6B7280] text-[10px]">
                      Price per seat: {formatPrice(item.unit_price, item.currency)}
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    {/* Seat Counter */}
                    <div className="flex items-center space-x-1 bg-[#0A0A0B] border border-[#2D2D30] rounded px-2 py-1">
                      <button
                        onClick={() => updateSeats(idx, item.seats - 1)}
                        className="px-1.5 font-bold text-[#6B7280] hover:text-white"
                      >
                        -
                      </button>
                      <span className="px-2 text-[#00FF80] font-bold">{item.seats} Seats</span>
                      <button
                        onClick={() => updateSeats(idx, item.seats + 1)}
                        className="px-1.5 font-bold text-[#6B7280] hover:text-white"
                      >
                        +
                      </button>
                    </div>

                    <div className="text-right">
                      <div className="font-bold text-white">
                        {formatPrice(item.unit_price * item.seats, item.currency)}
                      </div>
                    </div>

                    <button
                      onClick={() => removeItem(idx)}
                      className="p-1.5 text-[#6B7280] hover:text-red-400 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Order Summary & Proceed */}
            <div className="bg-[#121214] border border-[#2D2D30] rounded p-5 space-y-4 h-fit">
              <h3 className="font-bold text-white uppercase tracking-wider text-xs border-b border-[#2D2D30] pb-2">
                FINANCIAL SUMMARY
              </h3>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-[#6B7280]">
                  <span>Subtotal:</span>
                  <span className="text-white">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-[#6B7280]">
                  <span>Estimated VAT (20%):</span>
                  <span className="text-white">{formatPrice(tax)}</span>
                </div>
                <div className="flex justify-between text-white font-bold border-t border-[#2D2D30] pt-2 text-sm">
                  <span>Total Amount Due:</span>
                  <span className="text-[#00FF80]">{formatPrice(total)}</span>
                </div>
              </div>

              <Link
                href="/checkout"
                className="w-full py-2.5 rounded bg-[#00FF80] hover:bg-[#00E673] text-black font-bold transition flex items-center justify-center space-x-2 text-center text-xs shadow-[0_0_15px_rgba(0,255,128,0.2)]"
              >
                <span>PROCEED TO CHECKOUT</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
