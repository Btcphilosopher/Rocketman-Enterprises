'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { CLITerminal } from '@/components/CLITerminal';
import { CopilotDrawer } from '@/components/CopilotDrawer';
import { PurchaseRequest, AuditEvent, Organisation } from '@/lib/types';
import { formatPrice } from '@/lib/utils';
import {
  Building2,
  CheckCircle2,
  XCircle,
  Clock,
  ShieldCheck,
  FileText,
  DollarSign,
  Users,
  Activity,
  Award
} from 'lucide-react';

export default function EnterprisePage() {
  const [requests, setRequests] = useState<PurchaseRequest[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'requests' | 'inventory' | 'audit' | 'budget'>('requests');
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [userRole, setUserRole] = useState('PROCUREMENT');

  useEffect(() => {
    fetchEnterpriseData();
  }, []);

  const fetchEnterpriseData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/v1/procurement');
      const data = await res.json();
      if (data.requests) setRequests(data.requests);

      // Default audit events
      setAuditLogs([
        {
          id: 'aud_101',
          timestamp: new Date().toISOString(),
          actor_name: 'Tom Reynolds',
          actor_email: 'tom@ahyx.org',
          organisation_id: 'org_northstar_eng',
          action: 'PROCUREMENT_REQUESTED',
          object_type: 'PurchaseRequest',
          object_id: 'pr_501',
          details: 'Submitted purchase request for AeroSim Python CFD Toolkit (£1,200.00)'
        },
        {
          id: 'aud_100',
          timestamp: '2026-08-29T10:15:00Z',
          actor_name: 'Sarah Jenkins',
          actor_email: 'sarah.lead@northstar.io',
          organisation_id: 'org_northstar_eng',
          action: 'PURCHASE_APPROVED',
          object_type: 'Order',
          object_id: 'ord_10482',
          details: 'Approved order CM-10482 for 5 seats of RustFlow Engine'
        }
      ]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (requestId: string) => {
    try {
      const res = await fetch('/api/v1/procurement', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'APPROVE',
          request_id: requestId,
          reviewer_name: 'Sarah Jenkins (Procurement Manager)'
        })
      });
      const data = await res.json();
      if (data.success) {
        alert('Purchase request approved! Converted to order & generated active entitlement.');
        fetchEnterpriseData();
      } else {
        alert(data.error?.message || 'Failed to approve');
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#D1D5DB] font-mono text-xs flex flex-col">
      <Header
        cartCount={0}
        onOpenCart={() => (window.location.href = '/cart')}
        onOpenTerminal={() => setTerminalOpen(true)}
        onOpenCopilot={() => setCopilotOpen(true)}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        {/* Enterprise Header */}
        <div className="mb-6 pb-3 border-b border-[#2D2D30] flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold text-white flex items-center space-x-2">
              <Building2 className="w-5 h-5 text-[#00FF80]" />
              <span>CODEMARKET ENTERPRISE & PROCUREMENT CONTROL</span>
            </h1>
            <p className="text-[#6B7280] mt-0.5 text-[11px]">
              Organisation: <strong className="text-white">Northstar Engineering Ltd</strong> | Budget Limit: £250,000.00
            </p>
          </div>
        </div>

        {/* Top Executive Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
          <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
            <div className="text-[9px] text-[#6B7280] uppercase font-bold">ANNUAL SOFTWARE BUDGET</div>
            <div className="text-lg font-bold text-white mt-1">£250,000.00</div>
            <div className="text-[10px] text-[#00FF80] mt-0.5 font-semibold">£107,000.00 Remaining</div>
          </div>

          <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
            <div className="text-[9px] text-[#6B7280] uppercase font-bold">PENDING APPROVALS</div>
            <div className="text-lg font-bold text-[#F59E0B] mt-1">
              {requests.filter(r => r.status === 'PENDING_APPROVAL').length} Requests
            </div>
            <div className="text-[10px] text-[#6B7280] mt-0.5">Requires Manager Sign-off</div>
          </div>

          <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
            <div className="text-[9px] text-[#6B7280] uppercase font-bold">ACTIVE LICENSE SEATS</div>
            <div className="text-lg font-bold text-[#3B82F6] mt-1">12 / 15 Assigned</div>
            <div className="text-[10px] text-[#6B7280] mt-0.5">Across 48 Engineers</div>
          </div>

          <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
            <div className="text-[9px] text-[#6B7280] uppercase font-bold">COMPLIANCE & AUDIT</div>
            <div className="text-lg font-bold text-[#00FF80] mt-1">SOC 2 PASSED</div>
            <div className="text-[10px] text-[#6B7280] mt-0.5">SHA-256 Checksums Verified</div>
          </div>
        </div>

        {/* Tabs Navigation */}
        <div className="border-b border-[#2D2D30] mb-6 flex space-x-2">
          {[
            { id: 'requests', label: 'PROCUREMENT APPROVAL QUEUE', icon: Clock },
            { id: 'audit', label: 'AUDIT EVENT LOGS', icon: Activity },
            { id: 'inventory', label: 'SOFTWARE ASSET REGISTER', icon: Building2 }
          ].map(tab => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-t transition flex items-center space-x-2 font-bold text-xs ${
                  isActive
                    ? 'bg-[#121214] text-[#00FF80] border-b-2 border-[#00FF80]'
                    : 'text-[#94A3B8] hover:text-white hover:bg-[#121214]/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        {activeTab === 'requests' && (
          <div className="space-y-3">
            <h3 className="font-bold text-white uppercase tracking-wider text-xs">
              PENDING SOFTWARE PURCHASE REQUESTS
            </h3>

            {requests.length === 0 ? (
              <div className="p-8 text-center bg-[#121214] border border-[#2D2D30] rounded text-[#6B7280]">
                No purchase requests pending approval.
              </div>
            ) : (
              requests.map(req => (
                <div
                  key={req.id}
                  className="bg-[#121214] border border-[#2D2D30] rounded p-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-white text-sm">{req.product_name}</span>
                      <span className="px-2 py-0.5 rounded bg-[#1A1A1C] border border-[#2D2D30] text-[#00FF80] text-[10px] font-bold">
                        {req.request_number}
                      </span>
                    </div>

                    <div className="text-[#D1D5DB] text-xs">
                      Requested by: <strong className="text-[#00FF80]">{req.requested_by_name}</strong> ({req.department})
                    </div>

                    <p className="text-[#6B7280] text-xs italic">
                      Justification: &quot;{req.reason}&quot;
                    </p>
                  </div>

                  <div className="flex items-center space-x-4 shrink-0">
                    <div className="text-right">
                      <div className="text-[#6B7280] text-[10px] uppercase font-semibold">Amount</div>
                      <div className="text-base font-bold text-white">
                        {formatPrice(req.amount, req.currency)}
                      </div>
                    </div>

                    {req.status === 'PENDING_APPROVAL' ? (
                      <button
                        onClick={() => handleApprove(req.id)}
                        className="px-4 py-1.5 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition text-xs"
                      >
                        APPROVE & ISSUE PO
                      </button>
                    ) : (
                      <span className="px-3 py-1 rounded bg-[#00FF80]/10 text-[#00FF80] border border-[#00FF80]/30 font-bold">
                        APPROVED
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {activeTab === 'audit' && (
          <div className="bg-[#121214] border border-[#2D2D30] rounded p-4 space-y-3">
            <h3 className="font-bold text-white uppercase tracking-wider text-xs border-b border-[#2D2D30] pb-2">
              AUDIT TRAIL & COMPLIANCE EVENT LOGS
            </h3>

            <div className="space-y-2">
              {auditLogs.map(log => (
                <div key={log.id} className="p-2.5 rounded bg-[#0A0A0B] border border-[#2D2D30] flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white flex items-center space-x-2">
                      <span className="text-[#00FF80]">{log.action}</span>
                      <span className="text-[#6B7280]">•</span>
                      <span>{log.actor_name} ({log.actor_email})</span>
                    </div>
                    <div className="text-[#6B7280] text-[11px] mt-0.5">{log.details}</div>
                  </div>
                  <span className="text-[10px] text-[#6B7280]">{new Date(log.timestamp).toLocaleString()}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'inventory' && (
          <div className="bg-[#121214] border border-[#2D2D30] rounded p-4 space-y-3">
            <h3 className="font-bold text-white uppercase tracking-wider text-xs border-b border-[#2D2D30] pb-2">
              ORGANISATION SOFTWARE ASSET REGISTER
            </h3>

            <div className="space-y-2">
              {[
                { name: 'RustFlow Engine', version: 'v3.4.2', vendor: 'Northstar Systems', seats: '4/5 Seats', status: 'ACTIVE' },
                { name: 'Aardvark Enterprise UI Kit', version: 'v4.2.1', vendor: 'Aardvark Labs', seats: '8/10 Seats', status: 'ACTIVE' }
              ].map((item, i) => (
                <div key={i} className="p-2.5 rounded bg-[#0A0A0B] border border-[#2D2D30] flex items-center justify-between text-xs">
                  <div>
                    <div className="font-bold text-white">{item.name} <span className="text-[#00FF80]">{item.version}</span></div>
                    <div className="text-[#6B7280] text-[10px]">Vendor: {item.vendor} | Capacity: {item.seats}</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-[#00FF80]/10 text-[#00FF80] font-bold border border-[#00FF80]/30 text-[10px]">
                    {item.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      <Footer />
      <CLITerminal isOpen={terminalOpen} onClose={() => setTerminalOpen(false)} />
      <CopilotDrawer isOpen={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}
