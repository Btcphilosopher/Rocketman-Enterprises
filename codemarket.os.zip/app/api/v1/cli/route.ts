import { NextRequest, NextResponse } from 'next/server';
import { dbStore } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const { command } = await req.json();

    if (!command || typeof command !== 'string') {
      return NextResponse.json({ output: 'Error: No command provided.' }, { status: 400 });
    }

    const parts = command.trim().split(/\s+/);
    const mainCmd = parts[0];
    const subCmd = parts[1];
    const arg = parts.slice(2).join(' ').replace(/^["']|["']$/g, '');

    if (mainCmd !== 'codemarket') {
      return NextResponse.json({
        output: `Command not recognized: '${mainCmd}'. Type 'codemarket help' for available commands.`
      });
    }

    if (!subCmd || subCmd === 'help') {
      return NextResponse.json({
        output: `CODEMARKET.OS CLI v1.4.0
Available commands:
  codemarket search "<query>"       Search software catalog
  codemarket inspect <product-slug> Inspect technical product specifications
  codemarket library                List owned entitlements in organization
  codemarket download <product-slug> Get signed download token and SHA-256
  codemarket install <product-slug>  Simulate package installation
  codemarket manifest <product-slug> Generate codemarket.yaml manifest`
      });
    }

    if (subCmd === 'search') {
      const query = (parts.slice(2).join(' ') || '').toLowerCase().replace(/^["']|["']$/g, '');
      const products = dbStore.getProducts().filter(
        p =>
          p.name.toLowerCase().includes(query) ||
          p.tags.some(t => t.toLowerCase().includes(query)) ||
          p.languages.some(l => l.toLowerCase().includes(query))
      );

      if (products.length === 0) {
        return NextResponse.json({
          output: `No software assets found matching query: "${query}"`
        });
      }

      const table = products
        .map(
          p =>
            `[${p.product_type}] ${p.name.padEnd(28)} v${p.version.padEnd(8)} ${p.languages.join(',').padEnd(14)} £${(p.price / 100).toFixed(0)}`
        )
        .join('\n');

      return NextResponse.json({
        output: `FOUND ${products.length} MATCHING SOFTWARE ASSET(S):\n\n${table}`
      });
    }

    if (subCmd === 'inspect') {
      const slug = parts[2];
      const prod = dbStore.getProductBySlugOrId(slug || 'rustflow-engine');
      if (!prod) {
        return NextResponse.json({ output: `Product not found: ${slug}` });
      }

      return NextResponse.json({
        output: `--------------------------------------------------
SOFTWARE ASSET INSPECTION: ${prod.name.toUpperCase()}
--------------------------------------------------
ID:           ${prod.id}
Slug:         ${prod.slug}
Version:      v${prod.version}
Vendor:       ${prod.vendor_name} (Verified: ${prod.vendor_verified})
Type:         ${prod.product_type}
License:      ${prod.license_type}
Price:        £${(prod.price / 100).toFixed(2)}
Rating:       ★ ${prod.rating} (${prod.review_count} reviews)
Security:     ${prod.security_status}
Dependencies: ${prod.dependencies.map(d => `${d.name}@${d.version}`).join(', ')}
LOC:          ${prod.loc ? prod.loc.toLocaleString() : 'N/A'}
Coverage:     ${prod.test_coverage || 'N/A'}

Install Cmd:  ${prod.install_command || 'N/A'}`
      });
    }

    if (subCmd === 'library') {
      const ents = dbStore.getEntitlements();
      const list = ents
        .map(
          e =>
            `✔ ${e.product_name.padEnd(28)} v${e.version} (${e.seats_assigned}/${e.seats_total} seats) Key: ${e.license_key}`
        )
        .join('\n');
      return NextResponse.json({
        output: `ORGANISATION SOFTWARE LIBRARY (${ents.length} ACTIVE ENTITLEMENTS):\n\n${list}`
      });
    }

    if (subCmd === 'download') {
      const slug = parts[2] || 'rustflow-engine';
      const prod = dbStore.getProductBySlugOrId(slug);
      if (!prod) return NextResponse.json({ output: `Product not found: ${slug}` });

      return NextResponse.json({
        output: `GENERATING SIGNED DOWNLOAD TOKEN FOR ${prod.name.toUpperCase()} v${prod.version}...
Token: dl_tok_${Date.now()}_signed
Expires: 1 hour
SHA-256 Checksum: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
Download URL: /api/v1/products/${prod.id}/download`
      });
    }

    if (subCmd === 'install') {
      const slug = parts[2] || 'rustflow-engine';
      const prod = dbStore.getProductBySlugOrId(slug);
      if (!prod) return NextResponse.json({ output: `Product not found: ${slug}` });

      return NextResponse.json({
        output: `FETCHING ENTITLEMENT... SUCCESS
VERIFYING SHA-256 CHECKSUM... OK
EXTRACTING ASSETS FOR ${prod.name.toUpperCase()}... OK
EXECUTING POST-INSTALL HOOKS...
> ${prod.install_command || 'cargo add ' + prod.slug}
INSTALLED SUCCESSFUL: ${prod.slug} v${prod.version}`
      });
    }

    if (subCmd === 'manifest') {
      const slug = parts[2] || 'rustflow-engine';
      const prod = dbStore.getProductBySlugOrId(slug);
      if (!prod) return NextResponse.json({ output: `Product not found: ${slug}` });

      return NextResponse.json({
        output: `# codemarket.yaml
name: ${prod.slug}
version: ${prod.version}
type: ${prod.product_type.toLowerCase()}
license: ${prod.license_type.toLowerCase()}
languages:
${prod.languages.map(l => `  - ${l.toLowerCase()}`).join('\n')}
dependencies:
${prod.dependencies.map(d => `  - name: ${d.name}\n    version: "${d.version}"`).join('\n')}`
      });
    }

    return NextResponse.json({
      output: `Unknown subcommand '${subCmd}'. Type 'codemarket help'`
    });
  } catch (error: any) {
    return NextResponse.json({ output: `CLI Error: ${error.message}` }, { status: 500 });
  }
}
