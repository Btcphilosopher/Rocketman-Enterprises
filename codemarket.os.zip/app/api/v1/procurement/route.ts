import { NextRequest, NextResponse } from 'next/server';
import { dbStore } from '@/lib/db';
import { PurchaseRequest } from '@/lib/types';

export async function GET() {
  try {
    const requests = dbStore.getPurchaseRequests();
    return NextResponse.json({ success: true, requests });
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'INTERNAL_ERROR', message: error.message } },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === 'APPROVE') {
      const { request_id, reviewer_name } = body;
      const res = dbStore.approvePurchaseRequest(request_id, reviewer_name || 'Sarah Jenkins');
      return NextResponse.json({ success: true, ...res });
    }

    if (action === 'CREATE') {
      const product = dbStore.getProductBySlugOrId(body.product_id);
      if (!product) {
        return NextResponse.json(
          { error: { code: 'INVALID_PRODUCT', message: 'Product not found' } },
          { status: 400 }
        );
      }

      const seats = body.seats || 1;
      const amount = product.price * seats;

      const newPR: PurchaseRequest = {
        id: `pr_${Date.now()}`,
        request_number: `PR-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        organisation_id: body.organisation_id || 'org_northstar_eng',
        organisation_name: 'Northstar Engineering Ltd',
        requested_by_id: body.requested_by_id || 'usr_dev_01',
        requested_by_name: body.requested_by_name || 'Tom Reynolds',
        requested_by_email: body.requested_by_email || 'tom@ahyx.org',
        department: body.department || 'Software Architecture',
        product_id: product.id,
        product_name: product.name,
        version: product.version,
        license_type: product.license_type,
        seats,
        amount,
        currency: product.currency,
        reason: body.reason || 'Needed for enterprise project deployment.',
        status: 'PENDING_APPROVAL',
        created_at: new Date().toISOString()
      };

      dbStore.createPurchaseRequest(newPR);
      return NextResponse.json({ success: true, request: newPR });
    }

    return NextResponse.json(
      { error: { code: 'INVALID_ACTION', message: 'Action must be CREATE or APPROVE' } },
      { status: 400 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'PROCUREMENT_ERROR', message: error.message } },
      { status: 500 }
    );
  }
}
