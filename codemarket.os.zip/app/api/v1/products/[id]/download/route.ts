import { NextRequest, NextResponse } from 'next/server';
import { dbStore } from '@/lib/db';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(req.url);
    const version = searchParams.get('version');

    const product = dbStore.getProductBySlugOrId(id);
    if (!product) {
      return NextResponse.json(
        { error: { code: 'PRODUCT_NOT_FOUND', message: 'Product not found' } },
        { status: 404 }
      );
    }

    const downloadVersion = version || product.version;
    const sha256 = `sha256_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;

    // Generate package source archive manifest
    const manifest = {
      product: product.name,
      slug: product.slug,
      version: downloadVersion,
      vendor: product.vendor_name,
      license: product.license_type,
      checksum_sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      downloaded_at: new Date().toISOString(),
      files: product.code_files.map(f => f.path)
    };

    const fileContent = JSON.stringify(manifest, null, 2);

    return new NextResponse(fileContent, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': `attachment; filename="${product.slug}-v${downloadVersion}-release.json"`,
        'X-Checksum-SHA256': manifest.checksum_sha256,
        'X-Entitlement-Status': 'VALID'
      }
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'DOWNLOAD_FAILED', message: error.message } },
      { status: 500 }
    );
  }
}
