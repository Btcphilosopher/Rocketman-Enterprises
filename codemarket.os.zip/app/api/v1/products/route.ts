import { NextRequest, NextResponse } from 'next/server';
import { dbStore } from '@/lib/db';
import { DigitalProduct } from '@/lib/types';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get('q')?.toLowerCase() || '';
    const category = searchParams.get('category') || '';
    const productType = searchParams.get('type') || '';
    const language = searchParams.get('language') || '';
    const verifiedOnly = searchParams.get('verified') === 'true';

    let products = dbStore.getProducts();

    if (search) {
      products = products.filter(
        p =>
          p.name.toLowerCase().includes(search) ||
          p.short_description.toLowerCase().includes(search) ||
          p.description.toLowerCase().includes(search) ||
          p.tags.some(t => t.toLowerCase().includes(search)) ||
          p.languages.some(l => l.toLowerCase().includes(search)) ||
          p.frameworks.some(f => f.toLowerCase().includes(search))
      );
    }

    if (category) {
      products = products.filter(
        p => p.category.toLowerCase() === category.toLowerCase()
      );
    }

    if (productType) {
      products = products.filter(
        p => p.product_type.toLowerCase() === productType.toLowerCase()
      );
    }

    if (language) {
      products = products.filter(p =>
        p.languages.some(l => l.toLowerCase() === language.toLowerCase())
      );
    }

    if (verifiedOnly) {
      products = products.filter(p => p.vendor_verified);
    }

    return NextResponse.json({
      success: true,
      count: products.length,
      products
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'INTERNAL_ERROR', message: error.message } },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    const id = `prod_${Date.now()}`;
    const slug = body.name
      ? body.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')
      : `product-${Date.now()}`;

    const newProduct: DigitalProduct = {
      id,
      slug,
      name: body.name || 'Untitled Software Asset',
      vendor_id: body.vendor_id || 'v_northstar',
      vendor_name: body.vendor_name || 'Northstar Systems',
      vendor_verified: true,
      vendor_avatar: 'https://picsum.photos/seed/northstar/100/100',
      description: body.description || 'Enterprise software product.',
      short_description: body.short_description || 'Enterprise software asset.',
      category: body.category || 'Development',
      subcategory: body.subcategory || 'General',
      product_type: body.product_type || 'CODEBASE',
      version: body.version || '1.0.0',
      latest_version: body.version || '1.0.0',
      license_type: body.license_type || 'Commercial Developer',
      pricing_model: body.pricing_model || 'PER_USER',
      price: body.price ?? 19900,
      currency: body.currency || 'GBP',
      compatibility: body.compatibility || [
        { runtime: 'Node.js', versions: ['20.x'], os: ['Linux', 'macOS', 'Windows'], architectures: ['x86_64', 'ARM64'], tested: true }
      ],
      dependencies: body.dependencies || [],
      frameworks: body.frameworks || ['TypeScript'],
      languages: body.languages || ['TypeScript'],
      platforms: body.platforms || ['Linux', 'macOS', 'Windows'],
      tags: body.tags || ['software', 'codebase'],
      features: body.features || ['Production ready architecture'],
      code_files: body.code_files || [
        { path: 'src/index.ts', language: 'typescript', content: '// Entrypoint\nexport const version = "1.0.0";' }
      ],
      documentation: body.documentation || `# ${body.name || 'Software Package'}\n\nDocumentation provided by vendor.`,
      changelog: body.changelog || ['v1.0.0: Initial release'],
      release_history: [
        {
          version: body.version || '1.0.0',
          release_date: new Date().toISOString().split('T')[0],
          release_notes: 'Initial production release.',
          changelog: ['v1.0.0: Initial release'],
          assets: [
            {
              filename: `${slug}-1.0.0.tar.gz`,
              size: '8.4 MB',
              download_url: `/releases/${slug}-1.0.0.tar.gz`,
              sha256: 'a1b2c3d4e5f60718293a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e'
            }
          ],
          dependencies: [],
          compatibility: [],
          security_status: 'SECURITY_REVIEWED'
        }
      ],
      security_status: 'SECURITY_REVIEWED',
      rating: 5.0,
      review_count: 1,
      download_count: 10,
      install_count: 5,
      sales_count: 1,
      created_at: new Date().toISOString().split('T')[0],
      updated_at: new Date().toISOString().split('T')[0],
      published_at: new Date().toISOString().split('T')[0],
      status: 'PUBLISHED'
    };

    const saved = dbStore.addProduct(newProduct);
    return NextResponse.json({ success: true, product: saved });
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'PUBLISH_FAILED', message: error.message } },
      { status: 400 }
    );
  }
}
