import { NextRequest, NextResponse } from 'next/server';
import { dbStore } from '@/lib/db';
import { Order, OrderItem, Entitlement } from '@/lib/types';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { items, user_email, user_id, organisation_id, payment_method } = body;

    if (!items || !items.length) {
      return NextResponse.json(
        { error: { code: 'CART_EMPTY', message: 'Cart items cannot be empty' } },
        { status: 400 }
      );
    }

    // Recalculate price server-side to enforce financial integrity
    const orderItems: OrderItem[] = [];
    let subtotal = 0;

    for (const item of items) {
      const product = dbStore.getProductBySlugOrId(item.product_id);
      if (!product) {
        return NextResponse.json(
          { error: { code: 'INVALID_PRODUCT', message: `Product ${item.product_id} not found` } },
          { status: 400 }
        );
      }

      const seats = item.seats || 1;
      const unitPrice = product.price; // Server authoritative price
      const totalPrice = unitPrice * seats;

      subtotal += totalPrice;

      orderItems.push({
        product_id: product.id,
        product_name: product.name,
        product_slug: product.slug,
        version: product.version,
        license_type: item.license_type || product.license_type,
        seats,
        unit_price: unitPrice,
        total_price: totalPrice
      });
    }

    const tax = Math.round(subtotal * 0.2); // 20% VAT / Sales tax
    const total = subtotal + tax;

    const orderId = `ord_${Date.now()}`;
    const orderNumber = `CM-${Math.floor(10000 + Math.random() * 90000)}`;
    const invoiceNumber = `INV-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: orderId,
      order_number: orderNumber,
      user_id: user_id || 'usr_dev_01',
      user_email: user_email || 'tom@ahyx.org',
      organisation_id: organisation_id || 'org_northstar_eng',
      organisation_name: 'Northstar Engineering Ltd',
      items: orderItems,
      subtotal,
      tax,
      total,
      currency: 'GBP',
      payment_status: 'PAID',
      payment_method: payment_method || 'Sandbox Credit Card',
      created_at: new Date().toISOString(),
      invoice_number: invoiceNumber,
      po_number: `PO-${Math.floor(1000 + Math.random() * 9000)}`
    };

    // Create corresponding entitlements for each purchased product
    const newEntitlements: Entitlement[] = orderItems.map((item, idx) => {
      return {
        id: `ent_${Date.now()}_${idx}`,
        user_id: newOrder.user_id,
        organisation_id: newOrder.organisation_id,
        product_id: item.product_id,
        product_name: item.product_name,
        product_slug: item.product_slug,
        release_id: `rel_${item.product_id}_${item.version}`,
        version: item.version,
        latest_version: item.version,
        license_type: item.license_type,
        seats_total: item.seats,
        seats_assigned: 1,
        assigned_emails: [newOrder.user_email],
        status: 'ACTIVE',
        purchased_at: new Date().toISOString(),
        license_key: `CM-LIC-${item.product_id.toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}`,
        download_token: `dl_tok_${Date.now()}_${idx}`,
        update_available: false
      };
    });

    dbStore.createOrder(newOrder, newEntitlements);

    return NextResponse.json({
      success: true,
      order: newOrder,
      entitlements: newEntitlements
    });
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'CHECKOUT_FAILED', message: error.message } },
      { status: 500 }
    );
  }
}
