import { NextRequest, NextResponse } from 'next/server';
import { dbStore } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action, entitlement_id, email } = body;

    if (!entitlement_id || !email) {
      return NextResponse.json(
        { error: { code: 'MISSING_FIELDS', message: 'entitlement_id and email are required' } },
        { status: 400 }
      );
    }

    if (action === 'ASSIGN') {
      const updated = dbStore.assignSeat(entitlement_id, email);
      return NextResponse.json({ success: true, entitlement: updated });
    }

    if (action === 'REVOKE') {
      const updated = dbStore.revokeSeat(entitlement_id, email);
      return NextResponse.json({ success: true, entitlement: updated });
    }

    return NextResponse.json(
      { error: { code: 'INVALID_ACTION', message: 'Action must be ASSIGN or REVOKE' } },
      { status: 400 }
    );
  } catch (error: any) {
    return NextResponse.json(
      { error: { code: 'LICENSING_ERROR', message: error.message } },
      { status: 400 }
    );
  }
}
