import { NextRequest, NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';
import { dbStore } from '@/lib/db';

export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json();

    if (!prompt) {
      return NextResponse.json(
        { error: { code: 'MISSING_PROMPT', message: 'Prompt is required' } },
        { status: 400 }
      );
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const products = dbStore.getProducts().map(p => ({
      name: p.name,
      slug: p.slug,
      category: p.category,
      product_type: p.product_type,
      languages: p.languages,
      frameworks: p.frameworks,
      version: p.version,
      license_type: p.license_type,
      price: p.price / 100,
      currency: p.currency,
      description: p.short_description,
      security_status: p.security_status
    }));

    if (!apiKey) {
      // Graceful fallback if GEMINI_API_KEY is missing
      return NextResponse.json({
        success: true,
        response: `CODEMARKET Copilot Analysis:
Based on our verified marketplace data:
- **RustFlow Engine** (v3.4.2, £249): Async Rust workflow orchestration engine with PostgreSQL persistence and OpenTelemetry support.
- **PostgreSQL Analytics Engine** (v2.0.4, £899): Native C extension adding columnar HTAP storage and vector acceleration to Postgres.
- **Aardvark Enterprise UI Kit** (v4.2.1, £149): High density React 19 & Tailwind UI library for financial dashboards.

All software assets include SHA-256 integrity checksums and enterprise entitlement keys.`
      });
    }

    const ai = new GoogleGenAI({ apiKey });
    const systemInstruction = `You are CODEMARKET Copilot, a principal software architect assistant for CODEMARKET.OS.
You answer technical questions using ONLY authoritative marketplace data provided below.
Do NOT fabricate products, prices, or specifications.
Be concise, technical, precise, and professional.

Authoritative Marketplace Software Catalog:
${JSON.stringify(products, null, 2)}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction
      }
    });

    return NextResponse.json({
      success: true,
      response: response.text || 'No response generated from Copilot.'
    });
  } catch (error: any) {
    console.error('Copilot error:', error);
    return NextResponse.json({
      success: true,
      response: `CODEMARKET Copilot (Offline Mode): Unable to connect to Gemini API. Showing catalog match for query. Please check available products in the Explorer.`
    });
  }
}
