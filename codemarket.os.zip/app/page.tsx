'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { ProductCard } from '@/components/ProductCard';
import { CLITerminal } from '@/components/CLITerminal';
import { CopilotDrawer } from '@/components/CopilotDrawer';
import { DigitalProduct } from '@/lib/types';
import {
  Code2,
  Terminal,
  ShieldCheck,
  Building2,
  Sparkles,
  ArrowRight,
  SlidersHorizontal,
  Cpu,
  Layers,
  GitBranch,
  Lock,
  Download,
  CheckCircle2,
  Zap
} from 'lucide-react';

export default function HomePage() {
  const [products, setProducts] = useState<DigitalProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [cart, setCart] = useState<DigitalProduct[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [userRole, setUserRole] = useState('PROCUREMENT');
  const [activeTab, setActiveTab] = useState('ALL');

  useEffect(() => {
    fetch('/api/v1/products')
      .then(res => res.json())
      .then(data => {
        if (data.products) setProducts(data.products);
      })
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  const handleAddToCart = (product: DigitalProduct) => {
    setCart(prev => [...prev, product]);
    alert(`Added ${product.name} to cart.`);
  };

  const filteredProducts = products.filter(p => {
    if (activeTab === 'ALL') return true;
    if (activeTab === 'CODEBASE') return p.product_type === 'CODEBASE';
    if (activeTab === 'UI_KIT') return p.product_type === 'COMPONENT_LIBRARY';
    if (activeTab === 'DATABASE') return p.product_type === 'DATABASE';
    if (activeTab === 'ENGINEERING') return p.product_type === 'ENGINEERING_TOOL';
    return true;
  });

  return (
    <div className="min-h-screen bg-[#0a0c10] text-slate-100 font-sans flex flex-col selection:bg-sky-500/30 selection:text-sky-200">
      <Header
        cartCount={cart.length}
        onOpenCart={() => (window.location.href = '/cart')}
        onOpenTerminal={() => setTerminalOpen(true)}
        onOpenCopilot={() => setCopilotOpen(true)}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      {/* Hero Section */}
      <section className="relative pt-12 pb-16 border-b border-[#2D2D30] bg-[#0A0A0B] bg-tech-grid bg-radial-gradient">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-5">
            {/* Pill Header */}
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded bg-[#00FF80]/10 border border-[#00FF80]/20 text-[#00FF80] font-mono text-xs">
              <Sparkles className="w-3.5 h-3.5 text-[#00FF80]" />
              <span className="font-semibold tracking-wider uppercase">ENTERPRISE CODEBASE & SOFTWARE MARKETPLACE</span>
            </div>

            {/* Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white font-mono leading-tight">
              BUILD FROM SOFTWARE.<br />
              <span className="text-[#00FF80]">
                NOT FROM SCRATCH.
              </span>
            </h1>

            {/* Subheading */}
            <p className="text-xs sm:text-sm text-[#94A3B8] max-w-2xl mx-auto leading-relaxed font-sans">
              Discover, license, and deploy production-grade codebases, C++ solvers, Rust engines, AI models, and enterprise component suites with SHA-256 binary validation and B2B procurement workflows.
            </p>

            {/* CTA Buttons */}
            <div className="pt-2 flex flex-wrap items-center justify-center gap-3 font-mono text-xs">
              <Link
                href="/products"
                className="px-6 py-2.5 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition shadow-[0_0_20px_rgba(0,255,128,0.2)] flex items-center space-x-2"
              >
                <span>EXPLORE SOFTWARE CATALOGUE</span>
                <ArrowRight className="w-4 h-4" />
              </Link>

              <button
                onClick={() => setTerminalOpen(true)}
                className="px-6 py-2.5 rounded bg-[#1A1A1C] border border-[#2D2D30] text-white hover:bg-[#2D2D30] transition flex items-center space-x-2 font-bold"
              >
                <Terminal className="w-4 h-4 text-[#00FF80]" />
                <span>LAUNCH CLI TERMINAL</span>
              </button>
            </div>

            {/* Platform Trust Metrics */}
            <div className="pt-6 grid grid-cols-2 md:grid-cols-4 gap-3 text-left font-mono text-xs max-w-4xl mx-auto border-t border-[#2D2D30]">
              <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
                <div className="text-[#6B7280] text-[9px] uppercase tracking-wider font-bold">VERIFIED CODEBASES</div>
                <div className="text-sm font-bold text-white">120+ Published</div>
              </div>
              <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
                <div className="text-[#6B7280] text-[9px] uppercase tracking-wider font-bold">SHA-256 VALIDATED</div>
                <div className="text-sm font-bold text-[#00FF80]">100% Signed</div>
              </div>
              <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
                <div className="text-[#6B7280] text-[9px] uppercase tracking-wider font-bold">LICENSE SEAT POOLS</div>
                <div className="text-sm font-bold text-[#3B82F6]">B2B Compliant</div>
              </div>
              <div className="p-3 rounded bg-[#121214] border border-[#2D2D30]">
                <div className="text-[#6B7280] text-[9px] uppercase tracking-wider font-bold">PROCUREMENT WORKFLOW</div>
                <div className="text-sm font-bold text-white">PO & VAT Ready</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Catalog View Section */}
      <section className="py-12 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex-1 w-full">
        {/* Section Title & Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4 border-b border-[#2D2D30] pb-3">
          <div>
            <h2 className="text-lg font-bold font-mono text-white flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-[#00FF80]" />
              FEATURED SOFTWARE ASSETS
            </h2>
            <p className="text-[11px] text-[#6B7280] font-mono mt-0.5">
              Production-oriented codebases with full documentation, tests, and seat licensing
            </p>
          </div>

          {/* Type Filter Tabs */}
          <div className="flex flex-wrap gap-1 font-mono text-xs">
            {[
              { id: 'ALL', label: 'ALL ASSETS' },
              { id: 'CODEBASE', label: 'CODEBASES' },
              { id: 'UI_KIT', label: 'UI KITS' },
              { id: 'DATABASE', label: 'DATABASES' },
              { id: 'ENGINEERING', label: 'ENGINEERING' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-3 py-1 rounded text-[11px] font-bold transition ${
                  activeTab === tab.id
                    ? 'bg-[#1E1E20] text-white border-b-2 border-[#00FF80]'
                    : 'text-[#94A3B8] hover:text-white hover:bg-[#121214]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-8">
            {[1, 2, 3].map(i => (
              <div
                key={i}
                className="h-64 bg-[#121214] border border-[#2D2D30] rounded animate-pulse"
              />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        )}
      </section>

      {/* Enterprise Procurement Feature Highlight */}
      <section className="bg-[#0E0E10] border-y border-[#2D2D30] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
            <div className="space-y-4 font-mono">
              <div className="inline-flex items-center space-x-2 px-2.5 py-1 rounded bg-[#00FF80]/10 border border-[#00FF80]/20 text-[#00FF80] text-xs">
                <Building2 className="w-3.5 h-3.5" />
                <span className="font-bold">ENTERPRISE PROCUREMENT ARCHITECTURE</span>
              </div>

              <h2 className="text-2xl font-bold text-white">
                BUILT FOR ENGINEERING MANAGERS & PROCUREMENT TEAMS
              </h2>

              <p className="text-xs text-[#94A3B8] font-sans leading-relaxed">
                Developers request software; procurement officers approve within budget limits. CODEMARKET.OS manages PO invoicing, seat allocation, license keys, and breaking change notifications automatically.
              </p>

              <div className="space-y-2 text-xs">
                {[
                  'Automated budget checks & department manager approvals',
                  'Centralized software asset register across all engineering teams',
                  'License seat assign & revoke pool management',
                  'Audit event logging & VAT compliance receipts'
                ].map((item, i) => (
                  <div key={i} className="flex items-center space-x-2 text-[#D1D5DB]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00FF80] shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              <div className="pt-2">
                <Link
                  href="/enterprise"
                  className="inline-flex items-center space-x-2 px-4 py-2 rounded bg-[#1A1A1C] border border-[#2D2D30] text-white hover:bg-[#2D2D30] font-bold text-xs transition"
                >
                  <span>LAUNCH ENTERPRISE DASHBOARD</span>
                  <ArrowRight className="w-3.5 h-3.5 text-[#00FF80]" />
                </Link>
              </div>
            </div>

            {/* Mock Procurement Card UI */}
            <div className="bg-[#121214] border border-[#2D2D30] rounded p-5 font-mono text-xs space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-[#2D2D30]">
                <span className="text-[#94A3B8] font-bold text-[11px]">APPROVAL QUEUE — PR-2026-0501</span>
                <span className="px-2 py-0.5 rounded bg-amber-500/10 text-amber-500 border border-amber-500/20 text-[10px] font-bold">
                  PENDING MANAGER REVIEW
                </span>
              </div>

              <div className="p-3 rounded bg-[#0A0A0B] border border-[#2D2D30] space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Requested By:</span>
                  <span className="text-white">Tom Reynolds (Staff Engineer)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Software:</span>
                  <span className="text-[#00FF80] font-bold">AeroSim Python CFD Toolkit</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#6B7280]">Amount:</span>
                  <span className="text-white font-bold">£1,200.00 (1 Enterprise Seat)</span>
                </div>
              </div>

              <div className="flex justify-end space-x-2 pt-1">
                <button
                  onClick={() => alert('Simulated Procurement Request Approval!')}
                  className="px-4 py-1.5 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition text-xs shadow-[0_0_10px_rgba(0,255,128,0.2)]"
                >
                  APPROVE & ISSUE PO
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />

      {/* Drawers & Modals */}
      <CLITerminal isOpen={terminalOpen} onClose={() => setTerminalOpen(false)} />
      <CopilotDrawer isOpen={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}
