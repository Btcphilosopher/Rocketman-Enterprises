'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { formatPrice } from '@/lib/utils';
import { CreditCard, CheckCircle2, ShieldCheck, Building2, Key, Download } from 'lucide-react';

export default function CheckoutPage() {
  const [loading, setLoading] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<any>(null);
  const [completedEntitlements, setCompletedEntitlements] = useState<any[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('SANDBOX_CREDIT_CARD');

  const handlePay = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await fetch('/api/v1/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: [
            {
              product_id: 'prod_rustflow',
              seats: 5,
              license_type: 'Commercial Developer'
            }
          ],
          user_email: 'tom@ahyx.org',
          user_id: 'usr_dev_01',
          organisation_id: 'org_northstar_eng',
          payment_method: paymentMethod
        })
      });

      const data = await res.json();
      if (data.success) {
        setCompletedOrder(data.order);
        setCompletedEntitlements(data.entitlements);
      } else {
        alert(data.error?.message || 'Checkout failed');
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#D1D5DB] font-mono text-xs flex flex-col">
      <Header
        cartCount={0}
        onOpenCart={() => {}}
        onOpenTerminal={() => {}}
        onOpenCopilot={() => {}}
        userRole="PROCUREMENT"
        setUserRole={() => {}}
      />

      <main className="max-w-4xl mx-auto px-4 py-8 flex-1 w-full">
        {completedOrder ? (
          /* Order Success Confirmation */
          <div className="bg-[#121214] border border-[#2D2D30] rounded p-6 space-y-6 shadow-2xl">
            <div className="text-center space-y-2">
              <div className="w-12 h-12 rounded-full bg-[#00FF80]/10 border border-[#00FF80]/30 flex items-center justify-center text-[#00FF80] mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h1 className="text-xl font-bold text-white">ORDER & ENTITLEMENT SUCCESS</h1>
              <p className="text-[#6B7280] text-xs">
                Order <strong className="text-[#00FF80]">{completedOrder.order_number}</strong> completed. Invoice <strong className="text-white">{completedOrder.invoice_number}</strong> issued.
              </p>
            </div>

            {/* Generated Entitlements */}
            <div className="space-y-3 pt-4 border-t border-[#2D2D30]">
              <h3 className="font-bold text-white uppercase tracking-wider text-xs">
                GENERATED SOFTWARE ENTITLEMENTS ({completedEntitlements.length})
              </h3>

              {completedEntitlements.map(ent => (
                <div key={ent.id} className="p-4 rounded bg-[#0A0A0B] border border-[#2D2D30] space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-[#00FF80] text-sm">{ent.product_name} v{ent.version}</span>
                    <span className="px-2 py-0.5 rounded bg-[#00FF80]/10 text-[#00FF80] text-[10px] font-bold border border-[#00FF80]/30">
                      ACTIVE ENTITLEMENT
                    </span>
                  </div>

                  <div className="flex items-center space-x-2 text-[#D1D5DB]">
                    <Key className="w-3.5 h-3.5 text-[#6B7280]" />
                    <span>License Key: <strong className="text-white">{ent.license_key}</strong></span>
                  </div>

                  <div className="text-[#6B7280] text-[11px]">
                    License Seats: {ent.seats_assigned} / {ent.seats_total} assigned to {ent.assigned_emails.join(', ')}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-4 flex justify-center space-x-4">
              <Link
                href="/library"
                className="px-6 py-2 rounded bg-[#00FF80] hover:bg-[#00E673] text-black font-bold transition shadow-[0_0_15px_rgba(0,255,128,0.2)]"
              >
                GO TO MY SOFTWARE LIBRARY
              </Link>
            </div>
          </div>
        ) : (
          /* Checkout Form */
          <div className="bg-[#121214] border border-[#2D2D30] rounded p-6 space-y-5 shadow-2xl">
            <div className="border-b border-[#2D2D30] pb-3">
              <h1 className="text-lg font-bold text-white flex items-center space-x-2">
                <CreditCard className="w-5 h-5 text-[#00FF80]" />
                <span>B2B COMMERCE CHECKOUT</span>
              </h1>
              <p className="text-[#6B7280] mt-1 text-[11px]">
                Simulated transaction mode with instant order generation & entitlement creation.
              </p>
            </div>

            <form onSubmit={handlePay} className="space-y-4">
              <div>
                <label className="text-[#6B7280] text-[10px] uppercase font-bold">Billing Organisation:</label>
                <input
                  type="text"
                  disabled
                  value="Northstar Engineering Ltd (London EC2A 1NT)"
                  className="w-full bg-[#0A0A0B] border border-[#2D2D30] rounded p-2 text-[#D1D5DB]"
                />
              </div>

              <div>
                <label className="text-[#6B7280] text-[10px] uppercase font-bold">Payment Method:</label>
                <select
                  value={paymentMethod}
                  onChange={e => setPaymentMethod(e.target.value)}
                  className="w-full bg-[#0A0A0B] border border-[#2D2D30] rounded p-2 text-[#D1D5DB] focus:outline-none focus:border-[#00FF80]"
                >
                  <option value="SANDBOX_CREDIT_CARD">Sandbox Visa Corporate (4242••••4242)</option>
                  <option value="CORPORATE_INVOICE_PO">Corporate Purchase Order (NET 30 Invoicing)</option>
                </select>
              </div>

              <div className="p-3 rounded bg-[#0A0A0B] border border-[#2D2D30] space-y-2">
                <div className="flex justify-between text-[#6B7280]">
                  <span>RustFlow Engine (5 Commercial Seats)</span>
                  <span className="text-white">£1,245.00</span>
                </div>
                <div className="flex justify-between text-[#6B7280]">
                  <span>20% VAT</span>
                  <span className="text-white">£249.00</span>
                </div>
                <div className="flex justify-between text-white font-bold border-t border-[#2D2D30] pt-2 text-sm">
                  <span>Total Payable:</span>
                  <span className="text-[#00FF80]">£1,494.00</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 rounded bg-[#00FF80] hover:bg-[#00E673] text-black font-bold transition text-xs flex items-center justify-center space-x-2 shadow-[0_0_15px_rgba(0,255,128,0.2)]"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{loading ? 'PROCESSING TRANSACTION...' : 'COMPLETE PURCHASE & CLAIM ENTITLEMENTS'}</span>
              </button>
            </form>
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}
