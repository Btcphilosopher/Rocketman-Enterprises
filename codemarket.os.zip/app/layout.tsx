import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'CODEMARKET.OS — Enterprise Software Commerce Platform',
  description: 'The marketplace for software that you can actually build with. Codebases, SDKs, APIs, plugins, developer tools, licensing & procurement.',
  openGraph: {
    title: 'CODEMARKET.OS — Enterprise Software Commerce Platform',
    description: 'The marketplace for software that you can actually build with. Codebases, SDKs, APIs, plugins, developer tools, licensing & procurement.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'CODEMARKET.OS — Enterprise Software Commerce Platform',
    description: 'The marketplace for software that you can actually build with. Codebases, SDKs, APIs, plugins, developer tools, licensing & procurement.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
