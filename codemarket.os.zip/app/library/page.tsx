'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { LicenseSeatManager } from '@/components/LicenseSeatManager';
import { CLITerminal } from '@/components/CLITerminal';
import { CopilotDrawer } from '@/components/CopilotDrawer';
import { Entitlement } from '@/lib/types';
import {
  BookOpen,
  Key,
  Download,
  Users,
  AlertTriangle,
  CheckCircle2,
  Terminal,
  ShieldCheck,
  RefreshCw,
  ExternalLink
} from 'lucide-react';

export default function LibraryPage() {
  const [entitlements, setEntitlements] = useState<Entitlement[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedEntitlement, setSelectedEntitlement] = useState<Entitlement | null>(null);
  const [terminalOpen, setTerminalOpen] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [userRole, setUserRole] = useState('PROCUREMENT');

  const fetchEntitlements = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/v1/checkout'); // or fetch directly from dbStore client/API
      // Fetch products or mock client entitlements
      const dbRes = await fetch('/api/v1/products');
      const dbData = await dbRes.json();
      
      // Default entitlements for demonstration
      setEntitlements([
        {
          id: 'ent_9021',
          user_id: 'usr_dev_01',
          organisation_id: 'org_northstar_eng',
          product_id: 'prod_rustflow',
          product_name: 'RustFlow Engine',
          product_slug: 'rustflow-engine',
          release_id: 'rel_rustflow_342',
          version: '3.4.2',
          latest_version: '3.4.2',
          license_type: 'Commercial Developer',
          seats_total: 5,
          seats_assigned: 4,
          assigned_emails: ['tom@ahyx.org', 'dev1@northstar.io', 'dev2@northstar.io', 'dev3@northstar.io'],
          status: 'ACTIVE',
          purchased_at: '2026-08-29',
          license_key: 'CM-LIC-RF-342-99812-NSTAR',
          download_token: 'dl_tok_8812938129381',
          update_available: false
        },
        {
          id: 'ent_9022',
          user_id: 'usr_dev_01',
          organisation_id: 'org_northstar_eng',
          product_id: 'prod_aardvark_ui',
          product_name: 'Aardvark Enterprise UI Kit',
          product_slug: 'aardvark-enterprise-ui',
          release_id: 'rel_aardvark_421',
          version: '4.2.1',
          latest_version: '4.2.1',
          license_type: 'Commercial Developer',
          seats_total: 10,
          seats_assigned: 8,
          assigned_emails: ['tom@ahyx.org', 'frontend.lead@northstar.io'],
          status: 'ACTIVE',
          purchased_at: '2026-07-12',
          license_key: 'CM-LIC-AARD-421-12983-UI',
          download_token: 'dl_tok_7721381231',
          update_available: false
        }
      ]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEntitlements();
  }, []);

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-[#D1D5DB] font-mono text-xs flex flex-col">
      <Header
        cartCount={0}
        onOpenCart={() => (window.location.href = '/cart')}
        onOpenTerminal={() => setTerminalOpen(true)}
        onOpenCopilot={() => setCopilotOpen(true)}
        userRole={userRole}
        setUserRole={setUserRole}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full">
        <div className="mb-6 pb-3 border-b border-[#2D2D30] flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div>
            <h1 className="text-lg font-bold text-white flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-[#00FF80]" />
              <span>MY SOFTWARE LIBRARY & ENTITLEMENT REGISTER</span>
            </h1>
            <p className="text-[#6B7280] mt-0.5 text-[11px]">
              Active organization licenses, seat allocations, signed archive downloads, and version updates.
            </p>
          </div>

          <button
            onClick={() => setTerminalOpen(true)}
            className="px-3 py-1.5 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-white transition flex items-center space-x-2 shrink-0"
          >
            <Terminal className="w-3.5 h-3.5 text-[#00FF80]" />
            <span>codemarket library</span>
          </button>
        </div>

        {loading ? (
          <div className="p-12 text-center text-[#6B7280]">Loading active entitlements...</div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Entitlements Cards List */}
            <div className="lg:col-span-2 space-y-3">
              {entitlements.map(ent => (
                <div
                  key={ent.id}
                  className={`bg-[#121214] border rounded p-4 space-y-3 transition ${
                    selectedEntitlement?.id === ent.id
                      ? 'border-[#00FF80] bg-[#121214]'
                      : 'border-[#2D2D30] hover:border-[#4B5563]'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#2D2D30] pb-2.5">
                    <div>
                      <h3 className="font-bold text-white text-sm flex items-center space-x-2">
                        <span>{ent.product_name}</span>
                        <span className="text-[#00FF80] text-xs">v{ent.version}</span>
                      </h3>
                      <div className="text-[#6B7280] text-[11px] mt-0.5">
                        License Type: <span className="text-white">{ent.license_type}</span>
                      </div>
                    </div>

                    <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] bg-[#00FF80]/10 text-[#00FF80] border border-[#00FF80]/30 font-bold self-start sm:self-center">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      ACTIVE ENTITLEMENT
                    </span>
                  </div>

                  {/* License Key & Seats Details */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-2.5 rounded bg-[#0A0A0B] border border-[#2D2D30]">
                    <div>
                      <div className="text-[10px] text-[#6B7280] uppercase">License Key</div>
                      <div className="text-white font-bold font-mono truncate">{ent.license_key}</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-[#6B7280] uppercase">Seat Capacity</div>
                      <div className="text-[#00FF80] font-bold">
                        {ent.seats_assigned} / {ent.seats_total} Seats Assigned
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <button
                      onClick={() => setSelectedEntitlement(ent)}
                      className="px-3 py-1 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-white font-semibold transition flex items-center space-x-1"
                    >
                      <Users className="w-3.5 h-3.5 text-[#00FF80]" />
                      <span>Manage Seat Pool ({ent.seats_assigned}/{ent.seats_total})</span>
                    </button>

                    <a
                      href={`/api/v1/products/${ent.product_id}/download`}
                      download
                      className="px-3 py-1 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition flex items-center space-x-1"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download Archive (SHA-256)</span>
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* Right Column: Interactive Seat Allocator Panel */}
            <div className="lg:col-span-1">
              {selectedEntitlement ? (
                <LicenseSeatManager
                  entitlement={selectedEntitlement}
                  onRefresh={fetchEntitlements}
                />
              ) : (
                <div className="bg-[#121214] border border-[#2D2D30] rounded p-6 text-center space-y-3">
                  <Users className="w-8 h-8 text-[#00FF80] mx-auto" />
                  <p className="font-bold text-white">Select an Entitlement</p>
                  <p className="text-[#6B7280] text-xs">
                    Click &quot;Manage Seat Pool&quot; on any product to assign or revoke engineer license seats.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      <Footer />
      <CLITerminal isOpen={terminalOpen} onClose={() => setTerminalOpen(false)} />
      <CopilotDrawer isOpen={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}
