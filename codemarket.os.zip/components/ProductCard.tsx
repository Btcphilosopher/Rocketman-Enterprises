'use client';

import React from 'react';
import Link from 'next/link';
import { DigitalProduct } from '@/lib/types';
import { formatPrice, getSecurityBadgeColor } from '@/lib/utils';
import { ShieldCheck, Star, Download, Cpu, Code2, ArrowRight } from 'lucide-react';

interface ProductCardProps {
  product: DigitalProduct;
  onAddToCart?: (product: DigitalProduct) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <div className="group bg-[#121214] border border-[#2D2D30] hover:border-[#00FF80]/50 rounded p-4 transition-all duration-200 flex flex-col justify-between hover:shadow-[0_0_15px_rgba(0,255,128,0.05)] relative">
      <div>
        {/* Top Header: Badge, Product Type, Version */}
        <div className="flex items-center justify-between mb-2 text-xs font-mono">
          <div className="flex items-center space-x-1.5">
            <span className="px-1.5 py-0.5 rounded bg-[#1A1A1C] border border-[#2D2D30] text-slate-300 font-semibold uppercase text-[9px] tracking-wide">
              {product.product_type}
            </span>
            <span className="text-[#6B7280] text-[10px] font-bold">
              v{product.version}
            </span>
          </div>

          <span
            className="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-mono border bg-[#00FF80]/10 text-[#00FF80] border-[#00FF80]/20 font-bold"
          >
            <ShieldCheck className="w-3 h-3 mr-1 text-[#00FF80]" />
            {product.vendor_verified ? 'VERIFIED' : 'SCAN OK'}
          </span>
        </div>

        {/* Product Title & Vendor */}
        <Link href={`/products/${product.slug}`} className="block group-hover:text-[#00FF80] transition">
          <h3 className="text-sm font-bold text-white mb-1 line-clamp-1 font-mono tracking-tight">
            {product.name}
          </h3>
        </Link>

        <div className="text-[11px] text-[#6B7280] font-mono mb-2 flex items-center space-x-1">
          <span>by</span>
          <span className="text-[#94A3B8] font-medium">{product.vendor_name}</span>
          {product.vendor_verified && (
            <span className="text-[#00FF80] text-[10px]" title="Verified Vendor">✓</span>
          )}
        </div>

        {/* Short Description */}
        <p className="text-[11px] text-[#94A3B8] mb-3 line-clamp-2 leading-relaxed">
          {product.short_description}
        </p>

        {/* Technical Specs & Metrics */}
        <div className="grid grid-cols-2 gap-2 mb-3 p-2 rounded bg-[#0A0A0B] border border-[#2D2D30] text-[10px] font-mono">
          <div>
            <div className="text-[#6B7280] text-[9px] uppercase tracking-wider">Languages</div>
            <div className="text-white truncate">{product.languages.join(', ')}</div>
          </div>
          <div>
            <div className="text-[#6B7280] text-[9px] uppercase tracking-wider">License</div>
            <div className="text-white truncate">{product.license_type}</div>
          </div>
          <div>
            <div className="text-[#6B7280] text-[9px] uppercase tracking-wider">Rating</div>
            <div className="text-amber-400 flex items-center">
              <Star className="w-2.5 h-2.5 fill-amber-400 mr-1" />
              {product.rating.toFixed(1)} <span className="text-[#6B7280] ml-1">({product.review_count})</span>
            </div>
          </div>
          <div>
            <div className="text-[#6B7280] text-[9px] uppercase tracking-wider">Downloads</div>
            <div className="text-white flex items-center">
              <Download className="w-2.5 h-2.5 text-[#6B7280] mr-1" />
              {product.download_count.toLocaleString()}
            </div>
          </div>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1 mb-3">
          {product.tags.slice(0, 3).map(tag => (
            <span
              key={tag}
              className="px-1.5 py-0.5 rounded bg-[#1A1A1C] text-[#94A3B8] font-mono text-[9px] border border-[#2D2D30]"
            >
              #{tag}
            </span>
          ))}
        </div>
      </div>

      {/* Footer: Price & Add to Cart / View */}
      <div className="pt-2 border-t border-[#2D2D30] flex items-center justify-between font-mono">
        <div>
          <div className="text-[9px] text-[#6B7280] uppercase tracking-wider font-bold">PER SEAT</div>
          <div className="text-xs font-bold text-white">
            {formatPrice(product.price, product.currency)}
          </div>
        </div>

        <div className="flex items-center space-x-1.5">
          {onAddToCart && (
            <button
              onClick={() => onAddToCart(product)}
              className="px-2.5 py-1 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] text-[11px] transition shadow-[0_0_10px_rgba(0,255,128,0.15)]"
            >
              + CART
            </button>
          )}

          <Link
            href={`/products/${product.slug}`}
            className="p-1 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] text-white transition"
          >
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
