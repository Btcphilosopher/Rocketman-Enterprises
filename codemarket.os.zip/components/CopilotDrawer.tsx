'use client';

import React, { useState } from 'react';
import { Sparkles, X, Send, Bot, User, Code2 } from 'lucide-react';

interface CopilotDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CopilotDrawer({ isOpen, onClose }: CopilotDrawerProps) {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string }>>([
    {
      sender: 'bot',
      text: 'Hello! I am CODEMARKET Copilot, powered by Gemini 3.5. Ask me technical questions about codebases, dependencies, licensing, or runtime compatibility in our catalog.'
    }
  ]);

  if (!isOpen) return null;

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim() || loading) return;

    const userText = query.trim();
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setQuery('');
    setLoading(true);

    try {
      const res = await fetch('/api/v1/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userText })
      });
      const data = await res.json();
      setMessages(prev => [
        ...prev,
        { sender: 'bot', text: data.response || 'No response available.' }
      ]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        { sender: 'bot', text: `Copilot error: ${err.message}` }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[480px] bg-[#0A0A0B] border-l border-[#2D2D30] shadow-2xl flex flex-col font-mono text-xs">
      {/* Header */}
      <div className="bg-[#121214] border-b border-[#2D2D30] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="w-7 h-7 rounded bg-[#00FF80]/10 border border-[#00FF80]/30 flex items-center justify-center text-[#00FF80]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-white uppercase tracking-wider text-xs">
              CODEMARKET COPILOT
            </h3>
            <div className="text-[10px] text-[#6B7280]">GEMINI 3.5 FLASH AI ARCHITECT</div>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 text-[#6B7280] hover:text-white rounded hover:bg-[#1A1A1C] transition"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Preset Query Chips */}
      <div className="bg-[#121214] border-b border-[#2D2D30] p-2.5 space-y-1">
        <div className="text-[10px] text-[#6B7280] uppercase font-bold">Suggested AI Queries:</div>
        <div className="flex flex-wrap gap-1.5">
          {[
            'Compare RustFlow vs PostgreSQL Engine',
            'Which UI kit supports React 19?',
            'What is the license for AeroSim CFD?'
          ].map(q => (
            <button
              key={q}
              onClick={() => {
                setQuery(q);
              }}
              className="text-[10px] bg-[#1A1A1C] hover:bg-[#2D2D30] text-[#00FF80] border border-[#2D2D30] px-2 py-0.5 rounded text-left transition"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3">
        {messages.map((m, idx) => (
          <div
            key={idx}
            className={`flex items-start space-x-2.5 ${
              m.sender === 'user' ? 'justify-end' : 'justify-start'
            }`}
          >
            {m.sender === 'bot' && (
              <div className="w-6 h-6 rounded bg-[#00FF80]/10 border border-[#00FF80]/30 flex items-center justify-center text-[#00FF80] shrink-0 mt-0.5">
                <Bot className="w-3.5 h-3.5" />
              </div>
            )}
            <div
              className={`p-3 rounded leading-relaxed max-w-[85%] whitespace-pre-wrap text-xs ${
                m.sender === 'user'
                  ? 'bg-[#00FF80]/10 text-white border border-[#00FF80]/30'
                  : 'bg-[#121214] text-[#D1D5DB] border border-[#2D2D30]'
              }`}
            >
              {m.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center space-x-2 text-[#6B7280] animate-pulse">
            <Bot className="w-4 h-4 text-[#00FF80]" />
            <span>Analyzing software catalog...</span>
          </div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="bg-[#121214] border-t border-[#2D2D30] p-2.5 flex gap-2">
        <input
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Ask Copilot about software..."
          className="flex-1 bg-[#0A0A0B] border border-[#2D2D30] rounded px-3 py-1.5 text-xs text-white placeholder-[#6B7280] focus:outline-none focus:border-[#00FF80]"
        />
        <button
          type="submit"
          disabled={loading || !query.trim()}
          className="px-3 py-1.5 rounded bg-[#00FF80] text-black font-bold disabled:opacity-50 transition"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>
    </div>
  );
}
