'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Code2,
  Search,
  ShoppingBag,
  Terminal,
  Sparkles,
  Building2,
  BookOpen,
  Store,
  SlidersHorizontal,
  ShieldCheck,
  ChevronDown,
  UserCheck
} from 'lucide-react';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenTerminal: () => void;
  onOpenCopilot: () => void;
  userRole: string;
  setUserRole: (role: string) => void;
}

export function Header({
  cartCount,
  onOpenCart,
  onOpenTerminal,
  onOpenCopilot,
  userRole,
  setUserRole
}: HeaderProps) {
  const pathname = usePathname();
  const [searchQuery, setSearchQuery] = useState('');
  const [roleDropdown, setRoleDropdown] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#121214] border-b border-[#2D2D30]">
      {/* Top B2B Status Bar */}
      <div className="bg-[#0E0E10] border-b border-[#2D2D30] py-1 px-4 text-xs font-mono text-[#94A3B8] flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <span className="flex items-center text-[#00FF80]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#00FF80] animate-pulse mr-1.5" />
            CODEMARKET.OS LIVE — v3.7.0
          </span>
          <span className="hidden md:inline text-[#4B5563]">|</span>
          <span className="hidden md:inline">
            ORGANISATION: <strong className="text-white">Northstar Engineering Ltd</strong>
          </span>
          <span className="hidden lg:inline text-[#4B5563]">|</span>
          <span className="hidden lg:inline">
            BUDGET REMAINING: <strong className="text-[#00FF80]">£107,000.00</strong>
          </span>
        </div>
        <div className="flex items-center space-x-3">
          {/* Role Switcher */}
          <div className="relative">
            <button
              onClick={() => setRoleDropdown(!roleDropdown)}
              className="flex items-center space-x-1.5 px-2 py-0.5 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:bg-[#2D2D30] transition text-slate-200"
            >
              <UserCheck className="w-3 h-3 text-[#00FF80]" />
              <span>ROLE: <strong className="text-[#00FF80]">{userRole}</strong></span>
              <ChevronDown className="w-3 h-3 text-[#6B7280]" />
            </button>

            {roleDropdown && (
              <div className="absolute right-0 mt-1 w-52 bg-[#121214] border border-[#2D2D30] rounded shadow-2xl py-1 z-50 text-xs font-mono">
                <div className="px-3 py-1 text-[10px] text-[#6B7280] uppercase font-semibold">Switch Persona Context</div>
                {[
                  { role: 'PROCUREMENT', label: 'Procurement Officer' },
                  { role: 'DEVELOPER', label: 'Staff Software Engineer' },
                  { role: 'VENDOR', label: 'Vendor / Publisher' },
                  { role: 'ADMIN', label: 'Enterprise Admin' }
                ].map(r => (
                  <button
                    key={r.role}
                    onClick={() => {
                      setUserRole(r.role);
                      setRoleDropdown(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-[#1E1E20] transition flex items-center justify-between ${
                      userRole === r.role ? 'text-[#00FF80] font-bold bg-[#1E1E20]' : 'text-slate-300'
                    }`}
                  >
                    <span>{r.label}</span>
                    {userRole === r.role && <span className="text-[10px] text-[#00FF80]">ACTIVE</span>}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between gap-4">
        {/* Brand Logo */}
        <Link href="/" className="flex items-center space-x-2.5 group shrink-0">
          <div className="w-8 h-8 rounded bg-[#1E1E20] border border-[#2D2D30] flex items-center justify-center text-[#00FF80] group-hover:border-[#00FF80] transition">
            <Code2 className="w-4 h-4" />
          </div>
          <div>
            <div className="font-mono font-bold text-base tracking-tighter text-white transition flex items-center">
              CODEMARKET<span className="text-[#00FF80]">.OS</span>
            </div>
            <div className="text-[9px] font-mono text-[#6B7280] tracking-widest uppercase">ENTERPRISE SOFTWARE</div>
          </div>
        </Link>

        {/* Global Search Bar */}
        <div className="hidden md:flex flex-1 max-w-md relative">
          <form
            onSubmit={e => {
              e.preventDefault();
              if (searchQuery.trim()) {
                window.location.href = `/products?q=${encodeURIComponent(searchQuery)}`;
              }
            }}
            className="w-full relative"
          >
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-[#4B5563]" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search codebase, SDK, API, Rust, C++..."
              className="w-full bg-[#1E1E20] border border-[#2D2D30] text-xs font-mono text-white rounded-md py-1.5 pl-9 pr-12 focus:outline-none focus:border-[#00FF80] transition placeholder-[#6B7280]"
            />
            <span className="absolute right-2.5 top-2 text-[10px] font-mono text-[#6B7280] border border-[#2D2D30] px-1 rounded bg-[#0A0A0B]">
              /
            </span>
          </form>
        </div>

        {/* Nav Links */}
        <nav className="hidden lg:flex items-center space-x-6 font-mono text-xs uppercase tracking-widest text-[#94A3B8]">
          {[
            { href: '/products', label: 'EXPLORE', icon: SlidersHorizontal },
            { href: '/library', label: 'INVENTORY', icon: BookOpen },
            { href: '/enterprise', label: 'PROCUREMENT', icon: Building2 },
            { href: '/vendor', label: 'VENDOR.OS', icon: Store }
          ].map(item => {
            const isActive = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`py-1 transition flex items-center space-x-1.5 border-b-2 ${
                  isActive
                    ? 'text-white border-[#00FF80] font-semibold'
                    : 'border-transparent hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Quick Action Tools */}
        <div className="flex items-center space-x-2">
          {/* CLI Terminal Button */}
          <button
            onClick={onOpenTerminal}
            className="p-1.5 rounded bg-[#1A1A1C] border border-[#2D2D30] hover:border-[#00FF80]/50 text-slate-300 hover:text-[#00FF80] transition relative group"
            title="Open CODEMARKET CLI Terminal"
          >
            <Terminal className="w-4 h-4" />
          </button>

          {/* AI Copilot Button */}
          <button
            onClick={onOpenCopilot}
            className="px-2.5 py-1 rounded bg-[#00FF80]/10 border border-[#00FF80]/20 hover:bg-[#00FF80]/20 text-[#00FF80] transition flex items-center space-x-1 font-mono text-xs font-semibold"
            title="Ask AI Copilot"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#00FF80]" />
            <span className="hidden sm:inline">COPILOT</span>
          </button>

          {/* Cart Button */}
          <button
            onClick={onOpenCart}
            className="px-3 py-1 rounded bg-[#00FF80] text-black font-bold hover:bg-[#00E673] transition flex items-center space-x-1.5 font-mono text-xs shadow-[0_0_15px_rgba(0,255,128,0.15)]"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>CART</span>
            {cartCount > 0 && (
              <span className="ml-1 px-1.5 py-0.2 bg-black text-[#00FF80] font-bold rounded text-[10px]">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
