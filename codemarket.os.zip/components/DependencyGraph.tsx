'use client';

import React from 'react';
import { DependencyItem } from '@/lib/types';
import { GitFork, ShieldCheck, AlertTriangle, Layers } from 'lucide-react';

interface DependencyGraphProps {
  dependencies: DependencyItem[];
}

export function DependencyGraph({ dependencies }: DependencyGraphProps) {
  if (!dependencies || dependencies.length === 0) {
    return (
      <div className="p-4 bg-[#12151e] border border-[#232838] rounded-lg text-xs font-mono text-slate-500 text-center">
        Zero external dependencies. Standalone package.
      </div>
    );
  }

  return (
    <div className="bg-[#12151e] border border-[#232838] rounded-lg p-5 font-mono">
      <div className="flex items-center justify-between mb-4 border-b border-[#232838] pb-3">
        <div className="flex items-center space-x-2">
          <GitFork className="w-4 h-4 text-sky-400" />
          <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            DEPENDENCY TREE & VULNERABILITY MATRIX
          </h4>
        </div>
        <span className="text-[10px] text-slate-400 bg-[#1a1e2b] px-2 py-0.5 rounded border border-[#232838]">
          {dependencies.length} Packages Verified
        </span>
      </div>

      <div className="space-y-2">
        {dependencies.map((dep, idx) => (
          <div
            key={dep.name + idx}
            className="flex items-center justify-between p-3 rounded bg-[#0a0c10] border border-[#1f2434] hover:border-slate-700 transition text-xs"
          >
            <div className="flex items-center space-x-3">
              <Layers className="w-3.5 h-3.5 text-slate-500" />
              <div>
                <div className="font-bold text-slate-200 flex items-center space-x-2">
                  <span>{dep.name}</span>
                  <span className="text-[10px] text-sky-400 bg-sky-950/60 border border-sky-800/40 px-1.5 py-0.2 rounded">
                    v{dep.version}
                  </span>
                  {dep.isTransitive && (
                    <span className="text-[9px] text-slate-400 bg-slate-900 border border-slate-700 px-1 py-0.2 rounded">
                      TRANSITIVE
                    </span>
                  )}
                </div>
                <div className="text-[10px] text-slate-500">License: {dep.license}</div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              {dep.vulnerabilities && dep.vulnerabilities > 0 ? (
                <span className="inline-flex items-center text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded">
                  <AlertTriangle className="w-3 h-3 mr-1" />
                  {dep.vulnerabilities} Advisory
                </span>
              ) : (
                <span className="inline-flex items-center text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                  <ShieldCheck className="w-3 h-3 mr-1" />
                  0 Vulnerabilities
                </span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
