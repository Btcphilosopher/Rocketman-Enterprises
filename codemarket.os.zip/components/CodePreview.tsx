'use client';

import React, { useState } from 'react';
import { CodeFile } from '@/lib/types';
import { FileCode, Copy, Check, Search, Terminal, FileText } from 'lucide-react';

interface CodePreviewProps {
  files: CodeFile[];
  title?: string;
}

export function CodePreview({ files, title = 'SOFTWARE SOURCE EXPLORER' }: CodePreviewProps) {
  const [activeFileIndex, setActiveFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [searchFilter, setSearchFilter] = useState('');

  if (!files || files.length === 0) {
    return (
      <div className="p-6 bg-[#0a0c10] border border-[#232838] rounded-lg font-mono text-xs text-slate-500 text-center">
        No code files provided for preview.
      </div>
    );
  }

  const activeFile = files[activeFileIndex] || files[0];

  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredFiles = files.filter(f =>
    f.path.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="bg-[#0a0c10] border border-[#232838] rounded-lg overflow-hidden font-mono text-xs shadow-2xl">
      {/* IDE Header */}
      <div className="bg-[#12151e] border-b border-[#232838] px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <div className="flex space-x-1.5 mr-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
          </div>
          <Terminal className="w-3.5 h-3.5 text-sky-400" />
          <span className="text-slate-300 font-bold uppercase tracking-wider text-[11px]">
            {title}
          </span>
        </div>

        <div className="flex items-center space-x-3">
          <span className="text-slate-500 text-[10px]">
            {files.length} file(s) | {activeFile.language.toUpperCase()}
          </span>

          <button
            onClick={handleCopy}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#1a1e2b] border border-[#232838] hover:bg-[#232838] text-slate-300 hover:text-slate-100 transition"
          >
            {copied ? (
              <>
                <Check className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-400">Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-3 h-3 text-slate-400" />
                <span>Copy File</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main IDE Layout: Left File Tree Sidebar, Right Editor Content */}
      <div className="grid grid-cols-1 md:grid-cols-4 min-h-[360px]">
        {/* Left File Tree Sidebar */}
        <div className="md:col-span-1 bg-[#0d0f15] border-r border-[#1f2434] p-3 space-y-2">
          <div className="relative mb-2">
            <Search className="w-3 h-3 absolute left-2.5 top-2 text-slate-500" />
            <input
              type="text"
              placeholder="Filter files..."
              value={searchFilter}
              onChange={e => setSearchFilter(e.target.value)}
              className="w-full bg-[#12151e] border border-[#232838] rounded px-2 pl-7 py-1 text-[11px] text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500/40"
            />
          </div>

          <div className="space-y-1 overflow-y-auto max-h-[300px]">
            {filteredFiles.map((file, idx) => {
              const originalIndex = files.findIndex(f => f.path === file.path);
              const isActive = originalIndex === activeFileIndex;

              return (
                <button
                  key={file.path}
                  onClick={() => setActiveFileIndex(originalIndex)}
                  className={`w-full text-left px-2.5 py-1.5 rounded flex items-center space-x-2 transition ${
                    isActive
                      ? 'bg-sky-500/10 text-sky-400 border border-sky-500/30 font-bold'
                      : 'text-slate-400 hover:bg-[#12151e] hover:text-slate-200'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                  <span className="truncate text-[11px]">{file.path}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Editor Area */}
        <div className="md:col-span-3 bg-[#0a0c10] p-4 overflow-x-auto relative">
          <div className="text-[10px] text-slate-500 mb-2 font-mono pb-2 border-b border-[#1f2434] flex justify-between items-center">
            <span>FILE: <strong className="text-sky-300">{activeFile.path}</strong></span>
            <span>LINES: {activeFile.content.split('\n').length}</span>
          </div>

          <pre className="text-slate-200 leading-relaxed overflow-x-auto font-mono text-[11px]">
            <code>
              {activeFile.content.split('\n').map((line, i) => (
                <div key={i} className="table-row">
                  <span className="table-cell text-right pr-4 select-none text-slate-600 w-8">
                    {i + 1}
                  </span>
                  <span className="table-cell whitespace-pre">{line}</span>
                </div>
              ))}
            </code>
          </pre>
        </div>
      </div>
    </div>
  );
}
