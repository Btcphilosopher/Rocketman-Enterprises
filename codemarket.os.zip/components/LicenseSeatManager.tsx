'use client';

import React, { useState } from 'react';
import { Entitlement } from '@/lib/types';
import { Users, UserPlus, Trash2, Key, CheckCircle, AlertCircle } from 'lucide-react';

interface LicenseSeatManagerProps {
  entitlement: Entitlement;
  onRefresh?: () => void;
}

export function LicenseSeatManager({ entitlement, onRefresh }: LicenseSeatManagerProps) {
  const [newEmail, setNewEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleAssign = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim()) return;

    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/v1/licensing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'ASSIGN',
          entitlement_id: entitlement.id,
          email: newEmail.trim()
        })
      });

      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: `Assigned license seat to ${newEmail}` });
        setNewEmail('');
        if (onRefresh) onRefresh();
      } else {
        setMessage({ type: 'error', text: data.error?.message || 'Failed to assign seat' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  const handleRevoke = async (email: string) => {
    if (!confirm(`Revoke license seat for ${email}?`)) return;

    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch('/api/v1/licensing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'REVOKE',
          entitlement_id: entitlement.id,
          email
        })
      });

      const data = await res.json();
      if (data.success) {
        setMessage({ type: 'success', text: `Revoked seat for ${email}` });
        if (onRefresh) onRefresh();
      } else {
        setMessage({ type: 'error', text: data.error?.message || 'Failed to revoke seat' });
      }
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#121214] border border-[#2D2D30] rounded p-4 font-mono text-xs">
      {/* Header */}
      <div className="flex items-center justify-between pb-2.5 border-b border-[#2D2D30] mb-3">
        <div className="flex items-center space-x-2">
          <Key className="w-4 h-4 text-[#00FF80]" />
          <h4 className="font-bold text-white uppercase tracking-wider text-[11px]">
            LICENSE SEAT POOL MANAGER
          </h4>
        </div>
        <span className="text-[#00FF80] font-bold bg-[#00FF80]/10 border border-[#00FF80]/30 px-2 py-0.5 rounded text-[10px]">
          {entitlement.seats_assigned} / {entitlement.seats_total} SEATS ASSIGNED
        </span>
      </div>

      {message && (
        <div
          className={`p-2.5 rounded mb-3 flex items-center space-x-2 text-xs ${
            message.type === 'success'
              ? 'bg-[#00FF80]/10 text-[#00FF80] border border-[#00FF80]/30'
              : 'bg-red-500/10 text-red-400 border border-red-500/30'
          }`}
        >
          {message.type === 'success' ? (
            <CheckCircle className="w-4 h-4 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 shrink-0" />
          )}
          <span>{message.text}</span>
        </div>
      )}

      {/* Assign New Seat Form */}
      <form onSubmit={handleAssign} className="mb-4 flex gap-2">
        <input
          type="email"
          placeholder="engineer@company.com"
          value={newEmail}
          onChange={e => setNewEmail(e.target.value)}
          className="flex-1 bg-[#0A0A0B] border border-[#2D2D30] rounded px-2.5 py-1.5 text-white placeholder-[#6B7280] focus:outline-none focus:border-[#00FF80]"
        />
        <button
          type="submit"
          disabled={loading || entitlement.seats_assigned >= entitlement.seats_total}
          className="px-3 py-1.5 rounded bg-[#00FF80] text-black font-bold disabled:opacity-50 transition flex items-center space-x-1 shrink-0"
        >
          <UserPlus className="w-3.5 h-3.5" />
          <span>Assign Seat</span>
        </button>
      </form>

      {/* Assigned Users List */}
      <div className="space-y-1.5">
        <div className="text-[10px] text-[#6B7280] uppercase font-semibold mb-1">
          Currently Assigned Engineers ({entitlement.assigned_emails.length})
        </div>
        {entitlement.assigned_emails.map(email => (
          <div
            key={email}
            className="flex items-center justify-between p-2 rounded bg-[#0A0A0B] border border-[#2D2D30]"
          >
            <div className="flex items-center space-x-2 text-white">
              <Users className="w-3.5 h-3.5 text-[#6B7280]" />
              <span>{email}</span>
            </div>
            <button
              onClick={() => handleRevoke(email)}
              disabled={loading}
              className="p-1 text-[#6B7280] hover:text-red-400 hover:bg-red-500/10 rounded transition"
              title="Revoke Seat"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
