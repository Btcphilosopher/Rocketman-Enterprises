'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, X, Send, Play, HelpCircle } from 'lucide-react';

interface CLITerminalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CLITerminal({ isOpen, onClose }: CLITerminalProps) {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<Array<{ cmd: string; output: string }>>([
    {
      cmd: 'codemarket help',
      output: `CODEMARKET.OS CLI v1.4.0 — B2B Software Package Manager
Type 'codemarket search "rust"' to discover software.
Type 'codemarket inspect rustflow-engine' to inspect specifications.
Type 'codemarket library' to view organization entitlements.`
    }
  ]);
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [isOpen, history]);

  if (!isOpen) return null;

  const handleRun = async (cmdToRun?: string) => {
    const cmd = cmdToRun || input;
    if (!cmd.trim()) return;

    setLoading(true);
    setInput('');

    try {
      const res = await fetch('/api/v1/cli', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd })
      });
      const data = await res.json();
      setHistory(prev => [...prev, { cmd, output: data.output || 'Command executed.' }]);
    } catch (err: any) {
      setHistory(prev => [...prev, { cmd, output: `CLI Execution Error: ${err.message}` }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-[#0A0A0B] border border-[#2D2D30] rounded overflow-hidden shadow-2xl font-mono text-xs flex flex-col h-[520px]">
        {/* Terminal Header */}
        <div className="bg-[#121214] border-b border-[#2D2D30] px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TerminalIcon className="w-4 h-4 text-[#00FF80]" />
            <span className="font-bold text-white uppercase tracking-wider text-xs">
              CODEMARKET.OS TERMINAL CLI
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-[#6B7280] hover:text-white rounded hover:bg-[#1A1A1C] transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Preset Quick Commands */}
        <div className="bg-[#121214] border-b border-[#2D2D30] px-4 py-1.5 flex items-center space-x-2 overflow-x-auto text-[10px]">
          <span className="text-[#6B7280] font-bold uppercase shrink-0">QUICK:</span>
          {[
            'codemarket search "rust"',
            'codemarket inspect rustflow-engine',
            'codemarket library',
            'codemarket download rustflow-engine',
            'codemarket install rustflow-engine'
          ].map(c => (
            <button
              key={c}
              onClick={() => handleRun(c)}
              className="px-2 py-0.5 rounded bg-[#1A1A1C] text-[#00FF80] hover:bg-[#2D2D30] border border-[#2D2D30] shrink-0 transition"
            >
              {c}
            </button>
          ))}
        </div>

        {/* Terminal Output Stream */}
        <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#0A0A0B]">
          {history.map((item, idx) => (
            <div key={idx} className="space-y-1">
              <div className="flex items-center space-x-2 font-bold">
                <span className="text-[#00FF80]">user@northstar:~$</span>
                <span className="text-white">{item.cmd}</span>
              </div>
              <pre className="text-[#D1D5DB] leading-relaxed whitespace-pre-wrap pl-4 border-l-2 border-[#2D2D30]">
                {item.output}
              </pre>
            </div>
          ))}
          {loading && (
            <div className="text-[#6B7280] animate-pulse flex items-center space-x-2">
              <span className="w-2 h-2 rounded-full bg-[#00FF80] animate-ping" />
              <span>Executing CLI binary...</span>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Terminal Input Box */}
        <form
          onSubmit={e => {
            e.preventDefault();
            handleRun();
          }}
          className="bg-[#121214] border-t border-[#2D2D30] p-2.5 flex items-center space-x-2"
        >
          <span className="text-[#00FF80] font-bold shrink-0">$</span>
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="codemarket search <query>..."
            className="flex-1 bg-transparent text-white placeholder-[#6B7280] focus:outline-none text-xs font-mono"
            autoFocus
          />
          <button
            type="submit"
            disabled={loading}
            className="px-3 py-1 rounded bg-[#00FF80] text-black font-bold text-xs transition hover:bg-[#00E673]"
          >
            EXEC
          </button>
        </form>
      </div>
    </div>
  );
}
