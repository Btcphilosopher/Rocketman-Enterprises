'use client';

import React from 'react';
import { CompatibilityItem } from '@/lib/types';
import { Cpu, CheckCircle2, XCircle, Globe, Server } from 'lucide-react';

interface CompatibilityMatrixProps {
  compatibility: CompatibilityItem[];
}

export function CompatibilityMatrix({ compatibility }: CompatibilityMatrixProps) {
  if (!compatibility || compatibility.length === 0) {
    return (
      <div className="p-4 bg-[#12151e] border border-[#232838] rounded-lg text-xs font-mono text-slate-500 text-center">
        Universal compatibility specification.
      </div>
    );
  }

  return (
    <div className="bg-[#12151e] border border-[#232838] rounded-lg p-5 font-mono text-xs">
      <div className="flex items-center space-x-2 mb-4 border-b border-[#232838] pb-3">
        <Cpu className="w-4 h-4 text-sky-400" />
        <h4 className="font-bold text-slate-200 uppercase tracking-wider">
          SOFTWARE COMPATIBILITY MATRIX
        </h4>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-[#232838] text-[10px] text-slate-500 uppercase">
              <th className="pb-2">Target Runtime</th>
              <th className="pb-2">Supported Versions</th>
              <th className="pb-2">Operating Systems</th>
              <th className="pb-2">Architectures</th>
              <th className="pb-2 text-right">Verification</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1f2434]">
            {compatibility.map((item, idx) => (
              <tr key={idx} className="hover:bg-[#1a1e2b]/50 transition">
                <td className="py-2.5 font-bold text-slate-200">{item.runtime}</td>
                <td className="py-2.5 text-sky-400">{item.versions.join(', ')}</td>
                <td className="py-2.5 text-slate-300">{item.os.join(', ')}</td>
                <td className="py-2.5 text-slate-400">{item.architectures.join(', ')}</td>
                <td className="py-2.5 text-right">
                  {item.tested ? (
                    <span className="inline-flex items-center text-[10px] text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 rounded">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      TESTED PASS
                    </span>
                  ) : (
                    <span className="inline-flex items-center text-[10px] text-slate-500 bg-slate-900 border border-slate-700 px-2 py-0.5 rounded">
                      UNTESTED
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
