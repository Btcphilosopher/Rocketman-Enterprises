'use client';

import React from 'react';
import Link from 'next/link';
import { Code2, ShieldCheck, Cpu, Terminal, FileCheck, ExternalLink } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#0E0E10] border-t border-[#2D2D30] mt-16 py-6 font-mono text-xs text-[#94A3B8]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 pb-6 border-b border-[#2D2D30]">
          {/* Col 1: Brand & Compliance */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 rounded bg-[#1E1E20] border border-[#2D2D30] flex items-center justify-center text-[#00FF80]">
                <Code2 className="w-3.5 h-3.5" />
              </div>
              <span className="font-bold text-white tracking-tight text-sm">CODEMARKET<span className="text-[#00FF80]">.OS</span></span>
            </div>
            <p className="text-[#6B7280] leading-relaxed text-[11px]">
              The Enterprise B2B Marketplace for production-grade software codebases. Software entitlement distribution, SHA-256 binary validation, license seat management, and procurement workflows.
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-[#121214] border border-[#2D2D30] text-[10px] text-[#00FF80]">
                <ShieldCheck className="w-3 h-3 mr-1 text-[#00FF80]" />
                SOC 2 TYPE II VERIFIED
              </span>
              <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-[#121214] border border-[#2D2D30] text-[10px] text-[#3B82F6]">
                <FileCheck className="w-3 h-3 mr-1 text-[#3B82F6]" />
                SHA-256 SIGNED BINARIES
              </span>
              <span className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-[#121214] border border-[#2D2D30] text-[10px] text-slate-300">
                VAT INVOICING READY
              </span>
            </div>
          </div>

          {/* Col 2: Software Categories */}
          <div>
            <h4 className="text-[10px] font-bold text-[#4B5563] uppercase tracking-[0.2em] mb-3">
              SOFTWARE TYPES
            </h4>
            <ul className="space-y-1.5 text-[11px] text-[#94A3B8]">
              <li><Link href="/products?type=CODEBASE" className="hover:text-white transition">Complete Codebases</Link></li>
              <li><Link href="/products?type=LIBRARY" className="hover:text-white transition">Libraries & SDKs</Link></li>
              <li><Link href="/products?type=DATABASE" className="hover:text-white transition">Databases & Engines</Link></li>
              <li><Link href="/products?type=INFRASTRUCTURE" className="hover:text-white transition">Infrastructure & IaC</Link></li>
              <li><Link href="/products?type=COMPONENT_LIBRARY" className="hover:text-white transition">Enterprise UI Kits</Link></li>
            </ul>
          </div>

          {/* Col 3: Enterprise B2B */}
          <div>
            <h4 className="text-[10px] font-bold text-[#4B5563] uppercase tracking-[0.2em] mb-3">
              ENTERPRISE B2B
            </h4>
            <ul className="space-y-1.5 text-[11px] text-[#94A3B8]">
              <li><Link href="/enterprise" className="hover:text-white transition">Procurement Workflow</Link></li>
              <li><Link href="/enterprise" className="hover:text-white transition">Software Asset Register</Link></li>
              <li><Link href="/enterprise" className="hover:text-white transition">License Pool Allocator</Link></li>
              <li><Link href="/enterprise" className="hover:text-white transition">Purchase Order Invoicing</Link></li>
              <li><Link href="/enterprise" className="hover:text-white transition">Audit Logs & Compliance</Link></li>
            </ul>
          </div>

          {/* Col 4: Vendors & Developers */}
          <div>
            <h4 className="text-[10px] font-bold text-[#4B5563] uppercase tracking-[0.2em] mb-3">
              PUBLISHERS & CLI
            </h4>
            <ul className="space-y-1.5 text-[11px] text-[#94A3B8]">
              <li><Link href="/vendor" className="hover:text-white transition">Vendor Portal (VENDOR.OS)</Link></li>
              <li><Link href="/vendor" className="hover:text-white transition">Publish Software Release</Link></li>
              <li><Link href="/vendor" className="hover:text-white transition">License Key Engine</Link></li>
              <li><a href="#cli" onClick={(e) => { e.preventDefault(); alert("Open CLI Terminal via header terminal button!"); }} className="hover:text-white transition">CODEMARKET CLI Docs</a></li>
              <li><a href="/api/v1/products" target="_blank" className="hover:text-white transition flex items-center">REST API v1 <ExternalLink className="w-3 h-3 ml-1 text-[#00FF80]" /></a></li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright & status */}
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-between text-[10px] text-[#4B5563] font-mono uppercase tracking-widest gap-2">
          <div>SYSTEM_READY // ENTITLEMENT_ENGINE_V2</div>
          <div className="flex gap-4">
            <span><span className="text-[#00FF80]">●</span> DB_SYNC_OK</span>
            <span><span className="text-[#00FF80]">●</span> ASSET_STORE_LIVE</span>
            <span className="text-[#94A3B8]">© 2026 CODEMARKET.OS ENTERPRISE</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
