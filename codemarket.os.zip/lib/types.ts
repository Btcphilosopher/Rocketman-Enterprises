export type ProductType =
  | 'CODEBASE'
  | 'LIBRARY'
  | 'SDK'
  | 'API'
  | 'PLUGIN'
  | 'EXTENSION'
  | 'CLI'
  | 'TEMPLATE'
  | 'STARTER'
  | 'COMPONENT_LIBRARY'
  | 'UI_KIT'
  | 'DESIGN_SYSTEM'
  | 'DATABASE'
  | 'INFRASTRUCTURE'
  | 'DEVOPS'
  | 'ML_MODEL'
  | 'DATASET'
  | 'AUTOMATION'
  | 'MOBILE_APP'
  | 'WEB_APP'
  | 'BACKEND'
  | 'FULL_STACK'
  | 'ENGINEERING_TOOL'
  | 'DOCUMENTATION'
  | 'OTHER';

export type LicenseType =
  | 'MIT'
  | 'Apache-2.0'
  | 'GPL'
  | 'LGPL'
  | 'BSD'
  | 'Commercial Developer'
  | 'Commercial Enterprise'
  | 'Per Developer'
  | 'Per Organisation'
  | 'Per Deployment'
  | 'Per Server'
  | 'Per API Call'
  | 'Subscription'
  | 'Lifetime'
  | 'Custom';

export type PricingModel =
  | 'FREE'
  | 'ONE_TIME'
  | 'SUBSCRIPTION'
  | 'PER_USER'
  | 'PER_ORGANISATION'
  | 'PER_DEPLOYMENT'
  | 'USAGE_BASED'
  | 'TIERED'
  | 'ENTERPRISE';

export type SecurityStatus =
  | 'UNREVIEWED'
  | 'VENDOR_VERIFIED'
  | 'AUTOMATED_SCAN'
  | 'SECURITY_REVIEWED'
  | 'SUSPENDED';

export type UserRole =
  | 'INDIVIDUAL'
  | 'OWNER'
  | 'ADMIN'
  | 'PROCUREMENT'
  | 'FINANCE'
  | 'DEVELOPER'
  | 'ENGINEER'
  | 'VENDOR'
  | 'VIEWER';

export interface DependencyItem {
  name: string;
  version: string;
  license: string;
  isTransitive?: boolean;
  vulnerabilities?: number;
}

export interface CompatibilityItem {
  runtime: string; // e.g. "Rust", "Node.js", "Python", "Docker"
  versions: string[]; // e.g. ["1.82", "1.83", "1.84"]
  os: string[]; // e.g. ["Linux", "macOS", "Windows"]
  architectures: string[]; // e.g. ["x86_64", "ARM64"]
  tested: boolean;
}

export interface CodeFile {
  path: string;
  language: string;
  content: string;
}

export interface ReleaseAsset {
  filename: string;
  size: string;
  download_url: string;
  sha256: string;
  sha512?: string;
}

export interface Release {
  version: string;
  release_date: string;
  release_notes: string;
  changelog: string[];
  breaking_changes?: string[];
  assets: ReleaseAsset[];
  dependencies: DependencyItem[];
  compatibility: CompatibilityItem[];
  security_status: SecurityStatus;
}

export interface DigitalProduct {
  id: string;
  slug: string;
  name: string;
  vendor_id: string;
  vendor_name: string;
  vendor_verified: boolean;
  vendor_avatar?: string;
  description: string;
  short_description: string;
  category: string;
  subcategory: string;
  product_type: ProductType;
  version: string;
  latest_version: string;
  license_type: LicenseType;
  pricing_model: PricingModel;
  price: number; // In minor units (e.g. 24900 = £249.00)
  currency: string; // "GBP", "USD", "EUR"
  billing_interval?: 'monthly' | 'annual';
  repository_url?: string;
  documentation_url?: string;
  demo_url?: string;
  support_url?: string;
  compatibility: CompatibilityItem[];
  dependencies: DependencyItem[];
  frameworks: string[];
  languages: string[];
  platforms: string[];
  tags: string[];
  features: string[];
  code_files: CodeFile[];
  documentation: string; // Full markdown docs
  changelog: string[];
  release_history: Release[];
  security_status: SecurityStatus;
  rating: number;
  review_count: number;
  download_count: number;
  install_count: number;
  sales_count: number;
  created_at: string;
  updated_at: string;
  published_at: string;
  status: 'PUBLISHED' | 'DRAFT' | 'PENDING_REVIEW' | 'SUSPENDED';
  loc?: number; // Lines of code if codebase
  test_coverage?: string;
  build_status?: string;
  install_command?: string;
  manifest_json?: Record<string, unknown>;
  api_details?: {
    base_url: string;
    auth_type: string;
    rate_limit: string;
    endpoints_count: number;
  };
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  organisation_id?: string;
  organisation_name?: string;
  department?: string;
  avatar_url?: string;
}

export interface Organisation {
  id: string;
  name: string;
  slug: string;
  domain: string;
  industry: string;
  billing_email: string;
  billing_address: string;
  tax_id: string;
  default_currency: string;
  annual_budget: number; // in minor units
  committed_budget: number;
  users_count: number;
  auto_approve_limit: number; // e.g. 50000 = £500
  manager_approval_limit: number; // e.g. 500000 = £5,000
}

export interface Vendor {
  id: string;
  name: string;
  slug: string;
  logo_url: string;
  description: string;
  verified: boolean;
  joined_date: string;
  total_sales: number;
  rating: number;
  products_count: number;
  commission_rate: number; // e.g. 0.15 = 15%
  payout_email: string;
}

export interface Entitlement {
  id: string;
  user_id: string;
  organisation_id?: string;
  product_id: string;
  product_name: string;
  product_slug: string;
  release_id: string;
  version: string;
  latest_version: string;
  license_type: LicenseType;
  seats_total: number;
  seats_assigned: number;
  assigned_emails: string[];
  status: 'ACTIVE' | 'SUSPENDED' | 'EXPIRED' | 'REVOKED';
  purchased_at: string;
  expires_at?: string;
  license_key: string;
  download_token: string;
  update_available: boolean;
}

export interface OrderItem {
  product_id: string;
  product_name: string;
  product_slug: string;
  version: string;
  license_type: LicenseType;
  seats: number;
  unit_price: number;
  total_price: number;
}

export interface Order {
  id: string;
  order_number: string;
  user_id: string;
  user_email: string;
  organisation_id?: string;
  organisation_name?: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  currency: string;
  payment_status: 'PAID' | 'PENDING' | 'FAILED' | 'REFUNDED';
  payment_method: string;
  created_at: string;
  invoice_number: string;
  po_number?: string;
}

export interface PurchaseRequest {
  id: string;
  request_number: string;
  organisation_id: string;
  organisation_name: string;
  requested_by_id: string;
  requested_by_name: string;
  requested_by_email: string;
  department: string;
  product_id: string;
  product_name: string;
  version: string;
  license_type: LicenseType;
  seats: number;
  amount: number;
  currency: string;
  reason: string;
  status: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  created_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
  comments?: string;
}

export interface Invoice {
  id: string;
  invoice_number: string;
  order_id: string;
  organisation_name: string;
  billing_email: string;
  items: OrderItem[];
  subtotal: number;
  tax: number;
  total: number;
  currency: string;
  payment_status: 'PAID' | 'PENDING' | 'OVERDUE';
  issued_at: string;
  due_at: string;
  paid_at?: string;
  po_number?: string;
}

export interface Review {
  id: string;
  product_id: string;
  user_name: string;
  user_role: string;
  rating: number;
  title: string;
  body: string;
  verified_purchase: boolean;
  version_used: string;
  runtime: string;
  platform: string;
  created_at: string;
  helpful_count: number;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  actor_name: string;
  actor_email: string;
  organisation_id?: string;
  action: string; // e.g. 'PURCHASE_APPROVED', 'LICENCE_ASSIGNED', 'PRODUCT_DOWNLOADED'
  object_type: string;
  object_id: string;
  details: string;
}
