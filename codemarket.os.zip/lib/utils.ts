import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(amountMinor: number, currency: string = 'GBP'): string {
  if (amountMinor === 0) return 'FREE';
  const major = amountMinor / 100;
  const symbol = currency === 'GBP' ? '£' : currency === 'USD' ? '$' : '€';
  return `${symbol}${major.toLocaleString('en-GB', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

export function getSecurityBadgeColor(status: string): string {
  switch (status) {
    case 'SECURITY_REVIEWED':
      return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'VENDOR_VERIFIED':
      return 'bg-sky-500/10 text-sky-400 border-sky-500/20';
    case 'AUTOMATED_SCAN':
      return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
    case 'SUSPENDED':
      return 'bg-red-500/10 text-red-400 border-red-500/20';
    default:
      return 'bg-slate-500/10 text-slate-400 border-slate-500/20';
  }
}

