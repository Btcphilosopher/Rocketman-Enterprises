import {
  DigitalProduct,
  Vendor,
  Organisation,
  User,
  Order,
  Entitlement,
  PurchaseRequest,
  Invoice,
  AuditEvent,
  Review
} from './types';
import fs from 'fs';
import path from 'path';

// Initial synthetic seed vendors
const INITIAL_VENDORS: Vendor[] = [
  {
    id: 'v_northstar',
    name: 'Northstar Systems',
    slug: 'northstar-systems',
    logo_url: 'https://picsum.photos/seed/northstar/100/100',
    description: 'High-performance distributed systems, Rust workflow engines, and telemetry tools.',
    verified: true,
    joined_date: '2024-01-15',
    total_sales: 1420,
    rating: 4.9,
    products_count: 3,
    commission_rate: 0.15,
    payout_email: 'payouts@northstarsystems.io'
  },
  {
    id: 'v_aardvark',
    name: 'Aardvark Labs',
    slug: 'aardvark-labs',
    logo_url: 'https://picsum.photos/seed/aardvark/100/100',
    description: 'Enterprise React & TypeScript UI component libraries and design tokens.',
    verified: true,
    joined_date: '2023-11-02',
    total_sales: 3890,
    rating: 4.8,
    products_count: 4,
    commission_rate: 0.15,
    payout_email: 'finance@aardvarklabs.dev'
  },
  {
    id: 'v_dataforge',
    name: 'DataForge Technologies',
    slug: 'dataforge-tech',
    logo_url: 'https://picsum.photos/seed/dataforge/100/100',
    description: 'Python analytics engines, data pipelines, and machine learning infrastructure.',
    verified: true,
    joined_date: '2024-03-20',
    total_sales: 2150,
    rating: 4.9,
    products_count: 5,
    commission_rate: 0.15,
    payout_email: 'billing@dataforge.ai'
  },
  {
    id: 'v_aerosim',
    name: 'AeroSim Engineering',
    slug: 'aerosim-engineering',
    logo_url: 'https://picsum.photos/seed/aerosim/100/100',
    description: 'Computational fluid dynamics, finite element analysis, and aerospace software tools.',
    verified: true,
    joined_date: '2023-08-14',
    total_sales: 680,
    rating: 5.0,
    products_count: 2,
    commission_rate: 0.12,
    payout_email: 'accounts@aerosim.co.uk'
  }
];

// Initial synthetic seed organisations
const INITIAL_ORGANISATIONS: Organisation[] = [
  {
    id: 'org_northstar_eng',
    name: 'Northstar Engineering Ltd',
    slug: 'northstar-engineering',
    domain: 'northstar.io',
    industry: 'Aerospace & Software',
    billing_email: 'procurement@northstar.io',
    billing_address: '100 Silicon Way, Tech Sector, London EC2A 1NT',
    tax_id: 'GB123456789',
    default_currency: 'GBP',
    annual_budget: 25000000, // £250,000.00
    committed_budget: 14300000, // £143,000.00
    users_count: 48,
    auto_approve_limit: 50000, // £500.00
    manager_approval_limit: 500000 // £5,000.00
  },
  {
    id: 'org_rhino_systems',
    name: 'Rhino Global Systems',
    slug: 'rhino-global',
    domain: 'rhinosystems.com',
    industry: 'Financial Infrastructure',
    billing_email: 'ap@rhinosystems.com',
    billing_address: '45 Wall Street, Suite 1200, New York, NY 10005',
    tax_id: 'US987654321',
    default_currency: 'USD',
    annual_budget: 50000000, // $500,000.00
    committed_budget: 28000000, // $280,000.00
    users_count: 120,
    auto_approve_limit: 100000,
    manager_approval_limit: 1000000
  }
];

// Initial synthetic seed users
const INITIAL_USERS: User[] = [
  {
    id: 'usr_dev_01',
    email: 'tom@ahyx.org',
    name: 'Tom Reynolds',
    role: 'ENGINEER',
    organisation_id: 'org_northstar_eng',
    organisation_name: 'Northstar Engineering Ltd',
    department: 'Core Software Architecture',
    avatar_url: 'https://picsum.photos/seed/tom/80/80'
  },
  {
    id: 'usr_mgr_01',
    email: 'sarah.lead@northstar.io',
    name: 'Sarah Jenkins',
    role: 'PROCUREMENT',
    organisation_id: 'org_northstar_eng',
    organisation_name: 'Northstar Engineering Ltd',
    department: 'Engineering Procurement',
    avatar_url: 'https://picsum.photos/seed/sarah/80/80'
  },
  {
    id: 'usr_vendor_01',
    email: 'alex@northstarsystems.io',
    name: 'Alex Vance (Vendor)',
    role: 'VENDOR',
    avatar_url: 'https://picsum.photos/seed/alex/80/80'
  }
];

// Initial synthetic seed products
const INITIAL_PRODUCTS: DigitalProduct[] = [
  {
    id: 'prod_rustflow',
    slug: 'rustflow-engine',
    name: 'RustFlow Engine',
    vendor_id: 'v_northstar',
    vendor_name: 'Northstar Systems',
    vendor_verified: true,
    vendor_avatar: 'https://picsum.photos/seed/northstar/100/100',
    description: 'Enterprise high-throughput Rust async workflow orchestration engine. Built for low-latency message streaming, stateful execution graphs, and zero-allocation processing loops.',
    short_description: 'Enterprise async Rust workflow orchestration & state engine for distributed systems.',
    category: 'Backend',
    subcategory: 'Microservices & Queues',
    product_type: 'CODEBASE',
    version: '3.4.2',
    latest_version: '3.4.2',
    license_type: 'Commercial Developer',
    pricing_model: 'PER_USER',
    price: 24900, // £249.00
    currency: 'GBP',
    repository_url: 'https://github.com/northstar/rustflow-enterprise',
    documentation_url: 'https://docs.rustflow.io',
    demo_url: 'https://demo.rustflow.io',
    support_url: 'https://support.rustflow.io',
    loc: 48500,
    test_coverage: '94.2%',
    build_status: 'PASSING',
    install_command: 'cargo add rustflow-engine',
    compatibility: [
      { runtime: 'Rust', versions: ['1.82', '1.83', '1.84'], os: ['Linux', 'macOS', 'Windows'], architectures: ['x86_64', 'ARM64'], tested: true },
      { runtime: 'Docker', versions: ['24.0+'], os: ['Linux', 'macOS'], architectures: ['x86_64', 'ARM64'], tested: true }
    ],
    dependencies: [
      { name: 'tokio', version: '1.38.0', license: 'MIT' },
      { name: 'serde', version: '1.0.200', license: 'MIT/Apache-2.0' },
      { name: 'tracing', version: '0.1.40', license: 'MIT' },
      { name: 'sqlx', version: '0.8.0', license: 'MIT/Apache-2.0' },
      { name: 'reqwest', version: '0.12.4', license: 'MIT/Apache-2.0' }
    ],
    frameworks: ['Tokio', 'Actix', 'Serde'],
    languages: ['Rust'],
    platforms: ['Linux', 'macOS', 'Windows', 'Docker'],
    tags: ['rust', 'workflow', 'async', 'distributed', 'microservices', 'queue'],
    features: [
      'Sub-millisecond graph node execution latency',
      'Transactional step persistence with SQLx PostgreSQL connector',
      'Built-in rate limiting, exponential backoff, & dead-letter queueing',
      'Prometheus metric collection and OpenTelemetry tracing out-of-the-box',
      'HOT node re-configuration without restarting workflow runners'
    ],
    code_files: [
      {
        path: 'src/lib.rs',
        language: 'rust',
        content: `//! RustFlow Engine v3.4.2 - High performance workflow runner
pub mod engine;
pub mod scheduler;
pub mod runtime;
pub mod state;

pub use engine::WorkflowEngine;
pub use scheduler::StepScheduler;

#[derive(Debug, Clone, serde::Serialize, serde::Deserialize)]
pub struct WorkflowConfig {
    pub concurrency_limit: usize,
    pub max_retries: u32,
    pub timeout_ms: u64,
}
`
      },
      {
        path: 'src/engine.rs',
        language: 'rust',
        content: `use crate::WorkflowConfig;
use std::sync::Arc;
use tokio::sync::RwLock;

pub struct WorkflowEngine {
    config: WorkflowConfig,
    active_tasks: Arc<RwLock<usize>>,
}

impl WorkflowEngine {
    pub fn new(config: WorkflowConfig) -> Self {
        Self {
            config,
            active_tasks: Arc::new(RwLock::new(0)),
        }
    }

    pub async fn execute_step(&self, step_id: &str) -> Result<(), String> {
        let mut count = self.active_tasks.write().await;
        if *count >= self.config.concurrency_limit {
            return Err("Concurrency limit reached".to_string());
        }
        *count += 1;
        tracing::info!(step_id = %step_id, "Executing workflow step");
        Ok(())
    }
}
`
      },
      {
        path: 'Cargo.toml',
        language: 'toml',
        content: `[package]
name = "rustflow-engine"
version = "3.4.2"
edition = "2021"
authors = ["Northstar Engineering"]

[dependencies]
tokio = { version = "1.38", features = ["full"] }
serde = { version = "1.0", features = ["derive"] }
tracing = "0.1"
sqlx = { version = "0.8", features = ["postgres", "runtime-tokio-native-tls"] }
`
      }
    ],
    documentation: `# RustFlow Engine v3.4.2

## Overview
RustFlow is an enterprise-grade async workflow engine written in Rust. It enables developers to construct fault-tolerant distributed DAGs with atomic PostgreSQL persistence and sub-millisecond dispatching.

## Quickstart

\`\`\`rust
use rustflow_engine::{WorkflowEngine, WorkflowConfig};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let config = WorkflowConfig {
        concurrency_limit: 100,
        max_retries: 3,
        timeout_ms: 5000,
    };

    let engine = WorkflowEngine::new(config);
    engine.execute_step("step_init_payment").await?;
    Ok(())
}
\`\`\`

## Architecture
- **Worker Pools**: Dynamic thread-scaling based on CPU core load.
- **State Store**: Zero-alloc serialization into PostgreSQL JSONB columns.
- **Telemetry**: Native OpenTelemetry exporter.
`,
    changelog: [
      'v3.4.2: Added native OpenTelemetry 1.2 context propagation',
      'v3.4.1: Fixed memory leak in dead-letter event queue under load',
      'v3.4.0: Added support for Tokio 1.38 and PostgreSQL 16 row lock optimizations'
    ],
    release_history: [
      {
        version: '3.4.2',
        release_date: '2026-08-28',
        release_notes: 'Performance optimization release for high concurrency workloads.',
        changelog: ['OpenTelemetry context propagation fix', 'Tokio runtime upgrade'],
        assets: [
          { filename: 'rustflow-engine-v3.4.2.tar.gz', size: '14.2 MB', download_url: '/releases/rustflow-3.4.2.tar.gz', sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855' }
        ],
        dependencies: [
          { name: 'tokio', version: '1.38.0', license: 'MIT' },
          { name: 'serde', version: '1.0.200', license: 'MIT/Apache-2.0' }
        ],
        compatibility: [
          { runtime: 'Rust', versions: ['1.82', '1.83', '1.84'], os: ['Linux', 'macOS', 'Windows'], architectures: ['x86_64', 'ARM64'], tested: true }
        ],
        security_status: 'SECURITY_REVIEWED'
      },
      {
        version: '3.3.1',
        release_date: '2026-05-10',
        release_notes: 'Maintenance release for 3.3 line.',
        changelog: ['Security patch for serde buffer boundary'],
        assets: [
          { filename: 'rustflow-engine-v3.3.1.tar.gz', size: '13.8 MB', download_url: '/releases/rustflow-3.3.1.tar.gz', sha256: 'c34a044298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b999' }
        ],
        dependencies: [],
        compatibility: [],
        security_status: 'AUTOMATED_SCAN'
      }
    ],
    security_status: 'SECURITY_REVIEWED',
    rating: 4.9,
    review_count: 38,
    download_count: 1420,
    install_count: 890,
    sales_count: 410,
    created_at: '2024-02-10',
    updated_at: '2026-08-28',
    published_at: '2024-02-15',
    status: 'PUBLISHED'
  },
  {
    id: 'prod_aardvark_ui',
    slug: 'aardvark-enterprise-ui',
    name: 'Aardvark Enterprise UI Kit',
    vendor_id: 'v_aardvark',
    vendor_name: 'Aardvark Labs',
    vendor_verified: true,
    vendor_avatar: 'https://picsum.photos/seed/aardvark/100/100',
    description: 'Comprehensive React & TypeScript component library engineered for high-density B2B dashboards, financial terminals, and analytical workbenches.',
    short_description: 'High-density React & Tailwind UI component suite for financial and enterprise apps.',
    category: 'Frontend',
    subcategory: 'UI libraries',
    product_type: 'COMPONENT_LIBRARY',
    version: '4.2.1',
    latest_version: '4.2.1',
    license_type: 'Commercial Developer',
    pricing_model: 'PER_USER',
    price: 14900, // £149.00
    currency: 'GBP',
    repository_url: 'https://github.com/aardvark/enterprise-ui',
    documentation_url: 'https://ui.aardvark.dev',
    demo_url: 'https://storybook.aardvark.dev',
    install_command: 'npm install @aardvark/enterprise-ui',
    loc: 32000,
    test_coverage: '98.1%',
    build_status: 'PASSING',
    compatibility: [
      { runtime: 'Node.js', versions: ['18.x', '20.x', '22.x'], os: ['Cross-Platform'], architectures: ['All'], tested: true },
      { runtime: 'React', versions: ['18.x', '19.x'], os: ['Web'], architectures: ['Browser'], tested: true }
    ],
    dependencies: [
      { name: 'react', version: '^18.2.0', license: 'MIT' },
      { name: 'motion', version: '^12.0.0', license: 'MIT' },
      { name: 'clsx', version: '^2.1.1', license: 'MIT' },
      { name: 'lucide-react', version: '^0.400.0', license: 'ISC' }
    ],
    frameworks: ['React', 'Next.js', 'Tailwind CSS'],
    languages: ['TypeScript', 'CSS'],
    platforms: ['Web', 'Electron'],
    tags: ['react', 'ui-kit', 'tailwind', 'dashboard', 'enterprise', 'components'],
    features: [
      '65+ Accessible WCAG AAA high-density UI components',
      'Virtually-rendered DataGrids supporting 100k+ rows with smooth scrolling',
      'Dark/Light mode with CSS variable design token synchronization',
      'Keyboard shortcut navigation and full ARIA screen-reader support',
      'Figma design tokens directly exported to Tailwind v4 plugin'
    ],
    code_files: [
      {
        path: 'src/components/DataTable.tsx',
        language: 'typescript',
        content: `import React, { useState } from 'react';

export interface Column<T> {
  key: keyof T;
  header: string;
  width?: number;
}

export function DataTable<T extends { id: string | number }>({
  data,
  columns,
}: {
  data: T[];
  columns: Column<T>[];
}) {
  return (
    <div className="border border-slate-800 rounded-md overflow-hidden font-mono text-sm">
      <table className="w-full text-left bg-slate-950">
        <thead className="bg-slate-900 border-b border-slate-800 text-slate-400 uppercase text-xs">
          <tr>
            {columns.map((col) => (
              <th key={String(col.key)} className="px-4 py-2 font-medium">
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-800/60">
          {data.map((row) => (
            <tr key={row.id} className="hover:bg-slate-900/50 transition">
              {columns.map((col) => (
                <td key={String(col.key)} className="px-4 py-2.5 text-slate-200">
                  {String(row[col.key])}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
`
      }
    ],
    documentation: `# Aardvark Enterprise UI Kit v4.2.1

## Installation
\`\`\`bash
npm install @aardvark/enterprise-ui
\`\`\`

## Quickstart
\`\`\`tsx
import { DataTable, Button, Badge } from '@aardvark/enterprise-ui';

export function Dashboard() {
  return (
    <div>
      <Badge variant="success">Online</Badge>
      <Button variant="primary">Export CSV</Button>
    </div>
  );
}
\`\`\`
`,
    changelog: [
      'v4.2.1: Fixed React 19 server-component hydration warnings',
      'v4.2.0: Added Virtualized DataGrid tree view column support'
    ],
    release_history: [
      {
        version: '4.2.1',
        release_date: '2026-08-15',
        release_notes: 'React 19 compatibility & bugfixes.',
        changelog: ['React 19 support', 'Accessibility aria-activedescendant fixes'],
        assets: [
          { filename: 'aardvark-ui-v4.2.1.tgz', size: '4.5 MB', download_url: '/releases/aardvark-4.2.1.tgz', sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08' }
        ],
        dependencies: [],
        compatibility: [],
        security_status: 'SECURITY_REVIEWED'
      }
    ],
    security_status: 'SECURITY_REVIEWED',
    rating: 4.8,
    review_count: 64,
    download_count: 3890,
    install_count: 2750,
    sales_count: 1200,
    created_at: '2023-11-05',
    updated_at: '2026-08-15',
    published_at: '2023-11-10',
    status: 'PUBLISHED'
  },
  {
    id: 'prod_dataforge_py',
    slug: 'dataforge-python-toolkit',
    name: 'DataForge Python Analytics Engine',
    vendor_id: 'v_dataforge',
    vendor_name: 'DataForge Technologies',
    vendor_verified: true,
    vendor_avatar: 'https://picsum.photos/seed/dataforge/100/100',
    description: 'Blazing fast Python & C++ SIMD accelerated dataframe processing engine for financial time-series, streaming telemetry, and columnar data pipelines.',
    short_description: 'C++ SIMD accelerated Python dataframe processing engine for time-series analytics.',
    category: 'AI / ML',
    subcategory: 'datasets & inference',
    product_type: 'LIBRARY',
    version: '2.1.0',
    latest_version: '2.1.0',
    license_type: 'Apache-2.0',
    pricing_model: 'FREE',
    price: 0,
    currency: 'GBP',
    repository_url: 'https://github.com/dataforge/python-engine',
    install_command: 'pip install dataforge-analytics',
    loc: 28000,
    test_coverage: '96.5%',
    build_status: 'PASSING',
    compatibility: [
      { runtime: 'Python', versions: ['3.10', '3.11', '3.12'], os: ['Linux', 'macOS', 'Windows'], architectures: ['x86_64', 'ARM64'], tested: true }
    ],
    dependencies: [
      { name: 'numpy', version: '>=1.26.0', license: 'BSD-3-Clause' },
      { name: 'pyarrow', version: '>=15.0.0', license: 'Apache-2.0' }
    ],
    frameworks: ['Pandas', 'PyArrow', 'Polars'],
    languages: ['Python', 'C++'],
    platforms: ['Linux', 'macOS', 'Windows'],
    tags: ['python', 'analytics', 'dataframe', 'simd', 'time-series', 'arrow'],
    features: [
      '10x faster execution than standard Pandas on multi-core CPUs',
      'Zero-copy memory integration with PyArrow and Polars',
      'Streaming aggregation over million-event windows with sub-5ms latency'
    ],
    code_files: [
      {
        path: 'dataforge/__init__.py',
        language: 'python',
        content: `"""DataForge Analytics Engine v2.1.0"""
from .dataframe import DataFrame
from .series import Series

__version__ = "2.1.0"
__all__ = ["DataFrame", "Series"]
`
      }
    ],
    documentation: `# DataForge Python Analytics v2.1.0\nFast columnar analytics for Python.`,
    changelog: ['v2.1.0: AVX-512 SIMD vectorization routines added'],
    release_history: [
      {
        version: '2.1.0',
        release_date: '2026-07-01',
        release_notes: 'AVX-512 optimization release.',
        changelog: ['AVX-512 acceleration'],
        assets: [
          { filename: 'dataforge_analytics-2.1.0-cp311-manylinux.whl', size: '18.2 MB', download_url: '/releases/dataforge-2.1.0.whl', sha256: 'a38b0000112233445566778899aabbccddeeff00112233445566778899aabbcc' }
        ],
        dependencies: [],
        compatibility: [],
        security_status: 'AUTOMATED_SCAN'
      }
    ],
    security_status: 'VENDOR_VERIFIED',
    rating: 4.9,
    review_count: 51,
    download_count: 8900,
    install_count: 6200,
    sales_count: 0,
    created_at: '2024-03-22',
    updated_at: '2026-07-01',
    published_at: '2024-03-25',
    status: 'PUBLISHED'
  },
  {
    id: 'prod_aerosim_cfd',
    slug: 'aerosim-cfd-toolkit',
    name: 'AeroSim Python CFD Toolkit',
    vendor_id: 'v_aerosim',
    vendor_name: 'AeroSim Engineering',
    vendor_verified: true,
    vendor_avatar: 'https://picsum.photos/seed/aerosim/100/100',
    description: 'High-fidelity computational fluid dynamics and aerodynamic mesh simulation package. Integrates Python bindings for OpenFOAM parallel solvers and GPU acceleration.',
    short_description: 'Enterprise CFD & aerodynamic mesh solver with Python bindings & GPU acceleration.',
    category: 'Engineering',
    subcategory: 'simulation & CAD',
    product_type: 'ENGINEERING_TOOL',
    version: '5.1.0',
    latest_version: '5.1.0',
    license_type: 'Commercial Enterprise',
    pricing_model: 'PER_ORGANISATION',
    price: 120000, // £1,200.00
    currency: 'GBP',
    repository_url: 'https://github.com/aerosim/cfd-toolkit-ent',
    documentation_url: 'https://docs.aerosim.co.uk',
    install_command: 'pip install aerosim-cfd-pro',
    loc: 112000,
    test_coverage: '91.8%',
    build_status: 'PASSING',
    compatibility: [
      { runtime: 'Python', versions: ['3.11', '3.12'], os: ['Linux', 'Windows'], architectures: ['x86_64', 'CUDA GPU'], tested: true }
    ],
    dependencies: [
      { name: 'openfoam', version: 'v2312', license: 'GPL-3.0' },
      { name: 'cupy', version: '>=12.0.0', license: 'MIT' }
    ],
    frameworks: ['CUDA', 'OpenFOAM', 'PyVista'],
    languages: ['Python', 'C++'],
    platforms: ['Linux (RHEL/Ubuntu)', 'Windows Server'],
    tags: ['cfd', 'aerospace', 'simulation', 'fluid-dynamics', 'python', 'gpu'],
    features: [
      'Multi-GPU parallel solver support for up to 128 NVIDIA CUDA nodes',
      'Automated boundary layer meshing with adaptive cell density',
      'Pre-built CAD step file importer with automatic surface defect repair'
    ],
    code_files: [
      {
        path: 'aerosim/solver.py',
        language: 'python',
        content: `class CFDSolver:
    def __init__(self, mesh_path: str, gpu_accelerated: bool = True):
        self.mesh_path = mesh_path
        self.gpu = gpu_accelerated

    def run_simulation(self, mach_number: float, iterations: int = 1000):
        print(f"Initializing aerodynamic run at Mach {mach_number} over {iterations} steps")
        return {"status": "converged", "drag_coeff": 0.0245, "lift_coeff": 0.482}
`
      }
    ],
    documentation: `# AeroSim CFD Toolkit v5.1.0\nAerospace engineering grade fluid simulation.`,
    changelog: ['v5.1.0: CUDA 12.4 memory allocator optimizations'],
    release_history: [
      {
        version: '5.1.0',
        release_date: '2026-06-12',
        release_notes: 'CUDA 12.4 acceleration release.',
        changelog: ['CUDA 12.4 support'],
        assets: [
          { filename: 'aerosim-cfd-5.1.0-linux-x86_64.tar.gz', size: '142.5 MB', download_url: '/releases/aerosim-5.1.0.tar.gz', sha256: 'f8765432101234567890abcdef1234567890abcdef1234567890abcdef123456' }
        ],
        dependencies: [],
        compatibility: [],
        security_status: 'SECURITY_REVIEWED'
      }
    ],
    security_status: 'SECURITY_REVIEWED',
    rating: 5.0,
    review_count: 19,
    download_count: 680,
    install_count: 420,
    sales_count: 140,
    created_at: '2023-08-20',
    updated_at: '2026-06-12',
    published_at: '2023-08-25',
    status: 'PUBLISHED'
  },
  {
    id: 'prod_tensormesh',
    slug: 'tensormesh-ml-platform',
    name: 'TensorMesh ML Inference Server',
    vendor_id: 'v_dataforge',
    vendor_name: 'DataForge Technologies',
    vendor_verified: true,
    vendor_avatar: 'https://picsum.photos/seed/dataforge/100/100',
    description: 'Distributed LLM & Vision transformer inference gateway with automatic tensor parallelism, dynamic batching, and continuous paged KV-caching.',
    short_description: 'Distributed LLM & Vision transformer inference gateway with paged KV-caching.',
    category: 'AI / ML',
    subcategory: 'inference systems',
    product_type: 'INFRASTRUCTURE',
    version: '1.8.0',
    latest_version: '1.8.0',
    license_type: 'Per Developer',
    pricing_model: 'PER_USER',
    price: 59900, // £599.00
    currency: 'GBP',
    install_command: 'docker pull dataforge/tensormesh:1.8.0',
    loc: 54000,
    test_coverage: '92.0%',
    build_status: 'PASSING',
    compatibility: [
      { runtime: 'Docker', versions: ['24.0+'], os: ['Linux'], architectures: ['NVIDIA GPU', 'AMD ROCm'], tested: true }
    ],
    dependencies: [
      { name: 'torch', version: '2.3.0', license: 'BSD' },
      { name: 'vllm', version: '0.4.2', license: 'Apache-2.0' }
    ],
    frameworks: ['PyTorch', 'vLLM', 'FastAPI'],
    languages: ['Python', 'C++'],
    platforms: ['Kubernetes', 'Docker'],
    tags: ['ai', 'llm', 'inference', 'vllm', 'transformer', 'gpu', 'ml'],
    features: [
      'PagedAttention KV-cache management reducing GPU memory waste by 80%',
      'Dynamic request queuing with SLA latency guarantees',
      'OpenAI compatible REST and gRPC API endpoints'
    ],
    code_files: [
      {
        path: 'config.yaml',
        language: 'yaml',
        content: `server:
  port: 8080
  gpu_memory_utilization: 0.90
  max_num_seqs: 256
model:
  path: "meta-llama/Meta-Llama-3-70B-Instruct"
  tensor_parallel_size: 4
`
      }
    ],
    documentation: `# TensorMesh Inference Server v1.8.0\nHigh throughput LLM serving.`,
    changelog: ['v1.8.0: Multi-modal vision transformer support'],
    release_history: [],
    security_status: 'SECURITY_REVIEWED',
    rating: 4.9,
    review_count: 28,
    download_count: 1850,
    install_count: 1100,
    sales_count: 310,
    created_at: '2024-05-10',
    updated_at: '2026-08-01',
    published_at: '2024-05-15',
    status: 'PUBLISHED'
  },
  {
    id: 'prod_postgres_analytics',
    slug: 'postgres-analytics-engine',
    name: 'PostgreSQL Analytics Engine Extension',
    vendor_id: 'v_northstar',
    vendor_name: 'Northstar Systems',
    vendor_verified: true,
    vendor_avatar: 'https://picsum.photos/seed/northstar/100/100',
    description: 'Native C extension for PostgreSQL that turns standard Postgres into a high-performance hybrid transactional/analytical database (HTAP) with columnar storage.',
    short_description: 'Native C extension adding high-speed columnar analytics & HTAP queries to PostgreSQL.',
    category: 'Backend',
    subcategory: 'databases',
    product_type: 'DATABASE',
    version: '2.0.4',
    latest_version: '2.0.4',
    license_type: 'Per Server',
    pricing_model: 'PER_DEPLOYMENT',
    price: 89900, // £899.00
    currency: 'GBP',
    install_command: 'CREATE EXTENSION pg_analytics_pro;',
    loc: 62000,
    test_coverage: '95.1%',
    build_status: 'PASSING',
    compatibility: [
      { runtime: 'PostgreSQL', versions: ['14', '15', '16'], os: ['Linux', 'macOS'], architectures: ['x86_64', 'ARM64'], tested: true }
    ],
    dependencies: [
      { name: 'postgresql-server-dev', version: '>=15', license: 'PostgreSQL' }
    ],
    frameworks: ['PostgreSQL C SPI', 'Apache Arrow'],
    languages: ['C', 'SQL'],
    platforms: ['Linux (Debian/Ubuntu/RHEL)'],
    tags: ['postgresql', 'database', 'extension', 'columnar', 'htap', 'analytics'],
    features: [
      'Automatic query routing between OLTP row storage and columnar compression',
      'SIMD vectorization for SUM, AVG, COUNT, and GROUP BY operations',
      'Seamless support for existing pg_dump and replication streams'
    ],
    code_files: [
      {
        path: 'pg_analytics.c',
        language: 'c',
        content: `#include "postgres.h"
#include "fmgr.h"

PG_MODULE_MAGIC;

PG_FUNCTION_INFO_V1(pg_analytics_version);

Datum
pg_analytics_version(PG_FUNCTION_ARGS)
{
    PG_RETURN_TEXT_P(cstring_to_text("2.0.4-pro"));
}
`
      }
    ],
    documentation: `# PostgreSQL Analytics Engine v2.0.4\nColumnar HTAP storage for Postgres.`,
    changelog: ['v2.0.4: Postgres 16 partition pruning optimizations'],
    release_history: [],
    security_status: 'SECURITY_REVIEWED',
    rating: 4.8,
    review_count: 42,
    download_count: 2100,
    install_count: 1450,
    sales_count: 520,
    created_at: '2024-01-20',
    updated_at: '2026-07-18',
    published_at: '2024-01-25',
    status: 'PUBLISHED'
  }
];

// Initial synthetic seed orders
const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord_10482',
    order_number: 'CM-10482',
    user_id: 'usr_dev_01',
    user_email: 'tom@ahyx.org',
    organisation_id: 'org_northstar_eng',
    organisation_name: 'Northstar Engineering Ltd',
    items: [
      {
        product_id: 'prod_rustflow',
        product_name: 'RustFlow Engine',
        product_slug: 'rustflow-engine',
        version: '3.4.2',
        license_type: 'Commercial Developer',
        seats: 5,
        unit_price: 24900,
        total_price: 124500 // £1,245.00
      }
    ],
    subtotal: 124500,
    tax: 24900,
    total: 149400, // £1,494.00
    currency: 'GBP',
    payment_status: 'PAID',
    payment_method: 'Corporate Invoice / PO',
    created_at: '2026-08-29T10:15:00Z',
    invoice_number: 'INV-2026-0891',
    po_number: 'PO-NORTH-992'
  }
];

// Initial synthetic seed entitlements
const INITIAL_ENTITLEMENTS: Entitlement[] = [
  {
    id: 'ent_9021',
    user_id: 'usr_dev_01',
    organisation_id: 'org_northstar_eng',
    product_id: 'prod_rustflow',
    product_name: 'RustFlow Engine',
    product_slug: 'rustflow-engine',
    release_id: 'rel_rustflow_342',
    version: '3.4.2',
    latest_version: '3.4.2',
    license_type: 'Commercial Developer',
    seats_total: 5,
    seats_assigned: 4,
    assigned_emails: [
      'tom@ahyx.org',
      'dev1@northstar.io',
      'dev2@northstar.io',
      'dev3@northstar.io'
    ],
    status: 'ACTIVE',
    purchased_at: '2026-08-29T10:15:00Z',
    license_key: 'CM-LIC-RF-342-99812-NSTAR',
    download_token: 'dl_tok_8812938129381',
    update_available: false
  },
  {
    id: 'ent_9022',
    user_id: 'usr_dev_01',
    organisation_id: 'org_northstar_eng',
    product_id: 'prod_aardvark_ui',
    product_name: 'Aardvark Enterprise UI Kit',
    product_slug: 'aardvark-enterprise-ui',
    release_id: 'rel_aardvark_421',
    version: '4.2.1',
    latest_version: '4.2.1',
    license_type: 'Commercial Developer',
    seats_total: 10,
    seats_assigned: 8,
    assigned_emails: ['tom@ahyx.org', 'frontend.lead@northstar.io'],
    status: 'ACTIVE',
    purchased_at: '2026-07-12T14:22:00Z',
    license_key: 'CM-LIC-AARD-421-12983-UI',
    download_token: 'dl_tok_7721381231',
    update_available: false
  }
];

// Initial synthetic seed purchase requests
const INITIAL_PURCHASE_REQUESTS: PurchaseRequest[] = [
  {
    id: 'pr_501',
    request_number: 'PR-2026-0501',
    organisation_id: 'org_northstar_eng',
    organisation_name: 'Northstar Engineering Ltd',
    requested_by_id: 'usr_dev_01',
    requested_by_name: 'Tom Reynolds',
    requested_by_email: 'tom@ahyx.org',
    department: 'Core Software Architecture',
    product_id: 'prod_aerosim_cfd',
    product_name: 'AeroSim Python CFD Toolkit',
    version: '5.1.0',
    license_type: 'Commercial Enterprise',
    seats: 1,
    amount: 120000, // £1,200.00
    currency: 'GBP',
    reason: 'Required for Q4 turbine blade airflow simulation and high-speed thermal modeling.',
    status: 'PENDING_APPROVAL',
    created_at: '2026-09-04T16:30:00Z'
  }
];

// Initial synthetic audit events
const INITIAL_AUDIT_LOGS: AuditEvent[] = [
  {
    id: 'aud_101',
    timestamp: '2026-09-04T16:30:00Z',
    actor_name: 'Tom Reynolds',
    actor_email: 'tom@ahyx.org',
    organisation_id: 'org_northstar_eng',
    action: 'PROCUREMENT_REQUESTED',
    object_type: 'PurchaseRequest',
    object_id: 'pr_501',
    details: 'Submitted purchase request for AeroSim Python CFD Toolkit (£1,200.00)'
  },
  {
    id: 'aud_100',
    timestamp: '2026-08-29T10:15:00Z',
    actor_name: 'Tom Reynolds',
    actor_email: 'tom@ahyx.org',
    organisation_id: 'org_northstar_eng',
    action: 'PRODUCT_PURCHASED',
    object_type: 'Order',
    object_id: 'ord_10482',
    details: 'Purchased 5 seats of RustFlow Engine (Commercial Developer) - Order CM-10482'
  }
];

// Initial reviews
const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev_01',
    product_id: 'prod_rustflow',
    user_name: 'Dr. Marcus Vance',
    user_role: 'Principal Systems Architect',
    rating: 5,
    title: 'Flawless async graph execution under heavy load',
    body: 'We integrated RustFlow Engine v3.4 into our aerospace telemetry processing pipeline. The zero-allocation runner cut our tail latencies by 65%. High quality code base and clear documentation.',
    verified_purchase: true,
    version_used: '3.4.2',
    runtime: 'Rust 1.83',
    platform: 'Linux x86_64',
    created_at: '2026-08-30',
    helpful_count: 14
  },
  {
    id: 'rev_02',
    product_id: 'prod_aardvark_ui',
    user_name: 'Elena Rostova',
    user_role: 'Staff Frontend Engineer',
    rating: 5,
    title: 'The DataGrid component alone saved us 3 months',
    body: 'Remarkably clean TypeScript API. Renders 50,000 live streaming rows with zero lag in React 19. Highly recommended for enterprise trading desks.',
    verified_purchase: true,
    version_used: '4.2.1',
    runtime: 'Node.js 20',
    platform: 'Web / Chrome',
    created_at: '2026-08-18',
    helpful_count: 22
  }
];

// Data storage shape
interface StoreData {
  products: DigitalProduct[];
  vendors: Vendor[];
  organisations: Organisation[];
  users: User[];
  orders: Order[];
  entitlements: Entitlement[];
  purchaseRequests: PurchaseRequest[];
  auditLogs: AuditEvent[];
  reviews: Review[];
}

const DB_FILE_PATH = path.join('/tmp', 'codemarket_db.json');

class DatabaseStore {
  private memoryData: StoreData;

  constructor() {
    this.memoryData = this.loadFromFile();
  }

  private loadFromFile(): StoreData {
    try {
      if (fs.existsSync(DB_FILE_PATH)) {
        const raw = fs.readFileSync(DB_FILE_PATH, 'utf-8');
        return JSON.parse(raw);
      }
    } catch (e) {
      console.warn('Failed to load db file, fallback to initial seed:', e);
    }

    const defaultData: StoreData = {
      products: INITIAL_PRODUCTS,
      vendors: INITIAL_VENDORS,
      organisations: INITIAL_ORGANISATIONS,
      users: INITIAL_USERS,
      orders: INITIAL_ORDERS,
      entitlements: INITIAL_ENTITLEMENTS,
      purchaseRequests: INITIAL_PURCHASE_REQUESTS,
      auditLogs: INITIAL_AUDIT_LOGS,
      reviews: INITIAL_REVIEWS
    };

    this.saveToFile(defaultData);
    return defaultData;
  }

  private saveToFile(data: StoreData) {
    try {
      fs.writeFileSync(DB_FILE_PATH, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Failed to write db file:', e);
    }
  }

  public getProducts(): DigitalProduct[] {
    return this.memoryData.products;
  }

  public getProductBySlugOrId(idOrSlug: string): DigitalProduct | undefined {
    return this.memoryData.products.find(
      p => p.id === idOrSlug || p.slug === idOrSlug
    );
  }

  public addProduct(product: DigitalProduct): DigitalProduct {
    this.memoryData.products.unshift(product);
    this.saveToFile(this.memoryData);
    return product;
  }

  public updateProduct(product: DigitalProduct): DigitalProduct {
    const idx = this.memoryData.products.findIndex(p => p.id === product.id);
    if (idx !== -1) {
      this.memoryData.products[idx] = product;
      this.saveToFile(this.memoryData);
    }
    return product;
  }

  public getVendors(): Vendor[] {
    return this.memoryData.vendors;
  }

  public getOrganisations(): Organisation[] {
    return this.memoryData.organisations;
  }

  public getUsers(): User[] {
    return this.memoryData.users;
  }

  public getOrders(): Order[] {
    return this.memoryData.orders;
  }

  public getEntitlements(): Entitlement[] {
    return this.memoryData.entitlements;
  }

  public getPurchaseRequests(): PurchaseRequest[] {
    return this.memoryData.purchaseRequests;
  }

  public getAuditLogs(): AuditEvent[] {
    return this.memoryData.auditLogs;
  }

  public getReviewsForProduct(productId: string): Review[] {
    return this.memoryData.reviews.filter(r => r.product_id === productId);
  }

  public createOrder(order: Order, entitlements: Entitlement[]) {
    this.memoryData.orders.unshift(order);
    this.memoryData.entitlements.unshift(...entitlements);

    // Record audit event
    const audit: AuditEvent = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor_name: order.user_email,
      actor_email: order.user_email,
      organisation_id: order.organisation_id,
      action: 'ORDER_PURCHASED',
      object_type: 'Order',
      object_id: order.id,
      details: `Completed order ${order.order_number} for ${order.items.map(i => i.product_name).join(', ')}`
    };
    this.memoryData.auditLogs.unshift(audit);

    // Increment vendor sales
    order.items.forEach(item => {
      const prod = this.memoryData.products.find(p => p.id === item.product_id);
      if (prod) {
        prod.sales_count += 1;
        prod.download_count += 1;
      }
    });

    this.saveToFile(this.memoryData);
    return order;
  }

  public createPurchaseRequest(req: PurchaseRequest) {
    this.memoryData.purchaseRequests.unshift(req);

    const audit: AuditEvent = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor_name: req.requested_by_name,
      actor_email: req.requested_by_email,
      organisation_id: req.organisation_id,
      action: 'PROCUREMENT_REQUESTED',
      object_type: 'PurchaseRequest',
      object_id: req.id,
      details: `Requested approval for ${req.product_name} (${req.request_number})`
    };
    this.memoryData.auditLogs.unshift(audit);

    this.saveToFile(this.memoryData);
    return req;
  }

  public approvePurchaseRequest(requestId: string, reviewerName: string) {
    const pr = this.memoryData.purchaseRequests.find(r => r.id === requestId);
    if (!pr) throw new Error('Purchase request not found');

    pr.status = 'APPROVED';
    pr.reviewed_at = new Date().toISOString();
    pr.reviewed_by = reviewerName;

    // Convert into order & entitlement
    const orderId = `ord_${Date.now()}`;
    const orderNum = `CM-${Math.floor(10000 + Math.random() * 90000)}`;
    const newOrder: Order = {
      id: orderId,
      order_number: orderNum,
      user_id: pr.requested_by_id,
      user_email: pr.requested_by_email,
      organisation_id: pr.organisation_id,
      organisation_name: pr.organisation_name,
      items: [
        {
          product_id: pr.product_id,
          product_name: pr.product_name,
          product_slug: pr.product_id,
          version: pr.version,
          license_type: pr.license_type,
          seats: pr.seats,
          unit_price: pr.amount,
          total_price: pr.amount
        }
      ],
      subtotal: pr.amount,
      tax: Math.round(pr.amount * 0.2),
      total: Math.round(pr.amount * 1.2),
      currency: pr.currency,
      payment_status: 'PAID',
      payment_method: 'Enterprise Purchase Order',
      created_at: new Date().toISOString(),
      invoice_number: `INV-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`,
      po_number: `PO-${pr.organisation_id.slice(4).toUpperCase()}-${Math.floor(100 + Math.random() * 900)}`
    };

    const entitlement: Entitlement = {
      id: `ent_${Date.now()}`,
      user_id: pr.requested_by_id,
      organisation_id: pr.organisation_id,
      product_id: pr.product_id,
      product_name: pr.product_name,
      product_slug: pr.product_id,
      release_id: `rel_${pr.product_id}_${pr.version}`,
      version: pr.version,
      latest_version: pr.version,
      license_type: pr.license_type,
      seats_total: pr.seats,
      seats_assigned: 1,
      assigned_emails: [pr.requested_by_email],
      status: 'ACTIVE',
      purchased_at: new Date().toISOString(),
      license_key: `CM-LIC-${pr.product_id.toUpperCase()}-${Math.floor(10000 + Math.random() * 90000)}`,
      download_token: `dl_tok_${Date.now()}`,
      update_available: false
    };

    this.memoryData.orders.unshift(newOrder);
    this.memoryData.entitlements.unshift(entitlement);

    const audit: AuditEvent = {
      id: `aud_${Date.now()}`,
      timestamp: new Date().toISOString(),
      actor_name: reviewerName,
      actor_email: reviewerName,
      organisation_id: pr.organisation_id,
      action: 'PURCHASE_APPROVED',
      object_type: 'PurchaseRequest',
      object_id: pr.id,
      details: `Approved purchase request ${pr.request_number} for ${pr.product_name}`
    };
    this.memoryData.auditLogs.unshift(audit);

    this.saveToFile(this.memoryData);
    return { order: newOrder, entitlement };
  }

  public assignSeat(entitlementId: string, email: string) {
    const ent = this.memoryData.entitlements.find(e => e.id === entitlementId);
    if (!ent) throw new Error('Entitlement not found');
    if (ent.seats_assigned >= ent.seats_total) {
      throw new Error('All license seats are currently assigned');
    }
    if (!ent.assigned_emails.includes(email)) {
      ent.assigned_emails.push(email);
      ent.seats_assigned += 1;
      this.saveToFile(this.memoryData);
    }
    return ent;
  }

  public revokeSeat(entitlementId: string, email: string) {
    const ent = this.memoryData.entitlements.find(e => e.id === entitlementId);
    if (!ent) throw new Error('Entitlement not found');
    const idx = ent.assigned_emails.indexOf(email);
    if (idx !== -1) {
      ent.assigned_emails.splice(idx, 1);
      ent.seats_assigned = Math.max(0, ent.seats_assigned - 1);
      this.saveToFile(this.memoryData);
    }
    return ent;
  }
}

export const dbStore = new DatabaseStore();
