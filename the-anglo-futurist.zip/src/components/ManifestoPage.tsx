import React from 'react';
import { BookOpen, MapPin, Compass, ShieldCheck } from 'lucide-react';

interface ManifestoPageProps {
  isDarkMode: boolean;
}

export default function ManifestoPage({ isDarkMode }: ManifestoPageProps) {
  return (
    <section
      id="manifesto-section"
      className={`py-24 md:py-32 px-6 md:px-12 transition-colors duration-500 border-b ${
        isDarkMode ? 'bg-[#101010]' : 'bg-[#FAF8F4]'
      }`}
    >
      <div className="max-w-5xl mx-auto">
        
        {/* Editorial Header */}
        <div className="text-center space-y-6 mb-16">
          <span className="text-[10px] md:text-xs tracking-[0.4em] text-brand-brass font-bold uppercase block">
            ANGLO-FUTURIST JOURNAL &bull; VOL. I
          </span>
          <h1 className="font-serif text-4xl sm:text-6xl md:text-7xl font-light tracking-wide leading-tight">
            The Anglo-Futurist <br />
            Manifesto
          </h1>
          <p className="font-serif italic text-lg text-brand-brass max-w-xl mx-auto">
            "A critical reinterpretation of British craftsmanship, culinary architecture, and modern New England industrialism."
          </p>
        </div>

        {/* Large Decorative Photo Cover */}
        <div className="relative overflow-hidden border border-brand-brass/10 mb-16 h-[300px] md:h-[450px]">
          <div className="absolute inset-0 bg-gradient-to-t from-black/75 to-transparent z-10" />
          <img
            src="https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1200"
            alt="The hearth grill of Anglo-Futurist"
            className="w-full h-full object-cover filter brightness-[0.6] contrast-[1.1]"
          />
          <div className="absolute bottom-8 left-8 md:left-12 z-20 text-white max-w-xl">
            <span className="text-[9px] tracking-[0.25em] text-brand-brass uppercase font-bold">CHAPTER ONE</span>
            <h3 className="font-serif text-2xl md:text-3xl font-medium tracking-wide mt-1">
              Industrial Hearth & Southern Soil
            </h3>
          </div>
        </div>

        {/* Multi-Column Magazine Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 font-sans text-sm md:text-base leading-relaxed tracking-wide font-light">
          
          {/* Column One */}
          <div className="space-y-6 text-justify">
            <h4 className="font-serif text-xl font-bold text-brand-brass mb-4">
              I. The Fall of Apology
            </h4>
            <p>
              For generations, British hospitality existed in a state of quiet compromise. It retreated into the wood-paneled nostalgia of countryside pubs, or hid behind the strict, imported protocols of French high gastronomy. We believe this compromise was a profound failure of cultural confidence.
            </p>
            <p>
              The British Isles possess some of the most dramatic, mineral-rich terrains on earth. The cold, oxygenated currents of the North Sea yield sweet dabs and robust cod; the salt-sprayed pastures of Yorkshire, Wales, and the Scottish Highlands nourish meats of complex microbiology. To hide these behind heavy sauces is an offense to craftsmanship.
            </p>
            
            <h4 className="font-serif text-xl font-bold text-brand-brass mt-8 mb-4">
              II. The New England Conduit
            </h4>
            <p>
              Boston is a city of historic cables. Its bricks and harbors are tethered deeply to London’s maritime trade, its libraries aligned with Oxford’s high tables. Yet Boston is also a furnace of tireless technological innovation and clean, Scandinavian-influenced New England design.
            </p>
            <p>
              The Anglo-Futurist is the physical conduit of this relationship. We merge the heavy, industrial material honesty of Great Britain—solid iron griddles, dark oak, cast brass, and natural stone—with the expansive windows, natural light, and typographic minimalism of modern Massachusetts. It is an architecture of severe elegance.
            </p>
          </div>

          {/* Column Two */}
          <div className="space-y-6 text-justify">
            <h4 className="font-serif text-xl font-bold text-brand-brass mb-4">
              III. The Hearth and the Machine
            </h4>
            <p>
              At the center of our salon sits a solid, heavy steel hearth. This hearth represents the heart of the Industrial Revolution—it is a machine, but it is driven by fire, charcoal, and wood. We do not use gaseous heat to cook our meats. We char them over raw binchotan oak, drawing out the caramelized amino acids with architectural precision.
            </p>
            <p>
              We celebrate the regional makers of modern Britain: the potters in Yorkshire who throw clay rich in northern minerals; the weavers in Cornwall spinning heavyweight indigo denim; and the coopers in Scotland aging single-malts in heavy European sherry casks. This is not nostalgic tourism. This is living, breathing evolutionary craft.
            </p>

            <h4 className="font-serif text-xl font-bold text-brand-brass mt-8 mb-4">
              IV. Our Sovereign Promise
            </h4>
            <p>
              We promise an experience free from commercial hype. There are no gimmicks at our tables, no unearned flourishes on our plates. We treat each guest with the dignified, quiet composure that defines high hospitality. 
            </p>
            <p>
              Whether you gather in our Oak Room after a lecture on classical logic at Harvard, or join us at the Oyster Bar to toast a venture capital closing, you are participating in a sovereign movement. Welcome to the evolution of taste.
            </p>
          </div>

        </div>

        {/* Closing Seal */}
        <div className="border-t border-brand-brass/15 pt-12 mt-16 text-center">
          <div className="inline-flex flex-col items-center">
            <span className="font-serif text-xs uppercase tracking-[0.3em] font-bold text-brand-brass">
              Julian Sterling &bull; Chef Patron
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] opacity-60 mt-1">
              The Anglo-Futurist Hospitality Guild
            </span>
          </div>
        </div>

      </div>
    </section>
  );
}
