import React from 'react';
import { motion } from 'motion/react';
import { Award, Sparkles, ShieldCheck } from 'lucide-react';

interface PhilosophyProps {
  onManifestoClick: () => void;
  isDarkMode: boolean;
}

export default function Philosophy({ onManifestoClick, isDarkMode }: PhilosophyProps) {
  return (
    <section
      id="philosophy-section"
      className={`py-24 md:py-32 px-6 md:px-12 border-b transition-colors duration-500 ${
        isDarkMode ? 'bg-[#1D1D1D] border-brand-brass/10' : 'bg-[#F7F3EB] border-[#103B2E]/10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
          {/* Left Column: Evocative Luxury Photography */}
          <div className="lg:col-span-6 relative group overflow-hidden">
            {/* Elegant thin border enclosing the image */}
            <div className="absolute inset-4 border border-brand-brass/30 z-10 pointer-events-none transition-transform duration-700 group-hover:scale-95" />
            
            <img
              src="https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1000"
              alt="The Anglo-Futurist culinary craft plating"
              className="w-full h-[400px] md:h-[600px] object-cover filter brightness-[0.7] contrast-[1.1] transition-transform duration-1000 group-hover:scale-105"
            />
            
            {/* Absolute Badge */}
            <div className="absolute bottom-8 right-8 bg-[#103B2E] text-brand-stone p-6 flex flex-col items-start shadow-xl z-20">
              <span className="font-serif text-3xl font-medium tracking-wider text-brand-brass">EST. 2030</span>
              <span className="text-[9px] tracking-[0.3em] uppercase opacity-80 mt-1">Boston Seaport District</span>
            </div>
          </div>

          {/* Right Column: Editorial Copy */}
          <div className="lg:col-span-6 flex flex-col items-start">
            <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4">
              OUR PHILOSOPHY
            </span>
            
            <h2 className="font-serif text-3xl md:text-5xl lg:text-6xl tracking-wide font-medium leading-tight mb-8">
              We are not nostalgic. <br />
              We are evolutionary.
            </h2>

            <div className={`space-y-6 text-sm md:text-base leading-relaxed tracking-wide font-light ${
              isDarkMode ? 'text-brand-stone/80' : 'text-brand-charcoal/85'
            }`}>
              <p>
                British cuisine deserves to stand beside French, Japanese, and Italian cooking. For too long, the culinary heritage of the British Isles has been misunderstood or locked away in dusty pubs and nostalgic postcards.
              </p>
              
              <p className="font-serif text-lg md:text-xl italic text-brand-brass my-6 pl-4 border-l-2 border-brand-brass">
                "The Anglo-Futurist reinterprets Britain's culinary traditions through contemporary technique, exceptional local New England produce, and timeless, uncompromised hospitality."
              </p>

              <p>
                From the rugged Yorkshire moorlands to the deep waters of the North Sea and the historic ports of New England, we select ingredients with meticulous care. Our plates are architectural, our flavors precise, and our environment crafted for those who appreciate understated luxury.
              </p>
            </div>

            {/* Micro details / Badges */}
            <div className="grid grid-cols-2 gap-6 w-full pt-8 mt-8 border-t border-brand-brass/25">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-brand-brass/15 text-brand-brass rounded-none">
                  <Award size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-bold tracking-wider uppercase mb-1">Meticulous Craft</h4>
                  <p className="text-[11px] opacity-70">Aged meats, artisan baking, and hand-cut crystal.</p>
                </div>
              </div>

              <div className="flex items-start space-x-3">
                <div className="p-2 bg-brand-brass/15 text-brand-brass rounded-none">
                  <Sparkles size={18} />
                </div>
                <div>
                  <h4 className="text-xs font-bold tracking-wider uppercase mb-1">Local Sourcing</h4>
                  <p className="text-[11px] opacity-70">Vermont pasture-fed beef & Maine day-boat catches.</p>
                </div>
              </div>
            </div>

            <button
              id="read-manifesto-btn"
              onClick={onManifestoClick}
              className={`mt-10 text-xs tracking-[0.25em] font-medium border-b pb-2 uppercase transition-all duration-300 hover:text-brand-brass hover:border-brand-brass cursor-pointer ${
                isDarkMode ? 'border-brand-stone/30' : 'border-brand-charcoal/30'
              }`}
            >
              READ THE ANGLO-FUTURIST MANIFESTO &rarr;
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
