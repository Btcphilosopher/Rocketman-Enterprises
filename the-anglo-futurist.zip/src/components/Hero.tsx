import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, ArrowDown, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onReserveClick: () => void;
  onExploreClick: () => void;
  isDarkMode: boolean;
}

export default function Hero({ onReserveClick, onExploreClick, isDarkMode }: HeroProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Create soft lounge British jazz ambient track
    const audio = new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3'); // elegant instrumental
    audio.loop = true;
    audio.volume = 0.25; // elegant low background level
    audioRef.current = audio;

    return () => {
      audio.pause();
      audioRef.current = null;
    };
  }, []);

  const toggleAudio = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
    } else {
      audioRef.current.play().catch(err => console.log("Audio play blocked by browser", err));
    }
    setIsPlaying(!isPlaying);
  };

  return (
    <section
      id="hero-section"
      className="relative h-screen w-full flex items-center justify-center overflow-hidden"
    >
      {/* Background Media Panel */}
      <div className="absolute inset-0 z-0 bg-black">
        {/* Deep, luxurious overlay simulating dark glass, brass particles, and large glowing windows */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/35 to-[#101010] z-10" />
        
        {/* Parallax Panoramic Image: Luxury Anglo-Futurist restaurant glowing, Boston skyline outside */}
        <div 
          className="absolute inset-0 w-full h-full bg-cover bg-center bg-no-repeat scale-105 animate-[pulse_10s_infinite_alternate]"
          style={{
            backgroundImage: "url('https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1800')",
            filter: "brightness(0.4) contrast(1.15)"
          }}
        />

        {/* Floating subtle luxury lights to simulate guests arriving / glowing dining room */}
        <div className="absolute top-[30%] left-[20%] w-96 h-96 bg-brand-brass/10 blur-[120px] rounded-full animate-[pulse_6s_infinite]" />
        <div className="absolute bottom-[20%] right-[15%] w-80 h-80 bg-[#103B2E]/20 blur-[100px] rounded-full animate-[pulse_8s_infinite]" />
      </div>

      {/* Hero Content */}
      <div className="relative z-20 text-center px-6 max-w-4xl flex flex-col items-center justify-center">
        {/* Premium Eyebrow */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.2 }}
          className="flex items-center space-x-2 mb-6"
        >
          <span className="w-8 h-[1px] bg-brand-brass/60" />
          <span className="text-[10px] md:text-xs tracking-[0.4em] text-brand-brass font-semibold uppercase">
            A New Movement in New England Hospitality
          </span>
          <span className="w-8 h-[1px] bg-brand-brass/60" />
        </motion.div>

        {/* Main Monolithic Heading */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.5, ease: 'easeOut' }}
          className="font-serif text-5xl sm:text-7xl md:text-8xl lg:text-9xl tracking-[0.15em] font-medium leading-tight mb-4"
        >
          THE ANGLO-<br className="sm:hidden" />FUTURIST
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.6 }}
          className="text-serif italic text-lg sm:text-2xl md:text-3xl text-brand-cream/85 tracking-[0.05em] mb-12 max-w-2xl font-light"
        >
          The Best of Britain. Served in New England.
        </motion.p>

        {/* Primary Interactive CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.9 }}
          className="flex flex-col sm:flex-row items-center space-y-4 sm:space-y-0 sm:space-x-6"
        >
          <button
            id="hero-reserve-btn"
            onClick={onReserveClick}
            className="w-48 bg-brand-brass text-brand-charcoal text-xs tracking-[0.25em] py-4 uppercase font-bold border border-brand-brass transition-all duration-500 hover:bg-transparent hover:text-brand-stone hover:border-brand-stone cursor-pointer"
          >
            RESERVE TABLE
          </button>
          
          <button
            id="hero-menu-btn"
            onClick={onExploreClick}
            className="w-48 bg-transparent text-brand-stone text-xs tracking-[0.25em] py-4 uppercase font-medium border border-brand-stone/30 transition-all duration-500 hover:border-brand-brass hover:text-brand-brass cursor-pointer"
          >
            EXPLORE THE MENU
          </button>
        </motion.div>
      </div>

      {/* Floating Controls (Ambient Jazz and Scroll Down Indicators) */}
      <div className="absolute bottom-10 left-6 md:left-12 z-20 flex items-center space-x-3">
        <button
          id="ambient-audio-toggle"
          onClick={toggleAudio}
          className={`p-3 rounded-full border transition-all duration-300 flex items-center justify-center cursor-pointer group ${
            isPlaying 
              ? 'bg-brand-brass text-brand-charcoal border-brand-brass' 
              : 'border-brand-stone/20 text-brand-stone hover:border-brand-brass hover:text-brand-brass'
          }`}
          title={isPlaying ? "Mute Ambient Jazz" : "Unmute Ambient Jazz"}
        >
          {isPlaying ? <Volume2 size={16} /> : <VolumeX size={16} />}
        </button>
        <span className="text-[9px] tracking-[0.25em] text-brand-stone/60 uppercase select-none hidden sm:inline">
          {isPlaying ? "Playing: Atmospheric Jazz Loop" : "Ambient Audio Off"}
        </span>
      </div>

      <div className="absolute bottom-10 right-6 md:right-12 z-20 hidden md:flex flex-col items-center space-y-2 select-none">
        <span className="text-[9px] tracking-[0.3em] text-brand-stone/40 uppercase rotate-90 origin-right translate-y-6">
          SCROLL
        </span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 2 }}
          className="text-brand-brass/75 mt-8"
        >
          <ArrowDown size={14} />
        </motion.div>
      </div>
    </section>
  );
}
