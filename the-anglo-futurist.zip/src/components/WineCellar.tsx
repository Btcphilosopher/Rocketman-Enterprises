import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { WINES } from '../data';
import { WineCellarItem } from '../types';
import { Wine, Award, MapPin, Sparkles, HelpCircle } from 'lucide-react';

interface WineCellarProps {
  onConsultSommelier: (dishName: string, winePairing: string) => void;
  isDarkMode: boolean;
}

export default function WineCellar({ onConsultSommelier, isDarkMode }: WineCellarProps) {
  const [selectedRegion, setSelectedRegion] = useState<string>('England');

  const regions = ['England', 'France', 'Italy', 'Spain', 'California', 'Australia'];
  
  const filteredWines = WINES.filter((w) => w.region === selectedRegion);

  const handleWineInquiry = (wineName: string) => {
    onConsultSommelier("a selection from our cellar", `specifically the ${wineName}`);
  };

  return (
    <section
      id="wine-cellar-section"
      className={`py-24 md:py-32 px-6 md:px-12 border-b transition-colors duration-500 ${
        isDarkMode ? 'bg-[#101010] border-brand-brass/10' : 'bg-[#FAF8F4] border-[#103B2E]/10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Editorial Heading */}
        <div className="max-w-3xl mb-16">
          <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4 block">
            THE PRIVATE LIQUID ARCHIVE
          </span>
          <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium mb-6">
            The Animated Wine Cellar
          </h2>
          <p className={`text-sm md:text-base font-light tracking-wide leading-relaxed ${
            isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/65'
          }`}>
            A climate-controlled vault framing the finest architectural achievements in viticulture. Our selection represents a deliberate balance of historic continental terroirs and Britain's revolutionary cool-climate sparkling wines.
          </p>
        </div>

        {/* Region Board */}
        <div className="flex flex-wrap items-center gap-2 md:gap-4 mb-16 border-b border-brand-brass/10 pb-6">
          {regions.map((reg) => (
            <button
              key={reg}
              id={`wine-region-tab-${reg.toLowerCase()}`}
              onClick={() => setSelectedRegion(reg)}
              className={`text-xs md:text-sm tracking-[0.2em] py-3 px-4 font-medium relative transition-colors cursor-pointer ${
                selectedRegion === reg
                  ? 'text-brand-brass font-bold'
                  : 'text-current/60 hover:text-brand-brass'
              }`}
            >
              {reg.toUpperCase()}
              {selectedRegion === reg && (
                <motion.div
                  layoutId="activeWineIndicator"
                  className="absolute bottom-0 left-0 w-full h-[2px] bg-brand-brass"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Dynamic Display Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Interactive Region Showcase Banner */}
          <div className="lg:col-span-4 relative group">
            <div className="absolute inset-4 border border-brand-brass/25 z-10 pointer-events-none" />
            <div className="relative h-[300px] lg:h-[450px] w-full bg-brand-charcoal overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?q=80&w=800"
                alt="Anglo Futurist Premium Wine Cellar"
                className="w-full h-full object-cover filter brightness-[0.5] contrast-[1.15] transition-transform duration-1000 group-hover:scale-105"
              />
              {/* Region Label Overlay */}
              <div className="absolute inset-0 flex flex-col justify-end p-8 z-20 text-white">
                <span className="text-[10px] tracking-[0.3em] text-brand-brass uppercase font-bold mb-2">
                  EXPLORING TERROIR
                </span>
                <h3 className="font-serif text-3xl md:text-4xl tracking-wide font-medium">
                  {selectedRegion}
                </h3>
                <p className="text-[11px] text-brand-stone/70 tracking-wide font-light mt-2 leading-relaxed">
                  {selectedRegion === 'England' && 'Chalk-rich Hampshire downs and warm southern soils yielding award-winning, mineral-forward luxury sparklings.'}
                  {selectedRegion === 'France' && 'Iconic limestone slopes of Burgundy and classic estate-bottled châteaux from the heart of Bordeaux.'}
                  {selectedRegion === 'Italy' && 'Aristocratic Nebbiolos from Piedmont’s alpine mists and robust, complex Tuscan Sangiovese reserves.'}
                  {selectedRegion === 'Spain' && 'Aged oak masterpieces from Rioja, rich in leather, tobacco, and caramelized wild forest fruits.'}
                  {selectedRegion === 'California' && 'Saline oceanic mists meeting hot valleys to yield opulent, deeply concentrated premium Chardonnays.'}
                  {selectedRegion === 'Australia' && 'Deep iron-stone soils of Barossa and ancient Syrah vines producing heavy, ink-dark monumental reds.'}
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: List of Curated Vintages */}
          <div className="lg:col-span-8 space-y-6">
            <AnimatePresence mode="popLayout">
              {filteredWines.map((wine) => (
                <motion.div
                  key={wine.id}
                  id={`wine-cellar-card-${wine.id}`}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4 }}
                  className={`p-6 border transition-all duration-300 ${
                    isDarkMode 
                      ? 'bg-[#1D1D1D] border-brand-brass/10 hover:border-brand-brass/30' 
                      : 'bg-[#F7F3EB] border-[#103B2E]/5 hover:border-brand-brass/30'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-brand-brass/15 text-brand-brass rounded-none">
                        <Wine size={18} />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <span className="text-[10px] tracking-wider px-2 py-0.5 border border-brand-brass/25 text-brand-brass uppercase font-bold">
                            {wine.vintage} Vintage
                          </span>
                          <span className={`text-[9px] tracking-widest uppercase font-semibold opacity-75`}>
                            {wine.type}
                          </span>
                        </div>
                        <h4 className="font-serif text-xl md:text-2xl font-medium tracking-wide mt-1">
                          {wine.name}
                        </h4>
                      </div>
                    </div>

                    <div className="flex items-baseline space-x-2 text-brand-brass pl-11 md:pl-0">
                      <span className="text-xs uppercase tracking-widest opacity-60">Bottle</span>
                      <span className="font-serif text-2xl font-bold">${wine.price}</span>
                    </div>
                  </div>

                  <div className="pl-11 border-l border-brand-brass/15 space-y-3">
                    <p className={`text-xs md:text-sm font-light leading-relaxed ${
                      isDarkMode ? 'text-brand-stone/70' : 'text-brand-charcoal/80'
                    }`}>
                      {wine.description}
                    </p>
                    
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-3 border-t border-brand-brass/5">
                      <p className="text-xs font-serif italic text-brand-brass opacity-95">
                        <span className="font-sans font-bold text-[9px] tracking-wider uppercase block not-italic opacity-60">Pairing Recommendation</span>
                        {wine.pairingNote}
                      </p>
                      
                      <button
                        id={`ask-sommelier-wine-${wine.id}`}
                        onClick={() => handleWineInquiry(wine.name)}
                        className="self-start sm:self-center shrink-0 flex items-center space-x-2 text-[10px] tracking-[0.2em] bg-brand-brass/15 text-brand-brass border border-brand-brass/20 py-2 px-3 uppercase transition-all hover:bg-brand-brass hover:text-brand-charcoal font-bold cursor-pointer"
                      >
                        <HelpCircle size={12} />
                        <span>ASK SOMMELIER</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </section>
  );
}
