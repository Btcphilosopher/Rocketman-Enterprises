import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { COCKTAILS } from '../data';
import { ChevronRight, ChevronLeft, ArrowRight } from 'lucide-react';

interface CocktailCarouselProps {
  isDarkMode: boolean;
}

export default function CocktailCarousel({ isDarkMode }: CocktailCarouselProps) {
  const [index, setIndex] = useState(0);

  const prev = () => {
    setIndex((prevIndex) => (prevIndex === 0 ? COCKTAILS.length - 1 : prevIndex - 1));
  };

  const next = () => {
    setIndex((prevIndex) => (prevIndex === COCKTAILS.length - 1 ? 0 : prevIndex + 1));
  };

  const current = COCKTAILS[index];

  return (
    <section
      id="cocktail-section"
      className={`py-24 md:py-32 px-6 md:px-12 transition-colors duration-500 overflow-hidden ${
        isDarkMode ? 'bg-[#1D1D1D]' : 'bg-[#F7F3EB]'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Title Block */}
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4 block">
              THE DISPENSARY
            </span>
            <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium">
              Anglo-Futurist Mixology
            </h2>
          </div>
          <p className={`max-w-md text-sm font-light tracking-wide ${
            isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/65'
          }`}>
            Traditional British botanicals and single malts bridged elegantly with the spirits, ciders, and herbs of the historic New England coastline.
          </p>
        </div>

        {/* Interactive Carousel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative">
          
          {/* Left Column: Big Graphic Imagery */}
          <div className="lg:col-span-6 relative">
            <div className="absolute inset-4 border border-brand-brass/20 z-10 pointer-events-none" />
            <div className="relative h-[400px] md:h-[500px] w-full overflow-hidden bg-brand-charcoal">
              <AnimatePresence mode="wait">
                <motion.img
                  key={current.id}
                  src={current.image}
                  alt={current.name}
                  initial={{ opacity: 0, scale: 1.05 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  transition={{ duration: 0.8 }}
                  className="w-full h-full object-cover filter brightness-[0.7] contrast-[1.1]"
                />
              </AnimatePresence>
            </div>

            {/* Slider Navigation Buttons */}
            <div className="absolute bottom-6 right-6 z-20 flex space-x-2">
              <button
                id="cocktail-prev-btn"
                onClick={prev}
                className="p-3 bg-brand-charcoal border border-brand-brass/20 text-brand-brass hover:bg-brand-brass hover:text-brand-charcoal transition-all duration-300 cursor-pointer"
              >
                <ChevronLeft size={16} />
              </button>
              <button
                id="cocktail-next-btn"
                onClick={next}
                className="p-3 bg-brand-charcoal border border-brand-brass/20 text-brand-brass hover:bg-brand-brass hover:text-brand-charcoal transition-all duration-300 cursor-pointer"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>

          {/* Right Column: Detailed Botanical Copy */}
          <div className="lg:col-span-6 flex flex-col items-start lg:pl-6 justify-center">
            <AnimatePresence mode="wait">
              <motion.div
                key={current.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.5 }}
                className="space-y-6 w-full"
              >
                {/* Micro Category */}
                <div className="flex items-center space-x-4">
                  <span className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase">
                    GLASSWARE: {current.glassware}
                  </span>
                  <span className="w-1.5 h-1.5 bg-brand-brass rounded-full" />
                  <span className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase">
                    ${current.price}
                  </span>
                </div>

                {/* Cocktail Name */}
                <h3 className="font-serif text-3xl md:text-5xl tracking-wide font-medium">
                  {current.name}
                </h3>

                {/* Description */}
                <p className={`text-sm md:text-base leading-relaxed tracking-wide font-light ${
                  isDarkMode ? 'text-brand-stone/80' : 'text-brand-charcoal/85'
                }`}>
                  {current.description}
                </p>

                {/* Ingredients Chipset */}
                <div>
                  <h4 className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase mb-3">
                    Ingredients Blueprint
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {current.ingredients.map((ing) => (
                      <span
                        key={ing}
                        className={`text-xs tracking-wider px-3 py-1.5 border ${
                          isDarkMode 
                            ? 'border-brand-stone/15 text-brand-stone/85 bg-[#252525]' 
                            : 'border-brand-charcoal/15 text-brand-charcoal/85 bg-white'
                        }`}
                      >
                        {ing}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Origin Narrative */}
                <div className="border-t border-brand-brass/10 pt-6">
                  <h4 className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase mb-2">
                    Heritage Origin Story
                  </h4>
                  <p className="font-serif italic text-sm opacity-90 leading-relaxed">
                    "{current.originStory}"
                  </p>
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Slider Dots */}
            <div className="flex items-center space-x-2 mt-10">
              {COCKTAILS.map((c, i) => (
                <button
                  key={c.id}
                  id={`cocktail-dot-${i}`}
                  onClick={() => setIndex(i)}
                  className={`h-1.5 transition-all duration-300 cursor-pointer ${
                    index === i ? 'w-8 bg-brand-brass' : 'w-2 bg-brand-brass/25 hover:bg-brand-brass/55'
                  }`}
                />
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
