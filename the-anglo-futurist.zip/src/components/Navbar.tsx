import React, { useState, useEffect } from 'react';
import { Menu, X, Wine, ShoppingBag, MessageSquare, Sun, Moon, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  onNavClick: (view: 'home' | 'menu' | 'wine' | 'private-dining' | 'manifesto' | 'events' | 'store') => void;
  currentView: string;
  cartCount: number;
  onCartToggle: () => void;
  onReservationToggle: () => void;
  onAIChatToggle: () => void;
  isDarkMode: boolean;
  onThemeToggle: () => void;
}

export default function Navbar({
  onNavClick,
  currentView,
  cartCount,
  onCartToggle,
  onReservationToggle,
  onAIChatToggle,
  isDarkMode,
  onThemeToggle
}: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'THE JOURNAL' },
    { id: 'menu', label: 'THE MENU' },
    { id: 'wine', label: 'THE CELLAR' },
    { id: 'private-dining', label: 'PRIVATE SALONS' },
    { id: 'events', label: 'EVENTS' },
    { id: 'manifesto', label: 'MANIFESTO' },
    { id: 'store', label: 'STORE' }
  ];

  const handleItemClick = (id: 'home' | 'menu' | 'wine' | 'private-dining' | 'manifesto' | 'events' | 'store') => {
    onNavClick(id);
    setIsOpen(false);
  };

  return (
    <nav
      id="main-nav"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 border-b ${
        scrolled
          ? isDarkMode
            ? 'bg-[#101010]/95 backdrop-blur-md border-brand-brass/15 py-4'
            : 'bg-[#FAF8F4]/95 backdrop-blur-md border-[#103B2E]/10 py-4'
          : 'bg-transparent border-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
        {/* Logo/Identity */}
        <button
          id="logo-btn"
          onClick={() => handleItemClick('home')}
          className="flex flex-col items-start cursor-pointer group"
        >
          <span className="font-serif text-xl md:text-2xl tracking-[0.2em] font-medium transition-colors duration-300">
            THE ANGLO-FUTURIST
          </span>
          <span className="text-[9px] tracking-[0.4em] text-brand-brass uppercase opacity-80 group-hover:opacity-100 transition-opacity">
            BOSTON &bull; LONDON
          </span>
        </button>

        {/* Desktop Menu */}
        <div className="hidden lg:flex items-center space-x-8">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`nav-item-${item.id}`}
              onClick={() => handleItemClick(item.id as any)}
              className={`text-xs tracking-[0.2em] font-medium cursor-pointer relative py-1 transition-all hover:text-brand-brass ${
                currentView === item.id 
                  ? 'text-brand-brass' 
                  : isDarkMode ? 'text-brand-stone/80' : 'text-brand-charcoal/80'
              }`}
            >
              {item.label}
              {currentView === item.id && (
                <motion.div
                  layoutId="activeIndicator"
                  className="absolute bottom-0 left-0 w-full h-[1px] bg-brand-brass"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="hidden md:flex items-center space-x-6">
          {/* Theme Toggle */}
          <button
            id="theme-toggle-btn"
            onClick={onThemeToggle}
            className={`p-2 rounded-full border transition-all cursor-pointer ${
              isDarkMode 
                ? 'border-brand-brass/20 text-brand-brass hover:bg-brand-brass/10' 
                : 'border-brand-green/20 text-brand-green hover:bg-brand-green/10'
            }`}
            title={isDarkMode ? 'Bright Salon Mode' : 'Classic Evening Mode'}
          >
            {isDarkMode ? <Sun size={15} /> : <Moon size={15} />}
          </button>

          {/* Reservation Button */}
          <button
            id="nav-reserve-btn"
            onClick={onReservationToggle}
            className={`flex items-center space-x-2 text-xs tracking-[0.15em] font-medium border px-4 py-2 uppercase transition-all duration-300 cursor-pointer ${
              isDarkMode
                ? 'border-brand-brass/40 text-brand-stone hover:bg-brand-brass hover:text-brand-charcoal hover:border-brand-brass'
                : 'border-brand-green/40 text-brand-green hover:bg-brand-green hover:text-brand-stone hover:border-brand-green'
            }`}
          >
            <Calendar size={13} />
            <span>RESERVE</span>
          </button>

          {/* AI Concierge Shortcut */}
          <button
            id="nav-ai-btn"
            onClick={onAIChatToggle}
            className="flex items-center space-x-2 text-xs tracking-[0.15em] font-medium bg-brand-brass text-brand-charcoal px-4 py-2 uppercase transition-all duration-300 hover:bg-brand-brass/90 cursor-pointer"
          >
            <MessageSquare size={13} />
            <span>AI CONCIERGE</span>
          </button>

          {/* Shopping Cart button */}
          <button
            id="nav-cart-btn"
            onClick={onCartToggle}
            className="relative p-2 cursor-pointer group"
          >
            <ShoppingBag size={18} className="transition-colors hover:text-brand-brass" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-brass text-brand-charcoal text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>
        </div>

        {/* Mobile Control Bar */}
        <div className="flex lg:hidden items-center space-x-4">
          <button
            id="mobile-cart-btn"
            onClick={onCartToggle}
            className="relative p-2"
          >
            <ShoppingBag size={18} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-brand-brass text-brand-charcoal text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                {cartCount}
              </span>
            )}
          </button>

          <button
            id="mobile-menu-btn"
            onClick={() => setIsOpen(!isOpen)}
            className="p-2 transition-colors duration-300 hover:text-brand-brass"
          >
            {isOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="mobile-nav-drawer"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className={`absolute top-full left-0 w-full border-b flex flex-col px-6 py-8 space-y-6 z-40 ${
              isDarkMode 
                ? 'bg-[#101010]/98 border-brand-brass/10' 
                : 'bg-[#FAF8F4]/98 border-[#103B2E]/10'
            }`}
          >
            <div className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  id={`mobile-nav-item-${item.id}`}
                  onClick={() => handleItemClick(item.id as any)}
                  className={`text-left text-sm tracking-[0.25em] py-2 font-medium border-b border-dashed transition-colors ${
                    currentView === item.id 
                      ? 'text-brand-brass border-brand-brass/25' 
                      : 'border-transparent text-current/80'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap gap-4 pt-4 border-t border-brand-brass/10">
              <button
                id="mobile-theme-btn"
                onClick={onThemeToggle}
                className="flex items-center space-x-2 text-xs tracking-[0.15em] border px-4 py-3 uppercase rounded-none w-full justify-center"
              >
                {isDarkMode ? <Sun size={14} /> : <Moon size={14} />}
                <span>{isDarkMode ? 'BRIGHT SALON MODE' : 'CLASSIC EVENING MODE'}</span>
              </button>

              <button
                id="mobile-reserve-btn"
                onClick={() => {
                  onReservationToggle();
                  setIsOpen(false);
                }}
                className="flex items-center space-x-2 text-xs tracking-[0.15em] border px-4 py-3 uppercase rounded-none w-full justify-center"
              >
                <Calendar size={14} />
                <span>BOOK TABLE</span>
              </button>

              <button
                id="mobile-ai-btn"
                onClick={() => {
                  onAIChatToggle();
                  setIsOpen(false);
                }}
                className="flex items-center space-x-2 text-xs tracking-[0.15em] bg-brand-brass text-brand-charcoal px-4 py-3 uppercase rounded-none w-full justify-center font-bold"
              >
                <MessageSquare size={14} />
                <span>CONSULT AI CONCIERGE</span>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
