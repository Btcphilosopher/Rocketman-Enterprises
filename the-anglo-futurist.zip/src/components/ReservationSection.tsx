import React, { useState, useEffect } from 'react';
import { Calendar, Users, Clock, Mail, Phone, Bell, Check, Trash2, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Reservation } from '../types';

interface ReservationSectionProps {
  isDarkMode: boolean;
}

export default function ReservationSection({ isDarkMode }: ReservationSectionProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [partySize, setPartySize] = useState(2);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('7:30 PM');
  const [notes, setNotes] = useState('');
  const [smsReminders, setSmsReminders] = useState(true);
  
  const [submitting, setSubmitting] = useState(false);
  const [successReservation, setSuccessReservation] = useState<Reservation | null>(null);
  const [pastBookings, setPastBookings] = useState<Reservation[]>([]);

  const timeslots = [
    '5:30 PM', '6:00 PM', '6:30 PM', '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM', '9:00 PM', '9:30 PM'
  ];

  // Fetch past bookings on mount or updates
  const fetchBookings = async () => {
    try {
      const res = await fetch('/api/reservations');
      const data = await res.json();
      if (Array.isArray(data)) {
        setPastBookings(data);
      }
    } catch (err) {
      console.error("Error fetching bookings:", err);
    }
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || !date || !time) return;

    setSubmitting(true);
    try {
      const response = await fetch('/api/reservations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          email,
          phone,
          partySize,
          date,
          time,
          notes: notes + (smsReminders ? ' (SMS Reminders active)' : '')
        })
      });

      const data = await response.json();
      if (data.success) {
        setSuccessReservation(data.reservation);
        fetchBookings();
        // Reset form
        setName('');
        setEmail('');
        setPhone('');
        setNotes('');
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section
      id="reservations-section"
      className={`py-24 md:py-32 px-6 md:px-12 transition-colors duration-500 ${
        isDarkMode ? 'bg-[#101010]' : 'bg-[#FAF8F4]'
      }`}
    >
      <div className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-start">
          
          {/* Left Column: Explanatory Copy & Rules */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-24">
            <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-2 block">
              SECURE AN ENGAGEMENT
            </span>
            <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl tracking-wide font-medium leading-tight">
              Table Reservations
            </h2>
            <p className={`text-sm leading-relaxed font-light ${
              isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/70'
            }`}>
              Reservations are released precisely on the first day of each calendar month for the subsequent month. We accommodate walk-ins at the Oyster Bar strictly on a first-come, first-served basis.
            </p>

            <div className="border-t border-brand-brass/15 pt-6 space-y-4">
              <div>
                <h4 className="text-xs font-bold tracking-widest uppercase mb-1">Dress Code Policy</h4>
                <p className="text-xs opacity-70">Smart elegant / business casual. We request that gentlemen refrain from wearing open-toed shoes, sportswear, or active headwear.</p>
              </div>

              <div>
                <h4 className="text-xs font-bold tracking-widest uppercase mb-1">Cancellation Protocol</h4>
                <p className="text-xs opacity-70">Cancellations or party amendments must be processed at least 24 hours in advance to avoid a reservation release fee.</p>
              </div>

              <div>
                <h4 className="text-xs font-bold tracking-widest uppercase mb-1">OpenTable & SMS Systems</h4>
                <p className="text-xs opacity-70">Our table allocation uses a real-time smart integration. You will receive an immediate SMS text confirmation and an email pass.</p>
              </div>
            </div>
          </div>

          {/* Right Column: Reservation form or success screen */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              {successReservation ? (
                <motion.div
                  key="success-card"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className={`p-8 border border-brand-brass relative text-center space-y-6 ${
                    isDarkMode ? 'bg-[#1D1D1D]' : 'bg-[#F7F3EB]'
                  }`}
                >
                  <div className="w-16 h-16 bg-brand-brass/10 border border-brand-brass text-brand-brass rounded-full flex items-center justify-center mx-auto mb-4 animate-[pulse_2s_infinite]">
                    <Check size={28} />
                  </div>
                  
                  <span className="text-[10px] tracking-[0.3em] font-bold text-brand-brass uppercase block">
                    CONFIRMED ENGAGEMENT
                  </span>

                  <h3 className="font-serif text-3xl md:text-4xl font-medium tracking-wide">
                    Your Table Awaits
                  </h3>

                  <div className="border-y border-brand-brass/10 py-6 my-4 space-y-3 text-xs tracking-wider max-w-sm mx-auto">
                    <div className="flex justify-between">
                      <span className="opacity-60">REFERENCE:</span>
                      <span className="font-bold text-brand-brass">{successReservation.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="opacity-60">NAME:</span>
                      <span className="font-bold">{successReservation.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="opacity-60">PARTY SIZE:</span>
                      <span className="font-bold">{successReservation.partySize} Guests</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="opacity-60">DATE & TIME:</span>
                      <span className="font-bold text-brand-brass">{successReservation.date} &bull; {successReservation.time}</span>
                    </div>
                  </div>

                  <p className="text-xs opacity-80 leading-relaxed max-w-sm mx-auto">
                    An SMS confirmation has been dispatched. For specialized dining instructions or menu dietary needs, consult our AI concierge in the sidebar.
                  </p>

                  <button
                    id="new-booking-btn"
                    onClick={() => setSuccessReservation(null)}
                    className="bg-brand-brass text-brand-charcoal text-xs tracking-[0.2em] font-bold py-3 px-6 uppercase transition-all hover:bg-brand-brass/90 cursor-pointer"
                  >
                    BOOK ANOTHER TABLE
                  </button>
                </motion.div>
              ) : (
                <motion.div
                  key="booking-form"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className={`p-8 border ${
                    isDarkMode ? 'bg-[#1D1D1D] border-brand-brass/10' : 'bg-[#F7F3EB] border-[#103B2E]/10'
                  }`}
                >
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <h3 className="font-serif text-2xl md:text-3xl font-medium tracking-wide border-b border-brand-brass/15 pb-4">
                      Reservation Particulars
                    </h3>

                    {/* Inputs */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                          Full Name
                        </label>
                        <input
                          id="booking-name-input"
                          type="text"
                          required
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="e.g. Professor Thomas Sterling"
                          className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                            isDarkMode ? 'bg-[#101010] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                          }`}
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                          Email Address
                        </label>
                        <input
                          id="booking-email-input"
                          type="email"
                          required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="e.g. tom@ahyx.org"
                          className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                            isDarkMode ? 'bg-[#101010] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div>
                        <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                          Telephone / SMS
                        </label>
                        <input
                          id="booking-phone-input"
                          type="tel"
                          required
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          placeholder="+1 (617) 555-1776"
                          className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                            isDarkMode ? 'bg-[#101010] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                          }`}
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                          Party Size
                        </label>
                        <select
                          id="booking-size-select"
                          value={partySize}
                          onChange={(e) => setPartySize(Number(e.target.value))}
                          className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                            isDarkMode ? 'bg-[#101010] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                          }`}
                        >
                          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                            <option key={num} value={num}>
                              {num} {num === 1 ? 'Guest' : 'Guests'}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                          Calendar Date
                        </label>
                        <input
                          id="booking-date-input"
                          type="date"
                          required
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                            isDarkMode ? 'bg-[#101010] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                          }`}
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                        Preferential Dinner Hour
                      </label>
                      <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                        {timeslots.map((slot) => (
                          <button
                            key={slot}
                            id={`timeslot-${slot.replace(' ', '-').replace(':', '-')}`}
                            type="button"
                            onClick={() => setTime(slot)}
                            className={`text-xs py-2 border transition-all cursor-pointer ${
                              time === slot
                                ? 'bg-brand-brass border-brand-brass text-brand-charcoal font-bold'
                                : isDarkMode
                                  ? 'border-brand-stone/10 text-brand-stone/60 hover:border-brand-brass hover:text-brand-brass'
                                  : 'border-brand-green/10 text-brand-charcoal/60 hover:border-brand-brass hover:text-brand-brass'
                            }`}
                          >
                            {slot}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] tracking-widest font-bold uppercase mb-2 opacity-80">
                        Special Directives / Anniversaries / Requests
                      </label>
                      <textarea
                        id="booking-notes-textarea"
                        rows={3}
                        value={notes}
                        onChange={(e) => setNotes(e.target.value)}
                        placeholder="e.g. Window table with Seaport harbor views, food intolerances..."
                        className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass resize-none ${
                          isDarkMode ? 'bg-[#101010] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                        }`}
                      />
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        id="booking-sms-checkbox"
                        type="checkbox"
                        checked={smsReminders}
                        onChange={(e) => setSmsReminders(e.target.checked)}
                        className="accent-brand-brass cursor-pointer"
                      />
                      <span className="text-xs opacity-80 flex items-center space-x-1.5">
                        <Bell size={12} className="text-brand-brass" />
                        <span>Enlist for SMS reminders & instant digital reservation passes.</span>
                      </span>
                    </div>

                    <button
                      id="booking-submit-btn"
                      type="submit"
                      disabled={submitting}
                      className="w-full bg-brand-brass text-brand-charcoal text-xs tracking-[0.25em] py-4 uppercase font-bold transition-all hover:bg-brand-brass/90 flex items-center justify-center space-x-2 disabled:opacity-55 cursor-pointer"
                    >
                      <span>{submitting ? 'ENGAGING SYSTEM...' : 'CONFIRM IMMEDATE ENGAGEMENT'}</span>
                      <ArrowRight size={14} />
                    </button>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>

            {/* In-Memory Booking Confirmation List */}
            {pastBookings.length > 0 && (
              <div className="mt-8">
                <h4 className="text-[10px] tracking-[0.3em] text-brand-brass font-bold uppercase mb-4">
                  Currently Logged Bookings
                </h4>
                <div className="space-y-3">
                  {pastBookings.map((b) => (
                    <div
                      key={b.id}
                      id={`confirmed-booking-${b.id}`}
                      className={`p-4 border flex items-center justify-between text-xs font-mono ${
                        isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/10' : 'bg-white border-[#103B2E]/10'
                      }`}
                    >
                      <div className="space-y-1">
                        <p className="font-bold font-sans text-brand-brass">{b.name}</p>
                        <p className="text-[10px] opacity-70">
                          {b.date} at {b.time} &bull; {b.partySize} guests
                        </p>
                      </div>
                      <span className="bg-[#103B2E] text-brand-stone text-[9px] px-2 py-0.5 uppercase tracking-widest font-sans font-bold">
                        {b.id} Confirmed
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
