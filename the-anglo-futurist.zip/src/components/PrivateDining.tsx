import React, { useState } from 'react';
import { Calendar, Users, Wine, Clock, Sparkles, MessageSquare, Send, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface PrivateDiningProps {
  isDarkMode: boolean;
}

export default function PrivateDining({ isDarkMode }: PrivateDiningProps) {
  const [occasion, setOccasion] = useState('Corporate Boardroom Dinner');
  const [guests, setGuests] = useState('16');
  const [room, setRoom] = useState('The Oak Room');
  const [customDetails, setCustomDetails] = useState(
    'A highly formal dinner honoring visiting academic lecturers from Harvard Philosophy and London School of Economics. They prefer fine whisky and classic dry-aged beef.'
  );
  const [loading, setLoading] = useState(false);
  const [proposal, setProposal] = useState<string | null>(null);

  const rooms = [
    {
      name: 'The Oak Room',
      capacity: '12 - 18 Guests',
      atmosphere: 'Deep English oak paneling, historic oil paintings, brass candleholders, and high-table high-backed chairs. Built for intimate high-influence dining.',
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800'
    },
    {
      name: 'The Cambridge Library',
      capacity: '20 - 45 Guests',
      atmosphere: 'Floor-to-ceiling shelves housing rare first-editions, a roaring stone fireplace, Chesterfield leather sofas, and velvet curtains. Perfect for salons and debates.',
      image: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=800'
    },
    {
      name: 'The Boston Glasshouse',
      capacity: '50 - 120 Guests',
      atmosphere: 'Panoramic glass structure cantilevered over the Boston Seaport. Frames the harbor skyline at sunset. Ideal for corporate entertaining, weddings, and galas.',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?q=80&w=800'
    }
  ];

  const handleGenerateProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setProposal(null);

    const messageContent = `I am planning a private event. Here are the details:
- Occasion: ${occasion}
- Number of guests: ${guests}
- Preferred private room: ${room}
- Special requests and notes: ${customDetails}

Please generate a highly professional, bespoke event itinerary, custom dining menu (including wine and cocktail matches), and room configuration proposal matching the level of a Michelin-starred service.`;

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: messageContent,
          specialist: 'planner'
        })
      });
      const data = await response.json();
      if (data.text) {
        setProposal(data.text);
      } else {
        setProposal("My apologies, but our private dining curator is currently fine-tuning a banquet in the other room. Please try again shortly.");
      }
    } catch (err) {
      console.error(err);
      setProposal("An error occurred. Our booking office is offline, but we await your dispatch.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <section
      id="private-dining-section"
      className={`py-24 md:py-32 px-6 md:px-12 border-b transition-colors duration-500 ${
        isDarkMode ? 'bg-[#1D1D1D] border-brand-brass/10' : 'bg-[#FAF8F4] border-[#103B2E]/10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Header block */}
        <div className="text-center mb-20">
          <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4 block">
            THE PRIVATE SALONS
          </span>
          <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium mb-6">
            Luxury Dining & Academic Salons
          </h2>
          <p className={`max-w-2xl mx-auto text-sm md:text-base font-light tracking-wide ${
            isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/65'
          }`}>
            We provide a sanctuary for Boston's business leaders, innovators, and academic faculty. Our private salons are architectural masterpieces engineered for confidentiality and memorable hospitality.
          </p>
        </div>

        {/* Room Showcase Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-24">
          {rooms.map((rm) => (
            <div
              key={rm.name}
              id={`room-card-${rm.name.toLowerCase().replace(' ', '-')}`}
              className={`border transition-all duration-500 flex flex-col group ${
                isDarkMode ? 'bg-[#101010] border-brand-brass/10 hover:border-brand-brass/25' : 'bg-[#F7F3EB] border-[#103B2E]/5 hover:border-brand-brass/25'
              }`}
            >
              <div className="h-56 overflow-hidden relative">
                <img
                  src={rm.image}
                  alt={rm.name}
                  className="w-full h-full object-cover filter brightness-[0.7] group-hover:scale-105 transition-transform duration-1000"
                />
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-serif text-xl md:text-2xl font-medium tracking-wide">
                      {rm.name}
                    </h3>
                    <span className="text-xs font-semibold px-3 py-1 bg-brand-brass/15 text-brand-brass tracking-wider">
                      {rm.capacity}
                    </span>
                  </div>
                  <p className={`text-xs md:text-sm font-light leading-relaxed ${
                    isDarkMode ? 'text-brand-stone/70' : 'text-brand-charcoal/80'
                  }`}>
                    {rm.atmosphere}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* AI Proposal Generator Split Screen */}
        <div className={`border p-8 md:p-12 ${
          isDarkMode ? 'bg-[#101010] border-brand-brass/15' : 'bg-[#F7F3EB] border-[#103B2E]/10'
        }`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Form Column */}
            <div className="lg:col-span-5 space-y-6">
              <div className="flex items-center space-x-2 text-brand-brass">
                <Sparkles size={16} />
                <span className="text-[10px] tracking-[0.3em] font-bold uppercase">
                  BESPOKE EVENT CURATOR
                </span>
              </div>
              
              <h3 className="font-serif text-2xl md:text-3xl font-medium tracking-wide">
                Plan with AI Victoria
              </h3>
              
              <p className={`text-xs leading-relaxed ${
                isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/70'
              }`}>
                Input your event requirements. Our Private Events Director, Victoria (powered by Gemini AI), will curate a custom menu, seating arrangements, and wine pairing proposals instantly.
              </p>

              <form onSubmit={handleGenerateProposal} className="space-y-4">
                <div>
                  <label className="block text-[10px] tracking-widest font-bold uppercase mb-1.5 opacity-80">
                    Event Occasion
                  </label>
                  <select
                    id="event-occasion-select"
                    value={occasion}
                    onChange={(e) => setOccasion(e.target.value)}
                    className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                      isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                    }`}
                  >
                    <option>Corporate Boardroom Dinner</option>
                    <option>Harvard Philosophy Department Salon</option>
                    <option>MIT Tech Innovation Gala</option>
                    <option>Upscale Wedding Reception</option>
                    <option>Private Birthday Churchill Dinner</option>
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] tracking-widest font-bold uppercase mb-1.5 opacity-80">
                      Guests
                    </label>
                    <input
                      id="event-guests-input"
                      type="number"
                      value={guests}
                      onChange={(e) => setGuests(e.target.value)}
                      className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                        isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                      }`}
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] tracking-widest font-bold uppercase mb-1.5 opacity-80">
                      Room
                    </label>
                    <select
                      id="event-room-select"
                      value={room}
                      onChange={(e) => setRoom(e.target.value)}
                      className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                        isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                      }`}
                    >
                      <option>The Oak Room</option>
                      <option>The Cambridge Library</option>
                      <option>The Boston Glasshouse</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] tracking-widest font-bold uppercase mb-1.5 opacity-80">
                    Bespoke Directives & Catering Preferences
                  </label>
                  <textarea
                    id="event-details-textarea"
                    rows={4}
                    value={customDetails}
                    onChange={(e) => setCustomDetails(e.target.value)}
                    className={`w-full text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass resize-none ${
                      isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                    }`}
                    placeholder="E.g., high formal style, single malts, specific food allergies..."
                    required
                  />
                </div>

                <button
                  id="event-proposal-submit"
                  type="submit"
                  disabled={loading}
                  className="w-full bg-brand-brass text-brand-charcoal text-xs tracking-[0.25em] py-3.5 uppercase font-bold transition-all hover:bg-brand-brass/90 flex items-center justify-center space-x-2 disabled:opacity-55 cursor-pointer"
                >
                  <Send size={12} />
                  <span>{loading ? 'CURATING PROPOSAL...' : 'GENERATE AI PROPOSAL'}</span>
                </button>
              </form>
            </div>

            {/* Proposal Output Column */}
            <div className="lg:col-span-7 h-full flex flex-col justify-between">
              <div className={`p-6 border min-h-[350px] flex flex-col justify-between relative ${
                isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/10' : 'bg-white border-[#103B2E]/10'
              }`}>
                
                {/* Visual frame corners */}
                <div className="absolute top-0 left-0 w-3 h-3 border-t border-l border-brand-brass" />
                <div className="absolute bottom-0 right-0 w-3 h-3 border-b border-r border-brand-brass" />

                <AnimatePresence mode="wait">
                  {loading ? (
                    <motion.div
                      key="loading"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      className="flex flex-col items-center justify-center py-20 text-center h-full"
                    >
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-brass mb-4" />
                      <p className="font-serif italic text-brand-brass text-lg">
                        "Drafting menu selection... selecting fine wine vintages..."
                      </p>
                      <p className="text-[10px] tracking-widest text-current/50 uppercase mt-2">
                        Powered by Google Gemini 3.6-Flash
                      </p>
                    </motion.div>
                  ) : proposal ? (
                    <motion.div
                      key="proposal"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="space-y-4 text-xs h-[320px] overflow-y-auto pr-2 no-scrollbar"
                    >
                      <div className="flex justify-between items-center border-b border-brand-brass/20 pb-3 mb-3">
                        <span className="font-serif text-sm font-semibold text-brand-brass tracking-wider">
                          BESPOKE BANQUET DOSSIER
                        </span>
                        <button
                          id="reset-proposal-btn"
                          onClick={() => setProposal(null)}
                          className="text-[9px] tracking-widest text-brand-brass flex items-center space-x-1 cursor-pointer"
                        >
                          <RotateCcw size={10} />
                          <span>RESET</span>
                        </button>
                      </div>

                      <div className="space-y-3 leading-relaxed whitespace-pre-wrap font-sans text-current/90">
                        {proposal}
                      </div>
                    </motion.div>
                  ) : (
                    <motion.div
                      key="placeholder"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      className="flex flex-col items-center justify-center text-center py-20 opacity-60"
                    >
                      <MessageSquare className="text-brand-brass mb-3 opacity-80" size={32} />
                      <h4 className="font-serif text-lg font-medium tracking-wide mb-1">
                        Bespoke Proposal Document
                      </h4>
                      <p className="text-[10px] uppercase tracking-widest text-current/60 max-w-sm mb-4">
                        Awaiting your specific instructions. Complete the form to generate a curated high-influence catalog.
                      </p>
                      <div className="p-3 border border-dashed border-brand-brass/25 text-[10px] font-serif italic text-brand-brass">
                        "The Harvard lecturers deserve nothing less than our 2017 Château Margaux."
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

          </div>
        </div>

      </div>
    </section>
  );
}
