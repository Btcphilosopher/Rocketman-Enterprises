import React from 'react';
import { Calendar, Clock, MapPin, ArrowRight, Award } from 'lucide-react';
import { EVENTS } from '../data';

interface EventsListProps {
  onReserveClick: () => void;
  isDarkMode: boolean;
}

export default function EventsList({ onReserveClick, isDarkMode }: EventsListProps) {
  // Add other premium events to complement our initial list
  const secondaryEvents = [
    {
      id: 'event-5',
      title: 'Oxford vs. Cambridge Debate Night',
      date: 'Bi-Annual, October 14th',
      time: '7:00 PM - 10:30 PM',
      description: 'An elite collegiate debate and three-course dinner. Alumni and guests from Oxford and Cambridge gather in our Cambridge Library to dispute classical logic and aesthetics, accompanied by rare Sherry and Bordeaux.',
      pricePerGuest: 160,
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800'
    },
    {
      id: 'event-6',
      title: 'Shakespeare’s Sovereign Evenings',
      date: 'Monthly, First Tuesday',
      time: '6:00 PM - 9:30 PM',
      description: 'An atmospheric candlelit salon. Professional theater actors perform dramatic readings of Shakespeare’s sovereign tragedies in our central courtyard, paired with Tudor-era mulled clarets and game bird pastries.',
      pricePerGuest: 110,
      image: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=800'
    }
  ];

  const allEvents = [...EVENTS, ...secondaryEvents];

  return (
    <section
      id="events-section"
      className={`py-24 md:py-32 px-6 md:px-12 transition-colors duration-500 border-b ${
        isDarkMode ? 'bg-[#1D1D1D]' : 'bg-[#F7F3EB]'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Title Block */}
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between mb-20 gap-6">
          <div>
            <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4 block">
              THE CULTURE SOCIETY
            </span>
            <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium">
              Sovereign Events & Salons
            </h2>
          </div>
          <p className={`max-w-md text-sm font-light tracking-wide ${
            isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/65'
          }`}>
            We bridge intellectual debate, rare spirits, and classical gastronomy. Explore our upcoming curated gatherings and reserve your place at the high table.
          </p>
        </div>

        {/* Events Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {allEvents.map((ev) => (
            <div
              key={ev.id}
              id={`event-card-${ev.id}`}
              className={`border transition-all duration-500 flex flex-col justify-between group ${
                isDarkMode 
                  ? 'bg-[#101010] border-brand-brass/10 hover:border-brand-brass/25' 
                  : 'bg-[#FAF8F4] border-[#103B2E]/5 hover:border-brand-brass/25'
              }`}
            >
              {/* Graphic Header */}
              <div className="h-64 overflow-hidden relative">
                <div className="absolute inset-3 border border-brand-brass/15 z-10 pointer-events-none" />
                <img
                  src={ev.image}
                  alt={ev.title}
                  className="w-full h-full object-cover filter brightness-[0.7] group-hover:scale-105 transition-transform duration-1000"
                />
                <div className="absolute top-6 left-6 bg-brand-brass text-brand-charcoal text-[9px] tracking-widest font-bold px-3 py-1 uppercase z-10">
                  ${ev.pricePerGuest} / GUEST
                </div>
              </div>

              {/* Text Area */}
              <div className="p-6 md:p-8 flex-1 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex flex-wrap items-center gap-4 text-[10px] tracking-wider text-brand-brass font-bold uppercase mb-3">
                    <span className="flex items-center space-x-1">
                      <Calendar size={12} />
                      <span>{ev.date}</span>
                    </span>
                    <span className="w-1 h-1 bg-brand-brass rounded-full" />
                    <span className="flex items-center space-x-1">
                      <Clock size={12} />
                      <span>{ev.time}</span>
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-medium tracking-wide">
                    {ev.title}
                  </h3>

                  <p className={`text-xs md:text-sm font-light mt-3 leading-relaxed ${
                    isDarkMode ? 'text-brand-stone/70' : 'text-brand-charcoal/80'
                  }`}>
                    {ev.description}
                  </p>
                </div>

                <div className="border-t border-brand-brass/10 pt-4 flex items-center justify-between">
                  <span className="text-[9px] tracking-[0.25em] text-brand-brass font-bold uppercase flex items-center space-x-1">
                    <Award size={12} />
                    <span>LTD. CAPACITY SALON</span>
                  </span>
                  
                  <button
                    id={`reserve-event-btn-${ev.id}`}
                    onClick={onReserveClick}
                    className="flex items-center space-x-2 text-[10px] tracking-[0.2em] font-bold text-brand-brass uppercase group-hover:translate-x-1 transition-transform cursor-pointer"
                  >
                    <span>SECURE PASSES</span>
                    <ArrowRight size={12} />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
