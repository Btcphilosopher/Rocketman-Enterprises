import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MessageSquare, X, Send, Sparkles, Wine, User, Calendar, Tag, ShieldCheck } from 'lucide-react';

interface AIChatBotProps {
  isOpen: boolean;
  onClose: () => void;
  isDarkMode: boolean;
  externalTrigger: { specialist: string; message: string } | null;
  onClearTrigger: () => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
}

const SPECIALISTS = [
  {
    id: 'maitred',
    name: 'Edward',
    title: 'Maitre D’',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200',
    tagline: 'Charming general guidance regarding reservations, dress codes, & local logistics.',
    suggestions: [
      'What is the evening dress code?',
      'Tell me about valet parking options.',
      'What are your daily hours of operation?',
      'Are you close to the Boston Seaport?'
    ]
  },
  {
    id: 'sommelier',
    name: 'Alistair',
    title: 'Royal Sommelier',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200',
    tagline: 'Sophisticated wine recommendations, vintage profiles, & pairings.',
    suggestions: [
      'What pairs well with the Yorkshire Wagyu Wellington?',
      'Tell me about English sparkling wines (Gusbourne/Nyetimber).',
      'What white wine matches the Scottish Halibut?',
      'Suggest a rich red wine for the Rib of Beef.'
    ]
  },
  {
    id: 'planner',
    name: 'Victoria',
    title: 'Private Events',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200',
    tagline: 'Bespoke menus, room selection, and high-influence dining structures.',
    suggestions: [
      'I have 16 guests, which private room is best?',
      'Suggest a menu for a formal LSE/Harvard dinner.',
      'Explain the capacity of the Boston Glasshouse.',
      'Can I request custom floral arrangements?'
    ]
  },
  {
    id: 'dietary',
    name: 'Charlotte',
    title: 'Dietary & Gifting',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=200',
    tagline: 'Attentive safety guidance on allergens, & bespoke gourmet gifting.',
    suggestions: [
      'Which starters are dairy-free and gluten-free?',
      'What is the perfect premium gift for a client?',
      'Do you offer vegan main courses?',
      'Tell me about your stoneware ceramics from Yorkshire.'
    ]
  }
];

export default function AIChatBot({
  isOpen,
  onClose,
  isDarkMode,
  externalTrigger,
  onClearTrigger
}: AIChatBotProps) {
  const [activeSpecialist, setActiveSpecialist] = useState(SPECIALISTS[0]);
  const [input, setInput] = useState('');
  const [conversations, setConversations] = useState<Record<string, ChatMessage[]>>({
    maitred: [
      {
        id: 'welcome',
        role: 'model',
        text: 'Good evening, sir/madam. I am Edward, the Maitre D’ of The Anglo-Futurist. It is my absolute privilege to welcome you. How may I facilitate your reservations or answer your questions today?'
      }
    ],
    sommelier: [
      {
        id: 'welcome',
        role: 'model',
        text: 'Welcome, esteemed guest. I am Alistair, your Sommelier. Sourcing fine vintages from Hampshire to Burgundy is my life’s pursuit. May I suggest an extraordinary sparkling pour or assist in pairing your selected dish?'
      }
    ],
    planner: [
      {
        id: 'welcome',
        role: 'model',
        text: 'Greetings. I am Victoria, your Private Events Director. Whether curating a Harvard faculty debate or an executive board dinner, I am pleased to assist in proposing our private salons and custom menus. How can I serve your planning today?'
      }
    ],
    dietary: [
      {
        id: 'welcome',
        role: 'model',
        text: 'Hello. I am Charlotte, your Dietary and Gifting Concierge. I am dedicated to ensuring your meal is perfectly safe and tailored to your allergies, or helping you select high-end British ceramics, teas, and denim from our boutique. What can I curate for you?'
      }
    ]
  });
  const [loading, setLoading] = useState(false);
  const threadEndRef = useRef<HTMLDivElement | null>(null);

  // Scroll to bottom when conversation or active specialist changes
  useEffect(() => {
    threadEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversations, activeSpecialist]);

  // Handle external triggers (e.g. clicking "Consult Sommelier" on menu or wine sections)
  useEffect(() => {
    if (externalTrigger) {
      const spec = SPECIALISTS.find((s) => s.id === externalTrigger.specialist);
      if (spec) {
        setActiveSpecialist(spec);
        // Automatically submit the trigger message
        handleAutoMessageSubmit(spec.id, externalTrigger.message);
      }
      onClearTrigger();
    }
  }, [externalTrigger]);

  const handleAutoMessageSubmit = async (specialistId: string, text: string) => {
    setLoading(true);
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text
    };

    const currentHistory = conversations[specialistId] || [];
    const updatedHistory = [...currentHistory, userMsg];

    setConversations((prev) => ({
      ...prev,
      [specialistId]: updatedHistory
    }));

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          specialist: specialistId,
          history: currentHistory.filter(h => h.id !== 'welcome')
        })
      });
      const data = await response.json();
      
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        role: 'model',
        text: data.text || 'My apologies, but my connection is momentarily clouded. Please enquire once more.'
      };

      setConversations((prev) => ({
        ...prev,
        [specialistId]: [...updatedHistory, aiMsg]
      }));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const text = input;
    setInput('');
    await handleAutoMessageSubmit(activeSpecialist.id, text);
  };

  const handleResetConversation = () => {
    const defaultWelcomeText = {
      maitred: 'Good evening, sir/madam. I am Edward, the Maitre D’ of The Anglo-Futurist. It is my absolute privilege to welcome you. How may I facilitate your reservations or answer your questions today?',
      sommelier: 'Welcome, esteemed guest. I am Alistair, your Sommelier. Sourcing fine vintages from Hampshire to Burgundy is my life’s pursuit. May I suggest an extraordinary sparkling pour or assist in pairing your selected dish?',
      planner: 'Greetings. I am Victoria, your Private Events Director. Whether curating a Harvard faculty debate or an executive board dinner, I am pleased to assist in proposing our private salons and custom menus. How can I serve your planning today?',
      dietary: 'Hello. I am Charlotte, your Dietary and Gifting Concierge. I am dedicated to ensuring your meal is perfectly safe and tailored to your allergies, or helping you select high-end British ceramics, teas, and denim from our boutique. What can I curate for you?'
    };

    setConversations((prev) => ({
      ...prev,
      [activeSpecialist.id]: [
        {
          id: 'welcome',
          role: 'model',
          text: defaultWelcomeText[activeSpecialist.id as 'maitred' | 'sommelier' | 'planner' | 'dietary']
        }
      ]
    }));
  };

  const currentMessages = conversations[activeSpecialist.id] || [];

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay mask */}
          <div
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 cursor-pointer"
            onClick={onClose}
          />

          {/* Core Chat Panel Drawer */}
          <motion.div
            id="ai-chat-sidebar"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className={`fixed top-0 right-0 w-full sm:w-[480px] h-screen shadow-2xl flex flex-col z-50 border-l ${
              isDarkMode 
                ? 'bg-[#101010] text-brand-stone border-brand-brass/20' 
                : 'bg-[#FAF8F4] text-brand-charcoal border-[#103B2E]/15'
            }`}
          >
            {/* Header Area */}
            <div className={`p-6 border-b flex items-center justify-between ${
              isDarkMode ? 'bg-[#1D1D1D] border-brand-brass/15' : 'bg-[#F7F3EB] border-[#103B2E]/10'
            }`}>
              <div className="flex items-center space-x-2">
                <Sparkles className="text-brand-brass animate-[pulse_2s_infinite]" size={16} />
                <span className="font-serif text-sm tracking-[0.2em] font-medium">SOVEREIGN AI CONCIERGE</span>
              </div>
              <button
                id="close-ai-chat-btn"
                onClick={onClose}
                className="p-2 hover:bg-brand-brass/10 rounded-full transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Specialist Selector Board */}
            <div className="grid grid-cols-4 border-b border-brand-brass/10">
              {SPECIALISTS.map((spec) => (
                <button
                  key={spec.id}
                  id={`specialist-tab-${spec.id}`}
                  onClick={() => {
                    if (!loading) {
                      setActiveSpecialist(spec);
                    }
                  }}
                  className={`py-4 flex flex-col items-center border-r last:border-none border-brand-brass/10 transition-all cursor-pointer ${
                    activeSpecialist.id === spec.id
                      ? isDarkMode ? 'bg-[#1D1D1D] text-brand-brass' : 'bg-[#F7F3EB] text-brand-brass'
                      : 'opacity-60 hover:opacity-100'
                  }`}
                  disabled={loading}
                >
                  <img
                    src={spec.avatar}
                    alt={spec.name}
                    className="w-10 h-10 rounded-full border border-brand-brass/25 object-cover"
                  />
                  <span className="text-[9px] tracking-wider font-bold uppercase mt-2">
                    {spec.name}
                  </span>
                </button>
              ))}
            </div>

            {/* Active Specialist Tagline */}
            <div className={`px-6 py-3 border-b text-[10px] italic flex items-center justify-between ${
              isDarkMode ? 'bg-[#161616]/90 border-brand-brass/5 text-brand-stone/60' : 'bg-white border-[#103B2E]/5 text-brand-charcoal/70'
            }`}>
              <span>{activeSpecialist.tagline}</span>
              <button
                id="reset-chat-history-btn"
                onClick={handleResetConversation}
                className="text-brand-brass underline hover:no-underline font-sans not-italic font-bold tracking-widest uppercase text-[8px] cursor-pointer"
              >
                Reset Chat
              </button>
            </div>

            {/* Chat Messages Log */}
            <div className="flex-1 p-6 overflow-y-auto space-y-4 no-scrollbar">
              {currentMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role !== 'user' && (
                    <img
                      src={activeSpecialist.avatar}
                      alt={activeSpecialist.name}
                      className="w-8 h-8 rounded-full border border-brand-brass/20 object-cover mt-1"
                    />
                  )}

                  <div className={`max-w-[75%] p-4 text-xs leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-brand-brass text-brand-charcoal font-medium'
                      : isDarkMode
                        ? 'bg-[#1D1D1D] border border-brand-brass/10 text-brand-stone/90'
                        : 'bg-white border border-[#103B2E]/10 text-brand-charcoal/90'
                  }`}>
                    {msg.text}
                  </div>
                </div>
              ))}

              {loading && (
                <div className="flex items-start gap-3">
                  <img
                    src={activeSpecialist.avatar}
                    alt={activeSpecialist.name}
                    className="w-8 h-8 rounded-full border border-brand-brass/20 object-cover mt-1 animate-pulse"
                  />
                  <div className={`p-4 text-xs italic opacity-75 ${
                    isDarkMode ? 'bg-[#1D1D1D]' : 'bg-white'
                  }`}>
                    "{activeSpecialist.name} is typing..."
                  </div>
                </div>
              )}

              <div ref={threadEndRef} />
            </div>

            {/* Suggestions Drawer (Only when chat is idle) */}
            {!loading && currentMessages.length === 1 && (
              <div className="px-6 py-4 border-t border-brand-brass/10">
                <span className="text-[9px] tracking-widest uppercase font-bold text-brand-brass block mb-2">Suggested Inquiries:</span>
                <div className="flex flex-col gap-2">
                  {activeSpecialist.suggestions.map((sug) => (
                    <button
                      key={sug}
                      id={`suggested-inquiry-${sug.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                      onClick={() => handleAutoMessageSubmit(activeSpecialist.id, sug)}
                      className={`text-left text-[11px] p-2 border transition-all hover:border-brand-brass text-current/80 hover:text-brand-brass cursor-pointer ${
                        isDarkMode ? 'border-brand-stone/10 bg-[#161616]' : 'border-[#103B2E]/10 bg-white'
                      }`}
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Input Submission Bar */}
            <form onSubmit={handleSendMessage} className="p-4 border-t border-brand-brass/10 flex gap-2">
              <input
                id="ai-chat-input"
                type="text"
                disabled={loading}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={`Ask ${activeSpecialist.name}...`}
                className={`flex-1 text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                  isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                }`}
              />
              <button
                id="ai-chat-send-btn"
                type="submit"
                disabled={loading || !input.trim()}
                className="bg-brand-brass text-brand-charcoal p-3 hover:bg-brand-brass/90 transition-colors disabled:opacity-40 cursor-pointer"
              >
                <Send size={15} />
              </button>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
