import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MENU_ITEMS } from '../data';
import { MenuItem } from '../types';
import { Wine, Info, Sparkles, X, ChevronRight } from 'lucide-react';

interface MenuSectionProps {
  onConsultSommelier: (dishName: string, winePairing: string) => void;
  isDarkMode: boolean;
}

export default function MenuSection({ onConsultSommelier, isDarkMode }: MenuSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('Classics');
  const [activeDish, setActiveDish] = useState<MenuItem | null>(null);

  const categories = ['Starters', 'Seafood', 'Grill', 'Classics', 'Sunday Roast', 'Desserts', 'Cheese'];
  
  const filteredItems = MENU_ITEMS.filter(item => item.category === selectedCategory);
  const signatureItems = MENU_ITEMS.filter(item => item.isSignature);

  return (
    <section
      id="menu-section"
      className={`py-24 md:py-32 px-6 md:px-12 transition-colors duration-500 ${
        isDarkMode ? 'bg-[#101010]' : 'bg-[#FAF8F4]'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Signature Dishes Spotlight */}
        <div className="text-center mb-16">
          <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4 block">
            CULINARY SHOWCASE
          </span>
          <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium mb-6">
            Signature Ensembles
          </h2>
          <p className={`max-w-2xl mx-auto text-sm md:text-base font-light tracking-wide ${
            isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/65'
          }`}>
            A selection of our most celebrated dishes, crafted to showcase the evolutionary harmony between British culinary heritage and New England produce.
          </p>
        </div>

        {/* Signature Dishes Row (Large Horizontal Cards) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
          {signatureItems.slice(0, 3).map((dish) => (
            <motion.div
              key={dish.id}
              id={`signature-dish-${dish.id}`}
              className={`relative flex flex-col group overflow-hidden border transition-all duration-500 ${
                isDarkMode ? 'bg-[#1D1D1D] border-brand-brass/15' : 'bg-[#F7F3EB] border-[#103B2E]/10'
              }`}
              whileHover={{ y: -6 }}
            >
              {/* Image Frame */}
              <div className="h-64 overflow-hidden relative">
                {/* Thin accent frame inside the image */}
                <div className="absolute inset-3 border border-brand-brass/25 z-10 pointer-events-none" />
                <img
                  src={dish.image}
                  alt={dish.name}
                  className="w-full h-full object-cover filter brightness-[0.75] group-hover:scale-105 transition-transform duration-1000"
                />
                <span className="absolute top-6 left-6 bg-brand-brass text-brand-charcoal text-[9px] tracking-[0.2em] font-bold px-3 py-1 uppercase">
                  Signature
                </span>
              </div>

              {/* Text Area */}
              <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-baseline mb-3">
                    <h3 className="font-serif text-xl md:text-2xl font-medium tracking-wide">
                      {dish.name}
                    </h3>
                    <span className="text-brand-brass font-serif text-lg font-semibold ml-4">
                      ${dish.price}
                    </span>
                  </div>
                  <p className={`text-xs md:text-sm line-clamp-3 font-light mb-6 leading-relaxed ${
                    isDarkMode ? 'text-brand-stone/70' : 'text-brand-charcoal/80'
                  }`}>
                    {dish.description}
                  </p>
                </div>

                <div className="border-t border-brand-brass/10 pt-4 flex items-center justify-between">
                  <button
                    id={`view-dish-story-${dish.id}`}
                    onClick={() => setActiveDish(dish)}
                    className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase transition-colors hover:text-brand-stone cursor-pointer"
                  >
                    THE STORY & ALLERGENS
                  </button>
                  <button
                    id={`pair-dish-sommelier-${dish.id}`}
                    onClick={() => onConsultSommelier(dish.name, dish.winePairing)}
                    className="flex items-center space-x-1 text-[9px] tracking-[0.2em] opacity-80 hover:opacity-100 text-brand-brass cursor-pointer"
                    title="Consult Sommelier"
                  >
                    <Wine size={12} />
                    <span>SOMMELIER GUIDE</span>
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Dynamic Menu Tabbed Navigator */}
        <div className="border-t border-brand-brass/15 pt-20 mb-16">
          <div className="text-center mb-12">
            <span className="text-[10px] tracking-[0.35em] text-brand-brass font-bold uppercase mb-3 block">
              THE FULL MENU
            </span>
            <h3 className="font-serif text-3xl md:text-5xl font-medium tracking-wide">
              Meticulously Categorized
            </h3>
          </div>

          {/* Navigation Tab Bar */}
          <div className="flex flex-wrap items-center justify-center gap-2 md:gap-4 mb-16 max-w-4xl mx-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                id={`menu-tab-${cat.toLowerCase().replace(' ', '-')}`}
                onClick={() => setSelectedCategory(cat)}
                className={`text-[10px] md:text-xs tracking-[0.25em] font-medium border px-4 py-3 uppercase transition-all duration-300 cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-brand-brass text-brand-charcoal border-brand-brass font-bold'
                    : isDarkMode
                      ? 'border-brand-stone/10 text-brand-stone/70 hover:border-brand-brass hover:text-brand-brass'
                      : 'border-brand-green/10 text-brand-charcoal/70 hover:border-brand-brass hover:text-brand-brass'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Filtered Dishes Grid */}
          <motion.div
            layout
            className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-5xl mx-auto"
          >
            <AnimatePresence mode="popLayout">
              {filteredItems.map((dish) => (
                <motion.div
                  key={dish.id}
                  id={`menu-item-card-${dish.id}`}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  transition={{ duration: 0.4 }}
                  className={`p-6 border transition-all duration-300 flex flex-col md:flex-row gap-6 items-start md:items-center ${
                    isDarkMode 
                      ? 'bg-[#1D1D1D] border-brand-brass/10 hover:border-brand-brass/35' 
                      : 'bg-[#F7F3EB] border-[#103B2E]/5 hover:border-brand-brass/35'
                  }`}
                >
                  <img
                    src={dish.image}
                    alt={dish.name}
                    className="w-24 h-24 object-cover border border-brand-brass/20"
                  />
                  <div className="flex-1 flex flex-col justify-between h-full">
                    <div>
                      <div className="flex justify-between items-baseline mb-2">
                        <h4 className="font-serif text-lg md:text-xl font-medium tracking-wide">
                          {dish.name}
                        </h4>
                        <span className="text-brand-brass font-serif font-semibold ml-4">
                          ${dish.price}
                        </span>
                      </div>
                      <p className={`text-xs font-light mb-4 leading-relaxed line-clamp-2 ${
                        isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/70'
                      }`}>
                        {dish.description}
                      </p>
                    </div>

                    <div className="flex items-center space-x-6 text-[10px] tracking-[0.15em] uppercase">
                      <button
                        id={`menu-item-details-${dish.id}`}
                        onClick={() => setActiveDish(dish)}
                        className="text-brand-brass font-bold hover:underline cursor-pointer"
                      >
                        THE STORY & ALLERGENS
                      </button>
                      <button
                        id={`menu-item-sommelier-${dish.id}`}
                        onClick={() => onConsultSommelier(dish.name, dish.winePairing)}
                        className="flex items-center space-x-1 text-current/60 hover:text-brand-brass cursor-pointer"
                      >
                        <Wine size={11} />
                        <span>WINE CELLAR MATCH</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>

      </div>

      {/* Details/Story Modal */}
      <AnimatePresence>
        {activeDish && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              id="dish-detail-modal"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`w-full max-w-2xl overflow-hidden relative border ${
                isDarkMode 
                  ? 'bg-[#1D1D1D] text-brand-stone border-brand-brass/30' 
                  : 'bg-[#FAF8F4] text-brand-charcoal border-[#103B2E]/20'
              }`}
            >
              {/* Close Button */}
              <button
                id="close-dish-modal-btn"
                onClick={() => setActiveDish(null)}
                className="absolute top-4 right-4 p-2 bg-black/30 hover:bg-black/60 text-white rounded-full z-10 cursor-pointer"
              >
                <X size={16} />
              </button>

              <div className="relative h-64 md:h-80 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent z-10" />
                <img
                  src={activeDish.image}
                  alt={activeDish.name}
                  className="w-full h-full object-cover filter brightness-[0.8] contrast-[1.05]"
                />
                <div className="absolute bottom-6 left-6 md:left-8 z-20 text-white">
                  <span className="text-[9px] tracking-[0.3em] text-brand-brass font-bold uppercase block mb-1">
                    {activeDish.category}
                  </span>
                  <h3 className="font-serif text-3xl md:text-4xl tracking-wide font-medium">
                    {activeDish.name}
                  </h3>
                </div>
              </div>

              <div className="p-6 md:p-8 space-y-6 max-h-[50vh] overflow-y-auto no-scrollbar">
                {/* Description */}
                <div>
                  <h4 className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase mb-2">
                    Culinary Ensemble
                  </h4>
                  <p className="text-sm leading-relaxed font-light">
                    {activeDish.description}
                  </p>
                </div>

                {/* Origin Story */}
                <div className="border-t border-brand-brass/10 pt-4">
                  <h4 className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase mb-2">
                    The Origin Story
                  </h4>
                  <p className="text-xs leading-relaxed font-serif italic opacity-90">
                    {activeDish.originStory}
                  </p>
                </div>

                {/* Wine Pairing & Allergens */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-brand-brass/10 pt-4">
                  <div className="flex items-start space-x-3">
                    <Wine className="text-brand-brass shrink-0 mt-0.5" size={16} />
                    <div>
                      <h4 className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase mb-1">
                        Sommelier Wine Pairing
                      </h4>
                      <p className="text-xs font-medium">
                        {activeDish.winePairing}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-3">
                    <Info className="text-brand-brass shrink-0 mt-0.5" size={16} />
                    <div>
                      <h4 className="text-[10px] tracking-[0.25em] text-brand-brass font-bold uppercase mb-1">
                        Allergens
                      </h4>
                      <div className="flex flex-wrap gap-1.5 mt-1">
                        {activeDish.allergens.map((alg) => (
                          <span
                            key={alg}
                            className={`text-[9px] tracking-wider px-2 py-0.5 border ${
                              isDarkMode ? 'border-brand-stone/15 text-brand-stone/70' : 'border-brand-charcoal/15 text-brand-charcoal/75'
                            }`}
                          >
                            {alg}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sommelier Consultation Button */}
                <div className="pt-4">
                  <button
                    id="modal-sommelier-consult-btn"
                    onClick={() => {
                      onConsultSommelier(activeDish.name, activeDish.winePairing);
                      setActiveDish(null);
                    }}
                    className="w-full bg-brand-brass text-brand-charcoal text-xs tracking-[0.2em] py-3 uppercase font-bold transition-all hover:bg-brand-brass/90 flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <Wine size={14} />
                    <span>CONSULT ROYAL SOMMELIER REGARDING THIS PAIRING</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
