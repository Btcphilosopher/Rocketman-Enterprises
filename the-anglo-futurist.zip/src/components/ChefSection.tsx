import React from 'react';
import { Award, Info, Sparkles } from 'lucide-react';

interface ChefSectionProps {
  isDarkMode: boolean;
}

export default function ChefSection({ isDarkMode }: ChefSectionProps) {
  return (
    <section
      id="chef-section"
      className={`py-24 md:py-32 px-6 md:px-12 border-b transition-colors duration-500 ${
        isDarkMode ? 'bg-[#101010] border-brand-brass/10' : 'bg-[#FAF8F4] border-[#103B2E]/10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-center">
          
          {/* Left Column: Editorial profile and quotes */}
          <div className="lg:col-span-7 space-y-6">
            <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-2 block">
              CHEF PATRON
            </span>
            <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium leading-tight">
              Julian Sterling
            </h2>
            <p className="text-xs tracking-[0.2em] text-brand-brass font-bold uppercase border-b border-brand-brass/20 pb-4 max-w-sm">
              Formerly of Hawksmoor & The Ledbury, London
            </p>

            <div className={`space-y-6 text-sm md:text-base leading-relaxed font-light tracking-wide ${
              isDarkMode ? 'text-brand-stone/80' : 'text-brand-charcoal/85'
            }`}>
              <p>
                Julian Sterling spent fifteen years at the vanguard of London's culinary renaissance. Having trained directly under Britain's Michelin-starred traditionalists, he developed a profound reverence for ancient preservation, smoking, and baking techniques.
              </p>
              
              <p className="font-serif italic text-lg md:text-xl text-brand-brass border-l-2 border-brand-brass pl-4 py-1 my-6">
                "We do not manipulate ingredients to disguise them. We use modern heat, structural pastry, and thermal control to celebrate their raw, structural essence."
              </p>

              <p>
                In Boston, Julian oversees our open-concept hearth kitchen. Standing before our solid steel grills, he and his brigade plate each dish with the meticulous care of an architect. He insists on open kitchen transparency, inviting guests to witness the theater of modern British craftsmanship.
              </p>
            </div>

            {/* Philosophy checklist */}
            <div className="flex flex-col sm:flex-row gap-6 pt-6">
              <div className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-brand-brass rounded-full" />
                <span className="text-xs font-bold tracking-widest uppercase">Open Kitchen Transparency</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-brand-brass rounded-full" />
                <span className="text-xs font-bold tracking-widest uppercase">Ancient Hearth Charring</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-1.5 h-1.5 bg-brand-brass rounded-full" />
                <span className="text-xs font-bold tracking-widest uppercase">Sustainable Agrarian Links</span>
              </div>
            </div>
          </div>

          {/* Right Column: Large portrait & culinary action shot */}
          <div className="lg:col-span-5 grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div className="overflow-hidden border border-brand-brass/10 relative group">
                <img
                  src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?q=80&w=600"
                  alt="Chef Julian Sterling Portrait"
                  className="w-full h-72 object-cover filter brightness-[0.75] group-hover:scale-105 transition-transform duration-1000"
                />
                <div className="absolute bottom-4 left-4 text-white z-10">
                  <p className="text-[9px] tracking-widest uppercase opacity-75">Julian Sterling</p>
                  <p className="font-serif text-sm font-semibold text-brand-brass">Chef Patron</p>
                </div>
              </div>
              <div className="overflow-hidden border border-brand-brass/10 relative group">
                <img
                  src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?q=80&w=600"
                  alt="Bespoke charcoal kitchen griddle"
                  className="w-full h-44 object-cover filter brightness-[0.7] group-hover:scale-105 transition-transform duration-1000"
                />
              </div>
            </div>

            <div className="space-y-4 pt-8">
              <div className="overflow-hidden border border-brand-brass/10 relative group">
                <img
                  src="https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?q=80&w=600"
                  alt="Plating station slow motion"
                  className="w-full h-44 object-cover filter brightness-[0.7] group-hover:scale-105 transition-transform duration-1000"
                />
              </div>
              <div className="overflow-hidden border border-brand-brass/10 relative group">
                <img
                  src="https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=600"
                  alt="Julian plating Wagyu Wellington"
                  className="w-full h-72 object-cover filter brightness-[0.75] group-hover:scale-105 transition-transform duration-1000"
                />
                <div className="absolute bottom-4 left-4 text-white z-10">
                  <p className="text-[9px] tracking-widest uppercase opacity-75">Plating Station</p>
                  <p className="font-serif text-sm font-semibold text-brand-brass">The Wagyu Wellington</p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
