import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { MERCHANDISE } from '../data';
import { MerchandiseItem, CartItem } from '../types';
import { ShoppingBag, ArrowRight, X, Sparkles, Tag, Check, Send } from 'lucide-react';

interface StoreSectionProps {
  onAddToCart: (item: MerchandiseItem) => void;
  cartItems: CartItem[];
  onRemoveFromCart: (id: string) => void;
  onClearCart: () => void;
  isDarkMode: boolean;
}

export default function StoreSection({
  onAddToCart,
  cartItems,
  onRemoveFromCart,
  onClearCart,
  isDarkMode
}: StoreSectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [giftQuery, setGiftQuery] = useState('');
  const [giftRecommendation, setGiftRecommendation] = useState<string | null>(null);
  const [loadingRecommendation, setLoadingRecommendation] = useState(false);
  const [checkoutSuccess, setCheckoutSuccess] = useState(false);

  const categories = ['All', 'Cookbooks', 'Aprons', 'Tea & Coffee', 'Glassware', 'Ceramics'];

  const filteredItems = selectedCategory === 'All'
    ? MERCHANDISE
    : MERCHANDISE.filter((item) => item.category === selectedCategory);

  const subtotal = cartItems.reduce((acc, item) => acc + (item.merchandise.price * item.quantity), 0);

  const handleAskGiftAdvisor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftQuery) return;
    setLoadingRecommendation(true);
    setGiftRecommendation(null);

    const prompt = `A guest is looking for a curated gift in our store. Here is their request: "${giftQuery}".
Please recommend 1 or 2 specific items from our collection:
- The Anglo-Futurist Manifesto Cookbook ($65)
- Selvedge Denim Chef’s Apron ($110)
- The Royal Sovereign Breakfast Blend ($32)
- Hand-blown Crystal Cut-Glass Tumbler ($75)
- Stoneware Plating Bowl from Yorkshire ($85)
Detail exactly why this is a highly thoughtful, luxury selection. Keep your tone refined and sophisticated.`;

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: prompt,
          specialist: 'dietary'
        })
      });
      const data = await response.json();
      if (data.text) {
        setGiftRecommendation(data.text);
      } else {
        setGiftRecommendation("My deepest apologies, but our gifting concierge is cataloging arrivals. I suggest our elegant Hand-blown Crystal Cut-Glass Tumblers.");
      }
    } catch (err) {
      console.error(err);
      setGiftRecommendation("The gifting ledger is offline, but I personally recommend our Linen-bound Cookbook.");
    } finally {
      setLoadingRecommendation(false);
    }
  };

  const handleCheckout = () => {
    setCheckoutSuccess(true);
    onClearCart();
    setTimeout(() => {
      setCheckoutSuccess(false);
    }, 8000);
  };

  return (
    <section
      id="store-section"
      className={`py-24 md:py-32 px-6 md:px-12 transition-colors duration-500 border-b ${
        isDarkMode ? 'bg-[#1D1D1D] border-brand-brass/10' : 'bg-[#F7F3EB] border-[#103B2E]/10'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        
        {/* Header Title Block */}
        <div className="flex flex-col lg:flex-row items-start lg:items-end justify-between mb-16 gap-6">
          <div>
            <span className="text-[10px] md:text-xs tracking-[0.35em] text-brand-brass font-bold uppercase mb-4 block">
              THE EMPIRE BOUTIQUE
            </span>
            <h2 className="font-serif text-4xl md:text-6xl tracking-wide font-medium">
              Curated Craft Goods
            </h2>
          </div>
          <p className={`max-w-md text-sm font-light tracking-wide ${
            isDarkMode ? 'text-brand-stone/60' : 'text-brand-charcoal/65'
          }`}>
            Take home the raw materials of British luxury. From bespoke hand-thrown northern clay bowls to custom selvedge raw denim aprons and custom publication volumes.
          </p>
        </div>

        {/* AI Gift Assistant Splitting Banner */}
        <div className={`border p-6 md:p-8 mb-16 flex flex-col md:flex-row items-center gap-8 ${
          isDarkMode ? 'bg-[#101010] border-brand-brass/15' : 'bg-white border-[#103B2E]/10'
        }`}>
          <div className="md:w-1/3 space-y-3">
            <div className="flex items-center space-x-2 text-brand-brass">
              <Sparkles size={14} />
              <span className="text-[9px] tracking-[0.25em] font-bold uppercase">CHARLOTTE'S CURATION</span>
            </div>
            <h4 className="font-serif text-xl md:text-2xl font-medium tracking-wide">
              AI Gift Assistant
            </h4>
            <p className="text-xs font-light leading-relaxed opacity-80">
              Describe who you are buying for (e.g. "a gourmet home chef", "a business client who loves tea"), and Charlotte will find the ultimate match.
            </p>
          </div>

          <div className="md:w-2/3 w-full space-y-4">
            <form onSubmit={handleAskGiftAdvisor} className="flex gap-2">
              <input
                id="gift-advisor-input"
                type="text"
                required
                value={giftQuery}
                onChange={(e) => setGiftQuery(e.target.value)}
                placeholder="Describe your recipient..."
                className={`flex-1 text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                  isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-[#F7F3EB] border-[#103B2E]/15 text-brand-charcoal'
                }`}
              />
              <button
                id="gift-advisor-submit"
                type="submit"
                disabled={loadingRecommendation}
                className="bg-brand-brass text-brand-charcoal px-6 py-3 text-xs tracking-wider uppercase font-bold transition-all hover:bg-brand-brass/90 disabled:opacity-55 cursor-pointer shrink-0"
              >
                {loadingRecommendation ? 'CONSULTING...' : 'ADVISE ME'}
              </button>
            </form>

            <AnimatePresence mode="wait">
              {giftRecommendation && (
                <motion.div
                  id="gift-recommendation-output"
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="p-4 border border-dashed border-brand-brass/35 bg-brand-brass/5 text-xs font-serif italic text-brand-brass leading-relaxed relative"
                >
                  <button
                    id="clear-gift-rec-btn"
                    onClick={() => setGiftRecommendation(null)}
                    className="absolute top-2 right-2 text-brand-brass opacity-65 hover:opacity-100 cursor-pointer"
                  >
                    <X size={12} />
                  </button>
                  <p className="pr-4">{giftRecommendation}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex flex-wrap items-center gap-2 md:gap-3 mb-12 border-b border-brand-brass/10 pb-4">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`merch-cat-tab-${cat.toLowerCase().replace(' ', '-')}`}
              onClick={() => setSelectedCategory(cat)}
              className={`text-[10px] md:text-xs tracking-[0.2em] px-4 py-2 border rounded-none uppercase transition-all duration-300 cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-brand-brass text-brand-charcoal border-brand-brass font-bold'
                  : isDarkMode
                    ? 'border-brand-stone/10 text-brand-stone/60 hover:border-brand-brass hover:text-brand-brass'
                    : 'border-brand-green/10 text-brand-charcoal/60 hover:border-brand-brass hover:text-brand-brass'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Split Screen Layout: Left Items, Right Interactive Cart */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Items Grid */}
          <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <AnimatePresence mode="popLayout">
              {filteredItems.map((item) => (
                <motion.div
                  key={item.id}
                  id={`merch-card-${item.id}`}
                  layout
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.98 }}
                  className={`border transition-all duration-500 group flex flex-col justify-between ${
                    isDarkMode ? 'bg-[#101010] border-brand-brass/10' : 'bg-[#FAF8F4] border-[#103B2E]/5'
                  }`}
                >
                  <div className="h-56 overflow-hidden relative">
                    {/* Inner graphic thin frame */}
                    <div className="absolute inset-3 border border-brand-brass/15 z-10 pointer-events-none" />
                    <img
                      src={item.image}
                      alt={item.name}
                      className="w-full h-full object-cover filter brightness-[0.75] contrast-[1.05] group-hover:scale-105 transition-transform duration-1000"
                    />
                    <span className="absolute bottom-4 left-4 bg-brand-charcoal/80 border border-brand-brass/25 text-brand-brass text-[9px] tracking-widest font-bold px-2 py-0.5 uppercase z-10">
                      {item.category}
                    </span>
                  </div>

                  <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-baseline">
                        <h4 className="font-serif text-lg font-medium tracking-wide">
                          {item.name}
                        </h4>
                        <span className="text-brand-brass font-serif font-semibold ml-4">
                          ${item.price}
                        </span>
                      </div>
                      <p className={`text-xs font-light leading-relaxed mt-2 opacity-85`}>
                        {item.description}
                      </p>
                      <p className="text-[10px] tracking-wider opacity-60 italic mt-3 font-serif border-t border-brand-brass/5 pt-2">
                        {item.details}
                      </p>
                    </div>

                    <button
                      id={`add-to-cart-btn-${item.id}`}
                      onClick={() => onAddToCart(item)}
                      className="w-full bg-transparent text-brand-brass border border-brand-brass/45 text-xs tracking-[0.2em] py-2.5 uppercase font-bold transition-all duration-300 hover:bg-brand-brass hover:text-brand-charcoal hover:border-brand-brass cursor-pointer"
                    >
                      ADD TO SHOPPING BAG
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {/* Right Column: Checkout/Active Shopping Cart */}
          <div className="lg:col-span-4 lg:sticky lg:top-24">
            <div className={`p-6 border ${
              isDarkMode ? 'bg-[#101010] border-brand-brass/15' : 'bg-[#FAF8F4] border-[#103B2E]/10'
            }`}>
              <div className="flex items-center justify-between border-b border-brand-brass/20 pb-4 mb-4">
                <div className="flex items-center space-x-2">
                  <ShoppingBag size={16} className="text-brand-brass" />
                  <span className="font-serif text-sm font-bold tracking-wider uppercase">Shopping Bag</span>
                </div>
                <span className="text-xs opacity-60 font-bold">{cartItems.length} items</span>
              </div>

              <AnimatePresence mode="wait">
                {checkoutSuccess ? (
                  <motion.div
                    key="checkout-success"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="text-center py-12 space-y-4 text-brand-brass"
                  >
                    <Check size={32} className="mx-auto border border-brand-brass rounded-full p-1 bg-brand-brass/10" />
                    <h5 className="font-serif text-xl font-medium">Dispatch Confirmed</h5>
                    <p className="text-xs text-current/80 font-light leading-relaxed max-w-xs mx-auto">
                      Thank you for your patronage. Your curated British craft goods and cookbook are being prepared for dispatch under strict atmospheric controls. A courier bill is sent to your email.
                    </p>
                  </motion.div>
                ) : cartItems.length > 0 ? (
                  <motion.div key="cart-list" className="space-y-4">
                    <div className="max-h-[300px] overflow-y-auto space-y-4 no-scrollbar">
                      {cartItems.map((c) => (
                        <div
                          key={c.merchandise.id}
                          id={`cart-item-row-${c.merchandise.id}`}
                          className="flex items-center justify-between gap-4 border-b border-brand-brass/5 pb-3 text-xs"
                        >
                          <div className="flex items-center space-x-3">
                            <img
                              src={c.merchandise.image}
                              alt={c.merchandise.name}
                              className="w-10 h-10 object-cover border border-brand-brass/10"
                            />
                            <div>
                              <p className="font-bold truncate max-w-[150px]">{c.merchandise.name}</p>
                              <p className="text-[10px] opacity-60">Qty: {c.quantity} &bull; ${c.merchandise.price}</p>
                            </div>
                          </div>

                          <div className="flex items-center space-x-3">
                            <span className="font-serif font-bold text-brand-brass">${c.merchandise.price * c.quantity}</span>
                            <button
                              id={`remove-cart-item-${c.merchandise.id}`}
                              onClick={() => onRemoveFromCart(c.merchandise.id)}
                              className="text-red-400 hover:text-red-300 p-1 cursor-pointer"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="space-y-3 pt-4 border-t border-brand-brass/15 text-xs">
                      <div className="flex justify-between">
                        <span className="opacity-60">Subtotal</span>
                        <span className="font-serif font-semibold">${subtotal}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="opacity-60">Signature Courier Care</span>
                        <span className="text-brand-brass uppercase font-bold tracking-widest text-[9px]">Complimentary</span>
                      </div>
                      <div className="flex justify-between border-t border-brand-brass/10 pt-3 text-sm font-bold">
                        <span>Total Bill</span>
                        <span className="font-serif text-lg text-brand-brass">${subtotal}</span>
                      </div>
                    </div>

                    <button
                      id="checkout-btn"
                      onClick={handleCheckout}
                      className="w-full bg-brand-brass text-brand-charcoal text-xs tracking-[0.25em] py-3 uppercase font-bold transition-all hover:bg-brand-brass/90 flex items-center justify-center space-x-2 mt-4 cursor-pointer"
                    >
                      <span>CONFIRM COURIER DISPATCH</span>
                      <ArrowRight size={13} />
                    </button>
                  </motion.div>
                ) : (
                  <motion.div
                    key="cart-empty"
                    className="text-center py-12 opacity-60 flex flex-col items-center space-y-2"
                  >
                    <ShoppingBag size={24} className="text-brand-brass opacity-70" />
                    <p className="text-xs font-serif italic">"Your Shopping Bag is empty, sir/madam."</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
