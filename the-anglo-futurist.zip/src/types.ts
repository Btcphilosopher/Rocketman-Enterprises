/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface MenuItem {
  id: string;
  name: string;
  category: 'Starters' | 'Seafood' | 'Grill' | 'Classics' | 'Sunday Roast' | 'Desserts' | 'Cheese';
  price: number;
  description: string;
  originStory: string;
  winePairing: string;
  allergens: string[];
  image: string;
  isSignature?: boolean;
}

export interface Cocktail {
  id: string;
  name: string;
  price: number;
  description: string;
  ingredients: string[];
  glassware: string;
  originStory: string;
  image: string;
}

export interface WineCellarItem {
  id: string;
  name: string;
  region: 'England' | 'France' | 'Italy' | 'Spain' | 'California' | 'Australia';
  vintage: string;
  price: number;
  type: 'Red' | 'White' | 'Sparkling' | 'Fortified';
  description: string;
  pairingNote: string;
}

export interface RestaurantEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  description: string;
  pricePerGuest: number;
  image: string;
}

export interface MerchandiseItem {
  id: string;
  name: string;
  price: number;
  category: 'Cookbooks' | 'Aprons' | 'Tea & Coffee' | 'Glassware' | 'Ceramics' | 'Gift Cards';
  description: string;
  image: string;
  details: string;
}

export interface Reservation {
  id: string;
  name: string;
  email: string;
  phone: string;
  partySize: number;
  date: string;
  time: string;
  notes?: string;
  status: 'Confirmed' | 'Pending' | 'Cancelled';
  createdAt: string;
}

export interface CartItem {
  merchandise: MerchandiseItem;
  quantity: number;
}
