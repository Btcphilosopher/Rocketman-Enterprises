import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Philosophy from './components/Philosophy';
import MenuSection from './components/MenuSection';
import CocktailCarousel from './components/CocktailCarousel';
import WineCellar from './components/WineCellar';
import PrivateDining from './components/PrivateDining';
import ChefSection from './components/ChefSection';
import ReservationSection from './components/ReservationSection';
import StoreSection from './components/StoreSection';
import ManifestoPage from './components/ManifestoPage';
import EventsList from './components/EventsList';
import AIChatBot from './components/AIChatBot';
import { MerchandiseItem, CartItem } from './types';
import { Mail, Compass, Shield, Clock, Phone, MapPin, Heart, ArrowUp, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Brand default mode is Classic Evening (Luxurious Dark)
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [currentView, setCurrentView] = useState<'home' | 'menu' | 'wine' | 'private-dining' | 'manifesto' | 'events' | 'store'>('home');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isReservationOpen, setIsReservationOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [aiTrigger, setAiTrigger] = useState<{ specialist: string; message: string } | null>(null);
  
  // Newsletter State
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Smooth scroll to top when changing views
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  // Shopping Cart Logic
  const handleAddToCart = (item: MerchandiseItem) => {
    setCart((prevCart) => {
      const existing = prevCart.find((c) => c.merchandise.id === item.id);
      if (existing) {
        return prevCart.map((c) =>
          c.merchandise.id === item.id ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [...prevCart, { merchandise: item, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prevCart) => prevCart.filter((c) => c.merchandise.id !== id));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Triggering the AI Sommelier with pre-filled recommendations
  const handleConsultSommelier = (dishName: string, winePairing: string) => {
    setAiTrigger({
      specialist: 'sommelier',
      message: `Greetings. I am interested in ordering the ${dishName}. Could you explain why it pairs so beautifully with the ${winePairing}, and highlight its tasting profile?`
    });
    setIsAIChatOpen(true);
  };

  const handleSubscribeNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterSubscribed(true);
    setTimeout(() => {
      setNewsletterEmail('');
      setNewsletterSubscribed(false);
    }, 5000);
  };

  const cartTotalCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className={`min-h-screen relative font-sans transition-colors duration-500 selection:bg-brand-brass selection:text-brand-charcoal ${
      isDarkMode ? 'bg-[#101010] text-[#FAF8F4]' : 'bg-[#FAF8F4] text-[#101010]'
    }`}>
      {/* "Professional Polish" Elegant Dotted Background Overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.07] radial-dot-pattern z-0" />
      
      {/* Header & Sticky Top Bar */}
      <Navbar
        onNavClick={(view) => setCurrentView(view as any)}
        currentView={currentView}
        cartCount={cartTotalCount}
        onCartToggle={() => {
          setCurrentView('store');
          setIsCartOpen(!isCartOpen);
        }}
        onReservationToggle={() => {
          setIsReservationOpen(true);
          const el = document.getElementById('reservations-section');
          if (el) {
            el.scrollIntoView({ behavior: 'smooth' });
          } else {
            setCurrentView('home');
            setTimeout(() => {
              document.getElementById('reservations-section')?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          }
        }}
        onAIChatToggle={() => setIsAIChatOpen(!isAIChatOpen)}
        isDarkMode={isDarkMode}
        onThemeToggle={() => setIsDarkMode(!isDarkMode)}
      />

      {/* Main Content Area */}
      <main className="pt-20">
        <AnimatePresence mode="wait">
          {currentView === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Hero
                onReserveClick={() => {
                  const el = document.getElementById('reservations-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                onExploreClick={() => {
                  const el = document.getElementById('menu-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                isDarkMode={isDarkMode}
              />
              <Philosophy
                onManifestoClick={() => setCurrentView('manifesto')}
                isDarkMode={isDarkMode}
              />
              <MenuSection
                onConsultSommelier={handleConsultSommelier}
                isDarkMode={isDarkMode}
              />
              <CocktailCarousel isDarkMode={isDarkMode} />
              <WineCellar
                onConsultSommelier={handleConsultSommelier}
                isDarkMode={isDarkMode}
              />
              <PrivateDining isDarkMode={isDarkMode} />
              <ChefSection isDarkMode={isDarkMode} />
              <EventsList
                onReserveClick={() => {
                  const el = document.getElementById('reservations-section');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }}
                isDarkMode={isDarkMode}
              />
              <ReservationSection isDarkMode={isDarkMode} />
            </motion.div>
          )}

          {currentView === 'menu' && (
            <motion.div
              key="menu-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <MenuSection
                onConsultSommelier={handleConsultSommelier}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}

          {currentView === 'wine' && (
            <motion.div
              key="wine-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <WineCellar
                onConsultSommelier={handleConsultSommelier}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}

          {currentView === 'private-dining' && (
            <motion.div
              key="private-dining-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <PrivateDining isDarkMode={isDarkMode} />
            </motion.div>
          )}

          {currentView === 'manifesto' && (
            <motion.div
              key="manifesto-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <ManifestoPage isDarkMode={isDarkMode} />
            </motion.div>
          )}

          {currentView === 'events' && (
            <motion.div
              key="events-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <EventsList
                onReserveClick={() => {
                  setCurrentView('home');
                  setTimeout(() => {
                    document.getElementById('reservations-section')?.scrollIntoView({ behavior: 'smooth' });
                  }, 200);
                }}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}

          {currentView === 'store' && (
            <motion.div
              key="store-page"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <StoreSection
                onAddToCart={handleAddToCart}
                cartItems={cart}
                onRemoveFromCart={handleRemoveFromCart}
                onClearCart={handleClearCart}
                isDarkMode={isDarkMode}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Luxury Editorial Footer */}
      <footer className={`py-24 px-6 md:px-12 border-t transition-colors duration-500 ${
        isDarkMode ? 'bg-[#101010] border-brand-brass/10 text-brand-stone/80' : 'bg-[#FAF8F4] border-[#103B2E]/10 text-brand-charcoal/80'
      }`}>
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 border-b border-brand-brass/10 pb-16">
          
          {/* Identity Column */}
          <div className="space-y-4">
            <span className="font-serif text-xl tracking-[0.2em] font-medium block">
              THE ANGLO-FUTURIST
            </span>
            <p className="text-xs leading-relaxed opacity-80 max-w-xs">
              A contemporary culinary mission in Boston’s Seaport fanning the flames of traditional British craftsmanship.
            </p>
            <div className="flex items-center space-x-2 text-[10px] tracking-[0.2em] uppercase text-brand-brass font-bold">
              <Compass size={13} />
              <span>BOSTON &bull; LONDON</span>
            </div>
          </div>

          {/* Location & Logistical Details */}
          <div className="space-y-4 text-xs">
            <h5 className="font-serif text-sm tracking-wider text-brand-brass font-bold uppercase">
              Location & Valet
            </h5>
            <div className="space-y-3 opacity-90 leading-relaxed">
              <p className="flex items-start space-x-2">
                <MapPin size={14} className="text-brand-brass shrink-0 mt-0.5" />
                <span>284 Seaport Blvd,<br />Boston, MA 02210</span>
              </p>
              <p className="flex items-start space-x-2">
                <Clock size={14} className="text-brand-brass shrink-0 mt-0.5" />
                <span>Mon - Sat: 5:30 PM - 11:00 PM<br />Sunday: 12:00 PM - 10:00 PM</span>
              </p>
              <p className="flex items-start space-x-2">
                <Phone size={14} className="text-brand-brass shrink-0 mt-0.5" />
                <span>+1 (617) 555-1776</span>
              </p>
            </div>
          </div>

          {/* Navigation Links Column */}
          <div className="space-y-4 text-xs">
            <h5 className="font-serif text-sm tracking-wider text-brand-brass font-bold uppercase">
              Navigational Index
            </h5>
            <ul className="space-y-2 font-medium tracking-widest uppercase text-[10px]">
              <li>
                <button onClick={() => setCurrentView('home')} className="hover:text-brand-brass cursor-pointer transition-colors">THE JOURNAL</button>
              </li>
              <li>
                <button onClick={() => setCurrentView('menu')} className="hover:text-brand-brass cursor-pointer transition-colors">THE MENU</button>
              </li>
              <li>
                <button onClick={() => setCurrentView('wine')} className="hover:text-brand-brass cursor-pointer transition-colors">THE CELLAR</button>
              </li>
              <li>
                <button onClick={() => setCurrentView('private-dining')} className="hover:text-brand-brass cursor-pointer transition-colors">PRIVATE SALONS</button>
              </li>
              <li>
                <button onClick={() => setCurrentView('store')} className="hover:text-brand-brass cursor-pointer transition-colors">BOUTIQUE STORE</button>
              </li>
            </ul>
          </div>

          {/* Newsletter / Club column */}
          <div className="space-y-4">
            <h5 className="font-serif text-sm tracking-wider text-brand-brass font-bold uppercase">
              The Sovereign Register
            </h5>
            <p className="text-xs leading-relaxed opacity-80">
              Enlist your email to receive private invitations to our Sunday Roast club, LSE debates, and single-malt salons.
            </p>
            
            <AnimatePresence mode="wait">
              {newsletterSubscribed ? (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-3 border border-brand-brass text-[11px] font-serif italic text-brand-brass"
                >
                  "We have entered you onto our ledger, sir/madam."
                </motion.div>
              ) : (
                <form onSubmit={handleSubscribeNewsletter} className="flex gap-2">
                  <input
                    id="newsletter-email-input"
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email..."
                    className={`flex-1 text-xs p-3 border rounded-none focus:outline-none focus:border-brand-brass ${
                      isDarkMode ? 'bg-[#1D1D1D] border-brand-stone/15 text-white' : 'bg-white border-[#103B2E]/15 text-brand-charcoal'
                    }`}
                  />
                  <button
                    id="newsletter-submit-btn"
                    type="submit"
                    className="bg-brand-brass text-brand-charcoal p-3 hover:bg-brand-brass/90 transition-colors cursor-pointer"
                  >
                    <Mail size={14} />
                  </button>
                </form>
              )}
            </AnimatePresence>
          </div>

        </div>

        {/* Bottom Bar: Accessibilities & Legalities */}
        <div className="max-w-7xl mx-auto pt-8 flex flex-col md:flex-row items-center justify-between text-[11px] opacity-60 font-mono tracking-wider gap-4">
          <p>&copy; {new Date().getFullYear()} The Anglo-Futurist Hospitality Guild. All rights reserved.</p>
          
          <div className="flex flex-wrap gap-6 uppercase tracking-widest text-[9px] font-sans">
            <span className="flex items-center space-x-1">
              <Shield size={11} className="text-brand-brass" />
              <span>Full WCAG AAA Accessible Layout</span>
            </span>
            <span className="cursor-pointer hover:text-brand-brass transition-colors">Private Events Protocol</span>
            <span className="cursor-pointer hover:text-brand-brass transition-colors">Careers & Internships</span>
          </div>
        </div>
      </footer>

      {/* Floating AI Concierge Activation Button */}
      <div className="fixed bottom-6 right-6 z-40">
        <button
          id="floating-ai-concierge-btn"
          onClick={() => setIsAIChatOpen(true)}
          className="bg-brand-brass text-brand-charcoal hover:bg-brand-brass/95 p-4 rounded-full shadow-2xl flex items-center justify-center border border-brand-brass transition-all duration-300 hover:scale-105 cursor-pointer group"
          title="Consult AI Concierge"
        >
          <MessageSquare size={22} className="animate-[pulse_4s_infinite]" />
          <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-500 whitespace-nowrap text-xs tracking-wider font-bold uppercase pl-0 group-hover:pl-2">
            AI Concierge
          </span>
        </button>
      </div>

      {/* AI Chat Bot Side Drawer panel */}
      <AIChatBot
        isOpen={isAIChatOpen}
        onClose={() => setIsAIChatOpen(false)}
        isDarkMode={isDarkMode}
        externalTrigger={aiTrigger}
        onClearTrigger={() => setAiTrigger(null)}
      />

    </div>
  );
}
