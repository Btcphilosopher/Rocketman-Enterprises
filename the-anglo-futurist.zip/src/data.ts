import { MenuItem, Cocktail, WineCellarItem, RestaurantEvent, MerchandiseItem } from './types';

export const MENU_ITEMS: MenuItem[] = [
  // Starters
  {
    id: 'starter-1',
    name: 'North Sea Crab Crumpet',
    category: 'Starters',
    price: 24,
    description: 'Freshly caught Jonah crab, spiced brown butter emulsion, sea herbs, served on a warm, hand-toasted sourdough crumpet.',
    originStory: 'A traditional coastal Yorkshire breakfast staple re-imagined with sweet local New England crab and rich Jersey butter.',
    winePairing: 'English Oak Blanc de Blancs, Hampshire',
    allergens: ['Gluten', 'Shellfish', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?q=80&w=800'
  },
  {
    id: 'starter-2',
    name: 'English Garden Tart',
    category: 'Starters',
    price: 18,
    description: 'Heritage asparagus, whipped goat’s curd, fresh pea shoots, elderflower vinaigrette, nested in a crisp, buttery pastry shell.',
    originStory: 'Inspired by the summer abundance of the Royal Horticultural Society gardens, utilizing Boston organic farm microgreens.',
    winePairing: 'Sauvignon Blanc, Loire Valley, France',
    allergens: ['Gluten', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?q=80&w=800',
    isSignature: true
  },
  {
    id: 'starter-3',
    name: 'Cured Scottish Salmon',
    category: 'Starters',
    price: 22,
    description: 'Hendrick’s Gin-cured Loch Duart salmon, cucumber gel, pickled mustard seed, buttermilk dressing, dill oil.',
    originStory: 'Scottish west-coast fishing craftsmanship paired with botanical gin curing, slicing wafer-thin at tableside.',
    winePairing: 'Chablis Premier Cru, Burgundy, France',
    allergens: ['Fish', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?q=80&w=800'
  },

  // Seafood
  {
    id: 'seafood-1',
    name: 'Scottish Halibut',
    category: 'Seafood',
    price: 48,
    description: 'Pan-roasted North Atlantic halibut, braised leeks, native clams, sea lettuce, drenching in a delicate oyster-champagne velouté.',
    originStory: 'Caught in the deep, cold waters of the North Sea, shipped daily to Boston, and cooked on our bespoke solid steel grill.',
    winePairing: 'Meursault, Burgundy, France',
    allergens: ['Fish', 'Shellfish', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?q=80&w=800',
    isSignature: true
  },
  {
    id: 'seafood-2',
    name: 'Boston-London Lobster Pie',
    category: 'Seafood',
    price: 54,
    description: 'Maine lobster claw and tail meat, slow-simmered in a rich Cognac and tarragon cream, baked under a tall puff pastry dome.',
    originStory: 'A decadent hybrid marrying New England’s celebrated lobster catch with London’s luxury guildhall pie-making heritage.',
    winePairing: 'Chardonnay, Napa Valley, California',
    allergens: ['Gluten', 'Shellfish', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?q=80&w=800',
    isSignature: true
  },

  // Grill
  {
    id: 'grill-1',
    name: 'Dry-Aged Rib of Beef',
    category: 'Grill',
    price: 62,
    description: '14oz Prime Black Angus, dry-aged for 35 days on Himalayan salt bricks, charred over binchotan oak charcoal, beef fat Béarnaise.',
    originStory: 'Sourced from the lush grazing pastures of Vermont, prepared using the traditional dry-aging protocols of London’s historic meat markets.',
    winePairing: 'Cabernet Sauvignon, Bordeaux, France',
    allergens: ['Dairy'],
    image: 'https://images.unsplash.com/photo-1543353071-10c8ba85a904?q=80&w=800'
  },
  {
    id: 'grill-2',
    name: 'Roast Saddle of Lamb',
    category: 'Grill',
    price: 49,
    description: 'Saddle of lamb stuffed with sweetbreads and wild mint, broad bean fricassee, rosemary jus, salt-baked turnip.',
    originStory: 'A celebratory British Sunday centerpiece, brought to Boston to showcase the extraordinary quality of Maine hill lamb.',
    winePairing: 'Chianti Classico Riserva, Tuscany, Italy',
    allergens: ['Dairy'],
    image: 'https://images.unsplash.com/photo-1603048588665-791ca8aea617?q=80&w=800'
  },

  // Classics
  {
    id: 'classic-1',
    name: 'Yorkshire Wagyu Wellington',
    category: 'Classics',
    price: 68,
    description: 'Mishima Reserve Wagyu beef fillet, wild mushroom duxelles, parma ham, buttery crêpe, baked in a crisp golden lattice pastry.',
    originStory: 'The pinnacle of British culinary craftsmanship. Every Wellington is rolled by hand in our pastry salon, aged 24 hours, and baked to medium-rare.',
    winePairing: 'Barolo, Piedmont, Italy',
    allergens: ['Gluten', 'Dairy', 'Eggs'],
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800',
    isSignature: true
  },
  {
    id: 'classic-2',
    name: 'North Sea Style Fish & Chips',
    category: 'Classics',
    price: 36,
    description: 'Day-boat cod fried in a triple-cooked aerated local pale ale batter, beef dripping fat chips, minted marrow peas, tartar sauce.',
    originStory: 'Authentic Yorkshire coastal technique. The cod is caught sustainably, coated in a batter cold-whipped with nitrogen, and fried to perfect crunch.',
    winePairing: 'Brut Reserve Champagne, France',
    allergens: ['Gluten', 'Fish'],
    image: 'https://images.unsplash.com/photo-1579871494447-9811cf80d66c?q=80&w=800'
  },
  {
    id: 'classic-3',
    name: 'Beer-Braised Short Rib',
    category: 'Classics',
    price: 44,
    description: 'Boneless beef short rib slow-braised for 12 hours in Samuel Smith Oatmeal Stout, smoked potato purée, glazed heritage carrots.',
    originStory: 'An industrial Yorkshire northern soul classic, slow-cooked in traditional oak-fermented Yorkshire stout.',
    winePairing: 'Rioja Gran Reserva, Spain',
    allergens: ['Gluten', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800'
  },

  // Sunday Roast
  {
    id: 'sunday-1',
    name: 'The Royal Hereford Sirloin',
    category: 'Sunday Roast',
    price: 46,
    description: 'Dry-aged sliced sirloin, dripping roast potatoes, giant hand-whipped beef-fat Yorkshire pudding, roasted parsnips, bone marrow gravy.',
    originStory: 'Available strictly on Sundays. A majestic celebration of the legendary British Sunday Roast ritual, prepared on our wood hearth.',
    winePairing: 'Syrah, Rhone Valley, France',
    allergens: ['Gluten', 'Dairy', 'Eggs'],
    image: 'https://images.unsplash.com/photo-1543353071-10c8ba85a904?q=80&w=800'
  },

  // Desserts & Cheese
  {
    id: 'dessert-1',
    name: 'Sticky Toffee Soufflé',
    category: 'Desserts',
    price: 18,
    description: 'Light-as-air hot soufflé, Medjool date sponge base, warm sea-salt butterscotch sauce poured tableside, clotted cream ice cream.',
    originStory: 'The meeting of classic French technique and the rich, nostalgic caramel warmth of the Lake District.',
    winePairing: '10-Year-Old Tawny Port, Portugal',
    allergens: ['Gluten', 'Dairy', 'Eggs'],
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?q=80&w=800',
    isSignature: true
  },
  {
    id: 'cheese-1',
    name: 'The British Guild Board',
    category: 'Cheese',
    price: 26,
    description: 'A curated selection of England’s finest cheeses: Colton Bassett Stilton, Montgomery Cheddar, and Baron Bigod, served with honeycomb and oatcakes.',
    originStory: 'Sourced directly from Neal’s Yard Dairy in London, transported under temperature control to preserve the living crust and complex microbiology.',
    winePairing: 'Sauternes, Bordeaux, France',
    allergens: ['Gluten', 'Dairy'],
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=800'
  }
];

export const COCKTAILS: Cocktail[] = [
  {
    id: 'cocktail-1',
    name: 'Empire Martini',
    price: 22,
    description: 'Tanqueray No. Ten Gin, Dry Vermouth infused with Earl Grey tea, orange bitters, lemon oil expressed over crystal ice sphere.',
    ingredients: ['Tanqueray 10 Gin', 'Earl Grey Vermouth', 'Orange Bitters', 'Lemon Oil'],
    glassware: 'Bespoke etched crystal coupette',
    originStory: 'An aristocratic classic re-imagined with the subtle citrus and floral notes of high-altitude bergamot tea.',
    image: 'https://images.unsplash.com/photo-1575037614876-c38a4d44f5b8?q=80&w=600'
  },
  {
    id: 'cocktail-2',
    name: "King's Manhattan",
    price: 24,
    description: 'Woodford Reserve Rye, sweet vermouth macerated with dried British damson plums, Angostura, smoked cherrywood mist.',
    ingredients: ['Rye Whiskey', 'Damson Vermouth', 'Aromatic Bitters', 'Cherrywood Smoke'],
    glassware: 'Heavy cut crystal rocks glass',
    originStory: 'A robust American spirit tamed by the deep, forest-fruit tartness of native English damsons.',
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?q=80&w=600'
  },
  {
    id: 'cocktail-3',
    name: 'Oxford Negroni',
    price: 20,
    description: 'Sipsmith London Dry Gin, Campari, Cocchi di Torino, orange wheel, with a drop of saline solution for mineral depth.',
    ingredients: ['Sipsmith Gin', 'Campari', 'Cocchi Vermouth', 'Saline'],
    glassware: 'Faceted tumbler with custom monogram',
    originStory: 'Developed for the high-table salons of Oxford’s classical scholars, sharp, herbal, and unapologetically bitter.',
    image: 'https://images.unsplash.com/photo-1510626176961-4b57d4fbfc02?q=80&w=600'
  },
  {
    id: 'cocktail-4',
    name: 'The Commonwealth',
    price: 21,
    description: 'Bulleit Bourbon, Yorkshire ginger beer, apple cider shrub, fresh lime juice, Angostura float, rosemary torch.',
    ingredients: ['Bourbon', 'Ginger Beer', 'Cider Shrub', 'Lime', 'Rosemary'],
    glassware: 'Hammered brass goblet',
    originStory: 'A botanical bridge between New England’s historic apple orchards and Yorkshire’s legendary ginger brewing craft.',
    image: 'https://images.unsplash.com/photo-1536935338788-846bb9981813?q=80&w=600'
  },
  {
    id: 'cocktail-5',
    name: 'Yorkshire Old Fashioned',
    price: 23,
    description: 'Macallan 12 Double Cask Whisky, dark brown muscovado sugar syrup, walnut bitters, orange peel.',
    ingredients: ['Macallan 12', 'Muscovado', 'Walnut Bitters', 'Orange Peel'],
    glassware: 'Weighted double rocks glass',
    originStory: 'Rich molasses and fine Speyside malt wood-notes unite to evoke the coal-fired warmth of Yorkshire hearths.',
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?q=80&w=600'
  },
  {
    id: 'cocktail-6',
    name: 'London Fog',
    price: 19,
    description: 'Hendrick’s Gin, lavender infused honey, steamed almond milk, bergamot mist, served hot on raw slate.',
    ingredients: ['Hendrick’s Gin', 'Lavender Honey', 'Steamed Milk', 'Bergamot Mist'],
    glassware: 'Ceramic teacup handcrafted in Yorkshire',
    originStory: 'A soothing evening tonic inspired by the thick, atmospheric mists rolling across London’s riverbanks.',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=600'
  }
];

export const WINES: WineCellarItem[] = [
  // England
  {
    id: 'wine-1',
    name: 'Gusbourne Brut Reserve',
    region: 'England',
    vintage: '2019',
    price: 135,
    type: 'Sparkling',
    description: 'Bright golden colour with delicate aromas of green apple, pear, and toasted brioche. Outstanding chalky minerality.',
    pairingNote: 'Stunning with the North Sea Crab Crumpet and Oyster Velouté.'
  },
  {
    id: 'wine-2',
    name: 'Nyetimber Tillington Single Vineyard',
    region: 'England',
    vintage: '2014',
    price: 260,
    type: 'Sparkling',
    description: 'Ultra-refined palate with red fruit highlights, toasted almond, and honeyed complexity. Truly world-class.',
    pairingNote: 'The ultimate partner for the Cured Scottish Salmon.'
  },

  // France
  {
    id: 'wine-3',
    name: 'Domaine Leflaive Puligny-Montrachet',
    region: 'France',
    vintage: '2020',
    price: 380,
    type: 'White',
    description: 'Sensational precision. Flinty reduction, lemon zest, white flowers, and incredibly persistent buttery salinity.',
    pairingNote: 'Magnificent with our signature Scottish Halibut.'
  },
  {
    id: 'wine-4',
    name: 'Château Margaux 3ème Vin',
    region: 'France',
    vintage: '2017',
    price: 290,
    type: 'Red',
    description: 'Silk and graphite. Dark plum, cedarwood, violets, and elegant, fine-grained aristocratic tannins.',
    pairingNote: 'Designed specifically for the Yorkshire Wagyu Wellington.'
  },

  // Italy
  {
    id: 'wine-5',
    name: 'Gaja Barbaresco DOCG',
    region: 'Italy',
    vintage: '2018',
    price: 340,
    type: 'Red',
    description: 'Nebbiolo perfection. Sour cherry, licorice, dried rose petals, leather, and muscular structure.',
    pairingNote: 'Splendid companion to the Roast Saddle of Lamb.'
  },

  // Spain
  {
    id: 'wine-6',
    name: 'La Rioja Alta Gran Reserva 904',
    region: 'Spain',
    vintage: '2011',
    price: 180,
    type: 'Red',
    description: 'Nose of sweet tobacco, vanilla bean, dried figs, and warm spices. Perfectly polished acid line.',
    pairingNote: 'Complements the deep caramelized crust of our Short Rib.'
  },

  // California
  {
    id: 'wine-7',
    name: 'Kistler Les Noisetiers Chardonnay',
    region: 'California',
    vintage: '2021',
    price: 165,
    type: 'White',
    description: 'Opulent yet fresh. Crushed seashells, toasted hazelnuts, stone fruits, with a luxurious, layered finish.',
    pairingNote: 'Harmonizes with the rich butter cream of the Lobster Pie.'
  },

  // Australia
  {
    id: 'wine-8',
    name: 'Penfolds Grange Bin 95 Syrah',
    region: 'Australia',
    vintage: '2016',
    price: 950,
    type: 'Red',
    description: 'A dark, brooding masterpiece. Ink, black pepper, espresso, and intense, muscular French oak tannins.',
    pairingNote: 'A monumental choice for the Dry-Aged Rib of Beef.'
  }
];

export const EVENTS: RestaurantEvent[] = [
  {
    id: 'event-1',
    title: 'Sunday Roast Club',
    date: 'Every Sunday',
    time: '12:00 PM - 8:00 PM',
    description: 'The great British weekly gathering. Sliced Vermont Hereford sirloin, triple-cooked duck fat potatoes, towering Yorkshires, and unlimited rich bone marrow gravy. Accompanied by live acoustic cello.',
    pricePerGuest: 55,
    image: 'https://images.unsplash.com/photo-1543353071-10c8ba85a904?q=80&w=800'
  },
  {
    id: 'event-2',
    title: 'British Jazz & Oyster Night',
    date: 'Thursdays',
    time: '7:30 PM - 11:00 PM',
    description: 'Fresh shucked Wellfleet oysters with traditional shallot vinegar, pairing with rare English sparkling wines while Boston’s finest musicians play early 20th-century British avant-garde jazz.',
    pricePerGuest: 85,
    image: 'https://images.unsplash.com/photo-1514933651103-005eec06c04b?q=80&w=800'
  },
  {
    id: 'event-3',
    title: 'Harvard Philosophy Dinner',
    date: 'Monthly, Second Wednesday',
    time: '6:30 PM - 10:00 PM',
    description: 'A highly structured four-course culinary salon in our Oak Room. Scholars and guests discuss metaphysics, logic, and aesthetics over aged Scotch, curated by visiting faculty.',
    pricePerGuest: 150,
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=800'
  },
  {
    id: 'event-4',
    title: 'Churchill Supper & Single Malt Salon',
    date: 'Third Saturday of the Month',
    time: '8:00 PM - Late',
    description: 'An immersive journey through Winston Churchill’s favourite dishes. Filet of beef, Stilton, and chocolate truffles, followed by a bespoke flight of rare, oak-aged single malt Scotch whiskies.',
    pricePerGuest: 175,
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187?q=80&w=800'
  }
];

export const MERCHANDISE: MerchandiseItem[] = [
  {
    id: 'merch-1',
    name: 'The Anglo-Futurist Manifesto Cookbook',
    price: 65,
    category: 'Cookbooks',
    description: 'A stunning linen-bound volume featuring 80 signature recipes, culinary philosophies, and photographic essays of British craftsmanship in New England.',
    image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?q=80&w=600',
    details: 'Hardcover, 280 pages. Fine art paper. Published by London-Boston Press.'
  },
  {
    id: 'merch-2',
    name: 'Selvedge Denim Chef’s Apron',
    price: 110,
    category: 'Aprons',
    description: 'Crafted from raw 14oz Japanese selvedge indigo denim, double-stitched and fitted with sand-cast brass hardware, leather ties, and utility pocketing.',
    image: 'https://images.unsplash.com/photo-1595152772835-219674b2a8a6?q=80&w=600',
    details: 'One size fits all. Made in collaboration with Boston heritage tailors. Hand-wash only.'
  },
  {
    id: 'merch-3',
    name: 'The Royal Sovereign Breakfast Blend',
    price: 32,
    category: 'Tea & Coffee',
    description: 'A magnificent, highly caffeinated loose-leaf tea blend combining malted Assam, fragrant Ceylon, and rare smoked Lapsang Souchong leaves.',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=600',
    details: '150g tin canister. Loose leaf. Sourced sustainably from ethical gardens.'
  },
  {
    id: 'merch-4',
    name: 'Hand-blown Crystal Cut-Glass Tumbler',
    price: 75,
    category: 'Glassware',
    description: 'An exquisite, heavy-bottomed lead-free crystal glass meticulously hand-cut with traditional geometric patterns. Perfect weight and clarity.',
    image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?q=80&w=600',
    details: 'Sold individually. 320ml. Dishwasher safe, though hand-washing is recommended.'
  },
  {
    id: 'merch-5',
    name: 'Stoneware Plating Bowl from Yorkshire',
    price: 85,
    category: 'Ceramics',
    description: 'Each piece is hand-thrown in a Yorkshire studio using mineral-rich northern clay. Finished in a dual-matte anthracite and iron rust reactive glaze.',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?q=80&w=600',
    details: '22cm diameter. Microwave and dishwasher safe. Unique variation on each bowl.'
  }
];
