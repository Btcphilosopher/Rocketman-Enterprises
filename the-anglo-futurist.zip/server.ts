import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini SDK with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// AI System Instructions for Specialists
const SPECIALISTS_SYSTEM_PROMPTS: Record<string, string> = {
  sommelier: `You are Alistair, the Chief Sommelier of The Anglo-Futurist in Boston. 
You are highly sophisticated, knowledgeable, and elegant. You speak with a polished British accent.
Your expertise covers English sparkling wines (like Gusbourne and Nyetimber), French classics, and fine global vintages.
Provide recommendations based on our menu (such as Yorkshire Wagyu Wellington paired with Barolo or Chateau Margaux, or Halibut with Meursault).
Keep your tone incredibly refined, professional, and slightly poetic about tasting notes. Avoid emojis, unless very subtle.`,

  maitred: `You are Edward, the Maitre D' of The Anglo-Futurist. 
You represent the absolute pinnacle of British hospitality: charming, attentive, witty, and perfectly composed.
You help guests with reservation requests, dress code (smart elegant / business casual, no athletic wear), hours of operation (Mon-Sat 5:30 PM - 11 PM, Sun 12 PM - 10 PM), and parking (valet available on Seaport Blvd).
You should welcome guests warmly, refer to them with polite deference, and speak with high aristocratic poise.`,

  planner: `You are Victoria, the Private Events Director at The Anglo-Futurist.
You curate bespoke events in our private rooms: The Oak Room, The Cambridge Library, and The Boston Glasshouse.
Your clients include Harvard professors, MIT researchers, and Seaport CEOs.
When a user describes an event (guests, occasion, style), propose a beautiful, bespoke menu, specify which room fits best, and detail the atmosphere.
Keep your tone elegant, business-minded, organized, and deeply hospitable.`,

  dietary: `You are Charlotte, the Dietary & Curated Gift Concierge at The Anglo-Futurist.
You help guests navigate food allergies (gluten, dairy, shellfish, nuts) and dietary preferences, guiding them towards our suitable dishes.
You also curate gourmet gifting suggestions from our merchandise (Manifesto Cookbook, Selvedge Denim Apron, crystal tumblers, reactive glaze Yorkshire ceramics).
Your tone is deeply attentive, warm, safe, helpful, and sophisticated.`
};

// API Endpoint for AI Specialists Chat
app.post("/api/ai/chat", async (req, res) => {
  try {
    const { message, specialist, history } = req.body;

    if (!message) {
      return res.status(400).json({ error: "Message is required." });
    }

    const systemPrompt = SPECIALISTS_SYSTEM_PROMPTS[specialist] || SPECIALISTS_SYSTEM_PROMPTS.maitred;

    // Check if API key is present
    if (!process.env.GEMINI_API_KEY) {
      return res.json({ 
        text: "My apologies, sir/madam. My internal connection to the wine cellar and database seems to be momentarily offline (API Key not configured). I am pleased to assist you in spirit, but cannot query my AI oracle right now." 
      });
    }

    // Format contents with systemInstruction and history if available
    const formattedContents = [];
    
    // Add history if present
    if (history && Array.isArray(history)) {
      history.forEach((h: { role: 'user' | 'model'; text: string }) => {
        formattedContents.push({
          role: h.role === 'user' ? 'user' : 'model',
          parts: [{ text: h.text }]
        });
      });
    }
    
    // Append current message
    formattedContents.push({
      role: 'user',
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: formattedContents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: "Internal Server Error", details: error.message });
  }
});

// Simulated OpenTable API Endpoint (Stores in-memory reservations)
const reservations: any[] = [];

app.post("/api/reservations", (req, res) => {
  try {
    const { name, email, phone, partySize, date, time, notes } = req.body;

    if (!name || !email || !phone || !partySize || !date || !time) {
      return res.status(400).json({ error: "All fields are required." });
    }

    const reservation = {
      id: `RES-${Math.floor(100000 + Math.random() * 900000)}`,
      name,
      email,
      phone,
      partySize,
      date,
      time,
      notes,
      status: 'Confirmed',
      createdAt: new Date().toISOString()
    };

    reservations.push(reservation);
    res.json({ success: true, reservation });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

app.get("/api/reservations", (req, res) => {
  res.json(reservations);
});

// Setup Vite Dev Server / Production serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`The Anglo-Futurist server listening on http://localhost:${PORT}`);
  });
}

startServer();
