package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.BankCard
import com.example.data.model.Transaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Transaction::class, BankCard::class], version = 1, exportSchema = false)
abstract class BankDatabase : RoomDatabase() {
    abstract fun bankDao(): BankDao

    companion object {
        @Volatile
        private var INSTANCE: BankDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): BankDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BankDatabase::class.java,
                    "yunshan_bank_db"
                )
                .addCallback(BankDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class BankDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.bankDao())
                }
            }
        }

        suspend fun populateDatabase(dao: BankDao) {
            val now = System.currentTimeMillis()
            
            // Insert default transactions exactly from the phone mockup in the design image
            dao.insertTransaction(
                Transaction(
                    title = "Alipay",
                    category = "Shopping",
                    timestamp = now - 1000 * 60 * 15, // 15 mins ago (approx Today 10:24)
                    amount = -320.00
                )
            )
            dao.insertTransaction(
                Transaction(
                    title = "Starbucks",
                    category = "Food & Drink",
                    timestamp = now - 1000 * 60 * 60 * 2, // 2 hours ago (approx Today 08:17)
                    amount = -68.00
                )
            )
            dao.insertTransaction(
                Transaction(
                    title = "Salary",
                    category = "Income",
                    timestamp = now - 1000 * 60 * 60 * 18, // Yesterday afternoon (approx Yesterday 16:03)
                    amount = 12000.00
                )
            )
            
            // Add some other interesting transactions for depth and realism
            dao.insertTransaction(
                Transaction(
                    title = "WeChat Pay",
                    category = "Transfer",
                    timestamp = now - 1000 * 60 * 60 * 30,
                    amount = -150.00
                )
            )
            dao.insertTransaction(
                Transaction(
                    title = "Yunshan Smart Savings Interest",
                    category = "Income",
                    timestamp = now - 1000 * 60 * 60 * 48,
                    amount = 312.50
                )
            )

            // Insert default credit/debit cards
            dao.insertCard(
                BankCard(
                    cardNumber = "•••• •••• •••• 8848",
                    cardHolder = "TOM AHYX",
                    cardType = "Debit",
                    cardBrand = "UnionPay",
                    expiryDate = "12/29",
                    colorHex = "#111622", // Elegant Dark Slate matching phone mockup style
                    isFrozen = false
                )
            )
            dao.insertCard(
                BankCard(
                    cardNumber = "•••• •••• •••• 6688",
                    cardHolder = "TOM AHYX",
                    cardType = "Credit",
                    cardBrand = "Visa",
                    expiryDate = "05/30",
                    colorHex = "#1D3B2B", // Spruce Forest Green matching Spruce theme
                    isFrozen = false
                )
            )
            dao.insertCard(
                BankCard(
                    cardNumber = "•••• •••• •••• 9999",
                    cardHolder = "TOM AHYX",
                    cardType = "Credit",
                    cardBrand = "Mastercard",
                    expiryDate = "09/31",
                    colorHex = "#7C6335", // Warm Premium Gold
                    isFrozen = false
                )
            )
        }
    }
}
