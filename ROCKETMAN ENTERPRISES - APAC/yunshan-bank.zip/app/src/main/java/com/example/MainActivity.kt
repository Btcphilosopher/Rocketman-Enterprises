package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.data.database.BankDatabase
import com.example.data.repository.BankRepository
import com.example.ui.components.ActionDialogs
import com.example.ui.screens.CardsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MeScreen
import com.example.ui.screens.WealthScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.BankViewModel
import com.example.ui.viewmodel.BankViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup local Room database and repository using lifecycleScope
        val database = BankDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = BankRepository(database.bankDao())
        
        // Initialize the ViewModel using Factory pattern
        val viewModelFactory = BankViewModelFactory(repository)
        val viewModel = ViewModelProvider(this, viewModelFactory)[BankViewModel::class.java]

        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                // Intercept hardware Back Button to navigate correctly between screens/dialogs
                val activeDialog by viewModel.activeDialog.collectAsState()
                val currentTab by viewModel.currentTab.collectAsState()

                BackHandler(enabled = activeDialog != null || currentTab != "Home") {
                    if (activeDialog != null) {
                        viewModel.closeDialog()
                    } else {
                        viewModel.handleBackNavigation()
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        BottomNavigationBar(viewModel = viewModel)
                    }
                ) { innerPadding ->
                    Box(modifier = Modifier.padding(innerPadding)) {
                        when (currentTab) {
                            "Home" -> HomeScreen(viewModel = viewModel)
                            "Cards" -> CardsScreen(viewModel = viewModel)
                            "Wealth" -> WealthScreen(viewModel = viewModel)
                            "Me" -> MeScreen(viewModel = viewModel)
                        }

                        // Overlay for Action Dialogs (Transfer, Pay, Top Up, Add Card, Savings)
                        ActionDialogs(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun BottomNavigationBar(viewModel: BankViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    val tabs = listOf(
        NavigationTab("Home", viewModel.getString("home"), Icons.Filled.Home, Icons.Outlined.Home, "tab_home"),
        NavigationTab("Cards", viewModel.getString("cards"), Icons.Filled.CreditCard, Icons.Outlined.CreditCard, "tab_cards"),
        NavigationTab("Wealth", viewModel.getString("wealth"), Icons.Filled.TrendingUp, Icons.Outlined.TrendingUp, "tab_wealth"),
        NavigationTab("Me", viewModel.getString("me"), Icons.Filled.Person, Icons.Outlined.Person, "tab_me")
    )

    NavigationBar(
        containerColor = Color.White,
        tonalElevation = 8.dp,
        modifier = Modifier.testTag("app_bottom_navigation")
    ) {
        tabs.forEach { tab ->
            val isSelected = currentTab == tab.route
            val activeIcon = tab.filledIcon
            val inactiveIcon = tab.outlinedIcon

            NavigationBarItem(
                selected = isSelected,
                onClick = { viewModel.selectTab(tab.route) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) activeIcon else inactiveIcon,
                        contentDescription = tab.label,
                        modifier = Modifier.size(24.dp)
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color(0xFF11151D),
                    unselectedIconColor = Color(0xFF64748B),
                    selectedTextColor = Color(0xFF11151D),
                    unselectedTextColor = Color(0xFF64748B),
                    indicatorColor = Color(0xFFE2E8F0) // clean modern inactive pill
                ),
                modifier = Modifier.testTag(tab.testTag)
            )
        }
    }
}

data class NavigationTab(
    val route: String,
    val label: String,
    val filledIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val outlinedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
)
