package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BankViewModel

@Composable
fun WealthScreen(viewModel: BankViewModel) {
    val scrollState = rememberScrollState()
    val transactions by viewModel.transactions.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedTicker by remember { mutableStateOf("SHCOMP") }

    // Market indices mock statistics from image footer banner
    val marketTickers = listOf(
        MarketTicker("SHCOMP", "3,283.45", "+1.24%", true, listOf(0.1f, 0.3f, 0.25f, 0.45f, 0.6f, 0.55f, 0.8f)),
        MarketTicker("HKEX", "17,432.08", "+0.86%", true, listOf(0.5f, 0.4f, 0.6f, 0.55f, 0.7f, 0.65f, 0.75f)),
        MarketTicker("USD/CNY", "7.16", "-0.12%", false, listOf(0.9f, 0.8f, 0.85f, 0.6f, 0.65f, 0.4f, 0.35f)),
        MarketTicker("BTC", "68,432.10", "+2.34%", true, listOf(0.1f, 0.4f, 0.3f, 0.5f, 0.75f, 0.65f, 0.95f))
    )

    val activeTicker = marketTickers.firstOrNull { it.symbol == selectedTicker } ?: marketTickers.first()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp, bottom = 120.dp)
    ) {
        // Title
        Text(
            text = viewModel.getString("wealth"),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF11151D)
        )
        Text(
            text = viewModel.getString("desktop_title"),
            fontSize = 12.sp,
            color = Color(0xFF64748B)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Markets Banner exactly mirroring the ticker at the bottom of the landing page
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            marketTickers.forEach { ticker ->
                val isSelected = selectedTicker == ticker.symbol
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { selectedTicker = ticker.symbol }
                        .border(
                            width = if (isSelected) 2.dp else 0.dp,
                            color = if (isSelected) Color(0xFFE5C158) else Color.Transparent,
                            shape = RoundedCornerShape(12.dp)
                        ),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text(ticker.symbol, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(ticker.price, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF11151D))
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (ticker.isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                                contentDescription = null,
                                tint = if (ticker.isPositive) Color(0xFF10B981) else Color(0xFFEF4444),
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = ticker.change,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (ticker.isPositive) Color(0xFF10B981) else Color(0xFFEF4444)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Canvas Chart for selected Ticker
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(160.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.TrendingUp, contentDescription = "Trend", tint = Color(0xFFE5C158))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${activeTicker.symbol} Live Index",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF11151D)
                        )
                    }

                    Text(
                        text = activeTicker.price,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (activeTicker.isPositive) Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Canvas line graph
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    val w = size.width
                    val h = size.height
                    val data = activeTicker.points

                    val strokeColor = if (activeTicker.isPositive) Color(0xFF10B981) else Color(0xFFEF4444)

                    // Draw grid reference
                    drawLine(Color(0xFFF1F5F9), Offset(0f, h * 0.5f), Offset(w, h * 0.5f), strokeWidth = 1.dp.toPx())

                    val points = data.mapIndexed { idx, value ->
                        val x = w * (idx.toFloat() / (data.size - 1))
                        val y = h * (1f - value)
                        Offset(x, y)
                    }

                    val path = Path().apply {
                        moveTo(points[0].x, points[0].y)
                        for (i in 1 until points.size) {
                            lineTo(points[i].x, points[i].y)
                        }
                    }

                    drawPath(
                        path = path,
                        color = strokeColor,
                        style = Stroke(width = 2.5.dp.toPx())
                    )

                    // End indicator dot
                    drawCircle(
                        color = strokeColor,
                        radius = 4.dp.toPx(),
                        center = points.last()
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. High-yield Spruce Wealth Packages
        Text(
            text = "Wealth Management Portfolios",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF11151D)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            WealthProductCard(
                title = "Yunshan Fixed Savings",
                apr = "3.25%",
                risk = "Low Risk • Guaranteed",
                color = Color(0xFF111622),
                onClick = { viewModel.openDialog("Savings") }
            )
            WealthProductCard(
                title = "Spruce Balanced ESG Index",
                apr = "6.80%",
                risk = "Medium Risk • Compound",
                color = Color(0xFF1D3B2B),
                onClick = { viewModel.openDialog("Savings") }
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. Transactions Audit Search Panel
        Text(
            text = "Audit transaction logs",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF11151D)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Search text field
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search transactions (e.g. Starbucks, Alipay)...") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp),
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedBorderColor = Color(0xFF11151D),
                unfocusedBorderColor = Color(0xFFE2E8F0)
            )
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Filter and render list
        val filteredList = transactions.filter {
            it.title.contains(searchQuery, ignoreCase = true) ||
            it.category.contains(searchQuery, ignoreCase = true)
        }

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No matching transactions found.", color = Color(0xFF64748B), fontSize = 13.sp)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                filteredList.forEach { tx ->
                    TransactionItem(tx, viewModel)
                }
            }
        }
    }
}

@Composable
fun WealthProductCard(
    title: String,
    apr: String,
    risk: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(color, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = apr.take(1),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF11151D))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(risk, fontSize = 11.sp, color = Color(0xFF64748B))
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(apr, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE5C158))
                Text("Est. APR", fontSize = 10.sp, color = Color(0xFF94A3B8))
            }
        }
    }
}

data class MarketTicker(
    val symbol: String,
    val price: String,
    val change: String,
    val isPositive: Boolean,
    val points: List<Float>
)
