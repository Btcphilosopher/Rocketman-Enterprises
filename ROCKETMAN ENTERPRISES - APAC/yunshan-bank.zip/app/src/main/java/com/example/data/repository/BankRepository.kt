package com.example.data.repository

import com.example.data.database.BankDao
import com.example.data.model.BankCard
import com.example.data.model.Transaction
import kotlinx.coroutines.flow.Flow

class BankRepository(private val bankDao: BankDao) {
    val allTransactions: Flow<List<Transaction>> = bankDao.getAllTransactions()
    val allCards: Flow<List<BankCard>> = bankDao.getAllCards()

    suspend fun insertTransaction(transaction: Transaction) {
        bankDao.insertTransaction(transaction)
    }

    suspend fun deleteTransaction(id: Int) {
        bankDao.deleteTransactionById(id)
    }

    suspend fun insertCard(card: BankCard) {
        bankDao.insertCard(card)
    }

    suspend fun updateCard(card: BankCard) {
        bankDao.updateCard(card)
    }

    suspend fun deleteCard(id: Int) {
        bankDao.deleteCardById(id)
    }
}
