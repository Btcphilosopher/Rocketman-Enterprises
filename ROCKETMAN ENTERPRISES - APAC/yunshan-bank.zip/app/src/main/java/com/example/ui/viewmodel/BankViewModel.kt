package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.BankCard
import com.example.data.model.Transaction
import com.example.data.repository.BankRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class BankViewModel(private val repository: BankRepository) : ViewModel() {

    // Base constant balance: 116,848.00. Added to transaction sum, it gives exactly ¥128,460.00 with default database!
    private val baseBalance = 116848.00

    // Transactions list
    val transactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Bank cards list
    val cards: StateFlow<List<BankCard>> = repository.allCards
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Computed total balance (reactive)
    val totalBalance: StateFlow<Double> = transactions
        .combine(MutableStateFlow(baseBalance)) { transactionList, base ->
            base + transactionList.sumOf { it.amount }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = baseBalance
        )

    // Balance visibility toggle
    private val _isBalanceVisible = MutableStateFlow(true)
    val isBalanceVisible: StateFlow<Boolean> = _isBalanceVisible.asStateFlow()

    fun toggleBalanceVisibility() {
        _isBalanceVisible.value = !_isBalanceVisible.value
    }

    // App Navigation tabs: "Home", "Cards", "Wealth", "Me"
    private val _currentTab = MutableStateFlow("Home")
    val currentTab: StateFlow<String> = _currentTab.asStateFlow()

    // Navigation back stack for safe physical back button navigation
    private val tabBackStack = mutableListOf<String>()

    fun selectTab(tab: String) {
        if (_currentTab.value != tab) {
            tabBackStack.add(_currentTab.value)
            _currentTab.value = tab
        }
    }

    fun handleBackNavigation(): Boolean {
        if (tabBackStack.isNotEmpty()) {
            _currentTab.value = tabBackStack.removeAt(tabBackStack.size - 1)
            return true // Back handled
        }
        return false // Let system handle (exit app)
    }

    // Language state: "EN" (English) vs "CN" (Chinese)
    private val _language = MutableStateFlow("EN")
    val language: StateFlow<String> = _language.asStateFlow()

    fun toggleLanguage() {
        _language.value = if (_language.value == "EN") "CN" else "EN"
    }

    fun setLanguage(lang: String) {
        if (lang == "EN" || lang == "CN") {
            _language.value = lang
        }
    }

    // Active full-screen/sheet dialogs: "Transfer", "Pay", "TopUp", "AddCard", "Savings", "ViewAll", null
    private val _activeDialog = MutableStateFlow<String?>(null)
    val activeDialog: StateFlow<String?> = _activeDialog.asStateFlow()

    fun openDialog(dialogType: String) {
        _activeDialog.value = dialogType
    }

    fun closeDialog() {
        _activeDialog.value = null
    }

    // Interactive Transaction additions
    fun makeTransfer(recipientName: String, amount: Double, category: String) {
        viewModelScope.launch {
            val tx = Transaction(
                title = recipientName.ifEmpty { "Transfer to Friend" },
                category = "Transfer",
                timestamp = System.currentTimeMillis(),
                amount = -amount
            )
            repository.insertTransaction(tx)
        }
    }

    fun makePayment(merchantName: String, amount: Double, cardId: Int) {
        viewModelScope.launch {
            val tx = Transaction(
                title = merchantName.ifEmpty { "Store Merchant" },
                category = "Shopping",
                timestamp = System.currentTimeMillis(),
                amount = -amount
            )
            repository.insertTransaction(tx)
        }
    }

    fun topUpBalance(amount: Double) {
        viewModelScope.launch {
            val tx = Transaction(
                title = "Top Up",
                category = "Top Up",
                timestamp = System.currentTimeMillis(),
                amount = amount
            )
            repository.insertTransaction(tx)
        }
    }

    // Card Management
    fun addNewCard(cardNumber: String, cardType: String, cardBrand: String, colorHex: String) {
        viewModelScope.launch {
            val card = BankCard(
                cardNumber = "•••• •••• •••• " + cardNumber.takeLast(4).padStart(4, '0'),
                cardHolder = "TOM AHYX",
                cardType = cardType,
                cardBrand = cardBrand,
                expiryDate = "10/31",
                colorHex = colorHex.ifEmpty { "#111622" },
                isFrozen = false
            )
            repository.insertCard(card)
        }
    }

    fun toggleCardFreeze(card: BankCard) {
        viewModelScope.launch {
            repository.updateCard(card.copy(isFrozen = !card.isFrozen))
        }
    }

    fun deleteCard(cardId: Int) {
        viewModelScope.launch {
            repository.deleteCard(cardId)
        }
    }

    // Localization helper dictionary
    private val localizations = mapOf(
        "CN" to mapOf(
            "total_balance" to "总余额",
            "transfer" to "转账",
            "pay" to "付款",
            "top_up" to "充值",
            "more" to "更多",
            "smart_savings" to "智能储蓄",
            "annual_rate" to "年化利率",
            "recent_tx" to "最近交易",
            "view_all" to "查看全部",
            "home" to "首页",
            "cards" to "卡片",
            "wealth" to "财富",
            "me" to "我的",
            "open_account" to "立即开户",
            "learn_more" to "了解更多",
            "global_markets" to "全球市场",
            "ann_interest_rate" to "年利率",
            "today" to "今天",
            "yesterday" to "昨天",
            "recipient" to "收款人姓名",
            "amount" to "金额",
            "memo" to "备注",
            "confirm" to "确认",
            "cancel" to "取消",
            "alipay" to "支付宝",
            "starbucks" to "星巴克",
            "salary" to "工资收入",
            "card_holder" to "持卡人",
            "add_new_card" to "添加新卡",
            "freeze" to "冻结卡片",
            "unfreeze" to "解冻卡片",
            "delete_card" to "注销此卡",
            "interest_calculator" to "利息收益计算器",
            "calc_help" to "输入您的存期金额，查看年化 3.25% 下的复利收益！",
            "deposit_amount" to "存款本金 (¥)",
            "est_return_1y" to "1年预计收益: ",
            "est_return_3y" to "3年预计收益: ",
            "est_return_5y" to "5年预计收益: ",
            "analytics" to "账单消费统计分析",
            "spending_breakdown" to "本月支出分类比例",
            "no_spending" to "本期无支出数据",
            "smarter_banking" to "更智能、更互联的数字银行",
            "desktop_title" to "云杉银行 • 科技连接世界",
            "app_subtitle" to "云杉银行汇聚数字银行、全球支付与智能金融——全在单一App中。",
            "smarter_way" to "一种更明智的理财选择",
            "open_account_title" to "开立个人理财账户",
            "username" to "用户名",
            "security" to "安全设置",
            "biometrics" to "指纹/面容快速支付",
            "developer_options" to "开发者工具",
            "reset_db" to "清空并重置数据库",
            "theme" to "主题风格",
            "dark_mode" to "深色模式",
            "light_mode" to "浅色模式",
            "select_card_pay" to "选择付款卡片",
            "enter_merchant" to "商户名称",
            "payment_success" to "付款成功",
            "transfer_success" to "转账成功",
            "topup_success" to "充值成功"
        ),
        "EN" to mapOf(
            "total_balance" to "Total Balance",
            "transfer" to "Transfer",
            "pay" to "Pay",
            "top_up" to "Top Up",
            "more" to "More",
            "smart_savings" to "Smart Savings",
            "annual_rate" to "Annual Rate",
            "recent_tx" to "Recent Transactions",
            "view_all" to "View All",
            "home" to "Home",
            "cards" to "Cards",
            "wealth" to "Wealth",
            "me" to "Me",
            "open_account" to "Open Account",
            "learn_more" to "Learn More",
            "global_markets" to "Global Markets",
            "ann_interest_rate" to "Annual Interest Rate",
            "today" to "Today",
            "yesterday" to "Yesterday",
            "recipient" to "Recipient Name",
            "amount" to "Amount",
            "memo" to "Memo",
            "confirm" to "Confirm",
            "cancel" to "Cancel",
            "alipay" to "Alipay",
            "starbucks" to "Starbucks",
            "salary" to "Salary",
            "card_holder" to "Card Holder",
            "add_new_card" to "Add New Card",
            "freeze" to "Freeze Card",
            "unfreeze" to "Unfreeze Card",
            "delete_card" to "Remove Card",
            "interest_calculator" to "Interest Calculator",
            "calc_help" to "See how much compound interest you will earn at 3.25%!",
            "deposit_amount" to "Deposit Principal (¥)",
            "est_return_1y" to "Est. 1 Year Return: ",
            "est_return_3y" to "Est. 3 Years Return: ",
            "est_return_5y" to "Est. 5 Years Return: ",
            "analytics" to "Spending Analytics",
            "spending_breakdown" to "Monthly Spending Breakdown",
            "no_spending" to "No spending records this period",
            "smarter_banking" to "A Smarter, More Connected Way to Bank",
            "desktop_title" to "Yunshan Bank • Connect Your World",
            "app_subtitle" to "Yunshan Bank brings together digital banking, global payments and intelligent finance — all in one app.",
            "smarter_way" to "A SMARTER WAY TO BANK",
            "open_account_title" to "Open a Yunshan Bank Account",
            "username" to "Username",
            "security" to "Security Settings",
            "biometrics" to "Biometrics (FaceID / Fingerprint)",
            "developer_options" to "Developer Tools",
            "reset_db" to "Reset Database Logs",
            "theme" to "Theme Style",
            "dark_mode" to "Dark Mode",
            "light_mode" to "Light Mode",
            "select_card_pay" to "Select Payment Card",
            "enter_merchant" to "Merchant Name",
            "payment_success" to "Payment Successful",
            "transfer_success" to "Transfer Successful",
            "topup_success" to "Top Up Successful"
        )
    )

    fun getString(key: String): String {
        val currentLang = _language.value
        return localizations[currentLang]?.get(key) ?: key
    }
}

class BankViewModelFactory(private val repository: BankRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BankViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return BankViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
