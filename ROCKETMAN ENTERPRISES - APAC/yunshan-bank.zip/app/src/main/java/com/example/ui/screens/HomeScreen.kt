package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocalActivity
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Transaction
import com.example.ui.components.BankLogo
import com.example.ui.viewmodel.BankViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(viewModel: BankViewModel) {
    val totalBalance by viewModel.totalBalance.collectAsState()
    val isBalanceVisible by viewModel.isBalanceVisible.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
            .padding(top = 16.dp, bottom = 100.dp) // extra padding to avoid navigation cutoffs
    ) {
        // 1. Sleek Top App Bar with Spruce Brand logo and fast language toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BankLogo()

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Language Switch Indicator Pill
                Box(
                    modifier = Modifier
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .clickable { viewModel.toggleLanguage() }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Language,
                            contentDescription = "Language",
                            tint = Color(0xFF11151D),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (viewModel.language.collectAsState().value == "EN") "中文" else "EN",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF11151D)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                IconButton(
                    onClick = { viewModel.openDialog("Pay") },
                    modifier = Modifier
                        .size(36.dp)
                        .background(Color.White, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = "Scan",
                        tint = Color(0xFF11151D),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. Premium Total Balance Card displaying exact ¥128,460.00 aesthetic
        Text(
            text = viewModel.getString("total_balance"),
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF64748B),
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Start,
            modifier = Modifier.fillMaxWidth()
        ) {
            // Amount String: e.g., ¥ 128,460.00
            val formattedBalance = if (isBalanceVisible) {
                "¥ " + String.format(Locale.US, "%,.2f", totalBalance)
            } else {
                "¥ ••••••"
            }

            Text(
                text = formattedBalance,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF11151D),
                modifier = Modifier.testTag("total_balance_text")
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = { viewModel.toggleBalanceVisibility() },
                modifier = Modifier.size(24.dp)
            ) {
                Icon(
                    imageVector = if (isBalanceVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    contentDescription = "Toggle Balance",
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 3. Quick Actions Row: Transfer, Pay, Top Up, More
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            QuickActionButton(
                label = viewModel.getString("transfer"),
                icon = Icons.Default.SwapHoriz,
                testTag = "transfer_action_button",
                onClick = { viewModel.openDialog("Transfer") }
            )
            QuickActionButton(
                label = viewModel.getString("pay"),
                icon = Icons.Default.Payment,
                testTag = "pay_action_button",
                onClick = { viewModel.openDialog("Pay") }
            )
            QuickActionButton(
                label = viewModel.getString("top_up"),
                icon = Icons.Default.History,
                testTag = "top_up_action_button",
                onClick = { viewModel.openDialog("TopUp") }
            )
            QuickActionButton(
                label = viewModel.getString("more"),
                icon = Icons.Default.MoreHoriz,
                testTag = "more_action_button",
                onClick = { viewModel.selectTab("Wealth") }
            )
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 4. Smart Savings Banner with large 3.25% growth text
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable { viewModel.openDialog("Savings") },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = viewModel.getString("smart_savings"),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF11151D)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "3.25%",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE5C158) // Gold highlights
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = viewModel.getString("ann_interest_rate"),
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                Icon(
                    imageVector = Icons.Default.ArrowForwardIos,
                    contentDescription = "Calculator",
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 5. Recent Transactions Header & List exactly like mockup
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = viewModel.getString("recent_tx"),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF11151D)
            )

            Text(
                text = viewModel.getString("view_all"),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF64748B),
                modifier = Modifier.clickable { viewModel.selectTab("Wealth") }
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Render transactions lists
        if (transactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No recent transactions.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        } else {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Show only up to 4 on home, remainder accessible under "View All" / "Wealth"
                transactions.take(4).forEach { tx ->
                    TransactionItem(tx, viewModel)
                }
            }
        }
    }
}

@Composable
fun QuickActionButton(
    label: String,
    icon: ImageVector,
    testTag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .testTag(testTag)
            .clickable(onClick = onClick)
            .padding(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .background(Color.White, CircleShape)
                .border(1.dp, Color(0xFFE2E8F0), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = Color(0xFF11151D),
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF11151D)
        )
    }
}

@Composable
fun TransactionItem(tx: Transaction, viewModel: BankViewModel) {
    // Styling variables mapping based on Transaction types (e.g. Alipay blue, Starbucks green, Salary blue)
    val iconBgColor: Color
    val iconTint: Color
    val iconVector: ImageVector
    val localizedTitle: String

    when {
        tx.title.contains("Alipay", ignoreCase = true) -> {
            iconBgColor = Color(0xFFE0F2FE)
            iconTint = Color(0xFF0284C7)
            iconVector = Icons.Default.QrCodeScanner
            localizedTitle = viewModel.getString("alipay")
        }
        tx.title.contains("Starbucks", ignoreCase = true) -> {
            iconBgColor = Color(0xFFDCFCE7)
            iconTint = Color(0xFF15803D)
            iconVector = Icons.Default.LocalActivity
            localizedTitle = viewModel.getString("starbucks")
        }
        tx.title.contains("Salary", ignoreCase = true) -> {
            iconBgColor = Color(0xFFEEF2F6)
            iconTint = Color(0xFF475569)
            iconVector = Icons.Default.Wallet
            localizedTitle = viewModel.getString("salary")
        }
        tx.amount > 0 -> {
            // Income / Top Up generic
            iconBgColor = Color(0xFFFEF3C7)
            iconTint = Color(0xFFD97706)
            iconVector = Icons.Default.CardGiftcard
            localizedTitle = tx.title
        }
        else -> {
            // Spending generic
            iconBgColor = Color(0xFFEEF2F6)
            iconTint = Color(0xFF475569)
            iconVector = Icons.Default.Info
            localizedTitle = tx.title
        }
    }

    // Timestamps formatter
    val date = Date(tx.timestamp)
    val formatter = SimpleDateFormat("HH:mm", Locale.getDefault())
    val formattedTime = formatter.format(date)
    val isToday = System.currentTimeMillis() - tx.timestamp < 24 * 60 * 60 * 1000
    val dayLabel = if (isToday) viewModel.getString("today") else viewModel.getString("yesterday")

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White, RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFFF1F5F9), RoundedCornerShape(14.dp))
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(iconBgColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconVector,
                    contentDescription = tx.title,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = localizedTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF11151D)
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "$dayLabel $formattedTime",
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
            }
        }

        // Amount showing green "+ ¥..." or slate/dark text "- ¥..."
        val isIncome = tx.amount > 0
        val amountSign = if (isIncome) "+ " else "- "
        val absAmount = kotlin.math.abs(tx.amount)
        val amountColor = if (isIncome) Color(0xFF10B981) else Color(0xFF11151D)

        Text(
            text = "$amountSign¥ ${String.format(Locale.US, "%,.2f", absAmount)}",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = amountColor
        )
    }
}
