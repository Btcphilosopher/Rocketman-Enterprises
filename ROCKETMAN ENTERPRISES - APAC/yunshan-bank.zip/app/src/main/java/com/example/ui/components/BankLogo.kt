package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun BankLogo(
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.primary,
    goldAccent: Color = Color(0xFFE5C158),
    showText: Boolean = true,
    textColor: Color = MaterialTheme.colorScheme.primary
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Logo Drawing via Canvas for absolute precision
        Canvas(modifier = Modifier.size(36.dp)) {
            val width = size.width
            val height = size.height

            // 1. Draw the vertical trunk on the right
            // x from 0.7 to 0.75 of width, y from 0.15 to 0.85
            val trunkX = width * 0.72f
            drawLine(
                color = goldAccent,
                start = Offset(trunkX, height * 0.15f),
                end = Offset(trunkX, height * 0.85f),
                strokeWidth = width * 0.08f,
                cap = StrokeCap.Round
            )

            // 2. Draw three parallel slanted spruce branch lines on the left
            // Top slanted branch
            drawLine(
                color = tint,
                start = Offset(width * 0.25f, height * 0.44f),
                end = Offset(width * 0.62f, height * 0.25f),
                strokeWidth = width * 0.08f,
                cap = StrokeCap.Round
            )

            // Middle slanted branch
            drawLine(
                color = tint,
                start = Offset(width * 0.20f, height * 0.58f),
                end = Offset(width * 0.62f, height * 0.39f),
                strokeWidth = width * 0.08f,
                cap = StrokeCap.Round
            )

            // Bottom slanted branch
            drawLine(
                color = tint,
                start = Offset(width * 0.15f, height * 0.72f),
                end = Offset(width * 0.62f, height * 0.53f),
                strokeWidth = width * 0.08f,
                cap = StrokeCap.Round
            )
        }

        if (showText) {
            Column(verticalArrangement = Arrangement.Center) {
                Text(
                    text = "云杉银行",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = textColor,
                    letterSpacing = 2.sp,
                    lineHeight = 16.sp
                )
                Text(
                    text = "YUNSHAN BANK",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Light,
                    color = textColor.copy(alpha = 0.7f),
                    letterSpacing = 1.sp,
                    lineHeight = 9.sp
                )
            }
        }
    }
}
