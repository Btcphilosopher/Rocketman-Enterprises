package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Slate & Charcoal Palette
val YunshanDarkNavy = Color(0xFF11151D)
val YunshanMidnight = Color(0xFF0F1219)
val YunshanSlateGray = Color(0xFF64748B)
val YunshanLightGray = Color(0xFFF4F6F9)
val YunshanSoftWhite = Color(0xFFF8FAFC)
val YunshanPillSilver = Color(0xFFE2E8F0)

// Accents
val YunshanGold = Color(0xFFE5C158)
val YunshanSpruceGreen = Color(0xFF1D3B2B)
val YunshanEmerald = Color(0xFF10B981)
val YunshanCrimson = Color(0xFFEF4444)

// Material Dark Theme equivalents
val DarkPrimary = Color(0xFFF8FAFC)
val DarkSecondary = Color(0xFF94A3B8)
val DarkBackground = Color(0xFF0F1219)
val DarkSurface = Color(0xFF1E293B)
