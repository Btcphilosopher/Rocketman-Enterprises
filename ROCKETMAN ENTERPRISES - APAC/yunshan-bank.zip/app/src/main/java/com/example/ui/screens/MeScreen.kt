package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.BankViewModel
import kotlin.math.abs

@Composable
fun MeScreen(viewModel: BankViewModel) {
    val scrollState = rememberScrollState()
    val transactions by viewModel.transactions.collectAsState()
    val language by viewModel.language.collectAsState()

    var biometricEnabled by remember { mutableStateOf(true) }
    var mockUsername by remember { mutableStateOf("Tom Ahyx") }

    // Dynamic analytics: Sum values for negative amounts by category
    val spendingList = transactions.filter { it.amount < 0 }
    val totalSpending = spendingList.sumOf { abs(it.amount) }

    val shoppingSum = abs(spendingList.filter { it.category == "Shopping" }.sumOf { it.amount })
    val foodSum = abs(spendingList.filter { it.category == "Food & Drink" }.sumOf { it.amount })
    val transferSum = abs(spendingList.filter { it.category == "Transfer" }.sumOf { it.amount })

    // Percentage
    val shoppingPct = if (totalSpending > 0) (shoppingSum / totalSpending).toFloat() else 0.3f
    val foodPct = if (totalSpending > 0) (foodSum / totalSpending).toFloat() else 0.1f
    val transferPct = if (totalSpending > 0) (transferSum / totalSpending).toFloat() else 0.6f

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF4F6F9))
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp)
            .padding(top = 24.dp, bottom = 120.dp)
    ) {
        // 1. Profile Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .background(Color(0xFFE2E8F0), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Avatar",
                    tint = Color(0xFF11151D),
                    modifier = Modifier.size(32.dp)
                )
            }

            Spacer(modifier = Modifier.width(16.dp))

            Column {
                Text(
                    text = mockUsername,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF11151D)
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "Spruce Diamond Tier • Member since 2024",
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 2. Spending Analytics Card (Visual Custom Pie Chart!)
        Text(
            text = viewModel.getString("analytics"),
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF11151D)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Text(
                    text = viewModel.getString("spending_breakdown"),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF64748B)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Custom Donut/Pie Chart drawn on Canvas
                    Canvas(modifier = Modifier.size(110.dp)) {
                        val donutSize = size
                        val strokeWidth = 14.dp.toPx()

                        // Angles computation (sweep angles)
                        val angleShopping = shoppingPct * 360f
                        val angleFood = foodPct * 360f
                        val angleTransfer = transferPct * 360f

                        // Draw segments
                        var startAngle = -90f

                        // 1. Transfer (Amber/Gold)
                        if (angleTransfer > 0) {
                            drawArc(
                                color = Color(0xFFE5C158),
                                startAngle = startAngle,
                                sweepAngle = angleTransfer,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                            startAngle += angleTransfer
                        }

                        // 2. Shopping (Navy Indigo)
                        if (angleShopping > 0) {
                            drawArc(
                                color = Color(0xFF11151D),
                                startAngle = startAngle,
                                sweepAngle = angleShopping,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                            startAngle += angleShopping
                        }

                        // 3. Food & Drink (Green)
                        if (angleFood > 0) {
                            drawArc(
                                color = Color(0xFF10B981),
                                startAngle = startAngle,
                                sweepAngle = angleFood,
                                useCenter = false,
                                style = Stroke(width = strokeWidth)
                            )
                        }
                    }

                    // Legend Panel
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f).padding(start = 24.dp)
                    ) {
                        LegendItem(
                            color = Color(0xFFE5C158),
                            label = viewModel.getString("transfer") + " (${(transferPct * 100).toInt()}%)"
                        )
                        LegendItem(
                            color = Color(0xFF11151D),
                            label = "Shopping" + " (${(shoppingPct * 100).toInt()}%)"
                        )
                        LegendItem(
                            color = Color(0xFF10B981),
                            label = "Food & Drink" + " (${(foodPct * 100).toInt()}%)"
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 3. Settings Items List
        Text(
            text = "Wallet Settings & Tools",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF11151D)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column {
                // Language Switcher Row
                SettingItemRow(
                    icon = Icons.Default.Language,
                    title = "App Language",
                    subtitle = "Toggle English or Chinese translation",
                    widget = {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFEEF2F6), RoundedCornerShape(8.dp))
                                .clickable { viewModel.toggleLanguage() }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = if (language == "EN") "English" else "简体中文",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF11151D)
                            )
                        }
                    }
                )

                Divider(color = Color(0xFFF1F5F9), thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))

                // Biometrics Simulator Switch Row
                SettingItemRow(
                    icon = Icons.Default.Fingerprint,
                    title = viewModel.getString("biometrics"),
                    subtitle = "Verify transactions instantly via face ID",
                    widget = {
                        Switch(
                            checked = biometricEnabled,
                            onCheckedChange = { biometricEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF11151D),
                                uncheckedThumbColor = Color.White,
                                uncheckedTrackColor = Color(0xFFCBD5E1)
                            )
                        )
                    }
                )

                Divider(color = Color(0xFFF1F5F9), thickness = 1.dp, modifier = Modifier.padding(horizontal = 16.dp))

                // Developer tool warning
                SettingItemRow(
                    icon = Icons.Default.Security,
                    title = viewModel.getString("security"),
                    subtitle = "Manage security credentials & certificates",
                    widget = {
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = Color(0xFF94A3B8))
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // 4. Logo branding banner for Spruce digital banking
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    color = Color(0xFF11151D),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "云杉银行 • " + viewModel.getString("smarter_way"),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFE5C158),
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = viewModel.getString("smarter_banking"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = viewModel.getString("app_subtitle"),
                    fontSize = 11.sp,
                    color = Color.White.copy(alpha = 0.7f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
fun LegendItem(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .background(color, CircleShape)
        )
        Text(
            text = label,
            fontSize = 12.sp,
            color = Color(0xFF475569),
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun SettingItemRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    widget: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .background(Color(0xFFEEF2F6), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = Color(0xFF475569),
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF11151D)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = Color(0xFF64748B)
                )
            }
        }

        widget()
    }
}
