package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val category: String, // "Shopping", "Food & Drink", "Income", "Transfer", "Top Up", etc.
    val timestamp: Long,
    val amount: Double, // negative for spending, positive for income
    val status: String = "Completed" // "Completed", "Pending"
)

@Entity(tableName = "bank_cards")
data class BankCard(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val cardNumber: String,
    val cardHolder: String = "YUNSHAN CUSTOMER",
    val cardType: String, // "Debit" or "Credit"
    val cardBrand: String, // "UnionPay", "Visa", "Mastercard"
    val expiryDate: String, // "08/29"
    val colorHex: String, // "#111622", "#1D3B2B", "#7C6335", etc.
    val isFrozen: Boolean = false
)
