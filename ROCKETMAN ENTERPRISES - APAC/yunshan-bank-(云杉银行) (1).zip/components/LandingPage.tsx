'use client';

import React, { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Globe, ShieldCheck, Leaf, Zap, ArrowUpRight, ArrowDownRight, Info, CheckCircle, HelpCircle } from "lucide-react";
import Logo from "./Logo";
import PhoneMockup from "./PhoneMockup";

// Use the exact generated image path
import heroBg from "@/src/assets/images/hero_shanghai_skyline_1791201891760.jpg";

interface Transaction {
  id: string;
  merchant: string;
  date: string;
  time: string;
  amount: number;
  type: "income" | "expense";
  category: string;
}

interface LandingPageProps {
  balance: number;
  isBalanceVisible: boolean;
  onToggleBalance: () => void;
  transactions: Transaction[];
  lang: "zh" | "en";
  setLang: (lang: "zh" | "en") => void;
  onNavigateToDashboard: () => void;
  onOpenQuickTransfer: () => void;
  onOpenSavingsInDashboard: () => void;
}

export default function LandingPage({
  balance,
  isBalanceVisible,
  onToggleBalance,
  transactions,
  lang,
  setLang,
  onNavigateToDashboard,
  onOpenQuickTransfer,
  onOpenSavingsInDashboard,
}: LandingPageProps) {
  const [activeMenu, setActiveMenu] = useState("home");
  const [selectedFeature, setSelectedFeature] = useState<string | null>(null);

  // Translations Dict
  const t = {
    zh: {
      navHome: "首页",
      navPersonal: "个人",
      navBusiness: "企业",
      navWealth: "财富",
      navAbout: "关于",
      btnOpenAccount: "开立账户",
      btnLogin: "登录银行",
      kicker: "更智能的银行体验 · A SMARTER WAY TO BANK",
      title1: "您的世界。",
      title2: "更近一步，互联无界。",
      subtitle: "云杉银行将数字银行、全球支付与智能金融融为一体 —— 汇聚于一个极具质感且智能的 App 中。",
      btnOpenAccountHero: "立即开户",
      btnLearnMore: "了解更多",
      feature1Title: "即时收付款",
      feature1Desc: "秒级处理，全球范围即时发送与接收资金。",
      feature2Title: "全球化通路",
      feature2Desc: "尊享极具竞争力的汇率，轻松实现跨国资金流转。",
      feature3Title: "安全与信赖",
      feature3Desc: "采用前沿双重安全加密，具备全方位的合规与监管保护。",
      feature4Title: "可持续未来",
      feature4Desc: "携手绿色低碳金融，为更清洁、更繁荣的明天而创设。",
      marketsTitle: "全球市场",
      featureInfoTitle: "功能详情介绍",
      closeBtn: "关闭",
    },
    en: {
      navHome: "Home",
      navPersonal: "Personal",
      navBusiness: "Business",
      navWealth: "Wealth",
      navAbout: "About",
      btnOpenAccount: "Open Account",
      btnLogin: "Login",
      kicker: "A SMARTER WAY TO BANK",
      title1: "Your world.",
      title2: "More connected.",
      subtitle: "Yunshan Bank brings together digital banking, global payments and intelligent finance — all in one app.",
      btnOpenAccountHero: "Open an Account",
      btnLearnMore: "Learn more",
      feature1Title: "Instant Payments",
      feature1Desc: "Send and receive money globally, in seconds.",
      feature2Title: "Global Access",
      feature2Desc: "Bank across borders with competitive exchange rates.",
      feature3Title: "Secure & Trusted",
      feature3Desc: "Advanced security, with full regulatory protection.",
      feature4Title: "A Sustainable Future",
      feature4Desc: "Banking for a cleaner, greener tomorrow.",
      marketsTitle: "Global Markets",
      featureInfoTitle: "Feature Details",
      closeBtn: "Close",
    }
  }[lang];

  // Simulated live market data
  const marketTickers = [
    { name: "SHCOMP", value: "3,283.45", change: "+1.24%", up: true },
    { name: "HKEX", value: "17,432.08", change: "+0.86%", up: true },
    { name: "USD/CNY", value: "7.16", change: "-0.12%", up: false },
    { name: "BTC", value: "68,432.10", change: "+2.34%", up: true },
  ];

  const featuresList = [
    {
      id: "payments",
      title: t.feature1Title,
      desc: t.feature1Desc,
      icon: Zap,
      color: "text-amber-500 bg-amber-500/10",
      details: lang === "zh" 
        ? "云杉银行基于最先进的即时清算网络，为您提供7x24小时全天候境内外极速汇款服务。无论是转账给商户、个人还是海外账户，均可实现秒级到账，费用低至免手续费。全面支持数字钱包和银联/支付宝等通道智能对账。"
        : "Built on real-time netting and settlement architectures, Yunshan Bank delivers instant transfers worldwide 24/7. Whether paying businesses or individuals across borders, funds arrive in sub-seconds with near-zero friction. Fully compatible with mainstream wallets like Alipay and standard routing protocols."
    },
    {
      id: "global",
      title: t.feature2Title,
      desc: t.feature2Desc,
      icon: Globe,
      color: "text-blue-500 bg-blue-500/10",
      details: lang === "zh"
        ? "我们支持多达30余种主流货币的在线实时兑换与持有多币种钱包。通过领先的多银行聚合报价系统，为您提供媲美银行间交易水平的极佳牌价，消除高昂的中转行扣款和虚高溢价，让全球商旅与跨国资产配置自由无阻。"
        : "Unlock local multi-currency accounts supporting 30+ major currencies. Experience dynamic liquidity pools matching institutional interbank rates, avoiding high middleman fees. Perfect for cross-border operations, overseas travels, and diversified asset storage."
    },
    {
      id: "security",
      title: t.feature3Title,
      desc: t.feature3Desc,
      icon: ShieldCheck,
      color: "text-emerald-500 bg-emerald-500/10",
      details: lang === "zh"
        ? "安全是我们的根基。云杉银行受多国权威金融监管机构牌照许可，用户资产受主权级存款保险计划保障。资金端采用军工级端到端加密、独立信托账户隔离存管以及智能风控检测，最大程度护航您的资金安全。"
        : "Security is non-negotiable. Yunshan Bank is authorized and compliant under strict global regulatory frame networks. User deposits are fully backed by statutory sovereign deposit insurance schemes. Combined with hardware-level biometric logins, cold-key assets, and advanced anti-fraud layers."
    },
    {
      id: "future",
      title: t.feature4Title,
      desc: t.feature4Desc,
      icon: Leaf,
      color: "text-teal-500 bg-teal-500/10",
      details: lang === "zh"
        ? "我们坚持每一笔投资都为可持续发展注入动力。通过云杉专属的'碳中和智能储蓄罐'，您的每一笔存款都将优先且透明地投向经过严格环保认证的绿色清洁能源项目，并产生丰厚的环保效益回报。用绿色金融，成就长青未来。"
        : "Commit your cash reserves to a better tomorrow. Through our ESG Green Deposits and carbon-neutral initiatives, Yunshan Bank routes active capital directly into authenticated renewable energy, microgrid, and clean infrastructure developments, proving that yield and ecological ethics go hand-in-hand."
    }
  ];

  return (
    <div className="min-h-screen bg-white text-slate-800 flex flex-col relative overflow-x-hidden selection:bg-slate-900 selection:text-white">
      
      {/* 3-Zone Navigation Header */}
      <header className="w-full max-w-7xl mx-auto px-6 md:px-12 py-5 flex items-center justify-between z-40 bg-white/70 backdrop-blur-md sticky top-0 border-b border-slate-100">
        {/* Zone 1: Brand Wordmark Logo */}
        <Logo className="cursor-pointer" />

        {/* Zone 2: Navigation Links (4-6 links, single-line) */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-slate-500">
          {[
            { id: "home", label: t.navHome },
            { id: "personal", label: t.navPersonal },
            { id: "business", label: t.navBusiness },
            { id: "wealth", label: t.navWealth },
            { id: "about", label: t.navAbout },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveMenu(item.id)}
              className="relative py-1 cursor-pointer transition-colors hover:text-slate-950 font-semibold"
            >
              <span className={activeMenu === item.id ? "text-slate-950" : ""}>
                {item.label}
              </span>
              {activeMenu === item.id && (
                <motion.div
                  layoutId="activeUnderline"
                  className="absolute bottom-0 left-0 right-0 h-[2.5px] bg-slate-900 rounded-full"
                  transition={{ type: "spring", stiffness: 380, damping: 30 }}
                />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: Actions + Language Toggle */}
        <div className="flex items-center gap-4">
          {/* Language Switcher */}
          <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
            <button
              onClick={() => setLang("zh")}
              className={`hover:text-slate-950 cursor-pointer transition-colors px-1 py-0.5 ${lang === "zh" ? "text-slate-950 underline underline-offset-4 decoration-2" : ""}`}
            >
              中文
            </button>
            <span className="text-slate-300">|</span>
            <button
              onClick={() => setLang("en")}
              className={`hover:text-slate-950 cursor-pointer transition-colors px-1 py-0.5 ${lang === "en" ? "text-slate-950 underline underline-offset-4 decoration-2" : ""}`}
            >
              EN
            </button>
          </div>

          <button
            onClick={onNavigateToDashboard}
            className="text-sm font-bold text-slate-600 hover:text-slate-950 px-3 py-2 cursor-pointer transition-colors"
          >
            {t.btnLogin}
          </button>

          <button
            onClick={onNavigateToDashboard}
            className="bg-[#0C111D] text-white hover:bg-slate-800 text-xs font-bold px-4 py-2.5 rounded-lg active:scale-95 transition-all shadow-md shrink-0 cursor-pointer whitespace-nowrap"
          >
            {t.btnOpenAccount}
          </button>
        </div>
      </header>

      {/* Hero Section Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-6 md:px-12 pt-8 pb-16 md:pt-14 md:pb-24 flex flex-col justify-center relative">
        {/* Background Image Container with modern architecture crop styling */}
        <div className="absolute right-0 top-0 bottom-16 w-full lg:w-3/5 rounded-[40px] overflow-hidden -z-10 bg-slate-100 shadow-xl opacity-90 border border-slate-100 hidden lg:block">
          <div className="relative w-full h-full">
            <Image
              src={heroBg}
              alt="Shanghai Pudong skyline skyline golden sunrise with reflective wet modern architectural terrace"
              fill
              className="object-cover object-right-bottom select-none transition-transform duration-1000"
              priority
              placeholder="blur"
              referrerPolicy="no-referrer"
            />
            {/* Absolute gradients to blend background image perfectly into white landing canvas */}
            <div className="absolute inset-0 bg-gradient-to-r from-white via-white/40 to-transparent w-full" />
            <div className="absolute inset-0 bg-gradient-to-b from-white/10 via-transparent to-white/95" />
          </div>
        </div>

        {/* Responsive Mobile Background */}
        <div className="absolute inset-0 w-full h-full -z-10 rounded-2xl overflow-hidden bg-slate-50 opacity-40 lg:hidden">
          <Image
            src={heroBg}
            alt="Shanghai skyline"
            fill
            className="object-cover opacity-15"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Two Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          
          {/* Left Column: Headline and Copy */}
          <div className="lg:col-span-7 flex flex-col gap-6 md:gap-8 max-w-2xl">
            
            {/* Mono Kicker */}
            <div className="inline-flex items-center">
              <span className="text-[10px] md:text-xs font-bold tracking-[0.2em] text-slate-400 uppercase select-none">
                {t.kicker}
              </span>
            </div>

            {/* Title / Headline */}
            <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.1] text-wrap">
              <span className="block">{t.title1}</span>
              <span className="block mt-1 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-700 bg-clip-text text-slate-900">{t.title2}</span>
            </h1>

            {/* Description */}
            <p className="text-base md:text-lg text-slate-500 leading-relaxed max-w-xl">
              {t.subtitle}
            </p>

            {/* Hero CTAs */}
            <div className="flex flex-wrap items-center gap-5 mt-2">
              <button
                onClick={onNavigateToDashboard}
                className="group inline-flex items-center gap-2 bg-[#0C111D] text-white hover:bg-slate-800 text-sm font-bold px-6 py-3.5 rounded-xl shadow-lg hover:shadow-xl active:scale-[0.98] transition-all cursor-pointer"
              >
                <span>{t.btnOpenAccountHero}</span>
                <ArrowRight size={16} className="transform group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={() => setSelectedFeature("payments")}
                className="group inline-flex items-center gap-1.5 text-sm font-bold text-slate-600 hover:text-slate-900 transition-colors py-2 px-1 cursor-pointer"
              >
                <span>{t.btnLearnMore}</span>
                <ArrowRight size={14} className="transform group-hover:translate-x-0.5 transition-transform opacity-60 group-hover:opacity-100" />
              </button>
            </div>
          </div>

          {/* Right Column: High Fidelity Floating Mobile Phone Mockup */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end items-center">
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.1, ease: "easeOut" }}
              className="relative"
            >
              {/* Subtle background glow representing financial intelligence */}
              <div className="absolute -inset-10 bg-slate-200/50 rounded-full filter blur-3xl opacity-30 animate-pulse -z-10" />
              
              <PhoneMockup
                balance={balance}
                isBalanceVisible={isBalanceVisible}
                onToggleBalance={onToggleBalance}
                transactions={transactions}
                lang={lang}
                onLogin={onNavigateToDashboard}
                onOpenTransfer={onOpenQuickTransfer}
                onOpenSavings={onOpenSavingsInDashboard}
              />
            </motion.div>
          </div>

        </div>

      </main>

      {/* Key Feature Spotlight Grid Section (below hero) */}
      <section className="bg-slate-50 border-t border-slate-100 w-full relative z-20">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-12 md:py-16">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 md:gap-10">
            {featuresList.map((feat) => {
              const Icon = feat.icon;
              return (
                <div
                  key={feat.id}
                  onClick={() => setSelectedFeature(feat.id)}
                  className="group flex flex-col gap-4 p-5 hover:bg-white rounded-2xl border border-transparent hover:border-slate-100 transition-all cursor-pointer hover:shadow-xs"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${feat.color}`}>
                    <Icon size={18} />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900 flex items-center gap-1">
                      <span>{feat.title}</span>
                      <span className="opacity-0 group-hover:opacity-100 transform translate-x-1 group-hover:translate-x-0 transition-all text-slate-400">
                        <ArrowUpRight size={13} />
                      </span>
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed mt-1.5">
                      {feat.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Global Markets Floating Ticker Bar (At the bottom, infinite roll) */}
      <footer className="w-full bg-white border-t border-slate-100 py-3 overflow-hidden select-none relative z-30 flex items-center">
        <div className="max-w-7xl mx-auto px-6 md:px-12 w-full flex items-center justify-between">
          
          {/* Label Zone */}
          <div className="text-[10px] md:text-xs font-bold text-slate-400 uppercase tracking-widest bg-white pr-4 z-10 shrink-0">
            {t.marketsTitle}
          </div>

          {/* Scrolling Ticker Container */}
          <div className="flex-1 overflow-hidden relative flex items-center">
            {/* Soft left/right fade masks */}
            <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
            <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />

            <div className="animate-ticker whitespace-nowrap py-1">
              {/* Loop ticker items twice to ensure endless cycle */}
              {[...marketTickers, ...marketTickers, ...marketTickers, ...marketTickers].map((item, idx) => (
                <div
                  key={idx}
                  className="inline-flex items-center gap-2 px-6 border-r border-slate-100"
                >
                  <span className="text-[11px] font-bold text-slate-600">{item.name}</span>
                  <span className="text-[11px] font-semibold font-mono tabular-nums text-slate-900">{item.value}</span>
                  <span className={`inline-flex items-center text-[10px] font-bold font-mono tracking-tight ${
                    item.up ? "text-emerald-500" : "text-rose-500"
                  }`}>
                    {item.up ? "+" : ""}
                    {item.change}
                    {item.up ? (
                      <ArrowUpRight size={10} className="ml-0.5 shrink-0" />
                    ) : (
                      <ArrowDownRight size={10} className="ml-0.5 shrink-0" />
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Action icon indicator */}
          <button 
            onClick={onNavigateToDashboard}
            className="w-7 h-7 rounded-full bg-slate-50 hover:bg-slate-100 flex items-center justify-center text-slate-400 hover:text-slate-900 ml-4 transition-colors shrink-0"
          >
            <ArrowRight size={14} />
          </button>
        </div>
      </footer>

      {/* Feature details dialog modal overlay */}
      <AnimatePresence>
        {selectedFeature && (
          <div className="fixed inset-0 bg-slate-900/65 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl relative border border-slate-100"
            >
              {(() => {
                const feat = featuresList.find(f => f.id === selectedFeature);
                if (!feat) return null;
                const Icon = feat.icon;
                return (
                  <div className="flex flex-col gap-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${feat.color}`}>
                        <Icon size={20} />
                      </div>
                      <div>
                        <h2 className="text-lg font-extrabold text-slate-900">{feat.title}</h2>
                        <p className="text-xs font-semibold text-slate-400 tracking-wider uppercase">YUNSHAN BANK PLATFORM</p>
                      </div>
                    </div>
                    
                    <p className="text-sm text-slate-500 leading-relaxed bg-slate-50/50 p-4 rounded-xl border border-slate-100 font-medium">
                      {feat.details}
                    </p>

                    <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 text-[11px] font-bold px-3 py-2 rounded-lg">
                      <CheckCircle size={14} />
                      <span>{lang === "zh" ? "服务已就绪 · 欢迎登录体验" : "Operational · Login to explore details"}</span>
                    </div>

                    <div className="flex items-center gap-3 mt-2">
                      <button
                        onClick={onNavigateToDashboard}
                        className="flex-1 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-3 rounded-xl transition-all active:scale-95 text-center"
                      >
                        {lang === "zh" ? "登录体验功能" : "Login & Try It"}
                      </button>
                      <button
                        onClick={() => setSelectedFeature(null)}
                        className="flex-1 border border-slate-200 hover:border-slate-300 text-slate-600 text-xs font-bold py-3 rounded-xl transition-all text-center"
                      >
                        {t.closeBtn}
                      </button>
                    </div>
                  </div>
                );
              })()}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
