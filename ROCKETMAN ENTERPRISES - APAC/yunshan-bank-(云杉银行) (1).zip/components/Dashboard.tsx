'use client';

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  DollarSign, Landmark, Send, ArrowUpRight, ArrowDownRight, RefreshCw, 
  Search, ShieldAlert, Sparkles, LogOut, ChevronRight, Check, AlertCircle, 
  HelpCircle, UserCheck, Smartphone, Eye, EyeOff, BarChart3, TrendingUp,
  Briefcase, ShieldCheck, HeartPulse, SendToBack, ChevronDown, MessageSquare
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import Logo from "./Logo";

interface Transaction {
  id: string;
  merchant: string;
  date: string;
  time: string;
  amount: number;
  type: "income" | "expense";
  category: string;
}

interface DashboardProps {
  balance: number; // CNY Balance
  setBalance: React.Dispatch<React.SetStateAction<number>>;
  transactions: Transaction[];
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
  isBalanceVisible: boolean;
  onToggleBalance: () => void;
  lang: "zh" | "en";
  onLogout: () => void;
  openTab?: string;
}

export default function Dashboard({
  balance,
  setBalance,
  transactions,
  setTransactions,
  isBalanceVisible,
  onToggleBalance,
  lang,
  onLogout,
  openTab = "overview"
}: DashboardProps) {
  const [activeTab, setActiveTab] = useState(openTab);
  const [successTxId, setSuccessTxId] = useState("");
  
  // Secondary currency balances
  const [usdBalance, setUsdBalance] = useState(5400.00);
  const [hkdBalance, setHkdBalance] = useState(25000.00);
  const [btcBalance, setBtcBalance] = useState(0.084);
  const [vaultBalance, setVaultBalance] = useState(15000.00); // 3.25% APR vault

  // Exchange rates relative to CNY
  const exchangeRates: { [key: string]: number } = {
    CNY: 1,
    USD: 0.14,  // 1 CNY = 0.14 USD
    HKD: 1.09,  // 1 CNY = 1.09 HKD
    BTC: 0.0000021 // 1 CNY = 0.0000021 BTC
  };

  // Target exchange inputs
  const [exchangeFrom, setExchangeFrom] = useState("CNY");
  const [exchangeTo, setExchangeTo] = useState("USD");
  const [exchangeAmount, setExchangeAmount] = useState("");
  const [exchangeSuccess, setExchangeSuccess] = useState<string | null>(null);

  // Transfer Form State
  const [transferFromWallet, setTransferFromWallet] = useState("CNY");
  const [recipientType, setRecipientType] = useState("saved"); // saved | custom
  const [selectedRecipientId, setSelectedRecipientId] = useState("");
  const [customName, setCustomName] = useState("");
  const [customBank, setCustomBank] = useState("");
  const [customAccount, setCustomAccount] = useState("");
  const [transferAmount, setTransferAmount] = useState("");
  const [transferMemo, setTransferMemo] = useState("");
  const [transferError, setTransferError] = useState("");
  const [transferSuccess, setTransferSuccess] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [showBiometricVerification, setShowBiometricVerification] = useState(false);

  // Savings Builder State
  const [savingsDepositAmount, setSavingsDepositAmount] = useState("");
  const [savingsAction, setSavingsAction] = useState<"deposit" | "withdraw">("deposit");
  const [savingsSuccess, setSavingsSuccess] = useState<string | null>(null);
  const [savingsTerm, setSavingsTerm] = useState(5); // 1, 3, 5, 10 years

  // Search/Filters State
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [viewingReceipt, setViewingReceipt] = useState<Transaction | null>(null);

  // AI Financial Advisor State
  const [messages, setMessages] = useState<Array<{ sender: "user" | "ai"; text: string }>>([
    {
      sender: "ai",
      text: lang === "zh" 
        ? "您好，Tom！我是您的云杉智能（Yunshan AI）财务顾问。我已准备好分析您的交易明细、账户流水和储蓄习惯，为您出具专业的金融优化建议。您可以点击下方的按钮一键生成‘月度财务健康分析报告’，也可以向我提问任何关于投资规划或资产配置的问题。"
        : "Hello, Tom! I am your Yunshan AI Financial Advisor. I am ready to review your multi-currency balances, cash flow details, and savings habits to formulate specialized capital growth optimization strategies. Click the button below to generate a 'Monthly Financial Health Audit', or ask me any question about portfolio management or compound growth."
    }
  ]);
  const [aiInput, setAiInput] = useState("");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Scroll AI messages to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isAiLoading]);

  // Recipient list
  const savedRecipients = [
    { id: "rp1", name: lang === "zh" ? "支付宝 (Alipay)" : "Alipay", detail: "alipay-merchant@service.com" },
    { id: "rp2", name: lang === "zh" ? "星巴克咖啡 (Starbucks)" : "Starbucks Coffee", detail: "billing@starbucks.com.cn" },
    { id: "rp3", name: lang === "zh" ? "腾讯科技 (Tencent)" : "Tencent Technology", detail: "pay@tencent.com" },
    { id: "rp4", name: lang === "zh" ? "中国工商银行 (ICBC)" : "ICBC Bank Account", detail: "622202******5839" }
  ];

  // Translations Dict
  const t = {
    zh: {
      overview: "全景概览",
      transfer: "极速转账",
      savings: "智能储蓄",
      aiAdvisor: "云杉智能 AI",
      settings: "账户安全",
      welcome: "欢迎回来，",
      securityLevel: "安全评级: 极高 (L3)",
      financialScore: "财务健康度",
      scoreExplanation: "超过了95%的同等级尊贵用户",
      balanceTitle: "流动资产钱包",
      savingsVault: "智能储蓄金 (3.25% APY)",
      currency: "货币",
      balance: "可用金额",
      equivalent: "等值人民币",
      exchangeRate: "牌价汇率",
      recentActivity: "账单明细",
      searchPlaceholder: "搜索账单、商户或备注...",
      allCategories: "全部交易",
      filterIncome: "仅收入",
      filterExpense: "仅支出",
      emptyTransactions: "未找到符合条件的账单明细",
      transferMoney: "安全资金划转",
      sourceWallet: "支付钱包",
      recipient: "接收方",
      savedRec: "快捷常用收款人",
      customRec: "手动开立新账户",
      recName: "收款人户名",
      recBank: "开户行名称",
      recAccount: "银行账号/邮箱",
      amount: "汇款金额",
      memo: "附言 / 备注",
      reviewBtn: "核准交易指令",
      transferring: "正在通过云杉双重加密网络验证...",
      transferSuccessMsg: "资金已实时划转成功！",
      transferDone: "确认并关闭",
      deposit: "存入储蓄金",
      withdraw: "支取储蓄金",
      savingsTermTitle: "模拟资产增长周期 (年)",
      projectionTitle: "3.25% 复利增长前景预测",
      initialAmount: "初始本金",
      projectedInterest: "累计预估回报",
      projectedTotal: "期末本息总额",
      askAiPlaceholder: "向云杉财务顾问提问...",
      generateReport: "一键生成智能资产健康报告 ✨",
      generatingReport: "云杉金融大模型正在对您的资产负债表与消费习惯进行全量审计...",
      logout: "安全退出",
      exchangeBtn: "快速兑换",
      exchangeDone: "兑换成功！",
      insufficient: "钱包余额不足，请重新输入汇款金额",
      limitSet: "每日交易限额设置",
      twoFactor: "两步安全验证 (2FA)",
      biometricTitle: "指令安全确认",
      biometricSub: "请进行生物识别或输入交易密码以确认此款项划转",
      passcode: "请输入6位支付密码",
      confirmPay: "确认授权付款",
      categoryFood: "美食餐饮",
      categoryUtilities: "生活缴费",
      categorySalary: "薪酬收入",
      categoryShopping: "网络购物",
      categoryInvestment: "金融理财",
      categoryTransfers: "资金转账",
      closeBtn: "关闭"
    },
    en: {
      overview: "Overview",
      transfer: "Transfer Money",
      savings: "Smart Savings",
      aiAdvisor: "Yunshan AI",
      settings: "Security Settings",
      welcome: "Welcome back, ",
      securityLevel: "Security Rating: Ultra (L3)",
      financialScore: "Financial Health Score",
      scoreExplanation: "Top 5% among executive tier peers",
      balanceTitle: "Liquid Multi-Currency Wallets",
      savingsVault: "Smart Savings Vault (3.25% APY)",
      currency: "Currency",
      balance: "Available Balance",
      equivalent: "CNY Equivalent",
      exchangeRate: "Ex-Rate",
      recentActivity: "Recent Activities",
      searchPlaceholder: "Search merchants, notes...",
      allCategories: "All Transactions",
      filterIncome: "Income Only",
      filterExpense: "Expense Only",
      emptyTransactions: "No corresponding transactions found",
      transferMoney: "Secure Wire Transfer",
      sourceWallet: "Source Wallet",
      recipient: "Recipient Details",
      savedRec: "Quick Recipient Directory",
      customRec: "Add New Recipient Manual",
      recName: "Account Name",
      recBank: "Destination Bank",
      recAccount: "Account ID / Email",
      amount: "Transfer Amount",
      memo: "Memo / Reference",
      reviewBtn: "Validate Wire Instructions",
      transferring: "Encrypting and verifying via Yunshan Network...",
      transferSuccessMsg: "Transfer completed instantly!",
      transferDone: "Done & Dismiss",
      deposit: "Deposit to Vault",
      withdraw: "Withdraw from Vault",
      savingsTermTitle: "Asset Projections Term (Years)",
      projectionTitle: "3.25% Compound Interest Forecast",
      initialAmount: "Principal",
      projectedInterest: "Interest Earned",
      projectedTotal: "Projected Assets",
      askAiPlaceholder: "Ask AI advisor about allocation...",
      generateReport: "Generate Monthly Wealth Audit ✨",
      generatingReport: "Yunshan GenAI Engine is running full audit on your cashflows...",
      logout: "Secure Logout",
      exchangeBtn: "Convert Currency",
      exchangeDone: "Exchange success!",
      insufficient: "Insufficient liquid wallet reserves for this amount",
      limitSet: "Daily Limit Cap",
      twoFactor: "Two-Factor Verification (2FA)",
      biometricTitle: "Security Verification",
      biometricSub: "Authenticate biometric credentials or enter trade pin to authorize this wire transfer",
      passcode: "Enter 6-digit transaction PIN",
      confirmPay: "Authorize Wire",
      categoryFood: "Dining & Food",
      categoryUtilities: "Utilities",
      categorySalary: "Salary Income",
      categoryShopping: "E-Commerce",
      categoryInvestment: "Investments",
      categoryTransfers: "Transfers",
      closeBtn: "Close"
    }
  }[lang];

  // Synchronized formatting helper
  const formatMoney = (val: number, isBtc = false) => {
    return new Intl.NumberFormat("zh-CN", {
      minimumFractionDigits: isBtc ? 5 : 2,
      maximumFractionDigits: isBtc ? 5 : 2,
    }).format(val);
  };

  // Convert selected balances to CNY for total calculation
  const totalAssetsInCny = 
    balance + 
    (usdBalance / exchangeRates.USD) + 
    (hkdBalance / exchangeRates.HKD) + 
    (btcBalance / exchangeRates.BTC) +
    vaultBalance;

  // Handle Multi-currency conversion
  const handleExchange = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(exchangeAmount);
    if (isNaN(amount) || amount <= 0) return;

    // Source balance verification
    if (exchangeFrom === "CNY" && balance < amount) return alert(t.insufficient);
    if (exchangeFrom === "USD" && usdBalance < amount) return alert(t.insufficient);
    if (exchangeFrom === "HKD" && hkdBalance < amount) return alert(t.insufficient);
    if (exchangeFrom === "BTC" && btcBalance < amount) return alert(t.insufficient);

    // Subtract from source
    if (exchangeFrom === "CNY") setBalance(p => p - amount);
    else if (exchangeFrom === "USD") setUsdBalance(p => p - amount);
    else if (exchangeFrom === "HKD") setHkdBalance(p => p - amount);
    else if (exchangeFrom === "BTC") setBtcBalance(p => p - amount);

    // Calculate equivalent in CNY, then to target currency
    const amountInCny = amount / exchangeRates[exchangeFrom];
    const convertedAmount = amountInCny * exchangeRates[exchangeTo];

    // Add to target
    if (exchangeTo === "CNY") setBalance(p => p + convertedAmount);
    else if (exchangeTo === "USD") setUsdBalance(p => p + convertedAmount);
    else if (exchangeTo === "HKD") setHkdBalance(p => p + convertedAmount);
    else if (exchangeTo === "BTC") setBtcBalance(p => p + convertedAmount);

    // Record exchange in transactions
    const newTx: Transaction = {
      id: "tx-ex-" + (transactions.length + 1),
      merchant: lang === "zh" 
        ? `${exchangeFrom} 兑换为 ${exchangeTo}` 
        : `Currency Swap: ${exchangeFrom} to ${exchangeTo}`,
      date: "2026-10-05",
      time: "12:00",
      amount: amountInCny,
      type: "expense",
      category: "investment"
    };
    setTransactions(prev => [newTx, ...prev]);

    setExchangeSuccess(`${t.exchangeDone} Converted ${amount} ${exchangeFrom} to ${formatMoney(convertedAmount, exchangeTo === "BTC")} ${exchangeTo}`);
    setExchangeAmount("");
    setTimeout(() => setExchangeSuccess(null), 5000);
  };

  // Handle Wire Transfer Initiation
  const handleTransferReview = (e: React.FormEvent) => {
    e.preventDefault();
    setTransferError("");
    const amount = parseFloat(transferAmount);

    if (isNaN(amount) || amount <= 0) {
      setTransferError(lang === "zh" ? "请输入有效的汇款金额" : "Please input a valid transfer amount");
      return;
    }

    // Verify Balance
    if (transferFromWallet === "CNY" && balance < amount) {
      setTransferError(t.insufficient);
      return;
    }
    if (transferFromWallet === "USD" && usdBalance < amount) {
      setTransferError(t.insufficient);
      return;
    }
    if (transferFromWallet === "HKD" && hkdBalance < amount) {
      setTransferError(t.insufficient);
      return;
    }
    if (transferFromWallet === "BTC" && btcBalance < amount) {
      setTransferError(t.insufficient);
      return;
    }

    // Verify Recipient Information
    if (recipientType === "saved" && !selectedRecipientId) {
      setTransferError(lang === "zh" ? "请选择常用收款人" : "Please select a directory contact");
      return;
    }
    if (recipientType === "custom" && (!customName || !customBank || !customAccount)) {
      setTransferError(lang === "zh" ? "请完整填写收款人银行与账号信息" : "Please complete all recipient and banking fields");
      return;
    }

    // Show Biometrics Confirmation Dialog
    setShowBiometricVerification(true);
  };

  // Complete Transfer with Simulated Cryptographic Network Verifiers
  const handleConfirmPay = () => {
    setShowBiometricVerification(false);
    setIsVerifying(true);

    const amount = parseFloat(transferAmount);

    setTimeout(() => {
      // Execute Balance Subtraction
      if (transferFromWallet === "CNY") setBalance(p => p - amount);
      else if (transferFromWallet === "USD") setUsdBalance(p => p - amount);
      else if (transferFromWallet === "HKD") setHkdBalance(p => p - amount);
      else if (transferFromWallet === "BTC") setBtcBalance(p => p - amount);

      // Extract Recipient name
      let finalRecipientName = "";
      if (recipientType === "saved") {
        const found = savedRecipients.find(r => r.id === selectedRecipientId);
        finalRecipientName = found ? found.name : "Alipay";
      } else {
        finalRecipientName = customName;
      }

      // Add To transactions history
      const cnyEquivAmount = amount / exchangeRates[transferFromWallet];
      const newTx: Transaction = {
        id: "tx-wire-" + (transactions.length + 1),
        merchant: finalRecipientName,
        date: "2026-10-05",
        time: "12:15",
        amount: cnyEquivAmount,
        type: "expense",
        category: "transfers"
      };

      setTransactions(prev => [newTx, ...prev]);

      setIsVerifying(false);
      setSuccessTxId("TXN-" + Math.floor(Math.random() * 900000 + 100000).toString());
      setTransferSuccess(true);
      // Clear inputs
      setTransferAmount("");
      setTransferMemo("");
      setCustomName("");
      setCustomBank("");
      setCustomAccount("");
    }, 2000);
  };

  // Vault deposits / withdrawals
  const handleVaultAction = (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(savingsDepositAmount);
    if (isNaN(amount) || amount <= 0) return;

    if (savingsAction === "deposit") {
      if (balance < amount) {
        alert(t.insufficient);
        return;
      }
      setBalance(p => p - amount);
      setVaultBalance(p => p + amount);
      setSavingsSuccess(lang === "zh" ? `成功存入储蓄金 ¥${formatMoney(amount)}` : `Successfully deposited ¥${formatMoney(amount)} to Smart Savings Vault`);
    } else {
      if (vaultBalance < amount) {
        alert(lang === "zh" ? "储蓄金余额不足" : "Insufficient funds in savings vault");
        return;
      }
      setVaultBalance(p => p - amount);
      setBalance(p => p + amount);
      setSavingsSuccess(lang === "zh" ? `成功提取储蓄金 ¥${formatMoney(amount)}` : `Successfully withdrew ¥${formatMoney(amount)} to CNY wallet`);
    }

    setSavingsDepositAmount("");
    setTimeout(() => setSavingsSuccess(null), 5000);
  };

  // Call server-side Gemini AI for portfolio audit
  const generateAiInsights = async () => {
    setIsAiLoading(true);
    setMessages(prev => [
      ...prev,
      { sender: "user", text: lang === "zh" ? "请帮我审计当前资产分配并生成财务健康分析。" : "Review my active assets and generate my financial wealth audit." }
    ]);

    try {
      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          transactions: transactions,
          savingsRate: "3.25%",
          totalBalance: `CNY ${formatMoney(balance)}, USD ${formatMoney(usdBalance)}, HKD ${formatMoney(hkdBalance)}, BTC ${formatMoney(btcBalance, true)}, Smart Savings Vault CNY ${formatMoney(vaultBalance)}`,
          username: "Tom"
        })
      });

      const data = await response.json();
      if (data.text) {
        setMessages(prev => [...prev, { sender: "ai", text: data.text }]);
      } else if (data.error) {
        setMessages(prev => [...prev, { sender: "ai", text: `⚠️ Error: ${data.error}` }]);
      }
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { sender: "ai", text: "❌ Connection timeout. Failed to fetch intelligent suggestions." }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Submit custom questions to AI chat
  const handleAiMessageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiInput.trim()) return;

    const query = aiInput;
    setAiInput("");
    setMessages(prev => [...prev, { sender: "user", text: query }]);
    setIsAiLoading(true);

    try {
      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          transactions: transactions,
          savingsRate: "3.25%",
          customPrompt: query,
          totalBalance: `CNY ${formatMoney(balance)}, USD ${formatMoney(usdBalance)}, HKD ${formatMoney(hkdBalance)}, BTC ${formatMoney(btcBalance, true)}, Smart Savings Vault CNY ${formatMoney(vaultBalance)}`,
          username: "Tom"
        })
      });

      const data = await response.json();
      if (data.text) {
        setMessages(prev => [...prev, { sender: "ai", text: data.text }]);
      } else {
        setMessages(prev => [...prev, { sender: "ai", text: "⚠️ Server response failed. Let me re-verify your secure credentials." }]);
      }
    } catch (err) {
      setMessages(prev => [...prev, { sender: "ai", text: "❌ Connection error. Financial AI is currently offline." }]);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Filtering Logic
  const filteredTransactions = transactions.filter(tx => {
    const matchesSearch = 
      tx.merchant.toLowerCase().includes(searchQuery.toLowerCase()) || 
      tx.category.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedCategory === "All") return matchesSearch;
    if (selectedCategory === "Income") return matchesSearch && tx.type === "income";
    if (selectedCategory === "Expense") return matchesSearch && tx.type === "expense";
    return matchesSearch && tx.category.toLowerCase() === selectedCategory.toLowerCase();
  });

  // Math simulation for future Smart Savings compound interest projections
  const calculateCompoundProjections = () => {
    const rate = 0.0325; // 3.25% APR
    const principal = vaultBalance;
    const futureTotal = principal * Math.pow(1 + rate, savingsTerm);
    const interestEarned = futureTotal - principal;
    return {
      principal,
      interestEarned,
      futureTotal
    };
  };

  const projections = calculateCompoundProjections();

  // Category Translation Helper
  const getCategoryLabel = (cat: string) => {
    switch (cat.toLowerCase()) {
      case "food": return t.categoryFood;
      case "utilities": return t.categoryUtilities;
      case "salary": return t.categorySalary;
      case "shopping": return t.categoryShopping;
      case "investment": return t.categoryInvestment;
      case "transfers": return t.categoryTransfers;
      default: return cat;
    }
  };

  return (
    <div className="min-h-screen bg-[#F8F9FC] text-slate-800 flex flex-col relative overflow-hidden select-none">
      
      {/* Verification Overlay Indicator */}
      <AnimatePresence>
        {isVerifying && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-50 flex flex-col items-center justify-center p-6 text-white text-center">
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="flex flex-col items-center gap-6"
            >
              <div className="relative flex items-center justify-center">
                <div className="w-16 h-16 border-4 border-white/20 border-t-white rounded-full animate-spin" />
                <ShieldCheck size={28} className="absolute text-emerald-400" />
              </div>
              <div>
                <p className="text-lg font-bold tracking-tight">{t.transferring}</p>
                <p className="text-xs text-white/60 mt-1 select-none font-mono">Yunshan Cryptographic Vault Proof: Verifying 2FA Keys</p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Transfer success modal popup */}
      <AnimatePresence>
        {transferSuccess && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative border border-slate-100 flex flex-col items-center text-center gap-4"
            >
              <div className="w-14 h-14 bg-emerald-50 rounded-full flex items-center justify-center text-emerald-600">
                <Check size={32} />
              </div>
              <div>
                <h3 className="text-lg font-extrabold text-slate-900">{t.transferSuccessMsg}</h3>
                <p className="text-xs text-slate-400 mt-1">Yunshan Transaction Reference ID: {successTxId}</p>
              </div>
              <button
                onClick={() => {
                  setTransferSuccess(false);
                  setActiveTab("overview");
                }}
                className="w-full bg-[#0C111D] text-white hover:bg-slate-800 text-xs font-bold py-3 rounded-xl transition-all active:scale-95 cursor-pointer"
              >
                {t.transferDone}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Biometric validation dialog */}
      <AnimatePresence>
        {showBiometricVerification && (
          <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative border border-slate-100 flex flex-col gap-4 text-left"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-slate-700">
                  <UserCheck size={18} />
                </div>
                <div>
                  <h3 className="text-sm font-extrabold text-slate-900">{t.biometricTitle}</h3>
                  <p className="text-[10px] text-slate-400 font-bold tracking-wider uppercase">SECURE VERIFIER</p>
                </div>
              </div>

              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {t.biometricSub}
              </p>

              {/* Six circles representation of trade password */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 flex flex-col gap-2.5 items-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.passcode}</span>
                <div className="flex gap-3">
                  {[1, 2, 3, 4, 5, 6].map((dot) => (
                    <div key={dot} className="w-3.5 h-3.5 rounded-full bg-slate-300 border border-slate-400 animate-pulse" />
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-3 mt-1">
                <button
                  onClick={handleConfirmPay}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold py-3 rounded-xl transition-all active:scale-95 text-center cursor-pointer"
                >
                  {t.confirmPay}
                </button>
                <button
                  onClick={() => setShowBiometricVerification(false)}
                  className="flex-1 border border-slate-200 hover:border-slate-300 text-slate-600 text-xs font-bold py-3 rounded-xl transition-all text-center cursor-pointer"
                >
                  {lang === "zh" ? "取消" : "Cancel"}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main dashboard layout frame */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Left Interactive Sidebar (Desktop ONLY) */}
        <aside className="w-64 bg-[#0C111D] text-white flex flex-col justify-between p-6 shrink-0 z-30 shadow-xl border-r border-slate-800 hidden md:flex">
          <div className="flex flex-col gap-10">
            {/* Logo lockup in white */}
            <Logo light className="scale-90 origin-left" />

            {/* Nav tabs list */}
            <nav className="flex flex-col gap-1.5">
              {[
                { id: "overview", label: t.overview, icon: Landmark },
                { id: "transfer", label: t.transfer, icon: Send },
                { id: "savings", label: t.savings, icon: TrendingUp },
                { id: "ai", label: t.aiAdvisor, icon: Sparkles, accent: true },
                { id: "settings", label: t.settings, icon: ShieldCheck }
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveTab(tab.id);
                      setTransferError("");
                    }}
                    className={`group flex items-center gap-3.5 px-4 py-3 rounded-xl text-xs font-semibold tracking-wide transition-all select-none relative cursor-pointer ${
                      isActive 
                        ? "text-[#0C111D] bg-white shadow-md font-bold" 
                        : "text-slate-400 hover:text-white hover:bg-white/5"
                    }`}
                  >
                    <Icon size={16} className={tab.accent && !isActive ? "text-amber-400" : ""} />
                    <span className="flex-1 text-left">{tab.label}</span>
                    {tab.accent && !isActive && (
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Bottom user settings section */}
          <div className="flex flex-col gap-4 border-t border-slate-800 pt-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-slate-300">
                TO
              </div>
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-white truncate">Tom (Elite Tier)</p>
                <p className="text-[10px] text-slate-500 truncate">tom@ahyx.org</p>
              </div>
            </div>

            <button
              onClick={onLogout}
              className="flex items-center gap-2.5 text-xs font-bold text-rose-400 hover:text-rose-300 transition-colors py-2 px-1 cursor-pointer"
            >
              <LogOut size={14} />
              <span>{t.logout}</span>
            </button>
          </div>
        </aside>

        {/* Right dashboard workspace area */}
        <main className="flex-1 flex flex-col overflow-y-auto bg-[#F8F9FC]">
          
          {/* Top Panel Bar */}
          <header className="bg-white border-b border-slate-100 py-4 px-6 md:px-10 flex items-center justify-between sticky top-0 z-20 shadow-xs">
            {/* Title page locator */}
            <div className="flex items-center gap-3">
              {/* Dynamic sidebar toggler for mobile screen sizes */}
              <Logo className="md:hidden" />
              <h1 className="text-base md:text-lg font-extrabold text-slate-950 hidden md:block select-none">
                {activeTab === "overview" && t.overview}
                {activeTab === "transfer" && t.transfer}
                {activeTab === "savings" && t.savings}
                {activeTab === "ai" && t.aiAdvisor}
                {activeTab === "settings" && t.settings}
              </h1>
            </div>

            {/* Top Right Info Widgets */}
            <div className="flex items-center gap-4">
              <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-100">
                {t.securityLevel}
              </span>
              <button 
                onClick={onToggleBalance}
                className="text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
              >
                {isBalanceVisible ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
              {/* Quick Mobile logout link */}
              <button 
                onClick={onLogout}
                className="p-1 text-slate-400 hover:text-rose-500 transition-colors md:hidden cursor-pointer"
              >
                <LogOut size={18} />
              </button>
            </div>
          </header>

          {/* Quick Mobile Tab Bar (For screen sizes below md: 768px) */}
          <nav className="bg-white border-b border-slate-100 px-4 py-2 flex md:hidden items-center justify-between z-10 shrink-0">
            {[
              { id: "overview", label: "概览", icon: Landmark },
              { id: "transfer", label: "转账", icon: Send },
              { id: "savings", label: "储蓄", icon: TrendingUp },
              { id: "ai", label: "AI", icon: Sparkles }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center gap-1 py-1 px-3 rounded-xl cursor-pointer ${
                  activeTab === tab.id ? "text-slate-900 bg-slate-50 font-bold" : "text-slate-400"
                }`}
              >
                <tab.icon size={16} />
                <span className="text-[9px] font-medium">{tab.label}</span>
              </button>
            ))}
          </nav>

          {/* Tab Workspace Panel Container */}
          <div className="flex-1 p-6 md:p-10 max-w-6xl w-full mx-auto flex flex-col gap-8">
            
            {/* OVERVIEW PANEL WORKSPACE */}
            {activeTab === "overview" && (
              <div className="flex flex-col gap-8">
                {/* User Welcome Billboard */}
                <div className="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative overflow-hidden group">
                  <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-linear-to-l from-slate-50/50 to-transparent pointer-events-none" />
                  <div className="flex flex-col gap-1 z-10">
                    <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight">
                      {t.welcome}Tom!
                    </h2>
                    <p className="text-xs md:text-sm text-slate-400 font-medium">
                      {lang === "zh" 
                        ? "您的资产正在安全运行。目前持有4种多国法定/数字货币。极速理财与双重安全密钥已就绪。" 
                        : "Your global reserves are completely synchronized and secured. Elite banking access ready."}
                    </p>
                  </div>

                  {/* Financial scoreboard */}
                  <div className="flex items-center gap-4 bg-slate-50 border border-slate-100/80 p-4 rounded-2xl z-10 shrink-0">
                    <div className="w-12 h-12 bg-slate-900 rounded-xl flex items-center justify-center text-white font-extrabold text-sm tracking-tight shrink-0">
                      94
                    </div>
                    <div>
                      <p className="text-xs font-extrabold text-slate-900">{t.financialScore}</p>
                      <p className="text-[10px] text-slate-400 font-semibold">{t.scoreExplanation}</p>
                    </div>
                  </div>
                </div>

                {/* Account Balances Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  {/* Left block: Wallet Balances list */}
                  <div className="lg:col-span-8 flex flex-col gap-4">
                    <h3 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest">{t.balanceTitle}</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Wallet: CNY */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs">
                        <div className="flex justify-between items-center text-slate-400">
                          <span className="text-xs font-bold text-slate-800">CNY (人民币)</span>
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-100 text-slate-500 px-2 py-0.5 rounded">Primary</span>
                        </div>
                        <div className="text-2xl font-black text-slate-900 mt-3 font-mono tracking-tight flex items-baseline">
                          <span className="text-sm font-semibold mr-1">¥</span>
                          {isBalanceVisible ? formatMoney(balance) : "••••••"}
                        </div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-2">
                          {t.exchangeRate}: 1.0000 · Global Settlement
                        </div>
                      </div>

                      {/* Wallet: USD */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs">
                        <div className="flex justify-between items-center text-slate-400">
                          <span className="text-xs font-bold text-slate-800">USD (美元)</span>
                          <span className="text-[10px] font-bold uppercase tracking-wider bg-slate-50 text-slate-400 px-2 py-0.5 rounded">Secondary</span>
                        </div>
                        <div className="text-2xl font-black text-slate-900 mt-3 font-mono tracking-tight flex items-baseline">
                          <span className="text-sm font-semibold mr-1">$</span>
                          {isBalanceVisible ? formatMoney(usdBalance) : "••••••"}
                        </div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-2">
                          {t.equivalent}: ¥{isBalanceVisible ? formatMoney(usdBalance / exchangeRates.USD) : "••••••"}
                        </div>
                      </div>

                      {/* Wallet: HKD */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs">
                        <div className="flex justify-between items-center text-slate-400">
                          <span className="text-xs font-bold text-slate-800">HKD (港币)</span>
                        </div>
                        <div className="text-2xl font-black text-slate-900 mt-3 font-mono tracking-tight flex items-baseline">
                          <span className="text-sm font-semibold mr-1">HK$</span>
                          {isBalanceVisible ? formatMoney(hkdBalance) : "••••••"}
                        </div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-2">
                          {t.equivalent}: ¥{isBalanceVisible ? formatMoney(hkdBalance / exchangeRates.HKD) : "••••••"}
                        </div>
                      </div>

                      {/* Wallet: BTC */}
                      <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs">
                        <div className="flex justify-between items-center text-slate-400">
                          <span className="text-xs font-bold text-slate-800">BTC (比特币)</span>
                        </div>
                        <div className="text-2xl font-black text-slate-900 mt-3 font-mono tracking-tight flex items-baseline">
                          <span className="text-sm font-semibold mr-1">₿</span>
                          {isBalanceVisible ? formatMoney(btcBalance, true) : "••••••"}
                        </div>
                        <div className="text-[10px] text-slate-400 font-semibold mt-2">
                          {t.equivalent}: ¥{isBalanceVisible ? formatMoney(btcBalance / exchangeRates.BTC) : "••••••"}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Right block: Quick Swap & Yield highlights */}
                  <div className="lg:col-span-4 flex flex-col gap-6">
                    {/* APY Vault Highlight */}
                    <div className="bg-linear-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-5 shadow-lg flex flex-col justify-between">
                      <div>
                        <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest">{t.savingsVault}</span>
                        <div className="text-2xl font-black mt-2 font-mono tracking-tight">
                          ¥{isBalanceVisible ? formatMoney(vaultBalance) : "••••••"}
                        </div>
                      </div>
                      <div className="flex items-center justify-between border-t border-slate-700/60 pt-3 mt-4">
                        <span className="text-[10px] text-slate-400 font-bold">{lang === "zh" ? "约定存款年利率" : "Fixed APY"}</span>
                        <span className="text-xs font-black text-amber-400">3.25% APR</span>
                      </div>
                    </div>

                    {/* Quick Currency Exchange Widget */}
                    <div className="bg-white rounded-2xl p-5 border border-slate-100 shadow-xs">
                      <span className="text-xs font-extrabold text-slate-400 uppercase tracking-widest">{t.exchangeBtn}</span>
                      
                      <form onSubmit={handleExchange} className="flex flex-col gap-3 mt-3">
                        <div className="grid grid-cols-2 gap-2">
                          <div className="flex flex-col gap-1">
                            <span className="text-[9px] font-bold text-slate-400 uppercase">From</span>
                            <select
                              value={exchangeFrom}
                              onChange={(e) => setExchangeFrom(e.target.value)}
                              className="text-xs font-bold bg-slate-50 border border-slate-100 p-2 rounded-lg cursor-pointer"
                            >
                              <option value="CNY">CNY</option>
                              <option value="USD">USD</option>
                              <option value="HKD">HKD</option>
                              <option value="BTC">BTC</option>
                            </select>
                          </div>
                          <div className="flex flex-col gap-1">
                            <span className="text-[9px] font-bold text-slate-400 uppercase">To</span>
                            <select
                              value={exchangeTo}
                              onChange={(e) => setExchangeTo(e.target.value)}
                              className="text-xs font-bold bg-slate-50 border border-slate-100 p-2 rounded-lg cursor-pointer"
                            >
                              <option value="CNY">CNY</option>
                              <option value="USD">USD</option>
                              <option value="HKD">HKD</option>
                              <option value="BTC">BTC</option>
                            </select>
                          </div>
                        </div>

                        <div className="flex flex-col gap-1">
                          <span className="text-[9px] font-bold text-slate-400 uppercase">{t.amount}</span>
                          <input
                            type="number"
                            step="any"
                            required
                            placeholder="0.00"
                            value={exchangeAmount}
                            onChange={(e) => setExchangeAmount(e.target.value)}
                            className="text-xs font-bold font-mono bg-slate-50 border border-slate-100 p-2 rounded-lg"
                          />
                        </div>

                        {exchangeSuccess && (
                          <div className="text-[10px] text-emerald-600 bg-emerald-50 p-2 rounded-lg font-bold border border-emerald-100">
                            {exchangeSuccess}
                          </div>
                        )}

                        <button
                          type="submit"
                          className="w-full bg-[#0C111D] text-white hover:bg-slate-800 text-xs font-bold py-2.5 rounded-xl transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
                        >
                          <RefreshCw size={12} />
                          <span>{t.exchangeBtn}</span>
                        </button>
                      </form>
                    </div>
                  </div>
                </div>

                {/* Account Transactions Ledger */}
                <div className="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-xs flex flex-col gap-6">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <h3 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest">{t.recentActivity}</h3>
                    
                    {/* Filters & search block */}
                    <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                      {/* Search box */}
                      <div className="relative flex-1 md:flex-initial min-w-[200px]">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400" size={14} />
                        <input
                          type="text"
                          placeholder={t.searchPlaceholder}
                          value={searchQuery}
                          onChange={(e) => setSearchQuery(e.target.value)}
                          className="w-full pl-9 pr-4 py-1.5 text-xs font-bold bg-slate-50 border border-slate-100 rounded-xl focus:bg-white transition-all focus:outline-none"
                        />
                      </div>

                      {/* Dropdown Category Filter */}
                      <select
                        value={selectedCategory}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="text-xs font-bold bg-slate-50 border border-slate-100 px-3 py-1.5 rounded-xl cursor-pointer"
                      >
                        <option value="All">{t.allCategories}</option>
                        <option value="Income">{t.filterIncome}</option>
                        <option value="Expense">{t.filterExpense}</option>
                        <option value="Food">{t.categoryFood}</option>
                        <option value="Utilities">{t.categoryUtilities}</option>
                        <option value="Salary">{t.categorySalary}</option>
                        <option value="Shopping">{t.categoryShopping}</option>
                        <option value="Investment">{t.categoryInvestment}</option>
                        <option value="Transfers">{t.categoryTransfers}</option>
                      </select>
                    </div>
                  </div>

                  {/* Transaction Rows */}
                  <div className="divide-y divide-slate-100">
                    {filteredTransactions.length > 0 ? (
                      filteredTransactions.map((tx) => {
                        const isIncome = tx.type === "income";
                        return (
                          <div
                            key={tx.id}
                            onClick={() => setViewingReceipt(tx)}
                            className="flex items-center justify-between py-3.5 hover:bg-slate-50/50 rounded-xl px-2 transition-all cursor-pointer"
                          >
                            <div className="flex items-center gap-3.5">
                              {/* Avatar design based on category */}
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-extrabold ${
                                isIncome ? "bg-emerald-50 text-emerald-600 border border-emerald-100" : "bg-blue-50 text-blue-600 border border-blue-100"
                              }`}>
                                {tx.merchant.substring(0, 2).toUpperCase()}
                              </div>
                              <div>
                                <p className="text-xs font-black text-slate-900">{tx.merchant}</p>
                                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-semibold mt-0.5">
                                  <span>{tx.date} · {tx.time}</span>
                                  <span>·</span>
                                  <span className="text-[9px] uppercase tracking-wider bg-slate-100 text-slate-500 px-1.5 py-0.2 rounded-sm font-bold">
                                    {getCategoryLabel(tx.category)}
                                  </span>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-3">
                              <span className={`text-sm font-bold font-mono tracking-tight ${isIncome ? "text-emerald-600" : "text-slate-900"}`}>
                                {isIncome ? "+" : "-"} ¥{formatMoney(tx.amount)}
                              </span>
                              <ChevronRight size={14} className="text-slate-300" />
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-center py-10">
                        <HelpCircle size={28} className="text-slate-300 mx-auto" />
                        <p className="text-xs text-slate-400 mt-2 font-semibold">{t.emptyTransactions}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* WIRE TRANSFER TAB WORKSPACE */}
            {activeTab === "transfer" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Wire Form column */}
                <div className="lg:col-span-8 bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-xs flex flex-col gap-6">
                  <h3 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest">{t.transferMoney}</h3>
                  
                  <form onSubmit={handleTransferReview} className="flex flex-col gap-5">
                    {/* Source Wallet selector */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-slate-500">{t.sourceWallet}</label>
                      <select
                        value={transferFromWallet}
                        onChange={(e) => setTransferFromWallet(e.target.value)}
                        className="text-xs font-bold bg-slate-50 border border-slate-100 p-3 rounded-xl cursor-pointer focus:bg-white focus:ring-1 focus:ring-slate-900"
                      >
                        <option value="CNY">CNY Wallet (Balance: ¥{formatMoney(balance)})</option>
                        <option value="USD">USD Wallet (Balance: ${formatMoney(usdBalance)})</option>
                        <option value="HKD">HKD Wallet (Balance: HK${formatMoney(hkdBalance)})</option>
                        <option value="BTC">BTC Wallet (Balance: ₿{formatMoney(btcBalance, true)})</option>
                      </select>
                    </div>

                    {/* Recipient Block Toggle */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-slate-500">{t.recipient}</label>
                      <div className="grid grid-cols-2 gap-2 p-1 bg-slate-50 rounded-xl">
                        <button
                          type="button"
                          onClick={() => setRecipientType("saved")}
                          className={`py-2 text-xs font-bold rounded-lg transition-all ${
                            recipientType === "saved" 
                              ? "bg-white text-slate-900 shadow-xs" 
                              : "text-slate-500 hover:text-slate-900"
                          }`}
                        >
                          {t.savedRec}
                        </button>
                        <button
                          type="button"
                          onClick={() => setRecipientType("custom")}
                          className={`py-2 text-xs font-bold rounded-lg transition-all ${
                            recipientType === "custom" 
                              ? "bg-white text-slate-900 shadow-xs" 
                              : "text-slate-500 hover:text-slate-900"
                          }`}
                        >
                          {t.customRec}
                        </button>
                      </div>
                    </div>

                    {/* Conditionally render recipient form fields */}
                    {recipientType === "saved" ? (
                      <div className="flex flex-col gap-1.5">
                        <select
                          value={selectedRecipientId}
                          onChange={(e) => setSelectedRecipientId(e.target.value)}
                          className="text-xs font-bold bg-slate-50 border border-slate-100 p-3 rounded-xl cursor-pointer"
                        >
                          <option value="">-- {lang === "zh" ? "请选择常用收款对象" : "Select Recipient from Directory"} --</option>
                          {savedRecipients.map((rec) => (
                            <option key={rec.id} value={rec.id}>
                              {rec.name} ({rec.detail})
                            </option>
                          ))}
                        </select>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 animate-fadeIn">
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">{t.recName}</span>
                          <input
                            type="text"
                            required
                            placeholder="Tom Wood"
                            value={customName}
                            onChange={(e) => setCustomName(e.target.value)}
                            className="text-xs font-bold bg-slate-50 border border-slate-100 p-2.5 rounded-xl"
                          />
                        </div>
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">{t.recBank}</span>
                          <input
                            type="text"
                            required
                            placeholder="ICBC Bank"
                            value={customBank}
                            onChange={(e) => setCustomBank(e.target.value)}
                            className="text-xs font-bold bg-slate-50 border border-slate-100 p-2.5 rounded-xl"
                          />
                        </div>
                        <div className="flex flex-col gap-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase">{t.recAccount}</span>
                          <input
                            type="text"
                            required
                            placeholder="622202******0000"
                            value={customAccount}
                            onChange={(e) => setCustomAccount(e.target.value)}
                            className="text-xs font-bold bg-slate-50 border border-slate-100 p-2.5 rounded-xl"
                          />
                        </div>
                      </div>
                    )}

                    {/* Amount & Memo */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="flex flex-col gap-1.5">
                        <label className="text-xs font-bold text-slate-500">{t.amount}</label>
                        <div className="relative">
                          <span className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-sm font-bold font-mono">
                            {transferFromWallet === "CNY" && "¥"}
                            {transferFromWallet === "USD" && "$"}
                            {transferFromWallet === "HKD" && "HK$"}
                            {transferFromWallet === "BTC" && "₿"}
                          </span>
                          <input
                            type="number"
                            step="any"
                            required
                            placeholder="0.00"
                            value={transferAmount}
                            onChange={(e) => setTransferAmount(e.target.value)}
                            className="w-full pl-12 pr-4 py-3 text-xs font-bold font-mono bg-slate-50 border border-slate-100 rounded-xl focus:bg-white"
                          />
                        </div>
                      </div>

                      <div className="flex flex-col gap-1.5">
                        <label className="text-xs font-bold text-slate-500">{t.memo}</label>
                        <input
                          type="text"
                          placeholder={lang === "zh" ? "服务采购费、汇款备注" : "Invoice payment, ref code"}
                          value={transferMemo}
                          onChange={(e) => setTransferMemo(e.target.value)}
                          className="w-full px-4 py-3 text-xs font-bold bg-slate-50 border border-slate-100 rounded-xl focus:bg-white"
                        />
                      </div>
                    </div>

                    {/* Error container */}
                    {transferError && (
                      <div className="flex items-center gap-2 text-rose-600 bg-rose-50 text-xs font-bold p-3 rounded-xl border border-rose-100">
                        <AlertCircle size={14} />
                        <span>{transferError}</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-[#0C111D] text-white hover:bg-slate-800 text-xs font-bold py-3.5 rounded-xl shadow-md transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <ShieldCheck size={14} />
                      <span>{t.reviewBtn}</span>
                    </button>
                  </form>
                </div>

                {/* Right sidebar instruction column */}
                <div className="lg:col-span-4 flex flex-col gap-6">
                  {/* Security Policy Reminder */}
                  <div className="bg-slate-50 rounded-2xl p-5 border border-slate-100 flex flex-col gap-3">
                    <span className="text-xs font-extrabold text-slate-400 uppercase tracking-widest">{lang === "zh" ? "云杉风控合规说明" : "Transfer Guidelines"}</span>
                    <div className="flex items-start gap-3 mt-1">
                      <ShieldAlert size={16} className="text-amber-500 shrink-0 mt-0.5" />
                      <p className="text-[11px] text-slate-500 leading-relaxed font-semibold">
                        {lang === "zh"
                          ? "每笔跨境汇款指令通过 Yunshan Shield 端到端加密算法处理。针对异常汇款或超限限额支付，系统会自动触发两步人脸 biometric biometric 识别或指纹密钥授权。"
                          : "Every transaction instruction is certified end-to-end under Yunshan Shield cryptographic networks. Limits exceeding daily caps automatically trigger statutory biometric checks and cold-key authentications."}
                      </p>
                    </div>
                  </div>
                </div>

              </div>
            )}

            {/* SMART SAVINGS TAB WORKSPACE */}
            {activeTab === "savings" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Vault growth calculator form block */}
                <div className="lg:col-span-7 bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-xs flex flex-col gap-6">
                  <div className="flex justify-between items-center">
                    <h3 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest">{t.savingsVault}</h3>
                    <span className="text-xs font-bold text-amber-500 bg-amber-500/10 px-2.5 py-0.5 rounded-full select-none">3.25% APR</span>
                  </div>

                  <form onSubmit={handleVaultAction} className="flex flex-col gap-5 border-b border-slate-100 pb-6">
                    {/* Deposit vs Withdraw switcher */}
                    <div className="grid grid-cols-2 gap-2 p-1 bg-slate-50 rounded-xl">
                      <button
                        type="button"
                        onClick={() => setSavingsAction("deposit")}
                        className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          savingsAction === "deposit" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"
                        }`}
                      >
                        {t.deposit}
                      </button>
                      <button
                        type="button"
                        onClick={() => setSavingsAction("withdraw")}
                        className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                          savingsAction === "withdraw" ? "bg-white text-slate-900 shadow-xs" : "text-slate-500"
                        }`}
                      >
                        {t.withdraw}
                      </button>
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-xs font-bold text-slate-500">{t.amount}</label>
                      <div className="relative">
                        <span className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-sm font-bold font-mono">¥</span>
                        <input
                          type="number"
                          step="any"
                          required
                          placeholder="0.00"
                          value={savingsDepositAmount}
                          onChange={(e) => setSavingsDepositAmount(e.target.value)}
                          className="w-full pl-8 pr-4 py-3 text-xs font-bold font-mono bg-slate-50 border border-slate-100 rounded-xl focus:bg-white"
                        />
                      </div>
                    </div>

                    {savingsSuccess && (
                      <div className="text-xs text-emerald-600 bg-emerald-50 p-3 rounded-xl border border-emerald-100 font-semibold flex items-center gap-2 animate-fadeIn">
                        <Check size={14} />
                        <span>{savingsSuccess}</span>
                      </div>
                    )}

                    <button
                      type="submit"
                      className="w-full bg-[#0C111D] text-white hover:bg-slate-800 text-xs font-bold py-3 rounded-xl transition-all active:scale-[0.98] cursor-pointer"
                    >
                      {savingsAction === "deposit" ? t.deposit : t.withdraw}
                    </button>
                  </form>

                  {/* Future asset growth slider */}
                  <div className="flex flex-col gap-4 pt-2">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold text-slate-500">{t.savingsTermTitle}</label>
                      <span className="text-xs font-black text-slate-900">{savingsTerm} {lang === "zh" ? "年" : "Years"}</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={savingsTerm}
                      onChange={(e) => setSavingsTerm(parseInt(e.target.value))}
                      className="w-full accent-[#0C111D] h-1.5 bg-slate-100 rounded-lg cursor-pointer"
                    />

                    {/* Visual Horizontal projection graph */}
                    <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 mt-4 flex flex-col gap-3">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{t.projectionTitle}</span>
                      
                      {/* Projections graph container */}
                      <div className="flex flex-col gap-1 mt-1">
                        <div className="flex justify-between text-[11px] text-slate-400 font-semibold mb-1">
                          <span>{lang === "zh" ? "当前本金" : "Principal"}</span>
                          <span>{lang === "zh" ? "期末预估资产" : "Est. Maturity Balance"}</span>
                        </div>
                        
                        <div className="relative h-6 bg-slate-200/50 rounded-lg overflow-hidden border border-slate-100 flex items-center">
                          {/* Inner growth percentage bar */}
                          <div 
                            className="h-full bg-linear-to-r from-slate-900 to-slate-700 transition-all duration-500"
                            style={{ width: `${Math.min(100, 40 + (savingsTerm * 6))}%` }}
                          />
                          <div className="absolute inset-0 px-3 flex justify-between items-center text-[10px] font-extrabold text-slate-900 font-mono">
                            <span className="text-white">¥{formatMoney(projections.principal)}</span>
                            <span>¥{formatMoney(projections.futureTotal)}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Growth ledger details block */}
                <div className="lg:col-span-5 bg-[#0C111D] text-white rounded-3xl p-6 md:p-8 border border-slate-800 shadow-xl flex flex-col gap-6">
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest select-none">{lang === "zh" ? "复利账单测算" : "Maturity Ledger"}</span>
                  
                  <div className="divide-y divide-slate-800">
                    <div className="flex justify-between items-center py-3">
                      <span className="text-xs text-slate-400 font-bold">{t.initialAmount}</span>
                      <span className="text-xs font-bold font-mono">¥{formatMoney(projections.principal)}</span>
                    </div>
                    <div className="flex justify-between items-center py-3">
                      <span className="text-xs text-slate-400 font-bold">{t.projectedInterest}</span>
                      <span className="text-xs font-bold font-mono text-amber-400">+¥{formatMoney(projections.interestEarned)}</span>
                    </div>
                    <div className="flex justify-between items-center py-3">
                      <span className="text-xs text-white font-extrabold">{t.projectedTotal}</span>
                      <span className="text-sm font-extrabold font-mono text-emerald-400">¥{formatMoney(projections.futureTotal)}</span>
                    </div>
                  </div>

                  <div className="bg-white/5 border border-white/5 p-4 rounded-xl flex items-start gap-2.5">
                    <Sparkles size={14} className="text-amber-400 shrink-0 mt-0.5 animate-pulse" />
                    <p className="text-[10px] text-slate-300 leading-relaxed font-semibold">
                      {lang === "zh"
                        ? "所有通过云杉智能储蓄金投向的资本均优先支持 ESG 环保、风力与垃圾热解循环项目。该笔利息收益完全免缴代扣税款且全额受国家级存款保险保护。"
                        : "All capital allocated through smart savings vaults directly finances authenticated ESG green projects. Returns are fully tax-exempt and backed by national level deposit protections."}
                    </p>
                  </div>
                </div>

              </div>
            )}

            {/* AI FINANCIAL ADVISOR WORKSPACE (云杉智能) */}
            {activeTab === "ai" && (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch h-[calc(100vh-180px)] min-h-[500px]">
                
                {/* AI Advisor Chat Container */}
                <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-100 shadow-xs flex flex-col justify-between overflow-hidden">
                  
                  {/* Chat header */}
                  <div className="bg-slate-50 border-b border-slate-100 py-4 px-6 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-slate-900 text-white flex items-center justify-center">
                        <Sparkles size={16} className="text-amber-400 animate-pulse" />
                      </div>
                      <div>
                        <h4 className="text-xs font-black text-slate-900">云杉智能 (Yunshan AI Intelligence)</h4>
                        <p className="text-[9px] text-slate-400 font-extrabold uppercase tracking-wider">Gemini-2.5-Flash Active Portfolio Advisor</p>
                      </div>
                    </div>
                    {/* Reset Chat button */}
                    <button
                      onClick={() => setMessages([{
                        sender: "ai",
                        text: lang === "zh" 
                          ? "您好，Tom！我是您的云杉智能顾问。您可以继续向我提问关于您在云杉银行持有的各项多国钱包及储蓄账户利息最大化策略。"
                          : "Hello Tom, I am your active portfolio audit AI. Continue asking me details regarding asset classes, yield optimizers, and wallet swaps."
                      }])}
                      className="text-[10px] font-bold text-slate-400 hover:text-slate-900 transition-colors cursor-pointer"
                    >
                      {lang === "zh" ? "清空对话" : "Reset Conversation"}
                    </button>
                  </div>

                  {/* Messages Feed Viewport */}
                  <div className="flex-1 p-6 overflow-y-auto flex flex-col gap-4 bg-slate-50/50">
                    {messages.map((msg, index) => {
                      const isUser = msg.sender === "user";
                      return (
                        <div
                          key={index}
                          className={`flex ${isUser ? "justify-end" : "justify-start"} animate-fadeIn`}
                        >
                          <div className={`max-w-[85%] rounded-2xl p-4 text-xs shadow-xs border ${
                            isUser 
                              ? "bg-[#0C111D] text-white border-slate-800 rounded-tr-xs" 
                              : "bg-white text-slate-800 border-slate-100 rounded-tl-xs markdown-body"
                          }`}>
                            {isUser ? (
                              <p className="whitespace-pre-wrap font-semibold leading-relaxed">{msg.text}</p>
                            ) : (
                              <ReactMarkdown>{msg.text}</ReactMarkdown>
                            )}
                          </div>
                        </div>
                      );
                    })}

                    {/* AI Loading status */}
                    {isAiLoading && (
                      <div className="flex justify-start animate-pulse">
                        <div className="bg-white rounded-2xl p-4 text-xs border border-slate-100 flex items-center gap-2.5">
                          <div className="flex gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "0ms" }} />
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "150ms" }} />
                            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: "300ms" }} />
                          </div>
                          <span className="text-slate-400 font-bold select-none">{t.generatingReport}</span>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  {/* Input form area */}
                  <div className="p-4 border-t border-slate-100 flex flex-col gap-3 bg-white">
                    {/* Fast recommendations block */}
                    {messages.length === 1 && (
                      <div className="flex flex-wrap gap-2">
                        <button
                          type="button"
                          onClick={generateAiInsights}
                          className="text-[10px] font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 hover:text-slate-900 py-1.5 px-3 rounded-full transition-all cursor-pointer"
                        >
                          {t.generateReport}
                        </button>
                      </div>
                    )}

                    <form onSubmit={handleAiMessageSubmit} className="flex gap-2">
                      <input
                        type="text"
                        placeholder={t.askAiPlaceholder}
                        value={aiInput}
                        onChange={(e) => setAiInput(e.target.value)}
                        disabled={isAiLoading}
                        className="flex-1 px-4 py-3 text-xs font-bold bg-slate-50 border border-slate-100 rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-slate-900 transition-all disabled:opacity-50"
                      />
                      <button
                        type="submit"
                        disabled={isAiLoading || !aiInput.trim()}
                        className="bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-50 text-xs font-bold px-4 rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <MessageSquare size={13} />
                        <span>{lang === "zh" ? "咨询" : "Ask"}</span>
                      </button>
                    </form>
                  </div>

                </div>

                {/* Right Quick Analytics overview column */}
                <div className="lg:col-span-4 bg-white rounded-3xl p-6 border border-slate-100 shadow-xs flex flex-col justify-between">
                  <div className="flex flex-col gap-4">
                    <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest">{lang === "zh" ? "资产流动性比例" : "Reserves Breakdown"}</span>
                    
                    {/* Visual progress meters */}
                    <div className="space-y-3 mt-1">
                      {[
                        { label: "CNY Wallet", val: balance, max: totalAssetsInCny, color: "bg-slate-950" },
                        { label: "USD Wallet", val: usdBalance / exchangeRates.USD, max: totalAssetsInCny, color: "bg-blue-600" },
                        { label: "Smart APY Vault", val: vaultBalance, max: totalAssetsInCny, color: "bg-amber-500" },
                        { label: "BTC Wallet", val: btcBalance / exchangeRates.BTC, max: totalAssetsInCny, color: "bg-emerald-600" }
                      ].map((item, idx) => {
                        const percent = (item.val / item.max) * 100;
                        return (
                          <div key={idx} className="flex flex-col gap-1">
                            <div className="flex justify-between text-[10px] font-bold text-slate-500">
                              <span>{item.label}</span>
                              <span className="font-mono tabular-nums">{percent.toFixed(1)}%</span>
                            </div>
                            <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                              <div className={`h-full ${item.color}`} style={{ width: `${percent}%` }} />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100 text-slate-500 text-[11px] leading-relaxed font-semibold mt-4">
                    {lang === "zh" 
                      ? "💡 温馨提示: 您的流动性资金中有过大比例处于非利息钱包（人民币流动钱包）。建议将 ¥50,000.00 资产转移至 Smart Savings 3.25% 复利储蓄计划以加速资产增值。"
                      : "💡 Tips: A high ratio of your liquid balance sits idle in non-yield accounts. Moving ¥50,000 to the 3.25% APY smart vault will maximize passive yield compound mechanics."}
                  </div>
                </div>

              </div>
            )}

            {/* SETTINGS AND CREDENTIALS WORKSPACE */}
            {activeTab === "settings" && (
              <div className="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-xs flex flex-col gap-6 max-w-2xl">
                <h3 className="text-sm font-extrabold text-slate-400 uppercase tracking-widest">{t.settings}</h3>
                
                <div className="space-y-6 divide-y divide-slate-100">
                  {/* Item: Name toggle */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pt-2">
                    <div>
                      <p className="text-xs font-black text-slate-900">{lang === "zh" ? "用户名称变更" : "Change Display Profile Name"}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-semibold">Customize your dashboard display name</p>
                    </div>
                    <input
                      type="text"
                      className="text-xs font-bold bg-slate-50 border border-slate-100 p-2 rounded-xl text-slate-900 max-w-[200px]"
                      defaultValue="Tom"
                    />
                  </div>

                  {/* Item: Daily limit toggler */}
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pt-4">
                    <div>
                      <p className="text-xs font-black text-slate-900">{t.limitSet}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-semibold">Configure payment authorization guard rails</p>
                    </div>
                    <select className="text-xs font-bold bg-slate-50 border border-slate-100 px-3 py-2 rounded-xl cursor-pointer">
                      <option>¥50,000 / Day</option>
                      <option>¥200,000 / Day</option>
                      <option>¥1,000,000 / Day (No Limit)</option>
                    </select>
                  </div>

                  {/* Item: biometric login toggle */}
                  <div className="flex justify-between items-center pt-4">
                    <div>
                      <p className="text-xs font-black text-slate-900">{t.twoFactor}</p>
                      <p className="text-[10px] text-slate-400 mt-0.5 font-semibold">Mandatory secure checks for foreign transactions</p>
                    </div>
                    <div className="relative inline-flex items-center cursor-pointer">
                      <input type="checkbox" className="sr-only peer" defaultChecked />
                      <div className="w-9 h-5 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-slate-950"></div>
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

        </main>

      </div>

      {/* Slide-out modal Receipt Details drawer */}
      <AnimatePresence>
        {viewingReceipt && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl relative border border-slate-100 flex flex-col gap-5 text-left"
            >
              {/* Receipt Header details */}
              <div className="flex flex-col items-center gap-1.5 pb-4 border-b border-dashed border-slate-100 text-center">
                <Logo className="scale-75 mb-1" />
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{lang === "zh" ? "云杉银行交易指令凭证" : "Transaction Settlement Receipt"}</span>
                <div className="text-2xl font-black font-mono mt-1 text-slate-900">
                  {viewingReceipt.type === "income" ? "+" : "-"} ¥{formatMoney(viewingReceipt.amount)}
                </div>
              </div>

              {/* Receipt Body items */}
              <div className="space-y-3 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold">{lang === "zh" ? "交易对手" : "Counterparty"}</span>
                  <span className="font-extrabold text-slate-900">{viewingReceipt.merchant}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold">{lang === "zh" ? "交易状态" : "Status"}</span>
                  <span className="font-bold text-emerald-600 flex items-center gap-1">
                    <ShieldCheck size={12} />
                    <span>{lang === "zh" ? "处理完毕 (Settled)" : "Settled"}</span>
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold">{lang === "zh" ? "交易时间" : "Settlement Time"}</span>
                  <span className="font-bold text-slate-800 font-mono">{viewingReceipt.date} {viewingReceipt.time}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold">{lang === "zh" ? "清算分类" : "Category"}</span>
                  <span className="font-bold text-slate-800">{getCategoryLabel(viewingReceipt.category)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-bold">{lang === "zh" ? "交易流水号" : "Trade Audit Hash"}</span>
                  <span className="font-mono text-[9px] text-slate-400 font-bold truncate max-w-[150px]">
                    {viewingReceipt.id.replace("tx-", "").replace("ex-", "").toUpperCase()}
                  </span>
                </div>
              </div>

              <button
                onClick={() => setViewingReceipt(null)}
                className="w-full bg-[#0C111D] text-white hover:bg-slate-800 text-xs font-bold py-3 rounded-xl transition-all active:scale-95 text-center cursor-pointer"
              >
                {t.closeBtn}
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
