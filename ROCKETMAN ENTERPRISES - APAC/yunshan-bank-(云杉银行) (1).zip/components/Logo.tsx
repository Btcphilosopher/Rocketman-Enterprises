import React from "react";

interface LogoProps {
  className?: string;
  light?: boolean;
}

export default function Logo({ className = "", light = false }: LogoProps) {
  return (
    <div className={`flex items-center gap-3 select-none ${className}`}>
      {/* Three slanted lines logo */}
      <div className="flex flex-col gap-[4px] shrink-0">
        <div className={`w-6 h-[3.5px] rounded-full transform -skew-x-[25deg] transition-colors duration-300 ${light ? "bg-white" : "bg-slate-900"}`} />
        <div className={`w-6 h-[3.5px] rounded-full transform -skew-x-[25deg] ml-[3px] transition-colors duration-300 ${light ? "bg-white/90" : "bg-slate-800"}`} />
        <div className={`w-6 h-[3.5px] rounded-full transform -skew-x-[25deg] ml-[6px] transition-colors duration-300 ${light ? "bg-white/80" : "bg-slate-700"}`} />
      </div>
      
      {/* Text lockup */}
      <div className="flex flex-col justify-center leading-none">
        <span className={`text-base font-bold tracking-widest ${light ? "text-white" : "text-slate-900"}`}>
          云杉银行
        </span>
        <span className={`text-[8.5px] font-semibold tracking-[0.22em] mt-[2px] ${light ? "text-white/70" : "text-slate-500"}`}>
          YUNSHAN BANK
        </span>
      </div>
    </div>
  );
}
