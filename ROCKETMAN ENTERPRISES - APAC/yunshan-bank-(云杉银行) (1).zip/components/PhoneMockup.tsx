'use client';

import React from "react";
import { motion } from "motion/react";
import { Eye, EyeOff, Send, Receipt, ArrowUpCircle, Plus, ChevronRight, Home, CreditCard, PieChart, User } from "lucide-react";
import Logo from "./Logo";

interface Transaction {
  id: string;
  merchant: string;
  date: string;
  time: string;
  amount: number;
  type: "income" | "expense";
  category: string;
}

interface PhoneMockupProps {
  balance: number;
  isBalanceVisible: boolean;
  onToggleBalance: () => void;
  transactions: Transaction[];
  lang: "zh" | "en";
  onLogin: () => void;
  onOpenTransfer: () => void;
  onOpenSavings: () => void;
}

export default function PhoneMockup({
  balance,
  isBalanceVisible,
  onToggleBalance,
  transactions,
  lang,
  onLogin,
  onOpenTransfer,
  onOpenSavings,
}: PhoneMockupProps) {
  // Take top 3 transactions to fit nicely inside the mock mobile screen
  const displayedTransactions = transactions.slice(0, 3);

  // Translations
  const t = {
    zh: {
      totalBalance: "总余额 (估算)",
      smartSavings: "智能储蓄",
      annualRate: "约定年化利率",
      recentTrans: "近期交易",
      viewAll: "查看全部",
      transfer: "转账",
      pay: "支付",
      topUp: "充值",
      more: "更多",
      home: "首页",
      cards: "卡片",
      wealth: "理财",
      me: "我的",
      alipay: "支付宝",
      starbucks: "星巴克咖啡",
      salary: "工资发放",
    },
    en: {
      totalBalance: "Total Balance",
      smartSavings: "Smart Savings",
      annualRate: "Annual Interest Rate",
      recentTrans: "Recent Transactions",
      viewAll: "View All",
      transfer: "Transfer",
      pay: "Pay",
      topUp: "Top Up",
      more: "More",
      home: "Home",
      cards: "Cards",
      wealth: "Wealth",
      me: "Me",
      alipay: "Alipay",
      starbucks: "Starbucks",
      salary: "Salary",
    }
  }[lang];

  // Format money with commas
  const formatMoney = (val: number) => {
    return new Intl.NumberFormat("zh-CN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val);
  };

  return (
    <div className="relative mx-auto w-[320px] h-[650px] bg-slate-900 rounded-[48px] p-3 shadow-2xl border-4 border-slate-800 ring-12 ring-slate-950/20 flex flex-col overflow-hidden">
      {/* Top speaker & dynamic island */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 w-28 h-6 bg-black rounded-2xl z-50 flex items-center justify-between px-4">
        {/* Dynamic Island Details */}
        <div className="w-2 h-2 rounded-full bg-slate-900" />
        <div className="w-12 h-1 bg-slate-900 rounded-full" />
      </div>

      {/* Screen container */}
      <div className="w-full h-full bg-[#F8F9FC] rounded-[38px] overflow-hidden flex flex-col relative pt-8 select-none text-slate-800">
        
        {/* Phone status bar */}
        <div className="px-6 py-1 flex justify-between items-center text-[10px] font-semibold text-slate-600 z-10">
          <span>09:41</span>
          <div className="flex items-center gap-1">
            {/* Cellular Signal Icons */}
            <div className="flex gap-[1px] items-end h-2">
              <span className="w-[2px] h-1 bg-slate-600 rounded-full" />
              <span className="w-[2px] h-1.5 bg-slate-600 rounded-full" />
              <span className="w-[2px] h-2 bg-slate-600 rounded-full" />
              <span className="w-[2px] h-2.5 bg-slate-600 rounded-full" />
            </div>
            <span>5G</span>
            {/* Battery Icon */}
            <div className="w-5 h-2.5 border border-slate-600 rounded-sm p-[1px] flex items-center">
              <div className="w-full h-full bg-slate-600 rounded-xs" />
            </div>
          </div>
        </div>

        {/* Screen Header */}
        <div className="px-5 pt-3 pb-2 flex justify-between items-center">
          <Logo className="scale-75 origin-left" />
          {/* Action icon for profile / scanning */}
          <button 
            onClick={onLogin}
            className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 active:scale-95 transition-all text-slate-700"
          >
            <User size={14} />
          </button>
        </div>

        {/* Balance Card */}
        <div className="px-5 mt-2">
          <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-100 relative overflow-hidden group">
            {/* Decorative background circle */}
            <div className="absolute -right-6 -bottom-6 w-20 h-20 bg-slate-50 rounded-full -z-0 transition-transform group-hover:scale-110" />
            
            <div className="relative z-10">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">{t.totalBalance}</span>
                <button 
                  onClick={onToggleBalance}
                  className="text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-50 transition-colors"
                >
                  {isBalanceVisible ? <EyeOff size={13} /> : <Eye size={13} />}
                </button>
              </div>
              <div className="text-xl font-bold font-mono tracking-tight text-slate-900 mt-1 flex items-baseline">
                <span className="text-sm mr-1">¥</span>
                {isBalanceVisible ? formatMoney(balance) : "••••••"}
              </div>
            </div>
          </div>
        </div>

        {/* Quick actions grid */}
        <div className="px-5 mt-4 grid grid-cols-4 gap-2">
          {[
            { label: t.transfer, icon: Send, color: "bg-slate-900 text-white", action: onOpenTransfer },
            { label: t.pay, icon: Receipt, color: "bg-white text-slate-800 border border-slate-100 shadow-xs", action: onLogin },
            { label: t.topUp, icon: ArrowUpCircle, color: "bg-white text-slate-800 border border-slate-100 shadow-xs", action: onLogin },
            { label: t.more, icon: Plus, color: "bg-white text-slate-800 border border-slate-100 shadow-xs", action: onLogin }
          ].map((item, idx) => (
            <button
              key={idx}
              onClick={item.action}
              className="flex flex-col items-center gap-1.5 focus:outline-none group active:scale-95 transition-transform"
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${item.color} transition-colors group-hover:brightness-95`}>
                <item.icon size={16} />
              </div>
              <span className="text-[10px] font-semibold text-slate-600 truncate max-w-full text-center">
                {item.label}
              </span>
            </button>
          ))}
        </div>

        {/* Smart Savings Promotion */}
        <div className="px-5 mt-4">
          <button 
            onClick={onOpenSavings}
            className="w-full bg-white rounded-2xl p-4 border border-slate-100 shadow-xs text-left flex justify-between items-center group hover:border-slate-300 transition-all active:scale-[0.99]"
          >
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{t.smartSavings}</span>
              <div className="text-xl font-extrabold text-slate-900 mt-0.5 tracking-tight">3.25%</div>
              <span className="text-[9px] font-medium text-slate-500">{t.annualRate}</span>
            </div>
            <div className="flex items-center gap-1 text-slate-400 group-hover:text-slate-900 transition-colors">
              <ChevronRight size={16} className="transform group-hover:translate-x-0.5 transition-transform" />
            </div>
          </button>
        </div>

        {/* Recent Transactions list */}
        <div className="px-5 mt-4 flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="flex justify-between items-center mb-1">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">{t.recentTrans}</span>
            <button 
              onClick={onLogin}
              className="text-[10px] font-bold text-slate-400 hover:text-slate-900 transition-colors"
            >
              {t.viewAll}
            </button>
          </div>

          <div className="space-y-1.5 overflow-y-auto no-scrollbar flex-1 pb-4">
            {displayedTransactions.map((tx) => {
              const isIncome = tx.type === "income";
              
              // Map mock names into corresponding translations
              let merchantLabel = tx.merchant;
              if (tx.merchant.toLowerCase() === "alipay") merchantLabel = t.alipay;
              else if (tx.merchant.toLowerCase() === "starbucks") merchantLabel = t.starbucks;
              else if (tx.merchant.toLowerCase() === "salary") merchantLabel = t.salary;

              return (
                <div 
                  key={tx.id}
                  className="flex items-center justify-between bg-white/70 hover:bg-white rounded-xl p-2.5 border border-slate-50/50 transition-all hover:shadow-xs"
                >
                  <div className="flex items-center gap-2">
                    {/* Tiny Icon placeholder based on category */}
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold ${
                      isIncome ? "bg-emerald-50 text-emerald-600" : "bg-blue-50 text-blue-600"
                    }`}>
                      {tx.merchant.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <div className="text-[11px] font-bold text-slate-800 truncate max-w-[100px]">
                        {merchantLabel}
                      </div>
                      <div className="text-[9px] text-slate-400">
                        {tx.date} · {tx.time}
                      </div>
                    </div>
                  </div>
                  <div className={`text-[11px] font-mono font-bold tracking-tight ${
                    isIncome ? "text-emerald-600" : "text-slate-900"
                  }`}>
                    {isIncome ? "+" : "-"} ¥{formatMoney(tx.amount)}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bottom App Navigation */}
        <div className="border-t border-slate-100 bg-white/95 backdrop-blur-xs px-4 py-2 flex justify-between items-center text-slate-400 z-10 shrink-0">
          {[
            { label: t.home, icon: Home, active: true },
            { label: t.cards, icon: CreditCard, active: false },
            { label: t.wealth, icon: PieChart, active: false },
            { label: t.me, icon: User, active: false }
          ].map((nav, index) => (
            <button 
              key={index}
              onClick={onLogin}
              className={`flex flex-col items-center gap-0.5 focus:outline-none ${
                nav.active ? "text-slate-900 font-bold" : "hover:text-slate-600"
              }`}
            >
              <nav.icon size={15} />
              <span className="text-[9px] font-medium">{nav.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Screen reflection/gloss overlay */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none rounded-[48px] bg-gradient-to-tr from-white/0 via-white/5 to-white/10 z-30" />
    </div>
  );
}
