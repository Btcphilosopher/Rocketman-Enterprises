import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Yunshan Bank | Your world. More connected.',
  description: 'Yunshan Bank brings together digital banking, global payments and intelligent finance — all in one app.',
  openGraph: {
    title: 'Yunshan Bank | Your world. More connected.',
    description: 'Yunshan Bank brings together digital banking, global payments and intelligent finance — all in one app.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Yunshan Bank | Your world. More connected.',
    description: 'Yunshan Bank brings together digital banking, global payments and intelligent finance — all in one app.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
