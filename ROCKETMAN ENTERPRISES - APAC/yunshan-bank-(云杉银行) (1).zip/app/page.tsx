'use client';

import React, { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import LandingPage from "@/components/LandingPage";
import Dashboard from "@/components/Dashboard";

interface Transaction {
  id: string;
  merchant: string;
  date: string;
  time: string;
  amount: number;
  type: "income" | "expense";
  category: string;
}

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [lang, setLang] = useState<"zh" | "en">("zh");
  const [isBalanceVisible, setIsBalanceVisible] = useState(true);
  const [balance, setBalance] = useState(128460.00); // Matches mockup amount exactly!
  const [dashboardOpenTab, setDashboardOpenTab] = useState("overview");

  // Initial transactions synced with the provided mockup image
  const [transactions, setTransactions] = useState<Transaction[]>([
    {
      id: "tx-1",
      merchant: "Alipay",
      date: "Today",
      time: "10:24",
      amount: 320.00,
      type: "expense",
      category: "shopping"
    },
    {
      id: "tx-2",
      merchant: "Starbucks",
      date: "Today",
      time: "08:17",
      amount: 68.00,
      type: "expense",
      category: "food"
    },
    {
      id: "tx-3",
      merchant: "Salary",
      date: "Yesterday",
      time: "16:03",
      amount: 12000.00,
      type: "income",
      category: "salary"
    },
    {
      id: "tx-4",
      merchant: "Tencent Cloud",
      date: "2026-10-02",
      time: "14:11",
      amount: 1450.00,
      type: "expense",
      category: "utilities"
    },
    {
      id: "tx-5",
      merchant: "ICBC Security Dividend",
      date: "2026-09-28",
      time: "09:30",
      amount: 4500.00,
      type: "income",
      category: "investment"
    }
  ]);

  const toggleBalanceVisibility = () => {
    setIsBalanceVisible(prev => !prev);
  };

  const handleNavigateToDashboard = (tab = "overview") => {
    setDashboardOpenTab(tab);
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <div className="bg-[#F8F9FC] min-h-screen text-slate-800 selection:bg-slate-900 selection:text-white">
      <AnimatePresence mode="wait">
        {!isLoggedIn ? (
          <motion.div
            key="landing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
          >
            <LandingPage
              balance={balance}
              isBalanceVisible={isBalanceVisible}
              onToggleBalance={toggleBalanceVisibility}
              transactions={transactions}
              lang={lang}
              setLang={setLang}
              onNavigateToDashboard={() => handleNavigateToDashboard("overview")}
              onOpenQuickTransfer={() => handleNavigateToDashboard("transfer")}
              onOpenSavingsInDashboard={() => handleNavigateToDashboard("savings")}
            />
          </motion.div>
        ) : (
          <motion.div
            key="dashboard"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.4 }}
          >
            <Dashboard
              balance={balance}
              setBalance={setBalance}
              transactions={transactions}
              setTransactions={setTransactions}
              isBalanceVisible={isBalanceVisible}
              onToggleBalance={toggleBalanceVisibility}
              lang={lang}
              onLogout={handleLogout}
              openTab={dashboardOpenTab}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
