import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize the Google Gen AI SDK
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function POST(req: NextRequest) {
  try {
    const { transactions, savingsRate, customPrompt, totalBalance, username } = await req.json();

    const systemInstructions = `
You are Yunshan Intelligence (云杉智能), the elite AI Financial Advisor for Yunshan Bank (云杉银行). 
Your task is to provide personalized, professional, highly actionable financial insights and advisory reports for the client.
The client's name is ${username || "Tom"}.
Always maintain a prestigious, professional, friendly, and elite banking tone. 
Respond in the user's preferred language (blend English and Chinese elegantly, e.g., using terms like "Smart Savings (智能储蓄)" or "Annual Interest Rate (年化利率)").

Current Client Financial Snapshot:
- Total Liquid Balance: ${totalBalance}
- Savings Annual Interest Rate: ${savingsRate || "3.25%"}
- Recent Transactions:
${JSON.stringify(transactions || [], null, 2)}

Provide your response in beautifully formatted Markdown with the following sections:
1. **Financial Health Score (财务健康评估)**: Give a constructive rating (e.g. 94/100) based on their ratio of income to spending, and state what is going well.
2. **Spending Breakdown & Insights (消费分类洞察)**: Summarize where their money is going, identifying any patterns or potential leaks (e.g., Starbucks, Alipay).
3. **Smart Savings Optimizer (储蓄与理财优化)**: Calculate how much they could make over 1, 3, and 5 years with their 3.25% APR savings rate, and recommend how much more to deposit.
4. **Actionable Suggestions (云杉专属建议)**: Provide 3 concrete, personalized action steps.

Keep the markdown clean, highly readable, and free of unnecessary clutter. Do not use generic AI intro or outro greetings; start directly with the title.
`;

    const userMessage = customPrompt 
      ? `User's question/request: "${customPrompt}"`
      : `Generate my monthly financial health report and investment advice.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: userMessage,
      config: {
        systemInstruction: systemInstructions,
        temperature: 0.7,
      }
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    return NextResponse.json(
      { error: "Failed to generate financial insights. Please verify your GEMINI_API_KEY." },
      { status: 500 }
    );
  }
}
