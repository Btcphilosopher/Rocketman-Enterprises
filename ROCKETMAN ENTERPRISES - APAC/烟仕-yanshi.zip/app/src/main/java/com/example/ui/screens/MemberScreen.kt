package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import com.example.domain.AgeVerificationStatus
import com.example.domain.Member
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun MemberScreen() {
    val state by SimulationEngine.state.collectAsState()
    var searchKeyword by remember { mutableStateOf("") }
    var selectedStatus by remember { mutableStateOf<AgeVerificationStatus?>(null) }
    var showAddMemberDialog by remember { mutableStateOf(false) }
    var selectedMemberForAudit by remember { mutableStateOf<Member?>(null) }

    val filteredMembers = state.members.filter { m ->
        (searchKeyword.isEmpty() || m.name.contains(searchKeyword) || m.phoneMasked.contains(searchKeyword) || m.id.contains(searchKeyword)) &&
        (selectedStatus == null || m.ageVerificationStatus == selectedStatus)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // 顶部操作栏
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "雅仕成年会员核验证照簿",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
                Text(
                    text = "坚守未成年人零推荐准则 · 100% 实名登记",
                    fontSize = 11.sp,
                    color = SealRed,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // 新增注册
            Button(
                onClick = { showAddMemberDialog = true },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
            ) {
                Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("注册新雅仕 (实名登记)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 搜索筛选栏
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = searchKeyword,
                onValueChange = { searchKeyword = it },
                placeholder = { Text("搜索会员姓名、电话、凭证号...", fontSize = 11.sp, color = GraphiteGrey) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier
                    .weight(1.5f)
                    .height(48.dp),
                shape = RoundedCornerShape(2.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SealRed,
                    unfocusedBorderColor = CharcoalInk,
                    focusedContainerColor = OffWhite,
                    unfocusedContainerColor = OffWhite
                ),
                singleLine = true
            )

            // 核验状态选择
            var statusExpanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.weight(1.2f)) {
                OutlinedButton(
                    onClick = { statusExpanded = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(2.dp),
                    border = BorderStroke(1.dp, CharcoalInk),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(selectedStatus?.label ?: "全部核验状态", fontSize = 11.sp)
                        Text("▼", fontSize = 8.sp, color = GraphiteGrey)
                    }
                }
                DropdownMenu(expanded = statusExpanded, onDismissRequest = { statusExpanded = false }) {
                    DropdownMenuItem(text = { Text("全部核验状态") }, onClick = { selectedStatus = null; statusExpanded = false })
                    AgeVerificationStatus.values().forEach { st ->
                        DropdownMenuItem(
                            text = { Text(st.label) },
                            onClick = {
                                selectedStatus = st
                                statusExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 会员账本表格
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .border(1.dp, MutedPaper)
        ) {
            // 表头
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalInk)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("证本号", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                Text("雅仕姓名", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("实名手机", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                Text("法定年龄", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(0.8f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("双介质核验状态", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("初审核签人", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("安全核对", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }

            // 表体
            filteredMembers.forEachIndexed { index, member ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (index % 2 == 0) OffWhite else WarmPaper)
                        .clickable { selectedMemberForAudit = member }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(member.id, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontFamily = FontFamily.Monospace)
                    Text(member.name, color = CharcoalInk, fontSize = 12.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    Text(member.phoneMasked, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                    Text(
                        text = "${member.verifiedAge ?: 0} 岁",
                        color = if ((member.verifiedAge ?: 0) < 18) StatusError else CharcoalInk,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(0.8f),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    
                    // 状态徽章
                    Box(modifier = Modifier.weight(1.5f), contentAlignment = Alignment.Center) {
                        val bColor = when(member.ageVerificationStatus) {
                            AgeVerificationStatus.VERIFIED -> StatusSuccess
                            AgeVerificationStatus.MANUAL_REVIEW -> StatusAlert
                            AgeVerificationStatus.UNVERIFIED, AgeVerificationStatus.VERIFICATION_FAILED -> StatusError
                            else -> GraphiteGrey
                        }
                        Box(
                            modifier = Modifier
                                .background(bColor.copy(alpha = 0.12f), RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(member.ageVerificationStatus.label, color = bColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    val verifiedBy = if (member.ageVerificationStatus == AgeVerificationStatus.VERIFIED) "公安NFC芯片" else "系统初审中"
                    Text(verifiedBy, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)

                    Box(modifier = Modifier.weight(1.2f), contentAlignment = Alignment.Center) {
                        if (member.ageVerificationStatus == AgeVerificationStatus.MANUAL_REVIEW || member.ageVerificationStatus == AgeVerificationStatus.UNVERIFIED) {
                            IconButton(onClick = { selectedMemberForAudit = member }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.AssignmentLate, contentDescription = null, tint = SealRed)
                            }
                        } else {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // 1. 人工证照双盲核验对话框 (Manual Verification Audit)
        selectedMemberForAudit?.let { member ->
            var auditRemark by remember { mutableStateOf("") }
            
            AlertDialog(
                onDismissRequest = { selectedMemberForAudit = null },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                SimulationEngine.approveMemberManualReview(member.id)
                                selectedMemberForAudit = null
                            },
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess, contentColor = WarmPaper)
                        ) {
                            Text("复审核准通过")
                        }
                        Button(
                            onClick = {
                                selectedMemberForAudit = null
                            },
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusError, contentColor = WarmPaper)
                        ) {
                            Text("驳回暂缓")
                        }
                    }
                },
                title = { Text("实名硬件证照初核终端", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalInk) },
                text = {
                    Column {
                        Text("当前待复核会员: ${member.name}", fontSize = 12.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                        Text("登记手机号: ${member.phoneMasked}", fontSize = 11.sp, color = CharcoalInk)
                        Text("注册签发日期: ${member.registrationDate}", fontSize = 11.sp, color = CharcoalInk)
                        Text("自述年龄: ${member.verifiedAge ?: 0} 岁", fontSize = 11.sp, color = if ((member.verifiedAge ?: 0) < 18) StatusError else CharcoalInk, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(12.dp))

                        // 合规警告
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SealRed.copy(alpha = 0.05f))
                                .border(1.dp, SealRed.copy(alpha = 0.3f))
                                .padding(8.dp)
                        ) {
                            Text(
                                text = "【初审警示】经查该会员使用的身份证芯片信息匹配正常。系统后台未发现重号记录。请对照其手持芯片卡片或健康绿色绿码，确认真人五官与其芯片预留人脸一致，杜绝外借证件强闯通道。",
                                color = SealRed,
                                fontSize = 10.sp,
                                lineHeight = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("经办审核意见备档:", fontSize = 11.sp, color = CharcoalInk)
                        OutlinedTextField(
                            value = auditRemark,
                            onValueChange = { auditRemark = it },
                            placeholder = { Text("例：核查物理证件无误，人脸无差别通过。", fontSize = 10.sp) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            shape = RoundedCornerShape(2.dp),
                            textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                        )
                    }
                }
            )
        }

        // 2. 注册新雅仕对话框 Add Member
        if (showAddMemberDialog) {
            var newName by remember { mutableStateOf("") }
            var newPhone by remember { mutableStateOf("") }
            var newDobYear by remember { mutableStateOf("1998") }
            var newDobMonth by remember { mutableStateOf("08") }
            var newDobDay by remember { mutableStateOf("18") }

            AlertDialog(
                onDismissRequest = { showAddMemberDialog = false },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newName.isNotEmpty() && newPhone.isNotEmpty()) {
                                val dobStr = "$newDobYear-$newDobMonth-$newDobDay"
                                SimulationEngine.registerNewMember(newName, newPhone, dobStr)
                                showAddMemberDialog = false
                            }
                        },
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
                    ) {
                        Text("录入公安介质备案")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddMemberDialog = false }) {
                        Text("取消", color = CharcoalInk)
                    }
                },
                title = { Text("实名登记新雅仕会员 (双盲申报)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalInk) },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        Text("请输入顾客手持智能身份证上的真实物理数据:", fontSize = 11.sp, color = GraphiteGrey)
                        
                        Spacer(modifier = Modifier.height(10.dp))

                        Text("雅仕全名:", fontSize = 11.sp, color = CharcoalInk)
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            shape = RoundedCornerShape(2.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text("手机号 (实名核验联络):", fontSize = 11.sp, color = CharcoalInk)
                        OutlinedTextField(
                            value = newPhone,
                            onValueChange = { newPhone = it },
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            shape = RoundedCornerShape(2.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text("法定出生年月日 (极其关键 · 严格计算未成年防线):", fontSize = 11.sp, color = CharcoalInk)
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            OutlinedTextField(
                                value = newDobYear,
                                onValueChange = { newDobYear = it },
                                label = { Text("年", fontSize = 8.sp) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                            )
                            OutlinedTextField(
                                value = newDobMonth,
                                onValueChange = { newDobMonth = it },
                                label = { Text("月", fontSize = 8.sp) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                            )
                            OutlinedTextField(
                                value = newDobDay,
                                onValueChange = { newDobDay = it },
                                label = { Text("日", fontSize = 8.sp) },
                                modifier = Modifier.weight(1f).height(46.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 11.sp)
                            )
                        }
                    }
                }
            )
        }
    }
}
