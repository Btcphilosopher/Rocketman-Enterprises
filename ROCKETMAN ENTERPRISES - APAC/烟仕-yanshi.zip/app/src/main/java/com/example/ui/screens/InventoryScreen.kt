package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.InventoryLedger
import com.example.domain.Product
import com.example.domain.ProductCategory
import com.example.domain.ProductStatus
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun InventoryScreen() {
    val state by SimulationEngine.state.collectAsState()
    var selectedTab by remember { mutableStateOf(0) } // 0: 实时库存控制, 1: 变动流水账本
    
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // 头标签
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "库存精细控制与流水审计",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalInk
            )
            
            // 选项卡切换
            TabRow(
                selectedTabIndex = selectedTab,
                modifier = Modifier.width(260.dp),
                containerColor = OffWhite,
                contentColor = SealRed,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = SealRed
                    )
                }
            ) {
                Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                    Text("实时库存", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp), color = CharcoalInk)
                }
                Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                    Text("变动流水", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp), color = CharcoalInk)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedTab == 0) {
            RealtimeInventoryLayout(products = state.products)
        } else {
            InventoryLedgerLayout(ledgers = state.ledgers)
        }
    }
}

@Composable
fun RealtimeInventoryLayout(products: List<Product>) {
    var adjustProduct by remember { mutableStateOf<Product?>(null) }
    var transferProduct by remember { mutableStateOf<Product?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // 常规库存清单
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .border(1.dp, MutedPaper)
        ) {
            // 表头
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalInk)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("商品编号", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("品牌与商品名称", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(2.5f), fontWeight = FontWeight.Bold)
                Text("安全规格", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                Text("总库剩余", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                Text("状态", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("操作管理", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.8f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }

            // 表体
            products.forEachIndexed { index, product ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (index % 2 == 0) OffWhite else WarmPaper)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(product.id, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                    Column(modifier = Modifier.weight(2f)) {
                        Text(product.brand, color = AgedBrass, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(product.name, color = CharcoalInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(product.specification, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                    
                    Text(
                        text = "${product.totalStock} 盒/件",
                        color = if (product.totalStock == 0) StatusError else if (product.totalStock < 50) StatusAlert else StatusSuccess,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.End
                    )

                    // 库房状态徽章
                    Box(modifier = Modifier.weight(1.2f), contentAlignment = Alignment.Center) {
                        val label = if (product.totalStock == 0) "已售罄" else if (product.totalStock < 50) "低库存预警" else "充足"
                        val bColor = if (product.totalStock == 0) StatusError else if (product.totalStock < 50) StatusAlert else StatusSuccess
                        Box(
                            modifier = Modifier
                                .background(bColor.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(label, color = bColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // 补货调拨按钮区
                    Row(
                        modifier = Modifier.weight(1.8f),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { adjustProduct = product },
                            shape = RoundedCornerShape(2.dp),
                            border = BorderStroke(1.dp, CharcoalInk),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("紧急补货", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { transferProduct = product },
                            shape = RoundedCornerShape(2.dp),
                            border = BorderStroke(1.dp, AgedBrass),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = AgedBrass),
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("库间调拨", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 补货模态弹窗
        adjustProduct?.let { prod ->
            var qtyInput by remember { mutableStateOf("100") }
            AlertDialog(
                onDismissRequest = { adjustProduct = null },
                confirmButton = {
                    Button(
                        onClick = {
                            val q = qtyInput.toIntOrNull() ?: 100
                            SimulationEngine.requestRestock(prod.id, q)
                            adjustProduct = null
                        },
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
                    ) {
                        Text("提交补货申请")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { adjustProduct = null }) {
                        Text("取消", color = CharcoalInk)
                    }
                },
                title = { Text("紧急物料订购与补货申报", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalInk) },
                text = {
                    Column {
                        Text("您正在向 [${prod.supplier}] 订购合成商品：", fontSize = 12.sp, color = GraphiteGrey)
                        Text("${prod.name} (${prod.specification})", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SealRed, modifier = Modifier.padding(top = 4.dp))
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Text("输入增配补货数量 (默认：100):", fontSize = 11.sp, color = CharcoalInk)
                        OutlinedTextField(
                            value = qtyInput,
                            onValueChange = { qtyInput = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SealRed, unfocusedBorderColor = CharcoalInk)
                        )
                        Text("系统会自动折算合成进销货价并备案，到货批次约在1-2个时间周期(Tick)后抵仓。", fontSize = 10.sp, color = GraphiteGrey, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            )
        }

        // 调拨模态弹窗
        transferProduct?.let { prod ->
            var selectedDestStoreId by remember { mutableStateOf("ST-02") }
            var transferQty by remember { mutableStateOf("20") }
            val state by SimulationEngine.state.collectAsState()

            AlertDialog(
                onDismissRequest = { transferProduct = null },
                confirmButton = {
                    Button(
                        onClick = {
                            val q = transferQty.toIntOrNull() ?: 20
                            SimulationEngine.approveStoreTransfer(
                                fromStoreId = state.currentStore.id,
                                toStoreId = selectedDestStoreId,
                                productId = prod.id,
                                qty = q
                            )
                            transferProduct = null
                        },
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
                    ) {
                        Text("确认调出")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { transferProduct = null }) {
                        Text("取消", color = CharcoalInk)
                    }
                },
                title = { Text("门店库存共享调拨 (跨店自调)", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalInk) },
                text = {
                    Column {
                        Text("当前发货门店: ${state.currentStore.name}", fontSize = 11.sp, color = GraphiteGrey)
                        Text("调拨商品: ${prod.name} (当前本网点有余货 ${prod.totalStock} 件)", fontSize = 12.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                        
                        Spacer(modifier = Modifier.height(12.dp))

                        // 目标门店选择
                        Text("选择接收调配网点:", fontSize = 11.sp, color = CharcoalInk)
                        var expanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            val destStore = state.stores.find { it.id == selectedDestStoreId } ?: state.stores.first()
                            OutlinedButton(
                                onClick = { expanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(destStore.name)
                                    Text("▼", fontSize = 10.sp)
                                }
                            }
                            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                state.stores.filter { it.id != state.currentStore.id }.forEach { st ->
                                    DropdownMenuItem(
                                        text = { Text(st.name) },
                                        onClick = {
                                            selectedDestStoreId = st.id
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text("输入调拨货量数量:", fontSize = 11.sp, color = CharcoalInk)
                        OutlinedTextField(
                            value = transferQty,
                            onValueChange = { transferQty = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 6.dp),
                            shape = RoundedCornerShape(2.dp),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SealRed, unfocusedBorderColor = CharcoalInk)
                        )
                    }
                }
            )
        }
    }
}

@Composable
fun InventoryLedgerLayout(ledgers: List<InventoryLedger>) {
    Column(modifier = Modifier.fillMaxSize()) {
        if (ledgers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MutedPaper)
                    .background(OffWhite),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.History, contentDescription = null, tint = GraphiteGrey, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("账本无历史流水变动", color = GraphiteGrey, fontSize = 14.sp)
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .border(1.dp, MutedPaper)
            ) {
                // 表头
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalInk)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("时间记录", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                    Text("操作店口", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                    Text("商品明细", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(2f), fontWeight = FontWeight.Bold)
                    Text("业务性质", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                    Text("数量差额", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    Text("经办签名", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }

                // 表体
                ledgers.forEachIndexed { index, ledger ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (index % 2 == 0) OffWhite else WarmPaper)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(ledger.timestamp, color = CharcoalInk, fontSize = 10.sp, modifier = Modifier.weight(1.2f), fontFamily = FontFamily.Monospace)
                        Text(ledger.storeName, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                        Column(modifier = Modifier.weight(2f)) {
                            Text(ledger.productName, color = CharcoalInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text("编号: ${ledger.productId} | 余存: ${ledger.afterQty}", color = GraphiteGrey, fontSize = 10.sp)
                        }
                        Text(ledger.type, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                        Text(
                            text = if (ledger.quantityChange > 0) "+${ledger.quantityChange}" else "${ledger.quantityChange}",
                            color = if (ledger.quantityChange > 0) StatusSuccess else StatusError,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.End
                        )
                        Text(
                            text = ledger.operator,
                            color = CharcoalInk,
                            fontSize = 11.sp,
                            modifier = Modifier.weight(1f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
