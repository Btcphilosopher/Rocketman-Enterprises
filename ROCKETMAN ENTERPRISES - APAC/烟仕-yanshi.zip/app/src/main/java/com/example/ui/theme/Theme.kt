package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = SealRed,
    secondary = AgedBrass,
    tertiary = GraphiteGrey,
    background = CharcoalInk,
    surface = Color(0xFF242B28),
    onPrimary = White,
    onSecondary = CharcoalInk,
    onBackground = WarmPaper,
    onSurface = WarmPaper
  )

private val LightColorScheme =
  lightColorScheme(
    primary = SealRed,
    secondary = AgedBrass,
    tertiary = GraphiteGrey,
    background = WarmPaper,
    surface = OffWhite,
    onPrimary = White,
    onSecondary = CharcoalInk,
    onTertiary = White,
    onBackground = CharcoalInk,
    onSurface = CharcoalInk,
  )

@Composable
fun YanshiTheme(
  darkTheme: Boolean = false, // 强制默认浅色模式展现米色宣纸和高级木纹的高端质感
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
