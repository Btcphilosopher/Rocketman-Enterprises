package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.SupplyChainOrder
import com.example.domain.TransitStatus
import com.example.domain.RiskLevel
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun SupplyChainScreen() {
    val state by SimulationEngine.state.collectAsState()
    var selectedOrderForAction by remember { mutableStateOf<SupplyChainOrder?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "专营进销存 · 供应链在途追踪",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
                Text(
                    text = "中国烟草工业集团直供专线 · 恒温物流舱全流程链条",
                    fontSize = 11.sp,
                    color = SealRed,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // 新增采购
            Button(
                onClick = {
                    if (state.products.isNotEmpty()) {
                        val firstProd = state.products.first()
                        SimulationEngine.requestRestock(firstProd.id, 150)
                    }
                },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
            ) {
                Icon(Icons.Default.AddBusiness, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("向烟草工业集团一键申报直供", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 顶端物流摘要
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val totalInTransit = state.supplyOrders.count { it.status == TransitStatus.IN_TRANSIT || it.status == TransitStatus.DISPATCHED }
            val totalDelayed = state.supplyOrders.count { it.status == TransitStatus.DELAYED }
            
            Box(modifier = Modifier.weight(1f)) {
                SupplyMetricCard(
                    title = "在途恒温直配班次",
                    value = "${totalInTransit} 批",
                    color = AgedBrass,
                    icon = Icons.Default.LocalShipping
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                SupplyMetricCard(
                    title = "冷链异常预警班次",
                    value = "${totalDelayed} 批",
                    color = if (totalDelayed > 0) SealRed else StatusSuccess,
                    icon = Icons.Default.Thermostat
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                SupplyMetricCard(
                    title = "申报已签收妥投",
                    value = "${state.supplyOrders.count { it.status == TransitStatus.DELIVERED }} 批",
                    color = StatusSuccess,
                    icon = Icons.Default.TaskAlt
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 中间主表：供应链账本
        Card(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
            colors = CardDefaults.cardColors(containerColor = OffWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "实时在途班次流水 (上海冷链总调度专线)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
                Spacer(modifier = Modifier.height(10.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, MutedPaper)
                        .verticalScroll(rememberScrollState())
                ) {
                    // 表头
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CharcoalInk)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("物流单号", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                        Text("采购物料内容", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.8f), fontWeight = FontWeight.Bold)
                        Text("直配申报数量", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(0.9f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        Text("航路干线轨迹", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.8f), fontWeight = FontWeight.Bold)
                        Text("冷链温控状态", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("在途卡标", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                        Text("现场接车", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }

                    // 表体
                    state.supplyOrders.forEachIndexed { index, order ->
                        // 动态计算模拟物料名及恒温信息
                        val mockMaterialName = when (order.id.takeLast(2)) {
                            "01" -> "烟仕·东方锦绣 纪念装 (批量)"
                            "02" -> "暮雨雪茄·半岛臻选 (定制)"
                            else -> "雅仕精品专供卷烟 (标准周配)"
                        }
                        val mockSpecification = "20支/盒 | 50条/箱"
                        val tempSensorNormal = (order.id.hashCode() % 5 != 0)
                        val tempSensorText = if (tempSensorNormal) "19°C (恒温)" else "26°C (超标)"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (index % 2 == 0) OffWhite else WarmPaper)
                                .clickable { selectedOrderForAction = order }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(order.id, color = CharcoalInk, fontSize = 10.sp, modifier = Modifier.weight(1.2f), fontFamily = FontFamily.Monospace)
                            
                            Column(modifier = Modifier.weight(1.8f)) {
                                Text(mockMaterialName, color = CharcoalInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("规格: $mockSpecification", color = GraphiteGrey, fontSize = 10.sp)
                            }
                            
                            Text("${order.itemsCount * 5} 箱", color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(0.9f), textAlign = androidx.compose.ui.text.style.TextAlign.End, fontWeight = FontWeight.Bold)
                            Text(order.routeDesc, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.8f))
                            
                            // 冷链温控 (1D/2D IoT)
                            Box(modifier = Modifier.weight(1.0f), contentAlignment = Alignment.Center) {
                                Box(
                                    modifier = Modifier
                                        .background(if (tempSensorNormal) StatusSuccess.copy(alpha = 0.12f) else StatusError.copy(alpha = 0.12f), RoundedCornerShape(2.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = tempSensorText,
                                        color = if (tempSensorNormal) StatusSuccess else StatusError,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // 状态
                            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                val bColor = when(order.status) {
                                    TransitStatus.DELIVERED -> StatusSuccess
                                    TransitStatus.DELAYED -> StatusError
                                    else -> AgedBrass
                                }
                                Box(
                                    modifier = Modifier
                                        .background(bColor.copy(alpha = 0.12f), RoundedCornerShape(2.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(order.status.label, color = bColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // 签收操作
                            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                                if (order.status == TransitStatus.DELIVERED) {
                                    Icon(Icons.Default.Verified, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(16.dp))
                                } else {
                                    IconButton(
                                        onClick = { selectedOrderForAction = order },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.DownloadForOffline, contentDescription = null, tint = SealRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 签收处置弹窗
        selectedOrderForAction?.let { order ->
            val tempSensorNormal = (order.id.hashCode() % 5 != 0)
            val tempSensorText = if (tempSensorNormal) "19°C (恒温达标)" else "26°C (超温异常)"

            AlertDialog(
                onDismissRequest = { selectedOrderForAction = null },
                confirmButton = {
                    if (order.status != TransitStatus.DELIVERED) {
                        Button(
                            onClick = {
                                SimulationEngine.approveSupplyOrder(order.id)
                                selectedOrderForAction = null
                            },
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
                        ) {
                            Text("清点卸货·确认核签入库")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedOrderForAction = null }) {
                        Text(if (order.status == TransitStatus.DELIVERED) "关闭" else "取消", color = CharcoalInk)
                    }
                },
                title = { Text("直配恒温物流接车审核终端", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalInk) },
                text = {
                    Column {
                        Text("采购批次: ${order.id}", fontSize = 10.sp, color = GraphiteGrey)
                        Text("直配直供路线: ${order.routeDesc}", fontSize = 11.sp, color = CharcoalInk)
                        Text("干线当前温度传感器状态: $tempSensorText", fontSize = 11.sp, color = CharcoalInk)
                        Text("经办在途签注: 进关卡核验完毕，温湿达标，绿卡放行。", fontSize = 11.sp, color = GraphiteGrey)

                        Spacer(modifier = Modifier.height(12.dp))

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(OffWhite)
                                .border(1.dp, MutedPaper)
                                .padding(10.dp)
                        ) {
                            Text(
                                text = if (order.status == TransitStatus.DELIVERED) "【妥投结单】本批次货物已于较早前安全运抵并入库妥投完毕，库存账目折算无误。"
                                       else "【待卸货】车辆正处于店门口卸货平台。请核对货品电子标签。确认无误后点击“清点卸货”按钮，系统将自动把货物累加至专营后仓，并将此物流批次归档为妥投状态。",
                                color = CharcoalInk,
                                fontSize = 11.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun SupplyMetricCard(
    title: String,
    value: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
        colors = CardDefaults.cardColors(containerColor = OffWhite),
        shape = RoundedCornerShape(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(title, fontSize = 10.sp, color = GraphiteGrey)
                Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
            }
            Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
        }
    }
}
