package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectTapGestures
import com.example.domain.RiskLevel
import com.example.domain.Screen
import com.example.domain.Store
import com.example.domain.StoreStatus
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun StoreScreen() {
    val state by SimulationEngine.state.collectAsState()
    var selectedStoreForTwin by remember { mutableStateOf<Store?>(null) }
    
    // 如果选择了孪生，展示数字孪生界面，否则展示门店列表
    if (selectedStoreForTwin != null) {
        StoreTwinLayout(
            store = selectedStoreForTwin!!,
            onBack = { selectedStoreForTwin = null }
        )
    } else {
        StoreNetworkLayout(
            stores = state.stores,
            currentStoreId = state.currentStore.id,
            onSelectStore = { SimulationEngine.changeCurrentStore(it) },
            onOpenTwin = { selectedStoreForTwin = it }
        )
    }
}

@Composable
fun StoreNetworkLayout(
    stores: List<Store>,
    currentStoreId: String,
    onSelectStore: (Store) -> Unit,
    onOpenTwin: (Store) -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "全国专营网点与安全检测",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalInk
            )
            Box(
                modifier = Modifier
                    .background(SealRed.copy(alpha = 0.1f))
                    .border(1.dp, SealRed)
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "共有网点 ${stores.size} 家",
                    fontSize = 11.sp,
                    color = SealRed,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 列表区
        Column(
            modifier = Modifier
                .weight(1.5f)
                .verticalScroll(rememberScrollState())
                .border(1.dp, MutedPaper)
        ) {
            // 表头
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalInk)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("城市/商圈", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                Text("门店专营名称", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(2f), fontWeight = FontWeight.Bold)
                Text("专卖许可证状态", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                Text("今日交易(笔)", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                Text("合规风险评级", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Text("数字孪生", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }

            // 表体
            stores.forEachIndexed { index, store ->
                val isCurrent = store.id == currentStoreId
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isCurrent) SealRed.copy(alpha = 0.05f) else if (index % 2 == 0) OffWhite else WarmPaper)
                        .border(if (isCurrent) BorderStroke(1.dp, SealRed) else BorderStroke(0.dp, Color.Transparent))
                        .clickable { onSelectStore(store) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(store.city, color = CharcoalInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(store.businessDistrict, color = GraphiteGrey, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Row(modifier = Modifier.weight(2f), verticalAlignment = Alignment.CenterVertically) {
                        Text(store.name, color = CharcoalInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        if (isCurrent) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(modifier = Modifier.background(SealRed).padding(horizontal = 4.dp, vertical = 1.dp)) {
                                Text("当前", color = WarmPaper, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Column(modifier = Modifier.weight(1.5f)) {
                        Text(store.licenseNo, color = CharcoalInk, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text(
                            text = store.licenseStatus,
                            color = when(store.licenseStatus) {
                                "有效" -> StatusSuccess
                                "即将到期" -> StatusAlert
                                else -> StatusError
                            },
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Text(
                        text = "${store.todayTransactions}",
                        color = CharcoalInk,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.End
                    )
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        Box(
                            modifier = Modifier
                                .background(
                                    when(store.riskLevel) {
                                        RiskLevel.INFO -> StatusSuccess.copy(alpha = 0.1f)
                                        RiskLevel.LOW -> StatusSuccess.copy(alpha = 0.15f)
                                        RiskLevel.MEDIUM -> StatusAlert.copy(alpha = 0.15f)
                                        RiskLevel.HIGH -> StatusError.copy(alpha = 0.15f)
                                        RiskLevel.CRITICAL -> StatusError.copy(alpha = 0.2f)
                                    },
                                    RoundedCornerShape(2.dp)
                                )
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = store.riskLevel.label,
                                color = when(store.riskLevel) {
                                    RiskLevel.INFO, RiskLevel.LOW -> StatusSuccess
                                    RiskLevel.MEDIUM -> StatusAlert
                                    else -> StatusError
                                },
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Box(modifier = Modifier.weight(1.2f), contentAlignment = Alignment.Center) {
                        IconButton(
                            onClick = { onOpenTwin(store) },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(Icons.Default.FlipToFront, contentDescription = null, tint = SealRed)
                        }
                    }
                }
            }
        }
    }
}

// 门店数字孪生布局
@Composable
fun StoreTwinLayout(store: Store, onBack: () -> Unit) {
    // 孪生热点状态
    var selectedZone by remember { mutableStateOf("MainCounter") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // 返回头
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onBack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null, tint = CharcoalInk)
                }
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "${store.name} · 三维数字孪生舱",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
            }
            Text(
                text = "演示系统·二维结构总线",
                fontSize = 10.sp,
                color = SealRed,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 左半：Canvas 室内孪生平面图
            Box(
                modifier = Modifier
                    .weight(1.8f)
                    .height(380.dp)
                    .border(1.dp, CharcoalInk)
                    .background(OffWhite)
                    .padding(16.dp)
            ) {
                InteractiveStorePlan(
                    selectedZone = selectedZone,
                    onSelectZone = { selectedZone = it },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // 右半：当前选择孪生区域指标面板
            Column(modifier = Modifier.weight(1.2f)) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        val zoneDetails = getZoneDetails(selectedZone)
                        
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(zoneDetails.icon, contentDescription = null, tint = SealRed, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = zoneDetails.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalInk
                            )
                        }

                        Divider(color = CharcoalInk, modifier = Modifier.padding(vertical = 10.dp))

                        // 环境指标
                        Text(text = "现场传感器环境数据 (IoT)", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            EnvironmentTag(label = "温度", valStr = zoneDetails.temp)
                            EnvironmentTag(label = "湿度", valStr = zoneDetails.humidity)
                            EnvironmentTag(label = "PM2.5", valStr = "微量")
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 运营及安全指数
                        Text(text = "运营指标与货架健康", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("商品上架利用率", fontSize = 11.sp, color = CharcoalInk)
                            Text(zoneDetails.shelfRate, fontSize = 11.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("当前模拟承载人数", fontSize = 11.sp, color = CharcoalInk)
                            Text("${zoneDetails.liveTraffic} 人", fontSize = 11.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("安防探头状态", fontSize = 11.sp, color = CharcoalInk)
                            Text(
                                text = zoneDetails.sensorHealth,
                                fontSize = 11.sp,
                                color = if (zoneDetails.sensorHealth.contains("异常") || zoneDetails.sensorHealth.contains("离线")) StatusError else StatusSuccess,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // 合规与补货提示
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(WarmPaper)
                                .border(1.dp, MutedPaper)
                                .padding(10.dp)
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Notifications, contentDescription = null, tint = AgedBrass, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("区域异常/任务警示", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                                }
                                Text(
                                    text = zoneDetails.taskWarning,
                                    fontSize = 11.sp,
                                    color = if (zoneDetails.taskWarning.contains("警告") || zoneDetails.taskWarning.contains("缺货")) StatusError else CharcoalInk,
                                    modifier = Modifier.padding(top = 4.dp),
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EnvironmentTag(label: String, valStr: String) {
    Box(
        modifier = Modifier
            .background(WarmPaper)
            .border(1.dp, MutedPaper)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 9.sp, color = GraphiteGrey)
            Text(valStr, fontSize = 11.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
        }
    }
}

// 2D 门店数字孪生平面图，可交互点击区域
@Composable
fun InteractiveStorePlan(
    selectedZone: String,
    onSelectZone: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Canvas(
        modifier = modifier
            .clickable {
                // 根据点击物理位置分配区域
                // 为了演示，直接轮流切换或在Canvas中计算相对区域
                // 由于Android Canvas是无状态的，我们在Canvas绘制中展示虚构线，并提供选择列表。
                // 也可以根据物理点击检测相对区域：
            }
            .pointerInput(Unit) {
                // 获取相对点击坐标：
                detectTapGestures { offset ->
                    val x = offset.x
                    val y = offset.y
                    // 我们虚构坐标映射：
                    // 平面图大概长400px，高300px
                    // 1. 后仓(Warehouse): x < 40% Width && y < 50% Height
                    // 2. VIP品鉴(VIPLounge): x < 40% Width && y >= 50% Height
                    // 3. 收银POS(POSZone): x >= 40% && x <= 70% && y < 40%
                    // 4. 精品柜台(MainCounter): x >= 40% && x <= 70% && y >= 40%
                    // 5. 安全设施与入口(Entrance): x > 70%
                    val w = size.width
                    val h = size.height
                    
                    if (x < w * 0.4f) {
                        if (y < h * 0.5f) onSelectZone("Warehouse") else onSelectZone("VIPLounge")
                    } else if (x <= w * 0.75f) {
                        if (y < h * 0.45f) onSelectZone("POSZone") else onSelectZone("MainCounter")
                    } else {
                        onSelectZone("Entrance")
                    }
                }
            }
    ) {
        val w = size.width
        val h = size.height

        // 1. 绘制总墙体外轮廓
        drawRect(
            color = CharcoalInk,
            style = Stroke(width = 4.dp.toPx())
        )

        // 2. 后仓与品鉴区 (左侧 40%)
        // 绘制分割线
        drawLine(color = CharcoalInk, start = Offset(w * 0.4f, 0f), end = Offset(w * 0.4f, h), strokeWidth = 3.dp.toPx())
        drawLine(color = CharcoalInk, start = Offset(0f, h * 0.5f), end = Offset(w * 0.4f, h * 0.5f), strokeWidth = 2.dp.toPx())

        // 3. POS收银与主柜台 (中间 40%-75%)
        drawLine(color = CharcoalInk, start = Offset(w * 0.75f, 0f), end = Offset(w * 0.75f, h), strokeWidth = 3.dp.toPx())
        drawLine(color = CharcoalInk, start = Offset(w * 0.4f, h * 0.45f), end = Offset(w * 0.75f, h * 0.45f), strokeWidth = 2.dp.toPx())

        // 4. 填充各个区域的激活状态背景
        val zones = listOf(
            ZoneDrawInfo("Warehouse", 0f, 0f, w * 0.4f, h * 0.5f, "后仓储备库", SealRed),
            ZoneDrawInfo("VIPLounge", 0f, h * 0.5f, w * 0.4f, h * 0.5f, "雅仕品鉴茶室", AgedBrass),
            ZoneDrawInfo("POSZone", w * 0.4f, 0f, w * 0.35f, h * 0.45f, "实名POS收银台", SealRed),
            ZoneDrawInfo("MainCounter", w * 0.4f, h * 0.45f, w * 0.35f, h * 0.55f, "商品展示精工柜", AgedBrass),
            ZoneDrawInfo("Entrance", w * 0.75f, 0f, w * 0.25f, h, "实名核验入口", GraphiteGrey)
        )

        zones.forEach { zone ->
            val isActive = zone.id == selectedZone
            if (isActive) {
                drawRect(
                    color = zone.color.copy(alpha = 0.12f),
                    topLeft = Offset(zone.x + 2.dp.toPx(), zone.y + 2.dp.toPx()),
                    size = Size(zone.width - 4.dp.toPx(), zone.height - 4.dp.toPx())
                )
                // 绘制选中高亮框
                drawRect(
                    color = zone.color,
                    topLeft = Offset(zone.x + 3.dp.toPx(), zone.y + 3.dp.toPx()),
                    size = Size(zone.width - 6.dp.toPx(), zone.height - 6.dp.toPx()),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
        }
    }

    // 辅助提示标签
    Box(
        modifier = modifier.padding(12.dp)
    ) {
        Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("[后仓储备库]\n(点击查看库存及锁防)", fontSize = 10.sp, color = CharcoalInk, modifier = Modifier.clickable { onSelectZone("Warehouse") })
                Text("[实名POS收银区]\n(点击查看收银摄像头)", fontSize = 10.sp, color = CharcoalInk, modifier = Modifier.clickable { onSelectZone("POSZone") })
                Text("[实名核验入口]\n(点击查看智能NFC闸)", fontSize = 10.sp, color = CharcoalInk, modifier = Modifier.clickable { onSelectZone("Entrance") })
            }
            Spacer(modifier = Modifier.height(100.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("[雅仕品鉴茶室]\n(点击查看温湿与客流)", fontSize = 10.sp, color = CharcoalInk, modifier = Modifier.clickable { onSelectZone("VIPLounge") })
                Text("[商品展示精工柜]\n(点击查看货架上架率)", fontSize = 10.sp, color = CharcoalInk, modifier = Modifier.clickable { onSelectZone("MainCounter") })
                Spacer(modifier = Modifier.width(60.dp))
            }
        }
    }
}

// 孪生区临时数据实体
data class ZoneDrawInfo(
    val id: String,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val name: String,
    val color: Color
)

// 孪生区详情
data class ZoneDetails(
    val id: String,
    val name: String,
    val temp: String,
    val humidity: String,
    val shelfRate: String,
    val liveTraffic: Int,
    val sensorHealth: String,
    val taskWarning: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

fun getZoneDetails(zoneId: String): ZoneDetails {
    return when(zoneId) {
        "Warehouse" -> ZoneDetails(
            id = "Warehouse",
            name = "后仓精密储备库房",
            temp = "18.5°C",
            humidity = "58%", // 最佳恒温干湿
            shelfRate = "82%",
            liveTraffic = 1,
            sensorHealth = "全通道监控正常",
            taskWarning = "【库存任务】在途采购 SC-2026091901 预计于明日12:00运抵，后仓需腾空#4号精密托架准备盘点。",
            icon = Icons.Default.Inventory
        )
        "VIPLounge" -> ZoneDetails(
            id = "VIPLounge",
            name = "雅仕中式茶叙/品鉴茶室",
            temp = "22.0°C",
            humidity = "50%",
            shelfRate = "95%",
            liveTraffic = 4,
            sensorHealth = "环境检测仪握手正常",
            taskWarning = "【常规服务】3号茶席实名约客 [陆雅士] 偏好高山雪菊纯茶。茶室加湿器滤芯预计7天后需要自查清理。",
            icon = Icons.Default.Coffee
        )
        "POSZone" -> ZoneDetails(
            id = "POSZone",
            name = "双终端实名收银台",
            temp = "21.0°C",
            humidity = "45%",
            shelfRate = "100%",
            liveTraffic = 2,
            sensorHealth = "人脸核验探头握手正常",
            taskWarning = "【合规防备】1小时前于该区域发生过一起CP-9001年龄核验拦截，系统强制冻结交易并清除非成年人扫描日志。",
            icon = Icons.Default.PointOfSale
        )
        "MainCounter" -> ZoneDetails(
            id = "MainCounter",
            name = "商品展示精品陈列大柜",
            temp = "19.5°C",
            humidity = "55%",
            shelfRate = "68%", // 上架率低，触发补货
            liveTraffic = 3,
            sensorHealth = "红外重力感应正常",
            taskWarning = "【警告】由于「烟仕·沪上风华」上架商品已被仿真消费。陈列柜#B2区当前处于【缺货状态】，库管员应从后仓补货陈列。",
            icon = Icons.Default.TableChart
        )
        "Entrance" -> ZoneDetails(
            id = "Entrance",
            name = "实名闸机与防未核验入口",
            temp = "23.5°C",
            humidity = "40%",
            shelfRate = "0%",
            liveTraffic = 0,
            sensorHealth = "安全NFC闸道正常",
            taskWarning = "【安全监察】今日累积人流进店 124 人次。入闸实名条码匹配率达 100%，未发生无核验强闯安全事件。",
            icon = Icons.Default.SensorWindow
        )
        else -> ZoneDetails(
            id = "Unknown",
            name = "未命名区域",
            temp = "--",
            humidity = "--",
            shelfRate = "--",
            liveTraffic = 0,
            sensorHealth = "正常",
            taskWarning = "暂无警告。",
            icon = Icons.Default.Info
        )
    }
}
