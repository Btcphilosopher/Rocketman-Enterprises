package com.example.domain

import java.util.UUID

// 用户角色定义
enum class UserRole(val label: String, val canEditPrice: Boolean, val canEditCompliance: Boolean, val canExportData: Boolean) {
    ADMIN("系统管理员", true, true, true),
    REGIONAL_MANAGER("区域经理", true, false, true),
    STORE_MANAGER("门店经理", false, false, true),
    INVENTORY_CLERK("库存管理员", false, false, false),
    CASHIER("收银员", false, false, false),
    COMPLIANCE_AUDITOR("合规审核员", false, true, false),
    DATA_ANALYST("数据分析员", false, false, true),
    OBSERVER("只读观察员", false, false, false)
}

// 门市营业状态
enum class StoreStatus(val label: String) {
    OPEN("营业中"),
    CLOSED("已打烊"),
    MAINTENANCE("整顿中")
}

// 门市合规风险评级
enum class RiskLevel(val label: String) {
    INFO("信息"),
    LOW("低风险"),
    MEDIUM("中风险"),
    HIGH("高风险"),
    CRITICAL("严重警告")
}

// 门店数据模型
data class Store(
    val id: String,
    val name: String,
    val city: String,
    val businessDistrict: String,
    val area: Double, // 平方米
    val employeeCount: Int,
    val status: StoreStatus,
    val licenseNo: String, // 烟草专卖零售许可证号
    val licenseStatus: String, // "有效", "即将到期", "已过期"
    val todaySales: Double,
    val todayTransactions: Int,
    val currentTraffic: Int,
    val riskLevel: RiskLevel,
    val manager: String,
    val lastInspectionDate: String,
    val devicesStatus: String // "正常 (5/5)", "异常 (4/5)"
)

// 商品类别
enum class ProductCategory(val label: String) {
    SYNTHETIC_CIGARETTE("雅致合成卷烟"),
    SYNTHETIC_CIGAR("臻选合成雪茄"),
    SYNTHETIC_PIPE_TOBACCO("古典合成烟丝"),
    TOBACCO_ACCESSORIES("精工烟具"),
    STORAGE_BOX("尊享收纳器皿"),
    GIFT_BOX("高端礼盒包装"),
    NON_TOBACCO_RETAIL("合规店内配套")
}

// 商品状态
enum class ProductStatus(val label: String) {
    ON_SALE("在售"),
    OFF_SHELF("下架"),
    SUSPENDED("暂停销售")
}

// 商品数据模型
data class Product(
    val id: String,
    val name: String,
    val engName: String,
    val category: ProductCategory,
    val brand: String, // 虚构品牌
    val specification: String, // e.g. "20支/盒", "1支/尊"
    val supplier: String,
    val referencePrice: Double, // 单价
    val totalStock: Int,
    val isSaleable: Boolean,
    val complianceTags: List<String>, // e.g. "仅限成年人", "含焦油10mg", "禁止跨区销售"
    val imagePlaceholderText: String, // 生成图案占位符
    val description: String,
    val createDate: String,
    val updateDate: String,
    val status: ProductStatus,
    val regionLimits: String, // "无限制", "限上海市销售", etc.
    val isAgeRestricted: Boolean = true
)

// 年龄验证状态
enum class AgeVerificationStatus(val label: String) {
    UNVERIFIED("未验证"),
    VERIFICATION_REQUIRED("需验证"),
    VERIFICATION_IN_PROGRESS("验证中"),
    VERIFIED("验证通过"),
    VERIFICATION_FAILED("验证不通过"),
    MANUAL_REVIEW("需人工审核"),
    EXPIRED("验证过期"),
    BLOCKED("已屏蔽交易")
}

// 成年会员数据模型
data class Member(
    val id: String,
    val name: String,
    val phoneMasked: String, // 虚构脱敏手机号
    val ageVerificationStatus: AgeVerificationStatus,
    val verifiedAge: Int?,
    val registrationDate: String,
    val level: String, // "白金级", "黄金级", "雅仕级"
    val commonStoreId: String,
    val preferences: String,
    val isDataSharingConsent: Boolean,
    val auditTrail: List<String>
)

// 库存状态
enum class InventoryStatus(val label: String) {
    IN_STOCK("库存充裕"),
    LOW_STOCK("库存预警"),
    OUT_OF_STOCK("缺货"),
    RESERVED("锁定占位"),
    IN_TRANSIT("运输中"),
    QUARANTINED("合规封存"),
    EXPIRED("过期报损"),
    AUDIT_REQUIRED("盘点待核")
}

// 库存流水记录
data class InventoryLedger(
    val id: String,
    val timestamp: String,
    val storeId: String,
    val storeName: String,
    val productId: String,
    val productName: String,
    val type: String, // "入库", "出库", "调拨", "损耗", "盘点"
    val quantityChange: Int,
    val beforeQty: Int,
    val afterQty: Int,
    val operator: String,
    val notes: String
)

// 供应链运输状态
enum class TransitStatus(val label: String) {
    ORDERED("已下单"),
    CONFIRMED("已确认"),
    PACKED("已打包"),
    DISPATCHED("已出库"),
    IN_TRANSIT("运输中"),
    ARRIVING("即将送达"),
    DELIVERED("已签收"),
    DELAYED("物流延误"),
    CANCELLED("已取消")
}

// 供应链订单数据模型
data class SupplyChainOrder(
    val id: String,
    val creationTime: String,
    val supplier: String,
    val destinationStoreId: String,
    val destinationStoreName: String,
    val itemsCount: Int,
    val totalAmount: Double,
    val status: TransitStatus,
    val carrier: String,
    val eta: String,
    val routeDesc: String,
    val isDelayedAlert: Boolean = false
)

// 交易订单状态
enum class TransactionStatus(val label: String) {
    DRAFT("草稿交易"),
    AGE_CHECK_REQUIRED("待年龄验证"),
    COMPLIANCE_REVIEW("待合规审核"),
    READY_FOR_SIMULATION("准备支付"),
    PAYMENT_SIMULATED("已模拟付款"),
    COMPLETED_DEMO("交易完成 (演示)"),
    CANCELLED("已取消"),
    BLOCKED("合规拦截")
}

// 购物车商品
data class CartItem(
    val product: Product,
    var quantity: Int
)

// 模拟POS交易单
data class PosTransaction(
    val id: String,
    val timestamp: String,
    val storeId: String,
    val cashierName: String,
    val items: List<CartItem>,
    val totalAmount: Double,
    val status: TransactionStatus,
    val ageVerificationMethod: String, // "模拟身份证NFC", "扫码核验", "人工目测"
    val complianceFlags: List<String>,
    val demoReceiptPrinted: Boolean = false,
    val auditId: String
)

// 合规风险事件类型
enum class ComplianceEventType(val label: String) {
    AGE_CHECK_FAILED("年龄核验不通过"),
    REPEATED_ATTEMPTS("频繁重复验证"),
    STOCK_ANOMALY("库存账实不一"),
    OVER_LIMIT_SALE("大额限制性交易"),
    LICENSE_EXPIRING("许可证即将到期"),
    REGION_VIOLATION("疑似跨区串货"),
    FREQUENT_CANCEL("频繁取消收银"),
    PRIVILEGE_ABUSE("操作员越权尝试"),
    DEVICE_FAULT("监控设备离线")
}

// 合规事件数据模型
data class ComplianceEvent(
    val id: String,
    val timestamp: String,
    val storeId: String,
    val storeName: String,
    val type: ComplianceEventType,
    val riskLevel: RiskLevel,
    val status: String, // "待处理", "处理中", "已合规归档", "误报取消"
    val details: String,
    val operatorRole: String,
    val notes: String,
    val auditTrail: List<String>
)

// 全局审计日志模型
data class AuditLog(
    val id: String,
    val timestamp: String,
    val operator: String,
    val role: UserRole,
    val action: String,
    val pageAffected: String,
    val status: String, // "成功", "警告", "拦截"
    val details: String
)

// 系统预置通知
data class Notification(
    val id: String,
    val timestamp: String,
    val title: String,
    val content: String,
    val category: String, // "合规", "库存", "物流", "系统"
    val isRead: Boolean = false,
    val priority: RiskLevel
)
