package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.domain.Product
import com.example.domain.ProductCategory
import com.example.domain.ProductStatus
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun CatalogScreen() {
    val state by SimulationEngine.state.collectAsState()
    
    // 筛选与过滤状态
    var searchKeyword by remember { mutableStateOf("") }
    var selectedCat by remember { mutableStateOf<ProductCategory?>(null) }
    var isGridView by remember { mutableStateOf(true) }
    var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }

    val filteredProducts = state.products.filter { p ->
        (searchKeyword.isEmpty() || p.name.contains(searchKeyword) || p.id.contains(searchKeyword) || p.brand.contains(searchKeyword)) &&
        (selectedCat == null || p.category == selectedCat)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // 顶端操作与筛选
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "高端商品目录 (合成数据)",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalInk
            )
            
            // 视图切换
            Row(
                modifier = Modifier
                    .border(1.dp, CharcoalInk)
                    .background(OffWhite)
            ) {
                IconButton(
                    onClick = { isGridView = true },
                    modifier = Modifier.background(if (isGridView) CharcoalInk else Color.Transparent)
                ) {
                    Icon(Icons.Default.GridView, contentDescription = null, tint = if (isGridView) WarmPaper else CharcoalInk)
                }
                IconButton(
                    onClick = { isGridView = false },
                    modifier = Modifier.background(if (!isGridView) CharcoalInk else Color.Transparent)
                ) {
                    Icon(Icons.Default.List, contentDescription = null, tint = if (!isGridView) WarmPaper else CharcoalInk)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 筛选栏
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // 搜索框
            OutlinedTextField(
                value = searchKeyword,
                onValueChange = { searchKeyword = it },
                placeholder = { Text("搜索商品、编号、品牌...", fontSize = 12.sp, color = GraphiteGrey) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                modifier = Modifier
                    .weight(1.5f)
                    .height(48.dp),
                shape = RoundedCornerShape(2.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SealRed,
                    unfocusedBorderColor = CharcoalInk,
                    focusedContainerColor = OffWhite,
                    unfocusedContainerColor = OffWhite
                ),
                singleLine = true
            )

            // 类别选择
            var catExpanded by remember { mutableStateOf(false) }
            Box(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { catExpanded = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk),
                    border = BorderStroke(1.dp, CharcoalInk)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(selectedCat?.label ?: "全部分类", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("▼", fontSize = 8.sp, color = GraphiteGrey)
                    }
                }
                DropdownMenu(
                    expanded = catExpanded,
                    onDismissRequest = { catExpanded = false },
                    modifier = Modifier.background(OffWhite)
                ) {
                    DropdownMenuItem(
                        text = { Text("全部分类", color = CharcoalInk) },
                        onClick = {
                            selectedCat = null
                            catExpanded = false
                        }
                    )
                    ProductCategory.values().forEach { cat ->
                        DropdownMenuItem(
                            text = { Text(cat.label, color = CharcoalInk) },
                            onClick = {
                                selectedCat = cat
                                catExpanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 商品主呈现区
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MutedPaper)
                    .background(OffWhite),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Inbox, contentDescription = null, tint = GraphiteGrey, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("无匹配的高端合成商品", color = GraphiteGrey, fontSize = 14.sp)
                }
            }
        } else {
            Box(modifier = Modifier.weight(1f)) {
                if (isGridView) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 200.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredProducts) { product ->
                            ProductGridItem(product = product, onClick = { selectedProductForDetail = product })
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .border(1.dp, MutedPaper)
                    ) {
                        // 表头
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(CharcoalInk)
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("商品编号", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            Text("商品名称 / 规格", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(2f), fontWeight = FontWeight.Bold)
                            Text("类别", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                            Text("当前存量", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                            Text("参考单价", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.End)
                        }

                        // 表体
                        filteredProducts.forEachIndexed { index, product ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (index % 2 == 0) OffWhite else WarmPaper)
                                    .clickable { selectedProductForDetail = product }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(product.id, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1f))
                                Column(modifier = Modifier.weight(2f)) {
                                    Text(product.name, color = CharcoalInk, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(product.specification, color = GraphiteGrey, fontSize = 10.sp)
                                }
                                Text(product.category.label, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.5f))
                                Text(
                                    text = "${product.totalStock} 件",
                                    color = if (product.totalStock == 0) StatusError else if (product.totalStock < 50) StatusAlert else StatusSuccess,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "¥${String.format("%.2f", product.referencePrice)}",
                                    color = SealRed,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.End
                                )
                            }
                        }
                    }
                }
            }
        }

        // 商品详情抽屉 Drawer Modal
        selectedProductForDetail?.let { product ->
            CatalogDetailsModal(
                product = product,
                onDismiss = { selectedProductForDetail = null }
            )
        }
    }
}

@Composable
fun ProductGridItem(product: Product, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MutedPaper, RoundedCornerShape(2.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = OffWhite),
        shape = RoundedCornerShape(2.dp)
    ) {
        Column {
            // 商品仿真图层 (Canvas)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(CharcoalInk)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                ProductVisualCanvas(
                    placeholderText = product.imagePlaceholderText,
                    modifier = Modifier.fillMaxSize()
                )
                // 年龄限制徽章
                if (product.isAgeRestricted) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .background(StatusError, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("18禁", color = WarmPaper, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(text = product.brand, color = AgedBrass, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = product.name,
                    color = CharcoalInk,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 2.dp)
                )
                Text(text = product.specification, color = GraphiteGrey, fontSize = 10.sp)
                
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "¥${String.format("%.2f", product.referencePrice)}",
                        color = SealRed,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (product.totalStock == 0) "已缺货" else "库存 ${product.totalStock}",
                        color = if (product.totalStock == 0) StatusError else GraphiteGrey,
                        fontSize = 10.sp,
                        fontWeight = if (product.totalStock == 0) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

// 模拟中国高档包装的 Canvas 艺术绘图
@Composable
fun ProductVisualCanvas(placeholderText: String, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // 1. 底框渐变及质感
        drawRect(
            color = if (placeholderText.contains("暗红")) SealRed.copy(alpha = 0.9f)
                    else if (placeholderText.contains("绿")) StatusSuccess.copy(alpha = 0.85f)
                    else if (placeholderText.contains("银")) GraphiteGrey
                    else AgedBrass.copy(alpha = 0.9f)
        )

        // 2. 绘制金线/双环等古典几何纹路
        drawRect(
            color = AgedBrass,
            topLeft = Offset(4.dp.toPx(), 4.dp.toPx()),
            size = size.copy(width = w - 8.dp.toPx(), height = h - 8.dp.toPx()),
            style = Stroke(width = 1.dp.toPx())
        )

        // 3. 绘制圆形东方抽象纹饰
        drawCircle(
            color = WarmPaper.copy(alpha = 0.15f),
            radius = (h / 3),
            center = Offset(w/2, h/2)
        )

        // 4. 水平或垂直金饰
        drawLine(
            color = AgedBrass,
            start = Offset(4.dp.toPx(), h/2),
            end = Offset(w - 4.dp.toPx(), h/2),
            strokeWidth = 0.5.dp.toPx()
        )
    }
}

// 自定义商品详情模态窗口 CatalogDetailsModal
@Composable
fun CatalogDetailsModal(product: Product, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = { onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .widthIn(max = 600.dp)
            .fillMaxWidth()
            .border(1.dp, CharcoalInk)
            .background(WarmPaper),
        confirmButton = {
            Button(
                onClick = { onDismiss() },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
            ) {
                Text("关闭参数详情")
            }
        },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ShoppingBag, contentDescription = null, tint = SealRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text(product.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    // 左半部分：包装仿真
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .background(CharcoalInk)
                            .border(1.dp, AgedBrass),
                        contentAlignment = Alignment.Center
                    ) {
                        ProductVisualCanvas(placeholderText = product.imagePlaceholderText, modifier = Modifier.fillMaxSize())
                    }

                    // 右半部分：商品编号和核心数据
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "商品编号: ${product.id}", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                        Text(text = "英文别名: ${product.engName}", fontSize = 11.sp, color = GraphiteGrey)
                        Text(text = "核心品牌: ${product.brand}", fontSize = 12.sp, color = SealRed, fontWeight = FontWeight.Bold)
                        Text(text = "包装规格: ${product.specification}", fontSize = 12.sp, color = CharcoalInk)
                        Text(text = "专属供应商: ${product.supplier}", fontSize = 11.sp, color = CharcoalInk)
                        Text(text = "限制售卖区域: ${product.regionLimits}", fontSize = 11.sp, color = StatusAlert, fontWeight = FontWeight.Bold)
                    }
                }

                Divider(color = CharcoalInk, modifier = Modifier.padding(vertical = 12.dp))

                // 商品描述
                Text(text = "商品学术说明（演示用途，不具有真实促吸性质）：", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                Text(
                    text = product.description,
                    fontSize = 11.sp,
                    color = CharcoalInk,
                    lineHeight = 16.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 年龄警告面板
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StatusError.copy(alpha = 0.08f))
                        .border(1.dp, StatusError.copy(alpha = 0.3f))
                        .padding(10.dp)
                ) {
                    Column {
                        Text("合规标签及风险提示 (COMPLIANCE WARNINGS)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusError)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            product.complianceTags.forEach { tag ->
                                Box(
                                    modifier = Modifier
                                        .background(StatusError.copy(alpha = 0.15f))
                                        .border(0.5.dp, StatusError)
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(tag, fontSize = 9.sp, color = StatusError, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 仿真一维条形码，极富企业级软件真实质感！
                Text(text = "模拟收银台条形码 (POS BARCODE SIMULATION)", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                BarcodeCanvas(
                    barcodeText = product.id,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(45.dp)
                )
            }
        }
    )
}

// 模拟 1D Barcode 绘制 Canvas
@Composable
fun BarcodeCanvas(barcodeText: String, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // 绘制白背景
        drawRect(color = White)

        // 绘制条码的黑竖线 (粗细相间)
        val lineCount = 45
        val lineGap = w / lineCount
        val randomForSeed = barcodeText.hashCode()
        val randomObj = java.util.Random(randomForSeed.toLong())

        for (i in 3 until lineCount - 3) {
            val thickness = if (randomObj.nextBoolean()) 3.dp.toPx() else 1.dp.toPx()
            val startX = i * lineGap
            drawLine(
                color = Black,
                start = Offset(startX, 4.dp.toPx()),
                end = Offset(startX, h - 14.dp.toPx()),
                strokeWidth = thickness
            )
        }
    }
}
