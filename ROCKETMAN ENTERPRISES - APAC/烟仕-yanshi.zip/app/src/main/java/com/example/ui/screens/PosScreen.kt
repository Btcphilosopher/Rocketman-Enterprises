package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.example.domain.AgeVerificationStatus
import com.example.domain.Product
import com.example.domain.TransactionStatus
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun PosScreen() {
    val state by SimulationEngine.state.collectAsState()
    
    // POS 本地输入状态
    var searchKey by remember { mutableStateOf("") }
    var dobYear by remember { mutableStateOf("1995") }
    var dobMonth by remember { mutableStateOf("05") }
    var dobDay by remember { mutableStateOf("12") }
    var activeDemoMode by remember { mutableStateOf("SUCCESS") } // "SUCCESS", "FAIL", "MANUAL"

    val posProducts = state.products.filter { p ->
        searchKey.isEmpty() || p.name.contains(searchKey) || p.id.contains(searchKey)
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Pane (60%): 商品选取与条形码输入
        Column(
            modifier = Modifier
                .weight(1.5f)
                .fillMaxHeight()
        ) {
            Text(
                text = "仿真收银商品池 (点击快速扫码)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalInk
            )
            
            Spacer(modifier = Modifier.height(8.dp))

            // 快捷条码输入框
            OutlinedTextField(
                value = searchKey,
                onValueChange = { searchKey = it },
                placeholder = { Text("扫描虚拟条码/键盘搜索...", fontSize = 11.sp, color = GraphiteGrey) },
                leadingIcon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = SealRed) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(2.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SealRed,
                    unfocusedBorderColor = CharcoalInk,
                    focusedContainerColor = OffWhite,
                    unfocusedContainerColor = OffWhite
                ),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 快速点选格
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MutedPaper)
                    .background(OffWhite)
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    posProducts.forEach { prod ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .border(1.dp, MutedPaper)
                                .background(WarmPaper)
                                .clickable { SimulationEngine.addCartProduct(prod) }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(prod.brand, color = AgedBrass, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(prod.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                                Text("条码: ${prod.id} | 库存: ${prod.totalStock} 件", fontSize = 10.sp, color = GraphiteGrey)
                            }
                            
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "¥${String.format("%.2f", prod.referencePrice)}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SealRed
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Icon(Icons.Default.AddShoppingCart, contentDescription = null, tint = CharcoalInk, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
        }

        // Right Pane (40%): 购物车、年龄核验与模拟支付
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .border(
                    BorderStroke(
                        if (state.posTransactionStatus == TransactionStatus.BLOCKED) 2.dp else 1.dp,
                        if (state.posTransactionStatus == TransactionStatus.BLOCKED) StatusError else CharcoalInk
                    )
                )
                .background(OffWhite)
                .padding(14.dp)
        ) {
            Text(
                text = "活跃交易篮 (${state.posCart.sumOf { it.quantity }}件)",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalInk
            )

            Spacer(modifier = Modifier.height(8.dp))

            // 购物篮明细
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, MutedPaper)
                    .background(WarmPaper)
                    .padding(6.dp)
            ) {
                if (state.posCart.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("收银篮空置，请在左侧扫码添加", fontSize = 11.sp, color = GraphiteGrey)
                    }
                } else {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        state.posCart.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(OffWhite)
                                    .padding(6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.product.name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                                    Text("单价: ¥${item.product.referencePrice}", fontSize = 10.sp, color = GraphiteGrey)
                                }
                                
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { SimulationEngine.updateCartQuantity(item.product, item.quantity - 1) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Text("-", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                                    }
                                    Text("${item.quantity}", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
                                    IconButton(
                                        onClick = { SimulationEngine.updateCartQuantity(item.product, item.quantity + 1) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Text("+", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                                    }
                                    
                                    Spacer(modifier = Modifier.width(12.dp))
                                    
                                    Text(
                                        text = "¥${String.format("%.2f", item.product.referencePrice * item.quantity)}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SealRed
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 合计
            val totalAmount = state.posCart.sumOf { it.product.referencePrice * it.quantity }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("合计总金额:", fontSize = 13.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                Text("¥${String.format("%,.2f", totalAmount)}", fontSize = 18.sp, color = SealRed, fontWeight = FontWeight.Bold)
            }

            Divider(color = CharcoalInk, modifier = Modifier.padding(vertical = 10.dp))

            // 关键：年龄核验强制交互
            val needsAgeCheck = state.posCart.any { it.product.isAgeRestricted }
            if (needsAgeCheck && state.posCart.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (state.posAgeVerificationStatus == AgeVerificationStatus.VERIFIED) StatusSuccess.copy(alpha = 0.08f)
                            else if (state.posAgeVerificationStatus == AgeVerificationStatus.VERIFICATION_FAILED) StatusError.copy(alpha = 0.08f)
                            else AgedBrass.copy(alpha = 0.08f)
                        )
                        .border(
                            1.dp,
                            if (state.posAgeVerificationStatus == AgeVerificationStatus.VERIFIED) StatusSuccess
                            else if (state.posAgeVerificationStatus == AgeVerificationStatus.VERIFICATION_FAILED) StatusError
                            else AgedBrass
                        )
                        .padding(10.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = SealRed, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "防未成年人合规核验 (双介质检查)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalInk
                            )
                        }
                        
                        Text(
                            text = "篮内包含专营受限商品，必须读取身份证或实名健康核码。",
                            fontSize = 10.sp,
                            color = GraphiteGrey,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )

                        // 身份证输入及结果演示器
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 年
                            OutlinedTextField(
                                value = dobYear,
                                onValueChange = { dobYear = it },
                                label = { Text("年", fontSize = 8.sp) },
                                modifier = Modifier.weight(1.2f).height(42.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 10.sp),
                                singleLine = true
                            )
                            // 月
                            OutlinedTextField(
                                value = dobMonth,
                                onValueChange = { dobMonth = it },
                                label = { Text("月", fontSize = 8.sp) },
                                modifier = Modifier.weight(0.9f).height(42.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 10.sp),
                                singleLine = true
                            )
                            // 日
                            OutlinedTextField(
                                value = dobDay,
                                onValueChange = { dobDay = it },
                                label = { Text("日", fontSize = 8.sp) },
                                modifier = Modifier.weight(0.9f).height(42.dp),
                                textStyle = LocalTextStyle.current.copy(fontSize = 10.sp),
                                singleLine = true
                            )
                            
                            // 演示模式
                            var modeExpanded by remember { mutableStateOf(false) }
                            Box(modifier = Modifier.weight(1.5f)) {
                                OutlinedButton(
                                    onClick = { modeExpanded = true },
                                    modifier = Modifier.fillMaxWidth().height(42.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text(if (activeDemoMode == "SUCCESS") "通过(>=18)" else if (activeDemoMode == "FAIL") "不通过(<18)" else "人工挂起", fontSize = 9.sp)
                                }
                                DropdownMenu(expanded = modeExpanded, onDismissRequest = { modeExpanded = false }) {
                                    DropdownMenuItem(text = { Text("模拟验证成功 (>=18岁)") }, onClick = { activeDemoMode = "SUCCESS"; modeExpanded = false })
                                    DropdownMenuItem(text = { Text("模拟验证失败 (拦截未成年人)") }, onClick = { activeDemoMode = "FAIL"; modeExpanded = false })
                                    DropdownMenuItem(text = { Text("模拟需人工核签审核") }, onClick = { activeDemoMode = "MANUAL"; modeExpanded = false })
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // 发起核验按钮
                        Button(
                            onClick = {
                                val y = dobYear.toIntOrNull() ?: 1995
                                val m = dobMonth.toIntOrNull() ?: 5
                                val d = dobDay.toIntOrNull() ?: 12
                                SimulationEngine.submitPOSAgeCheck(y, m, d, activeDemoMode)
                            },
                            modifier = Modifier.fillMaxWidth().height(36.dp),
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SealRed, contentColor = WarmPaper)
                        ) {
                            Text("刷取实名硬件介质核验", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // 显示验证状态
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("验证结果:", fontSize = 10.sp, color = GraphiteGrey)
                            Text(
                                text = state.posAgeVerificationStatus.label + (state.posVerifiedAge?.let { " (${it}岁)" } ?: ""),
                                color = when(state.posAgeVerificationStatus) {
                                    AgeVerificationStatus.VERIFIED -> StatusSuccess
                                    AgeVerificationStatus.VERIFICATION_FAILED -> StatusError
                                    AgeVerificationStatus.MANUAL_REVIEW -> StatusAlert
                                    else -> GraphiteGrey
                                },
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            } else if (state.posCart.isNotEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(StatusSuccess.copy(alpha = 0.05f))
                        .border(1.dp, StatusSuccess)
                        .padding(8.dp)
                ) {
                    Text("本单商品全非易感商品，不触发年龄合规限制，可自由支付。", color = StatusSuccess, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 支付与取消控制区
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { SimulationEngine.clearCart() },
                    shape = RoundedCornerShape(2.dp),
                    border = BorderStroke(1.dp, CharcoalInk),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk),
                    modifier = Modifier.weight(1f).height(46.dp)
                ) {
                    Text("重置清空", fontSize = 12.sp)
                }

                Button(
                    onClick = { SimulationEngine.confirmPOSPayment() },
                    enabled = state.posCart.isNotEmpty() && state.posTransactionStatus == TransactionStatus.READY_FOR_SIMULATION,
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CharcoalInk,
                        contentColor = WarmPaper,
                        disabledContainerColor = MutedPaper,
                        disabledContentColor = GraphiteGrey
                    ),
                    modifier = Modifier.weight(1.5f).height(46.dp)
                ) {
                    Text("模拟完成付款 ¥${String.format("%.2f", totalAmount)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    // 支付完成后，展示传统的古典小票打印单 CatalogDetailsModal
    state.posActiveTransaction?.let { tx ->
        PosDemoInvoiceDialog(
            transaction = tx,
            onDismiss = { SimulationEngine.clearCart() }
        )
    }
}

// 古典传统中式小票模拟弹窗组件 PosDemoInvoiceDialog
@Composable
fun PosDemoInvoiceDialog(transaction: com.example.domain.PosTransaction, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = { onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .border(1.dp, CharcoalInk)
            .background(WarmPaper),
        confirmButton = {
            Button(
                onClick = { onDismiss() },
                shape = RoundedCornerShape(2.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
            ) {
                Text("关闭收银凭证")
            }
        },
        title = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Text("烟 仕 YANSHI", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CharcoalInk, fontFamily = FontFamily.Serif, letterSpacing = 2.sp)
                Text("专营商品零售缴费电子凭证", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Light)
                Text("DEMO RECEIPT · 不具有真实财务效力", fontSize = 9.sp, color = SealRed, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Divider(color = CharcoalInk, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))
                
                // 细节
                Text("发票流水单号: ${transaction.id}", fontSize = 10.sp, color = CharcoalInk)
                Text("交易记录时间: ${transaction.timestamp}", fontSize = 10.sp, color = CharcoalInk)
                Text("收银员签名: ${transaction.cashierName}", fontSize = 10.sp, color = CharcoalInk)
                Text("核验介质方式: ${transaction.ageVerificationMethod}", fontSize = 10.sp, color = CharcoalInk)
                
                Divider(color = CharcoalInk, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                // 商品账单列表
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("购买项及数量", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CharcoalInk, modifier = Modifier.weight(2f))
                    Text("单价", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CharcoalInk, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                    Text("折后总额", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CharcoalInk, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                }
                
                transaction.items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(2f)) {
                            Text(item.product.name, fontSize = 11.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                            Text("规格: ${item.product.specification} x ${item.quantity}", fontSize = 9.sp, color = GraphiteGrey)
                        }
                        Text("¥${item.product.referencePrice}", fontSize = 10.sp, color = CharcoalInk, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                        Text("¥${String.format("%.2f", item.product.referencePrice * item.quantity)}", fontSize = 11.sp, color = SealRed, modifier = Modifier.weight(1f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                    }
                }

                Divider(color = CharcoalInk, thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

                // 统计
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("含税总额", fontSize = 11.sp, color = CharcoalInk)
                    Text("¥${String.format("%.2f", transaction.totalAmount)}", fontSize = 11.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("专管虚拟代扣消费税 (56%)", fontSize = 10.sp, color = GraphiteGrey)
                    Text("¥${String.format("%.2f", transaction.totalAmount * 0.56)}", fontSize = 10.sp, color = GraphiteGrey)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("平台实付金额 (演示)", fontSize = 12.sp, color = SealRed, fontWeight = FontWeight.Bold)
                    Text("¥0.00", fontSize = 13.sp, color = SealRed, fontWeight = FontWeight.Bold, textDecoration = TextDecoration.LineThrough)
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 合规备注
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .border(1.dp, MutedPaper)
                        .padding(8.dp)
                ) {
                    Column {
                        Text("专管印花备档：", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                        transaction.complianceFlags.forEach { flag ->
                            Text("· $flag", fontSize = 9.sp, color = GraphiteGrey)
                        }
                    }
                }
            }
        }
    )
}
