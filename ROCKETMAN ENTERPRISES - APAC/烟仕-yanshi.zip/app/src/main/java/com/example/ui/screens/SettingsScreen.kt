package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Screen
import com.example.domain.Store
import com.example.domain.UserRole
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun SettingsScreen() {
    val state by SimulationEngine.state.collectAsState()
    val scrollState = rememberScrollState()

    var activeRole by remember { mutableStateOf(state.currentRole) }
    var activeStore by remember { mutableStateOf(state.currentStore) }
    
    // 通知偏好本地模拟
    var soundEnabled by remember { mutableStateOf(true) }
    var highRiskAlertEnabled by remember { mutableStateOf(true) }
    var autoBackupInterval by remember { mutableStateOf("1小时") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "系统集成配置与链上审计日志",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = CharcoalInk
        )
        Text(
            text = "演示系统后台控制面板 · 企业级安全审计",
            fontSize = 11.sp,
            color = SealRed,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 第一区：动态身份与环境快捷切换 (RBAC)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
            colors = CardDefaults.cardColors(containerColor = OffWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("沙盒操作环境动态配置 (RBAC & Environment Swapping)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // 角色切换
                    Column(modifier = Modifier.weight(1f)) {
                        Text("当前模拟身份:", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                        var roleExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            OutlinedButton(
                                onClick = { roleExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
                            ) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(activeRole.label, fontSize = 11.sp)
                                    Text("▼", fontSize = 9.sp)
                                }
                            }
                            DropdownMenu(expanded = roleExpanded, onDismissRequest = { roleExpanded = false }) {
                                UserRole.values().forEach { role ->
                                    DropdownMenuItem(
                                        text = { Text(role.label) },
                                        onClick = {
                                            activeRole = role
                                            SimulationEngine.changeUserRole(role)
                                            roleExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // 门店切换
                    Column(modifier = Modifier.weight(1f)) {
                        Text("当前宿主专营门店:", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                        var storeExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            OutlinedButton(
                                onClick = { storeExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
                            ) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(activeStore.name, fontSize = 11.sp)
                                    Text("▼", fontSize = 9.sp)
                                }
                            }
                            DropdownMenu(expanded = storeExpanded, onDismissRequest = { storeExpanded = false }) {
                                state.stores.forEach { st ->
                                    DropdownMenuItem(
                                        text = { Text(st.name) },
                                        onClick = {
                                            activeStore = st
                                            SimulationEngine.changeCurrentStore(st)
                                            storeExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = { SimulationEngine.setScreen(Screen.Login) },
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SealRed, contentColor = WarmPaper)
                ) {
                    Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("退出平台 · 返回初始化登入面", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 第二区：通知及辅助备忘偏好设置
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
            colors = CardDefaults.cardColors(containerColor = OffWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("沙盒运行机制及通知偏好", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("合规拦截声音提示", fontSize = 12.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                        Text("拦截未成年人或敏感交易时强制扬声器高分贝警告音", fontSize = 10.sp, color = GraphiteGrey)
                    }
                    Switch(checked = soundEnabled, onCheckedChange = { soundEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = SealRed, checkedTrackColor = SealRed.copy(alpha = 0.4f)))
                }

                Divider(color = CharcoalInk.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("高风险合规事件短信即时拦截", fontSize = 12.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                        Text("一旦核查不符，自动触发短信网关向直管审计员手机告警", fontSize = 10.sp, color = GraphiteGrey)
                    }
                    Switch(checked = highRiskAlertEnabled, onCheckedChange = { highRiskAlertEnabled = it }, colors = SwitchDefaults.colors(checkedThumbColor = SealRed, checkedTrackColor = SealRed.copy(alpha = 0.4f)))
                }

                Divider(color = CharcoalInk.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("冷链温湿自动备份频率", fontSize = 12.sp, color = CharcoalInk, fontWeight = FontWeight.Bold)
                        Text("在途直配车辆温控数据自主同步到上海烟草云盘间隔时间", fontSize = 10.sp, color = GraphiteGrey)
                    }
                    var intervalExpanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { intervalExpanded = true }, shape = RoundedCornerShape(2.dp)) {
                            Text(autoBackupInterval, fontSize = 11.sp, color = CharcoalInk)
                        }
                        DropdownMenu(expanded = intervalExpanded, onDismissRequest = { intervalExpanded = false }) {
                            listOf("15分钟", "30分钟", "1小时", "4小时").forEach { t ->
                                DropdownMenuItem(text = { Text(t) }, onClick = { autoBackupInterval = t; intervalExpanded = false })
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 第三区：全局链上系统审计日志 (System Audit Logs Ledger)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
            colors = CardDefaults.cardColors(containerColor = OffWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("安全审计流水日志簿 (${state.auditLogs.size} 条)", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                    Box(
                        modifier = Modifier
                            .background(StatusSuccess.copy(alpha = 0.1f))
                            .border(1.dp, StatusSuccess)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("链式校验正常", color = StatusSuccess, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
                
                Spacer(modifier = Modifier.height(12.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .border(1.dp, MutedPaper)
                        .background(WarmPaper)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (state.auditLogs.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("暂无审计日志", fontSize = 11.sp, color = GraphiteGrey)
                        }
                    } else {
                        state.auditLogs.asReversed().forEach { log ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp)
                                    .border(1.dp, MutedPaper)
                                    .background(OffWhite)
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "【审计日志】${log.action}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SealRed)
                                    Text(text = log.timestamp, fontSize = 9.sp, color = GraphiteGrey, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = log.details, fontSize = 10.sp, color = CharcoalInk, lineHeight = 14.sp)
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(text = "经手操作者: ${log.operator}", fontSize = 9.sp, color = GraphiteGrey)
                                    Text(text = "受影响舱室: ${log.pageAffected}", fontSize = 9.sp, color = GraphiteGrey)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
