package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ProductCategory
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun AnalyticsScreen() {
    val state by SimulationEngine.state.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // 头部
        Text(
            text = "专营决策支撑 · 商业智能分析舱",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = CharcoalInk
        )
        Text(
            text = "基于安全合成数据仿真 · 100% 离线沙盒测算",
            fontSize = 11.sp,
            color = SealRed,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // 第一排：大盘核心销售分类占比 + 24小时客流分布热力
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 左半：分类销售占比 (Progress Stack)
            Card(
                modifier = Modifier
                    .weight(1f)
                    .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "分类销售额占比测算",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalInk
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // 仿真销售额比例：烟草55%，雪茄30%，包装辅料15%
                    val catShares = listOf(
                        CategoryShare(ProductCategory.SYNTHETIC_CIGARETTE.label, 0.55f, SealRed),
                        CategoryShare(ProductCategory.SYNTHETIC_CIGAR.label, 0.30f, AgedBrass),
                        CategoryShare(ProductCategory.TOBACCO_ACCESSORIES.label, 0.15f, CharcoalInk)
                    )

                    // 绘制水平堆叠色条
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(24.dp)
                            .background(MutedPaper)
                    ) {
                        Row(modifier = Modifier.fillMaxSize()) {
                            catShares.forEach { share ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .weight(share.fraction)
                                        .background(share.color)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 标注
                    catShares.forEach { share ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(10.dp).background(share.color))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(share.name, fontSize = 11.sp, color = CharcoalInk)
                            }
                            Text(
                                text = "${String.format("%.0f", share.fraction * 100)}%",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalInk
                            )
                        }
                    }
                }
            }

            // 右半：24小时进店客流热力热度
            Card(
                modifier = Modifier
                    .weight(1.2f)
                    .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                colors = CardDefaults.cardColors(containerColor = OffWhite),
                shape = RoundedCornerShape(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "营业高峰时段流量热力模型",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalInk
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // 绘制时段分布图 (24h)
                    HourlyTrafficHeatGrid()
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 第二排：趋势大图 (Canvas 曲线图)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
            colors = CardDefaults.cardColors(containerColor = OffWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "全渠道交易负荷与合规拦截走势",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalInk
                    )
                    Text(
                        text = "单位: 交易笔数 / 拦截次数",
                        fontSize = 10.sp,
                        color = GraphiteGrey
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 绘制更精细的双折线曲线图
                AdvancedDoubleLineChart(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 第三排：每月最畅销单品榜单 Table
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
            colors = CardDefaults.cardColors(containerColor = OffWhite),
            shape = RoundedCornerShape(2.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "网点最畅销单品销量风向标 (TOP 5)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
                
                Spacer(modifier = Modifier.height(12.dp))

                Column(modifier = Modifier.border(1.dp, MutedPaper)) {
                    // 表头
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CharcoalInk)
                            .padding(10.dp)
                    ) {
                        Text("畅销排名", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(0.8f), fontWeight = FontWeight.Bold)
                        Text("单品名称", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(2.5f), fontWeight = FontWeight.Bold)
                        Text("商品类别", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                        Text("模拟月销量", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                        Text("模拟成交贡献值", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                    }

                    // 5个畅销品数据
                    val topSellers = listOf(
                        TopSeller(1, "烟仕·沪上风华 纪念版", "中式卷烟", 2410, 238590.00),
                        TopSeller(2, "雅仕经典·九五至尊 礼盒", "中式卷烟", 1850, 183150.00),
                        TopSeller(3, "烟仕·极境典藏 手工雪茄", "手工雪茄", 920, 165600.00),
                        TopSeller(4, "帝王品鉴·黄铜雪茄剪", "专营配件", 420, 32760.00),
                        TopSeller(5, "东方神韵·金线包装盒", "专营配件", 310, 15190.00)
                    )

                    topSellers.forEachIndexed { idx, seller ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(if (idx % 2 == 0) OffWhite else WarmPaper)
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "No.${seller.rank}",
                                color = if (idx < 3) SealRed else CharcoalInk,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(0.8f)
                            )
                            Text(seller.name, color = CharcoalInk, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2.5f))
                            Text(seller.category, color = GraphiteGrey, fontSize = 11.sp, modifier = Modifier.weight(1.2f))
                            Text("${seller.salesQty} 件", color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.2f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                            Text("¥${String.format("%,.2f", seller.revenue)}", color = SealRed, fontSize = 11.sp, modifier = Modifier.weight(1.5f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

data class CategoryShare(
    val name: String,
    val fraction: Float,
    val color: Color
)

data class TopSeller(
    val rank: Int,
    val name: String,
    val category: String,
    val salesQty: Int,
    val revenue: Double
)

@Composable
fun HourlyTrafficHeatGrid() {
    Column {
        // 24小时峰值热力模拟
        val trafficHours = listOf(
            8 to 15, 9 to 30, 10 to 45, 11 to 50, 12 to 85, 13 to 70,
            14 to 45, 15 to 40, 16 to 65, 17 to 95, 18 to 120, 19 to 110,
            20 to 80, 21 to 55, 22 to 20, 23 to 5
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            trafficHours.forEach { (hour, score) ->
                val fraction = score / 120f
                val color = if (hour >= 18 && hour <= 20) SealRed.copy(alpha = fraction.coerceAtLeast(0.1f))
                            else AgedBrass.copy(alpha = fraction.coerceAtLeast(0.1f))

                Box(
                    modifier = Modifier
                        .fillMaxHeight()
                        .weight(1f)
                        .background(color)
                        .border(0.5.dp, MutedPaper),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Text(
                        text = "${hour}h",
                        fontSize = 8.sp,
                        color = CharcoalInk,
                        modifier = Modifier.padding(bottom = 2.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
        
        Spacer(modifier = Modifier.height(6.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("上午门庭冷落", fontSize = 9.sp, color = GraphiteGrey)
            Text("中午茶敘小高峰", fontSize = 9.sp, color = GraphiteGrey)
            Text("晚上18h-20h 雅仕沙龙高峰", fontSize = 9.sp, color = SealRed, fontWeight = FontWeight.Bold)
        }
    }
}

// 过去7天：主干交易走势（黄铜金线）与合规拦截走势（印泥红线）
@Composable
fun AdvancedDoubleLineChart(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val leftPadding = 50.dp.toPx()
        val rightPadding = 20.dp.toPx()
        val topPadding = 20.dp.toPx()
        val bottomPadding = 30.dp.toPx()

        val chartWidth = width - leftPadding - rightPadding
        val chartHeight = height - topPadding - bottomPadding

        // 交易负荷 [120, 140, 110, 190, 160, 240, 210]
        val txData = listOf(120f, 140f, 110f, 190f, 160f, 240f, 210f)
        // 合规拦截 [15, 12, 18, 4, 25, 10, 8]
        val cpData = listOf(15f, 12f, 18f, 4f, 25f, 10f, 8f)

        val maxScale = 260f
        val pointsCount = txData.size

        // 网格线
        val gridLines = 5
        for (i in 0..gridLines) {
            val y = topPadding + (chartHeight / gridLines) * i
            drawLine(
                color = MutedPaper.copy(alpha = 0.5f),
                start = Offset(leftPadding, y),
                end = Offset(width - rightPadding, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // X/Y 轴
        drawLine(color = CharcoalInk, start = Offset(leftPadding, topPadding), end = Offset(leftPadding, height - bottomPadding), strokeWidth = 1.5.dp.toPx())
        drawLine(color = CharcoalInk, start = Offset(leftPadding, height - bottomPadding), end = Offset(width - rightPadding, height - bottomPadding), strokeWidth = 1.5.dp.toPx())

        // 1. 绘制交易走向 (黄铜)
        val txPoints = txData.mapIndexed { index, value ->
            val x = leftPadding + (chartWidth / (pointsCount - 1)) * index
            val y = height - bottomPadding - (chartHeight * (value / maxScale))
            Offset(x, y)
        }
        val txPath = Path().apply {
            txPoints.forEachIndexed { idx, pt ->
                if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
            }
        }
        drawPath(path = txPath, color = AgedBrass, style = Stroke(width = 3.dp.toPx()))

        // 2. 绘制拦截走向 (印泥红)
        val cpPoints = cpData.mapIndexed { index, value ->
            val x = leftPadding + (chartWidth / (pointsCount - 1)) * index
            val y = height - bottomPadding - (chartHeight * (value * 6 / maxScale)) // 将比例拉伸方便视觉对比
            Offset(x, y)
        }
        val cpPath = Path().apply {
            cpPoints.forEachIndexed { idx, pt ->
                if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
            }
        }
        drawPath(path = cpPath, color = SealRed, style = Stroke(width = 2.dp.toPx()))

        // 绘制圆点
        txPoints.forEach { pt ->
            drawCircle(color = AgedBrass, radius = 4.dp.toPx(), center = pt)
            drawCircle(color = OffWhite, radius = 2.dp.toPx(), center = pt)
        }
        cpPoints.forEach { pt ->
            drawCircle(color = SealRed, radius = 4.dp.toPx(), center = pt)
            drawCircle(color = OffWhite, radius = 2.dp.toPx(), center = pt)
        }
    }
}
