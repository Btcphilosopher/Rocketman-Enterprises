package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.*
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun DashboardScreen() {
    val state by SimulationEngine.state.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // 欢迎栏与演示标记
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "${state.currentStore.name} · 数字化控制舱",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(
                                if (state.isSimulationRunning) StatusSuccess else StatusAlert,
                                RoundedCornerShape(4.dp)
                            )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (state.isSimulationRunning) "时钟心跳自动运行中 · 模拟速度 ${state.simulationSpeedSecs}s/Tick" else "模拟心跳暂停中",
                        fontSize = 11.sp,
                        color = GraphiteGrey
                    )
                }
            }

            // 推进时间按钮
            OutlinedButton(
                onClick = { SimulationEngine.advanceTimeManual() },
                shape = RoundedCornerShape(2.dp),
                border = BorderStroke(1.dp, CharcoalInk),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("手动推时 +15m", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 顶端横幅: 演示模式声明
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(OffWhite)
                .border(1.dp, MutedPaper, RoundedCornerShape(2.dp))
                .padding(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "演示系统 · SYNTHETIC DATA · CONCEPT PROTOTYPE · 严禁未成年人触碰",
                    fontSize = 10.sp,
                    color = SealRed,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 1. 核心指标卡片网络 (6个)
        val totalStockVal = state.products.sumOf { it.totalStock * it.referencePrice }
        val pendingCompCount = state.complianceEvents.count { it.status == "待处理" }
        val activeMemberCount = state.members.count { it.ageVerificationStatus == AgeVerificationStatus.VERIFIED }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(modifier = Modifier.weight(1f)) {
                MetricCard(
                    title = "今日模拟销售额",
                    value = "¥${String.format("%,.2f", state.currentStore.todaySales)}",
                    subtitle = "累计交易 ${state.currentStore.todayTransactions} 笔",
                    icon = Icons.AutoMirrored.Filled.TrendingUp,
                    color = SealRed,
                    onClick = { SimulationEngine.setScreen(Screen.POS) }
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                MetricCard(
                    title = "全局库存价值",
                    value = "¥${String.format("%,.0f", totalStockVal)}",
                    subtitle = "缺货商品 ${state.products.count { it.totalStock == 0 }} 种",
                    icon = Icons.Default.Layers,
                    color = CharcoalInk,
                    onClick = { SimulationEngine.setScreen(Screen.InventoryConsole) }
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                MetricCard(
                    title = "待核合规事件",
                    value = "$pendingCompCount",
                    subtitle = "系统总计拦截 ${state.complianceEvents.size} 起",
                    icon = Icons.Default.Shield,
                    color = if (pendingCompCount > 0) StatusError else StatusSuccess,
                    onClick = { SimulationEngine.setScreen(Screen.ComplianceCenter) }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(modifier = Modifier.weight(1f)) {
                MetricCard(
                    title = "当前模拟客流",
                    value = "${state.currentStore.currentTraffic} 人",
                    subtitle = "门店面积 ${state.currentStore.area} ㎡",
                    icon = Icons.Default.People,
                    color = AgedBrass,
                    onClick = { SimulationEngine.setScreen(Screen.StoreNetwork) }
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                MetricCard(
                    title = "活跃成年会员",
                    value = "$activeMemberCount 人",
                    subtitle = "待人工复核 ${state.members.count { it.ageVerificationStatus == AgeVerificationStatus.MANUAL_REVIEW }} 人",
                    icon = Icons.Default.Badge,
                    color = CharcoalInk,
                    onClick = { SimulationEngine.setScreen(Screen.MemberServices) }
                )
            }
            Box(modifier = Modifier.weight(1f)) {
                val st = state.currentStore
                MetricCard(
                    title = "许可证及状态",
                    value = st.status.label,
                    subtitle = "证照：${st.licenseStatus} (${st.licenseNo.takeLast(4)})",
                    icon = Icons.Default.FactCheck,
                    color = when (st.status) {
                        StoreStatus.OPEN -> StatusSuccess
                        StoreStatus.CLOSED -> CharcoalInk
                        StoreStatus.MAINTENANCE -> StatusError
                    },
                    onClick = { SimulationEngine.setScreen(Screen.StoreNetwork) }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. 双生控制可视化 & 数据分析图表
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 左半：过去 7 天销售趋势 + 供应链更新
            Column(modifier = Modifier.weight(1.8f)) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "今日前序模拟销售趋势 (24h 仿真)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalInk
                            )
                            Text(
                                text = "单位: 元",
                                fontSize = 10.sp,
                                color = GraphiteGrey
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // 自定义趋势图表 (Canvas)
                        DashboardSalesTrendChart(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 供应链在途简要看板
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "紧急物流在途监管 (${state.supplyOrders.size} 个批次)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalInk
                            )
                            Text(
                                text = "查看详情 →",
                                fontSize = 11.sp,
                                color = SealRed,
                                modifier = Modifier.clickable { SimulationEngine.setScreen(Screen.SupplyChain) }
                            )
                        }
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        state.supplyOrders.take(3).forEach { order ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .border(1.dp, MutedPaper)
                                    .background(WarmPaper)
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = order.id, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CharcoalInk)
                                    Text(text = order.routeDesc, fontSize = 10.sp, color = GraphiteGrey, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            when(order.status) {
                                                TransitStatus.DELAYED -> StatusError.copy(alpha = 0.1f)
                                                TransitStatus.DELIVERED -> StatusSuccess.copy(alpha = 0.1f)
                                                else -> AgedBrass.copy(alpha = 0.1f)
                                            },
                                            RoundedCornerShape(2.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = order.status.label,
                                        fontSize = 10.sp,
                                        color = when(order.status) {
                                            TransitStatus.DELAYED -> StatusError
                                            TransitStatus.DELIVERED -> StatusSuccess
                                            else -> CharcoalInk
                                        },
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // 右半：库存分布与实时合规风险流
            Column(modifier = Modifier.weight(1.2f)) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "各商品类别当前总存占比",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalInk
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // 绘制水平分布进度图
                        ProductCategory.values().forEach { category ->
                            val catProducts = state.products.filter { it.category == category }
                            val catStockSum = catProducts.sumOf { it.totalStock }
                            val totalStockSum = state.products.sumOf { it.totalStock }.coerceAtLeast(1)
                            val fraction = catStockSum.toFloat() / totalStockSum

                            Column(modifier = Modifier.padding(vertical = 4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = category.label, fontSize = 11.sp, color = CharcoalInk)
                                    Text(text = "$catStockSum 件 (${String.format("%.1f", fraction * 100)}%)", fontSize = 10.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .background(MutedPaper)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .fillMaxWidth(fraction)
                                            .background(if (category == ProductCategory.SYNTHETIC_CIGARETTE || category == ProductCategory.SYNTHETIC_CIGAR) SealRed else AgedBrass)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // 实时合规风险流水 (CP Events)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "合规防御监控日志",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = CharcoalInk
                            )
                            Text(
                                text = "合规中心 →",
                                fontSize = 11.sp,
                                color = SealRed,
                                modifier = Modifier.clickable { SimulationEngine.setScreen(Screen.ComplianceCenter) }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        state.complianceEvents.take(3).forEach { event ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .border(1.dp, MutedPaper)
                                    .background(WarmPaper)
                                    .padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = event.type.label,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (event.riskLevel == RiskLevel.HIGH || event.riskLevel == RiskLevel.CRITICAL) StatusError else StatusAlert
                                    )
                                    Text(text = event.timestamp.substring(5), fontSize = 10.sp, color = GraphiteGrey)
                                }
                                Text(
                                    text = event.details,
                                    fontSize = 10.sp,
                                    color = CharcoalInk,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = 4.dp),
                                    lineHeight = 14.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MutedPaper, RoundedCornerShape(2.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = OffWhite),
        shape = RoundedCornerShape(2.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Medium)
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalInk,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = subtitle, fontSize = 10.sp, color = GraphiteGrey, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

// 过去7天的优雅Canvas曲线折线图
@Composable
fun DashboardSalesTrendChart(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // 边距
        val leftPadding = 50.dp.toPx()
        val rightPadding = 20.dp.toPx()
        val topPadding = 20.dp.toPx()
        val bottomPadding = 30.dp.toPx()

        val chartWidth = width - leftPadding - rightPadding
        val chartHeight = height - topPadding - bottomPadding

        // 虚构过去7天销售数据: [28000, 31000, 24000, 42000, 35000, 51000, 42800]
        val salesData = listOf(28000f, 31000f, 24000f, 42000f, 35000f, 51000f, 45000f)
        val maxSales = 60000f
        val pointsCount = salesData.size

        // 1. 绘制温润纸质网格背景
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = topPadding + (chartHeight / gridLines) * i
            drawLine(
                color = MutedPaper.copy(alpha = 0.5f),
                start = Offset(leftPadding, y),
                end = Offset(width - rightPadding, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        // 2. 绘制X/Y轴线
        drawLine(
            color = CharcoalInk,
            start = Offset(leftPadding, topPadding),
            end = Offset(leftPadding, height - bottomPadding),
            strokeWidth = 1.5.dp.toPx()
        )
        drawLine(
            color = CharcoalInk,
            start = Offset(leftPadding, height - bottomPadding),
            end = Offset(width - rightPadding, height - bottomPadding),
            strokeWidth = 1.5.dp.toPx()
        )

        // 3. 计算各个点坐标并绘制趋势曲线
        val points = salesData.mapIndexed { index, value ->
            val x = leftPadding + (chartWidth / (pointsCount - 1)) * index
            val y = height - bottomPadding - (chartHeight * (value / maxSales))
            Offset(x, y)
        }

        // 绘制阴影填充
        val fillPath = Path().apply {
            moveTo(leftPadding, height - bottomPadding)
            points.forEach { lineTo(it.x, it.y) }
            lineTo(width - rightPadding, height - bottomPadding)
            close()
        }
        drawPath(
            path = fillPath,
            color = SealRed.copy(alpha = 0.08f)
        )

        // 绘制折线
        val linePath = Path().apply {
            points.forEachIndexed { idx, pt ->
                if (idx == 0) moveTo(pt.x, pt.y) else lineTo(pt.x, pt.y)
            }
        }
        drawPath(
            path = linePath,
            color = SealRed,
            style = Stroke(width = 3.dp.toPx())
        )

        // 绘制数据圆点及外环
        points.forEach { pt ->
            drawCircle(
                color = OffWhite,
                radius = 6.dp.toPx(),
                center = pt
            )
            drawCircle(
                color = SealRed,
                radius = 4.dp.toPx(),
                center = pt
            )
            drawCircle(
                color = AgedBrass,
                radius = 2.dp.toPx(),
                center = pt
            )
        }
    }
}
