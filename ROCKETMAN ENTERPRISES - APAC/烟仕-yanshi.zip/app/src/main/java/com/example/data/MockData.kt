package com.example.data

import com.example.domain.*

object MockData {
    // 10家虚构的高端专营门店
    val initialStores = listOf(
        Store(
            id = "ST-01",
            name = "上海新天地专营旗舰店",
            city = "上海",
            businessDistrict = "新天地核心商业区",
            area = 180.0,
            employeeCount = 8,
            status = StoreStatus.OPEN,
            licenseNo = "JY31010120261099",
            licenseStatus = "有效",
            todaySales = 42800.0,
            todayTransactions = 34,
            currentTraffic = 12,
            riskLevel = RiskLevel.LOW,
            manager = "张雅仕",
            lastInspectionDate = "2026-09-15",
            devicesStatus = "正常 (6/6)"
        ),
        Store(
            id = "ST-02",
            name = "北京国贸三期雅仕汇店",
            city = "北京",
            businessDistrict = "国贸商务中心区",
            area = 150.0,
            employeeCount = 6,
            status = StoreStatus.OPEN,
            licenseNo = "JY11010520263481",
            licenseStatus = "即将到期", // 激发合规警告
            todaySales = 38500.0,
            todayTransactions = 28,
            currentTraffic = 8,
            riskLevel = RiskLevel.MEDIUM,
            manager = "王文墨",
            lastInspectionDate = "2026-09-10",
            devicesStatus = "警告 (5/6)"
        ),
        Store(
            id = "ST-03",
            name = "深圳湾万象城现代体验店",
            city = "深圳",
            businessDistrict = "深圳湾万象城商圈",
            area = 135.0,
            employeeCount = 5,
            status = StoreStatus.OPEN,
            licenseNo = "JY44030520267711",
            licenseStatus = "有效",
            todaySales = 51200.0,
            todayTransactions = 41,
            currentTraffic = 15,
            riskLevel = RiskLevel.LOW,
            manager = "李新泽",
            lastInspectionDate = "2026-09-18",
            devicesStatus = "正常 (5/5)"
        ),
        Store(
            id = "ST-04",
            name = "广州太古汇岭南文风阁",
            city = "广州",
            businessDistrict = "天河太古汇商圈",
            area = 160.0,
            employeeCount = 7,
            status = StoreStatus.OPEN,
            licenseNo = "JY44010620264903",
            licenseStatus = "有效",
            todaySales = 29000.0,
            todayTransactions = 22,
            currentTraffic = 5,
            riskLevel = RiskLevel.LOW,
            manager = "陈粤明",
            lastInspectionDate = "2026-09-08",
            devicesStatus = "正常 (6/6)"
        ),
        Store(
            id = "ST-05",
            name = "杭州湖滨银泰西子春风阁",
            city = "杭州",
            businessDistrict = "湖滨步行街商圈",
            area = 120.0,
            employeeCount = 4,
            status = StoreStatus.OPEN,
            licenseNo = "JY33010220265502",
            licenseStatus = "有效",
            todaySales = 31000.0,
            todayTransactions = 26,
            currentTraffic = 9,
            riskLevel = RiskLevel.LOW,
            manager = "林西湖",
            lastInspectionDate = "2026-09-12",
            devicesStatus = "正常 (4/4)"
        ),
        Store(
            id = "ST-06",
            name = "成都太古里竹林幽境店",
            city = "成都",
            businessDistrict = "春熙路太古里商圈",
            area = 145.0,
            employeeCount = 5,
            status = StoreStatus.OPEN,
            licenseNo = "JY51010420268801",
            licenseStatus = "有效",
            todaySales = 24600.0,
            todayTransactions = 19,
            currentTraffic = 6,
            riskLevel = RiskLevel.LOW,
            manager = "赵蜀音",
            lastInspectionDate = "2026-09-01",
            devicesStatus = "正常 (5/5)"
        ),
        Store(
            id = "ST-07",
            name = "南京德基广场石城春华店",
            city = "南京",
            businessDistrict = "新街口德基广场",
            area = 110.0,
            employeeCount = 4,
            status = StoreStatus.CLOSED, // 测试打烊状态
            licenseNo = "JY32010220269011",
            licenseStatus = "有效",
            todaySales = 0.0,
            todayTransactions = 0,
            currentTraffic = 0,
            riskLevel = RiskLevel.LOW,
            manager = "朱金陵",
            lastInspectionDate = "2026-08-25",
            devicesStatus = "正常 (4/4)"
        ),
        Store(
            id = "ST-08",
            name = "苏州平江路木色水乡阁",
            city = "苏州",
            businessDistrict = "平江路历史街区",
            area = 95.0,
            employeeCount = 3,
            status = StoreStatus.OPEN,
            licenseNo = "JY32050820260432",
            licenseStatus = "有效",
            todaySales = 18200.0,
            todayTransactions = 15,
            currentTraffic = 4,
            riskLevel = RiskLevel.LOW,
            manager = "吴姑苏",
            lastInspectionDate = "2026-09-14",
            devicesStatus = "正常 (3/3)"
        ),
        Store(
            id = "ST-09",
            name = "武汉琴台商业中心琴心阁",
            city = "武汉",
            businessDistrict = "汉阳琴台商务区",
            area = 130.0,
            employeeCount = 5,
            status = StoreStatus.MAINTENANCE, // 测试整顿维护状态
            licenseNo = "JY42010520261892",
            licenseStatus = "已过期", // 严重合规警告
            todaySales = 0.0,
            todayTransactions = 0,
            currentTraffic = 0,
            riskLevel = RiskLevel.CRITICAL,
            manager = "周九楚",
            lastInspectionDate = "2026-09-19",
            devicesStatus = "故障 (2/5)"
        ),
        Store(
            id = "ST-10",
            name = "重庆解放碑云端山阁",
            city = "重庆",
            businessDistrict = "解放碑商圈",
            area = 140.0,
            employeeCount = 6,
            status = StoreStatus.OPEN,
            licenseNo = "JY50010320265324",
            licenseStatus = "有效",
            todaySales = 35200.0,
            todayTransactions = 30,
            currentTraffic = 11,
            riskLevel = RiskLevel.LOW,
            manager = "郭渝水",
            lastInspectionDate = "2026-09-02",
            devicesStatus = "正常 (5/5)"
        )
    )

    // 10种合成的高端专营商品
    val initialProducts = listOf(
        Product(
            id = "PD-1001",
            name = "烟仕·东方锦绣",
            engName = "YANSHI Oriental Splendor",
            category = ProductCategory.SYNTHETIC_CIGARETTE,
            brand = "烟仕 (YANSHI)",
            specification = "20支/精装盒",
            supplier = "烟仕东方合成制品厂",
            referencePrice = 98.0,
            totalStock = 1200,
            isSaleable = true,
            complianceTags = listOf("仅限成年人购买", "烟气烟碱0.9mg", "严禁未成年人购买", "中国商业现代化演示商品"),
            imagePlaceholderText = "东方图案/暗红底",
            description = "虚构现代商业演示商品。融合清雅温润风味，极简包装，配合现代化高科技合成技术，展现烟具包装美学，不具有真实吸食体验。",
            createDate = "2026-01-10",
            updateDate = "2026-09-19",
            status = ProductStatus.ON_SALE,
            regionLimits = "无限制"
        ),
        Product(
            id = "PD-1002",
            name = "烟仕·江南竹韵",
            engName = "YANSHI Jiangnan Bamboo",
            category = ProductCategory.SYNTHETIC_CIGARETTE,
            brand = "烟仕 (YANSHI)",
            specification = "20支/高雅竹质盒",
            supplier = "温州古韵礼盒工艺厂",
            referencePrice = 120.0,
            totalStock = 850,
            isSaleable = true,
            complianceTags = listOf("仅限成年人购买", "天然草本提取合成", "不保存敏感信息", "严禁向未成年人展示"),
            imagePlaceholderText = "江南绿底/淡金线",
            description = "极具中国商业现代美学的高档模拟商品。精工竹饰外观，以天然草本纤维等环保材质进行包装呈现。",
            createDate = "2026-02-15",
            updateDate = "2026-09-18",
            status = ProductStatus.ON_SALE,
            regionLimits = "上海/北京销售"
        ),
        Product(
            id = "PD-1003",
            name = "烟仕·沪上风华",
            engName = "YANSHI Shanghai Era",
            category = ProductCategory.SYNTHETIC_CIGARETTE,
            brand = "烟仕 (YANSHI)",
            specification = "20支/磨砂金属边盒",
            supplier = "上海拉丝金属精工",
            referencePrice = 150.0,
            totalStock = 40, // 激发低库存状态
            isSaleable = true,
            complianceTags = listOf("仅限成年人购买", "高纯焦油控制0.6mg", "限购限售", "反代购标记"),
            imagePlaceholderText = "拉丝银/复古墨红印",
            description = "极简冷淡金属工业风格。经典与现代主义中国零售审美的完备结合。",
            createDate = "2026-03-20",
            updateDate = "2026-09-19",
            status = ProductStatus.ON_SALE,
            regionLimits = "限上海市销售"
        ),
        Product(
            id = "PD-1004",
            name = "暮雨雪茄·半岛臻选",
            engName = "Muyu Premium Peninsula Cigar",
            category = ProductCategory.SYNTHETIC_CIGAR,
            brand = "暮雨 (Muyu)",
            specification = "5支/纯木防潮装",
            supplier = "海南木香实业",
            referencePrice = 680.0,
            totalStock = 320,
            isSaleable = true,
            complianceTags = listOf("仅限成年人购买", "珍品木盒保存", "需要双人实名认证核销", "高净值单品"),
            imagePlaceholderText = "暗桃木色/金标印",
            description = "纯木香防潮保存设计。高端社交与礼仪用模拟雪茄，中性草木纯香质感，非化学添加制品。",
            createDate = "2026-04-12",
            updateDate = "2026-09-15",
            status = ProductStatus.ON_SALE,
            regionLimits = "无限制"
        ),
        Product(
            id = "PD-1005",
            name = "暮雨雪茄·一号金箔",
            engName = "Muyu Gold Leaf No.1 Cigar",
            category = ProductCategory.SYNTHETIC_CIGAR,
            brand = "暮雨 (Muyu)",
            specification = "10支/拉丝黄铜金箱",
            supplier = "深圳卓越精工实业",
            referencePrice = 1200.0,
            totalStock = 0, // 缺货状态
            isSaleable = false,
            complianceTags = listOf("限额交易", "仅在部分城市旗舰店可售", "未成年人严禁触碰", "合规审计限制"),
            imagePlaceholderText = "铜金色拉丝网格",
            description = "顶级拉丝黄铜防潮箱，金箔雕刻压制工艺。专为数字孪生门店高端展示货架提供的数据参考。",
            createDate = "2026-05-18",
            updateDate = "2026-09-19",
            status = ProductStatus.SUSPENDED,
            regionLimits = "限一线城市旗舰店"
        ),
        Product(
            id = "PD-1006",
            name = "古道秋色·珍品烟丝",
            engName = "Ancient Autumn Pipe Tobacco",
            category = ProductCategory.SYNTHETIC_PIPE_TOBACCO,
            brand = "古道 (Gudao)",
            specification = "100g/米白纸盒锡封",
            supplier = "云南天然香料工坊",
            referencePrice = 180.0,
            totalStock = 500,
            isSaleable = true,
            complianceTags = listOf("仅限成年人购买", "特级熟化工艺", "必须配备滤嘴器具", "不含违禁香精"),
            imagePlaceholderText = "米白手工纸质质感",
            description = "米色中国宣纸防潮设计包装，传统风味醇厚芬芳。面向专业器具品鉴的高端手工模拟材料。",
            createDate = "2026-05-01",
            updateDate = "2026-09-10",
            status = ProductStatus.ON_SALE,
            regionLimits = "无限制"
        ),
        Product(
            id = "PD-1007",
            name = "铜锁金兰·黄铜烟斗",
            engName = "Golden Brass Handcrafted Pipe",
            category = ProductCategory.TOBACCO_ACCESSORIES,
            brand = "古道 (Gudao)",
            specification = "1支/尊享皮绒袋",
            supplier = "扬州金雕工艺工坊",
            referencePrice = 380.0,
            totalStock = 180,
            isSaleable = true,
            complianceTags = listOf("非烟草制品", "精细黄铜雕刻", "18岁以上专用"),
            imagePlaceholderText = "黑檀木咬嘴/黄铜斗身",
            description = "匠人纯手工打磨黑檀木与复古黄铜结合，重力适中，吸附性强，彰显东方精工器物之美。",
            createDate = "2026-06-15",
            updateDate = "2026-09-19",
            status = ProductStatus.ON_SALE,
            regionLimits = "无限制",
            isAgeRestricted = false
        ),
        Product(
            id = "PD-1008",
            name = "黑檀木浮雕收纳盒",
            engName = "Ebony Hand-Carved Storage Chest",
            category = ProductCategory.STORAGE_BOX,
            brand = "尊尊 (Zunzun)",
            specification = "1个/精美防震木盒",
            supplier = "东阳雕刻艺术实业",
            referencePrice = 980.0,
            totalStock = 60,
            isSaleable = true,
            complianceTags = listOf("高档非易损工艺品", "100%正品黑檀木", "温度湿度精密计"),
            imagePlaceholderText = "浮雕黑檀深纹/黄铜件",
            description = "配备气压平衡与物理湿度表的高端原木存放箱。极简雅致线条，提供给品鉴家最佳的原木干湿度管理系统。",
            createDate = "2026-07-02",
            updateDate = "2026-09-15",
            status = ProductStatus.ON_SALE,
            regionLimits = "无限制",
            isAgeRestricted = false
        ),
        Product(
            id = "PD-1009",
            name = "雅宴·中秋尊享限定礼包",
            engName = "The Elegant Banquet Autumn Gift Box",
            category = ProductCategory.GIFT_BOX,
            brand = "烟仕 (YANSHI)",
            specification = "1套/红底烫金丝绸箱",
            supplier = "苏州丝绸精美礼盒",
            referencePrice = 2880.0,
            totalStock = 12, // 限量版
            isSaleable = true,
            complianceTags = listOf("高价值贵宾限定", "含有非烟草高端茶器", "仅限实名受邀会员预约", "严格实名审查"),
            imagePlaceholderText = "红泥暗金锦缎",
            description = "虚构中秋顶级演示礼盒。内置特制手拉石壶、白瓷品杯以及演示专享高级器具模型，高雅大器。",
            createDate = "2026-08-10",
            updateDate = "2026-09-19",
            status = ProductStatus.ON_SALE,
            regionLimits = "北京/上海/深圳旗舰店"
        ),
        Product(
            id = "PD-1010",
            name = "高山雪菊天然配套纯茶",
            engName = "Highland Snow-Chrysanthemum Shop Tea",
            category = ProductCategory.NON_TOBACCO_RETAIL,
            brand = "臻致 (Zhenzhi)",
            specification = "50g/锡封磨砂罐",
            supplier = "青海昆仑天然特产",
            referencePrice = 68.0,
            totalStock = 300,
            isSaleable = true,
            complianceTags = listOf("纯天然植物纯茶", "去腻生津", "全年龄适用", "辅助店内休息服务"),
            imagePlaceholderText = "磨砂黑/金边小花绘",
            description = "采自高海拔无污染昆仑雪菊，色泽红亮如琥珀，气味芬芳高雅，是店内作为高档成年品鉴的绝佳配套清口非烟草茶饮。",
            createDate = "2026-08-01",
            updateDate = "2026-09-19",
            status = ProductStatus.ON_SALE,
            regionLimits = "无限制",
            isAgeRestricted = false
        )
    )

    // 5个虚构的成年会员数据 (纯演示数据)
    val initialMembers = listOf(
        Member(
            id = "MB-8801",
            name = "陆雅士",
            phoneMasked = "139****8888",
            ageVerificationStatus = AgeVerificationStatus.VERIFIED,
            verifiedAge = 42,
            registrationDate = "2026-01-05",
            level = "雅仕至尊级",
            commonStoreId = "ST-01",
            preferences = "偏好高档合成雪茄，重视木质防潮收纳盒与手工茶具服务",
            isDataSharingConsent = true,
            auditTrail = listOf("2026-01-05: 身份模拟注册", "2026-01-05: 上海新天地店NFC身份证模拟核验成功", "2026-09-19: 导出虚构个人数据申请审核")
        ),
        Member(
            id = "MB-8802",
            name = "沈静竹",
            phoneMasked = "186****1234",
            ageVerificationStatus = AgeVerificationStatus.VERIFIED,
            verifiedAge = 29,
            registrationDate = "2026-03-12",
            level = "白金卡会员",
            commonStoreId = "ST-03",
            preferences = "关注极简东方烟丝及雅致包装礼盒系列，极客风黄铜斗身配件",
            isDataSharingConsent = true,
            auditTrail = listOf("2026-03-12: 模拟微信小程序扫码入会", "2026-03-12: 深圳湾万象城实名手机号核验成功")
        ),
        Member(
            id = "MB-8803",
            name = "钟国茂",
            phoneMasked = "133****9900",
            ageVerificationStatus = AgeVerificationStatus.MANUAL_REVIEW, // 待审核
            verifiedAge = 58,
            registrationDate = "2026-09-18",
            level = "黄金卡会员",
            commonStoreId = "ST-02",
            preferences = "关注北京国贸店的限定东方锦绣礼包发布，定期参与线下品鉴预约",
            isDataSharingConsent = false,
            auditTrail = listOf("2026-09-18: 提交北京店手工纸质验证", "2026-09-18: 待合规中心人工核实资质")
        ),
        Member(
            id = "MB-8804",
            name = "张未成年", // 专门用于测试拒绝验证
            phoneMasked = "177****4321",
            ageVerificationStatus = AgeVerificationStatus.VERIFICATION_FAILED,
            verifiedAge = 16,
            registrationDate = "2026-09-19",
            level = "无卡非会员",
            commonStoreId = "ST-01",
            preferences = "尝试进入受限区域被系统判定年龄不合规",
            isDataSharingConsent = false,
            auditTrail = listOf("2026-09-19: 尝试模拟身份证核验", "2026-09-19: 年龄未满18周岁拦截", "2026-09-19: 计入高风险合规拦截事件")
        ),
        Member(
            id = "MB-8805",
            name = "顾姑苏",
            phoneMasked = "135****4567",
            ageVerificationStatus = AgeVerificationStatus.EXPIRED, // 过期，需重新核验
            verifiedAge = 35,
            registrationDate = "2025-05-20",
            level = "雅仕普卡会员",
            commonStoreId = "ST-08",
            preferences = "偏好高山雪菊天然配套茶，关注平江路木色水乡阁的茶席服务",
            isDataSharingConsent = true,
            auditTrail = listOf("2025-05-20: 实名手机号关联", "2026-09-15: 系统自动判定一年验证周期到期，需要再次核验")
        )
    )

    // 供应链初始在途清单
    val initialSupplyOrders = listOf(
        SupplyChainOrder(
            id = "SC-2026091901",
            creationTime = "2026-09-19 02:00",
            supplier = "烟仕东方合成制品厂",
            destinationStoreId = "ST-01",
            destinationStoreName = "上海新天地专营旗舰店",
            itemsCount = 450,
            totalAmount = 44100.0,
            status = TransitStatus.IN_TRANSIT,
            carrier = "顺丰特惠精运",
            eta = "2026-09-20 12:00",
            routeDesc = "上海崇明研发配送中心 -> 新天地专营旗舰店"
        ),
        SupplyChainOrder(
            id = "SC-2026091902",
            creationTime = "2026-09-18 10:00",
            supplier = "深圳卓越精工实业",
            destinationStoreId = "ST-02",
            destinationStoreName = "北京国贸三期雅仕汇店",
            itemsCount = 120,
            totalAmount = 81600.0,
            status = TransitStatus.DELAYED, // 延误，激发预警
            carrier = "中铁特运航空",
            eta = "2026-09-19 18:00 (延误)",
            routeDesc = "深圳卓越精工仓库 -> 广州中转站 -> 北京货站 (由于北京空域调配延阻)",
            isDelayedAlert = true
        ),
        SupplyChainOrder(
            id = "SC-2026091903",
            creationTime = "2026-09-19 05:00",
            supplier = "东阳雕刻艺术实业",
            destinationStoreId = "ST-03",
            destinationStoreName = "深圳湾万象城现代体验店",
            itemsCount = 30,
            totalAmount = 29400.0,
            status = TransitStatus.DISPATCHED,
            carrier = "跨越速运",
            eta = "2026-09-21 09:00",
            routeDesc = "浙江金华东阳工厂 -> 深圳分拨仓"
        )
    )

    // 合规中心初始拦截与预警事件
    val initialComplianceEvents = listOf(
        ComplianceEvent(
            id = "CP-9001",
            timestamp = "2026-09-19 04:30",
            storeId = "ST-01",
            storeName = "上海新天地专营旗舰店",
            type = ComplianceEventType.AGE_CHECK_FAILED,
            riskLevel = RiskLevel.HIGH,
            status = "待处理",
            details = "虚构顾客尝试购买「烟仕·东方锦绣」时，刷入虚构未成年身份证(出生日期：2010年05月)，系统立时拦截交易并关闭收银窗口。顾客已离店。",
            operatorRole = "收银员",
            notes = "系统强制锁定收银台POS并报警，等待合规员审查归档。",
            auditTrail = listOf("04:30 - 系统拦截不合规出生年月", "04:31 - 计入未成年人拦截黑名单")
        ),
        ComplianceEvent(
            id = "CP-9002",
            timestamp = "2026-09-18 16:15",
            storeId = "ST-02",
            storeName = "北京国贸三期雅仕汇店",
            type = ComplianceEventType.LICENSE_EXPIRING,
            riskLevel = RiskLevel.MEDIUM,
            status = "处理中",
            details = "北京国贸三期店「烟草专卖零售许可证」(JY11010520263481)有效截止期为2026年10月10日，剩余有效期已少于30日。需启动续期模拟申报流程。",
            operatorRole = "门店经理",
            notes = "已提交虚构续延申报资料至线上局端模拟审核平台。",
            auditTrail = listOf("16:15 - 系统到期自动预警", "18:00 - 店长确认已递交申请")
        ),
        ComplianceEvent(
            id = "CP-9003",
            timestamp = "2026-09-19 01:20",
            storeId = "ST-09",
            storeName = "武汉琴台商业中心琴心阁",
            type = ComplianceEventType.DEVICE_FAULT,
            riskLevel = RiskLevel.CRITICAL,
            status = "待处理",
            details = "该店「合规人脸年龄辅助摄像头」及后仓「监控摄像头#3」发生网络握手失败。此设备直接关联出库防串监管，设备离线可能违反全时段数据留存条例。",
            operatorRole = "系统管理员",
            notes = "由于门店许可证已过期，且正在进行店面整顿维护，疑似门店断电引发网络掉线。",
            auditTrail = listOf("01:20 - 网关失去心跳信号", "01:25 - 生成严重红色合规风险事件")
        )
    )

    // 初始通知
    val initialNotifications = listOf(
        Notification(
            id = "NT-01",
            timestamp = "04:55",
            title = "合规：上海新天地店年龄拦截",
            content = "上海新天地店发生一起未成年身份证核验拦截，系统自动记录CP-9001事件。",
            category = "合规",
            priority = RiskLevel.HIGH
        ),
        Notification(
            id = "NT-02",
            timestamp = "04:12",
            title = "库存：沪上风华库存预警",
            content = "旗舰商品「烟仕·沪上风华」当前全国总可售库存仅剩余 40 盒，多店已缺货！",
            category = "库存",
            priority = RiskLevel.MEDIUM
        ),
        Notification(
            id = "NT-03",
            timestamp = "02:30",
            title = "物流：北京店补货路线延误",
            content = "补货单 SC-2026091902 发生中转站积压，预计到店延迟6小时。",
            category = "物流",
            priority = RiskLevel.LOW
        )
    )
}
