package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// 烟仕 (YANSHI) 专享：中国城市商业现代主义色彩体系
val WarmPaper = Color(0xFFFAF8F5)       // 温暖纸张底色
val OffWhite = Color(0xFFF4F1EA)         // 温润石质底色
val CharcoalInk = Color(0xFF1E2422)      // 深墨碳灰色
val DarkWood = Color(0xFF281C19)         // 深木红棕色
val SealRed = Color(0xFF941F24)          // 经典印泥暗红
val AgedBrass = Color(0xFFBCA06B)        // 精细柜台照明黄铜
val GraphiteGrey = Color(0xFF424D49)     // 烟草包装纸灰色
val MutedPaper = Color(0xFFEBE6DD)       // 传统票据描边灰色

val White = Color(0xFFFFFFFF)
val Black = Color(0xFF000000)

val StatusSuccess = Color(0xFF2E6B56)    // 邮绿合规成功色
val StatusAlert = Color(0xFFBC5815)      // 暖金仓储报警色
val StatusError = Color(0xFFA61C24)      // 红色拦截警报色
