package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Screen
import com.example.domain.Store
import com.example.domain.UserRole
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun LoginScreen() {
    val state by SimulationEngine.state.collectAsState()
    var selectedRole by remember { mutableStateOf(UserRole.ADMIN) }
    var selectedStore by remember { mutableStateOf(state.stores.first()) }
    
    val configuration = LocalConfiguration.current
    val isWide = configuration.screenWidthDp > 600

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(WarmPaper)
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        // 装饰外边框：双线传统中式几何边线
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, MutedPaper)
                .padding(4.dp)
                .border(2.dp, CharcoalInk)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // 顶端古典印章
                YanshiClassicalSeal(modifier = Modifier.size(80.dp))
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "烟 仕",
                    color = CharcoalInk,
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    letterSpacing = 6.sp
                )
                
                Text(
                    text = "中国烟草专营店数字化运营平台",
                    color = SealRed,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 2.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
                
                Text(
                    text = "YANSHI — Chinese Tobacco Retail & Store Operations Platform",
                    color = GraphiteGrey,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Light,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 2.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                // 中央卡片布局
                Card(
                    modifier = Modifier
                        .widthIn(max = 500.dp)
                        .fillMaxWidth()
                        .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
                    colors = CardDefaults.cardColors(containerColor = OffWhite),
                    shape = RoundedCornerShape(2.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "平台初始化登入",
                            color = CharcoalInk,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Start)
                        )
                        
                        Divider(
                            color = CharcoalInk,
                            thickness = 1.dp,
                            modifier = Modifier.padding(vertical = 12.0.dp)
                        )

                        // 1. 角色选择
                        Text(
                            text = "选择模拟操作员角色 (RBAC)",
                            color = GraphiteGrey,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                .align(Alignment.Start)
                                .padding(bottom = 6.dp)
                        )
                        
                        var roleExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { roleExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Person, contentDescription = null, tint = SealRed, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(selectedRole.label, fontWeight = FontWeight.SemiBold)
                                    }
                                    Text("▼", fontSize = 10.sp, color = GraphiteGrey)
                                }
                            }
                            DropdownMenu(
                                expanded = roleExpanded,
                                onDismissRequest = { roleExpanded = false },
                                modifier = Modifier.background(OffWhite)
                            ) {
                                UserRole.values().forEach { role ->
                                    DropdownMenuItem(
                                        text = { Text(role.label, color = CharcoalInk) },
                                        onClick = {
                                            selectedRole = role
                                            roleExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // 2. 门店选择
                        Text(
                            text = "选择初始化门店柜台",
                            color = GraphiteGrey,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier
                                        .align(Alignment.Start)
                                        .padding(bottom = 6.dp)
                        )
                        
                        var storeExpanded by remember { mutableStateOf(false) }
                        Box(modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(
                                onClick = { storeExpanded = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = CharcoalInk)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Business, contentDescription = null, tint = SealRed, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(selectedStore.name, fontWeight = FontWeight.SemiBold)
                                    }
                                    Text("▼", fontSize = 10.sp, color = GraphiteGrey)
                                }
                            }
                            DropdownMenu(
                                expanded = storeExpanded,
                                onDismissRequest = { storeExpanded = false },
                                modifier = Modifier.background(OffWhite)
                            ) {
                                state.stores.forEach { store ->
                                    DropdownMenuItem(
                                        text = { Text(store.name, color = CharcoalInk) },
                                        onClick = {
                                            selectedStore = store
                                            storeExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))

                        // 3. 登录按钮
                        Button(
                            onClick = {
                                SimulationEngine.changeUserRole(selectedRole)
                                SimulationEngine.changeCurrentStore(selectedStore)
                                SimulationEngine.setScreen(Screen.Dashboard)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp),
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CharcoalInk,
                                contentColor = WarmPaper
                            )
                        ) {
                            Text("确 认 · 进入专营操作系统", fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))

                // 底部合规免责声明
                Box(
                    modifier = Modifier
                        .widthIn(max = 550.dp)
                        .border(1.dp, SealRed.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
                        .background(SealRed.copy(alpha = 0.05f))
                        .padding(14.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = SealRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "合规声明与防未成年人采购红线",
                                color = SealRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "本系统为专营渠道合规管理系统、库存流动与数字孪生演示原型。系统内展示的所有卷烟、雪茄、包装礼盒及店铺数据均为【虚构合成数据】。平台【不涉及】真实烟草销售及任何在线支付接口。本系统严禁向未满18周岁未成年人推荐、展示、销售烟草制品。进入平台即代表您已年满18周岁并具备完全民事行为能力。",
                            color = CharcoalInk,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            textAlign = TextAlign.Justify,
                            fontWeight = FontWeight.Light
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "演示系统 · SYNTHETIC DATA · CONCEPT PROTOTYPE",
                            color = SealRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}

// 经典的印红色双框印章 Canvas 组件
@Composable
fun YanshiClassicalSeal(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val rColor = SealRed

        // 外圈框线
        drawRoundRect(
            color = rColor,
            topLeft = Offset(2.dp.toPx(), 2.dp.toPx()),
            size = Size(w - 4.dp.toPx(), h - 4.dp.toPx()),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx()),
            style = Stroke(width = 3.dp.toPx())
        )

        // 内圈细框线
        drawRoundRect(
            color = rColor,
            topLeft = Offset(6.dp.toPx(), 6.dp.toPx()),
            size = Size(w - 12.dp.toPx(), h - 12.dp.toPx()),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()),
            style = Stroke(width = 1.dp.toPx())
        )

        // 印章古典十字分割
        drawLine(
            color = rColor.copy(alpha = 0.2f),
            start = Offset(w/2, 10.dp.toPx()),
            end = Offset(w/2, h - 10.dp.toPx()),
            strokeWidth = 1.dp.toPx()
        )
        drawLine(
            color = rColor.copy(alpha = 0.2f),
            start = Offset(10.dp.toPx(), h/2),
            end = Offset(w - 10.dp.toPx(), h/2),
            strokeWidth = 1.dp.toPx()
        )
    }
}
