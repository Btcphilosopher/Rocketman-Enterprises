package com.example.engine

import com.example.data.MockData
import com.example.domain.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.*

// 整个系统的统一状态封装
data class YanshiState(
    val currentRole: UserRole = UserRole.ADMIN,
    val currentStore: Store = MockData.initialStores.first(),
    val stores: List<Store> = MockData.initialStores,
    val products: List<Product> = MockData.initialProducts,
    val members: List<Member> = MockData.initialMembers,
    val complianceEvents: List<ComplianceEvent> = MockData.initialComplianceEvents,
    val supplyOrders: List<SupplyChainOrder> = MockData.initialSupplyOrders,
    val ledgers: List<InventoryLedger> = emptyList(),
    val auditLogs: List<AuditLog> = emptyList(),
    val notifications: List<Notification> = MockData.initialNotifications,
    
    // UI 导航
    val currentScreen: Screen = Screen.Login,
    val screenHistory: List<Screen> = emptyList(),
    
    // 模拟POS状态
    val posCart: List<CartItem> = emptyList(),
    val posAgeVerificationStatus: AgeVerificationStatus = AgeVerificationStatus.UNVERIFIED,
    val posVerifiedAge: Int? = null,
    val posTransactionStatus: TransactionStatus = TransactionStatus.DRAFT,
    val posActiveTransaction: PosTransaction? = null,
    val posSelectedVerificationMethod: String = "扫描实名条码",
    
    // 模拟时钟与状态
    val simulatedTime: Date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2026-09-19 05:00:00"),
    val isSimulationRunning: Boolean = true,
    val simulationSpeedSecs: Int = 10, // 真实时间每多少秒触发一次心跳
    val clockMultiplierMinutes: Int = 15 // 每次心跳推进模拟时间多少分钟
)

object SimulationEngine {
    private val _state = MutableStateFlow(YanshiState())
    val state: StateFlow<YanshiState> = _state.asStateFlow()

    private var simJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    init {
        // 自动初始化一些默认审计日志和库存流水
        resetSimulation()
        startSimulationLoop()
    }

    fun startSimulationLoop() {
        simJob?.cancel()
        simJob = scope.launch {
            while (isActive) {
                delay(state.value.simulationSpeedSecs * 1000L)
                if (state.value.isSimulationRunning) {
                    triggerHeartbeat()
                }
            }
        }
    }

    fun pauseSimulation() {
        _state.update { it.copy(isSimulationRunning = false) }
        logAudit("系统", "暂停了后台自动运营模拟心跳", "系统设置", "成功", "时钟暂停")
    }

    fun resumeSimulation() {
        _state.update { it.copy(isSimulationRunning = true) }
        logAudit("系统", "启用了后台自动运营模拟心跳", "系统设置", "成功", "时钟恢复")
    }

    fun setSimulationSpeed(seconds: Int) {
        _state.update { it.copy(simulationSpeedSecs = seconds) }
        startSimulationLoop() // 重启循环
    }

    fun setScreen(screen: Screen) {
        _state.update {
            val history = it.screenHistory.toMutableList()
            if (it.currentScreen != Screen.Login) {
                history.add(it.currentScreen)
            }
            it.copy(currentScreen = screen, screenHistory = history)
        }
        logAudit(state.value.currentRole.label, "导航至页面: ${screen.title}", screen.title, "成功", "页面切换")
    }

    fun goBack() {
        _state.update {
            if (it.screenHistory.isNotEmpty()) {
                val history = it.screenHistory.toMutableList()
                val prev = history.removeAt(history.size - 1)
                it.copy(currentScreen = prev, screenHistory = history)
            } else {
                it.copy(currentScreen = Screen.Dashboard)
            }
        }
    }

    fun changeUserRole(role: UserRole) {
        _state.update { it.copy(currentRole = role) }
        logAudit("系统", "切换当前操作员角色为 [${role.label}]", "系统设置", "成功", "角色变更")
    }

    fun changeCurrentStore(store: Store) {
        _state.update { it.copy(currentStore = store) }
        logAudit(state.value.currentRole.label, "切换当前管理门店为 [${store.name}]", "运营总览", "成功", "门店切换")
    }

    // ------------------ POS 购物车操作 ------------------
    fun addCartProduct(product: Product) {
        if (!product.isSaleable && product.totalStock <= 0) {
            triggerNotification("库存警告", "无法添加 [${product.name}] 至购物车，当前总库房缺货中！", "库存", RiskLevel.MEDIUM)
            return
        }
        _state.update { s ->
            val existing = s.posCart.find { it.product.id == product.id }
            val newCart = if (existing != null) {
                s.posCart.map {
                    if (it.product.id == product.id) it.copy(quantity = it.quantity + 1) else it
                }
            } else {
                s.posCart + CartItem(product, 1)
            }
            
            // 如果需要年龄验证
            val needsAgeCheck = newCart.any { it.product.isAgeRestricted }
            val transStatus = if (needsAgeCheck && s.posAgeVerificationStatus != AgeVerificationStatus.VERIFIED) {
                TransactionStatus.AGE_CHECK_REQUIRED
            } else {
                TransactionStatus.READY_FOR_SIMULATION
            }

            s.copy(
                posCart = newCart,
                posTransactionStatus = transStatus
            )
        }
    }

    fun removeCartProduct(product: Product) {
        _state.update { s ->
            val newCart = s.posCart.filter { it.product.id != product.id }
            val needsAgeCheck = newCart.any { it.product.isAgeRestricted }
            val transStatus = if (newCart.isEmpty()) {
                TransactionStatus.DRAFT
            } else if (needsAgeCheck && s.posAgeVerificationStatus != AgeVerificationStatus.VERIFIED) {
                TransactionStatus.AGE_CHECK_REQUIRED
            } else {
                TransactionStatus.READY_FOR_SIMULATION
            }
            s.copy(posCart = newCart, posTransactionStatus = transStatus)
        }
    }

    fun updateCartQuantity(product: Product, quantity: Int) {
        if (quantity <= 0) {
            removeCartProduct(product)
            return
        }
        _state.update { s ->
            val newCart = s.posCart.map {
                if (it.product.id == product.id) it.copy(quantity = quantity) else it
            }
            s.copy(posCart = newCart)
        }
    }

    fun clearCart() {
        _state.update { s ->
            s.copy(
                posCart = emptyList(),
                posAgeVerificationStatus = AgeVerificationStatus.UNVERIFIED,
                posVerifiedAge = null,
                posTransactionStatus = TransactionStatus.DRAFT,
                posActiveTransaction = null
            )
        }
    }

    fun setPOSVerificationMethod(method: String) {
        _state.update { it.copy(posSelectedVerificationMethod = method) }
    }

    // 模拟实名核验触发
    fun submitPOSAgeCheck(birthYear: Int, birthMonth: Int, birthDay: Int, demoMode: String) {
        _state.update { s ->
            val cal = Calendar.getInstance()
            val curYear = cal.get(Calendar.YEAR)
            val curMonth = cal.get(Calendar.MONTH) + 1
            val curDay = cal.get(Calendar.DAY_OF_MONTH)
            
            var age = curYear - birthYear
            if (curMonth < birthMonth || (curMonth == birthMonth && curDay < birthDay)) {
                age--
            }

            val resultStatus = when (demoMode) {
                "SUCCESS" -> {
                    if (age >= 18) AgeVerificationStatus.VERIFIED else AgeVerificationStatus.VERIFICATION_FAILED
                }
                "FAIL" -> AgeVerificationStatus.VERIFICATION_FAILED
                "MANUAL" -> AgeVerificationStatus.MANUAL_REVIEW
                else -> AgeVerificationStatus.VERIFICATION_FAILED
            }

            val newTransStatus = if (resultStatus == AgeVerificationStatus.VERIFIED) {
                TransactionStatus.READY_FOR_SIMULATION
            } else if (resultStatus == AgeVerificationStatus.MANUAL_REVIEW) {
                TransactionStatus.COMPLIANCE_REVIEW
            } else {
                TransactionStatus.BLOCKED
            }

            // 如果验证失败，立刻向合规中心写入高风险警报事件
            if (resultStatus == AgeVerificationStatus.VERIFICATION_FAILED) {
                val newEvent = ComplianceEvent(
                    id = "CP-${System.currentTimeMillis() % 10000}",
                    timestamp = getFormattedSimulatedTime(),
                    storeId = s.currentStore.id,
                    storeName = s.currentStore.name,
                    type = ComplianceEventType.AGE_CHECK_FAILED,
                    riskLevel = RiskLevel.HIGH,
                    status = "待处理",
                    details = "POS终端实名验证拦截。录入虚构出生日期为：$birthYear-$birthMonth-$birthDay (核验时年龄 $age 岁)。系统自动拒绝该单交易，并锁定终端收银台。",
                    operatorRole = "收银员",
                    notes = "需合规审核员进行线上人工审核或实名流程重置。",
                    auditTrail = listOf("${getFormattedSimulatedTime()} - POS拦截异常", "系统拦截不合规年龄：$age 岁")
                )
                
                triggerNotification("合规预警", "[${s.currentStore.name}] 发生一起年龄核验未通过拦截，已锁单！", "合规", RiskLevel.HIGH)
                logAudit("POS系统", "拦截不合规年龄交易（出生日期：$birthYear-$birthMonth-$birthDay），交易已冻结", "模拟POS", "拦截", "年龄不符")
                
                s.copy(
                    posAgeVerificationStatus = resultStatus,
                    posVerifiedAge = age,
                    posTransactionStatus = TransactionStatus.BLOCKED,
                    complianceEvents = listOf(newEvent) + s.complianceEvents
                )
            } else if (resultStatus == AgeVerificationStatus.MANUAL_REVIEW) {
                val newEvent = ComplianceEvent(
                    id = "CP-${System.currentTimeMillis() % 10000}",
                    timestamp = getFormattedSimulatedTime(),
                    storeId = s.currentStore.id,
                    storeName = s.currentStore.name,
                    type = ComplianceEventType.PRIVILEGE_ABUSE,
                    riskLevel = RiskLevel.MEDIUM,
                    status = "待处理",
                    details = "顾客提供异地特殊身份证件（虚构出生日期 $birthYear-$birthMonth-$birthDay），POS终端触发‘待人工复核’。等待合规审计中心双人核签。",
                    operatorRole = "收银员",
                    notes = "已挂起交易，待合规后台审核。",
                    auditTrail = listOf("${getFormattedSimulatedTime()} - 发起人工挂起审核")
                )
                triggerNotification("合规提醒", "[${s.currentStore.name}] 提交了一笔待人工审核的特殊身份证交易。", "合规", RiskLevel.MEDIUM)
                logAudit("POS系统", "特殊证件人工挂载审核申请", "模拟POS", "警告", "待人工复核")
                
                s.copy(
                    posAgeVerificationStatus = resultStatus,
                    posVerifiedAge = age,
                    posTransactionStatus = TransactionStatus.COMPLIANCE_REVIEW,
                    complianceEvents = listOf(newEvent) + s.complianceEvents
                )
            } else {
                logAudit("POS系统", "成年人实名核验成功，验证年龄 $age 岁。批准后续支付。", "模拟POS", "成功", "年龄核验通过")
                s.copy(
                    posAgeVerificationStatus = resultStatus,
                    posVerifiedAge = age,
                    posTransactionStatus = TransactionStatus.READY_FOR_SIMULATION
                )
            }
        }
    }

    // 完成POS演示交易支付
    fun confirmPOSPayment() {
        _state.update { s ->
            if (s.posCart.isEmpty()) return@update s
            
            val totalAmt = s.posCart.sumOf { it.product.referencePrice * it.quantity }
            
            // 1. 扣减商品总库存及本地可售库存
            val updatedProducts = s.products.map { p ->
                val cartItem = s.posCart.find { it.product.id == p.id }
                if (cartItem != null) {
                    val remainingStock = (p.totalStock - cartItem.quantity).coerceAtLeast(0)
                    p.copy(
                        totalStock = remainingStock,
                        status = if (remainingStock == 0) ProductStatus.SUSPENDED else p.status
                    )
                } else p
            }

            // 2. 更新当前门店今日销售额与交易笔数
            val updatedStores = s.stores.map { st ->
                if (st.id == s.currentStore.id) {
                    st.copy(
                        todaySales = st.todaySales + totalAmt,
                        todayTransactions = st.todayTransactions + 1
                    )
                } else st
            }

            // 3. 生成销售流水Ledger
            val newLedgers = s.posCart.map { cartItem ->
                InventoryLedger(
                    id = "LG-${System.currentTimeMillis() % 100000 + cartItem.product.id.hashCode() % 1000}",
                    timestamp = getFormattedSimulatedTime(),
                    storeId = s.currentStore.id,
                    storeName = s.currentStore.name,
                    productId = cartItem.product.id,
                    productName = cartItem.product.name,
                    type = "出库 (POS销售)",
                    quantityChange = -cartItem.quantity,
                    beforeQty = cartItem.product.totalStock,
                    afterQty = (cartItem.product.totalStock - cartItem.quantity).coerceAtLeast(0),
                    operator = s.currentRole.label,
                    notes = "POS收银模拟支付。验证模式：${s.posSelectedVerificationMethod}"
                )
            }

            val txId = "TX-2026-${System.currentTimeMillis() % 100000}"
            val auditLogId = "AD-${System.currentTimeMillis() % 100000}"

            val finishedTransaction = PosTransaction(
                id = txId,
                timestamp = getFormattedSimulatedTime(),
                storeId = s.currentStore.id,
                cashierName = s.currentRole.label,
                items = s.posCart,
                totalAmount = totalAmt,
                status = TransactionStatus.COMPLETED_DEMO,
                ageVerificationMethod = s.posSelectedVerificationMethod,
                complianceFlags = listOf("年龄已通过核验", "完税虚拟凭证印花", "演示系统·不涉及真实款项"),
                demoReceiptPrinted = true,
                auditId = auditLogId
            )

            // 如果有大额大单，记录一个合规事件（反囤货代购）
            val newComplianceEvents = s.complianceEvents.toMutableList()
            if (totalAmt >= 1000.0) {
                val bulkEvent = ComplianceEvent(
                    id = "CP-${System.currentTimeMillis() % 10000}",
                    timestamp = getFormattedSimulatedTime(),
                    storeId = s.currentStore.id,
                    storeName = s.currentStore.name,
                    type = ComplianceEventType.OVER_LIMIT_SALE,
                    riskLevel = RiskLevel.MEDIUM,
                    status = "已合规归档",
                    details = "POS触发大额零售合规限额自动备案。总金额 ¥$totalAmt，购买商品包含：${s.posCart.joinToString { "${it.product.name}x${it.quantity}" }}。系统已自动限制单张身份证当日重复限售。",
                    operatorRole = "收银员",
                    notes = "符合专营限购额度，自动归档备案。",
                    auditTrail = listOf("${getFormattedSimulatedTime()} - 额度备案记录", "${getFormattedSimulatedTime()} - 白名单匹配通过")
                )
                newComplianceEvents.add(0, bulkEvent)
                triggerNotification("大额交易备案", "[${s.currentStore.name}] 发生一笔价值 ¥$totalAmt 的大额合规备案记录。", "合规", RiskLevel.LOW)
            }

            // 写入审计日志
            val newAudit = AuditLog(
                id = auditLogId,
                timestamp = getFormattedSimulatedTime(),
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "完成POS零售交易模拟 $txId",
                pageAffected = "模拟POS",
                status = "成功",
                details = "完成合成商品交易：合计金额 ¥$totalAmt，扣减库存流水完毕。该笔交易不绑定任何真实财务接口。"
            )

            s.copy(
                products = updatedProducts,
                stores = updatedStores,
                ledgers = newLedgers + s.ledgers,
                complianceEvents = newComplianceEvents,
                auditLogs = listOf(newAudit) + s.auditLogs,
                posActiveTransaction = finishedTransaction,
                posTransactionStatus = TransactionStatus.COMPLETED_DEMO,
                currentStore = updatedStores.first { it.id == s.currentStore.id }
            )
        }
    }

    // ------------------ 供应链与补货 ------------------
    fun requestRestock(productId: String, qty: Int) {
        _state.update { s ->
            val product = s.products.find { it.id == productId } ?: return@update s
            val orderId = "SC-RESTOCK-${System.currentTimeMillis() % 100000}"
            
            val newOrder = SupplyChainOrder(
                id = orderId,
                creationTime = getFormattedSimulatedTime(),
                supplier = product.supplier,
                destinationStoreId = s.currentStore.id,
                destinationStoreName = s.currentStore.name,
                itemsCount = qty,
                totalAmount = product.referencePrice * qty * 0.7, // 进货价按7折计算
                status = TransitStatus.ORDERED,
                carrier = "德邦高端专配",
                eta = getFormattedDateOffset(1), // 明日送达
                routeDesc = "供应商工厂仓库 -> [${s.currentStore.city}] 配送点 -> [${s.currentStore.name}]"
            )

            val newAudit = AuditLog(
                id = "AD-${System.currentTimeMillis() % 100000}",
                timestamp = getFormattedSimulatedTime(),
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "发起商品 [${product.name}] 紧急进货申请 $qty 件",
                pageAffected = "物资采购补货",
                status = "成功",
                details = "向供应商 [${product.supplier}] 订购商品合计进货模拟款 ¥${product.referencePrice * qty * 0.7} 元。"
            )

            triggerNotification("补货下单", "已成功向供应商提交 [${product.name}] 补货单，货量 $qty 件。", "物流", RiskLevel.INFO)

            s.copy(
                supplyOrders = listOf(newOrder) + s.supplyOrders,
                auditLogs = listOf(newAudit) + s.auditLogs
            )
        }
    }

    fun approveStoreTransfer(fromStoreId: String, toStoreId: String, productId: String, qty: Int) {
        _state.update { s ->
            val product = s.products.find { it.id == productId } ?: return@update s
            val fromStore = s.stores.find { it.id == fromStoreId } ?: return@update s
            val toStore = s.stores.find { it.id == toStoreId } ?: return@update s

            // 生成调拨供应链物流单
            val orderId = "SC-TRANSFER-${System.currentTimeMillis() % 100000}"
            val newOrder = SupplyChainOrder(
                id = orderId,
                creationTime = getFormattedSimulatedTime(),
                supplier = "门店自调拨 [${fromStore.name}]",
                destinationStoreId = toStoreId,
                destinationStoreName = toStore.name,
                itemsCount = qty,
                totalAmount = 0.0, // 调拨不计进销成本
                status = TransitStatus.CONFIRMED,
                carrier = "同城闪送急速专专专线",
                eta = getFormattedDateOffset(0) + " 18:00 (今日极速)",
                routeDesc = "出发地：[${fromStore.name}] -> 目的地：[${toStore.name}]"
            )

            // 扣减调拨出库方库存
            val updatedProducts = s.products.map { p ->
                if (p.id == productId) {
                    p.copy(totalStock = (p.totalStock - qty).coerceAtLeast(0))
                } else p
            }

            // 写调拨出库方流水
            val ledgerOut = InventoryLedger(
                id = "LG-TR-OUT-${System.currentTimeMillis() % 100000}",
                timestamp = getFormattedSimulatedTime(),
                storeId = fromStoreId,
                storeName = fromStore.name,
                productId = productId,
                productName = product.name,
                type = "出库 (调拨调出)",
                quantityChange = -qty,
                beforeQty = product.totalStock,
                afterQty = (product.totalStock - qty).coerceAtLeast(0),
                operator = s.currentRole.label,
                notes = "调拨申请 $orderId，目的地：${toStore.name}"
            )

            // 写入审计日志
            val newAudit = AuditLog(
                id = "AD-${System.currentTimeMillis() % 100000}",
                timestamp = getFormattedSimulatedTime(),
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "批准跨店库存调拨",
                pageAffected = "调拨与补货",
                status = "成功",
                details = "同意将 [${fromStore.name}] 的商品 [${product.name}] 共计 $qty 件紧急调拨转移至 [${toStore.name}]。"
            )

            triggerNotification("库存调拨", "已启动 [${fromStore.name}] ➡️ [${toStore.name}] 的 $qty 件商品同城调配！", "物流", RiskLevel.INFO)

            s.copy(
                products = updatedProducts,
                supplyOrders = listOf(newOrder) + s.supplyOrders,
                ledgers = listOf(ledgerOut) + s.ledgers,
                auditLogs = listOf(newAudit) + s.auditLogs
            )
        }
    }

    fun approveSupplyOrder(orderId: String) {
        _state.update { s ->
            val updatedOrders = s.supplyOrders.map { order ->
                if (order.id == orderId) {
                    order.copy(status = TransitStatus.DELIVERED)
                } else order
            }

            val targetOrder = s.supplyOrders.find { it.id == orderId }
            val timeStr = getFormattedSimulatedTime()

            val updatedProducts = if (targetOrder != null) {
                val matchProd = s.products.find { it.supplier == targetOrder.supplier } ?: s.products.first()
                s.products.map { p ->
                    if (p.id == matchProd.id) {
                        p.copy(totalStock = p.totalStock + targetOrder.itemsCount * 5)
                    } else p
                }
            } else s.products

            val newAudit = AuditLog(
                id = "AD-${System.currentTimeMillis() % 100000}",
                timestamp = timeStr,
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "人工接车核签直配订单 $orderId",
                pageAffected = "在途物流控制台",
                status = "成功",
                details = "直配车辆抵店卸货，经收货人清点核对，恒温仓传感器指标合格，增配入库完毕。"
            )

            triggerNotification("物流送达", "直供补货单 $orderId 已清点核签通过并妥投！", "物流", RiskLevel.INFO)

            s.copy(
                supplyOrders = updatedOrders,
                products = updatedProducts,
                auditLogs = listOf(newAudit) + s.auditLogs
            )
        }
    }

    // ------------------ 异常与合规处理 ------------------
    fun resolveComplianceEvent(eventId: String, notes: String) {
        _state.update { s ->
            val updatedEvents = s.complianceEvents.map { ev ->
                if (ev.id == eventId) {
                    val trails = ev.auditTrail.toMutableList()
                    trails.add("${getFormattedSimulatedTime()} - 合规员 [${s.currentRole.label}] 处理归档")
                    ev.copy(
                        status = "已合规归档",
                        notes = notes,
                        auditTrail = trails
                    )
                } else ev
            }

            val newAudit = AuditLog(
                id = "AD-${System.currentTimeMillis() % 100000}",
                timestamp = getFormattedSimulatedTime(),
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "合规审批归档事件 $eventId",
                pageAffected = "合规中心",
                status = "成功",
                details = "合规专家已审核事件详情并归档，核签意见：$notes"
            )

            s.copy(
                complianceEvents = updatedEvents,
                auditLogs = listOf(newAudit) + s.auditLogs
            )
        }
    }

    fun approveMemberManualReview(memberId: String) {
        _state.update { s ->
            val updatedMembers = s.members.map { mb ->
                if (mb.id == memberId) {
                    val trails = mb.auditTrail.toMutableList()
                    trails.add("${getFormattedSimulatedTime()} - 合规中心人工核实通过")
                    mb.copy(
                        ageVerificationStatus = AgeVerificationStatus.VERIFIED,
                        auditTrail = trails
                    )
                } else mb
            }

            val newAudit = AuditLog(
                id = "AD-${System.currentTimeMillis() % 100000}",
                timestamp = getFormattedSimulatedTime(),
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "人工审批通过会员年龄实名身份 MB-$memberId",
                pageAffected = "成年人会员服务",
                status = "成功",
                details = "人工核实会员提供的证件照片影像，证实年龄符合要求，解除系统冻结状态。"
            )

            s.copy(
                members = updatedMembers,
                auditLogs = listOf(newAudit) + s.auditLogs
            )
        }
    }

    fun registerNewMember(name: String, phone: String, dob: String) {
        _state.update { s ->
            val birthDate = try {
                SimpleDateFormat("yyyy-MM-dd").parse(dob) ?: Date()
            } catch (e: Exception) {
                Date()
            }
            val ageMs = System.currentTimeMillis() - birthDate.time
            val ageYears = (ageMs / (1000L * 60 * 60 * 24 * 365)).toInt().coerceAtLeast(0)
            
            val newMember = Member(
                id = "MB-${System.currentTimeMillis() % 10000}",
                name = name,
                phoneMasked = if (phone.length >= 11) phone.take(3) + "****" + phone.takeLast(4) else phone,
                ageVerificationStatus = if (ageYears >= 18) AgeVerificationStatus.VERIFIED else AgeVerificationStatus.VERIFICATION_FAILED,
                verifiedAge = ageYears,
                registrationDate = getFormattedSimulatedTime().split(" ")[0],
                level = "雅仕级",
                commonStoreId = s.currentStore.id,
                preferences = "未登记偏好",
                isDataSharingConsent = true,
                auditTrail = listOf("${getFormattedSimulatedTime()} - 公安介质实名注册成功")
            )
            
            val newAudit = AuditLog(
                id = "AD-${System.currentTimeMillis() % 100000}",
                timestamp = getFormattedSimulatedTime(),
                operator = s.currentRole.label,
                role = s.currentRole,
                action = "实名注册新雅仕会员 ${newMember.id}",
                pageAffected = "成年人会员服务",
                status = "成功",
                details = "录入实名顾客 ${newMember.name}，脱敏手机 ${newMember.phoneMasked}，系统计算年龄 $ageYears 岁。"
            )
            
            s.copy(
                members = s.members + newMember,
                auditLogs = listOf(newAudit) + s.auditLogs
            )
        }
    }

    // ------------------ 系统控制与重置 ------------------
    fun resetSimulation() {
        val defaultDate = SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse("2026-09-19 05:00:00")
        
        // 自动初始化一些默认流水和审计记录，使图表和历史不为空
        val initLedgers = listOf(
            InventoryLedger("LG-001", "2026-09-18 10:30", "ST-01", "上海新天地专营旗舰店", "PD-1001", "烟仕·东方锦绣", "入库 (供应商到货)", 500, 700, 1200, "系统管理员", "定期周配补货到货签收"),
            InventoryLedger("LG-002", "2026-09-18 14:00", "ST-01", "上海新天地专营旗舰店", "PD-1003", "烟仕·沪上风华", "出库 (模拟销售)", -10, 50, 40, "收银员", "大宗企业客户演示售出"),
            InventoryLedger("LG-003", "2026-09-19 02:30", "ST-03", "深圳湾万象城现代体验店", "PD-1002", "烟仕·江南竹韵", "入库 (调拨接收)", 100, 750, 850, "库管员", "从广州太古汇调出紧急入库")
        )

        val initAudits = listOf(
            AuditLog("AD-001", "2026-09-19 00:01", "系统核心", UserRole.ADMIN, "重置数据模拟环境", "系统设置", "成功", "初始化所有合成商业数据、虚构店铺及初始合规记录。"),
            AuditLog("AD-002", "2026-09-19 01:05", "王文墨", UserRole.STORE_MANAGER, "安全自查设备打卡", "门店管理", "成功", "北京国贸三期店提交消防与合规检测安全认证打卡。"),
            AuditLog("AD-003", "2026-09-19 03:00", "合规自动监视", UserRole.COMPLIANCE_AUDITOR, "全局许可证期效轮询", "合规中心", "成功", "扫视全国10个专营门店，发现 ST-02 证件临期，ST-09 证件已到期，发出高优先级预警。")
        )

        _state.value = YanshiState(
            currentRole = UserRole.ADMIN,
            currentStore = MockData.initialStores.first(),
            stores = MockData.initialStores,
            products = MockData.initialProducts,
            members = MockData.initialMembers,
            complianceEvents = MockData.initialComplianceEvents,
            supplyOrders = MockData.initialSupplyOrders,
            ledgers = initLedgers,
            auditLogs = initAudits,
            notifications = MockData.initialNotifications,
            currentScreen = Screen.Login,
            screenHistory = emptyList(),
            posCart = emptyList(),
            posAgeVerificationStatus = AgeVerificationStatus.UNVERIFIED,
            posVerifiedAge = null,
            posTransactionStatus = TransactionStatus.DRAFT,
            simulatedTime = defaultDate,
            isSimulationRunning = true
        )
        
        startSimulationLoop()
    }

    fun advanceTimeManual() {
        triggerHeartbeat()
    }

    // ------------------ 辅助函数 ------------------
    private fun getFormattedSimulatedTime(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm").format(state.value.simulatedTime)
    }

    private fun getFormattedDateOffset(days: Int): String {
        val cal = Calendar.getInstance()
        cal.time = state.value.simulatedTime
        cal.add(Calendar.DAY_OF_YEAR, days)
        return SimpleDateFormat("yyyy-MM-dd").format(cal.time)
    }

    private fun logAudit(operator: String, action: String, page: String, status: String, details: String) {
        val newLog = AuditLog(
            id = "AD-${System.currentTimeMillis() % 100000}",
            timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm").format(state.value.simulatedTime),
            operator = operator,
            role = state.value.currentRole,
            action = action,
            pageAffected = page,
            status = status,
            details = details
        )
        _state.update { it.copy(auditLogs = listOf(newLog) + it.auditLogs) }
    }

    private fun triggerNotification(title: String, content: String, category: String, priority: RiskLevel) {
        val newNotification = Notification(
            id = "NT-${System.currentTimeMillis() % 10000}",
            timestamp = SimpleDateFormat("HH:mm").format(state.value.simulatedTime),
            title = title,
            content = content,
            category = category,
            priority = priority
        )
        _state.update { it.copy(notifications = listOf(newNotification) + it.notifications) }
    }

    // ------------------ 模拟引擎：心跳驱动 ------------------
    private fun triggerHeartbeat() {
        _state.update { s ->
            // 1. 推进模拟时钟
            val cal = Calendar.getInstance()
            cal.time = s.simulatedTime
            cal.add(Calendar.MINUTE, s.clockMultiplierMinutes)
            val nextTime = cal.time

            // 格式化时间字符串以记录
            val timeStr = SimpleDateFormat("yyyy-MM-dd HH:mm").format(nextTime)

            // 2. 模拟今日各门店客流随机自然增加 (+1 ~ +4)
            val updatedStores = s.stores.map { st ->
                if (st.status == StoreStatus.OPEN) {
                    val addTraffic = (1..4).random()
                    st.copy(currentTraffic = (st.currentTraffic + addTraffic).coerceAtMost(35))
                } else st
            }

            // 3. 模拟后台自动下单/购买事件 (15% 概率)
            var currentProducts = s.products
            var finalStores = updatedStores
            val ledgerList = s.ledgers.toMutableList()
            val auditList = s.auditLogs.toMutableList()
            val complEvents = s.complianceEvents.toMutableList()
            val supplyList = s.supplyOrders.toMutableList()

            val randomVal = (1..100).random()
            if (randomVal <= 15) {
                // 选择一家随机开店
                val openStoreList = updatedStores.filter { it.status == StoreStatus.OPEN }
                if (openStoreList.isNotEmpty()) {
                    val targetStore = openStoreList.random()
                    
                    // 挑选随机在售商品
                    val saleable = currentProducts.filter { it.isSaleable && it.totalStock > 0 }
                    if (saleable.isNotEmpty()) {
                        val product = saleable.random()
                        val buyQty = (1..3).random()
                        val total = product.referencePrice * buyQty

                        // 扣减库存
                        currentProducts = currentProducts.map { p ->
                            if (p.id == product.id) {
                                val newSt = (p.totalStock - buyQty).coerceAtLeast(0)
                                p.copy(totalStock = newSt, status = if (newSt == 0) ProductStatus.SUSPENDED else p.status)
                            } else p
                        }

                        // 更新该门店销售额
                        finalStores = updatedStores.map { st ->
                            if (st.id == targetStore.id) {
                                st.copy(
                                    todaySales = st.todaySales + total,
                                    todayTransactions = st.todayTransactions + 1
                                )
                            } else st
                        }

                        // 写流水记录
                        val lId = "LG-${System.currentTimeMillis() % 100000 + (1..99).random()}"
                        ledgerList.add(0, InventoryLedger(
                            id = lId,
                            timestamp = timeStr,
                            storeId = targetStore.id,
                            storeName = targetStore.name,
                            productId = product.id,
                            productName = product.name,
                            type = "出库 (模拟销售)",
                            quantityChange = -buyQty,
                            beforeQty = product.totalStock,
                            afterQty = (product.totalStock - buyQty).coerceAtLeast(0),
                            operator = "AI仿真交易",
                            notes = "仿真背景交易。验证模式：实名条码自动核验"
                        ))

                        auditList.add(0, AuditLog(
                            id = "AD-${System.currentTimeMillis() % 100000}",
                            timestamp = timeStr,
                            operator = "AI仿真引擎",
                            role = UserRole.OBSERVER,
                            action = "模拟生成一笔背景消费。门店 [${targetStore.name}]",
                            pageAffected = "销售终端",
                            status = "成功",
                            details = "虚拟顾客成功购买商品 [${product.name}] $buyQty 件，流水号 $lId。金额 ¥$total"
                        ))
                    }
                }
            }

            // 4. 模拟在途供应链到货事件 (20% 概率将一个 ORDERED/DISPATCHED 变成 IN_TRANSIT 或 DELIVERED)
            val modifiedSupplyList = supplyList.map { order ->
                if (order.status == TransitStatus.IN_TRANSIT && (1..100).random() <= 20) {
                    // 到货了！
                    val matchingProduct = currentProducts.find { p -> p.supplier == order.supplier || p.name.contains(order.destinationStoreName.substring(0, 2)) || (1..3).random() == 1 } 
                    val prodToDeliver = matchingProduct ?: currentProducts.first()
                    
                    // 增加门店的库存
                    currentProducts = currentProducts.map { p ->
                        if (p.id == prodToDeliver.id) {
                            p.copy(totalStock = p.totalStock + order.itemsCount)
                        } else p
                    }

                    // 写到货流水
                    ledgerList.add(0, InventoryLedger(
                        id = "LG-DELIVERY-${System.currentTimeMillis() % 100000}",
                        timestamp = timeStr,
                        storeId = order.destinationStoreId,
                        storeName = order.destinationStoreName,
                        productId = prodToDeliver.id,
                        productName = prodToDeliver.name,
                        type = "入库 (供应链送达)",
                        quantityChange = order.itemsCount,
                        beforeQty = prodToDeliver.totalStock,
                        afterQty = prodToDeliver.totalStock + order.itemsCount,
                        operator = "顺丰特惠精运",
                        notes = "供应链补货单签收送达：单号 ${order.id}"
                    ))

                    auditList.add(0, AuditLog(
                        id = "AD-${System.currentTimeMillis() % 100000}",
                        timestamp = timeStr,
                        operator = "物资到港检测",
                        role = UserRole.INVENTORY_CLERK,
                        action = "签收供应链补货单 ${order.id}",
                        pageAffected = "供应链控制台",
                        status = "成功",
                        details = "补货商品 [${prodToDeliver.name}] 合计 ${order.itemsCount} 件正式入库门店 [${order.destinationStoreName}]。"
                    ))

                    // 通知
                    triggerNotification("补货送达", "补货单 [${order.id}] 已安全运抵 [${order.destinationStoreName}] 并完成盘点入库！", "物流", RiskLevel.INFO)

                    order.copy(status = TransitStatus.DELIVERED, eta = "已送达 $timeStr")
                } else if (order.status == TransitStatus.ORDERED && (1..100).random() <= 30) {
                    order.copy(status = TransitStatus.DISPATCHED)
                } else order
            }

            // 5. 模拟小概率合规随机风险事件 (5% 概率)
            if ((1..100).random() <= 5) {
                val types = ComplianceEventType.values()
                val rType = types.filter { it != ComplianceEventType.LICENSE_EXPIRING }.random()
                val randomStore = finalStores.random()
                val levels = listOf(RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH)
                val rLevel = if (rType == ComplianceEventType.AGE_CHECK_FAILED) RiskLevel.HIGH else levels.random()

                val details = when (rType) {
                    ComplianceEventType.AGE_CHECK_FAILED -> "合成顾客尝试在 [${randomStore.name}] POS付款。身份核验不一致，系统已强制取消结算流程。"
                    ComplianceEventType.REPEATED_ATTEMPTS -> "在 [${randomStore.name}] 出现单张演示身份证频繁刷卡失败。疑似系统握手掉线或重复持卡测试。"
                    ComplianceEventType.STOCK_ANOMALY -> "后台巡查发现：[${randomStore.name}] 自查上报中，「烟仕·东方锦绣」账面库存与现场红外监控货架盘点读数差额2盒。"
                    ComplianceEventType.DEVICE_FAULT -> "门店 [${randomStore.name}] 离线防火温控探头发出信号不一致，疑似进入巡检模式。"
                    ComplianceEventType.PRIVILEGE_ABUSE -> "收银终端前台尝试越权进入 [价格修改/许可证变更] 后台管理页面，操作已自动被合规拦截。"
                    else -> "门店自查常规合规测试事件备案。"
                }

                val cId = "CP-${System.currentTimeMillis() % 10000 + (1..99).random()}"
                val newEvent = ComplianceEvent(
                    id = cId,
                    timestamp = timeStr,
                    storeId = randomStore.id,
                    storeName = randomStore.name,
                    type = rType,
                    riskLevel = rLevel,
                    status = "待处理",
                    details = details,
                    operatorRole = "AI仿真引擎",
                    notes = "等待合规审计员处理。",
                    auditTrail = listOf("$timeStr - 警报事件自动创建并推送合规控制中心")
                )

                complEvents.add(0, newEvent)
                triggerNotification("合规警报", "门店 [${randomStore.name}] 触发 [${rType.label}] 级别，急需处理！", "合规", rLevel)
                
                auditList.add(0, AuditLog(
                    id = "AD-${System.currentTimeMillis() % 100000}",
                    timestamp = timeStr,
                    operator = "全时合规监视器",
                    role = UserRole.COMPLIANCE_AUDITOR,
                    action = "生成合规事件警报 $cId",
                    pageAffected = "合规中心",
                    status = "警告",
                    details = "[${randomStore.name}] 发现异常状况：$details"
                ))
            }

            s.copy(
                simulatedTime = nextTime,
                stores = finalStores,
                products = currentProducts,
                ledgers = ledgerList,
                auditLogs = auditList,
                complianceEvents = complEvents,
                supplyOrders = modifiedSupplyList
            )
        }
    }
}
