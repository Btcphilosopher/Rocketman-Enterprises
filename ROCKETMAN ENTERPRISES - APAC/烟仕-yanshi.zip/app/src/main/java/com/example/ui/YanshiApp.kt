package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.Screen
import com.example.engine.SimulationEngine
import com.example.ui.screens.*
import com.example.ui.theme.*

@Composable
fun YanshiApp() {
    val state by SimulationEngine.state.collectAsState()
    val configuration = LocalConfiguration.current
    val isWide = configuration.screenWidthDp > 720

    // 如果处于登入屏幕，展示登入界面
    if (state.currentScreen is Screen.Login) {
        LoginScreen()
    } else {
        Scaffold(
            modifier = Modifier.fillMaxSize(),
            contentWindowInsets = WindowInsets.navigationBars
        ) { innerPadding ->
            if (isWide) {
                // 宽屏平板/桌面端布局
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(WarmPaper)
                ) {
                    // 左侧高端侧边栏
                    YanshiSidebar(
                        currentScreen = state.currentScreen,
                        onNavigate = { SimulationEngine.setScreen(it) },
                        modifier = Modifier
                            .width(240.dp)
                            .fillMaxHeight()
                    )

                    // 右侧主屏
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .background(WarmPaper)
                    ) {
                        AnimatedContent(
                            targetState = state.currentScreen,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            }
                        ) { targetScreen ->
                            RenderScreen(targetScreen)
                        }
                    }
                }
            } else {
                // 窄屏/竖屏移动端布局
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(WarmPaper)
                ) {
                    YanshiCompactHeader()

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        AnimatedContent(
                            targetState = state.currentScreen,
                            transitionSpec = {
                                fadeIn() togetherWith fadeOut()
                            }
                        ) { targetScreen ->
                            RenderScreen(targetScreen)
                        }
                    }

                    YanshiCompactBottomBar(
                        currentScreen = state.currentScreen,
                        onNavigate = { SimulationEngine.setScreen(it) }
                    )
                }
            }
        }
    }
}

// 导航项定义
data class NavItem(
    val screen: Screen,
    val label: String,
    val icon: ImageVector
)

val NavigationItems = listOf(
    NavItem(Screen.Dashboard, "控制中心", Icons.Default.Dashboard),
    NavItem(Screen.Catalog, "精品目录", Icons.Default.ShoppingBag),
    NavItem(Screen.StoreNetwork, "网点孪生", Icons.Default.Business),
    NavItem(Screen.InventoryConsole, "精细库存", Icons.Default.Layers),
    NavItem(Screen.POS, "POS收银", Icons.Default.PointOfSale),
    NavItem(Screen.MemberServices, "雅仕会员", Icons.Default.Badge),
    NavItem(Screen.ComplianceCenter, "合规中心", Icons.Default.Shield),
    NavItem(Screen.SupplyChain, "在途物流", Icons.Default.LocalShipping),
    NavItem(Screen.Analytics, "决策智能", Icons.Default.InsertChart),
    NavItem(Screen.SystemSettings, "系统配置", Icons.Default.Settings)
)

@Composable
fun YanshiSidebar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    val state by SimulationEngine.state.collectAsState()

    Column(
        modifier = modifier
            .background(CharcoalInk)
            .border(BorderStroke(1.dp, AgedBrass)) // 黄铜边缘勾线
            .padding(vertical = 16.dp, horizontal = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        YanshiClassicalSeal(modifier = Modifier.size(50.dp))
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "烟仕 YANSHI",
            color = WarmPaper,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            letterSpacing = 3.sp
        )
        Text(
            text = "专营数字孪生系统",
            color = AgedBrass,
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(top = 2.dp)
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .background(SealRed)
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text("18+ 专营合规", color = WarmPaper, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }

        Divider(color = AgedBrass.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 16.dp))

        // 导航项目列表 (垂直滚动以防屏幕矮)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            NavigationItems.forEach { item ->
                // 精确匹配
                val isSelected = when (item.screen) {
                    is Screen.SystemSettings -> currentScreen is Screen.SystemSettings || currentScreen is Screen.AuditLogs || currentScreen is Screen.DataExport || currentScreen is Screen.StaffPermissions || currentScreen is Screen.Notifications
                    is Screen.InventoryConsole -> currentScreen is Screen.InventoryConsole || currentScreen is Screen.InventoryLedger
                    is Screen.StoreNetwork -> currentScreen is Screen.StoreNetwork || currentScreen is Screen.StoreDetail || currentScreen is Screen.StoreTwin
                    is Screen.ComplianceCenter -> currentScreen is Screen.ComplianceCenter || currentScreen is Screen.RiskEventDetail
                    is Screen.SupplyChain -> currentScreen is Screen.SupplyChain || currentScreen is Screen.Procurement
                    else -> item.screen::class == currentScreen::class
                }
                
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .background(
                            if (isSelected) AgedBrass.copy(alpha = 0.15f) else Color.Transparent,
                            RoundedCornerShape(2.dp)
                        )
                        .border(
                            if (isSelected) BorderStroke(1.dp, AgedBrass) else BorderStroke(0.dp, Color.Transparent)
                        )
                        .clickable { onNavigate(item.screen) }
                        .padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = null,
                        tint = if (isSelected) SealRed else WarmPaper.copy(alpha = 0.7f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = item.label,
                        color = if (isSelected) WarmPaper else WarmPaper.copy(alpha = 0.7f),
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        Divider(color = AgedBrass.copy(alpha = 0.3f), thickness = 1.dp, modifier = Modifier.padding(vertical = 12.dp))

        // 底部店员 & 门店信息
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = "店口: ${state.currentStore.name}",
                color = WarmPaper.copy(alpha = 0.8f),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(6.dp).background(StatusSuccess, RoundedCornerShape(3.dp)))
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "签到: ${state.currentRole.label}",
                    color = AgedBrass,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun YanshiCompactHeader() {
    val state by SimulationEngine.state.collectAsState()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CharcoalInk)
            .border(BorderStroke(1.dp, AgedBrass))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            YanshiClassicalSeal(modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text("烟仕 YANSHI", color = WarmPaper, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(state.currentStore.name, color = AgedBrass, fontSize = 9.sp)
            }
        }
        Box(
            modifier = Modifier
                .background(SealRed)
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(state.currentRole.label, color = WarmPaper, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun YanshiCompactBottomBar(
    currentScreen: Screen,
    onNavigate: (Screen) -> Unit
) {
    val activeIndex = NavigationItems.indexOfFirst { item ->
        when (item.screen) {
            is Screen.SystemSettings -> currentScreen is Screen.SystemSettings || currentScreen is Screen.AuditLogs || currentScreen is Screen.DataExport || currentScreen is Screen.StaffPermissions || currentScreen is Screen.Notifications
            is Screen.InventoryConsole -> currentScreen is Screen.InventoryConsole || currentScreen is Screen.InventoryLedger
            is Screen.StoreNetwork -> currentScreen is Screen.StoreNetwork || currentScreen is Screen.StoreDetail || currentScreen is Screen.StoreTwin
            is Screen.ComplianceCenter -> currentScreen is Screen.ComplianceCenter || currentScreen is Screen.RiskEventDetail
            is Screen.SupplyChain -> currentScreen is Screen.SupplyChain || currentScreen is Screen.Procurement
            else -> item.screen::class == currentScreen::class
        }
    }.coerceAtLeast(0)

    ScrollableTabRow(
        selectedTabIndex = activeIndex,
        containerColor = CharcoalInk,
        contentColor = AgedBrass,
        edgePadding = 8.dp,
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                Modifier.tabIndicatorOffset(tabPositions[activeIndex]),
                color = SealRed
            )
        }
    ) {
        NavigationItems.forEach { item ->
            val isSelected = NavigationItems.indexOf(item) == activeIndex
            Tab(
                selected = isSelected,
                onClick = { onNavigate(item.screen) },
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(item.icon, contentDescription = null, tint = if (isSelected) SealRed else WarmPaper.copy(alpha = 0.5f), modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(item.label, fontSize = 11.sp, color = if (isSelected) WarmPaper else WarmPaper.copy(alpha = 0.6f))
                    }
                }
            )
        }
    }
}

@Composable
fun RenderScreen(screen: Screen) {
    when (screen) {
        is Screen.Login -> LoginScreen()
        is Screen.Dashboard -> DashboardScreen()
        is Screen.Catalog -> CatalogScreen()
        is Screen.ProductDetail -> CatalogScreen()
        is Screen.StoreNetwork -> StoreScreen()
        is Screen.StoreDetail -> StoreScreen()
        is Screen.StoreTwin -> StoreScreen()
        is Screen.InventoryConsole -> InventoryScreen()
        is Screen.InventoryLedger -> InventoryScreen()
        is Screen.POS -> PosScreen()
        is Screen.MemberServices -> MemberScreen()
        is Screen.AgeVerification -> MemberScreen()
        is Screen.ComplianceCenter -> ComplianceScreen()
        is Screen.RiskEventDetail -> ComplianceScreen()
        is Screen.SupplyChain -> SupplyChainScreen()
        is Screen.Procurement -> SupplyChainScreen()
        is Screen.Analytics -> AnalyticsScreen()
        is Screen.StaffPermissions -> SettingsScreen()
        is Screen.Notifications -> SettingsScreen()
        is Screen.SystemSettings -> SettingsScreen()
        is Screen.AuditLogs -> SettingsScreen()
        is Screen.DataExport -> SettingsScreen()
    }
}
