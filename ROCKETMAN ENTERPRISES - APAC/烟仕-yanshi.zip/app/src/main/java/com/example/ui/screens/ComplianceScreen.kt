package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ComplianceEvent
import com.example.domain.RiskLevel
import com.example.engine.SimulationEngine
import com.example.ui.theme.*

@Composable
fun ComplianceScreen() {
    val state by SimulationEngine.state.collectAsState()
    var selectedEventForResolution by remember { mutableStateOf<ComplianceEvent?>(null) }
    var filterStatus by remember { mutableStateOf<String?>("待处理") } // "待处理", "已归档", null

    val filteredEvents = state.complianceEvents.filter { ev ->
        filterStatus == null || ev.status == filterStatus
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // 顶端头部
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "中国高端专营合规与风控拦截网",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = CharcoalInk
                )
                Text(
                    text = "防范未成年人采购红线 · 杜绝店外囤积与非法转卖",
                    fontSize = 11.sp,
                    color = StatusError,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }

            // 快捷过滤器
            Row(
                modifier = Modifier
                    .border(1.dp, CharcoalInk)
                    .background(OffWhite)
            ) {
                OutlinedButton(
                    onClick = { filterStatus = "待处理" },
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (filterStatus == "待处理") CharcoalInk else Color.Transparent,
                        contentColor = if (filterStatus == "待处理") WarmPaper else CharcoalInk
                    ),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("待核查 (${state.complianceEvents.count { it.status == "待处理" }})", fontSize = 10.sp)
                }
                OutlinedButton(
                    onClick = { filterStatus = "已处理" },
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (filterStatus == "已处理") CharcoalInk else Color.Transparent,
                        contentColor = if (filterStatus == "已处理") WarmPaper else CharcoalInk
                    ),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("已核签归档 (${state.complianceEvents.count { it.status == "已处理" }})", fontSize = 10.sp)
                }
                OutlinedButton(
                    onClick = { filterStatus = null },
                    shape = RoundedCornerShape(2.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (filterStatus == null) CharcoalInk else Color.Transparent,
                        contentColor = if (filterStatus == null) WarmPaper else CharcoalInk
                    ),
                    modifier = Modifier.height(36.dp)
                ) {
                    Text("全部 (${state.complianceEvents.size})", fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 顶端合规雷达卡片
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            val highRiskCount = state.complianceEvents.count { (it.riskLevel == RiskLevel.HIGH || it.riskLevel == RiskLevel.CRITICAL) && it.status == "待处理" }
            
            Box(modifier = Modifier.weight(1.2f)) {
                RiskSummaryCard(
                    title = "当前安全防护态势",
                    level = if (highRiskCount > 0) "高度戒备 (HIGH RISK)" else "绿邮合规 (SECURE)",
                    color = if (highRiskCount > 0) StatusError else StatusSuccess,
                    desc = "严查身份证假证、代买、多人凑单囤积行为。"
                )
            }
            
            Box(modifier = Modifier.weight(1f)) {
                RiskSummaryCard(
                    title = "未成年采购尝试拦截",
                    level = "${state.complianceEvents.count { it.type.label.contains("年龄") }} 次拦截",
                    color = SealRed,
                    desc = "今日通过硬件闸机实名双盲核验，100%成功阻断未成年人进店/消费。"
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // 合规监控日志流
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .border(1.dp, MutedPaper)
        ) {
            // 表头
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CharcoalInk)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("触发时间", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.2f), fontWeight = FontWeight.Bold)
                Text("风险事件大类", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                Text("安全级别", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("现场特征日志细节", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(2.5f), fontWeight = FontWeight.Bold)
                Text("拦截状态", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                Text("核签管理", color = WarmPaper, fontSize = 11.sp, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            }

            // 表体
            filteredEvents.forEachIndexed { index, event ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (index % 2 == 0) OffWhite else WarmPaper)
                        .clickable { selectedEventForResolution = event }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(event.timestamp, color = CharcoalInk, fontSize = 10.sp, modifier = Modifier.weight(1.2f), fontFamily = FontFamily.Monospace)
                    Text(event.type.label, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(1.5f), fontWeight = FontWeight.Bold)
                    
                    // 级别徽章
                    Box(modifier = Modifier.weight(1.1f), contentAlignment = Alignment.Center) {
                        val levelColor = when(event.riskLevel) {
                            RiskLevel.INFO, RiskLevel.LOW -> StatusSuccess
                            RiskLevel.MEDIUM -> StatusAlert
                            else -> StatusError
                        }
                        Box(
                            modifier = Modifier
                                .background(levelColor.copy(alpha = 0.12f), RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(event.riskLevel.label, color = levelColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Text(event.details, color = CharcoalInk, fontSize = 11.sp, modifier = Modifier.weight(2.5f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)

                    // 处理状态
                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        val isPending = event.status == "待处理"
                        Box(
                            modifier = Modifier
                                .background(if (isPending) StatusAlert.copy(alpha = 0.12f) else StatusSuccess.copy(alpha = 0.12f), RoundedCornerShape(2.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(event.status, color = if (isPending) StatusAlert else StatusSuccess, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        IconButton(onClick = { selectedEventForResolution = event }, modifier = Modifier.size(24.dp)) {
                            Icon(
                                if (event.status == "待处理") Icons.Default.Gavel else Icons.Default.TaskAlt,
                                contentDescription = null,
                                tint = if (event.status == "待处理") SealRed else StatusSuccess
                            )
                        }
                    }
                }
            }
        }

        // 合规事件处置弹窗 Resolving Dialog
        selectedEventForResolution?.let { event ->
            var auditorNote by remember { mutableStateOf("") }
            
            AlertDialog(
                onDismissRequest = { selectedEventForResolution = null },
                confirmButton = {
                    if (event.status == "待处理") {
                        Button(
                            onClick = {
                                SimulationEngine.resolveComplianceEvent(event.id, auditorNote)
                                selectedEventForResolution = null
                            },
                            shape = RoundedCornerShape(2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalInk, contentColor = WarmPaper)
                        ) {
                            Text("签发合规裁决与整改")
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedEventForResolution = null }) {
                        Text(if (event.status == "待处理") "取消" else "关闭窗口", color = CharcoalInk)
                    }
                },
                title = { Text("合规中心 · 事件现场复核判定", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = CharcoalInk) },
                text = {
                    Column {
                        Text("事件编号: ${event.id}", fontSize = 10.sp, color = GraphiteGrey)
                        Text("现场抓拍与触发日志: ${event.details}", fontSize = 12.sp, color = CharcoalInk, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                        Text("合规分类: ${event.type.label} | 风险级别: ${event.riskLevel.label}", fontSize = 11.sp, color = SealRed)

                        Divider(color = CharcoalInk, modifier = Modifier.padding(vertical = 12.dp))

                        if (event.status == "待处理") {
                            Text("合规员人工判定裁定意见:", fontSize = 11.sp, color = CharcoalInk)
                            OutlinedTextField(
                                value = auditorNote,
                                onValueChange = { auditorNote = it },
                                placeholder = { Text("例：经核查店内视频及收银员日志，确认已劝返。判定本拦截无实质红线违规，允许注销报警。", fontSize = 10.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 6.dp),
                                shape = RoundedCornerShape(2.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("提交裁决后，该事件将被归档，系统自动录入 YANSHI 链上审计，作为专管局备档凭证。", fontSize = 10.sp, color = GraphiteGrey)
                        } else {
                            Text("合规员处理归档历史备注:", fontSize = 11.sp, color = GraphiteGrey, fontWeight = FontWeight.Bold)
                            Text(
                                text = event.notes.ifEmpty { "经系统自查，防未成年人探头自主触发劝返，不作处罚，自动归档。" },
                                fontSize = 11.sp,
                                color = CharcoalInk,
                                modifier = Modifier.padding(top = 4.dp),
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun RiskSummaryCard(
    title: String,
    level: String,
    color: Color,
    desc: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MutedPaper, RoundedCornerShape(2.dp)),
        colors = CardDefaults.cardColors(containerColor = OffWhite),
        shape = RoundedCornerShape(2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 11.sp, color = GraphiteGrey)
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(8.dp).background(color, RoundedCornerShape(4.dp)))
                Spacer(modifier = Modifier.width(6.dp))
                Text(level, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = color)
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(desc, fontSize = 10.sp, color = GraphiteGrey)
        }
    }
}
