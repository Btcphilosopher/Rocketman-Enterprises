package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Burgundy,
    onPrimary = Color.White,
    secondary = WarmWood,
    onSecondary = Color.White,
    tertiary = BrushedMetal,
    background = GraphiteDark,
    onBackground = IvoryLight,
    surface = SurfaceDarkCard,
    onSurface = IvoryLight,
    surfaceVariant = Color(0xFF333336),
    onSurfaceVariant = BrushedMetal
)

private val LightColorScheme = lightColorScheme(
    primary = Burgundy,
    onPrimary = Color.White,
    secondary = WarmWood,
    onSecondary = Color.White,
    tertiary = BrushedMetal,
    background = IvoryLight,
    onBackground = GraphiteDark,
    surface = SurfaceWhite,
    onSurface = GraphiteDark,
    surfaceVariant = Color(0xFFF5F3ED),
    onSurfaceVariant = Color(0xFF5C5C60)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable dynamic colors to enforce pristine premium styling!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
