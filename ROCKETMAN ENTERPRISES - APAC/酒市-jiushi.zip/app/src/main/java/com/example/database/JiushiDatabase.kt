package com.example.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.domain.Order
import com.example.domain.ComplianceLog
import com.example.domain.AnalyticsSnapshot
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: String): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Query("DELETE FROM orders")
    suspend fun deleteAllOrders()
}

@Dao
interface ComplianceLogDao {
    @Query("SELECT * FROM compliance_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<ComplianceLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ComplianceLog)

    @Query("DELETE FROM compliance_logs")
    suspend fun deleteAllLogs()
}

@Dao
interface AnalyticsSnapshotDao {
    @Query("SELECT * FROM analytics_snapshots ORDER BY timestamp DESC")
    fun getAllSnapshots(): Flow<List<AnalyticsSnapshot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: AnalyticsSnapshot)
}

@Database(entities = [Order::class, ComplianceLog::class, AnalyticsSnapshot::class], version = 1, exportSchema = false)
abstract class JiushiDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun complianceLogDao(): ComplianceLogDao
    abstract fun analyticsSnapshotDao(): AnalyticsSnapshotDao

    companion object {
        @Volatile
        private var INSTANCE: JiushiDatabase? = null

        fun getDatabase(context: Context): JiushiDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    JiushiDatabase::class.java,
                    "jiushi_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
