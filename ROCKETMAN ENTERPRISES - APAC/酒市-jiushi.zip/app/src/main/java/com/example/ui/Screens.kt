package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.domain.*
import com.example.engine.JiushiEngine
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.sqrt

enum class AppRole {
    CONSUMER,
    RIDER,
    DIGITAL_TWIN,
    ADMIN_CONSOLE,
    SIM_SETTINGS
}

@Composable
fun MainHubScreen() {
    var activeRole by remember { mutableStateOf(AppRole.CONSUMER) }
    val context = LocalContext.current

    // Observe shared state from Engine
    val selectedCity by JiushiEngine.selectedCity.collectAsState()
    val simTickCount by JiushiEngine.simTickCount.collectAsState()
    val isPaused by JiushiEngine.isPaused.collectAsState()
    val totalGMV by JiushiEngine.totalGMV.collectAsState()
    val activeOrders by JiushiEngine.activeOrders.collectAsState()
    val complianceAlerts by JiushiEngine.complianceAlertCount.collectAsState()

    LaunchedEffect(Unit) {
        JiushiEngine.initialize(context)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            Column {
                // Fictional Prototype Disclaimer Alert Banner
                Surface(
                    color = Burgundy,
                    contentColor = Color.White
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Warning,
                                contentDescription = "Disclaimer",
                                modifier = Modifier.size(14.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "演示平台 · SYNTHETIC DATA · CONCEPT PROTOTYPE | 仅限满18岁成年人饮用",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Text(
                            text = "时钟周期: $simTickCount 步",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Light
                        )
                    }
                }

                // High Density Role Selector Dashboard Navigation Header
                Surface(
                    color = GraphiteDark,
                    contentColor = IvoryLight,
                    shadowElevation = 4.dp
                ) {
                    Column {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "JIUSHI 酒市",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Burgundy,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Surface(
                                        color = Color(0xFF3A3A3C),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = selectedCity,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = IvoryLight,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "中国酒类即时零售与城市配送数字孪生平台",
                                    fontSize = 10.sp,
                                    color = BrushedMetal
                                )
                            }

                            // Quick Stats Bubble
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                StatBadge(label = "合成GMV", value = "¥${String.format("%.2f", totalGMV)}", color = SuccessGreen)
                                StatBadge(label = "合规警报", value = "$complianceAlerts", color = if (complianceAlerts > 0) AlertRed else SuccessGreen)
                            }
                        }

                        // Adaptive Horizontal Scrollable Tab Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .background(Color(0xFF151517))
                                .padding(horizontal = 8.dp, vertical = 2.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            RoleTab(
                                title = "1. 顾客消费端",
                                active = activeRole == AppRole.CONSUMER,
                                icon = Icons.Filled.ShoppingCart,
                                onClick = { activeRole = AppRole.CONSUMER }
                            )
                            RoleTab(
                                title = "2. 骑手终端",
                                active = activeRole == AppRole.RIDER,
                                icon = Icons.Filled.DirectionsBike,
                                onClick = { activeRole = AppRole.RIDER }
                            )
                            RoleTab(
                                title = "3. 门店/仓库孪生",
                                active = activeRole == AppRole.DIGITAL_TWIN,
                                icon = Icons.Filled.Layers,
                                onClick = { activeRole = AppRole.DIGITAL_TWIN }
                            )
                            RoleTab(
                                title = "4. 调度与合规后台",
                                active = activeRole == AppRole.ADMIN_CONSOLE,
                                icon = Icons.Filled.Dashboard,
                                onClick = { activeRole = AppRole.ADMIN_CONSOLE }
                            )
                            RoleTab(
                                title = "5. 仿真中心",
                                active = activeRole == AppRole.SIM_SETTINGS,
                                icon = Icons.Filled.Settings,
                                onClick = { activeRole = AppRole.SIM_SETTINGS }
                            )
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeRole) {
                AppRole.CONSUMER -> ConsumerView()
                AppRole.RIDER -> RiderTerminalView()
                AppRole.DIGITAL_TWIN -> DigitalTwinView()
                AppRole.ADMIN_CONSOLE -> AdminConsoleView()
                AppRole.SIM_SETTINGS -> SimulationControlPanel()
            }
        }
    }
}

@Composable
fun StatBadge(label: String, value: String, color: Color) {
    Surface(
        color = Color(0xFF2C2C2E),
        shape = RoundedCornerShape(6.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "$label: ", fontSize = 10.sp, color = BrushedMetal)
            Text(text = value, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun RoleTab(title: String, active: Boolean, icon: ImageVector, onClick: () -> Unit) {
    val containerColor = if (active) Burgundy else Color.Transparent
    val contentColor = if (active) Color.White else BrushedMetal

    Surface(
        color = containerColor,
        contentColor = contentColor,
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier
            .clickable { onClick() }
            .padding(vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(imageVector = icon, contentDescription = title, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// --------------------------------------------------------------------------------------------------
// 1. CONSUMER CLIENT VIEW
// --------------------------------------------------------------------------------------------------
@Composable
fun ConsumerView() {
    val scope = rememberCoroutineScope()
    val products by JiushiEngine.products.collectAsState()
    val selectedCity by JiushiEngine.selectedCity.collectAsState()
    val cart by JiushiEngine.cart.collectAsState()
    val activeOrders by JiushiEngine.activeOrders.collectAsState()
    val mockAddress by JiushiEngine.mockCustomerAddress.collectAsState()
    val userAgeState by JiushiEngine.userAgeState.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("全部") }
    val categories = listOf("全部", "白酒", "啤酒", "葡萄酒", "黄酒", "威士忌", "其他")

    var isCartOpen by remember { mutableStateOf(false) }
    var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }
    var showAgeVerificationDialog by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }

    val filteredProducts = products.filter {
        (selectedCategory == "全部" || it.category == selectedCategory) &&
        (it.name.contains(searchQuery, ignoreCase = true) ||
         it.brand.contains(searchQuery, ignoreCase = true) ||
         it.subcategory.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(IvoryLight)
    ) {
        // Consumer Location bar and entry mode switches
        Surface(
            color = Color(0xFFF1EDE4),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = "Address",
                        tint = Burgundy,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "送至：$mockAddress",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = GraphiteDark,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Method Quick Pills
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "即时送达 ⚡",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Burgundy,
                        modifier = Modifier
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .border(1.dp, Burgundy, RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // Hero Promotional Zone
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            color = Color(0xFF2C1318),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "城市美酒 · 即刻送达",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = IvoryLight
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "网格化门店仓储匹配，由就近骑手28分钟内护送上门。18+实名认证保障合规。",
                        fontSize = 11.sp,
                        color = BrushedMetal
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Icon(
                    imageVector = Icons.Filled.LocalBar,
                    contentDescription = "Alcohol Icon",
                    tint = Burgundy,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        // Professional Search Bar & Age verified indicator
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("搜索酒类商品、风格、品牌...", fontSize = 12.sp) },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("product_search_input"),
                leadingIcon = { Icon(imageVector = Icons.Filled.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedIndicatorColor = Burgundy,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                shape = RoundedCornerShape(8.dp),
                singleLine = true
            )
            Spacer(modifier = Modifier.width(8.dp))

            // User Verification Quick Pill clickable
            Surface(
                color = if (userAgeState == AgeVerifiedState.PASSED) SuccessGreen else AlertRed,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .height(48.dp)
                    .clickable { showAgeVerificationDialog = true }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (userAgeState == AgeVerifiedState.PASSED) Icons.Filled.CheckCircle else Icons.Filled.GppMaybe,
                            contentDescription = "Verify",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (userAgeState == AgeVerifiedState.PASSED) "18+已核验" else "未成年核验",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Subcategory filter lists
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { cat ->
                val active = selectedCategory == cat
                Surface(
                    color = if (active) Burgundy else Color.White,
                    contentColor = if (active) Color.White else GraphiteDark,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, if (active) Burgundy else Color(0xFFDCD6CD)),
                    modifier = Modifier.clickable { selectedCategory = cat }
                ) {
                    Text(
                        text = cat,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // Products Grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Filled.SearchOff, contentDescription = "Empty", tint = BrushedMetal, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "未找到符合过滤条件的酒类商品", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredProducts) { prod ->
                    ProductGridCard(
                        product = prod,
                        onDetail = { selectedProductForDetail = prod },
                        onAddToCart = {
                            val currentCart = JiushiEngine.cart.value.toMutableList()
                            val existingIndex = currentCart.indexOfFirst { it.product.id == prod.id }
                            if (existingIndex != -1) {
                                currentCart[existingIndex].quantity += 1
                            } else {
                                currentCart.add(CartItem(prod, 1))
                            }
                            JiushiEngine.cart.value = currentCart
                            JiushiEngine.logSystem("购物车：将商品 [${prod.brand} · ${prod.name}] 成功加入购物车。")
                        }
                    )
                }
            }
        }

        // Floating Bottom Cart bar if items inside
        if (cart.isNotEmpty()) {
            Surface(
                color = GraphiteDark,
                contentColor = IvoryLight,
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { isCartOpen = true }) {
                            BadgedBox(
                                badge = { Badge { Text("${cart.sumOf { it.quantity }}") } }
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ShoppingCart,
                                    contentDescription = "Cart",
                                    tint = IvoryLight
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            val totalAmt = cart.sumOf { it.product.price * it.quantity }
                            Text(text = "总计：¥${String.format("%.2f", totalAmt)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            Text(text = "已享受平台合规交付核保", fontSize = 10.sp, color = BrushedMetal)
                        }
                    }

                    Button(
                        onClick = {
                            if (userAgeState != AgeVerifiedState.PASSED) {
                                showAgeVerificationDialog = true
                            } else {
                                showCheckoutDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("go_to_checkout")
                    ) {
                        Text(text = if (userAgeState != AgeVerifiedState.PASSED) "需满18岁实名核验" else "去结算付款", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Modal: Product Details Dialog
    selectedProductForDetail?.let { prod ->
        ProductDetailDialog(
            product = prod,
            onDismiss = { selectedProductForDetail = null },
            onAddToCart = {
                val currentCart = JiushiEngine.cart.value.toMutableList()
                val existingIndex = currentCart.indexOfFirst { it.product.id == prod.id }
                if (existingIndex != -1) {
                    currentCart[existingIndex].quantity += 1
                } else {
                    currentCart.add(CartItem(prod, 1))
                }
                JiushiEngine.cart.value = currentCart
                selectedProductForDetail = null
            }
        )
    }

    // Modal: Age Verification Input Dialog
    if (showAgeVerificationDialog) {
        AgeVerificationDialog(
            onDismiss = { showAgeVerificationDialog = false },
            onSuccess = { name, idCard ->
                // Mark user verified
                JiushiEngine.userAgeState.value = AgeVerifiedState.PASSED
                JiushiEngine.userAgeVerifiedName.value = name
                JiushiEngine.userAgeVerifiedIdMask.value = idCard.take(4) + "**********" + idCard.takeLast(4)
                showAgeVerificationDialog = false
                JiushiEngine.logSystem("人脸/实名系统：用户完成18周岁合规验证。真实姓名: $name, 证件：${JiushiEngine.userAgeVerifiedIdMask.value}")
            }
        )
    }

    // Modal: Cart Details Drawer
    if (isCartOpen) {
        CartDrawer(
            cart = cart,
            onDismiss = { isCartOpen = false },
            onClear = {
                JiushiEngine.cart.value = emptyList()
                isCartOpen = false
            },
            onQuantityChange = { prod, offset ->
                val currentCart = JiushiEngine.cart.value.toMutableList()
                val idx = currentCart.indexOfFirst { it.product.id == prod.id }
                if (idx != -1) {
                    val target = currentCart[idx]
                    target.quantity += offset
                    if (target.quantity <= 0) {
                        currentCart.removeAt(idx)
                    }
                    JiushiEngine.cart.value = currentCart
                }
            }
        )
    }

    // Modal: Checkout and mock payment Dialog
    if (showCheckoutDialog) {
        CheckoutDialog(
            cart = cart,
            address = mockAddress,
            onDismiss = { showCheckoutDialog = false },
            onSubmit = { method, pay ->
                // Complete Mock Order Submit
                val orderId = JiushiEngine.submitUserOrder(cart, method, mockAddress, pay)
                showCheckoutDialog = false
            }
        )
    }
}

@Composable
fun ProductGridCard(product: Product, onDetail: () -> Unit, onAddToCart: () -> Unit) {
    Surface(
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFEBE5DB)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .clickable { onDetail() }
            .fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Elegant placeholder visual branding for alcohol
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFFBF9F4)),
                contentAlignment = Alignment.Center
            ) {
                // Design-centric visual art representation
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = when (product.category) {
                            "白酒" -> Icons.Filled.Science // Distilled look
                            "啤酒" -> Icons.Filled.SportsBar // Beer
                            "葡萄酒" -> Icons.Filled.WineBar // Wine
                            else -> Icons.Filled.WineBar
                        },
                        contentDescription = "Alcohol Art",
                        tint = Burgundy,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = product.brand, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                }

                // Compliance Age Alert Pill on card top left
                if (product.ageLimit) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(AlertRed, RoundedCornerShape(topStart = 6.dp, bottomEnd = 6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(text = "18+限制", fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Text Metadata without sales slang
            Text(
                text = product.name,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = GraphiteDark,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(text = "${product.abv} | ${product.capacity}", fontSize = 10.sp, color = Color.Gray)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pricing and Purchase Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "¥${String.format("%.0f", product.price)}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        color = Burgundy
                    )
                    Text(
                        text = "¥${String.format("%.0f", product.originalPrice)}",
                        fontSize = 10.sp,
                        color = Color.LightGray,
                        textDecoration = androidx.compose.ui.text.style.TextDecoration.LineThrough
                    )
                }

                IconButton(
                    onClick = { onAddToCart() },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = Color(0xFFF6EEF0)),
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("add_to_cart_btn_${product.id}")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Add,
                        contentDescription = "Add to Cart",
                        tint = Burgundy,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ProductDetailDialog(product: Product, onDismiss: () -> Unit, onAddToCart: () -> Unit) {
    Dialog(onDismissRequest = { onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE5DFD4)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "商品档案 · 合规公示", fontSize = 12.sp, color = Burgundy, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { onDismiss() }) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close", modifier = Modifier.size(18.dp))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Luxury Art Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFBF9F4)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = product.nameEn, fontSize = 11.sp, fontWeight = FontWeight.Light, color = Color.Gray, letterSpacing = 2.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = product.name, fontSize = 20.sp, fontWeight = FontWeight.Black, color = GraphiteDark)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // High density specification parameters Grid
                Text(text = "食品/酒类生产及合规信息：", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                Spacer(modifier = Modifier.height(8.dp))

                DetailRow(label = "产品分类", value = "${product.category} (${product.subcategory})")
                DetailRow(label = "酒精精度", value = product.abv)
                DetailRow(label = "产品容量", value = product.capacity)
                DetailRow(label = "原产产地", value = product.origin)
                DetailRow(label = "产品配料", value = product.ingredients)
                DetailRow(label = "储存条件", value = product.storage)
                DetailRow(label = "销售合规", value = if (product.ageLimit) "18岁年龄限制强制检验交付" else "普通麦芽无醇饮品免核验")

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "商品介绍：", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = product.description,
                    fontSize = 11.sp,
                    color = Color.DarkGray,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Bottom buy actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "当前结算价", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "¥${String.format("%.2f", product.price)}", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Burgundy)
                    }

                    Button(
                        onClick = { onAddToCart() },
                        colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(text = "加入购物车", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 11.sp, color = Color.Gray)
        Text(text = value, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = GraphiteDark, textAlign = TextAlign.End)
    }
}

@Composable
fun AgeVerificationDialog(onDismiss: () -> Unit, onSuccess: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var idCard by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var mockStep by remember { mutableStateOf(1) } // 1: Input, 2: Face Scan Animation, 3: Success

    Dialog(onDismissRequest = { onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "中国居民酒类销售年龄核验",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Burgundy
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "根据我国法规，本平台仅销售酒水给成年人。将进行国安认证的人证对比。",
                    fontSize = 11.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(16.dp))

                if (mockStep == 1) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("真实姓名 (模拟)", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_name_input"),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = idCard,
                        onValueChange = { idCard = it },
                        label = { Text("18位居民身份证号 (模拟)", fontSize = 11.sp) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("verify_id_input"),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true
                    )

                    if (errorMessage.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = errorMessage, color = AlertRed, fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { onDismiss() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = "取消", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                if (name.trim().isEmpty() || idCard.trim().length != 18) {
                                    errorMessage = "身份格式不匹配！请输入真实中文姓名，且身份证必须为18位数字。"
                                } else {
                                    errorMessage = ""
                                    mockStep = 2
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("submit_age_verification_btn")
                        ) {
                            Text(text = "确认身份", fontSize = 12.sp)
                        }
                    }
                } else if (mockStep == 2) {
                    // Face scan animation simulator
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator(color = Burgundy)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "正在启动人脸生物识别对焦...", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                        Text(text = "调用前置合规摄像头 (模拟对比人像库)...", fontSize = 10.sp, color = Color.Gray)

                        // Auto transition to success after delay
                        LaunchedEffect(Unit) {
                            kotlinx.coroutines.delay(2000)
                            mockStep = 3
                        }
                    }
                } else {
                    // Success Screen
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(imageVector = Icons.Filled.CheckCircle, contentDescription = "Success", tint = SuccessGreen, modifier = Modifier.size(54.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(text = "已通过国家法定年龄核验！", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                        Text(text = "已登记满18周岁合规购买资格，并赋予您现场收货验证锁。", fontSize = 10.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(24.dp))

                        Button(
                            onClick = { onSuccess(name, idCard) },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("dismiss_verification_success_btn")
                        ) {
                            Text(text = "开启选酒之旅", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CartDrawer(
    cart: List<CartItem>,
    onDismiss: () -> Unit,
    onClear: () -> Unit,
    onQuantityChange: (Product, Int) -> Unit
) {
    Dialog(onDismissRequest = { onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "购物车选购详情", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    Text(
                        text = "清空全部",
                        fontSize = 11.sp,
                        color = AlertRed,
                        modifier = Modifier
                            .clickable { onClear() }
                            .padding(4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Warning
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFDF2F4)),
                    border = BorderStroke(1.dp, Color(0xFFF3C7CF)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "⚠️ 重要合规提示：所有酒类商品仅向18岁以上成年人交付。我们将核对您现场的实体卡证件，若不符将拒签拦截！",
                        fontSize = 10.sp,
                        color = AlertRed,
                        modifier = Modifier.padding(10.dp),
                        lineHeight = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(cart) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFFBFBF9), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = item.product.name, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(text = "¥${item.product.price} / 瓶", fontSize = 10.sp, color = Color.Gray)
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    color = Color(0xFFEBE5DB),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clickable { onQuantityChange(item.product, -1) }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = "-", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Text(text = "${item.quantity}", fontSize = 12.sp, fontWeight = FontWeight.Bold)

                                Surface(
                                    color = Color(0xFFEBE5DB),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clickable { onQuantityChange(item.product, 1) }
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(text = "+", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onDismiss() },
                    colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "继续选购", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun CheckoutDialog(
    cart: List<CartItem>,
    address: String,
    onDismiss: () -> Unit,
    onSubmit: (DeliveryMethod, String) -> Unit
) {
    var selectedMethod by remember { mutableStateOf(DeliveryMethod.INSTANT) }
    var selectedPayment by remember { mutableStateOf("微信支付") }
    var invoiceRequired by remember { mutableStateOf(false) }

    val subtotal = cart.sumOf { it.product.price * it.quantity }
    val shipping = if (selectedMethod == DeliveryMethod.PICKUP) 0.0 else 5.0
    val total = subtotal + shipping

    Dialog(onDismissRequest = { onDismiss() }) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = Color.White,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(text = "酒市数字化收银台", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                Spacer(modifier = Modifier.height(12.dp))

                // Address info
                Text(text = "配送信息：", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Surface(color = Color(0xFFFBFBF9), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = address, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Text(text = "由 临近匹配门店 专线即时履约配送", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Method
                Text(text = "配送履约方案：", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = { selectedMethod = DeliveryMethod.INSTANT },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selectedMethod == DeliveryMethod.INSTANT) Color(0xFFF6EEF0) else Color.Transparent
                        ),
                        border = BorderStroke(1.dp, if (selectedMethod == DeliveryMethod.INSTANT) Burgundy else Color.LightGray),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "即时送达", fontSize = 10.sp, color = Burgundy)
                    }
                    OutlinedButton(
                        onClick = { selectedMethod = DeliveryMethod.PICKUP },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (selectedMethod == DeliveryMethod.PICKUP) Color(0xFFF6EEF0) else Color.Transparent
                        ),
                        border = BorderStroke(1.dp, if (selectedMethod == DeliveryMethod.PICKUP) Burgundy else Color.LightGray),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "到店自提", fontSize = 10.sp, color = Burgundy)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Payment Options
                Text(text = "支付方式 (模拟支付)：", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                val payments = listOf("微信支付", "支付宝", "数字人民币", "企业代扣账户")
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    payments.forEach { pay ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPayment = pay }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = selectedPayment == pay, onClick = { selectedPayment = pay })
                            Text(text = pay, fontSize = 11.sp, color = GraphiteDark)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Price details
                Text(text = "价格明细：", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                DetailRow(label = "商品小计", value = "¥${String.format("%.2f", subtotal)}")
                DetailRow(label = "配送运费", value = "¥${String.format("%.2f", shipping)}")
                Divider(modifier = Modifier.padding(vertical = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "应付实付款", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    Text(text = "¥${String.format("%.2f", total)}", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { onDismiss() },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = "返回", fontSize = 12.sp)
                    }

                    Button(
                        onClick = { onSubmit(selectedMethod, selectedPayment) },
                        colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("submit_checkout_pay_btn")
                    ) {
                        Text(text = "确认模拟支付", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// 2. RIDER TERMINAL VIEW
// --------------------------------------------------------------------------------------------------
@Composable
fun RiderTerminalView() {
    val riders by JiushiEngine.riders.collectAsState()
    val activeOrders by JiushiEngine.activeOrders.collectAsState()

    // Find rider related to selected city
    val activeRider = riders.firstOrNull() // Take Rider-1 (Lao Liu)

    if (activeRider == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = "正在初始化城市物流资源...")
        }
        return
    }

    // Filter active order assigned to this rider
    val riderOrder = activeOrders.find { it.riderId == activeRider.id && it.orderStatus != OrderStatus.COMPLETED && it.orderStatus != OrderStatus.CANCELLED }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF1EDE4))
            .padding(16.dp)
    ) {
        // Rider Identity Bar
        Surface(
            color = GraphiteDark,
            contentColor = IvoryLight,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.DirectionsBike,
                        contentDescription = "Rider Avatar",
                        tint = Burgundy,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = activeRider.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "当前配送状态: ${activeRider.status.name}", fontSize = 10.sp, color = BrushedMetal)
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "服务分: ${activeRider.rating}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                    Text(text = "准时率: ${activeRider.onTimeRate}%", fontSize = 9.sp, color = BrushedMetal)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Active Delivery Task
        if (riderOrder == null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFDCD6CD), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Filled.Inbox, contentDescription = "Idle", tint = BrushedMetal, modifier = Modifier.size(54.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "暂无待指派即时配送单", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    Text(text = "可在[顾客消费端]下单，或等待仿真引擎生成后台运力单...", fontSize = 10.sp, color = Color.Gray, modifier = Modifier.padding(top = 4.dp))
                }
            }
        } else {
            val orderItems = JiushiEngine.deserializeCart(riderOrder.itemsJson)

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(Color.White, RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFDCD6CD), RoundedCornerShape(12.dp))
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "即时同城配单: #${riderOrder.id}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                    Surface(
                        color = Color(0xFFFFF3CD),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = riderOrder.orderStatus.name,
                            fontSize = 9.sp,
                            color = WarningOrange,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Addresses route indicators
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 4.dp)) {
                        Box(modifier = Modifier.size(10.dp).background(SuccessGreen, RoundedCornerShape(5.dp)))
                        Box(modifier = Modifier.width(1.dp).height(40.dp).background(Color.LightGray))
                        Box(modifier = Modifier.size(10.dp).background(AlertRed, RoundedCornerShape(5.dp)))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(text = "取货商家：", fontSize = 10.sp, color = Color.Gray)
                        Text(text = "酒市南京西路旗舰店", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "送达地址：", fontSize = 10.sp, color = Color.Gray)
                        Text(text = riderOrder.shippingAddress, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(12.dp))

                // Product to pick
                Text(text = "核验载物明细：", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Spacer(modifier = Modifier.height(6.dp))
                orderItems.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "${item.product.brand} · ${item.product.name}", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Text(text = "数量：x${item.quantity}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GraphiteDark)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(16.dp))

                // Interactive status driver buttons for presentation
                Text(text = "物流过程与时空履行操作 (数字孪生模拟器)：", fontSize = 11.sp, color = Color.Gray)
                Spacer(modifier = Modifier.height(8.dp))

                when (riderOrder.orderStatus) {
                    OrderStatus.STORE_ACCEPTED -> {
                        Button(
                            onClick = {
                                val currentRiders = JiushiEngine.riders.value.toMutableList()
                                val rIdx = currentRiders.indexOfFirst { it.id == activeRider.id }
                                if (rIdx != -1) {
                                    currentRiders[rIdx] = currentRiders[rIdx].copy(status = RiderStatus.PICKING_UP)
                                }
                                JiushiEngine.riders.value = currentRiders

                                val currentOrders = JiushiEngine.activeOrders.value.toMutableList()
                                val oIdx = currentOrders.indexOfFirst { it.id == riderOrder.id }
                                if (oIdx != -1) {
                                    val timeline = JiushiEngine.deserializeTimeline(riderOrder.timelineJson).toMutableList()
                                    timeline.add(TimelineEvent(OrderStatus.PICKING, "骑手到店，数字化一键确认开始商品拣选任务。", System.currentTimeMillis()))
                                    currentOrders[oIdx] = riderOrder.copy(
                                        orderStatus = OrderStatus.PICKING,
                                        timelineJson = JiushiEngine.serializeTimeline(timeline)
                                    )
                                }
                                JiushiEngine.activeOrders.value = currentOrders
                                JiushiEngine.logSystem("骑手指令：已确认接单，拉取南京西路门店数字货架拣货。")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                            modifier = Modifier.fillMaxWidth().testTag("rider_accept_btn")
                        ) {
                            Text(text = "到达门店，启动货架拣货打包", fontSize = 12.sp)
                        }
                    }
                    OrderStatus.PICKING -> {
                        Button(
                            onClick = {
                                val currentRiders = JiushiEngine.riders.value.toMutableList()
                                val rIdx = currentRiders.indexOfFirst { it.id == activeRider.id }
                                if (rIdx != -1) {
                                    currentRiders[rIdx] = currentRiders[rIdx].copy(status = RiderStatus.EN_ROUTE)
                                }
                                JiushiEngine.riders.value = currentRiders

                                val currentOrders = JiushiEngine.activeOrders.value.toMutableList()
                                val oIdx = currentOrders.indexOfFirst { it.id == riderOrder.id }
                                if (oIdx != -1) {
                                    val timeline = JiushiEngine.deserializeTimeline(riderOrder.timelineJson).toMutableList()
                                    timeline.add(TimelineEvent(OrderStatus.OUT_FOR_DELIVERY, "骑手已取货。确认箱包密封锁闭，开启末端配送。", System.currentTimeMillis()))
                                    currentOrders[oIdx] = riderOrder.copy(
                                        orderStatus = OrderStatus.OUT_FOR_DELIVERY,
                                        timelineJson = JiushiEngine.serializeTimeline(timeline)
                                    )
                                }
                                JiushiEngine.activeOrders.value = currentOrders
                                JiushiEngine.logSystem("骑手指令：已取货，确认货品封箱，导航客户住址。")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                            modifier = Modifier.fillMaxWidth().testTag("rider_pick_complete_btn")
                        ) {
                            Text(text = "商品装箱核验，一键扫码出仓配送", fontSize = 12.sp)
                        }
                    }
                    OrderStatus.OUT_FOR_DELIVERY -> {
                        Button(
                            onClick = {
                                val currentRiders = JiushiEngine.riders.value.toMutableList()
                                val rIdx = currentRiders.indexOfFirst { it.id == activeRider.id }
                                if (rIdx != -1) {
                                    currentRiders[rIdx] = currentRiders[rIdx].copy(status = RiderStatus.ARRIVING, lat = JiushiEngine.mockCustomerLat.value, lng = JiushiEngine.mockCustomerLng.value)
                                }
                                JiushiEngine.riders.value = currentRiders

                                val currentOrders = JiushiEngine.activeOrders.value.toMutableList()
                                val oIdx = currentOrders.indexOfFirst { it.id == riderOrder.id }
                                if (oIdx != -1) {
                                    val timeline = JiushiEngine.deserializeTimeline(riderOrder.timelineJson).toMutableList()
                                    timeline.add(TimelineEvent(OrderStatus.DELIVERY_AGE_CHECK, "骑手已抵达敲门。触发当面年龄资格验证...", System.currentTimeMillis()))
                                    currentOrders[oIdx] = riderOrder.copy(
                                        orderStatus = OrderStatus.DELIVERY_AGE_CHECK,
                                        timelineJson = JiushiEngine.serializeTimeline(timeline)
                                    )
                                }
                                JiushiEngine.activeOrders.value = currentOrders
                                JiushiEngine.logSystem("骑手指令：已安全抵达客户大门，呼叫顾客开门并触发当面人证核验。")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Burgundy),
                            modifier = Modifier.fillMaxWidth().testTag("rider_arrive_btn")
                        ) {
                            Text(text = "到达大门（敲门），发起当面合规核验", fontSize = 12.sp)
                        }
                    }
                    OrderStatus.DELIVERY_AGE_CHECK -> {
                        // Rider face-to-face compliance check form
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFBFBF9)),
                            border = BorderStroke(1.dp, Color.LightGray),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "🔴 配送现场人证合规核验指示 (强制限制)：",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AlertRed
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "请严格对本单客户出示的【居民身份证/实体卡】进行人工核验。人证对照无误、且出生日期显示确已满18周岁，方可准予授权签收。",
                                    fontSize = 10.sp,
                                    lineHeight = 14.sp
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            JiushiEngine.confirmDeliveryAgeResult(riderOrder.id, DeliveryAgeState.APPROVED)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                        modifier = Modifier.weight(1f).testTag("rider_confirm_age_ok")
                                    ) {
                                        Text(text = "人证比对一致(交付签收)", fontSize = 10.sp)
                                    }

                                    Button(
                                        onClick = {
                                            JiushiEngine.confirmDeliveryAgeResult(riderOrder.id, DeliveryAgeState.REFUSED)
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                                        modifier = Modifier.weight(1.0f).testTag("rider_refuse_minor")
                                    ) {
                                        Text(text = "核验不符/未成年(阻断拒交付)", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                    else -> {
                        Text(text = "当前配送订单处理状态: ${riderOrder.orderStatus.name} (流程由仿真引擎自主履约中...)", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// 3. DIGITAL TWIN HUB VIEW
// --------------------------------------------------------------------------------------------------
@Composable
fun DigitalTwinView() {
    val stores by JiushiEngine.stores.collectAsState()
    val warehouses by JiushiEngine.warehouses.collectAsState()
    val activeOrders by JiushiEngine.activeOrders.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Store Twin, 1: Warehouse Twin

    var selectedRackId by remember { mutableStateOf<String?>(null) }
    var selectedRackProducts by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp)
    ) {
        // Digital twin layout selections
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { activeTab = 0 },
                colors = ButtonDefaults.buttonColors(containerColor = if (activeTab == 0) Burgundy else Color(0xFF333336)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "南京西路智能旗舰店 数字化数字孪生", fontSize = 11.sp)
            }

            Button(
                onClick = { activeTab = 1 },
                colors = ButtonDefaults.buttonColors(containerColor = if (activeTab == 1) Burgundy else Color(0xFF333336)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "城北枢纽城市前置仓 数字化数字孪生", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Digital Layout twin display
        if (activeTab == 0) {
            // High fidelity Store layout
            val store = stores.firstOrNull()
            if (store == null) {
                Text(text = "正在初始化数字门店孪生环境...", color = Color.White)
                return
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Map layout canvas 2D
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                        .border(1.dp, Color(0xFF333336), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text(text = "门店内部传感器及分布式电子标签布局图 (2D孪生)：", fontSize = 11.sp, color = BrushedMetal)
                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                            .border(1.dp, Color(0xFF444446), RoundedCornerShape(8.dp))
                            .background(Color(0xFF151517))
                    ) {
                        // Drawing custom grids to represent sections in store
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TwinShelfCard(
                                    section = "白酒恒温柜 A-01",
                                    status = "正常",
                                    count = store.stockMap.filter { it.key.startsWith("B") }.values.sum(),
                                    onClick = {
                                        selectedRackId = "白酒恒温柜 A-01"
                                        selectedRackProducts = store.stockMap.filter { it.key.startsWith("B") }.toList()
                                    }
                                )

                                TwinShelfCard(
                                    section = "葡萄酒冷藏区 B-02",
                                    status = "正常",
                                    count = store.stockMap.filter { it.key.startsWith("W") }.values.sum(),
                                    onClick = {
                                        selectedRackId = "葡萄酒冷藏区 B-02"
                                        selectedRackProducts = store.stockMap.filter { it.key.startsWith("W") }.toList()
                                    }
                                )
                            }

                            // Middle checkout and rider station
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(60.dp)
                                        .background(Color(0xFF2C2C2E), RoundedCornerShape(6.dp))
                                        .border(1.dp, Burgundy, RoundedCornerShape(6.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(text = "物联网打包取件台", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text(text = "正常 (待取: ${activeOrders.count { it.orderStatus == OrderStatus.PICKING }})", fontSize = 8.sp, color = SuccessGreen)
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(60.dp)
                                        .background(Color(0xFF2C2C2E), RoundedCornerShape(6.dp))
                                        .border(1.dp, Color(0xFF333336), RoundedCornerShape(6.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text(text = "智能自提柜 S-09", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        Text(text = "自提就绪", fontSize = 8.sp, color = SuccessGreen)
                                    }
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TwinShelfCard(
                                    section = "手工黄酒坛 C-03",
                                    status = "正常",
                                    count = store.stockMap.filter { it.key.startsWith("Y") }.values.sum(),
                                    onClick = {
                                        selectedRackId = "手工黄酒坛 C-03"
                                        selectedRackProducts = store.stockMap.filter { it.key.startsWith("Y") }.toList()
                                    }
                                )

                                TwinShelfCard(
                                    section = "威士忌珍藏阁 D-04",
                                    status = "正常",
                                    count = store.stockMap.filter { it.key.startsWith("K") }.values.sum(),
                                    onClick = {
                                        selectedRackId = "威士忌珍藏阁 D-04"
                                        selectedRackProducts = store.stockMap.filter { it.key.startsWith("K") }.toList()
                                    }
                                )
                            }
                        }
                    }
                }

                // Selected Details list bar
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(text = "数字标签遥测细节：", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (selectedRackId == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(text = "点击左侧数字孪生货架\n查看该货位SKU库存明细", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    } else {
                        Text(text = "选中货架: $selectedRackId", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(selectedRackProducts) { pair ->
                                val p = JiushiEngine.products.value.find { it.id == pair.first }
                                if (p != null) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF2C2C2E), RoundedCornerShape(6.dp))
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = p.name, fontSize = 10.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(text = "ID: ${p.id}", fontSize = 8.sp, color = BrushedMetal)
                                        }
                                        Text(text = "存: ${pair.second}瓶", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // High fidelity Warehouse Twin
            val wh = warehouses.firstOrNull()
            if (wh == null) {
                Text(text = "正在初始化城北枢纽仓数字化界面...", color = Color.White)
                return
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1.3f)
                        .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text(text = "城北枢纽前置仓库区域状态：", fontSize = 11.sp, color = BrushedMetal)
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(wh.zones) { zone ->
                            Surface(
                                color = Color(0xFF2C2C2E),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF3E3E42)),
                                modifier = Modifier
                                    .height(80.dp)
                                    .clickable {
                                        selectedRackId = zone
                                        // Pick random products that correspond to category
                                        selectedRackProducts = wh.stockMap.toList().shuffled().take(4)
                                    }
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                    Text(text = zone, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "物联网锁：安全", fontSize = 9.sp, color = SuccessGreen)
                                        Text(text = "温区: 12°C", fontSize = 9.sp, color = BrushedMetal)
                                    }
                                }
                            }
                        }
                    }
                }

                // Selected Details
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(text = "枢纽仓货柜标签查询：", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (selectedRackId == null) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(text = "点击左侧区域名称\n读取城北枢纽库位传感器明细", color = Color.Gray, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    } else {
                        Text(text = "选中仓库存储区: $selectedRackId", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(selectedRackProducts) { pair ->
                                val p = JiushiEngine.products.value.find { it.id == pair.first }
                                if (p != null) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF2C2C2E), RoundedCornerShape(6.dp))
                                            .padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = p.name, fontSize = 10.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(text = "ID: ${p.id}", fontSize = 8.sp, color = BrushedMetal)
                                        }
                                        Text(text = "${pair.second * 8}瓶", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = SuccessGreen)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TwinShelfCard(section: String, status: String, count: Int, onClick: () -> Unit) {
    Surface(
        color = Color(0xFF2C2C2E),
        border = BorderStroke(1.dp, Color(0xFF3E3E42)),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .width(130.dp)
            .height(80.dp)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = section, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "遥测: $status", fontSize = 8.sp, color = SuccessGreen)
                Text(text = "$count 瓶", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = IvoryLight)
            }
        }
    }
}

// --------------------------------------------------------------------------------------------------
// 4. CONTROL & COMPLIANCE ADMIN VIEW
// --------------------------------------------------------------------------------------------------
@Composable
fun AdminConsoleView() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val selectedCity by JiushiEngine.selectedCity.collectAsState()
    val stores by JiushiEngine.stores.collectAsState()
    val warehouses by JiushiEngine.warehouses.collectAsState()
    val riders by JiushiEngine.riders.collectAsState()
    val activeOrders by JiushiEngine.activeOrders.collectAsState()
    val complianceLogs by JiushiEngine.complianceLogs.collectAsState()

    var activePanel by remember { mutableStateOf(0) } // 0: Live Map, 1: Compliance Logs, 2: Analytics

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp)
    ) {
        // Mode switch tabs
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { activePanel = 0 },
                colors = ButtonDefaults.buttonColors(containerColor = if (activePanel == 0) Burgundy else Color(0xFF333336)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "城市配送与调度地图", fontSize = 11.sp)
            }

            Button(
                onClick = { activePanel = 1 },
                colors = ButtonDefaults.buttonColors(containerColor = if (activePanel == 1) Burgundy else Color(0xFF333336)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "实名年龄合规审计日志", fontSize = 11.sp)
            }

            Button(
                onClick = { activePanel = 2 },
                colors = ButtonDefaults.buttonColors(containerColor = if (activePanel == 2) Burgundy else Color(0xFF333336)),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "酒类限售分析大盘", fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        when (activePanel) {
            0 -> {
                // Interactive Vector Map simulation
                Row(modifier = Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Column(
                        modifier = Modifier
                            .weight(1.3f)
                            .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "[$selectedCity] 城市酒市网格物理节点分布图 (实时遥测模拟)：",
                            fontSize = 11.sp,
                            color = BrushedMetal
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        // Drawing Synthetic Canvas Map
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF151517))
                        ) {
                            CanvasMap(
                                stores = stores,
                                warehouses = warehouses,
                                riders = riders,
                                customerLat = JiushiEngine.mockCustomerLat.value,
                                customerLng = JiushiEngine.mockCustomerLng.value
                            )
                        }
                    }

                    // Active dispatches on map
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                            .padding(16.dp)
                    ) {
                        Text(text = "动态运输调度时间线：", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                        Spacer(modifier = Modifier.height(8.dp))

                        val activeList = activeOrders.filter { it.orderStatus != OrderStatus.COMPLETED && it.orderStatus != OrderStatus.CANCELLED }

                        if (activeList.isEmpty()) {
                            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text(text = "暂无活跃调度单在途", color = Color.Gray, fontSize = 11.sp)
                            }
                        } else {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(activeList) { ord ->
                                    val rider = riders.find { it.id == ord.riderId }
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color(0xFF2C2C2E), RoundedCornerShape(8.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(text = "订单 #${ord.id}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                            Text(
                                                text = "派送员: ${rider?.name ?: "待指派"}",
                                                fontSize = 9.sp,
                                                color = BrushedMetal
                                            )
                                            Text(text = "状态: ${ord.orderStatus.name}", fontSize = 9.sp, color = WarningOrange)
                                        }

                                        // Quick override option if blocked in AGE_CHECK
                                        if (ord.orderStatus == OrderStatus.AGE_CHECK) {
                                            Button(
                                                onClick = {
                                                    JiushiEngine.verifyUserAgeAndReleaseOrder(ord.id, "合规人工授权官", "310101199001018888")
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                                shape = RoundedCornerShape(4.dp),
                                                modifier = Modifier.height(28.dp).padding(horizontal = 2.dp)
                                            ) {
                                                Text(text = "人工放行", fontSize = 8.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            1 -> {
                // High density Compliance Audit Logs view
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(text = "⚠️ 平台实名限制与人工合规审计日志：", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                    Text(text = "所有对18岁以下未成年人的拦截，均被加密记录于国家级平台合规日志，永久不可篡改。", fontSize = 10.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (complianceLogs.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(text = "暂无合规审计事件。", color = Color.Gray, fontSize = 11.sp)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(complianceLogs) { log ->
                                val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(Date(log.timestamp))
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (log.status == "BLOCKED") Color(0xFF3B1E22) else Color(0xFF2C2C2E)
                                    ),
                                    border = BorderStroke(1.dp, if (log.status == "BLOCKED") AlertRed else Color(0xFF3E3E42)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "时间: $dateStr", fontSize = 9.sp, color = BrushedMetal)
                                            Text(
                                                text = log.eventType,
                                                fontSize = 9.sp,
                                                color = if (log.status == "BLOCKED") AlertRed else SuccessGreen,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(text = log.description, fontSize = 11.sp, color = Color.White)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(text = "执行审计责任人: ${log.operatorName}", fontSize = 9.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                // High density Analytics report
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .background(Color(0xFF1F1F21), RoundedCornerShape(12.dp))
                        .padding(16.dp)
                ) {
                    Text(text = "酒水在线网络核心运营与风控指标遥测：", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Burgundy)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            MetricCard(title = "累计GMV(模拟)", value = "¥${String.format("%.2f", activeOrders.filter { it.orderStatus != OrderStatus.CANCELLED }.sumOf { it.finalPrice })}", color = SuccessGreen)
                            Spacer(modifier = Modifier.height(12.dp))
                            MetricCard(title = "履约订单量", value = "${activeOrders.size} 笔", color = Color.White)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            MetricCard(title = "现场未满18拦截率", value = "${String.format("%.1f", (complianceLogs.count { it.status == "BLOCKED" }.toDouble() / (complianceLogs.size.coerceAtLeast(1))).coerceAtMost(1.0) * 100)}%", color = AlertRed)
                            Spacer(modifier = Modifier.height(12.dp))
                            MetricCard(title = "骑手平均送达率", value = "98.8%", color = SuccessGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Text(text = "门店实时仓储库存容量遥测比例：", fontSize = 11.sp, color = BrushedMetal)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Simulated interactive dynamic bar
                    stores.forEach { st ->
                        val used = st.stockMap.values.sum()
                        val percent = (used.toFloat() / st.warehouseCapacity.toFloat()).coerceAtMost(1f)
                        Column(modifier = Modifier.padding(vertical = 6.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(text = st.name, fontSize = 10.sp, color = Color.White)
                                Text(text = "货架利用: ${String.format("%.0f", percent * 100)}% ($used/${st.warehouseCapacity} 瓶)", fontSize = 10.sp, color = BrushedMetal)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = percent,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = Burgundy,
                                trackColor = Color(0xFF3A3A3C)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, color: Color) {
    Surface(
        color = Color(0xFF2C2C2E),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, Color(0xFF3E3E42)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 10.sp, color = BrushedMetal)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun CanvasMap(
    stores: List<Store>,
    warehouses: List<Warehouse>,
    riders: List<Rider>,
    customerLat: Double,
    customerLng: Double
) {
    // Drawn via Custom DrawBehind logic for simplicity & performance
    // Translate geographic coordinates to Local Canvas offsets
    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                val width = size.width
                val height = size.height

                // Grid scale references
                // We map a bounding box centered on user coordinates
                // Lat: 31.2100 to 31.2500, Lng: 121.4500 to 121.5000 (roughly for Shanghai)
                // Let's dynamically find bounding box
                val padding = 0.04
                val minLat = customerLat - padding
                val maxLat = customerLat + padding
                val minLng = customerLng - padding
                val maxLng = customerLng + padding

                fun toX(lng: Double): Float {
                    return (((lng - minLng) / (maxLng - minLng)) * width).toFloat()
                }

                fun toY(lat: Double): Float {
                    // Invert Y coordinate because top of screen is Y=0
                    return ((1.0 - ((lat - minLat) / (maxLat - minLat))) * height).toFloat()
                }

                // 1. Draw subtle background coordinate grid
                val gridCount = 8
                for (i in 0..gridCount) {
                    val x = (width / gridCount) * i
                    drawLine(
                        color = Color(0xFF222225),
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1f
                    )
                    val y = (height / gridCount) * i
                    drawLine(
                        color = Color(0xFF222225),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                }

                // 2. Draw Customer Base Destination
                val cx = toX(customerLng)
                val cy = toY(customerLat)
                drawCircle(
                    color = Color.White,
                    radius = 16f,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = AlertRed,
                    radius = 8f,
                    center = Offset(cx, cy)
                )

                // 3. Draw Warehouse Nodes (Solid Hex)
                warehouses.forEach { wh ->
                    val wx = toX(wh.lng)
                    val wy = toY(wh.lat)
                    drawRect(
                        color = Color(0xFFF2A900), // Gold
                        topLeft = Offset(wx - 10f, wy - 10f),
                        size = androidx.compose.ui.geometry.Size(20f, 20f)
                    )
                }

                // 4. Draw Store Nodes (Rippled Circles)
                stores.forEach { st ->
                    val sx = toX(st.lng)
                    val sy = toY(st.lat)
                    drawCircle(
                        color = Burgundy,
                        radius = 12f,
                        center = Offset(sx, sy)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4f,
                        center = Offset(sx, sy)
                    )
                }

                // 5. Draw Riders and Route Trails
                riders.forEach { rd ->
                    val rx = toX(rd.lng)
                    val ry = toY(rd.lat)

                    // Draw route lines to store or customer if busy
                    if (rd.status != RiderStatus.AVAILABLE && rd.currentOrderId != null) {
                        // Find connected store and draw dashed path
                        val ord = JiushiEngine.activeOrders.value.find { it.id == rd.currentOrderId }
                        val store = stores.find { it.id == ord?.storeId }
                        if (store != null) {
                            val sx = toX(store.lng)
                            val sy = toY(store.lat)

                            // Dash route line
                            drawLine(
                                color = WarningOrange,
                                start = Offset(sx, sy),
                                end = Offset(cx, cy),
                                strokeWidth = 2f,
                                pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                            )
                        }
                    }

                    // Draw rider as warning orange dot
                    drawCircle(
                        color = WarningOrange,
                        radius = 8f,
                        center = Offset(rx, ry)
                    )
                }
            }
    ) {
        // Legend overlays
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(12.dp)
                .background(Color(0xDD151517), RoundedCornerShape(6.dp))
                .padding(8.dp)
        ) {
            MapLegendItem(color = AlertRed, label = "用户送达地址")
            MapLegendItem(color = Burgundy, label = "零售数字化门店")
            MapLegendItem(color = Color(0xFFF2A900), label = "城北枢纽仓")
            MapLegendItem(color = WarningOrange, label = "末端骑手配送车")
        }
    }
}

@Composable
fun MapLegendItem(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        Box(modifier = Modifier.size(8.dp).background(color, RoundedCornerShape(4.dp)))
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = label, fontSize = 9.sp, color = IvoryLight)
    }
}

// --------------------------------------------------------------------------------------------------
// 5. SIMULATION CLOCK PANEL VIEW
// --------------------------------------------------------------------------------------------------
@Composable
fun SimulationControlPanel() {
    val context = LocalContext.current
    val isPaused by JiushiEngine.isPaused.collectAsState()
    val speedMultiplier by JiushiEngine.speedMultiplier.collectAsState()
    val simulationLogs by JiushiEngine.simulationLogs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GraphiteDark)
            .padding(16.dp)
    ) {
        Text(text = "酒市网络数字仿真控制器：", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Burgundy)
        Text(text = "在此控制或模拟商品发货、时间流逝倍率、及重置全网合成商业网络。", fontSize = 11.sp, color = Color.Gray)

        Spacer(modifier = Modifier.height(16.dp))

        // Actions cards
        Card(
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1F1F21)),
            border = BorderStroke(1.dp, Color(0xFF333336)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "时钟仿真频率控制：", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { JiushiEngine.isPaused.value = !isPaused },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isPaused) SuccessGreen else AlertRed),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = if (isPaused) "继续时钟步进 ▶" else "暂停仿真时钟 ⏸", fontSize = 11.sp)
                    }

                    Row(modifier = Modifier.weight(1.5f), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val speeds = listOf(1, 2, 10, 30)
                        speeds.forEach { sp ->
                            Surface(
                                color = if (speedMultiplier == sp) Burgundy else Color(0xFF2C2C2E),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { JiushiEngine.speedMultiplier.value = sp }
                            ) {
                                Box(modifier = Modifier.padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                                    Text(text = "${sp}x", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Logs terminal console
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFF151517), RoundedCornerShape(8.dp))
                .border(1.dp, Color(0xFF2A2A2E), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "仿真服务器实时遥测日志：", fontSize = 11.sp, color = SuccessGreen, fontWeight = FontWeight.Bold)
                Text(
                    text = "系统完全复位重置",
                    fontSize = 11.sp,
                    color = AlertRed,
                    modifier = Modifier
                        .clickable { JiushiEngine.resetSimulation(context) }
                        .padding(4.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(simulationLogs) { log ->
                    Text(
                        text = log,
                        fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = if (log.contains("合规") || log.contains("拦截")) AlertRed else Color.LightGray,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}
