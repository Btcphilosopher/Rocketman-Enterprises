package com.example.engine

import android.content.Context
import android.util.Log
import com.example.data.SyntheticData
import com.example.domain.*
import com.example.database.JiushiDatabase
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlin.math.sqrt
import kotlin.random.Random

object JiushiEngine {

    private val TAG = "JiushiEngine"

    // Moshi JSON support for DB serialization
    val moshi: Moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    val cartItemAdapter = moshi.adapter<List<CartItem>>(
        Types.newParameterizedType(List::class.java, CartItem::class.java)
    )
    val timelineAdapter = moshi.adapter<List<TimelineEvent>>(
        Types.newParameterizedType(List::class.java, TimelineEvent::class.java)
    )

    private val engineScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var simJob: Job? = null

    // Shared Flow States (Single Source of Truth)
    val selectedCity = MutableStateFlow("上海")
    val currentCityCenter = MutableStateFlow(Pair(31.2304, 121.4737))

    val products = MutableStateFlow<List<Product>>(SyntheticData.products)
    val stores = MutableStateFlow<List<Store>>(emptyList())
    val warehouses = MutableStateFlow<List<Warehouse>>(emptyList())
    val riders = MutableStateFlow<List<Rider>>(emptyList())
    val cart = MutableStateFlow<List<CartItem>>(emptyList())

    val activeOrders = MutableStateFlow<List<Order>>(emptyList())
    val complianceLogs = MutableStateFlow<List<ComplianceLog>>(emptyList())
    val simulationLogs = MutableStateFlow<List<String>>(listOf("系统初始化完成。"))

    // Simulation Clock & Variables
    val isPaused = MutableStateFlow(false)
    val speedMultiplier = MutableStateFlow(1) // 1x, 2x, 10x, 30x
    val simTickCount = MutableStateFlow(0L)
    val totalGMV = MutableStateFlow(0.0)
    val totalOrdersCount = MutableStateFlow(0)
    val complianceAlertCount = MutableStateFlow(0)

    // User Simulation Mock Location Offset
    // Customer sits at cityCenter + (0.015, -0.010)
    val mockCustomerAddress = MutableStateFlow("长乐路雅苑二期A栋802室")
    val mockCustomerLat = MutableStateFlow(31.2304 + 0.012)
    val mockCustomerLng = MutableStateFlow(121.4737 - 0.008)

    // Current User Age Verification status
    val userAgeState = MutableStateFlow(AgeVerifiedState.NONE)
    val userAgeVerifiedName = MutableStateFlow("")
    val userAgeVerifiedIdMask = MutableStateFlow("")

    private var db: JiushiDatabase? = null

    fun initialize(context: Context) {
        db = JiushiDatabase.getDatabase(context)

        // Load historical logs and orders from Room Database
        engineScope.launch {
            db?.orderDao()?.getAllOrders()?.collect { dbOrders ->
                // Wait! To keep UI states updated, merge DB orders if we don't have them in memory
                val currentIds = activeOrders.value.map { it.id }.toSet()
                val merged = activeOrders.value.toMutableList()
                dbOrders.forEach { dbOrder ->
                    if (dbOrder.id !in currentIds) {
                        merged.add(dbOrder)
                    }
                }
                activeOrders.value = merged
                totalOrdersCount.value = merged.size
                totalGMV.value = merged.filter { it.orderStatus != OrderStatus.CANCELLED }.sumOf { it.finalPrice }
            }
        }

        engineScope.launch {
            db?.complianceLogDao()?.getAllLogs()?.collect { dbLogs ->
                complianceLogs.value = dbLogs
                complianceAlertCount.value = dbLogs.count { it.status == "FAILED" || it.status == "BLOCKED" }
            }
        }

        // Initialize infrastructure for default city
        switchCity("上海")

        // Start background simulation thread
        startSimulation()
    }

    fun switchCity(city: String) {
        selectedCity.value = city
        val center = SyntheticData.cityCenters[city] ?: Pair(31.2304, 121.4737)
        currentCityCenter.value = center
        mockCustomerLat.value = center.first + 0.012
        mockCustomerLng.value = center.second - 0.008

        // Generate infrastructure
        val (newStores, newWarehouses, newRiders) = SyntheticData.generateInfrastructureForCity(city)
        stores.value = newStores
        warehouses.value = newWarehouses
        riders.value = newRiders

        logSystem("切换城市到 [$city]，匹配门店数: ${newStores.size}，仓库数: ${newWarehouses.size}，骑手：${newRiders.size}人。")
    }

    private fun startSimulation() {
        simJob?.cancel()
        simJob = engineScope.launch {
            while (isActive) {
                if (!isPaused.value) {
                    simTickCount.value += 1
                    tickSimulation()
                }
                // Delay based on speedMultiplier
                val interval = when (speedMultiplier.value) {
                    1 -> 1500L
                    2 -> 800L
                    10 -> 250L
                    30 -> 80L
                    else -> 1000L
                }
                delay(interval)
            }
        }
    }

    private suspend fun tickSimulation() {
        // 1. Move Active Riders & Process Orders status
        val currentOrders = activeOrders.value.toMutableList()
        val currentRiders = riders.value.toMutableList()
        val currentStores = stores.value.toMutableList()

        var ordersUpdated = false
        var ridersUpdated = false
        var storesUpdated = false

        for (i in currentRiders.indices) {
            val rider = currentRiders[i]
            if (rider.status != RiderStatus.AVAILABLE && rider.currentOrderId != null) {
                // Find order
                val orderIndex = currentOrders.indexOfFirst { it.id == rider.currentOrderId }
                if (orderIndex != -1) {
                    val order = currentOrders[orderIndex]
                    val store = currentStores.find { it.id == order.storeId } ?: continue

                    // Simple 2D Interpolation toward destination
                    val targetLat: Double
                    val targetLng: Double
                    val isHeadingToStore = rider.status == RiderStatus.GOING_TO_STORE || rider.status == RiderStatus.ASSIGNED

                    if (isHeadingToStore) {
                        targetLat = store.lat
                        targetLng = store.lng
                    } else {
                        // Heading to Customer
                        targetLat = mockCustomerLat.value
                        targetLng = mockCustomerLng.value
                    }

                    val dx = targetLat - rider.lat
                    val dy = targetLng - rider.lng
                    val dist = sqrt(dx * dx + dy * dy)

                    // Movement speed: 0.003 degrees per tick (modified by speed multiplier)
                    val step = 0.0015 * speedMultiplier.value
                    if (dist > step) {
                        // Interpolate position
                        val ratio = step / dist
                        val newRider = rider.copy(
                            lat = rider.lat + dx * ratio,
                            lng = rider.lng + dy * ratio
                        )
                        currentRiders[i] = newRider
                        ridersUpdated = true
                    } else {
                        // Arrived at intermediate or final destination
                        val newRider = rider.copy(lat = targetLat, lng = targetLng)
                        currentRiders[i] = newRider
                        ridersUpdated = true

                        // Check status and progress order
                        if (isHeadingToStore) {
                            // Arrived at store! Transition to PICKING / PICKING_UP
                            val updatedRider = newRider.copy(status = RiderStatus.PICKING_UP)
                            currentRiders[i] = updatedRider

                            val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()
                            updatedTimeline.add(TimelineEvent(OrderStatus.PICKING, "骑手已到达门店 [${store.name}]，开始取货。", System.currentTimeMillis()))

                            val updatedOrder = order.copy(
                                orderStatus = OrderStatus.PICKING,
                                timelineJson = serializeTimeline(updatedTimeline)
                            )
                            currentOrders[orderIndex] = updatedOrder
                            ordersUpdated = true

                            logSystem("订单 [${order.id}] 骑手已到店，开始拣货打包。")
                            db?.orderDao()?.insertOrder(updatedOrder)
                        } else {
                            // Arrived at Customer! Transition to DELIVERY_AGE_CHECK
                            if (rider.status == RiderStatus.EN_ROUTE || rider.status == RiderStatus.ARRIVING) {
                                val updatedRider = newRider.copy(status = RiderStatus.ARRIVING)
                                currentRiders[i] = updatedRider

                                val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()
                                updatedTimeline.add(TimelineEvent(OrderStatus.DELIVERY_AGE_CHECK, "骑手已到达配送地址，正在进行人脸/身份证合规核验。", System.currentTimeMillis()))

                                val updatedOrder = order.copy(
                                    orderStatus = OrderStatus.DELIVERY_AGE_CHECK,
                                    timelineJson = serializeTimeline(updatedTimeline)
                                )
                                currentOrders[orderIndex] = updatedOrder
                                ordersUpdated = true

                                logSystem("订单 [${order.id}] 骑手送达地址，启动合规交付核验。")
                                db?.orderDao()?.insertOrder(updatedOrder)
                            }
                        }
                    }
                }
            }
        }

        // Simulate packing / picking task completed after random ticks
        for (i in currentOrders.indices) {
            val order = currentOrders[i]
            if (order.orderStatus == OrderStatus.PICKING) {
                // If picking, random chance or clock tick allows transitioning to OUT_FOR_DELIVERY
                if (Random.nextInt(4) == 0 || speedMultiplier.value >= 10) {
                    val riderIndex = currentRiders.indexOfFirst { it.id == order.riderId }
                    if (riderIndex != -1) {
                        val rider = currentRiders[riderIndex]
                        currentRiders[riderIndex] = rider.copy(status = RiderStatus.EN_ROUTE)
                        ridersUpdated = true
                    }

                    val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()
                    updatedTimeline.add(TimelineEvent(OrderStatus.OUT_FOR_DELIVERY, "商品打包拣货完毕，骑手正携单快马加鞭配送中。", System.currentTimeMillis()))

                    val updatedOrder = order.copy(
                        orderStatus = OrderStatus.OUT_FOR_DELIVERY,
                        timelineJson = serializeTimeline(updatedTimeline)
                    )
                    currentOrders[i] = updatedOrder
                    ordersUpdated = true

                    logSystem("订单 [${order.id}] 打包出库，骑手开始配送。")
                    db?.orderDao()?.insertOrder(updatedOrder)
                }
            }
        }

        // 2. Background Orders Simulation (Generating dynamic logs & dispatch animations for realism)
        // If speed is fast or randomly, let's create random background consumer transactions
        if (Random.nextInt(15) == 0 && currentOrders.size < 50) {
            simulateBackgroundOrder(currentOrders, currentRiders, currentStores)
            ordersUpdated = true
            ridersUpdated = true
            storesUpdated = true
        }

        // Update StateFlows if modified
        if (ordersUpdated) activeOrders.value = currentOrders
        if (ridersUpdated) riders.value = currentRiders
        if (storesUpdated) stores.value = currentStores
    }

    private suspend fun simulateBackgroundOrder(
        currentOrders: MutableList<Order>,
        currentRiders: MutableList<Rider>,
        currentStores: MutableList<Store>
    ) {
        val randomProduct = products.value.random()
        val randomStore = currentStores.random()
        val currentCity = selectedCity.value

        // Select available rider
        val availableRiderIndex = currentRiders.indexOfFirst { it.status == RiderStatus.AVAILABLE }
        if (availableRiderIndex == -1) return // No rider to dispatch

        val rider = currentRiders[availableRiderIndex]
        val orderId = "JS${Random.nextInt(100000, 999999)}"

        // Simulate Age Verification for background order
        val agePassed = Random.nextInt(10) != 0 // 10% fail rate for audit simulation
        val ageState = if (agePassed) AgeVerifiedState.PASSED else AgeVerifiedState.FAILED

        val cartItem = CartItem(randomProduct, 1)
        val itemsJson = cartItemAdapter.toJson(listOf(cartItem))

        val fee = 5.0
        val discount = 0.0
        val finalPrice = randomProduct.price + fee

        val timeline = mutableListOf(
            TimelineEvent(OrderStatus.ORDER_CREATED, "背景模拟消费者提交了购买订单。", System.currentTimeMillis())
        )

        if (ageState == AgeVerifiedState.FAILED) {
            // Log compliance block immediately
            timeline.add(TimelineEvent(OrderStatus.CANCELLED, "人脸实名年龄审核拒绝：未满18周岁拦截购买。", System.currentTimeMillis()))
            val order = Order(
                id = orderId,
                itemsJson = itemsJson,
                totalPrice = randomProduct.price,
                deliveryFee = fee,
                promoDiscount = discount,
                finalPrice = finalPrice,
                deliveryMethod = DeliveryMethod.INSTANT,
                paymentMethod = "支付宝",
                paymentStatus = PaymentStatus.PAYMENT_CANCELLED,
                orderStatus = OrderStatus.CANCELLED,
                city = currentCity,
                shippingAddress = "${currentCity}市商业区随机公寓 ${Random.nextInt(100, 999)}号",
                riderId = null,
                storeId = randomStore.id,
                warehouseId = null,
                ageVerifiedState = ageState,
                deliveryAgeState = DeliveryAgeState.NONE,
                etaMinutes = 0,
                timestamp = System.currentTimeMillis(),
                timelineJson = serializeTimeline(timeline)
            )
            currentOrders.add(0, order)

            val log = ComplianceLog(
                orderId = orderId,
                eventType = "BLOCKED_ORDER",
                description = "模拟订单人脸拦截。原因：未达到18周岁定级限制。",
                status = "BLOCKED",
                operatorName = "AI安全卫士系统"
            )
            db?.complianceLogDao()?.insertLog(log)
            db?.orderDao()?.insertOrder(order)

            logSystem("合规系统：拦截了一笔异常背景订单 [${orderId}]，收货人疑似未成年人。")
        } else {
            // Passed! Create active dispatch cycle
            timeline.add(TimelineEvent(OrderStatus.PAYMENT_SIMULATED, "模拟支付成功，生成待指派订单。", System.currentTimeMillis()))
            timeline.add(TimelineEvent(OrderStatus.STORE_ACCEPTED, "商户门店已接单，指派骑手 [${rider.name}]。", System.currentTimeMillis()))

            val order = Order(
                id = orderId,
                itemsJson = itemsJson,
                totalPrice = randomProduct.price,
                deliveryFee = fee,
                promoDiscount = discount,
                finalPrice = finalPrice,
                deliveryMethod = DeliveryMethod.INSTANT,
                paymentMethod = "微信支付",
                paymentStatus = PaymentStatus.PAYMENT_SUCCESS,
                orderStatus = OrderStatus.STORE_ACCEPTED,
                city = currentCity,
                shippingAddress = "${currentCity}市住宅社区随机住宅 ${Random.nextInt(100, 999)}室",
                riderId = rider.id,
                storeId = randomStore.id,
                warehouseId = null,
                ageVerifiedState = AgeVerifiedState.PASSED,
                deliveryAgeState = DeliveryAgeState.NONE,
                etaMinutes = 30,
                timestamp = System.currentTimeMillis(),
                timelineJson = serializeTimeline(timeline)
            )

            currentOrders.add(0, order)
            currentRiders[availableRiderIndex] = rider.copy(
                status = RiderStatus.GOING_TO_STORE,
                currentOrderId = orderId
            )

            // Deduct stock from store
            val currentStock = randomStore.stockMap[randomProduct.id] ?: 0
            if (currentStock > 0) {
                val updatedStock = randomStore.stockMap.toMutableMap()
                updatedStock[randomProduct.id] = currentStock - 1
                val storeIndex = currentStores.indexOfFirst { it.id == randomStore.id }
                if (storeIndex != -1) {
                    currentStores[storeIndex] = randomStore.copy(stockMap = updatedStock)
                }
            }

            db?.orderDao()?.insertOrder(order)
            logSystem("新背景配送订单：[${orderId}]，门店 [${randomStore.name}] 接单，配送员 [${rider.name}] 已出发取货。")
        }

        totalOrdersCount.value = currentOrders.size
        totalGMV.value = currentOrders.filter { it.orderStatus != OrderStatus.CANCELLED }.sumOf { it.finalPrice }
    }

    // Explicit User Order Actions
    fun submitUserOrder(
        items: List<CartItem>,
        deliveryMethod: DeliveryMethod,
        address: String,
        paymentMethod: String
    ): String {
        val currentCity = selectedCity.value
        val orderId = "JS${Random.nextInt(100000, 999999)}"

        // Match Store with Stock & Distance
        val availableStore = stores.value.firstOrNull { store ->
            items.all { cartItem -> (store.stockMap[cartItem.product.id] ?: 0) >= cartItem.quantity }
        } ?: stores.value.first() // Fallback to first store

        val totalAmount = items.sumOf { it.product.price * it.quantity }
        val fee = if (deliveryMethod == DeliveryMethod.PICKUP) 0.0 else 5.0
        val discount = 0.0
        val finalPrice = totalAmount + fee

        val timeline = mutableListOf(
            TimelineEvent(OrderStatus.ORDER_CREATED, "用户订单提交成功，等待年龄核验与商户接单。", System.currentTimeMillis())
        )

        val itemsJson = cartItemAdapter.toJson(items)

        val order = Order(
            id = orderId,
            itemsJson = itemsJson,
            totalPrice = totalAmount,
            deliveryFee = fee,
            promoDiscount = discount,
            finalPrice = finalPrice,
            deliveryMethod = deliveryMethod,
            paymentMethod = paymentMethod,
            paymentStatus = PaymentStatus.PAYMENT_PENDING,
            orderStatus = OrderStatus.ORDER_CREATED,
            city = currentCity,
            shippingAddress = address,
            riderId = null,
            storeId = availableStore.id,
            warehouseId = null,
            ageVerifiedState = userAgeState.value,
            deliveryAgeState = DeliveryAgeState.NONE,
            etaMinutes = 25,
            timestamp = System.currentTimeMillis(),
            timelineJson = serializeTimeline(timeline),
            ageVerificationData = if (userAgeState.value == AgeVerifiedState.PASSED) {
                "${userAgeVerifiedName.value} | ${userAgeVerifiedIdMask.value}"
            } else null
        )

        val updatedOrders = activeOrders.value.toMutableList()
        updatedOrders.add(0, order)
        activeOrders.value = updatedOrders
        totalOrdersCount.value = updatedOrders.size

        logSystem("核心订单流：用户成功创建了一笔酒类即时配送单 [${orderId}]，进入系统合规核验核心...")

        // Clear Cart
        cart.value = emptyList()

        // Auto trigger store accept and rider dispatch in simulation
        engineScope.launch {
            db?.orderDao()?.insertOrder(order)

            delay(1500)
            processUserOrderNextStep(orderId)
        }

        return orderId
    }

    private suspend fun processUserOrderNextStep(orderId: String) {
        val currentOrders = activeOrders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return
        var order = currentOrders[index]

        val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()

        if (order.ageVerifiedState != AgeVerifiedState.PASSED) {
            // Needs age check! Put order into blocked / review mode
            updatedTimeline.add(TimelineEvent(OrderStatus.AGE_CHECK, "合规控制：拦截未成年人或未认证身份购买，等待实名绑卡年龄核验。", System.currentTimeMillis()))
            val blockedOrder = order.copy(
                orderStatus = OrderStatus.AGE_CHECK,
                timelineJson = serializeTimeline(updatedTimeline)
            )
            currentOrders[index] = blockedOrder
            activeOrders.value = currentOrders
            db?.orderDao()?.insertOrder(blockedOrder)

            logSystem("合规预警：订单 [${orderId}] 因收货人未通过18岁实名核验，已进入 [AGE_VERIFICATION_REQUIRED] 合规熔断阻断区！")
        } else {
            // Already Verified, simulate payment success
            updatedTimeline.add(TimelineEvent(OrderStatus.PAYMENT_SIMULATED, "模拟在线支付通道成功，实付款 ¥${order.finalPrice}。", System.currentTimeMillis()))
            updatedTimeline.add(TimelineEvent(OrderStatus.STORE_ACCEPTED, "门店 [${order.storeId}] 已完成数字化接单，正在分配就近骑手...", System.currentTimeMillis()))

            // Dispatch rider
            val currentRiders = riders.value.toMutableList()
            val availableRiderIndex = currentRiders.indexOfFirst { it.status == RiderStatus.AVAILABLE }

            val finalRiderId = if (availableRiderIndex != -1) {
                val r = currentRiders[availableRiderIndex]
                currentRiders[availableRiderIndex] = r.copy(
                    status = RiderStatus.GOING_TO_STORE,
                    currentOrderId = orderId
                )
                riders.value = currentRiders
                logSystem("调度中心：订单 [${orderId}] 成功匹配即时配送骑手 [${r.name}]，已进入路径引导。")
                r.id
            } else {
                logSystem("调度中心：当前配送负载过大，订单 [${orderId}] 已进入分布式延迟队列中排队。")
                null
            }

            // Deduct stock from Store
            val currentStores = stores.value.toMutableList()
            val storeIndex = currentStores.indexOfFirst { it.id == order.storeId }
            if (storeIndex != -1) {
                val store = currentStores[storeIndex]
                val updatedStock = store.stockMap.toMutableMap()
                val orderItems = deserializeCart(order.itemsJson)
                orderItems.forEach { item ->
                    val s = updatedStock[item.product.id] ?: 10
                    updatedStock[item.product.id] = (s - item.quantity).coerceAtLeast(0)
                }
                currentStores[storeIndex] = store.copy(stockMap = updatedStock)
                stores.value = currentStores
            }

            val finalOrder = order.copy(
                orderStatus = OrderStatus.STORE_ACCEPTED,
                paymentStatus = PaymentStatus.PAYMENT_SUCCESS,
                riderId = finalRiderId,
                timelineJson = serializeTimeline(updatedTimeline)
            )
            currentOrders[index] = finalOrder
            activeOrders.value = currentOrders
            totalGMV.value = currentOrders.filter { it.orderStatus != OrderStatus.CANCELLED }.sumOf { it.finalPrice }
            db?.orderDao()?.insertOrder(finalOrder)
        }
    }

    // Complete simulated Age Verification for active User Order
    fun verifyUserAgeAndReleaseOrder(orderId: String, name: String, idCard: String): Boolean {
        userAgeState.value = AgeVerifiedState.PASSED
        userAgeVerifiedName.value = name
        userAgeVerifiedIdMask.value = idCard.take(4) + "**********" + idCard.takeLast(4)

        val currentOrders = activeOrders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return false
        val order = currentOrders[index]

        // Create audit logs
        engineScope.launch {
            val log = ComplianceLog(
                orderId = orderId,
                eventType = "AGE_VERIFICATION",
                description = "实名认证成功。证件核验收货人：${name} (${userAgeVerifiedIdMask.value})，结果：已满18周岁。",
                status = "SUCCESS",
                operatorName = "合规官人工审计"
            )
            db?.complianceLogDao()?.insertLog(log)

            val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()
            updatedTimeline.add(TimelineEvent(OrderStatus.COMPLIANCE_CHECK, "身份年龄认证审核通过，解除合规熔断阻断区，重新进入商业履行流程。", System.currentTimeMillis()))

            val updatedOrder = order.copy(
                ageVerifiedState = AgeVerifiedState.PASSED,
                orderStatus = OrderStatus.ORDER_CREATED,
                timelineJson = serializeTimeline(updatedTimeline),
                ageVerificationData = "${name} | ${userAgeVerifiedIdMask.value}"
            )
            currentOrders[index] = updatedOrder
            activeOrders.value = currentOrders
            db?.orderDao()?.insertOrder(updatedOrder)

            logSystem("合规系统：订单 [${orderId}] 身份年龄验证成功（收货人：${name}），合规官解除订单阻断释放出库！")

            delay(1000)
            processUserOrderNextStep(orderId)
        }
        return true
    }

    // Rider-side Final Delivery age confirmation
    fun confirmDeliveryAgeResult(orderId: String, status: DeliveryAgeState) {
        val currentOrders = activeOrders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return
        val order = currentOrders[index]

        val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()
        val currentRiders = riders.value.toMutableList()
        val riderIndex = currentRiders.indexOfFirst { it.id == order.riderId }

        engineScope.launch {
            if (status == DeliveryAgeState.APPROVED) {
                updatedTimeline.add(TimelineEvent(OrderStatus.DELIVERED, "骑手当面核验客户实卡，符合法定饮酒年龄资格，已成功授权交付商品并签收。", System.currentTimeMillis()))
                updatedTimeline.add(TimelineEvent(OrderStatus.COMPLETED, "订单圆满完成，系统关闭该履行时间线。", System.currentTimeMillis()))

                val completedOrder = order.copy(
                    orderStatus = OrderStatus.COMPLETED,
                    deliveryAgeState = DeliveryAgeState.APPROVED,
                    timelineJson = serializeTimeline(updatedTimeline)
                )
                currentOrders[index] = completedOrder

                if (riderIndex != -1) {
                    val r = currentRiders[riderIndex]
                    currentRiders[riderIndex] = r.copy(status = RiderStatus.AVAILABLE, currentOrderId = null)
                    riders.value = currentRiders
                }

                activeOrders.value = currentOrders
                db?.orderDao()?.insertOrder(completedOrder)

                val log = ComplianceLog(
                    orderId = orderId,
                    eventType = "DELIVERY_CHECK",
                    description = "当面交付合规通过：骑手人工核对收货人实物证件，确认为本人且年龄大于18岁。",
                    status = "SUCCESS",
                    operatorName = "现场配送骑手"
                )
                db?.complianceLogDao()?.insertLog(log)

                logSystem("末端合规：订单 [${orderId}] 末端证件交付核准通过，完成合规完美闭环。")
            } else {
                // Denied or Refused! Order fails delivery and returns to store
                updatedTimeline.add(TimelineEvent(OrderStatus.CANCELLED, "合规警示：末端交付核验失败（拒示证件/未满18周岁），骑手执行合规阻断，拒签并带回商品退仓。", System.currentTimeMillis()))

                val failedOrder = order.copy(
                    orderStatus = OrderStatus.CANCELLED,
                    deliveryAgeState = status,
                    timelineJson = serializeTimeline(updatedTimeline)
                )
                currentOrders[index] = failedOrder

                if (riderIndex != -1) {
                    val r = currentRiders[riderIndex]
                    currentRiders[riderIndex] = r.copy(status = RiderStatus.RETURNING, currentOrderId = null)
                    riders.value = currentRiders

                    // After some time, return rider to available
                    delay(3000)
                    val rCur = riders.value.toMutableList()
                    val rIdx = rCur.indexOfFirst { it.id == r.id }
                    if (rIdx != -1) {
                        rCur[rIdx] = rCur[rIdx].copy(status = RiderStatus.AVAILABLE)
                        riders.value = rCur
                    }
                }

                activeOrders.value = currentOrders
                db?.orderDao()?.insertOrder(failedOrder)

                val log = ComplianceLog(
                    orderId = orderId,
                    eventType = "DELIVERY_CHECK",
                    description = "末端交付拦截阻断！拦截类型：[${if (status == DeliveryAgeState.REFUSED) "未满18周岁" else "拒绝出示实名证件"}]。拒签商品并进行退款清退处理。",
                    status = "BLOCKED",
                    operatorName = "现场配送骑手"
                )
                db?.complianceLogDao()?.insertLog(log)

                logSystem("严重合规拦截：订单 [${orderId}] 在大门交付环节被骑手一枪阻断拦截，未达法定饮酒年龄拦截成功！商品正在原路返回退仓。")
            }
        }
    }

    // After-sales refund request
    fun requestOrderRefund(orderId: String, reason: String) {
        val currentOrders = activeOrders.value.toMutableList()
        val index = currentOrders.indexOfFirst { it.id == orderId }
        if (index == -1) return
        val order = currentOrders[index]

        val updatedTimeline = deserializeTimeline(order.timelineJson).toMutableList()
        updatedTimeline.add(TimelineEvent(OrderStatus.REFUND_REQUESTED, "用户在客户端发起了数字化售后申请。原因：$reason", System.currentTimeMillis()))

        engineScope.launch {
            val orderRequested = order.copy(
                orderStatus = OrderStatus.REFUND_REQUESTED,
                timelineJson = serializeTimeline(updatedTimeline)
            )
            currentOrders[index] = orderRequested
            activeOrders.value = currentOrders
            db?.orderDao()?.insertOrder(orderRequested)

            delay(2000)

            // Automate refund approval for demo purposes
            val curOrders = activeOrders.value.toMutableList()
            val curIdx = curOrders.indexOfFirst { it.id == orderId }
            if (curIdx == -1) return@launch
            val curOrder = curOrders[curIdx]

            val finalTimeline = deserializeTimeline(curOrder.timelineJson).toMutableList()
            finalTimeline.add(TimelineEvent(OrderStatus.REFUNDED, "售后专员线上合规审核通过，模拟退款原路退回付款账户，售后闭环。", System.currentTimeMillis()))

            val refundedOrder = curOrder.copy(
                orderStatus = OrderStatus.REFUNDED,
                paymentStatus = PaymentStatus.PAYMENT_CANCELLED,
                timelineJson = serializeTimeline(finalTimeline)
            )
            curOrders[curIdx] = refundedOrder
            activeOrders.value = curOrders
            db?.orderDao()?.insertOrder(refundedOrder)

            logSystem("数字化售后：订单 [${orderId}] 用户售后退款申请已通过合规核准，全额原路退回！")
        }
    }

    // System Log
    fun logSystem(msg: String) {
        val currentLogs = simulationLogs.value.toMutableList()
        currentLogs.add(0, "[${System.currentTimeMillis().let { java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.CHINA).format(java.util.Date(it)) }}] $msg")
        if (currentLogs.size > 100) {
            currentLogs.removeAt(currentLogs.size - 1)
        }
        simulationLogs.value = currentLogs
        Log.d(TAG, msg)
    }

    fun resetSimulation(context: Context) {
        engineScope.launch {
            db?.orderDao()?.deleteAllOrders()
            db?.complianceLogDao()?.deleteAllLogs()

            activeOrders.value = emptyList()
            complianceLogs.value = emptyList()
            cart.value = emptyList()
            simTickCount.value = 0L
            totalGMV.value = 0.0
            totalOrdersCount.value = 0
            complianceAlertCount.value = 0
            userAgeState.value = AgeVerifiedState.NONE
            userAgeVerifiedName.value = ""
            userAgeVerifiedIdMask.value = ""

            // Re-populate default city
            switchCity(selectedCity.value)
            simulationLogs.value = listOf("数字孪生平台网络完全复位，所有合成商业指标重置成功。")
        }
    }

    // Utility Serializers
    fun serializeTimeline(timeline: List<TimelineEvent>): String {
        return timelineAdapter.toJson(timeline)
    }

    fun deserializeTimeline(json: String): List<TimelineEvent> {
        return try {
            timelineAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun serializeCart(cart: List<CartItem>): String {
        return cartItemAdapter.toJson(cart)
    }

    fun deserializeCart(json: String): List<CartItem> {
        return try {
            cartItemAdapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
