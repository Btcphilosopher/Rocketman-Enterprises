package com.example.domain

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

enum class OrderStatus {
    CART,
    AGE_CHECK,
    COMPLIANCE_CHECK,
    ORDER_CREATED,
    PAYMENT_SIMULATED,
    STORE_ACCEPTED,
    PICKING,
    PACKED,
    RIDER_ASSIGNED,
    RIDER_TO_STORE,
    PICKED_UP,
    OUT_FOR_DELIVERY,
    ARRIVING,
    DELIVERY_AGE_CHECK,
    DELIVERED,
    COMPLETED,
    CANCELLED,
    REFUND_REQUESTED,
    REFUNDED
}

enum class AgeVerifiedState {
    NONE,
    REQUIRED,
    FAILED,
    REVIEW,
    PASSED
}

enum class DeliveryAgeState {
    NONE,
    APPROVED,
    UNVERIFIED,
    REFUSED
}

enum class RiderStatus {
    AVAILABLE,
    ASSIGNED,
    GOING_TO_STORE,
    PICKING_UP,
    PICKED_UP,
    EN_ROUTE,
    ARRIVING,
    DELIVERED,
    FAILED,
    RETURNING
}

enum class DeliveryMethod {
    INSTANT,      // 即时配送
    SCHEDULED,    // 预约配送
    PICKUP,       // 门店自提
    BUSINESS      // 企业采购
}

enum class PaymentStatus {
    PAYMENT_PENDING,
    PAYMENT_SUCCESS,
    PAYMENT_FAILED,
    PAYMENT_CANCELLED
}

data class Product(
    val id: String,
    val brand: String,
    val name: String,
    val nameEn: String,
    val category: String,
    val subcategory: String,
    val price: Double,
    val originalPrice: Double,
    val capacity: String,
    val abv: String,
    val origin: String,
    val ingredients: String,
    val storage: String,
    val description: String,
    val ageLimit: Boolean = true,
    val isAvailable: Boolean = true,
    val imageResName: String = "" // img_app_icon etc
)

data class Store(
    val id: String,
    val name: String,
    val city: String,
    val address: String,
    val lat: Double,
    val lng: Double,
    val isOperating: Boolean = true,
    val pickingCapacity: Int = 10,
    val warehouseCapacity: Int = 200,
    val staffCount: Int = 5,
    val stockMap: Map<String, Int> = emptyMap() // SKU -> count
)

data class Warehouse(
    val id: String,
    val name: String,
    val city: String,
    val address: String,
    val lat: Double,
    val lng: Double,
    val stockMap: Map<String, Int> = emptyMap(),
    val zones: List<String> = listOf("A区-白酒", "B区-葡萄酒", "C区-冷藏区", "D区-备货区")
)

data class Rider(
    val id: String,
    val name: String,
    val status: RiderStatus,
    val currentOrderId: String? = null,
    val lat: Double,
    val lng: Double,
    val rating: Double = 4.9,
    val onTimeRate: Double = 98.7
)

data class CartItem(
    val product: Product,
    var quantity: Int
)

data class TimelineEvent(
    val status: OrderStatus,
    val message: String,
    val timestamp: Long
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey val id: String,
    val itemsJson: String, // CartItem list
    val totalPrice: Double,
    val deliveryFee: Double,
    val promoDiscount: Double,
    val finalPrice: Double,
    val deliveryMethod: DeliveryMethod,
    val paymentMethod: String,
    val paymentStatus: PaymentStatus,
    val orderStatus: OrderStatus,
    val city: String,
    val shippingAddress: String,
    val riderId: String?,
    val storeId: String?,
    val warehouseId: String?,
    val ageVerifiedState: AgeVerifiedState,
    val deliveryAgeState: DeliveryAgeState,
    val etaMinutes: Int,
    val timestamp: Long,
    val timelineJson: String, // TimelineEvent list
    val ageVerificationData: String? = null // ID name and mask info
)

@Entity(tableName = "compliance_logs")
data class ComplianceLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: String,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String, // "AGE_VERIFICATION", "DELIVERY_CHECK", "BLOCKED_ORDER", "MANUAL_OVERRIDE"
    val description: String,
    val status: String, // "SUCCESS", "FAILED", "WARNING", "BLOCKED"
    val operatorName: String
)

@Entity(tableName = "analytics_snapshots")
data class AnalyticsSnapshot(
    @PrimaryKey val timestamp: Long,
    val dateStr: String,
    val totalGMV: Double,
    val orderCount: Int,
    val ageVerificationFailureCount: Int,
    val storePickingTimeAverage: Double,
    val riderOnTimeRate: Double,
    val stockoutRate: Double
)
