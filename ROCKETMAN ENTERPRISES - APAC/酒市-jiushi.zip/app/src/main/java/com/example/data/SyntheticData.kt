package com.example.data

import com.example.domain.*
import kotlin.random.Random

object SyntheticData {

    val cities = listOf("上海", "北京", "深圳", "广州", "杭州", "成都", "南京", "苏州")

    val cityCenters = mapOf(
        "上海" to Pair(31.2304, 121.4737),
        "北京" to Pair(39.9042, 116.4074),
        "深圳" to Pair(22.5431, 114.0579),
        "广州" to Pair(23.1291, 113.2644),
        "杭州" to Pair(30.2741, 120.1551),
        "成都" to Pair(30.5728, 104.0668),
        "南京" to Pair(32.0603, 118.7969),
        "苏州" to Pair(31.2990, 120.6186)
    )

    // Completely fictional, premium-themed Chinese alcoholic beverages
    val products = listOf(
        // 白酒
        Product(
            id = "B-01",
            brand = "蜀山窖",
            name = "翠竹特曲 · 浓香臻选",
            nameEn = "SHUSHAN JIAO GREEN BAMBOO",
            category = "白酒",
            subcategory = "浓香型",
            price = 198.0,
            originalPrice = 258.0,
            capacity = "500ml",
            abv = "52%vol",
            origin = "四川宜宾",
            ingredients = "水、高粱、大米、糯米、小麦、玉米",
            storage = "常温、阴凉、通风干燥处保存",
            description = "传承蜀山千年酿造技艺，多粮固态发酵。入口绵甜，窖香浓郁，回味悠长。竹韵清心，雅俗共赏。仅限成年人饮用。"
        ),
        Product(
            id = "B-02",
            brand = "黔风醉",
            name = "幽兰私酿 · 坤沙酱香",
            nameEn = "QIANFENG ZUI ORCHID RESERVE",
            category = "白酒",
            subcategory = "酱香型",
            price = 588.0,
            originalPrice = 699.0,
            capacity = "500ml",
            abv = "53%vol",
            origin = "贵州茅台镇",
            ingredients = "水、红缨子糯高粱、小麦",
            storage = "密封、避光保存，陈放更佳",
            description = "精选赤水河畔优质糯高粱，恪守「端午制曲、重阳下沙」古法酱酒工艺。酱香突出，幽雅细腻，空杯留香持久。"
        ),
        Product(
            id = "B-03",
            brand = "杏花烟雨",
            name = "牧童原酿 · 老池清香",
            nameEn = "XINGHUA YANYU MOWING ORIGIN",
            category = "白酒",
            subcategory = "清香型",
            price = 88.0,
            originalPrice = 108.0,
            capacity = "500ml",
            abv = "42%vol",
            origin = "山西汾阳",
            ingredients = "水、高粱、大麦、豌豆",
            storage = "阴凉、避光处保存",
            description = "精选优质豌豆大麦入曲，地缸分离发酵。清爽纯正，入口绵、落口甜、饮后余香，体现新中式极简美学。"
        ),
        Product(
            id = "B-04",
            brand = "象山漓水",
            name = "桂华春酒 · 密曲米香",
            nameEn = "XIANGSHAN LISHUI GWEI CHUN",
            category = "白酒",
            subcategory = "米香型",
            price = 68.0,
            originalPrice = 78.0,
            capacity = "480ml",
            abv = "38%vol",
            origin = "广西桂林",
            ingredients = "漓江泉水、优质大米、中草药酒曲",
            storage = "常温保存",
            description = "精选优质大米与象山清泉酿造，蜜香清柔，幽雅纯净。入口绵甜，落口爽冽。江南水乡之风物珍品。"
        ),
        Product(
            id = "B-05",
            brand = "幽湘缘",
            name = "三江醇厚 · 兼香典藏",
            nameEn = "YOUXIANG YUAN THREE RIVERS",
            category = "白酒",
            subcategory = "兼香型",
            price = 128.0,
            originalPrice = 148.0,
            capacity = "500ml",
            abv = "45%vol",
            origin = "湖南常德",
            ingredients = "水、高粱、小麦、大米、玉米",
            storage = "常温干燥处保存",
            description = "融合浓香之芬芳与酱香之优雅，一口三香，甘爽谐调。酒体丰满，风格独特，是当代商务宴请的东方佳选。"
        ),

        // 啤酒
        Product(
            id = "P-01",
            brand = "澜沧江",
            name = "雪峰金拉格 · 精酿听装",
            nameEn = "LANCANG SNOW PEAK LAGER",
            category = "啤酒",
            subcategory = "拉格",
            price = 8.0,
            originalPrice = 10.0,
            capacity = "500ml",
            abv = "4.2%vol",
            origin = "云南大理",
            ingredients = "澜沧江源泉水、进口大麦芽、啤酒花、活性酵母",
            storage = "5°C-25°C避光保存，冰镇饮用佳",
            description = "使用雪山融水与黄金大麦慢速发酵。泡沫洁白细腻，麦芽香气清爽，口感明亮纯净，消暑佐餐必备。"
        ),
        Product(
            id = "P-02",
            brand = "隐仙谷",
            name = "雾里寻梅 · 精酿艾尔",
            nameEn = "YINXIAN VALLEY MISTY PLUM ALE",
            category = "啤酒",
            subcategory = "艾尔",
            price = 18.0,
            originalPrice = 22.0,
            capacity = "330ml",
            abv = "5.5%vol",
            origin = "浙江莫干山",
            ingredients = "山泉水、大麦芽、小麦芽、乌梅提取液、啤酒花",
            storage = "避光冷藏",
            description = "上层艾尔酵母发酵，融合莫干山野生乌梅。果香迷人，微酸清甜，层次丰富，充满林野隐逸之气。"
        ),
        Product(
            id = "P-03",
            brand = "泰山岚",
            name = "云雾原浆小麦 · 鲜啤",
            nameEn = "MOUNT TAI MIST CLOUD WHEAT",
            category = "啤酒",
            subcategory = "小麦",
            price = 12.0,
            originalPrice = 15.0,
            capacity = "450ml",
            abv = "4.8%vol",
            origin = "山东泰安",
            ingredients = "水、大麦芽、小麦芽、啤酒花、酵母",
            storage = "冷藏保存最佳",
            description = "未经过滤与巴氏杀菌，保留丰富鲜活酵母。酒体金黄浑浊如云雾，充满浓郁的丁香与香蕉酯香，如泰山松岚般纯正。"
        ),
        Product(
            id = "P-04",
            brand = "烛龙精酿",
            name = "重浪双倍 · 浑浊IPA",
            nameEn = "CHULONG RE-WAVE DOUBLE IPA",
            category = "啤酒",
            subcategory = "IPA",
            price = 25.0,
            originalPrice = 30.0,
            capacity = "330ml",
            abv = "7.2%vol",
            origin = "广东深圳",
            ingredients = "水、大麦芽、燕麦、双重干投啤酒花、酵母",
            storage = "0°C-4°C冷藏，防剧烈震荡",
            description = "极限双倍干投西楚与马赛克啤酒花，带来排山倒海般的柑橘、芒果与百香果热带香气。燕麦带来丝滑厚实酒体，苦度平衡。"
        ),
        Product(
            id = "P-05",
            brand = "清露",
            name = "静心零度 · 无醇麦芽饮",
            nameEn = "CLEAR DEW PEACEFUL ZERO MALT",
            category = "啤酒",
            subcategory = "无醇",
            price = 10.0,
            originalPrice = 12.0,
            capacity = "330ml",
            abv = "0.05%vol",
            origin = "江苏无锡",
            ingredients = "水、大麦芽、焦香麦芽、啤酒花",
            storage = "常温或冷藏",
            description = "采用低温真空脱醇技术，在保留经典拉格饱满麦芽与啤酒花香气的同时，将酒精降低至极微量，无年龄消费限制，畅饮无负担。",
            ageLimit = false // NO AGE WARNING!
        ),

        // 葡萄酒
        Product(
            id = "W-01",
            brand = "贺兰砂",
            name = "深秋红颜 · 庄园赤霞珠干红",
            nameEn = "HELAN SAND LATE CABERNET",
            category = "葡萄酒",
            subcategory = "红葡萄酒",
            price = 228.0,
            originalPrice = 288.0,
            capacity = "750ml",
            abv = "13.5%vol",
            origin = "宁夏贺兰山东麓",
            ingredients = "100% 赤霞珠葡萄、微量二氧化硫",
            storage = "12°C-16°C恒温避光平放保存",
            description = "产自贺兰山砾石沙地，法式橡木桶陈酿12个月。呈深宝石红色，带有浓郁的黑醋栗、桑葚及木桶带来的烟熏、香草气味，单宁细腻饱满。"
        ),
        Product(
            id = "W-02",
            brand = "蓬莱潮",
            name = "晨雾干白 · 霞多丽精选",
            nameEn = "PONG LAI MORNING CHARDONNAY",
            category = "葡萄酒",
            subcategory = "白葡萄酒",
            price = 168.0,
            originalPrice = 198.0,
            capacity = "750ml",
            abv = "12.5%vol",
            origin = "山东蓬莱",
            ingredients = "100% 霞多丽葡萄、二氧化硫",
            storage = "8°C-12°C冷藏平放",
            description = "温带海洋气候孕育，晨雾缭绕中手工采摘。酒体清澈，带有青苹果、柠檬与白桃的清亮果香，伴有优雅的矿物质气息，口感清爽多汁。"
        ),
        Product(
            id = "W-03",
            brand = "瑶池红妆",
            name = "绯红晚霞 · 梦幻桃红起泡酒",
            nameEn = "SOPHIA CRIMSON SUNSET ROSE",
            category = "葡萄酒",
            subcategory = "桃红",
            price = 138.0,
            originalPrice = 168.0,
            capacity = "750ml",
            abv = "11.5%vol",
            origin = "新疆和硕",
            ingredients = "美乐、赤霞珠葡萄、二氧化硫",
            storage = "6°C-10°C避光保存",
            description = "亮丽的绯红色泽宛如大漠晚霞。气泡细腻欢快，充盈着草莓、红樱桃与新鲜野莓的甜美气息，酸度清脆，犹如少女红妆初绽。"
        ),
        Product(
            id = "W-04",
            brand = "碧落璀璨",
            name = "繁星交响 · 尊享天然起泡酒",
            nameEn = "EMPYREAN STARRY SPARKLING",
            category = "葡萄酒",
            subcategory = "起泡酒",
            price = 188.0,
            originalPrice = 238.0,
            capacity = "750ml",
            abv = "11.0%vol",
            origin = "云南迪庆香格里拉",
            ingredients = "霞多丽、黑比诺、二氧化硫",
            storage = "5°C-8°C冷藏平放，即开即饮",
            description = "海拔二千米高山葡萄，传统瓶内二次发酵法酿造。泡沫持久、密集成链，果香与烘烤面包、酵母香完美融合，适合节庆派对开香槟。"
        ),

        // 黄酒
        Product(
            id = "Y-01",
            brand = "古越春",
            name = "越水元红 · 手工干型黄酒",
            nameEn = "GUYUE YUESHUI YUAN RED",
            category = "黄酒",
            subcategory = "干型",
            price = 45.0,
            originalPrice = 55.0,
            capacity = "600ml",
            abv = "14.0%vol",
            origin = "浙江绍兴",
            ingredients = "鉴湖水、糯米、小麦",
            storage = "阴凉、常温保存",
            description = "恪守二十四节气古法手工酿造。色泽橙黄清澈，香气清雅，口感醇爽微涩，糖分极低。温饮或搭配大闸蟹极佳。"
        ),
        Product(
            id = "Y-02",
            brand = "鉴湖霜",
            name = "雕花加饭 · 十年陈酿半干",
            nameEn = "JIANHU CARVED JIAFAN 10Y",
            category = "黄酒",
            subcategory = "半干型",
            price = 88.0,
            originalPrice = 118.0,
            capacity = "600ml",
            abv = "15.0%vol",
            origin = "浙江绍兴",
            ingredients = "鉴湖水、优质糯米、小麦",
            storage = "常温阴凉处，陈放更香",
            description = "加饭黄酒，发酵中额外添加糯米，于鉴湖青瓷坛中静置熟化十年。酒体深琥珀色，馥郁温润，醇厚甘鲜，绍兴风骨毕显。"
        ),
        Product(
            id = "Y-03",
            brand = "会稽月",
            name = "蜜香善酿 · 十五年陈半甜",
            nameEn = "KUIJI MOON HONEY SHANNIANG",
            category = "黄酒",
            subcategory = "半甜型",
            price = 118.0,
            originalPrice = 148.0,
            capacity = "500ml",
            abv = "16.0%vol",
            origin = "浙江绍兴",
            ingredients = "鉴湖水、糯米、元红留糟代水、小麦",
            storage = "避光密封保存",
            description = "善酿工艺，以陈年元红酒代水酿造。色如深色红糖，香气优雅深沉，呈现蜂蜜、焦糖、坚果与红枣的甜美风味，口感柔滑浓郁。"
        ),

        // 威士忌
        Product(
            id = "K-01",
            brand = "雾林之息",
            name = "泥煤风暴 · 苏格兰型单麦威士忌",
            nameEn = "MISTY PEAT STORM SINGLE MALT",
            category = "威士忌",
            subcategory = "苏格兰",
            price = 420.0,
            originalPrice = 499.0,
            capacity = "700ml",
            abv = "46%vol",
            origin = "中国福建武夷山 (虚构橡木桶熟化)",
            ingredients = "大麦芽、水",
            storage = "常温避光立放",
            description = "优质苏格兰重泥煤麦芽进口入中国，于武夷山雾林环境中的法式雪莉桶中静置熟化。带有浓烈的篝火烟熏、海盐焦糖、皮革与乌龙茶的多重风味。"
        ),
        Product(
            id = "K-02",
            brand = "樱之川",
            name = "水楢风华 · 日本型单麦威士忌",
            nameEn = "SAKURA MIZUNARA SINGLE MALT",
            category = "威士忌",
            subcategory = "日本",
            price = 480.0,
            originalPrice = 580.0,
            capacity = "700ml",
            abv = "43%vol",
            origin = "中国吉林长白山 (虚构熟化基地)",
            ingredients = "大麦芽、长白山矿泉水",
            storage = "常温避光立放",
            description = "采用珍贵的日本水楢木桶 (Mizunara Oak) 熟化。酒体呈亮金色，散发东方禅意的檀香、线香、椰子与淡淡肉桂香气，口感丝滑，尾韵悠长悠远。"
        ),
        Product(
            id = "K-03",
            brand = "昆仑雪",
            name = "高原高寒 · 荒野雪松橡木桶威士忌",
            nameEn = "KUNLUN SNOW PLATEAU WHISKY",
            category = "威士忌",
            subcategory = "虚构地区",
            price = 350.0,
            originalPrice = 399.0,
            capacity = "700ml",
            abv = "40%vol",
            origin = "青海格尔木 (虚构高原橡木桶熟化)",
            ingredients = "高原大麦芽、雪山融水",
            storage = "常温避光立放",
            description = "首款中国高寒荒野概念威士忌，由海拔3000米雪山融水与耐寒大麦酿制。在经历极寒风沙洗礼的特制雪松木桶中老熟，松香高雅，酒体清冽凛然。"
        ),

        // 其他酒类
        Product(
            id = "O-01",
            brand = "富士雪",
            name = "精米步合50% · 大吟酿清酒",
            nameEn = "FUJI SNOW GINJO SAKE",
            category = "其他",
            subcategory = "清酒",
            price = 198.0,
            originalPrice = 248.0,
            capacity = "720ml",
            abv = "15.5%vol",
            origin = "日本新泻 (虚构进口合作)",
            ingredients = "水、山田锦大米、米曲",
            storage = "5°C-10°C冷藏，开瓶后尽快饮用",
            description = "精选「山田锦」酿酒大米，手工精碾至原米50%大小。低温发酵，呈水晶般清澈。蕴含新鲜哈密瓜、香蕉与白花的馥郁芬芳，口感如山泉般甘冽。"
        ),
        Product(
            id = "O-02",
            brand = "青梅雨",
            name = "雨打青梅 · 十年原窖黄金梅酒",
            nameEn = "GREEN PLUM RAIN 10Y UMESHU",
            category = "其他",
            subcategory = "梅酒",
            price = 128.0,
            originalPrice = 158.0,
            capacity = "500ml",
            abv = "12%vol",
            origin = "江苏苏州",
            ingredients = "米烧酒、高山青梅、冰糖",
            storage = "常温避光，冰镇加冰极佳",
            description = "精选太湖边有机青梅，以纯粮烧酒为基酒，封存在老窖泥坛中慢速浸润十年。色如琥珀，酸甜比完美，梅子香气浓缩，带有一丝杏仁香气。"
        ),
        Product(
            id = "O-03",
            brand = "幻月",
            name = "薰衣草梦境 · 晚安利口奶酒",
            nameEn = "PHANTOM LAVENDER LIQUEUR",
            category = "其他",
            subcategory = "利口酒",
            price = 98.0,
            originalPrice = 118.0,
            capacity = "500ml",
            abv = "17%vol",
            origin = "内蒙古呼伦贝尔",
            ingredients = "新鲜生牛乳、纯麦伏特加、野生薰衣草萃取液、蜂蜜",
            storage = "冷藏保存最佳，饮前摇匀",
            description = "将草原纯净鲜奶融入丝滑伏特加，加入富含安神成分的野生薰衣草。口感如奶油般醇厚丝滑，薰衣草草本香令人解压入梦，佐甜品圣品。"
        ),
        Product(
            id = "O-04",
            brand = "酌月",
            name = "柚子海盐 · 气泡鸡尾酒预调",
            nameEn = "CHUYUE YUZU SEA SALT CAN",
            category = "其他",
            subcategory = "鸡尾酒预调",
            price = 15.0,
            originalPrice = 18.0,
            capacity = "330ml",
            abv = "3.5%vol",
            origin = "浙江杭州",
            ingredients = "水、伏特加、日本柚子原汁、冲绳海盐、二氧化碳",
            storage = "常温保存，冰镇风味奇佳",
            description = "海盐微咸勾勒出柚子皮的清新与爆汁感，低糖微气泡，轻盈微醺。非常适合夏夜露营、闺蜜小聚或下班舒压。"
        ),
        Product(
            id = "O-05",
            brand = "饮冰茶会",
            name = "茉莉冷泡 · 微气泡无醇茶饮",
            nameEn = "ICE SIPS JASMINE TEA SPARKLING",
            category = "其他",
            subcategory = "无酒精饮品",
            price = 8.0,
            originalPrice = 10.0,
            capacity = "330ml",
            abv = "0.0%vol",
            origin = "福建福州",
            ingredients = "水、茉莉花茶、赤藓糖醇、二氧化碳",
            storage = "避光常温或冷藏",
            description = "精选横县双瓣茉莉花茶低温冷萃，充入细腻二氧化碳气泡。不含一滴酒精，无年龄和驾驶限制，茶香高雅，冰爽解腻。",
            ageLimit = false // NO AGE WARNING!
        )
    )

    // Generate stores, warehouses, and riders for a city based on center coordinates
    fun generateInfrastructureForCity(cityName: String): Triple<List<Store>, List<Warehouse>, List<Rider>> {
        val (centerLat, centerLng) = cityCenters[cityName] ?: Pair(31.2304, 121.4737)
        val random = Random(cityName.hashCode())

        val store1 = Store(
            id = "STORE-${cityName}-01",
            name = "酒市 · ${cityName}南京西路店",
            city = cityName,
            address = "${cityName}市静安区南京西路1038号",
            lat = centerLat + 0.008,
            lng = centerLng - 0.012,
            pickingCapacity = 12,
            warehouseCapacity = 250,
            staffCount = 6,
            stockMap = products.associate { it.id to random.nextInt(15, 45) }
        )

        val store2 = Store(
            id = "STORE-${cityName}-02",
            name = "酒市 · ${cityName}徐家汇店",
            city = cityName,
            address = "${cityName}市徐汇区虹桥路1号",
            lat = centerLat - 0.015,
            lng = centerLng + 0.009,
            pickingCapacity = 8,
            warehouseCapacity = 180,
            staffCount = 4,
            stockMap = products.associate { it.id to random.nextInt(10, 35) }
        )

        val store3 = Store(
            id = "STORE-${cityName}-03",
            name = "酒市 · ${cityName}静安寺店",
            city = cityName,
            address = "${cityName}市静安区愚园路228号",
            lat = centerLat + 0.012,
            lng = centerLng + 0.015,
            pickingCapacity = 15,
            warehouseCapacity = 300,
            staffCount = 8,
            stockMap = products.associate { it.id to random.nextInt(20, 50) }
        )

        val stores = listOf(store1, store2, store3)

        val warehouse = Warehouse(
            id = "WH-${cityName}-01",
            name = "酒市 · ${cityName}城北前置枢纽仓",
            city = cityName,
            address = "${cityName}市宝山区呼兰路55号",
            lat = centerLat + 0.045,
            lng = centerLng - 0.035,
            stockMap = products.associate { it.id to random.nextInt(120, 300) }
        )

        val warehouses = listOf(warehouse)

        val riderNames = listOf("刘强", "张伟", "王涛", "陈龙", "李杰")
        val riders = List(5) { index ->
            // Distribute riders around the stores
            val pivotStore = stores[index % stores.size]
            val offsetLat = (random.nextDouble() - 0.5) * 0.01
            val offsetLng = (random.nextDouble() - 0.5) * 0.01

            Rider(
                id = "RIDER-${cityName}-${index + 1}",
                name = "骑手-${riderNames[index % riderNames.size]}(${cityName})",
                status = RiderStatus.AVAILABLE,
                currentOrderId = null,
                lat = pivotStore.lat + offsetLat,
                lng = pivotStore.lng + offsetLng,
                rating = 4.8 + random.nextDouble() * 0.2,
                onTimeRate = 95.0 + random.nextDouble() * 4.9
            )
        }

        return Triple(stores, warehouses, riders)
    }
}
