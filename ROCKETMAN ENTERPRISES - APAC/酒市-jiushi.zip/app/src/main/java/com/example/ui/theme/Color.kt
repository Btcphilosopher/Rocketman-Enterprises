package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// JIUSHI Premium Theme Colors
val Burgundy = Color(0xFF6B1D2F)       // 典雅红酒/勃艮第红 (Primary)
val WarmWood = Color(0xFF8C6239)       // 温暖原木色 (Secondary)
val BrushedMetal = Color(0xFFB0B3B8)   // 银灰拉丝金属 (Tertiary)

val GraphiteDark = Color(0xFF1E1E20)   // 深邃石墨色 (OnBackground/DarkBackground)
val IvoryLight = Color(0xFFFDFBF7)     // 温润象牙白 (Background)

val SurfaceWhite = Color(0xFFFFFFFF)
val SurfaceDarkCard = Color(0xFF28282A)

val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFEF6C00)
val AlertRed = Color(0xFFC62828)
val InfoBlue = Color(0xFF1565C0)
