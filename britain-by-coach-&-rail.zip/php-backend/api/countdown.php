<?php
/**
 * Britain by Coach & Rail - Countdown & Departure Board API
 * Accurately computes UK departure time remaining, weather outlook and travel checklist.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('Europe/London');

$targetDateParam = $_GET['departure'] ?? null;
$destination = $_GET['destination'] ?? 'UK Coast & Country';

if (!$targetDateParam) {
    // Default to upcoming bank holiday
    $targetTimestamp = strtotime('+14 days 08:30:00');
} else {
    $targetTimestamp = strtotime($targetDateParam);
    if (!$targetTimestamp) {
        $targetTimestamp = strtotime('+14 days 08:30:00');
    }
}

$now = time();
$secondsDiff = max(0, $targetTimestamp - $now);

$days = floor($secondsDiff / 86400);
$hours = floor(($secondsDiff % 86400) / 3600);
$minutes = floor(($secondsDiff % 3600) / 60);
$seconds = $secondsDiff % 60;

$weatherProfiles = [
    'Edinburgh' => ['temp' => '14°C', 'condition' => 'Crisp & partly sunny', 'icon' => 'CloudSun'],
    'Cornwall' => ['temp' => '17°C', 'condition' => 'Gentle coastal breeze', 'icon' => 'Sun'],
    'Lake District' => ['temp' => '15°C', 'condition' => 'Clear skies over fells', 'icon' => 'Cloud'],
    'York' => ['temp' => '16°C', 'condition' => 'Mild & pleasant', 'icon' => 'Sun'],
    'Snowdonia' => ['temp' => '13°C', 'condition' => 'Fresh mountain air', 'icon' => 'Wind']
];

$matchedWeather = $weatherProfiles[$destination] ?? ['temp' => '16°C', 'condition' => 'Pleasant travel weather', 'icon' => 'CloudSun'];

echo json_encode([
    'status' => 'success',
    'timestamp' => $now,
    'departureIso' => date('c', $targetTimestamp),
    'countdown' => [
        'days' => $days,
        'hours' => $hours,
        'minutes' => $minutes,
        'seconds' => $seconds,
        'isDeparted' => $secondsDiff <= 0,
        'totalSecondsRemaining' => $secondsDiff
    ],
    'weatherForecast' => $matchedWeather,
    'packingChecklist' => [
        ['item' => 'Valid photo ID or Railcard', 'category' => 'Essential', 'packed' => true],
        ['item' => 'Comfortable walking shoes/boots', 'category' => 'Clothing', 'packed' => false],
        ['item' => 'Light waterproof jacket', 'category' => 'Clothing', 'packed' => false],
        ['item' => 'Camera or phone charger & power bank', 'category' => 'Electronics', 'packed' => false],
        ['item' => 'Prescription medication & travel insurance', 'category' => 'Essential', 'packed' => false]
    ]
], JSON_PRETTY_PRINT);
