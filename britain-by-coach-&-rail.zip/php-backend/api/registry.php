<?php
/**
 * Britain by Coach & Rail - Gift Registry API
 * Handles gift registry listing, creation, and contributions.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// In-memory / File-backed SQLite or JSON datastore for demonstration
$storageFile = __DIR__ . '/../data/registries.json';
if (!file_exists(dirname($storageFile))) {
    mkdir(dirname($storageFile), 0777, true);
}

function loadRegistries($file) {
    if (!file_exists($file)) {
        return [];
    }
    $raw = file_get_contents($file);
    return json_decode($raw, true) ?: [];
}

function saveRegistries($file, $data) {
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

$action = $_GET['action'] ?? 'list';
$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET' && $action === 'list') {
        $registries = loadRegistries($storageFile);
        echo json_encode([
            'status' => 'success',
            'count' => count($registries),
            'data' => $registries
        ]);
        exit;
    }

    if ($method === 'GET' && $action === 'get') {
        $code = strtoupper(trim($_GET['code'] ?? ''));
        $registries = loadRegistries($storageFile);
        foreach ($registries as $reg) {
            if (strtoupper($reg['code']) === $code || $reg['id'] === $code) {
                echo json_encode([
                    'status' => 'success',
                    'data' => $reg
                ]);
                exit;
            }
        }
        http_response_code(404);
        echo json_encode(['status' => 'error', 'message' => 'Registry not found']);
        exit;
    }

    if ($method === 'POST' && $action === 'contribute') {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            throw new Exception('Invalid JSON payload');
        }

        $registryId = $input['registryId'] ?? '';
        $contributorName = trim($input['contributorName'] ?? 'Anonymous Well-Wisher');
        $amount = floatval($input['amount'] ?? 0);
        $message = trim($input['message'] ?? '');
        $giftItemId = $input['giftItemId'] ?? null;

        if ($amount <= 0) {
            throw new Exception('Contribution amount must be greater than £0');
        }

        $registries = loadRegistries($storageFile);
        $updated = false;
        $matchedRegistry = null;

        foreach ($registries as &$reg) {
            if ($reg['id'] === $registryId || $reg['code'] === $registryId) {
                $reg['currentAmount'] += $amount;
                
                $itemTitle = null;
                if ($giftItemId && !empty($reg['items'])) {
                    foreach ($reg['items'] as &$item) {
                        if ($item['id'] === $giftItemId) {
                            $item['claimedAmount'] = min($item['price'], $item['claimedAmount'] + $amount);
                            $itemTitle = $item['title'];
                            break;
                        }
                    }
                }

                $newContribution = [
                    'id' => 'c_' . uniqid(),
                    'contributorName' => $contributorName,
                    'amount' => $amount,
                    'message' => $message ?: 'Best wishes for your journey!',
                    'timestamp' => 'Just now',
                    'giftItemTitle' => $itemTitle
                ];

                array_unshift($reg['contributions'], $newContribution);
                $updated = true;
                $matchedRegistry = $reg;
                break;
            }
        }

        if (!$updated) {
            throw new Exception('Target holiday registry not found');
        }

        saveRegistries($storageFile, $registries);

        echo json_encode([
            'status' => 'success',
            'message' => 'Contribution successfully recorded! Thank you for gifting adventure.',
            'registry' => $matchedRegistry
        ]);
        exit;
    }

    if ($method === 'POST' && $action === 'create') {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) {
            throw new Exception('Invalid JSON payload');
        }

        $title = trim($input['title'] ?? '');
        $recipientNames = trim($input['recipientNames'] ?? '');
        $occasion = trim($input['occasion'] ?? 'Holiday');
        $destination = trim($input['destination'] ?? 'UK Tour');
        $targetAmount = floatval($input['targetAmount'] ?? 500);
        $story = trim($input['story'] ?? '');
        $departureDate = $input['departureDate'] ?? date('Y-m-d', strtotime('+30 days'));

        if (empty($title) || empty($recipientNames)) {
            throw new Exception('Title and recipient names are required');
        }

        $newCode = 'BCR-' . strtoupper(substr(preg_replace('/[^a-zA-Z]/', '', $recipientNames), 0, 4)) . rand(10, 99);
        $newRegistry = [
            'id' => 'reg_' . uniqid(),
            'code' => $newCode,
            'title' => $title,
            'recipientNames' => $recipientNames,
            'occasion' => $occasion,
            'destination' => $destination,
            'targetAmount' => $targetAmount,
            'currentAmount' => 0,
            'departureDate' => $departureDate,
            'story' => $story,
            'organizerEmail' => $input['organizerEmail'] ?? '',
            'items' => $input['items'] ?? [
                ['id' => 'item_1', 'title' => 'Scenic Rail Tickets', 'category' => 'travel', 'price' => 120, 'claimedAmount' => 0, 'iconName' => 'Train'],
                ['id' => 'item_2', 'title' => 'Hotel Accommodation', 'category' => 'hotel', 'price' => 200, 'claimedAmount' => 0, 'iconName' => 'Hotel'],
                ['id' => 'item_3', 'title' => 'Traditional Afternoon Tea', 'category' => 'dining', 'price' => 45, 'claimedAmount' => 0, 'iconName' => 'Coffee']
            ],
            'contributions' => []
        ];

        $registries = loadRegistries($storageFile);
        array_unshift($registries, $newRegistry);
        saveRegistries($storageFile, $registries);

        echo json_encode([
            'status' => 'success',
            'message' => 'Holiday Gift Registry created successfully!',
            'registry' => $newRegistry
        ]);
        exit;
    }

    throw new Exception('Unsupported action');
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
