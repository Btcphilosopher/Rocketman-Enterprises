<?php
/**
 * Britain by Coach & Rail - Booking Inquiry & ATOL Protection Calculator
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON input']);
    exit;
}

$holidayId = $input['holidayId'] ?? 'custom';
$holidayTitle = $input['holidayTitle'] ?? 'Great British Holiday';
$departureTown = $input['departureTown'] ?? 'London Victoria';
$travelDate = $input['travelDate'] ?? date('Y-m-d', strtotime('+3 weeks'));
$contactName = trim($input['contactName'] ?? '');
$email = trim($input['email'] ?? '');
$phone = trim($input['phone'] ?? '');

$adults = max(1, intval($input['passengers']['adults'] ?? 2));
$seniors = max(0, intval($input['passengers']['seniors'] ?? 0));
$children = max(0, intval($input['passengers']['children'] ?? 0));

$basePrice = floatval($input['basePrice'] ?? 109);
// Calculate total with Senior 5% discount and Child 25% discount
$adultTotal = $adults * $basePrice;
$seniorTotal = $seniors * ($basePrice * 0.95);
$childTotal = $children * ($basePrice * 0.75);
$grandTotal = round($adultTotal + $seniorTotal + $childTotal, 2);

$reference = 'BCR-' . strtoupper(substr(md5(uniqid()), 0, 6));

echo json_encode([
    'status' => 'success',
    'bookingReference' => $reference,
    'message' => 'Provisional reservation held for 48 hours with 100% ATOL financial protection.',
    'summary' => [
        'holidayTitle' => $holidayTitle,
        'departureTown' => $departureTown,
        'travelDate' => $travelDate,
        'passengers' => [
            'adults' => $adults,
            'seniors' => $seniors,
            'children' => $children,
            'totalTravellers' => $adults + $seniors + $children
        ],
        'financials' => [
            'basePricePerPerson' => $basePrice,
            'totalAmount' => $grandTotal,
            'atolProtectionCover' => 'Fully Protected under ATOL #10842',
            'depositDueToday' => 50.00,
            'balanceDue' => $grandTotal - 50.00
        ],
        'customer' => [
            'name' => $contactName,
            'email' => $email,
            'phone' => $phone
        ]
    ]
], JSON_PRETTY_PRINT);
