-- Britain by Coach & Rail Database Schema
-- Compatible with MySQL 8+, MariaDB, and SQLite 3

CREATE TABLE IF NOT EXISTS holiday_packages (
    id VARCHAR(64) PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    tagline VARCHAR(255),
    region VARCHAR(64) NOT NULL,
    duration VARCHAR(64) NOT NULL,
    travel_mode ENUM('coach', 'rail', 'both') NOT NULL,
    base_price DECIMAL(10,2) NOT NULL,
    rating DECIMAL(3,2) DEFAULT 4.9,
    reviews_count INT DEFAULT 100,
    image_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gift_registries (
    id VARCHAR(64) PRIMARY KEY,
    code VARCHAR(32) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    recipient_names VARCHAR(255) NOT NULL,
    occasion VARCHAR(120) NOT NULL,
    destination VARCHAR(120) NOT NULL,
    target_amount DECIMAL(10,2) NOT NULL,
    current_amount DECIMAL(10,2) DEFAULT 0.00,
    departure_date DATE NOT NULL,
    story TEXT,
    organizer_email VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS registry_items (
    id VARCHAR(64) PRIMARY KEY,
    registry_id VARCHAR(64) NOT NULL,
    title VARCHAR(255) NOT NULL,
    category ENUM('travel', 'hotel', 'dining', 'experience', 'upgrade') NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    claimed_amount DECIMAL(10,2) DEFAULT 0.00,
    icon_name VARCHAR(64) DEFAULT 'Gift',
    FOREIGN KEY (registry_id) REFERENCES gift_registries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS registry_contributions (
    id VARCHAR(64) PRIMARY KEY,
    registry_id VARCHAR(64) NOT NULL,
    gift_item_id VARCHAR(64),
    contributor_name VARCHAR(150) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (registry_id) REFERENCES gift_registries(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tour_bookings (
    id VARCHAR(64) PRIMARY KEY,
    booking_reference VARCHAR(32) UNIQUE NOT NULL,
    holiday_id VARCHAR(64) NOT NULL,
    holiday_title VARCHAR(255) NOT NULL,
    departure_town VARCHAR(100) NOT NULL,
    travel_date DATE NOT NULL,
    adults INT NOT NULL DEFAULT 1,
    seniors INT NOT NULL DEFAULT 0,
    children INT NOT NULL DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    contact_name VARCHAR(150) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(64) NOT NULL,
    atol_certificate_number VARCHAR(64) NOT NULL,
    status ENUM('provisional', 'confirmed', 'cancelled') DEFAULT 'provisional',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
