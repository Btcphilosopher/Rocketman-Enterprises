'use client';

import React, { useState } from 'react';
import { Search, Heart, Menu, X, Gift, Clock, Bus, Train, Code2 } from 'lucide-react';

interface NavbarProps {
  onOpenSearch: () => void;
  onOpenWishlist: () => void;
  onOpenBooking: () => void;
  onOpenPhpInspector: () => void;
  wishlistCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenSearch,
  onOpenWishlist,
  onOpenBooking,
  onOpenPhpInspector,
  wishlistCount,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#0F2238] text-white shadow-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          
          {/* Brand Wordmark & Union Jack Flag Circle */}
          <a href="#" className="flex items-center gap-3.5 shrink-0 group">
            {/* British Flag Rounded Icon */}
            <div className="w-10 h-10 rounded-full overflow-hidden shadow-inner flex items-center justify-center bg-blue-900 border-2 border-slate-300 shrink-0 relative">
              <svg viewBox="0 0 60 30" className="w-full h-full object-cover">
                <clipPath id="s">
                  <path d="M0,0 v30 h60 v-30 z"/>
                </clipPath>
                <clipPath id="t">
                  <path d="M30,15 h30 v15 z v15 h-30 z h-30 v-15 z v-15 h30 z"/>
                </clipPath>
                <g clipPath="url(#s)">
                  <path d="M0,0 v30 h60 v-30 z" fill="#012169"/>
                  <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6"/>
                  <path d="M0,0 L60,30 M60,0 L0,30" clipPath="url(#t)" stroke="#C8102E" strokeWidth="4"/>
                  <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10"/>
                  <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6"/>
                </g>
              </svg>
            </div>
            
            <div className="flex flex-col">
              <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-white leading-tight">
                Britain by Coach & Rail
              </span>
              <span className="text-xs text-amber-300 font-medium tracking-wide">
                More of the UK. For Less.
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-sm font-medium text-slate-200">
            <a href="#" className="text-amber-400 border-b-2 border-amber-400 pb-0.5 whitespace-nowrap">
              Home
            </a>
            <a href="#destinations" className="hover:text-white transition-colors whitespace-nowrap">
              Holiday Deals
            </a>
            <a href="#coach-holidays" className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1.5">
              <Bus className="w-3.5 h-3.5 text-amber-300" />
              Coach Holidays
            </a>
            <a href="#rail-holidays" className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1.5">
              <Train className="w-3.5 h-3.5 text-amber-300" />
              Rail Holidays
            </a>
            <a href="#registry" className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1.5 text-amber-300 hover:text-amber-200 font-semibold">
              <Gift className="w-4 h-4 text-amber-400" />
              Gift Registry
            </a>
            <a href="#countdown" className="hover:text-white transition-colors whitespace-nowrap flex items-center gap-1.5 text-amber-300 hover:text-amber-200 font-semibold">
              <Clock className="w-4 h-4 text-amber-400" />
              Countdown
            </a>
            <a href="#testimonials" className="hover:text-white transition-colors whitespace-nowrap">
              About Us
            </a>
          </nav>

          {/* Right Action Icons & Primary CTA */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Search Trigger */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-full transition-colors"
              title="Search UK Holidays"
              aria-label="Search Holidays"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Wishlist Trigger */}
            <button
              onClick={onOpenWishlist}
              className="p-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded-full transition-colors relative"
              title="Saved Holidays"
              aria-label="Saved Holidays"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-400 text-slate-950 text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* PHP Backend Source & Live API Inspector */}
            <button
              onClick={onOpenPhpInspector}
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-md border border-slate-700 transition-colors"
              title="View PHP backend code and test API routes"
            >
              <Code2 className="w-3.5 h-3.5" />
              PHP API
            </button>

            {/* "Book Now" Amber CTA Button from Screenshot */}
            <button
              onClick={onOpenBooking}
              className="px-5 py-2.5 text-sm font-bold text-slate-950 bg-[#F2A900] hover:bg-[#d89600] rounded-lg shadow-sm transition-transform active:scale-95 whitespace-nowrap cursor-pointer"
            >
              Book Now
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-300 hover:text-white focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile dropdown menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-slate-800 space-y-2 animate-fadeIn">
            <a
              href="#"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-amber-400 bg-slate-900"
            >
              Home
            </a>
            <a
              href="#destinations"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-slate-200 hover:bg-slate-800"
            >
              Holiday Deals
            </a>
            <a
              href="#coach-holidays"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-slate-200 hover:bg-slate-800 flex items-center gap-2"
            >
              <Bus className="w-4 h-4 text-amber-400" />
              Coach Holidays
            </a>
            <a
              href="#rail-holidays"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-slate-200 hover:bg-slate-800 flex items-center gap-2"
            >
              <Train className="w-4 h-4 text-amber-400" />
              Rail Holidays
            </a>
            <a
              href="#registry"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-amber-300 hover:bg-slate-800 flex items-center gap-2"
            >
              <Gift className="w-4 h-4 text-amber-400" />
              Holiday Gift Registry
            </a>
            <a
              href="#countdown"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-amber-300 hover:bg-slate-800 flex items-center gap-2"
            >
              <Clock className="w-4 h-4 text-amber-400" />
              Interactive Countdown Timer
            </a>
            <a
              href="#testimonials"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-md text-base font-medium text-slate-200 hover:bg-slate-800"
            >
              About Us & Reviews
            </a>
            <div className="pt-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenPhpInspector();
                }}
                className="w-full flex items-center justify-center gap-2 px-3 py-2 text-sm font-semibold bg-slate-800 text-amber-300 rounded-md border border-slate-700"
              >
                <Code2 className="w-4 h-4" />
                Inspect PHP Backend & Endpoints
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
