'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { Clock, Calendar, Compass, Sun, Cloud, CloudSun, CheckSquare, Square, Share2, Sparkles, Bus, Train, ArrowRight } from 'lucide-react';
import { CountdownTour } from '@/types/holiday';
import { COUNTDOWN_TOURS, DESTINATIONS_LIST } from '@/data/mockData';

interface CountdownTimerSectionProps {
  onBookTour: (tourTitle: string, price: number) => void;
}

export const CountdownTimerSection: React.FC<CountdownTimerSectionProps> = ({ onBookTour }) => {
  const [activeTab, setActiveTab] = useState<'featured' | 'custom'>('featured');
  const [selectedTour, setSelectedTour] = useState<CountdownTour>(COUNTDOWN_TOURS[0]);

  // Live countdown state for featured tour
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  // Custom holiday countdown planner state
  const [customDestination, setCustomDestination] = useState('Cornwall & Coastal Riviera');
  const [customDate, setCustomDate] = useState('2027-05-25');
  const [customBookingRef, setCustomBookingRef] = useState('BCR-7824');
  const [customTimeLeft, setCustomTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  // Interactive packing checklist
  const [packingList, setPackingList] = useState([
    { id: 1, text: 'Senior Railcard / Photo ID & Tickets', done: true },
    { id: 2, text: 'Comfortable walking footwear for cobbles & hills', done: false },
    { id: 3, text: 'Compact umbrella & light waterproof jacket', done: false },
    { id: 4, text: 'Camera / Phone charger for scenic train views', done: true },
    { id: 5, text: 'Reusable water bottle & travel confectionery', done: false },
  ]);

  const [copiedShare, setCopiedShare] = useState(false);

  // Live timer interval for featured tour
  useEffect(() => {
    const calculateTime = () => {
      const target = new Date(selectedTour.targetDate).getTime();
      const now = new Date().getTime();
      const diff = Math.max(0, target - now);

      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [selectedTour]);

  // Live timer interval for custom holiday
  useEffect(() => {
    const calculateCustom = () => {
      const target = new Date(`${customDate}T09:00:00`).getTime();
      const now = new Date().getTime();
      const diff = Math.max(0, target - now);

      setCustomTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
        minutes: Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60)),
        seconds: Math.floor((diff % (1000 * 60)) / 1000),
      });
    };

    calculateCustom();
    const interval = setInterval(calculateCustom, 1000);
    return () => clearInterval(interval);
  }, [customDate]);

  const toggleChecklist = (id: number) => {
    setPackingList((prev) =>
      prev.map((item) => (item.id === id ? { ...item, done: !item.done } : item))
    );
  };

  const handleShareCountdown = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard?.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2500);
    }
  };

  return (
    <section id="countdown" className="py-16 sm:py-24 bg-[#0A192B] text-white relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl -z-0" />
      <div className="absolute bottom-0 left-10 w-96 h-96 bg-sky-500/10 rounded-full blur-3xl -z-0" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-400/20 text-amber-300 text-xs font-bold uppercase tracking-wider mb-3 border border-amber-400/30">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Interactive Departure Clock</span>
          </div>

          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
            Upcoming Holiday Countdowns
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-300 leading-relaxed">
            Watch the clock tick down to seasonal Bank Holiday tour departures, or track your own personalized countdown with live weather forecasts and packing checklist!
          </p>

          {/* Mode Switcher */}
          <div className="mt-8 inline-flex p-1.5 bg-slate-900/80 border border-slate-700 rounded-2xl text-sm font-semibold">
            <button
              onClick={() => setActiveTab('featured')}
              className={`px-6 py-2.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'featured'
                  ? 'bg-[#F2A900] text-slate-950 font-bold shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              Upcoming Seasonal Tours
            </button>
            <button
              onClick={() => setActiveTab('custom')}
              className={`px-6 py-2.5 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'custom'
                  ? 'bg-[#F2A900] text-slate-950 font-bold shadow-md'
                  : 'text-slate-300 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              My Holiday Countdown
            </button>
          </div>
        </div>

        {/* Tab 1: Featured Tour Countdowns */}
        {activeTab === 'featured' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Tour Selection Left Bar (4 cols) */}
            <div className="lg:col-span-5 space-y-3">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Select Tour Departure:
              </span>
              {COUNTDOWN_TOURS.map((tour) => {
                const isSelected = selectedTour.id === tour.id;
                return (
                  <button
                    key={tour.id}
                    onClick={() => setSelectedTour(tour)}
                    className={`w-full text-left p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-slate-800/90 border-[#F2A900] shadow-lg ring-1 ring-[#F2A900]'
                        : 'bg-slate-900/50 border-slate-800 hover:bg-slate-800/60'
                    }`}
                  >
                    <div>
                      <span className="text-xs font-bold text-amber-400 uppercase tracking-wide">
                        {tour.destination}
                      </span>
                      <h4 className="text-sm font-bold text-white mt-0.5">{tour.title}</h4>
                      <div className="flex items-center gap-2 mt-1 text-xs text-slate-400">
                        <span>{tour.duration}</span>
                        <span>·</span>
                        <span className="text-rose-400 font-semibold">{tour.seatsLeft} seats left</span>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-xs text-slate-400 line-through">£{tour.originalPrice}</span>
                      <div className="text-base font-extrabold text-[#F2A900] font-mono">£{tour.offerPrice}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Featured Live Countdown Clock Display (7 cols) */}
            <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl relative">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                <span className="px-3 py-1 rounded-md bg-rose-500/20 text-rose-300 font-bold text-xs uppercase tracking-wider border border-rose-500/30">
                  {selectedTour.discountText}
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-amber-400" />
                  Departure: {new Date(selectedTour.targetDate).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' })}
                </span>
              </div>

              <h3 className="font-serif text-2xl sm:text-3xl font-extrabold text-white mb-2">
                {selectedTour.title}
              </h3>
              <p className="text-sm text-slate-300 mb-6">
                {selectedTour.description}
              </p>

              {/* Live Ticking Digits Grid */}
              <div className="grid grid-cols-4 gap-3 sm:gap-4 mb-6">
                {/* Days */}
                <div className="bg-[#0F2238] rounded-2xl p-4 sm:p-5 text-center border border-slate-700 shadow-inner">
                  <span className="font-mono text-3xl sm:text-5xl font-extrabold text-[#F2A900] block">
                    {String(timeLeft.days).padStart(2, '0')}
                  </span>
                  <span className="text-[11px] sm:text-xs uppercase font-bold text-slate-400 tracking-wider mt-1 block">
                    Days
                  </span>
                </div>

                {/* Hours */}
                <div className="bg-[#0F2238] rounded-2xl p-4 sm:p-5 text-center border border-slate-700 shadow-inner">
                  <span className="font-mono text-3xl sm:text-5xl font-extrabold text-white block">
                    {String(timeLeft.hours).padStart(2, '0')}
                  </span>
                  <span className="text-[11px] sm:text-xs uppercase font-bold text-slate-400 tracking-wider mt-1 block">
                    Hours
                  </span>
                </div>

                {/* Minutes */}
                <div className="bg-[#0F2238] rounded-2xl p-4 sm:p-5 text-center border border-slate-700 shadow-inner">
                  <span className="font-mono text-3xl sm:text-5xl font-extrabold text-white block">
                    {String(timeLeft.minutes).padStart(2, '0')}
                  </span>
                  <span className="text-[11px] sm:text-xs uppercase font-bold text-slate-400 tracking-wider mt-1 block">
                    Mins
                  </span>
                </div>

                {/* Seconds */}
                <div className="bg-[#0F2238] rounded-2xl p-4 sm:p-5 text-center border border-slate-700 shadow-inner">
                  <span className="font-mono text-3xl sm:text-5xl font-extrabold text-amber-400 block animate-pulse">
                    {String(timeLeft.seconds).padStart(2, '0')}
                  </span>
                  <span className="text-[11px] sm:text-xs uppercase font-bold text-slate-400 tracking-wider mt-1 block">
                    Secs
                  </span>
                </div>
              </div>

              {/* Progress Bar of Available Seats */}
              <div className="mb-6 p-4 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="text-slate-300">Coach &amp; Train Carriage Capacity:</span>
                  <span className="font-bold text-amber-400 font-mono">
                    {selectedTour.totalSeats - selectedTour.seatsLeft} of {selectedTour.totalSeats} booked
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-700 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 via-amber-400 to-rose-500 rounded-full"
                    style={{
                      width: `${Math.round(((selectedTour.totalSeats - selectedTour.seatsLeft) / selectedTour.totalSeats) * 100)}%`,
                    }}
                  />
                </div>
              </div>

              {/* Call to Action */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
                <div>
                  <span className="text-xs text-slate-400 uppercase tracking-wide">Promotional Fare:</span>
                  <div className="text-2xl font-black text-[#F2A900] font-mono">
                    £{selectedTour.offerPrice} <span className="text-xs text-slate-300 font-normal">per person</span>
                  </div>
                </div>

                <button
                  onClick={() => onBookTour(selectedTour.title, selectedTour.offerPrice)}
                  className="w-full sm:w-auto px-6 py-3.5 bg-[#F2A900] hover:bg-[#d89600] text-slate-950 font-bold text-sm rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Book Tour at Early Price</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: Custom Holiday Countdown & Packing Planner */}
        {activeTab === 'custom' && (
          <div className="max-w-4xl mx-auto bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {/* Destination selector */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  My Destination
                </label>
                <select
                  value={customDestination}
                  onChange={(e) => setCustomDestination(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                >
                  {DESTINATIONS_LIST.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              {/* Departure date */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  My Departure Date
                </label>
                <input
                  type="date"
                  value={customDate}
                  min="2027-03-01"
                  onChange={(e) => setCustomDate(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Booking reference */}
              <div>
                <label className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Booking Reference
                </label>
                <input
                  type="text"
                  value={customBookingRef}
                  onChange={(e) => setCustomBookingRef(e.target.value.toUpperCase())}
                  placeholder="e.g. BCR-7824"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 text-sm font-mono text-white focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {/* Custom Boarding Countdown Box */}
            <div className="bg-gradient-to-br from-[#0F2238] to-[#0A192B] rounded-2xl p-6 border border-slate-700 shadow-xl mb-8">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
                <div>
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                    DEPARTURE COUNTDOWN · {customBookingRef}
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl font-extrabold text-white mt-1">
                    {customDestination}
                  </h3>
                </div>

                {/* Weather Forecast Preview */}
                <div className="flex items-center gap-3 bg-slate-800/80 px-4 py-2 rounded-xl border border-slate-700">
                  <CloudSun className="w-6 h-6 text-amber-300" />
                  <div className="text-xs">
                    <span className="font-bold text-white block">16°C · Spring Sunshine</span>
                    <span className="text-slate-400">Ideal coach &amp; walking conditions</span>
                  </div>
                </div>
              </div>

              {/* Big Ticking Display */}
              <div className="grid grid-cols-4 gap-3 sm:gap-4 mb-4">
                <div className="bg-slate-900/90 rounded-xl p-3 sm:p-4 text-center border border-slate-800">
                  <span className="font-mono text-3xl sm:text-4xl font-extrabold text-[#F2A900] block">
                    {customTimeLeft.days}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">Days to go</span>
                </div>
                <div className="bg-slate-900/90 rounded-xl p-3 sm:p-4 text-center border border-slate-800">
                  <span className="font-mono text-3xl sm:text-4xl font-extrabold text-white block">
                    {customTimeLeft.hours}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">Hours</span>
                </div>
                <div className="bg-slate-900/90 rounded-xl p-3 sm:p-4 text-center border border-slate-800">
                  <span className="font-mono text-3xl sm:text-4xl font-extrabold text-white block">
                    {customTimeLeft.minutes}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">Mins</span>
                </div>
                <div className="bg-slate-900/90 rounded-xl p-3 sm:p-4 text-center border border-slate-800">
                  <span className="font-mono text-3xl sm:text-4xl font-extrabold text-amber-400 block animate-pulse">
                    {customTimeLeft.seconds}
                  </span>
                  <span className="text-[10px] uppercase font-bold text-slate-400">Seconds</span>
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  onClick={handleShareCountdown}
                  className="text-xs font-semibold text-amber-300 hover:text-amber-200 flex items-center gap-1.5 transition-colors"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  {copiedShare ? 'Copied link to clipboard!' : 'Share countdown with companions'}
                </button>
              </div>
            </div>

            {/* Interactive Travel Packing Checklist */}
            <div className="bg-slate-800/60 rounded-2xl p-6 border border-slate-700/80">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-serif text-lg font-bold text-white flex items-center gap-2">
                  <CheckSquare className="w-5 h-5 text-emerald-400" />
                  Great British Travel Checklist
                </h4>
                <span className="text-xs font-bold text-slate-400 font-mono">
                  {packingList.filter((i) => i.done).length} / {packingList.length} packed
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {packingList.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => toggleChecklist(item.id)}
                    className={`flex items-center gap-3 p-3 rounded-xl border text-left text-xs transition-colors cursor-pointer ${
                      item.done
                        ? 'bg-emerald-950/40 border-emerald-800 text-emerald-200'
                        : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    {item.done ? (
                      <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : (
                      <Square className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                    <span className={item.done ? 'line-through text-slate-400' : ''}>{item.text}</span>
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}

      </div>
    </section>
  );
};
