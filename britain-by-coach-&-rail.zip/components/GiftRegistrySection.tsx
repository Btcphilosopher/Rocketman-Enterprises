'use client';

import React, { useState } from 'react';
import { Gift, Heart, Sparkles, Plus, Share2, Check, Send, Train, Hotel, UtensilsCrossed, Compass, Calendar, Search } from 'lucide-react';
import { GiftRegistry, GiftItem, Contribution } from '@/types/holiday';

interface GiftRegistrySectionProps {
  registries: GiftRegistry[];
  onContribute: (registryId: string, payload: {
    contributorName: string;
    amount: number;
    message: string;
    giftItemId?: string;
  }) => Promise<boolean>;
  onCreateRegistry: (payload: any) => Promise<boolean>;
}

export const GiftRegistrySection: React.FC<GiftRegistrySectionProps> = ({
  registries,
  onContribute,
  onCreateRegistry,
}) => {
  const [activeTab, setActiveTab] = useState<'browse' | 'create'>('browse');
  const [selectedRegistryId, setSelectedRegistryId] = useState<string>(registries[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Contribution modal state
  const [contributeModalOpen, setContributeModalOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<GiftItem | null>(null);
  const [contributorName, setContributorName] = useState('');
  const [contributionAmount, setContributionAmount] = useState<number>(50);
  const [contributorMessage, setContributorMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [celebrationSuccess, setCelebrationSuccess] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Create Registry Form State
  const [newTitle, setNewTitle] = useState('');
  const [newRecipients, setNewRecipients] = useState('');
  const [newOccasion, setNewOccasion] = useState('Golden Wedding Anniversary (50 Years)');
  const [newDestination, setNewDestination] = useState('Scottish Highlands & Steam Rail');
  const [newTargetAmount, setNewTargetAmount] = useState(650);
  const [newStory, setNewStory] = useState('');
  const [newDepartureDate, setNewDepartureDate] = useState('2027-06-15');
  const [newEmail, setNewEmail] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [createSuccessMsg, setCreateSuccessMsg] = useState('');

  const currentRegistry = registries.find((r) => r.id === selectedRegistryId) || registries[0];

  const handleOpenContribute = (item?: GiftItem) => {
    if (item) {
      setSelectedItem(item);
      const remaining = Math.max(10, item.price - item.claimedAmount);
      setContributionAmount(remaining);
    } else {
      setSelectedItem(null);
      setContributionAmount(50);
    }
    setContributorMessage('');
    setCelebrationSuccess(false);
    setContributeModalOpen(true);
  };

  const handleContributeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentRegistry) return;
    setIsSubmitting(true);

    const success = await onContribute(currentRegistry.id, {
      contributorName: contributorName || 'Anonymous Well-Wisher',
      amount: Number(contributionAmount),
      message: contributorMessage || 'Wishing you an unforgettable holiday!',
      giftItemId: selectedItem?.id,
    });

    setIsSubmitting(false);
    if (success) {
      setCelebrationSuccess(true);
      setTimeout(() => {
        setContributeModalOpen(false);
        setCelebrationSuccess(false);
      }, 2200);
    }
  };

  const handleCreateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);

    const success = await onCreateRegistry({
      title: newTitle,
      recipientNames: newRecipients,
      occasion: newOccasion,
      destination: newDestination,
      targetAmount: Number(newTargetAmount),
      story: newStory,
      departureDate: newDepartureDate,
      organizerEmail: newEmail,
      items: [
        { id: `i_${Date.now()}_1`, title: 'Scenic Coach & Rail Passes', category: 'travel', price: 150, claimedAmount: 0, iconName: 'Train' },
        { id: `i_${Date.now()}_2`, title: 'Hand-picked Heritage Hotel (3 Nights)', category: 'hotel', price: 280, claimedAmount: 0, iconName: 'Hotel' },
        { id: `i_${Date.now()}_3`, title: 'Celebratory 3-Course Dinner with Wine', category: 'dining', price: 85, claimedAmount: 0, iconName: 'UtensilsCrossed' },
        { id: `i_${Date.now()}_4`, title: 'Cathedral / Castle Excursions', category: 'experience', price: 60, claimedAmount: 0, iconName: 'Compass' }
      ]
    });

    setIsCreating(false);
    if (success) {
      setCreateSuccessMsg('Your Great British Holiday Registry has been created and published live!');
      setActiveTab('browse');
      setTimeout(() => setCreateSuccessMsg(''), 5000);
    }
  };

  const copyShareLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard?.writeText(window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const filteredRegistries = registries.filter((r) =>
    r.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.recipientNames.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
    r.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section id="registry" className="py-16 sm:py-24 bg-gradient-to-b from-white via-slate-50 to-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-100 text-amber-900 text-xs font-bold uppercase tracking-wider mb-3">
            <Gift className="w-4 h-4 text-amber-600" />
            <span>Holiday &amp; Travel Gift Registry</span>
          </div>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0F2238] tracking-tight">
            Give the Gift of Adventure
          </h2>
          <p className="mt-4 text-base sm:text-lg text-slate-600 leading-relaxed">
            Instead of ordinary gifts, help friends, parents and newlyweds experience unforgettable British coach &amp; rail journeys. Contribute towards steam train rides, scenic hotels, and celebratory teas.
          </p>

          {/* Tab Switcher */}
          <div className="mt-8 inline-flex p-1.5 bg-slate-200/80 rounded-2xl shadow-inner text-sm font-semibold">
            <button
              onClick={() => setActiveTab('browse')}
              className={`px-6 py-2.5 rounded-xl transition-all cursor-pointer ${
                activeTab === 'browse'
                  ? 'bg-white text-slate-900 shadow-md font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Browse Active Registries
            </button>
            <button
              onClick={() => setActiveTab('create')}
              className={`px-6 py-2.5 rounded-xl transition-all flex items-center gap-2 cursor-pointer ${
                activeTab === 'create'
                  ? 'bg-[#0F2238] text-white shadow-md font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Plus className="w-4 h-4" />
              Create a Holiday Registry
            </button>
          </div>
        </div>

        {createSuccessMsg && (
          <div className="mb-8 p-4 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-sm font-medium flex items-center justify-between max-w-2xl mx-auto animate-fadeIn">
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5 text-emerald-600" />
              <span>{createSuccessMsg}</span>
            </div>
            <button onClick={() => setCreateSuccessMsg('')} className="text-emerald-700 hover:underline text-xs">
              Dismiss
            </button>
          </div>
        )}

        {/* Tab 1: Browse Active Registries */}
        {activeTab === 'browse' && (
          <div className="space-y-8">
            {/* Top Selector Strip */}
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-2 md:pb-0">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider shrink-0 mr-1">
                  Featured Registries:
                </span>
                {filteredRegistries.map((reg) => (
                  <button
                    key={reg.id}
                    onClick={() => setSelectedRegistryId(reg.id)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer border ${
                      selectedRegistryId === reg.id
                        ? 'bg-[#0F2238] text-white border-[#0F2238] shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {reg.recipientNames} ({reg.code})
                  </button>
                ))}
              </div>

              {/* Search Registry Input */}
              <div className="relative w-full md:w-72">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Search by name, destination or code..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 rounded-xl border border-slate-200 focus:outline-none focus:border-amber-500 font-medium"
                />
              </div>
            </div>

            {currentRegistry && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Left 2 Cols: Registry Details, Items & Contributions */}
                <div className="lg:col-span-2 space-y-6">
                  
                  {/* Registry Hero Card */}
                  <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-lg relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-amber-50 rounded-full blur-3xl -z-0 opacity-60" />
                    
                    <div className="relative z-10">
                      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                        <span className="px-3 py-1 rounded-md bg-amber-100 text-amber-900 font-bold text-xs uppercase tracking-wider">
                          {currentRegistry.occasion}
                        </span>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md border border-slate-200">
                            Code: {currentRegistry.code}
                          </span>
                          <button
                            onClick={copyShareLink}
                            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-md hover:bg-slate-100 transition-colors"
                            title="Share registry link"
                          >
                            {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
                          </button>
                        </div>
                      </div>

                      <h3 className="font-serif text-2xl sm:text-3xl font-extrabold text-slate-900">
                        {currentRegistry.title}
                      </h3>

                      <p className="text-sm font-semibold text-amber-700 mt-1 flex items-center gap-1.5">
                        <Compass className="w-4 h-4" /> Destination: {currentRegistry.destination} · Planned Departure: {new Date(currentRegistry.departureDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
                      </p>

                      <p className="mt-4 text-sm text-slate-600 leading-relaxed italic bg-slate-50 p-4 rounded-xl border border-slate-100">
                        &ldquo;{currentRegistry.story}&rdquo;
                      </p>

                      {/* Progress Bar & Amount Raised */}
                      <div className="mt-6 pt-6 border-t border-slate-100">
                        <div className="flex items-end justify-between mb-2">
                          <div>
                            <span className="text-2xl sm:text-3xl font-extrabold text-slate-900 font-mono">
                              £{currentRegistry.currentAmount}
                            </span>
                            <span className="text-xs text-slate-500 ml-1">raised of £{currentRegistry.targetAmount} goal</span>
                          </div>
                          <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 font-mono">
                            {Math.round((currentRegistry.currentAmount / currentRegistry.targetAmount) * 100)}% Funded
                          </span>
                        </div>

                        {/* Progress meter */}
                        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden shadow-inner">
                          <div
                            className="h-full bg-gradient-to-r from-amber-400 to-amber-500 rounded-full transition-all duration-700 ease-out"
                            style={{
                              width: `${Math.min(100, Math.round((currentRegistry.currentAmount / currentRegistry.targetAmount) * 100))}%`,
                            }}
                          />
                        </div>

                        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
                          <span className="text-xs text-slate-500">
                            {currentRegistry.contributions.length} family members &amp; friends contributed
                          </span>
                          <button
                            onClick={() => handleOpenContribute()}
                            className="px-5 py-2.5 bg-[#F2A900] hover:bg-[#d89600] text-slate-950 text-xs font-extrabold rounded-xl shadow transition-transform active:scale-95 flex items-center gap-1.5 cursor-pointer"
                          >
                            <Gift className="w-4 h-4" />
                            Contribute Custom Amount
                          </button>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* Specific Experience & Wishlist Items to Fund */}
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-serif text-xl font-bold text-slate-900">
                          Holiday Experiences on Wishlist
                        </h4>
                        <p className="text-xs text-slate-500">
                          Pick a specific rail journey, meal or hotel upgrade to fund for them
                        </p>
                      </div>
                      <span className="text-xs font-semibold text-slate-400">
                        {currentRegistry.items.length} items
                      </span>
                    </div>

                    <div className="space-y-3">
                      {currentRegistry.items.map((item) => {
                        const isFullyClaimed = item.claimedAmount >= item.price;
                        const pct = Math.min(100, Math.round((item.claimedAmount / item.price) * 100));

                        return (
                          <div
                            key={item.id}
                            className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                              isFullyClaimed
                                ? 'bg-slate-50 border-slate-200/60 opacity-80'
                                : 'bg-white border-slate-200 hover:border-amber-400 hover:shadow-md'
                            }`}
                          >
                            <div className="flex items-start gap-3.5">
                              <div className="w-10 h-10 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center shrink-0 border border-amber-100">
                                {item.category === 'travel' && <Train className="w-5 h-5" />}
                                {item.category === 'hotel' && <Hotel className="w-5 h-5" />}
                                {item.category === 'dining' && <UtensilsCrossed className="w-5 h-5" />}
                                {item.category === 'experience' && <Compass className="w-5 h-5" />}
                                {item.category === 'upgrade' && <Sparkles className="w-5 h-5" />}
                              </div>
                              <div>
                                <h5 className="text-sm font-bold text-slate-900">{item.title}</h5>
                                <div className="flex items-center gap-2 mt-1">
                                  <span className="text-xs font-mono font-bold text-slate-800">£{item.price}</span>
                                  <span className="text-[11px] text-slate-400">·</span>
                                  <span className="text-[11px] text-slate-500">
                                    £{item.claimedAmount} pledged ({pct}%)
                                  </span>
                                </div>
                                <div className="w-36 h-1.5 bg-slate-100 rounded-full mt-1.5 overflow-hidden">
                                  <div className="h-full bg-amber-400 rounded-full" style={{ width: `${pct}%` }} />
                                </div>
                              </div>
                            </div>

                            <div>
                              {isFullyClaimed ? (
                                <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-lg">
                                  <Check className="w-3.5 h-3.5" /> Fully Gifted
                                </span>
                              ) : (
                                <button
                                  onClick={() => handleOpenContribute(item)}
                                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition-all cursor-pointer whitespace-nowrap"
                                >
                                  Gift this (£{item.price - item.claimedAmount} left)
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                </div>

                {/* Right Col: Contributor Wall & Live Messages */}
                <div className="space-y-6">
                  <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-2 mb-4">
                      <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
                      <h4 className="font-serif text-lg font-bold text-slate-900">
                        Well-Wishes Wall
                      </h4>
                    </div>

                    <p className="text-xs text-slate-500 mb-4">
                      Heartfelt messages from friends and family joining this holiday gift:
                    </p>

                    <div className="space-y-3.5 max-h-[500px] overflow-y-auto pr-1">
                      {currentRegistry.contributions.map((c) => (
                        <div key={c.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 text-xs">
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="font-bold text-slate-900">{c.contributorName}</span>
                            <span className="font-mono font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                              +£{c.amount}
                            </span>
                          </div>
                          {c.giftItemTitle && (
                            <div className="text-[11px] text-amber-800 font-semibold mb-1 flex items-center gap-1">
                              <Sparkles className="w-3 h-3" />
                              <span>Funded: {c.giftItemTitle}</span>
                            </div>
                          )}
                          <p className="text-slate-600 italic">&ldquo;{c.message}&rdquo;</p>
                          <span className="text-[10px] text-slate-400 block mt-1.5">{c.timestamp}</span>
                        </div>
                      ))}
                    </div>

                    <button
                      onClick={() => handleOpenContribute()}
                      className="w-full mt-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-colors cursor-pointer text-center"
                    >
                      Leave a Message &amp; Gift
                    </button>
                  </div>
                </div>

              </div>
            )}
          </div>
        )}

        {/* Tab 2: Create a Holiday Registry Form */}
        {activeTab === 'create' && (
          <div className="max-w-2xl mx-auto bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-xl">
            <div className="mb-6">
              <h3 className="font-serif text-2xl font-bold text-slate-900">
                Create a Great British Holiday Registry
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1">
                Whether celebrating a wedding, milestone anniversary, or retirement, let loved ones contribute towards your scenic tour.
              </p>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Registry Title *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. John &amp; Mary’s 40th Ruby Anniversary Rail Adventure"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Recipients Names *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Mary &amp; John Smith"
                    value={newRecipients}
                    onChange={(e) => setNewRecipients(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Occasion *
                  </label>
                  <select
                    value={newOccasion}
                    onChange={(e) => setNewOccasion(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500 bg-white"
                  >
                    <option>Golden Wedding Anniversary (50 Years)</option>
                    <option>Wedding &amp; Coastal Honeymoon</option>
                    <option>Retirement Celebration Tour</option>
                    <option>Milestone Birthday (60th / 70th / 80th)</option>
                    <option>Family Christmas &amp; Steam Train Break</option>
                    <option>Summer Scenic Getaway</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Holiday Destination *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Scottish Highlands, Cornwall, Lake District"
                    value={newDestination}
                    onChange={(e) => setNewDestination(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Target Goal Amount (£) *
                  </label>
                  <input
                    type="number"
                    min="100"
                    step="50"
                    required
                    value={newTargetAmount}
                    onChange={(e) => setNewTargetAmount(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Estimated Travel Date
                  </label>
                  <input
                    type="date"
                    value={newDepartureDate}
                    onChange={(e) => setNewDepartureDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Organizer Email
                  </label>
                  <input
                    type="email"
                    placeholder="organizer@example.co.uk"
                    value={newEmail}
                    onChange={(e) => setNewEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Holiday Story / Personal Note
                </label>
                <textarea
                  rows={3}
                  placeholder="Share a short note about why this holiday means so much..."
                  value={newStory}
                  onChange={(e) => setNewStory(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isCreating}
                  className="w-full py-3.5 bg-[#0F2238] hover:bg-slate-800 text-white font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isCreating ? (
                    <span>Creating Registry...</span>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Launch Holiday Gift Registry</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Modal: Contribute to Registry */}
        {contributeModalOpen && currentRegistry && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
            <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative">
              <button
                onClick={() => setContributeModalOpen(false)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 text-xl font-bold w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100"
              >
                &times;
              </button>

              {celebrationSuccess ? (
                <div className="text-center py-8 space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-2xl shadow-inner">
                    ✓
                  </div>
                  <h3 className="font-serif text-2xl font-bold text-slate-900">
                    Thank You for Gifting Travel!
                  </h3>
                  <p className="text-sm text-slate-600 max-w-xs mx-auto">
                    Your contribution of <strong className="font-mono text-slate-900">£{contributionAmount}</strong> and personal message have been added to {currentRegistry.recipientNames}&apos;s holiday fund!
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 mb-2">
                    <Gift className="w-5 h-5 text-amber-500" />
                    <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                      Gift Contribution
                    </span>
                  </div>

                  <h3 className="font-serif text-2xl font-bold text-slate-900">
                    {selectedItem ? `Fund ${selectedItem.title}` : `Gift towards ${currentRegistry.recipientNames}`}
                  </h3>

                  <p className="text-xs text-slate-500 mb-6">
                    Registry code: <strong className="font-mono text-slate-700">{currentRegistry.code}</strong>
                  </p>

                  <form onSubmit={handleContributeSubmit} className="space-y-4">
                    {/* Amount Selector */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                        Choose Amount (£)
                      </label>
                      <div className="grid grid-cols-4 gap-2 mb-2">
                        {[25, 50, 75, 100].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setContributionAmount(preset)}
                            className={`py-2 text-xs font-bold rounded-lg border transition-all cursor-pointer font-mono ${
                              contributionAmount === preset
                                ? 'bg-amber-400 text-slate-950 border-amber-500 shadow-sm'
                                : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                            }`}
                          >
                            £{preset}
                          </button>
                        ))}
                      </div>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 font-mono text-sm font-bold text-slate-500">£</span>
                        <input
                          type="number"
                          min="5"
                          step="5"
                          required
                          value={contributionAmount}
                          onChange={(e) => setContributionAmount(Number(e.target.value))}
                          className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 text-sm font-bold font-mono focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Your Name (or Family Name) *
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Auntie Sarah &amp; Uncle David"
                        value={contributorName}
                        onChange={(e) => setContributorName(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                        Greeting Card Message
                      </label>
                      <textarea
                        rows={2}
                        placeholder="Write your personal congratulations or travel wishes..."
                        value={contributorMessage}
                        onChange={(e) => setContributorMessage(e.target.value)}
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:outline-none focus:border-amber-500"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 bg-[#F2A900] hover:bg-[#d89600] text-slate-950 font-bold text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Processing Contribution...</span>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          <span>Send £{contributionAmount} Gift &amp; Greetings</span>
                        </>
                      )}
                    </button>
                  </form>
                </>
              )}
            </div>
          </div>
        )}

      </div>
    </section>
  );
};
