'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Search, X, MapPin, ArrowRight, Bus, Train } from 'lucide-react';
import { HolidayPackage } from '@/types/holiday';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  packages: HolidayPackage[];
  onSelectPackage: (pkg: HolidayPackage) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  packages,
  onSelectPackage,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('All');

  if (!isOpen) return null;

  const filtered = packages.filter((pkg) => {
    const matchesQuery =
      pkg.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pkg.destination.toLowerCase().includes(searchTerm.toLowerCase()) ||
      pkg.tagline.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRegion =
      selectedRegion === 'All' || pkg.region === selectedRegion;

    return matchesQuery && matchesRegion;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-start justify-center p-4 pt-16 sm:pt-24 animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 relative max-h-[80vh] flex flex-col">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 text-xl font-bold w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100"
        >
          &times;
        </button>

        {/* Search Input Bar */}
        <div className="relative mb-4">
          <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search UK holidays (e.g. Edinburgh, Steam rail, Cornwall, Lakes)..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            autoFocus
            className="w-full pl-11 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-semibold focus:outline-none focus:border-amber-500 focus:bg-white"
          />
        </div>

        {/* Region Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-3 mb-2 text-xs">
          {['All', 'Scotland', 'Cornwall', 'England', 'Wales', 'Cotswolds'].map((reg) => (
            <button
              key={reg}
              onClick={() => setSelectedRegion(reg)}
              className={`px-3 py-1.5 rounded-xl font-semibold transition-colors shrink-0 cursor-pointer ${
                selectedRegion === reg
                  ? 'bg-[#0F2238] text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {reg}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="overflow-y-auto space-y-2.5 flex-1 pr-1">
          {filtered.length === 0 ? (
            <div className="text-center py-10 text-xs text-slate-500">
              No matching British holidays found. Try another destination or search keyword.
            </div>
          ) : (
            filtered.map((pkg) => (
              <div
                key={pkg.id}
                onClick={() => {
                  onSelectPackage(pkg);
                  onClose();
                }}
                className="p-3 rounded-2xl border border-slate-200 hover:border-amber-400 hover:bg-amber-50/20 transition-all flex items-center justify-between gap-4 cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="relative w-14 h-14 rounded-xl overflow-hidden shrink-0">
                    <Image
                      src={pkg.image}
                      alt={pkg.destination}
                      fill
                      className="object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-serif font-bold text-sm text-slate-900">{pkg.destination}</span>
                      <span className="text-[11px] text-slate-400">·</span>
                      <span className="text-[11px] text-slate-500 font-medium">{pkg.duration}</span>
                    </div>
                    <p className="text-xs text-slate-600 line-clamp-1">{pkg.title}</p>
                    <div className="text-xs font-mono font-bold text-amber-600 mt-0.5">
                      From £{pkg.basePrice}pp
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs font-bold text-[#0F2238] group-hover:text-amber-600 shrink-0">
                  <span>View</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </div>
            ))
          )}
        </div>

      </div>
    </div>
  );
};
