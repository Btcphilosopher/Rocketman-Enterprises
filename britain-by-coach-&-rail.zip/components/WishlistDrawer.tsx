'use client';

import React from 'react';
import Image from 'next/image';
import { X, Trash2, ArrowRight, Heart, Bus, Train } from 'lucide-react';
import { HolidayPackage } from '@/types/holiday';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlistPackages: HolidayPackage[];
  onRemove: (id: string) => void;
  onBook: (pkg: HolidayPackage) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlistPackages,
  onRemove,
  onBook,
}) => {
  if (!isOpen) return null;

  const totalEstimate = wishlistPackages.reduce((acc, curr) => acc + curr.basePrice, 0);

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex justify-end animate-fadeIn">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col justify-between p-6 overflow-y-auto">
        
        {/* Header */}
        <div>
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-amber-500 fill-amber-500" />
              <h3 className="font-serif text-xl font-bold text-slate-900">
                Saved Holidays ({wishlistPackages.length})
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-slate-400 hover:text-slate-700 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List */}
          {wishlistPackages.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Heart className="w-6 h-6" />
              </div>
              <p className="text-sm text-slate-500">
                You haven&apos;t saved any holidays yet. Click the heart icon on any destination card to bookmark it here!
              </p>
            </div>
          ) : (
            <div className="py-4 space-y-3">
              {wishlistPackages.map((pkg) => (
                <div
                  key={pkg.id}
                  className="p-3 rounded-2xl border border-slate-200 flex gap-3 items-center justify-between hover:border-amber-400 transition-all"
                >
                  <div className="flex items-center gap-3">
                    <div className="relative w-14 h-14 rounded-xl overflow-hidden shrink-0">
                      <Image
                        src={pkg.image}
                        alt={pkg.destination}
                        fill
                        className="object-cover"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">{pkg.destination}</h4>
                      <p className="text-xs text-slate-500 line-clamp-1">{pkg.title}</p>
                      <div className="text-xs font-mono font-bold text-amber-600 mt-0.5">
                        From £{pkg.basePrice}pp
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        onClose();
                        onBook(pkg);
                      }}
                      className="px-3 py-1.5 bg-[#0F2238] hover:bg-slate-800 text-white text-xs font-bold rounded-lg cursor-pointer whitespace-nowrap"
                    >
                      Book
                    </button>
                    <button
                      onClick={() => onRemove(pkg.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {wishlistPackages.length > 0 && (
          <div className="pt-4 border-t border-slate-200">
            <div className="flex items-center justify-between text-xs mb-3">
              <span className="text-slate-500">Estimated Total (1 person each):</span>
              <span className="font-mono font-bold text-base text-slate-900">£{totalEstimate}</span>
            </div>
            <button
              onClick={onClose}
              className="w-full py-3 bg-[#F2A900] hover:bg-[#d89600] text-slate-950 font-bold text-xs rounded-xl shadow cursor-pointer text-center"
            >
              Continue Exploring Tours
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
