'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, Heart, Bus, Train, Calendar, Check, Gift } from 'lucide-react';
import { HolidayPackage } from '@/types/holiday';

interface DestinationsGridProps {
  packages: HolidayPackage[];
  onSelectPackage: (pkg: HolidayPackage) => void;
  onToggleWishlist: (pkg: HolidayPackage) => void;
  wishlistIds: string[];
  onAddToRegistryItem?: (pkg: HolidayPackage) => void;
}

export const DestinationsGrid: React.FC<DestinationsGridProps> = ({
  packages,
  onSelectPackage,
  onToggleWishlist,
  wishlistIds,
  onAddToRegistryItem,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'coach' | 'rail' | 'both'>('all');

  const filtered = packages.filter((pkg) => {
    if (filterMode === 'all') return true;
    return pkg.travelMode === filterMode || pkg.travelMode === 'both';
  });

  return (
    <section id="destinations" className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section from Screenshot */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div className="max-w-2xl">
            {/* Eyebrow */}
            <div className="flex items-center gap-2 mb-2">
              <span className="h-[2px] w-5 bg-amber-500"></span>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-600">
                POPULAR DESTINATIONS
              </span>
              <span className="h-[2px] w-5 bg-amber-500"></span>
            </div>

            {/* Headline */}
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-extrabold text-[#0F2238] tracking-tight">
              Discover the Best of Britain
            </h2>

            {/* Subhead */}
            <p className="mt-3 text-slate-600 text-sm sm:text-base leading-relaxed">
              From historic cities to breathtaking coastlines, our coach and rail holidays take you to the UK&apos;s most loved destinations.
            </p>
          </div>

          {/* Action Button & Travel Mode Filter Tabs */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="inline-flex bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setFilterMode('all')}
                className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                  filterMode === 'all' ? 'bg-[#0F2238] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Tours
              </button>
              <button
                onClick={() => setFilterMode('coach')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 cursor-pointer ${
                  filterMode === 'coach' ? 'bg-[#0F2238] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Bus className="w-3 h-3" /> Coach
              </button>
              <button
                onClick={() => setFilterMode('rail')}
                className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1 cursor-pointer ${
                  filterMode === 'rail' ? 'bg-[#0F2238] text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Train className="w-3 h-3" /> Rail
              </button>
            </div>

            <button
              onClick={() => {
                const el = document.getElementById('destinations');
                el?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#0F2238] hover:bg-slate-800 text-white text-xs font-bold rounded-full shadow transition-all cursor-pointer whitespace-nowrap"
            >
              <span>View All Destinations</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* 5-Column Destination Cards Grid (matches exact layout from screenshot) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-5">
          {filtered.map((pkg) => {
            const isWishlisted = wishlistIds.includes(pkg.id);
            return (
              <div
                key={pkg.id}
                className="group relative rounded-2xl overflow-hidden bg-slate-900 text-white shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-end min-h-[380px] border border-slate-200/20"
              >
                {/* Background Image */}
                <div className="absolute inset-0 z-0">
                  <Image
                    src={pkg.image}
                    alt={pkg.destination}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                    referrerPolicy="no-referrer"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 33vw, 20vw"
                  />
                  {/* Dark gradient overlay for text readability matching screenshot */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                </div>

                {/* Top Badges: Travel Mode & Wishlist */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-black/50 backdrop-blur-md text-[11px] font-semibold text-white border border-white/10">
                    {pkg.travelMode === 'coach' && <><Bus className="w-3 h-3 text-amber-300" /> Coach</>}
                    {pkg.travelMode === 'rail' && <><Train className="w-3 h-3 text-sky-300" /> Rail</>}
                    {pkg.travelMode === 'both' && <><Train className="w-3 h-3 text-sky-300" /><Bus className="w-3 h-3 text-amber-300" /> Coach &amp; Rail</>}
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleWishlist(pkg);
                    }}
                    className={`p-2 rounded-full backdrop-blur-md transition-colors ${
                      isWishlisted ? 'bg-amber-400 text-slate-950' : 'bg-black/40 text-white hover:bg-black/70'
                    }`}
                    title={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
                  >
                    <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-slate-950' : ''}`} />
                  </button>
                </div>

                {/* Card Content (Destination, Tagline, Price PP) */}
                <div className="relative z-10 p-5 flex flex-col justify-end">
                  <h3 className="font-serif text-2xl font-bold tracking-tight text-white mb-1">
                    {pkg.destination}
                  </h3>
                  
                  <p className="text-xs text-slate-300 line-clamp-2 mb-3 leading-snug">
                    {pkg.tagline}
                  </p>

                  <div className="pt-2 border-t border-white/20 flex items-center justify-between">
                    <div>
                      <span className="text-[11px] text-slate-300 uppercase tracking-wide">From </span>
                      <span className="font-bold text-base text-amber-400 font-mono">£{pkg.basePrice}</span>
                      <span className="text-[11px] text-slate-300">pp</span>
                    </div>

                    <button
                      onClick={() => onSelectPackage(pkg)}
                      className="inline-flex items-center gap-1 text-xs font-bold text-white group-hover:text-amber-400 transition-colors cursor-pointer"
                    >
                      <span>Explore</span>
                      <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
