'use client';

import React, { useState } from 'react';
import { X, Check, ShieldCheck, Bus, Train, Calendar, MapPin, Users, Send } from 'lucide-react';
import { HolidayPackage } from '@/types/holiday';
import { DEPARTURE_TOWNS } from '@/data/mockData';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPackage: HolidayPackage | null;
  initialTourTitle?: string;
  initialPrice?: number;
  onConfirmBooking: (data: any) => Promise<any>;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  selectedPackage,
  initialTourTitle,
  initialPrice,
  onConfirmBooking,
}) => {
  const [departureTown, setDepartureTown] = useState('London Victoria');
  const [travelDate, setTravelDate] = useState('2027-04-20');
  const [adults, setAdults] = useState(2);
  const [seniors, setSeniors] = useState(0);
  const [children, setChildren] = useState(0);
  const [contactName, setContactName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [specialRequests, setSpecialRequests] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingConfirmed, setBookingConfirmed] = useState<any>(null);

  if (!isOpen) return null;

  const basePrice = selectedPackage?.basePrice || initialPrice || 109;
  const tourTitle = selectedPackage?.title || initialTourTitle || 'Great British Holiday Tour';

  const adultCost = adults * basePrice;
  const seniorCost = seniors * (basePrice * 0.95);
  const childCost = children * (basePrice * 0.75);
  const totalCost = Math.round(adultCost + seniorCost + childCost);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    const result = await onConfirmBooking({
      holidayId: selectedPackage?.id || 'custom-tour',
      holidayTitle: tourTitle,
      departureTown,
      travelDate,
      passengers: { adults, seniors, children },
      basePrice,
      contactName,
      email,
      phone,
      specialRequests,
    });

    setIsSubmitting(false);
    if (result?.status === 'success') {
      setBookingConfirmed(result.details);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-slate-200 relative my-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 text-xl font-bold w-8 h-8 rounded-full flex items-center justify-center hover:bg-slate-100"
        >
          &times;
        </button>

        {bookingConfirmed ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto text-3xl font-bold shadow-inner">
              ✓
            </div>
            
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 text-xs font-bold font-mono">
              Reservation Reference: {bookingConfirmed.bookingReference}
            </div>

            <h3 className="font-serif text-2xl font-bold text-slate-900">
              Provisional Booking Held!
            </h3>

            <p className="text-sm text-slate-600 max-w-sm mx-auto leading-relaxed">
              Your seats on the <strong className="text-slate-900">{bookingConfirmed.holidayTitle}</strong> from <strong className="text-slate-900">{bookingConfirmed.departureTown}</strong> have been secured for 48 hours.
            </p>

            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-left text-xs space-y-2 max-w-md mx-auto font-mono">
              <div className="flex justify-between">
                <span className="text-slate-500">Total Travellers:</span>
                <span className="font-bold text-slate-800">{bookingConfirmed.passengers.total} passengers</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Departure Date:</span>
                <span className="font-bold text-slate-800">{bookingConfirmed.travelDate}</span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200 font-sans">
                <span className="font-bold text-slate-800">Total Holiday Fare:</span>
                <span className="text-base font-extrabold text-amber-600 font-mono">£{bookingConfirmed.financials.totalAmount}</span>
              </div>
              <div className="flex items-center gap-1 text-[11px] text-sky-700 font-sans pt-1">
                <ShieldCheck className="w-4 h-4 shrink-0" />
                <span>100% Protected under ATOL #10842 &amp; ABTA Y6291</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="mt-4 px-6 py-2.5 bg-slate-900 text-white font-bold text-xs rounded-xl hover:bg-slate-800 transition-colors cursor-pointer"
            >
              Done &amp; Close
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-bold text-amber-600 uppercase tracking-wider">
                Holiday Reservation
              </span>
            </div>

            <h3 className="font-serif text-2xl font-bold text-slate-900 mb-1">
              {tourTitle}
            </h3>
            
            <p className="text-xs text-slate-500 mb-4 flex items-center gap-2">
              <span>From £{basePrice}pp</span>
              <span>·</span>
              <span className="text-emerald-700 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> ATOL Protected
              </span>
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Pickup Town & Date */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-slate-500" />
                    Departure Town
                  </label>
                  <select
                    value={departureTown}
                    onChange={(e) => setDepartureTown(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:outline-none focus:border-amber-500 bg-white"
                  >
                    {DEPARTURE_TOWNS.map((town) => (
                      <option key={town} value={town}>
                        {town}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-500" />
                    Travel Date
                  </label>
                  <input
                    type="date"
                    required
                    value={travelDate}
                    min="2027-03-01"
                    onChange={(e) => setTravelDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Passengers Breakdown */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-slate-500" />
                  Passengers
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <span className="text-[11px] text-slate-500 block">Adults</span>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <button
                        type="button"
                        onClick={() => setAdults(Math.max(1, adults - 1))}
                        className="w-6 h-6 rounded border border-slate-300 font-bold hover:bg-slate-200"
                      >
                        -
                      </button>
                      <span className="font-bold text-sm font-mono">{adults}</span>
                      <button
                        type="button"
                        onClick={() => setAdults(adults + 1)}
                        className="w-6 h-6 rounded border border-slate-300 font-bold hover:bg-slate-200"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-500 block">Seniors 65+</span>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <button
                        type="button"
                        onClick={() => setSeniors(Math.max(0, seniors - 1))}
                        className="w-6 h-6 rounded border border-slate-300 font-bold hover:bg-slate-200"
                      >
                        -
                      </button>
                      <span className="font-bold text-sm font-mono">{seniors}</span>
                      <button
                        type="button"
                        onClick={() => setSeniors(seniors + 1)}
                        className="w-6 h-6 rounded border border-slate-300 font-bold hover:bg-slate-200"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-500 block">Children 3-15</span>
                    <div className="flex items-center justify-center gap-2 mt-1">
                      <button
                        type="button"
                        onClick={() => setChildren(Math.max(0, children - 1))}
                        className="w-6 h-6 rounded border border-slate-300 font-bold hover:bg-slate-200"
                      >
                        -
                      </button>
                      <span className="font-bold text-sm font-mono">{children}</span>
                      <button
                        type="button"
                        onClick={() => setChildren(children + 1)}
                        className="w-6 h-6 rounded border border-slate-300 font-bold hover:bg-slate-200"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact info */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Eleanor Rigby"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="eleanor@example.co.uk"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                  Telephone Contact *
                </label>
                <input
                  type="tel"
                  required
                  placeholder="07700 900077"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:outline-none focus:border-amber-500"
                />
              </div>

              {/* Cost summary and submit */}
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500">Estimated Total:</span>
                  <div className="text-2xl font-extrabold text-amber-600 font-mono">
                    £{totalCost}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-3 bg-[#F2A900] hover:bg-[#d89600] text-slate-950 font-bold text-xs rounded-xl shadow transition-all cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <span>Confirming...</span>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      <span>Hold Reservation Now</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </>
        )}

      </div>
    </div>
  );
};
