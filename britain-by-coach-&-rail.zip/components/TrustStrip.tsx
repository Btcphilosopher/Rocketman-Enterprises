import React from 'react';
import { Bus, Trees, ShieldCheck, Star } from 'lucide-react';

export const TrustStrip: React.FC = () => {
  return (
    <section className="bg-slate-50 border-b border-slate-200/80 py-10 mt-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6 lg:gap-8 items-start">
          
          {/* 1. Great Value */}
          <div className="flex items-start gap-3.5 group">
            <div className="w-12 h-12 rounded-full bg-[#0F2238] text-white flex items-center justify-center shrink-0 shadow-sm font-serif font-bold text-xl">
              £
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Great Value
              </h2>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Fantastic holidays from just £99pp
              </p>
            </div>
          </div>

          {/* 2. Comfortable Travel */}
          <div className="flex items-start gap-3.5 group">
            <div className="w-12 h-12 rounded-full bg-[#0F2238] text-white flex items-center justify-center shrink-0 shadow-sm">
              <Bus className="w-5 h-5 text-amber-300" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Comfortable Travel
              </h2>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Modern coaches &amp; scenic train journeys
              </p>
            </div>
          </div>

          {/* 3. Amazing Destinations */}
          <div className="flex items-start gap-3.5 group">
            <div className="w-12 h-12 rounded-full bg-[#0F2238] text-white flex items-center justify-center shrink-0 shadow-sm">
              <Trees className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Amazing Destinations
              </h2>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Coast, countryside, cathedrals &amp; more
              </p>
            </div>
          </div>

          {/* 4. ATOL Protected */}
          <div className="flex items-start gap-3.5 group">
            <div className="w-12 h-12 rounded-full bg-[#0F2238] text-white flex items-center justify-center shrink-0 shadow-sm">
              <ShieldCheck className="w-5 h-5 text-sky-300" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                ATOL Protected
              </h2>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Book with confidence &amp; financial protection
              </p>
            </div>
          </div>

          {/* 5. Thousands of Happy Travellers */}
          <div className="col-span-2 sm:col-span-1 flex items-start gap-3.5 group">
            <div className="w-12 h-12 rounded-full bg-[#0F2238] text-amber-400 flex items-center justify-center shrink-0 shadow-sm">
              <Star className="w-5 h-5 fill-amber-400" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900 group-hover:text-amber-600 transition-colors">
                Thousands of Happy Travellers
              </h2>
              <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">
                Rated Excellent on Trustpilot
              </p>
              {/* Trustpilot 5 stars badges */}
              <div className="flex items-center gap-1 mt-1.5">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-3.5 h-3.5 bg-[#00b67a] flex items-center justify-center text-white text-[9px]">
                    ★
                  </div>
                ))}
                <span className="text-[11px] font-semibold text-slate-700 ml-1">4.9/5</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
