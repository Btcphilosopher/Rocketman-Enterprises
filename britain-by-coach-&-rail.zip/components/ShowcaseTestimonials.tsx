'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Bus, Train, Quote, Star } from 'lucide-react';

interface ShowcaseTestimonialsProps {
  onExploreCoach: () => void;
  onExploreRail: () => void;
}

export const ShowcaseTestimonials: React.FC<ShowcaseTestimonialsProps> = ({
  onExploreCoach,
  onExploreRail,
}) => {
  return (
    <section id="testimonials" className="bg-[#0F2238] text-white overflow-hidden border-t border-slate-800">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[300px]">
          
          {/* 1. Left Scenic Train Image (3 cols) */}
          <div className="lg:col-span-3 relative min-h-[240px] lg:min-h-full">
            <Image
              src="https://images.unsplash.com/photo-1584003564943-60f45353f018?auto=format&fit=crop&w=800&q=80"
              alt="Scenic coastal train route in Great Britain"
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#0F2238]/60 lg:to-[#0F2238]" />
          </div>

          {/* 2. Middle Options: Coach & Rail Holidays / Short Breaks (5 cols) */}
          <div className="lg:col-span-5 p-6 sm:p-10 flex flex-col justify-center divide-y divide-slate-800 space-y-6">
            
            {/* Coach & Rail Holidays */}
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-center shrink-0">
                <Bus className="w-6 h-6 text-amber-300" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-white">
                  Coach &amp; Rail Holidays
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Relax, unwind and let us take you there.
                </p>
                <button
                  onClick={onExploreCoach}
                  className="mt-2 text-xs font-bold text-[#F2A900] hover:text-amber-300 inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Explore Coach Holidays</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Short Breaks */}
            <div className="pt-6 flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-slate-800/80 border border-slate-700 flex items-center justify-center shrink-0">
                <Train className="w-6 h-6 text-sky-300" />
              </div>
              <div>
                <h3 className="font-serif text-lg font-bold text-white">
                  Short Breaks
                </h3>
                <p className="text-xs text-slate-300 mt-1">
                  Perfect for a weekend away across the UK.
                </p>
                <button
                  onClick={onExploreRail}
                  className="mt-2 text-xs font-bold text-[#F2A900] hover:text-amber-300 inline-flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <span>Explore Rail Holidays</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

          </div>

          {/* 3. Right: Sarah T Testimonial Box & Coastal Image (4 cols) */}
          <div className="lg:col-span-4 bg-white text-slate-900 p-6 sm:p-8 flex flex-col justify-between relative shadow-lg">
            <div>
              <Quote className="w-8 h-8 text-slate-300 rotate-180 mb-2" />
              <blockquote className="font-serif text-base sm:text-lg font-medium text-slate-800 leading-snug">
                &ldquo;Fantastic trip to the Lake District. Well organised, great value and lovely hotel. Will definitely book again!&rdquo;
              </blockquote>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-200">
              <div className="text-xs font-bold text-slate-900">
                — Sarah T, Manchester
              </div>
              {/* Trustpilot stars */}
              <div className="flex items-center gap-1 mt-1.5">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="w-4 h-4 bg-[#00b67a] flex items-center justify-center text-white text-[10px] font-bold">
                    ★
                  </div>
                ))}
                <span className="text-xs font-bold text-slate-700 ml-1.5">Verified Traveller</span>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
