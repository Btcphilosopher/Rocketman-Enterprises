'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { ArrowRight, MapPin, Calendar, Users, ChevronDown, Check } from 'lucide-react';
import { DEPARTURE_TOWNS, DESTINATIONS_LIST } from '@/data/mockData';

interface HeroProps {
  onSearch: (params: {
    from: string;
    to: string;
    date: string;
    adults: number;
    seniors: number;
    children: number;
  }) => void;
  onExploreDeals: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onSearch, onExploreDeals }) => {
  const [departureTown, setDepartureTown] = useState('London Victoria');
  const [destination, setDestination] = useState('All UK Destinations');
  const [departDate, setDepartDate] = useState('2027-04-15');
  const [passengerDropdownOpen, setPassengerDropdownOpen] = useState(false);
  const [adults, setAdults] = useState(2);
  const [seniors, setSeniors] = useState(0);
  const [children, setChildren] = useState(0);

  const totalPassengers = adults + seniors + children;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      from: departureTown,
      to: destination,
      date: departDate,
      adults,
      seniors,
      children,
    });
  };

  return (
    <div className="relative bg-[#0b1b2d] overflow-hidden">
      {/* Background Graphic & Hero Image */}
      <div className="relative w-full h-[580px] sm:h-[640px] lg:h-[700px] overflow-hidden">
        {/* Main Hero Visual using the user provided high-res screenshot asset */}
        <Image
          src="/assets/aistudio/Britain_Coach-Rail_604d5e5e.png"
          alt="Great British Holidays for Less - Scenic UK Coach and Rail Travel"
          fill
          priority
          className="object-cover object-top opacity-95 filter brightness-95"
          referrerPolicy="no-referrer"
        />

        {/* Soft gradient vignette to ensure text contrast while retaining beautiful scenic photography */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/85 via-slate-900/60 to-transparent lg:w-3/5" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-slate-950/30" />

        {/* Hero Content Overlay */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex flex-col justify-between pt-12 sm:pt-16 pb-28 sm:pb-36">
          <div className="max-w-xl">
            {/* Eyebrow */}
            <div className="flex items-center gap-2 mb-3">
              <span className="h-[2px] w-6 bg-[#F2A900]"></span>
              <span className="text-xs sm:text-sm font-bold uppercase tracking-widest text-[#F2A900]">
                EXPLORE THE UK
              </span>
              <span className="h-[2px] w-6 bg-[#F2A900]"></span>
            </div>

            {/* Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1] drop-shadow-sm mb-4">
              Great British Holidays for Less
            </h1>

            {/* Subhead */}
            <p className="text-base sm:text-lg text-slate-200 font-normal leading-relaxed mb-8 max-w-lg drop-shadow">
              Coach & rail holidays to stunning destinations across the UK. Affordable. Comfortable. Unforgettable.
            </p>

            {/* View Holiday Deals Amber CTA */}
            <button
              onClick={onExploreDeals}
              className="inline-flex items-center gap-3 px-6 py-3.5 bg-[#F2A900] hover:bg-[#d89600] text-slate-950 font-bold text-base rounded-full shadow-lg transition-all hover:gap-4 hover:shadow-xl active:scale-95 group cursor-pointer"
            >
              <span>View Holiday Deals</span>
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* Script Quote on Right (matching screenshot: "Same country. A thousand adventures.") */}
          <div className="hidden lg:flex self-end mb-6 text-right">
            <div className="text-white drop-shadow-md">
              <p className="font-serif italic text-2xl xl:text-3xl tracking-wide opacity-95">
                &ldquo;Same country. A thousand adventures.&rdquo;
              </p>
              <p className="text-xs uppercase tracking-widest text-amber-300 font-semibold mt-1">
                Coast · Countryside · Heritage Steam · Scenic Rail
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Floating Interactive Search Widget overlapping hero bottom */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 sm:-mt-24 relative z-30">
        <div className="bg-white rounded-2xl shadow-2xl p-4 sm:p-5 lg:p-6 border border-slate-200">
          <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3.5 sm:gap-4 items-center">
            
            {/* From: Departure Town */}
            <div className="relative border border-slate-200 rounded-xl p-2.5 sm:p-3 hover:border-amber-400 focus-within:border-amber-500 transition-colors bg-slate-50/50">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-slate-700" />
                <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">From</label>
              </div>
              <select
                value={departureTown}
                onChange={(e) => setDepartureTown(e.target.value)}
                className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none cursor-pointer truncate"
              >
                {DEPARTURE_TOWNS.map((town) => (
                  <option key={town} value={town}>
                    {town}
                  </option>
                ))}
              </select>
            </div>

            {/* To: Destination */}
            <div className="relative border border-slate-200 rounded-xl p-2.5 sm:p-3 hover:border-amber-400 focus-within:border-amber-500 transition-colors bg-slate-50/50">
              <div className="flex items-center gap-2 mb-1">
                <MapPin className="w-4 h-4 text-slate-700" />
                <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">To</label>
              </div>
              <select
                value={destination}
                onChange={(e) => setDestination(e.target.value)}
                className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none cursor-pointer truncate"
              >
                {DESTINATIONS_LIST.map((dest) => (
                  <option key={dest} value={dest}>
                    {dest}
                  </option>
                ))}
              </select>
            </div>

            {/* Depart Date */}
            <div className="relative border border-slate-200 rounded-xl p-2.5 sm:p-3 hover:border-amber-400 focus-within:border-amber-500 transition-colors bg-slate-50/50">
              <div className="flex items-center gap-2 mb-1">
                <Calendar className="w-4 h-4 text-slate-700" />
                <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Depart</label>
              </div>
              <input
                type="date"
                value={departDate}
                onChange={(e) => setDepartDate(e.target.value)}
                min="2027-03-01"
                className="w-full bg-transparent text-sm font-semibold text-slate-900 focus:outline-none cursor-pointer"
              />
            </div>

            {/* Passengers Dropdown Selector */}
            <div className="relative border border-slate-200 rounded-xl p-2.5 sm:p-3 hover:border-amber-400 focus-within:border-amber-500 transition-colors bg-slate-50/50">
              <div className="flex items-center gap-2 mb-1">
                <Users className="w-4 h-4 text-slate-700" />
                <label className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Passengers</label>
              </div>
              <button
                type="button"
                onClick={() => setPassengerDropdownOpen(!passengerDropdownOpen)}
                className="w-full flex items-center justify-between text-left text-sm font-semibold text-slate-900 focus:outline-none"
              >
                <span>{totalPassengers} {totalPassengers === 1 ? 'Passenger' : 'Passengers'} ({adults} Ad{seniors > 0 ? `, ${seniors} Snr` : ''}{children > 0 ? `, ${children} Ch` : ''})</span>
                <ChevronDown className="w-4 h-4 text-slate-400" />
              </button>

              {/* Floating passenger selector popover */}
              {passengerDropdownOpen && (
                <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-slate-200 p-4 z-50 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-sm font-bold text-slate-900">Adults</div>
                      <div className="text-xs text-slate-500">Age 16–64</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setAdults(Math.max(1, adults - 1))}
                        className="w-7 h-7 rounded border border-slate-300 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-bold text-slate-900">{adults}</span>
                      <button
                        type="button"
                        onClick={() => setAdults(adults + 1)}
                        className="w-7 h-7 rounded border border-slate-300 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-100 pt-2">
                    <div>
                      <div className="text-sm font-bold text-slate-900">Seniors</div>
                      <div className="text-xs text-slate-500">Age 65+ (5% off)</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setSeniors(Math.max(0, seniors - 1))}
                        className="w-7 h-7 rounded border border-slate-300 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-bold text-slate-900">{seniors}</span>
                      <button
                        type="button"
                        onClick={() => setSeniors(seniors + 1)}
                        className="w-7 h-7 rounded border border-slate-300 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-100 pt-2">
                    <div>
                      <div className="text-sm font-bold text-slate-900">Children</div>
                      <div className="text-xs text-slate-500">Age 3–15 (25% off)</div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setChildren(Math.max(0, children - 1))}
                        className="w-7 h-7 rounded border border-slate-300 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100"
                      >
                        -
                      </button>
                      <span className="w-6 text-center font-bold text-slate-900">{children}</span>
                      <button
                        type="button"
                        onClick={() => setChildren(children + 1)}
                        className="w-7 h-7 rounded border border-slate-300 flex items-center justify-center font-bold text-slate-700 hover:bg-slate-100"
                      >
                        +
                      </button>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => setPassengerDropdownOpen(false)}
                    className="w-full mt-2 py-1.5 bg-slate-900 text-white rounded text-xs font-semibold flex items-center justify-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" /> Done
                  </button>
                </div>
              )}
            </div>

            {/* Amber Search Holidays Button */}
            <div className="w-full">
              <button
                type="submit"
                className="w-full h-[58px] bg-[#F2A900] hover:bg-[#d89600] text-slate-950 font-bold rounded-xl flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 cursor-pointer"
              >
                <span className="text-base font-bold">Search Holidays</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
};
