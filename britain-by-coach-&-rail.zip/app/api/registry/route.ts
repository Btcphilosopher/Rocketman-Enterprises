import { NextRequest, NextResponse } from 'next/server';
import { INITIAL_GIFT_REGISTRIES } from '@/data/mockData';
import { GiftRegistry } from '@/types/holiday';

// In-memory runtime cache for server-side persistence in applet
let registriesStore: GiftRegistry[] = [...INITIAL_GIFT_REGISTRIES];

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const action = searchParams.get('action') || 'list';
  const code = searchParams.get('code');

  if (action === 'get' && code) {
    const reg = registriesStore.find(
      (r) => r.code.toUpperCase() === code.toUpperCase() || r.id === code
    );
    if (!reg) {
      return NextResponse.json({ status: 'error', message: 'Registry not found' }, { status: 404 });
    }
    return NextResponse.json({ status: 'success', data: reg });
  }

  return NextResponse.json({
    status: 'success',
    count: registriesStore.length,
    data: registriesStore,
    backendEngine: 'PHP 8.3 & Next.js Server Bridge'
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    if (action === 'contribute') {
      const { registryId, contributorName, amount, message, giftItemId } = body;
      const numAmount = Number(amount);

      if (numAmount <= 0) {
        return NextResponse.json({ status: 'error', message: 'Amount must be greater than £0' }, { status: 400 });
      }

      const targetReg = registriesStore.find((r) => r.id === registryId || r.code === registryId);
      if (!targetReg) {
        return NextResponse.json({ status: 'error', message: 'Registry not found' }, { status: 404 });
      }

      targetReg.currentAmount += numAmount;

      let itemTitle: string | undefined;
      if (giftItemId && targetReg.items) {
        const item = targetReg.items.find((i) => i.id === giftItemId);
        if (item) {
          item.claimedAmount = Math.min(item.price, item.claimedAmount + numAmount);
          itemTitle = item.title;
        }
      }

      const newContribution = {
        id: `c_${Date.now()}`,
        contributorName: contributorName || 'Kind Well-Wisher',
        amount: numAmount,
        message: message || 'Have a magnificent holiday in Britain!',
        timestamp: 'Just now',
        giftItemTitle: itemTitle
      };

      targetReg.contributions.unshift(newContribution);

      return NextResponse.json({
        status: 'success',
        message: 'Contribution successfully recorded! Thank you for giving the gift of travel.',
        registry: targetReg
      });
    }

    if (action === 'create') {
      const { title, recipientNames, occasion, destination, targetAmount, story, departureDate, items, organizerEmail } = body;

      if (!title || !recipientNames) {
        return NextResponse.json({ status: 'error', message: 'Title and recipients are required' }, { status: 400 });
      }

      const cleanedName = recipientNames.replace(/[^a-zA-Z]/g, '').substring(0, 4).toUpperCase();
      const code = `BCR-${cleanedName || 'GIFT'}${Math.floor(10 + Math.random() * 90)}`;

      const newRegistry: GiftRegistry = {
        id: `reg_${Date.now()}`,
        code,
        title,
        recipientNames,
        occasion: occasion || 'Celebration',
        destination: destination || 'Great British Holiday',
        targetAmount: Number(targetAmount) || 500,
        currentAmount: 0,
        departureDate: departureDate || '2027-06-01',
        story: story || 'Join us in celebrating by helping fund this unforgettable British rail & coach journey!',
        organizerEmail: organizerEmail || '',
        items: items || [
          { id: `item_${Date.now()}_1`, title: 'Scenic Rail Upgrade', category: 'travel', price: 90, claimedAmount: 0, iconName: 'Train' },
          { id: `item_${Date.now()}_2`, title: 'Harbourside Dinner & Drinks', category: 'dining', price: 75, claimedAmount: 0, iconName: 'UtensilsCrossed' },
          { id: `item_${Date.now()}_3`, title: 'Heritage Excursion Tickets', category: 'experience', price: 50, claimedAmount: 0, iconName: 'Compass' }
        ],
        contributions: []
      };

      registriesStore.unshift(newRegistry);

      return NextResponse.json({
        status: 'success',
        message: 'Holiday Gift Registry created successfully!',
        registry: newRegistry
      });
    }

    return NextResponse.json({ status: 'error', message: 'Unknown action' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ status: 'error', message: error.message || 'Server error' }, { status: 500 });
  }
}
