import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const departure = searchParams.get('departure');
  const destination = searchParams.get('destination') || 'Edinburgh';

  const targetDate = departure ? new Date(departure) : new Date(Date.now() + 14 * 24 * 3600 * 1000);
  const now = new Date();
  const diffMs = Math.max(0, targetDate.getTime() - now.getTime());

  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

  const weatherMap: Record<string, { temp: string; condition: string }> = {
    'Edinburgh': { temp: '14°C', condition: 'Crisp Scottish breeze, sunny intervals' },
    'Cornwall': { temp: '17°C', condition: 'Mild coastal sunshine & calm surf' },
    'Lake District': { temp: '15°C', condition: 'Clear views across Derwentwater' },
    'York': { temp: '16°C', condition: 'Dry and bright medieval city conditions' },
    'Snowdonia': { temp: '13°C', condition: 'Fresh mountain breeze, ideal for railway summit' },
    'Cotswolds': { temp: '18°C', condition: 'Pleasant spring warmth over stone cottages' },
  };

  const weather = weatherMap[destination] || { temp: '16°C', condition: 'Ideal touring conditions' };

  return NextResponse.json({
    status: 'success',
    timestamp: now.toISOString(),
    departureIso: targetDate.toISOString(),
    countdown: {
      days,
      hours,
      minutes,
      seconds,
      totalSecondsRemaining: Math.floor(diffMs / 1000),
      isDeparted: diffMs <= 0
    },
    weatherForecast: weather,
    packingChecklist: [
      { id: '1', item: 'Valid photo ID / Senior Railcard', category: 'Essential', checked: false },
      { id: '2', item: 'Comfortable walking boots for cobbles & trails', category: 'Clothing', checked: false },
      { id: '3', item: 'Light waterproof jacket & compact umbrella', category: 'Clothing', checked: false },
      { id: '4', item: 'Camera / smartphone power bank for scenic window photos', category: 'Electronics', checked: false },
      { id: '5', item: 'Reusable water bottle for coach excursions', category: 'General', checked: false }
    ]
  });
}
