import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      holidayId = 'general-tour',
      holidayTitle = 'Great British Holiday Package',
      departureTown = 'London Victoria',
      travelDate = '2027-05-10',
      passengers = { adults: 2, seniors: 0, children: 0 },
      basePrice = 109,
      contactName = 'Guest Traveller',
      email = 'guest@example.co.uk',
      phone = '07700 900077',
      specialRequests = ''
    } = body;

    const adults = Math.max(1, Number(passengers.adults) || 1);
    const seniors = Math.max(0, Number(passengers.seniors) || 0);
    const children = Math.max(0, Number(passengers.children) || 0);

    const priceNum = Number(basePrice) || 109;
    const adultTotal = adults * priceNum;
    const seniorTotal = seniors * (priceNum * 0.95);
    const childTotal = children * (priceNum * 0.75);
    const grandTotal = Math.round((adultTotal + seniorTotal + childTotal) * 100) / 100;

    const bookingRef = `BCR-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

    return NextResponse.json({
      status: 'success',
      bookingReference: bookingRef,
      message: 'Your holiday reservation has been provisionally confirmed and held with 100% ATOL financial protection!',
      details: {
        bookingReference: bookingRef,
        holidayTitle,
        holidayId,
        departureTown,
        travelDate,
        passengers: {
          adults,
          seniors,
          children,
          total: adults + seniors + children
        },
        financials: {
          basePricePerPerson: priceNum,
          totalAmount: grandTotal,
          depositRequired: 50.00,
          remainingBalance: Math.max(0, grandTotal - 50.00),
          atolBondNumber: 'ATOL #10842 / ABTA Y6291'
        },
        contact: {
          name: contactName,
          email,
          phone,
          specialRequests
        }
      }
    });
  } catch (error: any) {
    return NextResponse.json({ status: 'error', message: error.message || 'Booking failed' }, { status: 500 });
  }
}
