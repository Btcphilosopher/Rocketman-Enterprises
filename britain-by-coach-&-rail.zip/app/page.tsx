'use client';

import React, { useState, useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { TrustStrip } from '@/components/TrustStrip';
import { DestinationsGrid } from '@/components/DestinationsGrid';
import { GiftRegistrySection } from '@/components/GiftRegistrySection';
import { CountdownTimerSection } from '@/components/CountdownTimerSection';
import { ShowcaseTestimonials } from '@/components/ShowcaseTestimonials';
import { Footer } from '@/components/Footer';
import { BookingModal } from '@/components/BookingModal';
import { SearchModal } from '@/components/SearchModal';
import { WishlistDrawer } from '@/components/WishlistDrawer';
import { PhpBackendInspector } from '@/components/PhpBackendInspector';
import { HOLIDAY_PACKAGES, INITIAL_GIFT_REGISTRIES } from '@/data/mockData';
import { HolidayPackage, GiftRegistry } from '@/types/holiday';

export default function HomePage() {
  const [packages, setPackages] = useState<HolidayPackage[]>(HOLIDAY_PACKAGES);
  const [registries, setRegistries] = useState<GiftRegistry[]>(INITIAL_GIFT_REGISTRIES);
  const [wishlistIds, setWishlistIds] = useState<string[]>(['edinburgh-royal', 'lake-district-scenic']);

  // Modals & Drawers state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [isPhpInspectorOpen, setIsPhpInspectorOpen] = useState(false);
  
  const [selectedBookingPackage, setSelectedBookingPackage] = useState<HolidayPackage | null>(null);
  const [bookingTourTitle, setBookingTourTitle] = useState<string>('Great British Holiday');
  const [bookingTourPrice, setBookingTourPrice] = useState<number>(109);

  // Fetch registries from API on load
  useEffect(() => {
    fetch('/api/registry?action=list')
      .then((res) => res.json())
      .then((data) => {
        if (data.status === 'success' && data.data) {
          setRegistries(data.data);
        }
      })
      .catch((err) => console.log('Registry fetch error', err));
  }, []);

  const handleToggleWishlist = (pkg: HolidayPackage) => {
    setWishlistIds((prev) =>
      prev.includes(pkg.id) ? prev.filter((id) => id !== pkg.id) : [...prev, pkg.id]
    );
  };

  const handleRemoveWishlist = (id: string) => {
    setWishlistIds((prev) => prev.filter((item) => item !== id));
  };

  const handleOpenBookingForPackage = (pkg: HolidayPackage) => {
    setSelectedBookingPackage(pkg);
    setBookingTourTitle(pkg.title);
    setBookingTourPrice(pkg.basePrice);
    setIsBookingOpen(true);
  };

  const handleOpenBookingGeneric = (title?: string, price?: number) => {
    setSelectedBookingPackage(null);
    setBookingTourTitle(title || 'Great British Scenic Holiday Package');
    setBookingTourPrice(price || 109);
    setIsBookingOpen(true);
  };

  const handleHeroSearch = (params: {
    from: string;
    to: string;
    date: string;
    adults: number;
    seniors: number;
    children: number;
  }) => {
    // Filter packages matching destination if specified
    if (params.to && params.to !== 'All UK Destinations') {
      const match = HOLIDAY_PACKAGES.filter((p) =>
        p.destination.toLowerCase().includes(params.to.toLowerCase().split(' ')[0]) ||
        params.to.toLowerCase().includes(p.destination.toLowerCase())
      );
      if (match.length > 0) {
        setPackages(match);
      } else {
        setPackages(HOLIDAY_PACKAGES);
      }
    } else {
      setPackages(HOLIDAY_PACKAGES);
    }

    // Scroll to destinations
    const element = document.getElementById('destinations');
    element?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleContribute = async (
    registryId: string,
    payload: {
      contributorName: string;
      amount: number;
      message: string;
      giftItemId?: string;
    }
  ): Promise<boolean> => {
    try {
      const res = await fetch('/api/registry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'contribute', registryId, ...payload }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.registry) {
        setRegistries((prev) =>
          prev.map((r) => (r.id === registryId ? data.registry : r))
        );
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const handleCreateRegistry = async (payload: any): Promise<boolean> => {
    try {
      const res = await fetch('/api/registry', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'create', ...payload }),
      });
      const data = await res.json();
      if (data.status === 'success' && data.registry) {
        setRegistries((prev) => [data.registry, ...prev]);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const handleConfirmBooking = async (bookingData: any) => {
    try {
      const res = await fetch('/api/booking', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bookingData),
      });
      return await res.json();
    } catch {
      return { status: 'error', message: 'Connection failed' };
    }
  };

  const wishlistPackages = packages.filter((p) => wishlistIds.includes(p.id));

  return (
    <div className="min-h-screen flex flex-col bg-white text-slate-900 selection:bg-amber-100 selection:text-amber-900">
      {/* 1. Header / Top Navigation Bar */}
      <Navbar
        onOpenSearch={() => setIsSearchOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenBooking={() => handleOpenBookingGeneric()}
        onOpenPhpInspector={() => setIsPhpInspectorOpen(true)}
        wishlistCount={wishlistIds.length}
      />

      <main className="flex-1">
        {/* 2. Hero Section with Search Widget and Scenic Viaduct Backdrop */}
        <Hero
          onSearch={handleHeroSearch}
          onExploreDeals={() => {
            const el = document.getElementById('destinations');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* 3. Five Core Value Trust Propositions Strip */}
        <TrustStrip />

        {/* 4. Discover the Best of Britain - 5 Destination Cards */}
        <DestinationsGrid
          packages={packages}
          onSelectPackage={handleOpenBookingForPackage}
          onToggleWishlist={handleToggleWishlist}
          wishlistIds={wishlistIds}
        />

        {/* 5. Dynamic Travel & Holiday Gift Registry */}
        <GiftRegistrySection
          registries={registries}
          onContribute={handleContribute}
          onCreateRegistry={handleCreateRegistry}
        />

        {/* 6. Interactive Holiday Countdown Timer & Departure Board */}
        <CountdownTimerSection
          onBookTour={(tourTitle, price) => handleOpenBookingGeneric(tourTitle, price)}
        />

        {/* 7. Bottom Showcase with Coach/Rail Options and Customer Testimonial */}
        <div id="coach-holidays"></div>
        <div id="rail-holidays"></div>
        <ShowcaseTestimonials
          onExploreCoach={() => {
            const el = document.getElementById('destinations');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
          onExploreRail={() => {
            const el = document.getElementById('destinations');
            el?.scrollIntoView({ behavior: 'smooth' });
          }}
        />
      </main>

      {/* 8. Footer matching screenshot with credentials and social links */}
      <Footer />

      {/* Interactive Modals & Drawers */}
      <BookingModal
        isOpen={isBookingOpen}
        onClose={() => setIsBookingOpen(false)}
        selectedPackage={selectedBookingPackage}
        initialTourTitle={bookingTourTitle}
        initialPrice={bookingTourPrice}
        onConfirmBooking={handleConfirmBooking}
      />

      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        packages={HOLIDAY_PACKAGES}
        onSelectPackage={handleOpenBookingForPackage}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistPackages={wishlistPackages}
        onRemove={handleRemoveWishlist}
        onBook={handleOpenBookingForPackage}
      />

      <PhpBackendInspector
        isOpen={isPhpInspectorOpen}
        onClose={() => setIsPhpInspectorOpen(false)}
      />
    </div>
  );
}
