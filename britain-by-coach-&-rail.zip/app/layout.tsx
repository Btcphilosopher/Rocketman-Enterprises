import type { Metadata } from 'next';
import { Playfair_Display, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Britain by Coach & Rail | Great British Holidays for Less',
  description: 'Coach & rail holidays to stunning destinations across the UK. Affordable, comfortable, unforgettable with dynamic gift registry and live countdown timer.',
  openGraph: {
    title: 'Britain by Coach & Rail | Great British Holidays for Less',
    description: 'Scenic UK coach and rail tours to Edinburgh, Cornwall, Lake District, York, Snowdonia and more. Plan your trip with our interactive countdown and gift registry.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Britain by Coach & Rail | Great British Holidays for Less',
    description: 'Scenic UK coach and rail tours with interactive departure countdown and dynamic gift registry.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${playfair.variable} ${plusJakarta.variable}`}>
      <body className="font-sans antialiased text-slate-900 bg-white selection:bg-amber-100 selection:text-amber-900" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
