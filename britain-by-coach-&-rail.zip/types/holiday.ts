export interface HolidayPackage {
  id: string;
  title: string;
  destination: string;
  tagline: string;
  region: 'Scotland' | 'England' | 'Wales' | 'Cornwall' | 'Cotswolds';
  duration: string;
  travelMode: 'coach' | 'rail' | 'both';
  basePrice: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  highlights: string[];
  departurePoints: string[];
  nextDepartureDate: string;
  badge?: string;
}

export interface GiftItem {
  id: string;
  title: string;
  category: 'travel' | 'dining' | 'experience' | 'hotel' | 'upgrade';
  price: number;
  claimedAmount: number;
  iconName: string;
}

export interface Contribution {
  id: string;
  contributorName: string;
  amount: number;
  message: string;
  timestamp: string;
  giftItemTitle?: string;
}

export interface GiftRegistry {
  id: string;
  code: string;
  title: string;
  recipientNames: string;
  occasion: string;
  destination: string;
  targetAmount: number;
  currentAmount: number;
  departureDate: string;
  story: string;
  organizerEmail: string;
  items: GiftItem[];
  contributions: Contribution[];
}

export interface CountdownTour {
  id: string;
  title: string;
  destination: string;
  targetDate: string;
  duration: string;
  travelMode: 'coach' | 'rail' | 'both';
  discountText: string;
  originalPrice: number;
  offerPrice: number;
  seatsLeft: number;
  totalSeats: number;
  image: string;
  description: string;
}

export interface BookingInquiry {
  holidayId: string;
  holidayTitle: string;
  departureTown: string;
  travelDate: string;
  passengers: {
    adults: number;
    seniors: number;
    children: number;
  };
  totalPrice: number;
  contactName: string;
  email: string;
  phone: string;
  specialRequests?: string;
}
