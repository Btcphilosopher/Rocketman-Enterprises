import { HolidayPackage, GiftRegistry, CountdownTour } from '@/types/holiday';

export const HOLIDAY_PACKAGES: HolidayPackage[] = [
  {
    id: 'edinburgh-royal',
    title: 'Edinburgh Castle & Royal Mile Explorer',
    destination: 'Edinburgh',
    tagline: 'History, culture and stunning views',
    region: 'Scotland',
    duration: '4 Days / 3 Nights',
    travelMode: 'both',
    basePrice: 129,
    originalPrice: 169,
    rating: 4.9,
    reviewsCount: 1420,
    image: 'https://images.unsplash.com/photo-1506377585622-be77d028ec41?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Reserved express rail tickets across scenic East Coast Main Line',
      'Executive coach excursion to Firth of Forth & Rosslyn Chapel',
      'Fast-track admission to historic Edinburgh Castle',
      '3-star centrally located hotel with full Scottish breakfast'
    ],
    departurePoints: ['London Victoria', 'York', 'Newcastle', 'Leeds', 'Birmingham'],
    nextDepartureDate: '2027-04-12',
    badge: 'Popular'
  },
  {
    id: 'cornwall-coast',
    title: 'Cornish Riviera & Coastal Fishing Harbours',
    destination: 'Cornwall',
    tagline: 'Golden beaches and coastal towns',
    region: 'Cornwall',
    duration: '5 Days / 4 Nights',
    travelMode: 'coach',
    basePrice: 99,
    originalPrice: 139,
    rating: 4.8,
    reviewsCount: 2150,
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Executive touring coach with panoramic windows & USB charging',
      'Excursions to St Ives, Padstow harbour and Land’s End',
      'Traditional Cornish cream tea included at Falmouth Bay',
      'Comfortable coastal hotel with evening entertainment'
    ],
    departurePoints: ['London Victoria', 'Bristol', 'Birmingham', 'Southampton', 'Reading'],
    nextDepartureDate: '2027-04-18',
    badge: 'Best Value'
  },
  {
    id: 'lake-district-scenic',
    title: 'Lake District Scenery & Windermere Steamer',
    destination: 'Lake District',
    tagline: 'Breathtaking scenery and fresh air',
    region: 'England',
    duration: '4 Days / 3 Nights',
    travelMode: 'both',
    basePrice: 109,
    originalPrice: 149,
    rating: 4.95,
    reviewsCount: 1890,
    image: 'https://images.unsplash.com/photo-1584003564943-60f45353f018?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Scenic rail journey to Oxenholme Lake District station',
      'Private chartered coach tour through Grasmere & Keswick',
      'Cruise on historic Lake Windermere heritage steamer',
      'Lakeview hotel accommodation with 3-course table d’hôte dinners'
    ],
    departurePoints: ['Manchester', 'Birmingham', 'London Euston', 'Leeds', 'Liverpool'],
    nextDepartureDate: '2027-04-22',
    badge: 'Travellers’ Choice'
  },
  {
    id: 'york-medieval',
    title: 'Historic York & North York Moors Steam Railway',
    destination: 'York',
    tagline: 'Medieval charm and walled streets',
    region: 'England',
    duration: '3 Days / 2 Nights',
    travelMode: 'rail',
    basePrice: 119,
    originalPrice: 159,
    rating: 4.85,
    reviewsCount: 970,
    image: 'https://images.unsplash.com/photo-1582201942988-13e60e4556ee?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'High-speed LNER rail journey with reserved seating',
      'Heritage steam train ride on the North Yorkshire Moors Railway',
      'Guided walking tour of The Shambles & Roman city walls',
      '4-star historic hotel near York Minster'
    ],
    departurePoints: ['London King’s Cross', 'Edinburgh', 'Peterborough', 'Doncaster'],
    nextDepartureDate: '2027-04-26',
    badge: 'Heritage Classic'
  },
  {
    id: 'snowdonia-wales',
    title: 'Snowdonia Mountain Railway & Welsh Castles',
    destination: 'Snowdonia',
    tagline: 'Adventure and natural beauty',
    region: 'Wales',
    duration: '4 Days / 3 Nights',
    travelMode: 'coach',
    basePrice: 109,
    originalPrice: 145,
    rating: 4.9,
    reviewsCount: 1120,
    image: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Luxury coach transport with dedicated British tour driver',
      'Journey on the vintage Snowdon Mountain Railway to summit',
      'Visits to Conwy Castle, Portmeirion Italianate village & Betws-y-Coed',
      'Welsh country hotel with hearty breakfasts and dinners'
    ],
    departurePoints: ['Birmingham', 'Manchester', 'Liverpool', 'Cardiff', 'Bristol'],
    nextDepartureDate: '2027-05-02',
    badge: 'Scenic Gem'
  },
  {
    id: 'cotswolds-bath',
    title: 'Cotswolds Quintessential Villages & Historic Bath',
    destination: 'Cotswolds',
    tagline: 'Honey-stone cottages and Roman thermal spas',
    region: 'Cotswolds',
    duration: '3 Days / 2 Nights',
    travelMode: 'both',
    basePrice: 115,
    originalPrice: 155,
    rating: 4.88,
    reviewsCount: 860,
    image: 'https://images.unsplash.com/photo-1568849676085-51415703900f?auto=format&fit=crop&w=1200&q=80',
    highlights: [
      'Scenic coach drive through Bourton-on-the-Water & Castle Combe',
      'Great Western Railway scenic service to World Heritage City of Bath',
      'Admission to the ancient Roman Baths museum',
      'Boutique Georgian coaching inn stay'
    ],
    departurePoints: ['London Paddington', 'Reading', 'Oxford', 'Swindon'],
    nextDepartureDate: '2027-05-08',
    badge: 'Short Break'
  }
];

export const INITIAL_GIFT_REGISTRIES: GiftRegistry[] = [
  {
    id: 'reg-golden-anniv',
    code: 'BCR-GOLD50',
    title: 'Arthur & Margaret’s 50th Golden Wedding Anniversary',
    recipientNames: 'Arthur & Margaret Davies',
    occasion: 'Golden Wedding Anniversary (50 Years)',
    destination: 'Scottish Highlands & Jacobite Steam Train',
    targetAmount: 750,
    currentAmount: 620,
    departureDate: '2027-05-15',
    story: 'Mum & Dad have always dreamed of journeying over the Glenfinnan Viaduct on the Jacobite Steam Train just like the classic railway posters. Help us give them a once-in-a-lifetime anniversary break across Scotland!',
    organizerEmail: 'claire.davies@example.co.uk',
    items: [
      { id: 'item-1', title: 'Jacobite Steam Train First Class Tickets', category: 'travel', price: 120, claimedAmount: 120, iconName: 'Train' },
      { id: 'item-2', title: 'Highland Luxury Hotel Stay (3 Nights)', category: 'hotel', price: 300, claimedAmount: 250, iconName: 'Hotel' },
      { id: 'item-3', title: 'Celebratory Anniversary Dinner & Whisky Tasting', category: 'dining', price: 90, claimedAmount: 90, iconName: 'UtensilsCrossed' },
      { id: 'item-4', title: 'Fort William & Loch Ness Lake Cruise', category: 'experience', price: 80, claimedAmount: 60, iconName: 'Compass' },
      { id: 'item-5', title: 'First Class Window Upgrade with Champagne', category: 'upgrade', price: 60, claimedAmount: 40, iconName: 'Sparkles' }
    ],
    contributions: [
      { id: 'c1', contributorName: 'Claire & Simon', amount: 150, message: 'Happy 50th Golden Anniversary Mum and Dad! Looking forward to seeing the railway photos.', timestamp: '2 days ago', giftItemTitle: 'Highland Luxury Hotel Stay (3 Nights)' },
      { id: 'c2', contributorName: 'Uncle Richard & Auntie Joan', amount: 120, message: 'Congratulations on 50 golden years together! Enjoy the steam train, Margaret!', timestamp: '3 days ago', giftItemTitle: 'Jacobite Steam Train First Class Tickets' },
      { id: 'c3', contributorName: 'The Henderson Family', amount: 90, message: 'A wonderful couple deserving of the most wonderful journey. Raise a glass of single malt for us!', timestamp: '5 days ago', giftItemTitle: 'Celebratory Anniversary Dinner & Whisky Tasting' },
      { id: 'c4', contributorName: 'Grandchildren Chloe, Jack & Oliver', amount: 60, message: 'To the best Grandad and Granny ever! Hope you see the Loch Ness monster!', timestamp: '1 week ago', giftItemTitle: 'Fort William & Loch Ness Lake Cruise' }
    ]
  },
  {
    id: 'reg-cornish-honeymoon',
    code: 'BCR-HONEY27',
    title: 'Tom & Clara’s Coastal Honeymoon Break',
    recipientNames: 'Tom & Clara Jenkins',
    occasion: 'Wedding & Honeymoon',
    destination: 'Cornish Riviera, St Ives & Falmouth',
    targetAmount: 580,
    currentAmount: 460,
    departureDate: '2027-06-01',
    story: 'Instead of toasters and dinner plates, we’d love to explore the hidden coves, coastal paths and art galleries of Cornwall by scenic train and coach!',
    organizerEmail: 'tom.clara@example.co.uk',
    items: [
      { id: 'item-c1', title: 'Night Riviera Sleeper Cabin Upgrade', category: 'upgrade', price: 140, claimedAmount: 140, iconName: 'Moon' },
      { id: 'item-c2', title: 'Harbourside Seafood Supper in St Ives', category: 'dining', price: 95, claimedAmount: 95, iconName: 'UtensilsCrossed' },
      { id: 'item-c3', title: 'Tate St Ives & Barbara Hepworth Museum Tickets', category: 'experience', price: 45, claimedAmount: 45, iconName: 'Ticket' },
      { id: 'item-c4', title: 'Coastal Boutique Sea-View Hotel', category: 'hotel', price: 200, claimedAmount: 140, iconName: 'Hotel' },
      { id: 'item-c5', title: 'Traditional Cornish Cream Tea Hamper', category: 'dining', price: 40, claimedAmount: 40, iconName: 'Coffee' }
    ],
    contributions: [
      { id: 'c5', contributorName: 'The Miller Family', amount: 140, message: 'Wishing you both a lifetime of happiness starting on the Cornish coast!', timestamp: 'Yesterday', giftItemTitle: 'Night Riviera Sleeper Cabin Upgrade' },
      { id: 'c6', contributorName: 'Best Man Dave', amount: 95, message: 'Eat all the seafood and drink plenty of cider! Love you guys.', timestamp: '3 days ago', giftItemTitle: 'Harbourside Seafood Supper in St Ives' },
      { id: 'c7', contributorName: 'Auntie Brenda', amount: 85, message: 'Have the loveliest time relaxing by the sea after the big day.', timestamp: '4 days ago', giftItemTitle: 'Coastal Boutique Sea-View Hotel' }
    ]
  },
  {
    id: 'reg-retirement-lakes',
    code: 'BCR-RETIRE70',
    title: 'David’s Retirement Grand Tour of the Lakes',
    recipientNames: 'David Wilson',
    occasion: 'Retirement Celebration',
    destination: 'Lake District & Windermere',
    targetAmount: 480,
    currentAmount: 340,
    departureDate: '2027-05-20',
    story: 'After 38 years of dedicated service with the NHS, David is finally retiring! Let’s send him off to the tranquil waters of Windermere and the high fells of Grasmere.',
    organizerEmail: 'sarah.wilson@example.co.uk',
    items: [
      { id: 'item-d1', title: 'Windermere Steam Cruise VIP Deck', category: 'experience', price: 50, claimedAmount: 50, iconName: 'Ship' },
      { id: 'item-d2', title: '3 Nights Lakeside Country House Hotel', category: 'hotel', price: 240, claimedAmount: 180, iconName: 'Hotel' },
      { id: 'item-d3', title: 'Celebratory Country Pub Dinner at The Swan', category: 'dining', price: 70, claimedAmount: 60, iconName: 'UtensilsCrossed' },
      { id: 'item-d4', title: 'National Trust Lakes & Wordsworth Cottage Passes', category: 'experience', price: 50, claimedAmount: 50, iconName: 'Compass' }
    ],
    contributions: [
      { id: 'c8', contributorName: 'Colleagues at St Mary’s Hospital', amount: 180, message: 'Happy retirement David! You will be sorely missed on the ward. Enjoy every single breath of Lake District fresh air!', timestamp: '1 day ago' },
      { id: 'c9', contributorName: 'Robert & Fiona', amount: 90, message: 'No more alarm clocks, Dave! Have a pint by the lake for us.', timestamp: '4 days ago' }
    ]
  }
];

export const COUNTDOWN_TOURS: CountdownTour[] = [
  {
    id: 'tour-spring-cotswolds',
    title: 'Spring Blossom: Cotswolds & Roman Bath Explorer',
    destination: 'Cotswolds & Bath',
    targetDate: '2027-04-03T08:30:00',
    duration: '3 Days / 2 Nights',
    travelMode: 'coach',
    discountText: 'Save £40pp • Early Bird Offer',
    originalPrice: 155,
    offerPrice: 115,
    seatsLeft: 6,
    totalSeats: 48,
    image: 'https://images.unsplash.com/photo-1568849676085-51415703900f?auto=format&fit=crop&w=1200&q=80',
    description: 'Bask in wisteria and apple blossoms across Bourton-on-the-Water, Stow-on-the-Wold and honey-coloured Bath.'
  },
  {
    id: 'tour-easter-highlands',
    title: 'Easter Highland Express: Glenfinnan & Fort William',
    destination: 'Scottish Highlands',
    targetDate: '2027-04-16T07:15:00',
    duration: '5 Days / 4 Nights',
    travelMode: 'both',
    discountText: 'Save £50pp • Bank Holiday Special',
    originalPrice: 219,
    offerPrice: 169,
    seatsLeft: 4,
    totalSeats: 42,
    image: 'https://images.unsplash.com/photo-1506377585622-be77d028ec41?auto=format&fit=crop&w=1200&q=80',
    description: 'Cross the monumental Glenfinnan Viaduct by steam and marvel at snow-capped Ben Nevis peaks.'
  },
  {
    id: 'tour-cornwall-mayday',
    title: 'May Day Coastal Escape: St Ives & Cornish Coves',
    destination: 'Cornwall Coast',
    targetDate: '2027-05-01T09:00:00',
    duration: '4 Days / 3 Nights',
    travelMode: 'coach',
    discountText: 'Save £35pp • Best Value Guaranteed',
    originalPrice: 134,
    offerPrice: 99,
    seatsLeft: 9,
    totalSeats: 50,
    image: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1200&q=80',
    description: 'Warm spring sunshine, sparkling azure Atlantic waters, and harbour strolls with fresh pasties.'
  },
  {
    id: 'tour-lakes-summer',
    title: 'Lakes & Fells Summer Solstice Celebration',
    destination: 'Lake District',
    targetDate: '2027-06-20T08:00:00',
    duration: '4 Days / 3 Nights',
    travelMode: 'both',
    discountText: 'Save £30pp • Limited Departure',
    originalPrice: 149,
    offerPrice: 119,
    seatsLeft: 8,
    totalSeats: 46,
    image: 'https://images.unsplash.com/photo-1584003564943-60f45353f018?auto=format&fit=crop&w=1200&q=80',
    description: 'Sunset steamer cruise on Lake Ullswater and scenic railway traverse over Shap summit.'
  }
];

export const DEPARTURE_TOWNS = [
  'London Victoria',
  'Birmingham New Street',
  'Manchester Piccadilly',
  'Leeds City Centre',
  'Bristol Temple Meads',
  'Newcastle Central',
  'Liverpool Lime Street',
  'Sheffield Interchange',
  'Southampton Central',
  'Nottingham Station',
  'Cardiff Central',
  'Glasgow Queen Street'
];

export const DESTINATIONS_LIST = [
  'All UK Destinations',
  'Edinburgh & Scottish Highlands',
  'Cornwall & Coastal Riviera',
  'Lake District & Windermere',
  'Historic York & North York Moors',
  'Snowdonia & North Wales',
  'Cotswolds & Historic Bath',
  'Devon & English Riviera'
];
