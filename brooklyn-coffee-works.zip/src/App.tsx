import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  MapPin, 
  Clock, 
  Phone, 
  CalendarDays, 
  Award, 
  Mail, 
  Instagram, 
  ChevronRight, 
  ChevronLeft, 
  Star, 
  BookOpen, 
  Heart,
  Globe,
  Leaf,
  ChevronUp
} from 'lucide-react';

// Types & Data
import { MenuItem, Product, CaféLocation, CommunityEvent, JournalPost, CartItem } from './types';
import { 
  IMAGES, 
  MENU_ITEMS, 
  PRODUCTS, 
  EVENTS, 
  JOURNAL_POSTS, 
  TESTIMONIALS, 
  LOCATIONS 
} from './data';

// Modular Components
import Navbar from './components/Navbar';
import InteractiveMenu from './components/InteractiveMenu';
import EStore from './components/EStore';
import CartDrawer from './components/CartDrawer';
import Reservations from './components/Reservations';
import LoyaltyRewards from './components/LoyaltyRewards';
import LocationsMap from './components/LocationsMap';
import CareersCorner from './components/CareersCorner';
import JournalModal from './components/JournalModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('home');
  const [theme, setTheme] = useState<'cream' | 'industrial'>('industrial'); // Default to luxury moody industrial dark
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [reservationsOpen, setReservationsOpen] = useState(false);
  const [loyaltyOpen, setLoyaltyOpen] = useState(false);
  const [activeJournalPost, setActiveJournalPost] = useState<JournalPost | null>(null);

  // Reviews Slider state
  const [activeReviewIdx, setActiveReviewIdx] = useState(0);

  // Email Newsletter Signup state
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false);

  // Contact form state
  const [contactName, setContactName] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSubmitted, setContactSubmitted] = useState(false);

  // Scroll to Top state
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Cart operations
  const handleAddToCart = (itemToAdd: CartItem) => {
    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex(
        (item) => item.itemId === itemToAdd.itemId && item.selectedOption === itemToAdd.selectedOption
      );
      if (existingIdx > -1) {
        const updated = [...prevCart];
        updated[existingIdx].quantity += 1;
        return updated;
      }
      return [...prevCart, itemToAdd];
    });
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => {
          if (item.id === id) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Toast System for general actions
  const [generalToast, setGeneralToast] = useState<string | null>(null);
  const triggerGeneralToast = (msg: string) => {
    setGeneralToast(msg);
    setTimeout(() => {
      setGeneralToast(null);
    }, 4000);
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterSubmitted(true);
    triggerGeneralToast("Welcome to the BKW collective! 15% discount code sent.");
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactMessage) return;
    setContactSubmitted(true);
    triggerGeneralToast("Message logged successfully. A community host will reply shortly.");
  };

  return (
    <div
      id="app-container"
      className={`min-h-screen font-sans transition-colors duration-500 selection:bg-amber-800 selection:text-white ${
        theme === 'cream'
          ? 'bg-amber-50/40 text-stone-900'
          : 'bg-stone-950 text-amber-50'
      }`}
    >
      {/* Toast popup */}
      {generalToast && (
        <div className="fixed bottom-6 left-6 z-50 bg-stone-900 text-amber-50 border border-amber-800/60 px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in uppercase tracking-wider text-xs font-bold font-mono">
          <Sparkles className="h-4 w-4 text-amber-500 animate-spin" />
          {generalToast}
        </div>
      )}

      {/* Primary Sticky Header Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cart={cart}
        toggleCart={() => setCartOpen(!cartOpen)}
        theme={theme}
        setTheme={setTheme}
        openLoyalty={() => setLoyaltyOpen(true)}
        openReservations={() => setReservationsOpen(true)}
      />

      {/* -------------------- HOME PAGE LAYOUT -------------------- */}
      {activeTab === 'home' && (
        <>
          {/* CINEMATIC HERO SCREEN */}
          <header
            id="hero-banner"
            className="relative h-screen flex flex-col justify-center items-center text-center overflow-hidden"
          >
            {/* Immersive background image */}
            <div className="absolute inset-0">
              <img
                src={IMAGES.heroInterior}
                alt="Brooklyn Coffee Works Café Interior"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover scale-105 animate-fade-in"
                style={{ filter: 'brightness(0.35)' }}
              />
            </div>

            {/* Distressed vintage brand logo typography overlay */}
            <div className="relative z-10 px-4 max-w-5xl space-y-8 animate-fade-in">
              <div className="space-y-3">
                <span className="text-amber-500 font-bold tracking-widest uppercase text-xs sm:text-sm font-mono block">
                  EST. 2012 / WILLIAMSBURG • DUMBO • GREENPOINT • PARK SLOPE
                </span>
                
                {/* Bold distressed editorial main title */}
                <h1 
                  className="text-5xl sm:text-7xl md:text-8xl font-black uppercase tracking-tighter leading-none text-white drop-shadow-lg"
                  style={{ fontFamily: "'Playfair Display', serif, system-ui" }}
                >
                  BROOKLYN
                  <span className="block text-4xl sm:text-6xl md:text-7xl font-sans tracking-widest font-thin text-stone-200 mt-2">
                    COFFEE WORKS
                  </span>
                </h1>
              </div>

              {/* Brand statement */}
              <p className="max-w-xl mx-auto text-sm sm:text-base text-stone-300 font-medium leading-relaxed">
                Handcrafted micro-lots, roasted 24h prior on Wythe Avenue. Combining industrial grit, reclaimed rustic oak, and perfect microfoam lattes.
              </p>

              {/* Action buttons CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                <button
                  onClick={() => {
                    setActiveTab('menu');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-600 hover:bg-amber-500 text-stone-950 transition-all shadow-lg cursor-pointer hover:scale-105"
                >
                  Order Online
                </button>
                <button
                  onClick={() => setReservationsOpen(true)}
                  className="w-full sm:w-auto px-8 py-4 rounded-xl text-xs font-black tracking-widest uppercase bg-transparent hover:bg-white/10 text-white border-2 border-white/60 hover:border-white transition-all cursor-pointer hover:scale-105"
                >
                  Our Story
                </button>
              </div>
            </div>

            {/* Visual indicators footer card */}
            <div className="absolute bottom-12 z-10 flex gap-6 text-[10px] font-bold text-stone-400 uppercase tracking-widest bg-stone-950/60 backdrop-blur-xs px-6 py-3 rounded-full border border-stone-800">
              <span className="flex items-center gap-1.5"><Leaf className="h-3.5 w-3.5 text-emerald-500" /> Direct Trade</span>
              <span className="text-stone-700">|</span>
              <span className="flex items-center gap-1.5"><Globe className="h-3.5 w-3.5 text-sky-500" /> Organic</span>
              <span className="text-stone-700">|</span>
              <span className="flex items-center gap-1.5"><Award className="h-3.5 w-3.5 text-amber-500" /> SCA QC Certified</span>
            </div>
          </header>

          {/* DUAL-IMAGE BRAND STATEMENT SECTION */}
          {/* Directly inspired by the layout in the user's provided image! */}
          <section id="brand-statement-grid" className="py-20 border-b border-stone-800/10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-center">
                
                {/* Column 1: Locally Roasted details */}
                <div className="space-y-4 text-left">
                  <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Artisanal Craft</span>
                  <h3 className="text-xl font-black uppercase tracking-wider">LOCALLY ROASTED</h3>
                  <div className="h-[2px] w-12 bg-amber-600 rounded-full" />
                  <p className={`text-xs leading-relaxed ${theme === 'cream' ? 'text-stone-600' : 'text-stone-400'}`}>
                    We source the highest quality beans from family-run farms in Colombia, Ethiopia, and Honduras. Each batch is hand-sorted and micro-roasted right here in Brooklyn.
                  </p>
                  <button
                    onClick={() => setActiveTab('shop')}
                    className="text-xs font-black uppercase tracking-widest text-amber-600 hover:text-amber-500 flex items-center gap-1 cursor-pointer pt-2"
                  >
                    LEARN MORE <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                {/* Column 2: Matte cup image */}
                <div className="aspect-4/3 rounded-2xl overflow-hidden shadow-xl border border-stone-850">
                  <img
                    src={IMAGES.latteCloseup}
                    alt="Premium microfoam latte art closeup"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>

                {/* Column 3: Made by Hand details */}
                <div className="space-y-4 text-left">
                  <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Sourcing Ethics</span>
                  <h3 className="text-xl font-black uppercase tracking-wider">MADE BY HAND</h3>
                  <div className="h-[2px] w-12 bg-amber-600 rounded-full" />
                  <p className={`text-xs leading-relaxed ${theme === 'cream' ? 'text-stone-600' : 'text-stone-400'}`}>
                    Every cup is crafted with precision by baristas who care. From weighing the dose, tracking extraction times, to pulling beautiful microfoam, we make no compromises.
                  </p>
                  <button
                    onClick={() => setActiveTab('menu')}
                    className="text-xs font-black uppercase tracking-widest text-amber-600 hover:text-amber-500 flex items-center gap-1 cursor-pointer pt-2"
                  >
                    LEARN MORE <ChevronRight className="h-4 w-4" />
                  </button>
                </div>

                {/* Column 4: Coffee bags on wood counter */}
                <div className="aspect-4/3 rounded-2xl overflow-hidden shadow-xl border border-stone-850">
                  <img
                    src={IMAGES.coffeeBag}
                    alt="Artisanal craft coffee bag packaging"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>

              </div>
            </div>
          </section>

          {/* FOUR PILLARS UTILITY GRID BANNER */}
          {/* Inspired by the bottom dark row of the provided image! */}
          <section className="bg-stone-950 text-white py-12 border-b border-stone-800">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                
                <div className="flex flex-col items-center text-center space-y-3 p-4">
                  <div className="p-3 bg-stone-900 rounded-xl text-amber-600">
                    <Award className="h-6 w-6" />
                  </div>
                  <h4 className="text-xs font-black tracking-widest uppercase">COMMUNITY FOCUSED</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed max-w-[210px]">
                    More than just coffee. We design cozy gathering spaces for creative minds.
                  </p>
                </div>

                <div className="flex flex-col items-center text-center space-y-3 p-4">
                  <div className="p-3 bg-stone-900 rounded-xl text-amber-600">
                    <Leaf className="h-6 w-6" />
                  </div>
                  <h4 className="text-xs font-black tracking-widest uppercase">SUSTAINABLY SOURCED</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed max-w-[210px]">
                    100% direct-trade relationships, compostable packaging, and organic practices.
                  </p>
                </div>

                <div className="flex flex-col items-center text-center space-y-3 p-4">
                  <div className="p-3 bg-stone-900 rounded-xl text-amber-600">
                    <Sparkles className="h-6 w-6" />
                  </div>
                  <h4 className="text-xs font-black tracking-widest uppercase">BROOKLYN PROUD</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed max-w-[210px]">
                    Roasted, brewed, and curated with authentic Brooklyn passion.
                  </p>
                </div>

                <div className="flex flex-col items-center text-center space-y-3 p-4">
                  <div className="p-3 bg-stone-900 rounded-xl text-amber-600">
                    <Heart className="h-6 w-6" />
                  </div>
                  <h4 className="text-xs font-black tracking-widest uppercase">GOOD COFFEE GOOD VIBES</h4>
                  <p className="text-[11px] text-stone-400 leading-relaxed max-w-[210px]">
                    Come for the coffee, stay for the welcoming neighbors and vibes.
                  </p>
                </div>

              </div>
            </div>
          </section>

          {/* INTERACTIVE MENU TEASER FEATURED DRINKS */}
          <section id="featured-menu" className="py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <div className="max-w-xl mx-auto space-y-2 mb-12">
                <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Flavors of Wythe Ave</span>
                <h3 className="text-3xl font-black uppercase tracking-wider">Featured Menu Selection</h3>
                <p className="text-xs text-stone-400 leading-relaxed">
                  Indulge in our award-winning, carefully extracted double ristrettos and seasonal infusions.
                </p>
              </div>

              {/* Display top 4 menu items */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
                {MENU_ITEMS.slice(0, 4).map((item) => (
                  <div
                    key={item.id}
                    className={`flex gap-4 p-4 rounded-2xl border text-left items-start ${
                      theme === 'cream' ? 'bg-white border-stone-200/60' : 'bg-stone-900/30 border-stone-850'
                    }`}
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      referrerPolicy="no-referrer"
                      className="w-20 h-20 rounded-xl object-cover"
                    />
                    <div className="flex-grow space-y-1">
                      <div className="flex justify-between items-start">
                        <h4 className="text-sm font-black uppercase tracking-wider">{item.name}</h4>
                        <span className="text-xs font-black text-amber-600 font-mono">${item.price.toFixed(2)}</span>
                      </div>
                      <p className="text-[11px] text-stone-400 leading-relaxed line-clamp-2">{item.description}</p>
                      <div className="flex gap-1 pt-1">
                        {item.tags.map((t, idx) => (
                          <span key={idx} className="text-[8px] font-bold uppercase text-stone-500 bg-stone-900 px-2 py-0.5 rounded-full">
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-10">
                <button
                  onClick={() => {
                    setActiveTab('menu');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-8 py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-950 text-amber-50 hover:bg-amber-900 border border-amber-800/30 cursor-pointer"
                >
                  View Full Menu
                </button>
              </div>
            </div>
          </section>

          {/* LOYALTY PORTAL INVITATION CARD */}
          <section className="py-12 border-t border-b border-stone-800/10">
            <div className="max-w-5xl mx-auto px-4 sm:px-6">
              <div className="bg-gradient-to-r from-amber-950 to-stone-950 rounded-3xl p-8 sm:p-10 border border-amber-900/40 text-left flex flex-col md:flex-row md:items-center justify-between gap-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 h-40 w-40 bg-amber-600/5 rounded-full -mr-12 -mt-12 blur-2xl" />
                
                <div className="space-y-3 max-w-lg z-10">
                  <div className="flex items-center gap-1.5 text-amber-500">
                    <Award className="h-5 w-5 animate-bounce" />
                    <span className="text-[10px] font-black tracking-widest uppercase">BKW LOYALTY NETWORK</span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-white">
                    Earn Free Specialty Cups & Beans
                  </h3>
                  <p className="text-xs text-stone-300 leading-relaxed">
                    Join over 4,000 local creative minds. Get 10 points for every dollar spent on draft cold brews, subscriptions, or work aprons. Swap points for concrete mugs and roasts.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 z-10">
                  <button
                    onClick={() => setLoyaltyOpen(true)}
                    className="px-6 py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-600 hover:bg-amber-500 text-stone-950 transition-all cursor-pointer text-center"
                  >
                    Lookup Points Balance
                  </button>
                  <button
                    onClick={() => setLoyaltyOpen(true)}
                    className="px-6 py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-900 hover:bg-stone-850 text-amber-50 border border-stone-800 cursor-pointer text-center"
                  >
                    Join Club (Get 50 pts)
                  </button>
                </div>
              </div>
            </div>
          </section>

          {/* SUSTAINABILITY SECTION */}
          <section id="sustainability" className="py-20 bg-stone-950/20">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              
              {/* Graphic stats counters */}
              <div className="grid grid-cols-2 gap-5 text-center">
                <div className="p-6 bg-stone-900/40 border border-stone-850 rounded-2xl space-y-1">
                  <span className="text-3xl font-black font-mono text-amber-600">100%</span>
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Direct Trade Beans</p>
                </div>
                <div className="p-6 bg-stone-900/40 border border-stone-850 rounded-2xl space-y-1">
                  <span className="text-3xl font-black font-mono text-amber-600">Zero</span>
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Single-Use Plastics</p>
                </div>
                <div className="p-6 bg-stone-900/40 border border-stone-850 rounded-2xl space-y-1">
                  <span className="text-3xl font-black font-mono text-amber-600">4,200</span>
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Pounds Composted</p>
                </div>
                <div className="p-6 bg-stone-900/40 border border-stone-850 rounded-2xl space-y-1">
                  <span className="text-3xl font-black font-mono text-amber-600">Solar</span>
                  <p className="text-[10px] font-bold text-stone-500 uppercase tracking-widest">Power Co-op Partner</p>
                </div>
              </div>

              {/* Text content */}
              <div className="space-y-4 text-left">
                <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Our Commitment</span>
                <h3 className="text-2xl font-black uppercase tracking-wider">ROASTING FOR THE PLANET</h3>
                <div className="h-[2px] w-12 bg-amber-600 rounded-full" />
                <p className="text-xs text-stone-400 leading-relaxed">
                  We believe specialty coffee shouldn’t compromise our ecological future. Our Loring S35 Kestrel roaster utilizes specialized hot-air recirculation tech, reducing carbon emissions by up to 80% compared to traditional drum roasters.
                </p>
                <p className="text-xs text-stone-400 leading-relaxed">
                  Every kraft paper coffee bag we stamp is entirely biodegradable. We partner with local urban farming collectives to ensure all spent espresso grounds are recycled into healthy, organic soils in Brooklyn.
                </p>
                <div className="flex items-center gap-3 pt-2">
                  <Leaf className="h-5 w-5 text-emerald-500" />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-stone-400">Committed to Net-Zero waste by 2030</span>
                </div>
              </div>

            </div>
          </section>

          {/* CUSTOMER REVIEWS & TESTIMONIALS SLIDER */}
          <section id="customer-reviews" className="py-20 border-t border-stone-800/10">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-8 relative">
              <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Locals Endorsements</span>
              <h3 className="text-2xl font-black uppercase tracking-wider">Word on the Street</h3>

              {/* Slider Panel */}
              <div className="min-h-[160px] flex flex-col justify-center items-center">
                <p className="text-sm sm:text-base italic leading-relaxed max-w-2xl text-stone-300 font-medium">
                  "{TESTIMONIALS[activeReviewIdx].text}"
                </p>

                <div className="mt-6 flex items-center justify-center gap-3">
                  <img
                    src={TESTIMONIALS[activeReviewIdx].avatarUrl}
                    alt={TESTIMONIALS[activeReviewIdx].name}
                    referrerPolicy="no-referrer"
                    className="h-10 w-10 rounded-full object-cover border border-amber-600/30"
                  />
                  <div className="text-left">
                    <h5 className="text-xs font-black uppercase tracking-wider text-white">
                      {TESTIMONIALS[activeReviewIdx].name}
                    </h5>
                    <p className="text-[9px] text-stone-500 uppercase tracking-widest">
                      {TESTIMONIALS[activeReviewIdx].role}
                    </p>
                  </div>
                </div>

                <div className="flex text-amber-500 justify-center mt-3 gap-0.5">
                  {Array.from({ length: TESTIMONIALS[activeReviewIdx].rating }).map((_, i) => (
                    <Star key={i} className="h-3 w-3 fill-amber-500" />
                  ))}
                </div>
              </div>

              {/* Slider Controls */}
              <div className="flex justify-center gap-3 pt-4">
                <button
                  onClick={() =>
                    setActiveReviewIdx((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1))
                  }
                  className="p-2 border border-stone-800 rounded-lg hover:bg-stone-900 text-stone-400 hover:text-white cursor-pointer"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <button
                  onClick={() =>
                    setActiveReviewIdx((prev) => (prev === TESTIMONIALS.length - 1 ? 0 : prev + 1))
                  }
                  className="p-2 border border-stone-800 rounded-lg hover:bg-stone-900 text-stone-400 hover:text-white cursor-pointer"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          </section>

          {/* COMMUNITY EVENTS TEASER CALENDAR */}
          <section id="upcoming-events" className="py-20 bg-stone-950/40 border-t border-stone-800/15">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-xl mx-auto space-y-2 mb-12">
                <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Neighborhood Gatherings</span>
                <h3 className="text-3xl font-black uppercase tracking-wider">Events & Masterclasses</h3>
                <p className="text-xs text-stone-400 leading-relaxed">
                  Join our weekly cupping logs, latte art texturing masterclasses, or live music gatherings.
                </p>
              </div>

              {/* Grid cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {EVENTS.map((ev) => (
                  <div
                    key={ev.id}
                    className={`rounded-2xl border overflow-hidden flex flex-col justify-between transition-all ${
                      theme === 'cream' ? 'bg-white border-stone-200' : 'bg-stone-900/30 border-stone-850'
                    }`}
                  >
                    <div>
                      <div className="relative h-44">
                        <img
                          src={ev.imageUrl}
                          alt={ev.title}
                          referrerPolicy="no-referrer"
                          className="w-full h-full object-cover"
                        />
                        <span className="absolute bottom-3 left-3 bg-stone-950 text-amber-600 border border-stone-800 font-bold tracking-widest text-[9px] uppercase px-2.5 py-1 rounded-full">
                          {ev.locationName}
                        </span>
                      </div>

                      <div className="p-5 space-y-2 text-left">
                        <div className="flex items-center justify-between text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                          <span className="flex items-center gap-1"><Clock className="h-3.5 w-3.5 text-amber-600" /> {ev.time}</span>
                          <span>{ev.date}</span>
                        </div>

                        <h4 className="text-sm font-black uppercase tracking-wider leading-snug">
                          {ev.title}
                        </h4>
                        <p className="text-xs text-stone-400 leading-relaxed">{ev.description}</p>
                      </div>
                    </div>

                    <div className="p-5 pt-0 flex items-center justify-between border-t border-dashed border-stone-800/10 mt-4">
                      <div>
                        <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block">ADMISSION</span>
                        <span className="text-xs font-bold font-mono text-amber-600">${ev.price.toFixed(2)}</span>
                      </div>
                      <button
                        onClick={() => setReservationsOpen(true)}
                        className="px-4 py-2 bg-stone-950 hover:bg-amber-900 text-amber-50 rounded-xl text-[10px] font-bold uppercase tracking-widest border border-amber-800/20 cursor-pointer"
                      >
                        Register
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* INSTAGRAM SOCIAL GALLERY */}
          <section id="instagram-gallery" className="py-20 border-t border-stone-850">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center space-y-8">
              <div className="space-y-1.5">
                <Instagram className="h-6 w-6 text-amber-600 mx-auto" />
                <span className="text-[10px] tracking-widest font-black uppercase text-stone-500 block">Sights from the counter</span>
                <h3 className="text-2xl font-black uppercase tracking-wider">#BROOKLYNCOFFEEWORKS</h3>
              </div>

              {/* Instagram styled photo grids */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                {[
                  'https://images.unsplash.com/photo-1577968897966-3d4325b36b61?auto=format&fit=crop&q=80&w=300',
                  'https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&q=80&w=300',
                  'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=300',
                  'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&q=80&w=300',
                  'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=300',
                  'https://images.unsplash.com/photo-1541532713592-79a0317b6b77?auto=format&fit=crop&q=80&w=300'
                ].map((url, i) => (
                  <div key={i} className="aspect-square rounded-xl overflow-hidden relative group border border-stone-850">
                    <img src={url} alt="Instagram scene" referrerPolicy="no-referrer" className="w-full h-full object-cover group-hover:scale-105 transition-all duration-300" />
                    <div className="absolute inset-0 bg-stone-950/60 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center">
                      <Heart className="h-5 w-5 text-amber-500 fill-amber-500" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* RECENT JOURNAL ARTICLES TEASER */}
          <section id="journal-teaser" className="py-20 bg-stone-950/10 border-t border-stone-800/15">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center max-w-xl mx-auto space-y-2 mb-12">
                <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Immersive Chronicles</span>
                <h3 className="text-3xl font-black uppercase tracking-wider">The Journal</h3>
                <p className="text-xs text-stone-400 leading-relaxed">
                  Dig into raw notes from coffee farms, extraction chemistry guides, and neighborhood design stories.
                </p>
              </div>

              {/* Grid logs */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {JOURNAL_POSTS.map((post) => (
                  <div
                    key={post.id}
                    onClick={() => setActiveJournalPost(post)}
                    className={`rounded-2xl border overflow-hidden p-5 text-left flex flex-col justify-between h-[360px] cursor-pointer group transition-all duration-300 ${
                      theme === 'cream' ? 'bg-white border-stone-200 hover:shadow-lg' : 'bg-stone-900/15 border-stone-850 hover:shadow-xl'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between text-[9px] font-bold text-stone-500 uppercase tracking-widest mb-3">
                        <span>{post.category}</span>
                        <span>{post.readTime}</span>
                      </div>

                      <h4 className="text-sm font-black uppercase tracking-wider leading-snug group-hover:text-amber-600 transition-colors">
                        {post.title}
                      </h4>
                      <p className="text-xs text-stone-400 leading-relaxed mt-2.5 line-clamp-3">{post.excerpt}</p>
                    </div>

                    <div className="flex items-center gap-2 pt-4 border-t border-dashed border-stone-800/10 mt-4 text-[10px] font-bold uppercase tracking-widest text-stone-400 group-hover:text-amber-600 transition-colors">
                      <BookOpen className="h-4 w-4 text-amber-600" />
                      <span>Read Narrative</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* NEWSLETTER SIGNUP BANNER */}
          <section id="newsletter-signup" className="py-16 bg-stone-950 border-t border-stone-850 text-white">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-6">
              <div className="space-y-1.5">
                <Mail className="h-6 w-6 text-amber-600 mx-auto" />
                <span className="text-[10px] tracking-widest font-black uppercase text-amber-600">Specialty Dispatch</span>
                <h3 className="text-xl sm:text-2xl font-black uppercase tracking-wider">Get micro-lot alerts & brewing guides</h3>
              </div>

              <p className="text-xs text-stone-400 max-w-sm mx-auto leading-relaxed">
                Receive our curated Monday Dispatch detailing new bean sourcing arrivals, seasonal coffee specials, and early masterclass registration slots.
              </p>

              {!newsletterSubmitted ? (
                <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto flex gap-2">
                  <input
                    type="email"
                    required
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="flex-grow px-4 py-3 rounded-xl text-xs bg-stone-900 border border-stone-800 text-amber-50 focus:outline-hidden focus:border-amber-600 font-semibold"
                  />
                  <button
                    type="submit"
                    className="px-6 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-600 hover:bg-amber-500 text-stone-950 cursor-pointer"
                  >
                    Subscribe
                  </button>
                </form>
              ) : (
                <div className="p-4 bg-stone-900 border border-stone-800 rounded-2xl max-w-md mx-auto space-y-1">
                  <p className="text-xs font-bold text-emerald-500 uppercase">Welcome to the BKW Collective!</p>
                  <p className="text-[10px] text-stone-400">
                    Use discount code <strong className="text-white font-mono uppercase bg-stone-850 px-2 py-0.5 rounded border border-stone-800">BKW15WELCOME</strong> at checkout for 15% off your first whole bean order.
                  </p>
                </div>
              )}
            </div>
          </section>
        </>
      )}

      {/* -------------------- BOUTIQUE MENU TAB PAGE -------------------- */}
      {activeTab === 'menu' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <div className="max-w-xl mx-auto space-y-2 mb-12">
            <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Fresh from the Counter</span>
            <h2 className="text-3xl font-black uppercase tracking-wider">Boutique Café Menu</h2>
            <p className="text-xs text-stone-400 leading-relaxed">
              Every bean is tracked, every shot is weighed, and every bun is baked hot daily by our artisanal neighborhood baker partners. Select an item to configure.
            </p>
          </div>

          <InteractiveMenu theme={theme} addToCart={handleAddToCart} />
        </main>
      )}

      {/* -------------------- LOCATIONS & CONTACT MAPS TAB PAGE -------------------- */}
      {activeTab === 'locations' && (
        <main className="py-16 text-center">
          <div className="max-w-xl mx-auto space-y-2 mb-12 px-4 sm:px-6">
            <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Urban Sanctuary Directories</span>
            <h2 className="text-3xl font-black uppercase tracking-wider">Our Café Grid</h2>
            <p className="text-xs text-stone-400 leading-relaxed">
              Find our welcoming specialty hubs in Williamsburg, Greenpoint, DUMBO, and Park Slope. Click an active coordinate on our vector map to inspect schedules.
            </p>
          </div>

          {/* Interactive map coordinates */}
          <LocationsMap theme={theme} />

          {/* Contact form block underneath map */}
          <section id="contact-form-block" className="max-w-xl mx-auto px-4 sm:px-6 pt-20 text-left">
            <div className="space-y-4 rounded-3xl border border-stone-800/10 p-6 bg-stone-900/5">
              <span className="text-[9px] font-black tracking-widest text-amber-600 uppercase">COMMUNITY DIALOGUE</span>
              <h3 className="text-lg font-black uppercase">Send Comments or Feedback</h3>
              
              {!contactSubmitted ? (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Your Name</label>
                      <input
                        type="text"
                        required
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        placeholder="Sarah J."
                        className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 focus:outline-hidden focus:border-amber-600 font-semibold"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Topic</label>
                      <select className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 focus:outline-hidden focus:border-amber-600 font-semibold">
                        <option>General Comment</option>
                        <option>Event Question</option>
                        <option>Direct Sourcing Inquiry</option>
                        <option>Merchandise Support</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Message</label>
                    <textarea
                      required
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="Share your thoughts about your recent cortado or event session..."
                      rows={3}
                      className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 focus:outline-hidden focus:border-amber-600 font-semibold"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-950 text-amber-50 hover:bg-amber-900 border border-amber-800/20 cursor-pointer"
                  >
                    Send Feedback
                  </button>
                </form>
              ) : (
                <div className="p-4 bg-stone-900 text-stone-300 rounded-xl space-y-1">
                  <p className="text-xs font-bold text-emerald-500 uppercase">Feedback Received!</p>
                  <p className="text-[10px] text-stone-400">
                    Thanks for sharing your thoughts with Julian and Elena. We appreciate you supporting local coffee.
                  </p>
                </div>
              )}
            </div>
          </section>
        </main>
      )}

      {/* -------------------- EVENTS CALENDAR TAB PAGE -------------------- */}
      {activeTab === 'events' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <div className="max-w-xl mx-auto space-y-2 mb-12">
            <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Creative Hub Schedulers</span>
            <h2 className="text-3xl font-black uppercase tracking-wider">Events & Masterclasses</h2>
            <p className="text-xs text-stone-400 leading-relaxed">
              We host industry-standard SCA sensory coffee cuppings, hands-on latte art coaching behind our La Marzocco stations, and live acoustic songwriter nights. Reserve a ticket instantly.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {EVENTS.map((ev) => (
              <div
                key={ev.id}
                className={`rounded-3xl border overflow-hidden p-6 text-left flex flex-col justify-between transition-all ${
                  theme === 'cream' ? 'bg-white border-stone-200' : 'bg-stone-900/15 border-stone-850'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[9px] font-bold text-stone-400 uppercase tracking-widest mb-4">
                    <span>{ev.date}</span>
                    <span>{ev.locationName}</span>
                  </div>

                  <h3 className="text-base font-black uppercase tracking-wider mb-2">{ev.title}</h3>
                  <p className="text-xs text-stone-400 leading-relaxed mb-4">{ev.description}</p>
                </div>

                <div className="pt-4 border-t border-dashed border-stone-800/10 flex items-center justify-between mt-4">
                  <div>
                    <span className="text-[8px] font-bold text-stone-500 uppercase tracking-widest block">PASS COST</span>
                    <span className="text-xs font-black font-mono text-amber-600">${ev.price.toFixed(2)}</span>
                  </div>
                  <button
                    onClick={() => setReservationsOpen(true)}
                    className="px-4 py-2 bg-stone-950 hover:bg-amber-900 text-amber-50 rounded-xl text-[10px] font-bold uppercase tracking-widest border border-amber-800/20 cursor-pointer animate-fade-in"
                  >
                    Get Seat ticket
                  </button>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* -------------------- JOURNAL STORIES TAB PAGE -------------------- */}
      {activeTab === 'journal' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <div className="max-w-xl mx-auto space-y-2 mb-12">
            <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Micro-lot Chronicles</span>
            <h2 className="text-3xl font-black uppercase tracking-wider">The BKW Journal</h2>
            <p className="text-xs text-stone-400 leading-relaxed">
              An editorial record mapping global farm journeys, botanical science logs, and coffee brewing chemistry recipes. Click an article to expand the view.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {JOURNAL_POSTS.map((post) => (
              <div
                key={post.id}
                onClick={() => setActiveJournalPost(post)}
                className={`rounded-2xl border overflow-hidden p-6 text-left flex flex-col justify-between h-[340px] cursor-pointer group transition-all duration-300 ${
                  theme === 'cream' ? 'bg-white border-stone-200 hover:shadow-lg' : 'bg-stone-900/15 border-stone-850 hover:shadow-xl'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between text-[9px] font-bold text-stone-500 uppercase tracking-widest mb-4">
                    <span>{post.category}</span>
                    <span>{post.readTime}</span>
                  </div>

                  <h3 className="text-sm font-black uppercase tracking-wider group-hover:text-amber-600 transition-colors">
                    {post.title}
                  </h3>
                  <p className="text-xs text-stone-400 leading-relaxed mt-2 line-clamp-3">{post.excerpt}</p>
                </div>

                <div className="flex items-center gap-2 pt-4 border-t border-dashed border-stone-800/10 mt-4 text-[9px] font-bold uppercase tracking-widest text-stone-400 group-hover:text-amber-600 transition-colors">
                  <BookOpen className="h-4 w-4 text-amber-600" />
                  <span>Expand Article</span>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* -------------------- MERCHANDISE E-STORE TAB PAGE -------------------- */}
      {activeTab === 'shop' && (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
          <div className="max-w-xl mx-auto space-y-2 mb-12">
            <span className="text-[10px] tracking-widest font-black text-amber-600 uppercase">Specialty Gear & Beans</span>
            <h2 className="text-3xl font-black uppercase tracking-wider">BKW E-Store Marketplace</h2>
            <p className="text-xs text-stone-400 leading-relaxed">
              Order roasted whole beans, monthly micro-lot subscriptions, precision pour-over drippers, and concrete-sand stoneware mugs. Shipped nationwide, freshly stamped.
            </p>
          </div>

          <EStore theme={theme} addToCart={handleAddToCart} />
        </main>
      )}

      {/* -------------------- CAREERS CORNER TAB PAGE -------------------- */}
      {activeTab === 'careers' && (
        <main className="py-16 text-center">
          <CareersCorner theme={theme} />
        </main>
      )}

      {/* -------------------- PRIMARY FOOTER DIRECTORY -------------------- */}
      <footer
        id="app-footer"
        className={`border-t py-16 transition-colors duration-500 ${
          theme === 'cream'
            ? 'bg-stone-900 text-stone-300 border-stone-850'
            : 'bg-stone-950 text-stone-400 border-stone-900'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 text-left">
          
          {/* Brand info */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <span
                className="font-mono tracking-widest text-lg font-black uppercase text-amber-50"
                style={{ fontFamily: "'Playfair Display', serif, system-ui" }}
              >
                BROOKLYN
              </span>
              <span className="text-[10px] tracking-widest font-bold uppercase text-amber-600">
                COFFEE WORKS
              </span>
            </div>
            <p className="text-xs text-stone-400 leading-relaxed">
              Specialty micro-batch roasting combined with authentic industrial coffee culture. Dedicated to sustainable sourcing, community spaces, and dialing-in lattes to perfection.
            </p>
            <div className="flex gap-3 pt-2 text-stone-400">
              {['Twitter', 'Instagram', 'Facebook', 'Spotify'].map((social) => (
                <button
                  key={social}
                  onClick={() => alert(`Redirecting to Brooklyn Coffee Works official ${social} account!`)}
                  className="p-2 bg-stone-900 rounded-lg hover:bg-stone-800 hover:text-white text-xs font-bold uppercase tracking-wider cursor-pointer"
                >
                  {social}
                </button>
              ))}
            </div>
          </div>

          {/* Quick directories */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-widest text-amber-50">Neighborhood Grids</h4>
            <div className="space-y-3 text-xs text-stone-400">
              <div>
                <strong className="text-stone-300 uppercase tracking-wider text-[10px] block">Williamsburg (Flagship)</strong>
                <span>142 Wythe Ave, Brooklyn, NY • (718) 555-0190</span>
              </div>
              <div>
                <strong className="text-stone-300 uppercase tracking-wider text-[10px] block">DUMBO (Waterfront)</strong>
                <span>55 Water St, Brooklyn, NY • (718) 555-0245</span>
              </div>
              <div>
                <strong className="text-stone-300 uppercase tracking-wider text-[10px] block">Greenpoint (Lab Counter)</strong>
                <span>98 Franklin St, Brooklyn, NY • (718) 555-0312</span>
              </div>
            </div>
          </div>

          {/* Site links */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-widest text-amber-50">Sitemap navigation</h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {[
                { id: 'home', l: 'Home Hub' },
                { id: 'menu', l: 'Cafe Menu' },
                { id: 'locations', l: 'Our Grids' },
                { id: 'events', l: 'Sensory Events' },
                { id: 'journal', l: 'BKW Journal' },
                { id: 'shop', l: 'Specialty Shop' },
                { id: 'careers', l: 'Careers Board' }
              ].map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    setActiveTab(link.id);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="text-left hover:text-amber-50 text-stone-400 transition-colors uppercase tracking-wider text-[10px] font-bold"
                >
                  ✓ {link.l}
                </button>
              ))}
            </div>
          </div>

          {/* Certifications and legal specs */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-widest text-amber-50">Roaster Credentials</h4>
            <div className="space-y-2 text-xs text-stone-400">
              <div className="flex items-center gap-2">
                <Leaf className="h-4 w-4 text-emerald-500 flex-shrink-0" />
                <span>100% compostable paper kraft packaging</span>
              </div>
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 text-sky-500 flex-shrink-0" />
                <span>Zero plastic waste in cafe channels</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="h-4 w-4 text-amber-600 flex-shrink-0" />
                <span>SCA Quality Control Certified roasts</span>
              </div>
            </div>
            <p className="text-[10px] text-stone-500 pt-2 border-t border-stone-850">
              All recipes scaled using precise volumetric metric extraction measurements. She Wolf and L'Appartement bakery counter partners.
            </p>
          </div>

        </div>

        {/* Outer credit line */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 mt-12 border-t border-stone-850 text-left flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] text-stone-500 font-bold uppercase tracking-wider">
          <p>© 2026 BROOKLYN COFFEE WORKS LLC. ALL RIGHTS RESERVED.</p>
          <p>Williamsburg • DUMBO • Greenpoint • Park Slope • NYC</p>
        </div>
      </footer>

      {/* -------------------- FLOATING OVERLAYS MODALS DRAWER COMPONENTS -------------------- */}

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cart={cart}
        updateQuantity={handleUpdateCartQuantity}
        removeItem={handleRemoveCartItem}
        clearCart={handleClearCart}
        theme={theme}
      />

      {/* Reservations Modal */}
      {reservationsOpen && (
        <Reservations
          theme={theme}
          onClose={() => setReservationsOpen(false)}
        />
      )}

      {/* Loyalty Portal Modal */}
      {loyaltyOpen && (
        <LoyaltyRewards
          theme={theme}
          onClose={() => {
            setLoyaltyOpen(false);
          }}
        />
      )}

      {/* Journal Modal Expanded Post */}
      {activeJournalPost && (
        <JournalModal
          post={activeJournalPost}
          theme={theme}
          onClose={() => setActiveJournalPost(null)}
        />
      )}

      {/* Scroll to Top helper widget */}
      {showScrollTop && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 p-3 bg-stone-900/90 text-amber-50 border border-amber-800/40 rounded-full shadow-2xl hover:bg-amber-800 hover:text-stone-950 transition-all cursor-pointer z-40 animate-fade-in"
          title="Scroll to top"
        >
          <ChevronUp className="h-5 w-5" />
        </button>
      )}
    </div>
  );
}
