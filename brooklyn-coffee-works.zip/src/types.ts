export interface NutritionalInfo {
  calories: number;
  caffeine: string; // e.g., "150mg" or "None"
  allergens: string[];
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'coffee' | 'espresso' | 'tea' | 'pastries' | 'sandwiches' | 'seasonal';
  imageUrl: string;
  tags: string[];
  isSeasonal?: boolean;
  nutritionalInfo?: NutritionalInfo;
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'beans' | 'equipment' | 'apparel' | 'mugs' | 'subscriptions';
  imageUrl: string;
  rating: number;
  reviewsCount: number;
  details: string[];
  options?: string[]; // e.g. ["Whole Bean", "Filter Grind", "Espresso Grind"] or sizes
}

export interface CaféLocation {
  id: string;
  name: string;
  address: string;
  neighborhood: string;
  phone: string;
  hours: {
    weekdays: string;
    weekends: string;
  };
  description: string;
  coordinates: { lat: number; lng: number }; // Relative coordinates for styled map
  features: string[];
}

export interface CommunityEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  locationName: string;
  description: string;
  price: number;
  spotsLeft: number;
  imageUrl: string;
}

export interface JournalPost {
  id: string;
  title: string;
  category: 'Roastery' | 'Culture' | 'Sourcing' | 'Recipes';
  date: string;
  author: string;
  excerpt: string;
  content: string;
  readTime: string;
  imageUrl: string;
}

export interface CartItem {
  id: string;
  itemId: string; // Product.id or MenuItem.id
  type: 'menu' | 'store';
  name: string;
  price: number;
  quantity: number;
  imageUrl: string;
  selectedOption?: string;
}

export interface CareerOpening {
  id: string;
  title: string;
  type: 'Full-time' | 'Part-time';
  department: 'Retail' | 'Roastery' | 'Kitchen' | 'Management';
  description: string;
  requirements: string[];
  salary: string;
}

export interface TableReservation {
  id: string;
  name: string;
  email: string;
  phone: string;
  locationId: string;
  date: string;
  time: string;
  guests: number;
  notes?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  text: string;
  rating: number;
  avatarUrl: string;
}
