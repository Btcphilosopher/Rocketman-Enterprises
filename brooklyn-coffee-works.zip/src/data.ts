import { MenuItem, Product, CaféLocation, CommunityEvent, JournalPost, CareerOpening, Testimonial } from './types';

// Let's use the generated assets for high-impact visual components
export const IMAGES = {
  heroInterior: '/src/assets/images/hero_cafe_interior_1785672792806.jpg',
  latteCloseup: '/src/assets/images/latte_art_closeup_1785672810625.jpg',
  coffeeBag: '/src/assets/images/coffee_bag_packaging_1785672836792.jpg'
};

export const MENU_ITEMS: MenuItem[] = [
  // Coffee & Espresso
  {
    id: 'm1',
    name: 'Williamsburg Espresso',
    description: 'Our signature double shot, featuring notes of dark chocolate, stone fruit, and a velvety brown sugar finish.',
    price: 3.50,
    category: 'espresso',
    imageUrl: IMAGES.latteCloseup,
    tags: ['Best Seller', 'Double Shot'],
    nutritionalInfo: { calories: 5, caffeine: '150mg', allergens: [] }
  },
  {
    id: 'm2',
    name: 'Flat White',
    description: 'Perfectly balanced ristretto double shot with velvety microfoam poured in a traditional 6oz ceramic cup.',
    price: 4.25,
    category: 'espresso',
    imageUrl: 'https://images.unsplash.com/photo-1577968897966-3d4325b36b61?auto=format&fit=crop&q=80&w=400',
    tags: ['Velvety', 'Balanced'],
    nutritionalInfo: { calories: 120, caffeine: '150mg', allergens: ['Dairy (Oat/Almond alternatives available)'] }
  },
  {
    id: 'm3',
    name: 'Cold Brew Draft',
    description: 'Slow-steeped for 18 hours, served on nitrogen tap for an incredibly smooth, creamy mouthfeel and stout-like head.',
    price: 5.00,
    category: 'coffee',
    imageUrl: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=400',
    tags: ['Draft', 'Iced'],
    nutritionalInfo: { calories: 3, caffeine: '210mg', allergens: [] }
  },
  {
    id: 'm4',
    name: 'Honduras Single Origin Pour Over',
    description: 'Single origin Honduras beans brewed via V60. Vibrant acidity with crisp notes of red apple, honey, and green tea.',
    price: 5.50,
    category: 'coffee',
    imageUrl: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=400',
    tags: ['Pour Over', 'Single Origin'],
    nutritionalInfo: { calories: 2, caffeine: '180mg', allergens: [] }
  },
  {
    id: 'm5',
    name: 'Edison Smoked Latte',
    description: 'Espresso combined with milk infused with smoked maple syrup, finished with a touch of volcanic sea salt.',
    price: 6.00,
    category: 'seasonal',
    imageUrl: 'https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&q=80&w=400',
    tags: ['Signature', 'Smoked', 'Seasonal'],
    isSeasonal: true,
    nutritionalInfo: { calories: 240, caffeine: '150mg', allergens: ['Dairy (Oat/Almond alternatives available)'] }
  },
  
  // Teas
  {
    id: 'm6',
    name: 'Ceremonial Matcha Latte',
    description: 'Stone-ground Uji matcha whisked to order, served with lightly sweetened steamed oat milk.',
    price: 5.50,
    category: 'tea',
    imageUrl: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?auto=format&fit=crop&q=80&w=400',
    tags: ['Antioxidant', 'Oat Milk Preferred'],
    nutritionalInfo: { calories: 130, caffeine: '70mg', allergens: [] }
  },
  {
    id: 'm7',
    name: 'Greenpoint Earl Grey Tea',
    description: 'Premium black tea leaves infused with high-grade Italian bergamot and a scatter of blue cornflower petals.',
    price: 4.00,
    category: 'tea',
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=400',
    tags: ['Loose Leaf', 'Hot'],
    nutritionalInfo: { calories: 0, caffeine: '50mg', allergens: [] }
  },

  // Pastries
  {
    id: 'm8',
    name: 'Sourdough Croissant',
    description: 'Baked fresh daily by L\'Appartement 4F in Brooklyn. Incredibly flaky, deep butter flavor with a distinct sourdough tang.',
    price: 4.75,
    category: 'pastries',
    imageUrl: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=400',
    tags: ['Freshly Baked', 'Local Partner'],
    nutritionalInfo: { calories: 340, caffeine: 'None', allergens: ['Gluten', 'Dairy'] }
  },
  {
    id: 'm9',
    name: 'DUMBO Pistachio Bun',
    description: 'Cardamom-infused sweet bun filled with roasted Sicilian pistachio cream and coated in a subtle orange blossom glaze.',
    price: 5.50,
    category: 'pastries',
    imageUrl: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=400',
    tags: ['Chef Special', 'Nutty'],
    nutritionalInfo: { calories: 410, caffeine: 'None', allergens: ['Gluten', 'Dairy', 'Tree Nuts'] }
  },

  // Sandwiches
  {
    id: 'm10',
    name: 'Prospect Park BEC',
    description: 'Thick-cut slab bacon, scrambled heirloom eggs, and sharp white Vermont cheddar on a toasted house brioche bun with maple aioli.',
    price: 11.50,
    category: 'sandwiches',
    imageUrl: 'https://images.unsplash.com/photo-1553909489-cd47e0907980?auto=format&fit=crop&q=80&w=400',
    tags: ['Breakfast Classic', 'Hot'],
    nutritionalInfo: { calories: 620, caffeine: 'None', allergens: ['Gluten', 'Dairy', 'Eggs'] }
  },
  {
    id: 'm11',
    name: 'Dressed Avocado Sourdough',
    description: 'Smashed organic hass avocado, pickled red onion, heirloom cherry tomatoes, red pepper flakes, and microgreens on toasted She Wolf sourdough.',
    price: 12.00,
    category: 'sandwiches',
    imageUrl: 'https://images.unsplash.com/photo-1541532713592-79a0317b6b77?auto=format&fit=crop&q=80&w=400',
    tags: ['Vegan Optional', 'Healthy'],
    nutritionalInfo: { calories: 450, caffeine: 'None', allergens: ['Gluten'] }
  }
];

export const PRODUCTS: Product[] = [
  // Beans
  {
    id: 'p1',
    name: 'Williamsburg Signature Blend',
    description: 'Our award-winning flagship espresso blend. Balanced and deeply complex, roasted medium-dark to draw out notes of rich cacao, stone fruit, and light molasses.',
    price: 18.50,
    category: 'beans',
    imageUrl: IMAGES.coffeeBag,
    rating: 4.9,
    reviewsCount: 142,
    details: [
      'Origin: Colombia (50%), Ethiopia (30%), Honduras (20%)',
      'Elevation: 1,500m - 1,950m',
      'Process: Washed & Natural combination',
      'Notes: Dark Chocolate, Plum, Caramel finish'
    ],
    options: ['Whole Bean', 'Filter Grind', 'Espresso Grind', 'Cold Brew Grind']
  },
  {
    id: 'p2',
    name: 'DUMBO Single Origin: Ethiopia Yirgacheffe',
    description: 'A brilliant light roast from the birthplace of coffee. Explodes with floral jasmine aromatics, citrus notes of sweet bergamot, and a clean, tea-like finish.',
    price: 21.00,
    category: 'beans',
    imageUrl: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?auto=format&fit=crop&q=80&w=400',
    rating: 4.8,
    reviewsCount: 89,
    details: [
      'Origin: Yirgacheffe, Ethiopia (Single Origin)',
      'Elevation: 2,100m',
      'Process: Washed',
      'Notes: Jasmine, Lemon Bergamot, Black Tea'
    ],
    options: ['Whole Bean', 'Filter Grind', 'Coarse Grind']
  },
  
  // Subscriptions
  {
    id: 'p3',
    name: 'Roaster\'s Choice Subscription',
    description: 'Freshly roasted beans delivered right to your door weekly or monthly. Curated selection of our best single origins and signature blends, roasted 24h prior to shipping.',
    price: 16.00,
    category: 'subscriptions',
    imageUrl: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&q=80&w=400',
    rating: 5.0,
    reviewsCount: 312,
    details: [
      'Frequency options: Weekly, Bi-weekly, or Monthly',
      'Guaranteed shipping within 24 hours of roasting',
      'Exclusive access to micro-lot, member-only single origins',
      'Pause, skip or cancel at any time with zero fees'
    ],
    options: ['Weekly Delivery', 'Bi-Weekly Delivery', 'Monthly Delivery']
  },

  // Equipment
  {
    id: 'p4',
    name: 'BKW Matte Black Kettle',
    description: 'Precision gooseneck kettle with built-in thermometer for the absolute perfect water temperature. Matte black finish matching our café aesthetic.',
    price: 85.00,
    category: 'equipment',
    imageUrl: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=400',
    rating: 4.7,
    reviewsCount: 54,
    details: [
      'Material: Premium Food-grade Stainless Steel with matte finish',
      'Gooseneck spout for precise 90-degree laminar water flow control',
      'Volume: 1.0 Litre, suitable for gas, electric, and induction cooktops',
      'Comfort-grip counterbalanced wooden handle'
    ],
    options: ['Standard Black', 'Walnut Detail Black']
  },
  {
    id: 'p5',
    name: 'BKW Craft Wood V60 Dripper',
    description: 'Handcrafted Japanese olive wood dripper stand paired with a custom-stamped BKW ceramic cone. Exquisite temperature isolation.',
    price: 48.00,
    category: 'equipment',
    imageUrl: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviewsCount: 76,
    details: [
      'Hand-carved premium sustainable olive wood sleeve',
      'High-fired heat-resistant matte white porcelain inner dripper',
      'Size 02: Makes 1-4 cups of specialty filter coffee',
      'Easy to clean, durable construction for lifetime use'
    ]
  },

  // Apparel & Mugs
  {
    id: 'p6',
    name: 'Barista Concrete-Gray Mug',
    description: 'Handmade, heavy-duty stoneware mug custom-fired by a local Williamsburg ceramicist. Softly textured sand exterior with a dark charcoal glazed interior.',
    price: 24.00,
    category: 'mugs',
    imageUrl: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?auto=format&fit=crop&q=80&w=400',
    rating: 4.9,
    reviewsCount: 205,
    details: [
      'Capacity: 12oz, perfect for lattes, drip, or tea',
      'Dishwasher and Microwave safe',
      'Ergonomically designed finger handle for secure grip',
      'Locally made and hand-stamped logo base'
    ],
    options: ['Concrete Gray', 'Espresso Black', 'Oat Cream']
  },
  {
    id: 'p7',
    name: 'Brooklyn Coffee Works Worker Apron',
    description: 'Our official café apron, made from heavy-weight 12oz black duck canvas with dark brown leather straps, raw brass grommets, and double-stitched utilitarian pockets.',
    price: 65.00,
    category: 'apparel',
    imageUrl: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&q=80&w=400',
    rating: 4.8,
    reviewsCount: 42,
    details: [
      '100% durable cotton canvas, adjustable cross-back leather straps',
      'Quick-release brass clasps to relieve neck tension during shifts',
      'Equipped with 3 deep utility pockets + pen and thermometer slots',
      'One size fits all with fully customisable straps'
    ],
    options: ['Coal Black Canvas', 'Tan Raw Canvas']
  }
];

export const LOCATIONS: CaféLocation[] = [
  {
    id: 'loc1',
    name: 'Williamsburg Flagship',
    address: '142 Wythe Ave, Brooklyn, NY 11249',
    neighborhood: 'Williamsburg',
    phone: '(718) 555-0190',
    hours: {
      weekdays: '6:30 AM - 7:00 PM',
      weekends: '7:00 AM - 8:00 PM'
    },
    description: 'Our original flagship space in Williamsburg features soaring 20ft ceilings, original exposed brickwork, and a masterfully restored 1950s copper Probat roaster behind a glass wall.',
    coordinates: { lat: 40.7196, lng: -73.9616 },
    features: ['In-house Roastery', 'Outdoor Heated Patio', 'Barista Training Academy', 'Wheelchair Accessible']
  },
  {
    id: 'loc2',
    name: 'DUMBO Waterfront',
    address: '55 Water St, Brooklyn, NY 11201',
    neighborhood: 'DUMBO',
    phone: '(718) 555-0245',
    hours: {
      weekdays: '7:00 AM - 6:00 PM',
      weekends: '7:30 AM - 7:00 PM'
    },
    description: 'Nestled between the historic brick warehouses adjacent to Brooklyn Bridge Park. Sip your double ristretto while soaking in sweeping views of the Manhattan skyline through floor-to-ceiling iron-gridded windows.',
    coordinates: { lat: 40.7032, lng: -73.9918 },
    features: ['Skyline Views', 'Draft Nitro Station', 'Espresso Tasting Flights', 'Curated Art Gallery']
  },
  {
    id: 'loc3',
    name: 'Greenpoint Lab',
    address: '98 Franklin St, Brooklyn, NY 11222',
    neighborhood: 'Greenpoint',
    phone: '(718) 555-0312',
    hours: {
      weekdays: '7:00 AM - 5:00 PM',
      weekends: '8:00 AM - 6:00 PM'
    },
    description: 'A cozy, minimalist hideaway focused on micro-lot exploration. Greenpoint serves as our sensory lab, where we host weekly cupping sessions and experimental fermentation brews.',
    coordinates: { lat: 40.7291, lng: -73.9575 },
    features: ['Weekly Public Cuppings', 'Slow Bar Pour Overs', 'Sourdough Bakery Counter', 'Bike Friendly']
  },
  {
    id: 'loc4',
    name: 'Park Slope Roost',
    address: '312 5th Ave, Brooklyn, NY 11215',
    neighborhood: 'Park Slope',
    phone: '(718) 555-0488',
    hours: {
      weekdays: '6:30 AM - 6:00 PM',
      weekends: '7:00 AM - 6:00 PM'
    },
    description: 'A warm community-centered hub featuring rich oak booths, custom-built reading nooks, and an extensive specialty loose-leaf tea program. Families, book lovers, and creative writers welcome.',
    coordinates: { lat: 40.6725, lng: -73.9814 },
    features: ['Reading Nooks', 'Kid-friendly Play Corner', 'Community Board', 'Stroller Parking Area']
  }
];

export const EVENTS: CommunityEvent[] = [
  {
    id: 'ev1',
    title: 'Intro to Sensory Coffee Tasting (Cupping)',
    date: 'August 14, 2026',
    time: '6:00 PM - 7:30 PM',
    locationName: 'Greenpoint Lab',
    description: 'Learn the official industry-standard SCA cupping protocols. Identify differences between African floral, Central American fruity, and South American chocolate coffee notes.',
    price: 35.00,
    spotsLeft: 8,
    imageUrl: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'ev2',
    title: 'Latte Art Masterclass: Pouring Microfoam',
    date: 'August 22, 2026',
    time: '5:30 PM - 7:30 PM',
    locationName: 'Williamsburg Flagship',
    description: 'Hands-on training behind our commercial La Marzocco KB90 machines. Master milk stretching, milk texturing, and pour patterns to create a flawless rosette and tulip.',
    price: 65.00,
    spotsLeft: 4,
    imageUrl: IMAGES.latteCloseup
  },
  {
    id: 'ev3',
    title: 'Live Acoustic Session: Brooklyn Sessions',
    date: 'August 28, 2026',
    time: '7:00 PM - 9:30 PM',
    locationName: 'DUMBO Waterfront',
    description: 'Join us for local DUMBO folk and jazz songwriters alongside discounted evening cold brews, beer, and light organic sourdough wood-fired pizzas.',
    price: 15.00,
    spotsLeft: 25,
    imageUrl: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&q=80&w=400'
  }
];

export const JOURNAL_POSTS: JournalPost[] = [
  {
    id: 'jp1',
    title: 'Sourcing at Altitude: The Highlands of Sidama',
    category: 'Sourcing',
    date: 'July 18, 2026',
    author: 'Elena Rostova (Head Roaster)',
    excerpt: 'Journey into Ethiopia\'s southern highlands to trace the family co-ops producing our brightest, most floral heirloom varieties of the season.',
    content: 'Deep in the heart of Sidama, we met with forty micro-lot farmers who pick red organic cherries individually at over 2,200 meters of elevation. It is this incredible environmental stress and rich volcanic loam that shapes the crisp floral jasmine notes we roast with precise care every Monday morning...',
    readTime: '6 min read',
    imageUrl: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&q=80&w=400'
  },
  {
    id: 'jp2',
    title: 'The Chemistry of Perfect Microfoam: A Barista\'s Guide',
    category: 'Recipes',
    date: 'June 30, 2026',
    author: 'Marcus Vance (Lead Barista)',
    excerpt: 'The hidden science behind vaporizing lipids, breaking down lactose, and texturing lipids to pour consistent rosettes at home.',
    content: 'Perfect microfoam is not an accident of aesthetics; it is a thermal sweet spot. When steam is injected, proteins stretch to form a protective cage around trapped air bubbles. If you heat milk past 145 degrees, those delicate proteins collapse completely, leaving you with dry foam and scalded lactose...',
    readTime: '4 min read',
    imageUrl: IMAGES.latteCloseup
  },
  {
    id: 'jp3',
    title: 'Urban Sanctuary: Creating Williamsburg\'s Gathering Space',
    category: 'Culture',
    date: 'June 12, 2026',
    author: 'Julian Cole (Founder)',
    excerpt: 'How we repurposed a 1920s metal workshop into a cozy, industrial living room centered around neighborhood connection and craft.',
    content: 'Specialty coffee shops aren\'t simply beverage dispensaries; they are the modern urban neighborhood living room. When we salvaged the Wythe Avenue steel foundry, we left the water-damaged brick and concrete stains intact, adding only reclaimed wood boards and warm Edison filament glow to encourage humans to slow down...',
    readTime: '8 min read',
    imageUrl: IMAGES.heroInterior
  }
];

export const CAREER_OPENINGS: CareerOpening[] = [
  {
    id: 'c1',
    title: 'Specialty Barista & Hospitality Guide',
    type: 'Full-time',
    department: 'Retail',
    description: 'Lead the coffee bar experience by brewing flawless espresso, educating guests on origin notes, and creating warm neighborhood hospitality.',
    requirements: [
      'Minimum 1 year experience behind a specialty espresso bar',
      'Basic understanding of dial-in parameters (dose, yield, extraction times)',
      'Passion for origin details, roasting philosophy, and clean milk texturing',
      'Friendly, proactive demeanor and active listener'
    ],
    salary: '$18.50 - $22.00 / hour + shared daily tips'
  },
  {
    id: 'c2',
    title: 'Assistant Coffee Roaster & QC Specialist',
    type: 'Full-time',
    department: 'Roastery',
    description: 'Assist our Head Roaster with green bean sorting, operating our Probat and Loring machines, maintaining roast logs, and organizing weekly coffee cupping events.',
    requirements: [
      'Strong passion for green coffee quality, botanical variations, and roasting science',
      'Detail-oriented physical stamina (capable of lifting 60lb green coffee bags)',
      'Familiarity with roasting software such as Cropster or Artisan is a major plus',
      'SCA Roasting or Cupping certification is highly valued but not mandatory'
    ],
    salary: '$48,000 - $55,000 / year'
  },
  {
    id: 'c3',
    title: 'Specialty Pastry Artisan (L\'Appartement Partner)',
    type: 'Part-time',
    department: 'Kitchen',
    description: 'Manage early morning bake schedules of premium croissants, pistachio rolls, and custom sourdough products in our state-of-the-art Greenpoint pastry kitchen.',
    requirements: [
      'Minimum 2 years experience in laminated doughs and artisan bread fermentation',
      'Comfortable starting shifts at 4:30 AM to ensure hot bakes for morning openings',
      'Food handlers safety license mandatory',
      'Eye for beautiful aesthetic presentation and consistency'
    ],
    salary: '$20.00 - $24.00 / hour'
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    id: 't1',
    name: 'Sarah Jenkins',
    role: 'Creative Director, DUMBO',
    text: 'BKW is my ultimate sanctuary. The espresso is dialed in to perfection every single morning, the concrete-and-brick design sparks my creativity, and the staff remembers my name and oat-milk cortado preference.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150'
  },
  {
    id: 't2',
    name: 'David Choi',
    role: 'Novelist & Greenpoint Local',
    text: 'Their single-origin pour overs are unmatched. I spend every Saturday morning sitting at the custom wood tables in Greenpoint with a cup of Ethiopia Yirgacheffe and my notebook. It is a true neighborhood gem.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=150'
  },
  {
    id: 't3',
    name: 'Amara Diop',
    role: 'Community Activist, Park Slope',
    text: 'I love BKW not just for their extraordinary draft nitro, but because they put their money where their mouth is. Their direct-trade relationships with organic farmers and focus on zero-waste packaging set a massive industry standard.',
    rating: 5,
    avatarUrl: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=150'
  }
];
