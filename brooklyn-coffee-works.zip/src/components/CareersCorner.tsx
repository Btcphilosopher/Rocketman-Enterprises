import React, { useState } from 'react';
import { Briefcase, FileText, CheckCircle2, DollarSign, UploadCloud, Sparkles } from 'lucide-react';
import { CAREER_OPENINGS } from '../data';
import { CareerOpening } from '../types';

interface CareersCornerProps {
  theme: 'cream' | 'industrial';
}

export default function CareersCorner({ theme }: CareersCornerProps) {
  const [activeJobId, setActiveJobId] = useState<string | null>(null);
  const [candidateName, setCandidateName] = useState('');
  const [candidateEmail, setCandidateEmail] = useState('');
  const [candidatePhone, setCandidatePhone] = useState('');
  const [coverNote, setCoverNote] = useState('');
  const [mockFileName, setMockFileName] = useState<string | null>(null);
  const [submittedApplication, setSubmittedApplication] = useState<any | null>(null);

  const activeJob = CAREER_OPENINGS.find(j => j.id === activeJobId) || null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMockFileName(file.name);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      setMockFileName(file.name);
    }
  };

  const handleApplicationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!candidateName || !candidateEmail || !candidatePhone || !mockFileName) return;

    // Build the mock application reference
    const applicationRef = `BKW-JOB-${Math.floor(1000 + Math.random() * 9000)}`;
    setSubmittedApplication({
      ref: applicationRef,
      candidateName,
      candidateEmail,
      jobTitle: activeJob?.title,
      department: activeJob?.department
    });
  };

  const resetApplication = () => {
    setSubmittedApplication(null);
    setActiveJobId(null);
    setCandidateName('');
    setCandidateEmail('');
    setCandidatePhone('');
    setCoverNote('');
    setMockFileName(null);
  };

  return (
    <div id="careers-portal" className="max-w-4xl mx-auto px-4 sm:px-6">
      {!activeJobId ? (
        /* Listings list */
        <div className="space-y-6">
          <div className="text-center max-w-xl mx-auto space-y-2 mb-10">
            <span className="text-[10px] tracking-widest font-black uppercase text-amber-600">Join the Collective</span>
            <h3 className="text-2xl font-black uppercase tracking-wider">Careers at Brooklyn Coffee Works</h3>
            <p className="text-xs text-stone-400 leading-relaxed">
              We are craft-driven, community-oriented, and passionate about sourcing, roasting, and hospitality. Join our growing teams in DUMBO, Williamsburg, Greenpoint, or Park Slope.
            </p>
          </div>

          <div className="space-y-4">
            {CAREER_OPENINGS.map((job) => (
              <div
                key={job.id}
                className={`p-6 rounded-2xl border transition-all duration-300 flex flex-col md:flex-row md:items-center justify-between gap-5 ${
                  theme === 'cream'
                    ? 'bg-white border-stone-200/60 hover:shadow-lg hover:border-amber-200'
                    : 'bg-stone-950 border-stone-850 hover:shadow-xl hover:border-amber-800/40'
                }`}
              >
                <div className="space-y-1.5 text-left">
                  <div className="flex flex-wrap gap-2">
                    <span className="text-[8px] font-black tracking-widest uppercase px-2 py-0.5 rounded-full bg-amber-600/10 text-amber-600">
                      {job.department}
                    </span>
                    <span className={`text-[8px] font-bold tracking-widest uppercase px-2 py-0.5 rounded-full ${
                      theme === 'cream' ? 'bg-stone-100 text-stone-600' : 'bg-stone-900 text-stone-400'
                    }`}>
                      {job.type}
                    </span>
                  </div>
                  <h4 className="text-base font-black uppercase tracking-wider">{job.title}</h4>
                  <p className="text-xs text-stone-400 line-clamp-1">{job.description}</p>
                </div>

                <div className="flex items-center justify-between md:justify-end gap-4 border-t border-dashed border-stone-800/10 md:border-0 pt-4 md:pt-0">
                  <div className="text-left md:text-right">
                    <span className="text-[8px] font-bold text-stone-500 uppercase tracking-widest block">COMPENSATION</span>
                    <span className="text-xs font-black font-mono text-amber-600">{job.salary}</span>
                  </div>
                  <button
                    onClick={() => setActiveJobId(job.id)}
                    className="px-5 py-2.5 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-950 text-amber-50 hover:bg-amber-900 cursor-pointer"
                  >
                    Apply Now
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : submittedApplication ? (
        /* Immersive success visual ticket receipt */
        <div className="space-y-6 max-w-md mx-auto text-center">
          <div className="p-8 bg-emerald-600/5 border border-emerald-500/20 rounded-3xl space-y-4 flex flex-col items-center">
            <div className="p-4 bg-emerald-500/10 rounded-full text-emerald-600 animate-pulse">
              <CheckCircle2 className="h-10 w-10" />
            </div>
            
            <span className="text-[10px] tracking-widest font-black uppercase text-emerald-600">Application Registered</span>
            <h4 className="text-xl font-black uppercase tracking-wider text-emerald-700">DOCKET GENERATED SUCCESSFULLY</h4>
            <p className="text-xs text-stone-400 leading-relaxed">
              Hey {submittedApplication.candidateName}, we have received your application for **{submittedApplication.jobTitle}** in our {submittedApplication.department} team.
            </p>

            <div className="w-full bg-stone-900/5 dark:bg-stone-900 p-4 rounded-2xl border border-stone-800/10 font-mono text-left text-[11px] space-y-2">
              <div className="flex justify-between">
                <span>REFERENCE #:</span>
                <span className="font-bold">{submittedApplication.ref}</span>
              </div>
              <div className="flex justify-between">
                <span>POSITION:</span>
                <span className="font-bold">{submittedApplication.jobTitle}</span>
              </div>
              <div className="flex justify-between">
                <span>EMAIL REGISTERED:</span>
                <span className="font-bold truncate">{submittedApplication.candidateEmail}</span>
              </div>
              <div className="flex justify-between">
                <span>STATUS:</span>
                <span className="text-amber-600 font-extrabold">CU-QC QUEUED</span>
              </div>
            </div>

            <p className="text-[10px] text-stone-500 leading-relaxed font-sans">
              Our hiring collective reviews bakes and barista portfolios every Wednesday. You will hear from Julian or Elena shortly!
            </p>
          </div>

          <button
            onClick={resetApplication}
            className="w-full py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-900 text-amber-50 hover:bg-amber-900 cursor-pointer"
          >
            Return to Career Board
          </button>
        </div>
      ) : (
        /* Detailed Form for individual job */
        <div className={`p-6 sm:p-8 rounded-3xl border ${
          theme === 'cream' ? 'bg-white border-amber-100' : 'bg-stone-950 border-stone-850'
        }`}>
          <div className="flex justify-between items-start pb-4 border-b border-stone-800/10 mb-6">
            <div className="text-left">
              <span className="text-[9px] tracking-widest font-black uppercase text-amber-600">{activeJob?.department} Division</span>
              <h3 className="text-xl font-black tracking-wider uppercase">{activeJob?.title}</h3>
            </div>
            <button
              onClick={() => setActiveJobId(null)}
              className="px-3 py-1.5 rounded-lg border border-stone-800/15 text-[10px] font-bold uppercase hover:bg-stone-900/5"
            >
              ← Back
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left specifications pane */}
            <div className="md:col-span-1 space-y-5 text-left">
              <div>
                <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block mb-1">CONTRACT</span>
                <p className="text-xs font-bold uppercase">{activeJob?.type}</p>
              </div>
              <div>
                <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block mb-1">COMPENSATION</span>
                <p className="text-xs font-bold text-amber-600 font-mono">{activeJob?.salary}</p>
              </div>

              <div>
                <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block mb-2">MINIMUM REQUIREMENTS</span>
                <div className="space-y-1.5">
                  {activeJob?.requirements.map((req, i) => (
                    <div key={i} className="flex items-start gap-1.5 text-[10px] leading-relaxed text-stone-400">
                      <span className="text-amber-600 mt-1">✦</span>
                      <p>{req}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Form pane */}
            <form onSubmit={handleApplicationSubmit} className="md:col-span-2 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Your Name</label>
                  <input
                    type="text"
                    required
                    value={candidateName}
                    onChange={(e) => setCandidateName(e.target.value)}
                    placeholder="e.g. Thomas Cole"
                    className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    value={candidateEmail}
                    onChange={(e) => setCandidateEmail(e.target.value)}
                    placeholder="thomas@cole.com"
                    className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Mobile Phone Number</label>
                <input
                  type="tel"
                  required
                  value={candidatePhone}
                  onChange={(e) => setCandidatePhone(e.target.value)}
                  placeholder="(718) 555-0120"
                  className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                />
              </div>

              {/* Cover note message */}
              <div>
                <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Cover Note (Brief introduction)</label>
                <textarea
                  value={coverNote}
                  onChange={(e) => setCoverNote(e.target.value)}
                  placeholder="Tell us why you love specialty coffee and how you thrive in a community-centered space..."
                  rows={3}
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold animate-fade-in"
                />
              </div>

              {/* Drag and Drop resume upload block */}
              <div>
                <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Attach Resume (Required)</label>
                
                <div
                  onDragOver={handleDragOver}
                  onDrop={handleDrop}
                  className="border-2 border-dashed border-stone-800/15 rounded-xl p-5 text-center bg-stone-900/5 hover:bg-stone-900/10 hover:border-amber-600 transition-colors relative"
                >
                  <input
                    type="file"
                    required
                    accept=".pdf,.doc,.docx"
                    onChange={handleFileUpload}
                    className="absolute inset-0 opacity-0 w-full h-full cursor-pointer z-10"
                  />
                  <div className="flex flex-col items-center gap-1.5">
                    <UploadCloud className="h-7 w-7 text-amber-600" />
                    <p className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
                      {mockFileName ? 'File Selected' : 'Drag & Drop your Resume'}
                    </p>
                    <p className="text-[9px] text-stone-500">
                      {mockFileName ? mockFileName : 'Supports PDF, DOC, DOCX up to 10MB'}
                    </p>
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-700 hover:bg-amber-600 text-stone-950 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sparkles className="h-4 w-4 animate-spin" style={{ animationDuration: '3s' }} />
                Submit Job Application
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
