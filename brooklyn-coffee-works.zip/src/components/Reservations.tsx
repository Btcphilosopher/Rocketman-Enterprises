import React, { useState } from 'react';
import { CalendarDays, MapPin, Users, Clock, CheckCircle2, QrCode, ClipboardCheck } from 'lucide-react';
import { LOCATIONS, EVENTS } from '../data';
import { CaféLocation, CommunityEvent } from '../types';

interface ReservationsProps {
  theme: 'cream' | 'industrial';
  onClose: () => void;
}

export default function Reservations({ theme, onClose }: ReservationsProps) {
  const [bookingType, setBookingType] = useState<'table' | 'tasting'>('table');
  const [selectedLocation, setSelectedLocation] = useState(LOCATIONS[0].id);
  const [selectedEventId, setSelectedEventId] = useState(EVENTS[0].id);
  const [guestCount, setGuestCount] = useState(2);
  const [date, setDate] = useState('2026-08-15');
  const [time, setTime] = useState('10:00 AM');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [bookedReceipt, setBookedReceipt] = useState<any | null>(null);

  const availableTimes = [
    '8:00 AM', '9:30 AM', '11:00 AM', '12:30 PM', '2:00 PM', '3:30 PM', '5:00 PM', '6:30 PM'
  ];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail || !customerPhone) return;

    // Build the mock receipt docket
    const randomTicketId = `BKW-RES-${Math.floor(1000 + Math.random() * 9000)}`;
    const locationObj = LOCATIONS.find(l => l.id === selectedLocation);
    const eventObj = EVENTS.find(e => e.id === selectedEventId);

    setBookedReceipt({
      ticketId: randomTicketId,
      customerName,
      customerEmail,
      customerPhone,
      bookingType,
      date,
      time: bookingType === 'table' ? time : eventObj?.time,
      locationName: bookingType === 'table' ? locationObj?.name : eventObj?.locationName,
      address: bookingType === 'table' ? locationObj?.address : 'Check Event Details',
      details: bookingType === 'table' ? `Table Reservation for ${guestCount} Guests` : `Cupping Ticket: ${eventObj?.title}`,
      notes
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 backdrop-blur-xs p-4 overflow-y-auto">
      <div className={`w-full max-w-2xl rounded-3xl border overflow-hidden shadow-2xl transition-all duration-300 my-8 ${
        theme === 'cream'
          ? 'bg-amber-50/98 border-amber-100 text-stone-950'
          : 'bg-stone-950 border-stone-850 text-amber-50'
      }`}>
        
        {/* Header bar */}
        <div className="p-6 border-b border-stone-800/10 flex justify-between items-center">
          <div>
            <span className="text-[10px] tracking-widest font-bold uppercase text-amber-600">Specialty Booking</span>
            <h3 className="text-xl font-black tracking-wider uppercase">Café Reservations</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-900/10 text-stone-400 font-bold text-sm"
          >
            ✕
          </button>
        </div>

        {/* Outer body */}
        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto scrollbar-hide">
          {!bookedReceipt ? (
            <form onSubmit={handleBookingSubmit} className="space-y-6">
              
              {/* Selector Tabs: Table vs Sensory Cupping */}
              <div className="flex bg-stone-900/5 dark:bg-stone-900 p-1.5 rounded-2xl gap-2">
                <button
                  type="button"
                  onClick={() => setBookingType('table')}
                  className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                    bookingType === 'table'
                      ? 'bg-amber-700 text-stone-950 font-black shadow-sm'
                      : 'text-stone-400 hover:text-stone-300'
                  }`}
                >
                  <Users className="inline-block h-4 w-4 mr-2" />
                  Reserve Table / Booth
                </button>
                <button
                  type="button"
                  onClick={() => setBookingType('tasting')}
                  className={`flex-1 py-3 text-xs font-bold uppercase tracking-wider rounded-xl transition-all cursor-pointer ${
                    bookingType === 'tasting'
                      ? 'bg-amber-700 text-stone-950 font-black shadow-sm'
                      : 'text-stone-400 hover:text-stone-300'
                  }`}
                >
                  <CalendarDays className="inline-block h-4 w-4 mr-2" />
                  Sensory Cupping Event
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {bookingType === 'table' ? (
                  <>
                    {/* Location Selection */}
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">
                        Choose Neighborhood
                      </label>
                      <div className="relative">
                        <MapPin className="absolute left-3.5 top-3.5 h-4 w-4 text-amber-600" />
                        <select
                          value={selectedLocation}
                          onChange={(e) => setSelectedLocation(e.target.value)}
                          className="w-full pl-10 pr-3.5 py-3 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 font-semibold focus:outline-hidden focus:border-amber-600"
                        >
                          {LOCATIONS.map((loc) => (
                            <option key={loc.id} value={loc.id}>{loc.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Guest count */}
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">
                        Party Size
                      </label>
                      <div className="relative">
                        <Users className="absolute left-3.5 top-3.5 h-4 w-4 text-amber-600" />
                        <select
                          value={guestCount}
                          onChange={(e) => setGuestCount(Number(e.target.value))}
                          className="w-full pl-10 pr-3.5 py-3 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 font-semibold focus:outline-hidden focus:border-amber-600"
                        >
                          {[1, 2, 3, 4, 5, 6, 8].map((num) => (
                            <option key={num} value={num}>{num} Guest{num > 1 ? 's' : ''}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </>
                ) : (
                  /* Tasting Event selector */
                  <div className="col-span-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">
                      Select Masterclass or Tasting
                    </label>
                    <div className="relative">
                      <CalendarDays className="absolute left-3.5 top-3.5 h-4 w-4 text-amber-600" />
                      <select
                        value={selectedEventId}
                        onChange={(e) => setSelectedEventId(e.target.value)}
                        className="w-full pl-10 pr-3.5 py-3 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 font-semibold focus:outline-hidden focus:border-amber-600"
                      >
                        {EVENTS.map((ev) => (
                          <option key={ev.id} value={ev.id}>
                            {ev.title} ({ev.date} @ {ev.locationName}) - ${ev.price}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                )}
              </div>

              {bookingType === 'table' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  {/* Date Input */}
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">
                      Target Date
                    </label>
                    <input
                      type="date"
                      required
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      min="2026-08-02"
                      className="w-full px-3.5 py-3 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 font-semibold focus:outline-hidden focus:border-amber-600"
                    />
                  </div>

                  {/* Time slot picker */}
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-2">
                      Available Sitting Slot
                    </label>
                    <div className="grid grid-cols-4 gap-1.5">
                      {availableTimes.map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setTime(t)}
                          className={`py-2 rounded-lg text-[9px] font-bold uppercase border text-center transition-all cursor-pointer ${
                            time === t
                              ? 'border-amber-600 bg-amber-600/10 text-amber-600 font-black'
                              : 'border-stone-800/10 hover:bg-stone-900/5 text-stone-500'
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Guest Information Details */}
              <div className="border-t border-stone-850 pt-5 space-y-4">
                <span className="text-[10px] tracking-widest font-black uppercase text-amber-600">Contact Details</span>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Eleanor Vance"
                      className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={customerEmail}
                      onChange={(e) => setCustomerEmail(e.target.value)}
                      placeholder="eleanor@vance.com"
                      className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Mobile</label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="(718) 555-0190"
                      className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[9px] font-bold uppercase tracking-widest text-stone-400 block mb-1">Special requests or food allergies</label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g., Anniversary, prefer low-top table, wheel-chair access, vegan"
                    className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                  />
                </div>
              </div>

              {/* Submit trigger button */}
              <button
                type="submit"
                className="w-full py-4 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-950 text-amber-50 hover:bg-amber-900 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <ClipboardCheck className="h-4.5 w-4.5 text-amber-500" />
                Book Reservation Now
              </button>
            </form>
          ) : (
            /* Immersive Reservation Pass Render */
            <div className="space-y-6 text-stone-950">
              <div className="bg-stone-50 border-3 border-stone-950 rounded-2xl shadow-xl overflow-hidden relative font-mono text-xs">
                {/* Visual perforation circles */}
                <div className="absolute top-1/2 -translate-y-1/2 -left-3 h-6 w-6 rounded-full bg-stone-950 border-r-2 border-stone-950" />
                <div className="absolute top-1/2 -translate-y-1/2 -right-3 h-6 w-6 rounded-full bg-stone-950 border-l-2 border-stone-950" />
                
                {/* Top Section */}
                <div className="p-6 bg-amber-100/50 border-b border-dashed border-stone-400 flex justify-between items-start">
                  <div>
                    <h5 className="font-extrabold text-xs uppercase text-amber-800">BROOKLYN COFFEE WORKS</h5>
                    <p className="text-[10px] text-stone-500 uppercase mt-0.5">EST. 2012 / GUEST BOARDING PASS</p>
                  </div>
                  <span className="font-black text-xs text-stone-700">{bookedReceipt.ticketId}</span>
                </div>

                {/* Info Block */}
                <div className="p-6 grid grid-cols-2 gap-y-4 gap-x-2 border-b border-dashed border-stone-400">
                  <div>
                    <span className="text-[8px] text-stone-400 uppercase tracking-widest">GUEST HOLDER</span>
                    <p className="font-black text-[11px] truncate">{bookedReceipt.customerName}</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-stone-400 uppercase tracking-widest">Neighborhood</span>
                    <p className="font-black text-[11px] truncate">{bookedReceipt.locationName}</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-stone-400 uppercase tracking-widest">SITTING DATE</span>
                    <p className="font-black text-[11px]">{bookedReceipt.date}</p>
                  </div>
                  <div>
                    <span className="text-[8px] text-stone-400 uppercase tracking-widest">TIME SLOT</span>
                    <p className="font-black text-[11px]">{bookedReceipt.time}</p>
                  </div>
                  <div className="col-span-2 pt-2 border-t border-stone-900/10">
                    <span className="text-[8px] text-stone-400 uppercase tracking-widest">SPECIFICATIONS</span>
                    <p className="font-bold text-[10px] text-amber-850">{bookedReceipt.details}</p>
                    {bookedReceipt.notes && (
                      <p className="text-[9px] text-stone-500 italic mt-1 font-sans">Notes: "{bookedReceipt.notes}"</p>
                    )}
                  </div>
                </div>

                {/* Digital scan validation footer */}
                <div className="p-6 bg-white flex items-center justify-between">
                  <div className="space-y-1 pr-4">
                    <span className="text-[8px] text-stone-400 uppercase tracking-widest block">CHECK-IN SCANNER</span>
                    <p className="text-[9px] text-stone-500 leading-relaxed font-sans">
                      Please arrive 5 mins early. Present this barcode to our host.
                    </p>
                  </div>
                  <QrCode className="h-12 w-12 text-stone-850 flex-shrink-0 stroke-[1.2]" />
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-center gap-1.5 text-emerald-800 text-[10px] font-bold uppercase mb-2">
                  <CheckCircle2 className="h-4.5 w-4.5 stroke-[2.5]" />
                  CONFIRMATION SENT TO EMAIL & SMS
                </div>
                <button
                  onClick={() => {
                    setBookedReceipt(null);
                    onClose();
                  }}
                  className="w-full py-4 rounded-xl text-xs font-black tracking-widest uppercase bg-emerald-700 hover:bg-emerald-600 text-white flex items-center justify-center cursor-pointer"
                >
                  Confirm & Dismiss
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
