import React, { useState } from 'react';
import { MapPin, Phone, Clock, Compass, HelpCircle, CheckCircle } from 'lucide-react';
import { LOCATIONS } from '../data';
import { CaféLocation } from '../types';

interface LocationsMapProps {
  theme: 'cream' | 'industrial';
}

export default function LocationsMap({ theme }: LocationsMapProps) {
  const [activeLocationId, setActiveLocationId] = useState<string>(LOCATIONS[0].id);

  const selectedLocation = LOCATIONS.find(loc => loc.id === activeLocationId) || LOCATIONS[0];

  // SVG coordinate projection helper
  // Map dimensions are 500x500 pixels. We translatelat/lng relative to Brooklyn bounds.
  // Lat: 40.6700 to 40.7350
  // Lng: -74.0000 to -73.9500
  const getCoordinates = (lat: number, lng: number) => {
    const latMin = 40.665;
    const latMax = 40.735;
    const lngMin = -74.005;
    const lngMax = -73.945;

    // Convert to 0-1 percentage
    const xPct = (lng - lngMin) / (lngMax - lngMin);
    // Y percentage is inverted since SVG y starts at top
    const yPct = 1 - (lat - latMin) / (latMax - latMin);

    return {
      x: xPct * 450 + 25,
      y: yPct * 450 + 25
    };
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      {/* Left List block */}
      <div className="lg:col-span-5 space-y-4 max-h-[580px] overflow-y-auto pr-2 scrollbar-hide">
        {LOCATIONS.map((loc) => {
          const isActive = loc.id === activeLocationId;
          return (
            <div
              key={loc.id}
              onClick={() => setActiveLocationId(loc.id)}
              className={`p-5 rounded-2xl border transition-all duration-300 cursor-pointer ${
                isActive
                  ? theme === 'cream'
                    ? 'bg-white border-amber-600 shadow-md ring-2 ring-amber-600/10'
                    : 'bg-stone-900 border-amber-600 shadow-xl ring-2 ring-amber-600/20'
                  : theme === 'cream'
                  ? 'bg-white/60 hover:bg-white border-stone-250/60 hover:shadow-md'
                  : 'bg-stone-950/40 hover:bg-stone-900/30 border-stone-850/60'
              }`}
            >
              <div className="flex items-start gap-3">
                <MapPin className={`h-5 w-5 mt-0.5 ${isActive ? 'text-amber-600 animate-bounce' : 'text-stone-400'}`} />
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-black uppercase tracking-wider">{loc.name}</h4>
                    {isActive && (
                      <span className="text-[8px] font-black tracking-widest uppercase text-amber-600 bg-amber-600/10 px-2 py-0.5 rounded-full">
                        Selected
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-400 font-medium">{loc.address}</p>
                </div>
              </div>

              {isActive && (
                <div className="mt-4 pt-4 border-t border-dashed border-stone-800/10 space-y-3 text-xs animate-fade-in">
                  <p className={`${theme === 'cream' ? 'text-stone-600' : 'text-stone-400'} leading-relaxed`}>
                    {loc.description}
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1 text-[11px]">
                    <div className="space-y-1">
                      <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block">Hours</span>
                      <div className="flex items-center gap-1.5 text-stone-400">
                        <Clock className="h-3.5 w-3.5 text-amber-600" />
                        <span>M-F: {loc.hours.weekdays}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-stone-400 pl-5">
                        <span>S-S: {loc.hours.weekends}</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block">Contact</span>
                      <div className="flex items-center gap-1.5 text-stone-400">
                        <Phone className="h-3.5 w-3.5 text-amber-600" />
                        <span>{loc.phone}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2">
                    <span className="text-[9px] font-bold text-stone-500 uppercase tracking-widest block mb-1.5">Aesthetic & Features</span>
                    <div className="flex flex-wrap gap-1">
                      {loc.features.map((feat, idx) => (
                        <span
                          key={idx}
                          className={`text-[9px] font-semibold px-2.5 py-0.5 rounded-full ${
                            theme === 'cream' ? 'bg-amber-100/40 text-stone-700' : 'bg-stone-900 text-stone-400'
                          }`}
                        >
                          ✓ {feat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Right Map block */}
      <div className="lg:col-span-7">
        <div className={`rounded-3xl border overflow-hidden p-6 relative aspect-square md:h-[580px] flex flex-col justify-between ${
          theme === 'cream' ? 'bg-amber-50/50 border-stone-200' : 'bg-stone-950 border-stone-850'
        }`}>
          {/* Compass Rose Header */}
          <div className="flex justify-between items-center border-b border-stone-800/10 pb-4">
            <div className="flex items-center gap-2">
              <Compass className="h-5 w-5 text-amber-600 animate-spin" style={{ animationDuration: '25s' }} />
              <span className="text-[10px] font-black tracking-widest uppercase">Specialty Coffee Grid - Brooklyn</span>
            </div>
            <span className="text-[9px] text-stone-500 font-bold uppercase tracking-wider">East River Waterfront</span>
          </div>

          {/* Styled SVG Map Content */}
          <div className="relative w-full h-full flex-grow py-4">
            <svg viewBox="0 0 500 500" className="w-full h-full rounded-2xl bg-stone-900/10 dark:bg-stone-900/25">
              
              {/* East River Path Shape */}
              <path
                d="M -50,450 Q 80,410 120,310 T 210,120 T 260,-50 L -50,-50 Z"
                fill={theme === 'cream' ? '#d9eafd' : '#141c2b'}
                className="transition-colors duration-500"
              />

              {/* Manhattan Island land block */}
              <path
                d="M -50,-50 L 150,-50 L 50,150 L -50,220 Z"
                fill={theme === 'cream' ? '#f5f3ef' : '#111'}
                opacity="0.7"
              />

              {/* Bridges (Brooklyn & Manhattan) */}
              {/* Brooklyn Bridge */}
              <line x1="85" y1="365" x2="160" y2="330" stroke="#777" strokeWidth="3" strokeDasharray="3,3" />
              <text x="110" y="335" transform="rotate(-20 110 335)" fill="#666" fontSize="7" fontWeight="bold" letterSpacing="1">
                BROOKLYN BRIDGE
              </text>

              {/* Manhattan Bridge */}
              <line x1="140" y1="260" x2="220" y2="235" stroke="#777" strokeWidth="3" strokeDasharray="3,3" />
              <text x="160" y="240" transform="rotate(-15 160 240)" fill="#666" fontSize="7" fontWeight="bold" letterSpacing="1">
                MANHATTAN BRIDGE
              </text>

              {/* Williamsburg Bridge */}
              <line x1="210" y1="120" x2="310" y2="90" stroke="#777" strokeWidth="3" strokeDasharray="3,3" />
              <text x="235" y="95" transform="rotate(-15 235 95)" fill="#666" fontSize="7" fontWeight="bold" letterSpacing="1">
                WILLIAMSBURG BRIDGE
              </text>

              {/* Major Roads Grid */}
              <path
                d="M 120,310 L 550,290 M 120,310 Q 200,340 250,550 M 210,120 L 550,110 M 210,120 L 250,400 M 98,400 L 500,410"
                stroke={theme === 'cream' ? 'rgba(0,0,0,0.06)' : 'rgba(255,255,255,0.04)'}
                strokeWidth="4"
                fill="none"
              />

              {/* Neighborhood texts overlay */}
              <text x="140" y="380" fill="#92400e" fontSize="9" fontWeight="bold" opacity="0.6" letterSpacing="1">DUMBO</text>
              <text x="310" y="160" fill="#92400e" fontSize="9" fontWeight="bold" opacity="0.6" letterSpacing="1">WILLIAMSBURG</text>
              <text x="320" y="55" fill="#92400e" fontSize="9" fontWeight="bold" opacity="0.6" letterSpacing="1">GREENPOINT</text>
              <text x="210" y="470" fill="#92400e" fontSize="9" fontWeight="bold" opacity="0.6" letterSpacing="1">PARK SLOPE</text>

              {/* Plot pins with pulsing glowing circles */}
              {LOCATIONS.map((loc) => {
                const isActive = loc.id === activeLocationId;
                const pt = getCoordinates(loc.coordinates.lat, loc.coordinates.lng);
                
                return (
                  <g
                    key={loc.id}
                    onClick={() => setActiveLocationId(loc.id)}
                    className="cursor-pointer group"
                  >
                    {/* Ring highlight aura */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isActive ? "18" : "11"}
                      fill="transparent"
                      stroke="#d97706"
                      strokeWidth="2"
                      strokeDasharray="4,4"
                      className="animate-spin"
                      style={{ animationDuration: isActive ? '10s' : '20s' }}
                    />

                    {/* Glowing outer circle */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isActive ? "9" : "5"}
                      fill="#d97706"
                      opacity={isActive ? "0.4" : "0.25"}
                      className="animate-ping"
                    />

                    {/* Central pin base */}
                    <circle
                      cx={pt.x}
                      cy={pt.y}
                      r={isActive ? "6" : "4.5"}
                      fill={isActive ? "#d97706" : "#451a03"}
                      stroke="#fff"
                      strokeWidth="1.5"
                      className="transition-all duration-300 group-hover:fill-amber-500"
                    />

                    {/* Small tag identifier text on active */}
                    {isActive && (
                      <g transform={`translate(${pt.x - 40}, ${pt.y - 24})`}>
                        <rect width="80" height="15" rx="3" fill="#1c1917" />
                        <text x="40" y="10" fill="#fef3c7" fontSize="7" fontWeight="bold" textAnchor="middle">
                          {loc.neighborhood.toUpperCase()}
                        </text>
                      </g>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Mini active pin details */}
          <div className="flex items-center gap-3 bg-stone-900/5 dark:bg-stone-900 p-3.5 rounded-2xl border border-stone-800/10">
            <CheckCircle className="h-5 w-5 text-emerald-600 flex-shrink-0" />
            <div className="text-left text-[11px]">
              <span className="font-extrabold uppercase tracking-wide block">Active Routing Coordinates:</span>
              <p className="text-stone-400">
                Lat {selectedLocation.coordinates.lat}, Lng {selectedLocation.coordinates.lng} — {selectedLocation.neighborhood} Channel
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
