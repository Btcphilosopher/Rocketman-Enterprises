import React, { useState } from 'react';
import { Star, Eye, Plus, ChevronRight, Check, Sparkles } from 'lucide-react';
import { Product, CartItem } from '../types';
import { PRODUCTS } from '../data';

interface EStoreProps {
  theme: 'cream' | 'industrial';
  addToCart: (item: CartItem) => void;
}

export default function EStore({ theme, addToCart }: EStoreProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [selectedProductOption, setSelectedProductOption] = useState<string>('');

  const categories = [
    { id: 'all', label: 'All Merch' },
    { id: 'beans', label: 'Fresh Coffee Bags' },
    { id: 'subscriptions', label: 'Subscriptions' },
    { id: 'equipment', label: 'Brewing Gear' },
    { id: 'mugs', label: 'Artisan Mugs' },
    { id: 'apparel', label: 'BKW Apparel' }
  ];

  const filteredProducts = selectedCategory === 'all'
    ? PRODUCTS
    : PRODUCTS.filter(prod => prod.category === selectedCategory);

  const openProductDetails = (product: Product) => {
    setActiveProduct(product);
    if (product.options && product.options.length > 0) {
      setSelectedProductOption(product.options[0]);
    } else {
      setSelectedProductOption('Standard Edition');
    }
  };

  const handleAddToCartFromDetails = () => {
    if (!activeProduct) return;

    addToCart({
      id: `store-${activeProduct.id}-${Date.now()}`,
      itemId: activeProduct.id,
      type: 'store',
      name: activeProduct.name,
      price: activeProduct.price,
      quantity: 1,
      imageUrl: activeProduct.imageUrl,
      selectedOption: selectedProductOption
    });

    showTemporaryToast(`Added ${activeProduct.name} (${selectedProductOption}) to bag.`);
    setActiveProduct(null);
  };

  const quickAdd = (product: Product) => {
    const defaultOpt = product.options && product.options.length > 0
      ? product.options[0]
      : 'Standard Edition';

    addToCart({
      id: `store-${product.id}-${Date.now()}`,
      itemId: product.id,
      type: 'store',
      name: product.name,
      price: product.price,
      quantity: 1,
      imageUrl: product.imageUrl,
      selectedOption: defaultOpt
    });

    showTemporaryToast(`Added ${product.name} to bag.`);
  };

  // Toast System
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showTemporaryToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  return (
    <section id="estore-section" className="py-12">
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-amber-50 border border-amber-800/60 px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in uppercase tracking-wider text-xs font-bold">
          <Sparkles className="h-4 w-4 text-amber-500 animate-spin" />
          {toastMessage}
        </div>
      )}

      {/* Merch Category Nav */}
      <div className="flex justify-center mb-12 overflow-x-auto pb-4 px-4 scrollbar-hide">
        <div className="flex gap-2.5 sm:gap-4 whitespace-nowrap">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-3 rounded-xl text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
                selectedCategory === cat.id
                  ? theme === 'cream'
                    ? 'bg-stone-950 text-amber-50 shadow-md'
                    : 'bg-amber-600 text-stone-950 shadow-md font-black'
                  : theme === 'cream'
                  ? 'bg-amber-100/40 text-stone-700 hover:bg-amber-100/80 border border-amber-200/40'
                  : 'bg-stone-900 text-stone-400 hover:bg-stone-850 hover:text-amber-50 border border-stone-800/40'
              }`}
            >
              {cat.id === 'subscriptions' && '☕ '}
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Product Catalog Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {filteredProducts.map((prod) => (
          <div
            key={prod.id}
            className={`group rounded-2xl overflow-hidden border transition-all duration-300 flex flex-col justify-between ${
              theme === 'cream'
                ? 'bg-white border-stone-200/60 hover:shadow-xl hover:border-amber-200/80'
                : 'bg-stone-950 border-stone-800/60 hover:shadow-2xl hover:border-amber-800/40'
            }`}
          >
            {/* Image container */}
            <div className="relative aspect-square overflow-hidden bg-stone-100">
              <img
                src={prod.imageUrl}
                alt={prod.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
                <button
                  onClick={() => openProductDetails(prod)}
                  className="p-3 rounded-xl bg-amber-50 text-stone-950 hover:bg-amber-100 hover:scale-105 transition-all shadow-md cursor-pointer"
                  title="View Details"
                >
                  <Eye className="h-5 w-5" />
                </button>
                <button
                  onClick={() => quickAdd(prod)}
                  className="p-3 rounded-xl bg-amber-600 text-stone-950 hover:bg-amber-500 hover:scale-105 transition-all shadow-md cursor-pointer"
                  title="Quick Add to Bag"
                >
                  <Plus className="h-5 w-5" />
                </button>
              </div>

              {/* Tag Category overlay */}
              <span className={`absolute top-3 left-3 text-[8px] font-black tracking-widest uppercase px-2.5 py-1 rounded-full shadow-sm ${
                theme === 'cream' ? 'bg-amber-50 text-stone-800' : 'bg-stone-900 text-amber-50 border border-stone-800'
              }`}>
                {prod.category}
              </span>
            </div>

            {/* Meta Info */}
            <div className="p-5 flex-grow flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <div className="flex text-amber-500">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          i < Math.floor(prod.rating) ? 'fill-amber-500' : ''
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-[10px] text-stone-500 font-bold">({prod.reviewsCount})</span>
                </div>

                <h3 className="text-sm font-black tracking-wider uppercase leading-snug group-hover:text-amber-600 transition-colors">
                  {prod.name}
                </h3>

                <p className={`mt-2 text-[11px] leading-relaxed line-clamp-2 ${
                  theme === 'cream' ? 'text-stone-500' : 'text-stone-400'
                }`}>
                  {prod.description}
                </p>
              </div>

              <div className="flex items-center justify-between mt-5 pt-3 border-t border-dashed border-stone-800/10">
                <span className="text-base font-bold text-amber-600 font-mono">
                  ${prod.price.toFixed(2)}
                </span>
                <button
                  onClick={() => openProductDetails(prod)}
                  className="text-[10px] font-black tracking-widest uppercase flex items-center gap-1 text-stone-500 hover:text-amber-600 transition-colors cursor-pointer"
                >
                  Configure
                  <ChevronRight className="h-3 w-3" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Immersive Product Details Modal Drawer */}
      {activeProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 backdrop-blur-xs p-4 overflow-y-auto">
          <div className={`w-full max-w-3xl rounded-3xl border overflow-hidden shadow-2xl transition-all duration-300 my-8 ${
            theme === 'cream'
              ? 'bg-amber-50/98 border-amber-100 text-stone-950'
              : 'bg-stone-950 border-stone-850 text-amber-50'
          }`}>
            <div className="flex flex-col md:flex-row">
              {/* Left Image Side */}
              <div className="w-full md:w-1/2 aspect-square md:aspect-auto md:h-[480px] relative bg-stone-900">
                <img
                  src={activeProduct.imageUrl}
                  alt={activeProduct.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
                <span className="absolute top-4 left-4 text-[9px] font-black tracking-widest uppercase bg-amber-600 text-stone-950 px-3 py-1 rounded-full shadow-md">
                  {activeProduct.category}
                </span>
              </div>

              {/* Right Content Details Side */}
              <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between">
                <div>
                  <div className="flex justify-between items-start mb-3">
                    <span className="text-[10px] tracking-widest font-extrabold uppercase text-amber-600">
                      Brooklyn Coffee Works Store
                    </span>
                    <button
                      onClick={() => setActiveProduct(null)}
                      className="p-1 rounded-lg hover:bg-stone-900/10 text-stone-400"
                    >
                      ✕
                    </button>
                  </div>

                  <h3 className="text-xl font-black tracking-wider uppercase leading-tight mb-2">
                    {activeProduct.name}
                  </h3>

                  <div className="flex items-center gap-2 mb-4">
                    <div className="flex text-amber-500">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <Star
                          key={i}
                          className={`h-3.5 w-3.5 ${
                            i < Math.floor(activeProduct.rating) ? 'fill-amber-500' : ''
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-stone-400 font-bold">
                      {activeProduct.rating} rating from {activeProduct.reviewsCount} verified locals
                    </span>
                  </div>

                  <p className={`text-xs leading-relaxed mb-5 ${
                    theme === 'cream' ? 'text-stone-600' : 'text-stone-300'
                  }`}>
                    {activeProduct.description}
                  </p>

                  {/* Bullet Spec Points */}
                  <div className="space-y-1.5 mb-6">
                    <span className="text-[10px] font-bold tracking-widest uppercase text-stone-400 block mb-2">
                      SPECIFICATIONS & ORIGIN
                    </span>
                    {activeProduct.details.map((detail, index) => (
                      <div key={index} className="flex items-start gap-2 text-[10px] leading-relaxed">
                        <span className="text-amber-600 mt-1">✦</span>
                        <p>{detail}</p>
                      </div>
                    ))}
                  </div>

                  {/* Options Choice (Grinds, Sizes, Frequency) */}
                  {activeProduct.options && activeProduct.options.length > 0 && (
                    <div className="mb-6">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-2.5">
                        Choose Option
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {activeProduct.options.map((opt) => (
                          <button
                            key={opt}
                            onClick={() => setSelectedProductOption(opt)}
                            className={`py-2 px-3 rounded-xl text-[10px] font-bold uppercase border transition-all cursor-pointer ${
                              selectedProductOption === opt
                                ? 'border-amber-600 bg-amber-600/10 text-amber-600'
                                : theme === 'cream'
                                ? 'border-stone-200 bg-white text-stone-700 hover:bg-stone-100'
                                : 'border-stone-850 bg-stone-900 text-stone-300 hover:bg-stone-805'
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Pricing & Add block */}
                <div className="pt-4 border-t border-dashed border-stone-800/10 flex items-center justify-between">
                  <div className="text-left">
                    <span className="text-[9px] tracking-widest font-bold uppercase text-stone-400">BAG SUBTOTAL</span>
                    <p className="text-2xl font-black font-mono text-amber-600">
                      ${activeProduct.price.toFixed(2)}
                    </p>
                  </div>
                  <button
                    onClick={handleAddToCartFromDetails}
                    className="flex items-center gap-2 px-6 py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-700 hover:bg-amber-600 text-stone-950 transition-all cursor-pointer"
                  >
                    <Plus className="h-4 w-4" />
                    Add To Bag
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
