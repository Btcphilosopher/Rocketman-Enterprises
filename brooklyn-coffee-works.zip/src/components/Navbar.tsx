import React, { useState } from 'react';
import { Coffee, ShoppingBag, Menu, X, Sun, Moon, CalendarDays, Award } from 'lucide-react';
import { CartItem } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cart: CartItem[];
  toggleCart: () => void;
  theme: 'cream' | 'industrial';
  setTheme: (theme: 'cream' | 'industrial') => void;
  openLoyalty: () => void;
  openReservations: () => void;
}

export default function Navbar({
  activeTab,
  setActiveTab,
  cart,
  toggleCart,
  theme,
  setTheme,
  openLoyalty,
  openReservations,
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'menu', label: 'Menu' },
    { id: 'locations', label: 'Locations' },
    { id: 'events', label: 'Events' },
    { id: 'journal', label: 'Journal' },
    { id: 'shop', label: 'Shop' },
    { id: 'careers', label: 'Careers' },
  ];

  const cartItemsCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const handleLinkClick = (tabId: string) => {
    setActiveTab(tabId);
    setMobileMenuOpen(false);
    // Smooth scroll to top of viewport
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <nav
      id="main-nav"
      className={`sticky top-0 z-50 backdrop-blur-md transition-all duration-300 border-b ${
        theme === 'cream'
          ? 'bg-amber-50/90 text-stone-900 border-amber-100/60 shadow-xs'
          : 'bg-stone-950/90 text-amber-50 border-stone-800/80 shadow-md'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo Brand Typography */}
          <div
            id="brand-logo"
            onClick={() => handleLinkClick('home')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div
              className={`p-2.5 rounded-xl transition-all duration-300 ${
                theme === 'cream'
                  ? 'bg-stone-900 text-amber-50 group-hover:bg-amber-800'
                  : 'bg-amber-800 text-stone-900 group-hover:bg-amber-100'
              }`}
            >
              <Coffee className="h-6 w-6 stroke-[1.8]" />
            </div>
            <div className="flex flex-col">
              <span
                className="font-mono tracking-widest text-xl font-black leading-none uppercase"
                style={{ fontFamily: "'Playfair Display', serif, system-ui" }}
              >
                BROOKLYN
              </span>
              <span className="font-sans text-[10px] tracking-widest font-bold uppercase text-amber-600">
                COFFEE WORKS
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <div id="desktop-links" className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`relative py-2 text-sm font-medium uppercase tracking-widest transition-colors duration-200 ${
                  activeTab === link.id
                    ? 'text-amber-600'
                    : theme === 'cream'
                    ? 'text-stone-700 hover:text-stone-950'
                    : 'text-stone-300 hover:text-amber-50'
                }`}
              >
                {link.label}
                {activeTab === link.id && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-amber-600 rounded-full animate-fade-in" />
                )}
              </button>
            ))}
          </div>

          {/* Right Action Utilities (Loyalty, Booking, Cart, Theme, Hamburger) */}
          <div id="nav-utilities" className="flex items-center gap-2 sm:gap-4">
            {/* Theme Toggle Button */}
            <button
              id="theme-toggle-btn"
              onClick={() => setTheme(theme === 'cream' ? 'industrial' : 'cream')}
              className={`p-2 rounded-lg transition-colors duration-200 cursor-pointer ${
                theme === 'cream'
                  ? 'hover:bg-amber-100 text-stone-700 hover:text-stone-900'
                  : 'hover:bg-stone-800 text-stone-300 hover:text-amber-50'
              }`}
              title={theme === 'cream' ? 'Switch to Industrial Dark' : 'Switch to Editorial Cream'}
            >
              {theme === 'cream' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </button>

            {/* Loyalty Portal Trigger */}
            <button
              id="loyalty-trigger-btn"
              onClick={openLoyalty}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold tracking-wider uppercase transition-all duration-300 cursor-pointer ${
                theme === 'cream'
                  ? 'border-amber-200 hover:border-amber-500 bg-amber-100/50 hover:bg-amber-100 text-stone-700'
                  : 'border-stone-800 hover:border-amber-800 bg-stone-900/50 hover:bg-stone-900 text-amber-100'
              }`}
            >
              <Award className="h-4 w-4 text-amber-600" />
              Rewards
            </button>

            {/* Table Booking Trigger */}
            <button
              id="book-table-trigger"
              onClick={openReservations}
              className={`hidden lg:flex items-center gap-1.5 px-3-5 py-2 rounded-lg text-xs font-semibold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
                theme === 'cream'
                  ? 'bg-stone-900 hover:bg-amber-900 text-amber-50'
                  : 'bg-amber-700 hover:bg-amber-600 text-stone-950 font-bold'
              }`}
            >
              <CalendarDays className="h-4 w-4" />
              Book Table
            </button>

            {/* Cart Bag Trigger */}
            <button
              id="cart-trigger-btn"
              onClick={toggleCart}
              className={`relative p-2.5 rounded-xl transition-all duration-200 cursor-pointer ${
                theme === 'cream'
                  ? 'bg-stone-900 text-amber-50 hover:bg-amber-950'
                  : 'bg-amber-700 text-stone-950 hover:bg-amber-600 font-bold'
              }`}
            >
              <ShoppingBag className="h-5 w-5" />
              {cartItemsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 h-5 w-5 flex items-center justify-center rounded-full text-[10px] font-black bg-amber-600 text-white animate-bounce">
                  {cartItemsCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              id="mobile-hamburger"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`md:hidden p-2 rounded-lg transition-colors cursor-pointer ${
                theme === 'cream'
                  ? 'hover:bg-amber-100 text-stone-800'
                  : 'hover:bg-stone-800 text-stone-100'
              }`}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div
          id="mobile-drawer"
          className={`md:hidden border-t py-4 px-6 space-y-3 transition-all duration-300 ${
            theme === 'cream' ? 'bg-amber-50/95 border-amber-100' : 'bg-stone-950/95 border-stone-800'
          }`}
        >
          <div className="flex flex-col space-y-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`w-full text-left py-2.5 px-3 rounded-lg text-sm font-semibold uppercase tracking-widest transition-colors ${
                  activeTab === link.id
                    ? 'bg-amber-600/10 text-amber-600'
                    : theme === 'cream'
                    ? 'text-stone-700 hover:bg-amber-100/50 hover:text-stone-900'
                    : 'text-stone-300 hover:bg-stone-900 hover:text-amber-50'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-dashed border-stone-800 flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openLoyalty();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg text-sm font-bold tracking-widest uppercase border border-amber-600/30 text-amber-600 bg-amber-600/5 hover:bg-amber-600/10"
            >
              <Award className="h-4 w-4" />
              Check Rewards Balance
            </button>

            <button
              onClick={() => {
                setMobileMenuOpen(false);
                openReservations();
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg text-sm font-bold tracking-widest uppercase bg-stone-900 text-amber-50 hover:bg-amber-900"
            >
              <CalendarDays className="h-4 w-4" />
              Reservations
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
