import React, { useState } from 'react';
import { ShoppingBag, Trash2, Plus, Minus, ArrowRight, Printer, CheckCircle, Ticket } from 'lucide-react';
import { CartItem } from '../types';
import { LOCATIONS } from '../data';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  updateQuantity: (id: string, delta: number) => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
  theme: 'cream' | 'industrial';
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  updateQuantity,
  removeItem,
  clearCart,
  theme,
}: CartDrawerProps) {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'details' | 'receipt'>('cart');
  const [customerName, setCustomerName] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [orderType, setOrderType] = useState<'pickup' | 'delivery'>('pickup');
  const [pickupLocation, setPickupLocation] = useState(LOCATIONS[0].id);
  const [shippingAddress, setShippingAddress] = useState('');
  const [receiptNumber, setReceiptNumber] = useState('');

  if (!isOpen) return null;

  const subtotal = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const tax = subtotal * 0.08875; // NYC Sales Tax 8.875%
  const deliveryFee = orderType === 'delivery' ? 4.99 : 0;
  const total = subtotal + tax + deliveryFee;
  const loyaltyPointsEarned = Math.floor(subtotal * 10);

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerEmail) return;

    // Generate random mock receipt info
    const randomReceiptNum = `BKW-${Math.floor(100000 + Math.random() * 900000)}`;
    setReceiptNumber(randomReceiptNum);
    setCheckoutStep('receipt');
  };

  const handleFinaliseOrder = () => {
    clearCart();
    setCheckoutStep('cart');
    setCustomerName('');
    setCustomerEmail('');
    setShippingAddress('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-950/80 backdrop-blur-xs">
      {/* Click outside backdrop to close */}
      <div className="absolute inset-0 cursor-pointer" onClick={onClose} />

      {/* Slider Drawer Panel */}
      <div className={`relative w-full max-w-md h-full flex flex-col justify-between shadow-2xl transition-all duration-300 border-l ${
        theme === 'cream'
          ? 'bg-amber-50/98 border-amber-100 text-stone-950'
          : 'bg-stone-950 border-stone-850 text-amber-50'
      }`}>
        
        {/* Header Block */}
        <div className="p-6 border-b border-stone-800/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="h-5 w-5 text-amber-600" />
            <h3 className="text-base font-black tracking-widest uppercase">Your BKW Bag</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-900/10 text-stone-400 text-sm font-bold"
          >
            ✕ CLOSE
          </button>
        </div>

        {/* Dynamic Inner Step Render */}
        <div className="flex-grow overflow-y-auto p-6 scrollbar-hide">
          {checkoutStep === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center py-12">
                  <div className="p-5 bg-amber-100/30 rounded-full text-stone-400 mb-4 animate-pulse">
                    <ShoppingBag className="h-10 w-10" />
                  </div>
                  <h4 className="text-sm font-bold uppercase tracking-widest text-stone-400 mb-1">
                    Your bag is empty
                  </h4>
                  <p className="text-xs text-stone-500 max-w-xs leading-relaxed">
                    Select artisan roasts, handcrafted teas, or signature lattes from our digital menu or estore.
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      className={`flex gap-4 p-3 rounded-xl border transition-all ${
                        theme === 'cream'
                          ? 'bg-white border-stone-200/50'
                          : 'bg-stone-900/40 border-stone-850'
                      }`}
                    >
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded-lg object-cover bg-stone-200"
                      />
                      <div className="flex-grow flex flex-col justify-between">
                        <div>
                          <div className="flex justify-between items-start">
                            <h4 className="text-xs font-black uppercase tracking-wider line-clamp-1">
                              {item.name}
                            </h4>
                            <button
                              onClick={() => removeItem(item.id)}
                              className="text-stone-400 hover:text-red-500 p-0.5"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                          <p className="text-[9px] text-stone-400 font-semibold uppercase mt-0.5">
                            {item.selectedOption || 'Standard Edition'}
                          </p>
                        </div>

                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs font-bold text-amber-600 font-mono">
                            ${(item.price * item.quantity).toFixed(2)}
                          </span>

                          <div className="flex items-center gap-1.5 border border-stone-800/10 rounded-lg px-2 py-1">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="p-0.5 hover:text-amber-600 text-stone-400"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="text-xs font-black px-1 font-mono">{item.quantity}</span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="p-0.5 hover:text-amber-600 text-stone-400"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {checkoutStep === 'details' && (
            <form onSubmit={handleCheckoutSubmit} className="space-y-5">
              <span className="text-[10px] tracking-widest font-black uppercase text-amber-600">Checkout Specifications</span>
              <h4 className="text-lg font-black tracking-wider uppercase">Contact & Hand-off</h4>
              
              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Your Full Name</label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. Eleanor Vance"
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Email Address</label>
                <input
                  type="email"
                  required
                  value={customerEmail}
                  onChange={(e) => setCustomerEmail(e.target.value)}
                  placeholder="eleanor@williamsburgcreative.co"
                  className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                />
              </div>

              <div>
                <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-2">Order Pickup Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setOrderType('pickup')}
                    className={`py-2.5 rounded-xl text-xs font-bold uppercase border ${
                      orderType === 'pickup'
                        ? 'border-amber-600 bg-amber-600/10 text-amber-600 font-extrabold'
                        : 'border-stone-800/10 hover:bg-stone-900/5'
                    }`}
                  >
                    Café Pickup
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType('delivery')}
                    className={`py-2.5 rounded-xl text-xs font-bold uppercase border ${
                      orderType === 'delivery'
                        ? 'border-amber-600 bg-amber-600/10 text-amber-600 font-extrabold'
                        : 'border-stone-800/10 hover:bg-stone-900/5'
                    }`}
                  >
                    Local Courier
                  </button>
                </div>
              </div>

              {orderType === 'pickup' ? (
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Select Café Location</label>
                  <select
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-white dark:bg-stone-900 focus:outline-hidden focus:border-amber-600 font-semibold"
                  >
                    {LOCATIONS.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {loc.name} - {loc.address}
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div>
                  <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Delivery Address (NYC Only)</label>
                  <textarea
                    required
                    value={shippingAddress}
                    onChange={(e) => setShippingAddress(e.target.value)}
                    placeholder="234 Bedford Ave, Apt 3B, Brooklyn, NY 11249"
                    rows={3}
                    className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                  />
                </div>
              )}

              <div className="pt-4 border-t border-dashed border-stone-850">
                <button
                  type="submit"
                  className="w-full py-4 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-700 hover:bg-amber-600 text-stone-950 flex items-center justify-center gap-2 cursor-pointer"
                >
                  Confirm Order & Generate Ticket
                  <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </form>
          )}

          {checkoutStep === 'receipt' && (
            <div className="space-y-6 text-stone-950">
              {/* Paper Vintage Ticket Design */}
              <div id="vintage-ticket" className="bg-amber-100/70 border-2 border-stone-900/90 rounded-2xl p-6 shadow-md relative overflow-hidden font-mono text-xs">
                {/* Visual barcode cutout circles */}
                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-3.5 w-8 bg-stone-950 dark:bg-stone-950 rounded-b-md" />
                
                <div className="text-center pb-4 border-b border-dashed border-stone-900/40">
                  <h5 className="font-extrabold text-sm uppercase tracking-wider">BROOKLYN COFFEE WORKS</h5>
                  <p className="text-[9px] text-stone-500 uppercase">EST. 2012 / BROOKLYN NY</p>
                  <p className="text-[10px] text-stone-800 mt-2 font-black">{receiptNumber}</p>
                </div>

                <div className="py-4 border-b border-dashed border-stone-900/40 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-stone-500">CUSTOMER:</span>
                    <span className="font-bold">{customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">TYPE:</span>
                    <span className="font-bold uppercase">{orderType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">ROUTING:</span>
                    <span className="font-bold uppercase text-right max-w-[180px] truncate">
                      {orderType === 'pickup' 
                        ? LOCATIONS.find(l => l.id === pickupLocation)?.name 
                        : shippingAddress}
                    </span>
                  </div>
                </div>

                {/* Ordered Items List */}
                <div className="py-4 border-b border-dashed border-stone-900/40 space-y-2 max-h-[140px] overflow-y-auto pr-1">
                  {cart.map((item) => (
                    <div key={item.id} className="flex justify-between text-[11px]">
                      <span>
                        {item.quantity}x {item.name}
                        <span className="block text-[9px] text-stone-500 normal-case">
                          {item.selectedOption}
                        </span>
                      </span>
                      <span className="font-bold font-mono">${(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>

                {/* Sum Ledger */}
                <div className="py-4 space-y-1.5 border-b border-stone-900">
                  <div className="flex justify-between text-[11px]">
                    <span>SUBTOTAL</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-[11px]">
                    <span>NY SALES TAX (8.875%)</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  {orderType === 'delivery' && (
                    <div className="flex justify-between text-[11px]">
                      <span>COURIER SURCHARGE</span>
                      <span>$4.99</span>
                    </div>
                  )}
                  <div className="flex justify-between text-xs font-black pt-1">
                    <span>TOTAL AMOUNT</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="pt-4 text-center">
                  <div className="flex items-center justify-center gap-1.5 text-emerald-800 text-[10px] font-bold uppercase mb-2">
                    <CheckCircle className="h-4 w-4 stroke-[2.5]" />
                    ESTIMATED TIME: 15 MINS
                  </div>
                  <p className="text-[9px] text-stone-500 max-w-[220px] mx-auto leading-relaxed">
                    Show this virtual docket on your device to the barista at pickup or check courier tracking in your inbox.
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  onClick={() => window.print()}
                  className="w-full py-3 rounded-xl text-xs font-bold border-2 border-stone-900/80 hover:bg-stone-900/5 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Printer className="h-4 w-4" />
                  Print Receipt Slip
                </button>
                <button
                  onClick={handleFinaliseOrder}
                  className="w-full py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-emerald-700 hover:bg-emerald-600 text-white flex items-center justify-center gap-2 cursor-pointer"
                >
                  Done & Close Order
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Ledger Summary and CTA footer */}
        {checkoutStep !== 'receipt' && cart.length > 0 && (
          <div className="p-6 border-t border-stone-800/10">
            <div className="space-y-2 mb-6">
              <div className="flex justify-between text-xs font-bold text-stone-500">
                <span>Loyalty Points Accumulated</span>
                <span className="text-amber-600 flex items-center gap-1">
                  <Ticket className="h-3.5 w-3.5" />
                  +{loyaltyPointsEarned} pts
                </span>
              </div>
              <div className="flex justify-between text-sm font-semibold">
                <span>Subtotal</span>
                <span className="font-mono">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-xs text-stone-400">
                <span>Sales Tax & Surcharges</span>
                <span className="font-mono">Calculated at Hand-off</span>
              </div>
            </div>

            {checkoutStep === 'cart' ? (
              <button
                onClick={() => setCheckoutStep('details')}
                className="w-full py-4 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-700 hover:bg-amber-600 text-stone-950 flex items-center justify-center gap-2 cursor-pointer"
              >
                Proceed to Checkout
                <ArrowRight className="h-4 w-4" />
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setCheckoutStep('cart')}
                className="w-full py-3 rounded-xl text-xs font-bold border border-stone-800/20 text-stone-400 hover:text-stone-300 hover:bg-stone-900/10 cursor-pointer"
              >
                ← Back to Bag Review
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
