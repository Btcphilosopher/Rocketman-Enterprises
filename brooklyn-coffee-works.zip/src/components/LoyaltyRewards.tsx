import React, { useState } from 'react';
import { Award, Search, Check, Sparkles, QrCode, Ticket, ArrowRight } from 'lucide-react';

interface LoyaltyRewardsProps {
  theme: 'cream' | 'industrial';
  onClose: () => void;
}

export default function LoyaltyRewards({ theme, onClose }: LoyaltyRewardsProps) {
  const [emailQuery, setEmailQuery] = useState('');
  const [pointsBalance, setPointsBalance] = useState<number | null>(null);
  const [searched, setSearched] = useState(false);
  const [memberName, setMemberName] = useState('');
  
  // Sign up state
  const [isSignUp, setIsSignUp] = useState(false);
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');

  // Voucher redeem state
  const [redeemedVoucher, setRedeemedVoucher] = useState<any | null>(null);

  // Preloaded mock accounts to make the experience real
  const MOCK_ACCOUNTS: Record<string, { name: string; points: number }> = {
    'tom@ahyx.org': { name: 'Tom Ahyx', points: 420 },
    'david@local.com': { name: 'David Choi', points: 180 },
    'eleanor@creative.co': { name: 'Eleanor Vance', points: 850 },
    'sarah@dumbo.com': { name: 'Sarah Jenkins', points: 95 }
  };

  const handleLookup = (e: React.FormEvent) => {
    e.preventDefault();
    const query = emailQuery.trim().toLowerCase();
    
    if (MOCK_ACCOUNTS[query]) {
      setPointsBalance(MOCK_ACCOUNTS[query].points);
      setMemberName(MOCK_ACCOUNTS[query].name);
    } else {
      setPointsBalance(0);
      setMemberName('Guest Member');
    }
    setSearched(true);
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!signUpName || !signUpEmail) return;

    // Simulate signup with 50 bonus points
    setMemberName(signUpName);
    setPointsBalance(50);
    setEmailQuery(signUpEmail);
    setSearched(true);
    setIsSignUp(false);
    showTemporaryToast(`Welcome! 50 bonus points loaded onto your new digital card.`);
  };

  const redeemableRewards = [
    { id: 'r1', name: 'Free Double Shot Cortado', cost: 100, desc: 'Freshly pulled single-origin or Williamsburg signature espresso with velvety microfoam.' },
    { id: 'r2', name: 'Artisan BKW Concrete-Gray Mug', cost: 250, desc: 'Handcrafted stoneware mug custom fired by local Williamsburg pottery works.' },
    { id: 'r3', name: 'Williamsburg Signature Blend Bag (12oz)', cost: 350, desc: 'Freshly roasted bag of our award-winning medium-dark espresso beans.' },
    { id: 'r4', name: 'Precision Matte Gooseneck Kettle', cost: 750, desc: 'Durable culinary stainless steel gooseneck kettle for precision hot-water flow.' }
  ];

  const handleRedeem = (reward: any) => {
    if (pointsBalance === null || pointsBalance < reward.cost) return;

    const remainingPoints = pointsBalance - reward.cost;
    setPointsBalance(remainingPoints);

    // Generate random validation token
    const token = `BKW-LOY-${Math.floor(10000 + Math.random() * 90000)}`;

    setRedeemedVoucher({
      title: reward.name,
      pointsSpent: reward.cost,
      token,
      expiryDate: 'September 1, 2026'
    });
  };

  // Toast System
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showTemporaryToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Calculate tier details
  const getTierDetails = (points: number) => {
    if (points >= 600) return { name: 'Platinum Co-op', color: 'text-stone-400 border-stone-300', nextTier: 'Max Tier reached!' };
    if (points >= 300) return { name: 'Gold Brewmaster', color: 'text-amber-500 border-amber-500', nextTier: `${600 - points} points to Platinum` };
    if (points >= 100) return { name: 'Silver Demitasse', color: 'text-zinc-400 border-zinc-400', nextTier: `${300 - points} points to Gold` };
    return { name: 'Bronze Crema', color: 'text-amber-700 border-amber-800', nextTier: `${100 - points} points to Silver` };
  };

  const tier = pointsBalance !== null ? getTierDetails(pointsBalance) : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 backdrop-blur-xs p-4 overflow-y-auto">
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-amber-50 border border-amber-800/60 px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in uppercase tracking-wider text-xs font-bold">
          <Sparkles className="h-4 w-4 text-amber-500 animate-spin" />
          {toastMessage}
        </div>
      )}

      <div className={`w-full max-w-xl rounded-3xl border overflow-hidden shadow-2xl transition-all duration-300 my-8 ${
        theme === 'cream'
          ? 'bg-amber-50/98 border-amber-100 text-stone-950'
          : 'bg-stone-950 border-stone-850 text-amber-50'
      }`}>
        
        {/* Header bar */}
        <div className="p-6 border-b border-stone-800/10 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Award className="h-5.5 w-5.5 text-amber-600 animate-pulse" />
            <h3 className="text-lg font-black tracking-wider uppercase">BKW Loyalty Club</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-stone-900/10 text-stone-400 font-bold text-sm"
          >
            ✕
          </button>
        </div>

        {/* Content body */}
        <div className="p-6 sm:p-8 max-h-[75vh] overflow-y-auto scrollbar-hide">
          {redeemedVoucher ? (
            /* Redeeemed Voucher Slip Page */
            <div className="space-y-6 text-stone-950 text-center">
              <div className="bg-amber-100 border-2 border-stone-950 rounded-2xl p-6 shadow-md relative font-mono text-xs max-w-sm mx-auto">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 h-3.5 w-8 bg-stone-950 rounded-b-md" />
                
                <div className="pb-4 border-b border-dashed border-stone-900/40">
                  <span className="text-[8px] font-black tracking-widest text-amber-850 uppercase">Loyalty Reward Certificate</span>
                  <h4 className="text-sm font-black uppercase mt-1 leading-snug">{redeemedVoucher.title}</h4>
                  <p className="text-[10px] text-emerald-800 font-bold mt-2">-[ REWARDS DOCK STATUS: ACTIVE ]-</p>
                </div>

                <div className="py-5 space-y-3 text-left">
                  <div className="flex justify-between">
                    <span>COUPON CODE:</span>
                    <span className="font-bold">{redeemedVoucher.token}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>VOUCHER VALUE:</span>
                    <span className="font-bold">-${redeemedVoucher.pointsSpent} PTS</span>
                  </div>
                  <div className="flex justify-between">
                    <span>VALID UNTIL:</span>
                    <span className="font-bold">{redeemedVoucher.expiryDate}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-dashed border-stone-900/40 flex flex-col items-center">
                  <QrCode className="h-28 w-28 text-stone-905 stroke-[1.2] mb-3" />
                  <p className="text-[9px] text-stone-500 max-w-[200px] leading-relaxed">
                    Scan this digital ticket at any Williamsburg, DUMBO, Greenpoint, or Park Slope checkout counter to claim your reward.
                  </p>
                </div>
              </div>

              <button
                onClick={() => setRedeemedVoucher(null)}
                className="w-full max-w-sm mx-auto py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-emerald-700 hover:bg-emerald-600 text-white flex items-center justify-center cursor-pointer"
              >
                Return to Club Hub
              </button>
            </div>
          ) : !searched ? (
            /* Initial entry search or register view */
            <div className="space-y-6">
              {!isSignUp ? (
                <>
                  <div className="text-center max-w-sm mx-auto space-y-2">
                    <p className="text-xs text-stone-400 leading-relaxed">
                      Collect points on every whole bean subscription, espresso shot, or sourdough bun. Redeem your points for exclusive artisan mugs or premium bags.
                    </p>
                  </div>

                  <form onSubmit={handleLookup} className="space-y-4">
                    <div>
                      <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">
                        Lookup Loyalty Account Email
                      </label>
                      <div className="flex gap-2">
                        <div className="relative flex-grow">
                          <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-stone-400" />
                          <input
                            type="email"
                            required
                            value={emailQuery}
                            onChange={(e) => setEmailQuery(e.target.value)}
                            placeholder="e.g. tom@ahyx.org or david@local.com"
                            className="w-full pl-10 pr-3.5 py-3 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                          />
                        </div>
                        <button
                          type="submit"
                          className="px-5 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-900 hover:bg-amber-900 text-amber-50 cursor-pointer"
                        >
                          Check
                        </button>
                      </div>
                    </div>
                  </form>

                  <div className="pt-6 border-t border-dashed border-stone-850 flex flex-col items-center gap-3">
                    <span className="text-[9px] font-bold tracking-widest text-stone-400 uppercase">New to Brooklyn Coffee Works?</span>
                    <button
                      onClick={() => setIsSignUp(true)}
                      className="text-xs font-black text-amber-600 hover:text-amber-500 flex items-center gap-1 cursor-pointer"
                    >
                      Create Loyalty Account (Get 50 points free)
                      <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </>
              ) : (
                /* Register Form */
                <form onSubmit={handleSignUpSubmit} className="space-y-5">
                  <span className="text-[10px] tracking-widest font-black uppercase text-amber-600">Rewards Registration</span>
                  <h4 className="text-lg font-black tracking-wider uppercase">Join the BKW Club</h4>
                  
                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Full Name</label>
                    <input
                      type="text"
                      required
                      value={signUpName}
                      onChange={(e) => setSignUpName(e.target.value)}
                      placeholder="Eleanor Vance"
                      className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold uppercase tracking-widest text-stone-400 block mb-1.5">Email Address</label>
                    <input
                      type="email"
                      required
                      value={signUpEmail}
                      onChange={(e) => setSignUpEmail(e.target.value)}
                      placeholder="eleanor@vance.com"
                      className="w-full px-3.5 py-2.5 rounded-xl text-xs border border-stone-800/10 bg-stone-900/5 focus:outline-hidden focus:border-amber-600 font-semibold"
                    />
                  </div>

                  <div className="flex items-center gap-2 py-2">
                    <input type="checkbox" required id="loyalty-terms" className="h-4 w-4 border-stone-800/20 text-amber-600 rounded" />
                    <label htmlFor="loyalty-terms" className="text-[10px] text-stone-400 leading-snug">
                      I agree to receive automated specialty coffee recipes, micro-lot alerts, and birthday coupon codes.
                    </label>
                  </div>

                  <div className="pt-4 border-t border-dashed border-stone-850 flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsSignUp(false)}
                      className="flex-1 py-3.5 rounded-xl text-xs font-bold uppercase border"
                    >
                      Back to Lookup
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-3.5 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-700 hover:bg-amber-600 text-stone-950"
                    >
                      Claim Sign-up Points
                    </button>
                  </div>
                </form>
              )}
            </div>
          ) : (
            /* Searched Profile Dashboard and Reward Exchange list */
            <div className="space-y-8">
              {/* Profile card with points indicator wheel */}
              <div className={`p-6 rounded-2xl border flex flex-col sm:flex-row items-center justify-between gap-6 ${
                theme === 'cream' ? 'bg-white border-amber-100' : 'bg-stone-900/40 border-stone-850'
              }`}>
                <div className="space-y-1.5 text-center sm:text-left">
                  <span className="text-[9px] font-black tracking-widest uppercase text-amber-600">LOYALTY MEMBER STATUS</span>
                  <h4 className="text-lg font-black uppercase tracking-wider">{memberName}</h4>
                  <p className="text-xs text-stone-400 leading-none">Club ID: BKW-{(emailQuery.length * 25) || 5412}</p>
                  
                  <div className="pt-3">
                    <span className={`inline-block text-[9px] font-extrabold tracking-widest uppercase px-3 py-1 rounded-full border ${tier?.color}`}>
                      {tier?.name}
                    </span>
                    <p className="text-[10px] text-stone-500 mt-1.5">{tier?.nextTier}</p>
                  </div>
                </div>

                {/* Circular graphical progress bar */}
                <div className="relative h-28 w-28 flex-shrink-0 flex items-center justify-center">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="56" cy="56" r="48" strokeWidth="6" stroke="#2a2522" fill="transparent" />
                    <circle
                      cx="56"
                      cy="56"
                      r="48"
                      strokeWidth="6"
                      stroke="#d97706"
                      fill="transparent"
                      strokeDasharray="301.6"
                      strokeDashoffset={301.6 - (301.6 * Math.min(pointsBalance || 0, 1000)) / 1000}
                    />
                  </svg>
                  <div className="absolute flex flex-col items-center justify-center">
                    <span className="text-2xl font-black font-mono leading-none">{pointsBalance}</span>
                    <span className="text-[9px] font-bold text-stone-400 uppercase tracking-widest">PTS</span>
                  </div>
                </div>
              </div>

              {/* Rewards Swap Shop */}
              <div>
                <span className="text-[10px] font-black tracking-widest text-stone-400 block mb-4 uppercase">
                  REWARDS MARKETPLACE: REDEEM YOUR POINTS
                </span>

                <div className="space-y-3">
                  {redeemableRewards.map((reward) => {
                    const canAfford = pointsBalance !== null && pointsBalance >= reward.cost;
                    return (
                      <div
                        key={reward.id}
                        className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
                          theme === 'cream' ? 'bg-white border-stone-100' : 'bg-stone-900/20 border-stone-850'
                        }`}
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <Ticket className="h-4 w-4 text-amber-600 flex-shrink-0" />
                            <h5 className="text-xs font-black uppercase tracking-wider">{reward.name}</h5>
                          </div>
                          <p className="text-[10px] text-stone-400 leading-relaxed max-w-sm">{reward.desc}</p>
                        </div>

                        <button
                          onClick={() => handleRedeem(reward)}
                          disabled={!canAfford}
                          className={`px-4 py-2.5 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all cursor-pointer ${
                            canAfford
                              ? 'bg-amber-600 hover:bg-amber-500 text-stone-950 font-black shadow-md'
                              : 'bg-stone-900/50 text-stone-500 border border-stone-850 cursor-not-allowed'
                          }`}
                        >
                          Exchange - {reward.cost} pts
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Reset search */}
              <div className="pt-4 border-t border-dashed border-stone-850 text-center">
                <button
                  onClick={() => {
                    setSearched(false);
                    setPointsBalance(null);
                  }}
                  className="text-[10px] font-bold text-stone-400 hover:text-amber-600 uppercase tracking-widest"
                >
                  ← Switch Loyalty Account
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
