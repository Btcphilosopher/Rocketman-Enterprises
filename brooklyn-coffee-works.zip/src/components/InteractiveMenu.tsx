import React, { useState } from 'react';
import { Info, Plus, ChevronDown, Check, Sparkles } from 'lucide-react';
import { MenuItem, CartItem } from '../types';
import { MENU_ITEMS } from '../data';

interface InteractiveMenuProps {
  theme: 'cream' | 'industrial';
  addToCart: (item: CartItem) => void;
}

export default function InteractiveMenu({ theme, addToCart }: InteractiveMenuProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedNutritionalId, setExpandedNutritionalId] = useState<string | null>(null);
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [selectedMilk, setSelectedMilk] = useState<string>('Oat Milk (+$0.75)');
  const [extraShot, setExtraShot] = useState<boolean>(false);
  const [syrupFlavor, setSyrupFlavor] = useState<string>('None');

  const categories = [
    { id: 'all', label: 'All Offerings' },
    { id: 'espresso', label: 'Espresso Bar' },
    { id: 'coffee', label: 'Slow Bar & Brews' },
    { id: 'tea', label: 'Ceremonial Teas' },
    { id: 'pastries', label: 'Fresh Pastries' },
    { id: 'sandwiches', label: 'Heirloom Sandwiches' },
    { id: 'seasonal', label: 'Seasonal Specials' }
  ];

  const filteredItems = selectedCategory === 'all'
    ? MENU_ITEMS
    : MENU_ITEMS.filter(item => item.category === selectedCategory);

  const startCustomizing = (item: MenuItem) => {
    // Determine if customizable (drinks are highly customizable, food is simpler)
    if (['espresso', 'coffee', 'tea', 'seasonal'].includes(item.category)) {
      setCustomizingItem(item);
      setSelectedMilk('Oat Milk (+$0.75)');
      setExtraShot(false);
      setSyrupFlavor('None');
    } else {
      // Just add directly
      addToCart({
        id: `menu-${item.id}-${Date.now()}`,
        itemId: item.id,
        type: 'menu',
        name: item.name,
        price: item.price,
        quantity: 1,
        imageUrl: item.imageUrl,
        selectedOption: 'Standard Recipe'
      });
      showTemporaryToast(`Added ${item.name} to order.`);
    }
  };

  const handleConfirmCustomization = () => {
    if (!customizingItem) return;

    let extraCost = 0;
    const notes: string[] = [];

    if (customizingItem.category !== 'tea') {
      if (selectedMilk.includes('Oat Milk') || selectedMilk.includes('Almond Milk')) {
        extraCost += 0.75;
        notes.push(selectedMilk.split(' (')[0]);
      } else {
        notes.push('Whole Milk');
      }
    }

    if (extraShot) {
      extraCost += 1.00;
      notes.push('Extra Espresso Shot');
    }

    if (syrupFlavor !== 'None') {
      extraCost += 0.50;
      notes.push(`${syrupFlavor} Syrup`);
    }

    const finalOption = notes.length > 0 ? notes.join(', ') : 'Standard Recipe';

    addToCart({
      id: `menu-${customizingItem.id}-${Date.now()}`,
      itemId: customizingItem.id,
      type: 'menu',
      name: customizingItem.name,
      price: customizingItem.price + extraCost,
      quantity: 1,
      imageUrl: customizingItem.imageUrl,
      selectedOption: finalOption
    });

    showTemporaryToast(`Added ${customizingItem.name} (${finalOption}) to order.`);
    setCustomizingItem(null);
  };

  // Toast Notification System
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const showTemporaryToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  return (
    <section id="interactive-menu-section" className="py-12">
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-amber-50 border border-amber-800/60 px-5 py-3.5 rounded-xl shadow-2xl flex items-center gap-3 animate-fade-in uppercase tracking-wider text-xs font-bold">
          <Sparkles className="h-4 w-4 text-amber-500 animate-spin" />
          {toastMessage}
        </div>
      )}

      {/* Categories Horizontal Scrolling Nav */}
      <div className="flex justify-center mb-12 overflow-x-auto pb-4 px-4 scrollbar-hide">
        <div className="flex gap-2.5 sm:gap-4 whitespace-nowrap">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 py-3 rounded-xl text-xs font-bold tracking-widest uppercase transition-all duration-300 cursor-pointer ${
                selectedCategory === cat.id
                  ? theme === 'cream'
                    ? 'bg-stone-950 text-amber-50 shadow-md'
                    : 'bg-amber-600 text-stone-950 shadow-md font-black'
                  : theme === 'cream'
                  ? 'bg-amber-100/40 text-stone-700 hover:bg-amber-100/80 border border-amber-200/40'
                  : 'bg-stone-900 text-stone-400 hover:bg-stone-850 hover:text-amber-50 border border-stone-800/40'
              }`}
            >
              {cat.id === 'seasonal' && '✨ '}
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {filteredItems.map((item) => (
          <div
            key={item.id}
            className={`flex flex-col sm:flex-row gap-5 p-5 rounded-2xl border transition-all duration-300 ${
              theme === 'cream'
                ? 'bg-white border-stone-200/60 hover:shadow-xl hover:border-amber-200/80'
                : 'bg-stone-950 border-stone-800/60 hover:shadow-2xl hover:border-amber-800/40'
            }`}
          >
            {/* Food or Drink Image */}
            <div className="relative w-full sm:w-36 h-36 flex-shrink-0 rounded-xl overflow-hidden group">
              <img
                src={item.imageUrl}
                alt={item.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
              />
              {item.isSeasonal && (
                <div className="absolute top-2 left-2 bg-amber-600 text-stone-950 font-bold tracking-widest text-[9px] uppercase px-2 py-0.5 rounded-full shadow-md">
                  Seasonal
                </div>
              )}
            </div>

            {/* Content info */}
            <div className="flex flex-col justify-between flex-grow">
              <div>
                <div className="flex items-start justify-between">
                  <h3 className="text-lg font-black tracking-wide uppercase leading-snug">
                    {item.name}
                  </h3>
                  <span className="text-base font-bold text-amber-600 font-mono">
                    ${item.price.toFixed(2)}
                  </span>
                </div>

                <p className={`mt-2 text-xs leading-relaxed ${
                  theme === 'cream' ? 'text-stone-600' : 'text-stone-400'
                }`}>
                  {item.description}
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 mt-3">
                  {item.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className={`text-[9px] tracking-widest font-bold uppercase px-2.5 py-0.5 rounded-full ${
                        theme === 'cream'
                          ? 'bg-amber-100/60 text-stone-700'
                          : 'bg-stone-900 text-stone-400'
                      }`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons & Expandable Nutritional Specs */}
              <div className="flex items-center justify-between mt-5 pt-3 border-t border-dashed border-stone-800/10">
                <button
                  onClick={() => setExpandedNutritionalId(expandedNutritionalId === item.id ? null : item.id)}
                  className={`flex items-center gap-1.5 text-[10px] font-bold tracking-wider uppercase transition-colors cursor-pointer ${
                    theme === 'cream'
                      ? 'text-stone-500 hover:text-stone-950'
                      : 'text-stone-500 hover:text-amber-50'
                  }`}
                >
                  <Info className="h-3.5 w-3.5" />
                  Specs
                  <ChevronDown className={`h-3 w-3 transition-transform duration-200 ${
                    expandedNutritionalId === item.id ? 'rotate-180' : ''
                  }`} />
                </button>

                <button
                  onClick={() => startCustomizing(item)}
                  className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold tracking-wider uppercase transition-all cursor-pointer ${
                    theme === 'cream'
                      ? 'bg-stone-900 hover:bg-amber-800 text-amber-50'
                      : 'bg-amber-700 hover:bg-amber-600 text-stone-950 font-black'
                  }`}
                >
                  <Plus className="h-4 w-4" />
                  Order
                </button>
              </div>

              {/* Collapsible Nutritional Stats Box */}
              {expandedNutritionalId === item.id && item.nutritionalInfo && (
                <div className={`mt-4 p-3.5 rounded-xl text-[10px] border transition-all duration-300 animate-fade-in ${
                  theme === 'cream'
                    ? 'bg-amber-50/50 border-amber-100 text-stone-700'
                    : 'bg-stone-900 border-stone-850 text-stone-300'
                }`}>
                  <div className="grid grid-cols-3 gap-2 text-center border-b border-dashed border-stone-800/10 pb-2 mb-2">
                    <div>
                      <p className="font-bold text-stone-500">CALORIES</p>
                      <p className="text-xs font-black mt-0.5">{item.nutritionalInfo.calories} kcal</p>
                    </div>
                    <div>
                      <p className="font-bold text-stone-500">CAFFEINE</p>
                      <p className="text-xs font-black mt-0.5">{item.nutritionalInfo.caffeine}</p>
                    </div>
                    <div>
                      <p className="font-bold text-stone-500">ALLERGENS</p>
                      <p className="text-xs font-black mt-0.5">
                        {item.nutritionalInfo.allergens.length > 0 ? 'See Details' : 'None'}
                      </p>
                    </div>
                  </div>
                  <div>
                    <span className="font-bold text-stone-500 uppercase tracking-widest block mb-0.5">Allergens Details:</span>
                    <p className="leading-relaxed">
                      {item.nutritionalInfo.allergens.length > 0
                        ? item.nutritionalInfo.allergens.join(', ')
                        : 'No direct common allergens registered. Cross-contamination possible in food preparation spaces.'}
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Beverage Customizer Modal Drawer */}
      {customizingItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 backdrop-blur-xs p-4">
          <div className={`w-full max-w-lg rounded-2xl border p-6 overflow-hidden shadow-2xl transition-all duration-300 ${
            theme === 'cream'
              ? 'bg-white border-amber-100 text-stone-950'
              : 'bg-stone-950 border-stone-800 text-amber-50'
          }`}>
            <div className="flex justify-between items-start pb-4 border-b border-stone-800/10">
              <div>
                <span className="text-[10px] tracking-widest font-bold uppercase text-amber-600">Customize Beverage</span>
                <h3 className="text-xl font-black tracking-wider uppercase">{customizingItem.name}</h3>
              </div>
              <button
                onClick={() => setCustomizingItem(null)}
                className="p-1 rounded-lg hover:bg-stone-900/10 text-stone-400"
              >
                ✕
              </button>
            </div>

            <div className="py-6 space-y-6 max-h-[60vh] overflow-y-auto pr-2">
              {/* Milk Option Choice */}
              {customizingItem.category !== 'tea' && (
                <div>
                  <label className="text-xs font-bold uppercase tracking-widest text-stone-400 block mb-2.5">
                    Milk Selection
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {['Whole Milk (Standard)', 'Oat Milk (+$0.75)', 'Almond Milk (+$0.75)'].map((milk) => (
                      <button
                        key={milk}
                        onClick={() => setSelectedMilk(milk)}
                        className={`py-3 px-4 rounded-xl text-left text-xs font-semibold uppercase flex items-center justify-between border cursor-pointer ${
                          selectedMilk === milk
                            ? 'border-amber-600 bg-amber-600/10 text-amber-600'
                            : theme === 'cream'
                            ? 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                            : 'border-stone-850 bg-stone-900 text-stone-300 hover:bg-stone-850'
                        }`}
                      >
                        {milk}
                        {selectedMilk === milk && <Check className="h-4 w-4" />}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Extra Double Espresso Shot Toggle */}
              <div>
                <label className="text-xs font-bold uppercase tracking-widest text-stone-400 block mb-2.5">
                  Strength Addition
                </label>
                <button
                  onClick={() => setExtraShot(!extraShot)}
                  className={`w-full py-3.5 px-4 rounded-xl border text-left text-xs font-semibold uppercase flex items-center justify-between cursor-pointer ${
                    extraShot
                      ? 'border-amber-600 bg-amber-600/10 text-amber-600'
                      : theme === 'cream'
                      ? 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                      : 'border-stone-850 bg-stone-900 text-stone-300 hover:bg-stone-850'
                  }`}
                >
                  <span className="flex flex-col text-left">
                    <span>Add Extra Double Shot (+$1.00)</span>
                    <span className="text-[10px] text-stone-500 normal-case font-normal mt-0.5">Boost caffeine by ~150mg</span>
                  </span>
                  {extraShot && <Check className="h-4 w-4" />}
                </button>
              </div>

              {/* Flavor Syrup Selection */}
              <div>
                <label className="text-xs font-bold uppercase tracking-widest text-stone-400 block mb-2.5">
                  Sweetener / Syrup (+0.50)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['None', 'Madagascar Vanilla', 'Smoked Caramel', 'Spiced Cardamom'].map((syrup) => (
                    <button
                      key={syrup}
                      onClick={() => setSyrupFlavor(syrup)}
                      className={`py-3 px-3 rounded-xl text-center text-[10px] font-bold uppercase border cursor-pointer ${
                        syrupFlavor === syrup
                          ? 'border-amber-600 bg-amber-600/10 text-amber-600'
                          : theme === 'cream'
                          ? 'border-stone-200 bg-stone-50 text-stone-700 hover:bg-stone-100'
                          : 'border-stone-850 bg-stone-900 text-stone-300 hover:bg-stone-850'
                      }`}
                    >
                      {syrup}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Confirm Actions */}
            <div className="pt-4 border-t border-stone-800/10 flex items-center justify-between">
              <div className="text-left">
                <span className="text-[9px] tracking-widest font-bold uppercase text-stone-400">Total Price</span>
                <p className="text-xl font-black font-mono text-amber-600">
                  ${(
                    customizingItem.price +
                    (customizingItem.category !== 'tea' && (selectedMilk.includes('Oat Milk') || selectedMilk.includes('Almond Milk')) ? 0.75 : 0) +
                    (extraShot ? 1.00 : 0) +
                    (syrupFlavor !== 'None' ? 0.50 : 0)
                  ).toFixed(2)}
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => setCustomizingItem(null)}
                  className={`px-4 py-2.5 rounded-xl text-xs font-bold tracking-wider uppercase border cursor-pointer ${
                    theme === 'cream' ? 'hover:bg-stone-100' : 'hover:bg-stone-900'
                  }`}
                >
                  Cancel
                </button>
                <button
                  onClick={handleConfirmCustomization}
                  className="px-5 py-2.5 rounded-xl text-xs font-black tracking-widest uppercase bg-amber-700 text-stone-950 hover:bg-amber-600 cursor-pointer"
                >
                  Add to Order
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
