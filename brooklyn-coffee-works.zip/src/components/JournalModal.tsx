import React from 'react';
import { Clock, User, Calendar, BookOpen, Share2 } from 'lucide-react';
import { JournalPost } from '../types';

interface JournalModalProps {
  post: JournalPost;
  onClose: () => void;
  theme: 'cream' | 'industrial';
}

export default function JournalModal({ post, onClose, theme }: JournalModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/85 backdrop-blur-xs p-4 overflow-y-auto">
      <div className={`w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl border transition-all duration-300 my-8 ${
        theme === 'cream'
          ? 'bg-amber-50 border-amber-100 text-stone-950'
          : 'bg-stone-950 border-stone-850 text-amber-50'
      }`}>
        
        {/* Cover Photo block */}
        <div className="h-60 sm:h-72 w-full relative bg-stone-900">
          <img
            src={post.imageUrl}
            alt={post.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-950 to-transparent" />
          
          <div className="absolute bottom-6 left-6 right-6 text-left">
            <span className="text-[9px] font-black tracking-widest uppercase bg-amber-600 text-stone-950 px-3 py-1 rounded-full shadow-md">
              {post.category}
            </span>
            <h3 className="text-xl sm:text-2xl font-black uppercase tracking-wider text-white mt-3 leading-tight">
              {post.title}
            </h3>
          </div>
          
          <button
            onClick={onClose}
            className="absolute top-4 right-4 h-9 w-9 bg-stone-950/65 text-amber-50 hover:bg-stone-950 hover:text-white rounded-full flex items-center justify-center font-bold text-sm cursor-pointer"
            title="Close Read View"
          >
            ✕
          </button>
        </div>

        {/* Read details and body text */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Metadata Block */}
          <div className="flex flex-wrap items-center gap-y-2 gap-x-5 text-[10px] font-bold text-stone-400 uppercase tracking-widest border-b border-stone-800/10 pb-4">
            <div className="flex items-center gap-1.5">
              <User className="h-3.5 w-3.5 text-amber-600" />
              <span>By {post.author}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5 text-amber-600" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5 text-amber-600" />
              <span>{post.readTime}</span>
            </div>
          </div>

          {/* Narrative Main Text Body */}
          <div className="max-w-[65ch] mx-auto text-left text-xs sm:text-sm leading-relaxed space-y-4">
            <p className="font-extrabold text-stone-400 uppercase tracking-widest text-[10px]">
              - INTRODUCTION -
            </p>
            <p className="font-bold text-amber-900 dark:text-amber-100 italic border-l-2 border-amber-600 pl-4">
              {post.excerpt}
            </p>
            <p className={`${theme === 'cream' ? 'text-stone-700' : 'text-stone-300'}`}>
              {post.content}
            </p>
            <p className={`${theme === 'cream' ? 'text-stone-700' : 'text-stone-300'}`}>
              At Brooklyn Coffee Works, our dedication extends beyond roasting green coffee beans; we strive to honor the entire lineage of agriculture, transit, sorting, chemistry, and craftsmanship. In each cup, you are tracing months of labor from Sidama or Copán, perfectly balanced by our microfoam texturing.
            </p>
            <p className={`${theme === 'cream' ? 'text-stone-700' : 'text-stone-300'}`}>
              Specialty brewing is as much an educational pursuit as it is a morning ritual. We encourage you to stop by our sensory lab in Greenpoint on Saturdays, or try pouring a slow drip with our single-origins at home using the custom ceramic drippers. Happy brewing!
            </p>
          </div>

          {/* Bottom sharing & close bars */}
          <div className="pt-6 border-t border-dashed border-stone-800/10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Share2 className="h-4 w-4 text-stone-400" />
              <span className="text-[10px] font-bold text-stone-400 uppercase tracking-widest">Share this Journal post:</span>
              <div className="flex gap-1.5">
                {['Twitter', 'Facebook', 'Copy Link'].map((medium) => (
                  <button
                    key={medium}
                    onClick={() => alert(`Copied link to ${post.title}!`)}
                    className={`px-2.5 py-1 text-[9px] font-bold uppercase border border-stone-800/10 rounded-md ${
                      theme === 'cream' ? 'hover:bg-stone-100' : 'hover:bg-stone-900'
                    }`}
                  >
                    {medium}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={onClose}
              className="px-6 py-2.5 rounded-xl text-xs font-black tracking-widest uppercase bg-stone-950 text-amber-50 hover:bg-amber-900 cursor-pointer"
            >
              Done Reading
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
