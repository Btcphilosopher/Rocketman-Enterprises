import React, { useState, useEffect } from 'react';
import { CATEGORIES, PRODUCTS, FAQS } from './data';
import { Product, CartItem, Category } from './types';

// Sub-components
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import CartDrawer from './components/CartDrawer';
import Oscilloscope from './components/Oscilloscope';

// Icons
import { 
  ShieldAlert, Cpu, Radio, Compass, BookOpen, Shirt, Tag, Heart, LayoutGrid,
  Truck, ArrowRightLeft, HeartHandshake, QrCode, Terminal, HelpCircle,
  Copy, Check, FileText, Info, Key, ShieldCheck, Github, X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // State Management
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Custom Modals State
  const [showPgpModal, setShowPgpModal] = useState(false);
  const [showManifestoModal, setShowManifestoModal] = useState(false);
  const [userPgpKey, setUserPgpKey] = useState('');
  const [isLoggedWithPgp, setIsLoggedWithPgp] = useState(false);
  const [pgpCopied, setPgpCopied] = useState(false);

  // QR Code interaction states
  const [copiedBTCAddress, setCopiedBTCAddress] = useState(false);
  const [copiedXMRAddress, setCopiedXMRAddress] = useState(false);

  const mockStorePgpKey = `-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v2.4.0 (GNU/Linux)

mQINBFk4z3gBEADOfq66lqI5RzW8bA9X0e3/uW98jdfDkK2MvY9N1mX4h0v4K58R
X7mZfN4vY8XvR0m3e2W7mN2G8y4f9r5v2HwK2MvY9N1mX4h0v4K58R5v2HwK2Mv
Y9N1mX4h0v4K58R5v2HwK2MvY9N1mX4h0v4K58R5v2HwK2MvY9N1mX4h0v4K58R
=e7Wf
-----END PGP PUBLIC KEY BLOCK-----`;

  // Filter products based on search and selected category
  const filteredProducts = PRODUCTS.filter((product) => {
    const matchesCategory = activeCategory === 'all' || product.category === activeCategory;
    const matchesSearch = product.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          product.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { product, quantity: 1 }];
    });
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const newQuantity = item.quantity + delta;
            return { ...item, quantity: newQuantity };
          }
          return item;
        })
        .filter((item) => item.quantity > 0);
    });
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const totalCartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  // Scroll navigation helper
  const handleNavClick = (sectionId: string) => {
    if (sectionId === 'shop') {
      setActiveCategory('all');
      document.getElementById('product-catalog')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'manifesto') {
      setShowManifestoModal(true);
    } else if (sectionId === 'about') {
      document.getElementById('about-section')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'shipping') {
      document.getElementById('features-section')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'faq') {
      document.getElementById('faq-section')?.scrollIntoView({ behavior: 'smooth' });
    } else if (sectionId === 'contact') {
      document.getElementById('footer-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePgpLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (userPgpKey.includes('-----BEGIN PGP PUBLIC KEY BLOCK-----')) {
      setIsLoggedWithPgp(true);
      setShowPgpModal(false);
    } else {
      alert('Invalid PGP Public Key. Key must begin with -----BEGIN PGP PUBLIC KEY BLOCK-----');
    }
  };

  const handleCopyStorePgp = () => {
    navigator.clipboard.writeText(mockStorePgpKey);
    setPgpCopied(true);
    setTimeout(() => setPgpCopied(false), 2000);
  };

  // Maps the category string to respective Lucide React icon components
  const renderCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'ShieldAlert': return <ShieldAlert className="w-4 h-4" />;
      case 'Cpu': return <Cpu className="w-4 h-4" />;
      case 'Radio': return <Radio className="w-4 h-4" />;
      case 'Compass': return <Compass className="w-4 h-4" />;
      case 'BookOpen': return <BookOpen className="w-4 h-4" />;
      case 'Shirt': return <Shirt className="w-4 h-4" />;
      case 'Tag': return <Tag className="w-4 h-4" />;
      case 'Heart': return <Heart className="w-4 h-4" />;
      case 'LayoutGrid': return <LayoutGrid className="w-4 h-4" />;
      default: return <Cpu className="w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-bento-radial text-gray-300 font-mono selection:bg-cyan-400 selection:text-black relative overflow-x-hidden">
      
      {/* Full screen scanline CRT glass overlay from Bento theme */}
      <div className="fixed inset-0 pointer-events-none z-50 bento-crt-overlay" />

      {/* Background Cyber Grid lines and dots overlay */}
      <div className="fixed inset-0 bg-cyber-grid opacity-30 pointer-events-none z-0" />
      <div className="fixed inset-0 bg-cyber-dots opacity-40 pointer-events-none z-0" />

      {/* FIXED HEADER NAVBAR */}
      <Navbar
        cartCount={totalCartCount}
        onCartOpen={() => setIsCartOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onNavClick={handleNavClick}
        onLoginClick={() => setShowPgpModal(true)}
      />

      {/* MAIN CONTAINER */}
      <main className="max-w-7xl mx-auto px-4 lg:px-8 pt-6 pb-20 relative z-10">
        
        {/* UPPER HERO GRID SECTION */}
        <Hero
          cityImagePath="/src/assets/images/cyberpunk_city_alley_1784213923596.jpg"
          onExploreClick={() => {
            document.getElementById('product-catalog')?.scrollIntoView({ behavior: 'smooth' });
          }}
        />

        {/* MIDDLE SECTION: SIDEBAR CATEGORIES & PRODUCTS GRID */}
        <div id="product-catalog" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start pt-4">
          
          {/* LEFT SIDEBAR: CATEGORIES SELECTOR (3 columns) */}
          <div className="lg:col-span-3 flex flex-col gap-6 sticky lg:top-24">
            
            {/* Categories Selection Box */}
            <div className="bg-black/60 border border-cyan-900/50 p-4 rounded-none relative">
              <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyan-400/50" />
              
              <div className="flex items-center justify-between border-b border-cyan-900/50 pb-2 mb-4">
                <span className="font-mono text-[11px] font-bold text-cyan-400 tracking-widest uppercase">CATEGORIES</span>
                <span className="text-[10px] font-mono text-cyan-600 font-semibold">&gt;_ SELECTOR</span>
              </div>

              <div className="space-y-1">
                {CATEGORIES.map((category) => {
                  const isActive = activeCategory === category.id;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      className={`w-full flex items-center justify-between p-2.5 rounded-none font-mono text-[11px] tracking-wider transition-all text-left cursor-pointer border uppercase ${
                        isActive
                          ? 'bg-black/80 border-cyan-400/50 text-cyan-400 glow-cyan font-bold'
                          : 'border-transparent text-gray-400 hover:text-white hover:bg-black/40'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <span className={isActive ? 'text-cyan-400' : 'text-cyan-800'}>
                          {renderCategoryIcon(category.iconName)}
                        </span>
                        <span>{category.name}</span>
                      </div>
                      
                      {isActive ? (
                        <div className="w-2.5 h-2.5 bg-cyan-400 rounded-sm rotate-45 shrink-0 shadow-[0_0_8px_#00f3ff]" />
                      ) : (
                        <span className="text-[8px] text-gray-600 font-bold font-mono">
                          [LINK]
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>

            </div>

            {/* Sub-Sidebar Console Warning Box with real-time green signal waves */}
            <div className="bg-black/40 border border-purple-900/40 p-4 rounded-none relative overflow-hidden">
              <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-purple-400/50" />
              
              <p className="font-mono text-[10px] text-purple-400/80 leading-normal mb-3 font-semibold uppercase">
                YOU ARE THE ECONOMY.<br />
                ACT ACCORDINGLY.
              </p>

              <div className="border border-purple-900/50 bg-purple-900/15 p-2.5 rounded-none">
                <div className="flex justify-between font-mono text-[8.5px] text-purple-500 mb-1.5 uppercase font-bold">
                  <span>SIGNAL STRENGTH</span>
                  <span className="text-purple-400 animate-pulse">LOCK // IN</span>
                </div>
                
                {/* Beautiful dynamic animated spectrum oscilloscope bar */}
                <Oscilloscope height={32} speed={1.8} color="#bc13fe" type="bars" />
              </div>
            </div>

          </div>

          {/* RIGHT GRID: PRODUCTS MATRIX (9 columns) */}
          <div className="lg:col-span-9 flex flex-col gap-6">
            
            {/* List Heading and dynamic filter counter */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-cyan-900/30 pb-3">
              <div className="flex items-center gap-3">
                <div className="w-2.5 h-2.5 bg-cyan-400 rotate-45 shadow-[0_0_8px_#00f3ff]" />
                <h2 className="font-display font-black text-base sm:text-lg tracking-widest text-white uppercase italic">
                  FEATURED HARDWARE & SYSTEM MODULES
                </h2>
              </div>
              
              <div className="flex items-center gap-3">
                <span className="font-mono text-[10px] text-gray-500 uppercase tracking-widest">
                  INDEX_DUMP: <span className="text-cyan-400 font-bold">{filteredProducts.length}</span> / {PRODUCTS.length} MODULES
                </span>
                {activeCategory !== 'all' && (
                  <button
                    onClick={() => setActiveCategory('all')}
                    className="text-[9.5px] font-mono text-magenta-500 hover:text-magenta-400 underline font-bold cursor-pointer uppercase tracking-widest"
                  >
                    RESET
                  </button>
                )}
              </div>
            </div>

            {/* Products Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-20 bg-black/40 border border-cyan-900/30 rounded-none p-6">
                <p className="font-mono text-cyan-500 text-[11px] uppercase tracking-widest mb-2">No matching products found inside this node.</p>
                <p className="font-mono text-gray-500 text-xs max-w-md mx-auto">Try typing another query in the search input or choosing a different categories module from the sidebar index.</p>
                <button
                  onClick={() => {
                    setSearchQuery('');
                    setActiveCategory('all');
                  }}
                  className="mt-4 font-mono text-[10px] text-cyan-400 border border-cyan-500/30 bg-cyan-950/20 hover:bg-cyan-950/40 px-4 py-2 rounded-none uppercase font-bold cursor-pointer"
                >
                  CLEAR SEARCH FILTER
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    onViewClick={(prod) => setSelectedProduct(prod)}
                  />
                ))}
              </div>
            )}

          </div>

        </div>

        {/* --- BOTTOM ROW: HIGH-END FEATURE CARDS (Shipping, Privacy, Refunds, Decentralization, Wallet QRs) --- */}
        <div id="features-section" className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-16 border-t border-cyan-900/30 pt-12 items-stretch">
          
          {/* Card 1: Shipping (3 cols) */}
          <div className="md:col-span-3 bg-black/40 border border-cyan-900/30 p-5 rounded-none flex flex-col justify-between group hover:border-cyan-500/40 transition-all relative">
            <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyan-900/60 group-hover:border-cyan-400 transition-colors" />
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 rounded-none bg-black/60 border border-cyan-900/50 text-cyan-400 group-hover:border-cyan-400 transition-colors">
                <Truck className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider mb-1.5 italic">DISCRETE SHIPPING</h4>
                <p className="font-sans text-[11.5px] text-gray-400 leading-normal">
                  Completely discrete, double-sealed vacuum-packed envelopes. Return addresses are randomized. No description of contents is shown externally.
                </p>
              </div>
            </div>
            <span className="block font-mono text-[8px] text-cyan-700 mt-4 uppercase font-bold">SHIPPING // 100% DISCRETE</span>
          </div>

          {/* Card 2: Refund Policy (3 cols) */}
          <div className="md:col-span-3 bg-black/40 border border-magenta-900/20 p-5 rounded-none flex flex-col justify-between group hover:border-magenta-500/40 transition-all relative">
            <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-magenta-950 group-hover:border-magenta-500 transition-colors" />
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 rounded-none bg-black/60 border border-magenta-900/50 text-magenta-500 group-hover:border-magenta-400 transition-colors">
                <ArrowRightLeft className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider mb-1.5 italic">SOVEREIGN SALES</h4>
                <p className="font-sans text-[11.5px] text-gray-400 leading-normal">
                  All transactions processed through non-custodial networks are absolute. Sales are final. We do not keep client history databases for processing standard returns.
                </p>
              </div>
            </div>
            <span className="block font-mono text-[8px] text-magenta-700 mt-4 uppercase font-bold">SALES_FINAL // REFUNDS</span>
          </div>

          {/* Card 3: Decentralization Support (3 cols) */}
          <div className="md:col-span-3 bg-black/40 border border-purple-900/20 p-5 rounded-none flex flex-col justify-between group hover:border-purple-500/40 transition-all relative">
            <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-purple-950 group-hover:border-purple-500 transition-colors" />
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 rounded-none bg-black/60 border border-purple-900/50 text-purple-400 group-hover:border-purple-400 transition-colors">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider mb-1.5 italic">PARALLEL FUNDING</h4>
                <p className="font-sans text-[11.5px] text-gray-400 leading-normal">
                  A portion of all storefront transaction values directly supports key open-source code repositories, privacy tool configurations, and sovereign decentralized builders.
                </p>
              </div>
            </div>
            <span className="block font-mono text-[8px] text-purple-700 mt-4 uppercase font-bold">SUPPORT // OPEN_SOURCE</span>
          </div>

          {/* Card 4: Wallet QR Codes (3 cols) */}
          <div className="md:col-span-3 bg-black/60 border border-cyan-900/50 p-5 rounded-none flex flex-col justify-between relative bg-cyber-dots">
            <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyan-400/45" />
            <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-cyan-400/45" />

            <div>
              <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider mb-3 flex items-center gap-1.5 italic">
                <QrCode className="w-4 h-4 text-cyan-400" />
                WALLET QR CODES
              </h4>
              <p className="font-sans text-[11px] text-gray-400 leading-normal mb-4">
                Scan to pay or tip securely. Click address tags below to copy store public cryptographic destination slots.
              </p>

              {/* BTC & XMR Destination tags */}
              <div className="space-y-2">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText('bc1q96p66z0p534m678m5v2ny3xepdfv899clwty7f');
                    setCopiedBTCAddress(true);
                    setTimeout(() => setCopiedBTCAddress(false), 2000);
                  }}
                  className="w-full flex items-center justify-between p-2 bg-black/90 border border-cyan-900/30 rounded-none hover:border-amber-500/50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-4 rounded-none bg-amber-500 text-black text-[10px] font-bold flex items-center justify-center font-mono">B</span>
                    <span className="font-mono text-[8.5px] text-gray-400 truncate max-w-[120px]">bc1q96p66z0p...wty7f</span>
                  </div>
                  {copiedBTCAddress ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <Copy className="w-3 h-3 text-gray-600 shrink-0" />
                  )}
                </button>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText('44AFFBcf56xP788mDfyUe88Pq4m89R7fV9q9clZwy7fN89mDfyUe88Pq4m89R7fV9q9clZw');
                    setCopiedXMRAddress(true);
                    setTimeout(() => setCopiedXMRAddress(false), 2000);
                  }}
                  className="w-full flex items-center justify-between p-2 bg-black/90 border border-cyan-900/30 rounded-none hover:border-orange-500/50 transition-colors text-left cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-none bg-orange-950/30 border border-orange-500/60 text-[#f97316] text-[8px] font-bold flex items-center justify-center">M</div>
                    <span className="font-mono text-[8.5px] text-gray-400 truncate max-w-[120px]">44AFFBcf56xP...clZw</span>
                  </div>
                  {copiedXMRAddress ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  ) : (
                    <Copy className="w-3 h-3 text-gray-600 shrink-0" />
                  )}
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* --- FAQ COLLAPSIBLE ACCORDION SECTION --- */}
        <div id="faq-section" className="mt-16 bg-black/60 border border-cyan-900/30 p-6 rounded-none relative max-w-3xl mx-auto">
          <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-cyan-400/50" />
          
          <div className="flex items-center gap-2.5 mb-6 border-b border-cyan-900/20 pb-3">
            <HelpCircle className="w-4 h-4 text-cyan-400" />
            <h3 className="font-display font-bold text-sm text-white uppercase tracking-widest italic">
              FREQUENTLY ASKED OPSEC QUESTIONS
            </h3>
          </div>

          <div className="space-y-4">
            {FAQS.map((faq, idx) => (
              <div key={idx} className="border-b border-cyan-900/10 pb-3.5 last:border-0 last:pb-0">
                <h4 className="font-mono text-[11px] font-bold text-cyan-400 uppercase mb-1.5 leading-relaxed">
                  &gt; {faq.question}
                </h4>
                <p className="font-sans text-[11.5px] text-gray-400 leading-relaxed pl-3 border-l-2 border-cyan-900/50">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>

      </main>

      {/* FOOTER SECTION */}
      <footer id="footer-section" className="bg-black/80 border-t border-cyan-900/50 py-10 relative z-10 font-mono text-[11px] backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 lg:px-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          
          {/* Logo & Slogan Column */}
          <div className="md:col-span-4 flex flex-col gap-2">
            <div className="flex items-center gap-2.5">
              <div className="w-3.5 h-3.5 bg-cyan-400 rotate-45 shadow-[0_0_8px_#00f3ff]" />
              <span className="font-display font-black tracking-wider text-sm text-white uppercase italic">
                COUNTER-ECONOMICS
              </span>
            </div>
            <p className="text-[10px] text-gray-500 max-w-sm leading-normal">
              NOT ANTI-MARKET. ANTI-EXPLOITATION. ALL RIGS RUN LOCAL. ENCRYPTION IS A FUNDAMENTAL HUMAN SHIELD.
            </p>
          </div>

          {/* Navigation Links Column */}
          <div className="md:col-span-4 flex flex-wrap gap-x-4 gap-y-2 justify-start md:justify-center text-gray-500">
            <button onClick={() => setShowManifestoModal(true)} className="hover:text-cyan-400 cursor-pointer transition-colors">MANIFESTO</button>
            <span>•</span>
            <button onClick={() => alert('Zero trace logs. No cookies stored. Absolute client privacy.')} className="hover:text-cyan-400 cursor-pointer transition-colors">PRIVACY</button>
            <span>•</span>
            <button onClick={() => alert('Sovereign peer trade terms. All code is public domain.')} className="hover:text-cyan-400 cursor-pointer transition-colors">TERMS</button>
            <span>•</span>
            <button onClick={() => setShowPgpModal(true)} className="hover:text-cyan-400 cursor-pointer transition-colors">PGP KEY</button>
            <span>•</span>
            <div className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse-slow shadow-[0_0_5px_#22c55e]" />
              <span className="text-green-500 text-[10px] font-bold uppercase">GLOBAL_NODE: ONLINE</span>
            </div>
          </div>

          {/* Extreme slogan with pulse spectrum wave */}
          <div className="md:col-span-4 flex flex-col md:items-end gap-1 text-gray-500">
            <div className="w-full max-w-[200px] mb-2 md:mb-0">
              <Oscilloscope height={16} speed={1} color="#ff0055" type="noise" />
            </div>
            <p className="text-[10px] tracking-wide font-bold uppercase text-right leading-tight">
              BUILD <span className="text-cyan-400">FREEDOM.</span> SHARE <span className="text-purple-400">ABUNDANCE.</span> STAY <span className="text-magenta-500 glow-text-magenta">UNGOVERNABLE.</span>
            </p>
          </div>

        </div>
      </footer>

      {/* --- SIDE CART SYSTEM SLIDE-OVER DRAWER --- */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* --- QUICK VIEW SYSTEM DETAILED MODAL --- */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* --- CUSTOM INTERACTIVE PGP / GPG LOGIN MODAL --- */}
      <AnimatePresence>
        {showPgpModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.8 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowPgpModal(false)}
              className="absolute inset-0 bg-black/90"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative max-w-md w-full bg-[#09090b] border border-cyan-800/40 p-5 rounded-sm font-mono z-10"
            >
              <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyan-400" />
              <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-cyan-400" />

              <div className="flex justify-between items-center border-b border-zinc-900 pb-2 mb-4">
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5" />
                  AUTHENTICATE_SESSION_GPG
                </span>
                <button
                  onClick={() => setShowPgpModal(false)}
                  className="p-1 rounded bg-zinc-950 border border-zinc-900 text-zinc-500 hover:text-zinc-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {isLoggedWithPgp ? (
                <div className="space-y-4">
                  <div className="p-3 bg-emerald-950/20 border border-emerald-900/50 text-emerald-400 rounded text-[11px] leading-relaxed">
                    <p className="font-bold">✓ GPG SESSION CRYPT-LOCKED</p>
                    <p className="mt-1 text-zinc-500 text-[10px]">
                      Your public key has been registered in the volatile local memory buffer. All outgoing receipt receipts and dispatch tracking tags will be automatically encrypted.
                    </p>
                  </div>
                  
                  <button
                    onClick={() => {
                      setIsLoggedWithPgp(false);
                      setUserPgpKey('');
                    }}
                    className="w-full py-2 bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-850 rounded text-center text-[10px] cursor-pointer"
                  >
                    DISCONNECT GPG SESSION
                  </button>
                </div>
              ) : (
                <form onSubmit={handlePgpLoginSubmit} className="space-y-4">
                  <p className="text-[10px] text-zinc-500 leading-normal">
                    Authenticate your browser context securely. Paste your GPG public block below or click "LOAD STORE ROOT KEY" to copy our signature key.
                  </p>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-[8.5px]">
                      <span className="text-zinc-400 font-bold">PASTE GPG PUBLIC BLOCK</span>
                      <button
                        type="button"
                        onClick={() => {
                          setUserPgpKey(`-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: GnuPG v2.4.0 (GNU/Linux)

mQINBFk4z3gBEADOfq66lqI5RzW8bA9X0e3/uW98jdfDkK2MvY9N1mX4h0v4K58R
X7mZfN4vY8XvR0m3e2W7mN2G8y4f9r5v2HwK2MvY9N1mX4h0v4K58R5v2HwK2Mv
=e7Wf
-----END PGP PUBLIC KEY BLOCK-----`);
                        }}
                        className="text-cyan-400 hover:underline cursor-pointer font-bold"
                      >
                        SIMULATE GENERATION
                      </button>
                    </div>

                    <textarea
                      placeholder="-----BEGIN PGP PUBLIC KEY BLOCK-----..."
                      value={userPgpKey}
                      onChange={(e) => setUserPgpKey(e.target.value)}
                      required
                      className="w-full h-32 bg-black border border-zinc-850 text-zinc-300 placeholder-zinc-700 rounded p-2 text-[9px] font-mono focus:outline-none focus:border-cyan-500 transition-all leading-tight"
                    />
                  </div>

                  <div className="bg-zinc-950 border border-zinc-900/60 p-2.5 rounded flex items-center justify-between text-[10px]">
                    <span className="text-zinc-500">STORE ROOT KEY: 0xF9ED3FA1</span>
                    <button
                      type="button"
                      onClick={handleCopyStorePgp}
                      className="text-cyan-400 hover:text-cyan-300 transition-colors font-bold underline flex items-center gap-1 cursor-pointer"
                    >
                      {pgpCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{pgpCopied ? 'COPIED' : 'COPY'}</span>
                    </button>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#09090b] text-cyan-400 hover:text-cyan-300 border border-cyan-800/40 hover:border-cyan-400 font-bold py-2.5 rounded text-[11px] uppercase cursor-pointer tracking-wider transition-all"
                  >
                    LOCK ENCRYPTED SESSION
                  </button>
                </form>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* --- CUSTOM INTERACTIVE STOREFRONT MANIFESTO MODAL --- */}
      <AnimatePresence>
        {showManifestoModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.85 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowManifestoModal(false)}
              className="absolute inset-0 bg-black/95"
            />

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative max-w-lg w-full bg-[#09090b] border border-cyan-800/40 p-6 rounded-sm font-mono z-10 max-h-[85vh] overflow-y-auto"
            >
              <div className="absolute top-0 left-0 w-2.5 h-2.5 border-t-2 border-l-2 border-cyan-500" />
              <div className="absolute bottom-0 right-0 w-2.5 h-2.5 border-b-2 border-r-2 border-cyan-500" />

              <div className="flex justify-between items-center border-b border-zinc-900 pb-3 mb-5">
                <span className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                  <FileText className="w-4 h-4" />
                  THE_COUNTER_ECONOMICS_MANIFESTO
                </span>
                <button
                  onClick={() => setShowManifestoModal(false)}
                  className="p-1 rounded bg-zinc-950 border border-zinc-900 text-zinc-500 hover:text-zinc-200 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="text-[11px] leading-relaxed text-zinc-400 space-y-4 font-sans select-text">
                <p className="font-mono text-cyan-400 text-[10px] font-bold">
                  &gt; DECLARATION_v2026.07
                </p>
                <p>
                  We believe that privacy is not a request for forgiveness or permission; it is a fundamental, non-negotiable human shielding shield. Freedom is the ability to trade, build, and cooperate with peers without the permission of centralized intermediating systems.
                </p>
                <p className="font-mono text-zinc-300 font-semibold border-l-2 border-cyan-800 pl-3 italic">
                  "Agorism is the practice of open, decentralized trade outside of coercive systems. Our code acts as the terminal boundary of sovereign peer commerce."
                </p>
                <p>
                  By creating cryptographic hardware wallets, military-grade signal blockers, off-grid communication transceivers, and open pamphlets, we construct a parallel economy of self-reliance. This economy does not ask for compliance. It secures autonomy.
                </p>
                <p>
                  Every line of our code is signed, transparent, and built with absolute custody held local on your devices. We don't trace logs. We don't store transaction data. We don't lease access. 
                </p>
                <p className="text-cyan-400 font-mono text-[9px] text-center font-bold uppercase pt-3">
                  // THE PARALLEL WORLD HAS BEGUN. JOIN THE NODES. //
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-900 flex justify-end">
                <button
                  onClick={() => setShowManifestoModal(false)}
                  className="px-5 py-2 border border-zinc-800 text-zinc-400 hover:text-cyan-400 hover:border-cyan-800/50 bg-zinc-950 rounded font-mono text-[10px] uppercase font-bold cursor-pointer transition-colors"
                >
                  DISMISS LOG
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
