import React, { useState } from 'react';
import { X, Check, ShieldCheck, Key, ShoppingCart, Terminal } from 'lucide-react';
import { Product } from '../types';
import ProductVector from './ProductVector';
import { motion, AnimatePresence } from 'motion/react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart
}: ProductDetailModalProps) {
  const [isVerifying, setIsVerifying] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [addedFeedback, setAddedFeedback] = useState(false);

  if (!product) return null;

  // Colors depending on categories
  let colorHex = '#06b6d4'; // Cyan
  let glowClass = 'glow-cyan';
  let textColorClass = 'text-cyan-400';
  let borderClass = 'border-cyan-500/30';
  let bgClass = 'bg-cyan-950/10';

  if (product.category === 'dec-tech') {
    colorHex = '#eab308'; // Amber
    glowClass = 'glow-amber';
    textColorClass = 'text-amber-400';
    borderClass = 'border-amber-500/30';
    bgClass = 'bg-amber-950/10';
  } else if (product.category === 'comm') {
    colorHex = '#10b981'; // Green
    glowClass = 'glow-cyan';
    textColorClass = 'text-emerald-400';
    borderClass = 'border-emerald-500/30';
    bgClass = 'bg-emerald-950/10';
  } else if (product.category === 'books') {
    colorHex = '#f43f5e'; // Pink
    glowClass = 'glow-magenta';
    textColorClass = 'text-rose-400';
    borderClass = 'border-rose-500/30';
    bgClass = 'bg-rose-950/10';
  } else if (product.category === 'apparel') {
    colorHex = '#a855f7'; // Purple
    glowClass = 'glow-purple';
    textColorClass = 'text-purple-400';
    borderClass = 'border-purple-500/30';
    bgClass = 'bg-purple-950/10';
  }

  // Simulated PGP Signature Block unique to this product's id
  const pSignature = `-----BEGIN PGP SIGNATURE-----
Version: GnuPG v2.4.0 (GNU/Linux)

mQINBFk4z3gBEADOfq66lqI5RzW8bA9X0e3/uW98jdfDkK2MvY9N1mX
Hash: SHA512 (Counter-Economics-Secure-Core)
ID: SEC-NODE-${product.id.toUpperCase()}-SIGNATURE-HASH
SigVal: ${btoa(product.id + 'verify-cypherpunk-secret').slice(0, 48)}
-----END PGP SIGNATURE-----`;

  const handleVerify = () => {
    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      setIsVerified(true);
    }, 1500);
  };

  const handleAddToCartWithFeedback = () => {
    onAddToCart(product);
    setAddedFeedback(true);
    setTimeout(() => {
      setAddedFeedback(false);
    }, 2000);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        
        {/* Backdrop overlay */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.75 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-[#020203]"
        />

        {/* Modal Panel */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 350 }}
          className={`relative max-w-3xl w-full bg-black/95 border ${borderClass} rounded-none overflow-hidden z-10 p-5 sm:p-6 shadow-[0_0_50px_rgba(0,0,0,0.9)] flex flex-col md:flex-row gap-6 max-h-[90vh] overflow-y-auto backdrop-blur-md`}
        >
          {/* Accent corners */}
          <div className={`absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 ${borderClass.replace('30', '80')}`} />
          <div className={`absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 ${borderClass.replace('30', '80')}`} />
          <div className={`absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 ${borderClass.replace('30', '80')}`} />
          <div className={`absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 ${borderClass.replace('30', '80')}`} />

          {/* Close trigger button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 text-zinc-500 hover:text-cyan-400 transition-colors p-1.5 bg-black border border-cyan-900/30 rounded-none cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Left Column: Visual Illustration and PGP authentication block */}
          <div className="w-full md:w-[45%] flex flex-col gap-4">
            
            {/* Vector Card */}
            <div className="relative w-full aspect-square bg-black border border-cyan-900/25 rounded-none flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-cyber-grid opacity-10" />
              <ProductVector type={product.iconType} className="w-auto h-52 max-w-full" glowColor={colorHex} />
              
              <span className={`absolute bottom-3 left-3 font-mono text-[8px] font-semibold text-zinc-500`}>
                DEVICE_HARDWARE_ID: {product.id.slice(0, 8).toUpperCase()}
              </span>
            </div>

            {/* Cryptographic verification block */}
            <div className="bg-black border border-cyan-900/20 rounded-none p-3 flex flex-col gap-2 font-mono text-[9px]">
              <div className="flex items-center justify-between">
                <span className="text-zinc-400 font-bold flex items-center gap-1.5">
                  <Key className="w-3.5 h-3.5 text-zinc-500" />
                  ORIGIN PGP SIGNATURE
                </span>
                {isVerified ? (
                  <span className="text-emerald-400 font-bold uppercase flex items-center gap-1">
                    <Check className="w-3 h-3" /> VERIFIED
                  </span>
                ) : (
                  <button
                    onClick={handleVerify}
                    disabled={isVerifying}
                    className="text-cyan-400 hover:text-cyan-300 transition-colors font-bold uppercase underline cursor-pointer"
                  >
                    {isVerifying ? 'VERIFYING...' : 'RUN VERIFY'}
                  </button>
                )}
              </div>

              {isVerified ? (
                <div className="bg-emerald-950/20 border border-emerald-900/60 p-2 text-emerald-400 rounded-none leading-relaxed">
                  <p className="font-bold">✓ CRYPTOGRAPHIC PROOF SECURE</p>
                  <p className="text-[8.5px] mt-0.5 text-emerald-500/90 leading-tight">
                    Validated via store root key <span className="font-bold underline">0xF9ED3FA1</span>. Origin signature integrity checks matched perfectly.
                  </p>
                </div>
              ) : isVerifying ? (
                <div className="flex items-center justify-center py-6 gap-2 text-cyan-400">
                  <span className="w-2.5 h-2.5 rounded-full border-2 border-cyan-400 border-t-transparent animate-spin" />
                  <span className="animate-pulse">DECRYPTING SIGNATURE...</span>
                </div>
              ) : (
                <pre className="text-zinc-600 bg-black/40 p-2 rounded-none leading-tight overflow-x-auto whitespace-pre font-mono scrollbar-none">
                  {pSignature}
                </pre>
              )}
            </div>

          </div>

          {/* Right Column: Title, description, specifications, and Add/Buy actions */}
          <div className="w-full md:w-[55%] flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest bg-black border border-cyan-900/30 px-2 py-0.5 rounded-none">
                  {product.category.toUpperCase()} SYSTEM
                </span>
                <span className={`font-mono text-[9px] font-bold uppercase tracking-widest ${textColorClass}`}>
                  {product.type}
                </span>
              </div>

              <h2 className="font-display font-black text-2xl text-zinc-100 uppercase tracking-wide leading-tight mb-3">
                {product.title}
              </h2>

              <p className="font-sans text-[12.5px] text-zinc-400 leading-relaxed mb-5">
                {product.description}
              </p>

              {/* Technical Specifications list */}
              <div className="mb-5">
                <h4 className="font-mono text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-2.5 flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-zinc-500" />
                  SYSTEM SPECIFICATIONS
                </h4>
                <ul className="space-y-1.5">
                  {product.specs.map((spec, idx) => (
                    <li key={idx} className="flex items-start gap-2 font-mono text-[10px] text-zinc-500 leading-normal">
                      <span className={`text-[11px] font-bold ${textColorClass} mt-0.5`}>•</span>
                      <span className="text-zinc-400">{spec}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Buying box details with dual BTC/XMR prices and cart triggers */}
            <div className="pt-4 border-t border-cyan-900/20 mt-6 flex flex-col gap-4">
              
              <div className="grid grid-cols-2 gap-4 bg-black border border-cyan-900/30 p-3 rounded-none">
                <div>
                  <span className="block font-mono text-[8px] text-zinc-500 uppercase">BITCOIN PRICE</span>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span className="text-sm text-amber-500 font-bold">₿</span>
                    <span className="text-base font-bold font-mono text-zinc-200">
                      {product.priceBTC.toFixed(4)}
                    </span>
                  </div>
                </div>

                <div>
                  <span className="block font-mono text-[8px] text-zinc-500 uppercase text-right">MONERO PRICE</span>
                  <div className="flex items-center gap-1 mt-0.5 justify-end">
                    <span className="text-xs text-[#f97316] font-bold">XMR</span>
                    <span className="text-base font-bold font-mono text-zinc-200">
                      {product.priceXMR.toFixed(3)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleAddToCartWithFeedback}
                  className="flex-1 bg-black hover:bg-black/80 text-gray-400 hover:text-cyan-400 border border-cyan-900/30 hover:border-cyan-900/60 rounded-none py-3.5 font-mono text-[10.5px] tracking-wider uppercase font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  {addedFeedback ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                      <span className="text-cyan-400">ADDED TO CART</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-3.5 h-3.5" />
                      <span>ADD TO SYSTEM CART</span>
                    </>
                  )}
                </button>

                <button
                  onClick={() => {
                    onAddToCart(product);
                    onClose();
                  }}
                  className="flex-1 bg-cyan-500 text-black font-mono text-[11px] font-bold tracking-widest uppercase border border-cyan-300 shadow-[0_0_15px_rgba(0,243,255,0.4)] hover:bg-cyan-400 hover:shadow-[0_0_20px_rgba(0,243,255,0.6)] py-3.5 transition-all cursor-pointer flex items-center justify-center gap-1 rounded-none"
                >
                  <span>DECENTRALIZED CHECKOUT</span>
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-zinc-600 font-mono text-[8.5px] text-center uppercase">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Double-encrypted, discreetly vacuum-packed, same-day queue placement.</span>
              </div>

            </div>

          </div>

        </motion.div>
      </div>
    </AnimatePresence>
  );
}
