import React from 'react';
import { Shield, Lock, Share2, Globe, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onExploreClick: () => void;
  cityImagePath: string;
}

export default function Hero({ onExploreClick, cityImagePath }: HeroProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch mb-8 mt-20">
      
      {/* LEFT COLUMN: Slogan & Mini Features Panel (4 columns) */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5 }}
        className="lg:col-span-4 flex flex-col justify-between bg-black/60 border border-cyan-900/40 p-6 rounded-none relative overflow-hidden bg-cyber-dots"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        
        <div>
          {/* Main Slogan Headings in Bento Grid exact typography */}
          <div className="space-y-1.5 mb-6">
            <p className="text-amber-500 text-[10px] uppercase tracking-[0.3em] font-bold">SOVEREIGN NETWORK SUPPLY</p>
            <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-[40px] xl:text-[46px] tracking-tighter leading-none text-white italic uppercase">
              AUGMENT_YOUR<br />
              <span className="text-transparent" style={{ WebkitTextStroke: '1px #00f3ff' }}>REALITY</span>
            </h1>
          </div>

          <p className="font-sans text-[12.5px] text-gray-400 leading-relaxed max-w-md mb-8">
            Tools for living outside the system. Every purchase supports decentralized networks and the sovereign developers building the tools of the future.
          </p>
        </div>

        {/* Highlight Feature Badges */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-cyan-900/30">
          <div className="flex items-start gap-2.5">
            <div className="p-1.5 rounded-none bg-black/40 border border-cyan-900/50 text-cyan-400 shrink-0">
              <Shield className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="block font-mono text-[10px] font-bold text-gray-200">NO KYC</span>
              <span className="block font-mono text-[9px] text-gray-500">Privacy first always.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <div className="p-1.5 rounded-none bg-black/40 border border-purple-900/50 text-purple-400 shrink-0">
              <Lock className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="block font-mono text-[10px] font-bold text-gray-200">SECURE</span>
              <span className="block font-mono text-[9px] text-gray-500">Encrypted checkout.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <div className="p-1.5 rounded-none bg-black/40 border border-magenta-900/50 text-magenta-500 shrink-0">
              <Share2 className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="block font-mono text-[10px] font-bold text-gray-200">DECENTRALIZED</span>
              <span className="block font-mono text-[9px] text-gray-500">We don't rent freedom.</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5">
            <div className="p-1.5 rounded-none bg-black/40 border border-amber-900/50 text-amber-400 shrink-0">
              <Globe className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="block font-mono text-[10px] font-bold text-gray-200">GLOBAL</span>
              <span className="block font-mono text-[9px] text-gray-500">Ships worldwide discreetly.</span>
            </div>
          </div>
        </div>

        <div className="mt-8">
          <button
            onClick={onExploreClick}
            className="px-8 py-3.5 bg-cyan-500 text-black font-mono font-bold text-xs uppercase tracking-widest border border-cyan-300 shadow-[0_0_15px_rgba(0,243,255,0.4)] hover:bg-cyan-400 hover:shadow-[0_0_20px_rgba(0,243,255,0.6)] transition-all cursor-pointer w-full flex items-center justify-center gap-2 rounded-none"
          >
            <span>ACCESS CATALOGUE</span>
            <ArrowRight className="w-3.5 h-3.5 shrink-0" />
          </button>
        </div>

      </motion.div>

      {/* MIDDLE COLUMN: Glowing Cyberpunk City Alleyway Portrait (4 columns) */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="lg:col-span-4 flex flex-col bg-black/60 border border-purple-900/30 p-3 rounded-none relative overflow-hidden"
      >
        <div className="relative w-full h-[320px] lg:h-full min-h-[300px] overflow-hidden rounded-none bg-black border border-purple-900/40 scanline-overlay group">
          <img 
            src={cityImagePath} 
            alt="Cyberpunk Street Alley" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
          />
          
          {/* Tech HUD overlay badges */}
          <div className="absolute top-3 left-3 bg-black/80 backdrop-blur-md border border-cyan-500/40 rounded-none px-2.5 py-1 text-[8px] font-mono tracking-widest text-cyan-400 flex items-center gap-1.5 shadow">
            <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>NODE_STREAM_ACTIVE</span>
          </div>

          <div className="absolute bottom-4 left-4 right-4 bg-gradient-to-t from-black via-black/80 to-transparent p-3 border-t border-cyan-900/30 rounded-none">
            <p className="font-mono text-[10px] text-cyan-400 font-bold uppercase tracking-widest mb-0.5">EXIT THE SYSTEM</p>
            <p className="font-sans text-[9.5px] text-gray-500 leading-normal">Your choices matter. Run parallel nodes. Keep keys local. Don't comply.</p>
          </div>
          
          {/* Scanline simulated sweeping line */}
          <div className="absolute left-0 right-0 h-[1.5px] bg-cyan-400/40 shadow-[0_0_10px_#00f3ff] pointer-events-none animate-grid-travel w-full" />
        </div>
      </motion.div>

      {/* RIGHT COLUMN: Payments Panel & Severe Monospace Terminal (3 columns) */}
      <motion.div 
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
        className="lg:col-span-4 flex flex-col justify-between bg-black/60 border border-magenta-900/30 p-6 rounded-none bg-cyber-dots relative"
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between border-b border-cyan-900/20 pb-3 mb-5 font-mono">
            <span className="font-mono text-[11px] font-bold text-gray-400 tracking-wider">ACCEPTED PAYMENT SYSTEMS</span>
            <span className="text-[9px] font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-900/50 px-1.5 py-0.5 rounded-none uppercase font-bold">NON-FIAT</span>
          </div>

          {/* Crypto Rows */}
          <div className="space-y-4">
            
            {/* Bitcoin Block */}
            <div className="flex items-center justify-between bg-black/80 border border-cyan-900/20 p-3.5 rounded-none hover:border-amber-500/50 transition-all group relative">
              <div className="flex items-center gap-3.5">
                {/* SVG BTC Icon */}
                <div className="w-10 h-10 rounded-none bg-amber-500 flex items-center justify-center font-mono font-black text-xl text-zinc-950 shadow-[0_0_10px_rgba(245,158,11,0.2)] group-hover:scale-105 transition-transform">
                  B
                </div>
                <div>
                  <span className="block font-display font-black text-xs text-white group-hover:text-amber-400 transition-colors italic">BITCOIN</span>
                  <span className="block font-mono text-[9px] text-gray-500">Lightning & On-Chain Accepted</span>
                </div>
              </div>
              <div className="text-right font-mono text-[8.5px] text-gray-500">
                <span className="block text-amber-500 font-bold">100% SECURE</span>
                <span>NETWORK: BTC</span>
              </div>
            </div>

            {/* Monero Block */}
            <div className="flex items-center justify-between bg-black/80 border border-magenta-900/20 p-3.5 rounded-none hover:border-orange-500/50 transition-all group">
              <div className="flex items-center gap-3.5">
                {/* Monero Custom SVG Icon */}
                <div className="w-10 h-10 rounded-none bg-black border border-[#f97316]/40 flex items-center justify-center overflow-hidden relative shadow-[0_0_10px_rgba(249,115,22,0.1)] group-hover:scale-105 transition-transform">
                  <div className="absolute inset-0 bg-[#f97316]/5" />
                  <span className="font-mono text-lg font-black text-[#f97316]">M</span>
                </div>
                <div>
                  <span className="block font-display font-black text-xs text-white group-hover:text-orange-400 transition-colors italic">MONERO</span>
                  <span className="block font-mono text-[9px] text-gray-500">Untraceable / Fully Confidential</span>
                </div>
              </div>
              <div className="text-right font-mono text-[8.5px] text-gray-500">
                <span className="block text-orange-500 font-bold">100% PRIVATE</span>
                <span>NETWORK: XMR</span>
              </div>
            </div>

          </div>
        </div>

        {/* Severe Terminal Slogan warning box at bottom */}
        <div className="mt-6 p-4 rounded-none border border-magenta-900/40 bg-black/85 text-center relative overflow-hidden group hover:border-magenta-500/50 transition-all">
          <div className="absolute top-0 left-0 w-1.5 h-1.5 border-t border-l border-magenta-500" />
          <div className="absolute bottom-0 right-0 w-1.5 h-1.5 border-b border-r border-magenta-500" />
          
          <p className="font-mono text-[10px] text-magenta-400 leading-relaxed font-semibold tracking-wider">
            WE DON'T TRACK. WE DON'T STORE.<br />
            WE DON'T COMPLY.<br />
            YOUR FREEDOM IS <span className="text-magenta-500 glow-text-magenta font-bold">NON-NEGOTIABLE.</span>
          </p>
        </div>

      </motion.div>

    </div>
  );
}
