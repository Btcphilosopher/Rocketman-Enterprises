import React from 'react';

interface ProductVectorProps {
  type: 'coldcard' | 'trezor' | 'faraday' | 'baofeng' | 'book' | 'hoodie' | 'yubikey' | 'starlink' | 'stove' | 'stickers' | 'manifesto';
  className?: string;
  glowColor?: string;
}

export default function ProductVector({
  type,
  className = 'w-full h-48',
  glowColor = '#06b6d4'
}: ProductVectorProps) {
  // We render a beautiful, highly detailed custom SVG vector drawing for each item
  switch (type) {
    case 'coldcard':
      return (
        <svg id="svg-coldcard" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Main Body */}
          <rect x="25" y="10" width="70" height="160" rx="6" fill="#18181b" stroke="#3f3f46" strokeWidth="1.5" />
          <rect x="25" y="10" width="70" height="160" rx="6" fill="none" stroke={glowColor} strokeWidth="1" className="opacity-30" />
          
          {/* LCD Screen */}
          <rect x="35" y="22" width="50" height="32" rx="2" fill="#09090b" stroke="#27272a" strokeWidth="1" />
          <rect x="38" y="25" width="44" height="26" fill="#042f2e" />
          
          {/* Screen Content (Simulated Code) */}
          <text x="42" y="36" fill="#14b8a6" fontSize="6" fontFamily="monospace" fontWeight="bold">Coldcard</text>
          <text x="42" y="44" fill="#14b8a6" fontSize="5" fontFamily="monospace">Don't Trust.</text>
          <text x="42" y="49" fill="#14b8a6" fontSize="5" fontFamily="monospace">Verify.</text>
          
          {/* Status LEDs */}
          <circle cx="40" cy="16" r="1.5" fill="#ef4444" />
          <circle cx="80" cy="16" r="1.5" fill="#22c55e" />

          {/* Keypad Grid */}
          {/* 1, 2, 3 */}
          <rect x="37" y="65" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="54" y="65" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="71" y="65" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          
          {/* 4, 5, 6 */}
          <rect x="37" y="80" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="54" y="80" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="71" y="80" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />

          {/* 7, 8, 9 */}
          <rect x="37" y="95" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="54" y="95" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="71" y="95" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />

          {/* X, 0, OK */}
          <rect x="37" y="110" width="12" height="10" rx="1" fill="#7f1d1d" stroke="#ef4444" strokeWidth="0.5" />
          <rect x="54" y="110" width="12" height="10" rx="1" fill="#27272a" stroke="#3f3f46" strokeWidth="0.5" />
          <rect x="71" y="110" width="12" height="10" rx="1" fill="#064e3b" stroke="#10b981" strokeWidth="0.5" />

          {/* Nav buttons */}
          <circle cx="43" cy="132" r="3" fill="#3f3f46" />
          <circle cx="77" cy="132" r="3" fill="#3f3f46" />

          {/* Grid background lines overlay for cyber look */}
          <line x1="25" y1="145" x2="95" y2="145" stroke="#27272a" strokeWidth="1" />
          <text x="35" y="154" fill="#52525b" fontSize="4.5" fontFamily="monospace">MODEL MK4 - SECURE</text>
        </svg>
      );

    case 'trezor':
      return (
        <svg id="svg-trezor" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Shield shape body */}
          <path d="M25,25 L95,25 L95,75 L60,150 L25,75 Z" fill="#18181b" stroke="#3f3f46" strokeWidth="1.5" />
          <path d="M25,25 L95,25 L95,75 L60,150 L25,75 Z" fill="none" stroke={glowColor} strokeWidth="1" className="opacity-30" />

          {/* Logo outline at top */}
          <path d="M54,35 L66,35 L60,45 Z" fill="none" stroke="#52525b" strokeWidth="1" />

          {/* OLED Screen */}
          <rect x="35" y="55" width="50" height="28" rx="2" fill="#09090b" stroke="#27272a" strokeWidth="1" />
          <rect x="38" y="58" width="44" height="22" fill="#09090b" />
          
          {/* Lock icon inside Trezor screen */}
          <circle cx="60" cy="67" r="4" fill="none" stroke="#eab308" strokeWidth="1" />
          <rect x="56" y="67" width="8" height="7" fill="#eab308" rx="0.5" />
          <text x="46" y="78" fill="#eab308" fontSize="4" fontFamily="monospace" textAnchor="middle">TREZOR</text>

          {/* Interactive buttons */}
          <rect x="42" y="95" width="15" height="8" rx="1" fill="#27272a" stroke="#52525b" strokeWidth="0.5" />
          <rect x="63" y="95" width="15" height="8" rx="1" fill="#27272a" stroke="#52525b" strokeWidth="0.5" />

          {/* Technical engraving lines */}
          <line x1="45" y1="120" x2="75" y2="120" stroke="#27272a" strokeWidth="1" />
          <circle cx="60" cy="135" r="2" fill="#3f3f46" />
        </svg>
      );

    case 'faraday':
      return (
        <svg id="svg-faraday" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Pouch Bag Body */}
          <rect x="30" y="20" width="60" height="135" rx="2" fill="#111" stroke="#27272a" strokeWidth="2" />
          <rect x="30" y="20" width="60" height="135" rx="2" fill="none" stroke={glowColor} strokeWidth="1" className="opacity-20" />
          
          {/* Stitch details */}
          <line x1="33" y1="20" x2="33" y2="155" stroke="#3f3f46" strokeDasharray="3 3" />
          <line x1="87" y1="20" x2="87" y2="155" stroke="#3f3f46" strokeDasharray="3 3" />
          
          {/* Pouch Flap */}
          <path d="M30,20 L30,45 L60,55 L90,45 L90,20 Z" fill="#1e1e24" stroke="#3f3f46" strokeWidth="1.5" />
          
          {/* Velcro Strip */}
          <rect x="40" y="26" width="40" height="10" fill="#222" stroke="#27272a" />

          {/* RF Grid Shield Pattern */}
          <pattern id="faradayGrid" width="6" height="6" patternUnits="userSpaceOnUse">
            <path d="M 6 0 L 0 0 0 6" fill="none" stroke="rgba(168, 85, 247, 0.15)" strokeWidth="0.5" />
          </pattern>
          <rect x="35" y="65" width="50" height="80" fill="url(#faradayGrid)" />
          <rect x="35" y="65" width="50" height="80" fill="none" stroke="#3f3f46" strokeWidth="1" />

          {/* Label Logo */}
          <rect x="42" y="85" width="36" height="18" fill="#09090b" stroke="#a855f7" strokeWidth="1.5" />
          <text x="60" y="94" fill="#a855f7" fontSize="4.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">FARADAY</text>
          <text x="60" y="100" fill="#a855f7" fontSize="4" fontFamily="monospace" textAnchor="middle">DEFENSE</text>

          {/* Hanging Loop */}
          <path d="M53,20 L53,10 L67,10 L67,20" fill="none" stroke="#27272a" strokeWidth="2" />
        </svg>
      );

    case 'baofeng':
      return (
        <svg id="svg-baofeng" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Antenna */}
          <rect x="38" y="5" width="8" height="40" fill="#18181b" stroke="#3f3f46" />
          <line x1="42" y1="5" x2="42" y2="45" stroke="#22c55e" strokeWidth="1" strokeDasharray="2 2" className="animate-pulse" />

          {/* Power/Volume Knob */}
          <rect x="74" y="12" width="10" height="13" fill="#18181b" stroke="#3f3f46" rx="1" />

          {/* Radio Body */}
          <rect x="30" y="40" width="60" height="125" rx="4" fill="#18181b" stroke="#3f3f46" strokeWidth="1.5" />
          
          {/* LCD Screen */}
          <rect x="38" y="52" width="44" height="25" rx="1" fill="#062f4f" stroke="#06b6d4" strokeWidth="1" />
          
          {/* LCD Content */}
          <text x="42" y="62" fill="#06b6d4" fontSize="5" fontFamily="monospace" fontWeight="bold">RX: 144.000</text>
          <text x="42" y="70" fill="#06b6d4" fontSize="4.5" fontFamily="monospace">CH-01 OPSEC</text>
          {/* Signal Level Indicator */}
          <rect x="72" y="58" width="2" height="4" fill="#22c55e" />
          <rect x="75" y="56" width="2" height="6" fill="#22c55e" />
          <rect x="78" y="54" width="2" height="8" fill="#22c55e" />

          {/* Speaker Grille lines */}
          <line x1="38" y1="85" x2="82" y2="85" stroke="#3f3f46" strokeWidth="1.5" />
          <line x1="42" y1="89" x2="78" y2="89" stroke="#3f3f46" strokeWidth="1.5" />
          <line x1="38" y1="93" x2="82" y2="93" stroke="#3f3f46" strokeWidth="1.5" />
          <line x1="44" y1="97" x2="76" y2="97" stroke="#3f3f46" strokeWidth="1.5" />

          {/* Keypad */}
          {/* Mini 3x4 buttons representing radio keypad */}
          <rect x="38" y="105" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="49" y="105" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="60" y="105" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="71" y="105" width="8" height="6" rx="0.5" fill="#ef4444" /> {/* Orange/Red MENU */}

          <rect x="38" y="115" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="49" y="115" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="60" y="115" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="71" y="115" width="8" height="6" rx="0.5" fill="#27272a" />

          <rect x="38" y="125" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="49" y="125" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="60" y="125" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="71" y="125" width="8" height="6" rx="0.5" fill="#27272a" />

          <rect x="38" y="135" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="49" y="135" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="60" y="135" width="8" height="6" rx="0.5" fill="#27272a" />
          <rect x="71" y="135" width="8" height="6" rx="0.5" fill="#10b981" /> {/* Green PTT */}

          {/* Model label */}
          <rect x="45" y="150" width="30" height="8" rx="1" fill="#09090b" stroke="#3f3f46" strokeWidth="0.5" />
          <text x="60" y="156" fill="#a1a1aa" fontSize="4" fontFamily="monospace" textAnchor="middle">UV-5R DUAL</text>
        </svg>
      );

    case 'book':
      return (
        <svg id="svg-book" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Isometric styled or 3D looking book */}
          <rect x="30" y="20" width="60" height="140" rx="3" fill="#111" stroke="#3f3f46" strokeWidth="1.5" />
          <rect x="25" y="23" width="5" height="134" rx="1" fill="#e11d48" stroke="#3f3f46" strokeWidth="0.5" />

          {/* Cover lines */}
          <line x1="38" y1="35" x2="82" y2="35" stroke="#f43f5e" strokeWidth="2.5" />
          <line x1="38" y1="43" x2="82" y2="43" stroke="#f43f5e" strokeWidth="2.5" />
          
          {/* Book Title */}
          <rect x="36" y="55" width="48" height="40" fill="#09090b" stroke="#27272a" strokeWidth="1" />
          <text x="60" y="66" fill="#f43f5e" fontSize="5.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">AGAINST</text>
          <text x="60" y="74" fill="#f43f5e" fontSize="5.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">THE</text>
          <text x="60" y="82" fill="#f43f5e" fontSize="5.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">MACHINE</text>

          {/* Abstract cover details */}
          <circle cx="60" cy="115" r="8" fill="none" stroke="#3f3f46" strokeWidth="1" />
          <line x1="45" y1="115" x2="75" y2="115" stroke="#3f3f46" strokeWidth="0.5" />
          <line x1="60" y1="100" x2="60" y2="130" stroke="#3f3f46" strokeWidth="0.5" />

          <text x="60" y="145" fill="#71717a" fontSize="3.5" fontFamily="monospace" textAnchor="middle">An Autonomous Handbook</text>
        </svg>
      );

    case 'hoodie':
      return (
        <svg id="svg-hoodie" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Hood */}
          <path d="M45,35 C45,15, 75,15, 75,35" fill="none" stroke="#27272a" strokeWidth="4" />
          <path d="M48,35 C48,20, 72,20, 72,35" fill="none" stroke="#10b981" strokeWidth="1" strokeDasharray="2 2" />

          {/* Shoulders & Sleeves */}
          <path d="M20,60 L35,45 L45,45 L75,45 L85,45 L100,60 L92,85 L85,80 L85,150 L35,150 L35,80 L28,85 Z" fill="#18181b" stroke="#3f3f46" strokeWidth="1.5" />

          {/* Drawstrings */}
          <line x1="52" y1="35" x2="52" y2="58" stroke="#10b981" strokeWidth="1.5" />
          <line x1="68" y1="35" x2="68" y2="54" stroke="#10b981" strokeWidth="1.5" />
          <circle cx="52" cy="58" r="1" fill="#10b981" />
          <circle cx="68" cy="54" r="1" fill="#10b981" />

          {/* Kangaroo Pocket */}
          <path d="M45,115 L75,115 L80,135 L40,135 Z" fill="#27272a" stroke="#3f3f46" strokeWidth="1" />

          {/* Custom graphic print on center */}
          <rect x="42" y="65" width="36" height="36" fill="#09090b" stroke="#10b981" strokeWidth="1" />
          <text x="60" y="77" fill="#10b981" fontSize="4.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">EXIT</text>
          <text x="60" y="84" fill="#10b981" fontSize="4" fontFamily="monospace" textAnchor="middle">THE</text>
          <text x="60" y="91" fill="#10b981" fontSize="4.5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">SYSTEM</text>

          {/* Cuffs */}
          <rect x="25" y="83" width="6" height="4" fill="#27272a" />
          <rect x="89" y="83" width="6" height="4" fill="#27272a" />
          <rect x="35" y="146" width="50" height="4" fill="#27272a" />
        </svg>
      );

    case 'yubikey':
      return (
        <svg id="svg-yubikey" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Main key body */}
          <rect x="35" y="25" width="50" height="110" rx="10" fill="#18181b" stroke="#3f3f46" strokeWidth="1.5" />
          
          {/* Keychain hole */}
          <circle cx="60" cy="40" r="8" fill="#09090b" stroke="#3f3f46" strokeWidth="1" />

          {/* Golden contacts circle */}
          <circle cx="60" cy="90" r="16" fill="#1e1b4b" stroke="#eab308" strokeWidth="2" className="animate-pulse" />
          
          {/* Engraving detail inside golden circle */}
          <path d="M55,90 A5,5 0 0,1 65,90" fill="none" stroke="#eab308" strokeWidth="1.5" />
          <line x1="60" y1="85" x2="60" y2="95" stroke="#eab308" strokeWidth="1.5" />

          {/* Technical text */}
          <text x="60" y="122" fill="#52525b" fontSize="4.5" fontFamily="monospace" textAnchor="middle">FIDO2 / NFC</text>
          <line x1="45" y1="112" x2="75" y2="112" stroke="#27272a" strokeWidth="1" />
        </svg>
      );

    case 'starlink':
      return (
        <svg id="svg-starlink" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Satellite Dish Panel */}
          <g transform="rotate(-15 60 70)">
            <rect x="25" y="30" width="70" height="48" rx="2" fill="#27272a" stroke="#52525b" strokeWidth="1.5" />
            <rect x="25" y="30" width="70" height="48" rx="2" fill="none" stroke={glowColor} strokeWidth="1" className="opacity-30" />
            <line x1="25" y1="54" x2="95" y2="54" stroke="#52525b" strokeWidth="0.5" />
            <line x1="60" y1="30" x2="60" y2="78" stroke="#52525b" strokeWidth="0.5" />
          </g>

          {/* Stand Pole */}
          <path d="M60,82 L60,135" fill="none" stroke="#52525b" strokeWidth="4" />
          
          {/* Heavy Kickstand Base */}
          <path d="M35,135 L85,135 M40,135 L30,150 M80,135 L90,150" fill="none" stroke="#3f3f46" strokeWidth="3" />

          {/* Upward transmission beams */}
          <path d="M35,20 Q60,5 85,20" fill="none" stroke="#06b6d4" strokeWidth="1" strokeDasharray="3 3" className="animate-pulse" />
          <path d="M45,12 Q60,0 75,12" fill="none" stroke="#06b6d4" strokeWidth="1" strokeDasharray="2 2" className="animate-pulse" />

          <text x="60" y="166" fill="#52525b" fontSize="4.5" fontFamily="monospace" textAnchor="middle">COSMIC NETWORK</text>
        </svg>
      );

    case 'stove':
      return (
        <svg id="svg-stove" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Cylindrical metal body */}
          <rect x="35" y="45" width="50" height="90" rx="3" fill="#18181b" stroke="#3f3f46" strokeWidth="1.5" />
          <rect x="35" y="45" width="50" height="90" rx="3" fill="none" stroke="#f59e0b" strokeWidth="1" className="opacity-20" />

          {/* Grid vent holes at bottom */}
          <circle cx="43" cy="120" r="1.5" fill="#27272a" />
          <circle cx="51" cy="120" r="1.5" fill="#27272a" />
          <circle cx="60" cy="120" r="1.5" fill="#27272a" />
          <circle cx="69" cy="120" r="1.5" fill="#27272a" />
          <circle cx="77" cy="120" r="1.5" fill="#27272a" />

          <circle cx="43" cy="127" r="1.5" fill="#27272a" />
          <circle cx="51" cy="127" r="1.5" fill="#27272a" />
          <circle cx="60" cy="127" r="1.5" fill="#27272a" />
          <circle cx="69" cy="127" r="1.5" fill="#27272a" />
          <circle cx="77" cy="127" r="1.5" fill="#27272a" />

          {/* Top burner vents */}
          <rect x="30" y="38" width="60" height="8" rx="1" fill="#27272a" stroke="#3f3f46" />
          <line x1="35" y1="42" x2="85" y2="42" stroke="#111" strokeWidth="2" />

          {/* Glowing fire/heat rings inside upper body */}
          <path d="M42,40 C42,20, 50,15, 48,32 C52,12, 62,8, 60,32 C65,15, 75,20, 72,40" fill="none" stroke="#f59e0b" strokeWidth="1.5" className="animate-pulse" />
          <path d="M48,40 C48,25, 55,20, 52,35 C56,18, 64,15, 62,35 C66,22, 70,25, 68,40" fill="none" stroke="#ef4444" strokeWidth="1" />

          {/* Metallic brushed pattern lines */}
          <line x1="40" y1="60" x2="80" y2="60" stroke="#27272a" strokeWidth="1" />
          <line x1="40" y1="80" x2="80" y2="80" stroke="#27272a" strokeWidth="1" />
          <line x1="40" y1="100" x2="80" y2="100" stroke="#27272a" strokeWidth="1" />

          <text x="60" y="155" fill="#52525b" fontSize="4.5" fontFamily="monospace" textAnchor="middle">BIOMASS PYROLYSIS</text>
        </svg>
      );

    case 'stickers':
      return (
        <svg id="svg-stickers" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Stacked geometric stickers */}
          {/* Sticker 1: Monero triangle logo badge */}
          <g transform="rotate(-10 50 80)">
            <rect x="20" y="30" width="50" height="50" rx="3" fill="#18181b" stroke="#f97316" strokeWidth="1.5" />
            {/* Monero Symbol inside */}
            <path d="M28,68 L28,42 L38,55 L48,42 L48,68 M28,68 L34,68 L34,57 L38,62 L42,57 L42,68 L48,68" fill="none" stroke="#f97316" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
            <text x="45" y="38" fill="#f97316" fontSize="4" fontFamily="monospace">XMR</text>
          </g>

          {/* Sticker 2: Bitcoin circle badge */}
          <g transform="rotate(15 70 100)">
            <rect x="50" y="55" width="48" height="48" rx="24" fill="#18181b" stroke="#f59e0b" strokeWidth="1.5" />
            <circle cx="74" cy="79" r="14" fill="#f59e0b" />
            <text x="74" y="84" fill="#18181b" fontSize="13" fontFamily="sans-serif" fontWeight="bold" textAnchor="middle">₿</text>
          </g>

          {/* Sticker 3: Opsec badge */}
          <g transform="rotate(-5 60 125)">
            <rect x="30" y="110" width="60" height="25" rx="2" fill="#06b6d4" stroke="#09090b" strokeWidth="1" />
            <text x="60" y="125" fill="#09090b" fontSize="5" fontFamily="monospace" fontWeight="bold" textAnchor="middle">OPSEC CONFIRMED</text>
            <line x1="35" y1="129" x2="85" y2="129" stroke="#09090b" strokeWidth="1.5" />
          </g>
          
          <text x="60" y="160" fill="#52525b" fontSize="4" fontFamily="monospace" textAnchor="middle">12 HIGH-CONTRAST PRINTS</text>
        </svg>
      );

    case 'manifesto':
      return (
        <svg id="svg-manifesto" className={`${className} text-zinc-400`} viewBox="0 0 120 180" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Slim booklet layout */}
          <rect x="25" y="15" width="70" height="150" rx="2" fill="#09090b" stroke="#a855f7" strokeWidth="2" />
          
          {/* Spine stitch */}
          <line x1="28" y1="15" x2="28" y2="165" stroke="#3f3f46" strokeWidth="1" strokeDasharray="2 2" />

          {/* Cover typography */}
          <text x="60" y="45" fill="#a855f7" fontSize="7" fontFamily="monospace" fontWeight="bold" textAnchor="middle">CRYPTONOTE</text>
          <text x="60" y="53" fill="#a855f7" fontSize="4.5" fontFamily="monospace" textAnchor="middle">v 1.0 MANIFESTO</text>
          
          {/* Abstract security graph on cover */}
          <circle cx="60" cy="95" r="22" fill="none" stroke="#27272a" strokeWidth="1" />
          <circle cx="60" cy="95" r="14" fill="none" stroke="#a855f7" strokeWidth="0.5" strokeDasharray="2 2" />
          
          {/* Nodes around circle */}
          <circle cx="42" cy="85" r="2" fill="#a855f7" />
          <circle cx="78" cy="85" r="2" fill="#a855f7" />
          <circle cx="60" cy="117" r="2" fill="#a855f7" />
          
          <line x1="42" y1="85" x2="78" y2="85" stroke="rgba(168, 85, 247, 0.3)" strokeWidth="0.5" />
          <line x1="42" y1="85" x2="60" y2="117" stroke="rgba(168, 85, 247, 0.3)" strokeWidth="0.5" />
          <line x1="78" y1="85" x2="60" y2="117" stroke="rgba(168, 85, 247, 0.3)" strokeWidth="0.5" />

          {/* Mathematical symbol */}
          <text x="60" y="100" fill="#a855f7" fontSize="11" fontFamily="sans-serif" textAnchor="middle">∑</text>

          <text x="60" y="145" fill="#52525b" fontSize="4.5" fontFamily="monospace" textAnchor="middle">CONFIDENTIAL VALUE</text>
        </svg>
      );

    default:
      return null;
  }
}
