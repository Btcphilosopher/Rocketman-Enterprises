import React from 'react';
import { Product } from '../types';
import ProductVector from './ProductVector';
import { motion } from 'motion/react';
import { ArrowUpRight } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onViewClick: (product: Product) => void;
  key?: any;
}

export default function ProductCard({ product, onViewClick }: ProductCardProps) {
  // Let's decide a color theme for the product based on its category
  let glowColor = '#06b6d4'; // default cyan
  let borderHoverClass = 'hover:border-cyan-500/50';
  let badgeColor = 'text-cyan-400 bg-cyan-950/20 border-cyan-900/60';
  let priceColor = 'text-cyan-400';

  if (product.category === 'opsec') {
    glowColor = '#06b6d4'; // Cyan
    borderHoverClass = 'hover:border-cyan-500/80 glow-cyan-hover';
    badgeColor = 'text-cyan-400 bg-cyan-950/20 border-cyan-900/60';
  } else if (product.category === 'dec-tech') {
    glowColor = '#eab308'; // Amber/Yellow
    borderHoverClass = 'hover:border-amber-500/80 glow-amber-hover';
    badgeColor = 'text-amber-400 bg-amber-950/20 border-amber-900/60';
    priceColor = 'text-amber-400';
  } else if (product.category === 'comm') {
    glowColor = '#10b981'; // Green
    borderHoverClass = 'hover:border-emerald-500/80 glow-cyan-hover';
    badgeColor = 'text-emerald-400 bg-emerald-950/20 border-emerald-900/60';
    priceColor = 'text-emerald-400';
  } else if (product.category === 'books') {
    glowColor = '#f43f5e'; // Pink/Rose
    borderHoverClass = 'hover:border-rose-500/80 glow-magenta-hover';
    badgeColor = 'text-rose-400 bg-rose-950/20 border-rose-900/60';
    priceColor = 'text-rose-400';
  } else if (product.category === 'apparel') {
    glowColor = '#a855f7'; // Purple
    borderHoverClass = 'hover:border-purple-500/80 glow-purple-hover';
    badgeColor = 'text-purple-400 bg-purple-950/20 border-purple-900/60';
    priceColor = 'text-purple-400';
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-20px' }}
      transition={{ duration: 0.4 }}
      className={`group bg-black/60 border border-cyan-900/30 p-4 rounded-none flex flex-col justify-between transition-all duration-300 relative ${borderHoverClass}`}
    >
      {/* Cyber Corner Decors */}
      <div className="absolute top-0 left-0 w-2 h-2 border-t border-l border-cyan-950 group-hover:border-cyan-400 transition-colors" />
      <div className="absolute top-0 right-0 w-2 h-2 border-t border-r border-cyan-950 group-hover:border-cyan-400 transition-colors" />
      <div className="absolute bottom-0 left-0 w-2 h-2 border-b border-l border-cyan-950 group-hover:border-cyan-400 transition-colors" />
      <div className="absolute bottom-0 right-0 w-2 h-2 border-b border-r border-cyan-950 group-hover:border-cyan-400 transition-colors" />

      {/* Product Image/Vector Drawing container */}
      <div className="relative w-full h-48 bg-black/80 rounded-none border border-cyan-900/30 flex items-center justify-center p-3 overflow-hidden transition-colors group-hover:bg-black/95">
        
        {/* Repeating scanlines match card specific category glow color */}
        <div 
          className="absolute inset-0 opacity-15 pointer-events-none" 
          style={{ 
            backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 1px, ${glowColor} 1px, ${glowColor} 2px)`,
            backgroundSize: '100% 3px' 
          }} 
        />
        
        <ProductVector type={product.iconType} className="w-auto h-40 max-w-full relative z-10" glowColor={glowColor} />
        
        {/* Category tag */}
        <span className={`absolute top-2.5 left-2.5 font-mono text-[8px] font-bold tracking-widest border px-2 py-0.5 rounded-none uppercase ${badgeColor}`}>
          {product.type}
        </span>
      </div>

      {/* Info Block */}
      <div className="mt-4 flex flex-col gap-1.5 flex-grow font-mono">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display font-black text-[13px] tracking-wider text-zinc-100 group-hover:text-white uppercase italic transition-colors">
            {product.title}
          </h3>
          <span className="font-mono text-[8.5px] text-gray-500 uppercase tracking-widest">
            {product.category}
          </span>
        </div>
        
        <p className="font-sans text-[11px] text-gray-400 leading-normal line-clamp-2 mb-3">
          {product.description}
        </p>
      </div>

      {/* Pricing & Add Trigger Row */}
      <div className="mt-auto pt-3.5 border-t border-cyan-900/20 flex flex-col gap-3 font-mono">
        <div className="flex items-center justify-between font-mono">
          <div className="flex items-center gap-1">
            <span className="text-[10px] text-amber-500 font-bold">₿</span>
            <span className="text-[11.5px] font-bold text-gray-200 tracking-tight">
              {product.priceBTC.toFixed(4)}
            </span>
          </div>
          <div className="flex items-center gap-1 text-right">
            <span className="text-[9px] text-purple-500 font-bold">XMR</span>
            <span className="text-[11px] font-semibold text-gray-400 tracking-tight">
              {product.priceXMR.toFixed(3)}
            </span>
          </div>
        </div>

        {/* Action Button */}
        <button
          onClick={() => onViewClick(product)}
          className="w-full bg-black/40 text-[10px] font-mono tracking-wider font-bold uppercase py-2.5 transition-all cursor-pointer flex items-center justify-center gap-1 rounded-none border"
          style={{ borderColor: glowColor + '60', color: glowColor }}
          onMouseEnter={(e) => {
            e.currentTarget.style.backgroundColor = glowColor;
            e.currentTarget.style.color = '#000000';
            e.currentTarget.style.boxShadow = `0 0 10px ${glowColor}80`;
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.backgroundColor = 'transparent';
            e.currentTarget.style.color = glowColor;
            e.currentTarget.style.boxShadow = 'none';
          }}
        >
          <span>VIEW PRODUCT</span>
          <ArrowUpRight className="w-3.5 h-3.5 shrink-0" />
        </button>
      </div>
    </motion.div>
  );
}
