import React, { useState } from 'react';
import { Search, ShoppingCart, Lock, Terminal, Shield } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onCartOpen: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onNavClick: (sectionId: string) => void;
  onLoginClick: () => void;
}

export default function Navbar({
  cartCount,
  onCartOpen,
  searchQuery,
  setSearchQuery,
  onNavClick,
  onLoginClick
}: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/85 backdrop-blur-md border-b border-cyan-900/50 px-4 lg:px-8 py-3.5 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Logo Section */}
        <div 
          onClick={() => onNavClick('shop')} 
          className="flex items-center gap-3 cursor-pointer group shrink-0"
        >
          <div className="relative w-7 h-7 bg-cyan-400 rotate-45 shadow-[0_0_8px_#00f3ff] flex items-center justify-center transition-all group-hover:bg-cyan-300">
            <span className="text-black font-black font-display text-xs -rotate-45 block transform">Ø</span>
          </div>
          <div className="hidden sm:block">
            <span className="font-display font-black tracking-wider text-sm text-white group-hover:text-cyan-400 transition-colors uppercase italic">
              COUNTER-ECONOMICS
            </span>
            <span className="block font-mono text-[8.5px] text-gray-500 tracking-widest leading-none">
              SECURE DECENTRALIZED PARALLEL
            </span>
          </div>
        </div>

        {/* Navigation Links - Desktop */}
        <div className="hidden md:flex items-center gap-1.5 lg:gap-3 text-gray-400 font-mono text-xs font-medium tracking-wider">
          {[
            { id: 'shop', label: 'SHOP' },
            { id: 'manifesto', label: 'MANIFESTO' },
            { id: 'about', label: 'ABOUT' },
            { id: 'shipping', label: 'SHIPPING' },
            { id: 'faq', label: 'FAQ' },
            { id: 'contact', label: 'CONTACT' }
          ].map((link) => (
            <button
              key={link.id}
              onClick={() => onNavClick(link.id)}
              className="px-2.5 py-1 rounded-none hover:text-cyan-400 hover:bg-black/60 border border-transparent hover:border-cyan-900/30 transition-all cursor-pointer relative group"
            >
              {link.label}
              <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-cyan-500 transition-all group-hover:w-full" />
            </button>
          ))}
        </div>

        {/* Action Items */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-end">
          
          {/* Search Input */}
          <div className="relative max-w-[160px] sm:max-w-[200px] lg:max-w-[240px] w-full">
            <input
              type="text"
              placeholder="SEARCH THE SYSTEM..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-black/60 border border-cyan-900/40 text-gray-200 placeholder-zinc-600 rounded-none px-3 py-1.5 pl-8 text-[11px] font-mono focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-500/20 transition-all"
            />
            <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-zinc-500" />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2 w-4 h-4 rounded-full flex items-center justify-center bg-zinc-800 hover:bg-zinc-700 text-zinc-400 text-[9px] font-mono"
              >
                X
              </button>
            )}
          </div>

          {/* Login/PGP Button */}
          <button
            onClick={onLoginClick}
            className="hidden sm:flex items-center gap-1.5 bg-black/60 hover:bg-black/90 text-gray-400 hover:text-cyan-400 border border-cyan-900/30 hover:border-cyan-900/60 rounded-none px-3 py-1.5 text-[11px] font-mono tracking-wider transition-all cursor-pointer"
          >
            <Lock className="w-3 h-3" />
            <span>LOGIN / PGP</span>
          </button>

          {/* Cart Button */}
          <button
            onClick={onCartOpen}
            className="flex items-center gap-2 bg-black/60 hover:bg-cyan-950/20 border border-cyan-900/40 hover:border-cyan-400 text-gray-200 hover:text-cyan-400 rounded-none px-3.5 py-1.5 text-[11px] font-mono tracking-wider transition-all cursor-pointer"
          >
            <ShoppingCart className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden xs:inline">CART</span>
            <span className="bg-cyan-950/80 text-cyan-400 border border-cyan-800/50 rounded-none px-1.5 py-0.5 text-[10px] font-bold">
              {cartCount}
            </span>
          </button>

          {/* Hamburger Menu - Mobile */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-1.5 bg-black border border-cyan-900/40 rounded-none text-gray-400 hover:text-cyan-400 cursor-pointer"
          >
            <span className="block w-5 h-0.5 bg-current mb-1" />
            <span className="block w-5 h-0.5 bg-current mb-1" />
            <span className="block w-5 h-0.5 bg-current" />
          </button>

        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden mt-3 bg-black border border-cyan-900/40 p-4 rounded-none flex flex-col gap-2 font-mono text-[11px] tracking-widest text-gray-400">
          {[
            { id: 'shop', label: 'SHOP' },
            { id: 'manifesto', label: 'MANIFESTO' },
            { id: 'about', label: 'ABOUT' },
            { id: 'shipping', label: 'SHIPPING' },
            { id: 'faq', label: 'FAQ' },
            { id: 'contact', label: 'CONTACT' }
          ].map((link) => (
            <button
              key={link.id}
              onClick={() => {
                onNavClick(link.id);
                setIsMobileMenuOpen(false);
              }}
              className="text-left py-2 px-3 hover:text-cyan-400 hover:bg-black/40 rounded-none border border-transparent hover:border-cyan-900/20"
            >
              &gt; {link.label}
            </button>
          ))}
          <button
            onClick={() => {
              onLoginClick();
              setIsMobileMenuOpen(false);
            }}
            className="flex items-center gap-2 py-2 px-3 text-amber-400 hover:bg-black/40 rounded-none border border-transparent"
          >
            <Lock className="w-3 h-3" />
            LOGIN / SIGN PGP KEY
          </button>
        </div>
      )}
    </nav>
  );
}
