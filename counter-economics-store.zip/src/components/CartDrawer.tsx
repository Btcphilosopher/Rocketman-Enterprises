import React, { useState, useEffect } from 'react';
import { X, Plus, Minus, Trash2, Key, ShieldCheck, QrCode, Clipboard, Check, Terminal, Heart } from 'lucide-react';
import { CartItem, Product } from '../types';
import { motion, AnimatePresence } from 'motion/react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}: CartDrawerProps) {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'invoice'>('cart');
  const [selectedCoin, setSelectedCoin] = useState<'BTC' | 'XMR'>('XMR');
  const [shippingAddress, setShippingAddress] = useState('');
  const [alias, setAlias] = useState('');
  const [pgpKey, setPgpKey] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  
  // Invoice Simulation State
  const [invoiceProgress, setInvoiceProgress] = useState(0);
  const [invoiceLogs, setInvoiceLogs] = useState<string[]>([]);
  const [txHash, setTxHash] = useState('');

  const totalBTC = cartItems.reduce((acc, item) => acc + (item.product.priceBTC * item.quantity), 0);
  const totalXMR = cartItems.reduce((acc, item) => acc + (item.product.priceXMR * item.quantity), 0);

  // Addresses for payment
  const mockAddresses = {
    BTC: 'bc1q96p66z0p534m678m5v2ny3xepdfv899clwty7f',
    XMR: '44AFFBcf56xP788mDfyUe88Pq4m89R7fV9q9clZwy7fN89mDfyUe88Pq4m89R7fV9q9clZw'
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(mockAddresses[selectedCoin]);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Run simulation when invoice page is loaded
  useEffect(() => {
    if (checkoutStep !== 'invoice') {
      setInvoiceProgress(0);
      setInvoiceLogs([]);
      return;
    }

    // Initialize transaction details
    const hash = Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join('');
    setTxHash(hash);

    const logMessages = [
      'Establishing confidential peer link...',
      'Secure invoice request received from client node.',
      `Generating temporary ${selectedCoin} receiver address...`,
      'Invoice address created. Standing by for transaction...',
      'Monitoring transaction pool for broadcast signs...',
    ];

    let currentLogIdx = 0;
    const interval = setInterval(() => {
      if (currentLogIdx < logMessages.length) {
        setInvoiceLogs((prev) => [...prev, `[${new Date().toLocaleTimeString()}] ${logMessages[currentLogIdx]}`]);
        currentLogIdx++;
        setInvoiceProgress((currentLogIdx / 10) * 100);
      } else {
        clearInterval(interval);
        
        // Phase 2: Simulate payment received after 7 seconds
        setTimeout(() => {
          setInvoiceLogs((prev) => [
            ...prev,
            `[${new Date().toLocaleTimeString()}] 🟢 INCOMING PAYMENT BROADCAST DETECTED!`,
            `[${new Date().toLocaleTimeString()}] Tx ID: ${hash.slice(0, 8)}...${hash.slice(-8)}`,
            `[${new Date().toLocaleTimeString()}] Status: Mempool pending (0/1 confirmation)...`
          ]);
          setInvoiceProgress(70);

          // Phase 3: Confirm payment
          setTimeout(() => {
            setInvoiceLogs((prev) => [
              ...prev,
              `[${new Date().toLocaleTimeString()}] ⛓️ BLOCK CONFIRMED (Height: #849202)`,
              `[${new Date().toLocaleTimeString()}] ✓ Cryptographic balance verification matched exactly.`,
              `[${new Date().toLocaleTimeString()}] ✓ Queue order placed into DISCRETE_DELIVERY_PREP.`,
              `[${new Date().toLocaleTimeString()}] SYSTEM: Thank you for keeping trade parallel.`
            ]);
            setInvoiceProgress(100);
            onClearCart();
          }, 5000);

        }, 4000);
      }
    }, 1200);

    return () => clearInterval(interval);
  }, [checkoutStep, selectedCoin]);

  const handleClose = () => {
    onClose();
    // Reset steps after slide closing transition
    setTimeout(() => {
      setCheckoutStep('cart');
    }, 300);
  };

  // Draw simulated cool QR code using squares inside Canvas
  const renderMockQR = () => {
    return (
      <div className="relative w-40 h-40 bg-white p-2 rounded-none border border-cyan-900/50 flex items-center justify-center shadow-lg group">
        <div className="grid grid-cols-10 gap-1 w-full h-full">
          {Array.from({ length: 100 }).map((_, i) => {
            // Static random blocks to look like QR
            const isCorner = 
              (i < 3 || (i >= 7 && i < 10) || (i >= 20 && i < 23) || (i >= 27 && i < 30) || (i >= 70 && i < 73) || (i >= 90 && i < 93));
            const isFill = isCorner || Math.sin(i * 3.14) > 0.1;
            return (
              <div
                key={i}
                className={`rounded-none transition-colors duration-500 ${
                  isFill ? 'bg-zinc-950' : 'bg-white'
                }`}
              />
            );
          })}
        </div>
        <div className="absolute inset-0 bg-transparent flex items-center justify-center">
          <div className="p-1 bg-white border border-zinc-200 rounded-none">
            {selectedCoin === 'BTC' ? (
              <span className="font-bold text-amber-500 text-xs">₿</span>
            ) : (
              <span className="font-bold text-[#f97316] text-[10px]">XMR</span>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 overflow-hidden font-mono">
          
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="absolute inset-0 bg-black/80"
          />

          {/* Drawer Panel */}
          <div className="absolute inset-y-0 right-0 max-w-full flex">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="w-screen max-w-md bg-black/95 border-l border-cyan-900/40 p-5 sm:p-6 flex flex-col justify-between shadow-[0_0_50px_rgba(0,0,0,0.9)] relative backdrop-blur-md"
            >
              {/* Corner decors */}
              <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-cyan-400" />
              <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-cyan-400" />

              {/* Close and Header */}
              <div>
                <div className="flex items-center justify-between border-b border-cyan-900/20 pb-3 mb-5">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-4 h-4 text-cyan-400" />
                    <span className="text-xs font-bold text-zinc-200 uppercase tracking-widest">
                      {checkoutStep === 'cart' && 'SYSTEM_CART_STATUS'}
                      {checkoutStep === 'shipping' && 'DELIVERY_ROUTING'}
                      {checkoutStep === 'invoice' && 'SECURE_CRYPT_INVOICE'}
                    </span>
                  </div>
                  
                  <button
                    onClick={handleClose}
                    className="p-1 rounded-none bg-black border border-cyan-900/30 text-zinc-500 hover:text-cyan-400 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* --- STEP 1: CART VIEW --- */}
                {checkoutStep === 'cart' && (
                  <div>
                    {cartItems.length === 0 ? (
                      <div className="text-center py-20 flex flex-col items-center justify-center gap-3">
                        <QrCode className="w-12 h-12 text-zinc-700 animate-pulse" />
                        <p className="text-[11px] text-zinc-500 uppercase tracking-wider">Cart contains 0 nodes.</p>
                        <button
                          onClick={handleClose}
                          className="mt-3 text-[10px] text-cyan-400 font-bold border border-cyan-900/40 px-4 py-2 rounded-none bg-black hover:bg-cyan-950/20 cursor-pointer transition-colors"
                        >
                          &lt; RETURN TO MARKETPLACE
                        </button>
                      </div>
                    ) : (
                      <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-1">
                        {cartItems.map((item) => (
                          <div
                            key={item.product.id}
                            className="bg-black/60 border border-cyan-900/20 p-3 rounded-none flex items-center justify-between gap-3 relative group hover:border-cyan-900/50 transition-all"
                          >
                            <div className="flex items-center gap-3">
                              {/* Coin-themed minimal square icon */}
                              <div className="w-11 h-11 rounded-none border border-cyan-900/30 bg-black flex items-center justify-center p-1 font-mono text-[10px] font-bold text-cyan-400">
                                <sub>id</sub>
                                {item.product.id.slice(0, 3).toUpperCase()}
                              </div>
                              <div>
                                <span className="block text-[11px] font-bold text-zinc-200 uppercase">{item.product.title}</span>
                                <span className="block text-[9px] text-zinc-500 font-bold uppercase">{item.product.type}</span>
                                <div className="flex gap-2.5 mt-1 text-[9.5px] text-zinc-400 font-semibold font-mono">
                                  <span>₿ {item.product.priceBTC}</span>
                                  <span className="text-zinc-600">|</span>
                                  <span>XMR {item.product.priceXMR}</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex flex-col items-end gap-2 shrink-0">
                              <div className="flex items-center gap-1.5 border border-cyan-900/30 rounded-none bg-black px-1.5 py-0.5">
                                <button
                                  onClick={() => onUpdateQuantity(item.product.id, -1)}
                                  className="p-0.5 text-zinc-500 hover:text-cyan-400 transition-colors cursor-pointer"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="text-[10px] text-zinc-200 px-1 font-bold">{item.quantity}</span>
                                <button
                                  onClick={() => onUpdateQuantity(item.product.id, 1)}
                                  className="p-0.5 text-zinc-500 hover:text-cyan-400 transition-colors cursor-pointer"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>
                              <button
                                onClick={() => onRemoveItem(item.product.id)}
                                className="text-[9px] text-rose-500 hover:text-rose-400 flex items-center gap-1 transition-colors cursor-pointer uppercase font-bold"
                              >
                                <Trash2 className="w-3 h-3" /> DELETE
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* --- STEP 2: SHIPPING FORM --- */}
                {checkoutStep === 'shipping' && (
                  <div className="space-y-4">
                    <div className="p-3 border border-purple-900/40 bg-purple-950/20 rounded-none text-[10.5px] leading-relaxed text-purple-400">
                      <p className="font-bold">✓ ABSOLUTE SHIELD SECURE CHANNEL</p>
                      <p className="mt-1 text-zinc-500">
                        Delivery details are stored purely in RAM caches and wiped instantly following packet registration. No databases will retain this info.
                      </p>
                    </div>

                    <div className="space-y-3 pt-2">
                      <div>
                        <label className="block text-[8.5px] text-zinc-500 font-bold mb-1 uppercase">DELIVERY COORDINATES / ADDRESS</label>
                        <textarea
                          placeholder="Provide shipping coordinates. E.g., PO Box, Amazon Locker address, or dead-drop directions. Real name NOT required."
                          value={shippingAddress}
                          onChange={(e) => setShippingAddress(e.target.value)}
                          className="w-full h-20 bg-black border border-cyan-900/40 text-gray-200 placeholder-zinc-700 rounded-none p-2 text-[10.5px] font-mono focus:outline-none focus:border-cyan-400 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-[8.5px] text-zinc-500 font-bold mb-1 uppercase">CONTACT METHOD (OPTIONAL)</label>
                        <input
                          type="text"
                          placeholder="Matrix Alias, Session ID, or anonymous email for tracking hashes"
                          value={alias}
                          onChange={(e) => setAlias(e.target.value)}
                          className="w-full bg-black border border-cyan-900/40 text-gray-200 placeholder-zinc-700 rounded-none px-3 py-2 text-[10.5px] font-mono focus:outline-none focus:border-cyan-400 transition-all"
                        />
                      </div>

                      <div>
                        <label className="block text-[8.5px] text-zinc-500 font-bold mb-1 uppercase flex items-center justify-between">
                          <span>YOUR PGP PUBLIC KEY (OPTIONAL)</span>
                          <span className="text-[7.5px] text-zinc-600">FOR ENCRYPTED ALERTS</span>
                        </label>
                        <textarea
                          placeholder="-----BEGIN PGP PUBLIC KEY BLOCK-----..."
                          value={pgpKey}
                          onChange={(e) => setPgpKey(e.target.value)}
                          className="w-full h-16 bg-black border border-cyan-900/40 text-gray-200 placeholder-zinc-700 rounded-none p-2 text-[9px] font-mono focus:outline-none focus:border-cyan-400 transition-all leading-tight"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* --- STEP 3: CRYPTOGRAPHIC INVOICE --- */}
                {checkoutStep === 'invoice' && (
                  <div className="space-y-5">
                    
                    {/* Coin selector */}
                    <div className="grid grid-cols-2 gap-2 p-1.5 bg-black border border-cyan-900/30 rounded-none">
                      <button
                        onClick={() => setSelectedCoin('XMR')}
                        className={`py-2 text-[10.5px] font-bold rounded-none transition-all cursor-pointer uppercase ${
                          selectedCoin === 'XMR' 
                            ? 'bg-black text-[#f97316] border border-[#f97316]/40 shadow-[0_0_8px_rgba(249,115,22,0.3)]' 
                            : 'text-zinc-500 hover:text-zinc-300'
                        }`}
                      >
                        PAY WITH MONERO (XMR)
                      </button>
                      <button
                        onClick={() => setSelectedCoin('BTC')}
                        className={`py-2 text-[10.5px] font-bold rounded-none transition-all cursor-pointer uppercase ${
                          selectedCoin === 'BTC' 
                            ? 'bg-black text-amber-500 border border-amber-500/40 shadow-[0_0_8px_rgba(245,158,11,0.3)]' 
                            : 'text-zinc-500 hover:text-zinc-300'
                        }`}
                      >
                        PAY WITH BITCOIN (BTC)
                      </button>
                    </div>

                    {/* QR and Amount block */}
                    <div className="flex flex-col items-center justify-center text-center p-4 bg-black border border-cyan-900/30 rounded-none">
                      <div className="mb-3">
                        {renderMockQR()}
                      </div>

                      <span className="text-[8px] text-zinc-500 font-bold uppercase tracking-wider">TOTAL INVOICE DEBT</span>
                      <div className="font-bold text-lg mt-0.5 mb-1.5 font-mono">
                        {selectedCoin === 'BTC' ? (
                          <span className="text-amber-500">₿ {totalBTC.toFixed(4)}</span>
                        ) : (
                          <span className="text-[#f97316]">XMR {totalXMR.toFixed(3)}</span>
                        )}
                      </div>

                      {/* Copier link */}
                      <div className="w-full bg-black border border-cyan-900/30 rounded-none px-2.5 py-1.5 flex items-center justify-between text-[8px] sm:text-[9.5px]">
                        <span className="text-zinc-500 truncate mr-2 text-left font-mono max-w-[240px]">
                          {mockAddresses[selectedCoin]}
                        </span>
                        <button
                          onClick={handleCopyAddress}
                          className="text-cyan-400 hover:text-cyan-300 transition-colors p-1 bg-black border border-cyan-900/30 rounded-none cursor-pointer flex items-center gap-1 shrink-0 font-bold"
                        >
                          {isCopied ? <Check className="w-3 h-3 text-emerald-400" /> : <Clipboard className="w-3 h-3" />}
                          <span>{isCopied ? 'COPIED' : 'COPY'}</span>
                        </button>
                      </div>
                    </div>

                    {/* Progress tracking terminal logs */}
                    <div className="bg-black border border-cyan-900/40 p-3 rounded-none font-mono text-[9px] text-cyan-400/90 space-y-1 h-36 overflow-y-auto leading-normal">
                      <div className="flex justify-between items-center mb-1 text-cyan-500 font-bold border-b border-cyan-950 pb-1">
                        <span>NODE WORKSPACE DIAGNOSTICS</span>
                        <span>{invoiceProgress.toFixed(0)}%</span>
                      </div>
                      
                      {invoiceLogs.map((log, idx) => (
                        <p key={idx} className="whitespace-pre-wrap">{log}</p>
                      ))}
                      
                      {invoiceProgress < 100 && (
                        <p className="animate-pulse flex items-center gap-1.5 text-zinc-500">
                          <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-ping" />
                          Listening for network packets...
                        </p>
                      )}
                    </div>

                  </div>
                )}

              </div>

              {/* --- BOTTOM SUMMARY AND CONTROLS --- */}
              <div className="border-t border-cyan-900/30 pt-5 mt-4 space-y-4 bg-black/90">
                {checkoutStep === 'cart' && cartItems.length > 0 && (
                  <>
                    <div className="bg-black border border-cyan-900/30 p-3 rounded-none space-y-1.5">
                      <div className="flex justify-between font-mono text-[10px] text-zinc-500">
                        <span>CART TOTAL (BTC)</span>
                        <span className="font-bold text-zinc-300">₿ {totalBTC.toFixed(4)}</span>
                      </div>
                      <div className="flex justify-between font-mono text-[10.5px] text-zinc-500">
                        <span>CART TOTAL (XMR)</span>
                        <span className="font-bold text-zinc-300">XMR {totalXMR.toFixed(3)}</span>
                      </div>
                      <div className="flex justify-between font-mono text-[11px] font-bold border-t border-cyan-900/20 pt-1.5">
                        <span className="text-zinc-400">PAYMENT EQUIVALENCE</span>
                        <span className="text-cyan-400">DUAL-MODE</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setCheckoutStep('shipping')}
                      className="w-full bg-cyan-500 text-black font-mono text-[11px] font-bold tracking-widest uppercase border border-cyan-300 shadow-[0_0_15px_rgba(0,243,255,0.4)] hover:bg-cyan-400 hover:shadow-[0_0_20px_rgba(0,243,255,0.6)] py-3 transition-all cursor-pointer flex items-center justify-center gap-1.5 rounded-none"
                    >
                      <span>PROCEED TO SECURE ROUTING</span>
                    </button>
                  </>
                )}

                {checkoutStep === 'shipping' && (
                  <div className="flex flex-col sm:flex-row gap-3">
                    <button
                      onClick={() => setCheckoutStep('cart')}
                      className="flex-1 bg-black hover:bg-black/80 text-gray-400 rounded-none py-3 font-mono text-[11px] border border-cyan-900/30 hover:border-cyan-900/60 cursor-pointer text-center uppercase font-bold transition-colors"
                    >
                      BACK TO CART
                    </button>
                    <button
                      onClick={() => setCheckoutStep('invoice')}
                      disabled={!shippingAddress.trim()}
                      className={`flex-1 font-mono text-[11px] font-bold rounded-none py-3 uppercase text-center cursor-pointer transition-all ${
                        shippingAddress.trim()
                          ? 'bg-cyan-500 text-black border border-cyan-300 shadow-[0_0_10px_rgba(0,243,255,0.3)] hover:bg-cyan-400'
                          : 'bg-black text-gray-600 border border-cyan-900/20 cursor-not-allowed'
                      }`}
                    >
                      GENERATE INVOICE
                    </button>
                  </div>
                )}

                {checkoutStep === 'invoice' && (
                  <button
                    onClick={handleClose}
                    className="w-full bg-black hover:bg-black/80 text-gray-300 hover:text-cyan-400 border border-cyan-900/30 rounded-none py-3 font-mono text-[11px] font-bold cursor-pointer text-center uppercase tracking-widest transition-all"
                  >
                    {invoiceProgress === 100 ? 'ORDER REGISTERED - EXIT' : 'MINIMIZE & MONITOR'}
                  </button>
                )}

                <div className="flex items-center justify-center gap-1.5 text-zinc-600 font-mono text-[8px] text-center uppercase">
                  <ShieldCheck className="w-3.5 h-3.5 text-zinc-600" />
                  <span>Encrypted, discrete, decentralized trade network.</span>
                </div>
              </div>

            </motion.div>
          </div>

        </div>
      )}
    </AnimatePresence>
  );
}
