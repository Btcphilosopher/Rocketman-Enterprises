import { useEffect, useRef } from 'react';

interface OscilloscopeProps {
  color?: string;
  height?: number;
  speed?: number;
  amplitude?: number;
  type?: 'sine' | 'bars' | 'noise';
}

export default function Oscilloscope({
  color = '#06b6d4', // Neon Cyan
  height = 40,
  speed = 1.5,
  amplitude = 12,
  type = 'sine'
}: OscilloscopeProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let offset = 0;

    // Resize canvas to match element dimensions
    const resizeCanvas = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Render loop
    const render = () => {
      const w = canvas.width / window.devicePixelRatio;
      const h = canvas.height / window.devicePixelRatio;
      ctx.clearRect(0, 0, w, h);

      if (type === 'sine') {
        // Draw grid lines
        ctx.strokeStyle = 'rgba(20, 20, 25, 0.3)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, h / 2);
        ctx.lineTo(w, h / 2);
        ctx.stroke();

        // Draw glowing wave
        ctx.strokeStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 6;
        ctx.lineWidth = 1.5;
        ctx.beginPath();

        for (let x = 0; x < w; x++) {
          const angle = (x / w) * Math.PI * 4 + offset;
          const y = h / 2 + Math.sin(angle) * amplitude * (0.3 + 0.7 * Math.sin(x / w * Math.PI));
          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();

        // Reset shadow
        ctx.shadowBlur = 0;
      } else if (type === 'bars') {
        // Draw vertical signal bars (like spectrum analyzer)
        const barWidth = 4;
        const gap = 2;
        const barCount = Math.floor(w / (barWidth + gap));
        
        ctx.shadowColor = color;
        ctx.shadowBlur = 4;
        ctx.fillStyle = color;

        for (let i = 0; i < barCount; i++) {
          const percent = (i / barCount);
          const noiseFactor = Math.sin(offset + i * 0.3) * Math.cos(offset * 0.5 + i * 0.1);
          const baseHeight = h * 0.7 * (0.5 + 0.5 * Math.sin(percent * Math.PI));
          const barHeight = Math.max(3, baseHeight * (0.4 + 0.6 * Math.abs(noiseFactor)));

          const x = i * (barWidth + gap);
          const y = h - barHeight;

          // Draw the main glowing bar
          ctx.fillRect(x, y, barWidth, barHeight);
        }
        ctx.shadowBlur = 0;
      } else if (type === 'noise') {
        // Digital lightning/static line
        ctx.strokeStyle = color;
        ctx.shadowColor = color;
        ctx.shadowBlur = 8;
        ctx.lineWidth = 1;
        ctx.beginPath();

        for (let x = 0; x < w; x += 3) {
          const randomFactor = (Math.random() - 0.5) * amplitude * 0.6;
          const waveFactor = Math.sin((x / w) * Math.PI * 2 + offset) * amplitude * 0.8;
          const y = h / 2 + waveFactor + randomFactor;

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      offset += speed * 0.05;
      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [color, height, speed, amplitude, type]);

  return (
    <div className="w-full relative overflow-hidden" style={{ height: `${height}px` }}>
      <canvas
        id={`oscilloscope-${type}`}
        ref={canvasRef}
        className="w-full h-full block"
      />
    </div>
  );
}
