export interface Product {
  id: string;
  title: string;
  category: string;
  type: string;
  priceBTC: number;
  priceXMR: number;
  description: string;
  specs: string[];
  imageUrl?: string;
  iconType: 'coldcard' | 'trezor' | 'faraday' | 'baofeng' | 'book' | 'hoodie' | 'yubikey' | 'starlink' | 'stove' | 'stickers' | 'manifesto';
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Category {
  id: string;
  name: string;
  iconName: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}
