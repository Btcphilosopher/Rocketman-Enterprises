import { Product, Category, FAQItem } from './types';

export const CATEGORIES: Category[] = [
  { id: 'all', name: 'ALL SYSTEMS', iconName: 'LayoutGrid' },
  { id: 'opsec', name: 'OPSEC & PRIVACY', iconName: 'ShieldAlert' },
  { id: 'dec-tech', name: 'DECENTRALIZED TECH', iconName: 'Cpu' },
  { id: 'comm', name: 'COMMUNICATION', iconName: 'Radio' },
  { id: 'survival', name: 'SURVIVAL & SELF-RELIANCE', iconName: 'Compass' },
  { id: 'books', name: 'BOOKS & MEDIA', iconName: 'BookOpen' },
  { id: 'apparel', name: 'APPAREL', iconName: 'Shirt' },
  { id: 'stickers', name: 'STICKERS & PRINTS', iconName: 'Tag' },
  { id: 'donate', name: 'DONATE / SUPPORT', iconName: 'Heart' }
];

export const PRODUCTS: Product[] = [
  {
    id: 'coldcard-mk4',
    title: 'COLDCARD MK4',
    category: 'opsec',
    type: 'Hardware Wallet',
    priceBTC: 0.0069,
    priceXMR: 0.049,
    description: 'The ultimate cypherpunk hardware wallet. Features ultra-secure dual secure elements, a complete air-gapped operation via MicroSD, full numeric keypad for PIN entry, and native multi-sig support.',
    specs: [
      'Dual Secure Elements (ATECC608B + DS28C36)',
      'Fully Air-Gapped MicroSD Operations',
      'USB-C Connector & NFC Tap Functionality',
      'BIP39 Passphrase & Seed Protection',
      'Encrypted backup & trick PIN features'
    ],
    iconType: 'coldcard'
  },
  {
    id: 'trezor-safe-3',
    title: 'TREZOR SAFE 3',
    category: 'dec-tech',
    type: 'Hardware Wallet',
    priceBTC: 0.0045,
    priceXMR: 0.032,
    description: 'Next-generation open-source hardware wallet with a dedicated secure element and bright OLED display. Designed for absolute cryptographic security and ease of use.',
    specs: [
      'Optiga Trust M Secure Element',
      'High-contrast 0.96 inch OLED screen',
      'Passphrase & Shamir Backup support',
      'On-device confirmation & tactile buttons',
      'Completely open-source firmware design'
    ],
    iconType: 'trezor'
  },
  {
    id: 'faraday-bag',
    title: 'FARADAY BAG',
    category: 'opsec',
    type: 'Signal Blocker',
    priceBTC: 0.0016,
    priceXMR: 0.012,
    description: 'Military-grade RF shielding bag. Instantly blocks cellular, WiFi (2.4 & 5GHz), Bluetooth, GPS, and RFID signals. Keeps your electronic devices completely invisible from external scans.',
    specs: [
      'Double-fold hook and loop closure design',
      'Water-resistant ballistic nylon exterior',
      'Blocks RF, Electromagnetic, and EMP radiation',
      'Dual internal pockets for shielding & storage',
      'Perfect for smartphones, keys, and hardware keys'
    ],
    iconType: 'faraday'
  },
  {
    id: 'baofeng-uv-5r',
    title: 'BAOFENG UV-5R',
    category: 'comm',
    type: 'Dual Band Radio',
    priceBTC: 0.0021,
    priceXMR: 0.015,
    description: 'Rugged dual-band handheld transceiver. The underground standard for local off-grid communications, disaster preparedness, emergency broadcasts, and mesh coordination.',
    specs: [
      'VHF/UHF Dual-Band display & dual standby',
      '65-108MHz FM Radio & 128 Memory Channels',
      'High/Low RF transmitter power settings',
      'Vox voice operated transmission built-in',
      'Upgraded heavy-duty lithium-ion battery pack'
    ],
    iconType: 'baofeng'
  },
  {
    id: 'against-machine',
    title: 'AGAINST THE MACHINE',
    category: 'books',
    type: 'Printed Book',
    priceBTC: 0.0012,
    priceXMR: 0.008,
    description: 'A comprehensive handbook for autonomous action and digital self-defense. Features practical guides on cryptography, decentralized infrastructure, operational security, and counter-economics.',
    specs: [
      'Paperback edition with textured matte black finish',
      '312 pages of technical essays and practical guides',
      'Covers decentralized finance, self-hosting, and physical security',
      'Rich diagrams, network topologies, and PGP setups',
      'Independently printed on eco-friendly paper'
    ],
    iconType: 'book'
  },
  {
    id: 'exit-system-hoodie',
    title: 'EXIT THE SYSTEM',
    category: 'apparel',
    type: 'Hoodie',
    priceBTC: 0.0035,
    priceXMR: 0.025,
    description: 'Ultra-premium heavyweight cotton hoodie. Styled with fluorescent cyber-green and high-contrast glowing digital graphics on chest, back, and sleeves. Engineered for comfort and style.',
    specs: [
      '450 GSM ultra-heavyweight brushback cotton',
      'Double-lined structured hood with custom drawstrings',
      'Fluorescent green glow-in-the-dark graphic prints',
      'Hidden inner zipper pocket for hardware keys',
      'Ribbed side panels for comfort and flexible fit'
    ],
    iconType: 'hoodie'
  },
  {
    id: 'yubikey-5c-nano',
    title: 'YUBIKEY 5C NANO',
    category: 'opsec',
    type: 'Hardware Key',
    priceBTC: 0.0011,
    priceXMR: 0.0075,
    description: 'The worlds smallest FIDO2 security key. Sits flush inside your USB-C port, providing hardware-backed multi-factor authentication (MFA) that is immune to phishing attacks.',
    specs: [
      'Ultra-low profile design (fits flush in USB-C)',
      'Supports FIDO2/WebAuthn, U2F, Smart Card, OTP',
      'IP68 water and crush resistant housing',
      'Made in the USA & Sweden under high security protocols',
      'Touch-to-activate capacitive sensor'
    ],
    iconType: 'yubikey'
  },
  {
    id: 'starlink-roam',
    title: 'STARLINK ROAMING KIT',
    category: 'comm',
    type: 'Satellite Terminal',
    priceBTC: 0.0120,
    priceXMR: 0.085,
    description: 'High-speed, low-latency satellite internet terminal designed for remote or fully off-grid operations. Connects to the low Earth orbit constellation anywhere with clear sky view.',
    specs: [
      'Self-aligning high-performance phased array antenna',
      'Weatherproof IP67 rated construction',
      'High-performance Wi-Fi 6 router included',
      'Low power draw mode with custom DC adapters',
      'Includes 15m ethernet cable and heavy duty kickstand'
    ],
    iconType: 'starlink'
  },
  {
    id: 'solo-stove-camp',
    title: 'SOLO STOVE CAMPFIRE',
    category: 'survival',
    type: 'Biomass Stove',
    priceBTC: 0.0028,
    priceXMR: 0.020,
    description: 'Ultra-efficient camp stove utilizing double-wall signature airflow to achieve secondary combustion. Burns twigs and wood completely smoke-free without relying on petroleum or gas canisters.',
    specs: [
      'Double-wall signature secondary combustion airflow',
      '304 Stainless Steel ultra-durable lightweight shell',
      'Smoke-free, clean-burning efficiency',
      'Burns twigs, pinecones, and leaves - no fuel tanks needed',
      'Nests compactly inside companion pots'
    ],
    iconType: 'stove'
  },
  {
    id: 'decal-pack',
    title: 'CYBER DECAL PACK',
    category: 'stickers',
    type: 'Vinyl Decals',
    priceBTC: 0.0003,
    priceXMR: 0.002,
    description: 'A curated pack of high-durability, weather-proof vinyl decals. Features classic cypherpunk slogans, cryptographic keys, hacker sigils, and terminal-inspired artwork.',
    specs: [
      '12 unique high-contrast sticker designs',
      'Thick, durable vinyl with UV protection coating',
      'Scratch and water resistant (perfect for laptops)',
      'Matte and holographic specialty finishes included',
      'Leaves zero adhesive residue upon removal'
    ],
    iconType: 'stickers'
  },
  {
    id: 'cryptonote-manifesto',
    title: 'CRYPTONOTE BOOKLET',
    category: 'books',
    type: 'Booklet',
    priceBTC: 0.0006,
    priceXMR: 0.004,
    description: 'The foundational cryptographic research paper outlining the creation of untraceable, decentralized payments that birthed confidential transaction technology.',
    specs: [
      'High-contrast silver ink typography on black cardstock',
      '64-page booklet including ring-signature math formulas',
      'Includes critical side-by-side annotations by developers',
      'Printed on premium heavy acid-free paper',
      'Limited numbered underground edition'
    ],
    iconType: 'manifesto'
  }
];

export const FAQS: FAQItem[] = [
  {
    question: 'How do I pay securely?',
    answer: 'We only accept Bitcoin (BTC) and Monero (XMR). Add items to your system cart, proceed to checkout, and select your cryptocurrency. A temporary, confidential QR invoice is generated on-screen. Once our nodes verify the transaction on the blockchain, your order is automatically queued.'
  },
  {
    question: 'Are there any KYC requirements?',
    answer: 'None whatsoever. Your freedom and privacy are absolute. We do not require real names, phone numbers, or credit card billing addresses. Simply provide a valid shipping destination (PO Boxes are highly encouraged) and an optional encrypted communication PGP key.'
  },
  {
    question: 'How are packages shipped?',
    answer: 'All items are shipped globally in completely discrete, unbranded, and double-sealed packaging. There is absolutely no external store branding, description of items, or billing info on the outside. Origin return addresses are randomized.'
  },
  {
    question: 'What is your refund policy?',
    answer: 'All sales are final. Because we process payments through decentralized, irreversible blockchains and do not keep user identity logs, we do not offer standard credit card-like refunds. We strive to provide only military-grade products and double-verify functional integrity before shipping.'
  },
  {
    question: 'Can I use a custom PGP key for messaging?',
    answer: 'Yes! During checkout, you can provide your public PGP key. We will encrypt all shipping alerts, tracking tags, and communication sent to your contact details using your key so that no intermediate network node can read it.'
  }
];
