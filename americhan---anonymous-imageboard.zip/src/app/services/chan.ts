import { Injectable, inject, signal, computed } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';

export interface Post {
  id: number;
  threadId: number;
  boardId: string;
  isOp: boolean;
  author: string;
  posterId: string;
  country: string;
  createdAt: string;
  timestamp: number;
  subject?: string;
  comment: string;
  file?: {
    name: string;
    size: string;
    dimensions: string;
    url: string;
    isSpoiler?: boolean;
    isAttachmentAsset?: boolean;
  };
  capcode?: 'Mod' | 'Admin';
  isBanned?: boolean;
  banReason?: string;
  reportCount?: number;
}

export interface Thread {
  id: number;
  boardId: string;
  opPost: Post;
  replies: Post[];
  replyCount: number;
  imageCount: number;
  isSticky: boolean;
  isClosed: boolean;
  createdAt: string;
  lastBumpTime: number;
}

export interface Board {
  id: string;
  code: string;
  title: string;
  description: string;
  category: 'Interests' | 'Creative' | 'Other' | 'General';
  icon: string;
  thumbnail: string;
  postCount: number;
  rules?: string[];
}

export interface ModLogEntry {
  id: string;
  timestamp: string;
  action: string;
  targetId: number | string;
  details: string;
  modName: string;
}

export interface ReportItem {
  id: string;
  postId: number;
  threadId: number;
  boardId: string;
  reason: string;
  timestamp: string;
  commentSnippet: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

interface ErrorPayload {
  error?: {
    error?: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class ChanStore {
  private http = inject(HttpClient);

  // Core signals
  boards = signal<Board[]>([]);
  currentBoard = signal<Board | null>(null);
  threads = signal<Thread[]>([]);
  currentThread = signal<Thread | null>(null);
  viewMode = signal<'thread' | 'catalog' | 'board'>('thread');
  isLoading = signal<boolean>(false);
  isSubmitting = signal<boolean>(false);
  errorMessage = signal<string | null>(null);
  successMessage = signal<string | null>(null);

  // Settings & Theme
  theme = signal<'tomorrow' | 'yotsuba' | 'photon' | 'cyber'>('tomorrow');
  autoUpdate = signal<boolean>(false);
  autoUpdateSeconds = signal<number>(10);
  soundAlerts = signal<boolean>(true);
  hideImages = signal<boolean>(false);

  // Global Stats
  stats = signal<{ totalPosts: number; activeUsers: number; onlineModerators: number; serverUptime: string }>({
    totalPosts: 4892317602,
    activeUsers: 152348,
    onlineModerators: 18,
    serverUptime: '99.98%'
  });

  // Moderation state
  modSession = signal<{ isLoggedIn: boolean; role: 'Admin' | 'Janitor'; token: string } | null>(null);
  isModLoggedIn = computed(() => !!this.modSession()?.isLoggedIn);
  reports = signal<ReportItem[]>([]);
  modLogs = signal<ModLogEntry[]>([]);

  // Post preview tooltip and quote linking
  hoveredPost = signal<{ post: Post; x: number; y: number } | null>(null);
  highlightedPostId = signal<number | null>(null);

  // Quick reply pre-fill
  quickReplyQuote = signal<string | null>(null);

  constructor() {
    // Load local storage preferences if available in browser
    if (typeof window !== 'undefined') {
      const savedTheme = localStorage.getItem('americhan_theme') as 'tomorrow' | 'yotsuba' | 'photon' | 'cyber' | null;
      if (savedTheme) {
        this.theme.set(savedTheme);
      }
      const savedMod = localStorage.getItem('americhan_mod');
      if (savedMod) {
        try {
          this.modSession.set(JSON.parse(savedMod));
        } catch {
          // ignore
        }
      }
    }
  }

  // Load boards list from server
  async loadBoards(): Promise<void> {
    try {
      const res = await firstValueFrom(this.http.get<{ boards: Board[] }>('/api/boards'));
      this.boards.set(res.boards);
      if (!this.currentBoard() && res.boards.length > 0) {
        // Default to /pol/ as shown in user attachment
        const pol = res.boards.find(b => b.id === 'pol') || res.boards[0];
        this.currentBoard.set(pol);
      }
    } catch (err) {
      console.error('Error loading boards', err);
    }
  }

  // Select board and load its threads
  async selectBoard(boardId: string, targetView: 'thread' | 'catalog' | 'board' = 'board'): Promise<void> {
    this.isLoading.set(true);
    try {
      const res = await firstValueFrom(this.http.get<{ board: Board; threads: Thread[] }>(`/api/boards/${boardId}/threads`));
      this.currentBoard.set(res.board);
      this.threads.set(res.threads);
      this.viewMode.set(targetView);

      // If viewing default /pol/, open thread 38472091 as primary
      if (boardId === 'pol' && res.threads.length > 0 && targetView === 'thread') {
        const primaryThread = res.threads.find(t => t.id === 38472091) || res.threads[0];
        this.currentThread.set(primaryThread);
      } else if (res.threads.length > 0 && targetView === 'thread') {
        this.currentThread.set(res.threads[0]);
      } else {
        this.currentThread.set(null);
      }
    } catch (err: unknown) {
      const msg = (err as ErrorPayload)?.error?.error || 'Failed to load board';
      this.errorMessage.set(msg);
    } finally {
      this.isLoading.set(false);
    }
  }

  // Open specific thread
  async selectThread(threadId: number): Promise<void> {
    this.isLoading.set(true);
    try {
      const res = await firstValueFrom(this.http.get<{ thread: Thread }>(`/api/threads/${threadId}`));
      this.currentThread.set(res.thread);
      this.viewMode.set('thread');

      // Update current board if not matched
      if (res.thread && (!this.currentBoard() || this.currentBoard()?.id !== res.thread.boardId)) {
        const board = this.boards().find(b => b.id === res.thread.boardId);
        if (board) this.currentBoard.set(board);
      }
    } catch (err: unknown) {
      const msg = (err as ErrorPayload)?.error?.error || 'Failed to load thread';
      this.errorMessage.set(msg);
    } finally {
      this.isLoading.set(false);
    }
  }

  // Refresh current view (auto update or manual)
  async refreshCurrent(): Promise<void> {
    const thread = this.currentThread();
    const board = this.currentBoard();
    if (this.viewMode() === 'thread' && thread) {
      try {
        const res = await firstValueFrom(this.http.get<{ thread: Thread }>(`/api/threads/${thread.id}`));
        const prevCount = thread.replies.length;
        this.currentThread.set(res.thread);
        if (res.thread.replies.length > prevCount && this.soundAlerts() && typeof Audio !== 'undefined') {
          // Play quiet notification beep
          this.playAlertTone();
        }
      } catch {
        // silent fail on poll
      }
    } else if (board) {
      try {
        const res = await firstValueFrom(this.http.get<{ board: Board; threads: Thread[] }>(`/api/boards/${board.id}/threads`));
        this.threads.set(res.threads);
      } catch {
        // silent fail on poll
      }
    }
  }

  // Refresh global stats
  async refreshStats(): Promise<void> {
    try {
      const res = await firstValueFrom(this.http.get<{ totalPosts: number; activeUsers: number; onlineModerators: number; serverUptime: string }>('/api/stats'));
      this.stats.set(res);
    } catch {
      // ignore
    }
  }

  // Create new thread
  async createThread(data: {
    boardId: string;
    subject?: string;
    comment: string;
    file?: { name: string; size: string; dimensions: string; url: string; isSpoiler?: boolean };
    captchaToken: string;
    isModPost?: boolean;
  }): Promise<{ success: boolean; threadId?: number; error?: string }> {
    this.isSubmitting.set(true);
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(this.http.post<{ success: boolean; threadId: number; post: Post }>(
        `/api/boards/${data.boardId}/threads`,
        data
      ));
      this.successMessage.set(`Thread #${res.threadId} created successfully!`);
      // Reload board and switch to new thread
      await this.selectThread(res.threadId);
      await this.refreshStats();
      return { success: true, threadId: res.threadId };
    } catch (err: unknown) {
      const msg = (err as ErrorPayload)?.error?.error || 'Failed to create thread';
      this.errorMessage.set(msg);
      return { success: false, error: msg };
    } finally {
      this.isSubmitting.set(false);
    }
  }

  // Post reply to current thread
  async postReply(threadId: number, data: {
    comment: string;
    file?: { name: string; size: string; dimensions: string; url: string; isSpoiler?: boolean };
    captchaToken: string;
    isModPost?: boolean;
  }): Promise<{ success: boolean; post?: Post; error?: string }> {
    this.isSubmitting.set(true);
    this.errorMessage.set(null);
    try {
      const res = await firstValueFrom(this.http.post<{ success: boolean; post: Post }>(
        `/api/threads/${threadId}/replies`,
        data
      ));
      this.successMessage.set(`Reply #${res.post.id} posted!`);
      // Update local thread immediately
      const current = this.currentThread();
      if (current && current.id === threadId) {
        this.currentThread.update(t => t ? {
          ...t,
          replies: [...t.replies, res.post],
          replyCount: t.replyCount + 1,
          imageCount: data.file ? t.imageCount + 1 : t.imageCount
        } : null);
      }
      await this.refreshStats();
      return { success: true, post: res.post };
    } catch (err: unknown) {
      const msg = (err as ErrorPayload)?.error?.error || 'Failed to post reply';
      this.errorMessage.set(msg);
      return { success: false, error: msg };
    } finally {
      this.isSubmitting.set(false);
    }
  }

  // Submit post report
  async reportPost(postId: number, threadId: number, reason: string): Promise<boolean> {
    try {
      await firstValueFrom(this.http.post('/api/reports', { postId, threadId, reason }));
      this.successMessage.set(`Post #${postId} reported to moderators.`);
      return true;
    } catch {
      this.errorMessage.set('Failed to submit report.');
      return false;
    }
  }

  // Moderator Login
  async loginMod(passkey: string): Promise<boolean> {
    try {
      const res = await firstValueFrom(this.http.post<{ success: boolean; role: 'Admin' | 'Janitor'; token: string }>(
        '/api/mod/auth',
        { passkey }
      ));
      const session = { isLoggedIn: true, role: res.role, token: res.token };
      this.modSession.set(session);
      if (typeof window !== 'undefined') {
        localStorage.setItem('americhan_mod', JSON.stringify(session));
      }
      this.successMessage.set(`Authenticated as ${res.role}! Mod tools activated.`);
      await this.loadModData();
      return true;
    } catch (err: unknown) {
      const msg = (err as ErrorPayload)?.error?.error || 'Invalid mod passkey';
      this.errorMessage.set(msg);
      return false;
    }
  }

  // Moderator Logout
  logoutMod(): void {
    this.modSession.set(null);
    if (typeof window !== 'undefined') {
      localStorage.removeItem('americhan_mod');
    }
    this.successMessage.set('Logged out of moderator mode.');
  }

  // Load moderator data (reports & audit logs)
  async loadModData(): Promise<void> {
    const token = this.modSession()?.token;
    if (!token) return;
    const headers = new HttpHeaders({ Authorization: token });

    try {
      const [reps, logs] = await Promise.all([
        firstValueFrom(this.http.get<{ reports: ReportItem[] }>('/api/reports', { headers })),
        firstValueFrom(this.http.get<{ logs: ModLogEntry[] }>('/api/mod/logs', { headers }))
      ]);
      this.reports.set(reps.reports);
      this.modLogs.set(logs.logs);
    } catch (err) {
      console.error('Failed to load mod data', err);
    }
  }

  // Perform moderator action
  async performModAction(
    action: string,
    targetId: number | string,
    reason?: string,
    posterId?: string,
    postId?: number
  ): Promise<boolean> {
    const session = this.modSession();
    if (!session?.token) {
      this.errorMessage.set('Moderator privileges required');
      return false;
    }
    const headers = new HttpHeaders({ Authorization: session.token });

    try {
      const res = await firstValueFrom(this.http.post<{ success: boolean; message?: string }>(
        '/api/mod/action',
        {
          action,
          targetId,
          reason,
          posterId,
          postId,
          modName: session.role
        },
        { headers }
      ));

      this.successMessage.set(res.message || 'Action executed successfully');

      // Refresh data
      await this.loadModData();
      await this.refreshCurrent();
      if (action === 'delete_thread' || (action === 'delete_post' && targetId === this.currentThread()?.id)) {
        if (this.currentBoard()) {
          await this.selectBoard(this.currentBoard()!.id, 'board');
        }
      }
      return true;
    } catch (err: unknown) {
      const msg = (err as ErrorPayload)?.error?.error || 'Failed to execute moderation action';
      this.errorMessage.set(msg);
      return false;
    }
  }

  // Set Theme
  setTheme(themeName: 'tomorrow' | 'yotsuba' | 'photon' | 'cyber'): void {
    this.theme.set(themeName);
    if (typeof window !== 'undefined') {
      localStorage.setItem('americhan_theme', themeName);
      if (themeName === 'tomorrow' || themeName === 'cyber') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    }
  }

  // Post quote linking helper
  quotePost(postId: number): void {
    this.quickReplyQuote.set(`>>${postId}\n`);
    this.highlightPost(postId);
  }

  highlightPost(postId: number): void {
    this.highlightedPostId.set(postId);
    setTimeout(() => {
      if (this.highlightedPostId() === postId) {
        this.highlightedPostId.set(null);
      }
    }, 3000);
  }

  // Play subtle web audio notification
  private playAlertTone(): void {
    try {
      const audioCtxClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new audioCtxClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch {
      // AudioContext unavailable
    }
  }
}
