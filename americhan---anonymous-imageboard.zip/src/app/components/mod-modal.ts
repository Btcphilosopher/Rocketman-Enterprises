import {
  ChangeDetectionStrategy,
  Component,
  inject,
  output,
  signal,
  OnInit
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-mod-modal',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div class="bg-[#121929] border border-blue-500/40 rounded-lg max-w-2xl w-full shadow-2xl overflow-hidden flex flex-col max-h-[88vh]">
        <!-- Modal Header -->
        <div class="flex items-center justify-between px-5 py-3.5 bg-[#172238] border-b border-slate-700">
          <div class="flex items-center gap-2.5">
            <mat-icon class="text-rose-400">shield</mat-icon>
            <div>
              <h3 class="text-sm font-bold text-white uppercase tracking-wider">
                Americhan Board Moderation
              </h3>
              <p class="text-[11px] text-slate-400">Janitor & SysOp Control Terminal</p>
            </div>
          </div>
          <button
            type="button"
            (click)="closeModal.emit()"
            class="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <!-- Modal Body -->
        <div class="p-5 overflow-y-auto flex-1 space-y-5 text-slate-200">
          @if (!chan.isModLoggedIn()) {
            <!-- Login State -->
            <div class="max-w-md mx-auto py-6">
              <div class="text-center mb-5">
                <div class="w-12 h-12 mx-auto mb-2 rounded-full bg-blue-950/80 border border-blue-700/50 flex items-center justify-center text-blue-400">
                  <mat-icon>admin_panel_settings</mat-icon>
                </div>
                <h4 class="text-base font-semibold text-white">Enter Moderator Passkey</h4>
                <p class="text-xs text-slate-400 mt-1">Authorized personnel only. All moderation actions are logged.</p>
              </div>

              <form [formGroup]="loginForm" (ngSubmit)="onLogin()" class="space-y-3">
                <div>
                  <label for="modPasskey" class="block text-xs font-medium text-slate-300 mb-1">Passkey</label>
                  <input
                    id="modPasskey"
                    type="password"
                    formControlName="passkey"
                    placeholder="Enter mod passkey (e.g. freedom1776)"
                    class="w-full bg-[#1b263b] border border-slate-700 text-slate-100 text-sm px-3 py-2 rounded focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>

                <div class="flex items-center justify-between text-xs pt-1">
                  <button
                    type="button"
                    (click)="useDemoKey()"
                    class="text-blue-400 hover:text-blue-300 underline cursor-pointer"
                  >
                    Use Demo Key (freedom1776)
                  </button>

                  <button
                    type="submit"
                    [disabled]="!loginForm.valid"
                    class="px-5 py-2 bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs rounded transition-colors disabled:opacity-50 cursor-pointer"
                  >
                    Authenticate
                  </button>
                </div>
              </form>
            </div>
          } @else {
            <!-- Authenticated Mod Dashboard -->
            <div class="space-y-4">
              <!-- Active Status Banner -->
              <div class="flex items-center justify-between p-3 bg-emerald-950/30 border border-emerald-800/40 rounded text-xs text-emerald-300">
                <div class="flex items-center gap-2">
                  <span class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  <span class="font-semibold">Operator: {{ chan.modSession()?.role }}</span>
                  <span class="text-slate-400">·</span>
                  <span class="text-slate-400">Token Verified</span>
                </div>
                <button
                  type="button"
                  (click)="chan.logoutMod()"
                  class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded transition-colors cursor-pointer"
                >
                  Sign Out
                </button>
              </div>

              <!-- Tabs: Reports | Audit Log | Anti-Spam Rules -->
              <div class="flex border-b border-slate-700 gap-4 text-xs font-medium">
                <button
                  type="button"
                  (click)="activeTab.set('reports')"
                  class="pb-2 cursor-pointer transition-colors"
                  [class.text-blue-400]="activeTab() === 'reports'"
                  [class.border-b-2]="activeTab() === 'reports'"
                  [class.border-blue-400]="activeTab() === 'reports'"
                  [class.text-slate-400]="activeTab() !== 'reports'"
                >
                  Flagged Reports ({{ chan.reports().length }})
                </button>
                <button
                  type="button"
                  (click)="activeTab.set('logs')"
                  class="pb-2 cursor-pointer transition-colors"
                  [class.text-blue-400]="activeTab() === 'logs'"
                  [class.border-b-2]="activeTab() === 'logs'"
                  [class.border-blue-400]="activeTab() === 'logs'"
                  [class.text-slate-400]="activeTab() !== 'logs'"
                >
                  Audit Log ({{ chan.modLogs().length }})
                </button>
                <button
                  type="button"
                  (click)="activeTab.set('banned')"
                  class="pb-2 cursor-pointer transition-colors"
                  [class.text-blue-400]="activeTab() === 'banned'"
                  [class.border-b-2]="activeTab() === 'banned'"
                  [class.border-blue-400]="activeTab() === 'banned'"
                  [class.text-slate-400]="activeTab() !== 'banned'"
                >
                  Moderation Rules & Anti-Spam
                </button>
              </div>

              <!-- Tab 1: Reports Queue -->
              @if (activeTab() === 'reports') {
                <div class="space-y-2">
                  @if (chan.reports().length === 0) {
                    <div class="text-center py-8 text-slate-400 text-xs">
                      <mat-icon class="text-3xl text-slate-500 mb-1">done_all</mat-icon>
                      <p>Reports queue is clean. No pending rule violations.</p>
                    </div>
                  } @else {
                    @for (report of chan.reports(); track report.id) {
                      <div class="p-3 bg-[#172238] border border-slate-700 rounded text-xs space-y-2">
                        <div class="flex items-center justify-between text-[11px] text-slate-400">
                          <span class="font-mono text-blue-400">Post #{{ report.postId }} (Board: /{{ report.boardId }}/)</span>
                          <span>{{ report.timestamp }}</span>
                        </div>
                        <div class="p-2 bg-[#0f172a] rounded border border-slate-800 text-slate-200 font-mono text-[11px]">
                          "{{ report.commentSnippet }}"
                        </div>
                        <div class="flex items-center justify-between text-[11px]">
                          <span class="text-rose-400">Flag Reason: <strong>{{ report.reason }}</strong></span>
                          <div class="flex gap-2">
                            <button
                              type="button"
                              (click)="dismissReport(report.id)"
                              class="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded cursor-pointer"
                            >
                              Dismiss
                            </button>
                            <button
                              type="button"
                              (click)="deletePostFromReport(report.postId)"
                              class="px-2.5 py-1 bg-rose-700 hover:bg-rose-600 text-white rounded cursor-pointer"
                            >
                              Purge & Ban
                            </button>
                          </div>
                        </div>
                      </div>
                    }
                  }
                </div>
              }

              <!-- Tab 2: Audit Logs -->
              @if (activeTab() === 'logs') {
                <div class="space-y-2">
                  @for (log of chan.modLogs(); track log.id) {
                    <div class="p-2.5 bg-[#172238] border border-slate-800 rounded text-xs flex items-center justify-between">
                      <div>
                        <div class="flex items-center gap-2">
                          <span class="px-1.5 py-0.5 bg-blue-950 text-blue-300 font-mono rounded text-[10px]">
                            {{ log.action }}
                          </span>
                          <span class="text-slate-300 font-medium">{{ log.details }}</span>
                        </div>
                        <span class="text-[10px] text-slate-400 mt-0.5 block">
                          By {{ log.modName }} · Target: #{{ log.targetId }}
                        </span>
                      </div>
                      <span class="text-[10px] text-slate-500 shrink-0 font-mono">{{ log.timestamp }}</span>
                    </div>
                  }
                </div>
              }

              <!-- Tab 3: Moderation Rules -->
              @if (activeTab() === 'banned') {
                <div class="space-y-3 text-xs">
                  <div class="p-3 bg-[#172238] border border-slate-700 rounded">
                    <h5 class="font-bold text-slate-200 mb-2">Automated Spam & Protection Systems</h5>
                    <ul class="space-y-1.5 text-slate-300 list-disc list-inside">
                      <li><strong>CAPTCHA Enforcement:</strong> All thread creation and post replies require genuine human token verification.</li>
                      <li><strong>Rate Limiting:</strong> Enforces minimum 3-second delay between posts per IP subnet to thwart script bots.</li>
                      <li><strong>Keyword Blacklist:</strong> Automated regex detection drops spam tokens immediately.</li>
                      <li><strong>Poster ID Hashing:</strong> Daily rotated cryptographic salt protects poster anonymity while tracking abusers within threads.</li>
                    </ul>
                  </div>

                  <div class="p-3 bg-[#172238] border border-slate-700 rounded">
                    <h5 class="font-bold text-slate-200 mb-1">Board Janitor Guidelines</h5>
                    <p class="text-slate-400 leading-relaxed">
                      Delete off-topic spam, commercial promotions, and illegal content promptly. Use the in-line post menu (▶) on any thread to sticky, lock, or ban poster IDs.
                    </p>
                  </div>
                </div>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class ModModal implements OnInit {
  chan = inject(ChanStore);
  closeModal = output<void>();

  activeTab = signal<'reports' | 'logs' | 'banned'>('reports');

  loginForm = new FormGroup({
    passkey: new FormControl<string>('', [Validators.required])
  });

  ngOnInit(): void {
    if (this.chan.isModLoggedIn()) {
      this.chan.loadModData();
    }
  }

  useDemoKey(): void {
    this.loginForm.controls.passkey.setValue('freedom1776');
  }

  async onLogin(): Promise<void> {
    const key = this.loginForm.controls.passkey.value;
    if (!key) return;
    const success = await this.chan.loginMod(key);
    if (success) {
      this.loginForm.reset();
    }
  }

  async dismissReport(reportId: string): Promise<void> {
    await this.chan.performModAction('dismiss_report', reportId);
  }

  async deletePostFromReport(postId: number): Promise<void> {
    await this.chan.performModAction('delete_post', postId, 'Flagged by community report');
  }
}
