import {
  ChangeDetectionStrategy,
  Component,
  inject,
  output,
  signal,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-thread-view',
  imports: [MatIconModule],
  template: `
    @if (chan.currentThread(); as thread) {
      <div class="space-y-4">
        <!-- Thread Action Toolbar -->
        <div class="flex items-center justify-between pb-2 text-xs border-b border-slate-700/60 font-mono">
          <div class="flex items-center gap-3">
            <button
              type="button"
              (click)="onReturnToBoard()"
              class="text-blue-400 hover:text-blue-300 font-bold hover:underline cursor-pointer"
            >
              [Return]
            </button>
            <button
              type="button"
              (click)="chan.viewMode.set('catalog')"
              class="text-blue-400 hover:text-blue-300 hover:underline cursor-pointer"
            >
              [Catalog]
            </button>
            <button
              type="button"
              (click)="scrollToBottom()"
              class="text-blue-400 hover:text-blue-300 hover:underline cursor-pointer"
            >
              [Bottom]
            </button>
            <button
              type="button"
              (click)="chan.refreshCurrent()"
              class="text-blue-400 hover:text-blue-300 hover:underline cursor-pointer flex items-center gap-1"
            >
              [Update]
            </button>

            <label class="flex items-center gap-1.5 text-slate-300 cursor-pointer ml-2">
              <input
                type="checkbox"
                [checked]="chan.autoUpdate()"
                (change)="chan.autoUpdate.set(!chan.autoUpdate())"
                class="rounded bg-slate-800 text-blue-500"
              />
              <span>Auto</span>
            </label>
          </div>

          <div class="text-[11px] text-slate-400">
            Replies: <span class="text-white font-bold">{{ thread.replyCount }}</span> ·
            Images: <span class="text-white font-bold">{{ thread.imageCount }}</span>
          </div>
        </div>

        <!-- OP Post Container -->
        <div class="thread-op pt-1" [class.bg-blue-950/20]="chan.highlightedPostId() === thread.opPost.id">
          <!-- File info header if OP has image -->
          @if (thread.opPost.file; as file) {
            <div class="text-[11px] text-slate-400 font-mono mb-2 flex items-center gap-1">
              <span>File:</span>
              <button
                type="button"
                (click)="openLightbox(file.url, file.name, file.size, file.dimensions)"
                class="text-blue-400 hover:text-blue-300 underline font-semibold cursor-pointer"
              >
                {{ file.name }}
              </button>
              <span>({{ file.size }}, {{ file.dimensions }})</span>
            </div>
          }

          <!-- OP Body Grid (Image on left, Post details on right matching screenshot) -->
          <div class="flex flex-col md:flex-row gap-4 items-start">
            <!-- OP Image (Clickable for lightbox) -->
            @if (thread.opPost.file; as file) {
              <button
                type="button"
                (click)="openLightbox(file.url, file.name, file.size, file.dimensions)"
                aria-label="Expand OP Image"
                class="relative group rounded border border-slate-700/80 overflow-hidden bg-black shrink-0 max-w-[380px] w-full cursor-zoom-in shadow-md text-left p-0"
              >
                @if (file.isAttachmentAsset) {
                  <!-- Dedicated crop of the NYC Skyline & American flag from americhan_d037b2a0.png -->
                  <div class="w-full aspect-[16/10] overflow-hidden relative">
                    <img
                      [src]="file.url"
                      [alt]="file.name"
                      class="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                      style="object-position: 15% 70%;"
                      referrerpolicy="no-referrer"
                    />
                  </div>
                } @else {
                  <img
                    [src]="file.url"
                    [alt]="file.name"
                    class="w-full max-h-[320px] object-cover transition-transform duration-300 group-hover:scale-105"
                    referrerpolicy="no-referrer"
                  />
                }

                @if (file.isSpoiler) {
                  <div class="absolute inset-0 bg-black/90 backdrop-blur-md flex items-center justify-center text-xs font-bold text-amber-300 uppercase tracking-widest">
                    Spoiler
                  </div>
                }

                <div class="absolute bottom-1 right-1 px-1.5 py-0.5 bg-black/70 rounded text-[10px] text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity">
                  Click to Expand
                </div>
              </button>
            }

            <!-- OP Content -->
            <div class="flex-1 min-w-0">
              <!-- Post Header Row -->
              <div class="flex flex-wrap items-center gap-1.5 text-xs text-slate-300 mb-2 font-mono">
                <input type="checkbox" class="rounded bg-slate-800 text-blue-500 mr-0.5" />

                <!-- Subject if exists -->
                @if (thread.opPost.subject) {
                  <span class="font-bold text-blue-400 text-sm mr-1">
                    {{ thread.opPost.subject }}
                  </span>
                }

                <!-- Author (bold green) -->
                <span class="font-bold text-emerald-400">
                  {{ thread.opPost.author }}
                </span>

                <!-- Mod Capcode -->
                @if (thread.opPost.capcode) {
                  <span class="font-bold text-rose-400">## {{ thread.opPost.capcode }}</span>
                }

                <!-- Poster ID badge with hashed color -->
                <span
                  class="px-1.5 py-0.5 rounded text-[10px] font-semibold text-white tracking-wide"
                  [style.background-color]="getIdColor(thread.opPost.posterId)"
                >
                  (ID: {{ thread.opPost.posterId }})
                </span>

                <!-- Country Flag -->
                <span class="text-sm">🇺🇸</span>

                <!-- Timestamp -->
                <span class="text-slate-400">{{ thread.opPost.createdAt }}</span>

                <!-- Post ID & Quick Links -->
                <span class="font-bold text-slate-200">No.{{ thread.opPost.id }}</span>

                <button
                  type="button"
                  (click)="chan.quotePost(thread.opPost.id)"
                  class="text-blue-400 hover:text-blue-300 font-bold hover:underline cursor-pointer ml-1"
                >
                  [Reply]
                </button>

                <!-- Sticky & Lock Badges -->
                @if (thread.isSticky) {
                  <span class="text-amber-400 flex items-center" title="Stickied Thread">
                    <mat-icon class="text-xs">push_pin</mat-icon>
                  </span>
                }
                @if (thread.isClosed) {
                  <span class="text-rose-400 flex items-center" title="Closed/Locked Thread">
                    <mat-icon class="text-xs">lock</mat-icon>
                  </span>
                }

                <!-- Post Menu Dropdown Button ▶ -->
                <div class="relative inline-block ml-1">
                  <button
                    type="button"
                    (click)="toggleMenu(thread.opPost.id)"
                    class="text-slate-400 hover:text-slate-200 text-[10px] font-mono cursor-pointer"
                    title="Post actions"
                  >
                    ▶
                  </button>

                  @if (activeMenuPostId() === thread.opPost.id) {
                    <div class="absolute left-0 mt-1 w-44 bg-[#172238] border border-slate-700 rounded shadow-xl py-1 z-30 text-xs">
                      <button
                        type="button"
                        (click)="chan.quotePost(thread.opPost.id); activeMenuPostId.set(null)"
                        class="w-full text-left px-3 py-1.5 text-slate-200 hover:bg-slate-700 cursor-pointer"
                      >
                        Quote Post
                      </button>
                      <button
                        type="button"
                        (click)="openReportModal(thread.opPost.id, thread.id); activeMenuPostId.set(null)"
                        class="w-full text-left px-3 py-1.5 text-rose-300 hover:bg-slate-700 cursor-pointer"
                      >
                        Report Post
                      </button>

                      @if (chan.isModLoggedIn()) {
                        <div class="border-t border-slate-700 my-1"></div>
                        <div class="px-3 py-0.5 text-[9px] uppercase font-bold text-rose-400">Mod Controls</div>
                        <button
                          type="button"
                          (click)="toggleSticky(thread.id); activeMenuPostId.set(null)"
                          class="w-full text-left px-3 py-1.5 text-amber-300 hover:bg-slate-700 cursor-pointer"
                        >
                          {{ thread.isSticky ? 'Unsticky Thread' : 'Sticky Thread 📌' }}
                        </button>
                        <button
                          type="button"
                          (click)="toggleLock(thread.id); activeMenuPostId.set(null)"
                          class="w-full text-left px-3 py-1.5 text-amber-300 hover:bg-slate-700 cursor-pointer"
                        >
                          {{ thread.isClosed ? 'Unlock Thread' : 'Lock Thread 🔒' }}
                        </button>
                        <button
                          type="button"
                          (click)="banPoster(thread.opPost.posterId, thread.opPost.id); activeMenuPostId.set(null)"
                          class="w-full text-left px-3 py-1.5 text-rose-400 hover:bg-slate-700 cursor-pointer"
                        >
                          Ban Poster ({{ thread.opPost.posterId }})
                        </button>
                        <button
                          type="button"
                          (click)="deletePost(thread.opPost.id); activeMenuPostId.set(null)"
                          class="w-full text-left px-3 py-1.5 text-rose-500 font-bold hover:bg-slate-700 cursor-pointer"
                        >
                          Delete Thread 🗑️
                        </button>
                      }
                    </div>
                  }
                </div>
              </div>

              <!-- OP Post Body with Formatted Greentext -->
              <div class="text-xs text-slate-100 leading-relaxed font-sans whitespace-pre-line select-text">
                @for (line of getParsedLines(thread.opPost.comment); track $index) {
                  @if (line.isGreentext) {
                    <div class="greentext font-mono">{{ line.text }}</div>
                  } @else {
                    <div>{{ line.text }}</div>
                  }
                }
              </div>

              <!-- Banned Stamp if Post was banned -->
              @if (thread.opPost.isBanned) {
                <div class="mt-2 text-xs font-bold text-rose-500 font-mono tracking-wide">
                  (USER WAS BANNED FOR THIS POST)
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Replies List matching screenshot nested/threaded style -->
        <div class="replies-container space-y-3 pt-3">
          @for (reply of thread.replies; track reply.id) {
            <div
              [id]="'p' + reply.id"
              class="flex items-start gap-2 group transition-colors"
              [class.bg-blue-950/30]="chan.highlightedPostId() === reply.id"
            >
              <!-- >> indicator matching screenshot -->
              <span class="text-slate-500 font-mono text-xs select-none pt-2">&gt;&gt;</span>

              <!-- Reply Box Card matching dark navy styling -->
              <div
                class="bg-[#162035] border border-slate-700/70 hover:border-slate-600 rounded p-2.5 max-w-2xl w-full shadow-sm text-xs relative"
              >
                <!-- Reply Header -->
                <div class="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-300 mb-1.5 font-mono">
                  <input type="checkbox" class="rounded bg-slate-800 text-blue-500 mr-0.5" />

                  <!-- Author (bold green) -->
                  <span class="font-bold text-emerald-400">
                    {{ reply.author }}
                  </span>

                  <!-- Mod Capcode -->
                  @if (reply.capcode) {
                    <span class="font-bold text-rose-400">## {{ reply.capcode }}</span>
                  }

                  <!-- ID Badge -->
                  <span
                    class="px-1.5 py-0.5 rounded text-[10px] font-semibold text-white"
                    [style.background-color]="getIdColor(reply.posterId)"
                  >
                    (ID: {{ reply.posterId }})
                  </span>

                  <!-- Flag -->
                  <span class="text-sm">🇺🇸</span>

                  <!-- Timestamp -->
                  <span class="text-slate-400">{{ reply.createdAt }}</span>

                  <!-- Post ID -->
                  <button
                    type="button"
                    (click)="chan.quotePost(reply.id)"
                    class="font-bold text-slate-200 hover:text-blue-400 cursor-pointer hover:underline p-0 bg-transparent border-none"
                  >
                    No.{{ reply.id }}
                  </button>

                  <!-- Reply Action Menu ▶ -->
                  <div class="relative inline-block ml-1">
                    <button
                      type="button"
                      (click)="toggleMenu(reply.id)"
                      class="text-slate-400 hover:text-slate-200 text-[10px] font-mono cursor-pointer"
                    >
                      ▶
                    </button>

                    @if (activeMenuPostId() === reply.id) {
                      <div class="absolute left-0 mt-1 w-44 bg-[#172238] border border-slate-700 rounded shadow-xl py-1 z-30 text-xs">
                        <button
                          type="button"
                          (click)="chan.quotePost(reply.id); activeMenuPostId.set(null)"
                          class="w-full text-left px-3 py-1.5 text-slate-200 hover:bg-slate-700 cursor-pointer"
                        >
                          Quote Post
                        </button>
                        <button
                          type="button"
                          (click)="openReportModal(reply.id, thread.id); activeMenuPostId.set(null)"
                          class="w-full text-left px-3 py-1.5 text-rose-300 hover:bg-slate-700 cursor-pointer"
                        >
                          Report Post
                        </button>

                        @if (chan.isModLoggedIn()) {
                          <div class="border-t border-slate-700 my-1"></div>
                          <button
                            type="button"
                            (click)="banPoster(reply.posterId, reply.id); activeMenuPostId.set(null)"
                            class="w-full text-left px-3 py-1.5 text-rose-400 hover:bg-slate-700 cursor-pointer"
                          >
                            Ban Poster ({{ reply.posterId }})
                          </button>
                          <button
                            type="button"
                            (click)="deletePost(reply.id); activeMenuPostId.set(null)"
                            class="w-full text-left px-3 py-1.5 text-rose-500 font-bold hover:bg-slate-700 cursor-pointer"
                          >
                            Delete Post 🗑️
                          </button>
                        }
                      </div>
                    }
                  </div>
                </div>

                <!-- Attached File if reply has an image -->
                @if (reply.file; as file) {
                  <div class="mb-2">
                    <div class="text-[10px] text-slate-400 font-mono mb-1">
                      File:
                      <button
                        type="button"
                        (click)="openLightbox(file.url, file.name, file.size, file.dimensions)"
                        class="text-blue-400 underline font-semibold cursor-pointer"
                      >
                        {{ file.name }}
                      </button>
                      ({{ file.size }}, {{ file.dimensions }})
                    </div>
                    <button
                      type="button"
                      (click)="openLightbox(file.url, file.name, file.size, file.dimensions)"
                      aria-label="Expand reply image"
                      class="p-0 border-none bg-transparent cursor-zoom-in"
                    >
                      <img
                        [src]="file.url"
                        [alt]="file.name"
                        class="max-w-[200px] max-h-[160px] object-cover rounded border border-slate-700"
                        referrerpolicy="no-referrer"
                      />
                    </button>
                  </div>
                }

                <!-- Comment text with greentext and >>quote links -->
                <div class="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line select-text">
                  @for (line of getParsedLines(reply.comment); track $index) {
                    @if (line.isQuoteLink) {
                      <div>
                        <button
                          type="button"
                          (click)="chan.highlightPost(line.quotedId)"
                          class="text-blue-400 font-mono hover:underline cursor-pointer p-0 bg-transparent border-none inline"
                        >
                          &gt;&gt;{{ line.quotedId }}
                        </button>
                      </div>
                    } @else if (line.isGreentext) {
                      <div class="greentext font-mono">{{ line.text }}</div>
                    } @else {
                      <div>{{ line.text }}</div>
                    }
                  }
                </div>

                <!-- Banned Stamp if Post was banned -->
                @if (reply.isBanned) {
                  <div class="mt-2 text-xs font-bold text-rose-500 font-mono tracking-wide">
                    (USER WAS BANNED FOR THIS POST)
                  </div>
                }
              </div>
            </div>
          }
        </div>

        <div id="thread-bottom"></div>
      </div>
    }
  `
})
export class ThreadView {
  chan = inject(ChanStore);

  requestLightbox = output<{ url: string; name: string; size: string; dimensions: string }>();
  requestReport = output<{ postId: number; threadId: number }>();

  activeMenuPostId = signal<number | null>(null);

  toggleMenu(postId: number): void {
    this.activeMenuPostId.update(cur => cur === postId ? null : postId);
  }

  onReturnToBoard(): void {
    if (this.chan.currentBoard()) {
      this.chan.selectBoard(this.chan.currentBoard()!.id, 'board');
    }
  }

  scrollToBottom(): void {
    const el = document.getElementById('thread-bottom');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }

  openLightbox(url: string, name: string, size: string, dimensions: string): void {
    this.requestLightbox.emit({ url, name, size, dimensions });
  }

  openReportModal(postId: number, threadId: number): void {
    this.requestReport.emit({ postId, threadId });
  }

  // Mod Action Handlers
  async toggleSticky(threadId: number): Promise<void> {
    await this.chan.performModAction('sticky_thread', threadId);
  }

  async toggleLock(threadId: number): Promise<void> {
    await this.chan.performModAction('lock_thread', threadId);
  }

  async banPoster(posterId: string, postId: number): Promise<void> {
    await this.chan.performModAction('ban_poster', posterId, 'Terms violation', posterId, postId);
  }

  async deletePost(postId: number): Promise<void> {
    await this.chan.performModAction('delete_post', postId, 'Moderator deletion');
  }

  // Generate unique color for poster ID
  getIdColor(posterId: string): string {
    const colors = [
      '#0d9488', // teal (exact match to 9fkq3v2b in screenshot!)
      '#0284c7', // light blue
      '#16a34a', // green
      '#9333ea', // purple
      '#ea580c', // orange
      '#b91c1c', // red
      '#4f46e5', // indigo
      '#059669', // emerald
      '#c026d3'  // fuchsia
    ];

    let hash = 0;
    for (let i = 0; i < posterId.length; i++) {
      hash = (hash << 5) - hash + posterId.charCodeAt(i);
      hash |= 0;
    }
    const index = Math.abs(hash) % colors.length;
    return colors[index];
  }

  // Parse text into greentext and quote links
  getParsedLines(text: string): { text: string; isGreentext: boolean; isQuoteLink: boolean; quotedId: number }[] {
    return text.split('\n').map(line => {
      const quoteMatch = line.match(/^>>(\d+)/);
      if (quoteMatch) {
        return {
          text: line,
          isGreentext: false,
          isQuoteLink: true,
          quotedId: parseInt(quoteMatch[1], 10)
        };
      }
      return {
        text: line,
        isGreentext: line.startsWith('>') && !line.startsWith('>>'),
        isQuoteLink: false,
        quotedId: 0
      };
    });
  }
}
