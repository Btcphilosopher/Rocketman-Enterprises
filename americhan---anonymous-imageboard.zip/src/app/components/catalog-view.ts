import {
  ChangeDetectionStrategy,
  Component,
  inject,
  computed,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-catalog-view',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-4">
      <!-- Catalog Control Header -->
      <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-700/60 font-mono text-xs">
        <div class="flex items-center gap-3">
          <span class="font-bold text-white uppercase tracking-wider">
            /{{ chan.currentBoard()?.id }}/ - Catalog
          </span>
          <button
            type="button"
            (click)="chan.viewMode.set('board')"
            class="text-blue-400 hover:text-blue-300 hover:underline cursor-pointer"
          >
            [Thread List]
          </button>
          <button
            type="button"
            (click)="chan.refreshCurrent()"
            class="text-blue-400 hover:text-blue-300 hover:underline cursor-pointer"
          >
            [Refresh]
          </button>
        </div>

        <!-- Filter Input -->
        <div class="flex items-center gap-2">
          <mat-icon class="text-slate-400 text-sm">search</mat-icon>
          <input
            type="text"
            [formControl]="filterControl"
            placeholder="Search catalog..."
            class="bg-[#182338] border border-slate-700 text-slate-100 text-xs px-2.5 py-1 rounded focus:outline-none focus:border-blue-500 w-44"
          />
        </div>
      </div>

      <!-- Catalog Grid -->
      <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3.5">
        @for (thread of filteredThreads(); track thread.id) {
          <button
            type="button"
            (click)="chan.selectThread(thread.id)"
            class="bg-[#151f33] border border-slate-700/80 hover:border-blue-500/80 rounded p-2.5 flex flex-col justify-between cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-lg group text-left w-full"
          >
            <div class="w-full">
              <!-- Thumbnail -->
              <div class="aspect-[4/3] bg-black rounded overflow-hidden mb-2 relative border border-slate-800 flex items-center justify-center w-full">
                @if (thread.opPost.file; as file) {
                  @if (file.isAttachmentAsset) {
                    <img
                      [src]="file.url"
                      [alt]="thread.opPost.subject || 'Thread image'"
                      class="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      style="object-position: 15% 70%;"
                      referrerpolicy="no-referrer"
                    />
                  } @else {
                    <img
                      [src]="file.url"
                      [alt]="thread.opPost.subject || 'Thread image'"
                      class="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      referrerpolicy="no-referrer"
                    />
                  }
                } @else {
                  <div class="text-slate-500 flex flex-col items-center">
                    <mat-icon class="text-2xl">chat_bubble_outline</mat-icon>
                    <span class="text-[9px] font-mono">Text Thread</span>
                  </div>
                }

                @if (thread.isSticky) {
                  <div class="absolute top-1 left-1 px-1 py-0.5 bg-amber-500/90 text-black text-[9px] font-bold rounded flex items-center gap-0.5 shadow">
                    <mat-icon class="text-[10px] leading-none">push_pin</mat-icon> PIN
                  </div>
                }
                @if (thread.isClosed) {
                  <div class="absolute top-1 right-1 px-1 py-0.5 bg-rose-600/90 text-white text-[9px] font-bold rounded flex items-center gap-0.5 shadow">
                    <mat-icon class="text-[10px] leading-none">lock</mat-icon> CLOSED
                  </div>
                }
              </div>

              <!-- Stats bar -->
              <div class="text-[10px] text-slate-400 font-mono mb-1 flex items-center justify-between">
                <span>R: <strong class="text-white">{{ thread.replyCount }}</strong></span>
                <span>I: <strong class="text-white">{{ thread.imageCount }}</strong></span>
                <span class="text-[9px] text-slate-500">No.{{ thread.id }}</span>
              </div>

              <!-- Subject & Excerpt -->
              @if (thread.opPost.subject) {
                <h4 class="text-xs font-bold text-blue-400 line-clamp-1 group-hover:text-blue-300">
                  {{ thread.opPost.subject }}
                </h4>
              }
              <p class="text-[11px] text-slate-300 line-clamp-3 leading-relaxed mt-0.5">
                {{ thread.opPost.comment }}
              </p>
            </div>

            <div class="mt-2 pt-1 border-t border-slate-800 text-[10px] text-slate-500 flex items-center justify-between w-full">
              <span>{{ thread.createdAt.split('(')[0] }}</span>
              <span class="text-blue-400 group-hover:underline">View →</span>
            </div>
          </button>
        }
      </div>

      @if (filteredThreads().length === 0) {
        <div class="text-center py-12 text-slate-400 text-xs">
          <mat-icon class="text-3xl text-slate-600 mb-1">search_off</mat-icon>
          <p>No catalog threads match your filter query.</p>
        </div>
      }
    </div>
  `
})
export class CatalogView {
  chan = inject(ChanStore);

  filterControl = new FormControl<string>('');

  filteredThreads = computed(() => {
    const query = (this.filterControl.value || '').toLowerCase().trim();
    const all = this.chan.threads();
    if (!query) return all;
    return all.filter(t =>
      (t.opPost.subject && t.opPost.subject.toLowerCase().includes(query)) ||
      t.opPost.comment.toLowerCase().includes(query) ||
      t.id.toString().includes(query)
    );
  });
}
