import {
  ChangeDetectionStrategy,
  Component,
  inject,
  input,
  output,
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-report-modal',
  imports: [ReactiveFormsModule, MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div class="bg-[#121929] border border-slate-700 rounded-lg max-w-md w-full shadow-2xl p-5 text-slate-200">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-rose-400 text-sm">flag</mat-icon>
            <h4 class="text-sm font-bold text-white uppercase tracking-wider">
              Report Post #{{ postId() }}
            </h4>
          </div>
          <button
            type="button"
            (click)="closeModal.emit()"
            class="text-slate-400 hover:text-white"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <form [formGroup]="reportForm" (ngSubmit)="onSubmit()" class="py-4 space-y-3">
          <p class="text-xs text-slate-300">
            Reports are immediately transmitted to volunteer board moderators for review.
          </p>

          <div>
            <label for="reportReason" class="block text-xs font-medium text-slate-300 mb-1">Reason for Report</label>
            <select
              id="reportReason"
              formControlName="reason"
              class="w-full bg-[#1a2337] border border-slate-700 text-slate-100 text-xs px-3 py-2 rounded focus:outline-none focus:border-blue-500"
            >
              <option value="Commercial Spam / Bot Advertising">Commercial Spam / Bot Advertising</option>
              <option value="Illegal or Dangerous Content">Illegal or Dangerous Content</option>
              <option value="Severe Off-Topic / Board Disruption">Severe Off-Topic / Board Disruption</option>
              <option value="Malicious Phishing Links">Malicious Phishing Links</option>
              <option value="Other Board Rule Violation">Other Board Rule Violation</option>
            </select>
          </div>

          <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-700">
            <button
              type="button"
              (click)="closeModal.emit()"
              class="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              class="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 text-white font-medium text-xs rounded transition-colors cursor-pointer"
            >
              Submit Report
            </button>
          </div>
        </form>
      </div>
    </div>
  `
})
export class ReportModal {
  chan = inject(ChanStore);
  postId = input.required<number>();
  threadId = input.required<number>();
  closeModal = output<void>();

  reportForm = new FormGroup({
    reason: new FormControl<string>('Commercial Spam / Bot Advertising', [Validators.required])
  });

  async onSubmit(): Promise<void> {
    const reason = this.reportForm.controls.reason.value || 'Rule violation';
    await this.chan.reportPost(this.postId(), this.threadId(), reason);
    this.closeModal.emit();
  }
}
