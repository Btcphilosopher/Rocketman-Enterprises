import {
  ChangeDetectionStrategy,
  Component,
  inject,
  output,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-settings-modal',
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div class="bg-[#121929] border border-slate-700 rounded-lg max-w-lg w-full shadow-2xl p-5 text-slate-200">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-400 text-sm">settings</mat-icon>
            <h4 class="text-sm font-bold text-white uppercase tracking-wider">
              Americhan Settings
            </h4>
          </div>
          <button
            type="button"
            (click)="closeModal.emit()"
            class="text-slate-400 hover:text-white"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <div class="py-4 space-y-4 text-xs">
          <!-- Theme Selector -->
          <div>
            <h5 class="block font-semibold text-slate-200 mb-2">Visual Theme</h5>
            <div class="grid grid-cols-2 gap-2">
              <button
                type="button"
                (click)="chan.setTheme('tomorrow')"
                class="p-2.5 rounded border text-left cursor-pointer transition-colors"
                [class.border-blue-500]="chan.theme() === 'tomorrow'"
                [class.bg-[#1a253c]]="chan.theme() === 'tomorrow'"
                [class.border-slate-700]="chan.theme() !== 'tomorrow'"
                [class.bg-[#151e30]]="chan.theme() !== 'tomorrow'"
              >
                <div class="font-bold text-slate-200">Tomorrow (Dark Navy)</div>
                <div class="text-[10px] text-slate-400">Authentic high-contrast dark style</div>
              </button>

              <button
                type="button"
                (click)="chan.setTheme('cyber')"
                class="p-2.5 rounded border text-left cursor-pointer transition-colors"
                [class.border-blue-500]="chan.theme() === 'cyber'"
                [class.bg-[#1a253c]]="chan.theme() === 'cyber'"
                [class.border-slate-700]="chan.theme() !== 'cyber'"
                [class.bg-[#151e30]]="chan.theme() !== 'cyber'"
              >
                <div class="font-bold text-slate-200">Americana Red & Blue</div>
                <div class="text-[10px] text-slate-400">Patriotic contrast palette</div>
              </button>

              <button
                type="button"
                (click)="chan.setTheme('yotsuba')"
                class="p-2.5 rounded border text-left cursor-pointer transition-colors"
                [class.border-amber-600]="chan.theme() === 'yotsuba'"
                [class.bg-[#2a261c]]="chan.theme() === 'yotsuba'"
                [class.border-slate-700]="chan.theme() !== 'yotsuba'"
                [class.bg-[#151e30]]="chan.theme() !== 'yotsuba'"
              >
                <div class="font-bold text-amber-200">Yotsuba B (Classic)</div>
                <div class="text-[10px] text-slate-400">Nostalgic warm cream palette</div>
              </button>

              <button
                type="button"
                (click)="chan.setTheme('photon')"
                class="p-2.5 rounded border text-left cursor-pointer transition-colors"
                [class.border-cyan-500]="chan.theme() === 'photon'"
                [class.bg-[#162738]]="chan.theme() === 'photon'"
                [class.border-slate-700]="chan.theme() !== 'photon'"
                [class.bg-[#151e30]]="chan.theme() !== 'photon'"
              >
                <div class="font-bold text-cyan-200">Photon (Clean Slate)</div>
                <div class="text-[10px] text-slate-400">Crisp light/cool tones</div>
              </button>
            </div>
          </div>

          <!-- Auto Update -->
          <div class="flex items-center justify-between p-3 bg-[#172238] border border-slate-700/60 rounded">
            <div>
              <div class="font-semibold text-slate-200">Auto-Update Thread</div>
              <div class="text-[10px] text-slate-400">Silently polls for new replies every 10 seconds</div>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                [checked]="chan.autoUpdate()"
                (change)="chan.autoUpdate.set(!chan.autoUpdate())"
                class="sr-only peer"
              >
              <div class="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>

          <!-- Sound Alerts -->
          <div class="flex items-center justify-between p-3 bg-[#172238] border border-slate-700/60 rounded">
            <div>
              <div class="font-semibold text-slate-200">Audio Tone on Reply</div>
              <div class="text-[10px] text-slate-400">Play subtle bell notification when thread receives new reply</div>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                [checked]="chan.soundAlerts()"
                (change)="chan.soundAlerts.set(!chan.soundAlerts())"
                class="sr-only peer"
              >
              <div class="w-9 h-5 bg-slate-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
            </label>
          </div>
        </div>

        <div class="flex justify-end pt-3 border-t border-slate-700">
          <button
            type="button"
            (click)="closeModal.emit()"
            class="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs rounded transition-colors cursor-pointer"
          >
            Save & Close
          </button>
        </div>
      </div>
    </div>
  `
})
export class SettingsModal {
  chan = inject(ChanStore);
  closeModal = output<void>();
}
