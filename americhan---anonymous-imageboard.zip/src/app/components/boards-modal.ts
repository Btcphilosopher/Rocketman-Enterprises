import {
  ChangeDetectionStrategy,
  Component,
  inject,
  output,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-boards-modal',
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div class="bg-[#121929] border border-slate-700 rounded-lg max-w-2xl w-full shadow-2xl p-5 text-slate-200 max-h-[85vh] flex flex-col">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-400 text-sm">dashboard</mat-icon>
            <h4 class="text-sm font-bold text-white uppercase tracking-wider">
              Americhan Board Directory
            </h4>
          </div>
          <button
            type="button"
            (click)="closeModal.emit()"
            class="text-slate-400 hover:text-white cursor-pointer"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <div class="py-4 overflow-y-auto space-y-4 flex-1">
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            @for (board of chan.boards(); track board.id) {
              <button
                type="button"
                (click)="onSelectBoard(board.id)"
                class="p-3 bg-[#172238] border border-slate-700/80 hover:border-blue-500 rounded flex items-center gap-3 cursor-pointer transition-colors group text-left w-full"
              >
                <div class="w-10 h-10 rounded bg-[#0f172a] border border-slate-700 flex items-center justify-center text-blue-400 group-hover:text-blue-300 shrink-0">
                  <mat-icon class="text-xl">{{ board.icon }}</mat-icon>
                </div>
                <div class="overflow-hidden">
                  <div class="flex items-center gap-1.5">
                    <span class="font-bold text-blue-400 text-xs">{{ board.code }}</span>
                    <span class="font-semibold text-white text-xs">{{ board.title }}</span>
                  </div>
                  <p class="text-[10px] text-slate-400 truncate mt-0.5">{{ board.description }}</p>
                  <span class="text-[9px] text-slate-500 font-mono">{{ board.postCount.toLocaleString() }} posts</span>
                </div>
              </button>
            }
          </div>
        </div>

        <div class="flex justify-end pt-3 border-t border-slate-700">
          <button
            type="button"
            (click)="closeModal.emit()"
            class="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs rounded transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  `
})
export class BoardsModal {
  chan = inject(ChanStore);
  closeModal = output<void>();

  onSelectBoard(boardId: string): void {
    this.chan.selectBoard(boardId, 'board');
    this.closeModal.emit();
  }
}
