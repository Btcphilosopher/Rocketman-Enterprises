import {
  ChangeDetectionStrategy,
  Component,
  inject,
  signal,
  effect,
  ViewChild
} from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from '../services/chan';
import { CaptchaVerification } from './captcha';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-post-form',
  imports: [ReactiveFormsModule, MatIconModule, CaptchaVerification],
  template: `
    <div class="bg-[#101726] border border-slate-700/60 rounded-md p-4 shadow-lg text-slate-200">
      <!-- Header with Mode Selector -->
      <div class="flex items-center justify-between pb-2 mb-3 border-b border-slate-700/60">
        <h3 class="font-bold text-sm text-slate-100 flex items-center gap-1.5">
          <mat-icon class="text-blue-400 text-base">
            {{ isCreatingThread() ? 'forum' : 'reply' }}
          </mat-icon>
          {{ isCreatingThread() ? 'Start a New Thread' : 'Post a Reply' }}
        </h3>

        @if (chan.currentThread()) {
          <button
            type="button"
            (click)="toggleMode()"
            class="text-[11px] text-blue-400 hover:text-blue-300 font-medium underline cursor-pointer"
          >
            {{ isCreatingThread() ? '← Return to Reply' : '+ New Thread' }}
          </button>
        }
      </div>

      <!-- Reactive Form -->
      <form [formGroup]="postForm" (ngSubmit)="onSubmit()">
        <!-- Subject (for Thread or optional for reply) -->
        @if (isCreatingThread()) {
          <div class="mb-2">
            <input
              type="text"
              formControlName="subject"
              placeholder="Subject / Title"
              class="w-full bg-[#182338] border border-slate-700 text-slate-100 text-xs px-2.5 py-1.5 rounded focus:outline-none focus:border-blue-500 placeholder-slate-500"
            />
          </div>
        }

        <!-- Comment Box with Greentext Helper -->
        <div class="mb-2">
          <textarea
            formControlName="comment"
            rows="5"
            placeholder="Comment (supports >greentext, >>12345 quote, [spoiler]secret[/spoiler])"
            class="w-full bg-[#182338] border border-slate-700 text-slate-100 text-xs p-2.5 rounded focus:outline-none focus:border-blue-500 font-mono resize-y min-h-[90px] placeholder-slate-500"
          ></textarea>

          <!-- Quick formatting bar -->
          <div class="flex items-center gap-1.5 mt-1 text-[11px] text-slate-400">
            <span>Format:</span>
            <button
              type="button"
              (click)="insertText('>')"
              class="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 text-[10px] font-mono cursor-pointer"
              title="Greentext"
            >
              >green
            </button>
            <button
              type="button"
              (click)="insertWrap('[spoiler]', '[/spoiler]')"
              class="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono cursor-pointer"
              title="Spoiler"
            >
              [spoiler]
            </button>
            <button
              type="button"
              (click)="insertWrap('**', '**')"
              class="px-1.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] font-mono cursor-pointer"
              title="Bold"
            >
              **bold**
            </button>
          </div>
        </div>

        <!-- Integrated CAPTCHA Verification -->
        <div class="mb-3">
          <app-captcha #captchaComp (verifiedToken)="onCaptchaVerified($event)" />
          @if (!captchaToken() && formSubmitted()) {
            <p class="text-[11px] text-rose-400 mt-1 flex items-center gap-1">
              <mat-icon class="text-xs">warning</mat-icon> Please complete CAPTCHA verification before posting.
            </p>
          }
        </div>

        <!-- File Upload Section with Drag & Drop -->
        <div class="mb-3">
          <div
            (dragover)="onDragOver($event)"
            (dragleave)="onDragLeave($event)"
            (drop)="onDrop($event)"
            class="border border-dashed border-slate-700 rounded p-2.5 bg-[#141d2f] hover:border-slate-500 transition-colors"
            [class.border-blue-500]="isDragging()"
          >
            <div class="flex items-center justify-between gap-2">
              <div class="flex items-center gap-2 overflow-hidden">
                <label
                  class="cursor-pointer px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium rounded border border-slate-600 transition-colors shrink-0"
                >
                  Choose File
                  <input
                    type="file"
                    accept="image/*"
                    (change)="onFileSelected($event)"
                    class="hidden"
                  />
                </label>
                <span class="text-xs text-slate-400 truncate max-w-[150px]">
                  {{ selectedFileName() || 'No file chosen' }}
                </span>
              </div>

              @if (selectedFileData()) {
                <button
                  type="button"
                  (click)="clearFile()"
                  class="text-slate-400 hover:text-rose-400 p-0.5 rounded text-xs cursor-pointer"
                  title="Remove image"
                >
                  <mat-icon class="text-sm">close</mat-icon>
                </button>
              }
            </div>

            <!-- Image Preview thumbnail -->
            @if (selectedFileData()) {
              <div class="mt-2.5 flex items-center gap-3 p-1.5 bg-[#0f172a] rounded border border-slate-800">
                <img
                  [src]="selectedFileData()"
                  alt="Upload preview"
                  class="w-14 h-14 object-cover rounded border border-slate-700 shrink-0"
                  referrerpolicy="no-referrer"
                />
                <div class="text-[10px] text-slate-400 flex flex-col justify-center overflow-hidden">
                  <span class="font-medium text-slate-200 truncate">{{ selectedFileName() }}</span>
                  <span>{{ selectedFileSize() }} · {{ selectedFileDimensions() }}</span>
                  <label class="flex items-center gap-1 mt-1 text-slate-300 cursor-pointer">
                    <input type="checkbox" formControlName="isSpoiler" class="rounded bg-slate-800 text-blue-500" />
                    <span>Mark as Spoiler</span>
                  </label>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Mod Capcode option if Moderator is Logged In -->
        @if (chan.isModLoggedIn()) {
          <div class="mb-3 px-2 py-1.5 bg-rose-950/40 border border-rose-800/40 rounded flex items-center justify-between text-xs text-rose-300">
            <span class="flex items-center gap-1 font-semibold">
              <mat-icon class="text-xs">shield</mat-icon> Mod Privileges Active
            </span>
            <label class="flex items-center gap-1 cursor-pointer">
              <input type="checkbox" formControlName="isModPost" class="rounded bg-slate-900 text-rose-500" />
              <span>Post with Capcode (## {{ chan.modSession()?.role }})</span>
            </label>
          </div>
        }

        <!-- Submit Button Row -->
        <div class="flex items-center justify-between pt-1">
          <div class="text-[11px] text-slate-400">
            @if (chan.isSubmitting()) {
              <span class="text-blue-400 animate-pulse">Broadcasting to network...</span>
            }
          </div>

          <button
            type="submit"
            [disabled]="chan.isSubmitting() || !postForm.valid"
            class="px-5 py-1.5 bg-[#1d4ed8] hover:bg-[#2563eb] text-white font-semibold text-xs rounded transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer flex items-center gap-1"
          >
            @if (chan.isSubmitting()) {
              <div class="w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            }
            <span>Post</span>
          </button>
        </div>
      </form>
    </div>
  `
})
export class PostForm {
  chan = inject(ChanStore);

  @ViewChild('captchaComp') captchaComponent?: CaptchaVerification;

  isCreatingThread = signal<boolean>(false);
  captchaToken = signal<string | null>(null);
  formSubmitted = signal<boolean>(false);

  // File upload state
  selectedFileName = signal<string | null>(null);
  selectedFileData = signal<string | null>(null);
  selectedFileSize = signal<string>('0 KB');
  selectedFileDimensions = signal<string>('0x0');
  isDragging = signal<boolean>(false);

  postForm = new FormGroup({
    subject: new FormControl<string>(''),
    comment: new FormControl<string>('', [Validators.required, Validators.minLength(2)]),
    isSpoiler: new FormControl<boolean>(false),
    isModPost: new FormControl<boolean>(false)
  });

  constructor() {
    // If quote requested from chan store, pre-fill comment
    effect(() => {
      const quote = this.chan.quickReplyQuote();
      if (quote) {
        const cur = this.postForm.controls.comment.value || '';
        this.postForm.controls.comment.setValue(cur ? `${cur}\n${quote}` : quote);
        this.chan.quickReplyQuote.set(null);
        this.isCreatingThread.set(false);
      }
    });

    // If currently viewing a thread, default to Reply; if on board catalog with no thread, default to New Thread
    effect(() => {
      if (!this.chan.currentThread()) {
        this.isCreatingThread.set(true);
      }
    });
  }

  toggleMode(): void {
    this.isCreatingThread.update(v => !v);
  }

  onCaptchaVerified(token: string): void {
    this.captchaToken.set(token);
  }

  insertText(text: string): void {
    const cur = this.postForm.controls.comment.value || '';
    this.postForm.controls.comment.setValue(cur ? `${cur}\n${text}` : text);
  }

  insertWrap(start: string, end: string): void {
    const cur = this.postForm.controls.comment.value || '';
    this.postForm.controls.comment.setValue(`${cur} ${start}content${end} `);
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      this.processFile(input.files[0]);
    }
  }

  onDragOver(e: DragEvent): void {
    e.preventDefault();
    this.isDragging.set(true);
  }

  onDragLeave(e: DragEvent): void {
    e.preventDefault();
    this.isDragging.set(false);
  }

  onDrop(e: DragEvent): void {
    e.preventDefault();
    this.isDragging.set(false);
    if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
      this.processFile(e.dataTransfer.files[0]);
    }
  }

  private processFile(file: File): void {
    this.selectedFileName.set(file.name);
    // Format file size
    const kb = Math.round(file.size / 1024);
    const sizeStr = kb > 1024 ? `${(kb / 1024).toFixed(2)} MB` : `${kb} KB`;
    this.selectedFileSize.set(sizeStr);

    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      this.selectedFileData.set(dataUrl);

      // Compute natural image dimensions
      if (typeof Image !== 'undefined') {
        const img = new Image();
        img.onload = () => {
          this.selectedFileDimensions.set(`${img.naturalWidth}x${img.naturalHeight}`);
        };
        img.src = dataUrl;
      }
    };
    reader.readAsDataURL(file);
  }

  clearFile(): void {
    this.selectedFileName.set(null);
    this.selectedFileData.set(null);
    this.selectedFileSize.set('0 KB');
    this.selectedFileDimensions.set('0x0');
  }

  async onSubmit(): Promise<void> {
    this.formSubmitted.set(true);
    if (!this.postForm.valid) return;

    const token = this.captchaToken();
    if (!token) return;

    const values = this.postForm.value;
    const currentThread = this.chan.currentThread();
    const currentBoard = this.chan.currentBoard();

    let fileObj = undefined;
    if (this.selectedFileData()) {
      fileObj = {
        name: this.selectedFileName() || 'upload.jpg',
        size: this.selectedFileSize(),
        dimensions: this.selectedFileDimensions(),
        url: this.selectedFileData()!,
        isSpoiler: values.isSpoiler || false
      };
    }

    if (this.isCreatingThread() || !currentThread) {
      if (!currentBoard) return;
      const res = await this.chan.createThread({
        boardId: currentBoard.id,
        subject: values.subject || undefined,
        comment: values.comment || '',
        file: fileObj,
        captchaToken: token,
        isModPost: values.isModPost || false
      });
      if (res.success) {
        this.resetForm();
      }
    } else {
      const res = await this.chan.postReply(currentThread.id, {
        comment: values.comment || '',
        file: fileObj,
        captchaToken: token,
        isModPost: values.isModPost || false
      });
      if (res.success) {
        this.resetForm();
      }
    }
  }

  private resetForm(): void {
    this.postForm.reset({
      subject: '',
      comment: '',
      isSpoiler: false,
      isModPost: false
    });
    this.clearFile();
    this.captchaToken.set(null);
    this.formSubmitted.set(false);
    this.captchaComponent?.reset();
  }
}
