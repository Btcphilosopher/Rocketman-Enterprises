import {
  ChangeDetectionStrategy,
  Component,
  input,
  output,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-lightbox-modal',
  imports: [MatIconModule],
  template: `
    <div
      role="dialog"
      aria-modal="true"
      class="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm p-4"
    >
      <!-- Backdrop button to close -->
      <button
        type="button"
        (click)="closeModal.emit()"
        class="fixed inset-0 w-full h-full bg-transparent border-none cursor-zoom-out"
        aria-label="Close Lightbox"
      ></button>

      <div
        class="relative max-w-5xl max-h-[92vh] flex flex-col items-center cursor-default z-10"
      >
        <!-- Top bar with details & close -->
        <div class="w-full flex items-center justify-between pb-2 text-xs text-slate-300 font-mono">
          <div class="flex items-center gap-2">
            <span class="text-blue-400 font-bold">{{ fileName() }}</span>
            <span>({{ fileSize() }} · {{ dimensions() }})</span>
          </div>
          <button
            type="button"
            (click)="closeModal.emit()"
            class="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Close dialog"
          >
            <mat-icon class="text-base">close</mat-icon>
          </button>
        </div>

        <!-- Image Content -->
        <div class="relative overflow-hidden rounded border border-slate-700 bg-black flex items-center justify-center">
          <img
            [src]="imageUrl()"
            [alt]="fileName()"
            class="max-h-[82vh] max-w-full object-contain rounded"
            referrerpolicy="no-referrer"
          />
        </div>
      </div>
    </div>
  `
})
export class LightboxModal {
  imageUrl = input.required<string>();
  fileName = input<string>('image.jpg');
  fileSize = input<string>('');
  dimensions = input<string>('');
  closeModal = output<void>();
}
