import {
  ChangeDetectionStrategy,
  Component,
  inject,
  output,
  signal,
} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';
import { firstValueFrom } from 'rxjs';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-captcha',
  imports: [MatIconModule],
  template: `
    <div class="captcha-box select-none border border-slate-700/60 bg-[#141b2a] rounded-sm p-3 shadow-inner">
      <div class="flex items-center justify-between gap-3">
        <!-- Checkbox Area -->
        <div class="flex items-center gap-3">
          <button
            type="button"
            (click)="triggerVerification()"
            [disabled]="isVerifying() || isVerified()"
            class="relative flex items-center justify-center w-7 h-7 rounded border transition-colors cursor-pointer"
            [class.border-slate-500]="!isVerified() && !isVerifying()"
            [class.bg-[#1e293b]]="!isVerified()"
            [class.border-emerald-500]="isVerified()"
            [class.bg-emerald-950]="isVerified()"
            aria-label="I'm not a robot verification"
          >
            @if (isVerifying()) {
              <div class="w-4 h-4 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
            } @else if (isVerified()) {
              <mat-icon class="text-emerald-400 text-[18px] leading-none">check</mat-icon>
            }
          </button>

          <span class="text-sm font-medium text-slate-200">
            @if (isVerified()) {
              <span class="text-emerald-400">Human verification passed</span>
            } @else {
              <span>I'm not a robot</span>
            }
          </span>
        </div>

        <!-- reCAPTCHA Branding matching screenshot -->
        <div class="flex flex-col items-center justify-center text-right text-[9px] text-slate-400 shrink-0">
          <div class="flex items-center gap-1">
            <svg class="w-5 h-5 text-blue-400 animate-pulse-slow" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14.5v-9l6 4.5-6 4.5z"/>
              <path d="M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm-6 8c0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 8 8v3l4-4-4-4v3c-3.31 0-6-2.69-6-6z" opacity=".8"/>
            </svg>
          </div>
          <span class="font-bold tracking-tight text-[10px] text-slate-300">reCAPTCHA</span>
          <div class="flex gap-1 text-[8px] text-slate-400">
            <span>Privacy</span>
            <span>·</span>
            <span>Terms</span>
          </div>
        </div>
      </div>

      <!-- Challenge Modal popup if puzzle triggered -->
      @if (showChallengeModal()) {
        <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div class="bg-[#1a2337] border border-blue-500/40 rounded-lg p-5 max-w-sm w-full shadow-2xl">
            <div class="flex items-center justify-between pb-3 border-b border-slate-700">
              <div class="flex items-center gap-2">
                <mat-icon class="text-blue-400 text-sm">security</mat-icon>
                <h4 class="text-sm font-bold text-white uppercase tracking-wider">Security Challenge</h4>
              </div>
              <button type="button" (click)="closeChallenge()" class="text-slate-400 hover:text-white">
                <mat-icon class="text-sm">close</mat-icon>
              </button>
            </div>

            <div class="py-4">
              <p class="text-xs text-slate-300 mb-3">
                Americhan Anti-Spam: Select all symbols representing <strong class="text-white">American Freedom</strong> (Flag, Eagle, Liberty):
              </p>

              <div class="grid grid-cols-3 gap-2">
                @for (item of challengeItems; track $index) {
                  <button
                    type="button"
                    (click)="toggleChallengeItem($index)"
                    class="h-16 flex items-center justify-center text-2xl rounded border transition-all cursor-pointer"
                    [class.border-blue-500]="selectedChallengeIndices().has($index)"
                    [class.bg-blue-600/20]="selectedChallengeIndices().has($index)"
                    [class.border-slate-700]="!selectedChallengeIndices().has($index)"
                    [class.bg-[#0f172a]]="!selectedChallengeIndices().has($index)"
                  >
                    <span>{{ item.icon }}</span>
                  </button>
                }
              </div>

              @if (challengeError()) {
                <p class="text-xs text-rose-400 mt-2">{{ challengeError() }}</p>
              }
            </div>

            <div class="flex items-center justify-between pt-3 border-t border-slate-700">
              <button
                type="button"
                (click)="resetChallenge()"
                class="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1"
              >
                <mat-icon class="text-xs">refresh</mat-icon> Reload
              </button>
              <button
                type="button"
                (click)="verifyChallenge()"
                class="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs rounded transition-colors"
              >
                Verify
              </button>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class CaptchaVerification {
  private http = inject(HttpClient);

  verifiedToken = output<string>();

  isVerifying = signal<boolean>(false);
  isVerified = signal<boolean>(false);
  showChallengeModal = signal<boolean>(false);
  challengeError = signal<string | null>(null);

  challengeItems = [
    { icon: '🇺🇸', isTarget: true },
    { icon: '🗼', isTarget: false },
    { icon: '🗽', isTarget: true },
    { icon: '🦅', isTarget: true },
    { icon: '🏰', isTarget: false },
    { icon: '⛩️', isTarget: false }
  ];

  selectedChallengeIndices = signal<Set<number>>(new Set());

  // Click on "I'm not a robot"
  async triggerVerification(): Promise<void> {
    if (this.isVerified() || this.isVerifying()) return;

    this.isVerifying.set(true);

    // Simulate realistic human verification check
    setTimeout(async () => {
      // 70% automatic verification pass (standard modern reCAPTCHA v2 human score behavior),
      // or open puzzle for visual confirmation
      const autoPass = Math.random() > 0.35;
      if (autoPass) {
        await this.completeVerification(true);
      } else {
        this.isVerifying.set(false);
        this.showChallengeModal.set(true);
      }
    }, 850);
  }

  toggleChallengeItem(index: number): void {
    const updated = new Set(this.selectedChallengeIndices());
    if (updated.has(index)) {
      updated.delete(index);
    } else {
      updated.add(index);
    }
    this.selectedChallengeIndices.set(updated);
  }

  async verifyChallenge(): Promise<void> {
    const selected = Array.from(this.selectedChallengeIndices());
    // Check if user selected all targets (🇺🇸, 🗽, 🦅 -> indices 0, 2, 3) and no non-targets
    const targetIndices = [0, 2, 3];
    const isCorrect =
      targetIndices.every(idx => selected.includes(idx)) &&
      selected.every(idx => targetIndices.includes(idx));

    if (isCorrect) {
      this.showChallengeModal.set(false);
      this.isVerifying.set(true);
      await this.completeVerification(true);
    } else {
      this.challengeError.set('Incorrect selection. Please try again.');
    }
  }

  resetChallenge(): void {
    this.selectedChallengeIndices.set(new Set());
    this.challengeError.set(null);
  }

  closeChallenge(): void {
    this.showChallengeModal.set(false);
    this.isVerifying.set(false);
  }

  private async completeVerification(passed: boolean): Promise<void> {
    try {
      const res = await firstValueFrom(
        this.http.post<{ success: boolean; token: string }>('/api/captcha/verify', {
          isRobotCheckPassed: passed
        })
      );
      if (res.success && res.token) {
        this.isVerified.set(true);
        this.verifiedToken.emit(res.token);
      }
    } catch {
      this.isVerified.set(false);
    } finally {
      this.isVerifying.set(false);
    }
  }

  reset(): void {
    this.isVerified.set(false);
    this.isVerifying.set(false);
    this.showChallengeModal.set(false);
    this.selectedChallengeIndices.set(new Set());
  }
}
