import {
  ChangeDetectionStrategy,
  Component,
  output,
} from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-rules-modal',
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xs p-4">
      <div class="bg-[#121929] border border-slate-700 rounded-lg max-w-xl w-full shadow-2xl p-5 text-slate-200">
        <div class="flex items-center justify-between pb-3 border-b border-slate-700">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400 text-sm">gavel</mat-icon>
            <h4 class="text-sm font-bold text-white uppercase tracking-wider">
              Americhan Global Rules & Guidelines
            </h4>
          </div>
          <button
            type="button"
            (click)="closeModal.emit()"
            class="text-slate-400 hover:text-white"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <div class="py-4 space-y-3.5 text-xs text-slate-300 overflow-y-auto max-h-[60vh]">
          <div class="p-2.5 bg-[#172238] rounded border border-slate-800">
            <div class="font-bold text-white mb-1">1. Respect United States Law</div>
            <p>Do not post, request, or link to any illegal content under United States federal or local law. Any such posts are purged immediately and reported.</p>
          </div>

          <div class="p-2.5 bg-[#172238] rounded border border-slate-800">
            <div class="font-bold text-white mb-1">2. Board Topicality & Quality</div>
            <p>Keep discussions relevant to the board they are posted in. Politics and US affairs belong in /pol/, technology in /g/, sports in /sp/, etc.</p>
          </div>

          <div class="p-2.5 bg-[#172238] rounded border border-slate-800">
            <div class="font-bold text-white mb-1">3. Automated Commercial Spam & Flooding</div>
            <p>Automated bots, phishing campaigns, affiliate schemes, and mass flooding are strictly forbidden. The automated CAPTCHA system tracks and rate limits suspicious traffic.</p>
          </div>

          <div class="p-2.5 bg-[#172238] rounded border border-slate-800">
            <div class="font-bold text-white mb-1">4. Anonymous Free Speech & Civil Discourse</div>
            <p>All posts are anonymous by design. Personal doxxing, harassment campaigns, or posting private information of individuals is strictly prohibited.</p>
          </div>
        </div>

        <div class="flex justify-end pt-3 border-t border-slate-700">
          <button
            type="button"
            (click)="closeModal.emit()"
            class="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-medium text-xs rounded transition-colors cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  `
})
export class RulesModal {
  closeModal = output<void>();
}
