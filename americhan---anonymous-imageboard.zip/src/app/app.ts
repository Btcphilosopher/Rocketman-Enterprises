import {
  ChangeDetectionStrategy,
  Component,
  inject,
  OnInit,
  OnDestroy,
  signal,
} from '@angular/core';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { ChanStore } from './services/chan';
import { ThreadView } from './components/thread-view';
import { CatalogView } from './components/catalog-view';
import { PostForm } from './components/post-form';
import { ModModal } from './components/mod-modal';
import { SettingsModal } from './components/settings-modal';
import { RulesModal } from './components/rules-modal';
import { ReportModal } from './components/report-modal';
import { BoardsModal } from './components/boards-modal';
import { LightboxModal } from './components/lightbox-modal';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    ReactiveFormsModule,
    MatIconModule,
    ThreadView,
    CatalogView,
    PostForm,
    ModModal,
    SettingsModal,
    RulesModal,
    ReportModal,
    BoardsModal,
    LightboxModal
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit, OnDestroy {
  chan = inject(ChanStore);

  // Top bar board list matching screenshot
  topBarBoards = [
    'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'm', 'o', 'p', 'r', 's', 't', 'u', 'v', 'vg', 'vr', 'w', 'wg', 'wsg'
  ];

  // Featured 9 boards matching the screenshot row
  featuredBoardCards = [
    { id: 'a', code: '/a/', title: 'Anime & Manga', imgCrop: 'center 30%', fallbackImg: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=300&q=80' },
    { id: 'b', code: '/b/', title: 'Random', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=300&q=80' },
    { id: 'g', code: '/g/', title: 'Technology', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=300&q=80' },
    { id: 'pol', code: '/pol/', title: 'Politics', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=300&q=80' },
    { id: 'sp', code: '/sp/', title: 'Sports', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=300&q=80' },
    { id: 'o', code: '/o/', title: 'Automotive', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=300&q=80' },
    { id: 'm', code: '/m/', title: 'Music', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=300&q=80' },
    { id: 'v', code: '/v/', title: 'Video Games', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=300&q=80' },
    { id: 'tv', code: '/tv/', title: 'Television & Film', imgCrop: 'center center', fallbackImg: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&q=80' }
  ];

  // Active Modals
  showModModal = signal<boolean>(false);
  showSettingsModal = signal<boolean>(false);
  showRulesModal = signal<boolean>(false);
  showBoardsModal = signal<boolean>(false);
  showSearchModal = signal<boolean>(false);

  // Lightbox Modal state
  activeLightbox = signal<{ url: string; name: string; size: string; dimensions: string } | null>(null);

  // Report Modal state
  activeReport = signal<{ postId: number; threadId: number } | null>(null);

  // Search input
  searchControl = new FormControl<string>('');

  // Polling timer
  private pollTimer: ReturnType<typeof setInterval> | null = null;

  async ngOnInit(): Promise<void> {
    await this.chan.loadBoards();
    // Default load /pol/ board and thread 38472091
    await this.chan.selectBoard('pol', 'thread');

    // Auto update interval if enabled
    if (typeof window !== 'undefined') {
      this.pollTimer = setInterval(() => {
        if (this.chan.autoUpdate()) {
          this.chan.refreshCurrent();
        }
      }, 10000);
    }
  }

  ngOnDestroy(): void {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
    }
  }

  // Board Navigation
  selectBoard(boardId: string): void {
    this.chan.selectBoard(boardId, 'board');
  }

  // Open Lightbox
  onOpenLightbox(event: { url: string; name: string; size: string; dimensions: string }): void {
    this.activeLightbox.set(event);
  }

  // Open Report
  onOpenReport(event: { postId: number; threadId: number }): void {
    this.activeReport.set(event);
  }

  // Search execute
  onSearchSubmit(): void {
    const query = this.searchControl.value?.trim();
    if (query) {
      this.chan.viewMode.set('catalog');
      this.showSearchModal.set(false);
    }
  }
}
