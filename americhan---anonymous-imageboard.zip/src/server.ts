import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express, { Request, Response } from 'express';
import { join } from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

// Body parser for JSON and URL-encoded bodies with large payload support for image uploads
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// -------------------------------------------------------------
// Data Types
// -------------------------------------------------------------
export interface Post {
  id: number;
  threadId: number;
  boardId: string;
  isOp: boolean;
  author: string;
  posterId: string;
  country: string;
  createdAt: string;
  timestamp: number;
  subject?: string;
  comment: string;
  file?: {
    name: string;
    size: string;
    dimensions: string;
    url: string;
    isSpoiler?: boolean;
    isAttachmentAsset?: boolean;
  };
  capcode?: 'Mod' | 'Admin';
  isBanned?: boolean;
  banReason?: string;
  reportCount?: number;
}

export interface Thread {
  id: number;
  boardId: string;
  opPost: Post;
  replies: Post[];
  replyCount: number;
  imageCount: number;
  isSticky: boolean;
  isClosed: boolean;
  createdAt: string;
  lastBumpTime: number;
}

export interface Board {
  id: string;
  code: string;
  title: string;
  description: string;
  category: 'Interests' | 'Creative' | 'Other' | 'General';
  icon: string;
  thumbnail: string;
  postCount: number;
  rules?: string[];
}

export interface ModLogEntry {
  id: string;
  timestamp: string;
  action: string;
  targetId: number | string;
  details: string;
  modName: string;
}

export interface ReportItem {
  id: string;
  postId: number;
  threadId: number;
  boardId: string;
  reason: string;
  timestamp: string;
  commentSnippet: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

// -------------------------------------------------------------
// Initial In-Memory Database & Seed Data
// -------------------------------------------------------------
const BOARDS: Board[] = [
  { id: 'pol', code: '/pol/', title: 'Politics', description: 'Politically Incorrect & US Current Affairs', category: 'General', icon: 'account_balance', thumbnail: 'https://images.unsplash.com/photo-1541872703-74c5e44368f9?w=400&q=80', postCount: 1482091 },
  { id: 'b', code: '/b/', title: 'Random', description: 'The stories and information posted here are artistic works of fiction', category: 'General', icon: 'shuffle', thumbnail: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=400&q=80', postCount: 9248102 },
  { id: 'g', code: '/g/', title: 'Technology', description: 'Hardware, software, open-source, and tech industry discussion', category: 'Interests', icon: 'memory', thumbnail: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&q=80', postCount: 847291 },
  { id: 'sp', code: '/sp/', title: 'Sports', description: 'American football, basketball, baseball, and athletic competition', category: 'Interests', icon: 'sports_football', thumbnail: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=400&q=80', postCount: 421092 },
  { id: 'a', code: '/a/', title: 'Anime & Manga', description: 'Anime, manga, and animation appreciation', category: 'Creative', icon: 'palette', thumbnail: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?w=400&q=80', postCount: 618402 },
  { id: 'o', code: '/o/', title: 'Automotive', description: 'Cars, trucks, engines, muscle, and EV engineering', category: 'Interests', icon: 'directions_car', thumbnail: 'https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=400&q=80', postCount: 382901 },
  { id: 'm', code: '/m/', title: 'Music', description: 'Americana, rock, folk, jazz, synth, and music production', category: 'Creative', icon: 'graphic_eq', thumbnail: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=400&q=80', postCount: 294819 },
  { id: 'v', code: '/v/', title: 'Video Games', description: 'Game discussions, gaming culture, and indie development', category: 'Interests', icon: 'videogame_asset', thumbnail: 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=400&q=80', postCount: 958210 },
  { id: 'tv', code: '/tv/', title: 'Television & Film', description: 'Cinema, streaming, television series, and scriptwriting', category: 'Creative', icon: 'live_tv', thumbnail: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&q=80', postCount: 512039 },
  { id: 'news', code: '/news/', title: 'Current News', description: 'Headlines, breaking stories, and national events', category: 'General', icon: 'newspaper', thumbnail: 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=400&q=80', postCount: 219400 },
  { id: 'biz', code: '/biz/', title: 'Business & Finance', description: 'Markets, stocks, entrepreneurship, and economics', category: 'Interests', icon: 'trending_up', thumbnail: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=400&q=80', postCount: 784102 },
  { id: 'his', code: '/his/', title: 'History & Humanities', description: 'American history, founding fathers, civilization, and philosophy', category: 'Interests', icon: 'menu_book', thumbnail: 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=400&q=80', postCount: 194820 },
  { id: 'k', code: '/k/', title: 'Weapons', description: 'Firearms, defense, outdoor gear, and tactical engineering', category: 'Interests', icon: 'shield', thumbnail: 'https://images.unsplash.com/photo-1595590424283-b8f17842773f?w=400&q=80', postCount: 432109 },
  { id: 'fit', code: '/fit/', title: 'Fitness', description: 'Strength training, nutrition, health, and athletics', category: 'Interests', icon: 'fitness_center', thumbnail: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=400&q=80', postCount: 310920 }
];

// Helper to format date string like "10/30/26(Fri)07:12:34"
function formatChanDate(date: Date = new Date()): string {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const pad = (n: number) => n.toString().padStart(2, '0');
  const month = pad(date.getMonth() + 1);
  const day = pad(date.getDate());
  const year = date.getFullYear().toString().slice(-2);
  const dayName = days[date.getDay()];
  const hours = pad(date.getHours());
  const minutes = pad(date.getMinutes());
  const seconds = pad(date.getSeconds());
  return `${month}/${day}/${year}(${dayName})${hours}:${minutes}:${seconds}`;
}

// Store state
let postCounter = 38472200;
const threads: Thread[] = [];
const bannedPosterIds = new Set<string>();
const modLogs: ModLogEntry[] = [];
const reports: ReportItem[] = [];
const verifiedCaptchaTokens = new Map<string, number>(); // token -> expiry

// Seed the exact thread from the screenshot!
const initialOpPost: Post = {
  id: 38472091,
  threadId: 38472091,
  boardId: 'pol',
  isOp: true,
  author: 'Anonymous',
  posterId: '9fkq3v2b',
  country: 'US',
  createdAt: '10/30/26(Fri)07:12:34',
  timestamp: 1793365954000,
  subject: 'America twenty years from now...',
  comment: 'America twenty years from now...\n\nWhat do you think? Better, worse, or the same?\nDiscuss.',
  file: {
    name: 'AMERICA.jpg',
    size: '1.24 MB',
    dimensions: '3840x2160',
    url: '/assets/aistudio/americhan_d037b2a0.png',
    isAttachmentAsset: true
  }
};

const initialReplies: Post[] = [
  {
    id: 38472102,
    threadId: 38472091,
    boardId: 'pol',
    isOp: false,
    author: 'Anonymous',
    posterId: 'Rm7qVf1k',
    country: 'US',
    createdAt: '10/30/26(Fri)07:13:49',
    timestamp: 1793366029000,
    comment: 'Long live the USA. 🇺🇸'
  },
  {
    id: 38472123,
    threadId: 38472091,
    boardId: 'pol',
    isOp: false,
    author: 'Anonymous',
    posterId: 'Kd4mQz7p',
    country: 'US',
    createdAt: '10/30/26(Fri)07:14:10',
    timestamp: 1793366050000,
    comment: '>>38472091\nBetter. Energy, AI, and a stronger economy.'
  },
  {
    id: 38472147,
    threadId: 38472091,
    boardId: 'pol',
    isOp: false,
    author: 'Anonymous',
    posterId: 'Lm8vXn3f',
    country: 'US',
    createdAt: '10/30/26(Fri)07:15:27',
    timestamp: 1793366127000,
    comment: '>>38472091\nWorse. The elites will never give up power.'
  },
  {
    id: 38472189,
    threadId: 38472091,
    boardId: 'pol',
    isOp: false,
    author: 'Anonymous',
    posterId: 'Vp2jQk9h',
    country: 'US',
    createdAt: '10/30/26(Fri)07:17:03',
    timestamp: 1793366223000,
    comment: '>>38472091\nSame. Just more technology and more division.'
  }
];

threads.push({
  id: 38472091,
  boardId: 'pol',
  opPost: initialOpPost,
  replies: initialReplies,
  replyCount: 4,
  imageCount: 1,
  isSticky: true,
  isClosed: false,
  createdAt: initialOpPost.createdAt,
  lastBumpTime: 1793366223000
});

// Seed additional realistic threads for other boards
function seedExtraThreads() {
  // /b/ Thread
  const bOp: Post = {
    id: 38471900,
    threadId: 38471900,
    boardId: 'b',
    isOp: true,
    author: 'Anonymous',
    posterId: 'k92Bx1zA',
    country: 'US',
    createdAt: formatChanDate(new Date(Date.now() - 3600000 * 2)),
    timestamp: Date.now() - 3600000 * 2,
    subject: 'Post your patriotic pepe and rare americana',
    comment: '> Be me\n> Look outside\n> Red, white, and blue in the morning mist\nDrop your highest quality patriotic pepes right now.',
    file: {
      name: 'PEPE_USA_HD.png',
      size: '840 KB',
      dimensions: '1920x1080',
      url: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&q=80'
    }
  };
  threads.push({
    id: 38471900,
    boardId: 'b',
    opPost: bOp,
    replies: [
      {
        id: 38471905,
        threadId: 38471900,
        boardId: 'b',
        isOp: false,
        author: 'Anonymous',
        posterId: 'W87xLp19',
        country: 'US',
        createdAt: formatChanDate(new Date(Date.now() - 3600000)),
        timestamp: Date.now() - 3600000,
        comment: '>>38471900\nBased and freedom-pilled anon.'
      }
    ],
    replyCount: 1,
    imageCount: 1,
    isSticky: false,
    isClosed: false,
    createdAt: bOp.createdAt,
    lastBumpTime: Date.now() - 3600000
  });

  // /g/ Thread
  const gOp: Post = {
    id: 38471820,
    threadId: 38471820,
    boardId: 'g',
    isOp: true,
    author: 'Anonymous',
    posterId: 'Tx89Mn4k',
    country: 'US',
    createdAt: formatChanDate(new Date(Date.now() - 3600000 * 5)),
    timestamp: Date.now() - 3600000 * 5,
    subject: 'American domestic semiconductor fabrication thread',
    comment: 'With the CHIPS act fabs coming online across Ohio, Texas, and Arizona, what architecture will lead the next decade?\n\nRISC-V vs customized silicon accelerators?',
    file: {
      name: 'SILICON_DIE_4NM.jpg',
      size: '1.82 MB',
      dimensions: '2560x1440',
      url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&q=80'
    }
  };
  threads.push({
    id: 38471820,
    boardId: 'g',
    opPost: gOp,
    replies: [
      {
        id: 38471825,
        threadId: 38471820,
        boardId: 'g',
        isOp: false,
        author: 'Anonymous',
        posterId: 'Hq55Rz11',
        country: 'US',
        createdAt: formatChanDate(new Date(Date.now() - 3600000 * 3)),
        timestamp: Date.now() - 3600000 * 3,
        comment: '>>38471820\nCustom optical interconnects will dominate data centers.'
      }
    ],
    replyCount: 1,
    imageCount: 1,
    isSticky: false,
    isClosed: false,
    createdAt: gOp.createdAt,
    lastBumpTime: Date.now() - 3600000 * 3
  });
}
seedExtraThreads();

// Initial Mod Log
modLogs.push({
  id: 'log-1',
  timestamp: formatChanDate(new Date(Date.now() - 7200000)),
  action: 'STICKY_THREAD',
  targetId: 38472091,
  details: 'Thread stickied by Board Administrator for national discussion',
  modName: 'Admin'
});

// Helper to generate 8-char poster ID like 9fkq3v2b
function generatePosterId(ip = '127.0.0.1', threadId: number): string {
  let hash = 0;
  const str = `${ip}:${threadId}:americhan_secret_salt_2026`;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(8, '0');
  return hex.slice(0, 8);
}

// -------------------------------------------------------------
// REST API Endpoints
// -------------------------------------------------------------

// GET /api/boards - List all boards
app.get('/api/boards', (req: Request, res: Response) => {
  // Update board counts dynamically
  const updatedBoards = BOARDS.map((b) => {
    const boardThreads = threads.filter((t) => t.boardId === b.id);
    const count = boardThreads.reduce((acc, t) => acc + 1 + t.replies.length, 0);
    return {
      ...b,
      postCount: b.postCount + count
    };
  });
  res.json({ boards: updatedBoards });
});

// GET /api/boards/:boardId/threads - List threads for board
app.get('/api/boards/:boardId/threads', (req: Request, res: Response): void => {
  const boardId = String(req.params['boardId'] || '');
  const board = BOARDS.find((b) => b.id === boardId);
  if (!board) {
    res.status(404).json({ error: 'Board not found' });
    return;
  }

  // Sort by sticky first, then lastBumpTime descending
  const boardThreads = threads
    .filter((t) => t.boardId === boardId)
    .sort((a, b) => {
      if (a.isSticky && !b.isSticky) return -1;
      if (!a.isSticky && b.isSticky) return 1;
      return b.lastBumpTime - a.lastBumpTime;
    });

  res.json({
    board,
    threads: boardThreads,
    total: boardThreads.length
  });
  return;
});

// GET /api/threads/:threadId - Get thread details
app.get('/api/threads/:threadId', (req: Request, res: Response): void => {
  const threadId = parseInt(String(req.params['threadId'] || ''), 10);
  const thread = threads.find((t) => t.id === threadId);
  if (!thread) {
    res.status(404).json({ error: 'Thread not found or was pruned' });
    return;
  }
  res.json({ thread });
  return;
});

// POST /api/captcha/generate - Generate challenge verification token
app.post('/api/captcha/generate', (req: Request, res: Response): void => {
  const challengeId = 'cap_' + Math.random().toString(36).substring(2, 10);
  // Support both robot check & interactive puzzle
  const challengeTypes = [
    {
      id: 'statue',
      prompt: 'Select the American flag or Statue of Liberty',
      options: ['🇺🇸', '🗼', '🗽', '🏰', '🦅', '⛩️'],
      correct: ['🇺🇸', '🗽', '🦅']
    },
    {
      id: 'math',
      prompt: 'Security verification: What is 17 + 76?',
      answer: '93'
    }
  ];

  const challenge = challengeTypes[Math.floor(Math.random() * challengeTypes.length)];
  res.json({
    challengeId,
    challenge
  });
  return;
});

// POST /api/captcha/verify - Verify human CAPTCHA
app.post('/api/captcha/verify', (req: Request, res: Response): void => {
  const { isRobotCheckPassed, puzzleSolution } = req.body;
  if (!isRobotCheckPassed && !puzzleSolution) {
    res.status(400).json({ success: false, error: 'CAPTCHA verification incomplete' });
    return;
  }

  const verificationToken = 'verified_' + Math.random().toString(36).substring(2, 12);
  verifiedCaptchaTokens.set(verificationToken, Date.now() + 15 * 60 * 1000); // 15 min validity

  res.json({
    success: true,
    token: verificationToken,
    message: 'Human verified successfully'
  });
  return;
});

// Anti-spam word filter check
const SPAM_KEYWORDS = ['buy cheap crypto fast', 'viagra discount now', 'telegram pump group'];
function containsSpam(text: string): boolean {
  const lower = text.toLowerCase();
  return SPAM_KEYWORDS.some((kw) => lower.includes(kw));
}

// POST /api/boards/:boardId/threads - Create New Thread
app.post('/api/boards/:boardId/threads', (req: Request, res: Response): void => {
  const boardId = String(req.params['boardId'] || '');
  const { subject, comment, file, captchaToken, isModPost } = req.body;

  const board = BOARDS.find((b) => b.id === boardId);
  if (!board) {
    res.status(404).json({ error: 'Invalid board' });
    return;
  }

  if (!comment || comment.trim().length === 0) {
    res.status(400).json({ error: 'Comment is required to start a thread' });
    return;
  }

  // Validate CAPTCHA token
  if (!captchaToken || !verifiedCaptchaTokens.has(captchaToken)) {
    res.status(403).json({ error: 'CAPTCHA verification required to post. Please verify you are human.' });
    return;
  }

  if (containsSpam(comment) || (subject && containsSpam(subject))) {
    res.status(400).json({ error: 'Post rejected by anti-spam security filter' });
    return;
  }

  const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
  postCounter++;
  const threadId = postCounter;
  const posterId = generatePosterId(clientIp, threadId);

  if (bannedPosterIds.has(posterId)) {
    res.status(403).json({ error: 'You are banned from posting on this board.' });
    return;
  }

  let postFile = undefined;
  if (file && file.url) {
    postFile = {
      name: file.name || 'UPLOAD_' + Date.now() + '.jpg',
      size: file.size || '1.1 MB',
      dimensions: file.dimensions || '1920x1080',
      url: file.url,
      isSpoiler: !!file.isSpoiler
    };
  }

  const newOp: Post = {
    id: threadId,
    threadId,
    boardId,
    isOp: true,
    author: 'Anonymous',
    posterId,
    country: 'US',
    createdAt: formatChanDate(new Date()),
    timestamp: Date.now(),
    subject: subject?.trim() || undefined,
    comment: comment.trim(),
    file: postFile,
    capcode: isModPost ? 'Mod' : undefined
  };

  const newThread: Thread = {
    id: threadId,
    boardId,
    opPost: newOp,
    replies: [],
    replyCount: 0,
    imageCount: postFile ? 1 : 0,
    isSticky: false,
    isClosed: false,
    createdAt: newOp.createdAt,
    lastBumpTime: Date.now()
  };

  // Add thread to start
  threads.unshift(newThread);

  res.status(201).json({
    success: true,
    threadId,
    post: newOp
  });
  return;
});

// POST /api/threads/:threadId/replies - Post a reply to thread
app.post('/api/threads/:threadId/replies', (req: Request, res: Response): void => {
  const threadId = parseInt(String(req.params['threadId'] || ''), 10);
  const { comment, file, captchaToken, isModPost } = req.body;

  const thread = threads.find((t) => t.id === threadId);
  if (!thread) {
    res.status(404).json({ error: 'Thread not found' });
    return;
  }

  if (thread.isClosed) {
    res.status(403).json({ error: 'This thread is closed/locked by moderators' });
    return;
  }

  if (!comment || comment.trim().length === 0) {
    res.status(400).json({ error: 'Comment is required' });
    return;
  }

  // Validate CAPTCHA token
  if (!captchaToken || !verifiedCaptchaTokens.has(captchaToken)) {
    res.status(403).json({ error: 'CAPTCHA verification required to post. Please verify you are human.' });
    return;
  }

  if (containsSpam(comment)) {
    res.status(400).json({ error: 'Post rejected by anti-spam security filter' });
    return;
  }

  const clientIp = (req.headers['x-forwarded-for'] as string) || req.socket.remoteAddress || '127.0.0.1';
  const posterId = generatePosterId(clientIp, threadId);

  if (bannedPosterIds.has(posterId)) {
    res.status(403).json({ error: 'You are banned from posting on this board.' });
    return;
  }

  postCounter++;
  const replyId = postCounter;

  let postFile = undefined;
  if (file && file.url) {
    postFile = {
      name: file.name || 'UPLOAD_' + Date.now() + '.jpg',
      size: file.size || '980 KB',
      dimensions: file.dimensions || '1280x720',
      url: file.url,
      isSpoiler: !!file.isSpoiler
    };
  }

  const replyPost: Post = {
    id: replyId,
    threadId,
    boardId: thread.boardId,
    isOp: false,
    author: 'Anonymous',
    posterId,
    country: 'US',
    createdAt: formatChanDate(new Date()),
    timestamp: Date.now(),
    comment: comment.trim(),
    file: postFile,
    capcode: isModPost ? 'Mod' : undefined
  };

  thread.replies.push(replyPost);
  thread.replyCount++;
  if (postFile) {
    thread.imageCount++;
  }
  // Sage check: if comment starts with sage or contains sage, don't bump
  if (!comment.toLowerCase().startsWith('sage')) {
    thread.lastBumpTime = Date.now();
  }

  res.status(201).json({
    success: true,
    post: replyPost
  });
  return;
});

// POST /api/reports - Report a post
app.post('/api/reports', (req: Request, res: Response): void => {
  const { postId, threadId, reason } = req.body;
  if (!postId || !reason) {
    res.status(400).json({ error: 'Post ID and reason required' });
    return;
  }

  // Find post snippet
  let commentSnippet = 'Post #' + postId;
  let boardId = 'pol';
  for (const t of threads) {
    if (t.opPost.id === postId) {
      commentSnippet = t.opPost.comment.slice(0, 100);
      boardId = t.boardId;
      t.opPost.reportCount = (t.opPost.reportCount || 0) + 1;
      break;
    }
    const r = t.replies.find((p) => p.id === postId);
    if (r) {
      commentSnippet = r.comment.slice(0, 100);
      boardId = t.boardId;
      r.reportCount = (r.reportCount || 0) + 1;
      break;
    }
  }

  const report: ReportItem = {
    id: 'rep_' + Date.now(),
    postId,
    threadId: threadId || postId,
    boardId,
    reason,
    timestamp: formatChanDate(new Date()),
    commentSnippet,
    status: 'pending'
  };

  reports.unshift(report);
  res.json({ success: true, message: 'Report submitted for moderator review' });
  return;
});

// GET /api/reports - Mod only
app.get('/api/reports', (req: Request, res: Response): void => {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.includes('Americhan-Mod')) {
    res.status(401).json({ error: 'Moderator authentication required' });
    return;
  }
  res.json({ reports });
  return;
});

// POST /api/mod/auth - Mod Login
app.post('/api/mod/auth', (req: Request, res: Response): void => {
  const { passkey } = req.body;
  // Default passkey is "freedom1776" or "admin"
  if (passkey === 'freedom1776' || passkey === 'admin' || passkey === 'janitor') {
    const role = passkey === 'freedom1776' || passkey === 'admin' ? 'Admin' : 'Janitor';
    res.json({
      success: true,
      role,
      token: 'Americhan-Mod-' + Math.random().toString(36).substring(2, 10),
      message: `Logged in as Board ${role}`
    });
    return;
  } else {
    res.status(401).json({ success: false, error: 'Invalid moderator passkey' });
    return;
  }
});

// POST /api/mod/action - Mod Actions
app.post('/api/mod/action', (req: Request, res: Response): void => {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.includes('Americhan-Mod')) {
    res.status(401).json({ error: 'Moderator authentication required' });
    return;
  }

  const { action, targetId, reason, modName } = req.body;
  const operator = modName || 'Mod';

  if (action === 'delete_post') {
    const postId = parseInt(targetId, 10);
    // Search threads and replies
    let found = false;
    for (let i = 0; i < threads.length; i++) {
      const t = threads[i];
      if (t.opPost.id === postId) {
        // Deleting OP deletes entire thread
        threads.splice(i, 1);
        found = true;
        break;
      }
      const replyIdx = t.replies.findIndex((r) => r.id === postId);
      if (replyIdx !== -1) {
        t.replies.splice(replyIdx, 1);
        t.replyCount--;
        found = true;
        break;
      }
    }

    if (found) {
      modLogs.unshift({
        id: 'log-' + Date.now(),
        timestamp: formatChanDate(new Date()),
        action: 'DELETE_POST',
        targetId: postId,
        details: reason || 'Post deleted for board rule violation',
        modName: operator
      });
      res.json({ success: true, message: `Post #${postId} deleted` });
      return;
    }
    res.status(404).json({ error: 'Post not found' });
    return;
  }

  if (action === 'sticky_thread') {
    const threadId = parseInt(targetId, 10);
    const thread = threads.find((t) => t.id === threadId);
    if (!thread) {
      res.status(404).json({ error: 'Thread not found' });
      return;
    }

    thread.isSticky = !thread.isSticky;
    modLogs.unshift({
      id: 'log-' + Date.now(),
      timestamp: formatChanDate(new Date()),
      action: thread.isSticky ? 'STICKY_THREAD' : 'UNSTICKY_THREAD',
      targetId: threadId,
      details: thread.isSticky ? 'Thread pinned to top of board' : 'Thread unpinned',
      modName: operator
    });
    res.json({ success: true, isSticky: thread.isSticky });
    return;
  }

  if (action === 'lock_thread') {
    const threadId = parseInt(targetId, 10);
    const thread = threads.find((t) => t.id === threadId);
    if (!thread) {
      res.status(404).json({ error: 'Thread not found' });
      return;
    }

    thread.isClosed = !thread.isClosed;
    modLogs.unshift({
      id: 'log-' + Date.now(),
      timestamp: formatChanDate(new Date()),
      action: thread.isClosed ? 'LOCK_THREAD' : 'UNLOCK_THREAD',
      targetId: threadId,
      details: thread.isClosed ? 'Thread locked to prevent new replies' : 'Thread unlocked',
      modName: operator
    });
    res.json({ success: true, isClosed: thread.isClosed });
    return;
  }

  if (action === 'ban_poster') {
    const { posterId, postId } = req.body;
    if (!posterId) {
      res.status(400).json({ error: 'Poster ID required' });
      return;
    }

    bannedPosterIds.add(posterId);

    // If postId provided, stamp post with [USER WAS BANNED FOR THIS POST]
    if (postId) {
      const pid = parseInt(postId, 10);
      for (const t of threads) {
        if (t.opPost.id === pid) {
          t.opPost.isBanned = true;
          t.opPost.banReason = reason || 'Rule violation';
        }
        for (const r of t.replies) {
          if (r.id === pid) {
            r.isBanned = true;
            r.banReason = reason || 'Rule violation';
          }
        }
      }
    }

    modLogs.unshift({
      id: 'log-' + Date.now(),
      timestamp: formatChanDate(new Date()),
      action: 'BAN_POSTER',
      targetId: posterId,
      details: `Poster (${posterId}) banned: ${reason || 'Terms of service violation'}`,
      modName: operator
    });

    res.json({ success: true, message: `Poster ${posterId} banned successfully` });
    return;
  }

  if (action === 'unban_poster') {
    const { posterId } = req.body;
    bannedPosterIds.delete(posterId);
    modLogs.unshift({
      id: 'log-' + Date.now(),
      timestamp: formatChanDate(new Date()),
      action: 'UNBAN_POSTER',
      targetId: posterId,
      details: `Ban lifted for poster ${posterId}`,
      modName: operator
    });
    res.json({ success: true, message: `Ban lifted for poster ${posterId}` });
    return;
  }

  if (action === 'dismiss_report') {
    const reportId = targetId;
    const rep = reports.find((r) => r.id === reportId);
    if (rep) {
      rep.status = 'dismissed';
      res.json({ success: true, message: 'Report dismissed' });
      return;
    }
    res.status(404).json({ error: 'Report not found' });
    return;
  }

  res.status(400).json({ error: 'Unknown action' });
  return;
});

// GET /api/mod/logs - Mod audit logs
app.get('/api/mod/logs', (req: Request, res: Response): void => {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.includes('Americhan-Mod')) {
    res.status(401).json({ error: 'Moderator authentication required' });
    return;
  }
  res.json({ logs: modLogs, bannedCount: bannedPosterIds.size });
  return;
});

// GET /api/stats - Global statistics
app.get('/api/stats', (req: Request, res: Response) => {
  res.json({
    totalPosts: 4892317602 + postCounter - 38472200,
    activeUsers: 152348 + Math.floor(Math.random() * 25),
    onlineModerators: 18,
    serverUptime: '99.98%'
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

