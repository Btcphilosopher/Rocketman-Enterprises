'use client';

import React, { useState } from 'react';
import { ShoppingBag, X, Plus, Minus, Trash2, ShieldCheck, CheckCircle2 } from 'lucide-react';

export interface CartItem {
  id: string;
  name: string;
  unitPriceGBP: number;
  quantity: number;
  abv?: string;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
  currency: 'GBP' | 'USD' | 'EUR';
}

export default function CartDrawer({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  currency
}: CartDrawerProps) {
  const [ageConfirmed, setAgeConfirmed] = useState(false);
  const [checkoutComplete, setCheckoutComplete] = useState(false);
  const [orderId, setOrderId] = useState('');

  if (!isOpen) return null;

  const totalGBP = items.reduce((sum, item) => sum + item.unitPriceGBP * item.quantity, 0);

  const getPriceFormatted = (gbpAmount: number) => {
    if (currency === 'USD') return `$${(gbpAmount * 1.28).toFixed(2)}`;
    if (currency === 'EUR') return `€${(gbpAmount * 1.17).toFixed(2)}`;
    return `£${gbpAmount.toFixed(2)}`;
  };

  const handleCheckout = () => {
    if (!ageConfirmed) return;
    const generatedId = 'NSS-' + Math.floor(100000 + Math.random() * 900000);
    setOrderId(generatedId);
    setCheckoutComplete(true);
  };

  const handleCloseAndReset = () => {
    if (checkoutComplete) {
      onClearCart();
      setCheckoutComplete(false);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex justify-end">
      <div className="bg-[#07111e] border-l border-[#d4af37]/40 w-full max-w-md h-full flex flex-col justify-between p-6 shadow-2xl relative">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#d4af37]" />
            <h2 className="font-cinzel text-xl font-bold text-white">
              OFFICER&apos;S BAG
            </h2>
          </div>
          <button
            onClick={handleCloseAndReset}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        {checkoutComplete ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-4 p-6">
            <CheckCircle2 className="w-16 h-16 text-emerald-400 animate-bounce" />
            <span className="text-[10px] font-mono font-bold text-[#d4af37] uppercase tracking-widest">
              ORDER CONFIRMED #{orderId}
            </span>
            <h3 className="font-cinzel text-2xl font-bold text-white">
              DISPATCH QUEUED
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              Your bottle allocation has been reserved in Portsmouth Bonded Warehouse #4. Standard courier dispatch within 24 hours.
            </p>
            <div className="p-4 rounded-xl bg-[#050b14] border border-[#d4af37]/30 text-xs font-mono text-[#d4af37] w-full text-left">
              <div>Total Charged: {getPriceFormatted(totalGBP)}</div>
              <div>Age Verification: PASS (18+)</div>
            </div>
            <button
              onClick={handleCloseAndReset}
              className="w-full py-3 bg-[#d4af37] text-black font-bold text-xs uppercase rounded-xl hover:bg-[#e5c158]"
            >
              RETURN TO STORE
            </button>
          </div>
        ) : items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-3 p-6 text-slate-400">
            <ShoppingBag className="w-12 h-12 text-slate-600" />
            <p className="text-sm font-cinzel font-semibold text-slate-300">
              Your shopping bag is empty.
            </p>
            <p className="text-xs">
              Explore our Navy Rum 57% ABV flagship or overproof spirits collection.
            </p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto py-4 space-y-4 pr-1">
            {items.map((item) => (
              <div
                key={item.id}
                className="bg-[#091424] border border-[#d4af37]/20 rounded-xl p-4 flex items-center justify-between gap-4"
              >
                <div className="flex-1">
                  <h4 className="font-cinzel text-sm font-bold text-white">
                    {item.name}
                  </h4>
                  {item.abv && (
                    <span className="text-[10px] text-[#d4af37] font-mono block">
                      {item.abv}
                    </span>
                  )}
                  <span className="font-mono text-sm font-bold text-[#d4af37] mt-1 block">
                    {getPriceFormatted(item.unitPriceGBP)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1 bg-[#050b14] border border-white/10 rounded-lg p-1">
                    <button
                      onClick={() => onUpdateQuantity(item.id, -1)}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="font-mono text-xs font-bold text-white px-2">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => onUpdateQuantity(item.id, 1)}
                      className="p-1 text-slate-400 hover:text-white"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>

                  <button
                    onClick={() => onRemoveItem(item.id)}
                    className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-950/40 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Footer Checkout Summary */}
        {!checkoutComplete && items.length > 0 && (
          <div className="pt-4 border-t border-white/10 space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400 font-medium">Subtotal</span>
              <span className="font-mono text-xl font-bold text-[#d4af37]">
                {getPriceFormatted(totalGBP)}
              </span>
            </div>

            {/* Age Confirmation Checkbox */}
            <label className="flex items-start gap-3 text-xs text-slate-300 cursor-pointer bg-[#050b14] p-3 rounded-xl border border-white/5">
              <input
                type="checkbox"
                checked={ageConfirmed}
                onChange={(e) => setAgeConfirmed(e.target.checked)}
                className="mt-0.5 accent-[#d4af37] rounded"
              />
              <span>
                I confirm I am over 18 years of age and authorized to purchase alcohol.
              </span>
            </label>

            <button
              disabled={!ageConfirmed}
              onClick={handleCheckout}
              className={`w-full py-4 rounded-xl font-extrabold text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                ageConfirmed
                  ? 'bg-[#d4af37] hover:bg-[#e5c158] text-black gold-glow'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>PROCEED TO SECURE CHECKOUT</span>
            </button>
          </div>
        )}

      </div>
    </div>
  );
}
