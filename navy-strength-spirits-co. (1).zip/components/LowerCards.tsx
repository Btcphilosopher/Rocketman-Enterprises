'use client';

import React from 'react';
import { ChevronRight, Crown } from 'lucide-react';
import Image from 'next/image';

interface LowerCardsProps {
  onNavigate: (sectionId: string) => void;
  onOpenCart: () => void;
}

export default function LowerCards({ onNavigate, onOpenCart }: LowerCardsProps) {
  const cards = [
    {
      id: 'heritage',
      title: 'OUR HERITAGE',
      description: 'A proud tradition since the age of sail.',
      actionText: 'LEARN MORE >',
      image: '/src/assets/images/sailor_deck_heritage_1793607519608.jpg',
      sectionTarget: 'heritage'
    },
    {
      id: 'cocktails',
      title: 'COCKTAIL RECIPES',
      description: 'Bold drinks for bold spirits.',
      actionText: 'EXPLORE RECIPES >',
      image: '/src/assets/images/cocktail_dark_and_stormy_1793607517765.jpg',
      sectionTarget: 'cocktails'
    },
    {
      id: 'range',
      title: 'OUR RANGE',
      description: 'From Navy Rum to Overproof Vodka.',
      actionText: 'VIEW RANGE >',
      image: '/src/assets/images/gold_bottle_overproof_vodka_1793607518819.jpg',
      sectionTarget: 'spirits'
    }
  ];

  return (
    <section className="bg-[#050b14] py-12 border-b border-[#d4af37]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          {/* Card 1: Our Heritage */}
          {cards.map((card) => (
            <div
              key={card.id}
              onClick={() => onNavigate(card.sectionTarget)}
              className="group relative h-80 rounded-xl overflow-hidden border border-[#d4af37]/30 hover:border-[#d4af37] transition-all duration-300 cursor-pointer shadow-xl"
            >
              <Image
                src={card.image}
                alt={card.title}
                fill
                className="object-cover object-center group-hover:scale-110 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#050b14] via-[#050b14]/60 to-transparent" />
              
              <div className="absolute bottom-0 left-0 right-0 p-6 flex flex-col justify-end">
                <h3 className="font-cinzel text-lg font-bold text-white group-hover:text-[#d4af37] transition-colors">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-300 mt-1 font-sans">
                  {card.description}
                </p>
                <div className="mt-4 flex items-center gap-1 text-xs font-bold tracking-widest text-[#d4af37] group-hover:translate-x-1 transition-transform">
                  <span>{card.actionText}</span>
                </div>
              </div>
            </div>
          ))}

          {/* Card 4: Gold Branded CTA Box */}
          <div
            onClick={onOpenCart}
            className="group relative h-80 rounded-xl overflow-hidden bg-gradient-to-br from-[#d4af37] via-[#b8860b] to-[#8b6508] p-8 flex flex-col justify-between cursor-pointer border border-[#f5ebd7]/50 shadow-2xl hover:brightness-105 transition-all"
          >
            <div className="flex flex-col items-center text-center space-y-3 pt-6">
              <div className="w-14 h-14 rounded-full bg-[#050b14]/20 border border-[#050b14]/30 flex items-center justify-center text-[#050b14]">
                <Crown className="w-8 h-8" />
              </div>
              <h3 className="font-cinzel text-2xl font-extrabold text-[#050b14] tracking-wider leading-tight">
                NAVY STRENGTH <br /> SPIRITS CO.
              </h3>
              <span className="text-xs font-bold tracking-[0.25em] text-[#050b14]/80 uppercase">
                BRITISH
              </span>
            </div>

            <div className="w-full">
              <button className="w-full py-3 px-6 bg-[#050b14] hover:bg-[#0c192d] text-[#d4af37] text-xs font-bold tracking-widest uppercase rounded border border-[#d4af37]/40 flex items-center justify-center gap-2 group-hover:scale-105 transition-all">
                <span>SHOP NOW</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
