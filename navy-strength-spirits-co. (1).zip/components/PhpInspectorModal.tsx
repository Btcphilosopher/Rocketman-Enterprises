'use client';

import React, { useState } from 'react';
import { PHP_CODE_SNIPPETS } from '@/lib/data';
import { Code2, Play, Terminal, CheckCircle2, FileCode, Copy, Check } from 'lucide-react';

interface PhpInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function PhpInspectorModal({ isOpen, onClose }: PhpInspectorModalProps) {
  const [selectedSnippet, setSelectedSnippet] = useState(PHP_CODE_SNIPPETS[0]);
  const [copied, setCopied] = useState(false);
  const [testApiRoute, setTestApiRoute] = useState<'spirits' | 'gunpowder' | 'order'>('gunpowder');
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [loadingApi, setLoadingApi] = useState(false);

  if (!isOpen) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedSnippet.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunPhpSimulation = () => {
    setLoadingApi(true);
    setApiResponse(null);

    setTimeout(() => {
      setLoadingApi(false);
      if (testApiRoute === 'gunpowder') {
        setApiResponse(JSON.stringify({
          status: '200 OK',
          php_engine: 'PHP 8.3.4 (Zend Engine v4.3.4)',
          script: 'GunpowderCalculator.php',
          execution_time_ms: 1.42,
          result: {
            abv_percent: 57.0,
            uk_proof: 99.8,
            us_proof: 114.0,
            gunpowder_ignition_test: 'PASSED (FLAMMABLE)',
            security_check: 'Age Verification Cookie Verified'
          }
        }, null, 2));
      } else if (testApiRoute === 'spirits') {
        setApiResponse(JSON.stringify({
          status: '200 OK',
          php_engine: 'PHP 8.3.4',
          script: 'SpiritsCatalog.php',
          execution_time_ms: 2.18,
          result: {
            spirits_count: 5,
            flagship: 'British Navy Rum Overproof (57% ABV)',
            warehouse_status: 'Portsmouth Bonded Vault #4 Active'
          }
        }, null, 2));
      } else {
        setApiResponse(JSON.stringify({
          status: '200 OK',
          php_engine: 'PHP 8.3.4',
          script: 'api_orders.php',
          execution_time_ms: 3.05,
          result: {
            order_id: 'NSS-7F3A0B',
            dispatch_status: 'QUEUED',
            vat_duty_paid: true
          }
        }, null, 2));
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#07111e] border-2 border-[#d4af37]/60 rounded-2xl max-w-5xl w-full h-[85vh] flex flex-col overflow-hidden shadow-2xl">
        
        {/* Header */}
        <div className="p-4 sm:p-6 bg-[#091424] border-b border-[#d4af37]/30 flex items-center justify-between gap-4 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-[#d4af37]/10 border border-[#d4af37]/40 text-[#d4af37]">
              <Code2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-[10px] bg-[#d4af37] text-black font-extrabold px-2 py-0.5 rounded">
                  PHP 8.3
                </span>
                <span className="text-xs text-slate-400 font-mono">Backend Architecture & Template Source</span>
              </div>
              <h2 className="font-cinzel text-xl font-bold text-white">
                PHP STOREFRONT ARCHITECTURE INSPECTOR
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 font-bold"
          >
            ✕
          </button>
        </div>

        {/* Modal Main Content Split */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          
          {/* File Selector Sidebar */}
          <div className="lg:col-span-4 bg-[#050b14] border-r border-white/10 p-4 space-y-3 overflow-y-auto shrink-0">
            <span className="text-[10px] font-mono uppercase text-[#d4af37] tracking-widest block px-2">
              PHP SCRIPTS & DOMAIN MODELS
            </span>

            {PHP_CODE_SNIPPETS.map((snippet) => (
              <button
                key={snippet.filename}
                onClick={() => setSelectedSnippet(snippet)}
                className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between gap-3 ${
                  selectedSnippet.filename === snippet.filename
                    ? 'bg-[#0c1a2e] border-[#d4af37] text-[#d4af37]'
                    : 'bg-[#091424]/50 border-white/5 text-slate-300 hover:border-white/20'
                }`}
              >
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <FileCode className="w-4 h-4 shrink-0" />
                  <div className="truncate">
                    <span className="font-mono text-xs font-bold block truncate">
                      {snippet.filename}
                    </span>
                    <span className="text-[10px] text-slate-400 font-sans block truncate">
                      {snippet.title}
                    </span>
                  </div>
                </div>
              </button>
            ))}

            {/* Live PHP API Tester Section */}
            <div className="pt-6 border-t border-white/10 space-y-3">
              <span className="text-[10px] font-mono uppercase text-[#d4af37] tracking-widest block px-2">
                TEST LIVE PHP API ENDPOINTS
              </span>

              <div className="space-y-2">
                {[
                  { id: 'gunpowder', label: 'POST /api/gunpowder_test.php' },
                  { id: 'spirits', label: 'GET /api/spirits_catalog.php' },
                  { id: 'order', label: 'POST /api/process_order.php' }
                ].map((route) => (
                  <button
                    key={route.id}
                    onClick={() => setTestApiRoute(route.id as any)}
                    className={`w-full text-left p-2.5 rounded-lg text-xs font-mono transition-all border ${
                      testApiRoute === route.id
                        ? 'bg-[#d4af37]/20 border-[#d4af37] text-[#d4af37]'
                        : 'bg-[#050b14] border-white/5 text-slate-400'
                    }`}
                  >
                    {route.label}
                  </button>
                ))}

                <button
                  onClick={handleRunPhpSimulation}
                  disabled={loadingApi}
                  className="w-full py-2.5 bg-[#d4af37] hover:bg-[#e5c158] text-black font-extrabold text-xs font-mono uppercase rounded-lg flex items-center justify-center gap-2"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>{loadingApi ? 'EXECUTING PHP...' : 'RUN PHP SCRIPT'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Code Viewer & Terminal Output Right */}
          <div className="lg:col-span-8 flex flex-col h-full bg-[#030810] overflow-hidden">
            
            {/* Top Toolbar */}
            <div className="p-3 bg-[#08111e] border-b border-white/10 flex items-center justify-between text-xs font-mono shrink-0">
              <span className="text-slate-300 font-bold flex items-center gap-2">
                <FileCode className="w-4 h-4 text-[#d4af37]" />
                {selectedSnippet.filename} — {selectedSnippet.title}
              </span>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 rounded text-slate-300"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Code'}</span>
              </button>
            </div>

            {/* Main Code View */}
            <div className="flex-1 overflow-y-auto p-4 font-mono text-xs text-slate-200 leading-relaxed bg-[#030810]">
              <pre className="whitespace-pre-wrap">
                <code>{selectedSnippet.code}</code>
              </pre>
            </div>

            {/* Terminal Response Drawer if executed */}
            {apiResponse && (
              <div className="h-48 border-t border-[#d4af37]/40 bg-[#02050a] p-4 font-mono text-xs overflow-y-auto space-y-2 shrink-0">
                <div className="flex items-center justify-between text-[#d4af37] text-[10px] uppercase font-bold border-b border-white/10 pb-1">
                  <span className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5" />
                    <span>PHP SCRIPT EXECUTION RESPONSE</span>
                  </span>
                  <button onClick={() => setApiResponse(null)} className="text-slate-500 hover:text-white">✕</button>
                </div>
                <pre className="text-emerald-400 whitespace-pre-wrap font-mono text-[11px]">
                  {apiResponse}
                </pre>
              </div>
            )}

          </div>

        </div>

      </div>
    </div>
  );
}
