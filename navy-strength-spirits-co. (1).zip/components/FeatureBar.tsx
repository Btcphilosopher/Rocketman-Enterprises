'use client';

import React from 'react';
import { Gem, Flame, Globe2, Sparkles, Building2 } from 'lucide-react';

export default function FeatureBar() {
  const features = [
    {
      id: 'heritage',
      title: 'BRITISH HERITAGE',
      subtitle: 'Official Admiralty Heritage',
      icon: (
        <svg className="w-7 h-7 text-[#d4af37]" viewBox="0 0 60 30" fill="none">
          <clipPath id="s"><path d="M0,0 v30 h60 v-30 z"/></clipPath>
          <path d="M0,0 v30 h60 v-30 z" fill="#012169"/>
          <path d="M0,0 L60,30 M60,0 L0,30" stroke="#fff" strokeWidth="6"/>
          <path d="M0,0 L60,30 M60,0 L0,30" stroke="#C8102E" strokeWidth="4" clipPath="url(#s)"/>
          <path d="M30,0 v30 M0,15 h60" stroke="#fff" strokeWidth="10"/>
          <path d="M30,0 v30 M0,15 h60" stroke="#C8102E" strokeWidth="6"/>
        </svg>
      )
    },
    {
      id: 'strength',
      title: 'OVERPROOF STRENGTH',
      subtitle: '57.0% ABV / 100° Proof',
      icon: <Gem className="w-7 h-7 text-[#d4af37]" />
    },
    {
      id: 'quality',
      title: 'PREMIUM QUALITY',
      subtitle: 'Copper Pot Still & Solera Oak',
      icon: <Sparkles className="w-7 h-7 text-[#d4af37]" />
    },
    {
      id: 'distribution',
      title: 'GLOBAL DISTRIBUTION',
      subtitle: 'Tax Bonded & Duty Free',
      icon: <Globe2 className="w-7 h-7 text-[#d4af37]" />
    }
  ];

  return (
    <section className="bg-[#040910] border-y border-[#d4af37]/30 py-8 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 divide-y sm:divide-y-0 sm:divide-x divide-[#d4af37]/20">
          {features.map((feature) => (
            <div
              key={feature.id}
              className="flex items-center gap-4 pt-4 sm:pt-0 sm:px-4 first:pl-0 last:pr-0 group cursor-default"
            >
              <div className="w-12 h-12 rounded-xl bg-[#0c192d] border border-[#d4af37]/30 flex items-center justify-center shrink-0 group-hover:border-[#d4af37] transition-colors shadow-lg">
                {feature.icon}
              </div>
              <div className="flex flex-col">
                <span className="font-cinzel text-xs sm:text-sm font-bold tracking-widest text-[#f5ebd7] group-hover:text-[#d4af37] transition-colors">
                  {feature.title}
                </span>
                <span className="text-[11px] text-slate-400 font-medium">
                  {feature.subtitle}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
