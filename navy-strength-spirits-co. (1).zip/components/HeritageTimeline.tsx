'use client';

import React from 'react';
import { HERITAGE_MILESTONES } from '@/lib/data';
import { Anchor, Compass, Shield, Award, Landmark } from 'lucide-react';

export default function HeritageTimeline() {
  return (
    <section id="heritage" className="py-20 bg-[#040810] border-t border-[#d4af37]/30 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#d4af37]/40 bg-[#d4af37]/10 text-[#d4af37] text-xs font-semibold tracking-widest uppercase">
            <Anchor className="w-4 h-4" />
            <span>370 YEARS OF ROYAL NAVY TRADITION</span>
          </div>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-[#f5ebd7]">
            OUR HERITAGE & TIMELINE
          </h2>
          <p className="font-cormorant text-xl text-slate-300 italic">
            From the wooden decks of 17th century warships to modern craft distilling in copper pot stills.
          </p>
        </div>

        {/* Vertical Timeline */}
        <div className="relative border-l-2 border-[#d4af37]/30 ml-4 md:ml-32 space-y-12">
          {HERITAGE_MILESTONES.map((item, idx) => (
            <div key={idx} className="relative pl-8 md:pl-12 group">
              
              {/* Year Marker Left (Desktop) */}
              <div className="hidden md:block absolute -left-32 top-0 text-right w-24">
                <span className="font-mono text-2xl font-black text-[#d4af37]">
                  {item.year}
                </span>
              </div>

              {/* Node Bullet */}
              <div className="absolute -left-[17px] top-1.5 w-8 h-8 rounded-full bg-[#050b14] border-2 border-[#d4af37] flex items-center justify-center text-[#d4af37] shadow-lg group-hover:scale-125 transition-transform">
                <Anchor className="w-4 h-4" />
              </div>

              {/* Content Card */}
              <div className="bg-[#091322] border border-[#d4af37]/30 hover:border-[#d4af37] rounded-2xl p-6 sm:p-8 space-y-3 shadow-xl transition-all">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="md:hidden font-mono text-xl font-bold text-[#d4af37]">
                    {item.year}
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest bg-[#050b14] px-2.5 py-1 rounded border border-white/10">
                    {item.location}
                  </span>
                </div>

                <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white">
                  {item.title}
                </h3>
                <p className="text-xs font-semibold text-[#d4af37] tracking-wider uppercase">
                  {item.subtitle}
                </p>

                <p className="text-xs sm:text-sm text-slate-300 font-sans leading-relaxed pt-2">
                  {item.description}
                </p>
              </div>

            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
