'use client';

import React, { useState, useEffect } from 'react';
import { Crown, ShieldAlert } from 'lucide-react';

export default function AgeVerificationModal() {
  const [verified, setVerified] = useState<boolean>(true); // default true while checking localStorage
  const [declined, setDeclined] = useState<boolean>(false);

  useEffect(() => {
    const isAgeVerified = localStorage.getItem('navy_rum_age_verified');
    if (isAgeVerified !== 'true') {
      setVerified(false);
    }
  }, []);

  const handleConfirmAge = () => {
    localStorage.setItem('navy_rum_age_verified', 'true');
    setVerified(true);
  };

  const handleDeclineAge = () => {
    setDeclined(true);
  };

  if (verified) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#03070d]/95 backdrop-blur-xl flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-[#081220] border-2 border-[#d4af37] rounded-3xl p-8 text-center space-y-6 shadow-2xl gold-border-glow relative overflow-hidden">
        
        {/* Top Crest */}
        <div className="w-16 h-16 mx-auto rounded-full bg-[#d4af37]/20 border border-[#d4af37] flex items-center justify-center text-[#d4af37] gold-glow">
          <Crown className="w-9 h-9" />
        </div>

        <div className="space-y-2">
          <span className="text-[10px] font-bold tracking-[0.25em] text-[#d4af37] uppercase">
            ADMIRALTY SPIRITS COMPLIANCE
          </span>
          <h2 className="font-cinzel text-2xl sm:text-3xl font-extrabold text-[#f5ebd7]">
            AGE VERIFICATION
          </h2>
          <p className="font-cormorant text-lg text-slate-300 italic">
            You must be of legal drinking age in your country of residence to enter Navy Strength Spirits Co.
          </p>
        </div>

        {declined ? (
          <div className="p-4 bg-rose-950/60 border border-rose-500/50 rounded-2xl text-xs text-rose-300 space-y-2">
            <ShieldAlert className="w-6 h-6 mx-auto text-rose-400" />
            <p className="font-bold">Access Restricted</p>
            <p className="opacity-90">
              You must be of legal drinking age to access this website. Thank you for your understanding.
            </p>
          </div>
        ) : (
          <div className="space-y-3 pt-2">
            <button
              onClick={handleConfirmAge}
              className="w-full py-4 bg-[#d4af37] hover:bg-[#e5c158] text-black font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all gold-glow"
            >
              I AM OVER 18 / 21 YEARS OLD
            </button>

            <button
              onClick={handleDeclineAge}
              className="w-full py-3 bg-transparent hover:bg-white/5 border border-slate-700 text-slate-400 hover:text-white font-semibold text-xs uppercase tracking-wider rounded-xl transition-all"
            >
              I am under legal drinking age
            </button>
          </div>
        )}

        <div className="pt-2 text-[10px] text-slate-500 font-mono">
          Enjoy Navy Strength Spirits responsibly. DrinkAware.co.uk
        </div>
      </div>
    </div>
  );
}
