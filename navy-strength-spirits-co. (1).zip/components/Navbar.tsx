'use client';

import React, { useState } from 'react';
import { ShoppingBag, Search, Code2, Menu, X, Crown, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenPhpInspector: () => void;
  activeSection: string;
  setActiveSection: (section: string) => void;
}

export default function Navbar({
  cartCount,
  onOpenCart,
  onOpenPhpInspector,
  activeSection,
  setActiveSection
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const navLinks = [
    { id: 'spirits', label: 'OUR SPIRITS' },
    { id: 'heritage', label: 'OUR HERITAGE' },
    { id: 'cocktails', label: 'COCKTAILS' },
    { id: 'proof-calculator', label: 'PROOF CALCULATOR' },
    { id: 'trade', label: 'TRADE' },
    { id: 'about', label: 'ABOUT' }
  ];

  const handleNavClick = (id: string) => {
    setActiveSection(id);
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#050b14]/90 backdrop-blur-md border-b border-[#d4af37]/20 transition-all duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-8">
          
          {/* Zone 1: Single Wordmark Brand Zone */}
          <button 
            onClick={() => handleNavClick('hero')}
            className="flex items-center gap-3 text-left focus:outline-none group shrink-0"
          >
            <div className="w-9 h-9 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37] group-hover:bg-[#d4af37]/20 transition-colors">
              <Crown className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="font-cinzel text-lg sm:text-xl font-bold tracking-widest text-[#f5ebd7] group-hover:text-[#d4af37] transition-colors whitespace-nowrap">
                NAVY STRENGTH
              </span>
              <div className="flex items-center gap-2 text-[10px] tracking-[0.25em] text-[#d4af37]/80 uppercase font-semibold">
                <span>SPIRITS CO.</span>
                <span>•</span>
                <span className="text-[#f5ebd7]">BRITISH</span>
              </div>
            </div>
          </button>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 text-xs font-semibold tracking-[0.18em] text-[#e2e8f0]/80">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`hover:text-[#d4af37] transition-colors py-2 whitespace-nowrap relative ${
                  activeSection === link.id ? 'text-[#d4af37]' : ''
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#d4af37] rounded-full" />
                )}
              </button>
            ))}
          </nav>

          {/* Zone 3: Actions */}
          <div className="flex items-center gap-3 shrink-0">
            {/* Search Button */}
            <div className="relative">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 text-[#e2e8f0]/70 hover:text-[#d4af37] transition-colors rounded-lg hover:bg-white/5"
                title="Search Spirits"
              >
                <Search className="w-5 h-5" />
              </button>
              
              {searchOpen && (
                <div className="absolute right-0 top-12 w-72 bg-[#0c182b] border border-[#d4af37]/40 rounded-xl p-3 shadow-2xl z-50">
                  <input
                    type="text"
                    placeholder="Search rum, vodka, recipes..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#050b14] text-xs text-slate-100 border border-[#d4af37]/30 rounded-lg px-3 py-2 focus:outline-none focus:border-[#d4af37]"
                    autoFocus
                  />
                  {searchQuery && (
                    <div className="mt-2 text-[11px] text-[#d4af37] font-medium">
                      Press enter to search for &quot;{searchQuery}&quot;
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* PHP Backend Inspector Button */}
            <button
              onClick={onOpenPhpInspector}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 text-xs font-mono border border-[#d4af37]/40 bg-[#d4af37]/10 text-[#d4af37] rounded-lg hover:bg-[#d4af37]/20 transition-all hover:scale-105"
              title="View PHP Backend Source & Architecture"
            >
              <Code2 className="w-4 h-4 text-[#d4af37]" />
              <span className="font-semibold tracking-wide">PHP Backend</span>
            </button>

            {/* Shopping Bag Button */}
            <button
              onClick={onOpenCart}
              className="relative flex items-center justify-center p-2.5 text-[#050b14] bg-[#d4af37] hover:bg-[#e5c158] transition-all rounded-lg font-bold text-xs gold-glow"
              title="View Shopping Bag"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#050b14] animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-300 hover:text-white"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#0a1526] border-b border-[#d4af37]/30 px-4 py-6 space-y-4">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className="text-left text-sm font-semibold tracking-widest text-[#f5ebd7] hover:text-[#d4af37] py-2 border-b border-white/5"
              >
                {link.label}
              </button>
            ))}
          </nav>

          <div className="pt-4 flex flex-col gap-3">
            <button
              onClick={() => {
                onOpenPhpInspector();
                setMobileMenuOpen(false);
              }}
              className="flex items-center justify-center gap-2 w-full py-2.5 text-xs font-mono border border-[#d4af37]/40 bg-[#d4af37]/10 text-[#d4af37] rounded-lg"
            >
              <Code2 className="w-4 h-4" />
              <span>Inspect PHP Backend Architecture</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
