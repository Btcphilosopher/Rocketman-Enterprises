'use client';

import React, { useState } from 'react';
import { Product, PRODUCTS } from '@/lib/data';
import { ShoppingBag, Eye, Star, Flame, Check, Sparkles } from 'lucide-react';
import Image from 'next/image';

interface SpiritsCatalogProps {
  currency: 'GBP' | 'USD' | 'EUR';
  setCurrency: (c: 'GBP' | 'USD' | 'EUR') => void;
  onAddToCart: (product: Product) => void;
}

export default function SpiritsCatalog({
  currency,
  setCurrency,
  onAddToCart
}: SpiritsCatalogProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedProductNotes, setSelectedProductNotes] = useState<Product | null>(null);
  const [addedItemMap, setAddedItemMap] = useState<Record<string, boolean>>({});

  const filteredProducts = PRODUCTS.filter((p) => {
    if (selectedCategory === 'all') return true;
    return p.category === selectedCategory;
  });

  const getPrice = (product: Product) => {
    if (currency === 'USD') return `$${product.priceUSD.toFixed(2)}`;
    if (currency === 'EUR') return `€${product.priceEUR.toFixed(2)}`;
    return `£${product.priceGBP.toFixed(2)}`;
  };

  const handleAdd = (product: Product) => {
    onAddToCart(product);
    setAddedItemMap((prev) => ({ ...prev, [product.id]: true }));
    setTimeout(() => {
      setAddedItemMap((prev) => ({ ...prev, [product.id]: false }));
    }, 1500);
  };

  return (
    <section id="spirits" className="py-20 bg-[#050b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-12 border-b border-[#d4af37]/20">
          <div>
            <span className="text-xs font-bold tracking-[0.25em] text-[#d4af37] uppercase block mb-2">
              ADMIRALTY DISTILLATION RANGE
            </span>
            <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-[#f5ebd7]">
              OUR SPIRITS COLLECTION
            </h2>
          </div>

          {/* Currency Switcher & Category Buttons */}
          <div className="flex items-center gap-4">
            <span className="text-xs text-slate-400 font-medium">Currency:</span>
            <div className="inline-flex p-1 bg-[#0c182b] border border-[#d4af37]/30 rounded-lg text-xs font-semibold">
              {(['GBP', 'USD', 'EUR'] as const).map((c) => (
                <button
                  key={c}
                  onClick={() => setCurrency(c)}
                  className={`px-3 py-1.5 rounded-md transition-colors ${
                    currency === c
                      ? 'bg-[#d4af37] text-black font-bold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {c === 'GBP' ? '£ GBP' : c === 'USD' ? '$ USD' : '€ EUR'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Category Segmented Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto py-6 border-b border-white/5 scrollbar-none">
          {[
            { id: 'all', label: 'All Spirits' },
            { id: 'rum', label: 'Navy Rums' },
            { id: 'vodka', label: 'Overproof Vodka' },
            { id: 'limited', label: 'Limited Editions' },
            { id: 'gift', label: 'Gift Sets' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-lg text-xs font-bold tracking-wider uppercase transition-all whitespace-nowrap ${
                selectedCategory === cat.id
                  ? 'bg-[#d4af37]/20 border border-[#d4af37] text-[#d4af37]'
                  : 'bg-[#0a1526]/60 border border-white/10 text-slate-400 hover:text-white hover:border-white/20'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-[#091424] border border-[#d4af37]/25 hover:border-[#d4af37] rounded-2xl overflow-hidden transition-all duration-300 flex flex-col justify-between hover:shadow-2xl hover:shadow-[#d4af37]/10"
            >
              {/* Image Header & Badges */}
              <div className="relative aspect-[4/3] bg-[#070f1a] overflow-hidden p-6 flex items-center justify-center">
                <Image
                  src={product.image}
                  alt={product.name}
                  fill
                  className="object-contain p-4 group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#091424] via-transparent to-transparent opacity-80" />

                {/* Top Left Badge */}
                {product.badge && (
                  <div className="absolute top-4 left-4 px-3 py-1 bg-[#d4af37] text-[#050b14] text-[10px] font-extrabold tracking-widest uppercase rounded shadow-lg">
                    {product.badge}
                  </div>
                )}

                {/* Top Right ABV Indicator */}
                <div className="absolute top-4 right-4 flex items-center gap-1 px-2.5 py-1 bg-[#050b14]/90 border border-[#d4af37]/50 rounded text-xs font-mono font-bold text-[#d4af37]">
                  <Flame className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>{product.abv}</span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-1">
                    <span>{product.volume}</span>
                    <div className="flex items-center gap-1 text-[#d4af37]">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span className="font-bold text-slate-200">{product.rating}</span>
                      <span className="text-slate-500">({product.reviewsCount})</span>
                    </div>
                  </div>

                  <h3 className="font-cinzel text-xl font-bold text-white group-hover:text-[#d4af37] transition-colors leading-snug">
                    {product.name}
                  </h3>
                  <p className="text-xs text-[#d4af37] font-medium mt-1">
                    {product.subTitle}
                  </p>
                  <p className="text-xs text-slate-300 font-sans mt-3 line-clamp-3 leading-relaxed">
                    {product.description}
                  </p>
                </div>

                {/* Price & Action Buttons */}
                <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-4">
                  <div>
                    <span className="text-[10px] text-slate-400 uppercase tracking-widest block">Price</span>
                    <span className="font-mono text-2xl font-black text-[#d4af37]">
                      {getPrice(product)}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* View Tasting Notes */}
                    <button
                      onClick={() => setSelectedProductNotes(product)}
                      className="p-3 bg-[#0a182d] border border-[#d4af37]/30 text-slate-300 hover:text-[#d4af37] hover:border-[#d4af37] rounded-xl transition-all"
                      title="View Tasting Notes & Cask Specs"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    {/* Add to Cart */}
                    <button
                      onClick={() => handleAdd(product)}
                      disabled={!product.inStock}
                      className={`px-5 py-3 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg ${
                        addedItemMap[product.id]
                          ? 'bg-emerald-500 text-black'
                          : product.inStock
                          ? 'bg-[#d4af37] hover:bg-[#e5c158] text-[#050b14] gold-glow'
                          : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      {addedItemMap[product.id] ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>ADDED</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-4 h-4" />
                          <span>ADD TO BAG</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Tasting Notes Modal */}
      {selectedProductNotes && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0c192d] border border-[#d4af37]/50 rounded-2xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl relative">
            <button
              onClick={() => setSelectedProductNotes(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white text-lg font-bold"
            >
              ✕
            </button>

            <div className="flex items-center gap-2 text-xs font-mono text-[#d4af37] uppercase tracking-widest">
              <Sparkles className="w-4 h-4" />
              <span>OFFICIAL TASTING NOTES</span>
            </div>

            <div>
              <h3 className="font-cinzel text-2xl font-bold text-white">
                {selectedProductNotes.name}
              </h3>
              <p className="text-xs text-[#d4af37] font-semibold mt-1">
                {selectedProductNotes.subTitle}
              </p>
            </div>

            <div className="space-y-4 text-xs font-sans">
              <div className="p-4 rounded-xl bg-[#050b14] border border-[#d4af37]/20">
                <span className="font-bold text-[#d4af37] uppercase tracking-wider block mb-1">NOSE</span>
                <p className="text-slate-300 leading-relaxed">{selectedProductNotes.tastingNotes.nose}</p>
              </div>

              <div className="p-4 rounded-xl bg-[#050b14] border border-[#d4af37]/20">
                <span className="font-bold text-[#d4af37] uppercase tracking-wider block mb-1">PALATE</span>
                <p className="text-slate-300 leading-relaxed">{selectedProductNotes.tastingNotes.palate}</p>
              </div>

              <div className="p-4 rounded-xl bg-[#050b14] border border-[#d4af37]/20">
                <span className="font-bold text-[#d4af37] uppercase tracking-wider block mb-1">FINISH</span>
                <p className="text-slate-300 leading-relaxed">{selectedProductNotes.tastingNotes.finish}</p>
              </div>
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => {
                  handleAdd(selectedProductNotes);
                  setSelectedProductNotes(null);
                }}
                className="w-full py-3 bg-[#d4af37] text-black font-bold text-xs uppercase rounded-xl hover:bg-[#e5c158] transition-colors"
              >
                ADD TO BAG ({getPrice(selectedProductNotes)})
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
