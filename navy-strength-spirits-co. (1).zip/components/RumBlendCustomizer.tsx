'use client';

import React, { useState } from 'react';
import { Flame, Compass, Sparkles, AlertTriangle, ShieldCheck, Check } from 'lucide-react';

interface RumBlendCustomizerProps {
  onOrderCustomBlend: (blendName: string, abv: number, price: number) => void;
}

export default function RumBlendCustomizer({ onOrderCustomBlend }: RumBlendCustomizerProps) {
  const [abv, setAbv] = useState<number>(57.0);
  const [agingYears, setAgingYears] = useState<number>(7);
  const [caskType, setCaskType] = useState<string>('Ex-Bourbon White Oak');
  const [blendName, setBlendName] = useState<string>('HMS Commander Reserve');
  const [orderedSuccess, setOrderedSuccess] = useState<boolean>(false);

  // Calculations
  const ukProof = (abv * 1.751).toFixed(1);
  const usProof = (abv * 2.0).toFixed(1);
  const passesGunpowderTest = abv >= 57.0;

  const basePrice = 50;
  const ageMultiplier = 1 + (agingYears * 0.08);
  const abvMultiplier = 1 + ((abv - 40) * 0.015);
  const totalPrice = Math.round((basePrice * ageMultiplier * abvMultiplier) * 100) / 100;

  const handleOrder = () => {
    onOrderCustomBlend(`${blendName} (${abv}% ABV, ${agingYears}yr ${caskType})`, abv, totalPrice);
    setOrderedSuccess(true);
    setTimeout(() => setOrderedSuccess(false), 3000);
  };

  return (
    <section id="proof-calculator" className="py-20 bg-[#040810] border-y border-[#d4af37]/30 relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#d4af37]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#d4af37]/40 bg-[#d4af37]/10 text-[#d4af37] text-xs font-semibold tracking-widest uppercase">
            <Compass className="w-4 h-4" />
            <span>ROYAL NAVY HYDROMETER SIMULATOR</span>
          </div>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-[#f5ebd7]">
            CUSTOM PROOF & BLEND CALCULATOR
          </h2>
          <p className="font-cormorant text-xl text-slate-300 italic">
            Simulate historic Admiralty hydrometer tests, calculate UK/US proof standards, and design your bespoke cask strength rum.
          </p>
        </div>

        {/* Interactive Calculator Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Controls Column */}
          <div className="lg:col-span-7 bg-[#091322] border border-[#d4af37]/30 rounded-2xl p-6 sm:p-8 space-y-8 shadow-2xl">
            
            {/* Custom Blend Name */}
            <div>
              <label className="text-xs font-bold uppercase tracking-widest text-[#d4af37] block mb-2">
                1. Bespoke Cask Name
              </label>
              <input
                type="text"
                value={blendName}
                onChange={(e) => setBlendName(e.target.value)}
                className="w-full bg-[#050b14] border border-[#d4af37]/30 rounded-xl px-4 py-3 text-sm text-slate-100 font-cinzel font-bold focus:outline-none focus:border-[#d4af37]"
                placeholder="e.g. HMS Victory Reserve"
              />
            </div>

            {/* Alcohol By Volume (ABV) Slider */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-widest text-[#d4af37]">
                  2. Alcohol By Volume (ABV %)
                </label>
                <span className="font-mono text-xl font-extrabold text-[#d4af37]">
                  {abv.toFixed(1)}% ABV
                </span>
              </div>
              <input
                type="range"
                min="35.0"
                max="75.0"
                step="0.5"
                value={abv}
                onChange={(e) => setAbv(parseFloat(e.target.value))}
                className="w-full accent-[#d4af37] bg-slate-800 h-2 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-2">
                <span>35% Standard</span>
                <span className="text-[#d4af37] font-bold">57.0% Navy Strength</span>
                <span>68.5% Gunpowder</span>
                <span>75% Max Still</span>
              </div>
            </div>

            {/* Aging Years */}
            <div>
              <label className="text-xs font-bold uppercase tracking-widest text-[#d4af37] block mb-3">
                3. Oak Barrel Aging Duration
              </label>
              <div className="grid grid-cols-4 gap-3">
                {[3, 7, 12, 20].map((years) => (
                  <button
                    key={years}
                    onClick={() => setAgingYears(years)}
                    className={`py-3 px-2 rounded-xl text-xs font-bold transition-all border ${
                      agingYears === years
                        ? 'bg-[#d4af37] text-black border-[#d4af37] font-black'
                        : 'bg-[#050b14] text-slate-300 border-white/10 hover:border-[#d4af37]/40'
                    }`}
                  >
                    {years} Years
                  </button>
                ))}
              </div>
            </div>

            {/* Cask Finish Selection */}
            <div>
              <label className="text-xs font-bold uppercase tracking-widest text-[#d4af37] block mb-3">
                4. Solera Cask Finish
              </label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  'Ex-Bourbon White Oak',
                  'Oloroso Sherry Cask',
                  'Pedro Ximénez PX',
                  'Peated Islay Cask'
                ].map((cask) => (
                  <button
                    key={cask}
                    onClick={() => setCaskType(cask)}
                    className={`py-3 px-3 text-left rounded-xl text-xs font-semibold transition-all border ${
                      caskType === cask
                        ? 'bg-[#d4af37]/20 text-[#d4af37] border-[#d4af37]'
                        : 'bg-[#050b14] text-slate-300 border-white/10 hover:border-[#d4af37]/40'
                    }`}
                  >
                    {cask}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Test Simulation Results Column */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Gunpowder Ignition Simulator Box */}
            <div className={`rounded-2xl p-6 sm:p-8 border transition-all shadow-2xl relative ${
              passesGunpowderTest
                ? 'bg-[#0c1c14] border-emerald-500/50 text-emerald-300'
                : 'bg-[#1c0c0c] border-rose-500/50 text-rose-300'
            }`}>
              <div className="flex items-center gap-3">
                <Flame className={`w-8 h-8 ${passesGunpowderTest ? 'text-emerald-400 animate-pulse' : 'text-rose-400'}`} />
                <div>
                  <span className="text-[10px] font-bold tracking-widest uppercase block">
                    ADMIRALTY GUNPOWDER TEST
                  </span>
                  <h3 className="font-cinzel text-xl font-bold">
                    {passesGunpowderTest ? 'PASSED — FLAMMABLE!' : 'FAILED — DAMPENED'}
                  </h3>
                </div>
              </div>

              <p className="text-xs font-sans mt-4 leading-relaxed opacity-90">
                {passesGunpowderTest
                  ? `At ${abv.toFixed(1)}% ABV, black gunpowder saturated with this rum WILL ignite when struck by flint! This meets or exceeds the Royal Navy 100° Proof standard.`
                  : `At ${abv.toFixed(1)}% ABV, excess water dampens black powder, preventing ignition. Ships purser fails this batch! Increase to at least 57.0% ABV.`
                }
              </p>
            </div>

            {/* Proof Metrics Breakdown */}
            <div className="bg-[#091322] border border-[#d4af37]/30 rounded-2xl p-6 space-y-4">
              <span className="text-xs font-bold uppercase tracking-widest text-[#d4af37] block">
                TECHNICAL PROOF CONVERSIONS
              </span>

              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="p-4 rounded-xl bg-[#050b14] border border-white/10">
                  <span className="text-[10px] text-slate-400 uppercase tracking-widest block">UK PROOF</span>
                  <span className="font-mono text-2xl font-black text-[#d4af37]">{ukProof}°</span>
                </div>
                <div className="p-4 rounded-xl bg-[#050b14] border border-white/10">
                  <span className="text-[10px] text-slate-400 uppercase tracking-widest block">US PROOF</span>
                  <span className="font-mono text-2xl font-black text-slate-200">{usProof}°</span>
                </div>
              </div>
            </div>

            {/* Custom Cask Order CTA */}
            <div className="bg-gradient-to-br from-[#0c182b] to-[#050b14] border border-[#d4af37] rounded-2xl p-6 space-y-4 shadow-2xl">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 uppercase tracking-widest block">ESTIMATED BOTTLE PRICE</span>
                  <span className="font-mono text-3xl font-black text-[#d4af37]">£{totalPrice.toFixed(2)}</span>
                </div>
                <Sparkles className="w-6 h-6 text-[#d4af37]" />
              </div>

              <button
                onClick={handleOrder}
                className="w-full py-4 bg-[#d4af37] hover:bg-[#e5c158] text-black font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all shadow-xl gold-glow flex items-center justify-center gap-2"
              >
                {orderedSuccess ? (
                  <>
                    <Check className="w-5 h-5" />
                    <span>BESPOKE BATCH ADDED TO BAG!</span>
                  </>
                ) : (
                  <span>ORDER BESPOKE BOTTLE</span>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
