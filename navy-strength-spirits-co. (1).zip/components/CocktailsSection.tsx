'use client';

import React, { useState } from 'react';
import { COCKTAILS, CocktailRecipe } from '@/lib/data';
import { Wine, Clock, Sparkles, ChevronRight, Check } from 'lucide-react';
import Image from 'next/image';

interface CocktailsSectionProps {
  onAddCocktailKit: (recipeName: string, price: number) => void;
}

export default function CocktailsSection({ onAddCocktailKit }: CocktailsSectionProps) {
  const [selectedRecipe, setSelectedRecipe] = useState<CocktailRecipe>(COCKTAILS[0]);
  const [addedKitId, setAddedKitId] = useState<string | null>(null);

  const handleAddKit = (recipe: CocktailRecipe) => {
    onAddCocktailKit(`${recipe.name} Cocktail Kit (Includes 700ml Bottle & Artisanal Mixers)`, 75.00);
    setAddedKitId(recipe.id);
    setTimeout(() => setAddedKitId(null), 2000);
  };

  return (
    <section id="cocktails" className="py-20 bg-[#050b14] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-xs font-bold tracking-[0.25em] text-[#d4af37] uppercase block">
            ROYAL NAVY MIXOLOGY
          </span>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-[#f5ebd7]">
            COCKTAIL RECIPES & SERVES
          </h2>
          <p className="font-cormorant text-xl text-slate-300 italic">
            Bold drinks for bold spirits. Discover signature serves crafted to accentuate 57% ABV Overproof Navy Rum.
          </p>
        </div>

        {/* Cocktails Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Recipe List Buttons Left */}
          <div className="lg:col-span-5 space-y-4">
            {COCKTAILS.map((recipe) => (
              <div
                key={recipe.id}
                onClick={() => setSelectedRecipe(recipe)}
                className={`p-6 rounded-2xl border transition-all cursor-pointer flex items-center gap-5 ${
                  selectedRecipe.id === recipe.id
                    ? 'bg-[#0c1a2e] border-[#d4af37] shadow-xl shadow-[#d4af37]/10'
                    : 'bg-[#07111e]/60 border-white/10 hover:border-[#d4af37]/40'
                }`}
              >
                <div className="relative w-20 h-20 rounded-xl overflow-hidden shrink-0 border border-[#d4af37]/30">
                  <Image
                    src={recipe.image}
                    alt={recipe.name}
                    fill
                    className="object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="flex-1">
                  <span className="text-[10px] font-mono text-[#d4af37] uppercase font-bold tracking-widest block">
                    {recipe.difficulty}
                  </span>
                  <h3 className="font-cinzel text-lg font-bold text-white">
                    {recipe.name}
                  </h3>
                  <p className="text-xs text-slate-300 mt-0.5 line-clamp-1">
                    {recipe.subtitle}
                  </p>
                </div>

                <ChevronRight className={`w-5 h-5 transition-transform ${
                  selectedRecipe.id === recipe.id ? 'text-[#d4af37] translate-x-1' : 'text-slate-500'
                }`} />
              </div>
            ))}
          </div>

          {/* Recipe Detailed Showcase Right */}
          <div className="lg:col-span-7 bg-[#091424] border border-[#d4af37]/30 rounded-2xl p-6 sm:p-8 space-y-6 shadow-2xl">
            
            <div className="relative aspect-[16/9] rounded-xl overflow-hidden border border-[#d4af37]/20">
              <Image
                src={selectedRecipe.image}
                alt={selectedRecipe.name}
                fill
                className="object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#091424] via-transparent to-transparent opacity-80" />

              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-slate-200">
                <div className="flex items-center gap-2 bg-[#050b14]/80 px-3 py-1.5 rounded-lg border border-[#d4af37]/40">
                  <Clock className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>{selectedRecipe.prepTime}</span>
                </div>
                <div className="flex items-center gap-2 bg-[#050b14]/80 px-3 py-1.5 rounded-lg border border-[#d4af37]/40">
                  <Wine className="w-3.5 h-3.5 text-[#d4af37]" />
                  <span>{selectedRecipe.glassware}</span>
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-cinzel text-2xl font-bold text-white">
                {selectedRecipe.name}
              </h3>
              <p className="text-xs font-semibold text-[#d4af37] mt-1">
                Base Spirit: {selectedRecipe.spiritUsed}
              </p>
            </div>

            {/* Ingredients */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#d4af37] mb-3">
                INGREDIENTS
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-sans">
                {selectedRecipe.ingredients.map((ing, idx) => (
                  <div key={idx} className="p-2.5 rounded-lg bg-[#050b14] border border-white/5 flex items-center justify-between">
                    <span className="font-medium text-slate-200">{ing.name}</span>
                    <span className="font-mono text-[#d4af37] font-bold">{ing.amount}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Preparation Steps */}
            <div>
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#d4af37] mb-3">
                PREPARATION METHOD
              </h4>
              <ol className="space-y-2 text-xs text-slate-300 font-sans list-decimal list-inside leading-relaxed">
                {selectedRecipe.instructions.map((step, idx) => (
                  <li key={idx} className="bg-[#050b14]/50 p-2.5 rounded-lg border border-white/5">
                    {step}
                  </li>
                ))}
              </ol>
            </div>

            {/* Pro Tip */}
            <div className="p-4 rounded-xl bg-[#d4af37]/10 border border-[#d4af37]/30 text-xs text-[#d4af37] flex items-start gap-3">
              <Sparkles className="w-5 h-5 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold uppercase block mb-0.5">MIXOLOGIST PRO TIP:</span>
                <p className="text-slate-300 italic">{selectedRecipe.proTip}</p>
              </div>
            </div>

            {/* Add Cocktail Kit Button */}
            <button
              onClick={() => handleAddKit(selectedRecipe)}
              className="w-full py-3.5 bg-[#d4af37] hover:bg-[#e5c158] text-black font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 gold-glow"
            >
              {addedKitId === selectedRecipe.id ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>COCKTAIL KIT ADDED TO BAG! (£75.00)</span>
                </>
              ) : (
                <span>ORDER COMPLETE COCKTAIL KIT (£75.00)</span>
              )}
            </button>

          </div>

        </div>

      </div>
    </section>
  );
}
