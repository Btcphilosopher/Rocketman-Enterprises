'use client';

import React, { useState } from 'react';
import { Building2, Send, CheckCircle2, ShieldCheck, FileText } from 'lucide-react';

export default function TradePortal() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    businessName: '',
    contactName: '',
    email: '',
    businessType: 'Cocktail Bar / Speakeasy',
    country: 'United Kingdom',
    estimatedCases: '10 - 25 Cases / Month',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="trade" className="py-20 bg-[#050b14] border-t border-[#d4af37]/30 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#d4af37]/40 bg-[#d4af37]/10 text-[#d4af37] text-xs font-semibold tracking-widest uppercase">
            <Building2 className="w-4 h-4" />
            <span>TRADE & WHOLESALE ACCOUNTS</span>
          </div>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-extrabold text-[#f5ebd7]">
            DISTRIBUTION & TRADE PORTAL
          </h2>
          <p className="font-cormorant text-xl text-slate-300 italic">
            Direct tax-bonded shipping for bars, restaurants, hotel groups, and global duty-free distributors.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Trade Specs Left */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-[#091322] border border-[#d4af37]/30 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
              <h3 className="font-cinzel text-2xl font-bold text-white">
                B2B Trade Terms
              </h3>

              <div className="space-y-4 text-xs font-sans text-slate-300">
                <div className="p-4 rounded-xl bg-[#050b14] border border-white/5 flex items-start gap-3">
                  <ShieldCheck className="w-5 h-5 text-[#d4af37] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white block mb-0.5">Bonded Warehouse Shipping</span>
                    <p className="text-slate-400">Shipped under bond from UK Excise Warehouse #4. EX1 / SAD clearance documents supplied.</p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#050b14] border border-white/5 flex items-start gap-3">
                  <FileText className="w-5 h-5 text-[#d4af37] shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-white block mb-0.5">Complementary Sample Kits</span>
                    <p className="text-slate-400">Qualified high-volume accounts receive 3x 100ml trade sample flasks upon verified excise registration.</p>
                  </div>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-[#d4af37]/10 border border-[#d4af37]/30 text-xs text-[#d4af37]">
                <span className="font-bold uppercase block mb-1">Direct Trade Desk Contact</span>
                <span className="font-mono block text-white font-bold">trade@navystrengthspirits.co.uk</span>
                <span className="font-mono text-slate-300">+44 (0) 20 7946 0918</span>
              </div>
            </div>
          </div>

          {/* Form Right */}
          <div className="lg:col-span-7 bg-[#091322] border border-[#d4af37]/30 rounded-2xl p-6 sm:p-8 shadow-2xl">
            {submitted ? (
              <div className="py-12 text-center space-y-4">
                <CheckCircle2 className="w-16 h-16 text-emerald-400 mx-auto" />
                <h3 className="font-cinzel text-2xl font-bold text-white">
                  TRADE INQUIRY RECEIVED
                </h3>
                <p className="text-xs text-slate-300 max-w-md mx-auto leading-relaxed">
                  Thank you for contacting Navy Strength Spirits Co. Our Trade Director will review your excise details and respond within 24 business hours with custom pricing.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-6 py-2.5 bg-[#d4af37] text-black font-bold text-xs uppercase rounded-lg hover:bg-[#e5c158]"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <h3 className="font-cinzel text-xl font-bold text-white">
                  Request Trade Account & Sample Flasks
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-bold uppercase text-[#d4af37] block mb-1.5">
                      Business Name
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.businessName}
                      onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                      className="w-full bg-[#050b14] border border-[#d4af37]/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-[#d4af37]"
                      placeholder="e.g. The Admiralty Bar Ltd"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase text-[#d4af37] block mb-1.5">
                      Contact Name
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.contactName}
                      onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                      className="w-full bg-[#050b14] border border-[#d4af37]/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-[#d4af37]"
                      placeholder="e.g. Lord Charles Nelson"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] font-bold uppercase text-[#d4af37] block mb-1.5">
                      Work Email Address
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full bg-[#050b14] border border-[#d4af37]/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-[#d4af37]"
                      placeholder="e.g. buyer@admiraltybar.co.uk"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold uppercase text-[#d4af37] block mb-1.5">
                      Estimated Monthly Volume
                    </label>
                    <select
                      value={formData.estimatedCases}
                      onChange={(e) => setFormData({ ...formData, estimatedCases: e.target.value })}
                      className="w-full bg-[#050b14] border border-[#d4af37]/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-[#d4af37]"
                    >
                      <option>10 - 25 Cases / Month</option>
                      <option>25 - 100 Cases / Month</option>
                      <option>100+ Pallet Orders</option>
                      <option>Duty-Free & Airport Retail</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold uppercase text-[#d4af37] block mb-1.5">
                    Specific Order Requirements or Excise Notes
                  </label>
                  <textarea
                    rows={3}
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    className="w-full bg-[#050b14] border border-[#d4af37]/30 rounded-xl px-4 py-2.5 text-xs text-slate-100 focus:outline-none focus:border-[#d4af37]"
                    placeholder="Provide AWRS excise number, delivery postcode, or sample request details..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 bg-[#d4af37] hover:bg-[#e5c158] text-black font-extrabold text-xs uppercase tracking-widest rounded-xl transition-all flex items-center justify-center gap-2 gold-glow"
                >
                  <Send className="w-4 h-4" />
                  <span>SUBMIT TRADE INQUIRY</span>
                </button>
              </form>
            )}
          </div>

        </div>

      </div>
    </section>
  );
}
