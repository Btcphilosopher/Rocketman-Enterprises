'use client';

import React from 'react';
import { ChevronRight, ShieldCheck, Flame, Compass, Award } from 'lucide-react';
import Image from 'next/image';

interface HeroProps {
  onDiscoverClick: () => void;
  onOpenProofCalc: () => void;
}

export default function Hero({ onDiscoverClick, onOpenProofCalc }: HeroProps) {
  return (
    <section id="hero" className="relative min-h-[85vh] flex items-center justify-center overflow-hidden bg-[#050b14] pt-8 pb-16">
      {/* Background Atmosphere & Radial Glows */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-[#132742] via-[#071324] to-[#03070d] opacity-90" />
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-[#d4af37]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-[#2a4365]/20 rounded-full blur-3xl pointer-events-none" />

      {/* Hero Content Grid */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Headline & Call To Action */}
          <div className="lg:col-span-6 space-y-6 text-left">
            
            {/* Kicker Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border border-[#d4af37]/30 bg-[#d4af37]/10 text-[#d4af37] text-xs font-semibold tracking-widest uppercase">
              <Award className="w-4 h-4 text-[#d4af37]" />
              <span>OFFICIAL ADMIRALTY SPECIFICATION</span>
            </div>

            {/* Main Title */}
            <h1 className="font-cinzel text-4xl sm:text-6xl xl:text-7xl font-extrabold tracking-tight text-[#f8f1e5] leading-[1.08] text-balance">
              BRITISH <br />
              <span className="gold-gradient-text drop-shadow-sm">NAVY RUM</span>
            </h1>

            {/* Subtitle */}
            <div className="text-xs sm:text-sm font-semibold tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-3">
              <span>TRADITION</span>
              <span>•</span>
              <span>STRENGTH</span>
              <span>•</span>
              <span>EXCELLENCE</span>
            </div>

            {/* Description Prose */}
            <p className="font-cormorant text-lg sm:text-2xl text-slate-300 italic max-w-xl leading-relaxed">
              &quot;Overproof. Uncompromising. British.&quot;<br />
              <span className="not-italic text-sm sm:text-base font-sans text-slate-300 font-normal mt-2 block">
                Our Navy Rum is crafted for those who demand more — with a rich heritage, copper pot still distillation, and a legendary strength.
              </span>
            </p>

            {/* CTA Buttons */}
            <div className="pt-4 flex flex-wrap items-center gap-4">
              <button
                onClick={onDiscoverClick}
                className="group relative inline-flex items-center justify-between gap-4 px-8 py-4 bg-gradient-to-r from-[#d4af37] to-[#b8860b] text-[#050b14] font-bold text-xs sm:text-sm tracking-widest uppercase rounded-md transition-all duration-300 hover:scale-[1.02] shadow-xl hover:shadow-[#d4af37]/30"
              >
                <span>DISCOVER OUR NAVY RUM</span>
                <ChevronRight className="w-4 h-4 text-[#050b14] group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onOpenProofCalc}
                className="inline-flex items-center gap-2 px-6 py-4 border border-[#d4af37]/40 bg-[#071324]/60 text-[#f5ebd7] hover:text-[#d4af37] hover:border-[#d4af37] text-xs sm:text-sm font-semibold tracking-wider uppercase rounded-md transition-all hover:bg-[#d4af37]/10"
              >
                <Flame className="w-4 h-4 text-[#d4af37]" />
                <span>GUNPOWDER TEST</span>
              </button>
            </div>

            {/* Proof Badges */}
            <div className="pt-6 border-t border-white/10 flex items-center gap-8 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
                <span className="font-medium text-slate-200">57% ABV / 100° UK Proof</span>
              </div>
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#d4af37]" />
                <span className="font-medium text-slate-200">Copper Pot Still Blend</span>
              </div>
            </div>

          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-2xl p-2 bg-gradient-to-b from-[#d4af37]/30 via-[#d4af37]/10 to-transparent gold-border-glow overflow-hidden">
              <div className="relative aspect-[4/3] rounded-xl overflow-hidden bg-[#071324]">
                <Image
                  src="/assets/aistudio/Navy_Rum_852cb1fd.png"
                  alt="British Navy Rum Overproof Bottle & Glass"
                  fill
                  priority
                  className="object-cover object-center transform hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#050b14] via-transparent to-transparent opacity-60" />

                {/* Floating Bottle Badge Overlay */}
                <div className="absolute bottom-4 left-4 right-4 bg-[#0a182d]/90 backdrop-blur-md p-4 rounded-xl border border-[#d4af37]/40 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold uppercase tracking-widest text-[#d4af37] block">
                      OFFICIAL FLAGSHIP
                    </span>
                    <h3 className="font-cinzel text-base font-bold text-white">
                      NAVY RUM OVERPROOF 57%
                    </h3>
                  </div>
                  <span className="font-mono text-xl font-extrabold text-[#d4af37]">
                    £58.00
                  </span>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
