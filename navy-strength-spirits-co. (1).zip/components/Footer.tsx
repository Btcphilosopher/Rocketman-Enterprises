'use client';

import React from 'react';
import { Crown, Code2, ShieldCheck, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onOpenPhpInspector: () => void;
}

export default function Footer({ onNavigate, onOpenPhpInspector }: FooterProps) {
  return (
    <footer className="bg-[#03070d] text-slate-400 text-xs border-t border-[#d4af37]/30 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#d4af37]/10 border border-[#d4af37]/40 flex items-center justify-center text-[#d4af37]">
                <Crown className="w-6 h-6" />
              </div>
              <div>
                <span className="font-cinzel text-xl font-extrabold tracking-widest text-[#f5ebd7] block">
                  NAVY STRENGTH
                </span>
                <span className="text-[10px] tracking-[0.25em] text-[#d4af37] font-semibold uppercase">
                  SPIRITS CO. • BRITISH
                </span>
              </div>
            </div>

            <p className="font-cormorant text-base text-slate-300 italic max-w-sm leading-relaxed">
              &quot;Overproof. Uncompromising. British. Crafted according to authentic Admiralty specifications since the age of sail.&quot;
            </p>

            <div className="pt-2">
              <button
                onClick={onOpenPhpInspector}
                className="inline-flex items-center gap-2 px-3 py-1.5 bg-[#d4af37]/10 border border-[#d4af37]/40 text-[#d4af37] font-mono text-xs rounded-lg hover:bg-[#d4af37]/20 transition-all"
              >
                <Code2 className="w-4 h-4" />
                <span>View PHP 8.3 Backend Source</span>
              </button>
            </div>
          </div>

          {/* Quick Nav Col */}
          <div className="space-y-3">
            <span className="text-xs font-bold font-cinzel tracking-widest text-[#d4af37] uppercase block">
              OUR RANGE
            </span>
            <ul className="space-y-2 font-medium">
              <li><button onClick={() => onNavigate('spirits')} className="hover:text-white transition-colors">Navy Rum 57% ABV</button></li>
              <li><button onClick={() => onNavigate('spirits')} className="hover:text-white transition-colors">Gunpowder Proof 68.5%</button></li>
              <li><button onClick={() => onNavigate('spirits')} className="hover:text-white transition-colors">Royal Navy Overproof Vodka</button></li>
              <li><button onClick={() => onNavigate('spirits')} className="hover:text-white transition-colors">12-Yr Solera Cask Reserve</button></li>
            </ul>
          </div>

          {/* Heritage Col */}
          <div className="space-y-3">
            <span className="text-xs font-bold font-cinzel tracking-widest text-[#d4af37] uppercase block">
              HERITAGE & TRADE
            </span>
            <ul className="space-y-2 font-medium">
              <li><button onClick={() => onNavigate('heritage')} className="hover:text-white transition-colors">1655 Daily Ration</button></li>
              <li><button onClick={() => onNavigate('cocktails')} className="hover:text-white transition-colors">Cocktails & Serves</button></li>
              <li><button onClick={() => onNavigate('proof-calculator')} className="hover:text-white transition-colors">Proof Calculator</button></li>
              <li><button onClick={() => onNavigate('trade')} className="hover:text-white transition-colors">Tax Bonded Trade Portal</button></li>
            </ul>
          </div>

          {/* Excise & Warehouse Col */}
          <div className="space-y-3">
            <span className="text-xs font-bold font-cinzel tracking-widest text-[#d4af37] uppercase block">
              TAX BONDED VAULT
            </span>
            <div className="space-y-2 text-[11px] text-slate-400 font-mono">
              <div>Portsmouth Excise Vault #4</div>
              <div>HM Revenue & Customs AWRS: XKAW0000010982</div>
              <div>UK Duty Paid & Export Bonded</div>
            </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            © {new Date().getFullYear()} Navy Strength Spirits Co. All rights reserved.
          </div>

          <div className="flex items-center gap-4">
            <span>DrinkAware.co.uk (18+)</span>
            <span>·</span>
            <span>Terms & Conditions</span>
            <span>·</span>
            <span>Privacy Policy</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
