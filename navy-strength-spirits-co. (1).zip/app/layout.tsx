import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Navy Strength Spirits Co. | British Navy Rum 57% ABV',
  description: 'British Navy Rum — Overproof. Uncompromising. British. Crafted for those who demand legendary strength and rich naval heritage.',
  openGraph: {
    title: 'Navy Strength Spirits Co. | British Navy Rum 57% ABV',
    description: 'Overproof. Uncompromising. British. Our Navy Rum is crafted for those who demand more — with a rich heritage and a legendary strength.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Navy Strength Spirits Co. | British Navy Rum 57% ABV',
    description: 'British Navy Rum — Overproof. Uncompromising. British.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-[#050b14] text-slate-200 antialiased selection:bg-[#d4af37] selection:text-black" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
