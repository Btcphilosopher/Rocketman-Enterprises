'use client';

import React, { useState } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import FeatureBar from '@/components/FeatureBar';
import LowerCards from '@/components/LowerCards';
import SpiritsCatalog from '@/components/SpiritsCatalog';
import RumBlendCustomizer from '@/components/RumBlendCustomizer';
import CocktailsSection from '@/components/CocktailsSection';
import HeritageTimeline from '@/components/HeritageTimeline';
import TradePortal from '@/components/TradePortal';
import Footer from '@/components/Footer';

import AgeVerificationModal from '@/components/AgeVerificationModal';
import CartDrawer, { CartItem } from '@/components/CartDrawer';
import PhpInspectorModal from '@/components/PhpInspectorModal';
import { Product, PRODUCTS } from '@/lib/data';

export default function Home() {
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: PRODUCTS[0].id,
      name: PRODUCTS[0].name,
      unitPriceGBP: PRODUCTS[0].priceGBP,
      quantity: 1,
      abv: PRODUCTS[0].abv
    }
  ]);

  const [currency, setCurrency] = useState<'GBP' | 'USD' | 'EUR'>('GBP');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isPhpInspectorOpen, setIsPhpInspectorOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  const totalCartCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [
        ...prev,
        {
          id: product.id,
          name: product.name,
          unitPriceGBP: product.priceGBP,
          quantity: 1,
          abv: product.abv
        }
      ];
    });
    setIsCartOpen(true);
  };

  const handleAddCustomBlend = (blendName: string, abv: number, priceGBP: number) => {
    const customId = 'custom-' + Date.now();
    setCartItems((prev) => [
      ...prev,
      {
        id: customId,
        name: blendName,
        unitPriceGBP: priceGBP,
        quantity: 1,
        abv: `${abv.toFixed(1)}% ABV`
      }
    ]);
    setIsCartOpen(true);
  };

  const handleAddCocktailKit = (kitName: string, priceGBP: number) => {
    const kitId = 'kit-' + Date.now();
    setCartItems((prev) => [
      ...prev,
      {
        id: kitId,
        name: kitName,
        unitPriceGBP: priceGBP,
        quantity: 1,
        abv: 'Complete Kit'
      }
    ]);
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <main className="min-h-screen bg-[#050b14] text-slate-100 flex flex-col justify-between selection:bg-[#d4af37] selection:text-black">
      {/* Legal Age Check Gate */}
      <AgeVerificationModal />

      {/* Main Top Navigation Bar */}
      <Navbar
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenPhpInspector={() => setIsPhpInspectorOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      {/* Hero Section */}
      <Hero
        onDiscoverClick={() => scrollToSection('spirits')}
        onOpenProofCalc={() => scrollToSection('proof-calculator')}
      />

      {/* Feature Pillars Bar */}
      <FeatureBar />

      {/* 4-Card Highlight Grid */}
      <LowerCards
        onNavigate={scrollToSection}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Complete Product Spirits Catalog */}
      <SpiritsCatalog
        currency={currency}
        setCurrency={setCurrency}
        onAddToCart={handleAddToCart}
      />

      {/* Bespoke Proof & Hydrometer Calculator */}
      <RumBlendCustomizer onOrderCustomBlend={handleAddCustomBlend} />

      {/* Cocktail Recipes & Serves */}
      <CocktailsSection onAddCocktailKit={handleAddCocktailKit} />

      {/* Heritage Timeline */}
      <HeritageTimeline />

      {/* B2B Trade & Wholesale Portal */}
      <TradePortal />

      {/* Footer */}
      <Footer
        onNavigate={scrollToSection}
        onOpenPhpInspector={() => setIsPhpInspectorOpen(true)}
      />

      {/* Shopping Bag Sliding Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        currency={currency}
      />

      {/* Interactive PHP Source Code & API Inspector Modal */}
      <PhpInspectorModal
        isOpen={isPhpInspectorOpen}
        onClose={() => setIsPhpInspectorOpen(false)}
      />
    </main>
  );
}
