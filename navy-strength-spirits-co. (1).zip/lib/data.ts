export interface Product {
  id: string;
  name: string;
  subTitle: string;
  category: 'rum' | 'vodka' | 'limited' | 'gift';
  abv: string;
  abvValue: number;
  volume: string;
  priceGBP: number;
  priceUSD: number;
  priceEUR: number;
  description: string;
  image: string;
  badge?: string;
  tastingNotes: {
    nose: string;
    palate: string;
    finish: string;
  };
  inStock: boolean;
  rating: number;
  reviewsCount: number;
}

export interface CocktailRecipe {
  id: string;
  name: string;
  subtitle: string;
  prepTime: string;
  glassware: string;
  garnish: string;
  difficulty: 'Easy' | 'Intermediate' | 'Master Mixologist';
  spiritUsed: string;
  image: string;
  ingredients: { amount: string; name: string }[];
  instructions: string[];
  proTip: string;
}

export interface HeritageMilestone {
  year: string;
  title: string;
  subtitle: string;
  description: string;
  location: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'navy-rum-overproof-57',
    name: 'British Navy Rum Overproof',
    subTitle: 'The Signature Flagship · 57% ABV (100° English Proof)',
    category: 'rum',
    abv: '57.0% ABV',
    abvValue: 57.0,
    volume: '700ml',
    priceGBP: 58.00,
    priceUSD: 74.00,
    priceEUR: 68.00,
    description: 'Crafted according to historic Admiralty specifications. A master blend of heavy Guyana pot still, Trinidad column, and Barbados copper aged rums. Overproof, uncompromising, and deeply complex.',
    image: '/assets/aistudio/Navy_Rum_852cb1fd.png',
    badge: 'FLAGSHIP EDITION',
    tastingNotes: {
      nose: 'Rich Demerara molasses, dark espresso bean, burnt orange peel, toasted oak, and a hint of maritime brine.',
      palate: 'Full-bodied explosion of dark chocolate, spiced raisin, cinnamon bark, charred pipe tobacco, and salted caramel.',
      finish: 'Long, warming, and remarkably smooth for 57% ABV, with lingering cocoa and toasted cedar notes.'
    },
    inStock: true,
    rating: 4.9,
    reviewsCount: 342
  },
  {
    id: 'gunpowder-proof-68',
    name: 'Gunpowder Proof Admiralty Reserve',
    subTitle: 'Limited Cask Strength · 68.5% ABV',
    category: 'limited',
    abv: '68.5% ABV',
    abvValue: 68.5,
    volume: '700ml',
    priceGBP: 88.00,
    priceUSD: 112.00,
    priceEUR: 102.00,
    description: 'The highest proof distilled in our copper stills. Passes the historic Royal Navy gunpowder test: when mixed with black powder, it ignites instantly.',
    image: '/assets/aistudio/Navy_Rum_852cb1fd.png',
    badge: 'LIMITED RUN · 1,805 BOTTLES',
    tastingNotes: {
      nose: 'Intense caramelized fig, smoked clove, toasted vanilla bean, and polished antique mahogany.',
      palate: 'Viscous, fiery yet velvet warmth, rich prune liqueur, cracked black pepper, and dark treacle.',
      finish: 'Immense persistence, leave notes of charred oak barrel, dark berries, and roasted nutmeg.'
    },
    inStock: true,
    rating: 5.0,
    reviewsCount: 189
  },
  {
    id: 'royal-navy-overproof-vodka',
    name: 'Royal Navy Overproof Vodka',
    subTitle: 'Quadruple Distilled Botanical Spirit · 57% ABV',
    category: 'vodka',
    abv: '57.0% ABV',
    abvValue: 57.0,
    volume: '700ml',
    priceGBP: 52.00,
    priceUSD: 66.00,
    priceEUR: 61.00,
    description: 'Distilled 4x from English winter wheat and filtered through Arctic birch charcoal. Pure, crystal clear, and bottled at true Navy Strength for crisp cocktails.',
    image: '/src/assets/images/gold_bottle_overproof_vodka_1793607518819.jpg',
    badge: 'NEW RELEASE',
    tastingNotes: {
      nose: 'Subtle sweet grain, crisp alpine air, faint lemon verbena, and crushed mineral rock.',
      palate: 'Silky texture, pristine neutrality with subtle hints of sweet wheat, cracked white pepper, and citrus oil.',
      finish: 'Clean, razor-sharp, zero harsh burn, leaving a refreshing warmth on the palate.'
    },
    inStock: true,
    rating: 4.8,
    reviewsCount: 116
  },
  {
    id: 'cask-reserve-12yr',
    name: '12-Year Admiralty Solera Reserve',
    subTitle: 'Extra Old Guyana & Barbados Blend · 46% ABV',
    category: 'rum',
    abv: '46.0% ABV',
    abvValue: 46.0,
    volume: '700ml',
    priceGBP: 95.00,
    priceUSD: 122.00,
    priceEUR: 110.00,
    description: 'Matured for 12 years in heavily charred ex-bourbon white oak barrels in tropical climates before finishing in Oloroso sherry casks.',
    image: '/assets/aistudio/Navy_Rum_852cb1fd.png',
    badge: 'MASTER DISTILLER SELECTION',
    tastingNotes: {
      nose: 'Dried sultanas, roasted macadamia nuts, leather ledger books, and sweet marzipan.',
      palate: 'Silky velvet layers of honeycomb, toasted coconut, dark plum jam, and dark wood tannins.',
      finish: 'Decadent sherry sweetness tapering into dry, dignified oak warmth.'
    },
    inStock: true,
    rating: 4.95,
    reviewsCount: 204
  },
  {
    id: 'mini-tasting-trio',
    name: 'Officer\'s Mess Tasting Collection',
    subTitle: '3x 100ml Miniature Flasks in Wooden Gift Box',
    category: 'gift',
    abv: '57.0% ABV',
    abvValue: 57.0,
    volume: '3x 100ml',
    priceGBP: 42.00,
    priceUSD: 54.00,
    priceEUR: 49.00,
    description: 'The complete Navy Strength range in handcrafted wax-sealed glass flasks, housed in a laser-engraved solid mahogany presentation chest.',
    image: '/src/assets/images/distillery_oak_casks_1793607518321.jpg',
    badge: 'LUXURY GIFT SET',
    tastingNotes: {
      nose: 'Varied flight exploring Overproof Rum, Gunpowder Proof, and Overproof Vodka.',
      palate: 'A guided journey through 3 centuries of British naval distilling excellence.',
      finish: 'Includes official tasting compass and wax seal opener.'
    },
    inStock: true,
    rating: 4.9,
    reviewsCount: 88
  }
];

export const COCKTAILS: CocktailRecipe[] = [
  {
    id: 'black-tot-dark-and-stormy',
    name: 'The Admiral\'s Dark & Stormy',
    subtitle: 'The Ultimate Overproof Highball',
    prepTime: '3 Mins',
    glassware: 'Highball or Crystal Tumbler',
    garnish: 'Fresh Lime Wheel & Candied Ginger',
    difficulty: 'Easy',
    spiritUsed: 'British Navy Rum Overproof (57% ABV)',
    image: '/src/assets/images/cocktail_dark_and_stormy_1793607517765.jpg',
    ingredients: [
      { amount: '60 ml', name: 'British Navy Rum Overproof (57% ABV)' },
      { amount: '120 ml', name: 'Artisanal Fiery Ginger Beer' },
      { amount: '15 ml', name: 'Freshly Squeezed Lime Juice' },
      { amount: '2 Dashes', name: 'Angostura Aromatic Bitters' },
      { amount: 'Garnish', name: 'Dehydrated Lime Wheel & Mint Sprig' }
    ],
    instructions: [
      'Fill a heavy crystal tumbler with large hand-cut ice cubes.',
      'Pour in 120ml of premium chilled fiery ginger beer and 15ml lime juice.',
      'Slowly float 60ml of British Navy Rum Overproof over the back of a bar spoon to form a dramatic dark storm layer.',
      'Top with 2 dashes of Angostura bitters and garnish with a fresh lime wheel.'
    ],
    proTip: 'Do not stir before serving! Let the guest watch the dark navy rum slowly cascade into the golden ginger beer.'
  },
  {
    id: 'grog-1740-classic',
    name: 'Classic Grog 1740',
    subtitle: 'Admiral Edward "Old Grog" Vernon\'s Historic Punch',
    prepTime: '5 Mins',
    glassware: 'Copper Tankard or Pewter Mug',
    garnish: 'Grated Nutmeg & Cinnamon Stick',
    difficulty: 'Intermediate',
    spiritUsed: 'British Navy Rum Overproof (57% ABV)',
    image: '/src/assets/images/sailor_deck_heritage_1793607519608.jpg',
    ingredients: [
      { amount: '50 ml', name: 'British Navy Rum Overproof' },
      { amount: '100 ml', name: 'Warm Spring Water (or Chilled for Summer Grog)' },
      { amount: '20 ml', name: 'Raw Lime Juice (Scurvy Prevention)' },
      { amount: '15 ml', name: 'Demerara Sugar Syrup' },
      { amount: '1 Pinch', name: 'Freshly Grated Nutmeg' }
    ],
    instructions: [
      'Dissolve Demerara sugar syrup into warm spring water in a copper tankard.',
      'Stir in fresh lime juice to activate the citrus oils.',
      'Add 50ml of British Navy Rum Overproof and stir briskly.',
      'Garnish generously with freshly grated nutmeg and a charred cinnamon quill.'
    ],
    proTip: 'In 1740, Admiral Vernon ordered rum to be diluted with water and lime to keep sailors vigilant and healthy on long voyages.'
  },
  {
    id: 'gunpowder-mai-tai',
    name: 'Gunpowder Royal Mai Tai',
    subtitle: 'Overproof Tropical Complexity',
    prepTime: '4 Mins',
    glassware: 'Rocks Glass with Crushed Ice',
    garnish: 'Spent Lime Shell & Fresh Mint Crown',
    difficulty: 'Master Mixologist',
    spiritUsed: 'Gunpowder Proof Rum (68.5% ABV)',
    image: '/src/assets/images/cocktail_dark_and_stormy_1793607517765.jpg',
    ingredients: [
      { amount: '45 ml', name: 'Gunpowder Proof Admiralty Reserve' },
      { amount: '15 ml', name: 'Pierre Ferrand Dry Curaçao' },
      { amount: '20 ml', name: 'Fresh Lime Juice' },
      { amount: '15 ml', name: 'House Made Orgeat (Almond Syrup)' },
      { amount: '7.5 ml', name: 'Rich Demerara Syrup' }
    ],
    instructions: [
      'Combine all ingredients into a heavy shaker filled with crushed ice.',
      'Shake vigorously for 10 seconds until frosted on the outside.',
      'Unstrained, dump all contents into a chilled rocks glass.',
      'Float the spent lime half upside-down and place a sprig of mint inside to resemble a tropical island.'
    ],
    proTip: 'The 68.5% ABV Gunpowder proof cuts right through the almond and citrus sweetness for unmatched depth.'
  }
];

export const HERITAGE_MILESTONES: HeritageMilestone[] = [
  {
    year: '1655',
    title: 'The Royal Navy Daily Tot Introduced',
    subtitle: 'Jamaica Campaign',
    description: 'Vice-Admiral William Penn captures Jamaica and replaces the daily sailor ration of French brandy and sour beer with half a pint of high-proof Caribbean rum.',
    location: 'Port Royal, Jamaica'
  },
  {
    year: '1740',
    title: 'Admiral Vernon Orders "Grog"',
    subtitle: 'Order No. 349',
    description: 'To curb drunkenness aboard HMS Burford, Admiral Edward Vernon ("Old Grog") commands that rum be mixed with four parts water and lime juice, giving birth to the iconic Grog.',
    location: 'Royal Navy Admiralty, London'
  },
  {
    year: '1805',
    title: 'Nelson\'s Blood at Trafalgar',
    subtitle: 'Battle of Trafalgar',
    description: 'After Vice-Admiral Lord Nelson is slain at Trafalgar, his body is preserved in a barrel of overproof Navy Spirit for the voyage home, giving rise to the name "Nelson\'s Blood".',
    location: 'Cape Trafalgar & HMS Victory'
  },
  {
    year: '1970',
    title: 'Black Tot Day',
    subtitle: '31st July 1970 at 6 Bells in the Forenoon',
    description: 'The British Admiralty officially ends the 315-year tradition of issuing daily rum rations to sailors. The final tot is poured in solemn ceremony across the fleet.',
    location: 'Portsmouth Royal Dockyard'
  },
  {
    year: '2026',
    title: 'Navy Strength Spirits Co. Revival',
    subtitle: 'Authentic Admiralty Craft',
    description: 'Re-creating the legendary 57% ABV Overproof Navy Rum using historic copper pot stills, original Caribbean distillates, and traditional Solera oak aging.',
    location: 'London & Bristol, United Kingdom'
  }
];

export const PHP_CODE_SNIPPETS = [
  {
    filename: 'index.php',
    language: 'php',
    title: 'Front Controller & Storefront Bootstrap',
    code: `<?php
/**
 * Navy Strength Spirits Co. — Storefront Front Controller
 * PHP 8.3 Production Architecture
 */
declare(strict_types=1);

require_once __DIR__ . '/vendor/autoload.php';

use NavySpirits\\Catalog\\SpiritsCatalog;
use NavySpirits\\Cart\\CartSession;
use NavySpirits\\Security\\AgeVerification;

session_start();

// Enforce Age Gate (18+ / 21+)
if (!AgeVerification::isVerified()) {
    header('Location: /age-gate.php');
    exit();
}

$catalog = new SpiritsCatalog();
$cart = new CartSession($_SESSION['cart_id'] ?? null);

$featuredSpirits = $catalog->getFeaturedSpirits(limit: 4);
$currentCurrency = $_GET['currency'] ?? 'GBP';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Navy Strength Spirits Co. | British Navy Rum 57% ABV</title>
</head>
<body>
    <?php include __DIR__ . '/templates/header.php'; ?>
    <?php include __DIR__ . '/templates/hero.php'; ?>
    <?php include __DIR__ . '/templates/catalog_grid.php'; ?>
    <?php include __DIR__ . '/templates/footer.php'; ?>
</body>
</html>`
  },
  {
    filename: 'SpiritsCatalog.php',
    language: 'php',
    title: 'Catalog Domain Model & Hydrometer Math',
    code: `<?php
namespace NavySpirits\\Catalog;

readonly class SpiritItem
{
    public function __construct(
        public string $id,
        public string $name,
        public float $abvPercent,
        public float $priceGbp,
        public bool $inStock = true,
        public array $tastingNotes = []
    ) {}

    public function isOverproof(): bool
    {
        // Historic Navy Strength cutoff is 57.15% ABV (100° UK Proof)
        return $this->abvPercent >= 57.0;
    }

    public function calculateGunpowderIgnitionProbability(): float
    {
        if ($this->abvPercent < 57.0) {
            return 0.0; // Gunpowder dampens, will not ignite
        }
        return min(100.0, 50.0 + ($this->abvPercent - 57.0) * 4.35);
    }
}

class SpiritsCatalog
{
    private array $db;

    public function getFeaturedSpirits(int $limit = 4): array
    {
        return array_slice($this->getAllSpirits(), 0, $limit);
    }

    public function calculateProof(float $abv): float
    {
        // UK Proof = ABV % * 1.751
        return round($abv * 1.751, 1);
    }
}`
  },
  {
    filename: 'GunpowderCalculator.php',
    language: 'php',
    title: 'Admiralty Gunpowder Test Simulator',
    code: `<?php
namespace NavySpirits\\Proof;

class GunpowderCalculator
{
    public static function testProof(float $abvPercent): array
    {
        $proofUk = round($abvPercent * 1.751, 1);
        $proofUs = round($abvPercent * 2.0, 1);
        $ignites = $abvPercent >= 57.0;

        return [
            'abv' => $abvPercent,
            'uk_proof' => $proofUk,
            'us_proof' => $proofUs,
            'gunpowder_test' => $ignites ? 'PASSED (FLAMMABLE)' : 'FAILED (DAMPENED)',
            'status_message' => $ignites 
                ? "At {$abvPercent}% ABV, black powder saturated in this rum WILL ignite when sparked by flint!"
                : "At {$abvPercent}% ABV, excess water dampens the gunpowder. Ship purser failed the test!",
            'recommended_serving' => $abvPercent > 60.0 ? 'Neat with drop of spring water' : 'Over hand-cut ice'
        ];
    }
}`
  },
  {
    filename: 'api_orders.php',
    language: 'php',
    title: 'REST API Endpoint — Order Processing',
    code: `<?php
header('Content-Type: application/json');

use NavySpirits\\Orders\\OrderProcessor;

$input = json_decode(file_get_contents('php://input'), true);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit();
}

$order = [
    'order_id' => 'NSS-' . strtoupper(dechex(time())),
    'timestamp' => date('c'),
    'items' => $input['items'] ?? [],
    'total_gbp' => $input['total'] ?? 0.0,
    'status' => 'DISPATCH_QUEUED',
    'tax_warehouse' => 'Portsmouth Bonded Vault #4'
];

echo json_encode(['success' => true, 'data' => $order], JSON_PRETTY_PRINT);`
  }
];
