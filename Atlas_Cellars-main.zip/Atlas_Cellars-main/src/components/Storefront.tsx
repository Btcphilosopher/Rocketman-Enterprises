/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShoppingBag, Heart, Search, ArrowRight, Check, Sparkles, Send, 
  MapPin, Clock, CreditCard, Copy, CheckCircle, ShieldAlert,
  HelpCircle, Info, FileText, ChevronRight, MessageSquare, AlertCircle, RefreshCw
} from "lucide-react";
import { Product, ProductStatus, Order, OrderStatus, CryptoCurrency, SupportTicket } from "../types";

interface StorefrontProps {
  products: Product[];
  orders: Order[];
  supportTickets: SupportTicket[];
  settings: any;
  cart: { product: Product; quantity: number }[];
  wishlist: Product[];
  currentPath: string;
  onUpdateCart: (newCart: any[]) => void;
  onUpdateWishlist: (newWishlist: Product[]) => void;
  onPlaceOrder: (order: Order) => void;
  onNavigate: (path: string) => void;
  onAddTicket: (ticket: SupportTicket) => void;
}

export default function Storefront({
  products,
  orders,
  supportTickets,
  settings,
  cart,
  wishlist,
  currentPath,
  onUpdateCart,
  onUpdateWishlist,
  onPlaceOrder,
  onNavigate,
  onAddTicket
}: StorefrontProps) {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Filtering & Search state
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedCountry, setSelectedCountry] = useState<string>("All");
  const [selectedSort, setSelectedSort] = useState<string>("popular");

  // Gemini Curator chatbot state
  const [curatorMessages, setCuratorMessages] = useState<{ sender: "user" | "bot"; text: string }[]>([
    { sender: "bot", text: "Welcome to the Atlas Cellars Private Lounge. I am your personal Sommelier. Ask me anything about wine gastronomy, tasting profiles, or dinner pairings for our custom allocations." }
  ]);
  const [curatorInput, setCuratorInput] = useState("");
  const [isCuratorTyping, setIsCuratorTyping] = useState(false);

  // Checkout Form State
  const [checkoutStep, setCheckoutStep] = useState<"form" | "crypto_invoice">("form");
  const [guestEmail, setGuestEmail] = useState("");
  const [customerName, setCustomerName] = useState("");
  const [shippingStreet, setShippingStreet] = useState("");
  const [shippingCity, setShippingCity] = useState("");
  const [shippingState, setShippingState] = useState("");
  const [shippingZip, setShippingZip] = useState("");
  const [shippingCountry, setShippingCountry] = useState("United States");
  const [shippingPhone, setShippingPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"credit_card" | "crypto">("credit_card");
  const [cryptoCurrency, setCryptoCurrency] = useState<CryptoCurrency>(CryptoCurrency.BTC);
  const [usdtNetwork, setUsdtNetwork] = useState<"ERC-20" | "TRC-20" | "BSC">("TRC-20");
  const [promoCode, setPromoCode] = useState("");
  const [promoDiscount, setPromoDiscount] = useState(0);
  const [checkoutNotes, setCheckoutNotes] = useState("");
  const [placedOrderInfo, setPlacedOrderInfo] = useState<Order | null>(null);

  // Active Crypto Invoice States
  const [invoiceTimer, setInvoiceTimer] = useState("15:00");
  const [isReconcilingBlockchain, setIsReconcilingBlockchain] = useState(false);
  const [reconcileSuccess, setReconcileSuccess] = useState(false);

  // CRM Ticket Form State
  const [ticketSubject, setTicketSubject] = useState("");
  const [ticketCategory, setTicketCategory] = useState<any>("Product Inquiry");
  const [ticketMessage, setTicketMessage] = useState("");
  const [ticketCreatedSuccess, setTicketCreatedSuccess] = useState(false);

  // News letter state
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);

  // Filter products that are published
  const availableProducts = products.filter(p => p.status === ProductStatus.Published);

  // Unique list of categories and countries for filters
  const categories = ["All", ...Array.from(new Set(availableProducts.map(p => p.beverageType)))];
  const countries = ["All", ...Array.from(new Set(availableProducts.map(p => p.country)))];

  // Run countdown for crypto invoice
  useEffect(() => {
    if (checkoutStep !== "crypto_invoice" || !placedOrderInfo) return;

    let time = 900; // 15 mins in secs
    const interval = setInterval(() => {
      const minutes = Math.floor(time / 60);
      const seconds = time % 60;
      setInvoiceTimer(`${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`);
      
      if (time <= 0) {
        clearInterval(interval);
        setInvoiceTimer("Expired");
      }
      time--;
    }, 1000);

    return () => clearInterval(interval);
  }, [checkoutStep, placedOrderInfo]);

  // Handle Gemini Curator Inquiry
  const handleSendCuratorInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!curatorInput.trim()) return;

    const userText = curatorInput;
    setCuratorInput("");
    setCuratorMessages(prev => [...prev, { sender: "user", text: userText }]);
    setIsCuratorTyping(true);

    try {
      const response = await fetch("/api/gemini/curator", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText })
      });
      const data = await response.json();
      
      setCuratorMessages(prev => [...prev, { sender: "bot", text: data.text }]);
    } catch (error) {
      console.error("Curator API failed:", error);
      setCuratorMessages(prev => [...prev, { sender: "bot", text: "I apologize, my tasting room files appear briefly offline. However, of our fine wines, the Château Margaux 2015 is an unparalleled vintage of silky cassies." }]);
    } finally {
      setIsCuratorTyping(false);
    }
  };

  // Quick Cart updates
  const handleAddToCart = (product: Product) => {
    const existing = cart.find(i => i.product.id === product.id);
    if (existing) {
      onUpdateCart(cart.map(i => i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i));
    } else {
      onUpdateCart([...cart, { product, quantity: 1 }]);
    }
  };

  const handleRemoveFromCart = (productId: string) => {
    onUpdateCart(cart.filter(i => i.product.id !== productId));
  };

  const handleUpdateCartQty = (productId: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    onUpdateCart(cart.map(i => i.product.id === productId ? { ...i, quantity: qty } : i));
  };

  // Wishlist actions
  const handleToggleWishlist = (product: Product) => {
    const isWished = wishlist.some(w => w.id === product.id);
    if (isWished) {
      onUpdateWishlist(wishlist.filter(w => w.id !== product.id));
    } else {
      onUpdateWishlist([...wishlist, product]);
    }
  };

  // Calculate pricing
  const subtotal = cart.reduce((sum, item) => {
    const price = item.product.salePrice !== undefined ? item.product.salePrice : item.product.price;
    return sum + (price * item.quantity);
  }, 0);

  const discount = subtotal * (promoDiscount / 100);
  const finalSub = subtotal - discount;
  const shipping = finalSub >= settings.freeShippingThreshold || finalSub === 0 ? 0 : settings.flatShippingCost;
  const tax = finalSub * (settings.taxRatePercentage / 100);
  const total = finalSub + shipping + tax;

  const handleApplyCoupon = () => {
    if (promoCode.toUpperCase() === "WELCOME10") {
      setPromoDiscount(10);
    } else if (promoCode.toUpperCase() === "ATLASCRYPTO") {
      setPromoDiscount(15);
    } else {
      setPromoDiscount(0);
      alert("Invalid coupon code.");
    }
  };

  // Process order placement
  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          customerEmail: guestEmail,
          items: cart.map(i => ({ productId: i.product.id, quantity: i.quantity })),
          shippingAddress: {
            name: customerName,
            street: shippingStreet,
            city: shippingCity,
            state: shippingState,
            postalCode: shippingZip,
            country: shippingCountry,
            phone: shippingPhone
          },
          paymentMethod,
          currency: paymentMethod === "crypto" ? cryptoCurrency : undefined,
          usdtNetwork: paymentMethod === "crypto" && cryptoCurrency === CryptoCurrency.USDT ? usdtNetwork : undefined,
          promoCode: promoDiscount > 0 ? promoCode : undefined,
          notes: checkoutNotes
        })
      });
      const orderData: Order = await response.json();
      
      onPlaceOrder(orderData);
      setPlacedOrderInfo(orderData);

      if (paymentMethod === "crypto") {
        setCheckoutStep("crypto_invoice");
      } else {
        // Direct transition
        onUpdateCart([]);
        onNavigate("order-confirmation");
      }
    } catch (err) {
      console.error("Order placing error:", err);
    }
  };

  // Mock Blockchain Verification
  const triggerCryptoInvoiceClearing = async () => {
    if (!placedOrderInfo) return;
    setIsReconcilingBlockchain(true);

    // Simulate blockchain mining search
    setTimeout(async () => {
      try {
        const response = await fetch(`/api/orders/${placedOrderInfo.id}/confirm-payment`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ txHash: `0x${Math.random().toString(16).slice(2, 26)}` })
        });
        const confirmed: Order = await response.json();
        
        setPlacedOrderInfo(confirmed);
        setReconcileSuccess(true);
        setIsReconcilingBlockchain(false);

        // Clear cart
        onUpdateCart([]);

        setTimeout(() => {
          onNavigate("order-confirmation");
          setCheckoutStep("form");
          setReconcileSuccess(false);
          setPlacedOrderInfo(null);
        }, 1500);

      } catch (e) {
        setIsReconcilingBlockchain(false);
        alert("Verification failed. Please retry.");
      }
    }, 2000);
  };

  // Support Ticket submission
  const handleSupportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject || !ticketMessage) return;

    try {
      const response = await fetch("/api/support-tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName: customerName || "Anonymised Client",
          customerEmail: guestEmail || "client@anonymous.org",
          category: ticketCategory,
          subject: ticketSubject,
          message: ticketMessage
        })
      });
      const ticket: SupportTicket = await response.json();
      
      onAddTicket(ticket);
      setTicketSubject("");
      setTicketMessage("");
      setTicketCreatedSuccess(true);
    } catch (err) {
      console.error("CRM ticket creation failed:", err);
    }
  };

  // Filtered and sorted products
  const processedProducts = availableProducts
    .filter(p => {
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                            p.producer.toLowerCase().includes(searchQuery.toLowerCase()) ||
                            p.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCat = selectedCategory === "All" || p.beverageType === selectedCategory;
      const matchesCountry = selectedCountry === "All" || p.country === selectedCountry;
      return matchesSearch && matchesCat && matchesCountry;
    })
    .sort((a, b) => {
      if (selectedSort === "price-low") return a.price - b.price;
      if (selectedSort === "price-high") return b.price - a.price;
      if (selectedSort === "alphabetical") return a.name.localeCompare(b.name);
      return 0; // popular / default
    });

  return (
    <div id="storefront-container" className="flex flex-col min-h-screen bg-[#050505] text-[#faf9f6]">
      <AnimatePresence mode="wait">
        
        {/* HOMEPAGE VIEW */}
        {currentPath === "home" && (
          <motion.div
            key="home"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-16"
          >
            {/* Architectural Editorial Hero Banner */}
            <section className="relative h-[85vh] flex flex-col justify-end p-8 md:p-16 overflow-hidden border-b border-neutral-900">
              {/* Dark luxury wine background */}
              <div className="absolute inset-0 z-0">
                <img 
                  src="https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=1920&q=80" 
                  alt="Atlas Cellars Reserve" 
                  className="w-full h-full object-cover filter brightness-[0.22] contrast-[1.1]"
                  referrerPolicy="no-referrer"
                />
              </div>
              
              <div className="relative z-10 w-full max-w-4xl space-y-6 text-left">
                <div className="font-mono text-[10px] tracking-[0.4em] text-luxury-bronze uppercase">
                  IMMORTAL ALLOCATIONS // SECURED ORIGINS
                </div>
                
                <h1 className="font-serif text-5xl md:text-7xl font-light tracking-tight leading-[1.05] text-white">
                  Gastronomic perfection. Meticulously catalogued.
                </h1>
                
                <p className="font-sans text-sm md:text-base text-neutral-400 font-light max-w-xl leading-relaxed">
                  Atlas Cellars curates highly sought-after, temperature-controlled bottles of wine, rare Speyside single malts, and Trappist Quadrupes for private collectors.
                </p>

                <div className="pt-4">
                  <button 
                    onClick={() => onNavigate("shop")}
                    className="group bg-luxury-bronze hover:bg-white text-black font-mono text-[11px] tracking-[0.25em] uppercase px-8 py-4 flex items-center gap-3 transition-colors duration-300 font-medium"
                  >
                    Browse Collections <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Acceptance of Bitcoin / USDT Banner */}
              <div className="absolute bottom-6 right-8 md:right-16 z-10 bg-black/60 backdrop-blur-md border border-neutral-800 p-3 flex items-center gap-3 font-mono text-[9px] tracking-widest text-neutral-400">
                <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                SECURE PAYOUTS: <span>BITCOIN (BTC)</span> &amp; <span>TETHER (USDT)</span> SUPPORTED
              </div>
            </section>

            {/* Featured Allocations Carousel/Grid */}
            <section className="max-w-7xl mx-auto px-6 md:px-8 space-y-10 text-left">
              <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-neutral-900 pb-4">
                <div>
                  <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">Curator allocations</span>
                  <h2 className="font-serif text-3xl font-light tracking-tight mt-1 text-[#faf9f6]">Seasonal Recommendations</h2>
                </div>
                <button 
                  onClick={() => onNavigate("shop")}
                  className="font-mono text-[10px] tracking-widest uppercase text-luxury-bronze hover:text-white flex items-center gap-1.5 mt-2 md:mt-0 transition-colors"
                >
                  View Catalog <ChevronRight className="w-4 h-4" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {availableProducts.slice(0, 4).map((product) => (
                  <div 
                    key={product.id} 
                    className="bg-[#0b0b0b] border border-neutral-900 hover:border-neutral-800 transition-all duration-300 flex flex-col justify-between group relative"
                  >
                    <div className="h-72 overflow-hidden bg-black/40 relative">
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-95"
                        referrerPolicy="no-referrer"
                      />
                      <button
                        onClick={() => handleToggleWishlist(product)}
                        className={`absolute top-4 right-4 p-2 bg-black/60 rounded-full border border-neutral-800 text-neutral-400 hover:text-rose-500 transition-colors ${wishlist.some(w => w.id === product.id) ? "text-rose-500" : ""}`}
                      >
                        <Heart className="w-4 h-4 fill-current" />
                      </button>
                    </div>

                    <div className="p-5 space-y-4 text-left">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between font-mono text-[9px] text-neutral-500">
                          <span>{product.beverageType.toUpperCase()}</span>
                          <span>{product.vintage || "NV"}</span>
                        </div>
                        <h3 className="font-serif text-base font-medium line-clamp-1 group-hover:text-luxury-bronze transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-[11px] text-neutral-400 font-light line-clamp-2 leading-relaxed">
                          {product.producer} // {product.region}, {product.country}
                        </p>
                      </div>

                      <div className="flex items-center justify-between border-t border-neutral-900 pt-3">
                        <span className="font-mono text-sm text-[#faf9f6]">
                          ${product.price}
                        </span>
                        <button
                          onClick={() => { setSelectedProduct(product); onNavigate("product"); }}
                          className="font-mono text-[9px] tracking-wider uppercase text-luxury-bronze group-hover:text-white flex items-center gap-1 transition-colors"
                        >
                          Details <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Quiet Luxury Lifestyle Quote / Testimonial */}
            <section className="bg-[#090909] py-20 border-y border-neutral-900">
              <div className="max-w-4xl mx-auto px-6 text-center space-y-6">
                <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">Quiet Luxury Manifesto</span>
                <p className="font-serif text-2xl md:text-3xl italic font-light text-neutral-300 leading-relaxed">
                  "Wine is not merely a consumable beverage; it is an architectural capture of a unique climate, custom-bottled in history. At Atlas, we serve the curators of that history."
                </p>
                <div className="font-mono text-[10px] tracking-widest uppercase text-neutral-500">
                  — CHARLES ATLAS, CELLARMASTER
                </div>
              </div>
            </section>

            {/* Interactive Gemini AI Sommelier Portal Promo */}
            <section className="max-w-7xl mx-auto px-6 md:px-8">
              <div className="bg-[#0a0a0a] border border-neutral-900 p-8 md:p-12 grid grid-cols-1 md:grid-cols-2 gap-8 items-center text-left relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-radial-gradient(ellipse_at_center,rgba(197,168,128,0.06)_0%,transparent_75%) pointer-events-none" />
                
                <div className="space-y-6">
                  <div className="inline-flex items-center gap-2 bg-luxury-bronze/10 border border-luxury-bronze/30 px-3 py-1 font-mono text-[9px] tracking-widest text-luxury-bronze uppercase">
                    <Sparkles className="w-3.5 h-3.5" /> AI-Powered Cellar Concierge
                  </div>
                  <h2 className="font-serif text-3xl md:text-4xl font-light tracking-tight text-white">
                    Uncover Your Perfect Curation with Gemini
                  </h2>
                  <p className="text-neutral-400 text-sm font-light leading-relaxed">
                    Consult our custom-trained digital Sommelier. Speak of your dinner menu, flavor profile preferences, or cellar objectives, and receive curated allocations mapped directly from our live vault list.
                  </p>
                  <button 
                    onClick={() => onNavigate("concierge")}
                    className="bg-[#121212] border border-neutral-800 hover:border-luxury-bronze hover:text-luxury-bronze text-white font-mono text-[10px] tracking-widest uppercase px-6 py-3 transition-colors duration-300"
                  >
                    Enter Private Sommelier Lounge
                  </button>
                </div>

                <div className="h-64 bg-[#0d0d0d] border border-neutral-900 p-4 font-mono text-xs text-neutral-400 flex flex-col justify-between overflow-hidden relative shadow-inner">
                  <div className="space-y-3 overflow-y-auto max-h-[180px] text-[11px] font-mono leading-relaxed">
                    <div><span className="text-luxury-bronze">GUEST:</span> "I am roasting wild venison this weekend. What single-malt or heavy red matches?"</div>
                    <div className="text-neutral-300"><span className="text-luxury-bronze">SOMMELIER (Gemini):</span> "For wild venison, we highly allocate Château Margaux 2015. Meticulous, silky tannins of cassis cut through roast fats. Alternatively, a dram of The Macallan 18 Sherry Oak offers lingering wood-smoke that bridges game flavors perfectly."</div>
                  </div>
                  <div className="border-t border-neutral-900 pt-2 text-[10px] text-neutral-500 text-center">
                    Grounded on live Atlas Cellars inventory database
                  </div>
                </div>
              </div>
            </section>

            {/* Newsletter and Footer */}
            <section className="max-w-md mx-auto px-6 text-center space-y-6 pb-12">
              <h3 className="font-serif text-2xl font-light">Join the Collector Registry</h3>
              <p className="text-xs text-neutral-400 font-light">Receive private notification of seasonal allocations, custom bottlings, and rare spirits releases.</p>
              
              {newsletterSuccess ? (
                <div className="text-xs font-mono text-luxury-bronze bg-luxury-bronze/10 border border-luxury-bronze/20 p-3">
                  EMAIL ENROLLED SUCCESSFULLY
                </div>
              ) : (
                <form 
                  onSubmit={(e) => { e.preventDefault(); if (newsletterEmail) setNewsletterSuccess(true); }}
                  className="flex border border-neutral-800 bg-[#0d0d0d] p-1 focus-within:border-luxury-bronze transition-colors"
                >
                  <input 
                    type="email" 
                    required
                    placeholder="Enter email address..." 
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="flex-1 bg-transparent px-3 py-2 text-xs focus:outline-none placeholder-neutral-700"
                  />
                  <button 
                    type="submit"
                    className="bg-luxury-bronze text-black px-4 font-mono text-[10px] tracking-widest uppercase font-medium"
                  >
                    Register
                  </button>
                </form>
              )}
            </section>

          </motion.div>
        )}

        {/* SHOP CATALOGUE VIEW */}
        {currentPath === "shop" && (
          <motion.div
            key="shop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-7xl mx-auto px-6 md:px-8 py-8 space-y-8"
          >
            {/* Header */}
            <div className="text-left space-y-2">
              <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">curated listings</span>
              <h1 className="font-serif text-4xl font-light text-[#faf9f6]">The Beverage Vault</h1>
              <p className="text-xs text-neutral-400 max-w-xl font-light">Fine wines, Speyside whiskeys, champagne vintages, non-alcoholic botanicals, and bespoke glassware available for temperature-controlled dispatch.</p>
            </div>

            {/* Filter controls */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-[#0d0d0d] p-4 border border-neutral-900 text-left">
              <div>
                <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-500 mb-1">Search Keywords</label>
                <div className="relative">
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="e.g. Margaux, Whisky..."
                    className="w-full bg-black border border-neutral-800 text-xs p-2 pl-8 focus:outline-none focus:border-luxury-bronze placeholder-neutral-800"
                  />
                  <Search className="w-3.5 h-3.5 text-neutral-800 absolute left-2.5 top-3" />
                </div>
              </div>

              <div>
                <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-500 mb-1">Beverage Type</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full bg-black border border-neutral-800 text-xs p-2 text-neutral-400 focus:outline-none focus:border-luxury-bronze font-mono"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-500 mb-1">Origin Country</label>
                <select
                  value={selectedCountry}
                  onChange={(e) => setSelectedCountry(e.target.value)}
                  className="w-full bg-black border border-neutral-800 text-xs p-2 text-neutral-400 focus:outline-none focus:border-luxury-bronze font-mono"
                >
                  {countries.map(cnt => (
                    <option key={cnt} value={cnt}>{cnt}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-500 mb-1">Sort Metrics</label>
                <select
                  value={selectedSort}
                  onChange={(e) => setSelectedSort(e.target.value)}
                  className="w-full bg-black border border-neutral-800 text-xs p-2 text-neutral-400 focus:outline-none focus:border-luxury-bronze font-mono"
                >
                  <option value="popular">Popularity Allocation</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="alphabetical">Alphabetical A-Z</option>
                </select>
              </div>
            </div>

            {/* Product Grid */}
            {processedProducts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {processedProducts.map((product) => (
                  <div 
                    key={product.id} 
                    className="bg-[#0b0b0b] border border-neutral-900 hover:border-neutral-800 transition-all duration-300 flex flex-col justify-between group relative"
                  >
                    <div className="h-72 overflow-hidden bg-black/40 relative">
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter brightness-95"
                        referrerPolicy="no-referrer"
                      />
                      <button
                        onClick={() => handleToggleWishlist(product)}
                        className={`absolute top-4 right-4 p-2 bg-black/60 rounded-full border border-neutral-800 text-neutral-400 hover:text-rose-500 transition-colors ${wishlist.some(w => w.id === product.id) ? "text-rose-500" : ""}`}
                      >
                        <Heart className="w-4 h-4 fill-current" />
                      </button>
                    </div>

                    <div className="p-5 space-y-4 text-left">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between font-mono text-[9px] text-neutral-500">
                          <span>{product.beverageType.toUpperCase()}</span>
                          <span>{product.vintage || "NV"}</span>
                        </div>
                        <h3 className="font-serif text-base font-medium line-clamp-1 group-hover:text-luxury-bronze transition-colors">
                          {product.name}
                        </h3>
                        <p className="text-[11px] text-neutral-400 font-light line-clamp-2 leading-relaxed">
                          {product.producer} // {product.region}, {product.country}
                        </p>
                      </div>

                      <div className="flex items-center justify-between border-t border-neutral-900 pt-3">
                        <span className="font-mono text-sm text-[#faf9f6]">
                          ${product.price}
                        </span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => { setSelectedProduct(product); onNavigate("product"); }}
                            className="font-mono text-[9px] tracking-wider uppercase text-luxury-bronze hover:text-white flex items-center gap-1 transition-colors"
                          >
                            Details
                          </button>
                          <button
                            onClick={() => handleAddToCart(product)}
                            className="font-mono text-[9px] tracking-wider uppercase bg-luxury-bronze text-black px-2 py-1 font-semibold"
                          >
                            Add
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 font-mono text-xs text-neutral-500">
                No allocations match your specified criteria. Let us look deeper in the cellar archives.
              </div>
            )}
          </motion.div>
        )}

        {/* CONCIERGE CHAT VIEW */}
        {currentPath === "concierge" && (
          <motion.div
            key="concierge"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-4xl mx-auto px-6 md:px-8 py-8 space-y-6"
          >
            <div className="text-left space-y-1 border-b border-neutral-900 pb-4">
              <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">AI sommelier concierge</span>
              <h1 className="font-serif text-3xl font-light">The Private Lounge</h1>
              <p className="text-xs text-neutral-400 font-light">Consult with our server-side intelligent curator to discover bespoke drink pairings and catalog suggestions.</p>
            </div>

            {/* Chatbox UI */}
            <div className="border border-neutral-900 bg-[#0c0c0c] flex flex-col justify-between h-[500px]">
              
              {/* Message log */}
              <div className="p-6 overflow-y-auto space-y-4 flex-1">
                {curatorMessages.map((msg, idx) => (
                  <div key={idx} className={`flex ${msg.sender === "user" ? "justify-end" : "justify-start"} text-left`}>
                    <div className={`max-w-[75%] p-4 text-xs leading-relaxed ${msg.sender === "user" ? "bg-[#111] border border-neutral-800 text-neutral-300" : "bg-[#090909] border border-neutral-900 text-neutral-200"}`}>
                      <div className="font-mono text-[8px] text-luxury-bronze uppercase mb-1.5 tracking-wider">
                        {msg.sender === "user" ? "Private Guest" : "Master Sommelier"}
                      </div>
                      <p>{msg.text}</p>
                    </div>
                  </div>
                ))}

                {isCuratorTyping && (
                  <div className="flex justify-start text-left">
                    <div className="bg-[#090909] border border-neutral-900 text-neutral-500 text-[10px] font-mono p-3 flex items-center gap-2">
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" /> Sommelier is formulating allocation brief...
                    </div>
                  </div>
                )}
              </div>

              {/* Input Form */}
              <form onSubmit={handleSendCuratorInquiry} className="flex border-t border-neutral-900 p-2 bg-black/40">
                <input
                  type="text"
                  value={curatorInput}
                  onChange={(e) => setCuratorInput(e.target.value)}
                  placeholder="Ask of sensory tasting profiles, ribeye steak wine matches, or high proof whiskey..."
                  className="flex-1 bg-transparent px-4 py-3 text-xs text-white focus:outline-none placeholder-neutral-700"
                />
                <button
                  type="submit"
                  className="bg-luxury-bronze hover:bg-white text-black px-6 font-mono text-[10px] uppercase tracking-widest font-medium"
                >
                  Inquire
                </button>
              </form>

            </div>
          </motion.div>
        )}

        {/* SINGLE PRODUCT DETAIL VIEW */}
        {currentPath === "product" && selectedProduct && (
          <motion.div
            key="product-detail"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="max-w-7xl mx-auto px-6 md:px-8 py-10"
          >
            <button
              onClick={() => onNavigate("shop")}
              className="text-neutral-400 hover:text-luxury-bronze font-mono text-[10px] uppercase tracking-widest mb-8 flex items-center gap-1"
            >
              <ArrowRight className="w-4 h-4 rotate-180" /> Back to Vault
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 text-left">
              
              {/* Image side */}
              <div className="space-y-4">
                <div className="bg-neutral-950 border border-neutral-900 h-[500px] overflow-hidden flex items-center justify-center relative">
                  <img 
                    src={selectedProduct.imageUrl} 
                    alt={selectedProduct.name} 
                    className="w-full h-full object-cover filter brightness-95"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-black/75 px-3 py-1 text-luxury-bronze font-mono text-[9px] tracking-widest border border-neutral-800">
                    SKU: {selectedProduct.sku}
                  </div>
                </div>
                
                {selectedProduct.awards.length > 0 && (
                  <div className="bg-[#0c0c0c] border border-neutral-900 p-4 space-y-1.5 font-serif italic text-xs text-luxury-bronze">
                    <div className="font-mono text-[8px] tracking-wider uppercase text-neutral-500 not-italic mb-1">Accolades &amp; Awards</div>
                    {selectedProduct.awards.map((aw, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <Sparkles className="w-3.5 h-3.5 shrink-0" />
                        <span>{aw}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Metadatas side */}
              <div className="space-y-6">
                <div>
                  <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">
                    {selectedProduct.beverageType} // {selectedProduct.vintage || "NV Vintage"}
                  </span>
                  <h1 className="font-serif text-3xl md:text-4xl font-light tracking-tight mt-1 text-white">
                    {selectedProduct.name}
                  </h1>
                  <p className="font-sans text-sm text-neutral-400 font-light mt-2 leading-relaxed">
                    By {selectedProduct.producer} in {selectedProduct.region}, {selectedProduct.country}.
                  </p>
                </div>

                <div className="border-y border-neutral-900 py-4 grid grid-cols-3 gap-4 font-mono text-[10px] tracking-wider uppercase text-neutral-400">
                  <div>
                    <span className="text-neutral-600 block text-[8px] mb-0.5">Volumetric Size</span>
                    <span className="text-white font-medium">{selectedProduct.bottleSize}</span>
                  </div>
                  <div>
                    <span className="text-neutral-600 block text-[8px] mb-0.5">Alcohol Volume</span>
                    <span className="text-white font-medium">{selectedProduct.abv}% ABV</span>
                  </div>
                  <div>
                    <span className="text-neutral-600 block text-[8px] mb-0.5">Optimal Temp</span>
                    <span className="text-white font-medium">{selectedProduct.servingTemp || "Default"}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">Curator Commentary</h3>
                  <p className="text-neutral-300 text-sm font-light leading-relaxed">
                    {selectedProduct.description}
                  </p>
                </div>

                {/* Tasting Notes Bento */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 border-t border-neutral-900 pt-4">
                  <div className="bg-[#0b0b0b] p-3 border border-neutral-900">
                    <span className="font-mono text-[8px] text-neutral-500 block uppercase">Nose bouquet</span>
                    <span className="text-xs text-neutral-300 italic mt-1 block font-serif">"{selectedProduct.tastingNotes.nose}"</span>
                  </div>
                  <div className="bg-[#0b0b0b] p-3 border border-neutral-900">
                    <span className="font-mono text-[8px] text-neutral-500 block uppercase">Palate mouthfeel</span>
                    <span className="text-xs text-neutral-300 italic mt-1 block font-serif">"{selectedProduct.tastingNotes.palate}"</span>
                  </div>
                  <div className="bg-[#0b0b0b] p-3 border border-neutral-900">
                    <span className="font-mono text-[8px] text-neutral-500 block uppercase">Finish persistence</span>
                    <span className="text-xs text-neutral-300 italic mt-1 block font-serif">"{selectedProduct.tastingNotes.finish}"</span>
                  </div>
                </div>

                {selectedProduct.foodPairings.length > 0 && (
                  <div className="space-y-1">
                    <h3 className="font-mono text-[9px] uppercase tracking-wider text-neutral-500">Gastronomic Pairings</h3>
                    <div className="flex flex-wrap gap-2 pt-1">
                      {selectedProduct.foodPairings.map((food, i) => (
                        <span key={i} className="bg-neutral-950 border border-neutral-800 text-[10px] px-2.5 py-1 text-neutral-300 font-mono">
                          {food}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Purchase Button */}
                <div className="border-t border-neutral-900 pt-6 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-mono text-neutral-500 block uppercase">Clearing price</span>
                    <span className="font-mono text-2xl text-white">${selectedProduct.price}</span>
                  </div>

                  <div className="flex gap-3">
                    <button
                      onClick={() => handleToggleWishlist(selectedProduct)}
                      className={`p-3 border border-neutral-800 text-neutral-400 hover:text-rose-500 transition-colors ${wishlist.some(w => w.id === selectedProduct.id) ? "text-rose-500 border-rose-950" : ""}`}
                    >
                      <Heart className="w-5 h-5 fill-current" />
                    </button>
                    <button
                      onClick={() => handleAddToCart(selectedProduct)}
                      className="bg-luxury-bronze hover:bg-white text-black font-mono text-[11px] tracking-widest uppercase px-8 py-3.5 transition-colors duration-300 font-medium"
                    >
                      Acquire Allocation
                    </button>
                  </div>
                </div>

              </div>

            </div>
          </motion.div>
        )}

        {/* WISH-LIST VIEW */}
        {currentPath === "wishlist" && (
          <motion.div
            key="wishlist"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-7xl mx-auto px-6 md:px-8 py-8 space-y-8 text-left"
          >
            <div>
              <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">private portfolio</span>
              <h1 className="font-serif text-3xl font-light">My Reserved Wishlist</h1>
              <p className="text-xs text-neutral-400 font-light">Track allocations and limited bottlings of high interest.</p>
            </div>

            {wishlist.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                {wishlist.map((product) => (
                  <div key={product.id} className="bg-[#0b0b0b] border border-neutral-900 p-4 space-y-4">
                    <div className="h-48 bg-neutral-950 overflow-hidden relative">
                      <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      <button 
                        onClick={() => handleToggleWishlist(product)}
                        className="absolute top-2 right-2 p-1.5 bg-black/60 text-rose-500 rounded-full border border-neutral-800"
                      >
                        <Heart className="w-4 h-4 fill-current" />
                      </button>
                    </div>
                    <div>
                      <h4 className="font-serif text-sm truncate">{product.name}</h4>
                      <p className="text-[10px] text-neutral-500 mt-1">{product.producer}</p>
                    </div>
                    <div className="flex justify-between items-center pt-2 border-t border-neutral-900">
                      <span className="font-mono text-sm">${product.price}</span>
                      <button
                        onClick={() => handleAddToCart(product)}
                        className="bg-luxury-bronze text-black text-[9px] font-mono uppercase px-3 py-1 font-semibold"
                      >
                        Add Cart
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-20 font-mono text-xs text-neutral-500 border border-neutral-900 p-8">
                Your portfolio is empty. Mark favorite listings to monitor them.
              </div>
            )}
          </motion.div>
        )}

        {/* CUSTOMER SUPPORT TICKETING */}
        {currentPath === "support" && (
          <motion.div
            key="support"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-xl mx-auto px-6 py-10 space-y-8 text-left"
          >
            <div>
              <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">Customer Care Concierge</span>
              <h1 className="font-serif text-3xl font-light">Concierge Support Tickets</h1>
              <p className="text-xs text-neutral-400 font-light">Submit private inquiries regarding custom allocations, temperature controls, or blockchain clearing delays.</p>
            </div>

            {ticketCreatedSuccess ? (
              <div className="bg-neutral-950 border border-luxury-bronze/30 p-6 space-y-4 text-center">
                <CheckCircle className="w-12 h-12 text-luxury-bronze mx-auto" />
                <h3 className="font-serif text-lg">Inquiry Registry Completed</h3>
                <p className="text-xs text-neutral-400 font-light">Your secure ticket has been compiled for curator desk review. A specialist will update you in the Merchant panel.</p>
                <button
                  onClick={() => setTicketCreatedSuccess(false)}
                  className="bg-luxury-bronze text-black px-6 py-2 text-xs font-mono uppercase font-medium"
                >
                  Create Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSupportSubmit} className="space-y-4">
                <div>
                  <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Inquiry Subject</label>
                  <input
                    type="text"
                    required
                    value={ticketSubject}
                    onChange={(e) => setTicketSubject(e.target.value)}
                    placeholder="e.g. Vintage allocation limit queries..."
                    className="w-full bg-[#0c0c0c] border border-neutral-800 p-3 text-xs text-white focus:outline-none focus:border-luxury-bronze"
                  />
                </div>

                <div>
                  <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Inquiry Category</label>
                  <select
                    value={ticketCategory}
                    onChange={(e) => setTicketCategory(e.target.value as any)}
                    className="w-full bg-[#0c0c0c] border border-neutral-800 p-3 text-xs text-neutral-400 focus:outline-none font-mono"
                  >
                    <option value="Product Inquiry">Product Inquiry</option>
                    <option value="Order Issue">Order Issue</option>
                    <option value="Payment">Payment</option>
                    <option value="Refund Request">Refund Request</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Detailed Sensory Message</label>
                  <textarea
                    required
                    rows={5}
                    value={ticketMessage}
                    onChange={(e) => setTicketMessage(e.target.value)}
                    placeholder="Provide full details of your request..."
                    className="w-full bg-[#0c0c0c] border border-neutral-800 p-3 text-xs text-white focus:outline-none focus:border-luxury-bronze"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-luxury-bronze text-black hover:bg-white text-xs font-mono uppercase tracking-widest py-3 font-medium transition-colors"
                >
                  Submit Private Inquiry
                </button>
              </form>
            )}

            {/* Display list of submitted support tickets for customer review */}
            <div className="border-t border-neutral-900 pt-8 space-y-4">
              <h3 className="font-mono text-[10px] tracking-widest uppercase text-neutral-500">My Registered Inquiries</h3>
              {supportTickets.length > 0 ? (
                <div className="space-y-3">
                  {supportTickets.map(t => (
                    <div key={t.id} className="p-4 bg-neutral-950 border border-neutral-900 space-y-2">
                      <div className="flex justify-between items-center text-[9px] font-mono text-neutral-500">
                        <span>{t.ticketNumber} // {new Date(t.createdAt).toLocaleDateString()}</span>
                        <span className={`px-2 py-0.5 uppercase tracking-wider ${t.status === "Open" ? "bg-amber-950/20 text-amber-500 border border-amber-900/30" : "bg-neutral-900 text-neutral-400 border border-neutral-800"}`}>{t.status}</span>
                      </div>
                      <h4 className="font-serif text-sm text-[#faf9f6]">{t.subject}</h4>
                      
                      {/* Message history preview */}
                      <div className="pl-4 border-l border-neutral-900 space-y-2 mt-2 text-xs text-neutral-400 font-light">
                        {t.messages.map((m, idx) => (
                          <div key={idx} className="space-y-0.5">
                            <span className="font-mono text-[8px] uppercase text-luxury-bronze">{m.sender === "customer" ? "GUEST" : "CONCIERGE"}</span>
                            <p>{m.text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[10px] font-mono text-neutral-600">No past inquiries found on this terminal.</p>
              )}
            </div>
          </motion.div>
        )}

        {/* CART CHECKOUT VIEW */}
        {currentPath === "checkout" && (
          <motion.div
            key="checkout"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-7xl mx-auto px-6 md:px-8 py-8 space-y-8"
          >
            <div className="text-left space-y-1 border-b border-neutral-900 pb-4">
              <span className="font-mono text-[9px] tracking-[0.3em] text-luxury-bronze uppercase">secure clearing</span>
              <h1 className="font-serif text-3xl font-light">DTC Settlement Desk</h1>
            </div>

            {cart.length === 0 ? (
              <div className="text-center py-20 font-mono text-xs text-neutral-500 border border-neutral-900 p-8">
                Your acquisition cart is empty. Mark bottles in the Vault to continue.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
                
                {/* Invoice inputs */}
                {checkoutStep === "form" ? (
                  <form onSubmit={handleCheckoutSubmit} className="md:col-span-2 space-y-6">
                    
                    <div className="bg-[#0c0c0c] border border-neutral-900 p-5 space-y-4">
                      <h3 className="font-serif text-lg text-luxury-bronze">1. Client Contact Records</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Full Name</label>
                          <input 
                            type="text" 
                            required
                            value={customerName}
                            onChange={(e) => setCustomerName(e.target.value)}
                            className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Email Address</label>
                          <input 
                            type="email" 
                            required
                            value={guestEmail}
                            onChange={(e) => setGuestEmail(e.target.value)}
                            className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#0c0c0c] border border-neutral-900 p-5 space-y-4">
                      <h3 className="font-serif text-lg text-luxury-bronze">2. Cold-Chain Delivery Destination</h3>
                      <div className="space-y-3">
                        <div>
                          <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Street Address</label>
                          <input 
                            type="text" 
                            required
                            value={shippingStreet}
                            onChange={(e) => setShippingStreet(e.target.value)}
                            className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                          <div className="col-span-2">
                            <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">City</label>
                            <input 
                              type="text" 
                              required
                              value={shippingCity}
                              onChange={(e) => setShippingCity(e.target.value)}
                              className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">State / Prov</label>
                            <input 
                              type="text" 
                              required
                              value={shippingState}
                              onChange={(e) => setShippingState(e.target.value)}
                              className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Zip Code</label>
                            <input 
                              type="text" 
                              required
                              value={shippingZip}
                              onChange={(e) => setShippingZip(e.target.value)}
                              className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Country</label>
                            <input 
                              type="text" 
                              required
                              value={shippingCountry}
                              onChange={(e) => setShippingCountry(e.target.value)}
                              className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none font-mono"
                            />
                          </div>
                          <div>
                            <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Phone Number</label>
                            <input 
                              type="text" 
                              required
                              value={shippingPhone}
                              onChange={(e) => setShippingPhone(e.target.value)}
                              className="w-full bg-black border border-neutral-800 p-2.5 text-xs text-white focus:outline-none"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-[#0c0c0c] border border-neutral-900 p-5 space-y-4">
                      <h3 className="font-serif text-lg text-luxury-bronze">3. Settlement Protocol</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <button
                          type="button"
                          onClick={() => setPaymentMethod("credit_card")}
                          className={`p-4 border font-mono text-xs uppercase text-center flex flex-col items-center gap-2 ${paymentMethod === "credit_card" ? "border-luxury-bronze bg-luxury-bronze/5 text-white" : "border-neutral-800 text-neutral-400 hover:border-neutral-700"}`}
                        >
                          <CreditCard className="w-5 h-5" /> Standard Credit Card
                        </button>
                        <button
                          type="button"
                          onClick={() => setPaymentMethod("crypto")}
                          className={`p-4 border font-mono text-xs uppercase text-center flex flex-col items-center gap-2 ${paymentMethod === "crypto" ? "border-luxury-bronze bg-luxury-bronze/5 text-white" : "border-neutral-800 text-neutral-400 hover:border-neutral-700"}`}
                        >
                          <Clock className="w-5 h-5 text-amber-500" /> Cryptocurrency
                        </button>
                      </div>

                      {paymentMethod === "crypto" && (
                        <div className="border border-neutral-800 bg-neutral-950 p-4 space-y-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Select Asset</label>
                              <select
                                value={cryptoCurrency}
                                onChange={(e) => setCryptoCurrency(e.target.value as CryptoCurrency)}
                                className="w-full bg-black border border-neutral-800 text-xs p-2 text-neutral-300 focus:outline-none"
                              >
                                <option value={CryptoCurrency.BTC}>Bitcoin (BTC)</option>
                                <option value={CryptoCurrency.USDT}>Tether (USDT)</option>
                              </select>
                            </div>
                            
                            {cryptoCurrency === CryptoCurrency.USDT && (
                              <div>
                                <label className="block font-mono text-[9px] uppercase text-neutral-500 mb-1">Network Standard</label>
                                <select
                                  value={usdtNetwork}
                                  onChange={(e) => setUsdtNetwork(e.target.value as any)}
                                  className="w-full bg-black border border-neutral-800 text-xs p-2 text-neutral-300 focus:outline-none"
                                >
                                  <option value="TRC-20">TRON (TRC-20) - Fast</option>
                                  <option value="ERC-20">Ethereum (ERC-20)</option>
                                  <option value="BSC">Binance Chain (BSC)</option>
                                </select>
                              </div>
                            )}
                          </div>
                          <p className="text-[10px] text-neutral-500 leading-relaxed font-light">
                            * Mempool payment tracking is self-hosted. Clicking place order will generate a unique payment link valid for 15 minutes.
                          </p>
                        </div>
                      )}
                    </div>

                    <div className="text-right">
                      <button
                        type="submit"
                        className="bg-luxury-bronze hover:bg-white text-black font-mono text-xs tracking-widest uppercase px-10 py-4 font-semibold transition-colors duration-300"
                      >
                        Place Custom Allocation Order
                      </button>
                    </div>

                  </form>
                ) : (
                  
                  /* CRYPTO MEMPOOL INVOICE POPUP */
                  <div className="md:col-span-2 bg-[#0d0d0d] border border-neutral-800 p-6 md:p-8 space-y-6 text-center">
                    <div className="space-y-1">
                      <span className="font-mono text-[9px] tracking-widest text-luxury-bronze uppercase">AWAITING BLOCKCHAIN CONFIRMATION</span>
                      <h2 className="font-serif text-2xl">Mempool Settlement Gateway</h2>
                      <p className="text-[11px] font-mono text-rose-400">INVOICE RESERVATION EXPIRES IN: {invoiceTimer}</p>
                    </div>

                    <div className="max-w-md mx-auto border border-neutral-900 bg-neutral-950 p-6 space-y-4">
                      
                      {/* Address display */}
                      <div className="space-y-2">
                        <span className="font-mono text-[9px] text-neutral-500 block uppercase">PAY EXACT AMOUNT TO REGISTER</span>
                        <div className="font-mono text-xl text-amber-500 font-bold">
                          {placedOrderInfo?.paymentDetails.amountCrypto} {placedOrderInfo?.paymentDetails.currency}
                        </div>
                        <div className="text-[10px] text-neutral-400 font-mono">
                          Equiv: ${placedOrderInfo?.total.toFixed(2)} USD (incl. Tax/Shipping)
                        </div>
                      </div>

                      {/* Fake QR code render */}
                      <div className="w-40 h-40 bg-white mx-auto flex items-center justify-center p-2 relative overflow-hidden border border-neutral-800">
                        {/* High fidelity looking QR mock lines */}
                        <div className="absolute inset-0 bg-neutral-100 flex flex-col justify-between p-2">
                          <div className="flex justify-between h-8">
                            <div className="w-8 h-8 bg-black" />
                            <div className="w-8 h-8 bg-black" />
                          </div>
                          <div className="h-6 w-full bg-black/80 flex items-center justify-center text-[7px] text-white font-mono">
                            ATLAS CONG
                          </div>
                          <div className="flex justify-between h-8">
                            <div className="w-8 h-8 bg-black" />
                            <div className="w-4 h-4 bg-black" />
                          </div>
                        </div>
                      </div>

                      {/* Wallet string copy */}
                      <div className="space-y-1 text-left">
                        <span className="font-mono text-[8px] text-neutral-500 block uppercase">WALLET SECURE ADDRESS</span>
                        <div className="flex items-center gap-2 bg-black border border-neutral-900 p-2.5">
                          <span className="font-mono text-[10px] text-neutral-300 select-all truncate flex-1">
                            {placedOrderInfo?.paymentDetails.walletAddress}
                          </span>
                          <button 
                            onClick={() => {
                              navigator.clipboard.writeText(placedOrderInfo?.paymentDetails.walletAddress || "");
                              alert("Wallet address copied.");
                            }}
                            className="text-neutral-500 hover:text-luxury-bronze"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        {placedOrderInfo?.paymentDetails.currency === CryptoCurrency.USDT && (
                          <div className="text-[8px] font-mono text-luxury-bronze">
                            * NETWORK REQUIRED: {placedOrderInfo?.paymentDetails.usdtNetwork} ONLY. WRONG NETWORK LEADS TO IRREVERSIBLE LOSS.
                          </div>
                        )}
                      </div>

                      <div className="font-mono text-[10px] text-neutral-400">
                        Order Reference: <span className="text-[#faf9f6]">{placedOrderInfo?.paymentDetails.orderReference}</span>
                      </div>

                    </div>

                    {/* Simulation settlement triggers */}
                    <div className="space-y-3 pt-4 border-t border-neutral-900 max-w-sm mx-auto">
                      <p className="text-[10px] font-mono text-neutral-500">
                        * In production, our self-hosted node automatically reconciles this mempool ticket. Click below to mock blockchain settlement receipt.
                      </p>
                      
                      <button
                        onClick={triggerCryptoInvoiceClearing}
                        disabled={isReconcilingBlockchain}
                        className="w-full bg-amber-500 hover:bg-amber-400 text-black font-mono text-[11px] tracking-wider uppercase py-3 font-semibold flex items-center justify-center gap-2"
                      >
                        {isReconcilingBlockchain ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" /> VERIFYING BLOCKCHAIN RECEIPT...
                          </>
                        ) : (
                          <>
                            <Check className="w-4 h-4" /> Simulate Blockchain Payment
                          </>
                        )}
                      </button>
                    </div>

                  </div>
                )}

                {/* Acquisition summary side */}
                <div className="md:col-span-1 bg-[#0c0c0c] border border-neutral-900 p-5 md:p-6 space-y-6 h-fit text-left">
                  <h3 className="font-serif text-xl border-b border-neutral-900 pb-3">Order Allocations</h3>
                  
                  <div className="space-y-4 max-h-[220px] overflow-y-auto">
                    {cart.map((item) => {
                      const price = item.product.salePrice !== undefined ? item.product.salePrice : item.product.price;
                      return (
                        <div key={item.product.id} className="flex justify-between items-start gap-2 text-xs border-b border-neutral-900 pb-2">
                          <div>
                            <h4 className="font-serif font-medium text-neutral-200">{item.product.name}</h4>
                            <span className="text-[10px] text-neutral-500 font-mono">Qty: {item.quantity} // {item.product.bottleSize}</span>
                          </div>
                          <div className="font-mono text-neutral-300 text-right">
                            <div>${(price * item.quantity).toFixed(2)}</div>
                            <button
                              onClick={() => handleUpdateCartQty(item.product.id, item.quantity - 1)}
                              className="text-[9px] text-neutral-500 hover:text-rose-400 underline mr-2"
                            >
                              Less
                            </button>
                            <button
                              onClick={() => handleUpdateCartQty(item.product.id, item.quantity + 1)}
                              className="text-[9px] text-neutral-500 hover:text-luxury-bronze underline"
                            >
                              More
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Promo coupon inputs */}
                  <div className="flex border border-neutral-800 p-1 bg-black">
                    <input 
                      type="text" 
                      placeholder="PROMO CODE" 
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      className="w-full bg-transparent px-2.5 py-1.5 text-xs focus:outline-none placeholder-neutral-700 font-mono uppercase"
                    />
                    <button
                      type="button"
                      onClick={handleApplyCoupon}
                      className="bg-[#121212] border border-neutral-800 text-neutral-300 hover:text-white px-3 font-mono text-[9px] uppercase"
                    >
                      Apply
                    </button>
                  </div>

                  {/* Total pricing block */}
                  <div className="space-y-2 border-t border-neutral-900 pt-4 font-mono text-xs">
                    <div className="flex justify-between text-neutral-400">
                      <span>Subtotal</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    {promoDiscount > 0 && (
                      <div className="flex justify-between text-emerald-400">
                        <span>Discount ({promoDiscount}%)</span>
                        <span>-${discount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-neutral-400">
                      <span>Cold shipping</span>
                      <span>{shipping === 0 ? "FREE" : `$${shipping.toFixed(2)}`}</span>
                    </div>
                    <div className="flex justify-between text-neutral-400">
                      <span>Sales Tax ({settings.taxRatePercentage}%)</span>
                      <span>${tax.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-base text-white border-t border-neutral-900 pt-2 font-bold">
                      <span>Total Clearing</span>
                      <span className="text-luxury-bronze">${total.toFixed(2)}</span>
                    </div>
                  </div>

                  <div className="text-[10px] font-mono text-neutral-500 leading-tight">
                    * Temperature controlled climate parcel. Legal age compliance audit completed on checkout.
                  </div>
                </div>

              </div>
            )}
          </motion.div>
        )}

        {/* ORDER CONFIRMATION VIEW */}
        {currentPath === "order-confirmation" && (
          <motion.div
            key="order-confirmation"
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            className="max-w-xl mx-auto px-6 py-16 text-center space-y-6"
          >
            <div className="w-16 h-16 bg-luxury-bronze/10 border border-luxury-bronze/30 rounded-full flex items-center justify-center mx-auto text-luxury-bronze">
              <CheckCircle className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="font-mono text-[9px] tracking-widest text-luxury-bronze uppercase">CLEARED AT BLOCKCHAIN NODE</span>
              <h1 className="font-serif text-3xl font-light">Allocation Confirmed</h1>
              <p className="text-xs text-neutral-400 font-light max-w-sm mx-auto">
                Thank you for your acquisition. Your order has been registered in the Atlas Cellars dispatch queue.
              </p>
            </div>

            {placedOrderInfo && (
              <div className="bg-neutral-950 border border-neutral-900 p-5 text-left space-y-3 font-mono text-xs">
                <div className="flex justify-between border-b border-neutral-900 pb-2">
                  <span className="text-neutral-500">ORDER NUMBER</span>
                  <span className="text-[#faf9f6] font-bold">{placedOrderInfo.orderNumber}</span>
                </div>
                <div className="flex justify-between border-b border-neutral-900 pb-2">
                  <span className="text-neutral-500">ESTIMATED ARRIVAL</span>
                  <span className="text-[#faf9f6]">3-5 Business Days (Insulated)</span>
                </div>
                <div className="flex justify-between border-b border-neutral-900 pb-2">
                  <span className="text-neutral-500">TOTAL SETTLEMENT</span>
                  <span className="text-luxury-bronze font-bold">${placedOrderInfo.total.toFixed(2)}</span>
                </div>
                {placedOrderInfo.paymentDetails.paymentMethod === "crypto" && (
                  <div className="pt-2 text-[9px] text-neutral-500 leading-tight">
                    PAYMENT HASH: {placedOrderInfo.paymentDetails.txHash || "Self-hosted auto reconciliation"}
                  </div>
                )}
              </div>
            )}

            <button
              onClick={() => onNavigate("home")}
              className="bg-luxury-bronze text-black hover:bg-white px-8 py-3 font-mono text-xs uppercase tracking-widest font-semibold transition-colors"
            >
              Return to Cellar Home
            </button>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
