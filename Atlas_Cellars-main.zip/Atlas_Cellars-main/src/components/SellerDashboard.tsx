/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BarChart3, ShieldAlert, Package, ShoppingBag, Users, FolderOpen, 
  Settings, KeyRound, ArrowRight, RotateCcw, Copy, Trash2, Edit3, 
  TrendingUp, CircleDollarSign, Plus, Download, MessageSquare, 
  Eye, CheckCircle2, History, AlertCircle, Save, Loader2, ArrowLeft, RefreshCw
} from "lucide-react";
import { Product, ProductStatus, Order, OrderStatus, AuditLog, SupportTicket, MediaAsset, Coupon } from "../types";

interface SellerDashboardProps {
  products: Product[];
  orders: Order[];
  auditLogs: AuditLog[];
  supportTickets: SupportTicket[];
  media: MediaAsset[];
  settings: any;
  onUpdateProducts: (newProducts: Product[]) => void;
  onUpdateOrders: (newOrders: Order[]) => void;
  onUpdateTickets: (newTickets: SupportTicket[]) => void;
  onUpdateMedia: (newMedia: MediaAsset[]) => void;
  onUpdateSettings: (newSettings: any) => void;
  onToggleDashboard: () => void;
}

export default function SellerDashboard({
  products,
  orders,
  auditLogs,
  supportTickets,
  media,
  settings,
  onUpdateProducts,
  onUpdateOrders,
  onUpdateTickets,
  onUpdateMedia,
  onUpdateSettings,
  onToggleDashboard
}: SellerDashboardProps) {
  const [activeTab, setActiveTab] = useState<"analytics" | "products" | "orders" | "crm" | "media" | "logs" | "settings">("analytics");
  
  // Product Editor States
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreatingProduct, setIsCreatingProduct] = useState(false);
  const [editorProduct, setEditorProduct] = useState<Partial<Product>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // CRM message state
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketReply, setTicketReply] = useState("");

  // Simulated CSV raw text for import/export
  const [csvText, setCsvText] = useState("");
  const [showCsvModal, setShowCsvModal] = useState(false);

  // Auto-Save simulation effect
  useEffect(() => {
    let timer: any;
    if (editingProduct || isCreatingProduct) {
      // Simulate silent autosave to local state or logs
      timer = setInterval(() => {
        console.log("Hypermodern ERP auto-save completed.");
      }, 15000);
    }
    return () => clearInterval(timer);
  }, [editingProduct, isCreatingProduct]);

  // Analytics Computation
  const activeOrders = orders.filter(o => o.status !== OrderStatus.Cancelled && o.status !== OrderStatus.AwaitingPayment);
  const totalRevenue = activeOrders.reduce((sum, o) => sum + o.total, 0);
  const totalItemsSold = activeOrders.reduce((sum, o) => sum + o.items.reduce((acc, i) => acc + i.quantity, 0), 0);
  const lowStockProducts = products.filter(p => p.inventoryQuantity <= p.lowStockAlertThreshold && p.status !== ProductStatus.Archived);

  // Sales category stats
  const categories = ["Wine", "Spirits", "Champagne", "Beer & Cider", "Sake", "Alcohol-Free", "Accessories"];
  const salesByCategory = categories.map(cat => {
    const revenue = activeOrders.reduce((sum, ord) => {
      const catItems = ord.items.filter(item => {
        const prod = products.find(p => p.id === item.productId);
        return prod ? prod.beverageType === cat : false;
      });
      return sum + catItems.reduce((acc, ci) => acc + (ci.price * ci.quantity), 0);
    }, 0);
    return { name: cat, value: revenue };
  });

  // Crypto Currency Usage
  const cryptoOrders = orders.filter(o => o.paymentDetails.paymentMethod === "crypto");
  const fiatOrders = orders.filter(o => o.paymentDetails.paymentMethod === "credit_card");

  // CRM Ticket management
  const handleReplyTicket = (ticketId: string) => {
    if (!ticketReply.trim()) return;
    
    const updated = supportTickets.map(t => {
      if (t.id === ticketId) {
        return {
          ...t,
          status: "In Progress" as const,
          messages: [
            ...t.messages,
            {
              id: `msg-reply-${Date.now()}`,
              sender: "merchant" as const,
              timestamp: new Date().toISOString(),
              text: ticketReply
            }
          ]
        };
      }
      return t;
    });

    onUpdateTickets(updated);
    setTicketReply("");
    const updatedTicket = updated.find(t => t.id === ticketId);
    if (updatedTicket) setSelectedTicket(updatedTicket);

    // Update Audit log
    const log: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "concierge@atlascellars.com",
      action: "CRM Response",
      details: `Replied to client inquiry ticket ${updatedTicket?.ticketNumber}`,
      ipAddress: "127.0.0.1"
    };
    auditLogs.unshift(log);
  };

  // Order state machine advance
  const handleAdvanceOrderStatus = (orderId: string, currentStatus: OrderStatus) => {
    const statuses = Object.values(OrderStatus);
    const currentIndex = statuses.indexOf(currentStatus);
    if (currentIndex === -1 || currentIndex === statuses.length - 1) return;
    
    const nextStatus = statuses[currentIndex + 1];
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return { ...o, status: nextStatus };
      }
      return o;
    });

    onUpdateOrders(updated);

    // Audit log
    const updatedOrder = updated.find(o => o.id === orderId);
    const log: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "admin@atlascellars.com",
      action: "Order Status Progression",
      details: `Advanced order ${updatedOrder?.orderNumber} to [${nextStatus}]`,
      ipAddress: "127.0.0.1"
    };
    auditLogs.unshift(log);
  };

  // Archive and delete products
  const handleArchiveProduct = (id: string) => {
    const updated = products.map(p => {
      if (p.id === id) {
        return { ...p, status: ProductStatus.Archived };
      }
      return p;
    });
    onUpdateProducts(updated);

    const target = products.find(p => p.id === id);
    const log: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "admin@atlascellars.com",
      action: "Product Archived",
      details: `Set ${target?.name} status to Archived.`,
      ipAddress: "127.0.0.1"
    };
    auditLogs.unshift(log);
  };

  // Quick Duplicate Listing
  const handleDuplicateProduct = (id: string) => {
    const found = products.find(p => p.id === id);
    if (!found) return;

    const duplicated: Product = {
      ...found,
      id: `prod-${Date.now()}`,
      sku: `${found.sku}-COPY-${Math.floor(100 + Math.random() * 900)}`,
      name: `${found.name} (Duplicate)`,
      status: ProductStatus.Draft,
      inventoryQuantity: 0,
      priceHistory: [{ date: new Date().toISOString().split("T")[0], price: found.price }],
      inventoryHistory: [{ date: new Date().toISOString(), change: 0, reason: "Manual Duplication", updatedBy: "Merchant" }]
    };

    onUpdateProducts([...products, duplicated]);

    const log: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "admin@atlascellars.com",
      action: "Product Duplication",
      details: `Duplicated listing: ${found.name}`,
      ipAddress: "127.0.0.1"
    };
    auditLogs.unshift(log);
  };

  // Quick Relist Archived Product
  const handleRelistProduct = (id: string) => {
    const updated = products.map(p => {
      if (p.id === id) {
        return { ...p, status: ProductStatus.Published, inventoryQuantity: Math.max(5, p.inventoryQuantity) };
      }
      return p;
    });
    onUpdateProducts(updated);

    const target = products.find(p => p.id === id);
    const log: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "admin@atlascellars.com",
      action: "Product Relisted",
      details: `Relisted and published archived product: ${target?.name}`,
      ipAddress: "127.0.0.1"
    };
    auditLogs.unshift(log);
  };

  // Save / Update Product metadata
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveSuccess(false);

    setTimeout(() => {
      if (isCreatingProduct) {
        const newProduct: Product = {
          id: `prod-${Date.now()}`,
          sku: (editorProduct.sku || `SKU-${Date.now().toString().slice(-6)}`).toUpperCase(),
          name: editorProduct.name || "Unnamed Drink",
          producer: editorProduct.producer || "Independent Cellars",
          region: editorProduct.region || "Various",
          country: editorProduct.country || "France",
          beverageType: editorProduct.beverageType || "Wine",
          vintage: editorProduct.vintage || "NV",
          abv: Number(editorProduct.abv) || 12.5,
          bottleSize: editorProduct.bottleSize || "750ml",
          tastingNotes: {
            nose: editorProduct.tastingNotes?.nose || "Elegant and aromatic.",
            palate: editorProduct.tastingNotes?.palate || "Rich and complex.",
            finish: editorProduct.tastingNotes?.finish || "Lingering finish."
          },
          foodPairings: editorProduct.foodPairings || ["Red Meat", "Cured Cheese"],
          servingTemp: editorProduct.servingTemp || "16°C",
          awards: editorProduct.awards || [],
          description: editorProduct.description || "A gorgeous bespoke drinks collection.",
          imageUrl: editorProduct.imageUrl || "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80",
          price: Number(editorProduct.price) || 99,
          salePrice: editorProduct.salePrice ? Number(editorProduct.salePrice) : undefined,
          inventoryQuantity: Number(editorProduct.inventoryQuantity) || 10,
          status: editorProduct.status || ProductStatus.Draft,
          lowStockAlertThreshold: Number(editorProduct.lowStockAlertThreshold) || 3,
          priceHistory: [{ date: new Date().toISOString().split('T')[0], price: Number(editorProduct.price) || 99 }],
          inventoryHistory: [{ date: new Date().toISOString(), change: Number(editorProduct.inventoryQuantity) || 10, reason: "Creation", updatedBy: "Merchant" }]
        };

        onUpdateProducts([...products, newProduct]);
        setIsCreatingProduct(false);

        const log: AuditLog = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: "admin@atlascellars.com",
          action: "Product Created",
          details: `Created new hypermodern listing: ${newProduct.name}`,
          ipAddress: "127.0.0.1"
        };
        auditLogs.unshift(log);
      } else if (editingProduct) {
        const updated = products.map(p => {
          if (p.id === editingProduct.id) {
            return {
              ...p,
              ...editorProduct,
              tastingNotes: {
                ...p.tastingNotes,
                ...editorProduct.tastingNotes
              }
            } as Product;
          }
          return p;
        });

        onUpdateProducts(updated);
        setEditingProduct(null);

        const log: AuditLog = {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          user: "admin@atlascellars.com",
          action: "Product Profile Modified",
          details: `Updated product metadata for ${editingProduct.name}`,
          ipAddress: "127.0.0.1"
        };
        auditLogs.unshift(log);
      }

      setIsSaving(false);
      setSaveSuccess(true);
      setEditorProduct({});
    }, 1000);
  };

  const startEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setIsCreatingProduct(false);
    setEditorProduct({ ...prod });
  };

  const startCreateProduct = () => {
    setIsCreatingProduct(true);
    setEditingProduct(null);
    setEditorProduct({
      status: ProductStatus.Draft,
      beverageType: "Wine",
      abv: 13.5,
      price: 150,
      inventoryQuantity: 12,
      lowStockAlertThreshold: 3,
      bottleSize: "750ml",
      tastingNotes: { nose: "", palate: "", finish: "" },
      foodPairings: [],
      awards: []
    });
  };

  // CSV Import simulation
  const handleCsvImport = () => {
    if (!csvText.trim()) return;
    
    try {
      const lines = csvText.trim().split("\n");
      const headers = lines[0].split(",");
      const importedItems: any[] = [];

      for (let i = 1; i < lines.length; i++) {
        if (!lines[i]) continue;
        const values = lines[i].split(",");
        const item: any = {};
        headers.forEach((h, idx) => {
          item[h.trim()] = values[idx]?.trim();
        });
        importedItems.push(item);
      }

      // Convert importedItems to products
      const mapped: Product[] = importedItems.map((item, idx) => ({
        id: `prod-csv-${Date.now()}-${idx}`,
        sku: item.sku || `SKU-CSV-${Math.floor(1000+Math.random()*9000)}`,
        name: item.name || "Imported Bottle",
        producer: item.producer || "Bespoke Vineyard",
        region: item.region || "Bordeaux",
        country: item.country || "France",
        beverageType: item.beverageType || "Wine",
        vintage: item.vintage || "2020",
        abv: Number(item.abv) || 13.0,
        bottleSize: item.bottleSize || "750ml",
        tastingNotes: {
          nose: item.nose || "Aromatic",
          palate: item.palate || "Rich",
          finish: item.finish || "Elegant"
        },
        foodPairings: (item.foodPairings || "").split(";").filter(Boolean),
        awards: (item.awards || "").split(";").filter(Boolean),
        description: item.description || "Premium DTC drink allocation",
        imageUrl: item.imageUrl || "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80",
        price: Number(item.price) || 120,
        inventoryQuantity: Number(item.inventoryQuantity) || 24,
        status: ProductStatus.Published,
        lowStockAlertThreshold: 5,
        priceHistory: [{ date: new Date().toISOString().split('T')[0], price: Number(item.price) || 120 }],
        inventoryHistory: [{ date: new Date().toISOString(), change: Number(item.inventoryQuantity) || 24, reason: "CSV Import", updatedBy: "Admin" }]
      }));

      onUpdateProducts([...products, ...mapped]);
      setShowCsvModal(false);
      setCsvText("");

      const log: AuditLog = {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        user: "admin@atlascellars.com",
        action: "CSV Bulk Import",
        details: `Imported and registered ${mapped.length} products via bulk operational file.`,
        ipAddress: "127.0.0.1"
      };
      auditLogs.unshift(log);
    } catch (e) {
      alert("Error parsing CSV. Please check formatting.");
    }
  };

  const handleExportCsv = () => {
    const headers = "sku,name,producer,beverageType,price,inventoryQuantity,region,country,vintage,abv";
    const rows = products.map(p => 
      `"${p.sku}","${p.name}","${p.producer}","${p.beverageType}",${p.price},${p.inventoryQuantity},"${p.region}","${p.country}","${p.vintage || ""}",${p.abv}`
    );
    const text = headers + "\n" + rows.join("\n");
    
    // Trigger download
    const blob = new Blob([text], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `atlas_cellars_inventory_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  // Reconcile manual blockchain check
  const handleSimulateBlockchainReconciliation = (orderId: string) => {
    const hash = `0x${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}${Math.random().toString(16).slice(2, 10)}`;
    const updated = orders.map(o => {
      if (o.id === orderId) {
        return {
          ...o,
          status: OrderStatus.PaymentReceived,
          paymentDetails: {
            ...o.paymentDetails,
            paymentConfirmed: true,
            paymentConfirmedAt: new Date().toISOString(),
            txHash: hash
          }
        };
      }
      return o;
    });

    onUpdateOrders(updated);

    const ord = orders.find(o => o.id === orderId);
    const log: AuditLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "system_blockchain_listener",
      action: "Blockchain Settlement",
      details: `Settled payment order ${ord?.orderNumber}. Wallet detected confirmation block successfully.`,
      ipAddress: "127.0.0.1"
    };
    auditLogs.unshift(log);
  };

  return (
    <div id="seller-dashboard-layout" className="min-h-screen bg-[#070707] text-[#faf9f6] flex flex-col font-sans">
      
      {/* ERP Header */}
      <header className="border-b border-neutral-900 bg-[#0d0d0d] px-6 py-4 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-4">
          <button 
            onClick={onToggleDashboard}
            className="flex items-center gap-2 text-xs font-mono text-neutral-400 hover:text-luxury-bronze uppercase tracking-wider"
          >
            <ArrowLeft className="w-4 h-4" /> Exit Portal
          </button>
          <div className="h-4 w-[1px] bg-neutral-800" />
          <h1 className="font-display font-medium text-sm tracking-[0.2em] uppercase text-luxury-bronze">
            ATLAS CELLARS // ENTERPRISE ERP v4.2
          </h1>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex h-2 w-2 relative">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-mono text-[10px] text-neutral-400 tracking-widest uppercase">
            SECURE INTEGRATION NODE // tom@ahyx.org
          </span>
        </div>
      </header>

      {/* Main Admin Body */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Navigation Sidebar */}
        <aside className="w-64 bg-[#090909] border-r border-neutral-900 p-4 flex flex-col justify-between shrink-0">
          <div className="space-y-1">
            <div className="px-3 py-2 text-[10px] font-mono tracking-[0.3em] text-neutral-500 uppercase">
              Control Panel
            </div>
            
            <button
              onClick={() => { setActiveTab("analytics"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "analytics" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <BarChart3 className="w-4 h-4 shrink-0" /> Analytics Summary
            </button>

            <button
              onClick={() => { setActiveTab("products"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "products" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <Package className="w-4 h-4 shrink-0" /> Inventory & SKU List
            </button>

            <button
              onClick={() => { setActiveTab("orders"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "orders" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <ShoppingBag className="w-4 h-4 shrink-0" /> Orders Pipeline
              {orders.filter(o => o.status === OrderStatus.AwaitingPayment || o.status === OrderStatus.PaymentReceived).length > 0 && (
                <span className="ml-auto bg-luxury-bronze text-black font-sans font-bold text-[9px] px-1.5 py-0.5 rounded-full">
                  {orders.filter(o => o.status === OrderStatus.AwaitingPayment || o.status === OrderStatus.PaymentReceived).length}
                </span>
              )}
            </button>

            <button
              onClick={() => { setActiveTab("crm"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "crm" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <MessageSquare className="w-4 h-4 shrink-0" /> CRM Concierge Tickets
              {supportTickets.filter(t => t.status === "Open").length > 0 && (
                <span className="ml-auto bg-amber-500 text-black font-sans font-bold text-[9px] px-1.5 py-0.5 rounded-full">
                  {supportTickets.filter(t => t.status === "Open").length}
                </span>
              )}
            </button>

            <button
              onClick={() => { setActiveTab("media"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "media" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <FolderOpen className="w-4 h-4 shrink-0" /> Media Library WebP
            </button>

            <button
              onClick={() => { setActiveTab("logs"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "logs" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <History className="w-4 h-4 shrink-0" /> Real-time Audit Logs
            </button>

            <button
              onClick={() => { setActiveTab("settings"); setEditingProduct(null); setIsCreatingProduct(false); }}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-mono tracking-wider uppercase transition-all duration-200 ${activeTab === "settings" ? "bg-neutral-900 text-luxury-bronze border-l-2 border-luxury-bronze" : "text-neutral-400 hover:bg-neutral-950 hover:text-[#faf9f6]"}`}
            >
              <Settings className="w-4 h-4 shrink-0" /> Server Configuration
            </button>
          </div>

          <div className="border-t border-neutral-900 pt-4 text-[10px] text-neutral-500 font-mono space-y-1">
            <div>HOST: CLOUD_RUN_PROD</div>
            <div>DB_ENGINE: POSTGRES_SELF</div>
            <div>CRYPTO_NODE: ONLINE (TLS)</div>
          </div>
        </aside>

        {/* Dynamic Content Panel */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto bg-[#0a0a0a]">
          <AnimatePresence mode="wait">
            
            {/* 1. ANALYTICS VIEW */}
            {activeTab === "analytics" && (
              <motion.div
                key="analytics"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-8"
              >
                {/* Visual Bento Stats Block */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  
                  <div className="bg-[#0f0f0f] border border-neutral-800 p-5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-12 h-12 flex items-center justify-center text-luxury-bronze opacity-20">
                      <CircleDollarSign className="w-10 h-10" />
                    </div>
                    <div className="font-mono text-[10px] tracking-wider uppercase text-neutral-500 mb-1">
                      Gross Settlement Volume
                    </div>
                    <div className="font-serif text-3xl font-light text-[#faf9f6]">
                      ${totalRevenue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </div>
                    <div className="mt-2 text-[10px] text-emerald-400 font-mono flex items-center gap-1">
                      <TrendingUp className="w-3 h-3" /> +14.2% Seasonal Gain
                    </div>
                  </div>

                  <div className="bg-[#0f0f0f] border border-neutral-800 p-5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-12 h-12 flex items-center justify-center text-luxury-bronze opacity-20">
                      <ShoppingBag className="w-10 h-10" />
                    </div>
                    <div className="font-mono text-[10px] tracking-wider uppercase text-neutral-500 mb-1">
                      Completed Orders
                    </div>
                    <div className="font-serif text-3xl font-light text-[#faf9f6]">
                      {activeOrders.length}
                    </div>
                    <div className="mt-2 text-[10px] text-neutral-400 font-mono">
                      {orders.filter(o => o.status === OrderStatus.AwaitingPayment).length} Awaiting Blockchain Settlement
                    </div>
                  </div>

                  <div className="bg-[#0f0f0f] border border-neutral-800 p-5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-12 h-12 flex items-center justify-center text-luxury-bronze opacity-20">
                      <KeyRound className="w-10 h-10" />
                    </div>
                    <div className="font-mono text-[10px] tracking-wider uppercase text-neutral-500 mb-1">
                      Crypto Transaction Ratio
                    </div>
                    <div className="font-serif text-3xl font-light text-[#faf9f6]">
                      {orders.length > 0 ? ((cryptoOrders.length / orders.length) * 100).toFixed(1) : "0.0"}%
                    </div>
                    <div className="mt-2 text-[10px] text-luxury-bronze font-mono">
                      {cryptoOrders.length} BTC/USDT settlements
                    </div>
                  </div>

                  <div className="bg-[#0f0f0f] border border-[#2b251d] p-5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-12 h-12 flex items-center justify-center text-luxury-bronze opacity-20">
                      <ShieldAlert className="w-10 h-10" />
                    </div>
                    <div className="font-mono text-[10px] tracking-wider uppercase text-amber-500 mb-1">
                      Low Stock Alerts
                    </div>
                    <div className="font-serif text-3xl font-light text-[#faf9f6]">
                      {lowStockProducts.length}
                    </div>
                    <div className="mt-2 text-[10px] text-amber-500/80 font-mono">
                      Requires supplier allocation order
                    </div>
                  </div>

                </div>

                {/* SVG High-End Custom Area Charts (No Recharts library crashes!) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  <div className="bg-[#0f0f0f] border border-neutral-800 p-6">
                    <h3 className="font-mono text-xs tracking-widest uppercase text-neutral-400 mb-6">
                      Seasonal Sales Category Volume (USD)
                    </h3>
                    <div className="space-y-4">
                      {salesByCategory.map((cat, idx) => {
                        const maxValue = Math.max(...salesByCategory.map(c => c.value), 1);
                        const pct = (cat.value / maxValue) * 100;
                        return (
                          <div key={idx} className="space-y-1">
                            <div className="flex justify-between text-xs font-mono">
                              <span className="text-neutral-400">{cat.name}</span>
                              <span className="text-luxury-bronze">${cat.value.toLocaleString()}</span>
                            </div>
                            <div className="h-1.5 w-full bg-neutral-900">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${pct}%` }}
                                transition={{ duration: 1, delay: idx * 0.1 }}
                                className="h-full bg-luxury-bronze" 
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="bg-[#0f0f0f] border border-neutral-800 p-6 flex flex-col justify-between">
                    <div>
                      <h3 className="font-mono text-xs tracking-widest uppercase text-neutral-400 mb-4">
                        Cryptocurrency Settlement Distribution
                      </h3>
                      <div className="grid grid-cols-3 gap-2 text-center py-4">
                        <div className="border border-neutral-900 p-3 bg-black/40">
                          <div className="font-mono text-[9px] text-neutral-500">BITCOIN (BTC)</div>
                          <div className="font-serif text-xl text-[#faf9f6] mt-1">
                            {orders.filter(o => o.paymentDetails.currency === "BTC").length}
                          </div>
                        </div>
                        <div className="border border-neutral-900 p-3 bg-black/40">
                          <div className="font-mono text-[9px] text-neutral-500">TETHER (USDT)</div>
                          <div className="font-serif text-xl text-[#faf9f6] mt-1">
                            {orders.filter(o => o.paymentDetails.currency === "USDT").length}
                          </div>
                        </div>
                        <div className="border border-neutral-900 p-3 bg-black/40">
                          <div className="font-mono text-[9px] text-neutral-500">CREDIT CARD</div>
                          <div className="font-serif text-xl text-neutral-400 mt-1">
                            {fiatOrders.length}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-neutral-900 pt-4 mt-4 text-xs text-neutral-400 font-light space-y-2">
                      <div className="flex justify-between font-mono text-[10px]">
                        <span>DTC Conversion Rate</span>
                        <span className="text-[#faf9f6]">{settings.enforceAgeVerification ? "3.14%" : "4.02%"}</span>
                      </div>
                      <div className="flex justify-between font-mono text-[10px]">
                        <span>Inventory Turnover Index</span>
                        <span className="text-[#faf9f6]">85.2 Days</span>
                      </div>
                      <div className="flex justify-between font-mono text-[10px]">
                        <span>Age-Restriction Bounce Rate</span>
                        <span className="text-amber-500">12.4% (Compliant)</span>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Direct-to-Consumer Marketing & SEO Tools Summary */}
                <div className="bg-[#0f0f0f] border border-neutral-800 p-6">
                  <h3 className="font-mono text-xs tracking-widest uppercase text-neutral-400 mb-4">
                    Active DTC Coupons & Marketing
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-neutral-950 p-4 border border-neutral-900">
                      <div className="font-mono text-[10px] text-luxury-bronze">WELCOME10 (10% OFF)</div>
                      <div className="text-[11px] text-neutral-400 mt-1 font-light">New accounts automated newsletter coupon.</div>
                      <div className="font-mono text-[10px] text-emerald-400 mt-2">ACTIVE</div>
                    </div>
                    <div className="bg-neutral-950 p-4 border border-neutral-900">
                      <div className="font-mono text-[10px] text-luxury-bronze">ATLASCRYPTO (15% OFF)</div>
                      <div className="text-[11px] text-neutral-400 mt-1 font-light">incentive campaign for self-hosted wallets.</div>
                      <div className="font-mono text-[10px] text-emerald-400 mt-2">ACTIVE</div>
                    </div>
                    <div className="bg-neutral-950 p-4 border border-neutral-900">
                      <div className="font-mono text-[10px] text-luxury-bronze">VIP50 ($50 FLAT)</div>
                      <div className="text-[11px] text-neutral-400 mt-1 font-light">Concierge private client allocation code.</div>
                      <div className="font-mono text-[10px] text-emerald-400 mt-2">ACTIVE</div>
                    </div>
                  </div>
                </div>

              </motion.div>
            )}

            {/* 2. INVENTORY & PRODUCT MANAGEMENT */}
            {activeTab === "products" && !editingProduct && !isCreatingProduct && (
              <motion.div
                key="products-list"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h2 className="font-serif text-2xl font-light text-[#faf9f6]">Catalogue Inventory</h2>
                    <p className="text-xs text-neutral-400 font-mono mt-1">Real-time beverage listing and allocation parameters</p>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={startCreateProduct}
                      className="bg-luxury-bronze text-black hover:bg-white text-xs font-mono uppercase tracking-widest px-4 py-2.5 flex items-center gap-2 font-medium"
                    >
                      <Plus className="w-4 h-4" /> Add Bottle
                    </button>
                    <button
                      onClick={() => setShowCsvModal(true)}
                      className="bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-mono uppercase tracking-widest px-4 py-2.5 flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> CSV Import
                    </button>
                    <button
                      onClick={handleExportCsv}
                      className="bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white text-xs font-mono uppercase tracking-widest px-4 py-2.5 flex items-center gap-2"
                    >
                      <Download className="w-4 h-4" /> CSV Export
                    </button>
                  </div>
                </div>

                {/* CSV Import Modal */}
                {showCsvModal && (
                  <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
                    <div className="bg-[#0d0d0d] border border-neutral-800 p-6 w-full max-w-xl">
                      <h3 className="font-serif text-xl mb-2">Bulk CSV Import</h3>
                      <p className="text-[10px] font-mono text-neutral-400 mb-4">
                        Provide a CSV structured line list. Format header: <span className="text-luxury-bronze">sku,name,producer,beverageType,price,inventoryQuantity,vintage,abv</span>
                      </p>
                      <textarea
                        value={csvText}
                        onChange={(e) => setCsvText(e.target.value)}
                        placeholder={`sku,name,producer,beverageType,price,inventoryQuantity,vintage,abv\nSPI-TEQ-REPOSADO-1,Curated Tequila Reposado,Altos,Spirits,125,24,NV,40.0`}
                        rows={8}
                        className="w-full bg-[#121212] border border-neutral-800 p-3 text-xs font-mono text-[#faf9f6] focus:outline-none focus:border-luxury-bronze"
                      />
                      <div className="mt-4 flex justify-end gap-2">
                        <button 
                          onClick={() => { setShowCsvModal(false); setCsvText(""); }}
                          className="bg-neutral-900 px-4 py-2 text-xs font-mono uppercase tracking-wider text-neutral-400"
                        >
                          Cancel
                        </button>
                        <button 
                          onClick={handleCsvImport}
                          className="bg-luxury-bronze text-black px-4 py-2 text-xs font-mono uppercase tracking-wider font-medium"
                        >
                          Import Listing
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Inventory Table */}
                <div className="bg-[#0f0f0f] border border-neutral-800 overflow-x-auto">
                  <table className="w-full border-collapse text-left">
                    <thead>
                      <tr className="border-b border-neutral-800 font-mono text-[9px] uppercase text-neutral-500 tracking-wider">
                        <th className="p-4">SKU / Bottle Details</th>
                        <th className="p-4">Category</th>
                        <th className="p-4">Stock Level</th>
                        <th className="p-4">Price</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-900">
                      {products.map((p) => (
                        <tr key={p.id} className="hover:bg-neutral-950/50 transition-colors">
                          <td className="p-4">
                            <div className="font-mono text-[10px] text-luxury-bronze">{p.sku}</div>
                            <div className="font-serif text-sm text-[#faf9f6] mt-0.5">{p.name}</div>
                            <div className="text-[10px] text-neutral-500 font-light mt-0.5">
                              {p.producer} // {p.region}, {p.country} {p.vintage ? `(${p.vintage})` : ""}
                            </div>
                          </td>
                          <td className="p-4 font-mono text-[10px] text-neutral-300">
                            {p.beverageType}
                          </td>
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              <span className={`font-mono text-xs ${p.inventoryQuantity <= p.lowStockAlertThreshold ? "text-amber-500 font-bold" : "text-neutral-300"}`}>
                                {p.inventoryQuantity}
                              </span>
                              {p.inventoryQuantity <= p.lowStockAlertThreshold && p.status !== ProductStatus.Archived && (
                                <span className="bg-amber-950/40 text-amber-500 border border-amber-900/40 text-[8px] font-mono px-1 py-0.5">
                                  LOW STOCK
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="p-4 font-mono text-xs text-neutral-200">
                            {p.salePrice ? (
                              <div className="space-y-0.5">
                                <div className="line-through text-neutral-500">${p.price}</div>
                                <div className="text-luxury-bronze">${p.salePrice}</div>
                              </div>
                            ) : (
                              `$${p.price}`
                            )}
                          </td>
                          <td className="p-4">
                            <span className={`inline-block font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 ${
                              p.status === ProductStatus.Published ? "bg-emerald-950/40 text-emerald-400 border border-emerald-900/40" :
                              p.status === ProductStatus.Draft ? "bg-neutral-900 text-neutral-400 border border-neutral-800" :
                              p.status === ProductStatus.Hidden ? "bg-amber-950/20 text-amber-500 border border-amber-900/20" :
                              "bg-rose-950/20 text-rose-400 border border-rose-900/20"
                            }`}>
                              {p.status}
                            </span>
                          </td>
                          <td className="p-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                onClick={() => startEditProduct(p)}
                                className="text-neutral-400 hover:text-luxury-bronze p-1.5 transition-colors"
                                title="Edit Product"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDuplicateProduct(p.id)}
                                className="text-neutral-400 hover:text-luxury-bronze p-1.5 transition-colors"
                                title="Duplicate Listing"
                              >
                                <Copy className="w-3.5 h-3.5" />
                              </button>
                              {p.status === ProductStatus.Archived ? (
                                <button
                                  onClick={() => handleRelistProduct(p.id)}
                                  className="text-emerald-400 hover:text-emerald-300 font-mono text-[9px] uppercase px-2 py-1 border border-emerald-900/50 hover:bg-emerald-950/20"
                                  title="Quick Relist"
                                >
                                  Relist
                                </button>
                              ) : (
                                <button
                                  onClick={() => handleArchiveProduct(p.id)}
                                  className="text-neutral-400 hover:text-rose-400 p-1.5 transition-colors"
                                  title="Archive / Delist"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </motion.div>
            )}

            {/* 3. PRODUCT EDITOR FORM */}
            {(editingProduct || isCreatingProduct) && (
              <motion.div
                key="product-editor"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div className="flex items-center justify-between border-b border-neutral-900 pb-4">
                  <div>
                    <h2 className="font-serif text-2xl font-light text-[#faf9f6]">
                      {isCreatingProduct ? "Add New Curated Listing" : `Edit Listing: ${editingProduct?.name}`}
                    </h2>
                    <p className="text-xs text-neutral-400 font-mono mt-0.5">Enterprise Beverage Information Management</p>
                  </div>
                  <button
                    onClick={() => { setEditingProduct(null); setIsCreatingProduct(false); }}
                    className="text-xs font-mono uppercase tracking-wider text-neutral-400 hover:text-luxury-bronze flex items-center gap-1"
                  >
                    <ArrowLeft className="w-4 h-4" /> Cancel
                  </button>
                </div>

                <form onSubmit={handleSaveProduct} className="space-y-8 max-w-4xl">
                  
                  {/* Status & Key Settings */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-neutral-950 p-6 border border-neutral-900">
                    <div>
                      <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Publish Status</label>
                      <select
                        value={editorProduct.status}
                        onChange={(e) => setEditorProduct({ ...editorProduct, status: e.target.value as ProductStatus })}
                        className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 text-[#faf9f6] focus:outline-none focus:border-luxury-bronze font-mono"
                      >
                        {Object.values(ProductStatus).map((status) => (
                          <option key={status} value={status}>{status}</option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">SKU Reference</label>
                      <input
                        type="text"
                        value={editorProduct.sku || ""}
                        onChange={(e) => setEditorProduct({ ...editorProduct, sku: e.target.value })}
                        placeholder="e.g. WIN-CH-MARG-2015"
                        className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze font-mono"
                      />
                    </div>

                    <div>
                      <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Beverage Category</label>
                      <select
                        value={editorProduct.beverageType}
                        onChange={(e) => setEditorProduct({ ...editorProduct, beverageType: e.target.value })}
                        className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 text-[#faf9f6] focus:outline-none focus:border-luxury-bronze font-mono"
                      >
                        {categories.map((cat) => (
                          <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Core Details */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Product Display Name</label>
                        <input
                          type="text"
                          required
                          value={editorProduct.name || ""}
                          onChange={(e) => setEditorProduct({ ...editorProduct, name: e.target.value })}
                          placeholder="e.g. Château Margaux 2015"
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>

                      <div>
                        <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Producer / Distillery / Brewery</label>
                        <input
                          type="text"
                          value={editorProduct.producer || ""}
                          onChange={(e) => setEditorProduct({ ...editorProduct, producer: e.target.value })}
                          placeholder="e.g. Château Margaux"
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Region</label>
                          <input
                            type="text"
                            value={editorProduct.region || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, region: e.target.value })}
                            placeholder="e.g. Bordeaux"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Country</label>
                          <input
                            type="text"
                            value={editorProduct.country || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, country: e.target.value })}
                            placeholder="e.g. France"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4">
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Vintage</label>
                          <input
                            type="text"
                            value={editorProduct.vintage || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, vintage: e.target.value })}
                            placeholder="e.g. 2015"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">ABV (%)</label>
                          <input
                            type="number"
                            step="0.1"
                            value={editorProduct.abv || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, abv: Number(e.target.value) })}
                            placeholder="13.5"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze font-mono"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Bottle Size</label>
                          <input
                            type="text"
                            value={editorProduct.bottleSize || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, bottleSize: e.target.value })}
                            placeholder="750ml"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Regular Price ($)</label>
                          <input
                            type="number"
                            required
                            value={editorProduct.price || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, price: Number(e.target.value) })}
                            placeholder="1850"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze font-mono"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Sale Price ($)</label>
                          <input
                            type="number"
                            value={editorProduct.salePrice || ""}
                            onChange={(e) => setEditorProduct({ ...editorProduct, salePrice: e.target.value ? Number(e.target.value) : undefined })}
                            placeholder="Promo Price"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze font-mono"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Stock Inventory</label>
                          <input
                            type="number"
                            value={editorProduct.inventoryQuantity || 0}
                            onChange={(e) => setEditorProduct({ ...editorProduct, inventoryQuantity: Number(e.target.value) })}
                            placeholder="12"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze font-mono"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Low Stock Threshold</label>
                          <input
                            type="number"
                            value={editorProduct.lowStockAlertThreshold || 3}
                            onChange={(e) => setEditorProduct({ ...editorProduct, lowStockAlertThreshold: Number(e.target.value) })}
                            placeholder="3"
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2.5 focus:outline-none focus:border-luxury-bronze font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Descriptions, tasting notes */}
                  <div className="space-y-4">
                    <div>
                      <label className="block font-mono text-[9px] uppercase tracking-wider text-neutral-400 mb-2">Curator Narrative Description (Supports Markdown / Rich Text)</label>
                      <textarea
                        value={editorProduct.description || ""}
                        onChange={(e) => setEditorProduct({ ...editorProduct, description: e.target.value })}
                        rows={4}
                        placeholder="Write dynamic sensory narrative of this allocation..."
                        className="w-full bg-[#121212] border border-neutral-800 p-3 text-xs focus:outline-none focus:border-luxury-bronze"
                      />
                    </div>

                    <div className="border border-neutral-900 bg-neutral-950/60 p-4 space-y-4">
                      <div className="font-mono text-[10px] text-luxury-bronze tracking-widest uppercase">Tasting Notes Structuring</div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block font-mono text-[8px] uppercase tracking-wider text-neutral-500 mb-1">Nose Bouquet</label>
                          <input
                            type="text"
                            value={editorProduct.tastingNotes?.nose || ""}
                            onChange={(e) => setEditorProduct({
                              ...editorProduct,
                              tastingNotes: { ...editorProduct.tastingNotes, nose: e.target.value } as any
                            })}
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[8px] uppercase tracking-wider text-neutral-500 mb-1">Palate & Mouthfeel</label>
                          <input
                            type="text"
                            value={editorProduct.tastingNotes?.palate || ""}
                            onChange={(e) => setEditorProduct({
                              ...editorProduct,
                              tastingNotes: { ...editorProduct.tastingNotes, palate: e.target.value } as any
                            })}
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                        <div>
                          <label className="block font-mono text-[8px] uppercase tracking-wider text-neutral-500 mb-1">Finish Persistence</label>
                          <input
                            type="text"
                            value={editorProduct.tastingNotes?.finish || ""}
                            onChange={(e) => setEditorProduct({
                              ...editorProduct,
                              tastingNotes: { ...editorProduct.tastingNotes, finish: e.target.value } as any
                            })}
                            className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 focus:outline-none focus:border-luxury-bronze"
                          />
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* SEO Optimization Area */}
                  <div className="bg-neutral-950 p-6 border border-neutral-900 space-y-4">
                    <h3 className="font-mono text-[10px] tracking-wider text-neutral-400 uppercase">Search Engine Optimization Metadata</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-mono text-[8px] text-neutral-500 mb-1 uppercase">SEO Meta Title</label>
                        <input
                          type="text"
                          value={editorProduct.seoTitle || ""}
                          onChange={(e) => setEditorProduct({ ...editorProduct, seoTitle: e.target.value })}
                          placeholder="e.g. Château Margaux 2015 Premier Grand Cru | Atlas Cellars"
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>
                      <div>
                        <label className="block font-mono text-[8px] text-neutral-500 mb-1 uppercase">SEO Meta Description</label>
                        <input
                          type="text"
                          value={editorProduct.seoDescription || ""}
                          onChange={(e) => setEditorProduct({ ...editorProduct, seoDescription: e.target.value })}
                          placeholder="Search engine synopsis..."
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Submission and auto-save notification */}
                  <div className="flex items-center justify-between border-t border-neutral-900 pt-6">
                    <span className="text-[10px] font-mono text-neutral-500 flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin text-neutral-700" /> Auto-saving draft enabled...
                    </span>
                    <button
                      type="submit"
                      disabled={isSaving}
                      className="bg-luxury-bronze hover:bg-white text-black text-xs font-mono uppercase tracking-widest px-8 py-3 flex items-center gap-2 font-medium"
                    >
                      {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                      Save Allocation Profile
                    </button>
                  </div>

                </form>
              </motion.div>
            )}

            {/* 4. ORDERS PIPELINE */}
            {activeTab === "orders" && (
              <motion.div
                key="orders"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="font-serif text-2xl font-light text-[#faf9f6]">Order Clearing Node</h2>
                  <p className="text-xs text-neutral-400 font-mono mt-1">Settle invoices, monitor blockchain nodes, and track deliveries.</p>
                </div>

                <div className="space-y-4">
                  {orders.map((ord) => (
                    <div key={ord.id} className="bg-[#0f0f0f] border border-neutral-800 p-5 md:p-6 grid grid-cols-1 md:grid-cols-4 gap-6 relative overflow-hidden">
                      
                      {/* Left Block */}
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs text-luxury-bronze font-bold">{ord.orderNumber}</span>
                          <span className="font-mono text-[9px] text-neutral-500">{new Date(ord.createdAt).toLocaleDateString()}</span>
                        </div>
                        <div className="font-serif text-sm">{ord.customerName}</div>
                        <div className="font-mono text-[10px] text-neutral-400 font-light">{ord.customerEmail}</div>
                        <div className="text-[10px] text-neutral-500 font-light leading-relaxed">
                          {ord.shippingAddress.street}, {ord.shippingAddress.city}, {ord.shippingAddress.state} {ord.shippingAddress.postalCode}, {ord.shippingAddress.country}
                        </div>
                      </div>

                      {/* Items Block */}
                      <div className="md:col-span-1 space-y-1">
                        <div className="font-mono text-[9px] uppercase text-neutral-500 tracking-wider">Purchased Items</div>
                        {ord.items.map((item, idx) => (
                          <div key={idx} className="text-xs font-light">
                            {item.quantity}x {item.name} <span className="font-mono text-[10px] text-neutral-500">({item.bottleSize})</span>
                          </div>
                        ))}
                        <div className="pt-2 font-mono text-xs text-luxury-bronze">
                          Total Paid: ${ord.total.toFixed(2)}
                        </div>
                      </div>

                      {/* Payment Status / Blockchain Monitoring */}
                      <div className="space-y-2">
                        <div className="font-mono text-[9px] uppercase text-neutral-500 tracking-wider">Transaction Settlement</div>
                        <div className="space-y-1">
                          <div className="text-xs flex items-center gap-1.5 font-mono">
                            {ord.paymentDetails.paymentMethod === "crypto" ? (
                              <>
                                <span className="bg-amber-950/30 text-amber-500 border border-amber-900/30 px-1 text-[9px]">
                                  {ord.paymentDetails.currency}
                                </span>
                                <span>{ord.paymentDetails.amountCrypto} coins</span>
                              </>
                            ) : (
                              <span className="bg-neutral-800 text-neutral-300 border border-neutral-700 px-1 text-[9px]">
                                CREDIT CARD
                              </span>
                            )}
                          </div>
                          
                          {ord.paymentDetails.paymentMethod === "crypto" && (
                            <div className="text-[9px] font-mono text-neutral-500 leading-tight break-all">
                              WALLET: {ord.paymentDetails.walletAddress}<br />
                              TX_HASH: {ord.paymentDetails.txHash || "PENDING BROADCAST"}
                            </div>
                          )}

                          <div className="flex items-center gap-2 mt-2">
                            <span className={`inline-block font-mono text-[9px] uppercase tracking-wider px-2 py-0.5 ${
                              ord.paymentDetails.paymentConfirmed ? "bg-emerald-950/30 text-emerald-400 border border-emerald-900/30" : "bg-amber-950/20 text-amber-500 border border-amber-900/20 animate-pulse"
                            }`}>
                              {ord.paymentDetails.paymentConfirmed ? "PAYMENT SETTLED" : "AWAITING MEMPOOL"}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* ERP Operations Advance */}
                      <div className="flex flex-col justify-between items-end gap-4 border-t md:border-t-0 md:border-l border-neutral-900 pt-4 md:pt-0 md:pl-6">
                        <div className="text-right w-full">
                          <div className="font-mono text-[9px] uppercase text-neutral-500 tracking-wider mb-1">Logistics Pipeline</div>
                          <span className={`inline-block font-mono text-[10px] uppercase tracking-widest bg-neutral-900 text-[#faf9f6] border border-neutral-800 px-2.5 py-1`}>
                            {ord.status}
                          </span>
                        </div>

                        <div className="flex flex-col w-full gap-2">
                          {/* Manual Blockchain Confirmation Simulation */}
                          {ord.paymentDetails.paymentMethod === "crypto" && !ord.paymentDetails.paymentConfirmed && (
                            <button
                              onClick={() => handleSimulateBlockchainReconciliation(ord.id)}
                              className="w-full text-center bg-amber-600 hover:bg-amber-500 text-black text-[10px] font-mono uppercase py-1.5 font-medium flex items-center justify-center gap-1.5"
                            >
                              <RefreshCw className="w-3.5 h-3.5" /> Reconcile Mempool
                            </button>
                          )}

                          {ord.status !== OrderStatus.Delivered && ord.status !== OrderStatus.Cancelled && ord.status !== OrderStatus.Refunded && (
                            <button
                              onClick={() => handleAdvanceOrderStatus(ord.id, ord.status)}
                              className="w-full text-center bg-luxury-bronze hover:bg-white text-black text-[10px] font-mono uppercase py-1.5 font-medium flex items-center justify-center gap-1"
                            >
                              Settle & Advance <ArrowRight className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 5. CRM TICKETING */}
            {activeTab === "crm" && (
              <motion.div
                key="crm"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-6"
              >
                {/* Tickets list */}
                <div className="md:col-span-1 bg-[#0f0f0f] border border-neutral-800 p-4 space-y-4">
                  <h3 className="font-serif text-lg tracking-tight border-b border-neutral-900 pb-2">Client Concierge Inbox</h3>
                  <div className="space-y-2">
                    {supportTickets.map((t) => (
                      <div
                        key={t.id}
                        onClick={() => setSelectedTicket(t)}
                        className={`p-3 border transition-colors cursor-pointer text-left ${selectedTicket?.id === t.id ? "bg-neutral-900 border-luxury-bronze" : "bg-black/30 border-neutral-900 hover:border-neutral-800"}`}
                      >
                        <div className="flex justify-between items-center text-[9px] font-mono text-neutral-500">
                          <span>{t.ticketNumber}</span>
                          <span className={`px-1.5 uppercase ${t.status === "Open" ? "text-amber-500 font-bold" : "text-neutral-400"}`}>{t.status}</span>
                        </div>
                        <h4 className="font-serif text-xs font-semibold mt-1 text-[#faf9f6]">{t.subject}</h4>
                        <div className="text-[10px] text-neutral-400 mt-1">{t.customerName}</div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Messages Panel */}
                <div className="md:col-span-2 bg-[#0f0f0f] border border-neutral-800 p-6 flex flex-col justify-between min-h-[450px]">
                  {selectedTicket ? (
                    <div className="flex flex-col justify-between h-full space-y-6">
                      
                      <div className="space-y-4">
                        <div className="border-b border-neutral-900 pb-3 flex justify-between items-center">
                          <div>
                            <span className="font-mono text-[10px] text-luxury-bronze uppercase">{selectedTicket.category}</span>
                            <h3 className="font-serif text-lg">{selectedTicket.subject}</h3>
                            <p className="text-[10px] text-neutral-400 font-mono">From: {selectedTicket.customerName} ({selectedTicket.customerEmail})</p>
                          </div>
                          <span className="font-mono text-xs text-neutral-500">{new Date(selectedTicket.createdAt).toLocaleDateString()}</span>
                        </div>

                        {/* Message log */}
                        <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2">
                          {selectedTicket.messages.map((m) => (
                            <div key={m.id} className={`flex flex-col max-w-[80%] ${m.sender === "customer" ? "mr-auto text-left" : "ml-auto text-right"}`}>
                              <span className="font-mono text-[8px] text-neutral-500 mb-1">
                                {m.sender === "customer" ? "CLIENT" : "MERCHANT"} // {new Date(m.timestamp).toLocaleTimeString()}
                              </span>
                              <div className={`p-3 text-xs ${m.sender === "customer" ? "bg-[#121212] border border-neutral-800 text-neutral-200" : "bg-neutral-900 text-luxury-bronze border border-neutral-800"}`}>
                                {m.text}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Replying */}
                      <div className="space-y-2 pt-4 border-t border-neutral-900">
                        <textarea
                          value={ticketReply}
                          onChange={(e) => setTicketReply(e.target.value)}
                          placeholder="Formulate private bespoke response..."
                          rows={3}
                          className="w-full bg-[#121212] border border-neutral-800 p-3 text-xs text-[#faf9f6] focus:outline-none focus:border-luxury-bronze"
                        />
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-mono text-neutral-500">concierge response channels active</span>
                          <button
                            onClick={() => handleReplyTicket(selectedTicket.id)}
                            className="bg-luxury-bronze text-black hover:bg-white text-xs font-mono uppercase tracking-wider px-4 py-2 font-medium"
                          >
                            Transmit Response
                          </button>
                        </div>
                      </div>

                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center text-center h-full text-neutral-500 font-mono text-xs">
                      <MessageSquare className="w-10 h-10 text-neutral-800 mb-2" />
                      Select a support ticket to respond to private client inquiries.
                    </div>
                  )}
                </div>
              </motion.div>
            )}

            {/* 6. MEDIA LIBRARY */}
            {activeTab === "media" && (
              <motion.div
                key="media"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="font-serif text-2xl font-light text-[#faf9f6]">Media Library Asset Catalog</h2>
                  <p className="text-xs text-neutral-400 font-mono mt-1">Self-hosted WebP drink imagery repository with automated SEO tagging.</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {media.map((med) => (
                    <div key={med.id} className="bg-[#0f0f0f] border border-neutral-800 p-3 flex flex-col justify-between group relative overflow-hidden">
                      <div className="h-40 bg-neutral-950 flex items-center justify-center overflow-hidden border border-neutral-900 relative">
                        <img 
                          src={med.url} 
                          alt={med.name} 
                          className="object-cover h-full w-full group-hover:scale-105 transition-transform duration-300"
                          referrerPolicy="no-referrer"
                        />
                        <span className="absolute top-2 left-2 bg-black/60 font-mono text-[8px] px-1.5 py-0.5 text-luxury-bronze">
                          {med.folder.toUpperCase()}
                        </span>
                      </div>
                      <div className="mt-2 space-y-1 text-left">
                        <div className="font-mono text-[9px] text-[#faf9f6] truncate">{med.name}</div>
                        <div className="flex justify-between text-[8px] font-mono text-neutral-500">
                          <span>{med.size}</span>
                          <span>WEBP OPTIMISED</span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Simulated Upload Slot */}
                  <div className="bg-[#0d0d0d] border border-dashed border-neutral-800 p-6 flex flex-col items-center justify-center text-center h-56 min-h-[14rem] cursor-pointer hover:border-luxury-bronze transition-colors">
                    <FolderOpen className="w-8 h-8 text-neutral-700 mb-2" />
                    <span className="font-mono text-[10px] text-neutral-400 uppercase tracking-widest">Upload Asset</span>
                    <span className="text-[8px] text-neutral-600 font-mono mt-1">Drag-and-drop or click to index. Max 5MB file.</span>
                  </div>
                </div>
              </motion.div>
            )}

            {/* 7. REAL-TIME AUDIT LOGS */}
            {activeTab === "logs" && (
              <motion.div
                key="logs"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="font-serif text-2xl font-light text-[#faf9f6]">System Cryptographic Audit Log</h2>
                  <p className="text-xs text-neutral-400 font-mono mt-1">Immutable record of merchant operations, administrative sessions, and order clearing actions.</p>
                </div>

                <div className="bg-[#0f0f0f] border border-neutral-800 p-4 font-mono text-[11px] leading-relaxed text-neutral-300 space-y-2 max-h-[500px] overflow-y-auto">
                  {auditLogs.map((log) => (
                    <div key={log.id} className="border-b border-neutral-900 pb-2 flex flex-col md:flex-row justify-between gap-2">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-luxury-bronze font-bold">[{log.action.toUpperCase()}]</span>
                          <span className="text-neutral-500">// {new Date(log.timestamp).toLocaleString()}</span>
                        </div>
                        <p className="text-neutral-400 font-light text-xs">{log.details}</p>
                      </div>
                      <div className="text-right text-[10px] text-neutral-500 font-light">
                        USER: {log.user}<br />
                        IP: {log.ipAddress}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}

            {/* 8. SETTINGS CONFIGURATION */}
            {activeTab === "settings" && (
              <motion.div
                key="settings"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="font-serif text-2xl font-light text-[#faf9f6]">Compliance & Server Node Settings</h2>
                  <p className="text-xs text-neutral-400 font-mono mt-1">Configure automated calculations, regional rules, and cryptographic payouts.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
                  
                  {/* Financial configuration */}
                  <div className="bg-[#0f0f0f] border border-neutral-800 p-6 space-y-4 text-left">
                    <h3 className="font-serif text-lg tracking-tight border-b border-neutral-900 pb-2">Checkout Calculations</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block font-mono text-[9px] uppercase text-neutral-400 mb-1">DTC Sales Tax Rate (%)</label>
                        <input
                          type="number"
                          value={settings.taxRatePercentage}
                          onChange={(e) => onUpdateSettings({ ...settings, taxRatePercentage: Number(e.target.value) })}
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 font-mono focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>
                      <div>
                        <label className="block font-mono text-[9px] uppercase text-neutral-400 mb-1">Flat Shipping ($)</label>
                        <input
                          type="number"
                          value={settings.flatShippingCost}
                          onChange={(e) => onUpdateSettings({ ...settings, flatShippingCost: Number(e.target.value) })}
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 font-mono focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-mono text-[9px] uppercase text-neutral-400 mb-1">Free Shipping Threshold ($)</label>
                      <input
                        type="number"
                        value={settings.freeShippingThreshold}
                        onChange={(e) => onUpdateSettings({ ...settings, freeShippingThreshold: Number(e.target.value) })}
                        className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 font-mono focus:outline-none focus:border-luxury-bronze"
                      />
                    </div>
                  </div>

                  {/* Compliance configuration */}
                  <div className="bg-[#0f0f0f] border border-neutral-800 p-6 space-y-4 text-left">
                    <h3 className="font-serif text-lg tracking-tight border-b border-neutral-900 pb-2">Compliance Gateway</h3>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <div className="text-xs font-mono uppercase text-neutral-300">Enforce Age Verification</div>
                        <div className="text-[10px] text-neutral-500">Require birth date check before entry.</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={settings.enforceAgeVerification}
                        onChange={(e) => onUpdateSettings({ ...settings, enforceAgeVerification: e.target.checked })}
                        className="w-4 h-4 accent-luxury-bronze bg-neutral-900 border-neutral-800 focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block font-mono text-[9px] uppercase text-neutral-400 mb-1">Standard Drinking Age Requirement</label>
                      <input
                        type="number"
                        value={settings.legalDrinkingAge}
                        onChange={(e) => onUpdateSettings({ ...settings, legalDrinkingAge: Number(e.target.value) })}
                        className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 font-mono focus:outline-none focus:border-luxury-bronze"
                      />
                    </div>
                  </div>

                  {/* Cryptocurrency wallets */}
                  <div className="bg-[#0f0f0f] border border-neutral-800 p-6 space-y-4 text-left md:col-span-2">
                    <h3 className="font-serif text-lg tracking-tight border-b border-neutral-900 pb-2">Mempool Payout Wallets</h3>
                    
                    <div className="space-y-3">
                      <div>
                        <label className="block font-mono text-[9px] uppercase text-neutral-400 mb-1">Bitcoin (BTC) Receive Address</label>
                        <input
                          type="text"
                          value={settings.btcWalletAddress}
                          onChange={(e) => onUpdateSettings({ ...settings, btcWalletAddress: e.target.value })}
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 font-mono focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>
                      <div>
                        <label className="block font-mono text-[9px] uppercase text-neutral-400 mb-1">Tether (USDT) Receive Address</label>
                        <input
                          type="text"
                          value={settings.usdtWalletAddress}
                          onChange={(e) => onUpdateSettings({ ...settings, usdtWalletAddress: e.target.value })}
                          className="w-full bg-[#121212] border border-neutral-800 text-xs p-2 font-mono focus:outline-none focus:border-luxury-bronze"
                        />
                      </div>
                    </div>
                  </div>

                </div>
              </motion.div>
            )}

          </AnimatePresence>
        </main>
      </div>

    </div>
  );
}
