/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { motion } from "motion/react";
import { Shield, Check, AlertTriangle } from "lucide-react";

interface AgeGateProps {
  onVerify: (country: string, age: number) => void;
}

export default function AgeGate({ onVerify }: AgeGateProps) {
  const [country, setCountry] = useState("US");
  const [day, setDay] = useState("");
  const [month, setMonth] = useState("");
  const [year, setYear] = useState("");
  const [error, setError] = useState("");

  const countries = [
    { code: "US", name: "United States (21+)", minAge: 21 },
    { code: "GB", name: "United Kingdom (18+)", minAge: 18 },
    { code: "FR", name: "France (18+)", minAge: 18 },
    { code: "JP", name: "Japan (20+)", minAge: 20 },
    { code: "CA", name: "Canada (19+)", minAge: 19 },
    { code: "DE", name: "Germany (18+)", minAge: 18 }
  ];

  const handleVerify = (e: React.FormEvent) => {
    e.preventDefault();
    if (!day || !month || !year) {
      setError("Please complete your full date of birth.");
      return;
    }

    const birthDate = new Date(Number(year), Number(month) - 1, Number(day));
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    const selectedCountry = countries.find(c => c.code === country);
    const minAge = selectedCountry ? selectedCountry.minAge : 21;

    if (isNaN(age) || age < 0 || year.length < 4) {
      setError("Please enter a valid birth year.");
      return;
    }

    if (age >= minAge) {
      onVerify(country, age);
    } else {
      setError(`Access denied. You must be at least ${minAge} to enter in your region.`);
    }
  };

  return (
    <div id="age-gate-container" className="fixed inset-0 z-50 flex items-center justify-center bg-[#070707] text-[#faf9f6] p-4">
      {/* Background elegant abstract pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(197,168,128,0.05)_0%,transparent_80%)]" />
      
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="w-full max-w-lg bg-[#0d0d0d] border border-neutral-800 p-8 md:p-12 relative overflow-hidden shadow-2xl"
      >
        <div className="absolute top-0 left-0 w-12 h-[1px] bg-luxury-bronze" />
        <div className="absolute top-0 left-0 w-[1px] h-12 bg-luxury-bronze" />
        
        <div className="text-center mb-8">
          <div className="font-mono text-[10px] tracking-[0.3em] text-luxury-bronze uppercase mb-4">
            Secured Allocation Registry
          </div>
          <h1 className="font-serif text-3xl md:text-4xl tracking-tight mb-2">
            ATLAS CELLARS
          </h1>
          <p className="text-xs text-neutral-400 font-light max-w-sm mx-auto">
            Independent Fine Wines & Curated Spirits Merchant. Entrance is restricted to legal age collectors.
          </p>
        </div>

        <form onSubmit={handleVerify} className="space-y-6">
          <div>
            <label className="block font-mono text-[10px] tracking-wider uppercase text-neutral-400 mb-2">
              Select Jurisdiction
            </label>
            <select
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="w-full bg-[#121212] border border-neutral-800 text-sm p-3 text-[#faf9f6] focus:outline-none focus:border-luxury-bronze font-light"
            >
              {countries.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-mono text-[10px] tracking-wider uppercase text-neutral-400 mb-2">
              Date of Birth
            </label>
            <div className="grid grid-cols-3 gap-3">
              <input
                type="number"
                placeholder="DD"
                min="1"
                max="31"
                value={day}
                onChange={(e) => { setDay(e.target.value); setError(""); }}
                className="bg-[#121212] border border-neutral-800 text-center p-3 text-sm focus:outline-none focus:border-luxury-bronze placeholder-neutral-700"
              />
              <input
                type="number"
                placeholder="MM"
                min="1"
                max="12"
                value={month}
                onChange={(e) => { setMonth(e.target.value); setError(""); }}
                className="bg-[#121212] border border-neutral-800 text-center p-3 text-sm focus:outline-none focus:border-luxury-bronze placeholder-neutral-700"
              />
              <input
                type="number"
                placeholder="YYYY"
                min="1900"
                max="2026"
                value={year}
                onChange={(e) => { setYear(e.target.value); setError(""); }}
                className="bg-[#121212] border border-neutral-800 text-center p-3 text-sm focus:outline-none focus:border-luxury-bronze placeholder-neutral-700"
              />
            </div>
          </div>

          {error && (
            <div className="flex items-start gap-2 text-rose-400 text-xs font-light bg-rose-950/20 border border-rose-900/40 p-3">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-luxury-bronze hover:bg-white text-black font-mono text-[11px] tracking-[0.2em] uppercase py-3.5 transition-colors duration-300 font-medium"
          >
            Verify & Enter Cellar
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-neutral-900 text-center">
          <p className="text-[10px] text-neutral-500 font-light leading-relaxed max-w-xs mx-auto">
            * Atlas Cellars strictly advocates responsible drinking. Enjoy of wine and whiskey as fine art, with sophisticated moderation.
          </p>
        </div>
      </motion.div>
    </div>
  );
}
