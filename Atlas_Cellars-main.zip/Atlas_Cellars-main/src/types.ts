/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum ProductStatus {
  Draft = "Draft",
  Published = "Published",
  Hidden = "Hidden",
  OutOfStock = "OutOfStock",
  Archived = "Archived"
}

export enum OrderStatus {
  AwaitingPayment = "Awaiting Payment",
  PaymentReceived = "Payment Received",
  Processing = "Processing",
  Packed = "Packed",
  ReadyForDispatch = "Ready for Dispatch",
  Shipped = "Shipped",
  Delivered = "Delivered",
  Refunded = "Refunded",
  Cancelled = "Cancelled",
  Archived = "Archived"
}

export enum CryptoCurrency {
  BTC = "BTC",
  USDT = "USDT"
}

export interface TastingNote {
  nose: string;
  palate: string;
  finish: string;
}

export interface PriceHistoryEntry {
  date: string;
  price: number;
  salePrice?: number;
}

export interface InventoryHistoryEntry {
  date: string;
  change: number;
  reason: string;
  updatedBy: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  producer: string;
  region: string;
  country: string;
  beverageType: string;
  vintage?: string; // e.g. "2018", "NV" (Non-Vintage)
  abv: number; // alcohol by volume
  bottleSize: string; // e.g. "750ml", "70cl"
  tastingNotes: TastingNote;
  foodPairings: string[];
  servingTemp?: string; // e.g. "16-18°C"
  awards: string[];
  description: string;
  imageUrl: string;
  videoUrl?: string;
  pdfFactSheetUrl?: string;
  price: number;
  salePrice?: number;
  inventoryQuantity: number;
  status: ProductStatus;
  scheduledReleaseDate?: string;
  supplierReference?: string;
  lowStockAlertThreshold: number;
  priceHistory: PriceHistoryEntry[];
  inventoryHistory: InventoryHistoryEntry[];
  seoTitle?: string;
  seoDescription?: string;
  versionHistory?: { version: number; date: string; changedBy: string; notes: string }[];
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  bottleSize: string;
  sku: string;
}

export interface ShippingAddress {
  name: string;
  street: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
}

export interface PaymentDetails {
  paymentMethod: "crypto" | "credit_card";
  currency?: CryptoCurrency;
  usdtNetwork?: "ERC-20" | "TRC-20" | "BSC";
  walletAddress?: string;
  amountCrypto?: number;
  txHash?: string;
  orderReference: string;
  paymentConfirmed: boolean;
  paymentConfirmedAt?: string;
  countdownMinutesRemaining?: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customerName: string;
  customerEmail: string;
  items: OrderItem[];
  shippingAddress: ShippingAddress;
  status: OrderStatus;
  subtotal: number;
  shippingCost: number;
  tax: number;
  discount: number;
  promoCodeUsed?: string;
  total: number;
  paymentDetails: PaymentDetails;
  notes?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
  ipAddress: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  createdAt: string;
  customerName: string;
  customerEmail: string;
  category: "Order Issue" | "Payment" | "Product Inquiry" | "Refund Request" | "Other";
  subject: string;
  status: "Open" | "In Progress" | "Resolved" | "Closed";
  messages: {
    id: string;
    sender: "customer" | "merchant";
    timestamp: string;
    text: string;
  }[];
}

export interface MediaAsset {
  id: string;
  name: string;
  url: string;
  size: string;
  type: string;
  folder: string;
  uploadedAt: string;
  seoAltText?: string;
}

export interface Coupon {
  code: string;
  discountType: "percentage" | "fixed";
  amount: number;
  isActive: boolean;
  expiryDate?: string;
}
