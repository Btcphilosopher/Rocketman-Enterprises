/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShoppingBag, Heart, Shield, Lock, Menu, X, ArrowRight, Check,
  CircleDollarSign, RotateCcw, AlertCircle, HelpCircle, ExternalLink
} from "lucide-react";
import AgeGate from "./components/AgeGate";
import SellerDashboard from "./components/SellerDashboard";
import Storefront from "./components/Storefront";
import { Product, Order, AuditLog, SupportTicket, MediaAsset } from "./types";

export default function App() {
  // Global Compliance
  const [ageVerified, setAgeVerified] = useState<boolean>(false);
  const [showAgeGate, setShowAgeGate] = useState<boolean>(true);

  // Active Context Switcher ("storefront" vs "merchant_erp")
  const [activeContext, setActiveContext] = useState<"storefront" | "merchant_erp">("storefront");
  
  // Storefront route state ("home", "shop", "concierge", "product", "wishlist", "support", "checkout", "order-confirmation")
  const [storefrontPath, setStorefrontPath] = useState<string>("home");

  // API State Synchronization
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [media, setMedia] = useState<MediaAsset[]>([]);
  const [settings, setSettings] = useState<any>({
    taxRatePercentage: 8.5,
    flatShippingCost: 25,
    freeShippingThreshold: 500,
    enforceAgeVerification: true,
    legalDrinkingAge: 21,
    btcWalletAddress: "bc1qxy2kg3ut6g3xptq69c766l87ctp0zl5v867chk",
    usdtWalletAddress: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F"
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Cart & Wishlist Local States
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [wishlist, setWishlist] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);

  // Load compliance state on initial mount
  useEffect(() => {
    const localGate = localStorage.getItem("atlas_age_verified");
    if (localGate === "true") {
      setAgeVerified(true);
      setShowAgeGate(false);
    }
  }, []);

  // Fetch all initial data from our Express server APIs
  useEffect(() => {
    async function loadAllData() {
      try {
        setIsLoading(true);
        
        // Products
        const prodRes = await fetch("/api/products");
        const prodData = await prodRes.json();
        setProducts(prodData);

        // Orders
        const ordRes = await fetch("/api/orders");
        const ordData = await ordRes.json();
        setOrders(ordData);

        // Audit Logs
        const auditRes = await fetch("/api/analytics/audit-logs");
        const auditData = await auditRes.json();
        setAuditLogs(auditData);

        // Support Tickets
        const ticketRes = await fetch("/api/support-tickets");
        const ticketData = await ticketRes.json();
        setSupportTickets(ticketData);

        // Media List
        const mediaRes = await fetch("/api/media");
        const mediaData = await mediaRes.json();
        setMedia(mediaData);

        // Settings
        const settingsRes = await fetch("/api/settings");
        const settingsData = await settingsRes.json();
        setSettings(settingsData);

        setIsLoading(false);
      } catch (err) {
        console.error("Critical: ERP state loop failed to synchronize:", err);
        setIsLoading(false);
      }
    }

    if (ageVerified) {
      loadAllData();
    }
  }, [ageVerified]);

  // Sync state modifications back to our local disk backend
  const handleUpdateProducts = async (newProducts: Product[]) => {
    setProducts(newProducts);
    // Write changes to backend (simulate via updating a specific catalog listing or let server handle bulk)
    try {
      await fetch("/api/products/bulk-update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ products: newProducts })
      });
    } catch (e) {
      console.error("Failed to backup bulk inventory updates to server disk:", e);
    }
  };

  const handleUpdateOrders = async (newOrders: Order[]) => {
    setOrders(newOrders);
  };

  const handleUpdateTickets = async (newTickets: SupportTicket[]) => {
    setSupportTickets(newTickets);
  };

  const handleUpdateSettings = async (newSettings: any) => {
    setSettings(newSettings);
    try {
      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSettings)
      });
    } catch (e) {
      console.error("Failed to update config keys:", e);
    }
  };

  const handleAddTicket = (ticket: SupportTicket) => {
    setSupportTickets([ticket, ...supportTickets]);
  };

  const handlePlaceOrder = (order: Order) => {
    setOrders([order, ...orders]);
  };

  const handleAgeVerified = (country: string, age: number) => {
    localStorage.setItem("atlas_age_verified", "true");
    setAgeVerified(true);
    setShowAgeGate(false);
  };

  // Cart helper quantities
  const totalCartItemsCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => {
    const price = item.product.salePrice !== undefined ? item.product.salePrice : item.product.price;
    return sum + (price * item.quantity);
  }, 0);

  if (showAgeGate) {
    return <AgeGate onVerify={handleAgeVerified} />;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#070707] flex flex-col items-center justify-center text-white font-mono gap-4">
        <div className="w-8 h-8 border-t-2 border-luxury-bronze border-solid rounded-full animate-spin" />
        <span className="text-xs uppercase tracking-widest text-neutral-400">Synchronising Vault Databases...</span>
      </div>
    );
  }

  return (
    <div id="atlas-root-framework" className="min-h-screen flex flex-col bg-[#050505] selection:bg-luxury-bronze selection:text-black">
      
      {activeContext === "merchant_erp" ? (
        // ERP Merchant Context view
        <SellerDashboard
          products={products}
          orders={orders}
          auditLogs={auditLogs}
          supportTickets={supportTickets}
          media={media}
          settings={settings}
          onUpdateProducts={handleUpdateProducts}
          onUpdateOrders={handleUpdateOrders}
          onUpdateTickets={handleUpdateTickets}
          onUpdateMedia={setMedia}
          onUpdateSettings={handleUpdateSettings}
          onToggleDashboard={() => setActiveContext("storefront")}
        />
      ) : (
        // Customer Storefront Context view
        <div className="flex flex-col min-h-screen">
          
          {/* Customer Global Navigation Bar */}
          <nav className="border-b border-neutral-900 bg-black/85 backdrop-blur-md sticky top-0 z-40 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-8">
              <button 
                onClick={() => setStorefrontPath("home")}
                className="font-display font-medium text-lg tracking-[0.2em] uppercase text-white hover:text-luxury-bronze transition-colors text-left"
              >
                ATLAS CELLARS
              </button>
              
              <div className="hidden md:flex items-center gap-6 text-xs font-mono tracking-wider uppercase text-neutral-400">
                <button onClick={() => setStorefrontPath("shop")} className={`hover:text-luxury-bronze transition-colors ${storefrontPath === "shop" ? "text-luxury-bronze font-bold" : ""}`}>
                  The Vault
                </button>
                <button onClick={() => setStorefrontPath("concierge")} className={`hover:text-luxury-bronze transition-colors ${storefrontPath === "concierge" ? "text-luxury-bronze font-bold" : ""}`}>
                  Sommelier Lounge
                </button>
                <button onClick={() => setStorefrontPath("support")} className={`hover:text-luxury-bronze transition-colors ${storefrontPath === "support" ? "text-luxury-bronze font-bold" : ""}`}>
                  Concierge Support
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              
              {/* PORTAL GATEWAY BUTTON (Toggles ERP admin dashboard) */}
              <button
                onClick={() => setActiveContext("merchant_erp")}
                className="bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-luxury-bronze px-3.5 py-1.5 rounded-sm font-mono text-[10px] uppercase tracking-widest flex items-center gap-2 transition-all"
                title="Open ERP Operations Node"
              >
                <Lock className="w-3 h-3 text-luxury-bronze" /> Merchant Portal
              </button>

              <button 
                onClick={() => setStorefrontPath("wishlist")}
                className={`relative text-neutral-400 hover:text-rose-500 transition-colors ${wishlist.length > 0 ? "text-rose-500" : ""}`}
                title="View reserved wishlist"
              >
                <Heart className="w-4 h-4 fill-current" />
                {wishlist.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-rose-500 text-white rounded-full text-[8px] font-sans font-bold w-3.5 h-3.5 flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </button>

              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative text-neutral-400 hover:text-luxury-bronze transition-colors"
                title="View acquisition summary"
              >
                <ShoppingBag className="w-4 h-4" />
                {totalCartItemsCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-luxury-bronze text-black rounded-full text-[8px] font-sans font-bold w-3.5 h-3.5 flex items-center justify-center">
                    {totalCartItemsCount}
                  </span>
                )}
              </button>

            </div>
          </nav>

          {/* Quick Cart Sidebar Slider Overlay */}
          <AnimatePresence>
            {isCartOpen && (
              <>
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 0.7 }}
                  exit={{ opacity: 0 }}
                  onClick={() => setIsCartOpen(false)}
                  className="fixed inset-0 bg-black z-50 cursor-pointer"
                />
                <motion.aside 
                  initial={{ x: "100%" }}
                  animate={{ x: 0 }}
                  exit={{ x: "100%" }}
                  transition={{ type: "tween", duration: 0.3 }}
                  className="fixed top-0 right-0 h-full w-full max-w-md bg-[#0d0d0d] border-l border-neutral-900 z-50 p-6 flex flex-col justify-between"
                >
                  <div className="space-y-6">
                    <div className="flex items-center justify-between border-b border-neutral-900 pb-4">
                      <h3 className="font-serif text-xl font-light text-white uppercase tracking-wider">Acquisitions Cart</h3>
                      <button onClick={() => setIsCartOpen(false)} className="text-neutral-400 hover:text-luxury-bronze">
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    {cart.length === 0 ? (
                      <div className="text-center py-20 font-mono text-xs text-neutral-500">
                        Acquisitions cart is empty.
                      </div>
                    ) : (
                      <div className="space-y-4 max-h-[60vh] overflow-y-auto pr-2">
                        {cart.map((item) => {
                          const price = item.product.salePrice !== undefined ? item.product.salePrice : item.product.price;
                          return (
                            <div key={item.product.id} className="flex justify-between gap-4 border-b border-neutral-900 pb-3 text-left">
                              <div className="space-y-0.5">
                                <h4 className="font-serif text-sm font-semibold text-white">{item.product.name}</h4>
                                <p className="text-[10px] text-neutral-500 font-mono">
                                  {item.product.producer} // {item.product.bottleSize}
                                </p>
                                <div className="text-xs font-mono text-luxury-bronze">
                                  ${price} x {item.quantity}
                                </div>
                              </div>
                              <div className="flex flex-col justify-between items-end">
                                <button 
                                  onClick={() => setCart(cart.filter(i => i.product.id !== item.product.id))}
                                  className="text-neutral-600 hover:text-rose-500 text-[10px] uppercase font-mono"
                                >
                                  Remove
                                </button>
                                <div className="flex items-center border border-neutral-800 bg-black text-xs">
                                  <button onClick={() => setCart(cart.map(i => i.product.id === item.product.id ? { ...i, quantity: Math.max(1, i.quantity - 1) } : i))} className="px-2 py-0.5 border-r border-neutral-800 text-neutral-400 hover:text-white">-</button>
                                  <span className="px-3 font-mono text-[#faf9f6]">{item.quantity}</span>
                                  <button onClick={() => setCart(cart.map(i => i.product.id === item.product.id ? { ...i, quantity: i.quantity + 1 } : i))} className="px-2 py-0.5 border-l border-neutral-800 text-neutral-400 hover:text-white">+</button>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>

                  {cart.length > 0 && (
                    <div className="border-t border-neutral-900 pt-6 space-y-4 text-left">
                      <div className="flex justify-between font-mono text-sm">
                        <span className="text-neutral-500 uppercase">Vault Subtotal</span>
                        <span className="text-luxury-bronze font-bold">${cartSubtotal.toFixed(2)}</span>
                      </div>
                      <p className="text-[10px] font-mono text-neutral-500 leading-tight">
                        * Excludes shipping, duties, and regional sales tax calculated on clearing.
                      </p>
                      <button
                        onClick={() => { setIsCartOpen(false); setStorefrontPath("checkout"); }}
                        className="w-full bg-luxury-bronze hover:bg-white text-black font-mono text-xs tracking-widest uppercase py-4 font-semibold text-center block transition-colors"
                      >
                        Proceed to Settlement Dispatch
                      </button>
                    </div>
                  )}
                </motion.aside>
              </>
            )}
          </AnimatePresence>

          {/* Render storefront page */}
          <div className="flex-1">
            <Storefront
              products={products}
              orders={orders}
              supportTickets={supportTickets}
              settings={settings}
              cart={cart}
              wishlist={wishlist}
              currentPath={storefrontPath}
              onUpdateCart={setCart}
              onUpdateWishlist={setWishlist}
              onPlaceOrder={handlePlaceOrder}
              onNavigate={setStorefrontPath}
              onAddTicket={handleAddTicket}
            />
          </div>

          {/* Storefront Footer */}
          <footer className="bg-[#080808] border-t border-neutral-900 px-6 py-12 md:py-16 text-left">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
              
              <div className="space-y-4">
                <h4 className="font-display font-medium text-sm tracking-wider uppercase text-white">ATLAS CELLARS</h4>
                <p className="text-[11px] text-neutral-400 font-light leading-relaxed">
                  DTC Premium Drinks Allocations. Self-hosted cryptocurrency mempool accounting integrations. Strictly verified age-restricted operations.
                </p>
                <div className="flex items-center gap-1 font-mono text-[9px] text-emerald-500 bg-emerald-950/20 border border-emerald-900/30 p-2 w-fit">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" /> MEMPOOL NODE: ACTIVE (21ms)
                </div>
              </div>

              <div className="space-y-3">
                <h5 className="font-mono text-[10px] tracking-widest uppercase text-neutral-500">Retail Desk</h5>
                <ul className="space-y-1.5 text-xs text-neutral-400 font-mono">
                  <li><button onClick={() => setStorefrontPath("shop")} className="hover:text-luxury-bronze transition-colors">The Vault</button></li>
                  <li><button onClick={() => setStorefrontPath("concierge")} className="hover:text-luxury-bronze transition-colors">Sommelier Lounge</button></li>
                  <li><button onClick={() => setStorefrontPath("support")} className="hover:text-luxury-bronze transition-colors">Concierge Care</button></li>
                </ul>
              </div>

              <div className="space-y-3">
                <h5 className="font-mono text-[10px] tracking-widest uppercase text-neutral-500">Private Operations</h5>
                <ul className="space-y-1.5 text-xs text-neutral-400 font-mono">
                  <li><button onClick={() => setActiveContext("merchant_erp")} className="hover:text-luxury-bronze transition-colors flex items-center gap-1.5"><Lock className="w-3.5 h-3.5" /> ERP Node Login</button></li>
                  <li><span className="text-neutral-500">TLS CRYPTO CORE</span></li>
                  <li><span className="text-neutral-500">POSTGRES ENGINE: ACTIVE</span></li>
                </ul>
              </div>

              <div className="space-y-3">
                <h5 className="font-mono text-[10px] tracking-widest uppercase text-neutral-500">Terms &amp; Compliance</h5>
                <p className="text-[10px] text-neutral-500 leading-relaxed font-light">
                  Atlas Cellars operates in strict accordance with national and regional legal age requirements. Deliveries are executed via cold-chain courier and require signature upon receipt. Portions of this platform simulate cryptocurrency payout loops safely inside private sandboxed environments.
                </p>
              </div>

            </div>

            <div className="max-w-7xl mx-auto border-t border-neutral-900 mt-12 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-[10px] font-mono text-neutral-500">
              <div>© 2026 ATLAS CELLARS. AMERICAN HYPERMODERN MERCHANTS.</div>
              <div className="flex items-center gap-1">
                SECURED BY COLD-CHAIN WALLETS // SHA-256 COMPLIANT
              </div>
            </div>
          </footer>

        </div>
      )}

    </div>
  );
}
