/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";
import { Product, ProductStatus, Order, OrderStatus, CryptoCurrency, AuditLog, SupportTicket, MediaAsset, Coupon } from "./src/types.js";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Path to persist mock database state
const DB_FILE = path.join(process.cwd(), "src", "database.json");

// Helper to load or initialize the database
function loadDatabase() {
  const defaultProducts: Product[] = [
    {
      id: "prod-1",
      sku: "WIN-CH-MARG-2015",
      name: "Château Margaux 2015 Premier Grand Cru Classé",
      producer: "Château Margaux",
      region: "Margaux, Bordeaux",
      country: "France",
      beverageType: "Wine",
      vintage: "2015",
      abv: 13.5,
      bottleSize: "750ml",
      tastingNotes: {
        nose: "Intense blackberry, violet, sweet cedar, and graphite.",
        palate: "Unbelievably silky tannins with layers of pure cassis, red currant, and black tea.",
        finish: "Symphonic, lasting over a minute with pristine freshness and minerality."
      },
      foodPairings: ["Roast Rack of Lamb", "Truffle Ribeye Steak", "Aged Comté Cheese"],
      servingTemp: "16-18°C",
      awards: ["100 Points - Robert Parker", "100 Points - Wine Spectator", "Wine of the Year 2015"],
      description: "A legendary vintage of Château Margaux. This 2015 represents the pinnacle of architectural precision in winemaking. Elegant, deep, and immortal, it celebrates the winery's bicentennial with unprecedented structural integrity and perfume.",
      imageUrl: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80",
      price: 1850,
      inventoryQuantity: 8,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 2,
      priceHistory: [
        { date: "2026-01-01", price: 1750 },
        { date: "2026-04-15", price: 1850 }
      ],
      inventoryHistory: [
        { date: "2026-01-01", change: 10, reason: "Initial shipment", updatedBy: "System" }
      ],
      seoTitle: "Chateau Margaux 2015 Grand Cru Classé | Atlas Cellars",
      seoDescription: "Secure a flawless bottle of Château Margaux 2015. Rated 100 points. Worldwide premium temperature-controlled delivery from Atlas Cellars."
    },
    {
      id: "prod-2",
      sku: "SPI-WH-MACA-18",
      name: "The Macallan 18 Year Old Sherry Oak",
      producer: "The Macallan Distillery",
      region: "Speyside",
      country: "Scotland",
      beverageType: "Spirits",
      vintage: "2023 Release",
      abv: 43.0,
      bottleSize: "700ml",
      tastingNotes: {
        nose: "Dried fruits and ginger, with hints of vanilla and cinnamon.",
        palate: "Rich, smooth, with intense toasted oak, clove, dried orange peel, and rich spice.",
        finish: "Lingering dried fruits, sweet ginger, and subtle wood smoke."
      },
      foodPairings: ["Dark Chocolate Fondant", "Glazed Pecans", "Roast Venison"],
      servingTemp: "18-20°C",
      awards: ["Gold Medal - San Francisco World Spirits Competition", "95 Points - Whisky Advocate"],
      description: "A robust and extraordinarily complex Speyside single malt, matured exclusively in hand-selected Sherry-seasoned oak casks from Jerez, Spain. This legendary liquid possesses an iconic natural amber mahogany hue.",
      imageUrl: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=800&q=80",
      price: 480,
      inventoryQuantity: 15,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 3,
      priceHistory: [
        { date: "2026-01-01", price: 460 },
        { date: "2026-05-10", price: 480 }
      ],
      inventoryHistory: [
        { date: "2026-01-01", change: 20, reason: "Initial stock", updatedBy: "System" }
      ]
    },
    {
      id: "prod-3",
      sku: "CHA-DP-DOMP-2012",
      name: "Dom Pérignon Vintage 2012 Brut",
      producer: "Dom Pérignon",
      region: "Champagne",
      country: "France",
      beverageType: "Champagne",
      vintage: "2012",
      abv: 12.5,
      bottleSize: "750ml",
      tastingNotes: {
        nose: "Complex harmony of green-gold mango, melon, and pineapple, yielding to toasted brioche.",
        palate: "Vibrant and tactile, explosive energy with an elegant chalky precision and lemon-zest zestiness.",
        finish: "Saline, structural, and extraordinarily persistent with a sophisticated smoke accent."
      },
      foodPairings: ["Fresh Oysters", "Seared Sea Scallops", "Beluga Caviar"],
      servingTemp: "8-10°C",
      awards: ["98 Points - Antonio Galloni", "97 Points - Wine Spectator"],
      description: "A triumph of contrasting forces. The 2012 vintage is structural, rich, and dynamic, showcasing the dual energy of Chardonnay and Pinot Noir harvested during an intensely dramatic weather season.",
      imageUrl: "https://images.unsplash.com/photo-1512503254922-b5ca32047d9b?auto=format&fit=crop&w=800&q=80",
      price: 260,
      salePrice: 245,
      inventoryQuantity: 24,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 5,
      priceHistory: [
        { date: "2026-01-01", price: 260, salePrice: 245 }
      ],
      inventoryHistory: [
        { date: "2026-01-01", change: 30, reason: "Imported from Reims", updatedBy: "System" }
      ]
    },
    {
      id: "prod-4",
      sku: "SPI-BO-PAPP-15",
      name: "Pappy Van Winkle 15 Year Old Family Reserve Kentucky Straight Bourbon",
      producer: "Old Rip Van Winkle Distillery",
      region: "Kentucky",
      country: "United States",
      beverageType: "Spirits",
      vintage: "2024 Bottling",
      abv: 53.5,
      bottleSize: "750ml",
      tastingNotes: {
        nose: "Sweet aromas of caramel, hazelnut, vanilla, and dark cherry wood.",
        palate: "Smooth wheat profile with deep oak, leather, rich dark chocolate, and spicy toasted maple.",
        finish: "Long, elegant finish of sweet honeyed oak, spice, and warm molasses."
      },
      foodPairings: ["Prime Rib Eye Roast", "Pecan Pie", "Artisanal Blue Cheese"],
      servingTemp: "18-20°C",
      awards: ["99 Points - Beverage Testing Institute", "Best Bourbon - World Whiskies Awards"],
      description: "An incredibly rare, sought-after wheated bourbon bottled at 107 proof. Aged for fifteen slow years in heavily charred white oak barrels, it offers a dramatic, uncompromised depth of classic American whiskey culture.",
      imageUrl: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&w=800&q=80",
      price: 1950,
      inventoryQuantity: 2,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 1,
      priceHistory: [
        { date: "2026-01-01", price: 1950 }
      ],
      inventoryHistory: [
        { date: "2026-01-01", change: 3, reason: "Auction Allocation", updatedBy: "System" }
      ]
    },
    {
      id: "prod-5",
      sku: "SAK-DA-DASSAI-23",
      name: "Dassai 23 Junmai Daiginjo Sake",
      producer: "Asahi Shuzo",
      region: "Yamaguchi",
      country: "Japan",
      beverageType: "Sake",
      vintage: "Fresh Release",
      abv: 16.0,
      bottleSize: "720ml",
      tastingNotes: {
        nose: "Incredibly aromatic bouquet of white peach, honey, white flowers, and red apple.",
        palate: "Velvety, clean, ultra-refined with a beautiful natural sweetness balanced by high elegance.",
        finish: "Exquisitely clean, leaving a gentle trace of fresh pear and white grape."
      },
      foodPairings: ["Bluefin Tuna Sashimi", "Sea Urchin Uni", "Lightly Salted Edamame"],
      servingTemp: "5-8°C",
      awards: ["Grand Gold Medal - Fine Sake Awards Japan"],
      description: "Milled down to an astonishing 23% of its original grain size, this represents the absolute peak of premium Japanese sake polishing. Every drop is crafted with Yamadanishiki rice to deliver sublime purity.",
      imageUrl: "https://images.unsplash.com/photo-1602015826531-29c464444b02?auto=format&fit=crop&w=800&q=80",
      price: 135,
      inventoryQuantity: 18,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 4,
      priceHistory: [
        { date: "2026-01-01", price: 135 }
      ],
      inventoryHistory: [
        { date: "2026-01-01", change: 20, reason: "Imported allocation", updatedBy: "System" }
      ]
    },
    {
      id: "prod-6",
      sku: "BEER-WV-WEST-12",
      name: "Westvleteren XII Trappist Quad",
      producer: "Brouwerij Westvleteren",
      region: "Westvleteren",
      country: "Belgium",
      beverageType: "Beer & Cider",
      vintage: "2024 Batch",
      abv: 10.2,
      bottleSize: "330ml",
      tastingNotes: {
        nose: "Dark stone fruits, raisins, figs, brown sugar, and complex Belgian yeast spice.",
        palate: "Rich, dense body of dark fruits, caramel, chocolate, licorice, and warm alcohol integration.",
        finish: "Warm, dry, beautifully long with a deep bitter-sweet chocolate complexity."
      },
      foodPairings: ["Roast Duck", "Gorgonzola Cheese", "Rich Chocolate Mud Cake"],
      servingTemp: "12-14°C",
      awards: ["Consistently rated #1 Beer in the World - RateBeer"],
      description: "Brewed strictly inside the walls of the Saint Sixtus Abbey of Westvleteren by Trappist monks. Matured naturally in the bottle, this legendary quadrupel is characterized by its deep amber-brown body and unrivaled depth.",
      imageUrl: "https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&w=800&q=80",
      price: 45,
      inventoryQuantity: 36,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 10,
      priceHistory: [{ date: "2026-01-01", price: 45 }],
      inventoryHistory: [{ date: "2026-01-01", change: 40, reason: "Special Import", updatedBy: "System" }]
    },
    {
      id: "prod-7",
      sku: "ALC-SE-SEED-94",
      name: "Seedlip Spice 94 Distilled Non-Alcoholic Spirit",
      producer: "Seedlip",
      region: "London",
      country: "United Kingdom",
      beverageType: "Alcohol-Free",
      abv: 0.0,
      bottleSize: "700ml",
      tastingNotes: {
        nose: "Warm allspice berries, aromatic cardamom, and fresh citrus notes.",
        palate: "An intricate, dry blend with wood bark, clove, and grapefruit peel highlights.",
        finish: "Dry, spicy, and extremely refreshing with a subtle bitter oak back."
      },
      foodPairings: ["Light Canapés", "Avocado Crostini", "Grilled Cod"],
      servingTemp: "4-6°C",
      awards: ["Gold Medal - Non-Alcoholic Spirits Masters"],
      description: "A sophisticated, zero-alcohol alternative made from individual botanical distillates. Spice 94 blends copper-pot distilled allspice, cardamom, oak bark, lemon, and grapefruit peel for a perfect quiet luxury tonic mocktail.",
      imageUrl: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80",
      price: 36,
      inventoryQuantity: 50,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 8,
      priceHistory: [{ date: "2026-01-01", price: 36 }],
      inventoryHistory: [{ date: "2026-01-01", change: 50, reason: "Direct order", updatedBy: "System" }]
    },
    {
      id: "prod-8",
      sku: "ACC-ZA-ZALTO-BX",
      name: "Zalto Denk'Art Bordeaux Hand-Blown Glass (Set of 2)",
      producer: "Zalto Glass",
      region: "Gmünd",
      country: "Austria",
      beverageType: "Accessories",
      abv: 0.0,
      bottleSize: "1 Set",
      tastingNotes: {
        nose: "N/A",
        palate: "N/A",
        finish: "N/A"
      },
      foodPairings: ["Bordeaux Wines", "Cabernet Sauvignon", "Barolo"],
      awards: ["Voted #1 Wine Glass by global sommeliers"],
      description: "Crafted with architectural minimalism and absolute functional perfection. These lead-free, mouth-blown crystal glasses are feather-light and designed dynamically at angles that align with the tilt of the Earth (24°, 48°, 72°) to enhance olfactory projection.",
      imageUrl: "https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80",
      price: 145,
      inventoryQuantity: 12,
      status: ProductStatus.Published,
      lowStockAlertThreshold: 2,
      priceHistory: [{ date: "2026-01-01", price: 145 }],
      inventoryHistory: [{ date: "2026-01-01", change: 12, reason: "Stock arrival", updatedBy: "System" }]
    }
  ];

  const defaultOrders: Order[] = [
    {
      id: "ord-1",
      orderNumber: "ATC-10481",
      createdAt: "2026-07-10T14:30:00Z",
      customerName: "Elizabeth Montgomery",
      customerEmail: "elizabeth@montgomery.co",
      items: [
        {
          productId: "prod-3",
          name: "Dom Pérignon Vintage 2012 Brut",
          price: 245,
          quantity: 2,
          bottleSize: "750ml",
          sku: "CHA-DP-DOMP-2012"
        }
      ],
      shippingAddress: {
        name: "Elizabeth Montgomery",
        street: "740 Park Avenue, Apt 12B",
        city: "New York",
        state: "NY",
        postalCode: "10021",
        country: "United States",
        phone: "+1 (212) 555-0198"
      },
      status: OrderStatus.Delivered,
      subtotal: 490,
      shippingCost: 0,
      tax: 73.5,
      discount: 0,
      total: 563.5,
      paymentDetails: {
        paymentMethod: "credit_card",
        orderReference: "REF-10481",
        paymentConfirmed: true,
        paymentConfirmedAt: "2026-07-10T14:35:00Z"
      },
      notes: "Please pack with extra insulation. Temperature controlled delivery."
    },
    {
      id: "ord-2",
      orderNumber: "ATC-10482",
      createdAt: "2026-07-13T09:15:00Z",
      customerName: "Xavier Sterling",
      customerEmail: "xavier@sterlingassets.xyz",
      items: [
        {
          productId: "prod-2",
          name: "The Macallan 18 Year Old Sherry Oak",
          price: 480,
          quantity: 1,
          bottleSize: "700ml",
          sku: "SPI-WH-MACA-18"
        }
      ],
      shippingAddress: {
        name: "Xavier Sterling",
        street: "88 Marina Boulevard",
        city: "San Francisco",
        state: "CA",
        postalCode: "94123",
        country: "United States",
        phone: "+1 (415) 555-8930"
      },
      status: OrderStatus.PaymentReceived,
      subtotal: 480,
      shippingCost: 0,
      tax: 72.0,
      discount: 72.0,
      promoCodeUsed: "ATLASCRYPTO",
      total: 480.0,
      paymentDetails: {
        paymentMethod: "crypto",
        currency: CryptoCurrency.BTC,
        walletAddress: "bc1qxy2kg3ut7axv2k267f897f7sh22n4shk8n4e8p",
        amountCrypto: 0.0076,
        txHash: "4f7a2db190e8c89b708b79fb04fa92b513cd77189b8893fa9121d5a7d3c0e3ee",
        orderReference: "REF-10482",
        paymentConfirmed: true,
        paymentConfirmedAt: "2026-07-13T09:28:10Z"
      },
      notes: "Accepting BTC manual payment. Reconciled successfully on blockchain."
    }
  ];

  const defaultLogs: AuditLog[] = [
    {
      id: "log-1",
      timestamp: "2026-07-14T10:00:00Z",
      user: "admin@atlascellars.com",
      action: "Product Price Update",
      details: "Updated Château Margaux 2015 price to $1850 due to seasonal demand.",
      ipAddress: "192.168.1.45"
    },
    {
      id: "log-2",
      timestamp: "2026-07-14T12:30:00Z",
      user: "system",
      action: "Payment Verification",
      details: "Crypto transaction for order ATC-10482 verified successfully.",
      ipAddress: "127.0.0.1"
    }
  ];

  const defaultTickets: SupportTicket[] = [
    {
      id: "tick-1",
      ticketNumber: "TKT-3091",
      createdAt: "2026-07-12T11:00:00Z",
      customerName: "Warren Buffett",
      customerEmail: "warren@berkshire.com",
      category: "Product Inquiry",
      subject: "Inquiry on Pappy Van Winkle 15 Yr allocation limits",
      status: "In Progress",
      messages: [
        {
          id: "m-1",
          sender: "customer",
          timestamp: "2026-07-12T11:00:00Z",
          text: "Hello, I am interested in securing a full case of Pappy Van Winkle 15 Year Old Family Reserve. Is this allocation limit strictly 2 bottles per customer?"
        },
        {
          id: "m-2",
          sender: "merchant",
          timestamp: "2026-07-12T14:15:00Z",
          text: "Dear Warren, thank you for reaching out to Atlas Cellars. Due to extremely limited global allocation, we restrict online checkouts to 2 bottles per customer. However, our concierge desk is reviewing private cellaring options for premium accounts. We will update you shortly."
        }
      ]
    }
  ];

  const defaultMedia: MediaAsset[] = [
    {
      id: "med-1",
      name: "chateau-margaux.jpg",
      url: "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80",
      size: "142 KB",
      type: "image/jpeg",
      folder: "wine",
      uploadedAt: "2026-07-01T09:00:00Z"
    },
    {
      id: "med-2",
      name: "macallan-18.jpg",
      url: "https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=800&q=80",
      size: "185 KB",
      type: "image/jpeg",
      folder: "spirits",
      uploadedAt: "2026-07-02T10:30:00Z"
    },
    {
      id: "med-3",
      name: "dom-perignon.jpg",
      url: "https://images.unsplash.com/photo-1512503254922-b5ca32047d9b?auto=format&fit=crop&w=800&q=80",
      size: "210 KB",
      type: "image/jpeg",
      folder: "champagne",
      uploadedAt: "2026-07-03T11:45:00Z"
    }
  ];

  const defaultCoupons: Coupon[] = [
    { code: "WELCOME10", discountType: "percentage", amount: 10, isActive: true },
    { code: "ATLASCRYPTO", discountType: "percentage", amount: 15, isActive: true },
    { code: "VIP50", discountType: "fixed", amount: 50, isActive: true }
  ];

  const defaultSettings = {
    legalDrinkingAge: 21,
    taxRatePercentage: 15,
    flatShippingCost: 15,
    freeShippingThreshold: 150,
    storeCurrency: "USD",
    btcWalletAddress: "bc1qxy2kg3ut7axv2k267f897f7sh22n4shk8n4e8p",
    usdtWalletAddress: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F",
    auditLogsEnabled: true,
    autoBackupMinutes: 60,
    enforceAgeVerification: true
  };

  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, "utf-8");
      return JSON.parse(data);
    }
  } catch (err) {
    console.error("Error loading database, resetting to defaults:", err);
  }

  const newDB = {
    products: defaultProducts,
    orders: defaultOrders,
    auditLogs: defaultLogs,
    supportTickets: defaultTickets,
    media: defaultMedia,
    coupons: defaultCoupons,
    settings: defaultSettings
  };
  saveDatabase(newDB);
  return newDB;
}

function saveDatabase(data: any) {
  try {
    // Ensure dir exists
    const dir = path.dirname(DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Error saving database file:", err);
  }
}

// Initialize database
let db = loadDatabase();

// Keep database synchronized with memory
function updateDB(callback: (dbInstance: any) => void) {
  callback(db);
  saveDatabase(db);
}

// Initialize Gemini Client Lazily
let aiClient: any = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.warn("GEMINI_API_KEY is missing. Curation service running in simulation mode.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return aiClient;
}

// REST ENDPOINTS

// 1. PRODUCTS API
app.get("/api/products", (req, res) => {
  res.json(db.products);
});

app.post("/api/products", (req, res) => {
  const newProd: Partial<Product> = req.body;
  if (!newProd.name || !newProd.price || !newProd.beverageType) {
    return res.status(400).json({ error: "Missing required fields (name, price, beverageType)" });
  }

  const finalProd: Product = {
    id: `prod-${Date.now()}`,
    sku: newProd.sku || `SKU-${newProd.beverageType.slice(0,3).toUpperCase()}-${Date.now().toString().slice(-6)}`,
    name: newProd.name,
    producer: newProd.producer || "Unknown Producer",
    region: newProd.region || "Unknown Region",
    country: newProd.country || "Unknown Country",
    beverageType: newProd.beverageType,
    vintage: newProd.vintage,
    abv: Number(newProd.abv) || 0,
    bottleSize: newProd.bottleSize || "750ml",
    tastingNotes: newProd.tastingNotes || { nose: "Floral and light.", palate: "Smooth and balanced.", finish: "Clean finish." },
    foodPairings: newProd.foodPairings || [],
    servingTemp: newProd.servingTemp,
    awards: newProd.awards || [],
    description: newProd.description || "",
    imageUrl: newProd.imageUrl || "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80",
    videoUrl: newProd.videoUrl,
    pdfFactSheetUrl: newProd.pdfFactSheetUrl,
    price: Number(newProd.price) || 0,
    salePrice: newProd.salePrice ? Number(newProd.salePrice) : undefined,
    inventoryQuantity: Number(newProd.inventoryQuantity) || 0,
    status: newProd.status || ProductStatus.Draft,
    scheduledReleaseDate: newProd.scheduledReleaseDate,
    supplierReference: newProd.supplierReference,
    lowStockAlertThreshold: Number(newProd.lowStockAlertThreshold) || 5,
    priceHistory: [{ date: new Date().toISOString().split('T')[0], price: Number(newProd.price) }],
    inventoryHistory: [{ date: new Date().toISOString(), change: Number(newProd.inventoryQuantity) || 0, reason: "Product Created", updatedBy: "Merchant" }],
    seoTitle: newProd.seoTitle,
    seoDescription: newProd.seoDescription
  };

  updateDB((inst) => {
    inst.products.push(finalProd);
    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "merchant@atlascellars.com",
      action: "Product Created",
      details: `Created new listing: ${finalProd.name} (${finalProd.sku})`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json(finalProd);
});

app.put("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  let foundIndex = db.products.findIndex((p: Product) => p.id === id);
  if (foundIndex === -1) {
    return res.status(404).json({ error: "Product not found" });
  }

  updateDB((inst) => {
    const existing = inst.products[foundIndex];

    // Log price history if changed
    if (updates.price !== undefined && Number(updates.price) !== existing.price) {
      existing.priceHistory.push({
        date: new Date().toISOString().split('T')[0],
        price: Number(updates.price),
        salePrice: updates.salePrice ? Number(updates.salePrice) : undefined
      });
    }

    // Log inventory history if changed
    if (updates.inventoryQuantity !== undefined && Number(updates.inventoryQuantity) !== existing.inventoryQuantity) {
      const diff = Number(updates.inventoryQuantity) - existing.inventoryQuantity;
      existing.inventoryHistory.push({
        date: new Date().toISOString(),
        change: diff,
        reason: updates.inventoryChangeReason || "Manual Inventory Adjustment",
        updatedBy: "Merchant"
      });
    }

    inst.products[foundIndex] = {
      ...existing,
      ...updates,
      // Ensure complex objects aren't partially overwritten
      tastingNotes: updates.tastingNotes ? { ...existing.tastingNotes, ...updates.tastingNotes } : existing.tastingNotes,
      priceHistory: existing.priceHistory,
      inventoryHistory: existing.inventoryHistory
    };

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "merchant@atlascellars.com",
      action: "Product Updated",
      details: `Modified product metadata for: ${existing.name}`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json(db.products[foundIndex]);
});

app.post("/api/products/duplicate/:id", (req, res) => {
  const { id } = req.params;
  const found = db.products.find((p: Product) => p.id === id);
  if (!found) {
    return res.status(404).json({ error: "Product not found to duplicate" });
  }

  const duplicated: Product = {
    ...found,
    id: `prod-${Date.now()}`,
    sku: `${found.sku}-DUP-${Date.now().toString().slice(-4)}`,
    name: `${found.name} (Copy)`,
    status: ProductStatus.Draft,
    inventoryQuantity: 0,
    priceHistory: [{ date: new Date().toISOString().split('T')[0], price: found.price }],
    inventoryHistory: [{ date: new Date().toISOString(), change: 0, reason: "Duplication", updatedBy: "Merchant" }]
  };

  updateDB((inst) => {
    inst.products.push(duplicated);
    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "merchant@atlascellars.com",
      action: "Product Duplicated",
      details: `Duplicated listing: ${found.name} as ${duplicated.name}`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json(duplicated);
});

app.delete("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const index = db.products.findIndex((p: Product) => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }

  updateDB((inst) => {
    const prod = inst.products[index];
    prod.status = ProductStatus.Archived;

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "merchant@atlascellars.com",
      action: "Product Archived",
      details: `Set status of ${prod.name} to Archived`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json({ success: true, message: "Product successfully archived" });
});

// BULK UPLOAD PRODUCTS
app.post("/api/products/bulk-upload", (req, res) => {
  const { items } = req.body;
  if (!Array.isArray(items)) {
    return res.status(400).json({ error: "Invalid payload. 'items' must be an array." });
  }

  let count = 0;
  updateDB((inst) => {
    items.forEach((item: any) => {
      const finalProd: Product = {
        id: `prod-${Date.now()}-${count}`,
        sku: item.sku || `SKU-BULK-${Date.now().toString().slice(-4)}-${count}`,
        name: item.name || "Bulk Product",
        producer: item.producer || "Curated Reserve",
        region: item.region || "Various",
        country: item.country || "Various",
        beverageType: item.beverageType || "Wine",
        vintage: item.vintage,
        abv: Number(item.abv) || 12.0,
        bottleSize: item.bottleSize || "750ml",
        tastingNotes: item.tastingNotes || { nose: "Rich", palate: "Elegant", finish: "Persistent" },
        foodPairings: item.foodPairings || [],
        awards: item.awards || [],
        description: item.description || "Curated beverage listing.",
        imageUrl: item.imageUrl || "https://images.unsplash.com/photo-1510812431401-41d2bd2722f3?auto=format&fit=crop&w=800&q=80",
        price: Number(item.price) || 50,
        inventoryQuantity: Number(item.inventoryQuantity) || 10,
        status: ProductStatus.Published,
        lowStockAlertThreshold: 5,
        priceHistory: [{ date: new Date().toISOString().split('T')[0], price: Number(item.price) || 50 }],
        inventoryHistory: [{ date: new Date().toISOString(), change: Number(item.inventoryQuantity) || 10, reason: "Bulk Import", updatedBy: "Merchant" }]
      };
      inst.products.push(finalProd);
      count++;
    });

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "merchant@atlascellars.com",
      action: "Bulk Products CSV Import",
      details: `Imported and published ${count} drinks in bulk.`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json({ success: true, count, products: db.products });
});


// 2. ORDERS API
app.get("/api/orders", (req, res) => {
  res.json(db.orders);
});

app.post("/api/orders", (req, res) => {
  const { customerName, customerEmail, items, shippingAddress, paymentMethod, currency, usdtNetwork, promoCode, notes } = req.body;

  if (!customerName || !customerEmail || !items || !Array.isArray(items) || items.length === 0 || !shippingAddress) {
    return res.status(400).json({ error: "Missing checkout parameters (customer details, items, address)" });
  }

  // Calculate prices
  let subtotal = 0;
  const mappedItems = items.map((cartItem: any) => {
    const product = db.products.find((p: Product) => p.id === cartItem.productId);
    if (!product) {
      throw new Error(`Product not found: ${cartItem.productId}`);
    }
    const itemPrice = product.salePrice !== undefined ? product.salePrice : product.price;
    subtotal += itemPrice * cartItem.quantity;
    return {
      productId: product.id,
      name: product.name,
      price: itemPrice,
      quantity: cartItem.quantity,
      bottleSize: product.bottleSize,
      sku: product.sku
    };
  });

  // Calculate promotional codes
  let discount = 0;
  if (promoCode) {
    const coupon = db.coupons.find((c: Coupon) => c.code.toUpperCase() === promoCode.toUpperCase() && c.isActive);
    if (coupon) {
      if (coupon.discountType === "percentage") {
        discount = subtotal * (coupon.amount / 100);
      } else {
        discount = coupon.amount;
      }
    }
  }

  // Auto tax & shipping calculation based on settings
  const { taxRatePercentage, flatShippingCost, freeShippingThreshold } = db.settings;
  const shippingCost = (subtotal - discount) >= freeShippingThreshold ? 0 : flatShippingCost;
  const tax = (subtotal - discount) * (taxRatePercentage / 100);
  const total = subtotal - discount + shippingCost + tax;

  const orderReference = `REF-${Math.floor(10000 + Math.random() * 90000)}`;
  const orderNumber = `ATC-${Math.floor(10000 + Math.random() * 90000)}`;

  // Cryptocurrency payment workflow setup
  let finalPaymentDetails: any = {
    paymentMethod,
    orderReference,
    paymentConfirmed: false
  };

  if (paymentMethod === "crypto") {
    const isUSDT = currency === "USDT";
    const walletAddress = isUSDT ? db.settings.usdtWalletAddress : db.settings.btcWalletAddress;

    // Simulate real exchange rate conversion
    // 1 BTC = $65,000, 1 USDT = $1
    const coinRate = isUSDT ? 1.0 : 65000;
    const cryptoAmount = Number((total / coinRate).toFixed(isUSDT ? 2 : 6));

    finalPaymentDetails = {
      ...finalPaymentDetails,
      currency,
      usdtNetwork: isUSDT ? (usdtNetwork || "TRC-20") : undefined,
      walletAddress,
      amountCrypto: cryptoAmount,
      countdownMinutesRemaining: 15
    };
  } else {
    // CC triggers instant payment received simulation
    finalPaymentDetails.paymentConfirmed = true;
    finalPaymentDetails.paymentConfirmedAt = new Date().toISOString();
  }

  const newOrder: Order = {
    id: `ord-${Date.now()}`,
    orderNumber,
    createdAt: new Date().toISOString(),
    customerName,
    customerEmail,
    items: mappedItems,
    shippingAddress,
    status: paymentMethod === "crypto" ? OrderStatus.AwaitingPayment : OrderStatus.PaymentReceived,
    subtotal,
    shippingCost,
    tax,
    discount,
    promoCodeUsed: discount > 0 ? promoCode : undefined,
    total,
    paymentDetails: finalPaymentDetails,
    notes
  };

  updateDB((inst) => {
    // Deduct stock levels on placement
    mappedItems.forEach((orderItem) => {
      const prod = inst.products.find((p: Product) => p.id === orderItem.productId);
      if (prod) {
        prod.inventoryQuantity = Math.max(0, prod.inventoryQuantity - orderItem.quantity);
        prod.inventoryHistory.push({
          date: new Date().toISOString(),
          change: -orderItem.quantity,
          reason: `Order ${orderNumber} Placement`,
          updatedBy: "System"
        });
      }
    });

    inst.orders.push(newOrder);

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: customerEmail,
      action: "Order Created",
      details: `Placed order ${orderNumber} via ${paymentMethod === "crypto" ? currency : "Credit Card"}. Total: $${total.toFixed(2)}`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json(newOrder);
});

// Update Order Status (ERP Action)
app.put("/api/orders/:id/status", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  if (!status || !Object.values(OrderStatus).includes(status as OrderStatus)) {
    return res.status(400).json({ error: "Invalid order status specified." });
  }

  let index = db.orders.findIndex((o: Order) => o.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Order not found" });
  }

  updateDB((inst) => {
    const ord = inst.orders[index];
    const prevStatus = ord.status;
    ord.status = status as OrderStatus;

    // If status is refunded, restore stock
    if (status === OrderStatus.Refunded && prevStatus !== OrderStatus.Refunded) {
      ord.items.forEach((item) => {
        const prod = inst.products.find((p: Product) => p.id === item.productId);
        if (prod) {
          prod.inventoryQuantity += item.quantity;
          prod.inventoryHistory.push({
            date: new Date().toISOString(),
            change: item.quantity,
            reason: `Refund Order Restore (${ord.orderNumber})`,
            updatedBy: "Merchant"
          });
        }
      });
    }

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "admin@atlascellars.com",
      action: "Order Status Updated",
      details: `Updated order ${ord.orderNumber} status from '${prevStatus}' to '${status}'`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json(db.orders[index]);
});

// Manually or Automatically Confirm Crypto Payments
app.post("/api/orders/:id/confirm-payment", (req, res) => {
  const { id } = req.params;
  const { txHash } = req.body;

  let index = db.orders.findIndex((o: Order) => o.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Order not found" });
  }

  updateDB((inst) => {
    const ord = inst.orders[index];
    ord.paymentDetails.paymentConfirmed = true;
    ord.paymentDetails.paymentConfirmedAt = new Date().toISOString();
    ord.paymentDetails.txHash = txHash || `mock-tx-${Math.random().toString(16).slice(2, 18)}`;
    ord.status = OrderStatus.PaymentReceived;

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "system",
      action: "Crypto Payment Reconciliation",
      details: `Reconciled block receipt for order ${ord.orderNumber}. TX Hash: ${ord.paymentDetails.txHash}`,
      ipAddress: "127.0.0.1"
    });
  });

  res.json(db.orders[index]);
});


// 3. ANALYTICS API
app.get("/api/analytics", (req, res) => {
  const validOrders = db.orders.filter((o: Order) =>
    o.status !== OrderStatus.Cancelled &&
    o.status !== OrderStatus.AwaitingPayment
  );

  const totalRevenue = validOrders.reduce((sum: number, o: Order) => sum + o.total, 0);

  // Sales by Category
  const categorySales: Record<string, number> = {};
  // Best Sellers
  const productQuantities: Record<string, { name: string; qty: number; revenue: number }> = {};

  validOrders.forEach((o: Order) => {
    o.items.forEach((item) => {
      // Find category in products
      const prod = db.products.find((p: Product) => p.id === item.productId);
      const cat = prod ? prod.beverageType : "Unknown";
      categorySales[cat] = (categorySales[cat] || 0) + (item.price * item.quantity);

      const old = productQuantities[item.productId] || { name: item.name, qty: 0, revenue: 0 };
      productQuantities[item.productId] = {
        name: item.name,
        qty: old.qty + item.quantity,
        revenue: old.revenue + (item.price * item.quantity)
      };
    });
  });

  const bestSellers = Object.values(productQuantities)
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 5);

  // Crypto usage
  const cryptoUsage = {
    crypto: db.orders.filter((o: Order) => o.paymentDetails.paymentMethod === "crypto").length,
    creditCard: db.orders.filter((o: Order) => o.paymentDetails.paymentMethod === "credit_card").length
  };

  res.json({
    totalRevenue,
    orderCount: db.orders.length,
    categorySales,
    bestSellers,
    cryptoUsage,
    conversionRate: 3.14, // Simulated DTC hypermodern metrics
    inventoryTurnover: 85.2, // Simulated analytics
    lowStockItems: db.products.filter((p: Product) => p.inventoryQuantity <= p.lowStockAlertThreshold && p.status !== ProductStatus.Archived)
  });
});


// 4. SETTINGS API
app.get("/api/settings", (req, res) => {
  res.json(db.settings);
});

app.put("/api/settings", (req, res) => {
  const updates = req.body;
  updateDB((inst) => {
    inst.settings = {
      ...inst.settings,
      ...updates
    };

    inst.auditLogs.unshift({
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user: "admin@atlascellars.com",
      action: "Settings Modified",
      details: "Updated general settings, taxes, and cryptocurrency wallets.",
      ipAddress: "127.0.0.1"
    });
  });
  res.json(db.settings);
});


// 5. AUDIT LOGS
app.get("/api/audit-logs", (req, res) => {
  res.json(db.auditLogs);
});


// 6. SUPPORT TICKETS CRM
app.get("/api/support-tickets", (req, res) => {
  res.json(db.supportTickets);
});

app.post("/api/support-tickets", (req, res) => {
  const { customerName, customerEmail, category, subject, message } = req.body;

  if (!customerName || !customerEmail || !category || !subject || !message) {
    return res.status(400).json({ error: "Missing required support details." });
  }

  const newTicket: SupportTicket = {
    id: `tick-${Date.now()}`,
    ticketNumber: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
    createdAt: new Date().toISOString(),
    customerName,
    customerEmail,
    category,
    subject,
    status: "Open",
    messages: [
      {
        id: `msg-${Date.now()}`,
        sender: "customer",
        timestamp: new Date().toISOString(),
        text: message
      }
    ]
  };

  updateDB((inst) => {
    inst.supportTickets.unshift(newTicket);
  });

  res.json(newTicket);
});

app.post("/api/support-tickets/:id/messages", (req, res) => {
  const { id } = req.params;
  const { sender, text } = req.body;

  if (!sender || !text) {
    return res.status(400).json({ error: "Sender and text are required." });
  }

  let index = db.supportTickets.findIndex((t: SupportTicket) => t.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Ticket not found" });
  }

  updateDB((inst) => {
    const tkt = inst.supportTickets[index];
    tkt.messages.push({
      id: `msg-${Date.now()}`,
      sender,
      timestamp: new Date().toISOString(),
      text
    });
    if (sender === "merchant") {
      tkt.status = "In Progress";
    }
  });

  res.json(db.supportTickets[index]);
});

app.put("/api/support-tickets/:id/status", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  let index = db.supportTickets.findIndex((t: SupportTicket) => t.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Ticket not found" });
  }

  updateDB((inst) => {
    inst.supportTickets[index].status = status;
  });

  res.json(db.supportTickets[index]);
});


// 7. MEDIA GALLERY
app.get("/api/media", (req, res) => {
  res.json(db.media);
});

app.post("/api/media", (req, res) => {
  const { name, url, folder, type, size } = req.body;

  if (!name || !url) {
    return res.status(400).json({ error: "Name and URL are required to index media assets." });
  }

  const newAsset: MediaAsset = {
    id: `med-${Date.now()}`,
    name,
    url,
    size: size || "120 KB",
    type: type || "image/jpeg",
    folder: folder || "uncategorized",
    uploadedAt: new Date().toISOString()
  };

  updateDB((inst) => {
    inst.media.push(newAsset);
  });

  res.json(newAsset);
});


// 8. GEMINI AI CURATOR (SOMMELIER) API
app.post("/api/gemini/curator", async (req, res) => {
  const { message, history } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message prompt is required." });
  }

  const ai = getGeminiClient();

  if (!ai) {
    // Elegant simulated curation when API Key is missing, to keep app beautiful and responsive
    console.log("No Gemini API key. Providing automated sommelier feedback.");
    const simulatedResponse = getSimulationResponse(message);
    return res.json({ text: simulatedResponse });
  }

  try {
    // Compile catalogue brief to ground Gemini on Atlas Cellars premium drinks
    const catalogueSummary = db.products.map((p: Product) =>
      `- SKU: ${p.sku}, Name: ${p.name}, Type: ${p.beverageType}, Producer: ${p.producer}, Region: ${p.region}, Price: $${p.price}, Tasting Notes: Nose: ${p.tastingNotes.nose} Palate: ${p.tastingNotes.palate} Finish: ${p.tastingNotes.finish}, Pairings: ${p.foodPairings.join(", ")}`
    ).join("\n");

    const systemInstruction = `
      You are the Master Sommelier and Premium Spirits Curator of 'Atlas Cellars' (an American Hypermodern, high-end independent drinks merchant).
      Your speaking tone should be sophisticated, quiet luxury, tech-forward, editorial, and deeply knowledgeable. Avoid exclamation marks and marketing fluff.

      Ground your recommendations strictly in the following curated drinks catalogue of Atlas Cellars:
      ${catalogueSummary}

      If requested to recommend or pair drinks not listed, gracefully guide the guest toward our carefully selected allocations. Give meticulous details on nose, palate, finish, serving temperatures, and architectural food pairings.
    `;

    // Reconstruct conversation using chats.create or generateContent
    // Since chats is perfect, let's use ai.models.generateContent with current query and systemInstruction
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: message,
      config: {
        systemInstruction,
        temperature: 0.7
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API call failed:", error);
    res.status(500).json({ error: "Curator service encountered an issue. Falling back to simulation.", fallbackText: getSimulationResponse(message) });
  }
});

// Advanced Simulation Fallback Generator for luxury drinks
function getSimulationResponse(msg: string): string {
  const lower = msg.toLowerCase();
  if (lower.includes("pair") || lower.includes("food") || lower.includes("eat")) {
    return `Excellent query. For fine dining pairings, we recommend the Chateau Margaux 2015 Classé ($1850). Its seamless, silky cassis and graphite palate pairs beautifully with Roast Rack of Lamb or Seared Ribeye. If looking for premium seafood matches, the Dom Pérignon Vintage 2012 Brut ($245) delivers an impeccable chalky salinity and lemon zest that cuts through Beluga Caviar and Fresh Oysters flawlessly. Shall we add a temperature-controlled bottle to your reservation list?`;
  }
  if (lower.includes("whisky") || lower.includes("whiskey") || lower.includes("bourbon") || lower.includes("pappy")) {
    return `For spirits of industrial elegance, we highlight the highly limited Pappy Van Winkle 15 Year Old Family Reserve ($1950) bottled at 107 proof. Matured in heavily charred white oak, its wheated caramel profiles offer unrivaled warmth. Alternatively, the Speyside Macallan 18 Year Old Sherry Oak ($480) presents a lingering dried fruit, sweet ginger, and wood-smoke finish. These represent our finest collector allocations.`;
  }
  if (lower.includes("champagne") || lower.includes("bubbly") || lower.includes("wine")) {
    return `Of fine wines, Château Margaux 2015 Premier Grand Cru ($1850) is indeed an immortal vintage. It represents an architectural milestone, possessing silky, infinite tannins. If celebrating, the Dom Pérignon Vintage 2012 Brut ($245) offers a vibrant, highly-structured tactile experience of toasted brioche and white peach notes. Let us know if you require personal cellaring assistance.`;
  }
  return `Welcome to the Atlas Cellars Conciérge. We curate only the world's most pristine allocations—from Château Margaux 2015 Premier Grand Cru and Dom Pérignon Vintage 2012, to the Speyside Macallan 18 Sherry Oak and limited Pappy Van Winkle Family Reserves. Speak to us of your taste profile, desired vintage, or gastronomic dinner pairings, and we will formulate an immaculate recommendation.`;
}


// VITE DEVELOPER SERVER INTERSECTION
async function run() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Atlas Cellars Enterprise Server] running on http://localhost:${PORT} in ${process.env.NODE_ENV || "development"} mode.`);
  });
}

run();
