export type ButterCollection = 'classic' | 'flavoured' | 'seasonal' | 'gift';

export interface Product {
  id: string;
  name: string;
  tagline: string;
  price: number;
  collection: ButterCollection;
  image: string;
  description: string;
  ingredients: string[];
  farmOrigin: {
    name: string;
    location: string;
    story: string;
  };
  churningMethod: string;
  tastingNotes: string[];
  pairingSuggestions: string[];
  storageAdvice: string;
  nutritionalInfo: {
    servingSize: string;
    calories: number;
    fat: string;
    saturatedFat: string;
    sodium: string;
    carbs: string;
    protein: string;
  };
  rating: number;
  reviewsCount: number;
  isLimitedEdition?: boolean;
}

export interface Review {
  id: string;
  userName: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  price: number;
  frequency: string;
  description: string;
  features: string[];
  badge?: string;
  image: string;
}

export interface Farm {
  id: string;
  name: string;
  farmer: string;
  location: string;
  coords: { x: number; y: number }; // Percentage coords on mock interactive map
  welfareScore: string;
  sustainabilityPractice: string;
  story: string;
  image: string;
  methods: string[];
}

export interface Recipe {
  id: string;
  title: string;
  category: 'baking' | 'breakfast' | 'steak' | 'seafood' | 'vegetables' | 'pastries' | 'sauces' | 'desserts';
  prepTime: string;
  cookTime: string;
  servings: number;
  description: string;
  ingredients: string[];
  instructions: string[];
  featuredButterId: string; // Links to a product
  image: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  isSubscription: boolean;
  subscriptionPlanId?: string;
}

export interface Order {
  id: string;
  date: string;
  items: {
    productName: string;
    quantity: number;
    price: number;
    isSubscription: boolean;
  }[];
  total: number;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Out for delivery';
  trackingNumber?: string;
}

export interface UserAccount {
  name: string;
  email: string;
  joinedDate: string;
  loyaltyPoints: number;
  subscriptionPlan?: string;
  addresses: {
    type: 'Shipping' | 'Billing';
    line1: string;
    city: string;
    postcode: string;
    country: string;
  }[];
  giftLists: {
    name: string;
    itemsCount: number;
  }[];
}
