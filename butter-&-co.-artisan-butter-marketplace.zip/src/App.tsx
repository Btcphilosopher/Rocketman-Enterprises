import { useState, useEffect } from 'react';
import { Search, SlidersHorizontal, ArrowRight, Heart, Star, Sparkles, ShoppingBag, Globe, Info, Clock, CheckCircle } from 'lucide-react';

// Imported modular components
import Header from './components/Header';
import Footer from './components/Footer';
import ProductDetailModal from './components/ProductDetailModal';
import CartDrawer from './components/CartDrawer';
import CheckoutModal from './components/CheckoutModal';
import FarmsSection from './components/FarmsSection';
import SubscriptionSection from './components/SubscriptionSection';
import RecipesSection from './components/RecipesSection';
import AccountSection from './components/AccountSection';

// Imported data
import { products } from './data/products';
import { Product, CartItem, Order, UserAccount } from './types';

export default function App() {
  // Global Navigation State
  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Cart / Drawer state
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);

  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [shopFilter, setShopFilter] = useState<'all' | 'classic' | 'flavoured' | 'seasonal' | 'gift'>('all');
  const [shopSort, setShopSort] = useState<'default' | 'price-low' | 'price-high' | 'rating'>('default');

  // Favorites tracking
  const [favoriteIds, setFavoriteIds] = useState<string[]>(['maldon-salted', 'truffle-gold']);

  // Account State
  const [userAccount, setUserAccount] = useState<UserAccount>({
    name: 'Tom Butterfield',
    email: 'tom@ahyx.org',
    joinedDate: 'November 2025',
    loyaltyPoints: 1200,
    subscriptionPlan: 'Monthly Butter Box',
    addresses: [
      { type: 'Shipping', line1: '12 Cotswold Green Cottage, Herb Lane', city: 'Chipping Campden', postcode: 'GL55 6XX', country: 'United Kingdom' }
    ],
    giftLists: [
      { name: 'My Bakery List', itemsCount: 3 }
    ]
  });

  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'BC-554102',
      date: '12/05/2026',
      items: [
        { productName: 'Maldon Sea Salt Churned Butter', quantity: 2, price: 9.50, isSubscription: false },
        { productName: 'Double-Churned Cultured Butter', quantity: 1, price: 10.50, isSubscription: true }
      ],
      total: 29.50,
      status: 'Delivered',
      trackingNumber: 'BC89021435'
    }
  ]);

  // Alert system for feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (message: string) => {
    setToastMessage(message);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Cart operations
  const addToCart = (product: Product, quantity: number, isSub: boolean) => {
    const existingIndex = cartItems.findIndex(
      (item) => item.product.id === product.id && item.isSubscription === isSub
    );

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += quantity;
      setCartItems(updated);
    } else {
      setCartItems([...cartItems, { product, quantity, isSubscription: isSub }]);
    }
    
    showToast(`Added ${quantity}x ${product.name} to your basket!`);
  };

  const updateCartQuantity = (productId: string, isSub: boolean, delta: number) => {
    const existingIndex = cartItems.findIndex(
      (item) => item.product.id === productId && item.isSubscription === isSub
    );

    if (existingIndex > -1) {
      const updated = [...cartItems];
      const newQty = updated[existingIndex].quantity + delta;
      
      if (newQty <= 0) {
        updated.splice(existingIndex, 1);
      } else {
        updated[existingIndex].quantity = newQty;
      }
      setCartItems(updated);
    }
  };

  const removeFromCart = (productId: string, isSub: boolean) => {
    const updated = cartItems.filter(
      (item) => !(item.product.id === productId && item.isSubscription === isSub)
    );
    setCartItems(updated);
    showToast("Item removed from your basket.");
  };

  const clearCart = () => {
    setCartItems([]);
  };

  // Favorites toggler
  const toggleFavorite = (productId: string) => {
    if (favoriteIds.includes(productId)) {
      setFavoriteIds(favoriteIds.filter(id => id !== productId));
      showToast("Removed from saved favorites.");
    } else {
      setFavoriteIds([...favoriteIds, productId]);
      showToast("Pinned to your saved favorites!");
    }
  };

  // Order placement helper
  const handleOrderPlaced = (newOrderSummary: { id: string; total: number; date: string; itemsCount: number }) => {
    const newOrder: Order = {
      id: newOrderSummary.id,
      date: newOrderSummary.date,
      items: cartItems.map(item => ({
        productName: item.product.name,
        quantity: item.quantity,
        price: item.isSubscription ? item.product.price * 0.9 : item.product.price,
        isSubscription: item.isSubscription
      })),
      total: newOrderSummary.total,
      status: 'Processing',
      trackingNumber: 'BC' + Math.floor(40000000 + Math.random() * 50000000)
    };

    setOrders([newOrder, ...orders]);
    
    // Add loyalty points to profile
    const gainedPoints = Math.floor(newOrderSummary.total * 10);
    setUserAccount(prev => ({
      ...prev,
      loyaltyPoints: prev.loyaltyPoints + gainedPoints
    }));

    showToast(`Order placed successfully! Earned ${gainedPoints} Loyalty Points.`);
  };

  // Subscription management simulation
  const handleSubscribeToPlan = (plan: any) => {
    // Add standard subscription item to cart
    // We mock a custom product representing the plan
    const mockProduct: Product = {
      id: plan.id,
      name: plan.name,
      tagline: plan.description,
      price: plan.price,
      collection: 'classic',
      image: plan.image,
      description: plan.description,
      ingredients: ['Multiple craft varieties included'],
      farmOrigin: { name: 'Gourmet Coop', location: 'UK Dairies', story: 'Traced back to partner organic pastures.' },
      churningMethod: 'Mixed micro-batch barrels.',
      tastingNotes: ['Artisanal variety', 'Seasonal grass richness'],
      pairingSuggestions: ['Great crusty sourdoughs', 'Pastry making'],
      storageAdvice: 'Store refrigerated.',
      nutritionalInfo: { servingSize: '10g', calories: 73, fat: '80g', saturatedFat: '50g', sodium: '0.1g', carbs: '0.1g', protein: '0.1g' },
      rating: 5.0,
      reviewsCount: 140
    };

    addToCart(mockProduct, 1, true);
    setCartOpen(true);
  };

  const handleSubscribeToCustomBox = (customPlan: any) => {
    const mockProduct: Product = {
      id: 'custom-curated-box',
      name: customPlan.name,
      tagline: `Curated assortment of ${customPlan.items.length} artisan varieties.`,
      price: customPlan.price,
      collection: 'classic',
      image: 'https://images.unsplash.com/photo-1620921556328-1a9300dce76d?auto=format&fit=crop&q=80&w=800',
      description: `Your custom curated recurring subscription. Delivered: ${customPlan.frequency}. Included: ${customPlan.items.map((i: any) => `${i.qty}x ${i.product.name}`).join(', ')}`,
      ingredients: ['Traced to individual selected labels'],
      farmOrigin: { name: 'Various Organic Creameries', location: 'United Kingdom & Scandinavia', story: 'Handpicked by you.' },
      churningMethod: 'Artisanal micro batch rolling.',
      tastingNotes: ['Gourmet assortment tailored to your palate'],
      pairingSuggestions: ['The perfect breakfast and pastry board centerpiece'],
      storageAdvice: 'Refrigerate immediately.',
      nutritionalInfo: { servingSize: '10g', calories: 72, fat: '79g', saturatedFat: '50g', sodium: '0.12g', carbs: '0.2g', protein: '0.1g' },
      rating: 5.0,
      reviewsCount: 1
    };

    addToCart(mockProduct, 1, true);
    setCartOpen(true);
  };

  // Recipe details shop hook
  const handleShopProductDetailsDirect = (productId: string) => {
    const prod = products.find(p => p.id === productId);
    if (prod) {
      setSelectedProduct(prod);
    }
  };

  // Filter and Sort Products
  const getFilteredProducts = () => {
    let list = [...products];

    // Filter by collection
    if (shopFilter !== 'all') {
      list = list.filter((p) => p.collection === shopFilter);
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.tagline.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.collection.toLowerCase().includes(q) ||
          p.ingredients.some((ing) => ing.toLowerCase().includes(q))
      );
    }

    // Sorting
    if (shopSort === 'price-low') {
      list.sort((a, b) => a.price - b.price);
    } else if (shopSort === 'price-high') {
      list.sort((a, b) => b.price - a.price);
    } else if (shopSort === 'rating') {
      list.sort((a, b) => b.rating - a.rating);
    }

    return list;
  };

  return (
    <div className="min-h-screen bg-brand-cream text-brand-forest selection:bg-brand-yellow/50 selection:text-brand-forest antialiased flex flex-col justify-between" id="app-wrapper">
      
      {/* Toast Feedback */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-brand-forest border border-brand-yellow/30 text-brand-yellow px-5 py-3.5 rounded-lg shadow-2xl flex items-center space-x-3 max-w-sm animate-slide-up" id="toast-banner">
          <CheckCircle className="h-5 w-5 text-brand-sage animate-pulse shrink-0" />
          <span className="font-sans text-xs font-semibold leading-relaxed">{toastMessage}</span>
        </div>
      )}

      {/* Global Luxury Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        openCart={() => setCartOpen(true)}
        favoritesCount={favoriteIds.length}
        openAccount={() => setActiveTab('account')}
      />

      {/* Main View Router */}
      <main className="flex-1">
        
        {/* VIEW 1: HOME */}
        {activeTab === 'home' && (
          <div id="home-view" className="animate-fade-in">
            {/* Cinematic Asymmetric Editorial Hero Section */}
            <section className="relative lg:grid lg:grid-cols-12 border-b border-brand-stone" id="hero-section">
              {/* Left Column: Magazine Editorial Content (7 cols) */}
              <div className="col-span-7 bg-brand-cream px-6 sm:px-12 lg:px-20 py-16 sm:py-24 flex flex-col justify-between space-y-12 relative z-10 lg:border-r border-brand-stone">
                <div className="space-y-6">
                  <div className="flex items-center space-x-2">
                    <span className="h-[1px] w-8 bg-brand-yellow block" />
                    <span className="text-[10px] uppercase tracking-[0.3em] text-brand-yellow font-sans font-extrabold block" id="hero-brand-eyebrow">
                      Spring Harvest Edition
                    </span>
                  </div>
                  
                  <h1 className="font-serif text-5xl sm:text-7xl lg:text-8xl font-black tracking-tight text-brand-forest leading-[0.9]" id="hero-headline">
                    BUTTER.<br />
                    PERFECTED.
                  </h1>
                  
                  <p className="font-serif italic text-lg sm:text-xl text-brand-forest/75 max-w-lg leading-relaxed pt-2" id="hero-subheading">
                    Handcrafted artisan butter made in slow small batches using exceptional pasture-fed dairy and traditional farm methods.
                  </p>
                </div>

                {/* Editorial Metadata block */}
                <div className="grid grid-cols-3 gap-4 border-t border-b border-brand-stone/60 py-6 max-w-xl font-sans text-[10px] tracking-widest uppercase text-brand-oak font-semibold">
                  <div>
                    <span className="block text-brand-forest/50 font-medium mb-1">ORIGIN</span>
                    <span className="text-brand-forest font-bold text-xs">Somerset, UK</span>
                  </div>
                  <div>
                    <span className="block text-brand-forest/50 font-medium mb-1">PROCESS</span>
                    <span className="text-brand-forest font-bold text-xs">36hr Sour Churn</span>
                  </div>
                  <div>
                    <span className="block text-brand-forest/50 font-medium mb-1">PURITY</span>
                    <span className="text-brand-forest font-bold text-xs">99.8% Grass-Fed</span>
                  </div>
                </div>

                {/* Primary CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-3 max-w-xl" id="hero-ctas">
                  <button
                    onClick={() => setActiveTab('shop')}
                    className="bg-brand-forest hover:bg-brand-yellow text-brand-cream hover:text-brand-forest font-sans uppercase tracking-widest text-xs font-extrabold py-4 px-8 rounded-none cursor-pointer transition-all flex items-center justify-center space-x-2 border border-brand-forest"
                  >
                    <span>Shop Collection</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => { setShopFilter('flavoured'); setActiveTab('shop'); }}
                    className="bg-transparent hover:bg-brand-forest text-brand-forest hover:text-brand-cream border border-brand-forest py-4 px-7 rounded-none cursor-pointer transition-colors font-sans uppercase tracking-widest text-xs font-bold"
                  >
                    Flavoured boutique
                  </button>
                  <button
                    onClick={() => setActiveTab('subscriptions')}
                    className="bg-brand-butter hover:bg-brand-forest text-brand-forest hover:text-brand-cream border border-brand-stone/60 py-4 px-7 rounded-none cursor-pointer transition-colors font-sans uppercase tracking-widest text-xs font-bold"
                  >
                    Subscribe Box
                  </button>
                </div>
              </div>

              {/* Right Column: Premium Showcase Board (5 cols) */}
              <div className="col-span-5 bg-brand-linen py-16 px-8 sm:px-16 flex flex-col justify-between items-center relative overflow-hidden min-h-[400px] lg:min-h-0">
                {/* Visual grid reference lines */}
                <div className="absolute inset-0 opacity-[0.03] pointer-events-none font-mono text-[8px] text-brand-forest p-4 leading-normal">
                  {Array.from({ length: 10 }).map((_, i) => (
                    <div key={i}>SEC_HARVEST_LINE_REF_{1000 + i * 15} // STATUS: MATURING</div>
                  ))}
                </div>

                <div className="text-center space-y-1 z-10">
                  <span className="text-[9px] uppercase tracking-[0.25em] text-brand-yellow font-sans font-bold block">
                    FEATURED CHURN
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-brand-forest">
                    Smoked Maldon Salt
                  </h3>
                </div>

                {/* Interactive elegant showcase card, rotated for magazine editorial aesthetic */}
                <div className="my-8 relative z-10 w-full max-w-[280px] aspect-[4/5] bg-brand-cream border-[8px] border-brand-stone p-4 shadow-xl transform rotate-2 hover:rotate-0 transition-transform duration-500 cursor-pointer group"
                     onClick={() => {
                       const p = products.find(prod => prod.id === 'maldon-salted');
                       if (p) setSelectedProduct(p);
                     }}>
                  <div className="w-full h-[65%] overflow-hidden border border-brand-stone">
                    <img 
                      src="https://images.unsplash.com/photo-1549931319-a545dcf3bc73?auto=format&fit=crop&q=80&w=600" 
                      alt="Artisanal rolled butter logs with gold seal"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <div className="pt-4 flex flex-col justify-between h-[35%]">
                    <div>
                      <h4 className="font-serif text-base font-bold text-brand-forest">Maldon Sea Salt Churn</h4>
                      <p className="text-[9px] text-brand-forest/60 font-sans tracking-wide">Slow Barrel Hand-Rolled Slabs</p>
                    </div>
                    <div className="flex justify-between items-end border-t border-brand-stone/60 pt-2">
                      <span className="font-mono text-xs font-bold text-brand-forest">£9.50</span>
                      <span className="text-[9px] uppercase tracking-wider font-sans font-bold text-brand-yellow flex items-center">
                        <Sparkles className="h-3 w-3 mr-1" /> Best Seller
                      </span>
                    </div>
                  </div>
                </div>

                <div className="z-10 text-center text-xs text-brand-forest/65 font-serif italic">
                  "Current Selection: Maldon Salted, Black Garlic & Wild Truffle"
                </div>
              </div>
            </section>

            {/* Brand Philosophy Section */}
            <section className="py-20 bg-brand-cream border-b border-brand-stone/30" id="philosophy-section">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                  
                  {/* Philosophy Text */}
                  <div className="space-y-6">
                    <span className="text-xs uppercase tracking-widest text-brand-oak font-sans font-bold block">
                      The Creed of Quality
                    </span>
                    <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-brand-forest tracking-wide">
                      "The finest butter deserves the finest presentation."
                    </h2>
                    <p className="font-sans text-sm text-brand-forest/80 leading-relaxed">
                      We believe dairy is a living canvas. Our craftsmen wait 36 hours for grass-fed single-herd cream to sour with lactic cultures, building an exquisite hazelnut complexity. We slow barrel-churn and hand-mold into logs, using traditional salt-flaking crystals and hand-foraged mountain herbs. No shortcuts, no compromises.
                    </p>
                    <div className="pt-2 flex space-x-6 text-xs text-brand-oak font-sans uppercase tracking-wider font-semibold">
                      <span>&bull; Pure Double Cream</span>
                      <span>&bull; Ancient Celtic Springs</span>
                      <span>&bull; zero synthetics</span>
                    </div>
                  </div>

                  {/* Philosophy Picture cards (Bento Style) */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="h-[280px] rounded overflow-hidden border border-brand-stone/40">
                      <img
                        src="https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=800"
                        alt="Artisanal freshly baked warm bread bread rolls and butter slabs"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="h-[280px] rounded overflow-hidden border border-brand-stone/40 translate-y-6">
                      <img
                        src="https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&q=80&w=800"
                        alt="Cream churn butter blocks salt flakes"
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* Featured Best Sellers Section */}
            <section className="py-20 bg-brand-linen/25 border-b border-brand-stone/30" id="best-sellers-section">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                
                {/* Heading */}
                <div className="flex justify-between items-end mb-12">
                  <div>
                    <span className="text-xs uppercase tracking-widest text-brand-oak font-sans font-bold">
                      Gourmet Staples
                    </span>
                    <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-brand-forest mt-1 tracking-wide">
                      Our Highly Coveted Churns
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveTab('shop')}
                    className="text-xs uppercase tracking-widest font-sans font-bold text-brand-forest hover:text-brand-oak flex items-center cursor-pointer hover:underline"
                  >
                    View Boutique Boutique &rarr;
                  </button>
                </div>
                 {/* Grid of 3 highlights */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {products.slice(0, 3).map((product) => (
                    <div
                      key={product.id}
                      onClick={() => setSelectedProduct(product)}
                      className="bg-brand-cream border border-brand-stone/60 rounded-none overflow-hidden group hover:border-brand-forest hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                    >
                      <div className="space-y-4">
                        {/* Img frame */}
                        <div className="h-[250px] overflow-hidden relative border-b border-brand-stone/30">
                          <img
                            src={product.image}
                            alt={product.name}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                          />
                          <div className="absolute top-4 left-4">
                            <span className="bg-brand-cream/95 backdrop-blur-sm text-brand-forest text-[9px] uppercase tracking-widest font-sans font-bold px-3 py-1.5 rounded-none shadow-sm border border-brand-stone/40">
                              {product.collection}
                            </span>
                          </div>
                        </div>

                        {/* Text */}
                        <div className="px-5 space-y-1.5 font-sans">
                          <div className="flex justify-between items-center">
                            <h3 className="font-serif text-lg font-bold text-brand-forest truncate pr-2">
                              {product.name}
                            </h3>
                            <span className="font-serif font-bold text-brand-forest shrink-0">
                              £{product.price.toFixed(2)}
                            </span>
                          </div>
                          <p className="text-xs text-brand-forest/65 line-clamp-2 leading-relaxed">
                            {product.tagline}
                          </p>
                        </div>
                      </div>

                      {/* Card bottom footer */}
                      <div className="p-5 border-t border-brand-stone/30 mt-4 flex justify-between items-center text-xs font-sans text-brand-forest/60">
                        <span className="flex items-center">
                          <Star className="h-4 w-4 fill-brand-brass text-brand-brass mr-1" />
                          <strong>{product.rating}</strong> ({product.reviewsCount} reviews)
                        </span>
                        <span className="font-bold tracking-widest uppercase text-[10px] group-hover:text-brand-oak">
                          View details
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            </section>

            {/* Quick Sourcing Map callout */}
            <section className="py-20 bg-brand-forest text-brand-cream" id="home-map-callout">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center max-w-2xl space-y-6">
                <span className="text-[10px] uppercase tracking-[0.3em] text-brand-yellow font-sans font-bold block">
                  Interactive Traceability
                </span>
                <h2 className="font-serif text-3xl sm:text-5xl font-semibold leading-tight">
                  Where Your Cream is Separated
                </h2>
                <p className="font-serif italic text-sm sm:text-base text-brand-cream/75 leading-relaxed">
                  We maintain zero secrecy. We trace every single block of our butter back to the family dairy pastures and heritage cows that feed on mineralized clover.
                </p>
                <button
                  onClick={() => setActiveTab('farms')}
                  className="bg-brand-yellow hover:bg-brand-cream text-brand-forest py-3.5 px-8 rounded cursor-pointer font-sans text-xs uppercase tracking-widest font-bold shadow-lg inline-flex items-center space-x-2"
                >
                  <Globe className="h-4 w-4 text-brand-forest shrink-0 animate-spin-slow" />
                  <span>Open Interactive Map</span>
                </button>
              </div>
            </section>
          </div>
        )}

        {/* VIEW 2: SHOP */}
        {activeTab === 'shop' && (
          <section className="py-12 bg-brand-cream animate-fade-in" id="shop-view">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              
              {/* Header section */}
              <div className="border-b border-brand-stone/40 pb-8 mb-10 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <div className="space-y-1">
                  <span className="text-[10px] tracking-widest uppercase text-brand-oak font-sans font-bold block">
                    The Complete Larder
                  </span>
                  <h1 className="font-serif text-3xl sm:text-4xl font-semibold text-brand-forest">
                    Artisanal Butter Boutique
                  </h1>
                </div>

                {/* Search Bar */}
                <div className="relative w-full md:max-w-xs font-sans">
                  <input
                    type="text"
                    placeholder="Search e.g. garlic, truffles, salted..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2.5 pl-9 text-xs focus:outline-none focus:border-brand-forest text-brand-forest"
                  />
                  <Search className="h-4 w-4 text-brand-forest/40 absolute left-3 top-3" />
                </div>
              </div>

              {/* Grid split: Filters left / Grid right */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                
                {/* Left side: Boutique Filters */}
                <div className="lg:col-span-3 bg-brand-linen/40 p-5 rounded-lg border border-brand-stone/40 space-y-6 font-sans">
                  
                  {/* Sub collections list */}
                  <div className="space-y-3">
                    <span className="text-[10px] tracking-widest uppercase font-bold text-brand-oak block border-b border-brand-stone/30 pb-1">
                      Collections
                    </span>
                    <div className="flex flex-col space-y-1" id="shop-categories-list">
                      {([
                        { id: 'all', label: 'All Collections' },
                        { id: 'classic', label: 'Classic Table Butter' },
                        { id: 'flavoured', label: 'Gourmet Flavoured' },
                        { id: 'seasonal', label: 'Limited Seasonal' },
                        { id: 'gift', label: 'Gifts & Hampers' }
                      ] as const).map((col) => (
                        <button
                          key={col.id}
                          onClick={() => setShopFilter(col.id)}
                          className={`w-full text-left py-2 px-3 text-xs uppercase tracking-wider font-semibold rounded transition-all cursor-pointer ${
                            shopFilter === col.id
                              ? 'bg-brand-forest text-brand-yellow font-extrabold shadow-sm'
                              : 'text-brand-forest/70 hover:bg-brand-stone/10'
                          }`}
                        >
                          {col.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Sorting dropdown */}
                  <div className="space-y-2">
                    <span className="text-[10px] tracking-widest uppercase font-bold text-brand-oak block border-b border-brand-stone/30 pb-1">
                      Sort Sequence
                    </span>
                    <div className="relative font-sans text-xs">
                      <select
                        value={shopSort}
                        onChange={(e: any) => setShopSort(e.target.value)}
                        className="w-full bg-brand-cream border border-brand-stone/60 rounded px-3 py-2 text-brand-forest focus:outline-none"
                      >
                        <option value="default">Traditional Default</option>
                        <option value="price-low">Price: Low to High</option>
                        <option value="price-high">Price: High to Low</option>
                        <option value="rating">Highest Rated</option>
                      </select>
                    </div>
                  </div>

                  {/* Trust badge */}
                  <div className="pt-4 border-t border-brand-stone/40 text-[10px] text-brand-forest/65 leading-relaxed space-y-2">
                    <p className="flex items-center">
                      <CheckCircle className="h-4.5 w-4.5 mr-2 text-brand-sage shrink-0" />
                      <span>Certified Pasture-fed Dairy</span>
                    </p>
                    <p className="flex items-center">
                      <CheckCircle className="h-4.5 w-4.5 mr-2 text-brand-sage shrink-0" />
                      <span>Insulated next-day delivery</span>
                    </p>
                  </div>
                </div>

                {/* Right side: Products Grid */}
                <div className="lg:col-span-9 space-y-6">
                  {getFilteredProducts().length === 0 ? (
                    <div className="text-center py-20 bg-brand-cream border rounded border-brand-stone/40" id="shop-empty-state">
                      <Info className="h-10 w-10 text-brand-stone mx-auto mb-2" />
                      <p className="text-sm font-sans text-brand-forest/60">No artisan blocks match your specific queries.</p>
                      <button
                        onClick={() => { setSearchQuery(''); setShopFilter('all'); }}
                        className="text-xs uppercase font-sans tracking-widest text-brand-forest underline font-bold mt-2 hover:text-brand-oak cursor-pointer"
                      >
                        Clear Active Filters
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6" id="shop-products-grid">
                      {getFilteredProducts().map((product) => (
                        <div
                          key={product.id}
                          onClick={() => setSelectedProduct(product)}
                          className="bg-brand-cream border border-brand-stone/60 rounded-lg overflow-hidden group hover:border-brand-forest hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
                        >
                          <div className="space-y-4">
                            {/* Visual wrapper */}
                            <div className="h-[200px] overflow-hidden relative border-b border-brand-stone/40">
                              <img
                                src={product.image}
                                alt={product.name}
                                referrerPolicy="no-referrer"
                                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                              />
                              
                              {/* Limited Edition badge */}
                              {product.isLimitedEdition && (
                                <span className="absolute top-3 left-3 bg-brand-brass text-brand-forest text-[8px] uppercase tracking-widest font-sans font-extrabold px-2 py-1 rounded shadow-sm">
                                  Limited
                                </span>
                              )}

                              {/* Save favorite quick click */}
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleFavorite(product.id);
                                }}
                                className="absolute top-3 right-3 p-2 bg-brand-cream/80 backdrop-blur-sm hover:bg-brand-cream rounded-full shadow-sm text-brand-forest hover:text-red-500 cursor-pointer transition-colors"
                                aria-label="Favorite"
                              >
                                <Heart className={`h-4 w-4 ${favoriteIds.includes(product.id) ? 'fill-brand-forest text-brand-forest' : ''}`} />
                              </button>
                            </div>

                            <div className="px-5 space-y-1.5 font-sans">
                              <div className="flex justify-between items-start">
                                <h3 className="font-serif text-base font-bold text-brand-forest leading-snug line-clamp-1 pr-1">
                                  {product.name}
                                </h3>
                                <span className="font-serif font-bold text-brand-forest shrink-0 text-sm">
                                  £{product.price.toFixed(2)}
                                </span>
                              </div>
                              <p className="text-xs text-brand-forest/65 line-clamp-2 leading-relaxed">
                                {product.tagline}
                              </p>
                            </div>
                          </div>

                          {/* Footer */}
                          <div className="p-5 border-t border-brand-stone/30 mt-4 flex justify-between items-center text-xs font-sans text-brand-forest/60">
                            <span className="flex items-center">
                              <Star className="h-3.5 w-3.5 fill-brand-brass text-brand-brass mr-1 shrink-0" />
                              <strong>{product.rating}</strong> ({product.reviewsCount} reviews)
                            </span>
                            <span className="font-bold tracking-widest uppercase text-[9px] group-hover:text-brand-oak">
                              Shop Block &rarr;
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            </div>
          </section>
        )}

        {/* VIEW 3: SUBSCRIPTIONS */}
        {activeTab === 'subscriptions' && (
          <SubscriptionSection
            onSubscribe={handleSubscribeToPlan}
            onCustomSubscribe={handleSubscribeToCustomBox}
          />
        )}

        {/* VIEW 4: OUR FARMS */}
        {activeTab === 'farms' && (
          <FarmsSection />
        )}

        {/* VIEW 5: RECIPES */}
        {activeTab === 'recipes' && (
          <RecipesSection
            onShopProduct={handleShopProductDetailsDirect}
            addToCart={addToCart}
          />
        )}

        {/* VIEW 6: ACCOUNT */}
        {activeTab === 'account' && (
          <AccountSection
            userAccount={userAccount}
            orders={orders}
            favoriteIds={favoriteIds}
            toggleFavorite={toggleFavorite}
            openProductDetail={(p) => setSelectedProduct(p)}
            addToCart={addToCart}
            onSkipNextDelivery={() => showToast("Success: Your next August subscription delivery has been skipped. You will not be billed.")}
            onDelayDelivery={() => showToast("Success: Next dispatch postponed by 14 days. Your billing schedule updated.")}
          />
        )}

      </main>

      {/* Slide-over Market Basket Cart Drawer */}
      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cartItems}
        updateQuantity={updateCartQuantity}
        removeFromCart={removeFromCart}
        triggerCheckout={() => {
          setCartOpen(false);
          setCheckoutOpen(true);
        }}
      />

      {/* One-Page Checkout Modal Overlay */}
      <CheckoutModal
        isOpen={checkoutOpen}
        onClose={() => setCheckoutOpen(false)}
        cartItems={cartItems}
        clearCart={clearCart}
        onOrderPlaced={handleOrderPlaced}
      />

      {/* Immersive Product Detail Modal Overlay */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={selectedProduct !== null}
        onClose={() => setSelectedProduct(null)}
        addToCart={addToCart}
        isFavorite={selectedProduct ? favoriteIds.includes(selectedProduct.id) : false}
        toggleFavorite={toggleFavorite}
      />

      {/* Editorial Newsletter & Site Footer */}
      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}
