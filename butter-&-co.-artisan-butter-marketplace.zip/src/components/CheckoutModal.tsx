import React, { useState } from 'react';
import { X, CreditCard, Sparkles, CheckCircle, Package, ArrowRight, Truck, Gift, ClipboardCheck } from 'lucide-react';
import { CartItem } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  clearCart: () => void;
  onOrderPlaced: (order: { id: string; total: number; date: string; itemsCount: number }) => void;
}

export default function CheckoutModal({
  isOpen,
  onClose,
  cartItems,
  clearCart,
  onOrderPlaced
}: CheckoutModalProps) {
  if (!isOpen) return null;

  // Checkout form fields
  const [email, setEmail] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [postcode, setPostcode] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  
  // Payment methods
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'apple' | 'google' | 'paypal'>('card');
  const [promoCode, setPromoCode] = useState('');
  const [promoApplied, setPromoApplied] = useState(false);
  const [promoDiscount, setPromoDiscount] = useState(0);

  // States
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [placedOrderId, setPlacedOrderId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const subtotal = cartItems.reduce((acc, item) => {
    const activePrice = item.isSubscription ? item.product.price * 0.9 : item.product.price;
    return acc + (activePrice * item.quantity);
  }, 0);

  const applyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'GOLDENBUTTER') {
      setPromoApplied(true);
      setPromoDiscount(10.00);
    } else {
      alert("Invalid code. Try using 'GOLDENBUTTER' for a £10.00 discount.");
    }
  };

  const deliveryFee = subtotal >= 35 || subtotal === 0 ? 0 : 4.50;
  const finalDiscount = Math.min(subtotal, promoDiscount);
  const total = Math.max(0, subtotal + deliveryFee - finalDiscount);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate gateway delay
    setTimeout(() => {
      const generatedId = 'BC-' + Math.floor(100000 + Math.random() * 900000);
      setPlacedOrderId(generatedId);
      setIsSubmitting(false);
      setOrderPlaced(true);
      
      onOrderPlaced({
        id: generatedId,
        total: total,
        date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
        itemsCount: cartItems.reduce((acc, item) => acc + item.quantity, 0)
      });
    }, 1500);
  };

  const handleFinishSuccess = () => {
    clearCart();
    setOrderPlaced(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-brand-forest/65 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 lg:p-8" id="checkout-modal">
      <div className="bg-brand-cream w-full max-w-4xl rounded-lg shadow-2xl overflow-hidden border border-brand-stone/40 max-h-[92vh] flex flex-col relative animate-fade-in">
        
        {/* Close Button */}
        {!orderPlaced && (
          <button
            id="close-checkout-btn"
            onClick={onClose}
            className="absolute right-4 top-4 z-10 bg-brand-cream/80 hover:bg-brand-forest hover:text-brand-yellow text-brand-forest p-2 rounded-full transition-colors cursor-pointer"
            aria-label="Cancel checkout"
          >
            <X className="h-5 w-5" />
          </button>
        )}

        <div className="overflow-y-auto flex-1">
          {orderPlaced ? (
            /* --- SUCCESS CONFIRMATION STATE --- */
            <div className="p-8 sm:p-16 text-center space-y-6 flex flex-col items-center max-w-xl mx-auto" id="checkout-success-panel">
              <div className="w-16 h-16 bg-brand-sage/20 text-brand-sage rounded-full flex items-center justify-center animate-pulse">
                <CheckCircle className="h-10 w-10 stroke-[1.5]" />
              </div>
              
              <div className="space-y-2">
                <span className="text-[10px] uppercase tracking-[0.3em] text-brand-oak font-sans font-bold">
                  Order Confirmed
                </span>
                <h2 className="font-serif text-3xl font-semibold text-brand-forest">
                  Thank You for Your Order
                </h2>
                <p className="text-xs text-brand-forest/70 font-sans leading-relaxed">
                  Your payment was secure and your order is being hand-packed inside our insulated chilled boxes. A receipt with tracking details has been sent to your email.
                </p>
              </div>

              {/* Order Receipt block */}
              <div className="w-full bg-brand-linen border border-brand-stone/40 p-6 rounded-md text-left space-y-3 font-sans">
                <div className="flex justify-between items-center text-xs pb-2 border-b border-brand-stone/40">
                  <span className="text-brand-forest/60">Order Reference:</span>
                  <span className="font-mono font-bold text-brand-forest">{placedOrderId}</span>
                </div>
                <div className="flex justify-between items-center text-xs pb-2 border-b border-brand-stone/40">
                  <span className="text-brand-forest/60">Chilled Dispatch:</span>
                  <span className="font-bold text-brand-forest flex items-center">
                    <Truck className="h-4.5 w-4.5 mr-1.5 text-brand-sage" /> Next Morning Express
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs pb-2 border-b border-brand-stone/40">
                  <span className="text-brand-forest/60">Estimated Arrival:</span>
                  <span className="font-bold text-brand-forest">In 48 Hours</span>
                </div>
                <div className="flex justify-between items-center text-sm font-bold text-brand-forest pt-1">
                  <span>Grand Total Paid:</span>
                  <span className="font-serif text-base text-brand-forest">£{total.toFixed(2)}</span>
                </div>
              </div>

              {/* Reward feedback */}
              <div className="bg-brand-forest text-brand-yellow p-4 rounded-md w-full flex items-center justify-center space-x-2 text-xs">
                <Sparkles className="h-4.5 w-4.5 text-brand-brass animate-bounce shrink-0" />
                <span>
                  <strong>+{Math.floor(subtotal * 10)} Loyalty Points</strong> credited! View your profile to redeem rewards.
                </span>
              </div>

              <button
                id="finish-checkout-btn"
                onClick={handleFinishSuccess}
                className="w-full bg-brand-forest hover:bg-brand-oak text-brand-cream text-xs uppercase tracking-widest py-3.5 font-bold rounded shadow-md transition-colors cursor-pointer flex items-center justify-center space-x-2"
              >
                <span>Return to Butter Boutique</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          ) : (
            /* --- ACTIVE CHECKOUT FORM STATE --- */
            <div className="grid grid-cols-1 lg:grid-cols-12">
              
              {/* Left Column: Checkout Inputs (7 cols) */}
              <form onSubmit={handleSubmit} className="p-6 sm:p-10 lg:col-span-7 space-y-8" id="checkout-form-fields">
                <div className="space-y-1">
                  <span className="text-[10px] tracking-[0.25em] uppercase text-brand-oak font-sans font-semibold">
                    Luxury Food Transport
                  </span>
                  <h2 className="font-serif text-2xl font-semibold text-brand-forest">
                    One-Page Premium Checkout
                  </h2>
                </div>

                {/* Section 1: Email and Identity */}
                <div className="space-y-4">
                  <h3 className="font-serif text-base font-semibold text-brand-forest border-b border-brand-stone/40 pb-2 flex items-center">
                    <span className="bg-brand-forest text-brand-yellow text-xs w-5 h-5 rounded-full flex items-center justify-center mr-2 font-mono">1</span>
                    Customer Identity
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">
                        Email Address (for order tracking)
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="e.g. sven@scandinaviadairy.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest font-sans"
                      />
                    </div>
                  </div>
                </div>

                {/* Section 2: Shipping Address */}
                <div className="space-y-4">
                  <h3 className="font-serif text-base font-semibold text-brand-forest border-b border-brand-stone/40 pb-2 flex items-center">
                    <span className="bg-brand-forest text-brand-yellow text-xs w-5 h-5 rounded-full flex items-center justify-center mr-2 font-mono">2</span>
                    Protected Chilled Delivery Address
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">First Name</label>
                      <input
                        type="text"
                        required
                        placeholder="Sven"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Last Name</label>
                      <input
                        type="text"
                        required
                        placeholder="Lindqvist"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Delivery Address Line 1</label>
                    <input
                      type="text"
                      required
                      placeholder="12 Cotswold Green Cottage, Herb Lane"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Town / City</label>
                      <input
                        type="text"
                        required
                        placeholder="Chipping Campden"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Postcode</label>
                      <input
                        type="text"
                        required
                        placeholder="GL55 6XX"
                        value={postcode}
                        onChange={(e) => setPostcode(e.target.value)}
                        className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest"
                      />
                    </div>
                  </div>
                </div>

                {/* Section 3: Payment details */}
                <div className="space-y-4">
                  <h3 className="font-serif text-base font-semibold text-brand-forest border-b border-brand-stone/40 pb-2 flex items-center">
                    <span className="bg-brand-forest text-brand-yellow text-xs w-5 h-5 rounded-full flex items-center justify-center mr-2 font-mono">3</span>
                    Secure Settlement Gate
                  </h3>

                  {/* Payment selection icons */}
                  <div className="grid grid-cols-4 gap-2" id="payment-method-selector">
                    {(['card', 'apple', 'google', 'paypal'] as const).map((method) => (
                      <button
                        key={method}
                        type="button"
                        onClick={() => setPaymentMethod(method)}
                        className={`py-3 px-1 border rounded-md flex flex-col items-center justify-center text-[10px] font-sans font-bold uppercase tracking-wider cursor-pointer transition-all ${
                          paymentMethod === method
                            ? 'border-brand-forest bg-brand-forest text-brand-yellow font-extrabold shadow-md'
                            : 'border-brand-stone bg-brand-linen text-brand-forest/70 hover:bg-brand-stone/20'
                        }`}
                      >
                        <CreditCard className="h-4.5 w-4.5 mb-1 shrink-0" />
                        <span>{method === 'card' ? 'Card' : method === 'apple' ? 'Apple Pay' : method === 'google' ? 'Google Pay' : 'PayPal'}</span>
                      </button>
                    ))}
                  </div>

                  {paymentMethod === 'card' ? (
                    <div className="space-y-3 animate-fade-in" id="card-inputs">
                      <div>
                        <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Cardholder Name</label>
                        <input
                          type="text"
                          required={paymentMethod === 'card'}
                          placeholder="Sven Lindqvist"
                          value={cardHolder}
                          onChange={(e) => setCardHolder(e.target.value)}
                          className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Card Number</label>
                        <input
                          type="text"
                          required={paymentMethod === 'card'}
                          placeholder="4000 1234 5678 9010"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest font-mono"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Expiration (MM/YY)</label>
                          <input
                            type="text"
                            required={paymentMethod === 'card'}
                            placeholder="12/28"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Security Code (CVV)</label>
                          <input
                            type="password"
                            required={paymentMethod === 'card'}
                            placeholder="***"
                            maxLength={3}
                            value={cardCvv}
                            onChange={(e) => setCardCvv(e.target.value)}
                            className="w-full bg-brand-linen border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest font-mono"
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="p-4 bg-brand-linen text-center rounded border border-brand-stone/40 font-sans text-xs text-brand-forest/70 py-6 space-y-2 animate-fade-in">
                      <Sparkles className="h-6 w-6 text-brand-brass mx-auto animate-bounce" />
                      <p>Will connect instantly to your pre-authorized {paymentMethod} secure wallet during settlement.</p>
                    </div>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  id="checkout-submit-btn"
                  className="w-full bg-brand-forest hover:bg-brand-oak text-brand-cream hover:text-brand-yellow text-xs uppercase tracking-widest py-4 font-bold rounded shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
                >
                  <ClipboardCheck className="h-5 w-5" />
                  <span>
                    {isSubmitting ? 'Verifying Safe Settlement...' : `Confirm Order Purchase &bull; £${total.toFixed(2)}`}
                  </span>
                </button>
              </form>

              {/* Right Column: Order Review Panel (5 cols) */}
              <div className="bg-brand-linen p-6 sm:p-10 lg:col-span-5 border-l border-brand-stone/40 flex flex-col justify-between" id="checkout-order-review">
                <div className="space-y-6">
                  <h3 className="font-serif text-lg font-medium text-brand-forest border-b border-brand-stone/40 pb-2">
                    Review Basket Selection
                  </h3>

                  {/* List of checkout items */}
                  <div className="space-y-4 max-h-[220px] overflow-y-auto pr-2" id="checkout-items-list">
                    {cartItems.map((item, idx) => {
                      const activePrice = item.isSubscription ? item.product.price * 0.9 : item.product.price;
                      return (
                        <div key={idx} className="flex items-center space-x-3 text-xs text-brand-forest font-sans">
                          <div className="w-10 h-10 rounded overflow-hidden shrink-0 border border-brand-stone/40">
                            <img src={item.product.image} alt={item.product.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold truncate">{item.product.name}</p>
                            <p className="text-[10px] text-brand-forest/60">
                              Qty {item.quantity} &bull; {item.isSubscription ? 'Monthly Sub' : 'One-time'}
                            </p>
                          </div>
                          <span className="font-bold">£{(activePrice * item.quantity).toFixed(2)}</span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Promo Input */}
                  <div className="border-t border-brand-stone/40 pt-4 space-y-2">
                    <label className="block text-[9px] uppercase tracking-wider font-bold text-brand-forest/70">
                      Artisan Promo Card / Gift Code
                    </label>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        placeholder="e.g. GOLDENBUTTER"
                        value={promoCode}
                        onChange={(e) => setPromoCode(e.target.value)}
                        className="flex-1 bg-brand-cream border border-brand-stone/60 rounded px-3 py-1.5 text-xs focus:outline-none focus:border-brand-forest font-sans"
                      />
                      <button
                        type="button"
                        onClick={applyPromo}
                        className="bg-brand-forest hover:bg-brand-oak text-brand-cream text-[10px] uppercase tracking-widest px-3 font-semibold rounded cursor-pointer transition-colors"
                      >
                        Apply
                      </button>
                    </div>
                    {promoApplied ? (
                      <span className="text-[10px] text-brand-sage font-bold flex items-center bg-brand-sage/15 p-1 px-2 rounded mt-1.5" id="promo-badge">
                        <Gift className="h-3.5 w-3.5 mr-1" /> Promo applied: -£10.00 Off
                      </span>
                    ) : (
                      <span className="text-[9px] text-brand-forest/40 block">
                        Tip: Apply coupon <strong>GOLDENBUTTER</strong> to get £10.00 off.
                      </span>
                    )}
                  </div>
                </div>

                {/* Calculation Summary block */}
                <div className="border-t border-brand-stone/40 pt-4 mt-6 space-y-2 text-xs text-brand-forest/80 font-sans">
                  <div className="flex justify-between">
                    <span>Products Subtotal:</span>
                    <span>£{subtotal.toFixed(2)}</span>
                  </div>
                  {promoApplied && (
                    <div className="flex justify-between text-brand-sage font-semibold">
                      <span>Promo Discount:</span>
                      <span>-£{finalDiscount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Chilled Carbon-Neutral Cargo:</span>
                    <span>{deliveryFee === 0 ? <strong className="text-brand-sage uppercase">Free</strong> : `£${deliveryFee.toFixed(2)}`}</span>
                  </div>
                  <div className="border-t-2 border-brand-forest pt-2 flex justify-between font-serif text-sm font-extrabold text-brand-forest">
                    <span>Grand Total:</span>
                    <span className="text-base text-brand-forest">£{total.toFixed(2)}</span>
                  </div>
                </div>

              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
}
