import { useState } from 'react';
import { Menu, X, ShoppingBag, User, Sparkles, Heart } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  openCart: () => void;
  favoritesCount: number;
  openAccount: () => void;
}

export default function Header({
  activeTab,
  setActiveTab,
  cartCount,
  openCart,
  favoritesCount,
  openAccount
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop Butter' },
    { id: 'subscriptions', label: 'Subscriptions' },
    { id: 'farms', label: 'Our Farms' },
    { id: 'recipes', label: 'Recipes' }
  ];

  const handleNavClick = (id: string) => {
    setActiveTab(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-50 bg-brand-cream/90 backdrop-blur-md border-b border-brand-stone/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Mobile Menu Trigger */}
          <div className="flex items-center md:hidden">
            <button
              id="mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-brand-forest hover:text-brand-oak transition-colors p-2"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Navigation Links - Desktop Left */}
          <nav className="hidden md:flex space-x-8 items-center" id="desktop-nav-left">
            {navItems.slice(0, 3).map((item) => (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`text-sm tracking-widest uppercase font-sans font-medium transition-colors cursor-pointer relative py-2 ${
                  activeTab === item.id
                    ? 'text-brand-forest'
                    : 'text-brand-forest/60 hover:text-brand-forest'
                }`}
              >
                {item.label}
                {activeTab === item.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-brand-oak" />
                )}
              </button>
            ))}
          </nav>

          {/* Central Elegant Branding */}
          <div className="flex flex-col items-center cursor-pointer select-none" onClick={() => handleNavClick('home')} id="header-brand">
            <span className="font-serif text-2xl lg:text-3xl font-bold tracking-[0.18em] text-brand-forest">
              BUTTER & CO.
            </span>
            <span className="text-[9px] tracking-[0.35em] uppercase text-brand-oak font-sans mt-0.5 font-medium">
              Artisan Butter Marketplace
            </span>
          </div>

          {/* Navigation Links - Desktop Right */}
          <nav className="hidden md:flex space-x-8 items-center" id="desktop-nav-right">
            {navItems.slice(3).map((item) => (
              <button
                key={item.id}
                id={`nav-${item.id}`}
                onClick={() => handleNavClick(item.id)}
                className={`text-sm tracking-widest uppercase font-sans font-medium transition-colors cursor-pointer relative py-2 ${
                  activeTab === item.id
                    ? 'text-brand-forest'
                    : 'text-brand-forest/60 hover:text-brand-forest'
                }`}
              >
                {item.label}
                {activeTab === item.id && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-brand-oak" />
                )}
              </button>
            ))}
          </nav>

          {/* Action Icons */}
          <div className="flex items-center space-x-4 sm:space-x-6" id="header-actions">
            {/* Saved Favorites Shortcut */}
            <button
              id="header-favorites-btn"
              onClick={openAccount}
              className="text-brand-forest/70 hover:text-brand-forest relative p-1.5 transition-colors cursor-pointer"
              title="Saved Favorites"
            >
              <Heart className="h-5.5 w-5.5" />
              {favoritesCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-brand-forest text-brand-yellow text-[9px] w-4.5 h-4.5 rounded-none flex items-center justify-center font-sans font-bold shadow-sm">
                  {favoritesCount}
                </span>
              )}
            </button>

            {/* Profile / Account */}
            <button
              id="header-account-btn"
              onClick={openAccount}
              className={`p-1.5 transition-colors cursor-pointer ${
                activeTab === 'account' ? 'text-brand-forest' : 'text-brand-forest/70 hover:text-brand-forest'
              }`}
              title="Customer Account"
            >
              <User className="h-5.5 w-5.5" />
            </button>

            {/* Premium Shopping Cart */}
            <button
              id="header-cart-btn"
              onClick={openCart}
              className="text-brand-forest hover:text-brand-yellow relative p-2 transition-colors cursor-pointer bg-brand-linen hover:bg-brand-forest hover:text-brand-yellow rounded-none border border-brand-stone/60"
              aria-label="Shopping bag"
            >
              <ShoppingBag className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-brand-forest text-brand-yellow text-[9px] w-4.5 h-4.5 rounded-none flex items-center justify-center font-sans font-bold border border-brand-yellow/30 shadow-sm animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-brand-cream border-b border-brand-stone/60 px-4 pt-2 pb-6 space-y-3 shadow-lg" id="mobile-nav-menu">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`mobile-nav-${item.id}`}
              onClick={() => handleNavClick(item.id)}
              className={`block w-full text-left px-4 py-3 text-sm tracking-widest uppercase font-sans font-medium rounded-md transition-colors ${
                activeTab === item.id
                  ? 'bg-brand-linen text-brand-forest font-semibold border-l-2 border-brand-oak'
                  : 'text-brand-forest/70 hover:bg-brand-linen/50 hover:text-brand-forest'
              }`}
            >
              {item.label}
            </button>
          ))}
          <button
            id="mobile-nav-account"
            onClick={() => handleNavClick('account')}
            className={`flex items-center space-x-2 w-full text-left px-4 py-3 text-sm tracking-widest uppercase font-sans font-medium rounded-md transition-colors ${
              activeTab === 'account'
                ? 'bg-brand-linen text-brand-forest font-semibold border-l-2 border-brand-oak'
                : 'text-brand-forest/70 hover:bg-brand-linen/50 hover:text-brand-forest'
            }`}
          >
            <User className="h-4 w-4" />
            <span>My Account</span>
          </button>
          <div className="px-4 py-3 border-t border-brand-stone/40 flex items-center justify-between mt-2">
            <span className="text-[10px] tracking-widest uppercase text-brand-oak font-sans font-semibold flex items-center">
              <Sparkles className="h-3 w-3 mr-1.5 text-brand-brass animate-pulse" />
              Small Batch Butter
            </span>
            <span className="text-[9px] text-brand-forest/50 font-sans">
              Free Shipping over £35
            </span>
          </div>
        </div>
      )}
    </header>
  );
}
