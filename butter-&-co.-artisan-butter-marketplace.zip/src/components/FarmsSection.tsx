import { useState } from 'react';
import { MapPin, ShieldCheck, Heart, Leaf, Award, Compass, Globe, CheckCircle } from 'lucide-react';
import { Farm } from '../types';
import { farms } from '../data/farms';

export default function FarmsSection() {
  const [selectedFarm, setSelectedFarm] = useState<Farm>(farms[0]);
  const [hoveredFarmId, setHoveredFarmId] = useState<string | null>(null);

  return (
    <section className="py-16 bg-brand-cream" id="farms-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-[10px] tracking-[0.35em] uppercase text-brand-oak font-sans font-bold flex items-center justify-center">
            <Compass className="h-4.5 w-4.5 mr-2 text-brand-brass animate-spin-slow" />
            100% Traceable Sourcing
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl font-semibold text-brand-forest tracking-wide">
            Our Certified Pastures
          </h2>
          <p className="font-serif italic text-base text-brand-forest/70 leading-relaxed">
            "Transparency is the soul of craftsmanship. We trace every single block of butter back to the family dairy pastures where it was slowly churned."
          </p>
        </div>

        {/* Content Split: Left Stylized Map / Right Farm Bio Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Column: Stylized Vector Map (7 cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            <div className="bg-brand-linen border border-brand-stone/60 rounded-none p-6 relative flex flex-col justify-between h-[450px] overflow-hidden shadow-inner">
              {/* Abstract Map Background Grids */}
              <div className="absolute inset-0 opacity-[0.06] pointer-events-none font-mono text-[9px] text-brand-forest p-4 select-none leading-none">
                {Array.from({ length: 15 }).map((_, i) => (
                  <div key={i} className="mb-2.5">
                    GRID_REF_0{100 + i * 23} // LAT_51.{2345 + i * 11}2°N // LON_0.{3456 - i * 14}5°W // COROMANDEL_STATION // PASTURE_MOISTURE_78%
                  </div>
                ))}
              </div>

              {/* Decorative Compass Rose and Scale */}
              <div className="absolute bottom-6 left-6 flex items-center space-x-3 text-brand-forest/40 text-[9px] font-sans font-bold tracking-widest uppercase">
                <Compass className="h-8 w-8 stroke-[1.2]" />
                <div>
                  <p>Mendip &bull; Cotswolds &bull; Jutland</p>
                  <p>Scale 1 : 2,400,000</p>
                </div>
              </div>

              {/* Graphical representation of land/sea (highly abstract minimalist design) */}
              <div className="absolute top-1/4 right-1/4 w-[300px] h-[300px] bg-brand-sage/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-10 left-10 w-[200px] h-[200px] bg-brand-yellow/10 rounded-full blur-2xl pointer-events-none" />

              {/* Title Overlay */}
              <div className="z-10 bg-brand-cream/80 backdrop-blur-sm p-3.5 border border-brand-stone/40 max-w-xs rounded-sm">
                <span className="text-[9px] uppercase tracking-widest font-sans font-bold text-brand-oak flex items-center">
                  <Globe className="h-3 w-3 mr-1 text-brand-sage" /> Visual Coordinates
                </span>
                <p className="font-serif text-sm font-semibold text-brand-forest mt-1">
                  Western European Milk Belt
                </p>
                <p className="text-[10px] text-brand-forest/60 font-sans mt-0.5">
                  Click pins to trace single-origin dairies.
                </p>
              </div>

              {/* Interactive Farm Map Pins */}
              <div className="absolute inset-0" id="interactive-map-stage">
                {farms.map((farm) => {
                  const isSelected = selectedFarm.id === farm.id;
                  const isHovered = hoveredFarmId === farm.id;
                  
                  return (
                    <button
                      key={farm.id}
                      id={`map-pin-${farm.id}`}
                      onClick={() => setSelectedFarm(farm)}
                      onMouseEnter={() => setHoveredFarmId(farm.id)}
                      onMouseLeave={() => setHoveredFarmId(null)}
                      className="absolute group transition-all duration-300 transform -translate-x-1/2 -translate-y-1/2 cursor-pointer focus:outline-none"
                      style={{ left: `${farm.coords.x}%`, top: `${farm.coords.y}%` }}
                    >
                      {/* Pulse effect for selected pin */}
                      {isSelected && (
                        <span className="absolute -inset-2.5 bg-brand-oak/25 rounded-full animate-ping pointer-events-none" />
                      )}

                      <div className={`p-2 rounded-full border transition-all flex items-center justify-center shadow-md ${
                        isSelected
                          ? 'bg-brand-forest border-brand-yellow text-brand-yellow scale-125'
                          : 'bg-brand-cream border-brand-stone hover:border-brand-forest text-brand-forest hover:scale-110'
                      }`}>
                        <MapPin className="h-4.5 w-4.5" />
                      </div>

                      {/* Tooltip on hover */}
                      {(isHovered || isSelected) && (
                        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-brand-forest text-brand-cream text-[10px] tracking-wider uppercase font-sans font-bold py-1.5 px-3 rounded shadow-lg whitespace-nowrap z-20 flex items-center border border-brand-yellow/30">
                          <CheckCircle className="h-3 w-3 text-brand-sage mr-1.5 shrink-0" />
                          <span>{farm.name}</span>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Legend Summary */}
              <div className="z-10 text-right self-end mt-auto font-sans text-[10px] text-brand-forest/60">
                <p>&bull; Latitude &bull; Longitude coordinate tracking verified</p>
                <p>100% pasture-grazing welfare guarantee</p>
              </div>
            </div>

            {/* Farm Cards Quick Scroller */}
            <div className="grid grid-cols-5 gap-2" id="farm-selector-row">
              {farms.map((farm) => (
                <button
                  key={farm.id}
                  id={`select-btn-${farm.id}`}
                  onClick={() => setSelectedFarm(farm)}
                  className={`py-3 px-1 border text-center font-sans text-[10px] uppercase tracking-wider font-semibold rounded-none transition-all cursor-pointer truncate ${
                    selectedFarm.id === farm.id
                      ? 'bg-brand-forest border-brand-forest text-brand-yellow font-extrabold'
                      : 'bg-brand-linen/60 border-brand-stone hover:bg-brand-linen text-brand-forest/70'
                  }`}
                >
                  {farm.name.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Right Column: Narrative Biography Card (5 cols) */}
          <div className="lg:col-span-5 flex flex-col justify-between" id="selected-farm-card">
            <div className="bg-brand-linen rounded-none border border-brand-stone/60 p-6 sm:p-8 space-y-6 flex-1 flex flex-col justify-between shadow-sm animate-fade-in">
              <div className="space-y-6">
                
                {/* Farmer identity header */}
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[10px] uppercase tracking-[0.2em] text-brand-oak font-sans font-bold block mb-1">
                      Lead Husbandry
                    </span>
                    <h3 className="font-serif text-2xl font-bold text-brand-forest">
                      {selectedFarm.name}
                    </h3>
                    <p className="text-xs text-brand-forest/60 font-sans mt-0.5">
                      Managed by: <strong>{selectedFarm.farmer}</strong>
                    </p>
                  </div>
                  <span className="bg-brand-forest/10 border border-brand-forest/30 text-brand-forest text-[10px] font-sans font-bold py-1 px-3 rounded-none shrink-0 uppercase tracking-wider flex items-center">
                    <ShieldCheck className="h-4 w-4 mr-1 text-brand-sage shrink-0" /> Certified
                  </span>
                </div>

                {/* Imagery from selected farm */}
                <div className="h-[200px] rounded-none overflow-hidden border border-brand-stone/40 relative">
                  <img
                    src={selectedFarm.image}
                    alt={selectedFarm.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
                  <span className="absolute bottom-3 left-3 font-sans text-[10px] text-brand-cream/80 flex items-center">
                    <MapPin className="h-3.5 w-3.5 mr-1 text-brand-yellow" />
                    {selectedFarm.location}
                  </span>
                </div>

                {/* Narrative description */}
                <div className="space-y-3 font-sans text-sm text-brand-forest/95 leading-relaxed">
                  <h4 className="font-serif text-lg font-semibold text-brand-forest border-b border-brand-stone/40 pb-1.5">
                    The Farmer’s Story
                  </h4>
                  <p className="text-xs italic leading-relaxed text-brand-forest/80">
                    "{selectedFarm.story}"
                  </p>
                </div>

                {/* Farm Quality Metrics */}
                <div className="border-t border-brand-stone/40 pt-4 grid grid-cols-2 gap-4 text-xs font-sans">
                  <div className="space-y-1 bg-brand-cream p-3 rounded-none border border-brand-stone/30">
                    <span className="text-[9px] uppercase tracking-wider font-bold text-brand-oak block flex items-center">
                      <Heart className="h-3.5 w-3.5 mr-1 text-red-500" /> Animal Welfare
                    </span>
                    <span className="font-extrabold text-brand-forest text-sm">
                      {selectedFarm.welfareScore}
                    </span>
                  </div>
                  <div className="space-y-1 bg-brand-cream p-3 rounded-none border border-brand-stone/30">
                    <span className="text-[9px] uppercase tracking-wider font-bold text-brand-sage block flex items-center">
                      <Leaf className="h-3.5 w-3.5 mr-1 text-brand-sage" /> Sustainability
                    </span>
                    <span className="font-semibold text-brand-forest text-[11px] leading-snug block">
                      Rotational paddock carbon capture &bull; Renewable Energy
                    </span>
                  </div>
                </div>

                {/* Farm Crafts Methods */}
                <div className="space-y-2">
                  <h5 className="text-[10px] uppercase tracking-widest font-bold text-brand-oak flex items-center">
                    <Award className="h-4 w-4 mr-1.5 text-brand-brass" /> Certified Farming Protocols
                  </h5>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedFarm.methods.map((meth, idx) => (
                      <span key={idx} className="bg-brand-cream text-brand-forest border border-brand-stone/60 text-[10px] py-1 px-2.5 rounded-none font-sans font-medium">
                        &bull; {meth}
                      </span>
                    ))}
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
