import { useState } from 'react';
import { Clock, Users, BookOpen, ChevronRight, Check, ShoppingBag, Sparkles } from 'lucide-react';
import { recipes } from '../data/recipes';
import { products } from '../data/products';
import { Recipe, Product } from '../types';

interface RecipesSectionProps {
  onShopProduct: (productId: string) => void;
  addToCart: (product: Product, quantity: number, isSub: boolean) => void;
}

export default function RecipesSection({ onShopProduct, addToCart }: RecipesSectionProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);

  const categories = [
    { id: 'all', label: 'All Recipes' },
    { id: 'pastries', label: 'Pastries & Baking' },
    { id: 'breakfast', label: 'Breakfast' },
    { id: 'steak', label: 'Steak & Meats' },
    { id: 'seafood', label: 'Seafood' },
    { id: 'vegetables', label: 'Vegetables' }
  ];

  const filteredRecipes = activeCategory === 'all'
    ? recipes
    : recipes.filter(r => r.category === activeCategory);

  const getFeaturedButter = (butterId: string): Product | undefined => {
    return products.find(p => p.id === butterId);
  };

  const handleShopFeaturedButter = (butterId: string) => {
    onShopProduct(butterId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddFeaturedButterToCart = (butter: Product) => {
    addToCart(butter, 1, false);
    alert(`${butter.name} added to your basket!`);
  };

  return (
    <section className="py-16 bg-brand-cream" id="recipes-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-[10px] tracking-[0.35em] uppercase text-brand-oak font-sans font-bold flex items-center justify-center">
            <BookOpen className="h-4.5 w-4.5 mr-2 text-brand-brass" />
            Culinary Chronicles
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl font-semibold text-brand-forest tracking-wide">
            The Butter Magazine
          </h2>
          <p className="font-serif italic text-base text-brand-forest/70 leading-relaxed">
            "Exceptional cooking is a conversation between premium ingredients. Explore our seasonal baking blueprints and gourmet steak basting tutorials."
          </p>
        </div>

        {selectedRecipe ? (
          /* --- DETAILED VIEW FOR SINGLE RECIPE --- */
          <div className="bg-brand-linen/40 border border-brand-stone/60 rounded-lg p-6 sm:p-10 lg:p-14 shadow-sm animate-fade-in" id="recipe-detail-panel">
            {/* Back to Magazine */}
            <button
              onClick={() => setSelectedRecipe(null)}
              className="text-brand-forest/60 hover:text-brand-forest text-xs uppercase tracking-widest font-sans font-bold flex items-center mb-8 cursor-pointer hover:underline"
            >
              &larr; Return to Recipe Index
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              
              {/* Left Side: Recipe Info & Imagery (7 cols) */}
              <div className="lg:col-span-7 space-y-8">
                <div className="space-y-4">
                  <span className="text-xs uppercase tracking-widest text-brand-oak font-sans font-bold">
                    Category: {selectedRecipe.category}
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl font-semibold text-brand-forest leading-tight">
                    {selectedRecipe.title}
                  </h3>
                  <p className="text-sm font-sans text-brand-forest/80 leading-relaxed italic">
                    "{selectedRecipe.description}"
                  </p>
                </div>

                {/* Cover Image */}
                <div className="h-[350px] rounded overflow-hidden border border-brand-stone/40">
                  <img
                    src={selectedRecipe.image}
                    alt={selectedRecipe.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Step-by-Step Directions */}
                <div className="space-y-6">
                  <h4 className="font-serif text-xl font-bold text-brand-forest border-b border-brand-stone/40 pb-2">
                    Method & Preparation
                  </h4>
                  <ol className="space-y-5 font-sans">
                    {selectedRecipe.instructions.map((step, idx) => (
                      <li key={idx} className="flex space-x-4">
                        <span className="bg-brand-forest text-brand-yellow font-mono text-sm w-7 h-7 rounded-full flex items-center justify-center shrink-0">
                          {idx + 1}
                        </span>
                        <p className="text-sm text-brand-forest/90 leading-relaxed mt-0.5">
                          {step}
                        </p>
                      </li>
                    ))}
                  </ol>
                </div>
              </div>

              {/* Right Side: Ingredients Checklist & Featured Butter Shop Block (5 cols) */}
              <div className="lg:col-span-5 space-y-8">
                
                {/* Recipe Timings Summary */}
                <div className="bg-brand-cream border border-brand-stone/40 p-5 rounded-md flex justify-between text-center text-brand-forest/80 font-sans text-xs">
                  <div className="flex flex-col items-center flex-1 border-r border-brand-stone/40">
                    <Clock className="h-5 w-5 mb-1.5 text-brand-oak" />
                    <span className="font-semibold uppercase tracking-wider text-[9px] text-brand-forest/50">Prep Phase</span>
                    <span className="font-bold text-brand-forest">{selectedRecipe.prepTime}</span>
                  </div>
                  <div className="flex flex-col items-center flex-1 border-r border-brand-stone/40">
                    <Clock className="h-5 w-5 mb-1.5 text-brand-oak" />
                    <span className="font-semibold uppercase tracking-wider text-[9px] text-brand-forest/50">Cook Phase</span>
                    <span className="font-bold text-brand-forest">{selectedRecipe.cookTime}</span>
                  </div>
                  <div className="flex flex-col items-center flex-1">
                    <Users className="h-5 w-5 mb-1.5 text-brand-oak" />
                    <span className="font-semibold uppercase tracking-wider text-[9px] text-brand-forest/50">Serves</span>
                    <span className="font-bold text-brand-forest">{selectedRecipe.servings} guests</span>
                  </div>
                </div>

                {/* Ingredients checklist */}
                <div className="bg-brand-cream border border-brand-stone/60 p-6 sm:p-8 rounded-lg space-y-4 shadow-sm">
                  <h4 className="font-serif text-lg font-bold text-brand-forest border-b border-brand-stone/40 pb-2">
                    Gourmet Ingredients
                  </h4>
                  <ul className="space-y-3 font-sans text-xs text-brand-forest/85">
                    {selectedRecipe.ingredients.map((ing, idx) => (
                      <li key={idx} className="flex items-start">
                        <Check className="h-4.5 w-4.5 text-brand-sage mr-2.5 shrink-0 mt-0.5" />
                        <span>{ing}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Featured Butter Hook (Sells the actual product) */}
                {(() => {
                  const butter = getFeaturedButter(selectedRecipe.featuredButterId);
                  if (!butter) return null;
                  
                  return (
                    <div className="bg-brand-forest text-brand-cream rounded-lg p-6 space-y-4 border border-brand-yellow/20 shadow-md">
                      <span className="text-[9px] uppercase tracking-widest font-sans font-bold text-brand-yellow flex items-center">
                        <Sparkles className="h-4 w-4 mr-1.5 text-brand-brass animate-pulse" /> Crucial Recipe Component
                      </span>
                      <h4 className="font-serif text-lg font-bold">Featured Recipe Butter</h4>
                      
                      <div className="flex items-center space-x-3 bg-brand-cream/10 p-3 rounded border border-brand-cream/10">
                        <div className="w-12 h-12 rounded overflow-hidden shrink-0">
                          <img src={butter.image} alt={butter.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0 font-sans">
                          <p className="text-xs font-bold text-brand-yellow truncate">{butter.name}</p>
                          <p className="text-[10px] text-brand-cream/60 truncate">£{butter.price.toFixed(2)} / 250g block</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-center text-[10px] font-sans tracking-widest uppercase font-bold">
                        <button
                          onClick={() => handleAddFeaturedButterToCart(butter)}
                          className="bg-brand-yellow hover:bg-brand-cream text-brand-forest py-2.5 rounded cursor-pointer transition-colors flex items-center justify-center space-x-1"
                        >
                          <ShoppingBag className="h-3.5 w-3.5 shrink-0" />
                          <span>Buy Now</span>
                        </button>
                        <button
                          onClick={() => handleShopFeaturedButter(butter.id)}
                          className="bg-transparent hover:bg-brand-cream/10 text-white border border-brand-cream/20 py-2.5 rounded cursor-pointer transition-colors"
                        >
                          View Details
                        </button>
                      </div>
                    </div>
                  );
                })()}

              </div>

            </div>
          </div>
        ) : (
          /* --- RECIPE MATRIX GRID INDEX --- */
          <div className="space-y-12">
            {/* Category tabs */}
            <div className="flex flex-wrap justify-center gap-2 border-b border-brand-stone/40 pb-4 bg-brand-linen/20 p-2 rounded-md" id="recipe-categories">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  id={`cat-btn-${cat.id}`}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`py-2.5 px-5 text-xs uppercase tracking-widest font-sans font-bold rounded-md cursor-pointer transition-all ${
                    activeCategory === cat.id
                      ? 'bg-brand-forest text-brand-yellow font-extrabold shadow-sm'
                      : 'text-brand-forest/60 hover:text-brand-forest hover:bg-brand-stone/10'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Recipe Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="recipe-magazine-grid">
              {filteredRecipes.map((recipe) => (
                <div
                  key={recipe.id}
                  id={`recipe-card-${recipe.id}`}
                  onClick={() => setSelectedRecipe(recipe)}
                  className="bg-brand-cream border border-brand-stone/60 rounded-lg overflow-hidden flex flex-col justify-between shadow-sm cursor-pointer group hover:border-brand-forest hover:shadow-md transition-all"
                >
                  <div className="space-y-4">
                    {/* Picture cover */}
                    <div className="h-[220px] overflow-hidden relative border-b border-brand-stone/40">
                      <img
                        src={recipe.image}
                        alt={recipe.title}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                      
                      {/* Servings timing overlay */}
                      <span className="absolute bottom-3 left-3 bg-brand-cream/90 backdrop-blur-sm text-brand-forest text-[10px] uppercase tracking-widest font-sans font-bold px-3 py-1 rounded shadow-sm">
                        Serves {recipe.servings}
                      </span>
                    </div>

                    <div className="px-5 space-y-2 font-sans">
                      <span className="text-[9px] uppercase tracking-widest text-brand-oak font-bold block">
                        Category: {recipe.category}
                      </span>
                      <h4 className="font-serif text-xl font-bold text-brand-forest truncate group-hover:text-brand-oak transition-colors">
                        {recipe.title}
                      </h4>
                      <p className="text-xs text-brand-forest/70 line-clamp-2 leading-relaxed">
                        {recipe.description}
                      </p>
                    </div>
                  </div>

                  {/* Card bottom */}
                  <div className="p-5 border-t border-brand-stone/30 mt-4 flex justify-between items-center text-xs font-sans text-brand-forest/65">
                    <span className="flex items-center">
                      <Clock className="h-4.5 w-4.5 mr-1.5 text-brand-oak shrink-0" />
                      Prep & Cook: {recipe.prepTime}
                    </span>
                    <span className="text-brand-forest font-bold tracking-widest uppercase text-[10px] group-hover:text-brand-oak flex items-center">
                      View Recipe <ChevronRight className="h-4 w-4 ml-0.5 shrink-0" />
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
