import React, { useState } from 'react';
import { Mail, Sparkles, MapPin, Phone, MessageSquare, ShieldCheck, Award } from 'lucide-react';

export default function Footer({ setActiveTab }: { setActiveTab: (tab: string) => void }) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <footer className="bg-brand-forest text-brand-cream border-t border-brand-oak/20 pt-16 pb-12" id="site-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand Philosophy column */}
          <div className="space-y-6">
            <span className="font-serif text-2xl font-bold tracking-[0.18em] text-brand-yellow block">
              BUTTER & CO.
            </span>
            <p className="font-sans text-sm text-brand-cream/70 leading-relaxed max-w-sm">
              We celebrate traditional craftsmanship, local organic pastures, and slow culinary arts. Bringing the absolute finest double-churned and custom-infused butters from the British countryside and Nordic meadows to your dining table.
            </p>
            <div className="pt-2 flex flex-col space-y-1.5">
              <span className="text-[11px] tracking-widest uppercase text-brand-yellow font-sans font-semibold flex items-center">
                <Award className="h-4 w-4 mr-2 text-brand-brass" />
                Artisanal Flagship Shop
              </span>
              <span className="text-[11px] tracking-widest uppercase text-brand-yellow font-sans font-medium flex items-center">
                <ShieldCheck className="h-4 w-4 mr-2 text-brand-sage" />
                Certified Pasture Welfare
              </span>
            </div>
          </div>

          {/* Navigation Directory column */}
          <div className="space-y-4">
            <h4 className="font-serif text-lg font-medium tracking-wide text-brand-yellow border-b border-brand-cream/10 pb-2">
              Marketplace
            </h4>
            <ul className="space-y-2.5 text-sm font-sans">
              <li>
                <button
                  onClick={() => { setActiveTab('shop'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-brand-cream/75 hover:text-brand-yellow transition-colors cursor-pointer text-left"
                >
                  Classic Churns
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('shop'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-brand-cream/75 hover:text-brand-yellow transition-colors cursor-pointer text-left"
                >
                  Gourmet Flavoured Collection
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('subscriptions'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-brand-cream/75 hover:text-brand-yellow transition-colors cursor-pointer text-left"
                >
                  Monthly Butter Box
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('farms'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-brand-cream/75 hover:text-brand-yellow transition-colors cursor-pointer text-left"
                >
                  Meet Our Farmers
                </button>
              </li>
              <li>
                <button
                  onClick={() => { setActiveTab('recipes'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="text-brand-cream/75 hover:text-brand-yellow transition-colors cursor-pointer text-left"
                >
                  Editorial Recipes
                </button>
              </li>
            </ul>
          </div>

          {/* Core Values & Sourcing info */}
          <div className="space-y-4">
            <h4 className="font-serif text-lg font-medium tracking-wide text-brand-yellow border-b border-brand-cream/10 pb-2">
              Sourcing & Trust
            </h4>
            <div className="space-y-4 text-xs font-sans text-brand-cream/70 leading-relaxed">
              <p className="flex items-start">
                <MapPin className="h-4 w-4 mr-2.5 text-brand-yellow shrink-0 mt-0.5" />
                <span>
                  Our Butteries:<br />
                  Somerset Mendips &bull; Cotswolds AONB &bull; Jutland Coast Denmark &bull; Devon Valleys
                </span>
              </p>
              <p className="flex items-center">
                <Phone className="h-4 w-4 mr-2.5 text-brand-yellow shrink-0" />
                <span>+44 (0) 1632 960024</span>
              </p>
              <p className="flex items-center">
                <MessageSquare className="h-4 w-4 mr-2.5 text-brand-yellow shrink-0" />
                <span>curator@butterandco.com</span>
              </p>
            </div>
          </div>

          {/* Newsletter Column */}
          <div className="space-y-4">
            <h4 className="font-serif text-lg font-medium tracking-wide text-brand-yellow border-b border-brand-cream/10 pb-2">
              The Churn Letter
            </h4>
            <p className="font-sans text-xs text-brand-cream/70 leading-relaxed">
              Receive beautiful stories from the pastures, limited seasonal butter release notices, and chef-curated recipes.
            </p>
            {subscribed ? (
              <div className="p-4 bg-brand-cream/10 border border-brand-yellow/30 rounded-none text-center" id="newsletter-success">
                <p className="font-sans text-xs text-brand-yellow font-semibold flex items-center justify-center">
                  <Sparkles className="h-4 w-4 mr-1.5 text-brand-brass" />
                  You are on the list.
                </p>
                <p className="text-[10px] text-brand-cream/60 mt-1">100 Loyalty Points credited to your account!</p>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="space-y-2" id="newsletter-form">
                <div className="relative">
                  <input
                    type="email"
                    required
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-brand-cream/10 border border-brand-cream/20 rounded-none py-2.5 pl-3 pr-10 text-xs font-sans text-brand-cream placeholder-brand-cream/40 focus:outline-none focus:border-brand-yellow focus:ring-1 focus:ring-brand-yellow transition-all"
                  />
                  <button
                    type="submit"
                    className="absolute right-2.5 top-2.5 text-brand-yellow hover:text-white transition-colors cursor-pointer"
                    aria-label="Subscribe"
                  >
                    <Mail className="h-4 w-4" />
                  </button>
                </div>
                <span className="text-[10px] text-brand-cream/40 block font-sans">
                  By signing up, you agree to our respectful privacy standards.
                </span>
              </form>
            )}
          </div>
        </div>

        {/* Divider and copyright panel */}
        <div className="border-t border-brand-cream/10 pt-8 flex flex-col sm:flex-row justify-between items-center text-xs font-sans text-brand-cream/50 space-y-4 sm:space-y-0">
          <div>
            &copy; 2026 BUTTER & CO. Ltd. Crafted Slowly. Enjoyed Daily.
          </div>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-brand-yellow transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-brand-yellow transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-brand-yellow transition-colors">Pasture Welfare Promise</a>
            <a href="#" className="hover:text-brand-yellow transition-colors">Sustainability Audit</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
