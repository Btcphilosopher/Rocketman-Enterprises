import React, { useState } from 'react';
import { Award, Sparkles, MapPin, Gift, Clock, RefreshCw, AlertCircle, Heart, ShieldCheck, CheckCircle } from 'lucide-react';
import { UserAccount, Order, Product } from '../types';
import { products } from '../data/products';

interface AccountSectionProps {
  userAccount: UserAccount;
  orders: Order[];
  favoriteIds: string[];
  toggleFavorite: (productId: string) => void;
  openProductDetail: (product: Product) => void;
  addToCart: (product: Product, quantity: number, isSub: boolean) => void;
  onSkipNextDelivery: () => void;
  onDelayDelivery: () => void;
}

export default function AccountSection({
  userAccount,
  orders,
  favoriteIds,
  toggleFavorite,
  openProductDetail,
  addToCart,
  onSkipNextDelivery,
  onDelayDelivery
}: AccountSectionProps) {
  const [activeSubTab, setActiveSubTab] = useState<'profile' | 'subscriptions' | 'history' | 'favorites' | 'addresses'>('profile');
  const [subscriptionPaused, setSubscriptionPaused] = useState(false);
  const [subSwapProduct, setSubSwapProduct] = useState('Cultured Butter');
  const [addressLine1, setAddressLine1] = useState(userAccount.addresses[0]?.line1 || '');
  const [addressSaved, setAddressSaved] = useState(false);

  // Filter products matching favorites
  const favoriteProducts = products.filter(p => favoriteIds.includes(p.id));

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    setAddressSaved(true);
    setTimeout(() => setAddressSaved(false), 3000);
  };

  const handleAddFavToCart = (p: Product) => {
    addToCart(p, 1, false);
    alert(`${p.name} added to your basket!`);
  };

  return (
    <section className="py-16 bg-brand-cream" id="account-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-[10px] tracking-[0.35em] uppercase text-brand-oak font-sans font-bold flex items-center justify-center">
            <Award className="h-4.5 w-4.5 mr-2 text-brand-brass" />
            L’Atelier Club
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl font-semibold text-brand-forest tracking-wide">
            Your Country Club Lounge
          </h2>
          <p className="font-serif italic text-base text-brand-forest/70 leading-relaxed">
            "Savor the benefits of slowly matured craftsmanship. Manage subscriptions, track gourmet logs, and claim your loyalty rewards."
          </p>
        </div>

        {/* Dashboard Frame */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Sidebar Tabs Controller (3 cols) */}
          <div className="lg:col-span-3 space-y-2 bg-brand-linen/40 p-4 rounded-lg border border-brand-stone/40" id="account-tabs">
            <div className="px-3 pb-3 border-b border-brand-stone/40">
              <p className="font-serif text-base font-bold text-brand-forest">{userAccount.name}</p>
              <p className="text-[11px] text-brand-forest/60 font-sans">{userAccount.email}</p>
            </div>

            {(['profile', 'subscriptions', 'history', 'favorites', 'addresses'] as const).map((tab) => (
              <button
                key={tab}
                id={`account-tab-${tab}`}
                onClick={() => setActiveSubTab(tab)}
                className={`w-full text-left px-4 py-3 text-xs uppercase tracking-widest font-sans font-bold rounded-md transition-all cursor-pointer ${
                  activeSubTab === tab
                    ? 'bg-brand-forest text-brand-yellow font-extrabold shadow-sm'
                    : 'text-brand-forest/70 hover:bg-brand-stone/20'
                }`}
              >
                {tab === 'profile' ? 'Lounge Dashboard' : tab === 'history' ? 'Order History' : tab}
              </button>
            ))}
          </div>

          {/* Main Dashboard Panel (9 cols) */}
          <div className="lg:col-span-9 bg-brand-linen/10 border border-brand-stone/50 rounded-lg p-6 sm:p-8 shadow-sm" id="account-main-panel">
            
            {activeSubTab === 'profile' && (
              <div className="space-y-8 animate-fade-in" id="dashboard-profile-sub">
                
                {/* Gold Member Card Banner */}
                <div className="bg-brand-forest text-brand-yellow rounded-lg p-6 sm:p-8 flex flex-col sm:flex-row justify-between items-center relative overflow-hidden shadow-lg border border-brand-yellow/20">
                  {/* Decorative faint background vectors */}
                  <div className="absolute top-0 right-0 w-48 h-48 bg-brand-yellow/5 rounded-full blur-2xl pointer-events-none" />
                  
                  <div className="space-y-3 text-center sm:text-left">
                    <span className="bg-brand-yellow/15 border border-brand-yellow/30 text-brand-yellow text-[9px] uppercase tracking-widest font-sans font-bold py-1 px-3 rounded-full inline-flex items-center">
                      <Sparkles className="h-3.5 w-3.5 mr-1 text-brand-brass animate-pulse" /> Gold Tier Member
                    </span>
                    <h3 className="font-serif text-2xl font-bold">L’Atelier Gourmet Guild</h3>
                    <p className="text-xs text-brand-cream/70 font-sans max-w-md leading-relaxed">
                      You are earning 10 points for every £1 spent. Thank you for supporting small-batch family creameries and traditional lamination techniques.
                    </p>
                  </div>

                  <div className="mt-6 sm:mt-0 text-center bg-brand-cream/10 p-4 rounded border border-brand-cream/10 shrink-0">
                    <span className="text-[10px] uppercase tracking-wider font-sans font-bold text-brand-cream/60 block">Loyalty Points Balances</span>
                    <span className="font-serif text-3xl font-extrabold text-brand-yellow block mt-1">{userAccount.loyaltyPoints}</span>
                    <span className="text-[9px] text-brand-sage font-bold uppercase tracking-widest mt-1 block">&bull; Platinum Tier in 300 pts</span>
                  </div>
                </div>

                {/* Dashboard stats grids */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 font-sans">
                  <div className="bg-brand-cream p-5 rounded border border-brand-stone/40 space-y-1">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-brand-oak block">Active Subscriptions</span>
                    <span className="text-lg font-bold text-brand-forest">
                      {userAccount.subscriptionPlan || 'Monthly Butter Box'}
                    </span>
                  </div>

                  <div className="bg-brand-cream p-5 rounded border border-brand-stone/40 space-y-1">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-brand-oak block">Historic Churned Logs</span>
                    <span className="text-lg font-bold text-brand-forest">
                      {orders.length} orders dispatched
                    </span>
                  </div>

                  <div className="bg-brand-cream p-5 rounded border border-brand-stone/40 space-y-1">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-brand-oak block">Member Since</span>
                    <span className="text-lg font-bold text-brand-forest">{userAccount.joinedDate}</span>
                  </div>
                </div>

                {/* Rewards Progress block */}
                <div className="bg-brand-linen p-6 rounded border border-brand-stone/50 space-y-4 font-sans">
                  <h4 className="font-serif text-base font-bold text-brand-forest flex items-center">
                    <Award className="h-5 w-5 mr-1.5 text-brand-brass" /> Current Guild Perks Unlock progress
                  </h4>
                  <div className="w-full bg-brand-stone/30 h-3.5 rounded-full overflow-hidden border border-brand-stone/50">
                    <div className="bg-brand-forest h-full" style={{ width: '80%' }} />
                  </div>
                  <div className="flex justify-between text-xs text-brand-forest/70 font-semibold">
                    <span>1,000 Points Earned</span>
                    <span>1,500 points (Claim Free Black Truffle Butter coin)</span>
                  </div>
                </div>

              </div>
            )}

            {activeSubTab === 'subscriptions' && (
              <div className="space-y-6 animate-fade-in" id="dashboard-subscriptions-sub">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-widest text-brand-oak font-sans font-bold">Subscription Console</span>
                  <h3 className="font-serif text-2xl font-bold text-brand-forest">Manage Recurring Deliveries</h3>
                </div>

                <div className="bg-brand-cream border border-brand-stone/60 rounded-lg p-6 space-y-6 font-sans">
                  <div className="flex justify-between items-start border-b border-brand-stone/40 pb-4">
                    <div>
                      <span className="bg-brand-sage/20 text-brand-sage text-[9px] font-bold uppercase tracking-widest py-0.5 px-2.5 rounded-full">
                        {subscriptionPaused ? 'Paused' : 'Active'}
                      </span>
                      <h4 className="font-serif text-xl font-bold text-brand-forest mt-1.5">
                        {userAccount.subscriptionPlan || 'Monthly Butter Box'}
                      </h4>
                      <p className="text-xs text-brand-forest/60 mt-1">
                        Next Chilled Courier Dispatch: <strong>August 15, 2026</strong> &bull; Subtotal: £24.00
                      </p>
                    </div>
                    <div className="text-right">
                      <span className="font-serif text-xl font-bold text-brand-forest">£24.00</span>
                      <span className="text-[10px] text-brand-forest/50 block">/ Month</span>
                    </div>
                  </div>

                  {/* Swap components panel */}
                  <div className="p-4 bg-brand-linen/40 rounded border border-brand-stone/30 space-y-3">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-brand-oak block flex items-center">
                      <RefreshCw className="h-4 w-4 mr-1 text-brand-sage" /> Next Delivery Butter Swap
                    </span>
                    <p className="text-xs text-brand-forest/70 leading-relaxed">
                      Bored of the same spread? Swap the rotating seasonal slot in your next shipment for any custom flavor below.
                    </p>
                    <div className="flex space-x-2">
                      <select
                        value={subSwapProduct}
                        onChange={(e) => {
                          setSubSwapProduct(e.target.value);
                          alert(`Rotational item swapped to: ${e.target.value} for your next August box!`);
                        }}
                        className="bg-brand-cream border border-brand-stone/60 rounded px-3 py-1.5 text-xs text-brand-forest font-sans focus:outline-none"
                      >
                        <option value="Cultured Butter">Cultured Butter (Normandy Style)</option>
                        <option value="Truffle Butter">Perigord Black Truffle (+£4.00)</option>
                        <option value="Smoked Oakwood Butter">Smoked Oakwood Butter</option>
                        <option value="Wild Flower Honey Butter">Wild Flower Honey & Sea Salt</option>
                        <option value="Wild Garlic Butter">Spring Foraged Wild Garlic</option>
                      </select>
                    </div>
                  </div>

                  {/* Actions buttons */}
                  <div className="flex flex-wrap gap-2 pt-2">
                    <button
                      onClick={onDelayDelivery}
                      className="bg-brand-linen hover:bg-brand-stone/20 text-brand-forest text-xs font-bold uppercase tracking-widest py-2.5 px-4 rounded border border-brand-stone/60 cursor-pointer transition-colors"
                    >
                      Delay 14 Days
                    </button>
                    <button
                      onClick={onSkipNextDelivery}
                      className="bg-brand-linen hover:bg-brand-stone/20 text-brand-forest text-xs font-bold uppercase tracking-widest py-2.5 px-4 rounded border border-brand-stone/60 cursor-pointer transition-colors"
                    >
                      Skip Next Shipment
                    </button>
                    <button
                      onClick={() => {
                        setSubscriptionPaused(!subscriptionPaused);
                        alert(subscriptionPaused ? "Your subscription has been successfully resumed." : "Your subscription has been paused. We will hold your spot in the queue.");
                      }}
                      className="bg-brand-forest hover:bg-brand-oak text-brand-cream text-xs font-bold uppercase tracking-widest py-2.5 px-5 rounded cursor-pointer transition-colors"
                    >
                      {subscriptionPaused ? 'Resume Shipments' : 'Pause Subscription'}
                    </button>
                  </div>
                </div>

                <div className="flex items-start bg-brand-yellow/10 p-4 rounded border border-brand-yellow/30 text-xs font-sans text-brand-forest/80 space-x-2">
                  <AlertCircle className="h-5 w-5 text-brand-oak shrink-0" />
                  <p>
                    <strong>Exclusive Member Advantage:</strong> Active subscribers receive immediate 10% discounts on all additional shop orders.
                  </p>
                </div>
              </div>
            )}

            {activeSubTab === 'history' && (
              <div className="space-y-6 animate-fade-in" id="dashboard-history-sub">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-widest text-brand-oak font-sans font-bold">Historic logs</span>
                  <h3 className="font-serif text-2xl font-bold text-brand-forest">Your Dispatch Ledger</h3>
                </div>

                {orders.length === 0 ? (
                  <div className="text-center py-12 bg-brand-cream border rounded-md border-brand-stone/40">
                    <Clock className="h-10 w-10 mx-auto text-brand-stone mb-2" />
                    <p className="text-sm font-sans text-brand-forest/60">No orders placed yet. Begin your butter journey today!</p>
                  </div>
                ) : (
                  <div className="space-y-4" id="account-orders-ledger">
                    {orders.map((ord) => (
                      <div key={ord.id} className="bg-brand-cream border border-brand-stone/50 rounded-lg p-5 font-sans space-y-3">
                        <div className="flex flex-col sm:flex-row justify-between sm:items-center text-xs border-b border-brand-stone/30 pb-2">
                          <p className="text-brand-forest/60">
                            Order Ref: <strong className="font-mono text-brand-forest">{ord.id}</strong> &bull; Date: {ord.date}
                          </p>
                          <span className={`self-start sm:self-auto font-bold uppercase tracking-widest text-[9px] py-1 px-3.5 rounded-full ${
                            ord.status === 'Processing' ? 'bg-brand-yellow/40 text-brand-oak' : 'bg-brand-sage/20 text-brand-sage'
                          }`}>
                            {ord.status}
                          </span>
                        </div>

                        <div className="text-xs text-brand-forest/80 space-y-1">
                          {ord.items?.map((item, idx) => (
                            <p key={idx} className="flex justify-between font-medium">
                              <span>{item.productName} (x{item.quantity}) {item.isSubscription && <strong className="text-brand-sage text-[9px] uppercase tracking-wider">(Sub)</strong>}</span>
                              <span className="font-bold">£{(item.price * item.quantity).toFixed(2)}</span>
                            </p>
                          ))}
                        </div>

                        <div className="border-t border-brand-stone/30 pt-2 flex justify-between items-center text-xs font-sans">
                          {ord.trackingNumber && (
                            <span className="text-brand-forest/60">
                              Tracking Code: <strong className="font-mono text-brand-forest">{ord.trackingNumber}</strong>
                            </span>
                          )}
                          <span className="font-serif text-sm font-extrabold text-brand-forest ml-auto">
                            Paid: £{ord.total.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeSubTab === 'favorites' && (
              <div className="space-y-6 animate-fade-in" id="dashboard-favorites-sub">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-widest text-brand-oak font-sans font-bold">Saved Favorites</span>
                  <h3 className="font-serif text-2xl font-bold text-brand-forest">Your Curated Collection</h3>
                </div>

                {favoriteProducts.length === 0 ? (
                  <div className="text-center py-12 bg-brand-cream border rounded-md border-brand-stone/40">
                    <Heart className="h-10 w-10 mx-auto text-brand-stone mb-2" />
                    <p className="text-sm font-sans text-brand-forest/60">No favorites pinned yet. Click the heart icon on any product page to bookmark!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4" id="account-favorites-grid">
                    {favoriteProducts.map((p) => (
                      <div key={p.id} className="bg-brand-cream border border-brand-stone/50 rounded-lg p-4 flex items-center space-x-3">
                        <div className="w-14 h-14 bg-brand-linen rounded overflow-hidden shrink-0 border border-brand-stone/40">
                          <img src={p.image} alt={p.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0 font-sans text-xs">
                          <h4 className="font-serif text-xs font-bold text-brand-forest truncate">{p.name}</h4>
                          <p className="text-brand-forest/60 truncate mb-1.5">£{p.price.toFixed(2)}</p>
                          <div className="flex gap-1.5 text-[10px] uppercase tracking-wider font-bold">
                            <button
                              onClick={() => handleAddFavToCart(p)}
                              className="bg-brand-forest hover:bg-brand-oak text-brand-cream py-1 px-3 rounded cursor-pointer transition-colors"
                            >
                              Add to Basket
                            </button>
                            <button
                              onClick={() => openProductDetail(p)}
                              className="text-brand-forest hover:underline"
                            >
                              Details
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeSubTab === 'addresses' && (
              <div className="space-y-6 animate-fade-in" id="dashboard-addresses-sub">
                <div className="space-y-1">
                  <span className="text-[10px] uppercase tracking-widest text-brand-oak font-sans font-bold">Address Ledger</span>
                  <h3 className="font-serif text-2xl font-bold text-brand-forest">Shipping & Invoicing Locations</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-sans">
                  {/* Address Display */}
                  <div className="bg-brand-cream border border-brand-stone/50 p-5 rounded-lg space-y-3">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-brand-oak block flex items-center">
                      <MapPin className="h-4 w-4 mr-1 text-brand-sage" /> Primary Shipping Address
                    </span>
                    <div className="text-xs text-brand-forest/80 space-y-1 font-semibold leading-relaxed">
                      <p>{userAccount.name}</p>
                      <p>{addressLine1 || '12 Cotswold Green Cottage, Herb Lane'}</p>
                      <p>Chipping Campden, GL55 6XX</p>
                      <p>United Kingdom</p>
                    </div>
                  </div>

                  {/* Edit form */}
                  <form onSubmit={handleSaveAddress} className="bg-brand-linen/40 p-5 rounded-lg border border-brand-stone/50 space-y-3">
                    <h4 className="font-serif text-sm font-semibold text-brand-forest">Update Ship Address</h4>
                    <div>
                      <label className="block text-[9px] uppercase tracking-wider font-bold text-brand-forest/60 mb-1">Address Line 1</label>
                      <input
                        type="text"
                        required
                        value={addressLine1}
                        onChange={(e) => setAddressLine1(e.target.value)}
                        className="w-full bg-brand-cream border border-brand-stone/60 rounded px-2.5 py-1.5 text-xs focus:outline-none focus:border-brand-forest text-brand-forest font-sans"
                      />
                    </div>
                    
                    {addressSaved ? (
                      <div className="p-2 bg-brand-sage/20 border border-brand-sage/40 rounded text-center text-[10px] text-brand-sage font-bold flex items-center justify-center space-x-1.5" id="address-success">
                        <CheckCircle className="h-4 w-4" />
                        <span>Address Saved!</span>
                      </div>
                    ) : (
                      <button
                        type="submit"
                        className="w-full bg-brand-forest hover:bg-brand-oak text-brand-cream text-[10px] uppercase tracking-widest py-2 font-bold rounded cursor-pointer transition-colors"
                      >
                        Save Address
                      </button>
                    )}
                  </form>
                </div>
              </div>
            )}

          </div>

        </div>
      </div>
    </section>
  );
}
