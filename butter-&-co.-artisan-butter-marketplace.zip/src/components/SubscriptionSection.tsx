import { useState } from 'react';
import { Calendar, Check, Sparkles, Box, Compass, RefreshCw, ShoppingBag, Plus, Minus } from 'lucide-react';
import { subscriptionPlans } from '../data/subscriptions';
import { products } from '../data/products';
import { Product, SubscriptionPlan } from '../types';

interface SubscriptionSectionProps {
  onSubscribe: (plan: SubscriptionPlan) => void;
  onCustomSubscribe: (customPlan: { name: string; price: number; items: { product: Product; qty: number }[]; frequency: string }) => void;
}

export default function SubscriptionSection({ onSubscribe, onCustomSubscribe }: SubscriptionSectionProps) {
  // Custom Box builder states
  const [selectedItems, setSelectedItems] = useState<{ [id: string]: number }>({});
  const [frequency, setFrequency] = useState('Every 30 Days');
  const [customBoxCreated, setCustomBoxCreated] = useState(false);

  // Filter products that can go in the box (filter out gifts)
  const boxEligibleProducts = products.filter(p => p.collection !== 'gift');

  const toggleItemQuantity = (productId: string, increment: boolean) => {
    const currentQty = selectedItems[productId] || 0;
    const newQty = increment ? currentQty + 1 : Math.max(0, currentQty - 1);
    
    setSelectedItems({
      ...selectedItems,
      [productId]: newQty
    });
  };

  const getCustomBoxTotalItems = () => {
    return Object.values(selectedItems).reduce((sum: number, val: number) => sum + val, 0);
  };

  const calculateCustomPrice = () => {
    let total = 0;
    boxEligibleProducts.forEach((p) => {
      const qty = selectedItems[p.id] || 0;
      total += qty * (p.price * 0.85); // 15% discount for custom subscribers
    });
    return parseFloat(total.toFixed(2));
  };

  const handleCustomSubscribeSubmit = () => {
    const totalItems = getCustomBoxTotalItems();
    if (totalItems === 0) {
      alert("Please select at least 1 butter block to construct your custom box.");
      return;
    }

    const itemsList = boxEligibleProducts
      .filter(p => (selectedItems[p.id] || 0) > 0)
      .map(p => ({
        product: p,
        qty: selectedItems[p.id]
      }));

    onCustomSubscribe({
      name: `Custom Curated Box (${totalItems} Blocks)`,
      price: calculateCustomPrice(),
      items: itemsList,
      frequency: frequency
    });

    setCustomBoxCreated(true);
    setTimeout(() => {
      setCustomBoxCreated(false);
      setSelectedItems({});
    }, 4000);
  };

  return (
    <section className="py-16 bg-brand-linen/30" id="subscriptions-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <span className="text-[10px] tracking-[0.35em] uppercase text-brand-oak font-sans font-bold flex items-center justify-center">
            <Calendar className="h-4.5 w-4.5 mr-2 text-brand-brass" />
            Recurring Pantry Deliveries
          </span>
          <h2 className="font-serif text-4xl sm:text-5xl font-semibold text-brand-forest tracking-wide">
            Subscriptions & Taster Memberships
          </h2>
          <p className="font-serif italic text-base text-brand-forest/70 leading-relaxed">
            "Never worry about running low on premium butter. Members receive exclusive seasonal releases, early access to reserves, and chilled delivery."
          </p>
        </div>

        {/* Part 1: Grid of Standard Subscription Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20" id="standard-plans-grid">
          {subscriptionPlans.slice(0, 3).map((plan) => (
            <div
              key={plan.id}
              className="bg-brand-cream border border-brand-stone/60 rounded-lg p-6 sm:p-8 flex flex-col justify-between shadow-sm relative overflow-hidden group hover:border-brand-forest transition-all"
            >
              {plan.badge && (
                <span className="absolute top-4 right-4 bg-brand-forest text-brand-yellow text-[9px] uppercase tracking-widest font-sans font-bold py-1 px-3.5 rounded-full shadow-sm">
                  {plan.badge}
                </span>
              )}

              <div className="space-y-6">
                <div>
                  <span className="text-[9px] tracking-widest uppercase font-sans font-bold text-brand-oak">
                    Curator’s Tier
                  </span>
                  <h3 className="font-serif text-2xl font-bold text-brand-forest mt-1">
                    {plan.name}
                  </h3>
                  <p className="text-xs text-brand-forest/60 font-sans mt-2 leading-relaxed">
                    {plan.description}
                  </p>
                </div>

                {/* Pricing display */}
                <div className="border-t border-b border-brand-stone/30 py-4 flex items-baseline space-x-1.5">
                  <span className="font-serif text-3xl font-extrabold text-brand-forest">
                    £{plan.price.toFixed(2)}
                  </span>
                  <span className="text-xs text-brand-oak font-sans uppercase tracking-wider">
                    / {plan.frequency}
                  </span>
                </div>

                {/* Features checklist */}
                <ul className="space-y-3 font-sans text-xs text-brand-forest/80">
                  {plan.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start">
                      <Check className="h-4 w-4 text-brand-sage mr-2.5 shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Action Button */}
              <button
                id={`sub-btn-${plan.id}`}
                onClick={() => onSubscribe(plan)}
                className="w-full bg-brand-forest hover:bg-brand-oak text-brand-cream hover:text-brand-yellow text-xs uppercase tracking-widest py-3.5 font-bold rounded shadow-md transition-all mt-8 cursor-pointer flex items-center justify-center space-x-2"
              >
                <ShoppingBag className="h-4 w-4" />
                <span>Subscribe &bull; £{plan.price.toFixed(2)}</span>
              </button>
            </div>
          ))}
        </div>

        {/* Part 2: Interactive Custom Box Builder Block */}
        <div className="bg-brand-cream border border-brand-stone/50 rounded-lg p-6 sm:p-10 lg:p-14 shadow-md space-y-10" id="custom-box-builder">
          <div className="text-center max-w-xl mx-auto space-y-3">
            <span className="bg-brand-forest/10 border border-brand-forest/20 text-brand-forest text-[10px] uppercase tracking-[0.2em] font-sans font-bold py-1 px-4 rounded-full inline-flex items-center">
              <Box className="h-4 w-4 mr-2 text-brand-sage" /> Custom Box Builder
            </span>
            <h3 className="font-serif text-3xl font-bold text-brand-forest">
              Design Your Custom Butter Box
            </h3>
            <p className="text-xs text-brand-forest/70 font-sans leading-relaxed">
              Choose your favorite artisan blocks, select your delivery cycle, and save a flat <strong>15% off standard shop pricing</strong> with our custom box privilege!
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Left side: Grid of butter blocks (7 cols) */}
            <div className="lg:col-span-7 space-y-4">
              <span className="text-[10px] tracking-widest uppercase font-sans font-bold text-brand-oak block border-b border-brand-stone/40 pb-1">
                Select Your Butter Varieties (15% Off Applied)
              </span>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-h-[480px] overflow-y-auto pr-2" id="custom-builder-products">
                {boxEligibleProducts.map((p) => {
                  const qty = selectedItems[p.id] || 0;
                  const discountPrice = p.price * 0.85;
                  
                  return (
                    <div
                      key={p.id}
                      className={`p-3 border rounded-lg bg-brand-cream transition-all flex items-center space-x-3 ${
                        qty > 0 ? 'border-brand-forest ring-1 ring-brand-forest bg-brand-linen/25' : 'border-brand-stone hover:border-brand-forest'
                      }`}
                    >
                      <div className="w-12 h-12 rounded overflow-hidden shrink-0 border border-brand-stone/40">
                        <img src={p.image} alt={p.name} referrerPolicy="no-referrer" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-serif text-xs font-bold text-brand-forest truncate">{p.name}</h4>
                        <p className="text-[10px] text-brand-forest/50 truncate mb-1">{p.collection}</p>
                        <div className="flex items-center justify-between">
                          <span className="font-mono text-xs font-bold text-brand-forest">£{discountPrice.toFixed(2)}</span>
                          
                          {/* Item Add/Minus Controls */}
                          <div className="flex items-center border border-brand-stone/60 rounded bg-brand-linen">
                            <button
                              type="button"
                              onClick={() => toggleItemQuantity(p.id, false)}
                              className="p-1 px-2 text-xs text-brand-forest hover:bg-brand-stone/20 cursor-pointer"
                              aria-label="Remove item"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="px-2 text-xs font-sans font-bold text-brand-forest select-none">
                              {qty}
                            </span>
                            <button
                              type="button"
                              onClick={() => toggleItemQuantity(p.id, true)}
                              className="p-1 px-2 text-xs text-brand-forest hover:bg-brand-stone/20 cursor-pointer"
                              aria-label="Add item"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right side: Box Summary Config Panel (5 cols) */}
            <div className="lg:col-span-5 bg-brand-linen p-6 rounded-lg border border-brand-stone/60 space-y-6" id="builder-summary-card">
              <span className="text-[9px] tracking-widest uppercase font-sans font-bold text-brand-oak block">
                Your Custom Box Specifications
              </span>

              {/* Chosen items list */}
              <div className="space-y-3 font-sans max-h-[160px] overflow-y-auto pr-2" id="builder-chosen-items">
                {getCustomBoxTotalItems() === 0 ? (
                  <div className="text-center py-6 text-brand-forest/50 text-xs">
                    <Box className="h-8 w-8 mx-auto mb-2 text-brand-oak/30 stroke-[1.2]" />
                    <p>Your box is empty. Choose varieties on the left side to begin curated lamination.</p>
                  </div>
                ) : (
                  boxEligibleProducts
                    .filter(p => (selectedItems[p.id] || 0) > 0)
                    .map(p => (
                      <div key={p.id} className="flex justify-between items-center text-xs text-brand-forest">
                        <span className="font-semibold truncate pr-3 flex-1">{p.name}</span>
                        <div className="flex items-center space-x-3 shrink-0">
                          <span className="text-brand-forest/60">Qty: {selectedItems[p.id]}</span>
                          <span className="font-bold">£{(p.price * 0.85 * selectedItems[p.id]).toFixed(2)}</span>
                        </div>
                      </div>
                    ))
                )}
              </div>

              {/* Delivery Frequency Selection */}
              <div className="space-y-2 border-t border-brand-stone/40 pt-4">
                <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70">
                  Select Shipping Interval
                </label>
                <div className="grid grid-cols-3 gap-2" id="frequency-selector">
                  {['Every 14 Days', 'Every 30 Days', 'Every 60 Days'].map((freq) => (
                    <button
                      key={freq}
                      type="button"
                      onClick={() => setFrequency(freq)}
                                            className={`py-2 text-[10px] uppercase tracking-wider font-sans font-bold border rounded cursor-pointer transition-all ${
                        frequency === freq
                          ? 'border-brand-forest bg-brand-forest text-brand-yellow font-extrabold shadow-sm'
                          : 'border-brand-stone bg-brand-cream text-brand-forest/70 hover:bg-brand-stone/10'
                      }`}
                    >
                      {freq.replace('Every ', '')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Calculations Block */}
              <div className="border-t border-brand-stone/40 pt-4 space-y-2 text-xs font-sans text-brand-forest/90">
                <div className="flex justify-between font-medium">
                  <span>Custom Box Contents:</span>
                  <span>{getCustomBoxTotalItems()} blocks</span>
                </div>
                <div className="flex justify-between font-medium text-brand-sage">
                  <span>Custom Box Discount:</span>
                  <span>-15% Off Applied</span>
                </div>
                <div className="flex justify-between">
                  <span>Insulated Carbon-Chilled Cargo:</span>
                  <span className="text-brand-sage uppercase font-bold">Free</span>
                </div>
                <div className="border-t border-brand-stone/40 pt-2 flex justify-between font-serif text-base font-extrabold text-brand-forest">
                  <span>Monthly Price:</span>
                  <span className="text-lg text-brand-forest">£{calculateCustomPrice().toFixed(2)}</span>
                </div>
              </div>

              {/* Sub Button */}
              {customBoxCreated ? (
                <div className="p-4 bg-brand-sage text-white text-center text-xs font-sans font-bold rounded shadow-md flex items-center justify-center space-x-2 animate-pulse" id="custom-sub-success">
                  <Check className="h-5 w-5" />
                  <span>Custom Subscription Added to Basket!</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleCustomSubscribeSubmit}
                  disabled={getCustomBoxTotalItems() === 0}
                  className="w-full bg-brand-forest hover:bg-brand-oak disabled:opacity-50 text-brand-cream hover:text-brand-yellow text-xs uppercase tracking-widest py-3.5 font-bold rounded shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <RefreshCw className="h-4 w-4 animate-spin-slow" />
                  <span>Subscribe to Custom Box &bull; £{calculateCustomPrice().toFixed(2)}</span>
                </button>
              )}
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
