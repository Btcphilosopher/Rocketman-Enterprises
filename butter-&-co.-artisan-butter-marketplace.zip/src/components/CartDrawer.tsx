import { X, Trash2, Calendar, Sparkles, Gift, ShieldAlert } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  updateQuantity: (productId: string, isSub: boolean, delta: number) => void;
  removeFromCart: (productId: string, isSub: boolean) => void;
  triggerCheckout: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  updateQuantity,
  removeFromCart,
  triggerCheckout
}: CartDrawerProps) {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => {
    const activePrice = item.isSubscription ? item.product.price * 0.9 : item.product.price;
    return acc + (activePrice * item.quantity);
  }, 0);

  const deliveryFee = subtotal >= 35 || subtotal === 0 ? 0 : 4.50;
  const total = subtotal + deliveryFee;
  const loyaltyPointsEarned = Math.floor(subtotal * 10);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-brand-forest/65 backdrop-blur-md flex justify-end" id="cart-drawer">
      {/* Click-outside backdrop */}
      <div className="absolute inset-0 cursor-pointer" onClick={onClose} />

      <div className="bg-brand-cream w-full max-w-md h-full shadow-2xl relative z-10 flex flex-col border-l border-brand-stone/40 animate-slide-left">
        {/* Header */}
        <div className="p-6 border-b border-brand-stone/40 flex justify-between items-center bg-brand-linen/50">
          <div className="flex items-center space-x-2">
            <span className="font-serif text-xl font-bold tracking-wide text-brand-forest">Your Market Basket</span>
            <span className="bg-brand-forest text-brand-yellow text-xs font-bold px-2 py-0.5 rounded-full font-sans">
              {cartItems.reduce((acc, item) => acc + item.quantity, 0)}
            </span>
          </div>
          <button
            id="close-cart-btn"
            onClick={onClose}
            className="text-brand-forest hover:text-brand-oak p-2 rounded-full hover:bg-brand-stone/20 cursor-pointer transition-all"
            aria-label="Close basket"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {cartItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4" id="empty-cart-state">
              <Gift className="h-14 w-14 text-brand-oak/40 stroke-[1.2]" />
              <div>
                <h3 className="font-serif text-lg font-medium text-brand-forest">Your basket is pristine</h3>
                <p className="text-xs text-brand-forest/60 mt-1 max-w-xs mx-auto">
                  Discover our signature collections and begin filling your table with handcrafted luxury.
                </p>
              </div>
              <button
                onClick={onClose}
                className="bg-brand-forest hover:bg-brand-oak text-brand-cream text-xs uppercase tracking-widest px-6 py-3 font-semibold rounded cursor-pointer transition-colors"
              >
                Continue Exploring
              </button>
            </div>
          ) : (
            <div className="space-y-4" id="cart-items-list">
              {cartItems.map((item, index) => {
                const activePrice = item.isSubscription ? item.product.price * 0.9 : item.product.price;
                return (
                  <div
                    key={`${item.product.id}-${item.isSubscription ? 'sub' : 'once'}`}
                    className="flex space-x-4 border-b border-brand-stone/30 pb-4 last:border-0"
                  >
                    {/* Item Thumbnail */}
                    <div className="w-20 h-20 bg-brand-linen rounded-md overflow-hidden shrink-0 border border-brand-stone/40">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover"
                      />
                    </div>

                    {/* Item Info */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start">
                          <h4 className="font-serif text-sm font-semibold text-brand-forest truncate pr-2">
                            {item.product.name}
                          </h4>
                          <button
                            onClick={() => removeFromCart(item.product.id, item.isSubscription)}
                            className="text-brand-forest/40 hover:text-red-600 p-1 rounded transition-colors cursor-pointer"
                            aria-label="Remove item"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                        
                        {item.isSubscription ? (
                          <span className="inline-flex items-center text-[10px] text-brand-sage font-bold uppercase tracking-widest mt-0.5 bg-brand-sage/10 px-2 py-0.5 rounded">
                            <Calendar className="h-3 w-3 mr-1" /> Monthly Box Sub
                          </span>
                        ) : (
                          <span className="text-[9px] text-brand-forest/50 uppercase tracking-widest">
                            One-time purchase
                          </span>
                        )}
                      </div>

                      {/* Quantity Toggles & Price */}
                      <div className="flex justify-between items-center mt-2">
                        <div className="flex border border-brand-stone/60 rounded overflow-hidden bg-brand-linen">
                          <button
                            onClick={() => updateQuantity(item.product.id, item.isSubscription, -1)}
                            className="px-2 py-1 text-xs text-brand-forest hover:bg-brand-stone/20 cursor-pointer"
                          >
                            -
                          </button>
                          <span className="px-2.5 py-1 text-xs text-brand-forest font-semibold">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.product.id, item.isSubscription, 1)}
                            className="px-2 py-1 text-xs text-brand-forest hover:bg-brand-stone/20 cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                        <span className="font-serif text-sm font-bold text-brand-forest">
                          £{(activePrice * item.quantity).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer Summary (Sticky at bottom) */}
        {cartItems.length > 0 && (
          <div className="p-6 border-t border-brand-stone/40 bg-brand-linen/60 space-y-4" id="cart-footer-summary">
            {/* Free shipping banner */}
            {subtotal < 35 ? (
              <div className="flex items-center space-x-2 bg-brand-yellow/30 p-3 rounded border border-brand-yellow/60 text-xs text-brand-oak font-sans" id="free-shipping-goal">
                <ShieldAlert className="h-4 w-4 shrink-0" />
                <span>Add <strong>£{(35 - subtotal).toFixed(2)}</strong> more for <strong>Free Carbon-Chilled Shipping</strong>.</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2 bg-brand-sage/20 p-3 rounded border border-brand-sage/40 text-xs text-brand-sage font-sans font-semibold" id="free-shipping-achieved">
                <Sparkles className="h-4 w-4 shrink-0 animate-bounce" />
                <span>You have unlocked <strong>Free Chilled Express Delivery</strong>!</span>
              </div>
            )}

            {/* Calculations breakdown */}
            <div className="space-y-1.5 text-sm text-brand-forest/80 font-sans">
              <div className="flex justify-between">
                <span>Market Subtotal</span>
                <span className="font-semibold">£{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Chilled Protective Courier</span>
                <span>{deliveryFee === 0 ? <strong className="text-brand-sage uppercase">Free</strong> : `£${deliveryFee.toFixed(2)}`}</span>
              </div>
              <div className="border-t border-brand-stone/40 pt-2 flex justify-between font-serif text-base font-bold text-brand-forest">
                <span>Total Balance</span>
                <span>£{total.toFixed(2)}</span>
              </div>
            </div>

            {/* Loyalty points banner */}
            <div className="p-3 bg-brand-forest text-brand-yellow text-center text-xs font-sans rounded font-medium flex items-center justify-center space-x-1.5">
              <Sparkles className="h-4 w-4 text-brand-brass" />
              <span>Purchase earns <strong>{loyaltyPointsEarned} Gourmet Loyalty Points</strong>!</span>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <button
                id="cart-checkout-btn"
                onClick={triggerCheckout}
                className="w-full bg-brand-forest hover:bg-brand-oak text-brand-cream text-xs uppercase tracking-widest py-3.5 font-bold rounded shadow-lg transition-colors cursor-pointer text-center block"
              >
                Proceed to Checkout
              </button>
              <button
                onClick={onClose}
                className="w-full bg-transparent hover:underline text-brand-forest text-xs uppercase tracking-widest py-2 font-bold text-center block cursor-pointer"
              >
                Continue Selection
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
