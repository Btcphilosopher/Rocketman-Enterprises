import React, { useState } from 'react';
import { X, Heart, Star, ShoppingBag, Leaf, Shield, Award, Calendar, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  addToCart: (product: Product, quantity: number, isSub: boolean) => void;
  isFavorite: boolean;
  toggleFavorite: (productId: string) => void;
}

export default function ProductDetailModal({
  product,
  isOpen,
  onClose,
  addToCart,
  isFavorite,
  toggleFavorite
}: ProductDetailModalProps) {
  if (!isOpen || !product) return null;

  const [quantity, setQuantity] = useState(1);
  const [purchaseType, setPurchaseType] = useState<'once' | 'subscribe'>('once');
  const [activeTab, setActiveTab] = useState<'overview' | 'origin' | 'nutrition' | 'reviews'>('overview');
  const [reviews, setReviews] = useState([
    { id: '1', userName: 'Lady Genevieve W.', rating: 5, date: 'June 18, 2026', comment: 'An absolute masterpiece. The crunch of Maldon crystals folded into that rich, golden butter fat is pure luxury. I spread this on warm sourdough every single morning.', verified: true },
    { id: '2', userName: 'Chef Marcus A.', rating: 5, date: 'May 04, 2026', comment: 'I run a Michelin-starred kitchen in London, and this butter is on our dining tables. It is exceptionally well-churned with negligible moisture. Outstanding.', verified: true },
    { id: '3', userName: 'Sven Lindqvist', rating: 4, date: 'April 22, 2026', comment: 'Tastes like the farm butter I had in Sweden as a boy. It has a beautiful yellow grass tone and a lovely lactic sweetness.', verified: true }
  ]);
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState(5);
  const [newReviewUser, setNewReviewUser] = useState('');
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  const handleAddReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReviewText.trim() || !newReviewUser.trim()) return;
    
    const nr = {
      id: Date.now().toString(),
      userName: newReviewUser,
      rating: newReviewRating,
      date: 'Just now',
      comment: newReviewText,
      verified: true
    };
    
    setReviews([nr, ...reviews]);
    setNewReviewText('');
    setNewReviewUser('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 4000);
  };

  const discountedPrice = parseFloat((product.price * 0.9).toFixed(2));
  const activePrice = purchaseType === 'subscribe' ? discountedPrice : product.price;

  const handleAddToCartClick = () => {
    addToCart(product, quantity, purchaseType === 'subscribe');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-brand-forest/65 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 lg:p-8" id="product-detail-modal">
      <div className="bg-brand-cream w-full max-w-5xl rounded-none shadow-2xl overflow-hidden border border-brand-stone/40 max-h-[90vh] flex flex-col relative animate-fade-in">
        
        {/* Close Button */}
        <button
          id="close-modal-btn"
          onClick={onClose}
          className="absolute right-4 top-4 z-10 bg-brand-cream/80 hover:bg-brand-forest hover:text-brand-yellow text-brand-forest p-2.5 rounded-none border border-brand-stone/60 transition-colors cursor-pointer shadow-md"
          aria-label="Close product view"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="overflow-y-auto flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2">
            
            {/* Visual Photography / Left Side */}
            <div className="relative bg-brand-linen h-[320px] md:h-auto min-h-[380px] flex items-stretch">
              <img
                src={product.image}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
                id="modal-product-image"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
              
              {/* Product Badges */}
              <div className="absolute top-4 left-4 flex flex-col space-y-2">
                {product.isLimitedEdition && (
                  <span className="bg-brand-brass text-brand-forest text-[10px] tracking-widest uppercase font-semibold px-3 py-1.5 rounded-sm shadow-sm" id="limited-badge">
                    Limited Edition
                  </span>
                )}
                <span className="bg-brand-forest/90 text-brand-yellow text-[9px] tracking-widest uppercase font-semibold px-2.5 py-1.5 rounded-sm shadow-sm flex items-center gap-1">
                  <Leaf className="h-3 w-3 text-brand-sage" />
                  Organic Pasture
                </span>
              </div>

              {/* Tagline Overlaid At bottom */}
              <div className="absolute bottom-6 left-6 right-6 text-white">
                <span className="text-[10px] uppercase tracking-[0.25em] text-brand-yellow block font-sans font-semibold mb-1">
                  Craft Signature
                </span>
                <p className="font-serif italic text-lg leading-relaxed text-brand-cream">
                  "{product.tagline}"
                </p>
              </div>
            </div>

            {/* Editorial Product Copy / Right Side */}
            <div className="p-6 sm:p-10 flex flex-col justify-between" id="modal-product-info">
              <div>
                {/* Collection indicator */}
                <span className="text-[10px] tracking-[0.3em] uppercase text-brand-oak font-sans font-semibold block mb-2">
                  {product.collection} COLLECTION
                </span>

                <div className="flex justify-between items-start">
                  <h2 className="font-serif text-3xl sm:text-4xl font-semibold text-brand-forest tracking-wide" id="modal-product-title">
                    {product.name}
                  </h2>
                  <button
                    id="modal-fav-btn"
                    onClick={() => toggleFavorite(product.id)}
                    className="ml-4 p-2 text-brand-forest hover:text-brand-oak transition-colors cursor-pointer"
                    aria-label="Add to favorites"
                  >
                    <Heart className={`h-6 w-6 ${isFavorite ? 'fill-brand-forest text-brand-forest' : ''}`} />
                  </button>
                </div>

                {/* Rating summary */}
                <div className="flex items-center space-x-1.5 mt-2">
                  <div className="flex text-brand-brass">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'fill-brand-brass' : ''}`} />
                    ))}
                  </div>
                  <span className="text-xs font-sans font-semibold text-brand-forest">{product.rating}</span>
                  <span className="text-xs font-sans text-brand-forest/50">({product.reviewsCount} reviews)</span>
                </div>

                {/* Price Display */}
                <div className="mt-4 flex items-baseline space-x-2">
                  <span className="font-serif text-2xl font-bold text-brand-forest" id="modal-product-price">
                    £{activePrice.toFixed(2)}
                  </span>
                  {purchaseType === 'subscribe' && (
                    <span className="text-xs font-sans text-brand-forest/60 line-through">
                      £{product.price.toFixed(2)}
                    </span>
                  )}
                  <span className="text-xs font-sans text-brand-oak tracking-widest uppercase">
                    / block (250g)
                  </span>
                </div>                 {/* Purchase Type Selector */}
                <div className="mt-6 border border-brand-stone/40 rounded-none p-4 bg-brand-linen/40 space-y-3" id="purchase-type-container">
                  <label className="flex items-start p-2 rounded-none hover:bg-brand-linen cursor-pointer transition-colors">
                    <input
                      type="radio"
                      name="purchase-type"
                      checked={purchaseType === 'once'}
                      onChange={() => setPurchaseType('once')}
                      className="mt-1 text-brand-forest focus:ring-brand-oak h-4 w-4 cursor-pointer"
                    />
                    <div className="ml-3">
                      <span className="block text-xs uppercase tracking-widest font-sans font-bold text-brand-forest">
                        One-Time Artisan Purchase
                      </span>
                      <span className="block text-xs text-brand-forest/60 mt-0.5">
                        Shipped in protective chilled packaging.
                      </span>
                    </div>
                  </label>

                  <label className="flex items-start p-2 rounded-none hover:bg-brand-linen cursor-pointer transition-colors border border-brand-oak/20 bg-brand-cream">
                    <input
                      type="radio"
                      name="purchase-type"
                      checked={purchaseType === 'subscribe'}
                      onChange={() => setPurchaseType('subscribe')}
                      className="mt-1 text-brand-forest focus:ring-brand-oak h-4 w-4 cursor-pointer"
                    />
                    <div className="ml-3">
                      <span className="block text-xs uppercase tracking-widest font-sans font-bold text-brand-forest flex items-center">
                        Subscribe & Recur (Save 10%)
                        <span className="ml-2 bg-brand-forest text-brand-yellow text-[9px] px-2 py-0.5 rounded-none uppercase tracking-widest border border-brand-yellow/30">
                          -10% Off
                        </span>
                      </span>
                      <span className="block text-xs text-brand-forest/60 mt-0.5 flex items-center">
                        <Calendar className="h-3 w-3 mr-1 text-brand-oak" />
                        Delivered fresh every 30 days. Cancel or modify anytime.
                      </span>
                    </div>
                  </label>
                </div>

                {/* Quantity and Add to Cart Section */}
                <div className="mt-6 flex items-center space-x-4">
                  <div className="flex border border-brand-stone/60 rounded-none overflow-hidden bg-brand-linen" id="quantity-control">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-2 text-brand-forest hover:bg-brand-stone/30 cursor-pointer text-sm font-semibold transition-colors"
                      aria-label="Decrease quantity"
                    >
                      -
                    </button>
                    <span className="px-4 py-2 text-brand-forest font-sans font-semibold text-sm flex items-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(quantity + 1)}
                      className="px-3 py-2 text-brand-forest hover:bg-brand-stone/30 cursor-pointer text-sm font-semibold transition-colors"
                      aria-label="Increase quantity"
                    >
                      +
                    </button>
                  </div>

                  <button
                    id="add-to-cart-modal-btn"
                    onClick={handleAddToCartClick}
                    className="flex-1 bg-brand-forest hover:bg-brand-oak text-brand-cream hover:text-brand-linen font-sans uppercase tracking-widest text-xs font-bold py-3 px-6 rounded-md shadow-lg transition-all flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    <ShoppingBag className="h-4 w-4" />
                    <span>Add to Market Basket &bull; £{(activePrice * quantity).toFixed(2)}</span>
                  </button>
                </div>
              </div>

              {/* Informative Icons */}
              <div className="mt-8 border-t border-brand-stone/40 pt-4 grid grid-cols-3 gap-2 text-center text-brand-forest/70 font-sans text-[10px]">
                <div className="flex flex-col items-center">
                  <Shield className="h-5 w-5 mb-1 text-brand-sage" />
                  <span className="font-bold">Honest Sourcing</span>
                </div>
                <div className="flex flex-col items-center">
                  <Award className="h-5 w-5 mb-1 text-brand-brass" />
                  <span className="font-bold">Championship Dairy</span>
                </div>
                <div className="flex flex-col items-center">
                  <Calendar className="h-5 w-5 mb-1 text-brand-oak" />
                  <span className="font-bold">Next-day Chilled Box</span>
                </div>
              </div>

            </div>
          </div>

          {/* Section Tabs - Editorial Details */}
          <div className="border-t border-brand-stone/40 mt-6">
            <div className="flex border-b border-brand-stone/40 px-6 sm:px-10 bg-brand-linen/30">
              {(['overview', 'origin', 'nutrition', 'reviews'] as const).map((tab) => (
                <button
                  key={tab}
                  id={`tab-${tab}`}
                  onClick={() => setActiveTab(tab)}
                  className={`py-4 px-4 sm:px-6 text-xs uppercase tracking-widest font-sans font-bold border-b-2 transition-all cursor-pointer ${
                    activeTab === tab
                      ? 'border-brand-forest text-brand-forest font-extrabold'
                      : 'border-transparent text-brand-forest/50 hover:text-brand-forest'
                  }`}
                >
                  {tab === 'origin' ? 'Farm & Sourcing' : tab}
                </button>
              ))}
            </div>

            <div className="p-6 sm:p-10 bg-brand-cream font-sans" id="modal-tab-content">
              {activeTab === 'overview' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 leading-relaxed text-brand-forest/90 text-sm">
                  <div className="space-y-4">
                    <h3 className="font-serif text-xl font-semibold text-brand-forest">The Butter Craft</h3>
                    <p>{product.description}</p>
                    <p className="flex items-start">
                      <span className="font-bold shrink-0 w-32 uppercase text-xs tracking-wider text-brand-oak">Churning Method:</span>
                      <span>{product.churningMethod}</span>
                    </p>
                    <p className="flex items-start">
                      <span className="font-bold shrink-0 w-32 uppercase text-xs tracking-wider text-brand-oak">Storage Advice:</span>
                      <span>{product.storageAdvice}</span>
                    </p>
                  </div>
                  <div className="space-y-6 bg-brand-linen/40 p-6 rounded-lg border border-brand-stone/30">
                    <div>
                      <h4 className="text-xs uppercase tracking-widest font-bold text-brand-oak mb-2">Ingredients</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.ingredients.map((ing, idx) => (
                          <span key={idx} className="bg-brand-cream border border-brand-stone/60 text-brand-forest text-xs px-3 py-1 rounded-sm">
                            {ing}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-xs uppercase tracking-widest font-bold text-brand-oak mb-2">Tasting Notes Matrix</h4>
                      <div className="flex flex-wrap gap-2">
                        {product.tastingNotes.map((note, idx) => (
                          <span key={idx} className="bg-brand-yellow/30 border border-brand-yellow/80 text-brand-oak text-xs px-3 py-1 rounded-sm italic font-medium">
                            &bull; {note}
                          </span>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-xs uppercase tracking-widest font-bold text-brand-oak mb-2">Pairing Suggestions</h4>
                      <ul className="list-disc pl-5 text-xs text-brand-forest/80 space-y-1">
                        {product.pairingSuggestions.map((pair, idx) => (
                          <li key={idx}>{pair}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'origin' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center leading-relaxed text-brand-forest/90 text-sm">
                  <div className="space-y-4">
                    <span className="text-xs uppercase tracking-widest text-brand-sage font-bold flex items-center">
                      <Leaf className="h-4 w-4 mr-1.5" /> Direct Sourced
                    </span>
                    <h3 className="font-serif text-2xl font-semibold text-brand-forest">{product.farmOrigin.name}</h3>
                    <p className="text-xs font-semibold uppercase tracking-wider text-brand-oak">{product.farmOrigin.location}</p>
                    <p className="italic text-brand-forest/80">"{product.farmOrigin.story}"</p>
                    <div className="border-t border-brand-stone/50 pt-4 space-y-2">
                      <p className="text-xs">
                        <strong className="uppercase text-brand-oak">Grass grazing audit:</strong> We verify that cattle eat a pasture diet free of synthetic hormones and chemical pesticides.
                      </p>
                      <p className="text-xs">
                        <strong className="uppercase text-brand-oak">Traceability:</strong> Single herd milk separation ensures that every block has a clear line of lineage back to the organic fields.
                      </p>
                    </div>
                  </div>
                  <div className="h-[250px] overflow-hidden rounded-lg border border-brand-stone/40">
                    <img
                      src="https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&q=80&w=800"
                      alt="Artisan pasture herd"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              )}

              {activeTab === 'nutrition' && (
                <div className="max-w-md mx-auto bg-brand-cream border-2 border-brand-forest p-6 font-mono text-brand-forest text-xs">
                  <h3 className="font-extrabold text-lg uppercase tracking-wide border-b-4 border-brand-forest pb-1">Nutritional Values</h3>
                  <p className="border-b-2 border-brand-forest py-1.5 flex justify-between">
                    <span>Serving Size:</span>
                    <span className="font-bold">{product.nutritionalInfo.servingSize}</span>
                  </p>
                  <p className="border-b border-brand-forest py-1.5 flex justify-between font-extrabold text-sm">
                    <span>Calories:</span>
                    <span>{product.nutritionalInfo.calories} kcal</span>
                  </p>
                  <div className="pl-4 space-y-1.5 py-2 border-b-2 border-brand-forest">
                    <p className="flex justify-between">
                      <span>Total Fat:</span>
                      <span className="font-bold">{product.nutritionalInfo.fat}</span>
                    </p>
                    <p className="flex justify-between pl-4 text-brand-forest/70">
                      <span>Saturated Fat:</span>
                      <span>{product.nutritionalInfo.saturatedFat}</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Sodium:</span>
                      <span className="font-bold">{product.nutritionalInfo.sodium}</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Carbohydrates:</span>
                      <span className="font-bold">{product.nutritionalInfo.carbs}</span>
                    </p>
                    <p className="flex justify-between">
                      <span>Protein:</span>
                      <span className="font-bold">{product.nutritionalInfo.protein}</span>
                    </p>
                  </div>
                  <p className="pt-2 text-[9px] text-brand-forest/60 text-center uppercase font-bold tracking-wider leading-relaxed">
                    Percentages are based on a standard 2,000 calorie reference diet. Hand churned butter contains active enzymes.
                  </p>
                </div>
              )}

              {activeTab === 'reviews' && (
                <div className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Review list */}
                    <div className="md:col-span-2 space-y-6">
                      {reviews.map((rev) => (
                        <div key={rev.id} className="border-b border-brand-stone/40 pb-4 space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-sm text-brand-forest">{rev.userName}</span>
                            <span className="text-xs text-brand-forest/50">{rev.date}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            {[...Array(5)].map((_, i) => (
                              <Star key={i} className={`h-3 w-3 ${i < rev.rating ? 'fill-brand-brass text-brand-brass' : 'text-brand-stone'}`} />
                            ))}
                            {rev.verified && (
                              <span className="ml-2 bg-brand-sage/20 text-brand-sage text-[9px] font-bold px-2 py-0.5 rounded-full flex items-center gap-0.5">
                                <Check className="h-2 w-2" /> Verified Buyer
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-brand-forest/80 italic leading-relaxed">"{rev.comment}"</p>
                        </div>
                      ))}
                    </div>

                    {/* New review form */}
                    <div className="bg-brand-linen/40 p-6 rounded-lg border border-brand-stone/30">
                      <h4 className="font-serif text-lg font-medium text-brand-forest mb-4">Post a Review</h4>
                      {reviewSubmitted ? (
                        <div className="text-center p-4 bg-brand-sage/10 rounded-md border border-brand-sage/20">
                          <p className="text-xs font-bold text-brand-sage">Thank you for your feedback!</p>
                          <p className="text-[10px] text-brand-forest/60 mt-1">Our culinary curator will verify your feedback shortly.</p>
                        </div>
                      ) : (
                        <form onSubmit={handleAddReview} className="space-y-3" id="add-review-form">
                          <div>
                            <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Your Name</label>
                            <input
                              type="text"
                              required
                              value={newReviewUser}
                              onChange={(e) => setNewReviewUser(e.target.value)}
                              placeholder="e.g. Eleanor Vance"
                              className="w-full bg-brand-cream border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest font-sans"
                            />
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Your Rating</label>
                            <div className="flex space-x-1.5" id="rating-stars-input">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  key={star}
                                  type="button"
                                  onClick={() => setNewReviewRating(star)}
                                  className="text-brand-brass hover:scale-110 transition-transform cursor-pointer"
                                  title={`${star} Star`}
                                >
                                  <Star className={`h-5 w-5 ${star <= newReviewRating ? 'fill-brand-brass' : ''}`} />
                                </button>
                              ))}
                            </div>
                          </div>

                          <div>
                            <label className="block text-[10px] uppercase tracking-wider font-bold text-brand-forest/70 mb-1">Comments</label>
                            <textarea
                              required
                              rows={3}
                              value={newReviewText}
                              onChange={(e) => setNewReviewText(e.target.value)}
                              placeholder="Tell us about the texture, melting response, and salt balance..."
                              className="w-full bg-brand-cream border border-brand-stone/60 rounded px-3 py-2 text-xs focus:outline-none focus:border-brand-forest font-sans"
                            />
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-brand-forest hover:bg-brand-oak text-brand-cream text-xs uppercase tracking-widest py-2.5 font-bold rounded cursor-pointer transition-colors"
                          >
                            Submit Review
                          </button>
                        </form>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
