import { Recipe } from '../types';

export const recipes: Recipe[] = [
  {
    id: 'baking-croissant',
    title: 'The Ultimate Hand-Laminated Croissant',
    category: 'pastries',
    prepTime: '2 hours',
    cookTime: '25 mins',
    servings: 8,
    description: 'A masterclass in pastry lamination. Using our high-fat Normandy Style Butter, this recipe guides you to create paper-thin butter layers that puff into crispy, light, golden shards of croissant perfection.',
    ingredients: [
      '500g Type T55 Traditional French Flour',
      '60g Castor Sugar',
      '10g Fine Sea Salt',
      '12g Active Dry Yeast',
      '250g 84% Butterfat Normandy Style Butter (cold)',
      '280ml Organic Whole Milk (chilled)',
      '1 Organic Egg (for egg wash)'
    ],
    instructions: [
      'Mix flour, sugar, yeast, milk, and salt until a cohesive dough forms. Knead lightly, roll into a flat square, and freeze for 30 minutes to arrest fermentation.',
      'Prepare the butter block: Place the cold Normandy Style Butter between two large sheets of parchment paper. Use a rolling pin to beat and roll the butter into a precise 20x20cm square. Keep chilled but pliable.',
      'Roll the dough into a 30x30cm square. Place the butter block diagonally in the center, fold the dough corners over to seal the butter completely inside.',
      'Roll out into a long rectangle, then perform a single folder turn (letter fold). Wrap and chill in the freezer for 20 minutes.',
      'Repeat the rolling and folding process two more times, chilling thoroughly between turns to prevent the butter from melting into the dough layers.',
      'Roll out the final laminated pastry dough to 4mm thickness. Cut into tall triangles, roll tightly from base to tip, and prove at 24°C for 2 hours until doubled and jiggly.',
      'Brush gently with beaten egg wash. Bake in a preheated convection oven at 190°C for 22-25 minutes until deep copper-golden.'
    ],
    featuredButterId: 'normandy-style',
    image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'steak-truffle-ribeye',
    title: 'Pan-Seared Dry-Aged Ribeye with Black Truffle Butter',
    category: 'steak',
    prepTime: '10 mins',
    cookTime: '12 mins',
    servings: 2,
    description: 'Elevate a premium cut of dry-aged beef with a luxurious, rich pool of Perigord Black Truffle Butter. Basting with high-quality fat locks in juices and builds a magnificent caramelized crust.',
    ingredients: [
      '2x 400g Dry-Aged Ribeye Steaks (room temperature)',
      '3 tbsp Coarse Fleur de Sel',
      '2 tbsp Cracked Black Pepper',
      '60g Perigord Black Truffle Butter',
      '3 sprigs Fresh Rosemary',
      '4 cloves Garlic (crushed)'
    ],
    instructions: [
      'Pat the steaks extremely dry with paper towels. Season generously on all sides with coarse salt and cracked black pepper, pressing them into the grain.',
      'Heat a heavy cast-iron skillet over high heat until smoking. Add a tiny splash of neutral high-heat oil.',
      'Lay the steaks in the skillet. Sear untouched for 2 minutes, then flip to form a deep brown crust.',
      'Turn heat to medium. Add the rosemary sprigs, crushed garlic, and the Perigord Black Truffle Butter to the pan.',
      'Tilt the skillet and continuously spoon the foaming, truffle-rich butter over the top of the steaks for 3-4 minutes, basting them in luxury.',
      'Remove steaks from pan at 52°C internal temperature (for medium-rare). Rest on a warm board for 8 minutes to redistribute juices.',
      'Slice thickly and top with an extra, cold coin of Black Truffle Butter right before serving.'
    ],
    featuredButterId: 'truffle-gold',
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'scallops-lemon-dill',
    title: 'Cast-Iron Scallops in Preserved Lemon & Dill Emulsion',
    category: 'seafood',
    prepTime: '15 mins',
    cookTime: '6 mins',
    servings: 4,
    description: 'Plump King Scallops seared to a golden caramelized crust, then pan-finished in an aromatic emulsion of our Preserved Lemon and Fresh Dill Butter.',
    ingredients: [
      '12 Fresh King Scallops (cleaned and dried)',
      '50g Preserved Lemon & Fresh Dill Butter',
      '1 tbsp Cold-pressed Olive Oil',
      '50ml Dry White Wine (Chablis preferred)',
      'Fresh lemon wedges (for serving)'
    ],
    instructions: [
      'Ensure the scallops are bone-dry. Season very lightly with sea salt (the preserved lemon butter is naturally seasoned).',
      'Get a stainless steel sauté pan intensely hot. Add olive oil.',
      'Place scallops in the pan in a clockwise circle. Sear untouched for 90 seconds until a deep, golden-brown crust forms.',
      'Flip the scallops. Add the white wine to deglaze, letting it reduce by half in 30 seconds.',
      'Reduce heat to low and add the Preserved Lemon & Dill Butter. Swirl the pan rapidly to create a glossy, creamy butter sauce.',
      'Spoon the dill-flecked butter emulsion over the scallops for 1 minute. Serve immediately with a drizzle of the pan juices.'
    ],
    featuredButterId: 'lemon-dill',
    image: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'breakfast-pancakes',
    title: 'Fluffy Soufflé Pancakes with Honey & Salted Butter',
    category: 'breakfast',
    prepTime: '20 mins',
    cookTime: '15 mins',
    servings: 3,
    description: 'A decadent Sunday morning celebration. Incredibly airy, cloud-like pancakes topped with a melting scoop of Wild Flower Honey & Sea Salt Butter and fresh organic honeycombs.',
    ingredients: [
      '150g Pastry Flour',
      '1 tsp Baking Powder',
      '30g Castor Sugar',
      '2 Large Eggs (separated)',
      '150ml Buttermilk',
      '1 tsp Vanilla Bean Paste',
      '50g Wild Flower Honey & Sea Salt Butter (softened)',
      'Fresh honeycomb & berries (to serve)'
    ],
    instructions: [
      'Whisk the egg yolks, buttermilk, vanilla paste, and sifted flour/baking powder in a bowl until smooth.',
      'In a clean bowl, whip egg whites and sugar to stiff glossy peaks.',
      'Gently fold the egg whites into the batter in three separate additions, maintaining the trapped air.',
      'Lightly grease a non-stick frying pan, heat over low. Scoop tall mounds of batter into the pan. Add 1 tsp of water to the pan and cover with a lid to steam-bake.',
      'Cook for 4 minutes until the bottom is golden, flip gently, cover and cook for another 3-4 minutes.',
      'Stack the warm pancakes high, place a generous quenelle of soft Wild Flower Honey & Sea Salt Butter on top, and garnish with fresh honeycomb.'
    ],
    featuredButterId: 'honey-comb',
    image: 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'vegetables-garlic',
    title: 'Roasted Roots in Foraged Wild Garlic Butter',
    category: 'vegetables',
    prepTime: '10 mins',
    cookTime: '35 mins',
    servings: 4,
    description: 'Sweet, earthy heirloom carrots slow-roasted in our spring-harvested Foraged Wild Garlic Butter until caramelized, tender, and intensely flavorful.',
    ingredients: [
      '800g Heirloom Carrots (colorful variety, scrubbed and halved)',
      '60g Spring Foraged Wild Garlic Butter (melted)',
      '2 sprigs Fresh Thyme',
      'Sea Salt and Coarse Black Pepper',
      'Fresh goat cheese crumbles (optional, for garnish)'
    ],
    instructions: [
      'Preheat oven to 200°C (185°C fan).',
      'Toss the colorful carrots in a baking dish with the melted Foraged Wild Garlic Butter, fresh thyme sprigs, salt, and pepper.',
      'Spread them in a single layer on a parchment-lined baking sheet, ensuring they aren’t crowded to encourage roasting instead of steaming.',
      'Roast for 30-35 minutes, turning halfway through, until carrots are tender and edges are beautifully caramelized.',
      'Drizzle any remaining garlic butter from the tray over the carrots, scatter with goat cheese if desired, and serve warm.'
    ],
    featuredButterId: 'wild-garlic',
    image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&q=80&w=800'
  }
];
