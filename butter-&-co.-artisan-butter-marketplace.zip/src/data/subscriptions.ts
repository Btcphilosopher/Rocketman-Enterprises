import { SubscriptionPlan } from '../types';

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'monthly-box',
    name: 'Monthly Butter Box',
    price: 24.00,
    frequency: 'Monthly',
    description: 'An exceptional monthly delivery of freshly churned table essentials and signature classics.',
    features: [
      '2x 250g Signature Maldon Salted blocks',
      '1x 200g Seasonal Cultured rotation',
      'Informative farm-origin cards and recipe pairings',
      'Free chilled carbon-neutral shipping'
    ],
    badge: 'Best Value',
    image: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'seasonal-selection',
    name: 'Seasonal Selection',
    price: 28.00,
    frequency: 'Monthly',
    description: 'Explore the flavors of the season. Features limited edition infusions with seasonal herbs, forest berries, and custom spices.',
    features: [
      '1x 200g Fresh Limited Seasonal release',
      '1x 200g Gourmet Flavoured butter (Garlic, Honey, or Truffle)',
      '1x 250g Hand-Rolled Farmhouse block',
      'Early access to small batch experimental reserves',
      'Free chilled shipping'
    ],
    badge: 'Popular Choice',
    image: 'https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'chefs-choice',
    name: "Chef's Choice Guild",
    price: 34.00,
    frequency: 'Monthly',
    description: 'Curated specifically for culinary purists and avid home chefs looking to elevate high-end dining.',
    features: [
      '1x 150g Perigord Black Truffle Butter',
      '1x 200g Aged Black Garlic & Umami Butter',
      '1x 250g 84% Butterfat Normandy Style block',
      'Exclusive invitation to quarterly online butter-masterclasses',
      'Priority express shipping'
    ],
    badge: 'Luxury Tier',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'family-sub',
    name: 'Family Country Subscription',
    price: 45.00,
    frequency: 'Monthly',
    description: 'Generously proportioned dairy for active country kitchens that bake, spread, and sauté daily.',
    features: [
      '4x 250g Signature Maldon Salted blocks',
      '2x 250g Sweet Cream Unsalted blocks',
      '1x 200g Family Flavoured rotation of the month',
      'A complimentary seasonal honey jar every quarter',
      'Free carbon-neutral courier delivery'
    ],
    image: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'gift-membership',
    name: 'Gift Membership (3 Months)',
    price: 85.00,
    frequency: 'One-off payment',
    description: 'Prepay a luxury 3-month subscription for a friend. Includes a copper butter spreader in the initial box.',
    features: [
      '3 consecutive monthly boxes shipped direct',
      'Initial box contains high-grade copper butter spreader',
      'Personalized handwritten gift calligraphy card included',
      'Recipient activates shipping calendar whenever ready'
    ],
    badge: 'Perfect Gift',
    image: 'https://images.unsplash.com/photo-1620921556328-1a9300dce76d?auto=format&fit=crop&q=80&w=800'
  }
];
