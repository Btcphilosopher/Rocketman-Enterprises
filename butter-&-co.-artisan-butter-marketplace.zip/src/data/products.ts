import { Product } from '../types';

export const products: Product[] = [
  // --- CLASSIC BUTTER COLLECTION ---
  {
    id: 'maldon-salted',
    name: 'Maldon Sea Salt Churned Butter',
    tagline: 'Hand-flaked Maldon crystals folded into slowly matured cream.',
    price: 9.50,
    collection: 'classic',
    image: 'https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?auto=format&fit=crop&q=80&w=800',
    description: 'Our signature classic. We mature grass-fed single-herd cream for 36 hours before churning in traditional French oak barrels. Flakes of sea salt from the ancient Maldon marshes are manually folded through just before block shaping, giving a delightful crunch and intense savory response.',
    ingredients: ['Pasture-Raised Double Cream (Milk)', 'Maldon Sea Salt Crystals (1.8%)'],
    farmOrigin: {
      name: 'Somerset Valley Farm',
      location: 'Somerset, UK',
      story: 'Home to forty heritage Guernsey cows grazing on deep-rooted white clover and rye-grass pastures. Run by the third-generation Alder family, known for producing high-fat, gold-hued cream.'
    },
    churningMethod: 'Slow barrel-churned in Normandy oak barrels, hand-beaten with maple paddles.',
    tastingNotes: ['Sweet grass-fed cream', 'Mineral-rich seaside finish', 'Intermittent crystalline crunch'],
    pairingSuggestions: ['Warm sourdough baguette', 'Radishes with coarse salt', 'A perfect canvas for morning toast'],
    storageAdvice: 'Keep chilled (3-5°C). For optimal spreadability, temper at room temperature for 15 minutes before serving.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 74,
      fat: '82.2g',
      saturatedFat: '52.1g',
      sodium: '0.18g',
      carbs: '0.1g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 148
  },
  {
    id: 'sweet-unsalted',
    name: 'Sweet Cream Unsalted Butter',
    tagline: 'Purity in its highest form, churned for velvet smooth pastry.',
    price: 8.50,
    collection: 'classic',
    image: 'https://images.unsplash.com/photo-1620921556328-1a9300dce76d?auto=format&fit=crop&q=80&w=800',
    description: 'Developed specifically for master bakers and pure butter purists. This sweet cream butter is churned within four hours of milking, capturing the delicate, light-floral sweetness of early morning dairy without salt interference. Extremely low moisture content ensures flaky croissants and high-tolerance puff pastries.',
    ingredients: ['Pasture-Raised Double Cream (Milk)'],
    farmOrigin: {
      name: 'Laneside Dairy pastures',
      location: 'Cotswolds, UK',
      story: 'Famous for pristine chalk streams and chemical-free herb meadows. Cows roam freely, feeding on chamomile and wild meadow fescue.'
    },
    churningMethod: 'Continuous vacuum-cold churned to reduce moisture to less than 15.5%.',
    tastingNotes: ['Delicate white flower', 'Sweet fresh milk', 'Subtle hazelnut Undertones'],
    pairingSuggestions: ['Fine pastry dough', 'Finishing premium reductions', 'Licking clean off a warm morning scone'],
    storageAdvice: 'Store below 4°C. Wrap tightly in parchment to prevent absorption of other refrigerator aromas.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 75,
      fat: '83.5g',
      saturatedFat: '53.0g',
      sodium: '0.01g',
      carbs: '0.1g',
      protein: '0.1g'
    },
    rating: 4.8,
    reviewsCount: 92
  },
  {
    id: 'cultured-double',
    name: 'Double-Churned Cultured Butter',
    tagline: 'Rich, lactic complexity inspired by traditional Nordic creameries.',
    price: 10.50,
    collection: 'classic',
    image: 'https://images.unsplash.com/photo-1634818462211-144f8303a5aa?auto=format&fit=crop&q=80&w=800',
    description: 'We introduce live lactic cultures to our pasteurized cream, letting it ferment in small batches at a controlled 16°C. Once the perfect acidity level (pH 4.8) is reached, it is twice churned. The resulting butter carries an exquisite, tangy sharpness, with a rich custard-like texture and superior melting characteristics.',
    ingredients: ['Cultured Double Cream (Milk)', 'Lactic Culture', 'Fleur de Sel (1.2%)'],
    farmOrigin: {
      name: 'Nordic Meadow Coop',
      location: 'Jutland Peninsula, Denmark',
      story: 'An eco-certified seaside pasture where cool sea winds mineralize the forage. Heritage Red Danish cattle provide cream rich in beta-caseins.'
    },
    churningMethod: 'Lactic acidification followed by double-churning in stainless steel paddle churns.',
    tastingNotes: ['Crème fraîche tang', 'Cultured yoghurt notes', 'Bright buttermilk acidity'],
    pairingSuggestions: ['Dark rye sourdough', 'Smoked salmon tartines', 'Finishing wild mushroom risottos'],
    storageAdvice: 'Keep refrigerated. Due to active fermentation depth, the flavor will continue to mature gracefully.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 73,
      fat: '81.4g',
      saturatedFat: '51.8g',
      sodium: '0.12g',
      carbs: '0.2g',
      protein: '0.2g'
    },
    rating: 5.0,
    reviewsCount: 204
  },
  {
    id: 'farmhouse-rolled',
    name: 'Traditional Hand-Rolled Farmhouse',
    tagline: 'Hand-beaten and shaped using antique maplewood butter paddles.',
    price: 11.00,
    collection: 'classic',
    image: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?auto=format&fit=crop&q=80&w=800',
    description: 'Our ultimate homage to rural British dairy craft. We retrieve the morning buttermilk curds, wash them in cold natural spring water, and hand-beat them using heritage maplewood paddles to express remaining moisture. Individually rolled and wrapped in greaseproof linen paper.',
    ingredients: ['Artisan Farmhouse Cream (Milk)', 'Celtic Sea Salt (1.5%)'],
    farmOrigin: {
      name: 'Blackdown Hills Dairy',
      location: 'Devon, UK',
      story: 'A highly preserved Devon woodland estate. Jersey cows forage on clover, dandelions, and medicinal wild herbs.'
    },
    churningMethod: 'Traditional wooden trough churning, washed in deep-well spring water.',
    tastingNotes: ['Grassy autumn hay', 'Rich clotted cream', 'Earthy mineral salt'],
    pairingSuggestions: ['Thick crusty farm loaf', 'Baking jacket potatoes', 'Crumpets hot off the griddle'],
    storageAdvice: 'Consume within 3 weeks of opening or freeze beautifully for up to 6 months.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 74,
      fat: '82.0g',
      saturatedFat: '52.0g',
      sodium: '0.15g',
      carbs: '0.1g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 76
  },
  {
    id: 'normandy-style',
    name: '84% Butterfat Normandy Style',
    tagline: 'Extraordinarily rich, pliable French-style baking champion.',
    price: 11.50,
    collection: 'classic',
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?auto=format&fit=crop&q=80&w=800',
    description: 'With a high butterfat ratio of 84%, this Normandy-inspired masterpiece is fermented with traditional European cultures. It yields a rich, pliable texture that folds effortlessly without breaking, making it the premier choice for laminate pastry doughs and gourmet sauces.',
    ingredients: ['High-Fat Cultured Cream (Milk)', 'Fine Sea Salt (0.8%)'],
    farmOrigin: {
      name: 'Bocage Normandy Pastures',
      location: 'Normandy, France',
      story: 'Lush pastures situated near the sea where salt spray enriches the soil, creating pasture grasses that yield uniquely rich cream.'
    },
    churningMethod: 'Slow speed paddle churning, hand kneaded on limestone boards.',
    tastingNotes: ['Sweet roasted hazelnut', 'Heavy warm milk', 'Cultured butterscotch'],
    pairingSuggestions: ['Laminated pastries', 'Drizzled on steamed lobster', 'Making traditional Hollandaise'],
    storageAdvice: 'Store at 2-4°C. Perfect for freezing.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 76,
      fat: '84.1g',
      saturatedFat: '54.2g',
      sodium: '0.08g',
      carbs: '0.1g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 118
  },

  // --- FLAVOURED BUTTER COLLECTION ---
  {
    id: 'garlic-herb',
    name: 'Roasted Garlic & Herb Butter',
    tagline: 'Sweet, caramelized slow-roasted garlic and fresh English herbs.',
    price: 12.00,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?auto=format&fit=crop&q=80&w=800',
    description: 'We roast whole cloves of English garlic in extra virgin olive oil until sweet and golden, then mash and fold them into cultured butter alongside finely chopped flat-leaf parsley, french chives, and lemon thyme. It delivers a punchy yet beautifully rounded finish.',
    ingredients: ['Cultured Butter (Milk)', 'English Garlic (12%)', 'Flat-Leaf Parsley', 'Chives', 'Lemon Thyme', 'Sea Salt'],
    farmOrigin: {
      name: 'Wiltshire Herb Farms',
      location: 'Wiltshire, UK',
      story: 'Organic heritage farm dedicated to sustainable herb growing and traditional cold-pressed herbal oils.'
    },
    churningMethod: 'Cultured churning blended with cold-infused roasted garlic oil.',
    tastingNotes: ['Sweet caramelized garlic', 'Peppery chive', 'Bright aromatic thyme'],
    pairingSuggestions: ['Seared ribeye steak', 'Garlic bread baguettes', 'Tossing through hot pasta'],
    storageAdvice: 'Store below 4°C. Use within 14 days of opening.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 71,
      fat: '78.5g',
      saturatedFat: '49.8g',
      sodium: '0.16g',
      carbs: '0.6g',
      protein: '0.2g'
    },
    rating: 4.9,
    reviewsCount: 312
  },
  {
    id: 'sea-salt-pepper',
    name: 'Fleur de Sel & Cracked Pepper',
    tagline: 'Premium Madagascar green peppercorns and rich mineral salt.',
    price: 10.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=800',
    description: 'A simple yet transformative blend. Coarse Fleur de Sel is combined with toasted, freshly cracked Madagascar green and black peppercorns. This combination delivers a woodsy, complex warmth that cuts beautifully through the high-fat pasture cream.',
    ingredients: ['Somerset Butter (Milk)', 'Madagascar Black Pepper (1.2%)', 'Green Peppercorns (0.8%)', 'Fleur de Sel (1.5%)'],
    farmOrigin: {
      name: 'Somerset Valley Farm',
      location: 'Somerset, UK',
      story: 'Grass-fed dairy farm nestled in the Mendip Hills, providing exceptionally creamy milk.'
    },
    churningMethod: 'Direct blending in our cooling vats to keep pepper volatile oils intact.',
    tastingNotes: ['Toasty warm wood', 'Piquant citrusy pepper', 'Mild clean sea salt'],
    pairingSuggestions: ['Crusty sourdough toast', 'Finishing baked potatoes', 'Melting over roast chicken'],
    storageAdvice: 'Keep chilled. Best served slightly tempered.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 73,
      fat: '80.1g',
      saturatedFat: '51.0g',
      sodium: '0.15g',
      carbs: '0.2g',
      protein: '0.1g'
    },
    rating: 4.7,
    reviewsCount: 84
  },
  {
    id: 'smoked-wood',
    name: 'Smoked Oakwood Butter',
    tagline: 'Cold-smoked over seasoned English oak barrels for 12 hours.',
    price: 12.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1506368249639-73a05d6f6488?auto=format&fit=crop&q=80&w=800',
    description: 'We spread our freshly hand-churned butter onto thin cheesecloth sheets and cold-smoke it inside our custom stone smokehouses. Seasoned English oak barrels from local distillers are burned low, infusing the butter with a deeply rich, sweet smokiness that mimics charcoal grill finishes.',
    ingredients: ['Oak-Smoked Sweet Cream Butter (Milk)', 'Alderwood Smoked Salt (1.2%)'],
    farmOrigin: {
      name: 'Weald Smokehouse Dairy',
      location: 'Kent, UK',
      story: 'An artisanal wood-smoking cooperative specializing in traditional preservation methods and forest-grazed livestock.'
    },
    churningMethod: 'Cold oakwood smoke chamber infusion followed by secondary whipping.',
    tastingNotes: ['Sweet birch woodfire', 'Campfire toast', 'Rich hickory finish'],
    pairingSuggestions: ['Steamed sweetcorn', 'Pan-fried scallops', 'Warmed rustic brown bread'],
    storageAdvice: 'Keep tightly sealed in its glass jar to lock in the delicate volatile smoke aromatics.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 74,
      fat: '81.8g',
      saturatedFat: '52.0g',
      sodium: '0.12g',
      carbs: '0.1g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 126
  },
  {
    id: 'chilli-butter',
    name: 'Smoked Chilli & Lime Butter',
    tagline: 'Smoky Chipotle peppers balanced with fresh lime zest.',
    price: 11.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&q=80&w=800',
    description: 'A vibrant combination of fiery Mexican chipotles and fresh citrus. Ground smoked jalapeños are folded together with fresh lime juice, grated lime zest, and a touch of coriander. The high butterfat content wraps around the chilli heat, delivering flavor without burning.',
    ingredients: ['Sweet Cream Butter (Milk)', 'Chipotle Pepper Paste (4%)', 'Fresh Lime Zest (2%)', 'Coriander', 'Sea Salt'],
    farmOrigin: {
      name: 'Laneside Dairy pastures',
      location: 'Cotswolds, UK',
      story: 'Pristine fields that run adjacent to wildflower orchards, adding natural complexity to the cream.'
    },
    churningMethod: 'Cold folded micro-batches to prevent citrus curdling.',
    tastingNotes: ['Sweet capsicum smoke', 'Vibrant citrus high-notes', 'Lingering warm pepper'],
    pairingSuggestions: ['Charred corn on the cob', 'Grilled jumbo prawns', 'Whipping into sweet potato mash'],
    storageAdvice: 'Refrigerate immediately. Zest oils are highly sensitive to warmth.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 72,
      fat: '79.2g',
      saturatedFat: '50.2g',
      sodium: '0.14g',
      carbs: '0.4g',
      protein: '0.1g'
    },
    rating: 4.8,
    reviewsCount: 165
  },
  {
    id: 'truffle-gold',
    name: 'Perigord Black Truffle Butter',
    tagline: 'French Black Winter truffles whipped with aged sea salt.',
    price: 18.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&q=80&w=800',
    description: 'The absolute pinnacle of luxury dining. We source genuine black winter truffles (Tuber melanosporum) directly from Périgord, France. These are shaved and gently steeped in clarified butter before being whipped into our 36-hour cultured cream. Deeply earthy, complex, and extraordinarily rich.',
    ingredients: ['Fermented Cultured Butter (Milk)', 'French Black Winter Truffle (5%)', 'Cold-Pressed White Truffle Oil', 'Grey Guerande Salt (1.1%)'],
    farmOrigin: {
      name: 'Blackdown Hills Dairy',
      location: 'Devon, UK',
      story: 'Lush pastures situated adjacent to a private truffle oak orchard, where Devon woodland soils yield rich forage.'
    },
    churningMethod: 'Steeped truffle micro-fusion, double-whipped at 12°C for aerated softness.',
    tastingNotes: ['Damp autumn earth', 'Rich woodland mushroom', 'Slight toasted garlic finish'],
    pairingSuggestions: ['Tossing through warm tagliatelle', 'Basting high-grade fillet steak', 'Melted over simple soft-scrambled eggs'],
    storageAdvice: 'Store below 4°C. Keep under glass dome lid to concentrate truffle esters.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 73,
      fat: '80.5g',
      saturatedFat: '51.1g',
      sodium: '0.11g',
      carbs: '0.2g',
      protein: '0.3g'
    },
    rating: 5.0,
    reviewsCount: 412
  },
  {
    id: 'wild-garlic',
    name: 'Spring Foraged Wild Garlic Butter',
    tagline: 'Hand-picked woodland wild garlic and spring chives.',
    price: 12.00,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1515003848353-796841b74b1c?auto=format&fit=crop&q=80&w=800',
    description: 'A true seasonal triumph available year-round. Wild garlic ramps are forage-harvested by hand in ancient Somerset woodlands, blanched to lock in their vibrant green chlorophyll, and puréed directly into cold-churned farmhouse butter. Delicate, sweet, and herbaceous.',
    ingredients: ['Farmhouse Butter (Milk)', 'Foraged Wild Garlic Ramps (8%)', 'Fresh Parsley', 'Sea Salt'],
    farmOrigin: {
      name: 'Somerset Valley Farm',
      location: 'Somerset, UK',
      story: 'Famous ancient woodlands bordered by freshwater streams where wild ramps carpet the valley floor every spring.'
    },
    churningMethod: 'Chlorophyll extraction and immediate cold compounding inside stone mortars.',
    tastingNotes: ['Delicate sweet onion', 'Fresh wet morning grass', 'Mild peppery garlic'],
    pairingSuggestions: ['Focaccia baking', 'Pan-seared cod or sea bass', 'Tossed into baby new potatoes'],
    storageAdvice: 'Keep chilled. Highly light sensitive; store away from glass exposure.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 72,
      fat: '79.8g',
      saturatedFat: '50.6g',
      sodium: '0.13g',
      carbs: '0.3g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 94
  },
  {
    id: 'honey-comb',
    name: 'Wild Flower Honey & Sea Salt',
    tagline: 'Sweet, amber Salisbury honey with flaky Maldon salt.',
    price: 11.00,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&q=80&w=800',
    description: 'An addictive sweet-savory masterpiece. Raw wildflower honey, harvested from local apiaries, is ribbon-folded into our cultured unsalted butter along with just a touch of flaky sea salt. Perfect for breakfast luxury, melting into golden puddles on toast.',
    ingredients: ['Sweet Cream Butter (Milk)', 'Raw Salisbury Honey (15%)', 'Maldon Salt (0.5%)'],
    farmOrigin: {
      name: 'Wiltshire Herb Farms',
      location: 'Wiltshire, UK',
      story: 'Features extensive lavender fields and wild clover pastures supporting fifty organic hives.'
    },
    churningMethod: 'Ribbon-whipped at high speed to emulsify honey fructose without separation.',
    tastingNotes: ['Rich amber nectar', 'Warm floral lavender', 'Salty honeycomb finish'],
    pairingSuggestions: ['Warm sourdough waffles', 'Freshly baked buttermilk biscuits', 'Glazing caramelized carrots'],
    storageAdvice: 'Do not freeze. Keep at 5-8°C for ultimate creamy scoopability.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 68,
      fat: '71.2g',
      saturatedFat: '45.0g',
      sodium: '0.05g',
      carbs: '1.8g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 224
  },
  {
    id: 'cinnamon-maple',
    name: 'Cinnamon & Dark Maple Butter',
    tagline: 'Toasted Ceylon cinnamon whipped with Vermont Grade-A maple syrup.',
    price: 11.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=800',
    description: 'Fragrant and warming. We toast whole Ceylon cinnamon bark, grind it to a micro-powder, and fold it alongside concentrated grade-A dark maple syrup into double-churned cream. It delivers a deeply nostalgic, bakery-fresh warmth.',
    ingredients: ['Sweet Cream Butter (Milk)', 'Grade-A Maple Syrup (10%)', 'Ceylon Cinnamon (1.5%)', 'Demerara Sugar'],
    farmOrigin: {
      name: 'Laneside Dairy pastures',
      location: 'Cotswolds, UK',
      story: 'Surrounded by ancient woodland, providing a peaceful, quiet grazing estate.'
    },
    churningMethod: 'Emulsified low-temp whipping to preserve the natural maple aromas.',
    tastingNotes: ['Warming sweet bark', 'Deep maple brown sugar', 'Buttery vanilla pod'],
    pairingSuggestions: ['Fresh French toast', 'Morning croissants', 'Glazing roasted butternut squash'],
    storageAdvice: 'Keep chilled. Bring to room temp before spreading.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 69,
      fat: '73.0g',
      saturatedFat: '46.1g',
      sodium: '0.02g',
      carbs: '1.4g',
      protein: '0.1g'
    },
    rating: 4.8,
    reviewsCount: 113
  },
  {
    id: 'lemon-dill',
    name: 'Preserved Lemon & Fresh Dill',
    tagline: 'North African preserved salt lemons and feathery green dill.',
    price: 11.00,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1615141982883-c7ad0e69fd62?auto=format&fit=crop&q=80&w=800',
    description: 'Specifically engineered for seafood lovers. We salt-preserve lemons for six months, then finely mince the fragrant rinds. This is blended into fresh cultured butter along with cold-harvested baby dill leaves and a splash of white balsamic.',
    ingredients: ['Cultured Butter (Milk)', 'Preserved Lemon Rind (6%)', 'Fresh Baby Dill (3%)', 'White Balsamic', 'Sea Salt'],
    farmOrigin: {
      name: 'Nordic Meadow Coop',
      location: 'Jutland Peninsula, Denmark',
      story: 'A premium coop that feeds cows high-fiber clover, creating extremely stable, milk-fat cream.'
    },
    churningMethod: 'Micro-batch blending using cold paddle rollers.',
    tastingNotes: ['Bright citrus rind', 'Anise-scented dill', 'Tangy sour-salty finish'],
    pairingSuggestions: ['Basting fresh salmon fillets', 'Tossing with green asparagus', 'Slathering on crab claws'],
    storageAdvice: 'Keep at 2-4°C. Best used fresh.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 72,
      fat: '79.1g',
      saturatedFat: '50.1g',
      sodium: '0.14g',
      carbs: '0.3g',
      protein: '0.1g'
    },
    rating: 4.8,
    reviewsCount: 77
  },
  {
    id: 'black-garlic',
    name: 'Aged Black Garlic & Umami Butter',
    tagline: '90-day fermented black garlic bulbs whipped with white miso.',
    price: 13.00,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1607532941433-304659e8198a?auto=format&fit=crop&q=80&w=800',
    description: 'An umami-bomb of epic proportions. We ferment organic garlic bulbs under low-heat humidity for 90 days until the cloves turn jet-black, soft, and sweet as molasses. Blended with organic white shiro miso into high-fat Normandy style butter.',
    ingredients: ['Artisan Butter (Milk)', 'Fermented Black Garlic (10%)', 'White Shiro Miso (3%)', 'Sea Salt'],
    farmOrigin: {
      name: 'Weald Smokehouse Dairy',
      location: 'Kent, UK',
      story: 'Famous for experimental culinary collaborations with modern foraging chefs.'
    },
    churningMethod: 'Stoned-ground pestle blending with whipped high-fat butter.',
    tastingNotes: ['Sweet aged balsamic', 'Rich soy-miso savoriness', 'Sticky sweet molasses'],
    pairingSuggestions: ['Finishing premium wagyu or ribeye', 'Sautéing green beans', 'Melting into hot stir-fries'],
    storageAdvice: 'Store chilled. Highly shelf-stable due to natural garlic antioxidants.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 71,
      fat: '77.8g',
      saturatedFat: '49.0g',
      sodium: '0.19g',
      carbs: '0.8g',
      protein: '0.3g'
    },
    rating: 5.0,
    reviewsCount: 189
  },
  {
    id: 'rosemary-thyme',
    name: 'Rosemary & Lemon Thyme Butter',
    tagline: 'Garden fresh rosemary and woodsy thyme infused in rich cream.',
    price: 11.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1515003848353-796841b74b1c?auto=format&fit=crop&q=80&w=800',
    description: 'The essence of a traditional English herb garden. We gently heat freshly harvested rosemary and lemon thyme in sweet pasture cream to extract their essential oils, let the mixture cool and cure, then churn to lock in the deep, aromatic garden notes.',
    ingredients: ['Sweet Farmhouse Cream (Milk)', 'Fresh Rosemary (2%)', 'Lemon Thyme (1.5%)', 'Coarse Sea Salt (1%)'],
    farmOrigin: {
      name: 'Blackdown Hills Dairy',
      location: 'Devon, UK',
      story: 'Rich alluvial soil pastures bordered by thick natural hedgerows brimming with wild herbs.'
    },
    churningMethod: 'Pre-churn cream infusion at 55°C followed by slow wood-paddle churn.',
    tastingNotes: ['Piney fresh rosemary', 'Bright lemon rind', 'Earthy woodsy thyme'],
    pairingSuggestions: ['Roasted leg of lamb', 'Basting roasted potatoes', 'Baking savory biscuits'],
    storageAdvice: 'Store below 4°C. Excellent when kept under wax paper.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 73,
      fat: '80.8g',
      saturatedFat: '51.3g',
      sodium: '0.10g',
      carbs: '0.2g',
      protein: '0.1g'
    },
    rating: 4.7,
    reviewsCount: 68
  },
  {
    id: 'whisky-barrel',
    name: '12-Year Islay Whisky Butter',
    tagline: 'Single malt peated whisky whipped into rich cultured butter.',
    price: 14.50,
    collection: 'flavoured',
    image: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&q=80&w=800',
    description: 'A decadent and dramatic culinary finishing butter. We blend cask-strength, heavily-peated single malt whisky from Islay, Scotland, directly into double-churned cultured cream. The peaty, sea-salty smoke of the whisky blends flawlessly with the butter fat.',
    ingredients: ['Cultured Butter (Milk)', '12-Year Islay Peated Single Malt Whisky (5.5% ABV equivalent prior to emulsification)', 'Muscovado Sugar', 'Sea Salt'],
    farmOrigin: {
      name: 'Weald Smokehouse Dairy',
      location: 'Kent, UK',
      story: 'Collaborates with artisanal spirits producers across the UK to study fat-and-alcohol flavor emulsions.'
    },
    churningMethod: 'Controlled low-temperature alcohol folding to maintain chemical cream structure.',
    tastingNotes: ['Peated single malt smoke', 'Rich iodine sea spray', 'Sweet molasses undertones'],
    pairingSuggestions: ['Perfect steak finisher', 'Glazing grilled game meat', 'Drizzled over warm fruit cake'],
    storageAdvice: 'Refrigerate tightly sealed. Alcohol content lowers freezing point slightly.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 72,
      fat: '78.2g',
      saturatedFat: '49.5g',
      sodium: '0.09g',
      carbs: '0.7g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 154
  },

  // --- SEASONAL COLLECTION ---
  {
    id: 'seasonal-wildberry',
    name: 'Summer Forest Berry & Lavender',
    tagline: 'Wild hand-picked summer berries infused with dried lavender bud.',
    price: 13.50,
    collection: 'seasonal',
    image: 'https://images.unsplash.com/photo-1601004890684-d8cbf643f5f2?auto=format&fit=crop&q=80&w=800',
    description: 'A gorgeous celebration of British midsummer. Hand-foraged wild blackberries, raspberries, and bilberries are reduced into a thick jam, then gently folded as beautiful purple ribbons into sweet unsalted butter alongside crushed English lavender flower buds.',
    ingredients: ['Sweet Cream Butter (Milk)', 'Foraged Summer Berries (10%)', 'English Lavender Buds (0.5%)', 'Cane Sugar'],
    farmOrigin: {
      name: 'Wiltshire Herb Farms',
      location: 'Wiltshire, UK',
      story: 'A highly bio-diverse estate with active organic beekeeping and pristine herb fields.'
    },
    churningMethod: 'Ribbon-marbled hand folding to preserve independent butter-and-berry layers.',
    tastingNotes: ['Tart wild bramble', 'Fragrant lavender perfume', 'Creamy sweet summer grass'],
    pairingSuggestions: ['Buttermilk pancakes', 'Warmed brioche or brioche toast', 'Afternoon tea scones'],
    storageAdvice: 'Limited edition. Keep refrigerated. Best consumed within 14 days of purchase.',
    nutritionalInfo: {
      servingSize: '10g',
      calories: 67,
      fat: '71.5g',
      saturatedFat: '44.8g',
      sodium: '0.01g',
      carbs: '1.9g',
      protein: '0.1g'
    },
    rating: 5.0,
    reviewsCount: 89,
    isLimitedEdition: true
  },

  // --- GIFT COLLECTION ---
  {
    id: 'gift-tasting-box',
    name: 'The Grand Butter Tasting Box',
    tagline: 'A curated discovery of five signature artisan butters.',
    price: 38.00,
    collection: 'gift',
    image: 'https://images.unsplash.com/photo-1620921556328-1a9300dce76d?auto=format&fit=crop&q=80&w=800',
    description: 'The ultimate culinary gift for the butter obsessive. Features five generous 80g portions of our finest butter crafts: Maldon Salted, Double-Churned Cultured, Périgord Black Truffle, Smoked Oakwood, and Roasted Garlic & Herb. Complete with a wooden butter spade and parchment tasting notes.',
    ingredients: ['Includes multiple butters. Refer to individual labels inside the box.'],
    farmOrigin: {
      name: 'Various Partner Creameries',
      location: 'United Kingdom & Europe',
      story: 'An anthology of the finest small-batch dairy producers in the West Country, Cotswolds and Scandinavia.'
    },
    churningMethod: 'Mixed traditional and modern churn styles, custom proportioned.',
    tastingNotes: ['Range of notes from sweet floral milk to deep woodsy mushroom and smoke'],
    pairingSuggestions: ['The perfect centerpiece for a cheese and charcuterie board'],
    storageAdvice: 'Store refrigerated. Butters can be unfrozen independently as needed.',
    nutritionalInfo: {
      servingSize: '10g average',
      calories: 73,
      fat: '80.0g',
      saturatedFat: '51.0g',
      sodium: '0.13g',
      carbs: '0.4g',
      protein: '0.1g'
    },
    rating: 5.0,
    reviewsCount: 340
  },
  {
    id: 'gift-hamper',
    name: 'Artisanal Butter & Sourdough Hamper',
    tagline: 'Gourmet hand-woven willow hamper filled with breakfast luxury.',
    price: 65.00,
    collection: 'gift',
    image: 'https://images.unsplash.com/photo-1549931319-a545dcf3bc73?auto=format&fit=crop&q=80&w=800',
    description: 'An exceptional gift presenting traditional food craftsmanship. Features a hand-woven willow picnic basket containing: 1x Traditional Hand-Rolled Farmhouse Butter, 1x Wild Flower Honey Butter, a freshly baked artisanal heritage sourdough loaf, raw honeycomb, and a handcrafted copper butter knife.',
    ingredients: ['Includes sourdough wheat loaf, honeycomb, and dairy butter products.'],
    farmOrigin: {
      name: 'Blackdown Hills Coop',
      location: 'Devon, UK',
      story: 'A highly cohesive network of rural farms keeping food traditions alive through communal packing houses.'
    },
    churningMethod: 'Mixed artisan hand paddle rolling and small batch honey ribboning.',
    tastingNotes: ['Rustic stone-ground wheat', 'Intense sweet clover nectar', 'Thick pasture-rich fat'],
    pairingSuggestions: ['Perfect for lazy Sunday morning feasts or countryside picnics'],
    storageAdvice: 'Consume bread within 3 days. Refrigerate butters immediately.',
    nutritionalInfo: {
      servingSize: '10g butter equivalent',
      calories: 71,
      fat: '76.0g',
      saturatedFat: '48.0g',
      sodium: '0.10g',
      carbs: '1.2g',
      protein: '0.1g'
    },
    rating: 4.9,
    reviewsCount: 154
  }
];
