import { Farm } from '../types';

export const farms: Farm[] = [
  {
    id: 'somerset',
    name: 'Somerset Valley Farm',
    farmer: 'Arthur & Charles Alder',
    location: 'Mendip Hills, Somerset, UK',
    coords: { x: 42, y: 72 }, // visual percentage offset
    welfareScore: '9.8 / 10 (A+ Certified)',
    sustainabilityPractice: '100% Regenerative grazing, zero chemical fertilizers, organic clover restoration.',
    story: 'Established in 1932, Somerset Valley Farm is famous for its herd of purebred Guernsey cattle. Arthur Alder and his son Charles practice rotational paddock grazing, moving cows daily to fresh grasses rich in deep-rooted herbs. This creates high-protein milk loaded with natural beta-carotene, giving our butter its signature gold pigment.',
    image: 'https://images.unsplash.com/photo-1570042225831-d98fa7577f1e?auto=format&fit=crop&q=80&w=800',
    methods: ['Rotational mob-pasture grazing', 'Double cold-separated cream separation', 'Zero pasture chemical footprint']
  },
  {
    id: 'cotswolds',
    name: 'Laneside Dairy Pastures',
    farmer: 'Eleanor Vance',
    location: 'Cotswolds Area of Outstanding Natural Beauty, UK',
    coords: { x: 48, y: 64 },
    welfareScore: '9.7 / 10',
    sustainabilityPractice: 'Solar-powered creamery, recycled water systems, wildflower corridor preservation.',
    story: 'Eleanor Vance breeds pedigree Jersey cows known for their gentle temperament and ultra-thick sweet cream. The pastures are dotted with ancient chalk-streams and wild herb corridors. Eleanor believes happy, stress-free cows produce cream with higher butterfat levels and a sweeter aroma.',
    image: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&q=80&w=800',
    methods: ['Stress-free automated grooming brushes', 'Continuous pasture wildflower seeding', 'Solar-powered churning facilities']
  },
  {
    id: 'nordic',
    name: 'Nordic Meadow Coop',
    farmer: 'Henrik Skou & Family',
    location: 'Jutland Peninsula, Denmark',
    coords: { x: 74, y: 32 },
    welfareScore: '9.9 / 10 (Highest Nordic Standard)',
    sustainabilityPractice: 'Carbon-neutral farm logistics, 100% organic-certified clover & rye forage.',
    story: 'Henrik leads an eco-cooperative of small family dairy farms near the windy North Sea coast of Denmark. Cool maritime winds deposit mineral salts onto the clover fields, which Henrik’s Danish Red cattle graze on. This high-mineral forage creates stable milk fat, yielding butter that holds shape wonderfully.',
    image: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=800',
    methods: ['Cold-spray lactic culture fermentation', 'Sea salt wind-forage grazing', 'Carbon-negative wind farm energy']
  },
  {
    id: 'blackdown',
    name: 'Blackdown Hills Estate',
    farmer: 'The Sterling Brothers',
    location: 'Blackdown Hills, Devon, UK',
    coords: { x: 34, y: 78 },
    welfareScore: '9.8 / 10',
    sustainabilityPractice: 'No-till organic farming, hedgerow restoration for nesting wildlife, spring-water utilization.',
    story: 'Tucked deep in Devon wood-valleys, Blackdown Hills Estate breeds heritage Milking Shorthorn cattle. The pastures are completely chemical-free, watered by deep natural wells. The cows graze alongside wild herbs, chicory, and meadowsweet, injecting a subtle, earthy, complex scent into the butterfat.',
    image: 'https://images.unsplash.com/photo-1527457960512-587afd227840?auto=format&fit=crop&q=80&w=800',
    methods: ['Washing curd with local limestone spring water', 'Traditional wooden trough beating', 'Biodiversity corridor creation']
  },
  {
    id: 'weald',
    name: 'Weald Smokehouse & Dairy',
    farmer: 'Giles and Beatrice Thorne',
    location: 'Weald Forest, Kent, UK',
    coords: { x: 58, y: 68 },
    welfareScore: '9.6 / 10',
    sustainabilityPractice: 'Sustainably sourced coppiced oak fuel, zero waste packaging loops, multi-species pasture.',
    story: 'Giles and Beatrice combine woodland management with micro-dairy farming. Their cows graze in silvopasture meadows, surrounded by mature oak and beech trees. The farm houses an antique stone smokehouse, where they cold-smoke our butter using seasoned whisky barrels and fallen oak wood.',
    image: 'https://images.unsplash.com/photo-1516467508483-a7212febe31a?auto=format&fit=crop&q=80&w=800',
    methods: ['Woodland silvopasture grazing', 'Natural cold smoke-curing', 'Glass container reuse scheme']
  }
];
