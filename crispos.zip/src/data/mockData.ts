import {
  PotatoSpecification,
  Farm,
  Field,
  PotatoLot,
  StorageBin,
  ProductRecipe,
  FryingOilBatch,
  ProductionLine,
  ProductionBatch,
  OpticalInspectionEvent,
  CcpLog,
  GoldenTicketCampaign,
  GoldenTicket
} from '../types';

export const POTATO_SPECS: PotatoSpecification[] = [
  {
    variety: 'Lady Rosetta',
    targetDryMatterMin: 22.0,
    targetDryMatterMax: 25.0,
    targetSpecificGravityMin: 1.085,
    targetSpecificGravityMax: 1.098,
    maxReducingSugars: 0.10,
    maxDefectPercent: 2.5,
    minSizeDiameterMm: 50,
    maxSizeDiameterMm: 85,
    expectedOilAbsorptionPercent: 31.0,
    fryingSuitability: 'PREMIUM'
  },
  {
    variety: 'Atlantic',
    targetDryMatterMin: 21.5,
    targetDryMatterMax: 24.5,
    targetSpecificGravityMin: 1.082,
    targetSpecificGravityMax: 1.095,
    maxReducingSugars: 0.12,
    maxDefectPercent: 3.0,
    minSizeDiameterMm: 45,
    maxSizeDiameterMm: 80,
    expectedOilAbsorptionPercent: 33.0,
    fryingSuitability: 'PREMIUM'
  },
  {
    variety: 'Hermes',
    targetDryMatterMin: 20.5,
    targetDryMatterMax: 23.5,
    targetSpecificGravityMin: 1.078,
    targetSpecificGravityMax: 1.090,
    maxReducingSugars: 0.15,
    maxDefectPercent: 3.5,
    minSizeDiameterMm: 45,
    maxSizeDiameterMm: 85,
    expectedOilAbsorptionPercent: 34.5,
    fryingSuitability: 'HIGH'
  },
  {
    variety: 'Markies',
    targetDryMatterMin: 21.0,
    targetDryMatterMax: 24.0,
    targetSpecificGravityMin: 1.080,
    targetSpecificGravityMax: 1.092,
    maxReducingSugars: 0.14,
    maxDefectPercent: 3.0,
    minSizeDiameterMm: 50,
    maxSizeDiameterMm: 90,
    expectedOilAbsorptionPercent: 32.8,
    fryingSuitability: 'HIGH'
  },
  {
    variety: 'Taurus',
    targetDryMatterMin: 22.5,
    targetDryMatterMax: 25.5,
    targetSpecificGravityMin: 1.088,
    targetSpecificGravityMax: 1.100,
    maxReducingSugars: 0.08,
    maxDefectPercent: 2.0,
    minSizeDiameterMm: 55,
    maxSizeDiameterMm: 85,
    expectedOilAbsorptionPercent: 29.5,
    fryingSuitability: 'PREMIUM'
  }
];

export const FARMS: Farm[] = [
  {
    id: 'FARM-01',
    name: 'Norfolk Fenland Estates',
    growerName: 'Arthur Pendelton & Sons',
    region: 'East Anglia, UK',
    totalAcreage: 1450,
    soilType: 'Silt / Peat Loam',
    irrigationMethod: 'Drip & Overhead Boom',
    sustainabilityRating: 'A+',
    activeContracts: 4
  },
  {
    id: 'FARM-02',
    name: 'Lincolnshire Wolds Agri',
    growerName: 'Sarah Jenkins',
    region: 'Lincolnshire, UK',
    totalAcreage: 2200,
    soilType: 'Chalky Boulder Clay',
    irrigationMethod: 'Central Pivot',
    sustainabilityRating: 'A',
    activeContracts: 6
  },
  {
    id: 'FARM-03',
    name: 'Perthshire Highland Farms',
    growerName: 'Duncan MacLeod',
    region: 'Perthshire, Scotland',
    totalAcreage: 980,
    soilType: 'Sandy Loam',
    irrigationMethod: 'Gun Sprinkler',
    sustainabilityRating: 'B+',
    activeContracts: 3
  }
];

export const FIELDS: Field[] = [
  {
    id: 'FIELD-N102',
    farmId: 'FARM-01',
    fieldName: 'Fen Edge Field 2B',
    acreage: 180,
    variety: 'Lady Rosetta',
    plantingDate: '2026-04-12',
    expectedHarvestDate: '2026-08-25',
    estimatedYieldTonnes: 820,
    soilMoisturePercent: 68,
    healthStatus: 'OPTIMAL'
  },
  {
    id: 'FIELD-L405',
    farmId: 'FARM-02',
    fieldName: 'Wolds Hill Top 5A',
    acreage: 240,
    variety: 'Atlantic',
    plantingDate: '2026-04-18',
    expectedHarvestDate: '2026-08-30',
    estimatedYieldTonnes: 1100,
    soilMoisturePercent: 62,
    healthStatus: 'OPTIMAL'
  },
  {
    id: 'FIELD-P801',
    farmId: 'FARM-03',
    fieldName: 'Glen Tay Valley 1',
    acreage: 120,
    variety: 'Taurus',
    plantingDate: '2026-05-02',
    expectedHarvestDate: '2026-09-10',
    estimatedYieldTonnes: 540,
    soilMoisturePercent: 74,
    healthStatus: 'WATCH'
  }
];

export const INITIAL_POTATO_LOTS: PotatoLot[] = [
  {
    id: 'LOT-P2026-0816-01',
    lotNumber: 'P2026-0816-01',
    farmId: 'FARM-01',
    farmName: 'Norfolk Fenland Estates',
    growerName: 'Arthur Pendelton & Sons',
    fieldId: 'FIELD-N102',
    variety: 'Lady Rosetta',
    harvestDate: '2026-08-14',
    grossWeightTonnes: 32.4,
    netWeightTonnes: 29.8,
    dryMatterPercent: 23.8,
    specificGravity: 1.091,
    reducingSugarsPercent: 0.08,
    defectsPercent: 1.4,
    foreignMaterialPercent: 0.2,
    dirtStonesPercent: 3.2,
    temperatureCelsius: 9.4,
    fryingSuitability: 'PREMIUM',
    status: 'IN_PROCESSING',
    assignedStorageBin: 'CELL-A1',
    qualityScore: 96,
    costPerRawTonne: 195,
    calculatedCostPerFinishedTonne: 612
  },
  {
    id: 'LOT-P2026-0815-02',
    lotNumber: 'P2026-0815-02',
    farmId: 'FARM-02',
    farmName: 'Lincolnshire Wolds Agri',
    growerName: 'Sarah Jenkins',
    fieldId: 'FIELD-L405',
    variety: 'Atlantic',
    harvestDate: '2026-08-15',
    grossWeightTonnes: 45.0,
    netWeightTonnes: 41.2,
    dryMatterPercent: 22.4,
    specificGravity: 1.086,
    reducingSugarsPercent: 0.11,
    defectsPercent: 2.1,
    foreignMaterialPercent: 0.3,
    dirtStonesPercent: 4.1,
    temperatureCelsius: 10.2,
    fryingSuitability: 'PREMIUM',
    status: 'STORED',
    assignedStorageBin: 'CELL-A2',
    qualityScore: 92,
    costPerRawTonne: 185,
    calculatedCostPerFinishedTonne: 598
  },
  {
    id: 'LOT-P2026-0813-03',
    lotNumber: 'P2026-0813-03',
    farmId: 'FARM-03',
    farmName: 'Perthshire Highland Farms',
    growerName: 'Duncan MacLeod',
    fieldId: 'FIELD-P801',
    variety: 'Taurus',
    harvestDate: '2026-08-12',
    grossWeightTonnes: 28.5,
    netWeightTonnes: 26.1,
    dryMatterPercent: 24.2,
    specificGravity: 1.093,
    reducingSugarsPercent: 0.06,
    defectsPercent: 0.9,
    foreignMaterialPercent: 0.1,
    dirtStonesPercent: 2.8,
    temperatureCelsius: 8.8,
    fryingSuitability: 'PREMIUM',
    status: 'STORED',
    assignedStorageBin: 'CELL-A3',
    qualityScore: 98,
    costPerRawTonne: 210,
    calculatedCostPerFinishedTonne: 630
  }
];

export const STORAGE_BINS: StorageBin[] = [
  {
    id: 'CELL-A1',
    code: 'CELL-A1',
    capacityTonnes: 150,
    currentLotId: 'LOT-P2026-0816-01',
    currentLotNumber: 'P2026-0816-01',
    currentWeightTonnes: 29.8,
    temperatureCelsius: 8.5,
    targetTempCelsius: 8.5,
    humidityPercent: 95,
    co2Ppm: 1100,
    ventilationStatus: 'ACTIVE',
    spoilageRiskScore: 4,
    storageDays: 2
  },
  {
    id: 'CELL-A2',
    code: 'CELL-A2',
    capacityTonnes: 150,
    currentLotId: 'LOT-P2026-0815-02',
    currentLotNumber: 'P2026-0815-02',
    currentWeightTonnes: 41.2,
    temperatureCelsius: 8.8,
    targetTempCelsius: 8.5,
    humidityPercent: 94,
    co2Ppm: 1250,
    ventilationStatus: 'COOLING',
    spoilageRiskScore: 8,
    storageDays: 1
  },
  {
    id: 'CELL-A3',
    code: 'CELL-A3',
    capacityTonnes: 150,
    currentLotId: 'LOT-P2026-0813-03',
    currentLotNumber: 'P2026-0813-03',
    currentWeightTonnes: 26.1,
    temperatureCelsius: 8.2,
    targetTempCelsius: 8.5,
    humidityPercent: 96,
    co2Ppm: 980,
    ventilationStatus: 'ACTIVE',
    spoilageRiskScore: 2,
    storageDays: 4
  },
  {
    id: 'CELL-A4',
    code: 'CELL-A4',
    capacityTonnes: 150,
    currentLotId: undefined,
    currentLotNumber: undefined,
    currentWeightTonnes: 0,
    temperatureCelsius: 8.5,
    targetTempCelsius: 8.5,
    humidityPercent: 95,
    co2Ppm: 800,
    ventilationStatus: 'IDLE',
    spoilageRiskScore: 0,
    storageDays: 0
  }
];

export const RECIPES: ProductRecipe[] = [
  {
    sku: 'CRISP-SAL-150G',
    name: 'Hand-Cooked Sea Salt Crisps 150g',
    flavor: 'Classic Sea Salt',
    cutType: 'Kettle Thick Hand-Cooked',
    targetSliceThicknessMm: 1.45,
    targetMoisturePercent: 1.35,
    targetOilPercent: 31.5,
    seasoningDosingPercent: 1.8,
    fryingTemperatureCelsius: 168.0,
    fryingResidenceTimeSeconds: 210,
    packSizeGrams: 150,
    targetBagWeightGrams: 151.5,
    allowableUnderweightGrams: 1.5,
    allowableOverweightGrams: 3.5,
    nitrogenFlushTargetPercent: 97.5
  },
  {
    sku: 'CRISP-VIN-150G',
    name: 'Sea Salt & Malt Vinegar Crisps 150g',
    flavor: 'Malt Vinegar & Sea Salt',
    cutType: 'Kettle Thick Hand-Cooked',
    targetSliceThicknessMm: 1.45,
    targetMoisturePercent: 1.30,
    targetOilPercent: 32.0,
    seasoningDosingPercent: 6.2,
    fryingTemperatureCelsius: 168.0,
    fryingResidenceTimeSeconds: 210,
    packSizeGrams: 150,
    targetBagWeightGrams: 151.8,
    allowableUnderweightGrams: 1.5,
    allowableOverweightGrams: 3.5,
    nitrogenFlushTargetPercent: 97.5
  },
  {
    sku: 'CRISP-CHD-150G',
    name: 'Mature Cheddar & Onion Crisps 150g',
    flavor: 'Mature Cheddar & Onion',
    cutType: 'V-Cut Ridge',
    targetSliceThicknessMm: 1.30,
    targetMoisturePercent: 1.40,
    targetOilPercent: 33.0,
    seasoningDosingPercent: 7.5,
    fryingTemperatureCelsius: 174.0,
    fryingResidenceTimeSeconds: 185,
    packSizeGrams: 150,
    targetBagWeightGrams: 151.5,
    allowableUnderweightGrams: 1.5,
    allowableOverweightGrams: 3.5,
    nitrogenFlushTargetPercent: 97.0
  }
];

export const FRYING_OIL_BATCHES: FryingOilBatch[] = [
  {
    id: 'OIL-2026-B812',
    supplier: 'Cargill Refined Oils',
    oilType: 'High Oleic Sunflower',
    lotNumber: 'HOS-99428',
    volumeLitres: 12000,
    currentFfaPercent: 0.38,
    currentTpcPercent: 11.4,
    peroxideValueMeq: 2.1,
    usageHours: 42,
    filtrationCyclesCompleted: 14,
    temperatureCelsius: 168.0,
    status: 'OPTIMAL'
  },
  {
    id: 'OIL-2026-B813',
    supplier: 'ADM Food Oils',
    oilType: 'Pure Rapeseed Oil',
    lotNumber: 'PRO-11029',
    volumeLitres: 8500,
    currentFfaPercent: 0.65,
    currentTpcPercent: 16.8,
    peroxideValueMeq: 4.2,
    usageHours: 88,
    filtrationCyclesCompleted: 29,
    temperatureCelsius: 174.0,
    status: 'OPTIMAL'
  }
];

export const PRODUCTION_LINES: ProductionLine[] = [
  {
    id: 'LINE-01',
    name: 'Line 1 - Kettle Hand-Cooked',
    type: 'KETTLE',
    status: 'RUNNING',
    currentBatchId: 'BAT-20260816-01',
    currentSku: 'CRISP-SAL-150G',
    throughputKgPerHour: 1850,
    fryerTemperatureCelsius: 168.2,
    slicerSpeedRpm: 1420,
    seasoningRatePercent: 1.82,
    packagingPacksPerMin: 128,
    oeePercent: 88.4,
    availabilityPercent: 94.2,
    performancePercent: 96.1,
    qualityPercent: 97.6,
    currentYieldPercent: 82.4
  },
  {
    id: 'LINE-02',
    name: 'Line 2 - Continuous Ridge & Thin Cut',
    type: 'CONTINUOUS',
    status: 'RUNNING',
    currentBatchId: 'BAT-20260816-02',
    currentSku: 'CRISP-CHD-150G',
    throughputKgPerHour: 2800,
    fryerTemperatureCelsius: 174.1,
    slicerSpeedRpm: 1850,
    seasoningRatePercent: 7.48,
    packagingPacksPerMin: 184,
    oeePercent: 91.2,
    availabilityPercent: 96.0,
    performancePercent: 97.2,
    qualityPercent: 97.9,
    currentYieldPercent: 84.1
  }
];

export const INITIAL_BATCHES: ProductionBatch[] = [
  {
    id: 'BAT-20260816-01',
    batchNumber: 'BAT-20260816-01',
    lineId: 'LINE-01',
    sku: 'CRISP-SAL-150G',
    productName: 'Hand-Cooked Sea Salt Crisps 150g',
    potatoLotId: 'LOT-P2026-0816-01',
    potatoLotNumber: 'P2026-0816-01',
    oilBatchId: 'OIL-2026-B812',
    seasoningBatchLot: 'SEASON-SALT-9901',
    plannedQuantityPacks: 25000,
    completedQuantityPacks: 14850,
    wasteKg: 142,
    startTime: '2026-08-16T06:00:00Z',
    estimatedEndTime: '2026-08-16T14:00:00Z',
    status: 'IN_PROGRESS',
    ccpStatus: 'PASS',
    goldenTicketsIssuedCount: 14850
  },
  {
    id: 'BAT-20260816-02',
    batchNumber: 'BAT-20260816-02',
    lineId: 'LINE-02',
    sku: 'CRISP-CHD-150G',
    productName: 'Mature Cheddar & Onion Crisps 150g',
    potatoLotId: 'LOT-P2026-0815-02',
    potatoLotNumber: 'P2026-0815-02',
    oilBatchId: 'OIL-2026-B813',
    seasoningBatchLot: 'SEASON-CHD-4412',
    plannedQuantityPacks: 40000,
    completedQuantityPacks: 22100,
    wasteKg: 210,
    startTime: '2026-08-16T05:30:00Z',
    estimatedEndTime: '2026-08-16T15:00:00Z',
    status: 'IN_PROGRESS',
    ccpStatus: 'PASS',
    goldenTicketsIssuedCount: 22100
  }
];

export const CAMPAIGNS: GoldenTicketCampaign[] = [
  {
    id: 'CAMP-SUMMER-2026',
    name: 'CRISPOS Golden Ticket Summer Extravaganza',
    status: 'ACTIVE',
    startDate: '2026-06-01',
    endDate: '2026-09-30',
    totalTicketsGenerated: 1500000,
    totalRedeemed: 123421,
    prizePoolGbp: 250000,
    grandPrizeClaimed: false,
    tier1Count: 1, // £100,000
    tier2Count: 20, // £2,500
    tier3Count: 500, // £100
    tier4Count: 10000 // £10
  }
];

export const INITIAL_CCP_LOGS: CcpLog[] = [
  {
    id: 'CCP-LOG-001',
    timestamp: '2026-08-16T06:15:00Z',
    ccpNumber: 'CCP-1 (Metal Detector)',
    lineId: 'LINE-01',
    batchNumber: 'BAT-20260816-01',
    measuredValue: 'FE 1.2mm, NFE 1.5mm, SS 2.0mm Test Wand Detected',
    criticalLimit: 'Zero Metal Contamination > 1.0mm',
    status: 'COMPLIANT',
    operatorName: 'J. Miller (QA Shift Lead)'
  },
  {
    id: 'CCP-LOG-002',
    timestamp: '2026-08-16T06:30:00Z',
    ccpNumber: 'CCP-2 (Optical Sorter)',
    lineId: 'LINE-01',
    batchNumber: 'BAT-20260816-01',
    measuredValue: 'Air Jet Ejection Sensitivity 99.4%, Dark Blotch Threshold 3.2mm²',
    criticalLimit: '< 0.5% Off-Spec Defect Rate',
    status: 'COMPLIANT',
    operatorName: 'J. Miller (QA Shift Lead)'
  },
  {
    id: 'CCP-LOG-003',
    timestamp: '2026-08-16T06:45:00Z',
    ccpNumber: 'CCP-3 (MAP Seal Integrity)',
    lineId: 'LINE-01',
    batchNumber: 'BAT-20260816-01',
    measuredValue: 'Residual Oxygen: 1.2% O₂, Nitrogen Purge: 98.8% N₂',
    criticalLimit: 'Residual O₂ < 2.0%',
    status: 'COMPLIANT',
    operatorName: 'R. Chen (Packaging Supervisor)'
  }
];

export const INITIAL_VISION_EVENTS: OpticalInspectionEvent[] = [
  {
    id: 'VIS-9012',
    timestamp: '2026-08-16T06:42:10Z',
    lineId: 'LINE-01',
    batchNumber: 'BAT-20260816-01',
    defectType: 'BURNT_EDGE',
    severity: 'MINOR',
    confidenceScore: 0.98,
    actionTaken: 'EJECTED_AIR_JET'
  },
  {
    id: 'VIS-9013',
    timestamp: '2026-08-16T06:44:35Z',
    lineId: 'LINE-01',
    batchNumber: 'BAT-20260816-01',
    defectType: 'GREEN_SPOT',
    severity: 'MINOR',
    confidenceScore: 0.95,
    actionTaken: 'EJECTED_AIR_JET'
  },
  {
    id: 'VIS-9014',
    timestamp: '2026-08-16T06:46:02Z',
    lineId: 'LINE-02',
    batchNumber: 'BAT-20260816-02',
    defectType: 'SEASONING_CLUMP',
    severity: 'MAJOR',
    confidenceScore: 0.92,
    actionTaken: 'EJECTED_AIR_JET'
  }
];
