// CRISPOS Domain Type Definitions

export type PotatoVarietyName = 'Lady Rosetta' | 'Hermes' | 'Atlantic' | 'Innovator' | 'Markies' | 'Taurus';

export interface PotatoSpecification {
  variety: PotatoVarietyName;
  targetDryMatterMin: number; // e.g. 21.0%
  targetDryMatterMax: number; // e.g. 24.5%
  targetSpecificGravityMin: number; // e.g. 1.080
  targetSpecificGravityMax: number; // e.g. 1.095
  maxReducingSugars: number; // e.g. 0.15%
  maxDefectPercent: number; // e.g. 3.0%
  minSizeDiameterMm: number; // e.g. 45mm
  maxSizeDiameterMm: number; // e.g. 85mm
  expectedOilAbsorptionPercent: number; // e.g. 32.5%
  fryingSuitability: 'PREMIUM' | 'HIGH' | 'MODERATE' | 'UNSUITABLE';
}

export interface Farm {
  id: string;
  name: string;
  growerName: string;
  region: string;
  totalAcreage: number;
  soilType: string;
  irrigationMethod: string;
  sustainabilityRating: string;
  activeContracts: number;
}

export interface Field {
  id: string;
  farmId: string;
  fieldName: string;
  acreage: number;
  variety: PotatoVarietyName;
  plantingDate: string;
  expectedHarvestDate: string;
  estimatedYieldTonnes: number;
  soilMoisturePercent: number;
  healthStatus: 'OPTIMAL' | 'WATCH' | 'WARNING';
}

export interface PotatoLot {
  id: string;
  lotNumber: string; // e.g. "LOT-P2026-0816"
  farmId: string;
  farmName: string;
  growerName: string;
  fieldId: string;
  variety: PotatoVarietyName;
  harvestDate: string;
  grossWeightTonnes: number;
  netWeightTonnes: number;
  dryMatterPercent: number;
  specificGravity: number;
  reducingSugarsPercent: number;
  defectsPercent: number;
  foreignMaterialPercent: number;
  dirtStonesPercent: number;
  temperatureCelsius: number;
  fryingSuitability: 'PREMIUM' | 'HIGH' | 'MODERATE' | 'REJECTED';
  status: 'IN_TRANSIT' | 'RECEIVING' | 'QUARANTINE' | 'STORED' | 'IN_PROCESSING' | 'CONSUMED' | 'REJECTED';
  assignedStorageBin?: string;
  qualityScore: number; // 0 - 100
  costPerRawTonne: number; // GBP/tonne
  calculatedCostPerFinishedTonne: number; // GBP/tonne taking yields into account
}

export interface StorageBin {
  id: string;
  code: string; // e.g. "CELL-A4"
  capacityTonnes: number;
  currentLotId?: string;
  currentLotNumber?: string;
  currentWeightTonnes: number;
  temperatureCelsius: number;
  targetTempCelsius: number;
  humidityPercent: number;
  co2Ppm: number;
  ventilationStatus: 'ACTIVE' | 'IDLE' | 'HEATING' | 'COOLING';
  spoilageRiskScore: number; // 0 - 100
  storageDays: number;
}

export type CrispFlavor = 'Classic Sea Salt' | 'Malt Vinegar & Sea Salt' | 'Mature Cheddar & Onion' | 'Flame Grilled BBQ' | 'Sweet Chilli' | 'Smoked Paprika';

export interface ProductRecipe {
  sku: string;
  name: string;
  flavor: CrispFlavor;
  cutType: 'Flat Cut' | 'V-Cut Ridge' | 'Kettle Thick Hand-Cooked';
  targetSliceThicknessMm: number;
  targetMoisturePercent: number;
  targetOilPercent: number;
  seasoningDosingPercent: number;
  fryingTemperatureCelsius: number;
  fryingResidenceTimeSeconds: number;
  packSizeGrams: number;
  targetBagWeightGrams: number;
  allowableUnderweightGrams: number;
  allowableOverweightGrams: number;
  nitrogenFlushTargetPercent: number;
}

export interface FryingOilBatch {
  id: string;
  supplier: string;
  oilType: 'High Oleic Sunflower' | 'Refined Peanut Oil' | 'Pure Rapeseed Oil';
  lotNumber: string;
  volumeLitres: number;
  currentFfaPercent: number; // Free Fatty Acids (Limit e.g. 1.0%)
  currentTpcPercent: number; // Total Polar Compounds (Limit e.g. 24%)
  peroxideValueMeq: number;
  usageHours: number;
  filtrationCyclesCompleted: number;
  temperatureCelsius: number;
  status: 'FRESH' | 'OPTIMAL' | 'DEGRADING' | 'REPLENISH_REQUIRED' | 'DISCARD';
}

export interface ProductionLine {
  id: string;
  name: string; // e.g. "Line 1 - Kettle Chips"
  type: 'KETTLE' | 'CONTINUOUS';
  status: 'RUNNING' | 'CHANGE_OVER' | 'MAINTENANCE' | 'IDLE' | 'ALERT';
  currentBatchId?: string;
  currentSku?: string;
  throughputKgPerHour: number;
  fryerTemperatureCelsius: number;
  slicerSpeedRpm: number;
  seasoningRatePercent: number;
  packagingPacksPerMin: number;
  oeePercent: number;
  availabilityPercent: number;
  performancePercent: number;
  qualityPercent: number;
  currentYieldPercent: number;
}

export interface ProductionBatch {
  id: string;
  batchNumber: string; // e.g. "BAT-20260816-01"
  lineId: string;
  sku: string;
  productName: string;
  potatoLotId: string;
  potatoLotNumber: string;
  oilBatchId: string;
  seasoningBatchLot: string;
  plannedQuantityPacks: number;
  completedQuantityPacks: number;
  wasteKg: number;
  startTime: string;
  estimatedEndTime: string;
  status: 'PLANNED' | 'IN_PROGRESS' | 'COMPLETED' | 'HALTED';
  ccpStatus: 'PASS' | 'WARNING' | 'FAIL';
  goldenTicketsIssuedCount: number;
}

export interface OpticalInspectionEvent {
  id: string;
  timestamp: string;
  lineId: string;
  batchNumber: string;
  defectType: 'BURNT_EDGE' | 'GREEN_SPOT' | 'DARK_SUGAR_BLOTCH' | 'BROKEN_CRISP' | 'SEASONING_CLUMP' | 'FOREIGN_OBJECT';
  severity: 'MINOR' | 'MAJOR' | 'CRITICAL';
  confidenceScore: number; // 0.00 - 1.00
  imageUrl?: string;
  actionTaken: 'EJECTED_AIR_JET' | 'FLAGGED_OPERATOR' | 'LINE_SLOWED';
}

export interface CcpLog {
  id: string;
  timestamp: string;
  ccpNumber: 'CCP-1 (Metal Detector)' | 'CCP-2 (Optical Sorter)' | 'CCP-3 (MAP Seal Integrity)';
  lineId: string;
  batchNumber: string;
  measuredValue: string;
  criticalLimit: string;
  status: 'COMPLIANT' | 'NON_CONFORMANCE' | 'ACTION_REQUIRED';
  operatorName: string;
}

export interface TraceabilityNode {
  type: 'FARM' | 'FIELD' | 'HARVEST_LOT' | 'STORAGE_BIN' | 'FRYING_BATCH' | 'SKU_PACK' | 'PALLET' | 'GOLDEN_TICKET';
  id: string;
  label: string;
  details: Record<string, string | number>;
  children?: TraceabilityNode[];
}

export interface GoldenTicketCampaign {
  id: string;
  name: string;
  status: 'ACTIVE' | 'PAUSED' | 'COMPLETED';
  startDate: string;
  endDate: string;
  totalTicketsGenerated: number;
  totalRedeemed: number;
  prizePoolGbp: number;
  grandPrizeClaimed: boolean;
  tier1Count: number; // £100,000
  tier2Count: number; // £2,500
  tier3Count: number; // £100
  tier4Count: number; // £10
}

export interface GoldenTicket {
  id: string;
  tokenHmac: string; // HMAC-SHA256 signature token
  campaignId: string;
  batchNumber: string;
  sku: string;
  prizeClass: 'GRAND_PRIZE_100K' | 'TIER_2_2500' | 'TIER_3_100' | 'TIER_4_10' | 'THANK_YOU_TRY_AGAIN';
  prizeAmountGbp: number;
  isWinner: boolean;
  isRedeemed: boolean;
  redemptionTimestamp?: string;
  redeemedByLocation?: string;
  blockchainTxHash?: string;
}

export interface GoldenTicketRedemptionResult {
  tokenHmac: string;
  isValid: boolean;
  status: 'SUCCESS_WINNER' | 'SUCCESS_NON_WINNER' | 'ALREADY_REDEEMED' | 'INVALID_TOKEN' | 'FRAUD_SUSPECTED';
  ticketDetails?: GoldenTicket;
  message: string;
  txHash?: string;
  fraudRiskScore: number; // 0 - 100
  geoAnomalyDetected: boolean;
}

export interface RScriptExecutionRequest {
  modelType: 'CROP_YIELD_REGRESSION' | 'OIL_DEGRADATION_KINETICS' | 'SHEWHART_SPC_CHARTS' | 'DEMAND_ARIMA_FORECAST' | 'PREDICTIVE_MAINTENANCE_HAZARD' | 'GOLDEN_TICKET_FRAUD_CLUSTERS';
  parameters: Record<string, any>;
}

export interface RScriptExecutionResult {
  modelType: string;
  executedAt: string;
  rVersionInfo: string;
  summaryText: string;
  chartData: any[];
  metrics: Record<string, number | string>;
  codeSnippet: string;
}

export interface VerticalSliceSimulationStep {
  stepIndex: number;
  title: string;
  description: string;
  domain: 'AGRICULTURE' | 'RECEIVING' | 'MES_FRYING' | 'PACKAGING' | 'GOLDEN_TICKET' | 'LEDGER' | 'R_ANALYTICS';
  payload: any;
}
