import React, { useState } from 'react';
import {
  Factory,
  Flame,
  Activity,
  Sliders,
  CheckCircle,
  AlertCircle,
  Clock,
  Zap,
  Layers,
  ArrowRight
} from 'lucide-react';
import { ProductionLine, ProductionBatch } from '../../types';

interface FactoryMesModuleProps {
  lines: ProductionLine[];
  batches: ProductionBatch[];
}

export const FactoryMesModule: React.FC<FactoryMesModuleProps> = ({
  lines,
  batches
}) => {
  const [selectedLineId, setSelectedLineId] = useState<string>('LINE-01');
  const [fryerTemp, setFryerTemp] = useState<number>(168.2);
  const [slicerSpeed, setSlicerSpeed] = useState<number>(1420);
  const [seasoningRate, setSeasoningRate] = useState<number>(1.82);
  const [nitrogenFlush, setNitrogenFlush] = useState<number>(98.2);

  const selectedLine = lines.find(l => l.id === selectedLineId) || lines[0];
  const activeBatch = batches.find(b => b.lineId === selectedLineId) || batches[0];

  const processStages = [
    { name: '1. Washing', status: 'Optimal', metric: 'Flow: 45 m³/h' },
    { name: '2. Sorting', status: 'Optimal', metric: 'Size: 55-85mm' },
    { name: '3. Peeling', status: 'Optimal', metric: 'Waste: 6.2%' },
    { name: '4. Slicing', status: 'Active', metric: `${slicerSpeed} RPM` },
    { name: '5. Starch Wash', status: 'Optimal', metric: 'Recov: 98%' },
    { name: '6. Dewatering', status: 'Optimal', metric: 'Air Knife 4.2 bar' },
    { name: '7. Frying', status: 'Critical', metric: `${fryerTemp} °C` },
    { name: '8. De-oiling', status: 'Optimal', metric: 'Drain: 2.1s' },
    { name: '9. Seasoning', status: 'Active', metric: `${seasoningRate}% Dose` },
    { name: '10. Optical Sort', status: 'Optimal', metric: 'Ejection: 99.4%' },
    { name: '11. Weigher', status: 'Optimal', metric: 'Target 150.0g' },
    { name: '12. MAP Pack', status: 'Active', metric: `${nitrogenFlush}% N₂` },
  ];

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <Factory className="w-4 h-4" />
            <span>Manufacturing Execution System (MES)</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Factory Digital Twin & Multi-Stage Frying Line SCADA
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time telemetry and parameter control from Raw Washing to Continuous Kettle Frying, Optical Defect Ejection, and Nitrogen MAP Form-Fill-Seal Packaging.
          </p>
        </div>

        {/* Line Selector */}
        <div className="flex items-center gap-2 font-mono text-xs">
          {lines.map(line => (
            <button
              key={line.id}
              onClick={() => setSelectedLineId(line.id)}
              className={`px-3 py-2 rounded-lg font-bold border transition-all ${
                selectedLineId === line.id
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-md'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:bg-slate-700'
              }`}
            >
              {line.name}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Process Pipeline Steps */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>12-Stage Manufacturing Pipeline Digital Twin</span>
          <span className="text-xs font-mono text-emerald-400 font-normal">All 12 SCADA Nodes Synchronized</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-2">
          {processStages.map((stage, idx) => (
            <div
              key={stage.name}
              className="p-3 bg-slate-800/60 border border-slate-700/60 rounded-lg space-y-1 font-mono text-xs relative hover:border-amber-500/50 transition-all"
            >
              <div className="text-[10px] text-slate-400 truncate">{stage.name}</div>
              <div className="font-bold text-white text-[11px]">{stage.metric}</div>
              <div className="flex items-center gap-1 text-[9px] text-emerald-400 pt-1 border-t border-slate-700/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span>{stage.status}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Batch & SCADA Live Controls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Active Production Batch Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Active Production Batch</h3>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
              {activeBatch.status}
            </span>
          </div>

          <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 space-y-2 text-xs">
            <div>
              <span className="text-slate-400 text-[10px] block">BATCH NUMBER</span>
              <span className="text-lg font-bold text-amber-400">{activeBatch.batchNumber}</span>
            </div>

            <div>
              <span className="text-slate-400 text-[10px] block">SKU / PRODUCT</span>
              <span className="text-white font-bold">{activeBatch.productName}</span>
            </div>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-700 text-[11px]">
              <div>
                <span className="text-slate-500 block text-[9px]">POTATO LOT</span>
                <span className="text-sky-400 font-bold">{activeBatch.potatoLotNumber}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[9px]">OIL LOT</span>
                <span className="text-purple-400 font-bold">{activeBatch.oilBatchId}</span>
              </div>
            </div>

            <div className="pt-2">
              <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                <span>Batch Progress:</span>
                <span className="text-emerald-400 font-bold">
                  {activeBatch.completedQuantityPacks} / {activeBatch.plannedQuantityPacks} packs
                </span>
              </div>
              <div className="w-full bg-slate-700 h-2 rounded-full overflow-hidden">
                <div
                  className="bg-amber-500 h-full rounded-full"
                  style={{
                    width: `${(activeBatch.completedQuantityPacks / activeBatch.plannedQuantityPacks) * 100}%`
                  }}
                ></div>
              </div>
            </div>
          </div>

          <div className="p-3 bg-amber-950/20 border border-amber-800/40 rounded-lg text-[11px] text-amber-300 flex items-center justify-between">
            <span>Golden Ticket HMAC Tokens Printed:</span>
            <span className="font-bold">{activeBatch.goldenTicketsIssuedCount}</span>
          </div>
        </div>

        {/* SCADA Live Parameter Tuner */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white">SCADA Process Parameter Tuner</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
            
            {/* Fryer Temp Slider */}
            <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span className="flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span>Fryer Zone 1 Temp (°C)</span>
                </span>
                <span className="font-bold text-amber-400">{fryerTemp} °C</span>
              </div>
              <input
                type="range"
                min="160"
                max="182"
                step="0.1"
                value={fryerTemp}
                onChange={e => setFryerTemp(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
              <span className="text-[10px] text-slate-400 block">Target: 168.0°C (Kettle Curve)</span>
            </div>

            {/* Slicer Speed Slider */}
            <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Rotary Slicer Speed (RPM)</span>
                <span className="font-bold text-sky-400">{slicerSpeed} RPM</span>
              </div>
              <input
                type="range"
                min="1000"
                max="2200"
                step="10"
                value={slicerSpeed}
                onChange={e => setSlicerSpeed(Number(e.target.value))}
                className="w-full accent-sky-500"
              />
              <span className="text-[10px] text-slate-400 block">Slice thickness: 1.45mm &plusmn; 0.05</span>
            </div>

            {/* Seasoning Dosing Slider */}
            <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Seasoning Drum Dose (%)</span>
                <span className="font-bold text-purple-400">{seasoningRate}%</span>
              </div>
              <input
                type="range"
                min="1.0"
                max="8.0"
                step="0.05"
                value={seasoningRate}
                onChange={e => setSeasoningRate(Number(e.target.value))}
                className="w-full accent-purple-500"
              />
              <span className="text-[10px] text-slate-400 block">Electrostatic dispersion active</span>
            </div>

            {/* Nitrogen Flush MAP Slider */}
            <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700 space-y-2">
              <div className="flex justify-between text-slate-300">
                <span>Nitrogen MAP Purge (%)</span>
                <span className="font-bold text-emerald-400">{nitrogenFlush}% N₂</span>
              </div>
              <input
                type="range"
                min="92"
                max="99.5"
                step="0.1"
                value={nitrogenFlush}
                onChange={e => setNitrogenFlush(Number(e.target.value))}
                className="w-full accent-emerald-500"
              />
              <span className="text-[10px] text-slate-400 block">Residual Oxygen: {(100 - nitrogenFlush).toFixed(1)}%</span>
            </div>

          </div>

          <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700 flex flex-col sm:flex-row items-center justify-between gap-3 font-mono text-xs">
            <div className="flex items-center gap-2 text-emerald-400">
              <CheckCircle className="w-4 h-4" />
              <span>Automated Closed-Loop Process Stability Index: 98.4%</span>
            </div>
            <span className="text-[10px] text-slate-400">Next Scheduled Maintenance in 142 hrs</span>
          </div>
        </div>

      </div>

    </div>
  );
};
