import React, { useState } from 'react';
import {
  Workflow,
  PlayCircle,
  CheckCircle2,
  Sprout,
  Truck,
  Factory,
  PackageCheck,
  Ticket,
  Award,
  BarChart2,
  Zap,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { runVerticalSliceSimulation } from '../../services/api';

export const VerticalSliceSimulator: React.FC = () => {
  const [currentStep, setCurrentStep] = useState<number>(0);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [simResult, setSimResult] = useState<any>(null);

  const steps = [
    { title: '1. Agricultural Harvesting', icon: Sprout, desc: 'Grower Norfolk Fenland Estates harvests Field N102 Lady Rosetta potatoes.' },
    { title: '2. Weighbridge & Quality Test', icon: Truck, desc: 'Core sample dry matter 23.9%, specific gravity 1.092, reducing sugars 0.07% (PREMIUM GRADE).' },
    { title: '3. Kettle Frying MES', icon: Factory, desc: 'Sliced to 1.45mm thickness, fried at 168.0°C in High Oleic Sunflower oil.' },
    { title: '4. Optical Sort & MAP Packaging', icon: PackageCheck, desc: 'Optical vision camera ejects 0.2% burnt edges; Nitrogen flush purges oxygen to 1.2% O₂.' },
    { title: '5. Cryptographic Golden Ticket', icon: Ticket, desc: 'Unique HMAC-SHA256 signed token printed inside crisp bag.' },
    { title: '6. Consumer Scan & Ledger Event', icon: Award, desc: 'Consumer scans QR code. Cryptographic verification confirms £100 winner & commits ledger block.' },
    { title: '7. R Statistical Intelligence', icon: BarChart2, desc: 'R engine recalculates Shewhart Cpk (1.65) and updates ARIMA demand forecasts.' },
  ];

  const handleStartSimulation = async () => {
    setIsRunning(true);
    setCurrentStep(1);
    setSimResult(null);

    for (let i = 1; i <= 7; i++) {
      setCurrentStep(i);
      await new Promise(resolve => setTimeout(resolve, 800));
    }

    try {
      const res = await runVerticalSliceSimulation();
      setSimResult(res.simulatedEntities);
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
    } catch (err) {
      console.error(err);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <Workflow className="w-4 h-4" />
            <span>End-to-End Vertical Slice Simulator</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Farm-to-Consumer Digital Operating System Lifecycle
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Trace a single batch of potatoes from farm harvest, through receiving quality tests, kettle frying, optical sorting, MAP packaging, cryptographic Golden Ticket issuance, consumer scanning, and R analytics update.
          </p>
        </div>

        <button
          onClick={handleStartSimulation}
          disabled={isRunning}
          className="px-5 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2 font-mono shrink-0"
        >
          {isRunning ? (
            <>
              <Zap className="w-4 h-4 animate-spin text-slate-950" />
              <span>Simulating Step {currentStep}/7...</span>
            </>
          ) : (
            <>
              <PlayCircle className="w-4 h-4" />
              <span>Execute 1-Click Vertical Slice</span>
            </>
          )}
        </button>
      </div>

      {/* Stepper Progress Bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>Simulation Stepper Execution Flow</span>
          <span className="text-amber-400 font-normal">Step {currentStep} of 7</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2">
          {steps.map((st, idx) => {
            const stepNum = idx + 1;
            const Icon = st.icon;
            const isDone = currentStep > stepNum || (currentStep === 7 && !isRunning && simResult);
            const isCurrent = currentStep === stepNum && isRunning;

            return (
              <div
                key={st.title}
                className={`p-3 rounded-lg border transition-all ${
                  isCurrent
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold scale-105 shadow-md'
                    : isDone
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300 font-semibold'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-500'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <Icon className={`w-4 h-4 ${isCurrent ? 'text-amber-400 animate-pulse' : isDone ? 'text-emerald-400' : 'text-slate-500'}`} />
                  {isDone ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <span className="text-[10px] text-slate-500 font-bold">#0{stepNum}</span>
                  )}
                </div>
                <div className="font-bold text-[11px] truncate">{st.title}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Simulation Output Card */}
      {simResult && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              <span>Vertical Slice Execution Completed & Ledger Committed</span>
            </h3>
            <span className="text-slate-400 text-[10px]">{simResult.timestamp || new Date().toISOString()}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700">
              <span className="text-slate-400 text-[10px] block">PRODUCED BATCH NUMBER</span>
              <span className="text-base font-bold text-amber-400">{simResult.batchNumber}</span>
              <span className="text-[10px] text-slate-400 block mt-1">Potato Lot: {simResult.potatoLotNumber}</span>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700">
              <span className="text-slate-400 text-[10px] block">QUALITY CORE SAMPLE</span>
              <span className="text-base font-bold text-sky-400">{simResult.qualityResult.dryMatterPercent}% Dry Matter</span>
              <span className="text-[10px] text-emerald-400 block mt-1">Grade: {simResult.qualityResult.qualityGrade}</span>
            </div>

            <div className="p-3 bg-purple-950/40 border border-purple-800/60 rounded-lg">
              <span className="text-purple-300 text-[10px] block">GOLDEN TICKET TOKEN</span>
              <span className="text-base font-bold text-amber-300">{simResult.goldenTicketToken}</span>
              <span className="text-[10px] text-emerald-400 block mt-1">Winner: £{simResult.prizeAmount} Prize Claimed!</span>
            </div>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-[10px] text-slate-400 truncate">
            Immutable Blockchain Block Hash: <span className="text-purple-300 font-bold">{simResult.blockchainTxHash}</span>
          </div>
        </div>
      )}

    </div>
  );
};
