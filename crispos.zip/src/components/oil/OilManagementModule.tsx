import React from 'react';
import {
  Droplet,
  AlertTriangle,
  RefreshCw,
  Activity,
  ShieldCheck,
  Zap,
  TrendingUp
} from 'lucide-react';
import { FryingOilBatch } from '../../types';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, Legend } from 'recharts';

interface OilManagementModuleProps {
  oilBatches: FryingOilBatch[];
}

const degradationData = Array.from({ length: 11 }, (_, i) => {
  const hours = i * 10;
  const ffa = +(0.15 + 0.008 * hours + 0.00005 * Math.pow(hours, 2)).toFixed(2);
  const tpc = +(4.0 + 0.18 * hours + 0.001 * Math.pow(hours, 2)).toFixed(2);
  return { hours, ffa, tpc, ffaLimit: 1.0, tpcLimit: 24.0 };
});

export const OilManagementModule: React.FC<OilManagementModuleProps> = ({ oilBatches }) => {
  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-purple-400 text-xs font-mono font-bold uppercase">
            <Droplet className="w-4 h-4" />
            <span>Frying Cooking Oil Management</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Oil Health, Thermal Degradation & Filtration Systems
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Monitor Free Fatty Acids (FFA %), Total Polar Compounds (TPC %), continuous oil turnover rates, and R thermal degradation kinetic curves.
          </p>
        </div>
      </div>

      {/* Active Oil Batches Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 font-mono">
        {oilBatches.map(oil => (
          <div key={oil.id} className="p-5 bg-slate-900 border border-slate-800 rounded-xl space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs text-purple-400 font-bold block">{oil.oilType}</span>
                <span className="text-sm font-bold text-white">{oil.lotNumber} ({oil.supplier})</span>
              </div>
              <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 text-xs font-bold border border-emerald-500/30">
                {oil.status}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs bg-slate-800/60 p-3 rounded-lg border border-slate-700/60">
              <div>
                <span className="text-slate-400 text-[10px] block">FFA LEVEL</span>
                <span className="text-base font-bold text-sky-400">{oil.currentFfaPercent}%</span>
                <span className="text-[9px] text-slate-500 block">Limit: &lt;1.0%</span>
              </div>

              <div>
                <span className="text-slate-400 text-[10px] block">TPC LEVEL</span>
                <span className="text-base font-bold text-amber-400">{oil.currentTpcPercent}%</span>
                <span className="text-[9px] text-slate-500 block">Limit: &lt;24.0%</span>
              </div>

              <div>
                <span className="text-slate-400 text-[10px] block">PEROXIDE VAL</span>
                <span className="text-base font-bold text-slate-200">{oil.peroxideValueMeq} mEq</span>
              </div>

              <div>
                <span className="text-slate-400 text-[10px] block">USAGE HOURS</span>
                <span className="text-base font-bold text-purple-400">{oil.usageHours} hrs</span>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
              <span>Filtration Cycles Completed: <strong className="text-white">{oil.filtrationCyclesCompleted}</strong></span>
              <span>Oil Volume: <strong className="text-white">{oil.volumeLitres.toLocaleString()} L</strong></span>
            </div>
          </div>
        ))}
      </div>

      {/* R Thermal Degradation Rate Curve Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center justify-between">
            <span>R Kinetic Model: Oil Degradation over Continuous Frying Hours</span>
            <span className="text-xs font-mono text-purple-400 font-normal">First-Order Thermal Kinetic Rate Equations</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            Predicts when FFA % and TPC % will breach regulatory food safety thresholds, triggering automated fresh oil replenishment.
          </p>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={degradationData}>
              <XAxis dataKey="hours" stroke="#64748b" fontSize={11} label={{ value: 'Continuous Frying Hours', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 11 }} />
              <YAxis stroke="#64748b" fontSize={11} />
              <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
              <Legend />
              <Line type="monotone" dataKey="ffa" name="Free Fatty Acids (FFA %)" stroke="#38bdf8" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="tpc" name="Total Polar Compounds (TPC %)" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
              <Line type="monotone" dataKey="tpcLimit" name="TPC Regulatory Limit (24%)" stroke="#ef4444" strokeWidth={1} strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};
