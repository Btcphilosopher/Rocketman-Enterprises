import React from 'react';
import {
  PackageCheck,
  Truck,
  MapPin,
  BarChart2,
  CheckCircle2,
  Globe,
  Clock,
  ShieldCheck
} from 'lucide-react';

export const LogisticsModule: React.FC = () => {
  const pallets = [
    { id: 'PLT-88201', sku: 'CRISP-SAL-150G', name: 'Sea Salt Crisps 150g', cases: 40, packs: 960, bin: 'RACK-B-12', fefoDays: 180, status: 'AVAILABLE' },
    { id: 'PLT-88202', sku: 'CRISP-VIN-150G', name: 'Salt & Vinegar 150g', cases: 40, packs: 960, bin: 'RACK-B-14', fefoDays: 175, status: 'RESERVED' },
    { id: 'PLT-88203', sku: 'CRISP-CHD-150G', name: 'Cheddar & Onion 150g', cases: 40, packs: 960, bin: 'RACK-C-02', fefoDays: 182, status: 'STAGING' }
  ];

  const shipments = [
    { id: 'SHP-9901', customer: 'Tesco Central Distribution', dest: 'Daventry RDC, UK', pallets: 12, truck: 'Volvo FH500 (Euro 6)', otifStatus: 'ON_TIME', co2Kg: 142 },
    { id: 'SHP-9902', customer: 'Sainsbury’s Regional Depot', dest: 'Emerald Park, Bristol', pallets: 10, truck: 'Scania R450 Clean-Diesel', otifStatus: 'ON_TIME', co2Kg: 118 },
    { id: 'SHP-9903', customer: 'Asda Logistics Services', dest: 'Lutterworth Hub', pallets: 14, truck: 'DAF XF Electric Heavy', otifStatus: 'ON_TIME', co2Kg: 0 }
  ];

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <PackageCheck className="w-4 h-4" />
            <span>Warehouse WMS & Logistics TMS</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Palletized Warehouse Management & Route Logistics
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            FEFO dispatch rules, rack location tracking, truck load consolidation, and fleet carbon footprint optimization.
          </p>
        </div>
      </div>

      {/* WMS Pallet Storage Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>Finished Goods WMS Pallet Locations</span>
          <span className="text-emerald-400 font-normal">FEFO Dispatch Strategy Active</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {pallets.map(p => (
            <div key={p.id} className="p-4 bg-slate-800/60 border border-slate-700 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-400 text-sm">{p.id}</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold">
                  {p.status}
                </span>
              </div>

              <div className="text-white font-bold">{p.name}</div>

              <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-700 text-slate-300">
                <div>
                  <span className="text-slate-500 block text-[9px]">CASES / PACKS</span>
                  <span className="font-bold">{p.cases} cases ({p.packs} pks)</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[9px]">RACK LOCATION</span>
                  <span className="font-bold text-sky-400">{p.bin}</span>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 pt-1">
                Best Before Expiry: <strong className="text-emerald-400">{p.fefoDays} days remaining</strong>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* TMS Active Shipments Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>Transportation Management System (TMS) Active Shipments</span>
          <span className="text-amber-400 font-normal">OTIF Delivery Rate: 97.4%</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 text-[10px] uppercase">
              <tr>
                <th className="p-3">Shipment ID</th>
                <th className="p-3">Retail Customer</th>
                <th className="p-3">Destination RDC</th>
                <th className="p-3">Pallets</th>
                <th className="p-3">Vehicle Fleet Type</th>
                <th className="p-3">Carbon CO₂</th>
                <th className="p-3">OTIF Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {shipments.map(shp => (
                <tr key={shp.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-amber-400">{shp.id}</td>
                  <td className="p-3 font-bold text-white">{shp.customer}</td>
                  <td className="p-3 text-slate-300">{shp.dest}</td>
                  <td className="p-3 font-bold">{shp.pallets} pallets</td>
                  <td className="p-3 text-slate-400">{shp.truck}</td>
                  <td className="p-3 font-bold text-sky-400">
                    {shp.co2Kg === 0 ? '0 kg (Electric Zero Emission)' : `${shp.co2Kg} kg CO₂`}
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold text-[10px]">
                      {shp.otifStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
