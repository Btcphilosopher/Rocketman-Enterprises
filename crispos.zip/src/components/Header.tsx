import React from 'react';
import {
  Factory,
  Cpu,
  BarChart3,
  ShieldCheck,
  PlayCircle,
  Award,
  Zap,
  Globe
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onRunSimulation: () => void;
  isSimulating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onRunSimulation,
  isSimulating
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-slate-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          
          {/* Logo and App Title */}
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-br from-amber-500 to-amber-600 text-slate-950 rounded-xl shadow-md flex items-center justify-center font-black">
              <Factory className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white font-mono">
                  CRISPOS
                </h1>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 font-semibold">
                  Industrial OS v4.2
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium">
                The Industrial Operating System for Potato Chips & Snack Manufacturing
              </p>
            </div>
          </div>

          {/* Live Engine Badges */}
          <div className="hidden xl:flex items-center gap-3 text-xs font-mono">
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-300">
              <Cpu className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>Rust Core:</span>
              <span className="text-emerald-400 font-semibold">ONLINE</span>
            </div>

            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-300">
              <BarChart3 className="w-3.5 h-3.5 text-sky-400" />
              <span>R Analytics:</span>
              <span className="text-sky-400 font-semibold">v4.3.2</span>
            </div>

            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              <span>HACCP CCP:</span>
              <span className="text-amber-400 font-semibold">100% PASS</span>
            </div>

            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-300">
              <Award className="w-3.5 h-3.5 text-purple-400" />
              <span>Ledger:</span>
              <span className="text-purple-400 font-semibold">IMMUTABLE</span>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            <button
              onClick={onRunSimulation}
              disabled={isSimulating}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-lg font-semibold text-xs transition-all shadow-md ${
                isSimulating
                  ? 'bg-amber-600/50 text-white cursor-not-allowed'
                  : 'bg-amber-500 hover:bg-amber-400 text-slate-950 hover:shadow-amber-500/20'
              }`}
            >
              {isSimulating ? (
                <>
                  <Zap className="w-4 h-4 animate-spin" />
                  <span>Processing Vertical Slice...</span>
                </>
              ) : (
                <>
                  <PlayCircle className="w-4 h-4" />
                  <span>1-Click End-to-End Simulation</span>
                </>
              )}
            </button>

            <button
              onClick={() => setActiveTab('golden-ticket')}
              className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                activeTab === 'golden-ticket'
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-800 hover:bg-slate-700 text-purple-300 border border-purple-500/30'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>Consumer Portal</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
