import React from 'react';
import {
  LayoutDashboard,
  Sprout,
  Truck,
  Factory,
  Droplet,
  Eye,
  GitFork,
  PackageCheck,
  Ticket,
  BarChart,
  Workflow
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Executive Cockpit', icon: LayoutDashboard },
    { id: 'agriculture', label: 'Agricultural & Potato Specs', icon: Sprout },
    { id: 'receiving', label: 'Inbound Receiving & Storage', icon: Truck },
    { id: 'mes', label: 'Factory MES & Frying Twin', icon: Factory },
    { id: 'oil', label: 'Frying Oil Management', icon: Droplet },
    { id: 'qms', label: 'QMS & Computer Vision', icon: Eye },
    { id: 'traceability', label: '2-Way Traceability Engine', icon: GitFork },
    { id: 'logistics', label: 'Warehouse WMS & TMS', icon: PackageCheck },
    { id: 'golden-ticket', label: 'Golden Ticket & Consumer', icon: Ticket },
    { id: 'r-workbench', label: 'R Analytics Workbench', icon: BarChart },
    { id: 'simulator', label: 'Vertical Slice Stepper', icon: Workflow }
  ];

  return (
    <aside className="w-full lg:w-64 bg-slate-900 border-r border-slate-800 shrink-0 p-3">
      <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 font-bold px-3 py-2">
        Operational Modules
      </div>
      <nav className="space-y-1">
        {menuItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-semibold transition-all ${
                isActive
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-400'}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="mt-8 p-3 rounded-lg bg-slate-800/40 border border-slate-800 text-[11px] text-slate-400 space-y-2 font-mono">
        <div className="text-slate-300 font-semibold flex items-center justify-between">
          <span>FACTORY SITE</span>
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
        </div>
        <div>NORFOLK CRISP PLANT #01</div>
        <div className="text-[10px] text-slate-500">Continuous & Kettle Fryer Lines</div>
      </div>
    </aside>
  );
};
