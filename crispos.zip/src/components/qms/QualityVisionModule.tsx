import React from 'react';
import {
  Eye,
  ShieldCheck,
  AlertTriangle,
  Camera,
  CheckCircle2,
  Zap,
  Activity,
  Layers
} from 'lucide-react';
import { CcpLog, OpticalInspectionEvent } from '../../types';

interface QualityVisionModuleProps {
  ccpLogs: CcpLog[];
  visionEvents: OpticalInspectionEvent[];
}

export const QualityVisionModule: React.FC<QualityVisionModuleProps> = ({
  ccpLogs,
  visionEvents
}) => {
  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <Eye className="w-4 h-4" />
            <span>Quality Management & Computer Vision</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Optical Sorting Vision Stream & HACCP Critical Control Points
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time optical defect classification via high-speed line cameras (burnt edge, green spot, broken chip) and HACCP verification logs.
          </p>
        </div>
      </div>

      {/* Optical Vision Stream & Defect Ejection Simulation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Optical Camera Feed Visualizer */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Camera className="w-5 h-5 text-sky-400" />
              <h3 className="text-sm font-bold text-white">Line 1 High-Speed Optical Inspection Camera (120 fps)</h3>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 text-[10px] font-bold animate-pulse">
              LIVE INFERENCE STREAM
            </span>
          </div>

          {/* Simulated Camera Viewport */}
          <div className="relative h-56 bg-slate-950 border border-slate-800 rounded-xl overflow-hidden flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:16px_16px] opacity-40"></div>
            
            {/* Visual Crisp Inspection Items */}
            <div className="flex items-center justify-around w-full relative z-10">
              <div className="w-16 h-16 rounded-full bg-amber-400/80 border-2 border-emerald-400 flex flex-col items-center justify-center shadow-lg transform hover:scale-110 transition-transform">
                <span className="text-[9px] font-bold text-slate-950">PASS</span>
                <span className="text-[8px] text-slate-900">99.8%</span>
              </div>

              <div className="w-16 h-16 rounded-full bg-amber-600/90 border-2 border-red-500 flex flex-col items-center justify-center shadow-lg relative animate-bounce">
                <span className="text-[9px] font-bold text-white bg-red-600 px-1 rounded">DEFECT</span>
                <span className="text-[8px] text-amber-200">Burnt Edge</span>
                <span className="absolute -top-3 text-[9px] bg-red-500 text-white font-bold px-1 rounded">EJECTED</span>
              </div>

              <div className="w-16 h-16 rounded-full bg-amber-400/80 border-2 border-emerald-400 flex flex-col items-center justify-center shadow-lg">
                <span className="text-[9px] font-bold text-slate-950">PASS</span>
                <span className="text-[8px] text-slate-900">99.5%</span>
              </div>

              <div className="w-16 h-16 rounded-full bg-amber-500/80 border-2 border-emerald-400 flex flex-col items-center justify-center shadow-lg">
                <span className="text-[9px] font-bold text-slate-950">PASS</span>
                <span className="text-[8px] text-slate-900">99.2%</span>
              </div>
            </div>

            {/* Bounding Box HUD */}
            <div className="absolute top-3 left-3 text-[10px] text-sky-400 font-bold bg-slate-900/80 p-1.5 rounded border border-sky-500/30">
              YOLOv8-Snack Inferences: 1,820 / min • Air Jet Response: 4.2ms
            </div>
          </div>

          <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60 text-xs flex justify-between">
            <span>Overall Optical Defect Rejection Rate: <strong className="text-emerald-400">0.38%</strong></span>
            <span>Target Rejection Precision: <strong className="text-sky-400">&gt; 99.0%</strong></span>
          </div>
        </div>

        {/* Optical Vision Events List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 font-mono">
          <h3 className="text-sm font-bold text-white">Recent Vision Defect Detections</h3>

          <div className="space-y-2 text-xs">
            {visionEvents.map(event => (
              <div key={event.id} className="p-3 bg-slate-800/60 rounded-lg border border-slate-700 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-400">{event.defectType}</span>
                  <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 text-[9px] font-bold">
                    {event.severity}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 flex justify-between">
                  <span>Confidence: {(event.confidenceScore * 100).toFixed(1)}%</span>
                  <span className="text-emerald-400 font-bold">{event.actionTaken}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* HACCP CCP Log Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>HACCP Critical Control Points (CCP) Monitoring Audit Trail</span>
          <span className="text-xs text-emerald-400">Audit Compliance: 100%</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 text-[10px] uppercase">
              <tr>
                <th className="p-3">Timestamp</th>
                <th className="p-3">CCP Number & Name</th>
                <th className="p-3">Batch Number</th>
                <th className="p-3">Measured Parameter</th>
                <th className="p-3">Critical Limit</th>
                <th className="p-3">Compliance Status</th>
                <th className="p-3">QA Operator</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {ccpLogs.map(log => (
                <tr key={log.id} className="hover:bg-slate-800/40">
                  <td className="p-3 text-slate-400">{log.timestamp.split('T')[1].replace('Z','')}</td>
                  <td className="p-3 font-bold text-white">{log.ccpNumber}</td>
                  <td className="p-3 text-amber-400 font-bold">{log.batchNumber}</td>
                  <td className="p-3 text-slate-200">{log.measuredValue}</td>
                  <td className="p-3 text-slate-400">{log.criticalLimit}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                      {log.status}
                    </span>
                  </td>
                  <td className="p-3 text-slate-400">{log.operatorName}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
