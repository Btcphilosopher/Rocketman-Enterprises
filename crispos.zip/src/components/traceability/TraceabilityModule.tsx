import React, { useState } from 'react';
import {
  GitFork,
  Search,
  CheckCircle2,
  ChevronRight,
  Sprout,
  Truck,
  Factory,
  PackageCheck,
  Ticket,
  MapPin
} from 'lucide-react';
import { fetchTraceability } from '../../services/api';
import { TraceabilityNode } from '../../types';

export const TraceabilityModule: React.FC = () => {
  const [searchKey, setSearchKey] = useState<string>('P2026-0816-01');
  const [loading, setLoading] = useState<boolean>(false);
  const [treeData, setTreeData] = useState<TraceabilityNode | null>(null);

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    try {
      const res = await fetchTraceability(searchKey);
      setTreeData(res.traceabilityTree);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    handleSearch();
  }, []);

  const renderNode = (node: TraceabilityNode, level: number = 0) => {
    return (
      <div key={node.id} className="space-y-3 font-mono">
        <div className="flex items-start gap-3 p-4 bg-slate-800/80 border border-slate-700/80 rounded-xl hover:border-amber-500/50 transition-all shadow-md">
          <div className="p-2.5 bg-amber-500/20 text-amber-400 rounded-lg shrink-0 font-bold text-xs">
            {node.type}
          </div>

          <div className="flex-1 space-y-1">
            <div className="text-sm font-bold text-white flex items-center justify-between">
              <span>{node.label}</span>
              <span className="text-[10px] text-slate-400 font-normal">ID: {node.id}</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs text-slate-300 pt-1">
              {Object.entries(node.details || {}).map(([key, val]) => (
                <div key={key}>
                  <span className="text-slate-500 text-[10px] block uppercase">{key}</span>
                  <span className="font-semibold text-amber-300">{val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Children Render Recursive */}
        {node.children && node.children.length > 0 && (
          <div className="pl-6 border-l-2 border-amber-500/30 space-y-3 ml-4">
            {node.children.map(child => renderNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      
      {/* Title & Search Bar */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <GitFork className="w-4 h-4" />
            <span>2-Way Traceability Query Engine</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Instant Backward & Forward Food Lineage Tree
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Trace any individual packet QR token or batch barcode back to the exact field, soil type, grower, frying oil lot, and seasoning batch in seconds.
          </p>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2 max-w-xl font-mono text-xs">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchKey}
              onChange={e => setSearchKey(e.target.value)}
              placeholder="Search Lot Number (e.g. P2026-0816-01), Batch (BAT-20260816-01), or Token (GT-8841)..."
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2.5 text-white focus:outline-none focus:border-amber-500"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition-all"
          >
            {loading ? 'Searching...' : 'Trace Lineage'}
          </button>
        </form>
      </div>

      {/* Lineage Tree Display */}
      {treeData && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between font-mono text-xs text-slate-400">
            <span>GENEALOGY TREE FOR KEY: <strong className="text-amber-400">{searchKey}</strong></span>
            <span className="text-emerald-400 font-bold">100% AUDIT VERIFIED</span>
          </div>

          <div className="py-2">
            {renderNode(treeData)}
          </div>
        </div>
      )}

    </div>
  );
};
