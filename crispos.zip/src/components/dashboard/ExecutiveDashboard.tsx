import React from 'react';
import {
  TrendingUp,
  Activity,
  Zap,
  Droplets,
  Scale,
  Award,
  ShieldCheck,
  AlertCircle,
  ArrowUpRight,
  Gauge,
  Layers,
  Sparkles
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

interface ExecutiveDashboardProps {
  summary: any;
  lines: any[];
  onNavigate: (tab: string) => void;
  onRunSimulation: () => void;
}

const hourlyThroughputData = [
  { time: '01:00', line1: 1800, line2: 2750 },
  { time: '02:00', line1: 1820, line2: 2780 },
  { time: '03:00', line1: 1850, line2: 2800 },
  { time: '04:00', line1: 1840, line2: 2820 },
  { time: '05:00', line1: 1860, line2: 2790 },
  { time: '06:00', line1: 1850, line2: 2800 },
];

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  summary,
  lines,
  onNavigate,
  onRunSimulation
}) => {
  return (
    <div className="space-y-6">
      
      {/* Hero Banner / Quick Overview */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-amber-400 via-amber-600 to-transparent pointer-events-none"></div>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase tracking-wider">
              <Sparkles className="w-4 h-4" />
              <span>Plant Operational Cockpit</span>
            </div>
            <h2 className="text-2xl font-bold text-white tracking-tight mt-1">
              Norfolk Crisp Manufacturing Facility #01
            </h2>
            <p className="text-slate-400 text-xs mt-1 max-w-2xl">
              Real-time integration across Agricultural Procurement, Raw Receiving, Kettle & Continuous Frying Lines, QMS Optical Sorting, MAP Packaging, and Golden Ticket Ledger.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('simulator')}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold flex items-center gap-2 transition-all"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>View Vertical Slice</span>
            </button>
            <button
              onClick={onRunSimulation}
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-2 transition-all shadow-lg shadow-amber-500/10"
            >
              <Zap className="w-4 h-4" />
              <span>Simulate Production Batch</span>
            </button>
          </div>
        </div>
      </div>

      {/* KPI Metric Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Daily Production */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Daily Crisp Production</span>
            <span className="p-2 bg-emerald-500/10 text-emerald-400 rounded-lg">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {summary?.productionTonnesToday || '842.5'}
            </span>
            <span className="text-xs text-slate-400 font-mono">Tonnes / day</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-400 flex items-center gap-1 font-medium">
            <ArrowUpRight className="w-3 h-3" />
            <span>+4.2% vs target capacity</span>
          </div>
        </div>

        {/* Card 2: Overall OEE */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Plant Overall OEE</span>
            <span className="p-2 bg-sky-500/10 text-sky-400 rounded-lg">
              <Gauge className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {summary?.oeePercent || '89.8'}%
            </span>
            <span className="text-xs text-slate-400 font-mono">Target: 85%</span>
          </div>
          <div className="mt-2 text-[11px] text-sky-400 flex items-center gap-1 font-medium">
            <Activity className="w-3 h-3" />
            <span>Availability 95.1% • Quality 97.8%</span>
          </div>
        </div>

        {/* Card 3: Material Yield */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Potato Crisp Yield</span>
            <span className="p-2 bg-amber-500/10 text-amber-400 rounded-lg">
              <Scale className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">
              {summary?.yieldPercent || '83.2'}%
            </span>
            <span className="text-xs text-slate-400 font-mono">Raw → Finished</span>
          </div>
          <div className="mt-2 text-[11px] text-amber-400 flex items-center gap-1 font-medium">
            <span>Peel loss: 6.8% • Frying moisture drop: 82%</span>
          </div>
        </div>

        {/* Card 4: Frying Oil Efficiency */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-400">Frying Oil Uptake</span>
            <span className="p-2 bg-purple-500/10 text-purple-400 rounded-lg">
              <Droplets className="w-4 h-4" />
            </span>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-bold font-mono text-white">31.5%</span>
            <span className="text-xs text-slate-400 font-mono">High Oleic Sunflower</span>
          </div>
          <div className="mt-2 text-[11px] text-purple-400 flex items-center gap-1 font-medium">
            <span>FFA: 0.38% • TPC: 11.4% (Optimal)</span>
          </div>
        </div>

      </div>

      {/* Production Throughput Chart & Line Digital Twin */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Line Throughput Real-Time Chart */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">Fryer Throughput Telemetry (kg/hr)</h3>
              <p className="text-xs text-slate-400">Live feed from SCADA OPC-UA edge controller</p>
            </div>
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
                <span className="text-slate-300">Line 1 Kettle</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-500"></span>
                <span className="text-slate-300">Line 2 Continuous</span>
              </div>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={hourlyThroughputData}>
                <defs>
                  <linearGradient id="line1Grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="line2Grad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} domain={[1000, 3200]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="line1" stroke="#f59e0b" strokeWidth={2} fillOpacity={1} fill="url(#line1Grad)" />
                <Area type="monotone" dataKey="line2" stroke="#0284c7" strokeWidth={2} fillOpacity={1} fill="url(#line2Grad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Line Status Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-white flex items-center justify-between">
            <span>Production Line Status</span>
            <span className="text-[10px] font-mono bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded">2 ACTIVE LINES</span>
          </h3>

          <div className="space-y-3">
            {lines.map((line: any) => (
              <div key={line.id} className="p-3.5 rounded-lg bg-slate-800/60 border border-slate-700/60 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="font-bold text-xs text-slate-100">{line.name}</div>
                  <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-semibold">
                    {line.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-slate-300">
                  <div>
                    <span className="text-slate-500 block text-[10px]">THROUGHPUT</span>
                    <span className="font-bold text-amber-400">{line.throughputKgPerHour} kg/hr</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">FRYER TEMP</span>
                    <span className="font-bold text-sky-400">{line.fryerTemperatureCelsius} °C</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">PACKAGING</span>
                    <span>{line.packagingPacksPerMin} bpm</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">OEE INDEX</span>
                    <span className="font-bold text-emerald-400">{line.oeePercent}%</span>
                  </div>
                </div>

                {/* OEE Mini Progress bar */}
                <div className="w-full bg-slate-700 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-gradient-to-r from-amber-500 to-emerald-500 h-full rounded-full" style={{ width: `${line.oeePercent}%` }}></div>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={() => onNavigate('mes')}
            className="w-full py-2 text-xs font-semibold text-center text-amber-400 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-lg transition-colors"
          >
            Open Factory Digital Twin →
          </button>
        </div>

      </div>

      {/* Bottom Grid: Golden Ticket Ledger + HACCP CCP Safety Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Golden Ticket Ledger Summary */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Award className="w-5 h-5 text-purple-400" />
              <h3 className="text-sm font-bold text-white">Golden Ticket Ledger Ecosystem</h3>
            </div>
            <button
              onClick={() => onNavigate('golden-ticket')}
              className="text-xs text-purple-400 hover:text-purple-300 font-semibold"
            >
              Open Scan Portal →
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono text-xs">
            <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60">
              <span className="text-slate-400 text-[10px] block">ISSUED PACKET TOKENS</span>
              <span className="text-lg font-bold text-white">1,500,000</span>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60">
              <span className="text-slate-400 text-[10px] block">REDEEMED BY CONSUMERS</span>
              <span className="text-lg font-bold text-purple-400">{summary?.goldenTicketsRedeemed || 123421}</span>
            </div>

            <div className="p-3 bg-slate-800/60 rounded-lg border border-slate-700/60">
              <span className="text-slate-400 text-[10px] block">REDEMPTION RATE</span>
              <span className="text-lg font-bold text-emerald-400">8.23%</span>
            </div>
          </div>

          <div className="p-3 bg-purple-950/30 border border-purple-800/40 rounded-lg text-xs text-purple-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-purple-400" />
              <span>Cryptographic HMAC Token Validation & Double-Spend Protection: Active</span>
            </div>
            <span className="text-[10px] font-mono bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded font-bold">HMAC-256</span>
          </div>
        </div>

        {/* HACCP Food Safety & QMS Status */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              <h3 className="text-sm font-bold text-white">HACCP Critical Control Points (CCP)</h3>
            </div>
            <button
              onClick={() => onNavigate('qms')}
              className="text-xs text-amber-400 hover:text-amber-300 font-semibold"
            >
              View QMS Logs →
            </button>
          </div>

          <div className="space-y-2.5 text-xs font-mono">
            <div className="p-2.5 bg-slate-800/60 rounded-lg border border-slate-700/60 flex items-center justify-between">
              <div>
                <span className="font-bold text-white">CCP-1 (Metal Detector)</span>
                <span className="text-slate-400 block text-[10px]">Ferrous 1.2mm, SS 2.0mm test wand verified</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">100% PASS</span>
            </div>

            <div className="p-2.5 bg-slate-800/60 rounded-lg border border-slate-700/60 flex items-center justify-between">
              <div>
                <span className="font-bold text-white">CCP-2 (Optical Sorter)</span>
                <span className="text-slate-400 block text-[10px]">Ejection air jet: 99.4% precision</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">100% PASS</span>
            </div>

            <div className="p-2.5 bg-slate-800/60 rounded-lg border border-slate-700/60 flex items-center justify-between">
              <div>
                <span className="font-bold text-white">CCP-3 (MAP Bag Seal Integrity)</span>
                <span className="text-slate-400 block text-[10px]">Nitrogen flush: 98.2% N₂, Residual O₂: 1.2%</span>
              </div>
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">100% PASS</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
