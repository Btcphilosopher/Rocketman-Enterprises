import React, { useState } from 'react';
import {
  BarChart,
  Play,
  Terminal,
  Cpu,
  BarChart2,
  CheckCircle2,
  Code,
  Sparkles,
  Layers
} from 'lucide-react';
import { executeRModel } from '../../services/api';
import { RScriptExecutionResult } from '../../types';
import { ResponsiveContainer, AreaChart, Area, LineChart, Line, XAxis, YAxis, Tooltip, Legend } from 'recharts';

export const RAnalyticsWorkbench: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState<any>('CROP_YIELD_REGRESSION');
  const [loading, setLoading] = useState<boolean>(false);
  const [modelResult, setModelResult] = useState<RScriptExecutionResult | null>(null);

  const handleExecuteRScript = async (modelType = selectedModel) => {
    setLoading(true);
    try {
      const res = await executeRModel({ modelType, parameters: {} });
      setModelResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    handleExecuteRScript('CROP_YIELD_REGRESSION');
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-sky-400 text-xs font-mono font-bold uppercase">
            <BarChart className="w-4 h-4" />
            <span>R Analytics Workbench & Data Science Core</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Statistical Intelligence, Yield Regression & SPC Control Models
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Executes reproducible R statistical scripts for agronomic crop forecasting, thermal oil degradation, Shewhart SPC capability, and ARIMA demand forecasting.
          </p>
        </div>

        <button
          onClick={() => handleExecuteRScript(selectedModel)}
          disabled={loading}
          className="px-4 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-2 transition-all shadow-md font-mono"
        >
          <Play className="w-4 h-4" />
          <span>{loading ? 'Executing R Script...' : 'Run R Statistical Pipeline'}</span>
        </button>
      </div>

      {/* Model Selection Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono text-xs">
        {[
          { id: 'CROP_YIELD_REGRESSION', label: '1. Crop Yield Regression' },
          { id: 'OIL_DEGRADATION_KINETICS', label: '2. Frying Oil Degradation' },
          { id: 'SHEWHART_SPC_CHARTS', label: '3. Shewhart SPC & Cpk' },
          { id: 'DEMAND_ARIMA_FORECAST', label: '4. ARIMA Demand Forecast' }
        ].map(m => {
          const isSelected = selectedModel === m.id;
          return (
            <button
              key={m.id}
              onClick={() => {
                setSelectedModel(m.id);
                handleExecuteRScript(m.id);
              }}
              className={`p-3 rounded-lg border text-left transition-all font-bold ${
                isSelected
                  ? 'bg-sky-500/20 text-sky-300 border-sky-500/50 shadow-md'
                  : 'bg-slate-800/60 text-slate-400 border-slate-700 hover:bg-slate-800'
              }`}
            >
              {m.label}
            </button>
          );
        })}
      </div>

      {/* R Model Result & Chart Visualization */}
      {modelResult && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono">
          
          {/* Chart Display Panel */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-white">{modelResult.modelType} Output</h3>
                <p className="text-xs text-slate-400 mt-0.5">{modelResult.summaryText}</p>
              </div>
              <span className="text-[10px] bg-slate-800 text-sky-400 px-2 py-1 rounded border border-slate-700">
                {modelResult.rVersionInfo}
              </span>
            </div>

            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                {modelResult.modelType === 'CROP_YIELD_REGRESSION' ? (
                  <LineChart data={modelResult.chartData}>
                    <XAxis dataKey="soilN" stroke="#64748b" fontSize={11} label={{ value: 'Soil Nitrogen (kg/ha)', position: 'insideBottom', offset: -5, fill: '#64748b', fontSize: 11 }} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                    <Legend />
                    <Line type="monotone" dataKey="actualYield" name="Actual Yield (t/ha)" stroke="#f59e0b" strokeWidth={2} />
                    <Line type="monotone" dataKey="predictedYield" name="Predicted R Model (t/ha)" stroke="#38bdf8" strokeWidth={2} strokeDasharray="3 3" />
                  </LineChart>
                ) : modelResult.modelType === 'SHEWHART_SPC_CHARTS' ? (
                  <LineChart data={modelResult.chartData}>
                    <XAxis dataKey="sample" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} domain={[147, 154]} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                    <Legend />
                    <Line type="monotone" dataKey="mean" name="Sample Mean Weight (g)" stroke="#38bdf8" strokeWidth={2} dot={{ r: 3 }} />
                    <Line type="monotone" dataKey="ucl" name="Upper Control Limit (UCL)" stroke="#ef4444" strokeWidth={1} strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="lcl" name="Lower Control Limit (LCL)" stroke="#ef4444" strokeWidth={1} strokeDasharray="3 3" />
                    <Line type="monotone" dataKey="target" name="Target (150.0g)" stroke="#10b981" strokeWidth={1} />
                  </LineChart>
                ) : (
                  <AreaChart data={modelResult.chartData}>
                    <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff', fontSize: '12px' }} />
                    <Area type="monotone" dataKey="forecast" stroke="#38bdf8" fill="#0284c7" fillOpacity={0.2} name="ARIMA Forecast Packs" />
                  </AreaChart>
                )}
              </ResponsiveContainer>
            </div>
          </div>

          {/* Model Statistics & Executable R Code */}
          <div className="space-y-4">
            
            {/* Statistical Metrics Box */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
              <h3 className="text-sm font-bold text-white flex items-center justify-between">
                <span>R Model Goodness of Fit</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              </h3>

              <div className="space-y-2 text-xs">
                {Object.entries(modelResult.metrics).map(([k, v]) => (
                  <div key={k} className="p-2.5 bg-slate-800/60 rounded-lg border border-slate-700/60 flex justify-between">
                    <span className="text-slate-400">{k}:</span>
                    <span className="font-bold text-sky-400">{v}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* R Code Viewer */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
                <Code className="w-4 h-4 text-amber-400" />
                <span>R Script Source Pipeline</span>
              </div>
              <pre className="p-3 bg-slate-950 border border-slate-800 rounded-lg text-[10px] text-amber-300 overflow-x-auto leading-relaxed">
                {modelResult.codeSnippet}
              </pre>
            </div>

          </div>

        </div>
      )}

    </div>
  );
};
