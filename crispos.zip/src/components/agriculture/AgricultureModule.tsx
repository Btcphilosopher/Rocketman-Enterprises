import React, { useState } from 'react';
import {
  Sprout,
  Calculator,
  CloudRain,
  Sun,
  Thermometer,
  ShieldAlert,
  Sliders,
  CheckCircle2,
  TrendingDown,
  ChevronRight
} from 'lucide-react';
import { PotatoSpecification, Farm } from '../../types';

interface AgricultureModuleProps {
  farms: Farm[];
  specifications: PotatoSpecification[];
}

export const AgricultureModule: React.FC<AgricultureModuleProps> = ({
  farms,
  specifications
}) => {
  const [selectedVariety, setSelectedVariety] = useState<string>('Lady Rosetta');
  const [rawPricePerTonne, setRawPricePerTonne] = useState<number>(195);
  const [dryMatterPercent, setDryMatterPercent] = useState<number>(23.8);
  const [peelLossPercent, setPeelLossPercent] = useState<number>(6.5);
  const [oilPricePerTonne, setOilPricePerTonne] = useState<number>(1200);

  // Scenario Simulator state
  const [scenario, setScenario] = useState<'NORMAL' | 'DROUGHT' | 'HEAVY_RAIN' | 'EARLY_FROST'>('NORMAL');

  const currentSpec = specifications.find(s => s.variety === selectedVariety) || specifications[0];

  // Calculate Cost per Finished Tonne of Crisps
  // Dry crisp mass relies primarily on dry matter content + oil absorbed during frying
  const dryMatterYieldFactor = dryMatterPercent / 100;
  const usablePotatoRatio = 1 - (peelLossPercent / 100);
  const crispYieldFromPotato = dryMatterYieldFactor * usablePotatoRatio; // e.g. 0.238 * 0.935 = 0.222 tonnes crisps per tonne raw potato
  const rawPotatoNeededPerTonneCrisp = 1 / crispYieldFromPotato; // e.g. 4.5 tonnes raw potato per 1 tonne crisps
  
  const rawPotatoCostForTonneCrisps = rawPotatoNeededPerTonneCrisp * rawPricePerTonne;
  const oilAbsorbedTonnePerTonneCrisps = (currentSpec.expectedOilAbsorptionPercent / 100);
  const oilCostForTonneCrisps = oilAbsorbedTonnePerTonneCrisps * oilPricePerTonne;

  const totalFinishedTonneCost = Math.round(rawPotatoCostForTonneCrisps + oilCostForTonneCrisps);

  // Scenario modifier adjustments
  let scenarioYieldImpact = 0;
  let scenarioCostImpact = 0;
  let scenarioSugarImpact = 0;
  let scenarioNotes = 'Normal growing conditions with optimal rainfall and soil temperature.';

  if (scenario === 'DROUGHT') {
    scenarioYieldImpact = -18; // -18% yield
    scenarioCostImpact = +24;  // +24% cost
    scenarioSugarImpact = +0.02;
    scenarioNotes = 'Drought stress increases dry matter density but reduces tuber size distribution and total hectare yield.';
  } else if (scenario === 'HEAVY_RAIN') {
    scenarioYieldImpact = -8;
    scenarioCostImpact = +12;
    scenarioSugarImpact = +0.05;
    scenarioNotes = 'Waterlogging increases soil tare (dirt/stones) and risk of soft rot during storage.';
  } else if (scenario === 'EARLY_FROST') {
    scenarioYieldImpact = -12;
    scenarioCostImpact = +32;
    scenarioSugarImpact = +0.12; // Increases reducing sugars -> dark browning risk during frying!
    scenarioNotes = 'Cold soil triggers starch-to-reducing sugar conversion (cold-induced sweetening). High acrylamide/dark browning risk.';
  }

  return (
    <div className="space-y-6">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <Sprout className="w-4 h-4" />
            <span>Agronomy & Procurement Module</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Agricultural Supply Chain & Processing Potato Varieties
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Track farm grower contracts, variety processing specs, dry matter yields, reducing sugar thresholds, and economic cost per finished tonne.
          </p>
        </div>
      </div>

      {/* Potato Variety Specifications Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>Processing Potato Variety Specifications</span>
          <span className="text-xs text-amber-400 font-mono font-normal">Select variety to inspect criteria</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
          {specifications.map(spec => {
            const isSelected = spec.variety === selectedVariety;
            return (
              <button
                key={spec.variety}
                onClick={() => {
                  setSelectedVariety(spec.variety);
                  setDryMatterPercent((spec.targetDryMatterMin + spec.targetDryMatterMax) / 2);
                }}
                className={`p-3 rounded-lg text-left transition-all font-mono text-xs ${
                  isSelected
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/50 shadow-md'
                    : 'bg-slate-800/60 text-slate-300 border border-slate-700/60 hover:bg-slate-800'
                }`}
              >
                <div className="font-bold">{spec.variety}</div>
                <div className="text-[10px] text-slate-400 mt-1">
                  Dry Matter: {spec.targetDryMatterMin}-{spec.targetDryMatterMax}%
                </div>
                <div className="mt-2 text-[10px] inline-block px-1.5 py-0.5 rounded bg-slate-900 text-emerald-400 font-bold">
                  {spec.fryingSuitability}
                </div>
              </button>
            );
          })}
        </div>

        {/* Selected Spec Details Card */}
        <div className="p-4 bg-slate-800/60 rounded-xl border border-slate-700/60 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
          <div>
            <span className="text-slate-400 block text-[10px]">TARGET DRY MATTER</span>
            <span className="text-base font-bold text-white">
              {currentSpec.targetDryMatterMin}% - {currentSpec.targetDryMatterMax}%
            </span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px]">SPECIFIC GRAVITY</span>
            <span className="text-base font-bold text-sky-400">
              {currentSpec.targetSpecificGravityMin} - {currentSpec.targetSpecificGravityMax}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px]">MAX REDUCING SUGARS</span>
            <span className="text-base font-bold text-amber-400">
              &le; {currentSpec.maxReducingSugars}%
            </span>
            <span className="text-[9px] text-slate-400 block">Prevents dark frying browning</span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px]">EST. OIL ABSORPTION</span>
            <span className="text-base font-bold text-purple-400">
              {currentSpec.expectedOilAbsorptionPercent}%
            </span>
          </div>
        </div>
      </div>

      {/* Finished Tonne Cost Engine & Harvest Scenario Simulator */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Cost per Finished Tonne Engine */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Calculator className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white">Expected Cost per Finished Tonne Engine</h3>
          </div>
          <p className="text-xs text-slate-400">
            Calculates true finished product cost by accounting for raw potato dry matter density, peeling waste, and oil absorption costs.
          </p>

          <div className="space-y-3 font-mono text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Raw Potato Price (£/tonne):</span>
                <span className="font-bold text-amber-400">£{rawPricePerTonne}</span>
              </div>
              <input
                type="range"
                min="140"
                max="320"
                value={rawPricePerTonne}
                onChange={e => setRawPricePerTonne(Number(e.target.value))}
                className="w-full accent-amber-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Dry Matter Content (%):</span>
                <span className="font-bold text-sky-400">{dryMatterPercent}%</span>
              </div>
              <input
                type="range"
                min="18"
                max="26"
                step="0.1"
                value={dryMatterPercent}
                onChange={e => setDryMatterPercent(Number(e.target.value))}
                className="w-full accent-sky-500"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Peeling Waste Loss (%):</span>
                <span className="font-bold text-red-400">{peelLossPercent}%</span>
              </div>
              <input
                type="range"
                min="3"
                max="12"
                step="0.5"
                value={peelLossPercent}
                onChange={e => setPeelLossPercent(Number(e.target.value))}
                className="w-full accent-red-500"
              />
            </div>

            <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700/80 space-y-1">
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Raw Potatoes Needed per 1t Crisps:</span>
                <span className="text-slate-200 font-bold">{rawPotatoNeededPerTonneCrisp.toFixed(2)} tonnes</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Raw Material Cost Component:</span>
                <span className="text-slate-200 font-bold">£{Math.round(rawPotatoCostForTonneCrisps)}</span>
              </div>
              <div className="flex justify-between text-slate-400 text-[11px]">
                <span>Frying Oil Cost Component:</span>
                <span className="text-slate-200 font-bold">£{Math.round(oilCostForTonneCrisps)}</span>
              </div>
              <div className="pt-2 border-t border-slate-700 flex justify-between text-sm font-bold text-white">
                <span>Calculated Cost / Finished Tonne:</span>
                <span className="text-emerald-400">£{totalFinishedTonneCost} / tonne</span>
              </div>
            </div>
          </div>
        </div>

        {/* Harvest Agronomy Scenario Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center gap-2">
            <CloudRain className="w-5 h-5 text-sky-400" />
            <h3 className="text-sm font-bold text-white">R Agronomic Scenario Simulator</h3>
          </div>
          <p className="text-xs text-slate-400">
            Simulate weather and environmental disruptions on harvest yield, crop availability, and frying quality.
          </p>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            {[
              { id: 'NORMAL', label: 'Optimal Weather', icon: Sun },
              { id: 'DROUGHT', label: 'Severe Drought', icon: Thermometer },
              { id: 'HEAVY_RAIN', label: 'Heavy Rain / Rot', icon: CloudRain },
              { id: 'EARLY_FROST', label: 'Early Frost Shock', icon: ShieldAlert }
            ].map(item => {
              const Icon = item.icon;
              const isSelected = scenario === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setScenario(item.id as any)}
                  className={`p-2.5 rounded-lg border text-left flex items-center gap-2 transition-all ${
                    isSelected
                      ? 'bg-sky-500/20 text-sky-300 border-sky-500/50 font-bold'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:bg-slate-800'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>

          <div className="p-3.5 bg-slate-800/60 rounded-xl border border-slate-700/60 space-y-2 text-xs font-mono">
            <div className="text-slate-300 font-bold flex items-center justify-between">
              <span>SIMULATION OUTPUT:</span>
              <span className="text-sky-400">{scenario}</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {scenarioNotes}
            </p>

            <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700 text-[11px]">
              <div>
                <span className="text-slate-500 block text-[10px]">YIELD IMPACT</span>
                <span className={`font-bold ${scenarioYieldImpact < 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                  {scenarioYieldImpact}%
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">COST IMPACT</span>
                <span className={`font-bold ${scenarioCostImpact > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                  +{scenarioCostImpact}%
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">REDUCING SUGAR</span>
                <span className={`font-bold ${scenarioSugarImpact > 0.05 ? 'text-amber-400' : 'text-slate-200'}`}>
                  +{(scenarioSugarImpact * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Contracted Farms Registry */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white">Active Farm & Grower Contracts</h3>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 text-[10px] uppercase">
              <tr>
                <th className="p-3">Farm Name</th>
                <th className="p-3">Grower</th>
                <th className="p-3">Region</th>
                <th className="p-3">Acreage</th>
                <th className="p-3">Soil Type</th>
                <th className="p-3">Contracts</th>
                <th className="p-3">Sustainability</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {farms.map(farm => (
                <tr key={farm.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-white">{farm.name}</td>
                  <td className="p-3">{farm.growerName}</td>
                  <td className="p-3">{farm.region}</td>
                  <td className="p-3">{farm.totalAcreage} acres</td>
                  <td className="p-3">{farm.soilType}</td>
                  <td className="p-3 font-bold text-amber-400">{farm.activeContracts} active</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                      {farm.sustainabilityRating}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
