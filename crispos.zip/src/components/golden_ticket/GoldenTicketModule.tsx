import React, { useState } from 'react';
import {
  Ticket,
  Award,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  QrCode,
  Sparkles,
  Smartphone,
  Zap,
  Globe,
  Lock,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { verifyGoldenTicket, issueGoldenTickets } from '../../services/api';
import { GoldenTicketRedemptionResult } from '../../types';

export const GoldenTicketModule: React.FC = () => {
  const [tokenInput, setTokenInput] = useState<string>('GT-8841');
  const [userLocation, setUserLocation] = useState<string>('Norwich, UK');
  const [loading, setLoading] = useState<boolean>(false);
  const [result, setResult] = useState<GoldenTicketRedemptionResult | null>(null);
  const [issueCount, setIssueCount] = useState<number>(5);
  const [issuedTokens, setIssuedTokens] = useState<any[]>([]);

  const handleVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!tokenInput.trim()) return;

    setLoading(true);
    setResult(null);

    try {
      const res = await verifyGoldenTicket(tokenInput.trim(), userLocation);
      setResult(res);

      if (res.isValid && res.ticketDetails?.isWinner) {
        confetti({
          particleCount: 120,
          spread: 80,
          origin: { y: 0.6 }
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleIssueMore = async () => {
    try {
      const res = await issueGoldenTickets('CAMP-SUMMER-2026', 'BAT-20260816-01', issueCount);
      if (res.success) {
        setIssuedTokens(res.sampleTokens);
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Module Title */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-purple-400 text-xs font-mono font-bold uppercase">
            <Ticket className="w-4 h-4" />
            <span>Golden Ticket Blockchain System</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Cryptographic Pack Tokens & Consumer Redemption Portal
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            HMAC-SHA256 signed packet QR tokens connecting physical snack bags to immutable double-spend ledger validation and anti-fraud scoring.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Side: Campaign Manager & Token Generator */}
        <div className="space-y-6">
          
          {/* Campaign Overview Card */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-purple-400" />
                <span>Active Campaign: CRISPOS Summer Golden Ticket</span>
              </h3>
              <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold">
                ACTIVE
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-800/60 p-3 rounded-lg border border-slate-700/60">
              <div>
                <span className="text-slate-400 text-[10px] block">GRAND PRIZE</span>
                <span className="text-base font-bold text-amber-400">£100,000</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">TIER 2 PRIZE</span>
                <span className="text-base font-bold text-white">20 &times; £2,500</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">TIER 3 PRIZE</span>
                <span className="text-base font-bold text-white">500 &times; £100</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] block">TIER 4 PRIZE</span>
                <span className="text-base font-bold text-white">10,000 &times; £10</span>
              </div>
            </div>

            <div className="p-3 bg-purple-950/20 border border-purple-800/40 rounded-lg text-purple-200 text-[11px] space-y-1">
              <div className="flex justify-between">
                <span>Cryptographic HMAC Key Salt:</span>
                <span className="font-bold text-white">SHA256_HMAC_CRISPOS_2026</span>
              </div>
              <div className="flex justify-between">
                <span>Anti-Double Spend Ledger:</span>
                <span className="font-bold text-emerald-400">IMMUTABLE ACTIVE</span>
              </div>
            </div>
          </div>

          {/* Token Generation Tool */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono text-xs">
            <h3 className="text-sm font-bold text-white flex items-center justify-between">
              <span>Cryptographic Pack Token Issuer</span>
              <span className="text-slate-400 font-normal">Generate batch tokens</span>
            </h3>

            <div className="flex items-center gap-3">
              <button
                onClick={handleIssueMore}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg transition-all"
              >
                Generate 5 New Signed Tokens
              </button>
            </div>

            {issuedTokens.length > 0 && (
              <div className="p-3 bg-slate-800/80 rounded-lg border border-slate-700 space-y-2">
                <span className="text-[10px] text-slate-400 block font-bold">RECENTLY ISSUED HMAC TOKENS:</span>
                {issuedTokens.map((t, idx) => (
                  <div key={idx} className="flex items-center justify-between text-[11px] font-bold">
                    <span className="text-purple-300">{t.tokenHmac}</span>
                    <button
                      onClick={() => setTokenInput(t.tokenHmac)}
                      className="text-[10px] text-amber-400 hover:underline"
                    >
                      Use in Scanner &rarr;
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* Right Side: Consumer Mobile Scan Portal Simulator */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center font-mono">
          <div className="w-full max-w-sm bg-slate-950 border-4 border-slate-800 rounded-3xl p-5 shadow-2xl space-y-5 relative">
            
            {/* Mobile Header */}
            <div className="text-center border-b border-slate-800 pb-3">
              <div className="text-[10px] text-purple-400 font-bold uppercase tracking-widest flex items-center justify-center gap-1">
                <Smartphone className="w-3.5 h-3.5" />
                <span>CRISPOS Consumer Portal</span>
              </div>
              <h4 className="text-base font-bold text-white mt-1">Golden Ticket Scanner</h4>
              <p className="text-[10px] text-slate-400">Scan QR or enter printed code inside bag</p>
            </div>

            {/* Quick Helper Sample Codes */}
            <div className="p-2.5 bg-slate-900/80 border border-slate-800 rounded-lg text-[10px] text-slate-300 space-y-1">
              <span className="text-slate-400 block font-bold">CLICK TO QUICK-TEST SAMPLE CODES:</span>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setTokenInput('GT-8841')}
                  className="px-2 py-0.5 bg-purple-500/20 text-purple-300 rounded hover:bg-purple-500/40 border border-purple-500/30"
                >
                  GT-8841 (£100k Winner!)
                </button>
                <button
                  onClick={() => setTokenInput('GT-8842')}
                  className="px-2 py-0.5 bg-amber-500/20 text-amber-300 rounded hover:bg-amber-500/40 border border-amber-500/30"
                >
                  GT-8842 (£2.5k)
                </button>
                <button
                  onClick={() => setTokenInput('GT-STD-1')}
                  className="px-2 py-0.5 bg-slate-800 text-slate-300 rounded hover:bg-slate-700"
                >
                  GT-STD-1 (Standard)
                </button>
              </div>
            </div>

            {/* Token Code Input Form */}
            <form onSubmit={handleVerify} className="space-y-3">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Packet Code Token</label>
                <div className="relative">
                  <QrCode className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={tokenInput}
                    onChange={e => setTokenInput(e.target.value.toUpperCase())}
                    placeholder="e.g. GT-8841"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-9 pr-3 py-2.5 text-amber-400 font-bold text-sm tracking-wider focus:outline-none focus:border-purple-500 uppercase"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 block mb-1">Consumer Scan Location</label>
                <input
                  type="text"
                  value={userLocation}
                  onChange={e => setUserLocation(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-amber-500 hover:from-purple-500 hover:to-amber-400 text-slate-950 font-black rounded-lg text-xs uppercase tracking-wider transition-all shadow-lg shadow-purple-500/20 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <span>Verifying Ledger...</span>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Claim & Verify Ticket</span>
                  </>
                )}
              </button>
            </form>

            {/* Result Display Box */}
            {result && (
              <div
                className={`p-4 rounded-xl border space-y-2 text-xs animate-fadeIn ${
                  result.status === 'SUCCESS_WINNER'
                    ? 'bg-amber-950/40 border-amber-500/60 text-amber-200'
                    : result.status === 'SUCCESS_NON_WINNER'
                    ? 'bg-purple-950/40 border-purple-500/60 text-purple-200'
                    : 'bg-red-950/40 border-red-500/60 text-red-200'
                }`}
              >
                <div className="font-bold flex items-center gap-1.5 text-sm">
                  {result.status === 'SUCCESS_WINNER' ? (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>WINNING GOLDEN TICKET!</span>
                    </>
                  ) : result.status === 'SUCCESS_NON_WINNER' ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-purple-400" />
                      <span>Authentic Crisp Packet</span>
                    </>
                  ) : (
                    <>
                      <AlertCircle className="w-4 h-4 text-red-400" />
                      <span>Redemption Status</span>
                    </>
                  )}
                </div>

                <p className="text-[11px] leading-relaxed">{result.message}</p>

                {result.txHash && (
                  <div className="pt-2 border-t border-slate-800 text-[9px] text-slate-400 truncate">
                    Ledger Tx Hash: <span className="text-purple-300 font-mono">{result.txHash}</span>
                  </div>
                )}
              </div>
            )}

          </div>
        </div>

      </div>

    </div>
  );
};
