import React, { useState } from 'react';
import {
  Truck,
  Scale,
  PlusCircle,
  Thermometer,
  Wind,
  ShieldCheck,
  AlertTriangle,
  Database,
  CheckCircle2,
  Droplet
} from 'lucide-react';
import { PotatoLot, StorageBin } from '../../types';

interface ReceivingModuleProps {
  lots: PotatoLot[];
  bins: StorageBin[];
  onAddLot: (lot: Partial<PotatoLot>) => void;
}

export const ReceivingModule: React.FC<ReceivingModuleProps> = ({
  lots,
  bins,
  onAddLot
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [grossWeight, setGrossWeight] = useState<number>(34.5);
  const [tareWeight, setTareWeight] = useState<number>(4.2);
  const [dryMatter, setDryMatter] = useState<number>(23.8);
  const [reducingSugar, setReducingSugar] = useState<number>(0.09);
  const [dirtPercent, setDirtPercent] = useState<number>(3.2);
  const [defectsPercent, setDefectsPercent] = useState<number>(1.4);
  const [variety, setVariety] = useState<any>('Lady Rosetta');
  const [assignedBin, setAssignedBin] = useState<string>('CELL-A4');

  const netWeight = +(grossWeight - tareWeight).toFixed(1);

  const handleSubmitNewLot = (e: React.FormEvent) => {
    e.preventDefault();
    onAddLot({
      variety,
      grossWeightTonnes: grossWeight,
      netWeightTonnes: netWeight,
      dryMatterPercent: dryMatter,
      reducingSugarsPercent: reducingSugar,
      dirtStonesPercent: dirtPercent,
      defectsPercent,
      assignedStorageBin: assignedBin,
      costPerRawTonne: 195
    });
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 bg-slate-900 p-5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs font-mono font-bold uppercase">
            <Truck className="w-4 h-4" />
            <span>Raw Potato Receiving & Storage</span>
          </div>
          <h2 className="text-xl font-bold text-white tracking-tight mt-1">
            Weighbridge Quality Testing & Controlled Atmosphere Storage
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Perform gross/net weighments, core sampling tests (dry matter, reducing sugar, defect % ground rot), and assign FEFO storage cells.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-bold flex items-center gap-2 transition-all shadow-md"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Receive Inbound Potato Truck</span>
        </button>
      </div>

      {/* Storage Bins Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center justify-between">
          <span>Controlled Atmosphere Potato Storage Bins</span>
          <span className="text-xs font-mono text-emerald-400">4 STORAGE CELLS ACTIVE</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {bins.map(bin => {
            const isFull = bin.currentWeightTonnes > 0;
            return (
              <div
                key={bin.id}
                className={`p-4 rounded-xl border transition-all ${
                  isFull
                    ? 'bg-slate-800/80 border-slate-700'
                    : 'bg-slate-900/60 border-slate-800 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between font-mono">
                  <span className="font-bold text-sm text-white">{bin.code}</span>
                  <span
                    className={`px-2 py-0.5 text-[10px] rounded font-bold ${
                      bin.ventilationStatus === 'ACTIVE'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : bin.ventilationStatus === 'COOLING'
                        ? 'bg-sky-500/20 text-sky-400'
                        : 'bg-slate-700 text-slate-400'
                    }`}
                  >
                    {bin.ventilationStatus}
                  </span>
                </div>

                <div className="mt-3 space-y-2 font-mono text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px] block">CURRENT LOT</span>
                    <span className="font-bold text-amber-400">
                      {bin.currentLotNumber || 'EMPTY CELL'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-2 border-t border-slate-700/60">
                    <div>
                      <span className="text-slate-500 block text-[9px]">TONNES</span>
                      <span className="text-slate-200 font-bold">{bin.currentWeightTonnes} t</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">TEMP</span>
                      <span className="text-sky-400 font-bold">{bin.temperatureCelsius} °C</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">HUMIDITY</span>
                      <span className="text-slate-300 font-bold">{bin.humidityPercent}%</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block text-[9px]">CO₂ LEVEL</span>
                      <span className="text-slate-300 font-bold">{bin.co2Ppm} ppm</span>
                    </div>
                  </div>

                  {/* Spoilage Risk meter */}
                  {isFull && (
                    <div>
                      <div className="flex justify-between text-[10px] text-slate-400 mb-1">
                        <span>Spoilage Risk Index:</span>
                        <span className="text-emerald-400 font-bold">{bin.spoilageRiskScore}%</span>
                      </div>
                      <div className="w-full bg-slate-700 h-1 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-500 h-full rounded-full"
                          style={{ width: `${bin.spoilageRiskScore}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Inbound Potato Lots Inventory Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white">Inbound Potato Lots Inventory</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-slate-300">
            <thead className="bg-slate-800/80 text-slate-400 text-[10px] uppercase">
              <tr>
                <th className="p-3">Lot Number</th>
                <th className="p-3">Variety</th>
                <th className="p-3">Farm / Grower</th>
                <th className="p-3">Net Weight</th>
                <th className="p-3">Dry Matter</th>
                <th className="p-3">Reducing Sugar</th>
                <th className="p-3">Defects</th>
                <th className="p-3">Quality Score</th>
                <th className="p-3">Frying Suitability</th>
                <th className="p-3">Storage Bin</th>
                <th className="p-3">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {lots.map(lot => (
                <tr key={lot.id} className="hover:bg-slate-800/40">
                  <td className="p-3 font-bold text-amber-400">{lot.lotNumber}</td>
                  <td className="p-3 font-bold text-white">{lot.variety}</td>
                  <td className="p-3">{lot.farmName}</td>
                  <td className="p-3 font-bold">{lot.netWeightTonnes} t</td>
                  <td className="p-3 text-sky-400 font-bold">{lot.dryMatterPercent}%</td>
                  <td className="p-3 text-amber-400 font-bold">{lot.reducingSugarsPercent}%</td>
                  <td className="p-3">{lot.defectsPercent}%</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                      {lot.qualityScore} / 100
                    </span>
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-bold text-[10px]">
                      {lot.fryingSuitability}
                    </span>
                  </td>
                  <td className="p-3 font-bold text-slate-200">{lot.assignedStorageBin || 'UNASSIGNED'}</td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                      {lot.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Receive Inbound Truck */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 max-w-lg w-full space-y-4 font-mono">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white">Weighbridge Inbound Receiving Workflow</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-white">✕</button>
            </div>

            <form onSubmit={handleSubmitNewLot} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Variety</label>
                  <select
                    value={variety}
                    onChange={e => setVariety(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                  >
                    <option value="Lady Rosetta">Lady Rosetta</option>
                    <option value="Atlantic">Atlantic</option>
                    <option value="Hermes">Hermes</option>
                    <option value="Taurus">Taurus</option>
                  </select>
                </div>

                <div>
                  <label className="text-slate-400 block mb-1">Target Cell Storage</label>
                  <select
                    value={assignedBin}
                    onChange={e => setAssignedBin(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                  >
                    {bins.map(b => (
                      <option key={b.id} value={b.code}>{b.code} ({b.currentLotNumber ? 'Occupied' : 'Available'})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Gross Wt (t)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={grossWeight}
                    onChange={e => setGrossWeight(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Tare Wt (t)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={tareWeight}
                    onChange={e => setTareWeight(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Net Weight</label>
                  <input
                    type="text"
                    disabled
                    value={`${netWeight} t`}
                    className="w-full bg-slate-900 border border-slate-800 rounded p-2 text-amber-400 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                <div>
                  <label className="text-slate-400 block mb-1">Dry Matter (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={dryMatter}
                    onChange={e => setDryMatter(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-sky-400 font-bold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Reducing Sugar (%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={reducingSugar}
                    onChange={e => setReducingSugar(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-amber-400 font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Dirt / Stones Tare (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={dirtPercent}
                    onChange={e => setDirtPercent(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Defects (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    value={defectsPercent}
                    onChange={e => setDefectsPercent(Number(e.target.value))}
                    className="w-full bg-slate-800 border border-slate-700 rounded p-2 text-white"
                  />
                </div>
              </div>

              <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded text-emerald-300 text-[11px]">
                Quality Inspection Auto-Evaluation: <span className="font-bold">PREMIUM ACCEPT</span> (Score: 96/100)
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-800 text-slate-300 rounded hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-500 text-slate-950 font-bold rounded hover:bg-amber-400"
                >
                  Confirm & Release to Cell
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
