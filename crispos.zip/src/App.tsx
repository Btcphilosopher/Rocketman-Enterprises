import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ExecutiveDashboard } from './components/dashboard/ExecutiveDashboard';
import { AgricultureModule } from './components/agriculture/AgricultureModule';
import { ReceivingModule } from './components/receiving/ReceivingModule';
import { FactoryMesModule } from './components/mes/FactoryMesModule';
import { OilManagementModule } from './components/oil/OilManagementModule';
import { QualityVisionModule } from './components/qms/QualityVisionModule';
import { TraceabilityModule } from './components/traceability/TraceabilityModule';
import { LogisticsModule } from './components/wms_tms/LogisticsModule';
import { GoldenTicketModule } from './components/golden_ticket/GoldenTicketModule';
import { RAnalyticsWorkbench } from './components/r_workbench/RAnalyticsWorkbench';
import { VerticalSliceSimulator } from './components/simulator/VerticalSliceSimulator';
import {
  fetchDashboardSummary,
  fetchAgricultureData,
  fetchPotatoLots,
  createPotatoLot,
  fetchStorageBins,
  fetchMesLines,
  fetchOilBatches,
  fetchQmsLogs,
  runVerticalSliceSimulation
} from './services/api';
import { PotatoLot, StorageBin, ProductionLine, ProductionBatch, FryingOilBatch, CcpLog, OpticalInspectionEvent, PotatoSpecification, Farm } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [summary, setSummary] = useState<any>(null);
  const [farms, setFarms] = useState<Farm[]>([]);
  const [specs, setSpecs] = useState<PotatoSpecification[]>([]);
  const [lots, setLots] = useState<PotatoLot[]>([]);
  const [bins, setBins] = useState<StorageBin[]>([]);
  const [lines, setLines] = useState<ProductionLine[]>([]);
  const [batches, setBatches] = useState<ProductionBatch[]>([]);
  const [oilBatches, setOilBatches] = useState<FryingOilBatch[]>([]);
  const [ccpLogs, setCcpLogs] = useState<CcpLog[]>([]);
  const [visionEvents, setVisionEvents] = useState<OpticalInspectionEvent[]>([]);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  const loadData = async () => {
    try {
      const [sumRes, agriRes, lotsRes, binsRes, mesRes, oilRes, qmsRes] = await Promise.all([
        fetchDashboardSummary(),
        fetchAgricultureData(),
        fetchPotatoLots(),
        fetchStorageBins(),
        fetchMesLines(),
        fetchOilBatches(),
        fetchQmsLogs()
      ]);

      setSummary(sumRes);
      setFarms(agriRes.farms || []);
      setSpecs(agriRes.specifications || []);
      setLots(lotsRes.lots || []);
      setBins(binsRes.bins || []);
      setLines(mesRes.lines || []);
      setBatches(mesRes.batches || []);
      setOilBatches(oilRes.oilBatches || []);
      setCcpLogs(qmsRes.ccpLogs || []);
      setVisionEvents(qmsRes.visionEvents || []);
    } catch (err) {
      console.error('Error loading CRISPOS operational state:', err);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleAddLot = async (lotData: Partial<PotatoLot>) => {
    try {
      await createPotatoLot(lotData);
      await loadData();
    } catch (err) {
      console.error(err);
    }
  };

  const handleRunSimulation = async () => {
    setIsSimulating(true);
    try {
      await runVerticalSliceSimulation();
      await loadData();
      setActiveTab('simulator');
    } catch (err) {
      console.error(err);
    } finally {
      setIsSimulating(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      
      {/* Global Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onRunSimulation={handleRunSimulation}
        isSimulating={isSimulating}
      />

      {/* Main Container Layout */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex flex-col lg:flex-row">
        
        {/* Sidebar Navigation */}
        <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Content Body Area */}
        <main className="flex-1 p-4 sm:p-6 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <ExecutiveDashboard
              summary={summary}
              lines={lines}
              onNavigate={setActiveTab}
              onRunSimulation={handleRunSimulation}
            />
          )}

          {activeTab === 'agriculture' && (
            <AgricultureModule farms={farms} specifications={specs} />
          )}

          {activeTab === 'receiving' && (
            <ReceivingModule lots={lots} bins={bins} onAddLot={handleAddLot} />
          )}

          {activeTab === 'mes' && (
            <FactoryMesModule lines={lines} batches={batches} />
          )}

          {activeTab === 'oil' && (
            <OilManagementModule oilBatches={oilBatches} />
          )}

          {activeTab === 'qms' && (
            <QualityVisionModule ccpLogs={ccpLogs} visionEvents={visionEvents} />
          )}

          {activeTab === 'traceability' && (
            <TraceabilityModule />
          )}

          {activeTab === 'logistics' && (
            <LogisticsModule />
          )}

          {activeTab === 'golden-ticket' && (
            <GoldenTicketModule />
          )}

          {activeTab === 'r-workbench' && (
            <RAnalyticsWorkbench />
          )}

          {activeTab === 'simulator' && (
            <VerticalSliceSimulator />
          )}
        </main>

      </div>

    </div>
  );
}
