import {
  PotatoLot,
  GoldenTicketRedemptionResult,
  RScriptExecutionRequest,
  RScriptExecutionResult
} from '../types';

export async function fetchHealth() {
  const res = await fetch('/api/health');
  return res.json();
}

export async function fetchDashboardSummary() {
  const res = await fetch('/api/dashboard/summary');
  return res.json();
}

export async function fetchAgricultureData() {
  const res = await fetch('/api/agriculture/farms');
  return res.json();
}

export async function fetchPotatoLots() {
  const res = await fetch('/api/agriculture/lots');
  return res.json();
}

export async function createPotatoLot(lotData: Partial<PotatoLot>) {
  const res = await fetch('/api/agriculture/lots', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(lotData)
  });
  return res.json();
}

export async function fetchStorageBins() {
  const res = await fetch('/api/storage/bins');
  return res.json();
}

export async function fetchMesLines() {
  const res = await fetch('/api/mes/lines');
  return res.json();
}

export async function fetchOilBatches() {
  const res = await fetch('/api/oil/batches');
  return res.json();
}

export async function fetchQmsLogs() {
  const res = await fetch('/api/qms/ccp-logs');
  return res.json();
}

export async function fetchTraceability(query: string) {
  const res = await fetch(`/api/traceability/query?q=${encodeURIComponent(query)}`);
  return res.json();
}

export async function verifyGoldenTicket(tokenHmac: string, userLocation?: string): Promise<GoldenTicketRedemptionResult> {
  const res = await fetch('/api/golden-ticket/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tokenHmac, userLocation })
  });
  return res.json();
}

export async function issueGoldenTickets(campaignId: string, batchNumber: string, count: number = 5) {
  const res = await fetch('/api/golden-ticket/issue', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ campaignId, batchNumber, count })
  });
  return res.json();
}

export async function executeRModel(req: RScriptExecutionRequest): Promise<RScriptExecutionResult> {
  const res = await fetch('/api/r-analytics/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(req)
  });
  return res.json();
}

export async function runVerticalSliceSimulation() {
  const res = await fetch('/api/simulation/run-slice', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' }
  });
  return res.json();
}
