import express from 'express';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import {
  FARMS,
  FIELDS,
  INITIAL_POTATO_LOTS,
  STORAGE_BINS,
  RECIPES,
  FRYING_OIL_BATCHES,
  PRODUCTION_LINES,
  INITIAL_BATCHES,
  CAMPAIGNS,
  INITIAL_CCP_LOGS,
  INITIAL_VISION_EVENTS,
  POTATO_SPECS
} from './src/data/mockData';
import {
  PotatoLot,
  GoldenTicket,
  GoldenTicketRedemptionResult,
  RScriptExecutionRequest,
  RScriptExecutionResult,
  TraceabilityNode
} from './src/types';

const SECRET_HMAC_KEY = process.env.GOLDEN_TICKET_SECRET || 'CRISPOS_HMAC_SECRET_2026_GOLDEN_TICKET_KEY_8812';

// Operational Database State (In-Memory transactional store)
let dbLots = [...INITIAL_POTATO_LOTS];
let dbBins = [...STORAGE_BINS];
let dbBatches = [...INITIAL_BATCHES];
let dbOilBatches = [...FRYING_OIL_BATCHES];
let dbLines = [...PRODUCTION_LINES];
let dbCcpLogs = [...INITIAL_CCP_LOGS];
let dbVisionEvents = [...INITIAL_VISION_EVENTS];
let dbCampaigns = [...CAMPAIGNS];

// Golden Tickets Ledger
let dbTickets: Map<string, GoldenTicket> = new Map();
let ledgerEvents: Array<{
  txHash: string;
  blockNumber: number;
  timestamp: string;
  eventType: 'TICKET_ISSUED' | 'TICKET_REDEEMED' | 'FRAUD_ALERT_RAISED';
  tokenHmac: string;
  details: string;
}> = [];

// Helper to calculate cryptographic Golden Ticket HMAC token
function generateTicketToken(campaignId: string, batchNumber: string, ticketNumber: number, salt: string): string {
  const data = `${campaignId}:${batchNumber}:${ticketNumber}:${salt}`;
  return 'GT-' + crypto.createHmac('sha256', SECRET_HMAC_KEY).update(data).digest('hex').substring(0, 16).toUpperCase();
}

// Seed initial Golden Tickets for current production batches
function seedInitialTickets() {
  const sampleBatch = dbBatches[0];
  const campaign = dbCampaigns[0];
  
  // Seed a grand winning ticket, a few tier prizes, and standard thank-you tickets
  const winningTokens = [
    { num: 8841, prizeClass: 'GRAND_PRIZE_100K' as const, amount: 100000, winner: true },
    { num: 8842, prizeClass: 'TIER_2_2500' as const, amount: 2500, winner: true },
    { num: 8843, prizeClass: 'TIER_3_100' as const, amount: 100, winner: true },
    { num: 8844, prizeClass: 'TIER_4_10' as const, amount: 10, winner: true },
  ];

  winningTokens.forEach(item => {
    const token = generateTicketToken(campaign.id, sampleBatch.batchNumber, item.num, 'SEED_SALT_WIN');
    const ticket: GoldenTicket = {
      id: `TICK-${item.num}`,
      tokenHmac: token,
      campaignId: campaign.id,
      batchNumber: sampleBatch.batchNumber,
      sku: sampleBatch.sku,
      prizeClass: item.prizeClass,
      prizeAmountGbp: item.amount,
      isWinner: item.winner,
      isRedeemed: false
    };
    dbTickets.set(token, ticket);
  });

  // Seed sample non-winning tickets
  for (let i = 1; i <= 50; i++) {
    const token = generateTicketToken(campaign.id, sampleBatch.batchNumber, i + 100, `SALT_${i}`);
    const ticket: GoldenTicket = {
      id: `TICK-STD-${i}`,
      tokenHmac: token,
      campaignId: campaign.id,
      batchNumber: sampleBatch.batchNumber,
      sku: sampleBatch.sku,
      prizeClass: 'THANK_YOU_TRY_AGAIN',
      prizeAmountGbp: 0,
      isWinner: false,
      isRedeemed: false
    };
    dbTickets.set(token, ticket);
  }
}

seedInitialTickets();

async function startServer() {
  const app = express();
  app.use(express.json());
  const PORT = 3000;

  // API Routes
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      systemName: 'CRISPOS - Potato Crisp Manufacturing OS',
      rustEngine: 'Active (Async Event Processor & Cryptographic Ledger)',
      rAnalyticsEngine: 'Active (R Statistical Computing Core 4.3.2)',
      timestamp: new Date().toISOString()
    });
  });

  app.get('/api/dashboard/summary', (req, res) => {
    const totalProductionTonnesToday = 842.5;
    const avgOee = (dbLines.reduce((acc, l) => acc + l.oeePercent, 0) / dbLines.length).toFixed(1);
    const avgYield = (dbLines.reduce((acc, l) => acc + l.currentYieldPercent, 0) / dbLines.length).toFixed(1);
    const wastePercent = 2.15;
    const totalInventoryValueGbp = 31450000;
    const otifDeliveryRate = 97.4;
    const forecastAccuracy = 92.1;

    res.json({
      productionTonnesToday: totalProductionTonnesToday,
      oeePercent: parseFloat(avgOee),
      yieldPercent: parseFloat(avgYield),
      wastePercent,
      inventoryValueGbp: totalInventoryValueGbp,
      otifDeliveryRate,
      forecastAccuracy,
      activeFarmsCount: FARMS.length,
      activeLotsCount: dbLots.length,
      storageBinsCount: dbBins.length,
      activeLinesCount: dbLines.length,
      ccpComplianceRate: 100.0,
      goldenTicketsRedeemed: dbCampaigns[0].totalRedeemed,
      goldenTicketsTotal: dbCampaigns[0].totalTicketsGenerated
    });
  });

  app.get('/api/agriculture/farms', (req, res) => {
    res.json({ farms: FARMS, fields: FIELDS, specifications: POTATO_SPECS });
  });

  app.get('/api/agriculture/lots', (req, res) => {
    res.json({ lots: dbLots });
  });

  app.post('/api/agriculture/lots', (req, res) => {
    const newLotData = req.body;
    const id = `LOT-P2026-${Date.now().toString().slice(-6)}`;
    const newLot: PotatoLot = {
      id,
      lotNumber: newLotData.lotNumber || `P2026-${Math.floor(1000 + Math.random() * 9000)}`,
      farmId: newLotData.farmId || FARMS[0].id,
      farmName: newLotData.farmName || FARMS[0].name,
      growerName: newLotData.growerName || FARMS[0].growerName,
      fieldId: newLotData.fieldId || FIELDS[0].id,
      variety: newLotData.variety || 'Lady Rosetta',
      harvestDate: newLotData.harvestDate || new Date().toISOString().split('T')[0],
      grossWeightTonnes: Number(newLotData.grossWeightTonnes) || 30.0,
      netWeightTonnes: Number(newLotData.netWeightTonnes) || 27.5,
      dryMatterPercent: Number(newLotData.dryMatterPercent) || 23.5,
      specificGravity: Number(newLotData.specificGravity) || 1.090,
      reducingSugarsPercent: Number(newLotData.reducingSugarsPercent) || 0.09,
      defectsPercent: Number(newLotData.defectsPercent) || 1.5,
      foreignMaterialPercent: Number(newLotData.foreignMaterialPercent) || 0.2,
      dirtStonesPercent: Number(newLotData.dirtStonesPercent) || 3.0,
      temperatureCelsius: Number(newLotData.temperatureCelsius) || 9.0,
      fryingSuitability: 'PREMIUM',
      status: 'STORED',
      assignedStorageBin: newLotData.assignedStorageBin || 'CELL-A4',
      qualityScore: 95,
      costPerRawTonne: Number(newLotData.costPerRawTonne) || 190,
      calculatedCostPerFinishedTonne: 605
    };

    dbLots.unshift(newLot);

    // Update designated bin
    const targetBin = dbBins.find(b => b.code === newLot.assignedStorageBin);
    if (targetBin) {
      targetBin.currentLotId = newLot.id;
      targetBin.currentLotNumber = newLot.lotNumber;
      targetBin.currentWeightTonnes = newLot.netWeightTonnes;
      targetBin.ventilationStatus = 'ACTIVE';
    }

    res.status(201).json({ success: true, lot: newLot });
  });

  app.get('/api/storage/bins', (req, res) => {
    res.json({ bins: dbBins });
  });

  app.get('/api/mes/lines', (req, res) => {
    res.json({ lines: dbLines, recipes: RECIPES, batches: dbBatches });
  });

  app.get('/api/oil/batches', (req, res) => {
    res.json({ oilBatches: dbOilBatches });
  });

  app.get('/api/qms/ccp-logs', (req, res) => {
    res.json({ ccpLogs: dbCcpLogs, visionEvents: dbVisionEvents });
  });

  // Fast 2-Way Traceability Query
  app.get('/api/traceability/query', (req, res) => {
    const query = (req.query.q as string || '').toUpperCase().trim();
    
    // Find matching lot, batch, or ticket token
    const matchedLot = dbLots.find(l => l.lotNumber.toUpperCase().includes(query) || l.id.toUpperCase().includes(query));
    const matchedBatch = dbBatches.find(b => b.batchNumber.toUpperCase().includes(query) || b.id.toUpperCase().includes(query));
    const matchedTicket = Array.from(dbTickets.values()).find(t => t.tokenHmac.toUpperCase().includes(query));

    let lot = matchedLot || (matchedBatch ? dbLots.find(l => l.id === matchedBatch.potatoLotId) : dbLots[0]);
    let batch = matchedBatch || (matchedLot ? dbBatches.find(b => b.potatoLotId === matchedLot.id) : dbBatches[0]);

    if (!lot) lot = dbLots[0];
    if (!batch) batch = dbBatches[0];

    const farm = FARMS.find(f => f.id === lot.farmId) || FARMS[0];
    const field = FIELDS.find(f => f.id === lot.fieldId) || FIELDS[0];
    const oil = dbOilBatches.find(o => o.id === batch.oilBatchId) || dbOilBatches[0];

    const rootNode: TraceabilityNode = {
      type: 'FARM',
      id: farm.id,
      label: farm.name,
      details: {
        Grower: farm.growerName,
        Region: farm.region,
        SoilType: farm.soilType,
        Rating: farm.sustainabilityRating
      },
      children: [
        {
          type: 'FIELD',
          id: field.id,
          label: field.fieldName,
          details: {
            Variety: field.variety,
            PlantingDate: field.plantingDate,
            HarvestDate: field.expectedHarvestDate
          },
          children: [
            {
              type: 'HARVEST_LOT',
              id: lot.id,
              label: `Lot ${lot.lotNumber}`,
              details: {
                NetWeight: `${lot.netWeightTonnes} t`,
                DryMatter: `${lot.dryMatterPercent}%`,
                ReducingSugar: `${lot.reducingSugarsPercent}%`,
                FryingQuality: lot.fryingSuitability
              },
              children: [
                {
                  type: 'STORAGE_BIN',
                  id: lot.assignedStorageBin || 'CELL-A1',
                  label: `Storage ${lot.assignedStorageBin || 'CELL-A1'}`,
                  details: {
                    StorageTemp: '8.5 °C',
                    Humidity: '95%',
                    Ventilation: 'ACTIVE'
                  },
                  children: [
                    {
                      type: 'FRYING_BATCH',
                      id: batch.id,
                      label: `Batch ${batch.batchNumber}`,
                      details: {
                        Line: batch.lineId,
                        SKU: batch.sku,
                        OilBatch: oil.lotNumber,
                        SeasoningLot: batch.seasoningBatchLot,
                        PackCount: batch.completedQuantityPacks
                      },
                      children: [
                        {
                          type: 'SKU_PACK',
                          id: batch.sku,
                          label: batch.productName,
                          details: {
                            TargetWeight: '150g',
                            NitrogenMAP: '98.5% N₂',
                            OpticalPass: '99.8%'
                          },
                          children: [
                            {
                              type: 'PALLET',
                              id: `PALLET-${batch.batchNumber.slice(-4)}-01`,
                              label: 'Pallet PLT-88201',
                              details: {
                                Cases: 40,
                                PacksPerCase: 24,
                                WarehouseBin: 'RACK-B-12'
                              },
                              children: [
                                {
                                  type: 'GOLDEN_TICKET',
                                  id: matchedTicket ? matchedTicket.tokenHmac : 'GT-7A2F8B9C0D1E',
                                  label: 'Golden Ticket Cryptographic Token',
                                  details: {
                                    TokenHMAC: matchedTicket ? matchedTicket.tokenHmac : 'GT-7A2F8B9C0D1E',
                                    Campaign: 'Summer Golden Ticket',
                                    Status: matchedTicket?.isRedeemed ? 'REDEEMED' : 'UNCLAIMED'
                                  }
                                }
                              ]
                            }
                          ]
                        }
                      ]
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    };

    res.json({ searchKey: query, traceabilityTree: rootNode });
  });

  // Issue Golden Ticket Token
  app.post('/api/golden-ticket/issue', (req, res) => {
    const { campaignId, batchNumber, count = 10 } = req.body;
    const campaign = dbCampaigns.find(c => c.id === campaignId) || dbCampaigns[0];
    const createdTokens: GoldenTicket[] = [];

    for (let i = 0; i < count; i++) {
      const ticketNum = Math.floor(100000 + Math.random() * 900000);
      const salt = crypto.randomBytes(8).toString('hex');
      const token = generateTicketToken(campaign.id, batchNumber, ticketNum, salt);

      const isWinning = Math.random() < 0.05; // 5% win chance in demo
      const prizeClass = isWinning ? 'TIER_4_10' : 'THANK_YOU_TRY_AGAIN';
      const prizeAmountGbp = isWinning ? 10 : 0;

      const ticket: GoldenTicket = {
        id: `TICK-${ticketNum}`,
        tokenHmac: token,
        campaignId: campaign.id,
        batchNumber: batchNumber || 'BAT-20260816-01',
        sku: 'CRISP-SAL-150G',
        prizeClass,
        prizeAmountGbp,
        isWinner: isWinning,
        isRedeemed: false
      };

      dbTickets.set(token, ticket);
      createdTokens.push(ticket);
    }

    campaign.totalTicketsGenerated += count;

    res.json({
      success: true,
      count: createdTokens.length,
      sampleTokens: createdTokens.map(t => ({ tokenHmac: t.tokenHmac, isWinner: t.isWinner, prizeAmountGbp: t.prizeAmountGbp }))
    });
  });

  // Verify and Redeem Golden Ticket
  app.post('/api/golden-ticket/verify', (req, res) => {
    const { tokenHmac, userLocation = 'London, UK' } = req.body;
    const tokenKey = (tokenHmac || '').trim().toUpperCase();

    const ticket = dbTickets.get(tokenKey);

    if (!ticket) {
      return res.status(404).json({
        tokenHmac: tokenKey,
        isValid: false,
        status: 'INVALID_TOKEN',
        message: 'Invalid or unrecognized Golden Ticket code. Please double-check the printed code inside your crisp packet.',
        fraudRiskScore: 15,
        geoAnomalyDetected: false
      } as GoldenTicketRedemptionResult);
    }

    if (ticket.isRedeemed) {
      return res.status(400).json({
        tokenHmac: tokenKey,
        isValid: true,
        status: 'ALREADY_REDEEMED',
        ticketDetails: ticket,
        message: `This Golden Ticket was already claimed on ${ticket.redemptionTimestamp || 'earlier today'}.`,
        fraudRiskScore: 45,
        geoAnomalyDetected: false
      } as GoldenTicketRedemptionResult);
    }

    // Mark redeemed
    ticket.isRedeemed = true;
    ticket.redemptionTimestamp = new Date().toISOString();
    ticket.redeemedByLocation = userLocation;

    // Create Immutable Ledger Block Event
    const txHash = '0x' + crypto.createHash('sha256').update(`${tokenKey}:${Date.now()}`).digest('hex');
    ledgerEvents.unshift({
      txHash,
      blockNumber: 184200 + ledgerEvents.length,
      timestamp: new Date().toISOString(),
      eventType: 'TICKET_REDEEMED',
      tokenHmac: tokenKey,
      details: `Redeemed via Consumer Portal at ${userLocation}. Prize: £${ticket.prizeAmountGbp}`
    });

    const campaign = dbCampaigns.find(c => c.id === ticket.campaignId);
    if (campaign) {
      campaign.totalRedeemed += 1;
    }

    const result: GoldenTicketRedemptionResult = {
      tokenHmac: tokenKey,
      isValid: true,
      status: ticket.isWinner ? 'SUCCESS_WINNER' : 'SUCCESS_NON_WINNER',
      ticketDetails: ticket,
      message: ticket.isWinner
        ? `CONGRATULATIONS! You won £${ticket.prizeAmountGbp} in the CRISPOS Golden Ticket Campaign!`
        : `Thank you for choosing CRISPOS Crisps! While this packet was not a cash winner, your code is verified authentic.`,
      txHash,
      fraudRiskScore: 2,
      geoAnomalyDetected: false
    };

    res.json(result);
  });

  // R Statistical Analytics Engine API
  app.post('/api/r-analytics/execute', (req, res) => {
    const { modelType, parameters } = req.body as RScriptExecutionRequest;

    let result: RScriptExecutionResult;

    if (modelType === 'CROP_YIELD_REGRESSION') {
      result = {
        modelType: 'CROP_YIELD_REGRESSION',
        executedAt: new Date().toISOString(),
        rVersionInfo: 'R version 4.3.2 (2023-10-31) -- "Eye Holes"',
        summaryText: 'Multivariate linear regression model linking Soil Nitrogen, Irrigation (mm), Temperature Degree Days, and Dry Matter % to Expected Crisp Yield per Hectare.',
        chartData: [
          { soilN: 80, actualYield: 32.4, predictedYield: 31.8, dryMatter: 22.1 },
          { soilN: 100, actualYield: 36.8, predictedYield: 36.2, dryMatter: 23.2 },
          { soilN: 120, actualYield: 41.2, predictedYield: 40.9, dryMatter: 23.8 },
          { soilN: 140, actualYield: 44.5, predictedYield: 44.1, dryMatter: 24.1 },
          { soilN: 160, actualYield: 45.8, predictedYield: 46.2, dryMatter: 24.4 },
          { soilN: 180, actualYield: 46.1, predictedYield: 46.8, dryMatter: 24.0 }
        ],
        metrics: {
          R_Squared: 0.968,
          Adjusted_R2: 0.959,
          Residual_SE: 0.84,
          F_Statistic: 142.8,
          p_value: '< 0.0001'
        },
        codeSnippet: `# R Script: Potato Crop Yield & Dry Matter Regression
library(stats)
fit <- lm(crisp_yield ~ soil_n + irrigation + degree_days + dry_matter_pct, data = harvest_data)
summary(fit)
predict(fit, newdata = scenario_params, interval = "confidence")`
      };
    } else if (modelType === 'OIL_DEGRADATION_KINETICS') {
      result = {
        modelType: 'OIL_DEGRADATION_KINETICS',
        executedAt: new Date().toISOString(),
        rVersionInfo: 'R version 4.3.2 (2023-10-31) -- "Eye Holes"',
        summaryText: 'First-order thermal reaction kinetics model predicting Free Fatty Acid (FFA %) accumulation and Total Polar Compounds (TPC %) degradation over continuous frying hours.',
        chartData: Array.from({ length: 12 }, (_, i) => {
          const hours = i * 10;
          const ffa = +(0.15 + 0.008 * hours + 0.00005 * Math.pow(hours, 2)).toFixed(2);
          const tpc = +(4.0 + 0.18 * hours + 0.001 * Math.pow(hours, 2)).toFixed(2);
          return { hours, ffa, tpc, ffaLimit: 1.0, tpcLimit: 24.0 };
        }),
        metrics: {
          KineticRateConst_k: '0.0084 hrs^-1',
          HalfLife_t50: '82.4 hours',
          PredictedHoursToLimit: '114.5 hours',
          RecommendedReplenishRate: '120 L/hour'
        },
        codeSnippet: `# R Script: Frying Oil Thermal Degradation Reaction Kinetics
library(deSolve)
oil_kinetics <- function(t, state, parms) {
  with(as.list(c(state, parms)), {
    dFFA <- k_ffa * temp_coef * (1 - FFA/FFA_max)
    dTPC <- k_tpc * temp_coef * (1 - TPC/TPC_max)
    return(list(c(dFFA, dTPC)))
  })
}
out <- ode(y = c(FFA=0.15, TPC=4.0), times = seq(0, 120, by=10), func = oil_kinetics, parms = c(k_ffa=0.008, k_tpc=0.18, temp_coef=1.12))`
      };
    } else if (modelType === 'SHEWHART_SPC_CHARTS') {
      result = {
        modelType: 'SHEWHART_SPC_CHARTS',
        executedAt: new Date().toISOString(),
        rVersionInfo: 'R version 4.3.2 (2023-10-31) -- "Eye Holes"',
        summaryText: 'Shewhart X-Bar and R Control Chart with Process Capability Indices (Cp, Cpk) for Multihead Weigher Bag Fill Weights (Target: 150.0g).',
        chartData: Array.from({ length: 20 }, (_, i) => {
          const sample = i + 1;
          const mean = +(150.2 + (Math.sin(i * 0.5) * 0.8) + (Math.random() - 0.5) * 0.4).toFixed(2);
          return { sample, mean, ucl: 152.5, lcl: 148.0, target: 150.0 };
        }),
        metrics: {
          Process_Mean: '150.22 g',
          Standard_Deviation: '0.41 g',
          Cp_CapabilityIndex: 1.83,
          Cpk_ProcessCapability: 1.65,
          Process_Status: 'IN_STATISTICAL_CONTROL'
        },
        codeSnippet: `# R Script: Shewhart SPC & Capability Analysis
library(qcc)
spc_obj <- qcc(weight_samples, type="xbar", nsigmas=3)
process.capability(spc_obj, spec.limits=c(148.0, 153.5), target=150.0)`
      };
    } else {
      // Default: Demand ARIMA Forecast
      result = {
        modelType: 'DEMAND_ARIMA_FORECAST',
        executedAt: new Date().toISOString(),
        rVersionInfo: 'R version 4.3.2 (2023-10-31) -- "Eye Holes"',
        summaryText: 'Seasonal ARIMA(1,1,1)(0,1,1)[7] demand forecasting for Sea Salt Crisps 150g over the next 14 production days.',
        chartData: Array.from({ length: 14 }, (_, i) => {
          const day = `Day ${i + 1}`;
          const forecast = Math.round(24000 + Math.sin(i) * 3500 + i * 400);
          return {
            day,
            forecast,
            upper80: Math.round(forecast * 1.08),
            lower80: Math.round(forecast * 0.92),
            upper95: Math.round(forecast * 1.15),
            lower95: Math.round(forecast * 0.85)
          };
        }),
        metrics: {
          Model: 'ARIMA(1,1,1)(0,1,1)[7]',
          AIC: 2142.8,
          MAPE_Forecast_Error: '3.12%',
          RecommendedProductionTarget: '364,200 packs'
        },
        codeSnippet: `# R Script: Seasonal ARIMA Crisp Demand Forecast
library(forecast)
fit <- auto.arima(ts_daily_demand, seasonal=TRUE)
fc <- forecast(fit, h=14, level=c(80, 95))
plot(fc)`
      };
    }

    res.json(result);
  });

  // 1-Click End-to-End Vertical Slice Simulation
  app.post('/api/simulation/run-slice', (req, res) => {
    const simTimestamp = new Date().toISOString();
    const batchNum = `BAT-${Date.now().toString().slice(-6)}`;
    const lotNum = `P2026-SIM-${Math.floor(100 + Math.random() * 900)}`;
    const salt = crypto.randomBytes(6).toString('hex');
    const token = generateTicketToken(CAMPAIGNS[0].id, batchNum, 9999, salt);

    const ticket: GoldenTicket = {
      id: `TICK-SIM-${Math.floor(1000 + Math.random() * 9000)}`,
      tokenHmac: token,
      campaignId: CAMPAIGNS[0].id,
      batchNumber: batchNum,
      sku: 'CRISP-SAL-150G',
      prizeClass: 'TIER_3_100',
      prizeAmountGbp: 100,
      isWinner: true,
      isRedeemed: false
    };

    dbTickets.set(token, ticket);

    res.json({
      success: true,
      timestamp: simTimestamp,
      simulatedEntities: {
        farm: FARMS[0],
        potatoLotNumber: lotNum,
        qualityResult: {
          dryMatterPercent: 23.9,
          specificGravity: 1.092,
          reducingSugarsPercent: 0.07,
          qualityGrade: 'PREMIUM_ACCEPT'
        },
        batchNumber: batchNum,
        fryerLine: 'LINE-01 (Kettle Chips)',
        fryerTempCelsius: 168.0,
        nitrogenMapPercent: 98.2,
        goldenTicketToken: token,
        prizeWinner: true,
        prizeAmount: 100,
        blockchainTxHash: '0x' + crypto.createHash('sha256').update(token + simTimestamp).digest('hex')
      }
    });
  });

  // Vite Integration for Development & Production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CRISPOS Industrial OS Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
