package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.ui.screens.UnionYardApp
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.UnionYardViewModel
import com.example.ui.viewmodel.UnionYardViewModelFactory

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    
    val app = application as UnionYardApplication
    val repository = app.repository
    val viewModel = ViewModelProvider(this, UnionYardViewModelFactory(repository))[UnionYardViewModel::class.java]

    setContent {
      MyApplicationTheme {
        UnionYardApp(viewModel = viewModel)
      }
    }
  }
}

