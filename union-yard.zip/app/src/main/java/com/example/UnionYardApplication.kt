package com.example

import android.app.Application
import com.example.data.db.AppDatabase
import com.example.data.repository.UnionYardRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class UnionYardApplication : Application() {
    private val database by lazy { AppDatabase.getDatabase(this) }
    
    val repository by lazy {
        UnionYardRepository(
            database.eventDao(),
            database.artistDao(),
            database.mediaItemDao(),
            database.badgeDao(),
            database.merchItemDao()
        )
    }

    private val applicationScope = CoroutineScope(SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        // Prepopulate database in background
        applicationScope.launch {
            repository.checkAndPrepopulate()
        }
    }
}
