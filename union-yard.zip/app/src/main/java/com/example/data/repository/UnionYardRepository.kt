package com.example.data.repository

import android.content.Context
import com.example.data.db.*
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class UnionYardRepository(
    private val eventDao: EventDao,
    private val artistDao: ArtistDao,
    private val mediaItemDao: MediaItemDao,
    private val badgeDao: BadgeDao,
    private val merchItemDao: MerchItemDao
) {
    val allEvents: Flow<List<Event>> = eventDao.getAllEvents()
    val allArtists: Flow<List<Artist>> = artistDao.getAllArtists()
    val allMediaItems: Flow<List<MediaItem>> = mediaItemDao.getAllMediaItems()
    val allBadges: Flow<List<Badge>> = badgeDao.getAllBadges()
    val allMerchItems: Flow<List<MerchItem>> = merchItemDao.getAllMerchItems()

    fun getEventById(id: String): Flow<Event?> = eventDao.getEventById(id)
    fun getArtistById(id: String): Flow<Artist?> = artistDao.getArtistById(id)

    suspend fun toggleSavedStatus(id: String, currentStatus: Boolean) {
        withContext(Dispatchers.IO) {
            eventDao.updateSavedStatus(id, !currentStatus)
        }
    }

    suspend fun purchaseTicket(id: String, ticketType: String) {
        withContext(Dispatchers.IO) {
            val qrPayload = "UNIONYARD-TICKET-$id-${System.currentTimeMillis()}-$ticketType"
            eventDao.purchaseTicket(id, true, ticketType, qrPayload)
        }
    }

    suspend fun addBadge(badge: Badge) {
        withContext(Dispatchers.IO) {
            badgeDao.insertBadge(badge)
        }
    }

    suspend fun insertEvent(event: Event) {
        withContext(Dispatchers.IO) {
            eventDao.insert(event)
        }
    }

    suspend fun checkAndPrepopulate() {
        withContext(Dispatchers.IO) {
            // Check if events are empty
            val currentEvents = eventDao.getAllEvents().first()
            if (currentEvents.isEmpty()) {
                val mockEvents = listOf(
                    Event(
                        id = "afterhours",
                        title = "AFTERHOURS",
                        subtitle = "WAREHOUSE RAVE",
                        dateStr = "SAT MAY 25",
                        timeStr = "11PM - LATE",
                        venueName = "THE HANGAR, BROOKLYN",
                        description = "UNION YARD returns to its spiritual Brooklyn hangar for an unforgiving night of raw energy. Featuring extreme tempos, modular soundscapes, and hypnotic light grids. Experience our brand new L-Acoustics K2 sound system tuned specifically for the concrete geometry of the main warehouse room.",
                        lineUp = "KLANGKUENSTLER, VTSS, SAOIRSE, SHXCXCHCXSH",
                        ticketPriceMin = 40.00,
                        remainingCapacity = 45,
                        totalCapacity = 1500,
                        genreTags = "HARD TECHNO, SCHRANZ, ACID, RAWR",
                        lat = 40.7061,
                        lng = -73.9268,
                        weather = "68°F CLEAR & DRY",
                        travelDirections = "L Train to Jefferson St. Walk 4 blocks east along Flushing Ave.",
                        dressGuidance = "All black recommended. Industrial boots and hardware friendly. No cameras on dancefloor.",
                        ageRestriction = "21+ WITH VALID PHYSICAL ID",
                        accessibilityInfo = "ADA compliant ramps at main entrance. Heavy strobe, lasers, and high-decibel environment."
                    ),
                    Event(
                        id = "basement",
                        title = "BASEMENT SESSIONS",
                        subtitle = "TECHNO SESSIONS",
                        dateStr = "SAT JUN 08",
                        timeStr = "10PM - 6AM",
                        venueName = "THE VAULT, QUEENS",
                        description = "A deep descent into sub-surface hypnotic frequency. The Vault is a subterranean concrete enclave located in Long Island City, featuring a completely dark layout with a singular monolithic red laser. Pure focus, zero distractions, ultimate acoustic isolation.",
                        lineUp = "DVS1, BEN KLOCK, DJ NOBU, KIA",
                        ticketPriceMin = 35.00,
                        remainingCapacity = 120,
                        totalCapacity = 800,
                        genreTags = "DEEP TECHNO, HYPNOTIC, DETROIT MINIMAL",
                        lat = 40.7484,
                        lng = -73.9401,
                        weather = "72°F MILD & HUMID",
                        travelDirections = "7 Train to Court Sq. Walk 2 blocks towards the industrial railyards.",
                        dressGuidance = "Dark aesthetic, minimal branding. Focus is on music, not fashion.",
                        ageRestriction = "21+ ONLY",
                        accessibilityInfo = "Concrete steps at entry, chairlifts available. Enclosed dark environment."
                    ),
                    Event(
                        id = "nocturnal",
                        title = "NOCTURNAL",
                        subtitle = "ALL NIGHT LONG",
                        dateStr = "SAT JUN 22",
                        timeStr = "11PM - 8AM",
                        venueName = "UNION YARD MAIN HALL, BROOKLYN",
                        description = "High-velocity garage, rave breakbeats, and jungle anthems echoing from sunset to sunrise. Our Greenpoint flagship main hall is retrofitted with panoramic moving head lasers and warehouse lighting rigs that shift dynamically to the beat.",
                        lineUp = "MALL GRAB, SALUTE, INTERPLANETARY CRIMINAL",
                        ticketPriceMin = 45.00,
                        remainingCapacity = 12,
                        totalCapacity = 2000,
                        genreTags = "UK GARAGE, BREAKS, HOUSE, JUNGLE",
                        lat = 40.7115,
                        lng = -73.9315,
                        weather = "75°F WARM SUMMER BREEZE",
                        travelDirections = "G Train to Nassau Ave. Walk past McCarren Park towards the East River waterfront.",
                        dressGuidance = "Sporty ravewear, breathable materials, protective eyewear.",
                        ageRestriction = "21+",
                        accessibilityInfo = "Fully step-free layout. Dedicated accessible bathrooms."
                    ),
                    Event(
                        id = "beyond",
                        title = "BEYOND",
                        subtitle = "INDEPENDENCE DAY RAVE",
                        dateStr = "SAT JUL 06",
                        timeStr = "9PM - 7AM",
                        venueName = "WAREHOUSE 19, BROOKLYN",
                        description = "A colossal multi-room gathering in Sunset Park celebrating the breakbeats that birthed modern underground culture. Expect sub-bass pressure, UK bass science, hyper-speed jungle breaks, and experimental footwork.",
                        lineUp = "SHERELLE, VTSS, TIM REAPER, SPECIAL REQUEST",
                        ticketPriceMin = 30.00,
                        remainingCapacity = 340,
                        totalCapacity = 2500,
                        genreTags = "JUNGLE, BASS MUSIC, FOOTWORK, INDUSTRIAL",
                        lat = 40.6552,
                        lng = -74.0084,
                        weather = "78°F CLEAR SUB-TROPICAL NIGHT",
                        travelDirections = "D, N, R Trains to 36th St (Brooklyn). Walk west towards the waterfront warehouses.",
                        dressGuidance = "Comfortable dancing shoes. Utilitarian streetwear.",
                        ageRestriction = "21+ WITH ID",
                        accessibilityInfo = "Industrial elevator access for second level. Accessible facilities."
                    )
                )
                eventDao.insertAll(mockEvents)
            }

            val currentArtists = artistDao.getAllArtists().first()
            if (currentArtists.isEmpty()) {
                val mockArtists = listOf(
                    Artist(
                        id = "klangkuenstler",
                        name = "KLANGKUENSTLER",
                        bio = "Berlin-based powerhouse reviving the raw, unadulterated energy of early 2000s Schranz and industrial techno. Known for his devastating, fast-paced kick drums, atmospheric horror pads, and relentless acid basslines that command dancefloors globally.",
                        country = "GERMANY",
                        genres = "HARD TECHNO, SCHRANZ, ACID",
                        socialLinks = "Spotify:https://spotify.com,Soundcloud:https://soundcloud.com,Instagram:https://instagram.com"
                    ),
                    Artist(
                        id = "vtss",
                        name = "VTSS",
                        bio = "Polish-born, London-based boundary pusher blending hard techno with industrial, acid, and hyper-energetic rave textures. Her sets are legendary for their high BPM, unpredictable genre-shifts, and unapologetic attitude.",
                        country = "POLAND",
                        genres = "INDUSTRIAL TECHNO, ACID, HARDCORE",
                        socialLinks = "Spotify:https://spotify.com,Soundcloud:https://soundcloud.com,Instagram:https://instagram.com"
                    ),
                    Artist(
                        id = "mall_grab",
                        name = "MALL GRAB",
                        bio = "Australian-born selector and producer Jordan Alexander (Mall Grab) has carved a unique lane in electronic music. Blending warm analog house with dusty breakbeats, high-energy UK garage, and heavy warehouse techno.",
                        country = "AUSTRALIA",
                        genres = "HOUSE, UK GARAGE, HARDCORE RAVE",
                        socialLinks = "Spotify:https://spotify.com,Soundcloud:https://soundcloud.com,Instagram:https://instagram.com"
                    ),
                    Artist(
                        id = "sherelle",
                        name = "SHERELLE",
                        bio = "A transformative figure in the contemporary UK rave scene. Sherelle championing high-speed electronic sounds—delivering breakneck 160BPM sets of jungle, footwork, drum & bass, and experimental bass science.",
                        country = "UNITED KINGDOM",
                        genres = "JUNGLE, BASS, FOOTWORK",
                        socialLinks = "Spotify:https://spotify.com,Soundcloud:https://soundcloud.com,Instagram:https://instagram.com"
                    ),
                    Artist(
                        id = "dvs1",
                        name = "DVS1",
                        bio = "Zak Khutoretsky, better known as DVS1, is one of the most prominent figures in purist, hypnotic techno. Hailing from Minneapolis and resident of Berghain, his deep collection, vinyl mastery, and wall-of-sound acoustics are revered.",
                        country = "UNITED STATES",
                        genres = "HYPNOTIC TECHNO, DETROIT MINIMAL, AMBIENT",
                        socialLinks = "Spotify:https://spotify.com,Soundcloud:https://soundcloud.com,Instagram:https://instagram.com"
                    )
                )
                artistDao.insertAll(mockArtists)
            }

            val currentMedia = mediaItemDao.getAllMediaItems().first()
            if (currentMedia.isEmpty()) {
                val mockMedia = listOf(
                    MediaItem(
                        id = "set_klang",
                        title = "KLANGKUENSTLER LIVE @ UNION YARD BEYOND (AUDIO & VIDEO)",
                        artistName = "KLANGKUENSTLER",
                        type = "LIVE_SET",
                        duration = "01:24:15",
                        videoUrl = "https://example.com/stream/klang",
                        releaseDate = "2026-06-12"
                    ),
                    MediaItem(
                        id = "boiler_vtss",
                        title = "VTSS LIVE @ THE HANGAR (BOILER ROOM STYLE)",
                        artistName = "VTSS",
                        type = "BOILER_ROOM",
                        duration = "01:02:30",
                        videoUrl = "https://example.com/stream/vtss",
                        releaseDate = "2026-05-28"
                    ),
                    MediaItem(
                        id = "doc_warehouse",
                        title = "UNION YARD UNDERGROUND DOCUMENTARY: WAREHOUSE CULTURE",
                        artistName = "UNION YARD",
                        type = "DOCUMENTARY",
                        duration = "00:45:00",
                        videoUrl = "https://example.com/stream/doc",
                        releaseDate = "2026-04-15"
                    ),
                    MediaItem(
                        id = "mix_mallgrab",
                        title = "MALL GRAB 3-HOUR CLOSING SET (AUDIO MIX)",
                        artistName = "MALL GRAB",
                        type = "LIVE_SET",
                        duration = "03:00:00",
                        videoUrl = "https://example.com/stream/mallgrab",
                        releaseDate = "2026-07-02"
                    )
                )
                mediaItemDao.insertAll(mockMedia)
            }

            val currentBadges = badgeDao.getAllBadges().first()
            if (currentBadges.isEmpty()) {
                val mockBadges = listOf(
                    Badge(
                        id = "badge_founding",
                        name = "FOUNDING RAVER",
                        description = "Attended the Union Yard inaugural industrial assembly in 2024.",
                        iconName = "ic_hologram",
                        dateEarned = "MAR 14, 2024",
                        venueName = "BROOKLYN NAVY YARD"
                    ),
                    Badge(
                        id = "badge_steel",
                        name = "STEEL & CONCRETE",
                        description = "Unlocked by checking into the Sunset Park Warehouse waterfront space.",
                        iconName = "ic_iron",
                        dateEarned = "OCT 12, 2025",
                        venueName = "WAREHOUSE 19"
                    ),
                    Badge(
                        id = "badge_ltrain",
                        name = "L-TRAIN SURVIVOR",
                        description = "Attended 3 consecutive Union Yard gatherings along the L subway line.",
                        iconName = "ic_subway",
                        dateEarned = "MAY 02, 2026",
                        venueName = "THE HANGAR"
                    )
                )
                for (b in mockBadges) {
                    badgeDao.insertBadge(b)
                }
            }

            val currentMerch = merchItemDao.getAllMerchItems().first()
            if (currentMerch.isEmpty()) {
                val mockMerch = listOf(
                    MerchItem(
                        id = "hoodie_oversized",
                        name = "UNION YARD OVERSIZED WORK HOODIE",
                        price = 85.00,
                        sizes = "S, M, L, XL, XXL",
                        description = "Heavyweight 450gsm organic French Terry cotton. Stone-washed black finish. Screen-printed reflective industrial stencil logo on rear. Dropped shoulder fit. Made in New York.",
                        imageUrl = "hoodie"
                    ),
                    MerchItem(
                        id = "tee_norules",
                        name = "'NO RULES' SIGNAGE TEE",
                        price = 45.00,
                        sizes = "S, M, L, XL",
                        description = "Heavyweight 240gsm jersey cotton. Raw steel-grey tone. Monospaced branding across front chest. Boxy oversized silhouette.",
                        imageUrl = "tee"
                    ),
                    MerchItem(
                        id = "cap_utility",
                        name = "WAREHOUSE UTILITY CAP",
                        price = 30.00,
                        sizes = "ONE SIZE FIT",
                        description = "Unstructured 6-panel brushed cotton canvas. Dark graphite black. Steel metal adjustable clasp with Union Yard engraving.",
                        imageUrl = "cap"
                    ),
                    MerchItem(
                        id = "vinyl_vol1",
                        name = "UNION YARD VOL 1 VINYL (12\" EP)",
                        price = 25.00,
                        sizes = "12\" CLEAR VINYL",
                        description = "Strictly limited heavy-cut 180g crystal-clear vinyl. Hand-stamped industrial cardboard sleeve. Includes deep, unreleased warehouse cuts by Klangkuenstler, VTSS, and DVS1.",
                        imageUrl = "vinyl"
                    )
                )
                merchItemDao.insertAll(mockMerch)
            }
        }
    }
}
