package com.example.data.db

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface EventDao {
    @Query("SELECT * FROM events ORDER BY dateStr ASC")
    fun getAllEvents(): Flow<List<Event>>

    @Query("SELECT * FROM events WHERE id = :id")
    fun getEventById(id: String): Flow<Event?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(events: List<Event>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: Event)

    @Update
    suspend fun update(event: Event)

    @Query("UPDATE events SET isSaved = :isSaved WHERE id = :id")
    suspend fun updateSavedStatus(id: String, isSaved: Boolean)

    @Query("UPDATE events SET isPurchased = :isPurchased, purchasedTicketType = :ticketType, qrCodePayload = :qrPayload WHERE id = :id")
    suspend fun purchaseTicket(id: String, isPurchased: Boolean, ticketType: String, qrPayload: String)
}

@Dao
interface ArtistDao {
    @Query("SELECT * FROM artists ORDER BY name ASC")
    fun getAllArtists(): Flow<List<Artist>>

    @Query("SELECT * FROM artists WHERE id = :id")
    fun getArtistById(id: String): Flow<Artist?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(artists: List<Artist>)
}

@Dao
interface MediaItemDao {
    @Query("SELECT * FROM media_items ORDER BY releaseDate DESC")
    fun getAllMediaItems(): Flow<List<MediaItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(mediaItems: List<MediaItem>)
}

@Dao
interface BadgeDao {
    @Query("SELECT * FROM badges ORDER BY dateEarned DESC")
    fun getAllBadges(): Flow<List<Badge>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBadge(badge: Badge)
}

@Dao
interface MerchItemDao {
    @Query("SELECT * FROM merch_items")
    fun getAllMerchItems(): Flow<List<MerchItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(merchItems: List<MerchItem>)
}
