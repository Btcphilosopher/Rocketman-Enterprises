package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "events")
data class Event(
    @PrimaryKey val id: String,
    val title: String,
    val subtitle: String = "WAREHOUSE RAVE",
    val dateStr: String, // e.g. "SAT MAY 25"
    val timeStr: String = "11PM - LATE",
    val venueName: String, // e.g. "THE HANGAR, BROOKLYN"
    val description: String,
    val lineUp: String, // Comma-separated names, e.g. "KLANGKUENSTLER, VTSS, SAOIRSE"
    val ticketPriceMin: Double,
    val remainingCapacity: Int,
    val totalCapacity: Int = 1500,
    val genreTags: String, // Comma-separated, e.g. "TECHNO, JUNGLE"
    val isSaved: Boolean = false,
    val isPurchased: Boolean = false,
    val purchasedTicketType: String? = null, // "VIP", "Standard", "Early Bird"
    val qrCodePayload: String? = null, // for digital ticket scanner
    val lat: Double = 40.7128,
    val lng: Double = -74.0060,
    val weather: String = "68°F CLEAR",
    val travelDirections: String = "L Train to Morgan Ave. 5 min walk.",
    val dressGuidance: String = "All black. Industrial hardware friendly.",
    val ageRestriction: String = "21+ ONLY",
    val accessibilityInfo: String = "ADA compliant main hall. Strobe lights warning."
) : Serializable

@Entity(tableName = "artists")
data class Artist(
    @PrimaryKey val id: String,
    val name: String,
    val bio: String,
    val country: String,
    val genres: String, // e.g. "Hard Techno, Acid"
    val socialLinks: String, // Comma-separated key-value e.g. "Spotify:url,Soundcloud:url"
    val popularity: Int = 80,
    val profileImageId: String = "default" // reference or custom color indicator
) : Serializable

@Entity(tableName = "media_items")
data class MediaItem(
    @PrimaryKey val id: String,
    val title: String,
    val artistName: String,
    val type: String, // "LIVE_SET", "BOILER_ROOM", "AFTERMOVIE", "DOCUMENTARY"
    val duration: String, // e.g. "01:24:15"
    val videoUrl: String, // mock URL or real sound/video source
    val releaseDate: String, // e.g. "2026-06-12"
    val thumbnailId: String = "default"
) : Serializable

@Entity(tableName = "badges")
data class Badge(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val iconName: String, // e.g. "ic_hologram", "ic_iron"
    val dateEarned: String, // e.g. "MAY 25, 2026"
    val venueName: String
) : Serializable

@Entity(tableName = "merch_items")
data class MerchItem(
    @PrimaryKey val id: String,
    val name: String,
    val price: Double,
    val sizes: String = "S, M, L, XL",
    val description: String,
    val imageUrl: String = "default",
    val isAvailable: Boolean = true
) : Serializable

data class Announcement(
    val id: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)
