package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElectricPurple,
    secondary = ElectricBlue,
    tertiary = SuccessGreen,
    background = BackgroundDark,
    surface = PanelDark,
    onPrimary = TextWhite,
    onSecondary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextLightGrey,
    outline = BorderDark,
    error = WarningAmber
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Default to dark for Union Yard
  dynamicColor: Boolean = false, // Enforce brand identity
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme // Always use our stunning custom raw warehouse theme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
