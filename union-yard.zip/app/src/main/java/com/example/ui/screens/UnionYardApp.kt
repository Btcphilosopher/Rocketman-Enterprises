package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.UnionYardViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UnionYardApp(viewModel: UnionYardViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Observe DB States
    val events by viewModel.events.collectAsState()
    val artists by viewModel.artists.collectAsState()
    val mediaItems by viewModel.mediaItems.collectAsState()
    val badges by viewModel.badges.collectAsState()
    val merchItems by viewModel.merchItems.collectAsState()

    // Observe Interactive States
    val selectedEvent by viewModel.selectedEvent.collectAsState()
    val selectedArtist by viewModel.selectedArtist.collectAsState()
    val isInsideVenue by viewModel.isInsideVenue.collectAsState()
    val liveActiveEventId by viewModel.liveActiveEventId.collectAsState()
    val cart by viewModel.cart.collectAsState()
    val isCheckingOut by viewModel.isCheckingOut.collectAsState()
    val checkoutSuccessMessage by viewModel.checkoutSuccessMessage.collectAsState()
    val crews by viewModel.crews.collectAsState()
    val crewChats by viewModel.crewChats.collectAsState()
    val downloadedMediaIds by viewModel.downloadedMediaIds.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    // Navigation State (Active Tab)
    var currentTab by remember { mutableStateOf("HOME") }
    // More menu sub-screen helper
    var activeMoreScreen by remember { mutableStateOf<String?>(null) }
    // Search query helper
    var searchQuery by remember { mutableStateOf("") }
    var searchCategory by remember { mutableStateOf("ALL") }

    // Audio Set playing state simulator
    var currentlyPlayingMediaId by remember { mutableStateOf<String?>(null) }
    var isAudioPlaying by remember { mutableStateOf(false) }

    // Strobe Accessibility Setting
    var strobeEnabled by remember { mutableStateOf(true) }

    // Active More Screens: "MERCH", "MEMBERSHIP", "MEDIA", "MAP", "SEARCH", "ADMIN", "PROFILE", "NOTIFICATIONS"

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = PanelDark,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .border(width = 1.dp, color = BorderDark, shape = RoundedCornerShape(topStart = 0.dp, topEnd = 0.dp))
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                val tabs = listOf("HOME", "EVENTS", "LIVE", "COMMUNITY", "MORE")
                tabs.forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            currentTab = tab
                            activeMoreScreen = null // reset more screens when moving
                        },
                        icon = {
                            val icon = when (tab) {
                                "HOME" -> if (isSelected) Icons.Filled.Home else Icons.Outlined.Home
                                "EVENTS" -> if (isSelected) Icons.Filled.ConfirmationNumber else Icons.Outlined.ConfirmationNumber
                                "LIVE" -> if (isSelected) Icons.Filled.Radar else Icons.Outlined.Radar
                                "COMMUNITY" -> if (isSelected) Icons.Filled.Groups else Icons.Outlined.Groups
                                else -> if (isSelected) Icons.Filled.MenuOpen else Icons.Outlined.Menu
                            }
                            Icon(
                                imageVector = icon,
                                contentDescription = tab,
                                tint = if (isSelected) ElectricPurple else TextMediumGrey
                            )
                        },
                        label = {
                            Text(
                                text = tab,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) TextWhite else TextMediumGrey,
                                fontSize = 9.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = BorderDark
                        )
                    )
                }
            }
        },
        containerColor = BackgroundDark
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Background ambient laser lines (Sophisticated Motion heavy!)
            LaserLightShow(enabled = strobeEnabled)

            // Dynamic screen selector
            Crossfade(
                targetState = if (activeMoreScreen != null) activeMoreScreen else currentTab,
                animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    "HOME" -> HomeScreen(
                        events = events,
                        onTabChange = { tab ->
                            currentTab = tab
                            activeMoreScreen = null
                        },
                        onNavigateToMore = { moreScreen ->
                            activeMoreScreen = moreScreen
                        },
                        onSelectEvent = { eventId ->
                            viewModel.selectEvent(eventId)
                            activeMoreScreen = "EVENT_DETAIL"
                        }
                    )
                    "EVENTS" -> EventsFeedScreen(
                        events = events,
                        onSelectEvent = { eventId ->
                            viewModel.selectEvent(eventId)
                            activeMoreScreen = "EVENT_DETAIL"
                        }
                    )
                    "LIVE" -> LiveModeScreen(
                        isInside = isInsideVenue,
                        events = events,
                        activeLiveEventId = liveActiveEventId,
                        onToggleSimulation = { viewModel.simulateVenueArrival(it) },
                        onSelectEvent = { viewModel.setLiveActiveEvent(it) },
                        badges = badges
                    )
                    "COMMUNITY" -> CommunityScreen(
                        crews = crews,
                        chats = crewChats,
                        badges = badges,
                        onPostChat = { crew, text -> viewModel.postCrewChat(crew, text) },
                        onCreateCrew = { viewModel.createCrew(it) }
                    )
                    "MORE" -> MoreDirectoryScreen(
                        strobeEnabled = strobeEnabled,
                        onToggleStrobe = { strobeEnabled = it },
                        onNavigate = { activeMoreScreen = it }
                    )
                    "EVENT_DETAIL" -> selectedEvent?.let { event ->
                        EventDetailPage(
                            event = event,
                            onBack = { activeMoreScreen = null },
                            onSave = { viewModel.toggleSaveEvent(event) },
                            onBuy = { type -> viewModel.purchaseTicket(event.id, type) },
                            artists = artists,
                            onSelectArtist = { artistId ->
                                viewModel.selectArtist(artistId)
                                activeMoreScreen = "ARTIST_DETAIL"
                            }
                        )
                    } ?: run {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("SELECT AN EVENT", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                    "ARTIST_DETAIL" -> selectedArtist?.let { artist ->
                        ArtistDetailPage(
                            artist = artist,
                            events = events,
                            onBack = { activeMoreScreen = "EVENT_DETAIL" },
                            onSelectEvent = { eventId ->
                                viewModel.selectEvent(eventId)
                                activeMoreScreen = "EVENT_DETAIL"
                            }
                        )
                    } ?: run {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("SELECT AN ARTIST", style = MaterialTheme.typography.titleLarge)
                        }
                    }
                    "MERCH" -> MerchStoreScreen(
                        items = merchItems,
                        cart = cart,
                        isCheckingOut = isCheckingOut,
                        checkoutMessage = checkoutSuccessMessage,
                        onAddToCart = { viewModel.addToCart(it) },
                        onRemoveFromCart = { viewModel.removeFromCart(it) },
                        onCheckout = { viewModel.simulateStripeCheckout() },
                        onDismissMessage = { viewModel.dismissCheckoutSuccess() },
                        onBack = { activeMoreScreen = null }
                    )
                    "MEMBERSHIP" -> MembershipScreen(
                        onBack = { activeMoreScreen = null }
                    )
                    "MEDIA" -> MediaScreen(
                        items = mediaItems,
                        downloads = downloadedMediaIds,
                        onToggleDownload = { viewModel.toggleMediaDownload(it) },
                        playingMediaId = currentlyPlayingMediaId,
                        isPlaying = isAudioPlaying,
                        onTogglePlay = { mediaId ->
                            if (currentlyPlayingMediaId == mediaId) {
                                isAudioPlaying = !isAudioPlaying
                            } else {
                                currentlyPlayingMediaId = mediaId
                                isAudioPlaying = true
                            }
                        },
                        onBack = { activeMoreScreen = null }
                    )
                    "MAP" -> NYCWarehouseMapScreen(
                        events = events,
                        onBack = { activeMoreScreen = null }
                    )
                    "SEARCH" -> SearchScreen(
                        events = events,
                        artists = artists,
                        query = searchQuery,
                        onQueryChange = { searchQuery = it },
                        category = searchCategory,
                        onCategoryChange = { searchCategory = it },
                        onSelectEvent = { eventId ->
                            viewModel.selectEvent(eventId)
                            activeMoreScreen = "EVENT_DETAIL"
                        },
                        onSelectArtist = { artistId ->
                            viewModel.selectArtist(artistId)
                            activeMoreScreen = "ARTIST_DETAIL"
                        },
                        onBack = { activeMoreScreen = null }
                    )
                    "ADMIN" -> AdminPanelScreen(
                        onAddEvent = { title, sub, date, venue, genres, lineUp, price ->
                            viewModel.adminCreateEvent(title, sub, date, venue, genres, lineUp, price)
                            Toast.makeText(context, "WAREHOUSE EVENT CREATED", Toast.LENGTH_SHORT).show()
                        },
                        onTriggerPush = { title ->
                            viewModel.triggerStaffNotification(title)
                            Toast.makeText(context, "SIMULATED PUSH BROADCASTED", Toast.LENGTH_SHORT).show()
                        },
                        onBack = { activeMoreScreen = null }
                    )
                    "PROFILE" -> ProfileScreen(
                        events = events,
                        badges = badges,
                        onSelectEvent = { eventId ->
                            viewModel.selectEvent(eventId)
                            activeMoreScreen = "EVENT_DETAIL"
                        },
                        onBack = { activeMoreScreen = null }
                    )
                    "NOTIFICATIONS" -> NotificationsHubScreen(
                        notifications = notifications,
                        onClear = { /* optional */ },
                        onBack = { activeMoreScreen = null }
                    )
                }
            }

            // Global Streaming Audio Wave Player Overlay if music is playing
            currentlyPlayingMediaId?.let { playingId ->
                val playingItem = mediaItems.find { it.id == playingId }
                playingItem?.let { item ->
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(PanelDark.copy(alpha = 0.95f))
                            .border(width = 1.dp, color = ElectricPurple, shape = RoundedCornerShape(0.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = TextWhite,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "STREAMING LIVE SET • EXOPLAYER ACTIVE",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ElectricBlue,
                                    fontSize = 9.sp
                                )
                            }
                            
                            // Audio visualizer bars (Motion heavy!)
                            Row(
                                modifier = Modifier.height(24.dp).padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.spacedBy(2.dp)
                            ) {
                                repeat(5) { i ->
                                    val infiniteTransition = rememberInfiniteTransition(label = "EQ")
                                    val heightMultiplier by infiniteTransition.animateFloat(
                                        initialValue = 0.2f,
                                        targetValue = 1.0f,
                                        animationSpec = infiniteRepeatable(
                                            animation = tween(300 + (i * 80), easing = FastOutSlowInEasing),
                                            repeatMode = RepeatMode.Reverse
                                        ),
                                        label = "EQBar"
                                    )
                                    val barHeight = if (isAudioPlaying) 20.dp * heightMultiplier else 4.dp
                                    Box(
                                        modifier = Modifier
                                            .width(2.dp)
                                            .height(barHeight)
                                            .background(ElectricPurple)
                                    )
                                }
                            }

                            Row {
                                IconButton(onClick = { isAudioPlaying = !isAudioPlaying }) {
                                    Icon(
                                        imageVector = if (isAudioPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = TextWhite
                                    )
                                }
                                IconButton(onClick = { currentlyPlayingMediaId = null; isAudioPlaying = false }) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Close",
                                        tint = TextMediumGrey
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: HOME ---
@Composable
fun HomeScreen(
    events: List<Event>,
    onTabChange: (String) -> Unit,
    onNavigateToMore: (String) -> Unit,
    onSelectEvent: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    
    // Animate hero text tracking
    val infiniteTransition = rememberInfiniteTransition("Hero")
    val laserIntensity by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LaserGlow"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Full screen style looping Hero element
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(480.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, BackgroundDark),
                        startY = 350f
                    )
                )
                .drawBehind {
                    // Draw raw wireframe lines & strobe laser vectors for warehouse environment
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(ElectricPurple.copy(alpha = 0.15f * laserIntensity), Color.Transparent),
                            center = Offset(size.width / 2, size.height / 3),
                            radius = size.width * 0.8f
                        )
                    )
                    
                    // Brutalist design grid wires
                    val step = 40.dp.toPx()
                    for (x in 0..size.width.toInt() step step.toInt()) {
                        drawLine(
                            color = BorderDark.copy(alpha = 0.15f),
                            start = Offset(x.toFloat(), 0f),
                            end = Offset(x.toFloat(), size.height),
                            strokeWidth = 1f
                        )
                    }
                },
            contentAlignment = Alignment.BottomStart
        ) {
            // Live laser lines projection
            Box(Modifier.fillMaxSize()) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val pulse = sin(System.currentTimeMillis() / 400.0)
                    // Draw intersecting searchlight beams
                    drawLine(
                        color = ElectricPurple.copy(alpha = 0.4f),
                        start = Offset(0f, 0f),
                        end = Offset(size.width * (0.5f + pulse.toFloat() * 0.3f), size.height * 0.9f),
                        strokeWidth = 2.dp.toPx()
                    )
                    drawLine(
                        color = ElectricBlue.copy(alpha = 0.3f),
                        start = Offset(size.width, 0f),
                        end = Offset(size.width * (0.3f - pulse.toFloat() * 0.2f), size.height * 0.8f),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                // Large upper-case signage
                Text(
                    text = "A RAVE KOLLECTIVE",
                    style = MaterialTheme.typography.labelSmall,
                    color = ElectricPurple,
                    fontWeight = FontWeight.Bold
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "UNION YARD",
                    style = MaterialTheme.typography.displayLarge,
                    color = TextWhite,
                    fontSize = 52.sp,
                    lineHeight = 56.sp
                )
                
                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "UNDERGROUND CULTURE.\nNO RULES. ONLY MUSIC.",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextLightGrey,
                    fontSize = 15.sp,
                    lineHeight = 20.sp
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = "Union Yard is a New York rave collective promoting industrial warehouse events, high-tempo hard techno, hypnotic bass, jungle and UK Garage. We champion freedom and unity on the concrete dancefloor.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextMediumGrey,
                    lineHeight = 18.sp
                )
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { onTabChange("EVENTS") },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("explore_events_button")
                    ) {
                        Text("EXPLORE EVENTS", style = MaterialTheme.typography.labelLarge, color = TextWhite)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    OutlinedButton(
                        onClick = { onNavigateToMore("MEMBERSHIP") },
                        border = BorderStroke(1.dp, TextWhite),
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextWhite),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("JOIN MEMBERSHIP", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        // Ticker alert bar (Horizontal marquee animation)
        AnnouncementTicker()

        // COUNTDOWN TIMER TO NEXT GATHERING
        NextEventCountdownBanner(events = events, onSelectEvent = onSelectEvent)

        // QUICK LINKS GRID (Brutalist blocks)
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "KONTROL PANEL //",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp),
            color = TextLightGrey
        )
        
        Spacer(modifier = Modifier.height(12.dp))
        
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val quickLinks = listOf(
                Triple("EVENTS & TICKETS", "TICKET INVENTORY", "EVENTS"),
                Triple("LIVE PORTAL", "IN-VENUE EXPERIENCE", "LIVE"),
                Triple("MEDIA PLATFORM", "BOILER ROOM SETS", "MEDIA"),
                Triple("UNION WEAR", "STRIPE MERCH STORE", "MERCH"),
                Triple("NYC RADAR MAP", "SUBWAY & WAREHOUSES", "MAP"),
                Triple("SEARCH ENGINE", "ARTISTS & GENRES", "SEARCH"),
                Triple("DIGITAL PASSPORT", "PROFILE & BADGES", "PROFILE"),
                Triple("STAFF INGEST", "ADMIN DASHBOARD", "ADMIN")
            )
            
            quickLinks.chunked(2).forEach { row ->
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { link ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .background(PanelDark)
                                .border(width = 1.dp, color = BorderDark)
                                .clickable {
                                    if (link.third in listOf("EVENTS", "LIVE")) {
                                        onTabChange(link.third)
                                    } else {
                                        onNavigateToMore(link.third)
                                    }
                                }
                                .padding(16.dp)
                        ) {
                            Column {
                                Text(text = link.first, style = MaterialTheme.typography.titleMedium, color = ElectricPurple, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = link.second, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }

        // SWIPE CARDS (Horizontal display of highlights)
        Spacer(modifier = Modifier.height(32.dp))
        Text(
            text = "LINE-UP REVEAL //",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 24.dp),
            color = TextLightGrey
        )
        
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            contentPadding = PaddingValues(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(events) { event ->
                Box(
                    modifier = Modifier
                        .width(280.dp)
                        .background(PanelDark)
                        .border(width = 1.dp, color = BorderDark)
                        .clickable { onSelectEvent(event.id) }
                ) {
                    Column {
                        // Poster placeholder
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(ElectricPurple.copy(alpha = 0.3f), Color.Transparent)
                                    )
                                )
                                .drawBehind {
                                    // Custom visual brutalist stamps
                                    drawCircle(
                                        color = ElectricPurple.copy(alpha = 0.2f),
                                        center = Offset(size.width * 0.8f, size.height * 0.4f),
                                        radius = 60.dp.toPx()
                                    )
                                },
                            contentAlignment = Alignment.TopStart
                        ) {
                            Box(
                                modifier = Modifier
                                    .padding(12.dp)
                                    .background(BackgroundDark)
                                    .border(1.dp, ElectricPurple)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(event.dateStr, style = MaterialTheme.typography.labelSmall, color = TextWhite)
                            }
                        }

                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(event.title, style = MaterialTheme.typography.titleLarge, color = TextWhite)
                            Text(event.subtitle, style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(event.venueName, style = MaterialTheme.typography.bodyMedium, color = TextLightGrey, maxLines = 1)
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            // Capacity indicator
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(if (event.remainingCapacity < 50) WarningAmber else SuccessGreen, shape = CircleShape)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (event.remainingCapacity < 50) "LAST RELEASE: ${event.remainingCapacity} TICKETS" else "ENTRY SECURE: CAPACITY IN STOCK",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.sp,
                                    color = if (event.remainingCapacity < 50) WarningAmber else TextMediumGrey
                                )
                            }
                        }
                    }
                }
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
    }
}

// --- SUB SCREEN: EVENTS FEED ---
@Composable
fun EventsFeedScreen(events: List<Event>, onSelectEvent: (String) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "INDUSTRIAL ASSEMBLIES",
            style = MaterialTheme.typography.displayMedium,
            color = TextWhite
        )
        Text(
            text = "ACTIVE SYSTEM STATUS: ACTIVE GATHERINGS IN NYC",
            style = MaterialTheme.typography.labelSmall,
            color = ElectricBlue
        )
        
        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            items(events) { event ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PanelDark)
                        .border(width = 1.dp, color = BorderDark)
                        .clickable { onSelectEvent(event.id) }
                ) {
                    Column {
                        // Poster Artwork Panel
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .background(
                                    Brush.sweepGradient(
                                        colors = listOf(
                                            BackgroundDark,
                                            ElectricPurple.copy(alpha = 0.2f),
                                            ElectricBlue.copy(alpha = 0.15f),
                                            BackgroundDark
                                        )
                                    )
                                )
                                .drawBehind {
                                    // Custom brutalist lines
                                    drawLine(
                                        color = BorderDark,
                                        start = Offset(0f, size.height),
                                        end = Offset(size.width, 0f),
                                        strokeWidth = 2f
                                    )
                                    drawRect(
                                        color = ElectricPurple.copy(alpha = 0.05f),
                                        topLeft = Offset(20f, 20f),
                                        size = Size(size.width - 40f, size.height - 40f),
                                        style = Stroke(width = 1f)
                                    )
                                }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(ElectricPurple)
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(event.dateStr, style = MaterialTheme.typography.labelSmall, color = TextWhite, fontWeight = FontWeight.Bold)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .background(BackgroundDark)
                                            .border(1.dp, BorderDark)
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(event.weather, style = MaterialTheme.typography.labelSmall, color = TextLightGrey)
                                    }
                                }

                                Column {
                                    Text(
                                        text = event.title,
                                        style = MaterialTheme.typography.displayMedium,
                                        color = TextWhite,
                                        fontSize = 32.sp
                                    )
                                    Text(
                                        text = event.subtitle,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ElectricBlue
                                    )
                                }
                            }
                        }

                        // Event Detail Footer Info
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("VENUE", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                                    Text(event.venueName, style = MaterialTheme.typography.titleMedium, color = TextLightGrey)
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("TICKETS FROM", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                                    Text("$${String.format("%.2f", event.ticketPriceMin)}", style = MaterialTheme.typography.titleMedium, color = ElectricPurple)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            
                            // Lineup teaser
                            Text("LINE-UP //", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                            Text(
                                text = event.lineUp,
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextLightGrey,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(if (event.remainingCapacity < 50) WarningAmber.copy(alpha = 0.15f) else BorderDark)
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = if (event.remainingCapacity < 50) "CRITICAL: ${event.remainingCapacity} LEFT" else "CAPACITY SECURE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (event.remainingCapacity < 50) WarningAmber else TextMediumGrey,
                                        fontSize = 9.sp
                                    )
                                }

                                Text(
                                    text = "SELECT TO ENTER →",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = ElectricPurple,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: EVENT DETAIL PAGE ---
@Composable
fun EventDetailPage(
    event: Event,
    onBack: () -> Unit,
    onSave: () -> Unit,
    onBuy: (String) -> Unit,
    artists: List<Artist>,
    onSelectArtist: (String) -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var selectedTicketType by remember { mutableStateOf("STANDARD") }
    var purchaseComplete by remember { mutableStateOf(event.isPurchased) }
    var showBuyDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Massive Cinematic Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(360.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, BackgroundDark),
                        startY = 220f
                    )
                )
                .drawBehind {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(ElectricPurple.copy(alpha = 0.25f), Color.Transparent),
                            center = Offset(size.width / 2, size.height / 2),
                            radius = size.width * 0.7f
                        )
                    )
                    // Structural brutalist lines overlay
                    drawLine(
                        color = BorderDark,
                        start = Offset(24.dp.toPx(), 0f),
                        end = Offset(24.dp.toPx(), size.height),
                        strokeWidth = 2f
                    )
                }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.background(BackgroundDark, CircleShape)
                    ) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                    }

                    Row {
                        IconButton(
                            onClick = onSave,
                            modifier = Modifier.background(BackgroundDark, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (event.isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                                contentDescription = "Save",
                                tint = if (event.isSaved) ElectricPurple else TextWhite
                            )
                        }
                    }
                }

                // Title Area
                Column {
                    Box(
                        modifier = Modifier
                            .background(ElectricPurple)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(event.dateStr, style = MaterialTheme.typography.labelSmall, color = TextWhite)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = event.title,
                        style = MaterialTheme.typography.displayLarge,
                        fontSize = 48.sp,
                        lineHeight = 52.sp,
                        color = TextWhite
                    )
                    Text(event.subtitle, style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                }
            }
        }

        // Details Block
        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            // Stats Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderDark)
                    .background(PanelDark)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("TIME", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                    Text(event.timeStr, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                }
                Column {
                    Text("WEATHER", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                    Text(event.weather, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                }
                Column {
                    Text("RESTRICTION", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                    Text(event.ageRestriction, style = MaterialTheme.typography.titleMedium, color = ElectricPurple)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Description
            Text("MISSION BRIEF //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = event.description,
                style = MaterialTheme.typography.bodyLarge,
                color = TextLightGrey,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Line Up & Timetable
            Text("LINE-UP // SELECT DJ TO EXPAND BIO", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))
            
            // Map event line-up strings to actual DJ details
            val lineupNames = event.lineUp.split(", ")
            lineupNames.forEach { djName ->
                val matchedArtist = artists.find { it.name.equals(djName, ignoreCase = true) }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            matchedArtist?.let { onSelectArtist(it.id) }
                        }
                        .border(1.dp, BorderDark)
                        .background(PanelDark)
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(djName, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                        Text(if (matchedArtist != null) matchedArtist.genres else "INDUSTRIAL TECHNO", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                    }
                    if (matchedArtist != null) {
                        Text("VIEW BIO →", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Logistics info
            Text("LOGISTICS & DRESS GUIDANCE //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderDark)
                    .background(PanelDark)
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column {
                        Text("SUBWAY / TRAVEL", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                        Text(event.travelDirections, style = MaterialTheme.typography.bodyMedium, color = TextLightGrey)
                    }
                    Column {
                        Text("DRESS GUIDANCE", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                        Text(event.dressGuidance, style = MaterialTheme.typography.bodyMedium, color = TextLightGrey)
                    }
                    Column {
                        Text("ACCESSIBILITY", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                        Text(event.accessibilityInfo, style = MaterialTheme.typography.bodyMedium, color = TextLightGrey)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Ticket Purchasing Section
            Text("ACCESS CREDENTIAL SELECTOR //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
            Spacer(modifier = Modifier.height(8.dp))
            
            if (event.isPurchased) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SuccessGreen)
                        .background(PanelDark)
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Filled.CheckCircle, "Secured", tint = SuccessGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("ENTRY CREDENTIALS SECURED", style = MaterialTheme.typography.titleLarge, color = TextWhite)
                        Text("TYPE: ${event.purchasedTicketType}", style = MaterialTheme.typography.titleMedium, color = ElectricPurple)
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // Fake barcode simulation
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.8f)
                                .height(60.dp)
                                .background(TextWhite)
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val barCount = 40
                                val barWidth = size.width / barCount
                                for (i in 0 until barCount) {
                                    val isBar = (i * 7 + i % 3) % 2 == 0
                                    if (isBar) {
                                        drawRect(
                                            color = Color.Black,
                                            topLeft = Offset(i * barWidth, 0f),
                                            size = Size(barWidth * 0.7f, size.height)
                                        )
                                    }
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = {
                                Toast.makeText(context, "ADDED TO GOOGLE WALLET", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = TextWhite),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text("SAVE TO GOOGLE WALLET", color = Color.Black, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            } else {
                val ticketOptions = listOf(
                    Triple("EARLY BIRD", event.ticketPriceMin, "10% CAPACITY LEFT"),
                    Triple("STANDARD RELEASE", event.ticketPriceMin + 10.0, "SELLING FAST"),
                    Triple("VIP FRONTROW ACCESS", event.ticketPriceMin + 45.0, "SECRET AREA UNLOCKED")
                )

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ticketOptions.forEach { option ->
                        val isSelected = selectedTicketType == option.first
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, if (isSelected) ElectricPurple else BorderDark)
                                .background(if (isSelected) ElectricPurple.copy(alpha = 0.05f) else PanelDark)
                                .clickable { selectedTicketType = option.first }
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(option.first, style = MaterialTheme.typography.titleMedium, color = if (isSelected) ElectricPurple else TextWhite)
                                Text(option.third, style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                            }
                            Text("$${String.format("%.2f", option.second)}", style = MaterialTheme.typography.titleLarge, color = TextWhite)
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { showBuyDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.fillMaxWidth().testTag("purchase_button")
                    ) {
                        Text("SECURE PASS FOR $selectedTicketType", style = MaterialTheme.typography.labelLarge, color = TextWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(60.dp))
        }
    }

    // Interactive Stripe Credit Card Purchase Sheet dialog
    if (showBuyDialog) {
        Dialog(onDismissRequest = { showBuyDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, ElectricPurple)
                    .background(PanelDark)
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STRIPE SECURE CHECKOUT", style = MaterialTheme.typography.titleLarge, color = TextWhite)
                    Text("UNION YARD RAVE GATEWAY", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                    
                    Spacer(modifier = Modifier.height(16.dp))

                    OutlinedTextField(
                        value = "4242 •••• •••• 4242",
                        onValueChange = {},
                        label = { Text("CARD NUMBER (STRIPE SIMULATED)", color = TextMediumGrey) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricPurple,
                            unfocusedBorderColor = BorderDark,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        enabled = false
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = "12 / 29",
                            onValueChange = {},
                            label = { Text("EXP", color = TextMediumGrey) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricPurple,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            modifier = Modifier.weight(1f),
                            enabled = false
                        )
                        OutlinedTextField(
                            value = "•••",
                            onValueChange = {},
                            label = { Text("CVC", color = TextMediumGrey) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricPurple,
                                unfocusedBorderColor = BorderDark,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            modifier = Modifier.weight(1f),
                            enabled = false
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedButton(
                            onClick = { showBuyDialog = false },
                            border = BorderStroke(1.dp, TextWhite),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ABORT", color = TextWhite, style = MaterialTheme.typography.labelLarge)
                        }

                        Button(
                            onClick = {
                                onBuy(selectedTicketType)
                                showBuyDialog = false
                                Toast.makeText(context, "STRIPE PAYMENT SECURED", Toast.LENGTH_LONG).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SECURE TICKET", color = Color.Black, style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: ARTIST DETAIL PAGE ---
@Composable
fun ArtistDetailPage(
    artist: Artist,
    events: List<Event>,
    onBack: () -> Unit,
    onSelectEvent: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, BackgroundDark)
                    )
                )
                .drawBehind {
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(ElectricBlue.copy(alpha = 0.25f), Color.Transparent),
                            center = Offset(size.width / 2, size.height / 2),
                            radius = size.width * 0.7f
                        )
                    )
                },
            contentAlignment = Alignment.BottomStart
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.background(BackgroundDark, CircleShape)
                ) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = TextWhite)
                }

                Column {
                    Box(
                        modifier = Modifier
                            .background(ElectricBlue)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(artist.country, style = MaterialTheme.typography.labelSmall, color = TextWhite)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(artist.name, style = MaterialTheme.typography.displayLarge, color = TextWhite)
                    Text("GENRES: ${artist.genres}", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
                }
            }
        }

        Column(modifier = Modifier.padding(horizontal = 24.dp)) {
            Spacer(modifier = Modifier.height(16.dp))
            Text("BIOGRAPHY //", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = artist.bio,
                style = MaterialTheme.typography.bodyLarge,
                color = TextLightGrey,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Social channels
            Text("PLATFORM LINKAGES //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val links = listOf("Spotify", "AppleMusic", "Soundcloud", "Instagram", "ResidentAdvisor")
                links.forEach { platform ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(PanelDark)
                            .border(1.dp, BorderDark)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(platform, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = TextWhite)
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Upcoming Shows
            Text("UPCOMING ASSEMBLIES //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
            Spacer(modifier = Modifier.height(8.dp))
            
            val matchingEvents = events.filter { it.lineUp.contains(artist.name, ignoreCase = true) }
            if (matchingEvents.isEmpty()) {
                Text("NO SCHEDULED SHOWS CURRENTLY", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
            } else {
                matchingEvents.forEach { event ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderDark)
                            .background(PanelDark)
                            .clickable { onSelectEvent(event.id) }
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(event.title, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                            Text(event.venueName, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                        }
                        Box(
                            modifier = Modifier
                                .background(ElectricPurple)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(event.dateStr, style = MaterialTheme.typography.labelSmall, color = TextWhite)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// --- SUB SCREEN: LIVE MODE (SENSORS & INTERACTIVE WAREHOUSE) ---
@Composable
fun LiveModeScreen(
    isInside: Boolean,
    events: List<Event>,
    activeLiveEventId: String,
    onToggleSimulation: (Boolean) -> Unit,
    onSelectEvent: (String) -> Unit,
    badges: List<Badge>
) {
    val scrollState = rememberScrollState()
    val activeEvent = events.find { it.id == activeLiveEventId } ?: events.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Text(text = "LIVE RAVE MODE", style = MaterialTheme.typography.displayMedium, color = TextWhite)
        Text(text = "MONITORING POSITION STATUS...", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)

        Spacer(modifier = Modifier.height(16.dp))

        // Arrival Stimulator Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(width = 1.dp, color = if (isInside) SuccessGreen else ElectricPurple)
                .background(PanelDark)
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (isInside) "STATUS: INSIDE THE VENUE" else "STATUS: OUTSIDE RANGE",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isInside) SuccessGreen else TextWhite
                        )
                        Text(
                            text = if (isInside) "GPS & WIFI DETECTED MORGAN AVE" else "NYC COORDINATES RADAR OFF-GRID",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMediumGrey
                        )
                    }
                    
                    Switch(
                        checked = isInside,
                        onCheckedChange = { onToggleSimulation(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = SuccessGreen,
                            checkedTrackColor = SuccessGreen.copy(alpha = 0.3f),
                            uncheckedThumbColor = ElectricPurple,
                            uncheckedTrackColor = BorderDark
                        )
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        if (!isInside) {
            // Simulated Locked state layout
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderDark)
                    .background(PanelDark)
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = "Locked",
                        tint = ElectricPurple,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "LIVE MODE LOCKED",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextWhite,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This mode unlocks automatically when you arrive at a UNION YARD warehouse venue. Use the simulation switch above to override GPS sensors.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMediumGrey,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            // Live Timetable
            Text("SET TIMETABLE // LIVE NOW", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
            Spacer(modifier = Modifier.height(8.dp))
            
            val liveSets = listOf(
                Triple("11:00 PM - 01:00 AM", "SAOIRSE", "COMPLETED"),
                Triple("01:00 AM - 03:00 AM", "VTSS", "LIVE ON STAGE"),
                Triple("03:00 AM - 06:00 AM", "KLANGKUENSTLER", "UPCOMING NEXT"),
                Triple("06:00 AM - ADJOURN", "SHXCXCHCXSH", "UPCOMING")
            )

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                liveSets.forEach { set ->
                    val isLive = set.third == "LIVE ON STAGE"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (isLive) SuccessGreen else BorderDark)
                            .background(if (isLive) SuccessGreen.copy(alpha = 0.05f) else PanelDark)
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(set.second, style = MaterialTheme.typography.titleMedium, color = if (isLive) SuccessGreen else TextWhite)
                            Text(set.first, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                        }
                        Box(
                            modifier = Modifier
                                .background(if (isLive) SuccessGreen else BorderDark)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(set.third, style = MaterialTheme.typography.labelSmall, color = if (isLive) Color.Black else TextMediumGrey)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Interactive vector-drawn warehouse layout map
            Text("INTERACTIVE VENUE BLUEPRINT //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .border(1.dp, BorderDark)
                    .background(BackgroundDark)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    // Draw outer wall layout
                    drawRect(
                        color = BorderDark,
                        style = Stroke(width = 3.dp.toPx())
                    )
                    
                    // Main Stage
                    drawRect(
                        color = ElectricPurple.copy(alpha = 0.2f),
                        topLeft = Offset(20.dp.toPx(), 20.dp.toPx()),
                        size = Size(100.dp.toPx(), 60.dp.toPx())
                    )
                    drawRect(
                        color = ElectricPurple,
                        topLeft = Offset(20.dp.toPx(), 20.dp.toPx()),
                        size = Size(100.dp.toPx(), 60.dp.toPx()),
                        style = Stroke(width = 1.dp.toPx())
                    )
                    
                    // Bar
                    drawRect(
                        color = ElectricBlue.copy(alpha = 0.2f),
                        topLeft = Offset(200.dp.toPx(), 180.dp.toPx()),
                        size = Size(100.dp.toPx(), 40.dp.toPx())
                    )
                    
                    // Water
                    drawCircle(
                        color = ElectricBlue,
                        center = Offset(50.dp.toPx(), 200.dp.toPx()),
                        radius = 8.dp.toPx()
                    )

                    // Toilets
                    drawRect(
                        color = PanelDark,
                        topLeft = Offset(250.dp.toPx(), 20.dp.toPx()),
                        size = Size(60.dp.toPx(), 60.dp.toPx()),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }

                // Custom labels inside Canvas container
                Box(Modifier.padding(24.dp)) {
                    Text("MAIN STAGE (DANCEFLOOR)", color = TextWhite, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                }
                Box(Modifier.align(Alignment.BottomEnd).padding(24.dp)) {
                    Text("INDUSTRIAL BAR", color = ElectricBlue, style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                }
                Box(Modifier.align(Alignment.BottomStart).padding(start = 24.dp, bottom = 44.dp)) {
                    Text("WATER REFILL", color = TextWhite, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
                }
                Box(Modifier.align(Alignment.TopEnd).padding(end = 40.dp, top = 40.dp)) {
                    Text("TOILETS", color = TextLightGrey, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Collect badges checking
            Text("DIGITAL BADGE ISSUED //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SuccessGreen)
                    .background(PanelDark)
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.WorkspacePremium, "Premium", tint = SuccessGreen, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("BADGE SECURED: HANGAR ENCLAVE", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                    Text("Added to your local Rave Passport history.", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// --- SUB SCREEN: COMMUNITY (CREWS & RSVP CHAT) ---
@Composable
fun CommunityScreen(
    crews: List<String>,
    chats: List<Pair<String, String>>,
    badges: List<Badge>,
    onPostChat: (String, String) -> Unit,
    onCreateCrew: (String) -> Unit
) {
    var activeCrew by remember { mutableStateOf(crews.firstOrNull() ?: "UNION") }
    var chatInput by remember { mutableStateOf("") }
    var crewInput by remember { mutableStateOf("") }
    var showCreateCrewDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Text(text = "UNION COMMUNITY", style = MaterialTheme.typography.displayMedium, color = TextWhite)
        Text(text = "CONNECTED RADAR CHANNELS", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)

        Spacer(modifier = Modifier.height(16.dp))

        // Crews selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("ACTIVE CREWS //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
            Text(
                "+ CREATE CREW",
                style = MaterialTheme.typography.labelSmall,
                color = ElectricPurple,
                modifier = Modifier.clickable { showCreateCrewDialog = true }
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(crews) { crew ->
                val isSelected = activeCrew == crew
                Box(
                    modifier = Modifier
                        .background(if (isSelected) ElectricPurple else PanelDark)
                        .border(1.dp, if (isSelected) ElectricPurple else BorderDark)
                        .clickable { activeCrew = crew }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(crew, style = MaterialTheme.typography.labelSmall, color = TextWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Chat log
        Text("CREW LOG: $activeCrew", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .border(1.dp, BorderDark)
                .background(PanelDark)
                .padding(16.dp)
        ) {
            val matchingChats = chats.filter { it.first == activeCrew }
            
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (matchingChats.isEmpty()) {
                        item {
                            Text("NO CHATS YET. CONSTRUCT COMMUNICATION.", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                        }
                    } else {
                        items(matchingChats) { chat ->
                            Column {
                                Text("ANONYMOUS RAVER //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple, fontSize = 8.sp)
                                Text(chat.second, style = MaterialTheme.typography.bodyLarge, color = TextWhite)
                                Spacer(modifier = Modifier.height(4.dp))
                                Divider(color = BorderDark, thickness = 0.5.dp)
                            }
                        }
                    }
                }

                // Chat Input Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = chatInput,
                        onValueChange = { chatInput = it },
                        placeholder = { Text("SEND TO CREW CHANNEL...", color = TextMediumGrey) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = ElectricPurple,
                            unfocusedBorderColor = BorderDark
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (chatInput.isNotBlank()) {
                                onPostChat(activeCrew, chatInput)
                                chatInput = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text("POST", color = TextWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    if (showCreateCrewDialog) {
        Dialog(onDismissRequest = { showCreateCrewDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ElectricPurple)
                    .background(PanelDark)
                    .padding(24.dp)
            ) {
                Column {
                    Text("CONSTRUCT CREW STATION", style = MaterialTheme.typography.titleLarge, color = TextWhite)
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = crewInput,
                        onValueChange = { crewInput = it },
                        label = { Text("CREW IDENTIFIER", color = TextMediumGrey) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = ElectricPurple,
                            unfocusedBorderColor = BorderDark
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { showCreateCrewDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = BorderDark),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("ABORT", color = TextWhite)
                        }
                        Button(
                            onClick = {
                                if (crewInput.isNotBlank()) {
                                    onCreateCrew(crewInput)
                                    activeCrew = crewInput.uppercase()
                                    crewInput = ""
                                    showCreateCrewDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("CREATE", color = TextWhite)
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: MORE DIRECTORY ---
@Composable
fun MoreDirectoryScreen(
    strobeEnabled: Boolean,
    onToggleStrobe: (Boolean) -> Unit,
    onNavigate: (String) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Text(text = "UNION DIRECTORY", style = MaterialTheme.typography.displayMedium, color = TextWhite)
        Text(text = "FULL PLATFORM ACCESS", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)

        Spacer(modifier = Modifier.height(20.dp))

        // Large list of brutalist navigation targets
        val listItems = listOf(
            Triple("UNION WEAR STORE", "Minimal Industrial clothing & Heavyweight vinyl sets", "MERCH"),
            Triple("UNION MEMBERSHIP CARD", "Glowing holographic priority entry pass", "MEMBERSHIP"),
            Triple("MEDIA PLATFORM STREAM", "Live warehouse music, videos, and documentary", "MEDIA"),
            Triple("NYC WAREHOUSE RADAR MAP", "Locations, Travel, subway lines, and recommended afterparties", "MAP"),
            Triple("SEARCH SYSTEM ENGINE", "Locate Artists, Genres, venues and events", "SEARCH"),
            Triple("DIGITAL RAVER PASSPORT", "Your local tickets history, statistics, and achievement badges", "PROFILE"),
            Triple("UNION STAFF PORTAL", "Admin options to ingest events or emit push notifications", "ADMIN"),
            Triple("PULSING RADAR ARCHIVE", "Review previously received emergency announcements", "NOTIFICATIONS")
        )

        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            listItems.forEach { item ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderDark)
                        .background(PanelDark)
                        .clickable { onNavigate(item.third) }
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.first, style = MaterialTheme.typography.titleMedium, color = ElectricPurple)
                            Text(item.second, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                        }
                        Icon(Icons.Filled.ChevronRight, "Navigate", tint = TextMediumGrey)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Accessibility strobe switch
        Text("ACCESSIBILITY SYSTEM CONFIG //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderDark)
                .background(PanelDark)
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("MOTION LASERS EFFECTS", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                Text("Toggle animated background searchlight lines", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
            }
            Switch(
                checked = strobeEnabled,
                onCheckedChange = onToggleStrobe,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ElectricPurple,
                    checkedTrackColor = ElectricPurple.copy(alpha = 0.3f),
                    uncheckedThumbColor = TextMediumGrey,
                    uncheckedTrackColor = BorderDark
                )
            )
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// --- SUB SCREEN: MEMBERSHIP ---
@Composable
fun MembershipScreen(onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
            }
            Text("MEMBERSHIP DIVISION", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Holographic Glowing card
        val infiniteTransition = rememberInfiniteTransition("HoloCard")
        val colorShift by infiniteTransition.animateFloat(
            initialValue = 0f,
            targetValue = 360f,
            animationSpec = infiniteRepeatable(
                animation = tween(4000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "HoloGradient"
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(220.dp)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            ElectricPurple.copy(alpha = 0.4f),
                            ElectricBlue.copy(alpha = 0.3f),
                            BackgroundDark,
                            ElectricPurple.copy(alpha = 0.2f)
                        ),
                        start = Offset(0f, 0f),
                        end = Offset(1000f, 1000f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                .border(2.dp, ElectricPurple, shape = RoundedCornerShape(12.dp))
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("UNION YARD", style = MaterialTheme.typography.titleLarge, color = TextWhite)
                    Text("PASS LEVEL I", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                }

                Column {
                    Text("MEMBER ID", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey, fontSize = 8.sp)
                    Text("UY-2026-9482", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                    Text("STATUS: RECONVERGED MEMBER", style = MaterialTheme.typography.labelSmall, color = SuccessGreen, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text("DIVISION MEMBER PERKS //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
        Spacer(modifier = Modifier.height(8.dp))

        val perks = listOf(
            "EARLY ACCESS ENTRY TICKETS SECURED",
            "EXCLUSIVITY CO-DESIGN HOODIES & VINYL INVENTORY",
            "SECRET WAREHOUSE GPS LOCATION DISCOVERY",
            "PRIORITY BYPASS CONCRETE ENTRY DOORWAYS"
        )

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            perks.forEach { perk ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderDark)
                        .background(PanelDark)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.WorkspacePremium, "Perk", tint = ElectricPurple)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(perk, style = MaterialTheme.typography.titleMedium, fontSize = 11.sp, color = TextWhite)
                }
            }
        }
    }
}

// --- SUB SCREEN: MERCH STORE (STRIPE INTEGRATED) ---
@Composable
fun MerchStoreScreen(
    items: List<MerchItem>,
    cart: Map<String, Int>,
    isCheckingOut: Boolean,
    checkoutMessage: String?,
    onAddToCart: (String) -> Unit,
    onRemoveFromCart: (String) -> Unit,
    onCheckout: () -> Unit,
    onDismissMessage: () -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()
    var showCartSheet by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "UNION STORE", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }

            // Cart icon indicator
            Box(
                modifier = Modifier
                    .background(PanelDark)
                    .border(1.dp, ElectricPurple)
                    .clickable { showCartSheet = true }
                    .padding(8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.ShoppingCart, "Cart", tint = ElectricPurple)
                    val totalQty = cart.values.sum()
                    if (totalQty > 0) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("$totalQty", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 32.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(items) { item ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderDark)
                        .background(PanelDark)
                ) {
                    Column {
                        // Store image placeholder box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .background(BackgroundDark)
                                .drawBehind {
                                    // Draw minimal abstract geometry for merch style
                                    drawLine(
                                        color = BorderDark,
                                        start = Offset(0f, 0f),
                                        end = Offset(size.width, size.height),
                                        strokeWidth = 1f
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "UY STORE // SKU",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMediumGrey
                            )
                        }

                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                item.name,
                                style = MaterialTheme.typography.titleMedium,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                color = TextWhite
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "$${String.format("%.2f", item.price)}",
                                style = MaterialTheme.typography.titleMedium,
                                color = ElectricPurple
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Button(
                                onClick = { onAddToCart(item.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                                shape = RoundedCornerShape(2.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ADD TO CART", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = TextWhite)
                            }
                        }
                    }
                }
            }
        }
    }

    // Cart overlay panel dialog (Stripe Simulated Integration)
    if (showCartSheet) {
        Dialog(onDismissRequest = { showCartSheet = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, ElectricPurple)
                    .background(PanelDark)
                    .padding(24.dp)
            ) {
                Column {
                    Text("YOUR RAVER STATION CART", style = MaterialTheme.typography.titleLarge, color = TextWhite)
                    Spacer(modifier = Modifier.height(16.dp))

                    if (cart.isEmpty()) {
                        Text("CART IS EMPTY. FILL WITH CARGO.", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                    } else {
                        val cartItemsList = cart.keys.toList()
                        var totalAmount = 0.0
                        cartItemsList.forEach { itemId ->
                            val item = items.find { it.id == itemId }
                            item?.let {
                                val qty = cart[itemId] ?: 0
                                totalAmount += item.price * qty
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(it.name, style = MaterialTheme.typography.titleMedium, fontSize = 11.sp, color = TextWhite)
                                        Text("$qty x $${String.format("%.2f", it.price)}", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                                    }
                                    Row {
                                        IconButton(onClick = { onRemoveFromCart(it.id) }) {
                                            Icon(Icons.Filled.RemoveCircleOutline, "Minus", tint = TextMediumGrey)
                                        }
                                        IconButton(onClick = { onAddToCart(it.id) }) {
                                            Icon(Icons.Filled.AddCircleOutline, "Add", tint = ElectricPurple)
                                        }
                                    }
                                }
                                Divider(color = BorderDark)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("SUBTOTAL SECURED", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                            Text("$${String.format("%.2f", totalAmount)}", style = MaterialTheme.typography.titleLarge, color = ElectricBlue)
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        if (isCheckingOut) {
                            CircularProgressIndicator(color = ElectricPurple, modifier = Modifier.align(Alignment.CenterHorizontally))
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showCartSheet = false },
                                    colors = ButtonDefaults.buttonColors(containerColor = BorderDark),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("ABORT", color = TextWhite)
                                }
                                Button(
                                    onClick = { onCheckout() },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("STRIPE BUY", color = Color.Black, style = MaterialTheme.typography.labelLarge)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (checkoutMessage != null) {
        Dialog(onDismissRequest = onDismissMessage) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, SuccessGreen)
                    .background(BackgroundDark)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Filled.Check, "Success", tint = SuccessGreen, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(checkoutMessage, style = MaterialTheme.typography.titleLarge, color = TextWhite, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { onDismissMessage(); showCartSheet = false },
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                        shape = RoundedCornerShape(2.dp)
                    ) {
                        Text("ACKNOWLEDGEMENT", color = Color.Black)
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: MEDIA PLATFORM ---
@Composable
fun MediaScreen(
    items: List<MediaItem>,
    downloads: Set<String>,
    onToggleDownload: (String) -> Unit,
    playingMediaId: String?,
    isPlaying: Boolean,
    onTogglePlay: (String) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("UNION MEDIA", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }
            Text("OFFLINE ARCHIVES ACTIVE", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
        }

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            items(items) { item ->
                val isCurrent = playingMediaId == item.id
                val isDownloaded = downloads.contains(item.id)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (isCurrent) ElectricPurple else BorderDark)
                        .background(PanelDark)
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play action button
                        IconButton(
                            onClick = { onTogglePlay(item.id) },
                            modifier = Modifier
                                .background(if (isCurrent) ElectricPurple else BorderDark, CircleShape)
                        ) {
                            Icon(
                                imageVector = if (isCurrent && isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Play",
                                tint = TextWhite
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                item.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontSize = 12.sp,
                                color = TextWhite
                            )
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.padding(top = 4.dp)
                            ) {
                                Text("ARTIST: ${item.artistName}", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey, fontSize = 10.sp)
                                Text("DURATION: ${item.duration}", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey, fontSize = 10.sp)
                            }
                        }

                        // Offline Download trigger
                        IconButton(onClick = { onToggleDownload(item.id) }) {
                            Icon(
                                imageVector = if (isDownloaded) Icons.Filled.DownloadDone else Icons.Outlined.Download,
                                contentDescription = "Download",
                                tint = if (isDownloaded) SuccessGreen else TextMediumGrey
                            )
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: WAREHOUSE BRUTALIST Canvas-drawn MAP ---
@Composable
fun NYCWarehouseMapScreen(events: List<Event>, onBack: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("NYC RADAR MAP", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }
            Text("NYC INDUSTRIAL WAREHOUSES", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .border(1.dp, BorderDark)
                .background(BackgroundDark)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                // Background coordinates matrix lines
                val matrixSpacing = 30.dp.toPx()
                for (x in 0..size.width.toInt() step matrixSpacing.toInt()) {
                    drawLine(color = BorderDark.copy(alpha = 0.1f), start = Offset(x.toFloat(), 0f), end = Offset(x.toFloat(), size.height))
                }
                for (y in 0..size.height.toInt() step matrixSpacing.toInt()) {
                    drawLine(color = BorderDark.copy(alpha = 0.1f), start = Offset(0f, y.toFloat()), end = Offset(size.width, y.toFloat()))
                }

                // Subway path drawings (G Line & L Line)
                // L Subway line (Grey steel)
                val lPath = Path().apply {
                    moveTo(0f, size.height * 0.4f)
                    lineTo(size.width * 0.3f, size.height * 0.4f)
                    lineTo(size.width * 0.7f, size.height * 0.7f)
                    lineTo(size.width, size.height * 0.7f)
                }
                drawPath(lPath, color = Color.Gray, style = Stroke(width = 3.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)))

                // Queens Subway line (Green/Blue)
                val qPath = Path().apply {
                    moveTo(size.width * 0.2f, 0f)
                    lineTo(size.width * 0.2f, size.height * 0.5f)
                    lineTo(size.width * 0.5f, size.height)
                }
                drawPath(qPath, color = ElectricBlue.copy(alpha = 0.5f), style = Stroke(width = 2.dp.toPx()))

                // Draw Venue Blinking Radar nodes
                val pulse = sin(System.currentTimeMillis() / 300.0).toFloat()
                
                // The Hangar (Brooklyn)
                val hangarOffset = Offset(size.width * 0.5f, size.height * 0.55f)
                drawCircle(color = ElectricPurple.copy(alpha = 0.2f + 0.1f * pulse), center = hangarOffset, radius = (15.dp.toPx() + 5.dp.toPx() * pulse))
                drawCircle(color = ElectricPurple, center = hangarOffset, radius = 5.dp.toPx())

                // The Vault (Queens)
                val vaultOffset = Offset(size.width * 0.3f, size.height * 0.25f)
                drawCircle(color = ElectricBlue.copy(alpha = 0.2f + 0.1f * pulse), center = vaultOffset, radius = (15.dp.toPx() + 5.dp.toPx() * pulse))
                drawCircle(color = ElectricBlue, center = vaultOffset, radius = 5.dp.toPx())

                // Sunset Warehouse 19 (South Brooklyn)
                val sunsetOffset = Offset(size.width * 0.8f, size.height * 0.85f)
                drawCircle(color = ElectricPurple.copy(alpha = 0.2f + 0.1f * pulse), center = sunsetOffset, radius = (15.dp.toPx() + 5.dp.toPx() * pulse))
                drawCircle(color = ElectricPurple, center = sunsetOffset, radius = 5.dp.toPx())
            }

            // Labels for Canvas Map
            Box(Modifier.align(Alignment.TopStart).padding(16.dp)) {
                Text("NYC SUBWAY SYSTEM GRID //", color = TextMediumGrey, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            }
            
            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 100.dp, y = 140.dp)
                    .background(PanelDark)
                    .border(1.dp, BorderDark)
                    .padding(4.dp)
            ) {
                Text("THE VAULT LIC", color = ElectricBlue, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            }

            Box(
                Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 150.dp, y = 300.dp)
                    .background(PanelDark)
                    .border(1.dp, BorderDark)
                    .padding(4.dp)
            ) {
                Text("THE HANGAR BUSHWICK", color = ElectricPurple, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            }

            Box(
                Modifier
                    .align(Alignment.BottomEnd)
                    .padding(bottom = 60.dp, end = 20.dp)
                    .background(PanelDark)
                    .border(1.dp, BorderDark)
                    .padding(4.dp)
            ) {
                Text("WAREHOUSE 19 SUNSET PARK", color = ElectricPurple, style = MaterialTheme.typography.labelSmall, fontSize = 8.sp)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Directions list
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.height(180.dp)) {
            items(events) { event ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, BorderDark)
                        .background(PanelDark)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(event.venueName, style = MaterialTheme.typography.titleMedium, fontSize = 11.sp, color = TextWhite)
                        Text(event.travelDirections, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey, fontSize = 9.sp)
                    }
                    Text("COORD: ${String.format("%.4f", event.lat)}, ${String.format("%.4f", event.lng)}", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = ElectricBlue)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
    }
}

// --- SUB SCREEN: SEARCH ENGINE ---
@Composable
fun SearchScreen(
    events: List<Event>,
    artists: List<Artist>,
    query: String,
    onQueryChange: (String) -> Unit,
    category: String,
    onCategoryChange: (String) -> Unit,
    onSelectEvent: (String) -> Unit,
    onSelectArtist: (String) -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("SEARCH CORE", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }
            Text("DB STATUS: OK", style = MaterialTheme.typography.labelSmall, color = SuccessGreen)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            placeholder = { Text("SEARCH ARTIST, GENRE, VENUE...", color = TextMediumGrey) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite,
                focusedBorderColor = ElectricPurple,
                unfocusedBorderColor = BorderDark
            ),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Categories selector
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            listOf("ALL", "EVENTS", "ARTISTS").forEach { cat ->
                val isSelected = category == cat
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSelected) ElectricPurple else PanelDark)
                        .border(1.dp, if (isSelected) ElectricPurple else BorderDark)
                        .clickable { onCategoryChange(cat) }
                        .padding(10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(cat, style = MaterialTheme.typography.labelSmall, color = TextWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Filter logic
            val filteredEvents = events.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.venueName.contains(query, ignoreCase = true) ||
                it.genreTags.contains(query, ignoreCase = true)
            }

            val filteredArtists = artists.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.genres.contains(query, ignoreCase = true)
            }

            if (category == "ALL" || category == "EVENTS") {
                item {
                    Text("EVENTS DISCOVERED //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                }
                if (filteredEvents.isEmpty()) {
                    item { Text("NO EVENTS MATCH MATCH", style = MaterialTheme.typography.bodyMedium, color = TextDarkGrey) }
                } else {
                    items(filteredEvents) { event ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderDark)
                                .background(PanelDark)
                                .clickable { onSelectEvent(event.id) }
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(event.title, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                                Text(event.venueName, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                            }
                            Icon(Icons.Filled.ChevronRight, "Discover", tint = TextMediumGrey)
                        }
                    }
                }
            }

            if (category == "ALL" || category == "ARTISTS") {
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("ARTISTS DISCOVERED //", style = MaterialTheme.typography.labelSmall, color = TextMediumGrey)
                }
                if (filteredArtists.isEmpty()) {
                    item { Text("NO ARTISTS MATCH MATCH", style = MaterialTheme.typography.bodyMedium, color = TextDarkGrey) }
                } else {
                    items(filteredArtists) { artist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, BorderDark)
                                .background(PanelDark)
                                .clickable { onSelectArtist(artist.id) }
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(artist.name, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                                Text(artist.genres, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                            }
                            Icon(Icons.Filled.ChevronRight, "Discover", tint = TextMediumGrey)
                        }
                    }
                }
            }
        }
    }
}

// --- SUB SCREEN: ADMIN PORTAL ---
@Composable
fun AdminPanelScreen(
    onAddEvent: (String, String, String, String, String, String, Double) -> Unit,
    onTriggerPush: (String) -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    var eventTitle by remember { mutableStateOf("") }
    var eventSub by remember { mutableStateOf("WAREHOUSE RAVE") }
    var eventDate by remember { mutableStateOf("SAT JUL 20") }
    var eventVenue by remember { mutableStateOf("THE MAIN HALL") }
    var eventGenres by remember { mutableStateOf("HARD TECHNO, ACID") }
    var eventLineUp by remember { mutableStateOf("DVS1, VTSS") }
    var eventPrice by remember { mutableStateOf("40.00") }

    var pushTitle by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("STAFF WORKSPACE", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }
            Text("STAFF LOGGED IN", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Create event section
        Text("INGEST NEW WAREHOUSE EVENT //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderDark)
                .background(PanelDark)
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = eventTitle,
                    onValueChange = { eventTitle = it },
                    label = { Text("EVENT TITLE", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = eventSub,
                    onValueChange = { eventSub = it },
                    label = { Text("EVENT SUBTITLE", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = eventDate,
                    onValueChange = { eventDate = it },
                    label = { Text("DATE (E.G. SAT JUL 20)", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = eventVenue,
                    onValueChange = { eventVenue = it },
                    label = { Text("VENUE LOCATION", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = eventGenres,
                    onValueChange = { eventGenres = it },
                    label = { Text("GENRES TAGS", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = eventLineUp,
                    onValueChange = { eventLineUp = it },
                    label = { Text("LINEUP (COMMA SEPARATED)", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = eventPrice,
                    onValueChange = { eventPrice = it },
                    label = { Text("ENTRY PRICE MINIMUM", color = TextMediumGrey) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = ElectricPurple, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        val parsedPrice = eventPrice.toDoubleOrNull() ?: 40.0
                        if (eventTitle.isNotBlank()) {
                            onAddEvent(eventTitle, eventSub, eventDate, eventVenue, eventGenres, eventLineUp, parsedPrice)
                            eventTitle = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("INGEST TO CORE DB", color = TextWhite)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Emit Simulated Push notification
        Text("EMIT EMERGENCY STAFF ANNOUNCEMENT //", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
        Spacer(modifier = Modifier.height(8.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderDark)
                .background(PanelDark)
                .padding(16.dp)
        ) {
            Column {
                OutlinedTextField(
                    value = pushTitle,
                    onValueChange = { pushTitle = it },
                    label = { Text("ANNOUNCEMENT ALERTER BODY", color = TextMediumGrey) },
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = TextWhite, unfocusedTextColor = TextWhite, focusedBorderColor = WarningAmber, unfocusedBorderColor = BorderDark),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (pushTitle.isNotBlank()) {
                            onTriggerPush(pushTitle)
                            pushTitle = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                    shape = RoundedCornerShape(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("EMIT BROADCAST", color = Color.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// --- SUB SCREEN: DIGITAL PASSPORT & PROFILE ---
@Composable
fun ProfileScreen(
    events: List<Event>,
    badges: List<Badge>,
    onSelectEvent: (String) -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .verticalScroll(scrollState)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("MY DIGITAL PROFILE", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }
            Text("LEVEL I PASSPORT", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Avatar banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, BorderDark)
                .background(PanelDark)
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .background(ElectricPurple, shape = CircleShape)
                    .border(1.dp, TextWhite, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text("UY", style = MaterialTheme.typography.titleLarge, color = TextWhite)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text("RAVER ID // 002498", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                Text("tom@ahyx.org", style = MaterialTheme.typography.titleMedium, color = TextWhite)
                Text("UNION MEMBER SINCE 2026", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Secured entry tickets
        Text("SECURED PASSES //", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
        Spacer(modifier = Modifier.height(8.dp))

        val securedPasses = events.filter { it.isPurchased }
        if (securedPasses.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderDark)
                    .background(PanelDark)
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("NO DIGITAL ENTRY PASSES IN INVENTORY", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
            }
        } else {
            securedPasses.forEach { pass ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, SuccessGreen)
                        .background(PanelDark)
                        .clickable { onSelectEvent(pass.id) }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(pass.title, style = MaterialTheme.typography.titleLarge, color = TextWhite)
                        Text(pass.venueName, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                    }
                    Box(
                        modifier = Modifier
                            .background(SuccessGreen)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("ENTRY PASS", style = MaterialTheme.typography.labelSmall, color = Color.Black)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Achievement Badges
        Text("EARNED RAVE PASSPORT BADGES //", style = MaterialTheme.typography.labelSmall, color = ElectricPurple)
        Spacer(modifier = Modifier.height(8.dp))

        if (badges.isEmpty()) {
            Text("NO EARNED BADGES RECORDED", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                badges.forEach { badge ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ElectricPurple)
                            .background(PanelDark)
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = when(badge.iconName) {
                                "ic_subway" -> Icons.Filled.DirectionsSubway
                                "ic_iron" -> Icons.Filled.Architecture
                                "ic_concrete" -> Icons.Filled.Warehouse
                                "ic_ticket" -> Icons.Filled.ConfirmationNumber
                                else -> Icons.Filled.WorkspacePremium
                            },
                            contentDescription = "Badge",
                            tint = ElectricPurple,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(badge.name, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                                Text(badge.dateEarned, style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                            }
                            Text(badge.description, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

// --- SUB SCREEN: NOTIFICATIONS HUB ---
@Composable
fun NotificationsHubScreen(
    notifications: List<Announcement>,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = TextWhite)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("RADAR NOTIFICATIONS", style = MaterialTheme.typography.displayMedium, color = TextWhite)
            }
            Text("SYS ARCHIVE active", style = MaterialTheme.typography.labelSmall, color = WarningAmber)
        }

        Spacer(modifier = Modifier.height(20.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            if (notifications.isEmpty()) {
                item {
                    Text("NO RECENT NOTIFICATIONS EMITTED", style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                }
            } else {
                items(notifications) { n ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, BorderDark)
                            .background(PanelDark)
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("SYSTEM TRANSMISSION", style = MaterialTheme.typography.labelSmall, color = WarningAmber, fontSize = 8.sp)
                                Text("SECURED", style = MaterialTheme.typography.labelSmall, color = ElectricBlue, fontSize = 8.sp)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(n.text, style = MaterialTheme.typography.titleMedium, color = TextWhite)
                        }
                    }
                }
            }
        }
    }
}

// --- HELPER COMPOSABLE: LASER LIGHT SHOW BACKGROUND ---
@Composable
fun LaserLightShow(enabled: Boolean) {
    if (!enabled) return

    val infiniteTransition = rememberInfiniteTransition("Lasers")
    val laserPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "LaserPhase"
    )

    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        
        // Simulating 3 rotating lasers radiating from different corners of the warehouse
        val laser1X = width * (0.5f + 0.5f * sin(laserPhase * 2 * Math.PI).toFloat())
        drawLine(
            color = ElectricPurple.copy(alpha = 0.08f),
            start = Offset(0f, 0f),
            end = Offset(laser1X, height),
            strokeWidth = 3.dp.toPx()
        )

        val laser2X = width * (0.5f + 0.5f * sin(laserPhase * 2 * Math.PI + Math.PI / 2).toFloat())
        drawLine(
            color = ElectricBlue.copy(alpha = 0.05f),
            start = Offset(width, 0f),
            end = Offset(laser2X, height),
            strokeWidth = 2.5.dp.toPx()
        )

        val laser3Y = height * (0.5f + 0.5f * sin(laserPhase * 2 * Math.PI + Math.PI).toFloat())
        drawLine(
            color = ElectricPurple.copy(alpha = 0.06f),
            start = Offset(0f, height * 0.3f),
            end = Offset(width, laser3Y),
            strokeWidth = 2.dp.toPx()
        )
    }
}

// --- HELPER COMPOSABLE: HORIZONTAL SCROLLING ANNOUNCEMENT TICKER ---
@Composable
fun AnnouncementTicker() {
    val infiniteTransition = rememberInfiniteTransition("Ticker")
    val tickerOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -500f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Offset"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelDark)
            .border(width = 1.dp, color = BorderDark)
            .padding(vertical = 10.dp)
            .clip(RectangleShape),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.offset(x = tickerOffset.dp)
        ) {
            val alertText = " /// WARNING: BASEMENT ACCESS TO VAULT SELLING FAST /// NEXT UNION YARD AFTERHOURS INGREDIENT INBOUND ON SAT MAY 25 /// ALL BLACK DRESS PROTOCOL REQUIRED /// NO MOBILE CAMERAS PERMITTED ON DANCEFLOOR /// MEMBERS-ONLY EARLY ACCESS TICKETS DISPATCHED ///"
            repeat(3) {
                Text(
                    text = alertText,
                    style = MaterialTheme.typography.labelLarge,
                    color = WarningAmber,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

// --- HELPER COMPOSABLE: COUNTDOWN TIMER BANNER TO NEXT EVENT ---
@Composable
fun NextEventCountdownBanner(events: List<Event>, onSelectEvent: (String) -> Unit) {
    val nextEvent = events.firstOrNull { !it.isPurchased } ?: events.firstOrNull() ?: return
    
    // Simulate real-time countdown decrementing
    var mockHours by remember { mutableStateOf(34) }
    var mockMinutes by remember { mutableStateOf(18) }
    var mockSeconds by remember { mutableStateOf(52) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (mockSeconds > 0) {
                mockSeconds--
            } else {
                mockSeconds = 59
                if (mockMinutes > 0) {
                    mockMinutes--
                } else {
                    mockMinutes = 59
                    if (mockHours > 0) {
                        mockHours--
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
            .border(width = 1.dp, color = ElectricPurple)
            .background(PanelDark)
            .clickable { onSelectEvent(nextEvent.id) }
            .padding(20.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("COUNTDOWN TO ASSEMBLAGE //", style = MaterialTheme.typography.labelSmall, color = ElectricBlue)
                    Text(nextEvent.title, style = MaterialTheme.typography.displayMedium, fontSize = 24.sp, color = TextWhite)
                    Text(nextEvent.venueName, style = MaterialTheme.typography.bodyMedium, color = TextMediumGrey)
                }
                Box(
                    modifier = Modifier
                        .background(ElectricPurple)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("ACTIVE TIMER", style = MaterialTheme.typography.labelSmall, color = TextWhite)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Timers Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val timerBlocks = listOf(
                    Pair(mockHours.toString().padStart(2, '0'), "HOURS"),
                    Pair(mockMinutes.toString().padStart(2, '0'), "MINUTES"),
                    Pair(mockSeconds.toString().padStart(2, '0'), "SECONDS")
                )

                timerBlocks.forEach { block ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .border(1.dp, BorderDark)
                            .background(BackgroundDark)
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = block.first, style = MaterialTheme.typography.displayMedium, color = ElectricPurple, fontSize = 28.sp)
                            Text(text = block.second, style = MaterialTheme.typography.labelSmall, color = TextMediumGrey, fontSize = 8.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CAPACITY: ${nextEvent.remainingCapacity} PASSES LEFT",
                    style = MaterialTheme.typography.labelSmall,
                    color = WarningAmber
                )
                Text(
                    text = "GET TICKET →",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
