package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.UnionYardRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class UnionYardViewModel(private val repository: UnionYardRepository) : ViewModel() {

    // --- DB State Flows ---
    val events: StateFlow<List<Event>> = repository.allEvents
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val artists: StateFlow<List<Artist>> = repository.allArtists
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mediaItems: StateFlow<List<MediaItem>> = repository.allMediaItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val badges: StateFlow<List<Badge>> = repository.allBadges
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val merchItems: StateFlow<List<MerchItem>> = repository.allMerchItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- UI/UX Interactive States ---
    private val _selectedEventId = MutableStateFlow<String?>(null)
    val selectedEventId = _selectedEventId.asStateFlow()

    val selectedEvent: StateFlow<Event?> = _selectedEventId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getEventById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private val _selectedArtistId = MutableStateFlow<String?>(null)
    val selectedArtistId = _selectedArtistId.asStateFlow()

    val selectedArtist: StateFlow<Artist?> = _selectedArtistId
        .flatMapLatest { id ->
            if (id == null) flowOf(null) else repository.getArtistById(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- Live Mode & Simulations ---
    private val _isInsideVenue = MutableStateFlow(false)
    val isInsideVenue = _isInsideVenue.asStateFlow()

    private val _liveActiveEventId = MutableStateFlow("afterhours")
    val liveActiveEventId = _liveActiveEventId.asStateFlow()

    // --- Merch Cart & Stripe Checkout Simulator ---
    private val _cart = MutableStateFlow<Map<String, Int>>(emptyMap()) // MerchItem.id -> Quantity
    val cart = _cart.asStateFlow()

    private val _isCheckingOut = MutableStateFlow(false)
    val isCheckingOut = _isCheckingOut.asStateFlow()

    private val _checkoutSuccessMessage = MutableStateFlow<String?>(null)
    val checkoutSuccessMessage = _checkoutSuccessMessage.asStateFlow()

    // --- Community Crews & Interactive States ---
    private val _crews = MutableStateFlow<List<String>>(listOf("BK RAWER CREW", "L-TRAIN STOMPERS"))
    val crews = _crews.asStateFlow()

    private val _crewChats = MutableStateFlow<List<Pair<String, String>>>(
        listOf(
            "BK RAWER CREW" to "Are we hitting the Hangar at 11 or midnight?",
            "L-TRAIN STOMPERS" to "Klangkuenstler plays at 2:30 AM! Don't miss it.",
            "BK RAWER CREW" to "Strobes are going to be insane tonight."
        )
    )
    val crewChats = _crewChats.asStateFlow()

    // --- Offline Downloads ---
    private val _downloadedMediaIds = MutableStateFlow<Set<String>>(emptySet())
    val downloadedMediaIds = _downloadedMediaIds.asStateFlow()

    // --- Simulated Notifications ---
    private val _notifications = MutableStateFlow<List<Announcement>>(
        listOf(
            Announcement("1", "SECRET WATERFRONT LOCATION RELEASED FOR BEYOND"),
            Announcement("2", "SET TIMES ANNOUNCED FOR AFTERHOURS RAVE"),
            Announcement("3", "LINE-UP UPDATE: SHXCXCHCXSH ADDED TO HANGAR MAIN ROOM")
        )
    )
    val notifications = _notifications.asStateFlow()

    init {
        viewModelScope.launch {
            repository.checkAndPrepopulate()
        }
    }

    // --- Actions ---

    fun selectEvent(id: String?) {
        _selectedEventId.value = id
    }

    fun selectArtist(id: String?) {
        _selectedArtistId.value = id
    }

    fun toggleSaveEvent(event: Event) {
        viewModelScope.launch {
            repository.toggleSavedStatus(event.id, event.isSaved)
        }
    }

    fun purchaseTicket(eventId: String, ticketType: String) {
        viewModelScope.launch {
            repository.purchaseTicket(eventId, ticketType)
            // Auto earn badge when purchasing first ticket!
            val currentBadges = badges.value
            if (!currentBadges.any { it.id == "badge_ticket" }) {
                repository.addBadge(
                    Badge(
                        id = "badge_ticket",
                        name = "FIRST CONTACT",
                        description = "Secured your very first digital entry credentials to UNION YARD.",
                        iconName = "ic_ticket",
                        dateEarned = "TODAY",
                        venueName = "UNION YARD PLATFORM"
                    )
                )
            }
        }
    }

    fun simulateVenueArrival(isInside: Boolean) {
        _isInsideVenue.value = isInside
        if (isInside) {
            viewModelScope.launch {
                // Earn venue check-in badge!
                val currentBadges = badges.value
                val hasHangarBadge = currentBadges.any { it.id == "badge_hangar" }
                if (!hasHangarBadge) {
                    repository.addBadge(
                        Badge(
                            id = "badge_hangar",
                            name = "HANGAR ENCLAVE",
                            description = "Unlocked by stepping onto the concrete floor of the Morgan Ave Hangar.",
                            iconName = "ic_concrete",
                            dateEarned = "TODAY",
                            venueName = "THE HANGAR, BROOKLYN"
                        )
                    )
                }
            }
        }
    }

    fun setLiveActiveEvent(id: String) {
        _liveActiveEventId.value = id
    }

    // Merch Cart Methods
    fun addToCart(itemId: String) {
        val current = _cart.value.toMutableMap()
        current[itemId] = (current[itemId] ?: 0) + 1
        _cart.value = current
    }

    fun removeFromCart(itemId: String) {
        val current = _cart.value.toMutableMap()
        val qty = current[itemId] ?: 0
        if (qty <= 1) {
            current.remove(itemId)
        } else {
            current[itemId] = qty - 1
        }
        _cart.value = current
    }

    fun clearCart() {
        _cart.value = emptyMap()
    }

    fun simulateStripeCheckout() {
        if (_cart.value.isEmpty()) return
        viewModelScope.launch {
            _isCheckingOut.value = true
            kotlinx.coroutines.delay(2000) // Simulated processing network delay
            _isCheckingOut.value = false
            _checkoutSuccessMessage.value = "STRIPE PURCHASE SECURED. WORK WEAR ON THE WAY."
            clearCart()
        }
    }

    fun dismissCheckoutSuccess() {
        _checkoutSuccessMessage.value = null
    }

    // Community Methods
    fun createCrew(name: String) {
        val current = _crews.value.toMutableList()
        if (!current.contains(name.uppercase())) {
            current.add(name.uppercase())
            _crews.value = current
        }
    }

    fun postCrewChat(crew: String, text: String) {
        if (text.isBlank()) return
        val current = _crewChats.value.toMutableList()
        current.add(crew to text)
        _crewChats.value = current
    }

    // Media Offline Manager
    fun toggleMediaDownload(mediaId: String) {
        val current = _downloadedMediaIds.value.toMutableSet()
        if (current.contains(mediaId)) {
            current.remove(mediaId)
        } else {
            current.add(mediaId)
        }
        _downloadedMediaIds.value = current
    }

    // Admin Creation Methods
    fun adminCreateEvent(
        title: String,
        subtitle: String,
        date: String,
        venue: String,
        genres: String,
        lineUp: String,
        price: Double
    ) {
        viewModelScope.launch {
            val id = title.lowercase().replace(" ", "_")
            val newEvent = Event(
                id = id,
                title = title.uppercase(),
                subtitle = subtitle.uppercase(),
                dateStr = date.uppercase(),
                timeStr = "10PM - LATE",
                venueName = venue.uppercase(),
                description = "Custom staff-approved Union Yard warehouse gathering promoting pure electronic frequency.",
                lineUp = lineUp.uppercase(),
                ticketPriceMin = price,
                remainingCapacity = 500,
                totalCapacity = 500,
                genreTags = genres.uppercase(),
                lat = 40.7128,
                lng = -74.0060
            )
            repository.insertEvent(newEvent)
        }
    }

    fun triggerStaffNotification(title: String) {
        val current = _notifications.value.toMutableList()
        current.add(0, Announcement(System.currentTimeMillis().toString(), title.uppercase()))
        _notifications.value = current
    }
}

class UnionYardViewModelFactory(private val repository: UnionYardRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UnionYardViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UnionYardViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
