package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundDark = Color(0xFF050505)
val PanelDark = Color(0xFF101010)
val BorderDark = Color(0xFF2B2B2B)
val ElectricPurple = Color(0xFF8A2EFF)
val ElectricBlue = Color(0xFF00AEEF)
val SuccessGreen = Color(0xFF00D17A)
val WarningAmber = Color(0xFFF59E0B)

val TextWhite = Color(0xFFFFFFFF)
val TextLightGrey = Color(0xFFE0E0E0)
val TextMediumGrey = Color(0xFF888888)
val TextDarkGrey = Color(0xFF2E2E2E)

