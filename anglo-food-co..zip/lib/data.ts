export interface ModifierOption {
  id: string;
  name: string;
  price: number;
}

export interface ModifierGroup {
  id: string;
  title: string;
  required: boolean;
  type: 'radio' | 'checkbox';
  options: ModifierOption[];
}

export interface MenuItem {
  id: string;
  name: string;
  category: 'CHICKEN' | 'BEEF' | 'FISH' | 'VEGETABLE' | 'SIDES' | 'SAUCES' | 'DRINKS' | 'DESSERT';
  price: number;
  description: string;
  image: string;
  prepTimeMinutes: number;
  isPopular?: boolean;
  dietary: {
    isVegetarian?: boolean;
    isVegan?: boolean;
    isGlutenFree?: boolean;
    containsNuts?: boolean;
    containsDairy?: boolean;
  };
  ingredients: string[];
  allergens: string[];
  nutrition: {
    calories: number;
    protein: number; // in grams
    carbs: number; // in grams
    fat: number; // in grams
    salt: number; // in grams
  };
  modifierGroups?: ModifierGroup[];
}

export interface Kitchen {
  id: string;
  code: string;
  name: string;
  address: string;
  postcode: string;
  city: string;
  distanceMiles: number;
  status: 'OPEN' | 'BUSY' | 'CLOSED';
  service: string;
  hours: string;
  ordersToday: number;
  avgPrepMinutes: number;
  currentLoad: 'NORMAL' | 'HIGH' | 'LOW';
  lat: number;
  lng: number;
}

export interface IngredientDoc {
  id: string;
  title: string;
  sourceRegion: string;
  description: string;
  seasonality: string;
  preparation: string;
}

export const MENU_CATEGORIES = [
  'ALL',
  'CHICKEN',
  'BEEF',
  'FISH',
  'VEGETABLE',
  'SIDES',
  'SAUCES',
  'DRINKS',
  'DESSERT',
] as const;

export const MENU_ITEMS: MenuItem[] = [
  {
    id: 'roast-chicken',
    name: 'ROAST CHICKEN',
    category: 'CHICKEN',
    price: 11.50,
    description: 'Free-range chicken, roast gravy, crisp skin, house sourdough bread, watercress.',
    image: '/src/assets/images/dish_roast_chicken_1790954282183.jpg',
    prepTimeMinutes: 10,
    isPopular: true,
    dietary: {
      isVegetarian: false,
      isGlutenFree: false,
      containsNuts: false,
      containsDairy: true,
    },
    ingredients: [
      'Free-Range Norfolk Chicken',
      'Anglo Slow-Simmered Poultry Gravy',
      'Artisan Sourdough Slice',
      'Fresh Fresh British Watercress',
      'Maldon Sea Salt & Thyme Butter'
    ],
    allergens: ['Gluten', 'Milk', 'Celery'],
    nutrition: {
      calories: 680,
      protein: 52,
      carbs: 34,
      fat: 22,
      salt: 1.8,
    },
    modifierGroups: [
      {
        id: 'side',
        title: 'CHOOSE YOUR SIDE',
        required: true,
        type: 'radio',
        options: [
          { id: 'side-chips', name: 'Triple-Cooked Chips', price: 0 },
          { id: 'side-roast-potatoes', name: 'Roast Potatoes', price: 0 },
          { id: 'side-greens', name: 'Seasonal Greens', price: 0 },
        ],
      },
      {
        id: 'sauce',
        title: 'CHOOSE YOUR SAUCE',
        required: true,
        type: 'radio',
        options: [
          { id: 'sauce-roast-gravy', name: 'Roast Gravy', price: 0 },
          { id: 'sauce-anglo-house', name: 'Anglo House Sauce', price: 0 },
          { id: 'sauce-mustard', name: 'English Herb Mustard', price: 0 },
          { id: 'sauce-none', name: 'No Sauce', price: 0 },
        ],
      },
      {
        id: 'extras',
        title: 'EXTRAS',
        required: false,
        type: 'checkbox',
        options: [
          { id: 'extra-chicken', name: 'Extra Half Chicken Portion', price: 5.50 },
          { id: 'extra-gravy', name: 'Extra Gravy Boat', price: 1.50 },
          { id: 'extra-cheddar', name: 'Aged Somerset Cheddar Slice', price: 1.20 },
        ],
      },
    ],
  },
  {
    id: 'british-beef-burger',
    name: 'BRITISH BEEF BURGER',
    category: 'BEEF',
    price: 12.50,
    description: 'Dry-aged British beef, mature cheddar, caramelized onions, Anglo sauce, toasted house bun.',
    image: '/src/assets/images/dish_british_beef_burger_1790954295476.jpg',
    prepTimeMinutes: 8,
    isPopular: true,
    dietary: {
      isVegetarian: false,
      isGlutenFree: false,
      containsNuts: false,
      containsDairy: true,
    },
    ingredients: [
      '100% British Grass-Fed Beef (Aberdeen Angus)',
      'Aged West Country Cheddar (18 Months)',
      'Slow-Cooked Shallots & Onions',
      'House Secret Anglo Sauce (Smoked Mayo & English Pickle)',
      'Brioche Bun'
    ],
    allergens: ['Gluten', 'Milk', 'Eggs', 'Mustard'],
    nutrition: {
      calories: 790,
      protein: 44,
      carbs: 48,
      fat: 38,
      salt: 2.2,
    },
    modifierGroups: [
      {
        id: 'side',
        title: 'CHOOSE YOUR SIDE',
        required: true,
        type: 'radio',
        options: [
          { id: 'side-chips', name: 'Triple-Cooked Chips', price: 0 },
          { id: 'side-roast-potatoes', name: 'Roast Potatoes', price: 0 },
          { id: 'side-greens', name: 'Seasonal Greens', price: 0 },
        ],
      },
      {
        id: 'extras',
        title: 'EXTRAS',
        required: false,
        type: 'checkbox',
        options: [
          { id: 'extra-patty', name: 'Extra Beef Patty', price: 4.50 },
          { id: 'extra-bacon', name: 'Smoked British Bacon', price: 2.00 },
          { id: 'extra-pickle', name: 'Crisp Dill Pickle', price: 0.80 },
        ],
      },
    ],
  },
  {
    id: 'fish-and-chips',
    name: 'FISH & CHIPS',
    category: 'FISH',
    price: 13.50,
    description: 'Crisp Atlantic white fish in craft ale batter, triple-cooked chips, sea salt, malt vinegar reduction.',
    image: '/src/assets/images/dish_fish_and_chips_1790954306389.jpg',
    prepTimeMinutes: 10,
    isPopular: true,
    dietary: {
      isVegetarian: false,
      isGlutenFree: false,
      containsNuts: false,
      containsDairy: false,
    },
    ingredients: [
      'Sustainably Sourced Atlantic Haddock/Cod',
      'Yorkshire Pale Ale Crisp Batter',
      'Maris Piper Triple-Cooked Chips',
      'House Mushy Peas',
      'Malt Vinegar Spray & Maldon Sea Salt'
    ],
    allergens: ['Fish', 'Gluten'],
    nutrition: {
      calories: 740,
      protein: 48,
      carbs: 68,
      fat: 26,
      salt: 1.9,
    },
    modifierGroups: [
      {
        id: 'sauce',
        title: 'CHOOSE YOUR DIP',
        required: true,
        type: 'radio',
        options: [
          { id: 'sauce-tartare', name: 'House Tartare Sauce', price: 0 },
          { id: 'sauce-curry', name: 'Curry Sauce', price: 0 },
          { id: 'sauce-mushy-peas', name: 'Extra Mushy Peas', price: 0 },
        ],
      },
    ],
  },
  {
    id: 'roasted-cauliflower',
    name: 'ROASTED CAULIFLOWER',
    category: 'VEGETABLE',
    price: 10.50,
    description: 'Whole roasted British cauliflower, fresh herbs, tahini & lemon dressing, seasonal buttered greens.',
    image: '/src/assets/images/dish_roasted_cauliflower_1790954317110.jpg',
    prepTimeMinutes: 9,
    dietary: {
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: true,
      containsNuts: false,
      containsDairy: false,
    },
    ingredients: [
      'Whole Lincolnshire Cauliflower',
      'Toasted Sesame Tahini',
      'Fresh Flat Parsley & Mint',
      'Steamed Savoy Cabbage & Peas',
      'Extra Virgin Rapeseed Oil'
    ],
    allergens: ['Sesame'],
    nutrition: {
      calories: 420,
      protein: 16,
      carbs: 28,
      fat: 22,
      salt: 1.1,
    },
    modifierGroups: [
      {
        id: 'side',
        title: 'CHOOSE YOUR SIDE',
        required: true,
        type: 'radio',
        options: [
          { id: 'side-chips', name: 'Triple-Cooked Chips', price: 0 },
          { id: 'side-greens', name: 'Steamed Greens', price: 0 },
        ],
      },
    ],
  },
  {
    id: 'steak-and-ale-pie',
    name: 'STEAK & ALE PIE',
    category: 'BEEF',
    price: 13.00,
    description: 'Tender British beef chuck slow-braised in Yorkshire ale, all-butter puff pastry, bone marrow gravy.',
    image: '/src/assets/images/dish_british_beef_burger_1790954295476.jpg', // Fallback styled image
    prepTimeMinutes: 12,
    dietary: {
      isVegetarian: false,
      isGlutenFree: false,
      containsNuts: false,
      containsDairy: true,
    },
    ingredients: [
      'British Beef Chuck',
      'Black Sheep Brewery Bitter',
      'All-Butter Shortcrust & Puff Pastry',
      'Carrots & Roscoff Onions',
      'Bone Marrow Reduction'
    ],
    allergens: ['Gluten', 'Milk', 'Celery', 'Eggs'],
    nutrition: {
      calories: 820,
      protein: 42,
      carbs: 58,
      fat: 42,
      salt: 2.4,
    },
  },
  {
    id: 'triple-cooked-chips',
    name: 'TRIPLE-COOKED CHIPS',
    category: 'SIDES',
    price: 4.00,
    description: 'Thick-cut Maris Piper potatoes, hand-steamed, chilled, and triple-cooked in rapeseed oil.',
    image: '/src/assets/images/dish_fish_and_chips_1790954306389.jpg',
    prepTimeMinutes: 5,
    dietary: {
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: true,
      containsNuts: false,
      containsDairy: false,
    },
    ingredients: ['Maris Piper Potatoes', 'Cold-Pressed Rapeseed Oil', 'Maldon Sea Salt Flakes'],
    allergens: [],
    nutrition: {
      calories: 380,
      protein: 5,
      carbs: 48,
      fat: 18,
      salt: 0.9,
    },
  },
  {
    id: 'seasonal-greens',
    name: 'SEASONAL BRITISH GREENS',
    category: 'SIDES',
    price: 4.00,
    description: 'Lightly buttered Savoy cabbage, garden peas, lemon zest, sea salt.',
    image: '/src/assets/images/dish_roasted_cauliflower_1790954317110.jpg',
    prepTimeMinutes: 4,
    dietary: {
      isVegetarian: true,
      isVegan: false,
      isGlutenFree: true,
      containsNuts: false,
      containsDairy: true,
    },
    ingredients: ['British Savoy Cabbage', 'English Garden Peas', 'Unsalted Butter', 'Lemon Zest'],
    allergens: ['Milk'],
    nutrition: {
      calories: 140,
      protein: 6,
      carbs: 12,
      fat: 7,
      salt: 0.5,
    },
  },
  {
    id: 'anglo-house-gravy',
    name: 'ANGLO HOUSE GRAVY',
    category: 'SAUCES',
    price: 1.50,
    description: '24-hour slow simmered roasting gravy with caramelised onions and herbs.',
    image: '/src/assets/images/dish_roast_chicken_1790954282183.jpg',
    prepTimeMinutes: 2,
    dietary: {
      isVegetarian: false,
      isGlutenFree: false,
      containsNuts: false,
    },
    ingredients: ['Roasted Beef & Chicken Bones', 'Caramelised Roscoff Onions', 'Fresh Thyme', 'Red Wine Reduction'],
    allergens: ['Celery', 'Gluten'],
    nutrition: {
      calories: 80,
      protein: 4,
      carbs: 6,
      fat: 3,
      salt: 0.8,
    },
  },
  {
    id: 'craft-yorkshire-ale',
    name: 'CRAFT YORKSHIRE ALE (330ml)',
    category: 'DRINKS',
    price: 4.80,
    description: 'Crisp, refreshing pale ale brewed in Yorkshire. 4.8% ABV.',
    image: '/src/assets/images/hero_anglo_dinner_1790954267932.jpg',
    prepTimeMinutes: 1,
    dietary: {
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: false,
    },
    ingredients: ['Spring Water', 'Malted Barley', 'British Hops', 'Yeast'],
    allergens: ['Gluten'],
    nutrition: {
      calories: 160,
      protein: 2,
      carbs: 12,
      fat: 0,
      salt: 0.05,
    },
  },
  {
    id: 'sparkling-presse',
    name: 'ANGLO SPARKLING PRESSÉ (330ml)',
    category: 'DRINKS',
    price: 3.20,
    description: 'Hand-picked British elderflower and crisp Bramley apple sparkling water.',
    image: '/src/assets/images/hero_anglo_dinner_1790954267932.jpg',
    prepTimeMinutes: 1,
    dietary: {
      isVegetarian: true,
      isVegan: true,
      isGlutenFree: true,
    },
    ingredients: ['Sparkling Spring Water', 'English Elderflower Infusion', 'Pressed Bramley Apple Juice'],
    allergens: [],
    nutrition: {
      calories: 85,
      protein: 0,
      carbs: 21,
      fat: 0,
      salt: 0.02,
    },
  },
  {
    id: 'sticky-toffee-pudding',
    name: 'STICKY TOFFEE PUDDING',
    category: 'DESSERT',
    price: 6.50,
    description: 'Warm dark date sponge, rich butterscotch sauce, served with thick Cornish clotted cream.',
    image: '/src/assets/images/dish_roast_chicken_1790954282183.jpg',
    prepTimeMinutes: 5,
    dietary: {
      isVegetarian: true,
      isGlutenFree: false,
      containsDairy: true,
    },
    ingredients: ['Medjool Dates', 'Dark Muscovado Sugar', 'Unsalted Butter', 'Wheat Flour', 'Cornish Clotted Cream'],
    allergens: ['Gluten', 'Milk', 'Eggs'],
    nutrition: {
      calories: 540,
      protein: 6,
      carbs: 68,
      fat: 28,
      salt: 0.6,
    },
  },
];

export const KITCHENS: Kitchen[] = [
  {
    id: 'london-01',
    code: 'ANGLO / LONDON 01',
    name: 'Bermondsey Central Kitchen',
    address: '42 Railway Arches, Bermondsey',
    postcode: 'SE1 2TH',
    city: 'LONDON',
    distanceMiles: 1.2,
    status: 'OPEN',
    service: 'DELIVERY + COLLECTION',
    hours: '11:30 — 23:00',
    ordersToday: 1842,
    avgPrepMinutes: 8.7,
    currentLoad: 'NORMAL',
    lat: 51.501,
    lng: -0.076,
  },
  {
    id: 'sheffield-02',
    code: 'ANGLO / SHEFFIELD 02',
    name: 'Kelham Island Kitchen',
    address: '14 Alma Street',
    postcode: 'S3 8SD',
    city: 'SHEFFIELD',
    distanceMiles: 4.5,
    status: 'OPEN',
    service: 'DELIVERY + COLLECTION',
    hours: '11:30 — 23:00',
    ordersToday: 1210,
    avgPrepMinutes: 9.2,
    currentLoad: 'NORMAL',
    lat: 53.388,
    lng: -1.472,
  },
  {
    id: 'manchester-03',
    code: 'ANGLO / MANCHESTER 03',
    name: 'Ancoats Mills Kitchen',
    address: '88 Great Ancoats St',
    postcode: 'M4 6AJ',
    city: 'MANCHESTER',
    distanceMiles: 3.1,
    status: 'OPEN',
    service: 'DELIVERY + COLLECTION',
    hours: '11:30 — 23:00',
    ordersToday: 1650,
    avgPrepMinutes: 8.2,
    currentLoad: 'NORMAL',
    lat: 53.483,
    lng: -2.232,
  },
  {
    id: 'leeds-04',
    code: 'ANGLO / LEEDS 04',
    name: 'South Bank Depot Kitchen',
    address: '3 Crown Point Road',
    postcode: 'LS10 1BD',
    city: 'LEEDS',
    distanceMiles: 2.8,
    status: 'OPEN',
    service: 'DELIVERY + COLLECTION',
    hours: '11:30 — 23:00',
    ordersToday: 980,
    avgPrepMinutes: 10.1,
    currentLoad: 'NORMAL',
    lat: 53.792,
    lng: -1.538,
  },
  {
    id: 'bristol-05',
    code: 'ANGLO / BRISTOL 05',
    name: 'Harbourside Arches Kitchen',
    address: '12 Gas Ferry Road',
    postcode: 'BS1 6XN',
    city: 'BRISTOL',
    distanceMiles: 2.1,
    status: 'OPEN',
    service: 'DELIVERY + COLLECTION',
    hours: '11:30 — 23:00',
    ordersToday: 1140,
    avgPrepMinutes: 8.5,
    currentLoad: 'NORMAL',
    lat: 51.448,
    lng: -2.603,
  },
  {
    id: 'edinburgh-06',
    code: 'ANGLO / EDINBURGH 06',
    name: 'Leith Walk Freight Kitchen',
    address: '102 Leith Walk',
    postcode: 'EH6 8NR',
    city: 'EDINBURGH',
    distanceMiles: 3.6,
    status: 'OPEN',
    service: 'DELIVERY + COLLECTION',
    hours: '11:30 — 23:00',
    ordersToday: 890,
    avgPrepMinutes: 9.8,
    currentLoad: 'NORMAL',
    lat: 55.968,
    lng: -3.175,
  },
];

export const INGREDIENT_DOCS: IngredientDoc[] = [
  {
    id: 'beef',
    title: 'BRITISH BEEF',
    sourceRegion: 'Aberdeenshire & North Yorkshire Moors',
    description: 'Dry-aged grass-fed Aberdeen Angus beef, hung for a minimum of 28 days for depth of flavour and tenderness.',
    seasonality: 'Year-Round Availability',
    preparation: 'Minced daily in-kitchen, seasoned exclusively with Maldon sea salt flaked at time of sear.',
  },
  {
    id: 'chicken',
    title: 'FREE-RANGE CHICKEN',
    sourceRegion: 'Norfolk Farms, East Anglia',
    description: 'Sustainably raised outdoor-roaming Norfolk chicken fed on natural grain diets.',
    seasonality: 'Year-Round Peak Quality',
    preparation: 'Brined in fresh thyme, bay, and sea salt for 12 hours prior to precision convection roasting.',
  },
  {
    id: 'vegetables',
    title: 'SEASONAL VEGETABLES',
    sourceRegion: 'Lincolnshire & Kent (Garden of England)',
    description: 'Lincolnshire brassicas, Kentish cabbages, and heritage carrots harvested at dawn.',
    seasonality: 'Rotated Seasonally Every 12 Weeks',
    preparation: 'Steamed or dry-roasted over high heat with cold-pressed rapeseed oil.',
  },
  {
    id: 'fish',
    title: 'FRESH WHITE FISH',
    sourceRegion: 'Peterhead & Grimsby Docks',
    description: 'Line-caught wild Atlantic cod and haddock, delivered direct from British fishing vessels within 24 hours.',
    seasonality: 'Subject to Sea Conditions & Sustainable Quotas',
    preparation: 'Dipped in ice-cold Yorkshire pale ale batter and flash-fried at 185°C.',
  },
  {
    id: 'potatoes',
    title: 'MARIS PIPER POTATOES',
    sourceRegion: 'Fens, Cambridgeshire',
    description: 'Cambridgeshire silt-grown Maris Pipers selected for dry matter density and fluffy interior.',
    seasonality: 'New Season Harvest Late Summer — Stored In Clamps',
    preparation: 'Triple-cooked: steamed, dried, first-fried at low temperature, second-fried crisp before dispatch.',
  },
  {
    id: 'bread',
    title: 'ARTISAN BREAD',
    sourceRegion: 'Bermondsey Bakery, London',
    description: 'Naturally fermented sourdough buns and loaves baked fresh every morning with British stoneground wheat.',
    seasonality: 'Baked Daily 04:30 AM',
    preparation: 'Lightly toasted with clarified butter prior to burger or roast chicken plating.',
  },
];

export const LOCALIZATION_STRINGS = {
  EN: {
    tagline: 'PROPER FOOD. MODERN SYSTEM.',
    orderDelivery: 'ORDER DELIVERY',
    collectKitchen: 'COLLECT FROM A KITCHEN',
    openToday: 'OPEN TODAY 11:30 — 23:00',
    todayFood: "TODAY'S FOOD",
    todaySubtitle: 'Straightforward food. Very good ingredients. No unnecessary complications.',
    yourOrder: 'YOUR ORDER',
    checkout: 'CHECKOUT',
    kitchens: 'ANGLO KITCHENS',
    delivery: 'DELIVERY',
    story: 'STORY',
    ingredients: 'INGREDIENTS',
    system: 'SYSTEM',
    account: 'ACCOUNT',
    demoDisclaimer: 'DEMO CHECKOUT — NO REAL PAYMENT REQUIRED',
  },
  CY: {
    tagline: 'BWYD DA. SYSTEM FODERN.',
    orderDelivery: 'ARCHEBU CYFLWYNO',
    collectKitchen: 'CASGLU O GISTIN',
    openToday: 'AR AGOR HEDDIW 11:30 — 23:00',
    todayFood: 'BWYD HEDDIW',
    todaySubtitle: 'Bwyd syml. Cynhwysion da iawn. Dim cymhlethdodau di-angen.',
    yourOrder: 'EICH ARCHEB',
    checkout: 'TSHIECIO ALLAN',
    kitchens: 'CEGINAU ANGLO',
    delivery: 'CYFLWYNO',
    story: 'STORI',
    ingredients: 'CYNHWYSIADAU',
    system: 'SYSTEM',
    account: 'CYFRIF',
    demoDisclaimer: 'TSHIECIO DEMO — DIM TALIAD REAL',
  },
  FR: {
    tagline: 'CUISINE FRANCHE. SYSTÈME MODERNE.',
    orderDelivery: 'COMMANDER EN LIVRAISON',
    collectKitchen: 'RETIRER EN CUISINE',
    openToday: 'OUVERT AUJOURDHUI 11:30 — 23:00',
    todayFood: 'LE MENU DU JOUR',
    todaySubtitle: 'Des plats simples. De très bons ingrédients. Aucune complication inutile.',
    yourOrder: 'VOTRE COMMANDE',
    checkout: 'PAIEMENT',
    kitchens: 'CUISINES ANGLO',
    delivery: 'LIVRAISON',
    story: 'HISTOIRE',
    ingredients: 'INGRÉDIENTS',
    system: 'SYSTÈME',
    account: 'COMPTE',
    demoDisclaimer: 'COMMANDO DEMO — AUCUN PAIEMENT RÉEL',
  },
  DE: {
    tagline: 'GUTES ESSEN. MODERNES SYSTEM.',
    orderDelivery: 'LIEFERUNG BESTELLEN',
    collectKitchen: 'IN DER KÜCHE ABHOLEN',
    openToday: 'HEUTE GEÖFFNET 11:30 — 23:00',
    todayFood: 'DAS ESSEN VON HEUTE',
    todaySubtitle: 'Ehrliche Küche. Sehr gute Zutaten. Keine unnötigen Komplikationen.',
    yourOrder: 'IHRE BESTELLUNG',
    checkout: 'KASSE',
    kitchens: 'ANGLO KÜCHEN',
    delivery: 'LIEFERUNG',
    story: 'GESCHICHTE',
    ingredients: 'ZUTATEN',
    system: 'SYSTEM',
    account: 'KONTO',
    demoDisclaimer: 'DEMO BESTELLUNG — KEINE ECHTE ZAHLUNG',
  },
};
