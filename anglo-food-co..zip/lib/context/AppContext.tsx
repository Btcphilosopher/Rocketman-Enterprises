'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { MenuItem, Kitchen, KITCHENS, MENU_ITEMS } from '../data';

export interface BasketItemModifier {
  groupId: string;
  groupTitle: string;
  optionId: string;
  optionName: string;
  price: number;
}

export interface BasketItem {
  id: string; // unique basket item id
  menuItem: MenuItem;
  quantity: number;
  modifiers: BasketItemModifier[];
  unitPrice: number;
  totalPrice: number;
  specialInstructions?: string;
}

export type OrderStatus =
  | 'CREATED'
  | 'CONFIRMED'
  | 'IN_KITCHEN'
  | 'COOKING'
  | 'PACKING'
  | 'DISPATCH'
  | 'ARRIVING'
  | 'COMPLETED';

export interface OrderTimelineStep {
  status: OrderStatus;
  label: string;
  timestamp: string;
  completed: boolean;
}

export interface ActiveOrder {
  orderId: string;
  kitchen: Kitchen;
  deliveryType: 'DELIVERY' | 'COLLECTION';
  deliveryAddress: {
    postcode: string;
    street: string;
    city: string;
    instructions?: string;
  };
  items: BasketItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: OrderStatus;
  estimatedArrival: string; // e.g. "18:42 — 18:52"
  createdAt: string;
  timeline: OrderTimelineStep[];
}

export interface UserAccount {
  name: string;
  email: string;
  phone: string;
  savedAddresses: {
    id: string;
    label: string;
    street: string;
    postcode: string;
    city: string;
  }[];
  favouriteItemIds: string[];
  previousOrders: ActiveOrder[];
  dietaryPreferences: {
    vegetarianOnly: boolean;
    veganOnly: boolean;
    glutenFreeOnly: boolean;
    noNuts: boolean;
  };
  notifications: boolean;
}

interface AppContextType {
  // Theme & Lang
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  language: 'EN' | 'CY' | 'FR' | 'DE';
  setLanguage: (lang: 'EN' | 'CY' | 'FR' | 'DE') => void;

  // Kitchen & Delivery
  selectedKitchen: Kitchen;
  setSelectedKitchen: (kitchen: Kitchen) => void;
  deliveryType: 'DELIVERY' | 'COLLECTION';
  setDeliveryType: (type: 'DELIVERY' | 'COLLECTION') => void;
  postcode: string;
  setPostcode: (postcode: string) => void;
  deliveryAddress: {
    street: string;
    city: string;
    instructions: string;
  };
  setDeliveryAddress: React.Dispatch<React.SetStateAction<{ street: string; city: string; instructions: string }>>;

  // Menu Search & Filter
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  dietaryFilter: {
    vegetarian: boolean;
    glutenFree: boolean;
    nutFree: boolean;
  };
  setDietaryFilter: React.Dispatch<React.SetStateAction<{ vegetarian: boolean; glutenFree: boolean; nutFree: boolean }>>;

  // Basket
  basket: BasketItem[];
  addToBasket: (item: MenuItem, quantity: number, modifiers: BasketItemModifier[], instructions?: string) => void;
  removeFromBasket: (basketItemId: string) => void;
  updateQuantity: (basketItemId: string, delta: number) => void;
  clearBasket: () => void;
  basketSubtotal: number;
  deliveryFee: number;
  basketTotal: number;

  // Active Order & Simulation
  activeOrder: ActiveOrder | null;
  placeOrder: () => void;
  cancelOrder: () => void;

  // Modals & UI Drawers
  inspectItem: MenuItem | null;
  setInspectItem: (item: MenuItem | null) => void;
  isBasketOpen: boolean;
  setIsBasketOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isKitchensModalOpen: boolean;
  setIsKitchensModalOpen: (open: boolean) => void;
  isIngredientsModalOpen: boolean;
  setIsIngredientsModalOpen: (open: boolean) => void;
  isAccountModalOpen: boolean;
  setIsAccountModalOpen: (open: boolean) => void;
  isTrackerOpen: boolean;
  setIsTrackerOpen: (open: boolean) => void;

  // User Account & Favourites
  user: UserAccount;
  toggleFavourite: (itemId: string) => void;
  reorderPrevious: (order: ActiveOrder) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const DEFAULT_USER: UserAccount = {
  name: 'Alex Wright',
  email: 'alex.wright@anglofood.co.uk',
  phone: '+44 7700 900842',
  savedAddresses: [
    {
      id: 'addr-1',
      label: 'Home',
      street: '14 Bermondsey Street, Apt 3B',
      postcode: 'SE1 2ER',
      city: 'London',
    },
    {
      id: 'addr-2',
      label: 'Office',
      street: '25 King William Street',
      postcode: 'EC4N 7AR',
      city: 'London',
    },
  ],
  favouriteItemIds: ['roast-chicken', 'fish-and-chips'],
  previousOrders: [
    {
      orderId: 'ANGLO-10294',
      kitchen: KITCHENS[0],
      deliveryType: 'DELIVERY',
      deliveryAddress: {
        street: '14 Bermondsey Street, Apt 3B',
        postcode: 'SE1 2ER',
        city: 'London',
      },
      items: [
        {
          id: 'prev-item-1',
          menuItem: MENU_ITEMS[0],
          quantity: 1,
          modifiers: [
            { groupId: 'side', groupTitle: 'CHOOSE YOUR SIDE', optionId: 'side-chips', optionName: 'Triple-Cooked Chips', price: 0 },
            { groupId: 'sauce', groupTitle: 'CHOOSE YOUR SAUCE', optionId: 'sauce-roast-gravy', optionName: 'Roast Gravy', price: 0 },
          ],
          unitPrice: 11.50,
          totalPrice: 11.50,
        },
        {
          id: 'prev-item-2',
          menuItem: MENU_ITEMS[5],
          quantity: 1,
          modifiers: [],
          unitPrice: 4.00,
          totalPrice: 4.00,
        },
      ],
      subtotal: 15.50,
      deliveryFee: 2.50,
      total: 18.00,
      status: 'COMPLETED',
      estimatedArrival: '19:15',
      createdAt: 'Yesterday, 18:42',
      timeline: [
        { status: 'CREATED', label: 'Order Confirmed', timestamp: '18:42', completed: true },
        { status: 'IN_KITCHEN', label: 'In Kitchen', timestamp: '18:43', completed: true },
        { status: 'COOKING', label: 'Cooking', timestamp: '18:45', completed: true },
        { status: 'PACKING', label: 'Packing', timestamp: '18:55', completed: true },
        { status: 'DISPATCH', label: 'Dispatched', timestamp: '19:00', completed: true },
        { status: 'ARRIVING', label: 'Arriving', timestamp: '19:12', completed: true },
        { status: 'COMPLETED', label: 'Delivered', timestamp: '19:15', completed: true },
      ],
    },
  ],
  dietaryPreferences: {
    vegetarianOnly: false,
    veganOnly: false,
    glutenFreeOnly: false,
    noNuts: true,
  },
  notifications: true,
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [language, setLanguage] = useState<'EN' | 'CY' | 'FR' | 'DE'>('EN');

  const [selectedKitchen, setSelectedKitchen] = useState<Kitchen>(KITCHENS[0]);
  const [deliveryType, setDeliveryType] = useState<'DELIVERY' | 'COLLECTION'>('DELIVERY');
  const [postcode, setPostcode] = useState<string>('SE1 2ER');
  const [deliveryAddress, setDeliveryAddress] = useState({
    street: '14 Bermondsey Street, Apt 3B',
    city: 'London',
    instructions: 'Leave at front entrance desk if unavailable',
  });

  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [dietaryFilter, setDietaryFilter] = useState({
    vegetarian: false,
    glutenFree: false,
    nutFree: false,
  });

  const [basket, setBasket] = useState<BasketItem[]>([]);
  const [activeOrder, setActiveOrder] = useState<ActiveOrder | null>(null);
  const [user, setUser] = useState<UserAccount>(DEFAULT_USER);

  // Modals
  const [inspectItem, setInspectItem] = useState<MenuItem | null>(null);
  const [isBasketOpen, setIsBasketOpen] = useState<boolean>(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isKitchensModalOpen, setIsKitchensModalOpen] = useState<boolean>(false);
  const [isIngredientsModalOpen, setIsIngredientsModalOpen] = useState<boolean>(false);
  const [isAccountModalOpen, setIsAccountModalOpen] = useState<boolean>(false);
  const [isTrackerOpen, setIsTrackerOpen] = useState<boolean>(false);

  // Dark mode effect
  const toggleDarkMode = () => {
    setIsDarkMode((prev) => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      return next;
    });
  };

  // Basket calculations
  const basketSubtotal = basket.reduce((sum, item) => sum + item.totalPrice, 0);
  const deliveryFee = deliveryType === 'DELIVERY' ? 2.50 : 0.00;
  const basketTotal = basketSubtotal > 0 ? basketSubtotal + deliveryFee : 0;

  const addToBasket = (
    item: MenuItem,
    quantity: number,
    modifiers: BasketItemModifier[],
    instructions?: string
  ) => {
    const modifierExtra = modifiers.reduce((acc, m) => acc + m.price, 0);
    const unitPrice = item.price + modifierExtra;
    const totalPrice = unitPrice * quantity;

    const basketItemId = `${item.id}-${modifiers.map((m) => m.optionId).sort().join('-')}`;

    setBasket((prev) => {
      const existingIndex = prev.findIndex((b) => b.id === basketItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        const current = updated[existingIndex];
        const newQty = current.quantity + quantity;
        updated[existingIndex] = {
          ...current,
          quantity: newQty,
          totalPrice: current.unitPrice * newQty,
        };
        return updated;
      } else {
        return [
          ...prev,
          {
            id: basketItemId,
            menuItem: item,
            quantity,
            modifiers,
            unitPrice,
            totalPrice,
            specialInstructions: instructions,
          },
        ];
      }
    });

    setIsBasketOpen(true);
  };

  const removeFromBasket = (basketItemId: string) => {
    setBasket((prev) => prev.filter((item) => item.id !== basketItemId));
  };

  const updateQuantity = (basketItemId: string, delta: number) => {
    setBasket((prev) => {
      return prev
        .map((item) => {
          if (item.id === basketItemId) {
            const newQty = item.quantity + delta;
            if (newQty <= 0) return null;
            return {
              ...item,
              quantity: newQty,
              totalPrice: item.unitPrice * newQty,
            };
          }
          return item;
        })
        .filter(Boolean) as BasketItem[];
    });
  };

  const clearBasket = () => {
    setBasket([]);
  };

  const toggleFavourite = (itemId: string) => {
    setUser((prev) => {
      const isFav = prev.favouriteItemIds.includes(itemId);
      const nextFavs = isFav
        ? prev.favouriteItemIds.filter((id) => id !== itemId)
        : [...prev.favouriteItemIds, itemId];
      return { ...prev, favouriteItemIds: nextFavs };
    });
  };

  const reorderPrevious = (order: ActiveOrder) => {
    setBasket(order.items);
    setSelectedKitchen(order.kitchen);
    setDeliveryType(order.deliveryType);
    setIsBasketOpen(true);
  };

  // Deterministic order simulation pipeline
  const placeOrder = () => {
    if (basket.length === 0) return;

    const now = new Date();
    const orderNum = Math.floor(10000 + Math.random() * 90000);
    const orderId = `ANGLO-${orderNum}`;

    const etaStart = new Date(now.getTime() + 18 * 60000); // +18 mins
    const etaEnd = new Date(now.getTime() + 28 * 60000); // +28 mins
    const formatTime = (d: Date) => d.toTimeString().slice(0, 5);

    const initialOrder: ActiveOrder = {
      orderId,
      kitchen: selectedKitchen,
      deliveryType,
      deliveryAddress: {
        postcode,
        street: deliveryAddress.street,
        city: deliveryAddress.city,
        instructions: deliveryAddress.instructions,
      },
      items: [...basket],
      subtotal: basketSubtotal,
      deliveryFee,
      total: basketTotal,
      status: 'CREATED',
      estimatedArrival: `${formatTime(etaStart)} — ${formatTime(etaEnd)}`,
      createdAt: formatTime(now),
      timeline: [
        { status: 'CREATED', label: 'ORDER CONFIRMED', timestamp: formatTime(now), completed: true },
        { status: 'IN_KITCHEN', label: 'IN KITCHEN', timestamp: '--:--', completed: false },
        { status: 'COOKING', label: 'COOKING', timestamp: '--:--', completed: false },
        { status: 'PACKING', label: 'PACKING', timestamp: '--:--', completed: false },
        { status: 'DISPATCH', label: 'DISPATCH', timestamp: '--:--', completed: false },
        { status: 'ARRIVING', label: 'ARRIVING', timestamp: '--:--', completed: false },
        { status: 'COMPLETED', label: 'DELIVERED', timestamp: '--:--', completed: false },
      ],
    };

    setActiveOrder(initialOrder);
    clearBasket();
    setIsCheckoutOpen(false);
    setIsTrackerOpen(true);
  };

  const cancelOrder = () => {
    setActiveOrder(null);
    setIsTrackerOpen(false);
  };

  // Order status advancement timer simulation
  useEffect(() => {
    if (!activeOrder || activeOrder.status === 'COMPLETED') return;

    const statusFlow: OrderStatus[] = [
      'CREATED',
      'IN_KITCHEN',
      'COOKING',
      'PACKING',
      'DISPATCH',
      'ARRIVING',
      'COMPLETED',
    ];

    const currentIndex = statusFlow.indexOf(activeOrder.status);
    if (currentIndex === -1 || currentIndex >= statusFlow.length - 1) return;

    const timer = setTimeout(() => {
      const nextStatus = statusFlow[currentIndex + 1];
      const timeStr = new Date().toTimeString().slice(0, 5);

      setActiveOrder((prev) => {
        if (!prev) return null;
        const updatedTimeline = prev.timeline.map((step) => {
          if (step.status === nextStatus) {
            return { ...step, completed: true, timestamp: timeStr };
          }
          return step;
        });

        return {
          ...prev,
          status: nextStatus,
          timeline: updatedTimeline,
        };
      });
    }, 6000); // advance every 6 seconds for interactive demo

    return () => clearTimeout(timer);
  }, [activeOrder]);

  return (
    <AppContext.Provider
      value={{
        isDarkMode,
        toggleDarkMode,
        language,
        setLanguage,
        selectedKitchen,
        setSelectedKitchen,
        deliveryType,
        setDeliveryType,
        postcode,
        setPostcode,
        deliveryAddress,
        setDeliveryAddress,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        dietaryFilter,
        setDietaryFilter,
        basket,
        addToBasket,
        removeFromBasket,
        updateQuantity,
        clearBasket,
        basketSubtotal,
        deliveryFee,
        basketTotal,
        activeOrder,
        placeOrder,
        cancelOrder,
        inspectItem,
        setInspectItem,
        isBasketOpen,
        setIsBasketOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isKitchensModalOpen,
        setIsKitchensModalOpen,
        isIngredientsModalOpen,
        setIsIngredientsModalOpen,
        isAccountModalOpen,
        setIsAccountModalOpen,
        isTrackerOpen,
        setIsTrackerOpen,
        user,
        toggleFavourite,
        reorderPrevious,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
