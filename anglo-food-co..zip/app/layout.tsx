import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'ANGLO FOOD CO. | Proper Food. Modern System.',
  description: 'British food for the modern city. Contemporary takeaway, modern kitchens, precise logistics.',
  openGraph: {
    title: 'ANGLO FOOD CO. | Proper Food. Modern System.',
    description: 'British food for the modern city. Contemporary takeaway, modern kitchens, precise logistics.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'ANGLO FOOD CO. | Proper Food. Modern System.',
    description: 'British food for the modern city. Contemporary takeaway, modern kitchens, precise logistics.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body suppressHydrationWarning className="bg-[#FAF9F5] text-[#18181B] antialiased selection:bg-[#004225] selection:text-[#FAF9F5]">
        {children}
      </body>
    </html>
  );
}
