'use client';

import React from 'react';
import { AppProvider } from '@/lib/context/AppContext';
import { LoadingBar } from '@/components/LoadingBar';
import { AngloHeader } from '@/components/AngloHeader';
import { HeroSection } from '@/components/HeroSection';
import { FoodSection } from '@/components/FoodSection';
import { KitchensSection } from '@/components/KitchensSection';
import { AngloSystemSection } from '@/components/AngloSystemSection';
import { StorySection } from '@/components/StorySection';
import { DeliverySection } from '@/components/DeliverySection';
import { AngloFooter } from '@/components/AngloFooter';
import { FoodDetailModal } from '@/components/FoodDetailModal';
import { BasketDrawer } from '@/components/BasketDrawer';
import { CheckoutModal } from '@/components/CheckoutModal';
import { OrderTracker } from '@/components/OrderTracker';
import { KitchensModal } from '@/components/KitchensModal';
import { IngredientsModal } from '@/components/IngredientsModal';
import { AccountModal } from '@/components/AccountModal';
import { MobileBottomNav } from '@/components/MobileBottomNav';

export default function Home() {
  return (
    <AppProvider>
      {/* Brand Loading Animation (<1s duration) */}
      <LoadingBar />

      <main className="min-h-screen flex flex-col justify-between pb-16 md:pb-0">
        <AngloHeader />
        
        {/* Page Sections */}
        <HeroSection />
        <FoodSection />
        <KitchensSection />
        <AngloSystemSection />
        <StorySection />
        <DeliverySection />

        <AngloFooter />

        {/* Drawers & Modals */}
        <FoodDetailModal />
        <BasketDrawer />
        <CheckoutModal />
        <OrderTracker />
        <KitchensModal />
        <IngredientsModal />
        <AccountModal />

        {/* Mobile Navigation */}
        <MobileBottomNav />
      </main>
    </AppProvider>
  );
}
