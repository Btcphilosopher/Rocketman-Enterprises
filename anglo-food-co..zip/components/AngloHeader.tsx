'use client';

import React, { useState, useEffect } from 'react';
import { ShoppingBag, MapPin, Moon, Sun, Globe, User, Clock } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { LOCALIZATION_STRINGS } from '@/lib/data';

export const AngloHeader: React.FC = () => {
  const {
    isDarkMode,
    toggleDarkMode,
    language,
    setLanguage,
    selectedKitchen,
    basket,
    setIsBasketOpen,
    setIsKitchensModalOpen,
    setIsAccountModalOpen,
    activeOrder,
    setIsTrackerOpen,
  } = useApp();

  const [isScrolled, setIsScrolled] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const totalBasketCount = basket.reduce((sum, item) => sum + item.quantity, 0);
  const strings = LOCALIZATION_STRINGS[language];

  return (
    <header
      className={`sticky top-0 z-40 w-full transition-all duration-200 border-b ${
        isScrolled
          ? 'bg-[#FAF9F5]/90 dark:bg-[#111315]/90 backdrop-blur-md py-3 shadow-xs border-zinc-200 dark:border-zinc-800'
          : 'bg-[#FAF9F5] dark:bg-[#111315] py-4 border-zinc-200/80 dark:border-zinc-800/80'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Zone 1: Brand title wordmark */}
        <div className="flex items-center gap-3">
          <a
            href="#"
            className="text-xl sm:text-2xl font-bold tracking-tight text-zinc-900 dark:text-zinc-50 font-serif"
          >
            ANGLO
          </a>
          <span className="hidden sm:inline-block text-[10px] font-mono tracking-widest px-2 py-0.5 border border-zinc-300 dark:border-zinc-700 text-zinc-600 dark:text-zinc-400 uppercase">
            FOOD CO.
          </span>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-mono tracking-wider uppercase text-zinc-600 dark:text-zinc-400">
          <a href="#food" className="hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors">
            FOOD
          </a>
          <a href="#kitchens" className="hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors">
            KITCHENS
          </a>
          <a href="#delivery" className="hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors">
            DELIVERY
          </a>
          <a href="#system" className="hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors">
            SYSTEM
          </a>
          <a href="#story" className="hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors">
            STORY
          </a>
        </nav>

        {/* Zone 3: Actions & Status */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Active Order Pill if exists */}
          {activeOrder && (
            <button
              onClick={() => setIsTrackerOpen(true)}
              className="hidden lg:flex items-center gap-2 px-2.5 py-1 text-xs font-mono bg-[#004225] text-white hover:bg-[#00331C] transition-colors"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>ORDER #{activeOrder.orderId}</span>
            </button>
          )}

          {/* Kitchen Location button */}
          <button
            onClick={() => setIsKitchensModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-mono text-zinc-800 dark:text-zinc-200 hover:bg-zinc-200/60 dark:hover:bg-zinc-800/60 border border-zinc-300 dark:border-zinc-700 transition-colors shrink-0"
            title="Change Kitchen"
          >
            <MapPin className="w-3.5 h-3.5 text-[#004225] dark:text-emerald-400" />
            <span className="hidden sm:inline font-semibold">{selectedKitchen.city}</span>
            <span className="text-[10px] text-zinc-500 font-normal">({selectedKitchen.code.split('/ ')[1]})</span>
          </button>

          {/* Language Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="p-1.5 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 transition-colors"
              title="Change Language"
            >
              <Globe className="w-4 h-4" />
            </button>
            {showLangMenu && (
              <div className="absolute right-0 mt-1 w-28 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-md py-1 z-50 text-xs font-mono">
                {(['EN', 'CY', 'FR', 'DE'] as const).map((lang) => (
                  <button
                    key={lang}
                    onClick={() => {
                      setLanguage(lang);
                      setShowLangMenu(false);
                    }}
                    className={`w-full text-left px-3 py-1.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors ${
                      language === lang ? 'font-bold text-[#004225] dark:text-emerald-400' : 'text-zinc-700 dark:text-zinc-300'
                    }`}
                  >
                    {lang === 'EN' && 'English'}
                    {lang === 'CY' && 'Cymraeg'}
                    {lang === 'FR' && 'Français'}
                    {lang === 'DE' && 'Deutsch'}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Dark mode toggle */}
          <button
            onClick={toggleDarkMode}
            className="p-1.5 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 transition-colors"
            title="Toggle theme"
          >
            {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Account Modal trigger */}
          <button
            onClick={() => setIsAccountModalOpen(true)}
            className="p-1.5 text-zinc-600 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-100 hover:bg-zinc-200/50 dark:hover:bg-zinc-800/50 transition-colors"
            title="User Account"
          >
            <User className="w-4 h-4" />
          </button>

          {/* Basket Button */}
          <button
            onClick={() => setIsBasketOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#004225] dark:bg-[#006B3C] text-white hover:bg-[#00331C] dark:hover:bg-[#005530] font-mono text-xs font-medium tracking-wide transition-colors"
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden xs:inline">BASKET</span>
            {totalBasketCount > 0 && (
              <span className="ml-0.5 px-1.5 py-0.2 bg-white text-[#004225] font-bold text-[11px] tabular-nums">
                {totalBasketCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
