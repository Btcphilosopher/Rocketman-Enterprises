'use client';

import React from 'react';
import { useApp } from '@/lib/context/AppContext';

export const AngloFooter: React.FC = () => {
  const { setIsIngredientsModalOpen, setIsKitchensModalOpen } = useApp();

  return (
    <footer className="w-full bg-[#111315] text-[#F4F4F5] border-t border-zinc-800 py-16 sm:py-20 font-mono text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Footer Top Row: Large Brand Statement */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8 border-b border-zinc-800 pb-12">
          <div className="space-y-2">
            <div className="text-4xl sm:text-6xl font-bold font-serif tracking-tight text-white">
              ANGLO
            </div>
            <div className="text-sm tracking-widest text-emerald-400 uppercase">
              PROPER FOOD. MODERN SYSTEM.
            </div>
          </div>

          <div className="text-zinc-400 font-sans text-sm max-w-md font-light leading-relaxed">
            Contemporary British takeaway & food logistics company. Precision kitchens across London, Sheffield, Manchester, Leeds, Bristol, and Edinburgh.
          </div>
        </div>

        {/* Links Navigation Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-zinc-400">
          <div className="space-y-3">
            <div className="text-white font-bold uppercase tracking-wider">NAVIGATE</div>
            <ul className="space-y-2">
              <li><a href="#food" className="hover:text-white transition-colors">DAILY MENU</a></li>
              <li><a href="#kitchens" className="hover:text-white transition-colors">ANGLO KITCHENS</a></li>
              <li><a href="#delivery" className="hover:text-white transition-colors">DELIVERY SYSTEM</a></li>
              <li><a href="#story" className="hover:text-white transition-colors">OUR STORY</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-white font-bold uppercase tracking-wider">RESOURCES</div>
            <ul className="space-y-2">
              <li>
                <button onClick={() => setIsIngredientsModalOpen(true)} className="hover:text-white transition-colors">
                  BRITISH INGREDIENTS
                </button>
              </li>
              <li>
                <button onClick={() => setIsKitchensModalOpen(true)} className="hover:text-white transition-colors">
                  KITCHEN NETWORK
                </button>
              </li>
              <li><a href="#system" className="hover:text-white transition-colors">OPERATIONAL SPEC</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-white font-bold uppercase tracking-wider">LEGAL & ETHICS</div>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white transition-colors">ACCESSIBILITY</a></li>
              <li><a href="#" className="hover:text-white transition-colors">PRIVACY POLICY</a></li>
              <li><a href="#" className="hover:text-white transition-colors">TERMS OF SERVICE</a></li>
              <li><a href="#" className="hover:text-white transition-colors">ALLERGEN SAFETY</a></li>
            </ul>
          </div>

          <div className="space-y-3">
            <div className="text-white font-bold uppercase tracking-wider">CONNECT</div>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white transition-colors">INSTAGRAM (@ANGLOFOODCO)</a></li>
              <li><a href="#" className="hover:text-white transition-colors">PRESS & EDITORIAL</a></li>
              <li><a href="#" className="hover:text-white transition-colors">CONTACT PASS</a></li>
            </ul>
          </div>
        </div>

        {/* Footer Bottom Strip */}
        <div className="pt-8 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-zinc-500 text-[11px]">
          <div>
            © 2026 ANGLO FOOD CO. ALL RIGHTS RESERVED.
          </div>
          <div className="px-3 py-1 border border-zinc-800 bg-zinc-900 text-emerald-400 font-bold tracking-wider">
            DEMO WEBSITE — SIMULATED DATA
          </div>
        </div>

      </div>
    </footer>
  );
};
