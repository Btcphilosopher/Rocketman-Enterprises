'use client';

import React from 'react';
import Image from 'next/image';
import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight, MapPin } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';

export const BasketDrawer: React.FC = () => {
  const {
    isBasketOpen,
    setIsBasketOpen,
    basket,
    removeFromBasket,
    updateQuantity,
    clearBasket,
    basketSubtotal,
    deliveryFee,
    basketTotal,
    selectedKitchen,
    deliveryType,
    setIsCheckoutOpen,
  } = useApp();

  if (!isBasketOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      <div className="relative w-full max-w-md h-full bg-[#FAF9F5] dark:bg-[#181A1D] border-l border-zinc-300 dark:border-zinc-800 shadow-2xl flex flex-col justify-between overflow-hidden">
        
        {/* Drawer Header */}
        <div className="p-6 border-b border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#004225] dark:text-emerald-400" />
            <h2 className="text-xl font-bold font-serif text-zinc-900 dark:text-zinc-50">
              YOUR ORDER
            </h2>
          </div>

          <button
            onClick={() => setIsBasketOpen(false)}
            className="p-1.5 text-zinc-500 hover:text-zinc-900 dark:hover:text-zinc-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selected Kitchen Banner */}
        <div className="px-6 py-3 bg-zinc-200/70 dark:bg-zinc-800/70 text-xs font-mono flex items-center justify-between border-b border-zinc-200 dark:border-zinc-800">
          <div className="flex items-center gap-1.5 text-zinc-800 dark:text-zinc-200">
            <MapPin className="w-3.5 h-3.5 text-[#004225] dark:text-emerald-400" />
            <span className="font-semibold">{selectedKitchen.code}</span>
          </div>
          <span className="text-zinc-500 font-bold uppercase">{deliveryType}</span>
        </div>

        {/* Drawer Content: Basket Items */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {basket.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-4 py-16">
              <ShoppingBag className="w-12 h-12 text-zinc-300 dark:text-zinc-700" />
              <p className="text-sm font-mono text-zinc-500 uppercase">Your order is currently empty.</p>
              <button
                onClick={() => setIsBasketOpen(false)}
                className="px-6 py-2.5 bg-[#004225] text-white text-xs font-mono uppercase font-semibold"
              >
                BROWSE FOOD MENU
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {basket.map((item) => (
                <div
                  key={item.id}
                  className="p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="relative w-12 h-12 bg-zinc-100 shrink-0 border border-zinc-200">
                        <Image
                          src={item.menuItem.image}
                          alt={item.menuItem.name}
                          fill
                          className="object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      <div>
                        <h4 className="text-sm font-bold font-serif text-zinc-900 dark:text-zinc-50">
                          {item.menuItem.name}
                        </h4>
                        <span className="text-xs font-mono font-semibold text-[#004225] dark:text-emerald-400 tabular-nums">
                          £{item.unitPrice.toFixed(2)} each
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => removeFromBasket(item.id)}
                      className="text-zinc-400 hover:text-red-600 transition-colors p-1"
                      title="Remove item"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Modifiers List */}
                  {item.modifiers.length > 0 && (
                    <ul className="text-[11px] font-mono text-zinc-500 space-y-0.5 pl-2 border-l border-zinc-200 dark:border-zinc-800">
                      {item.modifiers.map((m, idx) => (
                        <li key={idx} className="flex justify-between">
                          <span>• {m.optionName}</span>
                          {m.price > 0 && <span>+£{m.price.toFixed(2)}</span>}
                        </li>
                      ))}
                    </ul>
                  )}

                  {item.specialInstructions && (
                    <div className="text-[10px] font-mono italic text-zinc-500 bg-zinc-100 dark:bg-zinc-800 p-1.5">
                      Note: {item.specialInstructions}
                    </div>
                  )}

                  {/* Quantity Stepper & Item Total */}
                  <div className="flex items-center justify-between pt-2 border-t border-zinc-100 dark:border-zinc-800">
                    <div className="flex items-center border border-zinc-300 dark:border-zinc-700 bg-zinc-50 dark:bg-zinc-800 text-xs font-mono">
                      <button
                        onClick={() => updateQuantity(item.id, -1)}
                        className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-700"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-3 font-bold tabular-nums">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, 1)}
                        className="p-1.5 hover:bg-zinc-200 dark:hover:bg-zinc-700"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="text-sm font-bold font-mono text-zinc-900 dark:text-zinc-100 tabular-nums">
                      £{item.totalPrice.toFixed(2)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Drawer Footer: Subtotal & Checkout Action */}
        {basket.length > 0 && (
          <div className="p-6 bg-white dark:bg-zinc-900 border-t border-zinc-200 dark:border-zinc-800 space-y-4">
            <div className="space-y-1.5 text-xs font-mono text-zinc-600 dark:text-zinc-400">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="tabular-nums font-semibold text-zinc-900 dark:text-zinc-100">
                  £{basketSubtotal.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Delivery Fee ({deliveryType})</span>
                <span className="tabular-nums font-semibold text-zinc-900 dark:text-zinc-100">
                  {deliveryFee > 0 ? `£${deliveryFee.toFixed(2)}` : 'FREE'}
                </span>
              </div>
              <div className="flex justify-between text-sm font-bold text-zinc-900 dark:text-zinc-50 pt-2 border-t border-zinc-200 dark:border-zinc-800">
                <span>Total</span>
                <span className="tabular-nums text-[#004225] dark:text-emerald-400">
                  £{basketTotal.toFixed(2)}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                setIsBasketOpen(false);
                setIsCheckoutOpen(true);
              }}
              className="w-full py-3.5 bg-[#004225] text-white hover:bg-[#00331C] text-xs font-mono font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
            >
              <span>CONTINUE TO CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
