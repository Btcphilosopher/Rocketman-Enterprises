'use client';

import React from 'react';
import { Truck, Clock, ShieldCheck, Thermometer, MapPin, ArrowRight } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';

export const DeliverySection: React.FC = () => {
  const { setDeliveryType, setIsKitchensModalOpen } = useApp();

  return (
    <section id="delivery" className="w-full py-16 sm:py-20 border-b border-zinc-200 dark:border-zinc-800 bg-[#FAF9F5] dark:bg-[#111315]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-2xl border-b border-zinc-300 dark:border-zinc-800 pb-8">
          <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
            05. DISPATCH & LOGISTICS
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold tracking-tight font-serif text-zinc-900 dark:text-zinc-50">
            DELIVERY, PROPERLY DONE.
          </h2>
          <p className="text-sm sm:text-base text-zinc-700 dark:text-zinc-300 font-sans font-light">
            Food is only as good as the condition in which it arrives at your table.
          </p>
        </div>

        {/* Operational Flow Diagram */}
        <div className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 font-mono text-xs">
          <div className="text-[10px] text-zinc-400 uppercase tracking-widest mb-4">LOGISTICS TIMELINE PIPELINE</div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
            <div className="p-3 bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700">
              <span className="font-bold text-[#004225] dark:text-emerald-400 block">01 KITCHEN</span>
              <span className="text-[10px] text-zinc-500">Cooked to Order</span>
            </div>
            <div className="p-3 bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700">
              <span className="font-bold text-[#004225] dark:text-emerald-400 block">02 PACKING</span>
              <span className="text-[10px] text-zinc-500">Thermal Seal</span>
            </div>
            <div className="p-3 bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700">
              <span className="font-bold text-[#004225] dark:text-emerald-400 block">03 DISPATCH</span>
              <span className="text-[10px] text-zinc-500">Electric Courier</span>
            </div>
            <div className="p-3 bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700">
              <span className="font-bold text-[#004225] dark:text-emerald-400 block">04 DELIVERY</span>
              <span className="text-[10px] text-zinc-500">Direct Route</span>
            </div>
            <div className="p-3 bg-zinc-100 dark:bg-zinc-800/80 border border-zinc-200 dark:border-zinc-700 col-span-2 sm:col-span-1">
              <span className="font-bold text-[#004225] dark:text-emerald-400 block">05 DOOR</span>
              <span className="text-[10px] text-zinc-500">Hot & Fresh</span>
            </div>
          </div>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3">
            <Thermometer className="w-6 h-6 text-[#004225] dark:text-emerald-400" />
            <h3 className="text-base font-bold font-serif text-zinc-900 dark:text-zinc-50">
              Thermal Packaging
            </h3>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 font-sans leading-relaxed">
              Custom breathable paper boxes designed in London to retain roast heat while preventing steam condensation. Chips stay crisp, gravy stays piping hot.
            </p>
          </div>

          <div className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3">
            <Clock className="w-6 h-6 text-[#004225] dark:text-emerald-400" />
            <h3 className="text-base font-bold font-serif text-zinc-900 dark:text-zinc-50">
              Predictable ETA
            </h3>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 font-sans leading-relaxed">
              We calculate delivery windows based on real kitchen workload and transport traffic, providing a precise 10-minute arrival window.
            </p>
          </div>

          <div className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3">
            <MapPin className="w-6 h-6 text-[#004225] dark:text-emerald-400" />
            <h3 className="text-base font-bold font-serif text-zinc-900 dark:text-zinc-50">
              Kitchen Collection
            </h3>
            <p className="text-xs text-zinc-600 dark:text-zinc-400 font-sans leading-relaxed">
              Prefer to collect? Select your nearest Anglo Kitchen and pick up your order directly from our pass in under 12 minutes. Zero delivery fee.
            </p>
          </div>
        </div>

      </div>
    </section>
  );
};
