'use client';

import React, { useState, useEffect } from 'react';
import Image from 'next/image';
import { X, Plus, Minus, Check, AlertCircle, Sparkles } from 'lucide-react';
import { useApp, BasketItemModifier } from '@/lib/context/AppContext';

export const FoodDetailModal: React.FC = () => {
  const { inspectItem, setInspectItem, addToBasket } = useApp();

  // Calculate default selected modifiers when inspectItem changes
  const initialModifiers = React.useMemo(() => {
    if (!inspectItem?.modifierGroups) return {};
    const initialMods: Record<string, string[]> = {};
    inspectItem.modifierGroups.forEach((group) => {
      if (group.required && group.type === 'radio' && group.options.length > 0) {
        initialMods[group.id] = [group.options[0].id];
      } else {
        initialMods[group.id] = [];
      }
    });
    return initialMods;
  }, [inspectItem]);

  const [quantity, setQuantity] = useState<number>(1);
  const [selectedModifiers, setSelectedModifiers] = useState<Record<string, string[]>>({});
  const [instructions, setInstructions] = useState<string>('');

  // Sync state when initialModifiers changes
  const [prevItemId, setPrevItemId] = useState<string | null>(null);
  if (inspectItem && inspectItem.id !== prevItemId) {
    setPrevItemId(inspectItem.id);
    setQuantity(1);
    setInstructions('');
    setSelectedModifiers(initialModifiers);
  }

  if (!inspectItem) return null;

  // Calculate modifier total price additions
  let extraPrice = 0;
  if (inspectItem.modifierGroups) {
    inspectItem.modifierGroups.forEach((group) => {
      const selectedOptionIds = selectedModifiers[group.id] || [];
      group.options.forEach((opt) => {
        if (selectedOptionIds.includes(opt.id)) {
          extraPrice += opt.price;
        }
      });
    });
  }

  const unitPrice = inspectItem.price + extraPrice;
  const totalPrice = unitPrice * quantity;

  const handleToggleRadio = (groupId: string, optionId: string) => {
    setSelectedModifiers((prev) => ({
      ...prev,
      [groupId]: [optionId],
    }));
  };

  const handleToggleCheckbox = (groupId: string, optionId: string) => {
    setSelectedModifiers((prev) => {
      const current = prev[groupId] || [];
      const exists = current.includes(optionId);
      const next = exists ? current.filter((id) => id !== optionId) : [...current, optionId];
      return { ...prev, [groupId]: next };
    });
  };

  const handleAdd = () => {
    // Compile modifiers into standardized BasketItemModifier format
    const compiledModifiers: BasketItemModifier[] = [];

    if (inspectItem.modifierGroups) {
      inspectItem.modifierGroups.forEach((group) => {
        const selectedIds = selectedModifiers[group.id] || [];
        group.options.forEach((opt) => {
          if (selectedIds.includes(opt.id)) {
            compiledModifiers.push({
              groupId: group.id,
              groupTitle: group.title,
              optionId: opt.id,
              optionName: opt.name,
              price: opt.price,
            });
          }
        });
      });
    }

    addToBasket(inspectItem, quantity, compiledModifiers, instructions);
    setInspectItem(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl my-8 bg-[#FAF9F5] dark:bg-[#181A1D] border border-zinc-300 dark:border-zinc-700 shadow-2xl overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={() => setInspectItem(null)}
          className="absolute top-4 right-4 z-20 p-2 bg-black/60 text-white hover:bg-black transition-colors rounded-none"
          title="Close Modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Scroll Container */}
        <div className="max-h-[82vh] overflow-y-auto">
          
          {/* Header Image */}
          <div className="relative w-full h-64 sm:h-80 bg-zinc-900">
            <Image
              src={inspectItem.image}
              alt={inspectItem.name}
              fill
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#FAF9F5] dark:from-[#181A1D] via-transparent to-black/30" />
            
            <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between">
              <div>
                <span className="text-[10px] font-mono tracking-widest uppercase text-[#004225] dark:text-emerald-400 bg-white/90 dark:bg-zinc-900/90 px-2 py-0.5 border border-zinc-200 dark:border-zinc-800">
                  {inspectItem.category}
                </span>
                <h2 className="text-2xl sm:text-4xl font-bold font-serif text-zinc-900 dark:text-zinc-50 mt-1">
                  {inspectItem.name}
                </h2>
              </div>
              <div className="text-xl sm:text-2xl font-bold font-mono text-[#004225] dark:text-emerald-400 tabular-nums bg-white/90 dark:bg-zinc-900/90 px-3 py-1 border border-zinc-200 dark:border-zinc-800">
                £{unitPrice.toFixed(2)}
              </div>
            </div>
          </div>

          {/* Modal Content */}
          <div className="p-6 sm:p-8 space-y-8">
            <p className="text-sm sm:text-base text-zinc-700 dark:text-zinc-300 font-sans leading-relaxed">
              {inspectItem.description}
            </p>

            {/* Customisation Options */}
            {inspectItem.modifierGroups && inspectItem.modifierGroups.length > 0 && (
              <div className="space-y-6 pt-4 border-t border-zinc-200 dark:border-zinc-800">
                <h3 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-900 dark:text-zinc-100">
                  CUSTOMISATION & SIDES
                </h3>

                {inspectItem.modifierGroups.map((group) => (
                  <div key={group.id} className="space-y-3">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="font-semibold text-zinc-800 dark:text-zinc-200">{group.title}</span>
                      {group.required && <span className="text-xs text-red-700 dark:text-red-400 font-normal">REQUIRED</span>}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      {group.options.map((opt) => {
                        const isSelected = (selectedModifiers[group.id] || []).includes(opt.id);

                        return (
                          <button
                            key={opt.id}
                            onClick={() =>
                              group.type === 'radio'
                                ? handleToggleRadio(group.id, opt.id)
                                : handleToggleCheckbox(group.id, opt.id)
                            }
                            className={`p-3 text-left border text-xs font-mono transition-all flex items-center justify-between ${
                              isSelected
                                ? 'border-[#004225] bg-[#004225]/10 text-zinc-900 dark:text-zinc-100 dark:border-emerald-500'
                                : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400 text-zinc-700 dark:text-zinc-300'
                            }`}
                          >
                            <span className="font-medium">{opt.name}</span>
                            <span className="tabular-nums font-semibold text-zinc-500">
                              {opt.price > 0 ? `+£${opt.price.toFixed(2)}` : 'INC.'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Ingredients & Allergens Section */}
            <div className="pt-6 border-t border-zinc-200 dark:border-zinc-800 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-900 dark:text-zinc-100 mb-2">
                  INGREDIENTS
                </h4>
                <ul className="text-xs font-sans text-zinc-600 dark:text-zinc-400 space-y-1">
                  {inspectItem.ingredients.map((ing, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 bg-[#004225] dark:bg-emerald-400 shrink-0" />
                      <span>{ing}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h4 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-900 dark:text-zinc-100 mb-2">
                  ALLERGENS & DIETARY
                </h4>
                <div className="space-y-2">
                  {inspectItem.allergens.length > 0 ? (
                    <div className="flex items-center gap-1.5 text-xs text-amber-800 dark:text-amber-400 font-mono">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>Contains: {inspectItem.allergens.join(', ')}</span>
                    </div>
                  ) : (
                    <div className="text-xs font-mono text-emerald-700 dark:text-emerald-400">
                      ✓ No Major Common Allergens Recorded
                    </div>
                  )}

                  <div className="text-[11px] font-mono text-zinc-500 space-y-1">
                    <div>Vegetarian: {inspectItem.dietary.isVegetarian ? 'Yes' : 'No'}</div>
                    <div>Gluten-Free: {inspectItem.dietary.isGlutenFree ? 'Yes' : 'No'}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Nutrition Table */}
            <div className="pt-6 border-t border-zinc-200 dark:border-zinc-800 space-y-3">
              <h4 className="text-xs font-mono font-bold tracking-wider uppercase text-zinc-900 dark:text-zinc-100">
                NUTRITIONAL INFORMATION (PER PORTION)
              </h4>

              <div className="grid grid-cols-5 gap-2 p-3 bg-zinc-200/50 dark:bg-zinc-800/50 font-mono text-center text-xs">
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">ENERGY</div>
                  <div className="font-bold text-zinc-900 dark:text-zinc-100 tabular-nums">
                    {inspectItem.nutrition.calories} kcal
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">PROTEIN</div>
                  <div className="font-bold text-zinc-900 dark:text-zinc-100 tabular-nums">
                    {inspectItem.nutrition.protein}g
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">CARBS</div>
                  <div className="font-bold text-zinc-900 dark:text-zinc-100 tabular-nums">
                    {inspectItem.nutrition.carbs}g
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">FAT</div>
                  <div className="font-bold text-zinc-900 dark:text-zinc-100 tabular-nums">
                    {inspectItem.nutrition.fat}g
                  </div>
                </div>
                <div>
                  <div className="text-[10px] text-zinc-500 uppercase">SALT</div>
                  <div className="font-bold text-zinc-900 dark:text-zinc-100 tabular-nums">
                    {inspectItem.nutrition.salt}g
                  </div>
                </div>
              </div>
            </div>

            {/* Special Instructions */}
            <div className="pt-4 border-t border-zinc-200 dark:border-zinc-800 space-y-2">
              <label className="block text-xs font-mono font-bold tracking-wider uppercase text-zinc-900 dark:text-zinc-100">
                SPECIAL INSTRUCTIONS FOR KITCHEN
              </label>
              <input
                type="text"
                placeholder="e.g. Extra crisp roast skin, gravy on side..."
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                className="w-full p-2.5 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-xs font-mono text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-[#004225]"
              />
            </div>

          </div>

          {/* Sticky Modal Bottom Action Bar */}
          <div className="sticky bottom-0 z-20 p-4 sm:p-6 bg-[#FAF9F5] dark:bg-[#181A1D] border-t border-zinc-300 dark:border-zinc-800 flex items-center justify-between gap-4">
            {/* Quantity Stepper */}
            <div className="flex items-center border border-zinc-300 dark:border-zinc-700 bg-white dark:bg-zinc-900">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="p-2.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors text-zinc-700 dark:text-zinc-300"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="px-4 text-xs font-mono font-bold tabular-nums text-zinc-900 dark:text-zinc-100">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="p-2.5 hover:bg-zinc-100 dark:hover:bg-zinc-800 transition-colors text-zinc-700 dark:text-zinc-300"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>

            {/* Add CTA */}
            <button
              onClick={handleAdd}
              className="flex-1 py-3 px-6 bg-[#004225] dark:bg-[#006B3C] text-white hover:bg-[#00331C] dark:hover:bg-[#005530] text-xs font-mono font-bold uppercase tracking-wider transition-colors flex items-center justify-between"
            >
              <span>ADD TO ORDER</span>
              <span className="tabular-nums">£{totalPrice.toFixed(2)}</span>
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
