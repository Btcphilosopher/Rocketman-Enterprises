'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export const LoadingBar: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState<'ANGLO' | 'FOOD' | 'KITCHEN' | 'DELIVERY'>('ANGLO');

  useEffect(() => {
    const t1 = setTimeout(() => setStep('FOOD'), 250);
    const t2 = setTimeout(() => setStep('KITCHEN'), 500);
    const t3 = setTimeout(() => setStep('DELIVERY'), 750);
    const t4 = setTimeout(() => setLoading(false), 950);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#FAF9F5] dark:bg-[#111315] text-[#18181B] dark:text-[#F4F4F5]"
        >
          <div className="w-64 space-y-4">
            <div className="flex items-center justify-between text-xs font-mono tracking-widest uppercase text-zinc-500">
              <span className="font-semibold text-zinc-900 dark:text-zinc-100">ANGLO</span>
              <span className="tabular-nums">{step}</span>
            </div>

            {/* Progress line */}
            <div className="h-[2px] w-full bg-zinc-200 dark:bg-zinc-800 overflow-hidden">
              <motion.div
                className="h-full bg-[#004225] dark:bg-[#006B3C]"
                initial={{ width: '0%' }}
                animate={{
                  width:
                    step === 'ANGLO'
                      ? '25%'
                      : step === 'FOOD'
                      ? '50%'
                      : step === 'KITCHEN'
                      ? '75%'
                      : '100%',
                }}
                transition={{ ease: 'easeInOut', duration: 0.2 }}
              />
            </div>

            <div className="text-[10px] font-mono text-center text-zinc-400 tracking-wider uppercase">
              PROPER FOOD. MODERN SYSTEM.
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};
