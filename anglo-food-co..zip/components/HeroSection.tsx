'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowRight, Clock, MapPin, Sparkles } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { LOCALIZATION_STRINGS } from '@/lib/data';

export const HeroSection: React.FC = () => {
  const { setDeliveryType, setIsKitchensModalOpen, language } = useApp();
  const strings = LOCALIZATION_STRINGS[language];

  return (
    <section className="relative w-full border-b border-zinc-300 dark:border-zinc-800 bg-[#FAF9F5] dark:bg-[#111315] overflow-hidden">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 min-h-[580px] lg:min-h-[640px]">
        
        {/* Left Column: Editorial Typography & Actions */}
        <div className="lg:col-span-6 px-6 sm:px-10 py-12 lg:py-20 flex flex-col justify-between z-10">
          <div className="space-y-6">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              <span className="w-2 h-2 bg-[#004225] dark:bg-emerald-400 rounded-none inline-block" />
              <span>PROPER FOOD. MODERN SYSTEM.</span>
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight font-serif text-zinc-900 dark:text-zinc-50 leading-[0.95]">
              DINNER,<br />
              PROPERLY<br />
              <span className="text-[#004225] dark:text-emerald-500">DONE.</span>
            </h1>

            <p className="text-lg sm:text-xl text-zinc-700 dark:text-zinc-300 max-w-lg font-sans font-light leading-relaxed">
              British food for the modern city. Exceptional ingredients, straightforward British cooking, and precise kitchen logistics.
            </p>
          </div>

          <div className="space-y-6 mt-10">
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href="#food"
                onClick={() => setDeliveryType('DELIVERY')}
                className="px-6 py-3.5 bg-[#004225] text-white hover:bg-[#00331C] dark:bg-[#006B3C] dark:hover:bg-[#005530] font-mono text-xs font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2 shadow-xs group"
              >
                <span>{strings.orderDelivery}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>

              <button
                onClick={() => {
                  setDeliveryType('COLLECTION');
                  setIsKitchensModalOpen(true);
                }}
                className="px-6 py-3.5 bg-transparent text-zinc-900 dark:text-zinc-100 hover:bg-zinc-200/60 dark:hover:bg-zinc-800/60 border border-zinc-900 dark:border-zinc-100 font-mono text-xs font-semibold tracking-wider uppercase transition-all flex items-center justify-center gap-2"
              >
                <MapPin className="w-4 h-4 text-[#004225] dark:text-emerald-400" />
                <span>{strings.collectKitchen}</span>
              </button>
            </div>

            {/* Operational Banner */}
            <div className="flex items-center gap-4 text-xs font-mono text-zinc-600 dark:text-zinc-400 pt-2 border-t border-zinc-200 dark:border-zinc-800">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#004225] dark:text-emerald-400" />
                <span className="font-semibold text-zinc-800 dark:text-zinc-200">{strings.openToday}</span>
              </div>
              <span className="text-zinc-300 dark:text-zinc-700">|</span>
              <span className="text-emerald-700 dark:text-emerald-400 font-semibold">AVERAGE PREP: 08:42 MINS</span>
            </div>
          </div>
        </div>

        {/* Right Column: High Quality Hero Photograph */}
        <div className="lg:col-span-6 relative min-h-[320px] lg:min-h-full bg-zinc-900 border-t lg:border-t-0 lg:border-l border-zinc-300 dark:border-zinc-800">
          <Image
            src="/src/assets/images/hero_anglo_dinner_1790954267932.jpg"
            alt="Anglo Roast Chicken Dinner"
            fill
            priority
            className="object-cover object-center brightness-95 contrast-105"
            referrerPolicy="no-referrer"
          />
          {/* Subtle Scrim Gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent lg:bg-gradient-to-r lg:from-black/40 lg:via-transparent lg:to-transparent" />
          
          {/* Overlay Spec Tag */}
          <div className="absolute bottom-6 left-6 right-6 lg:left-8 lg:right-8 bg-[#18181B]/90 backdrop-blur-md p-4 text-white font-mono text-xs border border-zinc-700 flex justify-between items-center">
            <div>
              <div className="text-[10px] text-zinc-400 uppercase tracking-widest">FEATURED SPECIAL</div>
              <div className="font-semibold text-sm text-zinc-100 font-serif">NORFOLK FREE-RANGE ROAST CHICKEN</div>
            </div>
            <div className="text-right">
              <div className="text-emerald-400 font-bold text-sm">£11.50</div>
              <div className="text-[10px] text-zinc-400">SERVED WITH HOUSE GRAVY</div>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
