'use client';

import React from 'react';
import { ShieldCheck, Flame, Box, Truck, CheckCircle2, Cpu, Sparkles } from 'lucide-react';

export const AngloSystemSection: React.FC = () => {
  const steps = [
    {
      num: '01',
      title: 'INGREDIENTS',
      desc: 'Direct British sourcing from Norfolk, Yorkshire & Cambridgeshire. Daily fresh delivery.',
      icon: Cpu,
    },
    {
      num: '02',
      title: 'KITCHENS',
      desc: 'Stainless steel high-capacity kitchens with precision digital order queueing.',
      icon: ShieldCheck,
    },
    {
      num: '03',
      title: 'COOKING',
      desc: 'Made to order. Roast chicken, seared beef, and fish fried in fresh oil.',
      icon: Flame,
    },
    {
      num: '04',
      title: 'PACKAGING',
      desc: 'Custom engineered recycled thermal paper packaging to preserve crispness and heat.',
      icon: Box,
    },
    {
      num: '05',
      title: 'LOGISTICS',
      desc: 'Dedicated electric vehicle fleet dispatched precisely when packing completes.',
      icon: Truck,
    },
    {
      num: '06',
      title: 'DELIVERY',
      desc: 'Direct route navigation with live transport tracking and zero-contact drop.',
      icon: CheckCircle2,
    },
  ];

  return (
    <section id="system" className="w-full py-16 sm:py-20 border-b border-zinc-200 dark:border-zinc-800 bg-[#FAF9F5] dark:bg-[#111315]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Section Header */}
        <div className="space-y-3 max-w-2xl border-b border-zinc-300 dark:border-zinc-800 pb-8">
          <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
            03. OPERATIONAL PHILOSOPHY
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold tracking-tight font-serif text-zinc-900 dark:text-zinc-50">
            THE ANGLO SYSTEM
          </h2>
          <p className="text-sm sm:text-base text-zinc-700 dark:text-zinc-300 font-sans font-light leading-relaxed">
            Good takeaway is partly about food and partly about what happens around it. We treat British takeaway as a serious modern food system.
          </p>
        </div>

        {/* Horizontal Process Diagram Flow */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 relative">
          {steps.map((step, idx) => {
            const IconComp = step.icon;
            return (
              <div
                key={step.num}
                className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex flex-col justify-between space-y-4 relative group hover:border-[#004225] transition-colors"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="font-bold text-[#004225] dark:text-emerald-400">{step.num}</span>
                    <IconComp className="w-4 h-4 text-zinc-400 group-hover:text-[#004225] dark:group-hover:text-emerald-400 transition-colors" />
                  </div>

                  <h3 className="text-sm font-bold font-mono text-zinc-900 dark:text-zinc-100 tracking-wider">
                    {step.title}
                  </h3>

                  <p className="text-xs text-zinc-600 dark:text-zinc-400 font-sans leading-relaxed">
                    {step.desc}
                  </p>
                </div>

                <div className="pt-3 border-t border-zinc-100 dark:border-zinc-800/80 text-[10px] font-mono text-zinc-400 uppercase">
                  STAGE {idx + 1} OF 6
                </div>
              </div>
            );
          })}
        </div>

        {/* Process Guarantee Quote */}
        <div className="p-8 bg-[#004225] text-white font-serif text-xl sm:text-2xl leading-snug flex flex-col sm:flex-row items-center justify-between gap-6">
          <p className="max-w-3xl font-light italic">
            &ldquo;From Norfolk chicken farms to your front door in under 30 minutes. Engineered for heat, texture, and taste.&rdquo;
          </p>
          <span className="font-mono text-xs not-italic tracking-widest text-emerald-300 uppercase shrink-0 border border-emerald-600 px-3 py-1">
            ANGLO SPECIFICATION 2026
          </span>
        </div>

      </div>
    </section>
  );
};
