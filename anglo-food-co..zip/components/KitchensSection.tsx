'use client';

import React, { useState } from 'react';
import { MapPin, Search, Clock, Activity, Check, ArrowRight, ShieldCheck } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { KITCHENS, Kitchen } from '@/lib/data';

export const KitchensSection: React.FC = () => {
  const { selectedKitchen, setSelectedKitchen, setDeliveryType, setIsKitchensModalOpen } = useApp();
  const [searchPostcode, setSearchPostcode] = useState('');

  const filteredKitchens = KITCHENS.filter(
    (k) =>
      searchPostcode.trim() === '' ||
      k.city.toLowerCase().includes(searchPostcode.toLowerCase()) ||
      k.postcode.toLowerCase().includes(searchPostcode.toLowerCase()) ||
      k.name.toLowerCase().includes(searchPostcode.toLowerCase())
  );

  return (
    <section id="kitchens" className="w-full py-16 sm:py-20 border-b border-zinc-200 dark:border-zinc-800 bg-[#FAF9F5] dark:bg-[#111315]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Editorial Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-zinc-300 dark:border-zinc-800 pb-8">
          <div className="space-y-3 max-w-2xl">
            <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              02. INFRASTRUCTURE NETWORK
            </div>
            <h2 className="text-3xl sm:text-5xl font-bold tracking-tight font-serif text-zinc-900 dark:text-zinc-50">
              ANGLO KITCHENS
            </h2>
            <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 font-sans font-light">
              A growing network of modern British kitchens. Designed for speed, precision, and food quality.
            </p>
          </div>

          {/* Search Postcode Input */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Enter postcode or city..."
              value={searchPostcode}
              onChange={(e) => setSearchPostcode(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-xs font-mono text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-[#004225] dark:focus:border-emerald-500 transition-colors"
            />
          </div>
        </div>

        {/* Transport Map & Kitchen Network Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Transport Line Map Visualizer */}
          <div className="lg:col-span-5 bg-zinc-900 text-white p-6 sm:p-8 space-y-6 border border-zinc-800 relative overflow-hidden">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <span className="text-xs font-mono text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                NETWORK CARTOGRAPHY
              </span>
              <span className="text-[10px] font-mono text-zinc-500">6 ACTIVE NODES</span>
            </div>

            {/* Stylized British Transport Schematic Map */}
            <div className="relative h-72 sm:h-80 w-full bg-[#121417] border border-zinc-800 p-4 font-mono text-[11px] flex flex-col justify-between">
              
              {/* Map Railway / Transport Lines SVG */}
              <svg className="absolute inset-0 w-full h-full stroke-zinc-700/60 stroke-[1.5] fill-none pointer-events-none">
                {/* Vertical Main Trunk Line */}
                <path d="M 140 30 L 140 250" strokeDasharray="4 4" />
                {/* Diagonal Branch Lines */}
                <path d="M 140 180 L 220 220" />
                <path d="M 140 120 L 70 160" />
                <path d="M 140 60 L 210 90" />
              </svg>

              {/* Kitchen Map Nodes */}
              <div className="relative z-10 h-full flex flex-col justify-between py-2">
                
                {/* Edinburgh Node */}
                <div className="flex items-center gap-2 pl-24">
                  <span className="w-3 h-3 bg-emerald-500 border-2 border-zinc-900 shrink-0" />
                  <span className="text-xs font-bold text-zinc-100">EDINBURGH 06</span>
                  <span className="text-[9px] text-zinc-500">980 OFF</span>
                </div>

                {/* Leeds & Manchester Nodes */}
                <div className="flex items-center justify-between px-4">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 bg-emerald-500 border-2 border-zinc-900 shrink-0" />
                    <span className="text-xs font-bold text-zinc-100">MANCHESTER 03</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 bg-emerald-500 border-2 border-zinc-900 shrink-0" />
                    <span className="text-xs font-bold text-zinc-100">LEEDS 04</span>
                  </div>
                </div>

                {/* Sheffield Node */}
                <div className="flex items-center gap-2 pl-24">
                  <span className="w-3 h-3 bg-emerald-500 border-2 border-zinc-900 shrink-0" />
                  <span className="text-xs font-bold text-zinc-100">SHEFFIELD 02</span>
                </div>

                {/* Bristol & London Nodes */}
                <div className="flex items-center justify-between px-4">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 bg-emerald-500 border-2 border-zinc-900 shrink-0" />
                    <span className="text-xs font-bold text-zinc-100">BRISTOL 05</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 bg-[#004225] border-2 border-emerald-400 shrink-0" />
                    <span className="text-xs font-bold text-emerald-400">LONDON 01 (HUB)</span>
                  </div>
                </div>

              </div>
            </div>

            {/* Operational Summary Strip */}
            <div className="grid grid-cols-3 gap-2 pt-2 text-center text-xs font-mono border-t border-zinc-800">
              <div>
                <div className="text-[10px] text-zinc-500">NETWORK ORDERS</div>
                <div className="font-bold text-zinc-100 tabular-nums">7,712 TODAY</div>
              </div>
              <div>
                <div className="text-[10px] text-zinc-500">AVG PREP TIME</div>
                <div className="font-bold text-emerald-400 tabular-nums">08:42 MIN</div>
              </div>
              <div>
                <div className="text-[10px] text-zinc-500">SERVICE STATUS</div>
                <div className="font-bold text-emerald-400">NORMAL</div>
              </div>
            </div>

          </div>

          {/* Right Column: Kitchen Cards List */}
          <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {filteredKitchens.map((k) => {
              const isSelected = selectedKitchen.id === k.id;

              return (
                <div
                  key={k.id}
                  className={`p-6 border text-left flex flex-col justify-between gap-4 transition-all ${
                    isSelected
                      ? 'bg-white dark:bg-zinc-900 border-[#004225] dark:border-emerald-500 shadow-sm'
                      : 'bg-white dark:bg-zinc-900/60 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400'
                  }`}
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono font-bold text-[#004225] dark:text-emerald-400 tracking-wider">
                        {k.code}
                      </span>
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300 text-[10px] font-mono font-bold">
                        {k.status}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-lg font-bold font-serif text-zinc-900 dark:text-zinc-50">
                        {k.name}
                      </h3>
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono mt-0.5">
                        {k.address}, {k.postcode}
                      </p>
                    </div>

                    {/* Operational Telemetry Data */}
                    <div className="grid grid-cols-2 gap-2 p-2.5 bg-zinc-100/80 dark:bg-zinc-800/80 font-mono text-[11px] text-zinc-700 dark:text-zinc-300">
                      <div>
                        <span className="text-[9px] text-zinc-500 uppercase block">ORDERS TODAY</span>
                        <span className="font-bold tabular-nums">{k.ordersToday.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-[9px] text-zinc-500 uppercase block">AVG PREP</span>
                        <span className="font-bold tabular-nums text-emerald-700 dark:text-emerald-400">{k.avgPrepMinutes}m</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                    <span className="text-[11px] font-mono text-zinc-500">
                      {k.service}
                    </span>

                    <button
                      onClick={() => {
                        setSelectedKitchen(k);
                        setDeliveryType('DELIVERY');
                      }}
                      className={`px-3 py-1.5 text-xs font-mono font-semibold uppercase tracking-wider transition-colors ${
                        isSelected
                          ? 'bg-[#004225] text-white dark:bg-[#006B3C]'
                          : 'bg-zinc-200 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 hover:bg-[#004225] hover:text-white'
                      }`}
                    >
                      {isSelected ? 'ACTIVE KITCHEN' : 'SELECT KITCHEN'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

      </div>
    </section>
  );
};
