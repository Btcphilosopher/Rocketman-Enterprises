'use client';

import React, { useState } from 'react';
import { X, User, MapPin, Heart, Clock, ShieldCheck, RefreshCw, Check } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { MENU_ITEMS } from '@/lib/data';

export const AccountModal: React.FC = () => {
  const { isAccountModalOpen, setIsAccountModalOpen, user, reorderPrevious, toggleFavourite, setIsBasketOpen } = useApp();
  const [activeTab, setActiveTab] = useState<'ADDRESSES' | 'FAVOURITES' | 'ORDERS' | 'PREFERENCES'>('ORDERS');

  if (!isAccountModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl my-8 bg-[#FAF9F5] dark:bg-[#181A1D] border border-zinc-300 dark:border-zinc-700 shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-zinc-300 dark:border-zinc-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-[#004225] text-white">
              <User className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
                MY ANGLO ACCOUNT
              </div>
              <h2 className="text-2xl font-bold font-serif text-zinc-900 dark:text-zinc-50">
                {user.name}
              </h2>
              <div className="text-xs font-mono text-zinc-500">{user.email} · {user.phone}</div>
            </div>
          </div>

          <button
            onClick={() => setIsAccountModalOpen(false)}
            className="p-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 overflow-x-auto border-b border-zinc-200 dark:border-zinc-800 pb-2 font-mono text-xs">
          {(['ORDERS', 'FAVOURITES', 'ADDRESSES', 'PREFERENCES'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 uppercase font-semibold transition-colors ${
                activeTab === tab
                  ? 'bg-[#004225] text-white'
                  : 'bg-zinc-200/60 dark:bg-zinc-800/60 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-300'
              }`}
            >
              {tab === 'ORDERS' && 'PREVIOUS ORDERS'}
              {tab === 'FAVOURITES' && 'FAVOURITES'}
              {tab === 'ADDRESSES' && 'SAVED ADDRESSES'}
              {tab === 'PREFERENCES' && 'DIETARY PREFERENCES'}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="min-h-[300px] max-h-[50vh] overflow-y-auto pr-1">
          
          {/* ORDERS TAB */}
          {activeTab === 'ORDERS' && (
            <div className="space-y-4">
              {user.previousOrders.length === 0 ? (
                <p className="text-xs font-mono text-zinc-500 text-center py-12 uppercase">
                  No previous orders recorded.
                </p>
              ) : (
                user.previousOrders.map((order) => (
                  <div
                    key={order.orderId}
                    className="p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3 font-mono text-xs"
                  >
                    <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                      <div>
                        <span className="font-bold text-[#004225] dark:text-emerald-400">{order.orderId}</span>
                        <span className="text-zinc-500 text-[10px] ml-2">({order.createdAt})</span>
                      </div>
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                        {order.status}
                      </span>
                    </div>

                    <div className="space-y-1 text-zinc-700 dark:text-zinc-300">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="flex justify-between">
                          <span>{item.quantity}x {item.menuItem.name}</span>
                          <span className="tabular-nums">£{item.totalPrice.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 border-t border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
                      <div className="text-zinc-500">
                        Total: <span className="font-bold text-zinc-900 dark:text-zinc-100">£{order.total.toFixed(2)}</span>
                      </div>

                      <button
                        onClick={() => {
                          reorderPrevious(order);
                          setIsAccountModalOpen(false);
                          setIsBasketOpen(true);
                        }}
                        className="px-3 py-1.5 bg-[#004225] text-white font-semibold uppercase hover:bg-[#00331C] transition-colors flex items-center gap-1.5"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>RE-ORDER MEAL</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {/* FAVOURITES TAB */}
          {activeTab === 'FAVOURITES' && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {user.favouriteItemIds.map((favId) => {
                const item = MENU_ITEMS.find((m) => m.id === favId);
                if (!item) return null;

                return (
                  <div
                    key={item.id}
                    className="p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between gap-3"
                  >
                    <div>
                      <h4 className="text-sm font-bold font-serif text-zinc-900 dark:text-zinc-50">{item.name}</h4>
                      <div className="text-xs font-mono text-[#004225] dark:text-emerald-400 font-semibold">£{item.price.toFixed(2)}</div>
                    </div>

                    <button
                      onClick={() => toggleFavourite(item.id)}
                      className="p-2 text-red-600 hover:bg-zinc-100 dark:hover:bg-zinc-800"
                      title="Remove from Favourites"
                    >
                      <Heart className="w-4 h-4 fill-red-600" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}

          {/* ADDRESSES TAB */}
          {activeTab === 'ADDRESSES' && (
            <div className="space-y-3 font-mono text-xs">
              {user.savedAddresses.map((addr) => (
                <div key={addr.id} className="p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
                  <div>
                    <div className="font-bold text-zinc-900 dark:text-zinc-100 flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-[#004225] dark:text-emerald-400" />
                      <span>{addr.label}</span>
                    </div>
                    <div className="text-zinc-500 mt-1">{addr.street}, {addr.postcode}, {addr.city}</div>
                  </div>
                  <span className="px-2 py-1 border border-zinc-300 dark:border-zinc-700 text-[10px] uppercase">DEFAULT</span>
                </div>
              ))}
            </div>
          )}

          {/* PREFERENCES TAB */}
          {activeTab === 'PREFERENCES' && (
            <div className="space-y-4 font-mono text-xs">
              <div className="p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3">
                <div className="font-bold text-zinc-900 dark:text-zinc-100 uppercase">DIETARY RESTRICTION FILTERS</div>
                <div className="space-y-2 text-zinc-600 dark:text-zinc-400">
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={user.dietaryPreferences.noNuts} readOnly className="accent-[#004225]" />
                    <span>Nut Allergy Protocol Always Active</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input type="checkbox" checked={user.dietaryPreferences.vegetarianOnly} readOnly className="accent-[#004225]" />
                    <span>Strict Vegetarian Filter</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
