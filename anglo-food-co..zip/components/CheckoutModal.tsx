'use client';

import React, { useState } from 'react';
import { X, Check, ShieldCheck, CreditCard, MapPin, Truck, Clock, ArrowRight } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    basket,
    basketSubtotal,
    deliveryFee,
    basketTotal,
    selectedKitchen,
    deliveryType,
    postcode,
    setPostcode,
    deliveryAddress,
    setDeliveryAddress,
    placeOrder,
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'CARD' | 'CONTACTLESS' | 'CREDIT'>('CARD');

  if (!isCheckoutOpen) return null;

  const now = new Date();
  const etaStart = new Date(now.getTime() + 18 * 60000);
  const etaEnd = new Date(now.getTime() + 28 * 60000);
  const formatTime = (d: Date) => d.toTimeString().slice(0, 5);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl my-8 bg-[#FAF9F5] dark:bg-[#181A1D] border border-zinc-300 dark:border-zinc-700 shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-zinc-300 dark:border-zinc-800 pb-4">
          <div>
            <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              CHECKOUT SYSTEM
            </div>
            <h2 className="text-2xl font-bold font-serif text-zinc-900 dark:text-zinc-50">
              CONFIRM YOUR ORDER
            </h2>
          </div>

          <button
            onClick={() => setIsCheckoutOpen(false)}
            className="p-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Indicator Header (01 FOOD -> 02 KITCHEN -> 03 DELIVERY -> 04 PAYMENT -> 05 CONFIRM) */}
        <div className="grid grid-cols-5 gap-1 font-mono text-[10px] text-center uppercase border-b border-zinc-200 dark:border-zinc-800 pb-4">
          <div className="text-emerald-700 dark:text-emerald-400 font-bold">✓ 01 FOOD</div>
          <div className="text-emerald-700 dark:text-emerald-400 font-bold">✓ 02 KITCHEN</div>
          <div className="text-emerald-700 dark:text-emerald-400 font-bold">✓ 03 DELIVERY</div>
          <div className="text-emerald-700 dark:text-emerald-400 font-bold">✓ 04 PAYMENT</div>
          <div className="bg-[#004225] text-white font-bold py-0.5">● 05 CONFIRM</div>
        </div>

        {/* Explicit Demo Disclaimer Banner */}
        <div className="p-3 bg-amber-100 dark:bg-amber-950/80 border border-amber-300 dark:border-amber-700 text-amber-900 dark:text-amber-200 text-xs font-mono font-bold flex items-center justify-between">
          <span className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 shrink-0 text-amber-700 dark:text-amber-400" />
            <span>DEMO CHECKOUT — NO REAL PAYMENT REQUIRED</span>
          </span>
          <span className="text-[10px] uppercase font-normal">TEST MODE</span>
        </div>

        {/* Delivery Details & Kitchen Summary */}
        <div className="space-y-4">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-900 dark:text-zinc-100">
            DELIVERY ADDRESS & KITCHEN
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
              <span className="text-[10px] text-zinc-400 block uppercase">FULFILLED BY</span>
              <div className="font-bold text-zinc-900 dark:text-zinc-100">{selectedKitchen.code}</div>
              <div className="text-zinc-500">{selectedKitchen.address}</div>
            </div>

            <div className="p-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-2">
              <span className="text-[10px] text-zinc-400 block uppercase">DELIVERY DESTINATION</span>
              <input
                type="text"
                value={deliveryAddress.street}
                onChange={(e) => setDeliveryAddress((prev) => ({ ...prev, street: e.target.value }))}
                placeholder="Street address..."
                className="w-full bg-transparent border-b border-zinc-300 dark:border-zinc-700 focus:outline-none focus:border-[#004225] text-zinc-900 dark:text-zinc-100 font-semibold"
              />
              <div className="flex gap-2 pt-1">
                <input
                  type="text"
                  value={postcode}
                  onChange={(e) => setPostcode(e.target.value.toUpperCase())}
                  placeholder="Postcode..."
                  className="w-24 bg-transparent border-b border-zinc-300 dark:border-zinc-700 focus:outline-none focus:border-[#004225] text-zinc-900 dark:text-zinc-100"
                />
                <input
                  type="text"
                  value={deliveryAddress.city}
                  onChange={(e) => setDeliveryAddress((prev) => ({ ...prev, city: e.target.value }))}
                  placeholder="City..."
                  className="flex-1 bg-transparent border-b border-zinc-300 dark:border-zinc-700 focus:outline-none focus:border-[#004225] text-zinc-900 dark:text-zinc-100"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Estimated Arrival Window */}
        <div className="p-4 bg-zinc-900 text-white font-mono text-xs flex items-center justify-between border border-zinc-800">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-400" />
            <div>
              <span className="text-[10px] text-zinc-400 uppercase block">ESTIMATED ARRIVAL WINDOW</span>
              <span className="font-bold text-sm text-emerald-400">
                {formatTime(etaStart)} — {formatTime(etaEnd)}
              </span>
            </div>
          </div>
          <span className="text-[10px] text-zinc-400 uppercase">~22 MIN PREPARATION & DISPATCH</span>
        </div>

        {/* Simulated Payment Method Selection */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-900 dark:text-zinc-100">
            PAYMENT METHOD (DEMO)
          </h3>

          <div className="grid grid-cols-3 gap-2 font-mono text-xs">
            <button
              onClick={() => setPaymentMethod('CARD')}
              className={`p-3 border text-center transition-colors ${
                paymentMethod === 'CARD'
                  ? 'border-[#004225] bg-[#004225]/10 font-bold text-zinc-900 dark:text-zinc-100 dark:border-emerald-500'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400 text-zinc-600'
              }`}
            >
              CARD ••• 4242
            </button>

            <button
              onClick={() => setPaymentMethod('CONTACTLESS')}
              className={`p-3 border text-center transition-colors ${
                paymentMethod === 'CONTACTLESS'
                  ? 'border-[#004225] bg-[#004225]/10 font-bold text-zinc-900 dark:text-zinc-100 dark:border-emerald-500'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400 text-zinc-600'
              }`}
            >
              APPLE PAY / CONTACTLESS
            </button>

            <button
              onClick={() => setPaymentMethod('CREDIT')}
              className={`p-3 border text-center transition-colors ${
                paymentMethod === 'CREDIT'
                  ? 'border-[#004225] bg-[#004225]/10 font-bold text-zinc-900 dark:text-zinc-100 dark:border-emerald-500'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400 text-zinc-600'
              }`}
            >
              ANGLO ACCOUNT
            </button>
          </div>
        </div>

        {/* Order Summary Total & Action */}
        <div className="pt-4 border-t border-zinc-300 dark:border-zinc-800 space-y-4">
          <div className="flex items-center justify-between font-mono text-sm">
            <span className="text-zinc-600 dark:text-zinc-400 uppercase">TOTAL AMOUNT PAYABLE</span>
            <span className="font-bold text-lg text-[#004225] dark:text-emerald-400 tabular-nums">
              £{basketTotal.toFixed(2)}
            </span>
          </div>

          <button
            onClick={placeOrder}
            className="w-full py-4 bg-[#004225] text-white hover:bg-[#00331C] text-sm font-mono font-bold uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
          >
            <span>PLACE SIMULATED ORDER</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
