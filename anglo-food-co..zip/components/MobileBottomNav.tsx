'use client';

import React from 'react';
import { Home, Utensils, Clock, MapPin, User, ShoppingBag } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';

export const MobileBottomNav: React.FC = () => {
  const {
    basket,
    basketTotal,
    setIsBasketOpen,
    setIsKitchensModalOpen,
    setIsAccountModalOpen,
    setIsTrackerOpen,
    activeOrder,
  } = useApp();

  const totalBasketCount = basket.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#FAF9F5]/95 dark:bg-[#111315]/95 backdrop-blur-md border-t border-zinc-300 dark:border-zinc-800">
      
      {/* Floating Sticky Basket Bar (if items exist) */}
      {totalBasketCount > 0 && (
        <div className="p-2 border-b border-zinc-200 dark:border-zinc-800">
          <button
            onClick={() => setIsBasketOpen(true)}
            className="w-full py-2.5 px-4 bg-[#004225] text-white font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-between shadow-md"
          >
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4" />
              <span>{totalBasketCount} {totalBasketCount === 1 ? 'ITEM' : 'ITEMS'}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="tabular-nums">£{basketTotal.toFixed(2)}</span>
              <span className="text-[10px] bg-white text-[#004225] px-2 py-0.5 font-bold">VIEW BASKET</span>
            </div>
          </button>
        </div>
      )}

      {/* Navigation Icons Bar */}
      <div className="grid grid-cols-5 h-14 font-mono text-[10px] uppercase text-zinc-600 dark:text-zinc-400">
        <a
          href="#"
          className="flex flex-col items-center justify-center gap-1 hover:text-[#004225] dark:hover:text-emerald-400 transition-colors"
        >
          <Home className="w-4 h-4" />
          <span>HOME</span>
        </a>

        <a
          href="#food"
          className="flex flex-col items-center justify-center gap-1 hover:text-[#004225] dark:hover:text-emerald-400 transition-colors"
        >
          <Utensils className="w-4 h-4" />
          <span>FOOD</span>
        </a>

        <button
          onClick={() => {
            if (activeOrder) setIsTrackerOpen(true);
            else setIsAccountModalOpen(true);
          }}
          className="flex flex-col items-center justify-center gap-1 hover:text-[#004225] dark:hover:text-emerald-400 transition-colors relative"
        >
          <Clock className="w-4 h-4" />
          <span>ORDERS</span>
          {activeOrder && (
            <span className="absolute top-2 right-4 w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          )}
        </button>

        <button
          onClick={() => setIsKitchensModalOpen(true)}
          className="flex flex-col items-center justify-center gap-1 hover:text-[#004225] dark:hover:text-emerald-400 transition-colors"
        >
          <MapPin className="w-4 h-4" />
          <span>KITCHENS</span>
        </button>

        <button
          onClick={() => setIsAccountModalOpen(true)}
          className="flex flex-col items-center justify-center gap-1 hover:text-[#004225] dark:hover:text-emerald-400 transition-colors"
        >
          <User className="w-4 h-4" />
          <span>ACCOUNT</span>
        </button>
      </div>

    </div>
  );
};
