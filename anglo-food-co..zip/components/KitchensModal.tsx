'use client';

import React, { useState } from 'react';
import { X, MapPin, Search, Check, Clock } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { KITCHENS, Kitchen } from '@/lib/data';

export const KitchensModal: React.FC = () => {
  const { isKitchensModalOpen, setIsKitchensModalOpen, selectedKitchen, setSelectedKitchen, postcode, setPostcode, deliveryType, setDeliveryType } = useApp();
  const [search, setSearch] = useState('');

  if (!isKitchensModalOpen) return null;

  const filtered = KITCHENS.filter(
    (k) =>
      search.trim() === '' ||
      k.city.toLowerCase().includes(search.toLowerCase()) ||
      k.postcode.toLowerCase().includes(search.toLowerCase()) ||
      k.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-2xl my-8 bg-[#FAF9F5] dark:bg-[#181A1D] border border-zinc-300 dark:border-zinc-700 shadow-2xl p-6 sm:p-8 space-y-6">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-zinc-300 dark:border-zinc-800 pb-4">
          <div>
            <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              LOCATION & SERVICE
            </div>
            <h2 className="text-2xl font-bold font-serif text-zinc-900 dark:text-zinc-50">
              SELECT YOUR ANGLO KITCHEN
            </h2>
          </div>

          <button
            onClick={() => setIsKitchensModalOpen(false)}
            className="p-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Service Type Toggle */}
        <div className="flex items-center gap-2 p-1 bg-zinc-200 dark:bg-zinc-800 text-xs font-mono">
          <button
            onClick={() => setDeliveryType('DELIVERY')}
            className={`flex-1 py-2 font-semibold transition-colors ${
              deliveryType === 'DELIVERY'
                ? 'bg-[#004225] text-white shadow-xs'
                : 'text-zinc-700 dark:text-zinc-300 hover:text-zinc-900'
            }`}
          >
            DELIVERY TO DOOR
          </button>
          <button
            onClick={() => setDeliveryType('COLLECTION')}
            className={`flex-1 py-2 font-semibold transition-colors ${
              deliveryType === 'COLLECTION'
                ? 'bg-[#004225] text-white shadow-xs'
                : 'text-zinc-700 dark:text-zinc-300 hover:text-zinc-900'
            }`}
          >
            COLLECT FROM KITCHEN
          </button>
        </div>

        {/* Postcode Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Enter postcode or town (e.g. SE1, S3, M4, LS1)..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPostcode(e.target.value.toUpperCase());
            }}
            className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-xs font-mono text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-[#004225]"
          />
        </div>

        {/* Kitchen List */}
        <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
          {filtered.map((k) => {
            const isSelected = selectedKitchen.id === k.id;

            return (
              <div
                key={k.id}
                onClick={() => {
                  setSelectedKitchen(k);
                  setIsKitchensModalOpen(false);
                }}
                className={`p-4 border text-left cursor-pointer transition-all flex items-center justify-between ${
                  isSelected
                    ? 'bg-white dark:bg-zinc-900 border-[#004225] dark:border-emerald-500 shadow-sm'
                    : 'bg-white dark:bg-zinc-900/60 border-zinc-200 dark:border-zinc-800 hover:border-zinc-400'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-[#004225] dark:text-emerald-400">
                      {k.code}
                    </span>
                    <span className="text-[10px] font-mono text-zinc-500">({k.city})</span>
                  </div>
                  <div className="text-sm font-bold font-serif text-zinc-900 dark:text-zinc-50">
                    {k.name}
                  </div>
                  <div className="text-xs font-mono text-zinc-500">
                    {k.address}, {k.postcode} · {k.avgPrepMinutes}m prep time
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {isSelected ? (
                    <span className="p-2 bg-[#004225] text-white">
                      <Check className="w-4 h-4" />
                    </span>
                  ) : (
                    <button className="px-3 py-1.5 border border-zinc-300 dark:border-zinc-700 text-xs font-mono uppercase hover:bg-zinc-100 dark:hover:bg-zinc-800">
                      SELECT
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </div>
  );
};
