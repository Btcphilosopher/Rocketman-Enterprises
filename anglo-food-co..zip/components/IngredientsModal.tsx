'use client';

import React from 'react';
import { X, MapPin, Sparkles, Check } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { INGREDIENT_DOCS } from '@/lib/data';

export const IngredientsModal: React.FC = () => {
  const { isIngredientsModalOpen, setIsIngredientsModalOpen } = useApp();

  if (!isIngredientsModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl my-8 bg-[#FAF9F5] dark:bg-[#181A1D] border border-zinc-300 dark:border-zinc-700 shadow-2xl p-6 sm:p-10 space-y-8">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-zinc-300 dark:border-zinc-800 pb-6">
          <div className="space-y-1">
            <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              INGREDIENT DIRECTORY
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold font-serif text-zinc-900 dark:text-zinc-50">
              BRITISH SOURCING
            </h2>
            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-400 font-sans">
              Straightforward food. Very good ingredients from verified regional farms and docks.
            </p>
          </div>

          <button
            onClick={() => setIsIngredientsModalOpen(false)}
            className="p-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Ingredients Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-h-[60vh] overflow-y-auto pr-2">
          {INGREDIENT_DOCS.map((doc) => (
            <div
              key={doc.id}
              className="p-6 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 space-y-3 text-left"
            >
              <div className="flex items-center justify-between border-b border-zinc-100 dark:border-zinc-800 pb-2">
                <h3 className="text-base font-bold font-serif text-zinc-900 dark:text-zinc-50">
                  {doc.title}
                </h3>
                <span className="text-[10px] font-mono font-semibold text-[#004225] dark:text-emerald-400 uppercase flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {doc.sourceRegion}
                </span>
              </div>

              <p className="text-xs text-zinc-600 dark:text-zinc-400 font-sans leading-relaxed">
                {doc.description}
              </p>

              <div className="pt-2 text-[10px] font-mono text-zinc-500 space-y-1">
                <div><span className="font-bold uppercase text-zinc-700 dark:text-zinc-300">SEASONALITY:</span> {doc.seasonality}</div>
                <div><span className="font-bold uppercase text-zinc-700 dark:text-zinc-300">PREPARATION:</span> {doc.preparation}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-zinc-300 dark:border-zinc-800 flex justify-end">
          <button
            onClick={() => setIsIngredientsModalOpen(false)}
            className="px-6 py-2.5 bg-[#004225] text-white text-xs font-mono font-semibold uppercase tracking-wider hover:bg-[#00331C] transition-colors"
          >
            CLOSE DIRECTORY
          </button>
        </div>

      </div>
    </div>
  );
};
