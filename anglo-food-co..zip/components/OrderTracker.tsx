'use client';

import React from 'react';
import { X, CheckCircle, Clock, MapPin, Truck, RefreshCw, ChevronRight } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';

export const OrderTracker: React.FC = () => {
  const { isTrackerOpen, setIsTrackerOpen, activeOrder, cancelOrder } = useApp();

  if (!isTrackerOpen || !activeOrder) return null;

  const currentStepIndex = activeOrder.timeline.findIndex((s) => s.status === activeOrder.status);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/75 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-3xl my-8 bg-[#FAF9F5] dark:bg-[#181A1D] border border-zinc-300 dark:border-zinc-700 shadow-2xl p-6 sm:p-8 space-y-8">
        
        {/* Header */}
        <div className="flex items-start justify-between border-b border-zinc-300 dark:border-zinc-800 pb-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>LIVE ORDER SIMULATOR</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-zinc-900 dark:text-zinc-50">
              ORDER {activeOrder.orderId}
            </h2>
            <div className="text-xs font-mono text-zinc-500">
              FULFILLED BY: <span className="font-semibold text-zinc-800 dark:text-zinc-200">{activeOrder.kitchen.code}</span>
            </div>
          </div>

          <button
            onClick={() => setIsTrackerOpen(false)}
            className="p-2 bg-zinc-200 dark:bg-zinc-800 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-300 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Estimated Arrival Time Banner */}
        <div className="p-4 bg-[#004225] text-white font-mono text-xs flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Clock className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="text-[10px] text-emerald-300 uppercase block">ESTIMATED ARRIVAL TIME</span>
              <span className="font-bold text-lg text-white tabular-nums">
                {activeOrder.estimatedArrival}
              </span>
            </div>
          </div>

          <div className="text-right sm:text-left text-[11px] text-emerald-200 border-l sm:border-l border-emerald-700 pl-4">
            <div>STATUS: <span className="font-bold text-white uppercase">{activeOrder.status.replace('_', ' ')}</span></div>
            <div>DELIVERY TO: {activeOrder.deliveryAddress.street}, {activeOrder.deliveryAddress.postcode}</div>
          </div>
        </div>

        {/* Status Timeline Progression */}
        <div className="space-y-3">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-900 dark:text-zinc-100">
            KITCHEN & LOGISTICS PROGRESSION
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-1 font-mono text-[10px] text-center">
            {activeOrder.timeline.map((step, idx) => {
              const isDone = step.completed;
              const isCurrent = step.status === activeOrder.status;

              return (
                <div
                  key={step.status}
                  className={`p-2 border transition-all ${
                    isCurrent
                      ? 'bg-[#004225] text-white border-[#004225] font-bold shadow-xs'
                      : isDone
                      ? 'bg-emerald-950/20 text-emerald-700 dark:text-emerald-400 border-emerald-700/50'
                      : 'bg-zinc-100 dark:bg-zinc-900 text-zinc-400 border-zinc-200 dark:border-zinc-800'
                  }`}
                >
                  <div className="text-[9px] mb-1 opacity-80">{step.timestamp}</div>
                  <div className="truncate font-semibold">{step.label}</div>
                  <div className="mt-1">
                    {isDone ? '✓' : isCurrent ? '●' : '○'}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Custom Transport-Inspired Route Map Visualizer */}
        <div className="p-6 bg-zinc-900 text-white font-mono text-xs border border-zinc-800 space-y-4 relative overflow-hidden">
          <div className="flex items-center justify-between border-b border-zinc-800 pb-2 text-[10px] text-zinc-400 uppercase">
            <span>TRANSPORT ROUTE CANVAS</span>
            <span>DISPATCH COURIER: DAVE (ELECTRIC FLEET #08)</span>
          </div>

          <div className="relative h-44 bg-[#121417] border border-zinc-800 p-4 flex items-center justify-between">
            {/* Route Vector SVG Line */}
            <svg className="absolute inset-0 w-full h-full stroke-emerald-500/80 stroke-[2] fill-none pointer-events-none">
              <line x1="60" y1="88" x2="85%" y2="88" strokeDasharray="6 4" />
            </svg>

            {/* Kitchen Origin Node */}
            <div className="relative z-10 flex flex-col items-center gap-1">
              <span className="w-6 h-6 bg-[#004225] border-2 border-emerald-400 flex items-center justify-center font-bold text-xs text-white">
                K
              </span>
              <span className="text-[10px] font-bold text-emerald-400">{activeOrder.kitchen.code.split('/ ')[1]}</span>
            </div>

            {/* Moving Courier Marker based on progression */}
            <div
              className="relative z-10 flex flex-col items-center gap-1 transition-all duration-1000 ease-in-out"
              style={{
                left: `${Math.min(75, Math.max(5, (currentStepIndex / 6) * 75))}%`,
              }}
            >
              <div className="p-2 bg-emerald-500 text-zinc-900 rounded-full shadow-lg animate-bounce">
                <Truck className="w-4 h-4" />
              </div>
              <span className="text-[9px] text-zinc-300 font-bold uppercase">DISPATCH COURIER</span>
            </div>

            {/* Customer Destination Node */}
            <div className="relative z-10 flex flex-col items-center gap-1">
              <span className="w-6 h-6 bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center font-bold text-xs text-zinc-300">
                D
              </span>
              <span className="text-[10px] font-bold text-zinc-300">{activeOrder.deliveryAddress.postcode}</span>
            </div>
          </div>
        </div>

        {/* Itemized Receipt Summary */}
        <div className="space-y-3 pt-2">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-zinc-900 dark:text-zinc-100">
            ORDER SUMMARY RECEIPT
          </h3>

          <div className="p-4 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-mono space-y-2">
            {activeOrder.items.map((item, idx) => (
              <div key={idx} className="flex justify-between border-b border-zinc-100 dark:border-zinc-800/60 pb-1">
                <span>
                  {item.quantity}x {item.menuItem.name}
                  {item.modifiers.length > 0 && (
                    <span className="text-zinc-400 text-[10px]">
                      {' '}
                      ({item.modifiers.map((m) => m.optionName).join(', ')})
                    </span>
                  )}
                </span>
                <span className="tabular-nums font-semibold">£{item.totalPrice.toFixed(2)}</span>
              </div>
            ))}

            <div className="flex justify-between text-zinc-500 pt-1">
              <span>Subtotal</span>
              <span className="tabular-nums">£{activeOrder.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-zinc-500">
              <span>Delivery</span>
              <span className="tabular-nums">£{activeOrder.deliveryFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold text-sm text-zinc-900 dark:text-zinc-50 pt-2 border-t border-zinc-200 dark:border-zinc-800">
              <span>TOTAL PAID</span>
              <span className="tabular-nums text-[#004225] dark:text-emerald-400">
                £{activeOrder.total.toFixed(2)}
              </span>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-4 border-t border-zinc-300 dark:border-zinc-800">
          <button
            onClick={cancelOrder}
            className="px-4 py-2 border border-zinc-300 dark:border-zinc-700 text-xs font-mono text-zinc-600 hover:text-red-600 uppercase"
          >
            DISCORD / RESET DEMO
          </button>

          <button
            onClick={() => setIsTrackerOpen(false)}
            className="px-6 py-2.5 bg-[#004225] text-white text-xs font-mono font-semibold uppercase tracking-wider hover:bg-[#00331C] transition-colors"
          >
            RETURN TO MENU
          </button>
        </div>

      </div>
    </div>
  );
};
