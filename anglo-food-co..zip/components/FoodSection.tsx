'use client';

import React from 'react';
import Image from 'next/image';
import { Search, Heart, Plus, Check, Filter, Sparkles } from 'lucide-react';
import { useApp } from '@/lib/context/AppContext';
import { MENU_CATEGORIES, MENU_ITEMS, MenuItem, LOCALIZATION_STRINGS } from '@/lib/data';

export const FoodSection: React.FC = () => {
  const {
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    dietaryFilter,
    setDietaryFilter,
    setInspectItem,
    addToBasket,
    user,
    toggleFavourite,
    language,
  } = useApp();

  const strings = LOCALIZATION_STRINGS[language];

  // Filter items
  const filteredItems = MENU_ITEMS.filter((item) => {
    // Category match
    if (selectedCategory !== 'ALL' && item.category !== selectedCategory) {
      return false;
    }
    // Search query match
    if (
      searchQuery.trim() !== '' &&
      !item.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !item.description.toLowerCase().includes(searchQuery.toLowerCase()) &&
      !item.ingredients.some((i) => i.toLowerCase().includes(searchQuery.toLowerCase()))
    ) {
      return false;
    }
    // Dietary filters
    if (dietaryFilter.vegetarian && !item.dietary.isVegetarian) return false;
    if (dietaryFilter.glutenFree && !item.dietary.isGlutenFree) return false;
    if (dietaryFilter.nutFree && item.dietary.containsNuts) return false;

    return true;
  });

  return (
    <section id="food" className="w-full py-16 sm:py-20 border-b border-zinc-200 dark:border-zinc-800 bg-[#FAF9F5] dark:bg-[#111315]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        
        {/* Section Editorial Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-zinc-300 dark:border-zinc-800 pb-8">
          <div className="space-y-3 max-w-2xl">
            <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
              01. DAILY MENU
            </div>
            <h2 className="text-3xl sm:text-5xl font-bold tracking-tight font-serif text-zinc-900 dark:text-zinc-50">
              {strings.todayFood}
            </h2>
            <p className="text-sm sm:text-base text-zinc-600 dark:text-zinc-400 font-sans font-light">
              {strings.todaySubtitle}
            </p>
          </div>

          {/* Search Input Bar */}
          <div className="relative w-full md:w-80">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search dishes, ingredients..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white dark:bg-zinc-900 border border-zinc-300 dark:border-zinc-700 text-xs font-mono text-zinc-900 dark:text-zinc-100 placeholder-zinc-400 focus:outline-none focus:border-[#004225] dark:focus:border-emerald-500 transition-colors"
            />
          </div>
        </div>

        {/* Filter Controls & Categories Bar */}
        <div className="space-y-4">
          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-zinc-200 dark:border-zinc-800">
            {MENU_CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 text-xs font-mono font-medium tracking-wider uppercase whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#004225] text-white dark:bg-[#006B3C]'
                    : 'bg-zinc-200/60 text-zinc-700 hover:bg-zinc-300/60 dark:bg-zinc-800/60 dark:text-zinc-300 dark:hover:bg-zinc-700/60'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Dietary Toggles */}
          <div className="flex flex-wrap items-center gap-4 text-xs font-mono pt-1 text-zinc-600 dark:text-zinc-400">
            <span className="flex items-center gap-1.5 font-semibold text-zinc-800 dark:text-zinc-200">
              <Filter className="w-3.5 h-3.5" /> DIETARY:
            </span>

            <button
              onClick={() => setDietaryFilter((prev) => ({ ...prev, vegetarian: !prev.vegetarian }))}
              className={`px-3 py-1 border transition-colors ${
                dietaryFilter.vegetarian
                  ? 'border-[#004225] bg-[#004225]/10 text-[#004225] dark:text-emerald-400 dark:border-emerald-500 font-bold'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400'
              }`}
            >
              VEGETARIAN
            </button>

            <button
              onClick={() => setDietaryFilter((prev) => ({ ...prev, glutenFree: !prev.glutenFree }))}
              className={`px-3 py-1 border transition-colors ${
                dietaryFilter.glutenFree
                  ? 'border-[#004225] bg-[#004225]/10 text-[#004225] dark:text-emerald-400 dark:border-emerald-500 font-bold'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400'
              }`}
            >
              GLUTEN-FREE
            </button>

            <button
              onClick={() => setDietaryFilter((prev) => ({ ...prev, nutFree: !prev.nutFree }))}
              className={`px-3 py-1 border transition-colors ${
                dietaryFilter.nutFree
                  ? 'border-[#004225] bg-[#004225]/10 text-[#004225] dark:text-emerald-400 dark:border-emerald-500 font-bold'
                  : 'border-zinc-300 dark:border-zinc-700 hover:border-zinc-400'
              }`}
            >
              NUT-FREE
            </button>
          </div>
        </div>

        {/* Food Items Grid */}
        {filteredItems.length === 0 ? (
          <div className="py-16 text-center border border-dashed border-zinc-300 dark:border-zinc-800">
            <p className="text-sm font-mono text-zinc-500 uppercase">No dishes match your selected filters.</p>
            <button
              onClick={() => {
                setSelectedCategory('ALL');
                setSearchQuery('');
                setDietaryFilter({ vegetarian: false, glutenFree: false, nutFree: false });
              }}
              className="mt-4 px-4 py-2 bg-zinc-900 text-white dark:bg-zinc-100 dark:text-zinc-900 text-xs font-mono uppercase"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredItems.map((item) => {
              const isFav = user.favouriteItemIds.includes(item.id);

              return (
                <div
                  key={item.id}
                  className="group flex flex-col justify-between bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600 transition-all duration-200"
                >
                  {/* Card Media Header */}
                  <div>
                    <div
                      className="relative w-full aspect-[4/3] bg-zinc-100 dark:bg-zinc-800 overflow-hidden cursor-pointer"
                      onClick={() => setInspectItem(item)}
                    >
                      <Image
                        src={item.image}
                        alt={item.name}
                        fill
                        className="object-cover group-hover:scale-102 transition-transform duration-300"
                        referrerPolicy="no-referrer"
                      />

                      {/* Favourite Button */}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavourite(item.id);
                        }}
                        className="absolute top-3 right-3 p-2 bg-white/80 dark:bg-zinc-900/80 backdrop-blur-md text-zinc-700 dark:text-zinc-300 hover:text-red-600 transition-colors"
                        title="Add to Favourites"
                      >
                        <Heart className={`w-4 h-4 ${isFav ? 'fill-red-600 text-red-600' : ''}`} />
                      </button>

                      {/* Popular / Prep Tag */}
                      <div className="absolute bottom-3 left-3 flex items-center gap-2">
                        {item.isPopular && (
                          <span className="px-2 py-0.5 bg-[#004225] text-white text-[10px] font-mono tracking-wider uppercase font-semibold">
                            POPULAR
                          </span>
                        )}
                        <span className="px-2 py-0.5 bg-zinc-900/80 text-white text-[10px] font-mono tracking-wider">
                          {item.prepTimeMinutes} MIN PREP
                        </span>
                      </div>
                    </div>

                    {/* Card Body */}
                    <div className="p-6 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <h3
                          onClick={() => setInspectItem(item)}
                          className="text-lg font-bold font-serif text-zinc-900 dark:text-zinc-50 cursor-pointer hover:text-[#004225] dark:hover:text-emerald-400 transition-colors"
                        >
                          {item.name}
                        </h3>
                        <span className="text-base font-bold font-mono text-zinc-900 dark:text-zinc-100 tabular-nums shrink-0">
                          £{item.price.toFixed(2)}
                        </span>
                      </div>

                      <p className="text-xs text-zinc-600 dark:text-zinc-400 font-sans line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Unboxed Metadata list */}
                      <div className="pt-2 text-[11px] font-mono text-zinc-500 dark:text-zinc-400 flex flex-wrap items-center gap-1.5">
                        {item.dietary.isVegetarian && <span>Vegetarian</span>}
                        {item.dietary.isVegetarian && <span aria-hidden="true">·</span>}
                        {item.dietary.isGlutenFree && <span>Gluten-Free</span>}
                        {item.dietary.isGlutenFree && <span aria-hidden="true">·</span>}
                        <span>{item.nutrition.calories} kcal</span>
                      </div>
                    </div>
                  </div>

                  {/* Card Actions Footer */}
                  <div className="px-6 pb-6 pt-2 flex items-center gap-3">
                    <button
                      onClick={() => setInspectItem(item)}
                      className="flex-1 py-2 px-3 border border-zinc-300 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200 hover:bg-zinc-100 dark:hover:bg-zinc-800 text-xs font-mono uppercase tracking-wider transition-colors text-center"
                    >
                      CUSTOMISE
                    </button>

                    <button
                      onClick={() => addToBasket(item, 1, [])}
                      className="py-2 px-4 bg-[#004225] dark:bg-[#006B3C] text-white hover:bg-[#00331C] text-xs font-mono uppercase font-semibold tracking-wider transition-colors flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>ADD</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
