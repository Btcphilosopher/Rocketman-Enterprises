'use client';

import React from 'react';

export const StorySection: React.FC = () => {
  return (
    <section id="story" className="w-full py-16 sm:py-24 border-b border-zinc-200 dark:border-zinc-800 bg-[#FAF9F5] dark:bg-[#111315]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12 text-zinc-900 dark:text-zinc-100">
        
        {/* Header */}
        <div className="space-y-4 text-center">
          <div className="text-xs font-mono uppercase tracking-widest text-[#004225] dark:text-emerald-400">
            04. BRAND PHILOSOPHY
          </div>
          <h2 className="text-4xl sm:text-6xl font-bold font-serif tracking-tight">
            BRITAIN, COOKED DAILY.
          </h2>
          <div className="w-16 h-[2px] bg-[#004225] dark:bg-emerald-400 mx-auto" />
        </div>

        {/* Editorial Body Text */}
        <div className="space-y-6 text-base sm:text-lg font-sans text-zinc-700 dark:text-zinc-300 font-light leading-relaxed">
          <p className="first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:float-left first-letter:mr-3 first-letter:text-[#004225] dark:first-letter:text-emerald-400">
            Britain has always had a practical relationship with food. The Anglo idea is simple: take that practicality seriously, cook it well, and build a modern system around it.
          </p>

          <p>
            For generations, British takeaway has been treated as a guilty compromise — late-night food wrapped in soggy foil, unpredictable waiting times, and anonymous ingredients. We believe British takeaway deserves better engineering.
          </p>

          <blockquote className="my-8 p-6 border-l-2 border-[#004225] dark:border-emerald-400 bg-white dark:bg-zinc-900 font-serif text-xl sm:text-2xl italic text-zinc-900 dark:text-zinc-50">
            &ldquo;We don&apos;t need complex fussiness or foreign concepts to eat well. We need superb British ingredients, crisp roasting, hot gravy, and a logistics network that respects your time.&rdquo;
          </blockquote>

          <p>
            From our central Bermondsey kitchen in London to Kelham Island in Sheffield and Ancoats in Manchester, every Anglo Kitchen operates on identical principles: Norfolk free-range chickens, Aberdeen Angus beef aged for 28 days, Maris Piper potatoes triple-cooked in fresh oil, and bread baked every morning.
          </p>

          <p>
            Dinner, properly done. Britain, cooked daily.
          </p>
        </div>

        {/* Editorial Signature */}
        <div className="pt-8 border-t border-zinc-300 dark:border-zinc-800 flex items-center justify-between font-mono text-xs text-zinc-500">
          <div>ANGLO FOOD CO. EDITORIAL DIRECTORY</div>
          <div>EST. LONDON 2026</div>
        </div>

      </div>
    </section>
  );
};
