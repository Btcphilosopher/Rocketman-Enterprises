export enum ProductStatus {
  Draft = "Draft",
  Published = "Published",
  Hidden = "Hidden",
  OutOfStock = "Out of Stock",
  Archived = "Archived",
  Scheduled = "Scheduled",
  Duplicate = "Duplicate",
  Relist = "Relist"
}

export interface BulkPriceRule {
  quantity: number;
  price: number;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  manufacturer: string;
  compatiblePrinters: string[];
  cartridgeNumber: string;
  oemReference: string;
  color: "Black" | "Cyan" | "Magenta" | "Yellow" | "Multi" | "None";
  capacity: string; // e.g., "18ml", "2400 pages", "120g"
  estimatedPageYield: number;
  costPerPage: number;
  images: string[];
  description: string;
  installationGuide: string;
  pdfDocumentationUrl?: string;
  videoUrl?: string;
  stockQuantity: number;
  price: number;
  salePrice?: number;
  bulkPricing?: BulkPriceRule[];
  status: ProductStatus;
  category: "Ink Cartridge" | "Toner" | "Refill Kit" | "Office Supplies";
  isCompatible: boolean; // Compatible vs OEM
  isXL: boolean;
  isMultipack: boolean;
  rating: number;
  reviewsCount: number;
}

export interface PrinterModel {
  id: string;
  manufacturer: string;
  model: string;
  productNumber: string;
  cartridgeNumber: string;
  tonerNumber: string;
  barcode: string;
  imageUrl?: string;
}

export enum OrderStatus {
  AwaitingPayment = "Awaiting Payment",
  Paid = "Paid",
  Picking = "Picking",
  Packing = "Packing",
  Shipped = "Shipped",
  Delivered = "Delivered",
  Refunded = "Refunded",
  Cancelled = "Cancelled",
  Archived = "Archived"
}

export interface OrderItem {
  productId: string;
  name: string;
  sku: string;
  quantity: number;
  price: number;
}

export interface Order {
  id: string;
  orderReference: string;
  timestamp: string;
  customerName: string;
  customerEmail: string;
  shippingAddress: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  billingAddress?: {
    street: string;
    city: string;
    state: string;
    postalCode: string;
    country: string;
  };
  businessVat?: string;
  items: OrderItem[];
  subtotal: number;
  shippingCost: number;
  discountCode?: string;
  discountAmount?: number;
  total: number;
  status: OrderStatus;
  paymentMethod: "Card" | "BTC" | "USDT";
  paymentDetails?: {
    cryptoAddress?: string;
    cryptoAmount?: number;
    cryptoRate?: number; // USD per BTC/USDT
    network?: string; // e.g. TRC20, ERC20, BTC Mainnet
    txId?: string;
    confirmations?: number;
    countdown?: number; // in seconds
  };
}

export interface BusinessAccount {
  id: string;
  companyName: string;
  vatNumber: string;
  contactEmail: string;
  creditLimit: number;
  creditUsed: number;
  volumeDiscountRate: number; // e.g., 0.15 for 15%
  users: Array<{ name: string; email: string; role: "Admin" | "Buyer" }>;
  purchaseOrders: string[];
  monthlyStatements: Array<{ month: string; amount: number; paid: boolean }>;
}

export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  action: string;
  details: string;
}
