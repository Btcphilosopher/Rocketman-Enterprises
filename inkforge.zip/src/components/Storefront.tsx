import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Search, Printer, Shield, ChevronRight, ShoppingCart, Heart, 
  ArrowRight, Landmark, GraduationCap, Coins, Mail, Info, Check, 
  Clock, AlertCircle, Copy, HelpCircle, FileText, Play, ChevronDown, RefreshCw
} from "lucide-react";
import { Product, ProductStatus, PrinterModel, Order, OrderStatus } from "../types";
import { PRINTER_BRANDS } from "../data";

interface StorefrontProps {
  products: Product[];
  printers: PrinterModel[];
  onOrderCreated: (order: Order) => void;
  orders: Order[];
  onRegisterBusiness: (companyName: string, email: string, vat: string) => void;
}

export default function Storefront({ 
  products, 
  printers, 
  onOrderCreated, 
  orders,
  onRegisterBusiness 
}: StorefrontProps) {
  // Navigation & Sub-views
  const [currentTab, setCurrentTab] = useState<"home" | "shop" | "finder" | "business" | "faq" | "about">("home");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedManufacturer, setSelectedManufacturer] = useState<string>("All");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  
  // Cart State
  const [cart, setCart] = useState<Array<{ product: Product; quantity: number }>>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<"cart" | "shipping" | "crypto" | "success">("cart");
  
  // Checkout Form State
  const [customerName, setCustomerName] = useState("");
  const [customerEmail, setCustomerEmail] = useState("");
  const [shippingStreet, setShippingStreet] = useState("");
  const [shippingCity, setShippingCity] = useState("");
  const [shippingState, setShippingState] = useState("");
  const [shippingZip, setShippingZip] = useState("");
  const [businessVat, setBusinessVat] = useState("");
  const [discountCode, setDiscountCode] = useState("");
  const [appliedDiscount, setAppliedDiscount] = useState(0);
  const [selectedPayment, setSelectedPayment] = useState<"Card" | "BTC" | "USDT">("Card");
  const [selectedNetwork, setSelectedNetwork] = useState("TRC20 (Tron)");
  const [latestCreatedOrder, setLatestCreatedOrder] = useState<Order | null>(null);
  
  // Printer Finder State
  const [finderMake, setFinderMake] = useState("");
  const [finderModelQuery, setFinderModelQuery] = useState("");
  const [selectedPrinter, setSelectedPrinter] = useState<PrinterModel | null>(null);
  const [finderActive, setFinderActive] = useState(false);

  // Business signup state
  const [busCompany, setBusCompany] = useState("");
  const [busEmail, setBusEmail] = useState("");
  const [busVat, setBusVat] = useState("");
  const [busSubmitted, setBusSubmitted] = useState(false);

  // Wishlist state
  const [wishlist, setWishlist] = useState<string[]>([]);
  
  // Copy feedback
  const [copiedText, setCopiedText] = useState(false);

  // Trigger low stock simulation alert
  const [lowStockAlerts, setLowStockAlerts] = useState<string[]>([]);

  // Local storage loading for wishlist
  useEffect(() => {
    const saved = localStorage.getItem("inkforge_wishlist");
    if (saved) setWishlist(JSON.parse(saved));
  }, []);

  const toggleWishlist = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    let updated = [...wishlist];
    if (updated.includes(id)) {
      updated = updated.filter(i => i !== id);
    } else {
      updated.push(id);
    }
    setWishlist(updated);
    localStorage.setItem("inkforge_wishlist", JSON.stringify(updated));
  };

  // Active Printer Selection Filtering
  const getFilteredProducts = () => {
    let list = [...products].filter(p => p.status === ProductStatus.Published);

    if (selectedPrinter) {
      // Filter by printer model compatibility
      list = list.filter(p => 
        p.compatiblePrinters.some(cp => cp.toLowerCase().includes(selectedPrinter.model.toLowerCase())) ||
        p.cartridgeNumber.toLowerCase() === selectedPrinter.cartridgeNumber.toLowerCase() ||
        p.oemReference.toLowerCase() === selectedPrinter.tonerNumber.toLowerCase()
      );
      return list;
    }

    if (selectedCategory !== "All") {
      list = list.filter(p => p.category === selectedCategory);
    }
    if (selectedManufacturer !== "All") {
      list = list.filter(p => p.manufacturer.toLowerCase() === selectedManufacturer.toLowerCase());
    }
    if (searchQuery.trim() !== "") {
      const q = searchQuery.toLowerCase();
      list = list.filter(p => 
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.cartridgeNumber.toLowerCase().includes(q) ||
        p.oemReference.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }
    return list;
  };

  const currentProducts = getFilteredProducts();

  // Cart operations
  const addToCart = (product: Product, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    
    // Check if item in stock
    if (product.stockQuantity <= 0) {
      alert("Item is out of stock.");
      return;
    }

    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      setCart(cart.map(item => 
        item.product.id === product.id 
          ? { ...item, quantity: Math.min(product.stockQuantity, item.quantity + 1) }
          : item
      ));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
    setIsCartOpen(true);
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(cart.map(item => {
      if (item.product.id === productId) {
        const nextQty = item.quantity + delta;
        if (nextQty <= 0) return null;
        return { ...item, quantity: Math.min(item.product.stockQuantity, nextQty) };
      }
      return item;
    }).filter(Boolean) as any);
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.product.id !== productId));
  };

  const getCartSubtotal = () => {
    return cart.reduce((sum, item) => {
      const price = item.product.salePrice || item.product.price;
      return sum + (price * item.quantity);
    }, 0);
  };

  const getCartTotal = () => {
    const sub = getCartSubtotal();
    const discount = sub * appliedDiscount;
    const shipping = sub >= 50 || sub === 0 ? 0 : 4.99;
    return parseFloat((sub - discount + shipping).toFixed(2));
  };

  const applyPromoCode = () => {
    if (discountCode.toUpperCase() === "FORGE10") {
      setAppliedDiscount(0.1);
    } else {
      alert("Invalid promotional code.");
    }
  };

  // Checkout process
  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    const payload = {
      customerName,
      customerEmail,
      shippingAddress: {
        street: shippingStreet,
        city: shippingCity,
        state: shippingState,
        postalCode: shippingZip,
        country: "United States"
      },
      items: cart.map(item => ({
        productId: item.product.id,
        quantity: item.quantity,
        price: item.product.salePrice || item.product.price
      })),
      paymentMethod: selectedPayment,
      paymentNetwork: selectedNetwork,
      businessVat: businessVat || undefined,
      discountCode: appliedDiscount > 0 ? "FORGE10" : undefined
    };

    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const order: Order = await res.json();
        onOrderCreated(order);
        setLatestCreatedOrder(order);
        setCart([]);
        setCheckoutStep("crypto");
      } else {
        const err = await res.json();
        alert(`Checkout failed: ${err.error}`);
      }
    } catch (err) {
      console.error(err);
      alert("Error submitting checkout. Please verify connection.");
    }
  };

  // Real-time payment detection trigger
  const [confirmations, setConfirmations] = useState(0);
  const [txDetected, setTxDetected] = useState(false);
  const [paymentTimeRemaining, setPaymentTimeRemaining] = useState(900);
  const [isVerifying, setIsVerifying] = useState(false);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (checkoutStep === "crypto" && latestCreatedOrder && (latestCreatedOrder.paymentMethod !== "Card")) {
      setPaymentTimeRemaining(900);
      setConfirmations(0);
      setTxDetected(false);

      timer = setInterval(() => {
        setPaymentTimeRemaining(prev => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [checkoutStep, latestCreatedOrder]);

  const triggerBlockchainSim = async () => {
    if (!latestCreatedOrder) return;
    setIsVerifying(true);
    
    try {
      // Calls server API to check blocks
      const res = await fetch("/api/blockchain-check");
      if (res.ok) {
        setTxDetected(true);
        setConfirmations(prev => {
          const next = Math.min(6, prev + Math.floor(Math.random() * 2) + 1);
          if (next >= 4) {
            setCheckoutStep("success");
          }
          return next;
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsVerifying(false);
    }
  };

  const copyAddress = (address: string) => {
    navigator.clipboard.writeText(address);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  // Handles custom printer finder matches
  const handlePrinterSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanModel = finderModelQuery.toLowerCase().trim();
    if (!cleanModel) return;

    const matched = printers.find(p => 
      p.model.toLowerCase().includes(cleanModel) || 
      p.productNumber.toLowerCase().includes(cleanModel) ||
      p.cartridgeNumber.toLowerCase().includes(cleanModel) ||
      p.tonerNumber.toLowerCase().includes(cleanModel) ||
      p.barcode.includes(cleanModel)
    );

    if (matched) {
      setSelectedPrinter(matched);
      setFinderActive(true);
      setCurrentTab("shop");
    } else {
      alert("No exact printer match found. Try entering 'M404dn' or 'TS6350a'.");
    }
  };

  return (
    <div class="min-h-screen bg-[#fafafa] selection:bg-neutral-900 selection:text-white">
      {/* Brand Header */}
      <header class="sticky top-0 z-40 bg-[#FAFAFA]/95 backdrop-blur-md border-b border-zinc-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div class="flex items-center gap-8">
            <button 
              onClick={() => { setCurrentTab("home"); setSelectedPrinter(null); setFinderActive(false); }}
              class="text-xl font-bold tracking-tighter uppercase text-zinc-950 flex items-center gap-2"
            >
              Ink<span class="text-zinc-400 font-light italic">Forge</span>
            </button>
            <nav class="hidden md:flex items-center gap-8 text-[11px] font-medium tracking-[0.1em] uppercase text-zinc-500">
              <button 
                onClick={() => { setCurrentTab("shop"); setSelectedPrinter(null); setFinderActive(false); }} 
                class={`hover:text-zinc-950 transition-colors py-1 ${currentTab === "shop" ? "text-zinc-950 font-bold border-b border-zinc-950" : ""}`}
              >
                Storefront
              </button>
              <button 
                onClick={() => { setCurrentTab("finder"); }} 
                class={`hover:text-zinc-950 transition-colors py-1 ${currentTab === "finder" ? "text-zinc-950 font-bold border-b border-zinc-950" : ""}`}
              >
                Printer Finder
              </button>
              <button 
                onClick={() => { setCurrentTab("business"); }} 
                class={`hover:text-zinc-950 transition-colors py-1 ${currentTab === "business" ? "text-zinc-950 font-bold border-b border-zinc-950" : ""}`}
              >
                Wholesale & Education
              </button>
              <button 
                onClick={() => { setCurrentTab("faq"); }} 
                class={`hover:text-zinc-950 transition-colors py-1 ${currentTab === "faq" ? "text-zinc-950 font-bold border-b border-zinc-950" : ""}`}
              >
                Support / FAQ
              </button>
            </nav>
          </div>

          <div class="flex items-center gap-6">
            {wishlist.length > 0 && (
              <button 
                onClick={() => { setCurrentTab("shop"); setSelectedCategory("All"); setSearchQuery(""); setSelectedManufacturer("All"); }}
                class="hidden sm:flex items-center gap-1.5 px-3 py-1.5 border border-zinc-100 rounded-md text-xs font-mono font-medium hover:bg-zinc-50"
              >
                <Heart class="w-3.5 h-3.5 text-black fill-black" />
                Wishlist ({wishlist.length})
              </button>
            )}
            <button 
              onClick={() => setIsCartOpen(true)}
              class="relative p-2.5 hover:bg-zinc-100 rounded-md transition-colors"
            >
              <ShoppingCart class="w-5 h-5 text-zinc-900" />
              {cart.length > 0 && (
                <span class="absolute -top-1 -right-1 bg-black text-white text-[10px] font-mono font-bold w-5 h-5 flex items-center justify-center rounded-full border-2 border-[#FAFAFA]">
                  {cart.reduce((s, i) => s + i.quantity, 0)}
                </span>
              )}
            </button>
            <div class="w-8 h-8 rounded-full border border-zinc-200 flex items-center justify-center">
              <div class="w-2 h-2 bg-black rounded-full animate-pulse"></div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Areas */}
      <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in">
        
        {/* Dynamic Header Badge for selected printer filtering */}
        {selectedPrinter && (
          <div class="mb-6 p-4 bg-zinc-950 text-white rounded-md flex items-center justify-between gap-4">
            <div class="flex items-center gap-3">
              <Printer class="w-5 h-5 text-zinc-300" />
              <div>
                <p class="text-xs font-mono text-zinc-400">FILTERING FOR ACTIVE DEVICE</p>
                <p class="text-sm font-semibold tracking-tight">{selectedPrinter.manufacturer} {selectedPrinter.model}</p>
              </div>
            </div>
            <button 
              onClick={() => { setSelectedPrinter(null); setFinderActive(false); }}
              class="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 rounded-sm text-xs font-mono text-zinc-200 transition-colors"
            >
              Show All Products
            </button>
          </div>
        )}

        {currentTab === "home" && (
          <div class="space-y-16">
            {/* Architectural Hero Banner with Split Columns */}
            <div class="grid grid-cols-1 lg:grid-cols-12 border border-zinc-200 bg-white rounded-lg overflow-hidden min-h-[600px] shadow-sm">
              <div class="lg:col-span-7 flex flex-col justify-center p-8 sm:p-12 lg:p-16 border-r border-zinc-100 bg-[#FAFAFA]">
                <div class="mb-4 self-start px-3 py-1 bg-black text-white text-[9px] font-bold tracking-[0.2em] uppercase rounded-full">
                  Production Grade
                </div>
                <h1 class="font-display text-[40px] sm:text-[56px] lg:text-[72px] leading-[0.95] font-light tracking-tight text-zinc-950 mb-6">
                  Precision for<br/><span class="font-medium italic text-zinc-500">Infrastructure.</span>
                </h1>
                <p class="text-sm sm:text-base text-zinc-500 max-w-md leading-relaxed mb-4">
                  Direct-to-consumer enterprise ink distribution. Self-hosted logistics, high-performance compatibility, and cryptographically secured payments.
                </p>

                {/* Intelligent Printer Finder */}
                <div class="relative max-w-xl mt-8">
                  <div class="absolute -top-3 left-6 px-2 bg-[#FAFAFA] text-[10px] font-bold uppercase text-zinc-400 tracking-widest z-10">
                    Intelligent Printer Finder
                  </div>
                  <div class="flex flex-col sm:flex-row border border-black p-1 bg-white items-center gap-1 shadow-sm">
                    <div class="relative flex-1 w-full">
                      <input 
                        type="text" 
                        placeholder="Enter model number (e.g. M404, TS6350)..."
                        value={finderModelQuery}
                        onChange={(e) => setFinderModelQuery(e.target.value)}
                        class="w-full bg-transparent px-4 py-3 text-sm outline-none placeholder:text-zinc-300 font-mono text-zinc-950"
                      />
                    </div>
                    <div class="w-full sm:w-44 border-t sm:border-t-0 sm:border-l border-zinc-200">
                      <select 
                        value={finderMake} 
                        onChange={(e) => setFinderMake(e.target.value)}
                        class="w-full bg-transparent px-3 py-3 text-xs font-mono outline-none text-zinc-600 appearance-none cursor-pointer"
                      >
                        <option value="">Any Brand</option>
                        {PRINTER_BRANDS.map(b => (
                          <option key={b} value={b}>{b}</option>
                        ))}
                      </select>
                    </div>
                    <button 
                      onClick={handlePrinterSearch}
                      class="w-full sm:w-auto bg-black text-white px-6 py-3.5 text-[11px] font-bold uppercase tracking-widest hover:bg-zinc-900 transition-colors shrink-0"
                    >
                      Execute
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Illustration Column */}
              <div class="lg:col-span-5 relative flex flex-col justify-between bg-white min-h-[400px]">
                <div class="flex-1 flex items-center justify-center p-8 sm:p-12">
                  <div class="relative w-full max-w-[280px] aspect-square border-[0.5px] border-zinc-200 rounded-full flex items-center justify-center">
                    <div class="w-[80%] h-[80%] border-[0.5px] border-zinc-100 rounded-full flex items-center justify-center">
                      <div class="w-36 h-48 bg-[#FAFAFA] border border-zinc-200 flex flex-col p-3 shadow-lg rotate-6 transition-transform hover:rotate-0 duration-300">
                         <div class="h-1 w-full bg-zinc-300 mb-2"></div>
                         <div class="h-28 w-full bg-white mb-2 flex items-center justify-center overflow-hidden border border-zinc-100">
                            <div class="w-8 h-8 bg-black rounded-sm flex items-center justify-center text-white text-[10px] font-bold">IF</div>
                         </div>
                         <div class="text-[9px] font-mono text-zinc-400">SKU: IF-901-BK</div>
                         <div class="text-[11px] font-bold mt-0.5 text-zinc-950 uppercase tracking-tight">BLACK TONER</div>
                      </div>
                    </div>
                    <div class="absolute top-4 right-4 bg-white p-3 border border-zinc-100 shadow-sm rounded-sm">
                      <div class="text-[8px] font-bold uppercase text-zinc-400 tracking-wider">In Stock</div>
                      <div class="text-xl font-light text-zinc-950">1,204 <span class="text-xs text-zinc-400 font-normal">units</span></div>
                    </div>
                  </div>
                </div>

                <div class="border-t border-zinc-100 p-6 flex items-end justify-between text-zinc-600 bg-[#FAFAFA]">
                  <div>
                    <div class="text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-1.5">Payment Support</div>
                    <div class="flex gap-2.5 text-[10px] font-mono">
                      <span>₿ BTC</span>
                      <span class="text-zinc-300">/</span>
                      <span>₮ USDT</span>
                      <span class="text-zinc-300">/</span>
                      <span>FIAT</span>
                    </div>
                  </div>
                  <div class="text-right">
                     <div class="text-[8px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Delivery Protocol</div>
                     <div class="flex items-center gap-1.5 justify-end">
                       <div class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></div>
                       <span class="text-[11px] font-medium text-zinc-800">Next Day Dispatched</span>
                     </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Popular Manufacturers Grid */}
            <div class="space-y-6">
              <div class="flex items-end justify-between border-b border-zinc-200 pb-4">
                <div>
                  <p class="text-xs font-mono font-bold tracking-widest text-zinc-400 uppercase">CALIBRATED OEM CHANNELS</p>
                  <h2 class="font-display text-2xl font-bold tracking-tight text-zinc-900">Supported Printer Platforms</h2>
                </div>
                <button onClick={() => { setCurrentTab("shop"); setSelectedCategory("All"); }} class="text-xs font-mono hover:underline flex items-center gap-1 font-semibold text-zinc-800">
                  Browse Catalog
                  <ChevronRight class="w-4 h-4" />
                </button>
              </div>
              <div class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                {PRINTER_BRANDS.map(brand => (
                  <button 
                    key={brand}
                    onClick={() => { setSelectedManufacturer(brand); setCurrentTab("shop"); }}
                    class="p-6 bg-white border border-zinc-200 rounded-md text-center hover:border-zinc-950 transition-all duration-200 group"
                  >
                    <p class="font-display text-lg font-bold tracking-tight text-zinc-800 group-hover:text-zinc-950">{brand}</p>
                    <p class="text-[10px] font-mono text-zinc-400 mt-1">Compatibles Available</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Featured Products Showcase */}
            <div class="space-y-6">
              <div class="flex items-end justify-between border-b border-zinc-200 pb-4">
                <div>
                  <p class="text-xs font-mono font-bold tracking-widest text-zinc-400 uppercase">POPULAR OFFERS</p>
                  <h2 class="font-display text-2xl font-bold tracking-tight text-zinc-900">High-Yield Compatible Ranges</h2>
                </div>
                <div class="flex gap-2">
                  {["All", "Toner", "Ink Cartridge", "Refill Kit"].map(cat => (
                    <button 
                      key={cat}
                      onClick={() => { setSelectedCategory(cat === "All" ? "All" : cat); setCurrentTab("shop"); }}
                      class="px-3 py-1 border border-zinc-200 hover:border-zinc-900 text-xs font-mono rounded-md transition-all text-zinc-600 hover:text-zinc-950"
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {products.slice(0, 4).map(product => {
                  const hasDiscount = product.salePrice && product.salePrice < product.price;
                  return (
                    <div 
                      key={product.id}
                      onClick={() => setSelectedProduct(product)}
                      class="group bg-white border border-zinc-200 rounded-lg overflow-hidden hover:border-zinc-900 transition-all cursor-pointer flex flex-col justify-between"
                    >
                      <div class="relative bg-zinc-50 p-6 aspect-square flex items-center justify-center border-b border-zinc-100">
                        <img 
                          src={product.images[0]} 
                          alt={product.name}
                          class="max-h-40 object-contain group-hover:scale-105 transition-transform duration-300"
                        />
                        <button 
                          onClick={(e) => toggleWishlist(product.id, e)}
                          class="absolute top-3 right-3 p-2 bg-white/90 backdrop-blur-sm hover:bg-white border border-zinc-200 rounded-full transition-colors"
                        >
                          <Heart class={`w-4 h-4 ${wishlist.includes(product.id) ? "text-rose-500 fill-rose-500" : "text-zinc-400"}`} />
                        </button>
                        <span class={`absolute bottom-3 left-3 text-[9px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-sm ${product.isCompatible ? "bg-zinc-950 text-white" : "bg-amber-100 text-amber-900 border border-amber-200"}`}>
                          {product.isCompatible ? "COMPATIBLE" : "OEM ORIGINAL"}
                        </span>
                      </div>

                      <div class="p-5 flex-1 flex flex-col justify-between space-y-4">
                        <div class="space-y-1">
                          <p class="text-[10px] font-mono text-zinc-400">{product.sku}</p>
                          <h3 class="font-display font-bold text-sm text-zinc-900 group-hover:text-zinc-950 line-clamp-2">{product.name}</h3>
                        </div>

                        <div class="space-y-3">
                          <div class="grid grid-cols-2 gap-1 text-[10px] font-mono text-zinc-500">
                            <div>Yield: <span class="font-semibold text-zinc-800">{product.estimatedPageYield.toLocaleString()} pgs</span></div>
                            <div>Cost/Pg: <span class="font-semibold text-zinc-800">${product.costPerPage.toFixed(4)}</span></div>
                          </div>

                          <div class="flex items-baseline justify-between pt-1">
                            <div class="flex items-center gap-2">
                              {hasDiscount ? (
                                <>
                                  <span class="text-base font-mono font-bold text-zinc-950">${product.salePrice}</span>
                                  <span class="text-xs font-mono line-through text-zinc-400">${product.price}</span>
                                </>
                              ) : (
                                <span class="text-base font-mono font-bold text-zinc-950">${product.price}</span>
                              )}
                            </div>
                            <button 
                              onClick={(e) => addToCart(product, e)}
                              class="p-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-md transition-colors"
                            >
                              <ShoppingCart class="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Cryptocurrencies & Business Trust Section */}
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* BTC & USDT Accept Banner */}
              <div class="p-8 bg-zinc-950 text-white rounded-lg flex flex-col justify-between border border-zinc-900 relative overflow-hidden shadow-sm">
                <div class="space-y-4 max-w-md relative z-10">
                  <div class="flex items-center gap-2 text-zinc-400 text-xs font-mono">
                    <Coins class="w-4 h-4 text-emerald-400" />
                    DECENTRALIZED ENTERPRISE SETTLEMENT
                  </div>
                  <h3 class="font-display text-2xl font-bold tracking-tight">Decentralized Payments</h3>
                  <p class="text-sm text-zinc-400 font-light leading-relaxed">
                    Settle invoices natively in Bitcoin (BTC) or Tether (USDT TRC20/ERC20) with automated node verification. Zero checkout friction, zero credit card processor fees.
                  </p>
                </div>
                <div class="flex gap-4 mt-6 relative z-10">
                  <div class="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-sm text-xs font-mono text-zinc-300 flex items-center gap-1.5">
                    <span>₿</span> Bitcoin Accepted
                  </div>
                  <div class="px-3 py-1.5 bg-zinc-900 border border-zinc-800 rounded-sm text-xs font-mono text-zinc-300 flex items-center gap-1.5">
                    <span>₮</span> Tether USDT
                  </div>
                </div>
              </div>

              {/* Business Account Promo */}
              <div class="p-8 bg-white border border-zinc-100 rounded-lg flex flex-col justify-between shadow-sm">
                <div class="space-y-4">
                  <div class="flex items-center gap-2 text-zinc-500 text-xs font-mono">
                    <Landmark class="w-4 h-4 text-zinc-800" />
                    BUSINESS DECK PRO
                  </div>
                  <h3 class="font-display text-2xl font-bold tracking-tight text-zinc-900">Corporate & Education Accounts</h3>
                  <p class="text-sm text-zinc-600 font-light leading-relaxed">
                    Unlock professional ERP privileges: 15% flat volume discounts, flexible purchase order billing (Net 30/60 days), custom multi-user provisioning, and dedicated monthly statements.
                  </p>
                </div>
                <button 
                  onClick={() => setCurrentTab("business")}
                  class="mt-6 self-start px-4 py-2 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-mono tracking-wider uppercase rounded-md transition-colors flex items-center gap-1.5"
                >
                  Configure Business Desk
                  <ArrowRight class="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Sustainability section & Reviews */}
            <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-6">
              <div class="lg:col-span-4 space-y-4">
                <p class="text-xs font-mono font-bold text-zinc-400 uppercase tracking-widest">ECO CORE SYSTEMS</p>
                <h3 class="font-display text-xl font-bold tracking-tight text-zinc-900">Sustainably Engineered</h3>
                <p class="text-sm text-zinc-600 font-light leading-relaxed">
                  By refilling existing cartridge frames or manufacturing ultra-precise compatible cartridges, InkForge diverts valuable electronic polymer waste from landfills. Save costs, save ecology.
                </p>
                <div class="pt-2 text-xs font-mono text-zinc-500 flex items-center gap-1.5">
                  <Shield class="w-4 h-4 text-emerald-500" />
                  ISO 14001 Ecological Certified
                </div>
              </div>

              <div class="lg:col-span-8 space-y-6">
                <p class="text-xs font-mono font-bold text-zinc-400 uppercase tracking-widest">VERIFIED CLIENT REVIEWS</p>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div class="p-5 bg-white border border-zinc-100 rounded-md space-y-3 shadow-sm">
                    <p class="text-xs text-zinc-600 font-light italic leading-relaxed">"The page yield on the compatible 59X is incredible. Got 10,240 pages on our warehouse shipping printer before seeing a low toner indicator."</p>
                    <div>
                      <p class="text-xs font-bold text-zinc-900">Nathaniel Vance</p>
                      <p class="text-[10px] font-mono text-zinc-400">Logistics Director</p>
                    </div>
                  </div>
                  <div class="p-5 bg-white border border-zinc-100 rounded-md space-y-3 shadow-sm">
                    <p class="text-xs text-zinc-600 font-light italic leading-relaxed">"Excellent color matching for photo portfolios. Canon compatible tanks worked flawlessly, saving us almost 60%."</p>
                    <div>
                      <p class="text-xs font-bold text-zinc-900">Dr. Amanda Albright</p>
                      <p class="text-[10px] font-mono text-zinc-400">Creative Media Studio</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Newsletter section */}
            <div class="bg-[#FAFAFA] p-8 rounded-lg flex flex-col md:flex-row items-center justify-between gap-6 border border-zinc-200">
              <div class="space-y-1">
                <h4 class="font-display text-lg font-bold text-zinc-950">Receive Inventory & Discount Updates</h4>
                <p class="text-xs text-zinc-500">No spam. Only high-precision product drops and technical inventory discount alerts.</p>
              </div>
              <div class="flex w-full md:w-auto max-w-sm gap-2">
                <input 
                  type="email" 
                  placeholder="Enter email address" 
                  class="bg-white border border-zinc-200 px-3 py-2 text-xs font-mono rounded-md w-full focus:outline-none focus:border-zinc-900"
                />
                <button 
                  onClick={() => alert("Subscribed! Thank you for trusting InkForge.")}
                  class="bg-black text-white px-5 py-2 text-[11px] font-mono rounded hover:bg-zinc-800 transition-colors uppercase tracking-widest font-bold"
                >
                  Join
                </button>
              </div>
            </div>
          </div>
        )}

        {/* SHOP VIEW */}
        {currentTab === "shop" && (
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Sidebar Filters */}
            <div class="lg:col-span-3 space-y-6">
              <div class="space-y-4">
                <h3 class="text-xs font-mono font-bold tracking-widest text-zinc-400 uppercase">SYSTEM FILTERS</h3>
                
                {/* Search Bar */}
                <div class="relative">
                  <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  <input 
                    type="text" 
                    placeholder="Search SKU or name..." 
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    class="w-full pl-9 pr-3 py-2 border border-zinc-200 rounded-md text-xs font-mono focus:outline-none focus:border-zinc-900"
                  />
                </div>
              </div>

              {/* Categories */}
              <div class="space-y-2 border-t border-zinc-200 pt-4">
                <h4 class="text-xs font-bold text-zinc-900">Consumable Category</h4>
                <div class="space-y-1">
                  {["All", "Ink Cartridge", "Toner", "Refill Kit", "Office Supplies"].map(cat => (
                    <button 
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      class={`w-full text-left px-2 py-1.5 text-xs rounded-sm transition-colors font-mono flex items-center justify-between ${selectedCategory === cat ? "bg-zinc-950 text-white" : "hover:bg-zinc-100 text-zinc-600"}`}
                    >
                      <span>{cat}</span>
                      <span class="text-[10px] opacity-75">
                        ({products.filter(p => cat === "All" ? p.status === ProductStatus.Published : p.category === cat && p.status === ProductStatus.Published).length})
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Manufacturers */}
              <div class="space-y-2 border-t border-zinc-200 pt-4">
                <h4 class="text-xs font-bold text-zinc-900">OEM Manufacturers</h4>
                <div class="space-y-1">
                  {["All", ...PRINTER_BRANDS, "Universal"].map(m => (
                    <button 
                      key={m}
                      onClick={() => setSelectedManufacturer(m)}
                      class={`w-full text-left px-2 py-1.5 text-xs rounded-sm transition-colors font-mono ${selectedManufacturer === m ? "bg-zinc-950 text-white" : "hover:bg-zinc-100 text-zinc-600"}`}
                    >
                      {m}
                    </button>
                  ))}
                </div>
              </div>

              {/* Technical Certs Badge */}
              <div class="p-4 bg-zinc-50 border border-zinc-200 rounded-md space-y-2">
                <div class="flex items-center gap-1.5 text-zinc-900 text-xs font-mono font-bold">
                  <Shield class="w-4 h-4 text-emerald-600" />
                  INKFORGE COMPLIANCE
                </div>
                <p class="text-[11px] text-zinc-500 font-light leading-relaxed">
                  All InkForge cartridges undergo rigid ISO 9001/14001 validation for page yield standard conformity, ensuring flawless density.
                </p>
              </div>
            </div>

            {/* Product Grid Area */}
            <div class="lg:col-span-9 space-y-6">
              <div class="flex items-center justify-between border-b border-zinc-200 pb-4">
                <p class="text-xs font-mono text-zinc-500 font-medium">
                  Showing <span class="font-bold text-zinc-900">{currentProducts.length}</span> high-precision items
                </p>
                <select class="px-2 py-1 border border-zinc-200 rounded-md text-xs font-mono text-zinc-600 focus:outline-none">
                  <option>Page Yield: High to Low</option>
                  <option>Price: Low to High</option>
                  <option>Alphabetical</option>
                </select>
              </div>

              {currentProducts.length === 0 ? (
                <div class="p-16 border border-dashed border-zinc-200 rounded-lg text-center space-y-4">
                  <Printer class="w-12 h-12 text-zinc-300 mx-auto" />
                  <div class="space-y-1">
                    <p class="font-semibold text-zinc-900 text-sm">No Compatible Consumables Found</p>
                    <p class="text-xs text-zinc-500">Adjust filters or search models to locate compatible cartridges.</p>
                  </div>
                  <button 
                    onClick={() => { setSelectedCategory("All"); setSelectedManufacturer("All"); setSearchQuery(""); setSelectedPrinter(null); }}
                    class="px-3.5 py-1.5 bg-zinc-900 text-white text-xs font-mono rounded-md hover:bg-zinc-800"
                  >
                    Reset System Filters
                  </button>
                </div>
              ) : (
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {currentProducts.map(product => {
                    const hasDiscount = product.salePrice && product.salePrice < product.price;
                    return (
                      <div 
                        key={product.id}
                        onClick={() => setSelectedProduct(product)}
                        class="group bg-white border border-zinc-200 rounded-lg overflow-hidden hover:border-zinc-950 transition-all cursor-pointer flex flex-col justify-between"
                      >
                        <div class="relative bg-zinc-50 p-5 aspect-square flex items-center justify-center border-b border-zinc-100">
                          <img 
                            src={product.images[0]} 
                            alt={product.name}
                            class="max-h-36 object-contain group-hover:scale-105 transition-transform duration-300"
                          />
                          <button 
                            onClick={(e) => toggleWishlist(product.id, e)}
                            class="absolute top-3 right-3 p-2 bg-white/90 backdrop-blur-sm hover:bg-white border border-zinc-200 rounded-full transition-colors"
                          >
                            <Heart class={`w-3.5 h-3.5 ${wishlist.includes(product.id) ? "text-rose-500 fill-rose-500" : "text-zinc-400"}`} />
                          </button>
                          <span class={`absolute bottom-3 left-3 text-[9px] font-mono uppercase tracking-wider px-2 py-0.5 rounded-sm ${product.isCompatible ? "bg-zinc-950 text-white" : "bg-amber-100 text-amber-900 border border-amber-200"}`}>
                            {product.isCompatible ? "COMPATIBLE" : "OEM ORIGINAL"}
                          </span>
                        </div>

                        <div class="p-5 flex-1 flex flex-col justify-between space-y-4">
                          <div class="space-y-1">
                            <p class="text-[10px] font-mono text-zinc-400">{product.sku}</p>
                            <h3 class="font-display font-bold text-xs text-zinc-900 group-hover:text-zinc-950 line-clamp-2">{product.name}</h3>
                          </div>

                          <div class="space-y-3">
                            <div class="grid grid-cols-2 gap-1 text-[10px] font-mono text-zinc-500">
                              <div>Yield: <span class="font-semibold text-zinc-800">{product.estimatedPageYield.toLocaleString()} pgs</span></div>
                              <div>Color: <span class="font-semibold text-zinc-800">{product.color}</span></div>
                            </div>

                            <div class="flex items-baseline justify-between pt-1">
                              <div class="flex items-center gap-2">
                                {hasDiscount ? (
                                  <>
                                    <span class="text-sm font-mono font-bold text-zinc-950">${product.salePrice}</span>
                                    <span class="text-[11px] font-mono line-through text-zinc-400">${product.price}</span>
                                  </>
                                ) : (
                                  <span class="text-sm font-mono font-bold text-zinc-950">${product.price}</span>
                                )}
                              </div>
                              <button 
                                onClick={(e) => addToCart(product, e)}
                                class="p-2 bg-zinc-900 hover:bg-zinc-800 text-white rounded-md transition-colors"
                              >
                                <ShoppingCart class="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* PRINTER FINDER TAB */}
        {currentTab === "finder" && (
          <div class="max-w-4xl mx-auto space-y-8 py-4">
            <div class="text-center space-y-2">
              <p class="text-xs font-mono font-bold tracking-widest text-zinc-400 uppercase">INTELLIGENT COMPATIBILITY ENGINE</p>
              <h2 class="font-display text-3xl font-bold tracking-tight text-zinc-950">Locate Your Exact Cartridge Match</h2>
              <p class="text-sm text-zinc-500 max-w-xl mx-auto font-light leading-relaxed">
                Enter your printer manufacturer, model, part number or scanner barcode to instantly pull compatible XL multipacks and calculate optimal cost per page.
              </p>
            </div>

            <div class="p-8 bg-white border border-zinc-200 rounded-lg shadow-sm space-y-6">
              <form onSubmit={handlePrinterSearch} class="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
                <div class="md:col-span-8 space-y-1.5">
                  <label class="text-xs font-mono font-bold text-zinc-500 uppercase tracking-wider block">Printer Model, Barcode or Cartridge Code</label>
                  <div class="relative">
                    <Search class="absolute left-3 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-zinc-400" />
                    <input 
                      type="text" 
                      placeholder="e.g., LaserJet Pro M404dn, TS6350a, TN-2420, CF259X..."
                      value={finderModelQuery}
                      onChange={(e) => setFinderModelQuery(e.target.value)}
                      class="w-full pl-10 pr-3 py-3 border border-zinc-200 rounded-md text-sm font-mono focus:outline-none focus:border-zinc-900"
                    />
                  </div>
                </div>
                <div class="md:col-span-4">
                  <button 
                    type="submit"
                    class="w-full py-3 bg-zinc-950 hover:bg-zinc-900 text-white rounded-md text-xs font-mono uppercase tracking-wider font-semibold transition-all"
                  >
                    Identify Compatibles
                  </button>
                </div>
              </form>

              <div class="pt-4 border-t border-zinc-100">
                <p class="text-[11px] font-mono text-zinc-400 mb-3">POPULAR SEARCH TARGETS</p>
                <div class="flex flex-wrap gap-2">
                  {["HP LaserJet Pro M404dn", "HP OfficeJet Pro 9015e", "Brother HL-L2350DW Compact", "Canon PIXMA TS6350a", "Epson EcoTank ET-2810"].map(target => (
                    <button 
                      key={target}
                      onClick={() => { setFinderModelQuery(target); setSelectedPrinter(null); }}
                      class="px-2.5 py-1.5 bg-zinc-50 hover:bg-zinc-100 border border-zinc-200 rounded-md text-xs font-mono text-zinc-600 hover:text-zinc-900 transition-colors"
                    >
                      {target}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Simulated hardware barcode prompt */}
            <div class="p-6 bg-zinc-50 border border-zinc-200 rounded-lg flex flex-col sm:flex-row items-center gap-4 justify-between">
              <div class="flex items-center gap-3">
                <Printer class="w-6 h-6 text-zinc-400" />
                <div>
                  <p class="text-xs font-mono text-zinc-500 font-medium">BARCODE TELEMETRY</p>
                  <p class="text-xs font-light text-zinc-600">Scan physical box barcode with any USB or Bluetooth scanner directly into search field.</p>
                </div>
              </div>
              <button 
                onClick={() => { setFinderModelQuery("4977766782357"); alert("Injected simulated barcode '4977766782357' (Brother HL-L2350DW)!"); }}
                class="px-3 py-1.5 border border-zinc-300 rounded-md text-xs font-mono hover:bg-white transition-all text-zinc-700"
              >
                Simulate Laser Scanner
              </button>
            </div>
          </div>
        )}

        {/* WHOLESALE & EDUCATION PORTAL */}
        {currentTab === "business" && (
          <div class="max-w-4xl mx-auto space-y-12 py-4">
            <div class="text-center space-y-2">
              <p class="text-xs font-mono font-bold tracking-widest text-zinc-400 uppercase">HIGH VOLUME TELEMETRY</p>
              <h2 class="font-display text-3xl font-bold tracking-tight text-zinc-950">Bulk Procurement Desk</h2>
              <p class="text-sm text-zinc-500 max-w-xl mx-auto font-light leading-relaxed">
                Configure purchasing accounts for companies, government entities, educational academies and copy clinics. Save 15% flat across high yield compatible multipacks.
              </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
              <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
                <Shield class="w-6 h-6 text-emerald-600 mx-auto" />
                <h4 class="font-display font-semibold text-zinc-900">NET 30 / 60 Terms</h4>
                <p class="text-xs text-zinc-500 font-light">Flexible invoice structures. Submit authorized Purchase Orders (PO) for automated monthly processing.</p>
              </div>
              <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
                <GraduationCap class="w-6 h-6 text-blue-600 mx-auto" />
                <h4 class="font-display font-semibold text-zinc-900">Academy Subsidies</h4>
                <p class="text-xs text-zinc-500 font-light">Special school budgets mapping for heavy volume copier clinics and administrative desks.</p>
              </div>
              <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
                <Landmark class="w-6 h-6 text-purple-600 mx-auto" />
                <h4 class="font-display font-semibold text-zinc-900">DTC Flat Rates</h4>
                <p class="text-xs text-zinc-500 font-light">Eliminate typical distributor markup layers. Receive dedicated business support.</p>
              </div>
            </div>

            {/* Registration Form */}
            <div class="p-8 bg-white border border-zinc-200 rounded-lg shadow-sm">
              <h3 class="font-display text-lg font-bold text-zinc-900 mb-6 border-b border-zinc-100 pb-3">Submit Wholesale Account Application</h3>
              
              {busSubmitted ? (
                <div class="p-8 bg-emerald-50 border border-emerald-200 rounded-md text-center space-y-3">
                  <Check class="w-10 h-10 text-emerald-600 mx-auto" />
                  <p class="font-semibold text-emerald-950">Wholesale Application Received</p>
                  <p class="text-xs text-emerald-800 max-w-md mx-auto leading-relaxed">
                    Account desk has initialized credit underwriting for <strong>{busCompany}</strong>. Check your inbox at <strong>{busEmail}</strong> for Net-30 authorization credentials.
                  </p>
                </div>
              ) : (
                <form onSubmit={(e) => { e.preventDefault(); onRegisterBusiness(busCompany, busEmail, busVat); setBusSubmitted(true); }} class="space-y-4">
                  <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="space-y-1">
                      <label class="text-[10px] font-mono font-bold text-zinc-400 uppercase block">Registered Organization Name</label>
                      <input 
                        type="text" 
                        required
                        value={busCompany}
                        onChange={(e) => setBusCompany(e.target.value)}
                        placeholder="e.g. Vanguard Tech Academy"
                        class="w-full px-3 py-2 border border-zinc-200 rounded-md text-xs font-mono focus:outline-none focus:border-zinc-900"
                      />
                    </div>
                    <div class="space-y-1">
                      <label class="text-[10px] font-mono font-bold text-zinc-400 uppercase block">Corporate VAT / Tax Registration ID</label>
                      <input 
                        type="text" 
                        required
                        value={busVat}
                        onChange={(e) => setBusVat(e.target.value)}
                        placeholder="e.g. US98271822"
                        class="w-full px-3 py-2 border border-zinc-200 rounded-md text-xs font-mono focus:outline-none focus:border-zinc-900"
                      />
                    </div>
                  </div>
                  <div class="space-y-1">
                    <label class="text-[10px] font-mono font-bold text-zinc-400 uppercase block">Authorized Procurement Email Address</label>
                    <input 
                      type="email" 
                      required
                      value={busEmail}
                      onChange={(e) => setBusEmail(e.target.value)}
                      placeholder="e.g. purchasing@vanguardtech.edu"
                      class="w-full px-3 py-2 border border-zinc-200 rounded-md text-xs font-mono focus:outline-none focus:border-zinc-900"
                    />
                  </div>

                  <button 
                    type="submit"
                    class="px-5 py-2.5 bg-zinc-950 hover:bg-zinc-900 text-white text-xs font-mono uppercase tracking-wider font-semibold rounded-md transition-all"
                  >
                    Submit Procurement Request
                  </button>
                </form>
              )}
            </div>
          </div>
        )}

        {/* SUPPORT / FAQ TAB */}
        {currentTab === "faq" && (
          <div class="max-w-3xl mx-auto space-y-8 py-4">
            <div class="text-center space-y-2">
              <h2 class="font-display text-3xl font-bold tracking-tight text-zinc-950">Technical Telemetry Assistance</h2>
              <p class="text-sm text-zinc-500">Answers regarding firmware smart chips, cryptocurrency networks, and direct shipping logistics.</p>
            </div>

            <div class="space-y-4">
              {[
                {
                  q: "Will compatible cartridges void my printer's warranty?",
                  a: "Absolutely not. In the United States, the Magnuson-Moss Warranty Act strictly prohibits printer manufacturers from forcing consumers to use OEM original cartridges. Using high-quality InkForge compatible cartridges keeps your warranty 100% active."
                },
                {
                  q: "Do the cartridges include smart telemetry reporting microchips?",
                  a: "Yes. All InkForge compatible ink and toner units feature integrated latest-generation microprocessors that emulate physical cartridge signals, enabling real-time toner percentage tracking and error-free network handshake operations."
                },
                {
                  q: "Which networks are supported for USDT cryptocurrency checkout?",
                  a: "We support Tether via Tron Network (TRC20) and Ethereum Network (ERC20). TRC20 is highly recommended due to ultra-low blockchain gas costs and rapid block confirmation speeds."
                },
                {
                  q: "What is your return policy for open consumables?",
                  a: "We offer a 100-day high-fidelity guarantee. If a compatible unit fails to perform or produces poor density outputs, you can initiate a return for a complete refund or swap."
                }
              ].map((faq, index) => (
                <div key={index} class="p-5 bg-white border border-zinc-200 rounded-md space-y-2">
                  <p class="text-xs font-mono text-zinc-400 font-bold">CASE-LOG #{1000 + index}</p>
                  <h4 class="font-display font-semibold text-zinc-900 text-sm">{faq.q}</h4>
                  <p class="text-xs text-zinc-600 leading-relaxed font-light">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer class="bg-white text-zinc-500 py-12 mt-16 border-t border-zinc-100 text-xs font-mono">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8">
          <div class="space-y-4">
            <p class="text-zinc-950 text-base font-bold tracking-tighter uppercase">
              Ink<span class="text-zinc-400 font-light italic">Forge</span>
            </p>
            <p class="text-[11px] font-light leading-relaxed text-zinc-500">
              High-precision direct-to-consumer printer consumables. Sourced directly, calibrated with precision microchips, and priced for the bottom line.
            </p>
            <p class="text-[10px] text-zinc-400">© 2026 InkForge. All rights reserved.</p>
          </div>
          <div class="space-y-2">
            <p class="text-zinc-950 text-[10px] font-bold uppercase tracking-wider">Catalog Channels</p>
            <ul class="space-y-1.5 text-[11px] text-zinc-500">
              <li><button onClick={() => { setCurrentTab("shop"); setSelectedCategory("Ink Cartridge"); }} class="hover:text-black">Ink Cartridges</button></li>
              <li><button onClick={() => { setCurrentTab("shop"); setSelectedCategory("Toner"); }} class="hover:text-black">Toner Cartridges</button></li>
              <li><button onClick={() => { setCurrentTab("shop"); setSelectedCategory("Refill Kit"); }} class="hover:text-black">Refill Kits</button></li>
              <li><button onClick={() => { setCurrentTab("shop"); setSelectedCategory("Office Supplies"); }} class="hover:text-black">Office Consumables</button></li>
            </ul>
          </div>
          <div class="space-y-2">
            <p class="text-zinc-950 text-[10px] font-bold uppercase tracking-wider">Support & Corporate</p>
            <ul class="space-y-1.5 text-[11px] text-zinc-500">
              <li><button onClick={() => setCurrentTab("business")} class="hover:text-black">Corporate Portal</button></li>
              <li><button onClick={() => setCurrentTab("faq")} class="hover:text-black font-semibold text-zinc-950">USDT & Crypto FAQ</button></li>
              <li><button onClick={() => alert("Standard shipping delivers within 2 days across domestic freight vectors.")} class="hover:text-black">Freight Logistics</button></li>
              <li><button onClick={() => alert("Privacy is absolute. Zero external tracking scripts.")} class="hover:text-black">Privacy Protocol</button></li>
            </ul>
          </div>
          <div class="space-y-2">
            <p class="text-zinc-950 text-[10px] font-bold uppercase tracking-wider">Delivery Standards</p>
            <div class="p-4 bg-[#FAFAFA] border border-zinc-100 rounded-sm text-[11px] space-y-2 text-zinc-500">
              <div class="flex items-center justify-between">
                <span>Domestic Freight</span>
                <span class="text-zinc-900 font-bold">1-2 Days</span>
              </div>
              <div class="flex items-center justify-between">
                <span>International Transport</span>
                <span class="text-zinc-900 font-bold">3-5 Days</span>
              </div>
              <div class="flex items-center gap-1.5 pt-1 text-[10px] font-semibold text-zinc-950">
                <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                Dispatch Operations Active
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* PRODUCT DETAILS MODAL */}
      <AnimatePresence>
        {selectedProduct && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              class="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-zinc-950 border border-zinc-200"
            >
              <div class="flex justify-between items-start gap-4">
                <div class="space-y-1">
                  <div class="flex items-center gap-2">
                    <span class="text-[9px] font-mono bg-zinc-950 text-white px-2 py-0.5 rounded-sm">
                      {selectedProduct.sku}
                    </span>
                    <span class="text-[9px] font-mono text-zinc-500">
                      OEM Ref: {selectedProduct.oemReference}
                    </span>
                  </div>
                  <h3 class="font-display font-bold text-xl sm:text-2xl text-zinc-950">{selectedProduct.name}</h3>
                </div>
                <button 
                  onClick={() => setSelectedProduct(null)}
                  class="text-zinc-400 hover:text-zinc-950 font-bold text-xl"
                >
                  ✕
                </button>
              </div>

              <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 pt-4">
                {/* Images column */}
                <div class="lg:col-span-5 space-y-4">
                  <div class="bg-zinc-50 border border-zinc-200 rounded-lg p-6 flex items-center justify-center aspect-square">
                    <img 
                      src={selectedProduct.images[0]} 
                      alt={selectedProduct.name}
                      class="max-h-56 object-contain"
                    />
                  </div>
                  
                  {/* Performance Indicators */}
                  <div class="grid grid-cols-2 gap-3">
                    <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-md">
                      <p class="text-[10px] font-mono text-zinc-400">PAGE YIELD</p>
                      <p class="text-sm font-bold font-mono text-zinc-950">{selectedProduct.estimatedPageYield.toLocaleString()}</p>
                    </div>
                    <div class="p-3 bg-zinc-50 border border-zinc-200 rounded-md">
                      <p class="text-[10px] font-mono text-zinc-400">COST PER PAGE</p>
                      <p class="text-sm font-bold font-mono text-zinc-950">${selectedProduct.costPerPage.toFixed(4)}</p>
                    </div>
                  </div>
                </div>

                {/* Info Column */}
                <div class="lg:col-span-7 space-y-6">
                  <div class="space-y-2">
                    <p class="text-xs font-mono font-bold text-zinc-400 uppercase">TELEMETRY & DESCRIPTION</p>
                    <p class="text-xs text-zinc-700 font-light leading-relaxed">{selectedProduct.description}</p>
                  </div>

                  <div class="space-y-2">
                    <p class="text-xs font-mono font-bold text-zinc-400 uppercase">PRINTER COMPATIBILITY GRAPH</p>
                    <div class="flex flex-wrap gap-1.5">
                      {selectedProduct.compatiblePrinters.map(cp => (
                        <span key={cp} class="px-2.5 py-1 bg-zinc-100 text-zinc-800 rounded-sm text-[10px] font-mono">
                          {cp}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Installation manual accordion */}
                  <div class="space-y-2">
                    <p class="text-xs font-mono font-bold text-zinc-400 uppercase">HARDWARE INSTALLATION MATRIX</p>
                    <pre class="p-3 bg-zinc-50 border border-zinc-200 rounded-md text-[10px] font-mono text-zinc-600 whitespace-pre-wrap leading-relaxed">
                      {selectedProduct.installationGuide}
                    </pre>
                  </div>

                  {/* Bulk Volume Matrix */}
                  {selectedProduct.bulkPricing.length > 0 && (
                    <div class="space-y-2">
                      <p class="text-xs font-mono font-bold text-zinc-400 uppercase">BULK ACQUISITION DEPRECIATION</p>
                      <div class="grid grid-cols-2 gap-2 text-xs font-mono text-zinc-600">
                        {selectedProduct.bulkPricing.map((bp, i) => (
                          <div key={i} class="p-2 bg-emerald-50/50 border border-emerald-100 rounded-md flex justify-between">
                            <span>Qty {bp.quantity}+:</span>
                            <span class="font-bold text-emerald-950">${bp.price} / unit</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actions & Price */}
                  <div class="flex items-center justify-between border-t border-zinc-100 pt-6">
                    <div class="space-y-0.5">
                      <p class="text-[10px] font-mono text-zinc-400">DTC PRICE</p>
                      <div class="flex items-baseline gap-2">
                        {selectedProduct.salePrice ? (
                          <>
                            <span class="text-2xl font-mono font-bold text-zinc-950">${selectedProduct.salePrice}</span>
                            <span class="text-sm font-mono line-through text-zinc-400">${selectedProduct.price}</span>
                          </>
                        ) : (
                          <span class="text-2xl font-mono font-bold text-zinc-950">${selectedProduct.price}</span>
                        )}
                      </div>
                    </div>

                    <div class="flex gap-3">
                      <button 
                        onClick={() => { addToCart(selectedProduct); setSelectedProduct(null); }}
                        class="px-5 py-3 bg-zinc-950 hover:bg-zinc-900 text-white text-xs font-mono font-bold uppercase tracking-wider rounded-md transition-colors"
                      >
                        Add To Consumable Bin
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* SHOPPING CART & STREAMLINED CHECKOUT DRAWER */}
      <AnimatePresence>
        {isCartOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            class="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end"
          >
            <div 
              onClick={() => setIsCartOpen(false)}
              class="absolute inset-0"
            />
            <motion.div 
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              class="relative bg-white w-full max-w-lg h-full flex flex-col justify-between shadow-2xl z-10 p-6 sm:p-8"
            >
              {/* Header */}
              <div class="flex justify-between items-center border-b border-zinc-100 pb-4">
                <div class="flex items-center gap-2">
                  <ShoppingCart class="w-5 h-5 text-zinc-800" />
                  <h3 class="font-display font-bold text-lg text-zinc-950">Secure Ingress Terminal</h3>
                </div>
                <button onClick={() => { setIsCartOpen(false); setCheckoutStep("cart"); }} class="text-zinc-400 hover:text-zinc-950 text-lg">✕</button>
              </div>

              {/* Checkout Progress indicator */}
              {checkoutStep !== "cart" && checkoutStep !== "success" && (
                <div class="grid grid-cols-2 gap-2 text-center text-[10px] font-mono border-b border-zinc-100 pb-3 mt-2">
                  <span class={`py-1 rounded-sm ${checkoutStep === "shipping" ? "bg-zinc-950 text-white font-bold" : "bg-zinc-100 text-zinc-400"}`}>1. Freight Details</span>
                  <span class={`py-1 rounded-sm ${checkoutStep === "crypto" ? "bg-zinc-950 text-white font-bold" : "bg-zinc-100 text-zinc-400"}`}>2. Crypto Settlement</span>
                </div>
              )}

              {/* Content Panels */}
              <div class="flex-1 overflow-y-auto py-4 space-y-4">
                {checkoutStep === "cart" && (
                  <>
                    {cart.length === 0 ? (
                      <div class="py-16 text-center space-y-3">
                        <ShoppingCart class="w-12 h-12 text-zinc-300 mx-auto" />
                        <p class="text-xs font-mono text-zinc-400">Ingress cargo bin is completely empty.</p>
                      </div>
                    ) : (
                      <div class="space-y-4">
                        {cart.map(item => (
                          <div key={item.product.id} class="flex gap-4 border-b border-zinc-100 pb-4 text-xs font-mono">
                            <div class="w-12 h-12 bg-zinc-50 border border-zinc-200 rounded p-1 flex items-center justify-center">
                              <img src={item.product.images[0]} alt={item.product.name} class="max-h-10 object-contain" />
                            </div>
                            <div class="flex-1 space-y-1">
                              <p class="font-bold text-zinc-950 line-clamp-1">{item.product.name}</p>
                              <p class="text-[10px] text-zinc-400">SKU: {item.product.sku}</p>
                              <div class="flex items-center justify-between">
                                <div class="flex items-center border border-zinc-200 rounded">
                                  <button onClick={() => updateQuantity(item.product.id, -1)} class="px-2 py-0.5 hover:bg-zinc-100">-</button>
                                  <span class="px-2 py-0.5 border-x border-zinc-200">{item.quantity}</span>
                                  <button onClick={() => updateQuantity(item.product.id, 1)} class="px-2 py-0.5 hover:bg-zinc-100">+</button>
                                </div>
                                <span class="font-bold text-zinc-950">${((item.product.salePrice || item.product.price) * item.quantity).toFixed(2)}</span>
                              </div>
                            </div>
                          </div>
                        ))}

                        {/* Promo code area */}
                        <div class="pt-2 flex gap-2">
                          <input 
                            type="text" 
                            placeholder="Promo Code: try FORGE10" 
                            value={discountCode}
                            onChange={(e) => setDiscountCode(e.target.value)}
                            class="bg-zinc-50 border border-zinc-200 px-3 py-1.5 text-xs font-mono rounded w-full focus:outline-none focus:border-zinc-950"
                          />
                          <button onClick={applyPromoCode} class="bg-zinc-900 text-white px-3 py-1.5 text-xs font-mono rounded hover:bg-zinc-800">Apply</button>
                        </div>
                      </div>
                    )}
                  </>
                )}

                {checkoutStep === "shipping" && (
                  <form onSubmit={handleCheckoutSubmit} class="space-y-4 text-xs font-mono text-zinc-700">
                    <p class="text-[11px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-1.5">Direct Freight Consignee</p>
                    <div class="grid grid-cols-2 gap-2">
                      <div class="space-y-1">
                        <label class="block text-[10px] text-zinc-400">Full Name</label>
                        <input type="text" required value={customerName} onChange={(e) => setCustomerName(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                      </div>
                      <div class="space-y-1">
                        <label class="block text-[10px] text-zinc-400">Procurement Email</label>
                        <input type="email" required value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                      </div>
                    </div>

                    <div class="space-y-1">
                      <label class="block text-[10px] text-zinc-400">Freight Street Address</label>
                      <input type="text" required value={shippingStreet} onChange={(e) => setShippingStreet(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                    </div>

                    <div class="grid grid-cols-3 gap-2">
                      <div class="space-y-1">
                        <label class="block text-[10px] text-zinc-400">City</label>
                        <input type="text" required value={shippingCity} onChange={(e) => setShippingCity(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                      </div>
                      <div class="space-y-1">
                        <label class="block text-[10px] text-zinc-400">State / Region</label>
                        <input type="text" required value={shippingState} onChange={(e) => setShippingState(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                      </div>
                      <div class="space-y-1">
                        <label class="block text-[10px] text-zinc-400">Postal Zip Code</label>
                        <input type="text" required value={shippingZip} onChange={(e) => setShippingZip(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                      </div>
                    </div>

                    <div class="space-y-1">
                      <label class="block text-[10px] text-zinc-400">Corporate VAT (Optional)</label>
                      <input type="text" placeholder="e.g., US98271822" value={businessVat} onChange={(e) => setBusinessVat(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                    </div>

                    <p class="text-[11px] font-bold text-zinc-400 uppercase tracking-widest border-b border-zinc-100 pb-1.5 pt-2">Settlement Corridor</p>
                    <div class="grid grid-cols-3 gap-2 text-center">
                      {[
                        { id: "Card", label: "Credit Card" },
                        { id: "BTC", label: "Bitcoin ₿" },
                        { id: "USDT", label: "Tether ₮" }
                      ].map(method => (
                        <button 
                          key={method.id}
                          type="button"
                          onClick={() => setSelectedPayment(method.id as any)}
                          class={`py-2 border rounded transition-colors ${selectedPayment === method.id ? "bg-zinc-950 text-white border-zinc-950 font-bold" : "bg-white hover:bg-zinc-50 border-zinc-200 text-zinc-600"}`}
                        >
                          {method.label}
                        </button>
                      ))}
                    </div>

                    {selectedPayment === "USDT" && (
                      <div class="space-y-1">
                        <label class="block text-[10px] text-zinc-400">Select Blockchain Ledger Network</label>
                        <select 
                          value={selectedNetwork} 
                          onChange={(e) => setSelectedNetwork(e.target.value)}
                          class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded"
                        >
                          <option value="TRC20 (Tron)">TRC20 (Tron Network - Low Gas)</option>
                          <option value="ERC20 (Ethereum)">ERC20 (Ethereum Network)</option>
                        </select>
                      </div>
                    )}

                    <button 
                      type="submit"
                      class="w-full mt-4 py-3 bg-zinc-950 hover:bg-zinc-900 text-white rounded text-xs font-semibold uppercase tracking-wider"
                    >
                      Authorize Shipment & Settlement
                    </button>
                  </form>
                )}

                {checkoutStep === "crypto" && latestCreatedOrder && (
                  <div class="space-y-5 text-xs font-mono">
                    
                    {latestCreatedOrder.paymentMethod === "Card" ? (
                      <div class="p-6 bg-emerald-50 border border-emerald-200 rounded text-center space-y-3">
                        <Check class="w-10 h-10 text-emerald-600 mx-auto" />
                        <p class="font-bold text-emerald-950">Payment Settled</p>
                        <p class="text-[11px] text-emerald-800">Your credit card was authorized instantly. Shipment tracking is ready.</p>
                        <button onClick={() => setCheckoutStep("success")} class="px-4 py-2 bg-emerald-600 text-white hover:bg-emerald-700 rounded uppercase font-bold text-[10px] tracking-wider">
                          Proceed to Invoice Receipt
                        </button>
                      </div>
                    ) : (
                      <div class="space-y-4">
                        <div class="p-4 bg-zinc-950 text-white rounded-md space-y-3 border border-zinc-800">
                          <div class="flex justify-between items-center text-[10px]">
                            <span class="text-zinc-400">INVOICE CORRIDOR:</span>
                            <span class="text-emerald-400 font-bold tracking-wider">{latestCreatedOrder.paymentMethod} SETTLEMENT</span>
                          </div>
                          
                          <div class="flex justify-between items-end border-t border-zinc-800 pt-3">
                            <div>
                              <p class="text-[10px] text-zinc-500">EXACT CRYPTO VOLUME TO TRANSFER</p>
                              <p class="text-lg font-bold tracking-tight text-white font-mono">
                                {latestCreatedOrder.paymentDetails?.cryptoAmount} {latestCreatedOrder.paymentMethod}
                              </p>
                            </div>
                            <div class="text-right">
                              <p class="text-[10px] text-zinc-500">EXCHANGE RATE</p>
                              <p class="text-[10px] text-zinc-400 font-mono">
                                1 {latestCreatedOrder.paymentMethod} = ${latestCreatedOrder.paymentDetails?.cryptoRate?.toLocaleString()} USD
                              </p>
                            </div>
                          </div>
                        </div>

                        {/* QR Code and Address */}
                        <div class="bg-zinc-50 border border-zinc-200 rounded-md p-5 text-center space-y-4">
                          <p class="text-[10px] text-zinc-400 uppercase tracking-widest font-bold">RECIPIENT SECURE WALLET ADDRESS</p>
                          
                          {/* CSS Drawn Vector QR Code Placeholder */}
                          <div class="w-32 h-32 bg-white border border-zinc-300 mx-auto p-2 flex items-center justify-center relative shadow-sm">
                            <div class="grid grid-cols-4 gap-1 w-full h-full opacity-75">
                              {[...Array(16)].map((_, idx) => (
                                <div key={idx} class={`w-full h-full ${((idx + 2) % 3 === 0 || (idx % 4 === 0)) ? "bg-zinc-950" : "bg-white"}`} />
                              ))}
                            </div>
                            <span class="absolute inset-0 flex items-center justify-center bg-white/95 px-2 text-[8px] font-bold text-zinc-900 border border-zinc-300">
                              SECURE QR
                            </span>
                          </div>

                          <div class="space-y-1">
                            <p class="text-[10px] font-semibold text-zinc-800 select-all font-mono break-all p-2 bg-white border border-zinc-200 rounded">
                              {latestCreatedOrder.paymentDetails?.cryptoAddress}
                            </p>
                            <button 
                              onClick={() => copyAddress(latestCreatedOrder.paymentDetails?.cryptoAddress || "")}
                              class="text-[10px] text-zinc-500 hover:text-zinc-900 flex items-center justify-center gap-1 mx-auto"
                            >
                              <Copy class="w-3 h-3" />
                              {copiedText ? "Address Copied!" : "Copy Secure Wallet Address"}
                            </button>
                          </div>
                        </div>

                        {/* Simulation trigger */}
                        <div class="p-4 bg-emerald-50/70 border border-emerald-100 rounded-md space-y-3">
                          <div class="flex justify-between items-center text-[10px] text-emerald-900">
                            <span class="font-bold">BLOCKCHAIN MEMPOOL DETECTOR</span>
                            <span class="flex items-center gap-1">
                              <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-ping"></span>
                              Active Listening
                            </span>
                          </div>
                          
                          <p class="text-[10px] text-emerald-800 font-light leading-relaxed">
                            A decentralized node daemon is actively listening for your transaction broadcast. Once detected, confirmations will update in real-time.
                          </p>

                          <div class="flex justify-between items-center bg-white p-2 border border-emerald-200 rounded text-[10px]">
                            <span>STATUS:</span>
                            <span class="font-mono font-bold uppercase text-emerald-700">
                              {txDetected ? `DETECTED (${confirmations}/4 confirmations)` : "AWAITING BROADCAST"}
                            </span>
                          </div>

                          <button 
                            type="button"
                            onClick={triggerBlockchainSim}
                            disabled={isVerifying}
                            class="w-full py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-zinc-300 text-white rounded text-[10px] tracking-wider uppercase font-bold transition-all flex items-center justify-center gap-1.5"
                          >
                            {isVerifying ? (
                              <>
                                <RefreshCw class="w-3.5 h-3.5 animate-spin" />
                                Validating Blocks...
                              </>
                            ) : (
                              <>
                                <Coins class="w-3.5 h-3.5" />
                                Simulate Blockchain Broadcast
                              </>
                            )}
                          </button>
                        </div>

                        {/* Countdown */}
                        <div class="flex items-center justify-center gap-2 text-[11px] text-zinc-500 text-center font-mono py-2">
                          <Clock class="w-4 h-4 text-zinc-400" />
                          Invoice closes in: <span class="font-bold text-zinc-900">{Math.floor(paymentTimeRemaining / 60)}m {paymentTimeRemaining % 60}s</span>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {checkoutStep === "success" && latestCreatedOrder && (
                  <div class="py-6 text-center space-y-6 text-zinc-950 animate-fade-in font-mono text-xs">
                    <div class="w-12 h-12 bg-zinc-950 text-white rounded-full flex items-center justify-center mx-auto">
                      <Check class="w-6 h-6 stroke-[3]" />
                    </div>

                    <div class="space-y-2">
                      <p class="font-display font-bold text-lg text-zinc-950">Shipment Consigned</p>
                      <p class="text-[11px] text-zinc-500">Order Ref: <span class="font-bold text-zinc-900">{latestCreatedOrder.orderReference}</span> has been scheduled for packaging.</p>
                    </div>

                    <div class="border border-zinc-200 rounded-lg p-5 text-left bg-zinc-50 space-y-4">
                      <div class="border-b border-zinc-200 pb-2 flex justify-between items-center text-[10px] text-zinc-400">
                        <span>FREIGHT RECEIPT</span>
                        <span>{new Date(latestCreatedOrder.timestamp).toLocaleDateString()}</span>
                      </div>
                      
                      <div class="space-y-1">
                        <p class="font-bold text-zinc-900">{latestCreatedOrder.customerName}</p>
                        <p class="text-zinc-500">{latestCreatedOrder.customerEmail}</p>
                        <p class="text-zinc-500">{latestCreatedOrder.shippingAddress.street}, {latestCreatedOrder.shippingAddress.city}, {latestCreatedOrder.shippingAddress.state} {latestCreatedOrder.shippingAddress.postalCode}</p>
                      </div>

                      <div class="border-t border-zinc-200 pt-2 space-y-1.5">
                        {latestCreatedOrder.items.map((it, idx) => (
                          <div key={idx} class="flex justify-between text-[11px]">
                            <span class="text-zinc-600">{it.name} (x{it.quantity})</span>
                            <span class="font-bold text-zinc-900">${(it.price * it.quantity).toFixed(2)}</span>
                          </div>
                        ))}
                      </div>

                      <div class="border-t border-zinc-200 pt-2 flex justify-between items-center font-bold text-zinc-900 text-sm">
                        <span>TOTAL SETTLED:</span>
                        <span>${latestCreatedOrder.total}</span>
                      </div>
                    </div>

                    <div class="p-3.5 bg-zinc-100 border border-zinc-200 rounded text-[11px] text-zinc-500 leading-relaxed text-left">
                      <strong>Audit Daemon Note:</strong> An automated confirmation transmission has been sent to your registered email corridor. System dashboard tracks real-time fulfillment logs.
                    </div>

                    <button 
                      onClick={() => { setIsCartOpen(false); setCheckoutStep("cart"); }}
                      class="w-full py-3 bg-zinc-950 hover:bg-zinc-900 text-white text-xs uppercase tracking-wider font-bold rounded transition-colors"
                    >
                      Close Secure Session
                    </button>
                  </div>
                )}
              </div>

              {/* Subtotal Footer */}
              {checkoutStep === "cart" && cart.length > 0 && (
                <div class="border-t border-zinc-100 pt-4 space-y-3 font-mono text-xs text-zinc-500">
                  <div class="flex justify-between text-zinc-600">
                    <span>Subtotal:</span>
                    <span class="font-bold text-zinc-900">${getCartSubtotal().toFixed(2)}</span>
                  </div>
                  {appliedDiscount > 0 && (
                    <div class="flex justify-between text-emerald-600">
                      <span>Discount (10% code Applied):</span>
                      <span class="font-bold">-${(getCartSubtotal() * appliedDiscount).toFixed(2)}</span>
                    </div>
                  )}
                  <div class="flex justify-between text-zinc-600">
                    <span>Direct Courier Shipping:</span>
                    <span class="font-bold text-zinc-900">{getCartSubtotal() >= 50 ? "FREE" : "$4.99"}</span>
                  </div>
                  <div class="border-t border-zinc-200 pt-2 flex justify-between text-sm font-bold text-zinc-950">
                    <span>Total Invoice:</span>
                    <span>${getCartTotal()}</span>
                  </div>

                  <button 
                    onClick={() => setCheckoutStep("shipping")}
                    class="w-full py-3.5 bg-zinc-950 hover:bg-zinc-900 text-white rounded text-xs font-bold uppercase tracking-wider transition-colors"
                  >
                    Proceed to Consignee details
                  </button>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
