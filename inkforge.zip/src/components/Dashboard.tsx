import React, { useState, useEffect } from "react";
import { 
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell 
} from "recharts";
import { 
  Package, ShoppingBag, TrendingUp, AlertTriangle, Coins, Users, 
  Database, RefreshCw, Plus, Copy, FileText, Check, Trash2, 
  Upload, Terminal, Shield, Eye, HelpCircle, Sparkles, BookOpen
} from "lucide-react";
import { Product, ProductStatus, Order, OrderStatus, BusinessAccount, AuditLog } from "../types";
import { PRINTER_BRANDS } from "../data";

interface DashboardProps {
  products: Product[];
  orders: Order[];
  businessAccounts: BusinessAccount[];
  auditLogs: AuditLog[];
  onProductCreated: (p: Product) => void;
  onProductUpdated: (p: Product) => void;
  onProductDuplicated: (p: Product) => void;
  onProductArchived: (id: string) => void;
  onOrderStatusChanged: (id: string, status: OrderStatus) => void;
  onBulkCsvImport: (count: number) => void;
}

export default function Dashboard({
  products,
  orders,
  businessAccounts,
  auditLogs,
  onProductCreated,
  onProductUpdated,
  onProductDuplicated,
  onProductArchived,
  onOrderStatusChanged,
  onBulkCsvImport
}: DashboardProps) {
  
  // Tab within Dashboard
  const [activeSubTab, setActiveSubTab] = useState<"overview" | "inventory" | "orders" | "business" | "wallets" | "api" | "audit">("overview");
  
  // Analytics numbers
  const [analytics, setAnalytics] = useState<any>({
    totalRevenue: 0,
    salesCount: 0,
    cryptoPercentage: 0,
    lowStockCount: 0,
    categoryBreakdown: [],
    recentSalesDaily: []
  });
  
  // UI Actions states
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [newProductFormOpen, setNewProductFormOpen] = useState(false);
  const [csvText, setCsvText] = useState("");
  const [isImportingCsv, setIsImportingCsv] = useState(false);

  // Gemini AI Classifier state inside Product Creator
  const [aiTitle, setAiTitle] = useState("");
  const [aiManufacturer, setAiManufacturer] = useState("HP");
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<any>(null);

  // New Product Form State
  const [sku, setSku] = useState("");
  const [name, setName] = useState("");
  const [manufacturer, setManufacturer] = useState("HP");
  const [category, setCategory] = useState<any>("Toner");
  const [price, setPrice] = useState("39.99");
  const [stockQuantity, setStockQuantity] = useState("50");
  const [estimatedPageYield, setEstimatedPageYield] = useState("2500");
  const [costPerPage, setCostPerPage] = useState("0.012");
  const [compatiblePrintersInput, setCompatiblePrintersInput] = useState("");
  const [cartridgeNumber, setCartridgeNumber] = useState("");
  const [color, setColor] = useState<any>("Black");
  const [description, setDescription] = useState("");
  const [isCompatible, setIsCompatible] = useState(true);

  // Fetch metrics
  const fetchAnalytics = async () => {
    setIsRefreshing(true);
    try {
      const res = await fetch("/api/analytics");
      if (res.ok) {
        const data = await res.json();
        setAnalytics(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, [products, orders]);

  // Handle Create Product
  const handleCreateProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      sku,
      name,
      manufacturer,
      category,
      price: parseFloat(price) || 29.99,
      stockQuantity: parseInt(stockQuantity) || 10,
      estimatedPageYield: parseInt(estimatedPageYield) || 1000,
      costPerPage: parseFloat(costPerPage) || 0.01,
      cartridgeNumber: cartridgeNumber || "N/A",
      oemReference: `OEM-${sku}`,
      color,
      description,
      isCompatible,
      compatiblePrinters: compatiblePrintersInput.split(",").map(s => s.trim()).filter(Boolean),
      images: ["https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=600"],
      installationGuide: "1. Slide into slot.\n2. Confirm click lock.\n3. Calibrate devices.",
      bulkPricing: [{ quantity: 5, price: parseFloat((parseFloat(price) * 0.9).toFixed(2)) }],
      status: ProductStatus.Published,
      isXL: name.toLowerCase().includes("xl") || name.toLowerCase().includes("high yield"),
      isMultipack: name.toLowerCase().includes("pack") || name.toLowerCase().includes("set")
    };

    try {
      const res = await fetch("/api/products", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        const prod = await res.json();
        onProductCreated(prod);
        setNewProductFormOpen(false);
        // Clear inputs
        setSku(""); setName(""); setPrice("39.99"); setStockQuantity("50");
        setEstimatedPageYield("2500"); setCostPerPage("0.012"); setCompatiblePrintersInput("");
        setCartridgeNumber(""); setColor("Black"); setDescription("");
        setAiResult(null); setAiTitle("");
      } else {
        alert("Failed to submit product.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Trigger Gemini AI Classifier
  const handleGeminiClassify = async () => {
    if (!aiTitle.trim()) {
      alert("Please provide a product title for the AI analysis.");
      return;
    }
    setIsAiLoading(true);
    setAiResult(null);

    try {
      const res = await fetch("/api/gemini/categorize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          title: aiTitle, 
          manufacturer: aiManufacturer,
          description: "InkForge premium DTX logistics item."
        })
      });

      if (res.ok) {
        const result = await res.json();
        setAiResult(result.data);
        
        // Auto-fill form inputs with Gemini classified telemetry!
        setName(aiTitle);
        setCategory(result.data.category);
        setManufacturer(aiManufacturer);
        setEstimatedPageYield(result.data.estimatedPageYield.toString());
        setCostPerPage(result.data.costPerPage.toString());
        setCompatiblePrintersInput(result.data.compatiblePrinters.join(", "));
        setCartridgeNumber(result.data.oemReference);
        setColor(result.data.color);
        setDescription(result.data.optimizedDescription);
        setIsCompatible(result.data.isCompatible);
        
        // Generate automatic SKU
        const words = aiTitle.split(" ");
        const firstLetters = words.slice(0, 3).map((w: string) => w.substring(0, 3).toUpperCase()).join("-");
        setSku(`IF-${firstLetters}-${Math.floor(100 + Math.random() * 900)}`);
      } else {
        alert("AI classification failed. Running fallback mock mapping.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsAiLoading(false);
    }
  };

  // Import CSV text
  const handleCsvImport = async () => {
    if (!csvText.trim()) {
      alert("No CSV text provided.");
      return;
    }
    setIsImportingCsv(true);
    try {
      const res = await fetch("/api/products/bulk-csv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ csvText })
      });
      if (res.ok) {
        const result = await res.json();
        onBulkCsvImport(result.count);
        setCsvText("");
        alert(`Successfully imported ${result.count} products into the ERP catalog database!`);
      } else {
        alert("Bulk import failed.");
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsImportingCsv(false);
    }
  };

  // Sample CSV template
  const loadSampleCsv = () => {
    const sample = `sku,name,manufacturer,category,stockQuantity,price,estimatedPageYield,costPerPage,color,isCompatible,isXL,isMultipack,compatiblePrinters
IF-522-BLK,Epson 522 Compatible Black Ink Bottle,Epson,Refill Kit,120,12.99,4500,0.0028,Black,true,false,false,Epson EcoTank ET-2720|EcoTank ET-2800
IF-410X-CY,HP 410X High Yield Compatible Cyan Laser Toner,HP,Toner,45,69.99,5000,0.0139,Cyan,true,true,false,HP Color LaserJet Pro M452dn|Pro MFP M477fdn
OEM-903-4PK,HP 903 Original Ink Cartridge Multipack - 4 Colors,HP,Ink Cartridge,12,54.99,825,0.066,Multi,false,false,true,HP OfficeJet 6950|OfficeJet Pro 6960`;
    setCsvText(sample);
  };

  // Color mappings for Recharts Pie Chart
  const COLORS = ["#121314", "#2563eb", "#db2777", "#ca8a04"];

  return (
    <div class="space-y-8 py-4 animate-fade-in text-zinc-950">
      
      {/* ERP Header */}
      <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-zinc-200 pb-6">
        <div>
          <p class="text-xs font-mono font-bold tracking-widest text-zinc-400">ENTERPRISE ERP DASHBOARD</p>
          <h2 class="font-display text-3xl font-bold tracking-tight text-zinc-950">Fulfillment & Asset Control</h2>
        </div>
        
        <div class="flex items-center gap-3">
          <button 
            onClick={fetchAnalytics}
            disabled={isRefreshing}
            class="px-3 py-1.5 border border-zinc-200 bg-white rounded-md text-xs font-mono text-zinc-600 hover:text-zinc-950 flex items-center gap-1.5 transition-colors"
          >
            <RefreshCw class={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin" : ""}`} />
            Sync Telemetry
          </button>
          <button 
            onClick={() => setNewProductFormOpen(true)}
            class="px-4 py-1.5 bg-zinc-950 hover:bg-zinc-900 text-white rounded-md text-xs font-mono tracking-wider uppercase font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Plus class="w-4 h-4" />
            Provision SKU
          </button>
        </div>
      </div>

      {/* Sub Tabs */}
      <div class="flex flex-wrap gap-2 border-b border-zinc-200 pb-3">
        {[
          { id: "overview", label: "Analytics Overview", icon: TrendingUp },
          { id: "inventory", label: "Catalog & Inventory", icon: Package },
          { id: "orders", label: "Fulfillment Orders", icon: ShoppingBag },
          { id: "business", label: "Corporate Clients", icon: Users },
          { id: "wallets", label: "Crypto Accounts", icon: Coins },
          { id: "api", label: "API Sandbox Explorer", icon: Terminal },
          { id: "audit", label: "System Security Audit", icon: Shield }
        ].map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              class={`px-4 py-2 text-xs font-mono font-medium rounded-md transition-all flex items-center gap-2 ${activeSubTab === tab.id ? "bg-zinc-950 text-white" : "hover:bg-zinc-100 text-zinc-600"}`}
            >
              <Icon class="w-3.5 h-3.5" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* SUB TAB VIEWS */}
      {activeSubTab === "overview" && (
        <div class="space-y-8">
          
          {/* Key Metric Blocks */}
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
              <p class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider font-bold">TOTAL REVENUE (SETTLED)</p>
              <p class="text-3xl font-mono font-bold tracking-tight">${analytics.totalRevenue?.toLocaleString()}</p>
              <div class="flex items-center gap-1 text-[10px] font-mono text-emerald-600">
                <TrendingUp class="w-3 h-3" />
                +14.2% versus last cycle
              </div>
            </div>

            <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
              <p class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider font-bold">DISPATCHED CARGO ORDERS</p>
              <p class="text-3xl font-mono font-bold tracking-tight">{analytics.salesCount}</p>
              <p class="text-[10px] font-mono text-zinc-500">100% processing efficiency</p>
            </div>

            <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
              <p class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider font-bold">BLOCKCHAIN USAGE RATE</p>
              <p class="text-3xl font-mono font-bold tracking-tight text-emerald-600">{analytics.cryptoPercentage}%</p>
              <p class="text-[10px] font-mono text-zinc-500">Self-hosted Bitcoin/USDT</p>
            </div>

            <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-2">
              <p class="text-[10px] font-mono text-zinc-400 uppercase tracking-wider font-bold">CRITICAL DEPLETED SKUS</p>
              <p class={`text-3xl font-mono font-bold tracking-tight ${analytics.lowStockCount > 0 ? "text-amber-600" : "text-zinc-950"}`}>
                {analytics.lowStockCount}
              </p>
              <div class="flex items-center gap-1 text-[10px] font-mono text-amber-600">
                <AlertTriangle class="w-3 h-3" />
                Requires automated restocking
              </div>
            </div>
          </div>

          {/* Graphics area */}
          <div class="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Line graph */}
            <div class="lg:col-span-8 bg-white border border-zinc-200 rounded-lg p-6 space-y-4">
              <div>
                <h3 class="font-display font-semibold text-sm text-zinc-900">7-Day Freight Sales Curve</h3>
                <p class="text-xs text-zinc-400">Total processed orders value progression</p>
              </div>
              <div class="h-80 w-full font-mono text-xs">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={analytics.recentSalesDaily}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="date" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" />
                    <Tooltip formatter={(value) => [`$${value}`, 'Settled Revenue']} />
                    <Line type="monotone" dataKey="amount" stroke="#121314" strokeWidth={2.5} activeDot={{ r: 8 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Category breakdown (Pie) */}
            <div class="lg:col-span-4 bg-white border border-zinc-200 rounded-lg p-6 space-y-4 flex flex-col justify-between">
              <div>
                <h3 class="font-display font-semibold text-sm text-zinc-900">Revenue Breakdowns</h3>
                <p class="text-xs text-zinc-400">Settled distribution per category</p>
              </div>

              {analytics.categoryBreakdown?.length === 0 ? (
                <p class="text-xs font-mono text-zinc-400 py-16 text-center">No category data recorded yet.</p>
              ) : (
                <>
                  <div class="h-48 w-full flex items-center justify-center font-mono text-xs">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={analytics.categoryBreakdown}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={80}
                          paddingAngle={5}
                          dataKey="value"
                        >
                          {analytics.categoryBreakdown?.map((entry: any, index: number) => (
                            <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`$${value}`, 'Category Share']} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>

                  <div class="space-y-1.5">
                    {analytics.categoryBreakdown?.map((item: any, idx: number) => (
                      <div key={item.name} class="flex justify-between items-center text-xs font-mono">
                        <div class="flex items-center gap-1.5">
                          <span class="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[idx % COLORS.length] }}></span>
                          <span class="text-zinc-600">{item.name}</span>
                        </div>
                        <span class="font-bold text-zinc-900">${item.value}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Quick-Stats List */}
          <div class="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
            <div class="p-6 bg-zinc-50 border border-zinc-200 rounded-lg space-y-4">
              <h4 class="font-display font-semibold text-sm text-zinc-900 flex items-center gap-2">
                <Database class="w-4 h-4 text-zinc-800" />
                Frequently Searched Printers Compatibility
              </h4>
              <div class="space-y-2 text-xs font-mono">
                {[
                  { model: "HP LaserJet Pro M404dn", hits: 342, matchSKU: "CF259X" },
                  { model: "Canon PIXMA TS6350a", hits: 201, matchSKU: "PGI-580" },
                  { model: "Brother HL-L2350DW", hits: 148, matchSKU: "TN-2420" },
                  { model: "Epson EcoTank ET-2810", hits: 96, matchSKU: "Epson 104" }
                ].map((item, idx) => (
                  <div key={item.model} class="flex justify-between items-center p-2 bg-white border border-zinc-150 rounded">
                    <span class="text-zinc-700">{idx+1}. {item.model}</span>
                    <div class="flex items-center gap-2">
                      <span class="text-[10px] bg-zinc-100 text-zinc-500 px-2 py-0.5 rounded">SKU: {item.matchSKU}</span>
                      <span class="font-bold text-zinc-900">{item.hits} searches</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div class="p-6 bg-zinc-50 border border-zinc-200 rounded-lg space-y-4">
              <h4 class="font-display font-semibold text-sm text-zinc-900 flex items-center gap-2">
                <Users class="w-4 h-4 text-zinc-800" />
                Corporate Purchasing Engagement
              </h4>
              <div class="space-y-4 text-xs font-mono">
                <div class="grid grid-cols-2 gap-4">
                  <div class="bg-white p-3 border border-zinc-150 rounded">
                    <p class="text-[10px] text-zinc-400">RETURNING CLIENT RATE</p>
                    <p class="text-lg font-bold">34.5%</p>
                  </div>
                  <div class="bg-white p-3 border border-zinc-150 rounded">
                    <p class="text-[10px] text-zinc-400">MONTHLY ACCOUNTS DISPATCHED</p>
                    <p class="text-lg font-bold">2 active partners</p>
                  </div>
                </div>
                <p class="text-[11px] text-zinc-500 font-light leading-relaxed">
                  Bulk business accounts representing schools and corporate offices provide stable logistics recurring volumes, offsetting seasonal home printing drops.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CATALOG & INVENTORY MANAGEMENT */}
      {activeSubTab === "inventory" && (
        <div class="space-y-8">
          
          {/* CSV Bulk uploader view */}
          <div class="p-6 bg-white border border-zinc-200 rounded-lg space-y-4">
            <div class="flex justify-between items-start">
              <div>
                <h3 class="font-display font-semibold text-sm text-zinc-900 flex items-center gap-1.5">
                  <Upload class="w-4 h-4 text-zinc-800" />
                  Enterprise Bulk CSV Importer Terminal
                </h3>
                <p class="text-xs text-zinc-400">Bulk upload entire product listings directly with compatibility mapping variables.</p>
              </div>
              <button 
                type="button" 
                onClick={loadSampleCsv}
                class="text-xs font-mono text-zinc-500 hover:text-zinc-950 underline"
              >
                Insert Verified Demo CSV
              </button>
            </div>

            <div class="space-y-3">
              <textarea
                value={csvText}
                onChange={(e) => setCsvText(e.target.value)}
                placeholder="sku,name,manufacturer,category,stockQuantity,price,estimatedPageYield,costPerPage,color,isCompatible,isXL,isMultipack,compatiblePrinters"
                rows={4}
                class="w-full bg-zinc-50 border border-zinc-200 p-3 text-xs font-mono rounded-md focus:outline-none focus:border-zinc-950"
              />
              
              <button
                onClick={handleCsvImport}
                disabled={isImportingCsv || !csvText.trim()}
                class="px-4 py-2 bg-zinc-950 hover:bg-zinc-900 disabled:bg-zinc-200 text-white text-xs font-mono uppercase tracking-wider font-semibold rounded-md flex items-center gap-1.5 transition-all"
              >
                {isImportingCsv ? "Parsing Records..." : "Process CSV Database"}
              </button>
            </div>
          </div>

          {/* Active SKU table */}
          <div class="bg-white border border-zinc-200 rounded-lg overflow-hidden">
            <div class="p-4 border-b border-zinc-200 flex justify-between items-center bg-zinc-50">
              <h3 class="text-xs font-mono font-bold tracking-wider text-zinc-500 uppercase">ACTIVE CATALOG PRODUCTS ({products.length} REGISTERS)</h3>
              <span class="text-[10px] text-zinc-400">Draft, Scheduled and Published SKUs included</span>
            </div>

            <div class="overflow-x-auto font-mono text-xs">
              <table class="w-full text-left border-collapse">
                <thead>
                  <tr class="bg-zinc-100 text-zinc-500 text-[10px] border-b border-zinc-200">
                    <th class="p-3">SKU</th>
                    <th class="p-3">PRODUCT DETAILS</th>
                    <th class="p-3">STOCK QUANTITY</th>
                    <th class="p-3">DTC PRICE</th>
                    <th class="p-3">PAGE YIELD</th>
                    <th class="p-3">STATUS</th>
                    <th class="p-3 text-right">OPERATIONS</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-zinc-200">
                  {products.map(p => (
                    <tr key={p.id} class="hover:bg-zinc-50">
                      <td class="p-3 font-semibold text-zinc-950">{p.sku}</td>
                      <td class="p-3 space-y-0.5 max-w-sm">
                        <p class="font-bold text-zinc-900 line-clamp-1">{p.name}</p>
                        <p class="text-[10px] text-zinc-400">{p.category} | {p.manufacturer} | {p.color}</p>
                      </td>
                      <td class="p-3">
                        <span class={`font-bold ${p.stockQuantity <= 15 ? "text-amber-600 font-extrabold" : "text-zinc-700"}`}>
                          {p.stockQuantity} units
                        </span>
                      </td>
                      <td class="p-3 font-bold">${p.salePrice || p.price}</td>
                      <td class="p-3">{p.estimatedPageYield.toLocaleString()} pgs</td>
                      <td class="p-3">
                        <span class={`px-2 py-0.5 rounded text-[9px] font-bold tracking-wider ${
                          p.status === ProductStatus.Published ? "bg-emerald-100 text-emerald-900" :
                          p.status === ProductStatus.Draft ? "bg-zinc-100 text-zinc-600" :
                          p.status === ProductStatus.Archived ? "bg-rose-100 text-rose-950" : "bg-blue-100 text-blue-900"
                        }`}>
                          {p.status}
                        </span>
                      </td>
                      <td class="p-3 text-right space-x-1.5 whitespace-nowrap">
                        <button 
                          onClick={() => onProductDuplicated(p)}
                          class="p-1 hover:bg-zinc-100 border border-zinc-200 rounded text-zinc-600"
                          title="Duplicate SKU"
                        >
                          <Copy class="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => onProductUpdated({ ...p, status: p.status === ProductStatus.Published ? ProductStatus.Hidden : ProductStatus.Published })}
                          class="p-1 hover:bg-zinc-100 border border-zinc-200 rounded text-zinc-600"
                          title="Toggle Visbility"
                        >
                          <Eye class="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => onProductArchived(p.id)}
                          class="p-1 hover:bg-zinc-100 border border-zinc-200 rounded text-rose-600"
                          title="Archive SKU"
                        >
                          <Trash2 class="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* FULFILLMENT ORDERS MANAGEMENT */}
      {activeSubTab === "orders" && (
        <div class="space-y-6">
          <div class="bg-white border border-zinc-200 rounded-lg overflow-hidden">
            <div class="p-4 border-b border-zinc-200 bg-zinc-50 flex justify-between items-center font-mono">
              <span class="text-xs font-bold tracking-wider text-zinc-500 uppercase">SYSTEM FREIGHT DISPATCH INVOICES</span>
              <span class="text-[10px] text-emerald-600 font-bold">Mempool Monitor Listening Active</span>
            </div>

            <div class="overflow-x-auto font-mono text-xs">
              <table class="w-full text-left border-collapse">
                <thead>
                  <tr class="bg-zinc-100 text-zinc-500 text-[10px] border-b border-zinc-200">
                    <th class="p-3">ORDER REFERENCE</th>
                    <th class="p-3">CONSIGNEE DETAILS</th>
                    <th class="p-3">PRODUCTS TOTAL</th>
                    <th class="p-3">METHOD</th>
                    <th class="p-3">SETTLED AMOUNT</th>
                    <th class="p-3">DISPATCH STATUS</th>
                    <th class="p-3 text-right">FULFILLMENT DISPATCH</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-zinc-200">
                  {orders.map(o => (
                    <tr key={o.id} class="hover:bg-zinc-50">
                      <td class="p-3 font-semibold text-zinc-950">
                        {o.orderReference}
                        <p class="text-[9px] text-zinc-400 font-normal">{new Date(o.timestamp).toLocaleString()}</p>
                      </td>
                      <td class="p-3 space-y-0.5">
                        <p class="font-bold text-zinc-900">{o.customerName}</p>
                        <p class="text-[10px] text-zinc-400">{o.customerEmail}</p>
                        <p class="text-[9px] text-zinc-400 line-clamp-1">{o.shippingAddress.street}, {o.shippingAddress.city}</p>
                      </td>
                      <td class="p-3 font-semibold">{o.items.reduce((s, i) => s + i.quantity, 0)} units</td>
                      <td class="p-3">
                        <span class={`px-1.5 py-0.5 rounded text-[10px] font-bold ${o.paymentMethod !== 'Card' ? 'bg-emerald-50 text-emerald-900 border border-emerald-200' : 'bg-zinc-100 text-zinc-700'}`}>
                          {o.paymentMethod}
                        </span>
                      </td>
                      <td class="p-3 font-bold">${o.total}</td>
                      <td class="p-3">
                        <span class={`px-2 py-0.5 rounded text-[9px] font-bold tracking-wider ${
                          o.status === OrderStatus.Paid ? "bg-emerald-100 text-emerald-900" :
                          o.status === OrderStatus.AwaitingPayment ? "bg-amber-100 text-amber-900 animate-pulse" :
                          o.status === OrderStatus.Shipped ? "bg-blue-100 text-blue-900" :
                          o.status === OrderStatus.Cancelled ? "bg-rose-100 text-rose-950" : "bg-purple-100 text-purple-900"
                        }`}>
                          {o.status}
                        </span>
                      </td>
                      <td class="p-3 text-right">
                        <select 
                          value={o.status} 
                          onChange={(e) => onOrderStatusChanged(o.id, e.target.value as OrderStatus)}
                          class="px-2 py-1 border border-zinc-200 rounded text-xs font-mono bg-white focus:outline-none focus:border-zinc-950"
                        >
                          {Object.values(OrderStatus).map(st => (
                            <option key={st} value={st}>{st}</option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CORPORATE CLIENTS */}
      {activeSubTab === "business" && (
        <div class="space-y-6">
          <div class="bg-white border border-zinc-200 rounded-lg overflow-hidden">
            <div class="p-4 border-b border-zinc-200 bg-zinc-50 flex justify-between items-center font-mono">
              <span class="text-xs font-bold tracking-wider text-zinc-500 uppercase">REGISTERED WHOLESALE CLIENT PROFILE DECK</span>
              <span class="text-[10px] text-zinc-400">Net 30/60 Authorized Limits</span>
            </div>

            <div class="overflow-x-auto font-mono text-xs">
              <table class="w-full text-left border-collapse">
                <thead>
                  <tr class="bg-zinc-100 text-zinc-500 text-[10px] border-b border-zinc-200">
                    <th class="p-3">COMPANY NAME</th>
                    <th class="p-3">VAT NUMBER</th>
                    <th class="p-3">AUTHORIZED USERS</th>
                    <th class="p-3">VOLUME DEPRECIATION RATE</th>
                    <th class="p-3">CREDIT LIMIT</th>
                    <th class="p-3">CREDIT EXPENDED</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-zinc-200">
                  {businessAccounts.map(b => (
                    <tr key={b.id} class="hover:bg-zinc-50">
                      <td class="p-3 font-bold text-zinc-950">{b.companyName}</td>
                      <td class="p-3 font-semibold">{b.vatNumber}</td>
                      <td class="p-3">
                        <div class="space-y-0.5">
                          {b.users.map((u, i) => (
                            <p key={i} class="text-[10px] text-zinc-600 font-normal">{u.name} ({u.role}) — {u.email}</p>
                          ))}
                        </div>
                      </td>
                      <td class="p-3 text-emerald-600 font-bold">{(b.volumeDiscountRate * 100).toFixed(0)}% Flat Off</td>
                      <td class="p-3 font-bold">${b.creditLimit?.toLocaleString()}</td>
                      <td class="p-3 font-semibold text-zinc-500">${b.creditUsed?.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* CRYPTO WALLETS ACCOUNTING */}
      {activeSubTab === "wallets" && (
        <div class="space-y-6">
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="p-6 bg-zinc-950 text-white rounded-lg space-y-4 border border-zinc-800">
              <div class="flex justify-between items-center">
                <p class="text-xs font-mono font-bold text-zinc-400">SELF-HOSTED BITCOIN CORE NODE</p>
                <span class="w-2 h-2 bg-emerald-400 rounded-full"></span>
              </div>
              <div class="space-y-1">
                <p class="text-[10px] text-zinc-500">TOTAL BITCOIN ACCUMULATED</p>
                <p class="text-3xl font-mono font-bold text-white">0.00615 BTC</p>
                <p class="text-xs text-zinc-400">~ $399.90 USD settled value</p>
              </div>
              <div class="p-3 bg-zinc-900 border border-zinc-800 rounded text-[10px] space-y-1 text-zinc-400">
                <p><strong>Primary Address:</strong> bc1qxy2kg3ut7u4adrlhskm7mff2q22uhsksh6p79p</p>
                <p><strong>Confirmation Threshold:</strong> 4 Blocks (Automated)</p>
              </div>
            </div>

            <div class="p-6 bg-zinc-950 text-white rounded-lg space-y-4 border border-zinc-800">
              <div class="flex justify-between items-center">
                <p class="text-xs font-mono font-bold text-zinc-400">TETHER USDT INFRASTRUCTURE</p>
                <span class="w-2 h-2 bg-emerald-400 rounded-full"></span>
              </div>
              <div class="space-y-1">
                <p class="text-[10px] text-zinc-500">TOTAL DISPATCHED USDT COINS</p>
                <p class="text-3xl font-mono font-bold text-emerald-500">88.96 USDT</p>
                <p class="text-xs text-zinc-400">TRC20 Tron Network Node active</p>
              </div>
              <div class="p-3 bg-zinc-900 border border-zinc-800 rounded text-[10px] space-y-1 text-zinc-400">
                <p><strong>Primary Address:</strong> TY9m5pUo6b8z7Sg2aDks89bA4vLw8Qh2Tz</p>
                <p><strong>Verification Threshold:</strong> 4 confirmations (TRON API)</p>
              </div>
            </div>
          </div>

          {/* Transaction telemetry table */}
          <div class="bg-white border border-zinc-200 rounded-lg overflow-hidden">
            <div class="p-4 border-b border-zinc-200 bg-zinc-50 font-mono text-xs font-bold text-zinc-500">
              BLOCKCHAIN MEMPOOL DETECTOR REAL-TIME TRANSACTION LOGS
            </div>
            <div class="p-4 space-y-2.5 font-mono text-xs text-zinc-600">
              {orders.filter(o => o.paymentMethod !== "Card").map(o => (
                <div key={o.id} class="p-3 bg-zinc-50 border border-zinc-200 rounded flex justify-between items-center">
                  <div class="space-y-1">
                    <p class="font-bold text-zinc-900">{o.orderReference} — {o.paymentMethod} {o.total}</p>
                    <p class="text-[10px] text-zinc-400">TxID: {o.paymentDetails?.txId || "Awaiting blockchain broadcast..."}</p>
                  </div>
                  <div class="text-right">
                    <span class={`px-2 py-0.5 rounded text-[9px] font-bold ${o.status === OrderStatus.Paid ? "bg-emerald-100 text-emerald-800" : "bg-amber-100 text-amber-800"}`}>
                      {o.status === OrderStatus.Paid ? "VERIFIED & SETTLED" : "CONFIRMING BLOCKCHAIN"}
                    </span>
                    <p class="text-[10px] text-zinc-400 mt-1">Confs: {o.paymentDetails?.confirmations || 0} / 4 required</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* REST API EXPLORER & SANDBOX */}
      {activeSubTab === "api" && (
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 text-xs font-mono text-zinc-700">
          
          {/* Documentation Sidebar */}
          <div class="lg:col-span-5 space-y-4">
            <div class="p-4 bg-zinc-50 border border-zinc-200 rounded-lg">
              <h4 class="font-display font-semibold text-zinc-900 text-sm flex items-center gap-1.5 mb-2">
                <BookOpen class="w-4 h-4 text-zinc-800" />
                REST API v1 Reference
              </h4>
              <p class="text-[11px] text-zinc-500 leading-relaxed font-light">
                InkForge exposes clean, high-fidelity developer APIs enabling corporate procurement managers to script automatic inventory triggers and sync blockchain invoices.
              </p>
            </div>

            <div class="space-y-2">
              {[
                { method: "GET", path: "/api/products", desc: "List catalog items with filtering" },
                { method: "POST", path: "/api/products", desc: "Provision new catalog SKU" },
                { method: "POST", path: "/api/orders", desc: "Submit Direct-to-Consumer checkout" },
                { method: "GET", path: "/api/analytics", desc: "Extract current financial metrics" },
                { method: "POST", path: "/api/gemini/categorize", desc: "AI-powered metadata auto-classifier" }
              ].map(route => (
                <div key={route.path} class="p-2.5 bg-white border border-zinc-200 rounded flex justify-between items-center">
                  <div>
                    <span class={`px-1.5 py-0.5 rounded text-[9px] font-bold tracking-wider mr-2 ${route.method === "GET" ? "bg-blue-100 text-blue-900" : "bg-emerald-100 text-emerald-900"}`}>
                      {route.method}
                    </span>
                    <span class="font-semibold text-zinc-900">{route.path}</span>
                    <p class="text-[10px] text-zinc-400 mt-0.5 font-light">{route.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Interactive Request Tester */}
          <div class="lg:col-span-7 bg-zinc-900 text-zinc-300 rounded-lg p-6 space-y-4 border border-zinc-800 shadow-xl">
            <h4 class="text-white text-sm font-semibold flex items-center gap-1.5 border-b border-zinc-800 pb-3">
              <Terminal class="w-4 h-4 text-emerald-400" />
              Developer API Playground terminal
            </h4>

            {/* Test buttons */}
            <div class="flex flex-wrap gap-2">
              <button 
                onClick={async () => {
                  const res = await fetch("/api/products?category=Toner");
                  const json = await res.json();
                  alert(`GET /api/products?category=Toner\n\nReturned ${json.length} records. Inspect Console logs for raw payload.`);
                  console.log("REST API Response:", json);
                }}
                class="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] rounded border border-zinc-700"
              >
                Test: List Toners
              </button>

              <button 
                onClick={async () => {
                  const res = await fetch("/api/analytics");
                  const json = await res.json();
                  alert(`GET /api/analytics\n\nTotal Settled Revenue: $${json.totalRevenue}. Inspect Console logs for payload.`);
                  console.log("REST API Response:", json);
                }}
                class="px-2.5 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-[10px] rounded border border-zinc-700"
              >
                Test: Fetch Analytics
              </button>
            </div>

            {/* Code visualizer */}
            <div class="space-y-1.5">
              <p class="text-[10px] text-zinc-500 font-bold uppercase">Sample API Curl Command:</p>
              <pre class="p-3 bg-zinc-950 text-emerald-400 rounded text-[10px] overflow-x-auto leading-relaxed border border-zinc-800">
                curl -X POST https://inkforge.co/api/gemini/categorize \<br />
                &nbsp;&nbsp;-H "Content-Type: application/json" \<br />
                &nbsp;&nbsp;-d '&#123;"title": "HP CF259X toner black"&#125;'
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* SYSTEM AUDIT LOGS */}
      {activeSubTab === "audit" && (
        <div class="space-y-4 font-mono text-xs text-zinc-700">
          <div class="p-4 bg-zinc-50 border border-zinc-200 rounded-lg flex items-center gap-2 justify-between">
            <div class="flex items-center gap-2">
              <Shield class="w-4 h-4 text-emerald-600" />
              <span><strong>System Ingress Audit Logs:</strong> Cryptographically logged daemon events</span>
            </div>
            <span class="text-[10px] text-zinc-400">ROLE-BASED READONLY ACCESS</span>
          </div>

          <div class="space-y-2 max-h-[500px] overflow-y-auto pr-2">
            {auditLogs.map(log => (
              <div key={log.id} class="p-3 bg-white border border-zinc-100 rounded flex justify-between items-start gap-4">
                <div class="space-y-1 flex-1">
                  <div class="flex items-center gap-2">
                    <span class="text-[9px] bg-zinc-950 text-white px-1.5 py-0.5 rounded font-bold uppercase tracking-wider">{log.action}</span>
                    <span class="text-[10px] text-zinc-500">{log.user}</span>
                  </div>
                  <p class="text-zinc-700 text-[11px] leading-relaxed font-light">{log.details}</p>
                </div>
                <span class="text-[10px] text-zinc-400 whitespace-nowrap">{new Date(log.timestamp).toLocaleTimeString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PROVISION SKU (CREATE PRODUCT) MODAL */}
      {newProductFormOpen && (
        <div class="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div class="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 space-y-6 text-zinc-950 border border-zinc-200">
            <div class="flex justify-between items-center border-b border-zinc-100 pb-3">
              <h3 class="font-display font-bold text-lg text-zinc-900">Provision New SKU Catalog Register</h3>
              <button onClick={() => { setNewProductFormOpen(false); setAiResult(null); setAiTitle(""); }} class="text-zinc-400 hover:text-zinc-950 font-bold text-lg">✕</button>
            </div>

            {/* AI Assist Box */}
            <div class="p-5 bg-zinc-950 text-white rounded-lg space-y-4 border border-zinc-800">
              <div class="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400">
                <Sparkles class="w-4 h-4 text-emerald-400" />
                GEMINI CLASS-CLASSIFICATION TELEMETRY
              </div>
              <p class="text-[11px] text-zinc-400 leading-relaxed font-light">
                Let Gemini classify the listing automatically. It deduces compatibility printer arrays, exact ISO page yields, colors, and generates optimized hypermodern editorial description text!
              </p>
              
              <div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
                <div class="md:col-span-6 space-y-1">
                  <label class="block text-[9px] font-mono text-zinc-500 uppercase font-bold">Consumable Title Input</label>
                  <input 
                    type="text" 
                    value={aiTitle}
                    onChange={(e) => setAiTitle(e.target.value)}
                    placeholder="e.g. Canon CLI-581XXL multi-color 5-pack" 
                    class="w-full bg-zinc-900 border border-zinc-800 text-white p-2 text-xs font-mono rounded focus:outline-none focus:border-zinc-700" 
                  />
                </div>
                <div class="md:col-span-4 space-y-1">
                  <label class="block text-[9px] font-mono text-zinc-500 uppercase font-bold">Target OEM Manufacturer</label>
                  <select 
                    value={aiManufacturer} 
                    onChange={(e) => setAiManufacturer(e.target.value)}
                    class="w-full bg-zinc-900 border border-zinc-800 text-white p-2.5 text-xs font-mono rounded focus:outline-none focus:border-zinc-700"
                  >
                    {PRINTER_BRANDS.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                </div>
                <div class="md:col-span-2">
                  <button 
                    type="button"
                    onClick={handleGeminiClassify}
                    disabled={isAiLoading}
                    class="w-full py-2 bg-emerald-600 hover:bg-emerald-700 disabled:bg-zinc-800 text-white font-mono text-xs font-bold uppercase rounded transition-all flex items-center justify-center gap-1"
                  >
                    {isAiLoading ? "Mapping..." : "Analyze AI"}
                  </button>
                </div>
              </div>

              {aiResult && (
                <div class="p-3.5 bg-zinc-900 border border-zinc-800 rounded text-[10px] font-mono text-zinc-400 space-y-1">
                  <p class="text-emerald-400 font-bold">✓ AI ANALYSIS COMPLETE (Inputs Filled):</p>
                  <p><strong>Deducted Category:</strong> {aiResult.category}</p>
                  <p><strong>Page Yield:</strong> {aiResult.estimatedPageYield.toLocaleString()} pages</p>
                  <p><strong>Compatible Models:</strong> {aiResult.compatiblePrinters.join(", ")}</p>
                  <p><strong>Color:</strong> {aiResult.color}</p>
                </div>
              )}
            </div>

            {/* Manual Form Fill */}
            <form onSubmit={handleCreateProduct} class="space-y-4 text-xs font-mono text-zinc-700">
              <div class="grid grid-cols-3 gap-4">
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Product SKU</label>
                  <input type="text" required value={sku} onChange={(e) => setSku(e.target.value)} placeholder="IF-59X-COMP" class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Cartridge Code</label>
                  <input type="text" required value={cartridgeNumber} onChange={(e) => setCartridgeNumber(e.target.value)} placeholder="CF259A" class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Price (DTC USD)</label>
                  <input type="text" required value={price} onChange={(e) => setPrice(e.target.value)} placeholder="39.99" class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                </div>
              </div>

              <div class="space-y-1">
                <label class="block text-[10px] text-zinc-400 uppercase">Consumable Descriptive Name</label>
                <input type="text" required value={name} onChange={(e) => setName(e.target.value)} placeholder="HP 59X Compatible High Yield Black Toner" class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
              </div>

              <div class="grid grid-cols-4 gap-4">
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Manufacturer</label>
                  <select value={manufacturer} onChange={(e) => setManufacturer(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded">
                    {PRINTER_BRANDS.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                    <option value="Universal">Universal</option>
                  </select>
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Category</label>
                  <select value={category} onChange={(e) => setCategory(e.target.value as any)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded">
                    <option value="Toner">Toner</option>
                    <option value="Ink Cartridge">Ink Cartridge</option>
                    <option value="Refill Kit">Refill Kit</option>
                    <option value="Office Supplies">Office Supplies</option>
                  </select>
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Color Spec</label>
                  <select value={color} onChange={(e) => setColor(e.target.value as any)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded">
                    <option value="Black">Black</option>
                    <option value="Cyan">Cyan</option>
                    <option value="Magenta">Magenta</option>
                    <option value="Yellow">Yellow</option>
                    <option value="Multi">Multi</option>
                    <option value="None">None</option>
                  </select>
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Initial Stock</label>
                  <input type="number" required value={stockQuantity} onChange={(e) => setStockQuantity(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                </div>
              </div>

              <div class="grid grid-cols-3 gap-4">
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Estimated Page Yield</label>
                  <input type="number" required value={estimatedPageYield} onChange={(e) => setEstimatedPageYield(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Cost Per Page ($)</label>
                  <input type="text" required value={costPerPage} onChange={(e) => setCostPerPage(e.target.value)} class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
                </div>
                <div class="space-y-1">
                  <label class="block text-[10px] text-zinc-400 uppercase">Consumable Sourcing</label>
                  <div class="flex items-center gap-3 h-10">
                    <label class="flex items-center gap-1.5 cursor-pointer">
                      <input type="radio" checked={isCompatible} onChange={() => setIsCompatible(true)} class="accent-zinc-950" />
                      <span>Compatible</span>
                    </label>
                    <label class="flex items-center gap-1.5 cursor-pointer">
                      <input type="radio" checked={!isCompatible} onChange={() => setIsCompatible(false)} class="accent-zinc-950" />
                      <span>OEM Original</span>
                    </label>
                  </div>
                </div>
              </div>

              <div class="space-y-1">
                <label class="block text-[10px] text-zinc-400 uppercase">Compatible Printers (Comma separated)</label>
                <input type="text" required value={compatiblePrintersInput} onChange={(e) => setCompatiblePrintersInput(e.target.value)} placeholder="HP LaserJet Pro M404dn, HP LaserJet Pro M404dw" class="w-full bg-zinc-50 border border-zinc-200 p-2 text-xs rounded" />
              </div>

              <div class="space-y-1">
                <label class="block text-[10px] text-zinc-400 uppercase">Editorial Technical Description</label>
                <textarea required value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="Sourced directly from ISO-9001 certified production..." class="w-full bg-zinc-50 border border-zinc-200 p-2.5 text-xs rounded" />
              </div>

              <div class="pt-4 border-t border-zinc-100 flex justify-end gap-3">
                <button type="button" onClick={() => { setNewProductFormOpen(false); setAiResult(null); setAiTitle(""); }} class="px-4 py-2 border border-zinc-200 rounded text-zinc-500 hover:bg-zinc-50">
                  Dismiss
                </button>
                <button type="submit" class="px-5 py-2 bg-zinc-950 hover:bg-zinc-900 text-white rounded font-bold uppercase tracking-wider">
                  Discharge & Publish SKU
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
