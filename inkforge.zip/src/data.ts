import { Product, ProductStatus, PrinterModel, Order, OrderStatus, BusinessAccount, Review } from "./types";

export const PRINTER_BRANDS = ["HP", "Canon", "Epson", "Brother", "Xerox", "Lexmark"];

export const INITIAL_PRINTERS: PrinterModel[] = [
  {
    id: "p1",
    manufacturer: "HP",
    model: "LaserJet Pro M404dn",
    productNumber: "W1A53A",
    cartridgeNumber: "CF259A",
    tonerNumber: "CF259X",
    barcode: "192018883652",
    imageUrl: "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "p2",
    manufacturer: "HP",
    model: "OfficeJet Pro 9015e",
    productNumber: "1G5L3B",
    cartridgeNumber: "HP 963",
    tonerNumber: "HP 963XL",
    barcode: "195122497672",
    imageUrl: "https://images.unsplash.com/photo-1552308995-2b39865b312a?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "p3",
    manufacturer: "Brother",
    model: "HL-L2350DW Compact",
    productNumber: "HLL2350DW",
    cartridgeNumber: "TN-2410",
    tonerNumber: "TN-2420",
    barcode: "4977766782357",
    imageUrl: "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "p4",
    manufacturer: "Canon",
    model: "PIXMA TS6350a",
    productNumber: "3774C048",
    cartridgeNumber: "PGI-580",
    tonerNumber: "CLI-581XXL",
    barcode: "4549292193152",
    imageUrl: "https://images.unsplash.com/photo-1552308995-2b39865b312a?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "p5",
    manufacturer: "Epson",
    model: "EcoTank ET-2810",
    productNumber: "C11CJ67401",
    cartridgeNumber: "Epson 104",
    tonerNumber: "Epson 104",
    barcode: "8715946684703",
    imageUrl: "https://images.unsplash.com/photo-1552308995-2b39865b312a?auto=format&fit=crop&q=80&w=200"
  },
  {
    id: "p6",
    manufacturer: "Brother",
    model: "MFC-L3750CDW Color Laser",
    productNumber: "MFCL3750CDW",
    cartridgeNumber: "TN-243",
    tonerNumber: "TN-247",
    barcode: "4977766790116"
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "prod-1",
    sku: "IF-59X-COMP",
    name: "HP 59X (CF259X) High Yield Compatible Black Toner Cartridge",
    manufacturer: "HP",
    compatiblePrinters: ["HP LaserJet Pro M404dn", "HP LaserJet Pro M404dw", "HP LaserJet Pro MFP M428fdn"],
    cartridgeNumber: "CF259A",
    oemReference: "CF259X",
    color: "Black",
    capacity: "220g",
    estimatedPageYield: 10000,
    costPerPage: 0.0059, // $0.0059 per page
    images: [
      "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=600"
    ],
    description: "Our high-yield InkForge compatible CF259X Black Toner Cartridge is engineered with extreme precision to match original equipment manufacturer quality, offering crisp monochrome output and a massive 10,000-page yield. Features a pre-installed, state-of-the-art smart-reporting microchip for real-time toner level telemetry on your enterprise network.",
    installationGuide: "1. Turn off your printer and open the front access door.\n2. Extract the spent toner assembly from the track.\n3. Pull the orange safety tab to remove the photosensitive drum shield.\n4. Gently rock the cartridge side to side five times to distribute toner particles.\n5. Slide the new InkForge cartridge firmly into place until it clicks.\n6. Close the printer door, boot up, and perform a calibration print.",
    pdfDocumentationUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
    videoUrl: "https://www.w3.org/2010/05/video/media/movie_300.webm",
    stockQuantity: 142,
    price: 59.99,
    salePrice: 49.99,
    bulkPricing: [
      { quantity: 3, price: 44.99 },
      { quantity: 10, price: 39.99 }
    ],
    status: ProductStatus.Published,
    category: "Toner",
    isCompatible: true,
    isXL: true,
    isMultipack: false,
    rating: 4.8,
    reviewsCount: 34
  },
  {
    id: "prod-2",
    sku: "IF-963XL-4PK",
    name: "HP 963XL Compatible High Yield Ink Cartridge Multipack - 4 Colors",
    manufacturer: "HP",
    compatiblePrinters: ["HP OfficeJet Pro 9015e", "HP OfficeJet Pro 9010", "HP OfficeJet Pro 9020"],
    cartridgeNumber: "HP 963",
    oemReference: "3YP35AE",
    color: "Multi",
    capacity: "80ml Total",
    estimatedPageYield: 2000,
    costPerPage: 0.0195,
    images: [
      "https://images.unsplash.com/photo-1552308995-2b39865b312a?auto=format&fit=crop&q=80&w=600"
    ],
    description: "A complete professional solution for business ink jets. Contains High-Yield Black, Cyan, Magenta, and Yellow compatible cartridges. Formulated with fast-drying pigment ink for laser-like document resilience, fade resistance, and smooth color transitions.",
    installationGuide: "1. Power on printer and open carriage access panel.\n2. Depress the top lever of the depleted cartridge and pull upwards.\n3. Remove the sealed protective wrap from the InkForge replacement cartridge.\n4. Do not touch the copper electrical contact point or nozzle.\n5. Insert the replacement at a slight angle and push down until secure.\n6. Let the printer complete its initialization cycle.",
    pdfDocumentationUrl: "https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf",
    stockQuantity: 84,
    price: 39.99,
    bulkPricing: [
      { quantity: 2, price: 36.99 },
      { quantity: 5, price: 32.99 }
    ],
    status: ProductStatus.Published,
    category: "Ink Cartridge",
    isCompatible: true,
    isXL: true,
    isMultipack: true,
    rating: 4.9,
    reviewsCount: 19
  },
  {
    id: "prod-3",
    sku: "IF-TN2420-COMP",
    name: "Brother TN-2420 High Yield Compatible Black Toner Cartridge",
    manufacturer: "Brother",
    compatiblePrinters: ["Brother HL-L2350DW Compact", "Brother HL-L2370DN", "Brother MFC-L2710DW"],
    cartridgeNumber: "TN-2410",
    oemReference: "TN-2420",
    color: "Black",
    capacity: "3000 pages",
    estimatedPageYield: 3000,
    costPerPage: 0.0099,
    images: [
      "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=600"
    ],
    description: "Highly optimized replacement toner cartridge delivering crisp, deep black text and smooth line arts. Seamless integration with Brother drum assemblies for industrial-level printing speeds.",
    installationGuide: "1. Pull down the front cover of the printer.\n2. Extract the drum unit assembly.\n3. Push down the green lock lever and take the spent toner cartridge out of the drum unit.\n4. Unpack the new cartridge and shake it side-to-side.\n5. Push the new toner cartridge firmly into the drum unit until it locks.\n6. Clean the primary corona wire inside the drum by gently sliding the green tab.\n7. Reinsert the whole assembly into the printer and close the door.",
    stockQuantity: 230,
    price: 29.99,
    salePrice: 24.99,
    bulkPricing: [
      { quantity: 5, price: 21.99 }
    ],
    status: ProductStatus.Published,
    category: "Toner",
    isCompatible: true,
    isXL: true,
    isMultipack: false,
    rating: 4.7,
    reviewsCount: 52
  },
  {
    id: "prod-4",
    sku: "IF-580-581-6PK",
    name: "Canon PGI-580 / CLI-581 XXL Compatible Premium Chroma Ink - 6 Pack",
    manufacturer: "Canon",
    compatiblePrinters: ["Canon PIXMA TS6350a", "Canon PIXMA TS8350", "Canon PIXMA TR8550"],
    cartridgeNumber: "PGI-580",
    oemReference: "6541B009",
    color: "Multi",
    capacity: "120ml Total",
    estimatedPageYield: 800,
    costPerPage: 0.043,
    images: [
      "https://images.unsplash.com/photo-1552308995-2b39865b312a?auto=format&fit=crop&q=80&w=600"
    ],
    description: "Ultimate photo-quality replacement ink pack for Canon PIXMA devices. Includes Pigment Black, Dye Black, Cyan, Magenta, Yellow, and Photo Blue. Specially formulated for wide-gamut high contrast prints and vibrant architectural illustrations.",
    installationGuide: "1. Turn printer on, open scan cover.\n2. Wait for the carriage to glide into center alignment.\n3. Remove the orange protective cap by pulling the tab.\n4. Insert the ink tank into correct slot based on color label.\n5. Press down until the integrated LED status light illuminates steadily.\n6. Close cover and run printhead alignment.",
    stockQuantity: 41,
    price: 34.99,
    bulkPricing: [
      { quantity: 3, price: 31.99 }
    ],
    status: ProductStatus.Published,
    category: "Ink Cartridge",
    isCompatible: true,
    isXL: true,
    isMultipack: true,
    rating: 4.6,
    reviewsCount: 22
  },
  {
    id: "prod-5",
    sku: "OEM-TN247-CY",
    name: "Brother TN-247C Original Manufacturer Cyan Toner Cartridge",
    manufacturer: "Brother",
    compatiblePrinters: ["Brother MFC-L3750CDW Color Laser", "Brother HL-L3230CDW"],
    cartridgeNumber: "TN-243",
    oemReference: "TN-247C",
    color: "Cyan",
    capacity: "2300 pages",
    estimatedPageYield: 2300,
    costPerPage: 0.034,
    images: [
      "https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=600"
    ],
    description: "Genuine OEM Brother high yield cyan toner cartridge. Formulated specifically to Brother specifications, ensuring flawless color matching, consistent density, and protection of delicate mechanical laser components.",
    installationGuide: "Unpack and insert into the Brother drum assembly track.",
    stockQuantity: 15,
    price: 79.99,
    status: ProductStatus.Published,
    category: "Toner",
    isCompatible: false, // OEM
    isXL: true,
    isMultipack: false,
    rating: 4.9,
    reviewsCount: 8
  },
  {
    id: "prod-6",
    sku: "IF-UNIV-REFILL-K",
    name: "InkForge Advanced Universal Refill Kit with Syringes & Ink - 4x100ml",
    manufacturer: "Epson",
    compatiblePrinters: ["Epson EcoTank ET-2810", "Canon PIXMA TS6350a", "HP OfficeJet Pro 9015e"],
    cartridgeNumber: "Epson 104",
    oemReference: "UNIV-REFILL",
    color: "Multi",
    capacity: "400ml",
    estimatedPageYield: 8000,
    costPerPage: 0.0024,
    images: [
      "https://images.unsplash.com/photo-1552308995-2b39865b312a?auto=format&fit=crop&q=80&w=600"
    ],
    description: "The eco-conscious, high-efficiency direct refill system. Comprises 100ml bottles of premium InkForge formula in Black, Cyan, Magenta, and Yellow. Bundled with 4 blunt-tip medical-grade syringes, suction clips, and step-by-step instructions for refilling cartridges or reservoir-based ink systems directly.",
    installationGuide: "1. Wear the included protective latex-free gloves.\n2. Locate the filler port on your cartridge (drill a tiny hole under the label if necessary) or open your reservoir cap.\n3. Draw the exact required volume of ink into the designated syringe.\n4. Insert the blunt needle into the sponge core at a 45-degree angle.\n5. Depress the syringe plunger slowly (approx 1ml per 5 seconds).\n6. Seal the port with the provided silicon plugs and let it rest.",
    stockQuantity: 110,
    price: 19.99,
    bulkPricing: [
      { quantity: 2, price: 17.99 }
    ],
    status: ProductStatus.Published,
    category: "Refill Kit",
    isCompatible: true,
    isXL: false,
    isMultipack: true,
    rating: 4.5,
    reviewsCount: 65
  },
  {
    id: "prod-7",
    sku: "IF-OFFICE-WIPES",
    name: "InkForge Anti-Static Printer Head & Laser Optics Lint-Free Wipes",
    manufacturer: "Universal",
    compatiblePrinters: ["All Laser Printers", "All Inkjet Printers"],
    cartridgeNumber: "NONE",
    oemReference: "IF-WIPES-100",
    color: "None",
    capacity: "100 Pack",
    estimatedPageYield: 0,
    costPerPage: 0,
    images: [
      "https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&q=80&w=600"
    ],
    description: "Sealed anti-static, pure isopropyl alcohol lint-free micro-cloths. Specially calibrated for safe cleaning of direct thermal printheads, ink jets nozzle tracks, and laser drum optical glass arrays.",
    installationGuide: "Gently wipe contacts or printheads in a single directional stroke. Allow to air dry for 30 seconds before reassembling.",
    stockQuantity: 400,
    price: 12.49,
    salePrice: 9.99,
    status: ProductStatus.Published,
    category: "Office Supplies",
    isCompatible: true,
    isXL: false,
    isMultipack: false,
    rating: 4.7,
    reviewsCount: 104
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: "r1",
    customerName: "Nathaniel Vance",
    rating: 5,
    comment: "The page yield on the compatible 59X is incredible. Got 10,240 pages on our warehouse shipping printer before seeing a low toner indicator. The chip worked instantly on our network.",
    date: "2026-06-12",
    verifiedPurchase: true
  },
  {
    id: "r2",
    customerName: "Dr. Amanda Albright",
    rating: 5,
    comment: "Excellent color matching for photo portfolios. Canon compatible tanks worked flawlessly, saving us almost 60% compared to typical supplier markups. Highly recommended.",
    date: "2026-07-02",
    verifiedPurchase: true
  },
  {
    id: "r3",
    customerName: "Marcus Sterling (Tech Solutions)",
    rating: 4,
    comment: "Excellent merchant. High-fidelity developer APIs and native USDT TRC20 payments make it ideal for automated office expense workflows.",
    date: "2026-07-10",
    verifiedPurchase: true
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: "ord-101",
    orderReference: "IF-98231-BTC",
    timestamp: "2026-07-14T14:24:00Z",
    customerName: "Nakamoto Holdings LLC",
    customerEmail: "finance@nakamoto.io",
    shippingAddress: {
      street: "21 Block Heights",
      city: "Austin",
      state: "TX",
      postalCode: "78701",
      country: "United States"
    },
    items: [
      {
        productId: "prod-1",
        name: "HP 59X (CF259X) High Yield Compatible Black Toner Cartridge",
        sku: "IF-59X-COMP",
        quantity: 10,
        price: 39.99
      }
    ],
    subtotal: 399.90,
    shippingCost: 0,
    total: 399.90,
    status: OrderStatus.Paid,
    paymentMethod: "BTC",
    paymentDetails: {
      cryptoAddress: "bc1qxy2kg3ut7u4adrlhskm7mff2q22uhsksh6p79p",
      cryptoAmount: 0.00615,
      cryptoRate: 65000,
      network: "Bitcoin Mainnet",
      txId: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
      confirmations: 6,
      countdown: 0
    }
  },
  {
    id: "ord-102",
    orderReference: "IF-98232-USDT",
    timestamp: "2026-07-15T08:12:00Z",
    customerName: "Jane Doe (DTC Logistics)",
    customerEmail: "jane@dtclogistics.com",
    shippingAddress: {
      street: "100 Port Side Way",
      city: "Seattle",
      state: "WA",
      postalCode: "98101",
      country: "United States"
    },
    businessVat: "US98271822",
    items: [
      {
        productId: "prod-2",
        name: "HP 963XL Compatible High Yield Ink Cartridge Multipack - 4 Colors",
        sku: "IF-963XL-4PK",
        quantity: 2,
        price: 36.99
      },
      {
        productId: "prod-7",
        name: "InkForge Anti-Static Printer Head & Laser Optics Lint-Free Wipes",
        sku: "IF-OFFICE-WIPES",
        quantity: 1,
        price: 9.99
      }
    ],
    subtotal: 83.97,
    shippingCost: 4.99,
    total: 88.96,
    status: OrderStatus.AwaitingPayment,
    paymentMethod: "USDT",
    paymentDetails: {
      cryptoAddress: "TY9m5pUo6b8z7Sg2aDks89bA4vLw8Qh2Tz",
      cryptoAmount: 88.96,
      cryptoRate: 1,
      network: "TRC20 (Tron)",
      countdown: 840
    }
  },
  {
    id: "ord-103",
    orderReference: "IF-98233-CARD",
    timestamp: "2026-07-15T09:30:00Z",
    customerName: "Alex Mercer",
    customerEmail: "alex@mercerdesign.co",
    shippingAddress: {
      street: "505 Grid Plaza Apt 4B",
      city: "New York",
      state: "NY",
      postalCode: "10003",
      country: "United States"
    },
    items: [
      {
        productId: "prod-3",
        name: "Brother TN-2420 High Yield Compatible Black Toner Cartridge",
        sku: "IF-TN2420-COMP",
        quantity: 1,
        price: 24.99
      }
    ],
    subtotal: 24.99,
    shippingCost: 4.99,
    total: 29.98,
    status: OrderStatus.Picking,
    paymentMethod: "Card"
  }
];

export const INITIAL_BUSINESS_ACCOUNTS: BusinessAccount[] = [
  {
    id: "bus-1",
    companyName: "Vanguard Tech Academy",
    vatNumber: "GB98231221",
    contactEmail: "purchasing@vanguardtech.edu",
    creditLimit: 5000.00,
    creditUsed: 1250.00,
    volumeDiscountRate: 0.15, // 15% automatic discount
    users: [
      { name: "Robert Chen", email: "rchen@vanguardtech.edu", role: "Admin" },
      { name: "Sarah Jenkins", email: "sjenkins@vanguardtech.edu", role: "Buyer" }
    ],
    purchaseOrders: ["PO-2026-004", "PO-2026-009"],
    monthlyStatements: [
      { month: "June 2026", amount: 620.00, paid: true },
      { month: "July 2026", amount: 1250.00, paid: false }
    ]
  },
  {
    id: "bus-2",
    companyName: "Horizon Architecture Partners",
    vatNumber: "US5849102",
    contactEmail: "ops@horizonpartners.com",
    creditLimit: 3000.00,
    creditUsed: 450.00,
    volumeDiscountRate: 0.10, // 10%
    users: [
      { name: "Linda Sterling", email: "linda@horizonpartners.com", role: "Admin" }
    ],
    purchaseOrders: ["PO-HORIZON-99"],
    monthlyStatements: [
      { month: "June 2026", amount: 450.00, paid: true }
    ]
  }
];
