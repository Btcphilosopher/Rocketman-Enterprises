import React, { useState, useEffect } from "react";
import { 
  INITIAL_PRODUCTS, INITIAL_PRINTERS, INITIAL_ORDERS, INITIAL_BUSINESS_ACCOUNTS 
} from "./data";
import { 
  Product, ProductStatus, PrinterModel, Order, OrderStatus, BusinessAccount, AuditLog 
} from "./types";
import Storefront from "./components/Storefront";
import Dashboard from "./components/Dashboard";
import { Terminal, Shield, RefreshCw } from "lucide-react";

export default function App() {
  // Navigation: customer vs seller
  const [portalMode, setPortalMode] = useState<"customer" | "seller">("customer");

  // Core App states (synced from Express Server)
  const [products, setProducts] = useState<Product[]>([]);
  const [printers, setPrinters] = useState<PrinterModel[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [businessAccounts, setBusinessAccounts] = useState<BusinessAccount[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  // Sync all core records from REST APIs
  const syncDatabase = async () => {
    try {
      const pRes = await fetch("/api/products");
      const prRes = await fetch("/api/printers");
      const oRes = await fetch("/api/orders");
      const bRes = await fetch("/api/business-accounts");
      const aRes = await fetch("/api/audit-logs");

      if (pRes.ok) setProducts(await pRes.json());
      if (prRes.ok) setPrinters(await prRes.json());
      if (oRes.ok) setOrders(await oRes.json());
      if (bRes.ok) setBusinessAccounts(await bRes.json());
      if (aRes.ok) setAuditLogs(await aRes.json());
      
      setLoading(false);
    } catch (err) {
      console.warn("Failed to reach REST API server. Initializing safe memory fallbacks.", err);
      // Fallback to initial local dataset if server is not fully booted or responding yet
      setProducts(INITIAL_PRODUCTS);
      setPrinters(INITIAL_PRINTERS);
      setOrders(INITIAL_ORDERS);
      setBusinessAccounts(INITIAL_BUSINESS_ACCOUNTS);
      setAuditLogs([
        {
          id: "log-offline",
          timestamp: new Date().toISOString(),
          user: "Local Client",
          action: "Local Fallback Loaded",
          details: "Storefront is running in safe offline memory-mode. Connect full-stack Express endpoints to synchronize with server state."
        }
      ]);
      setLoading(false);
    }
  };

  useEffect(() => {
    syncDatabase();
    // Poll blockchain states every 15 seconds to simulate node mempool confirmations!
    const timer = setInterval(() => {
      fetch("/api/blockchain-check")
        .then(res => {
          if (res.ok) {
            // refresh data if updates were processed
            return fetch("/api/orders")
              .then(o => o.json())
              .then(updatedOrders => setOrders(updatedOrders));
          }
        })
        .catch(err => {});
    }, 15000);

    return () => clearInterval(timer);
  }, []);

  // Creation/Modification Operations mapped with API synchronizations
  const handleProductCreated = (newP: Product) => {
    setProducts(prev => [newP, ...prev]);
    // Append to audit logs local representation as well
    syncDatabase();
  };

  const handleProductUpdated = async (updatedP: Product) => {
    try {
      const res = await fetch(`/api/products/${updatedP.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedP)
      });
      if (res.ok) {
        syncDatabase();
      }
    } catch (err) {
      setProducts(prev => prev.map(p => p.id === updatedP.id ? updatedP : p));
    }
  };

  const handleProductDuplicated = async (originalP: Product) => {
    try {
      const res = await fetch(`/api/products/${originalP.id}/duplicate`, {
        method: "POST"
      });
      if (res.ok) {
        syncDatabase();
      }
    } catch (err) {
      const duplicated: Product = {
        ...originalP,
        id: `prod-${Date.now()}`,
        sku: `${originalP.sku}-COPY-${Math.floor(Math.random() * 100)}`,
        name: `${originalP.name} (Duplicate)`,
        status: ProductStatus.Draft
      };
      setProducts(prev => [duplicated, ...prev]);
    }
  };

  const handleProductArchived = async (id: string) => {
    try {
      const res = await fetch(`/api/products/${id}`, {
        method: "DELETE"
      });
      if (res.ok) {
        syncDatabase();
      }
    } catch (err) {
      setProducts(prev => prev.map(p => p.id === id ? { ...p, status: ProductStatus.Archived } : p));
    }
  };

  const handleOrderStatusChanged = async (id: string, nextStatus: OrderStatus) => {
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res.ok) {
        syncDatabase();
      }
    } catch (err) {
      setOrders(prev => prev.map(o => o.id === id ? { ...o, status: nextStatus } : o));
    }
  };

  const handleOrderCreated = (newOrder: Order) => {
    setOrders(prev => [newOrder, ...prev]);
    syncDatabase();
  };

  const handleRegisterBusiness = async (companyName: string, email: string, vat: string) => {
    try {
      const res = await fetch("/api/business-accounts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyName, contactEmail: email, vatNumber: vat })
      });
      if (res.ok) {
        syncDatabase();
      }
    } catch (err) {
      const newAcc: BusinessAccount = {
        id: `bus-${Date.now()}`,
        companyName,
        vatNumber: vat,
        contactEmail: email,
        creditLimit: 3000,
        creditUsed: 0,
        volumeDiscountRate: 0.10,
        users: [{ name: "Corporate Admin", email, role: "Admin" }],
        purchaseOrders: [],
        monthlyStatements: []
      };
      setBusinessAccounts(prev => [...prev, newAcc]);
    }
  };

  const handleBulkCsvImport = (count: number) => {
    syncDatabase();
  };

  if (loading) {
    return (
      <div class="min-h-screen bg-[#fafafa] flex flex-col items-center justify-center space-y-4 font-mono text-xs">
        <RefreshCw class="w-6 h-6 text-zinc-950 animate-spin" />
        <p class="text-zinc-500 uppercase tracking-widest">Waking InkForge Full-Stack Server Daemon...</p>
      </div>
    );
  }

  return (
    <div class="min-h-screen bg-[#fafafa]">
      
      {/* Top Engineering Controller Switch */}
      <div class="bg-zinc-950 text-white py-2 px-4 border-b border-zinc-800 text-xs font-mono">
        <div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
          <div class="flex items-center gap-2.5">
            <span class="inline-block w-2 h-2 bg-emerald-400 rounded-full animate-ping"></span>
            <span class="text-zinc-400">HOST INTEGRATION ACTIVE</span>
            <span class="text-zinc-600">|</span>
            <span class="text-zinc-400">MODE:</span>
            <span class="text-emerald-400 font-bold uppercase">{portalMode} PORTAL</span>
          </div>

          <div class="flex items-center gap-4">
            <span class="text-zinc-600 hidden sm:inline">DEVELOPER SWITCHBOARD:</span>
            <div class="flex bg-zinc-900 border border-zinc-800 rounded p-0.5">
              <button 
                onClick={() => setPortalMode("customer")}
                class={`px-3 py-1 rounded text-[10px] uppercase font-bold tracking-wider transition-all ${portalMode === "customer" ? "bg-zinc-800 text-white border border-zinc-700 shadow-sm" : "text-zinc-400 hover:text-white"}`}
              >
                Customer Storefront
              </button>
              <button 
                onClick={() => setPortalMode("seller")}
                class={`px-3 py-1 rounded text-[10px] uppercase font-bold tracking-wider transition-all ${portalMode === "seller" ? "bg-zinc-800 text-white border border-zinc-700 shadow-sm" : "text-zinc-400 hover:text-white"}`}
              >
                Seller ERP Platform
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main portal render */}
      <div class="transition-all duration-300">
        {portalMode === "customer" ? (
          <Storefront 
            products={products}
            printers={printers}
            orders={orders}
            onOrderCreated={handleOrderCreated}
            onRegisterBusiness={handleRegisterBusiness}
          />
        ) : (
          <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <Dashboard 
              products={products}
              orders={orders}
              businessAccounts={businessAccounts}
              auditLogs={auditLogs}
              onProductCreated={handleProductCreated}
              onProductUpdated={handleProductUpdated}
              onProductDuplicated={handleProductDuplicated}
              onProductArchived={handleProductArchived}
              onOrderStatusChanged={handleOrderStatusChanged}
              onBulkCsvImport={handleBulkCsvImport}
            />
          </div>
        )}
      </div>
    </div>
  );
}
