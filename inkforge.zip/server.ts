import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { INITIAL_PRODUCTS, INITIAL_PRINTERS, INITIAL_ORDERS, INITIAL_BUSINESS_ACCOUNTS, INITIAL_REVIEWS } from "./src/data";
import { Product, ProductStatus, Order, OrderStatus, BusinessAccount, AuditLog } from "./src/types";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// In-Memory Database State
let products: Product[] = [...INITIAL_PRODUCTS];
let printers = [...INITIAL_PRINTERS];
let orders: Order[] = [...INITIAL_ORDERS];
let businessAccounts: BusinessAccount[] = [...INITIAL_BUSINESS_ACCOUNTS];
let reviews = [...INITIAL_REVIEWS];
let auditLogs: AuditLog[] = [
  {
    id: "log-1",
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    user: "System Daemon",
    action: "System Initialization",
    details: "InkForge full-stack platform loaded with initial seed data. 7 products, 6 printer models, 3 orders initialized."
  }
];

// Lazy Gemini API Initializer (Safety First)
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key && key !== "MY_GEMINI_API_KEY") {
      try {
        aiClient = new GoogleGenAI({
          apiKey: key,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            }
          }
        });
        console.log("Gemini API Client initialized successfully.");
      } catch (err) {
        console.error("Failed to initialize Gemini Client:", err);
      }
    }
  }
  return aiClient;
}

// Helper to push audit log
function addAuditLog(user: string, action: string, details: string) {
  auditLogs.unshift({
    id: `log-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    timestamp: new Date().toISOString(),
    user,
    action,
    details
  });
  if (auditLogs.length > 100) {
    auditLogs.pop();
  }
}

// API Routes

// Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Products API
app.get("/api/products", (req, res) => {
  const { category, search, manufacturer, compatibility, status } = req.query;
  let filtered = [...products];

  if (category) {
    filtered = filtered.filter(p => p.category === category);
  }
  if (status) {
    filtered = filtered.filter(p => p.status === status);
  } else {
    // default: don't show archived/draft products on storefront unless specified
    // but on admin dashboard they are shown
  }
  if (manufacturer) {
    filtered = filtered.filter(p => p.manufacturer.toLowerCase() === (manufacturer as string).toLowerCase());
  }
  if (compatibility) {
    filtered = filtered.filter(p =>
      p.compatiblePrinters.some(cp => cp.toLowerCase().includes((compatibility as string).toLowerCase()))
    );
  }
  if (search) {
    const query = (search as string).toLowerCase();
    filtered = filtered.filter(p =>
      p.name.toLowerCase().includes(query) ||
      p.sku.toLowerCase().includes(query) ||
      p.cartridgeNumber.toLowerCase().includes(query) ||
      p.oemReference.toLowerCase().includes(query) ||
      p.description.toLowerCase().includes(query)
    );
  }

  res.json(filtered);
});

app.post("/api/products", (req, res) => {
  try {
    const newProduct: Product = {
      ...req.body,
      id: `prod-${Date.now()}`,
      rating: req.body.rating || 5.0,
      reviewsCount: req.body.reviewsCount || 0,
      compatiblePrinters: Array.isArray(req.body.compatiblePrinters) 
        ? req.body.compatiblePrinters 
        : typeof req.body.compatiblePrinters === 'string'
        ? req.body.compatiblePrinters.split(",").map((s: string) => s.trim())
        : []
    };
    products.unshift(newProduct);
    addAuditLog("Operator", "Product Created", `SKU: ${newProduct.sku} - ${newProduct.name}`);
    res.status(201).json(newProduct);
  } catch (error: any) {
    res.status(400).json({ error: error.message });
  }
});

app.put("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const index = products.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }
  products[index] = { ...products[index], ...req.body };
  addAuditLog("Operator", "Product Updated", `SKU: ${products[index].sku} - Status: ${products[index].status}`);
  res.json(products[index]);
});

app.post("/api/products/:id/duplicate", (req, res) => {
  const { id } = req.params;
  const original = products.find(p => p.id === id);
  if (!original) {
    return res.status(404).json({ error: "Product not found" });
  }
  const duplicated: Product = {
    ...original,
    id: `prod-${Date.now()}`,
    sku: `${original.sku}-COPY-${Math.floor(Math.random() * 100)}`,
    name: `${original.name} (Duplicate)`,
    status: ProductStatus.Draft
  };
  products.unshift(duplicated);
  addAuditLog("Operator", "Product Duplicated", `Copied ${original.sku} to ${duplicated.sku}`);
  res.json(duplicated);
});

app.delete("/api/products/:id", (req, res) => {
  const { id } = req.params;
  const index = products.findIndex(p => p.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Product not found" });
  }
  const oldStatus = products[index].status;
  products[index].status = ProductStatus.Archived;
  addAuditLog("Operator", "Product Archived", `SKU: ${products[index].sku} (changed status from ${oldStatus} to Archived)`);
  res.json({ success: true, product: products[index] });
});

// CSV Bulk Import Simulation
app.post("/api/products/bulk-csv", (req, res) => {
  const { csvText } = req.body;
  if (!csvText) {
    return res.status(400).json({ error: "No CSV content provided." });
  }
  try {
    const lines = csvText.split("\n").filter((l: string) => l.trim() !== "");
    if (lines.length < 2) {
      return res.status(400).json({ error: "Invalid CSV content: requires header and at least one data row." });
    }
    const headers = lines[0].split(",").map((h: string) => h.trim());
    let importedCount = 0;

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v: string) => v.trim());
      if (values.length < headers.length) continue;

      const productObj: any = {};
      headers.forEach((h: string, idx: number) => {
        productObj[h] = values[idx];
      });

      const newProd: Product = {
        id: `prod-${Date.now()}-${i}`,
        sku: productObj.sku || `SKU-IMP-${Math.floor(Math.random() * 10000)}`,
        name: productObj.name || `Imported Product ${i}`,
        manufacturer: productObj.manufacturer || "HP",
        compatiblePrinters: productObj.compatiblePrinters ? productObj.compatiblePrinters.split("|") : ["All LaserJet Printers"],
        cartridgeNumber: productObj.cartridgeNumber || "N/A",
        oemReference: productObj.oemReference || "N/A",
        color: (productObj.color || "Black") as any,
        capacity: productObj.capacity || "Standard",
        estimatedPageYield: parseInt(productObj.estimatedPageYield) || 1500,
        costPerPage: parseFloat(productObj.costPerPage) || 0.01,
        images: ["https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&q=80&w=600"],
        description: productObj.description || "DTC imported item via Enterprise Bulk Manager.",
        installationGuide: "Standard ink installation guide applies.",
        stockQuantity: parseInt(productObj.stockQuantity) || 50,
        price: parseFloat(productObj.price) || 29.99,
        bulkPricing: [],
        status: ProductStatus.Published,
        category: (productObj.category || "Toner") as any,
        isCompatible: productObj.isCompatible === "true",
        isXL: productObj.isXL === "true",
        isMultipack: productObj.isMultipack === "true",
        rating: 4.5,
        reviewsCount: 1
      };

      products.unshift(newProd);
      importedCount++;
    }

    addAuditLog("System Daemon", "Bulk CSV Upload", `Imported ${importedCount} products successfully.`);
    res.json({ success: true, count: importedCount });
  } catch (err: any) {
    res.status(500).json({ error: `CSV Parsing failed: ${err.message}` });
  }
});

// Printers API
app.get("/api/printers", (req, res) => {
  res.json(printers);
});

app.post("/api/printers", (req, res) => {
  const newPrinter = {
    id: `p-${Date.now()}`,
    ...req.body
  };
  printers.unshift(newPrinter);
  addAuditLog("Operator", "Printer Registered", `Added Printer Model ${newPrinter.manufacturer} ${newPrinter.model}`);
  res.status(201).json(newPrinter);
});

// Orders API
app.get("/api/orders", (req, res) => {
  res.json(orders);
});

app.post("/api/orders", (req, res) => {
  const { customerName, customerEmail, shippingAddress, items, paymentMethod, paymentNetwork, businessVat, discountCode } = req.body;
  
  if (!items || items.length === 0) {
    return res.status(400).json({ error: "No products in cart" });
  }

  // Calculate prices
  let subtotal = 0;
  const orderItems = items.map((cartItem: any) => {
    const prod = products.find(p => p.id === cartItem.productId);
    const unitPrice = prod ? (prod.salePrice || prod.price) : cartItem.price;
    subtotal += unitPrice * cartItem.quantity;
    
    // Low stock reduction
    if (prod) {
      prod.stockQuantity = Math.max(0, prod.stockQuantity - cartItem.quantity);
      if (prod.stockQuantity <= 10) {
        addAuditLog("System Alert", "Low Stock Alert", `SKU: ${prod.sku} stock depleted to ${prod.stockQuantity}. Reorder recommended.`);
      }
    }

    return {
      productId: cartItem.productId,
      name: cartItem.name || (prod ? prod.name : "InkForge Cartridge"),
      sku: cartItem.sku || (prod ? prod.sku : "SKU-N/A"),
      quantity: cartItem.quantity,
      price: unitPrice
    };
  });

  let discountAmount = 0;
  if (discountCode && discountCode.toUpperCase() === "FORGE10") {
    discountAmount = parseFloat((subtotal * 0.1).toFixed(2));
  }

  const shippingCost = subtotal >= 50 ? 0 : 4.99;
  const total = parseFloat((subtotal - discountAmount + shippingCost).toFixed(2));
  const refNum = `IF-${Math.floor(10000 + Math.random() * 90000)}-${paymentMethod}`;

  // Generate crypto payment parameters if needed
  let paymentDetails: any = undefined;
  if (paymentMethod === "BTC") {
    paymentDetails = {
      cryptoAddress: "bc1q" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
      cryptoAmount: parseFloat((total / 65000).toFixed(6)),
      cryptoRate: 65000,
      network: "Bitcoin Mainnet",
      txId: "",
      confirmations: 0,
      countdown: 900 // 15 mins
    };
  } else if (paymentMethod === "USDT") {
    paymentDetails = {
      cryptoAddress: "T" + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15),
      cryptoAmount: total,
      cryptoRate: 1.0,
      network: paymentNetwork || "TRC20 (Tron)",
      txId: "",
      confirmations: 0,
      countdown: 900
    };
  }

  const newOrder: Order = {
    id: `ord-${Date.now()}`,
    orderReference: refNum,
    timestamp: new Date().toISOString(),
    customerName,
    customerEmail,
    shippingAddress,
    businessVat,
    items: orderItems,
    subtotal,
    shippingCost,
    discountCode,
    discountAmount,
    total,
    status: paymentMethod === "Card" ? OrderStatus.Paid : OrderStatus.AwaitingPayment,
    paymentMethod,
    paymentDetails
  };

  orders.unshift(newOrder);
  addAuditLog("Storefront Checkout", "Order Created", `Ref: ${refNum} - Total: $${total} via ${paymentMethod}`);
  res.status(201).json(newOrder);
});

app.put("/api/orders/:id", (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const index = orders.findIndex(o => o.id === id);
  if (index === -1) {
    return res.status(404).json({ error: "Order not found" });
  }
  const oldStatus = orders[index].status;
  orders[index].status = status as OrderStatus;
  addAuditLog("Operator", "Order Status Modified", `Ref: ${orders[index].orderReference} changed from ${oldStatus} to ${status}`);
  res.json(orders[index]);
});

// Simulated Crypto Blockchain Monitoring Loop
// Whenever clients query this endpoint, we simulate block progression
app.get("/api/blockchain-check", (req, res) => {
  let updatedOrdersCount = 0;
  orders = orders.map(o => {
    if (o.status === OrderStatus.AwaitingPayment && o.paymentDetails) {
      const details = { ...o.paymentDetails };
      
      // Decrement countdown
      if (details.countdown && details.countdown > 0) {
        details.countdown = Math.max(0, details.countdown - 30); // simulation leaps 30 seconds
      }

      // Generate TxID if not set
      if (!details.txId && Math.random() > 0.4) {
        details.txId = "0x" + Math.random().toString(16).substring(2, 15) + Math.random().toString(16).substring(2, 15);
        addAuditLog("Blockchain Listener", "Transaction Detected", `Ref: ${o.orderReference} - Tx: ${details.txId.substring(0, 10)}... on ${details.network}`);
      }

      // Increase confirmations if TxID is set
      if (details.txId && details.confirmations !== undefined && details.confirmations < 6) {
        details.confirmations += Math.floor(Math.random() * 2) + 1;
        if (details.confirmations >= 4) {
          // Confirm order payment
          o.status = OrderStatus.Paid;
          addAuditLog("Blockchain Validator", "Payment Confirmed", `Ref: ${o.orderReference} - ${details.confirmations} confirmations detected on blockchain.`);
          updatedOrdersCount++;
        }
      }

      // Handle Timeout
      if (details.countdown === 0 && o.status === OrderStatus.AwaitingPayment && !details.txId) {
        o.status = OrderStatus.Cancelled;
        addAuditLog("System Daemon", "Order Payment Timeout", `Ref: ${o.orderReference} expired without payment.`);
      }

      return { ...o, paymentDetails: details };
    }
    return o;
  });

  res.json({ success: true, processed: true, updatedOrdersCount });
});

// Business Accounts API
app.get("/api/business-accounts", (req, res) => {
  res.json(businessAccounts);
});

app.post("/api/business-accounts", (req, res) => {
  const newAccount: BusinessAccount = {
    id: `bus-${Date.now()}`,
    volumeDiscountRate: 0.10,
    creditLimit: 3000,
    creditUsed: 0,
    users: [{ name: req.body.contactName || "Contact Admin", email: req.body.contactEmail, role: "Admin" }],
    purchaseOrders: [],
    monthlyStatements: [],
    ...req.body
  };
  businessAccounts.push(newAccount);
  addAuditLog("Business Desk", "Corporate Account Opened", `${newAccount.companyName} registered with VAT ${newAccount.vatNumber}`);
  res.status(201).json(newAccount);
});

// Audit Logs API
app.get("/api/audit-logs", (req, res) => {
  res.json(auditLogs);
});

// Analytics API (Calculates authentic numbers from live in-memory DB)
app.get("/api/analytics", (req, res) => {
  const totalRevenue = orders
    .filter(o => o.status !== OrderStatus.Cancelled && o.status !== OrderStatus.Refunded)
    .reduce((sum, o) => sum + o.total, 0);

  const salesCount = orders.filter(o => o.status !== OrderStatus.Cancelled).length;

  // Crypto usage
  const cryptoPaymentsCount = orders.filter(o => o.paymentMethod === "BTC" || o.paymentMethod === "USDT").length;
  const cryptoPercentage = salesCount > 0 ? parseFloat(((cryptoPaymentsCount / salesCount) * 100).toFixed(1)) : 0;

  // Category breakdowns
  const categorySales: Record<string, number> = {};
  orders.forEach(o => {
    if (o.status !== OrderStatus.Cancelled) {
      o.items.forEach(item => {
        const prod = products.find(p => p.id === item.productId);
        const category = prod ? prod.category : "Toner";
        categorySales[category] = (categorySales[category] || 0) + (item.price * item.quantity);
      });
    }
  });

  const categoryBreakdown = Object.entries(categorySales).map(([name, value]) => ({
    name,
    value: parseFloat(value.toFixed(2))
  }));

  // Low stock products count
  const lowStockCount = products.filter(p => p.stockQuantity <= 15).length;

  // Returning customer simulation rate
  const returningCustomerRate = 34.5; // percent

  res.json({
    totalRevenue: parseFloat(totalRevenue.toFixed(2)),
    salesCount,
    cryptoPercentage,
    lowStockCount,
    returningCustomerRate,
    categoryBreakdown,
    recentSalesDaily: [
      { date: "07-09", amount: 240 },
      { date: "07-10", amount: 480 },
      { date: "07-11", amount: 310 },
      { date: "07-12", amount: 640 },
      { date: "07-13", amount: 520 },
      { date: "07-14", amount: 890 },
      { date: "07-15", amount: totalRevenue > 2000 ? 1150 : 640 }
    ]
  });
});

// AI Auto-Categorize and Compatibility mapping (Gemini Integration)
app.post("/api/gemini/categorize", async (req, res) => {
  const { title, description, manufacturer } = req.body;
  if (!title) {
    return res.status(400).json({ error: "Product title is required." });
  }

  const ai = getGeminiClient();
  if (!ai) {
    // Graceful Fallback if API key not available or still in default state
    console.warn("Gemini API key is not active. Performing high-fidelity algorithmic rule-based fallback.");
    
    // Simple mock classification based on title keywords
    const isInk = /ink|cartridge|color|chroma|pixma|epson/i.test(title);
    const isToner = /toner|laser|laserjet|drum/i.test(title);
    const isRefill = /refill|bottle|syringe/i.test(title);
    
    const category = isRefill ? "Refill Kit" : isToner ? "Toner" : "Ink Cartridge";
    const yieldEst = isToner ? 3500 : isInk ? 1200 : 8000;
    const estCost = isToner ? 0.008 : 0.024;

    const fallbackResponse = {
      category,
      oemReference: `OEM-${title.substring(0, 4).toUpperCase()}-${Math.floor(Math.random() * 1000)}`,
      compatiblePrinters: [`${manufacturer || "HP"} LaserJet Pro`, `${manufacturer || "HP"} SmartTank Office`],
      estimatedPageYield: yieldEst,
      costPerPage: estCost,
      color: /cyan/i.test(title) ? "Cyan" : /magenta/i.test(title) ? "Magenta" : /yellow/i.test(title) ? "Yellow" : /black/i.test(title) ? "Black" : "Multi",
      isCompatible: !/genuine|original|oem/i.test(title),
      isXL: /xl|high yield/i.test(title),
      isMultipack: /pack|multipack|set/i.test(title),
      optimizedDescription: `${title}. Engineered by InkForge for ultra-resilient outputs. Delivers superb density and immaculate line clarity at an exceptional DTC price.`
    };
    
    return res.json({
      fallback: true,
      data: fallbackResponse,
      warning: "Running in offline mode. Configure a valid GEMINI_API_KEY in Secrets to activate real-time intelligence mapping."
    });
  }

  try {
    const prompt = `Analyze the following printer product listing and output a highly accurate JSON metadata schema based on your expert printer consumable knowledge.
Product Title: "${title}"
Manufacturer: "${manufacturer || "Universal"}"
Original Description context: "${description || ""}"

You must categorize the product, extract the color, estimate its standard ISO page yield based on cartridge/toner reference standard metrics, compute an optimal cost-per-page (assume standard printing retail prices divided by page yield), identify 2 or 3 common compatible printers, and write an optimized editorial description styled in clean, technical American Hypermodernism (editorial, high-precision, tech-focused).`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert procurement and logistics classifier at InkForge. You classify office consumable goods into structural JSON metadata models with perfect type safety. Always respond with raw JSON matching the requested schema.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: {
              type: Type.STRING,
              description: "Must be exactly 'Ink Cartridge', 'Toner', 'Refill Kit', or 'Office Supplies'."
            },
            oemReference: {
              type: Type.STRING,
              description: "Estimated manufacturer original SKU or part number."
            },
            compatiblePrinters: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Array of 2 to 3 compatible printer models."
            },
            estimatedPageYield: {
              type: Type.INTEGER,
              description: "Estimated ISO/IEC page yield at 5% coverage."
            },
            costPerPage: {
              type: Type.NUMBER,
              description: "Estimated cost-per-page in USD cents (e.g. 0.0059 for $0.0059)."
            },
            color: {
              type: Type.STRING,
              description: "Must be exactly 'Black', 'Cyan', 'Magenta', 'Yellow', 'Multi', or 'None'."
            },
            isCompatible: {
              type: Type.BOOLEAN,
              description: "True if third-party compatible, false if official manufacturer OEM."
            },
            isXL: {
              type: Type.BOOLEAN,
              description: "True if XL, XXL, or High Yield."
            },
            isMultipack: {
              type: Type.BOOLEAN,
              description: "True if contains multiple cartridges or colors."
            },
            optimizedDescription: {
              type: Type.STRING,
              description: "Optimized marketing and technical copy reflecting hypermodernist minimalist brand tone."
            }
          },
          required: ["category", "oemReference", "compatiblePrinters", "estimatedPageYield", "costPerPage", "color", "isCompatible", "isXL", "isMultipack", "optimizedDescription"]
        }
      }
    });

    const resultText = response.text || "{}";
    const resultJson = JSON.parse(resultText);

    addAuditLog("Gemini Intelligence", "Product Classification", `Mapped "${title}" to category "${resultJson.category}"`);
    res.json({
      fallback: false,
      data: resultJson
    });
  } catch (err: any) {
    console.error("Gemini classification failed:", err);
    res.status(500).json({ error: `AI Classification failed: ${err.message}` });
  }
});

// Vite Middleware & Production static serve setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Dev Mode using Vite Dev Server
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite Development Middleware mounted.");
  } else {
    // Production Mode serving compiled static assets
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log(`Serving static distribution from: ${distPath}`);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`InkForge Full-Stack Server listening on http://0.0.0.0:${PORT} in [${process.env.NODE_ENV || 'development'}] mode.`);
  });
}

startServer();
