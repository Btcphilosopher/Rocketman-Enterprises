import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { INITIAL_PRODUCTS } from './src/data';
import { Product, Prescription, Order, Message, AuditLog, ReminderSetting } from './src/types';

// In-Memory Database State
let products: Product[] = [...INITIAL_PRODUCTS];
let prescriptions: Prescription[] = [
  {
    id: 'rx-101',
    patientName: 'Jane Doe',
    patientEmail: 'tom@ahyx.org',
    uploadedAt: new Date(Date.now() - 3600000 * 24).toISOString(),
    fileName: 'prescription_amoxicillin_doe.pdf',
    status: 'Pending Review',
    medicationName: 'Amoxicillin Trihydrate',
    strength: '500mg',
    dosage: '3 times daily',
    directions: 'Take 1 capsule every 8 hours for 10 days. Complete entire course.',
    doctorName: 'Dr. Robert Chen, MD',
    doctorLicense: 'LIC-774920-MD',
    contraindicationsCheck: 'Safe',
    aiAnalysis: 'PRESCRIPTION VALIDATION SUMMARY:\n- Authenticated patient name: Jane Doe\n- Medication: Amoxicillin Trihydrate 500mg\n- Direct matches with standard antibiotic dosage guidelines.\n- No severe contraindications found in patient history.'
  },
  {
    id: 'rx-102',
    patientName: 'Jane Doe',
    patientEmail: 'tom@ahyx.org',
    uploadedAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    fileName: 'prescription_lipitor_doe.jpg',
    status: 'Approved',
    medicationName: 'Atorvastatin (Lipitor)',
    strength: '20mg',
    dosage: '1 tablet daily',
    directions: 'Take 1 tablet daily in the evening.',
    doctorName: 'Dr. Robert Chen, MD',
    doctorLicense: 'LIC-774920-MD',
    contraindicationsCheck: 'Warning',
    aiAnalysis: 'PRESCRIPTION VALIDATION SUMMARY:\n- Authenticated patient name: Jane Doe\n- Medication: Atorvastatin 20mg\n- Clinician approved.\n- Warning: Monitor liver enzymes (LFTs) if muscle aches develop. Patient should avoid grapefruit juice.',
    pharmacistNotes: 'Verified with prescriber Dr. Chen. Patient advised regarding grapefruit juice contraindication.'
  }
];

let orders: Order[] = [
  {
    id: 'ord-2026-001',
    patientName: 'Jane Doe',
    patientEmail: 'tom@ahyx.org',
    items: [
      { productId: 'p-4', productName: 'Acetaminophen (Tylenol Extra Strength)', quantity: 2, price: 9.99, isPrescription: false },
      { productId: 'p-6', productName: 'Methylcobalamin B12 Wellness', quantity: 1, price: 18.99, isPrescription: false }
    ],
    status: 'Delivered',
    type: 'Delivery',
    deliveryAddress: '144 Enterprise Blvd, London, EC1A 1AA',
    deliverySchedule: 'Standard Delivery (2-3 Business Days)',
    totalAmount: 38.97,
    paymentStatus: 'Paid',
    createdAt: new Date(Date.now() - 3600000 * 48).toISOString()
  },
  {
    id: 'ord-2026-002',
    patientName: 'Jane Doe',
    patientEmail: 'tom@ahyx.org',
    items: [
      { productId: 'p-1', productName: 'Atorvastatin (Lipitor)', quantity: 1, price: 45.00, isPrescription: true }
    ],
    status: 'Processing',
    type: 'Click & Collect',
    deliverySchedule: 'Collect in 2 hours - MedBridge Central Pharmacy',
    totalAmount: 45.00,
    paymentStatus: 'Paid',
    prescriptionId: 'rx-102',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString()
  }
];

let messages: Message[] = [
  {
    id: 'm-1',
    sender: 'System',
    timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
    text: 'Welcome to MedBridge Secure Pharmacy Messaging. You are connected with Dr. Sarah Vance, PharmD.',
    patientEmail: 'tom@ahyx.org'
  },
  {
    id: 'm-2',
    sender: 'Patient',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    text: 'Hi, can I take ibuprofen with Atorvastatin (Lipitor)?',
    patientEmail: 'tom@ahyx.org'
  },
  {
    id: 'm-3',
    sender: 'Pharmacist',
    timestamp: new Date(Date.now() - 3600000 * 1.9).toISOString(),
    text: 'Hello! I am Dr. Sarah Vance. Yes, in general, there is no direct contraindication between Atorvastatin (Lipitor) and Ibuprofen (Advil). However, if you have any pre-existing kidney issues or high blood pressure, you should use ibuprofen with caution, as NSAIDs can impact renal function and elevate blood pressure. Let me know if you are taking any other heart medications!',
    patientEmail: 'tom@ahyx.org'
  }
];

let reminders: ReminderSetting[] = [
  {
    id: 'rem-1',
    patientEmail: 'tom@ahyx.org',
    medicationName: 'Atorvastatin (Lipitor)',
    time: '21:00',
    frequency: 'Daily',
    isActive: true
  },
  {
    id: 'rem-2',
    patientEmail: 'tom@ahyx.org',
    medicationName: 'Amoxicillin Trihydrate',
    time: '08:00',
    frequency: 'Daily',
    isActive: false
  }
];

let auditLogs: AuditLog[] = [
  {
    id: 'log-1',
    timestamp: new Date(Date.now() - 3600000 * 24).toISOString(),
    user: 'System Bot',
    role: 'System',
    action: 'Database Initialization',
    status: 'Success',
    details: 'Initial corporate medicine inventory of 9 items synchronized successfully with GSL database.'
  },
  {
    id: 'log-2',
    timestamp: new Date(Date.now() - 3600000 * 23).toISOString(),
    user: 'Jane Doe',
    role: 'Patient',
    action: 'Prescription Upload',
    status: 'Success',
    details: 'Uploaded prescription_amoxicillin_doe.pdf for verification.'
  },
  {
    id: 'log-3',
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    user: 'Dr. Sarah Vance, PharmD',
    role: 'Pharmacist',
    action: 'Prescription Approval',
    status: 'Success',
    details: 'Approved Rx-102 (Atorvastatin 20mg) after prescribers verification call.'
  }
];

// Lazy Gemini Initialization to avoid crashing when key is absent
let aiInstance: GoogleGenAI | null = null;
function getAI() {
  if (!aiInstance) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn('GEMINI_API_KEY environment variable is missing. Running on simulated mode.');
      return null;
    }
    aiInstance = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return aiInstance;
}

// Write helper for adding audit logs
function logAction(user: string, role: 'Patient' | 'Pharmacist' | 'Administrator' | 'System', action: string, status: 'Success' | 'Failed' | 'Warning', details: string) {
  const newLog: AuditLog = {
    id: `log-${Date.now()}`,
    timestamp: new Date().toISOString(),
    user,
    role,
    action,
    status,
    details
  };
  auditLogs.unshift(newLog);
  if (auditLogs.length > 200) auditLogs.pop(); // limit log size
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Support JSON payload up to 10MB (for images/PDF prescription data URLs)
  app.use(express.json({ limit: '10mb' }));

  // --- API ROUTES ---

  // Health Check Endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      service: 'MedBridge Enterprise Digital Pharmacy Engine',
      environment: process.env.NODE_ENV || 'development'
    });
  });

  // 1. PRODUCTS API
  app.get('/api/products', (req, res) => {
    res.json(products);
  });

  app.post('/api/products', (req, res) => {
    const productData = req.body;
    if (productData.id) {
      // Edit
      const index = products.findIndex(p => p.id === productData.id);
      if (index !== -1) {
        products[index] = { ...products[index], ...productData };
        logAction('Administrator', 'Administrator', 'Product Update', 'Success', `Updated medicine catalogue details for "${productData.name}".`);
        return res.json(products[index]);
      }
    } else {
      // Create
      const newProduct: Product = {
        ...productData,
        id: `p-${Date.now()}`,
        stock: Number(productData.stock) || 100,
        price: Number(productData.price) || 10.00
      };
      products.push(newProduct);
      logAction('Administrator', 'Administrator', 'Product Creation', 'Success', `Added new medical item "${newProduct.name}" to stock inventory.`);
      return res.json(newProduct);
    }
    res.status(400).json({ error: 'Failed to process product details' });
  });

  // 2. PRESCRIPTIONS API
  app.get('/api/prescriptions', (req, res) => {
    res.json(prescriptions);
  });

  app.post('/api/prescriptions', (req, res) => {
    const { patientName, patientEmail, fileName, fileData } = req.body;
    
    const newPrescription: Prescription = {
      id: `rx-${Date.now().toString().slice(-4)}`,
      patientName: patientName || 'Patient',
      patientEmail: patientEmail || 'tom@ahyx.org',
      uploadedAt: new Date().toISOString(),
      fileName: fileName || 'prescription_upload.pdf',
      status: 'Pending Review',
      fileData: fileData // save base64 string
    };

    // Populate with some smart automatic mock defaults
    newPrescription.medicationName = 'Extracting...';
    newPrescription.contraindicationsCheck = 'Safe';
    newPrescription.aiAnalysis = 'Awaiting Clinical Evaluation...';

    prescriptions.unshift(newPrescription);
    logAction(newPrescription.patientName, 'Patient', 'Prescription Upload', 'Success', `Uploaded prescription file "${fileName}" (ID: ${newPrescription.id}).`);
    res.json(newPrescription);
  });

  // Update/Review Prescription (by Pharmacist)
  app.post('/api/prescriptions/:id/review', (req, res) => {
    const { id } = req.params;
    const { status, pharmacistNotes, medicationName, strength, dosage, directions, doctorName, doctorLicense, contraindicationsCheck } = req.body;
    
    const index = prescriptions.findIndex(rx => rx.id === id);
    if (index !== -1) {
      prescriptions[index] = {
        ...prescriptions[index],
        status,
        pharmacistNotes,
        medicationName: medicationName || prescriptions[index].medicationName,
        strength: strength || prescriptions[index].strength,
        dosage: dosage || prescriptions[index].dosage,
        directions: directions || prescriptions[index].directions,
        doctorName: doctorName || prescriptions[index].doctorName,
        doctorLicense: doctorLicense || prescriptions[index].doctorLicense,
        contraindicationsCheck: contraindicationsCheck || prescriptions[index].contraindicationsCheck
      };
      
      logAction('Dr. Sarah Vance, PharmD', 'Pharmacist', `Prescription Review (${status})`, status === 'Approved' ? 'Success' : 'Warning', `Reviewed prescription ${id} for patient ${prescriptions[index].patientName}. Action: ${status}`);
      return res.json(prescriptions[index]);
    }
    res.status(404).json({ error: 'Prescription not found' });
  });

  // 3. ORDERS API
  app.get('/api/orders', (req, res) => {
    res.json(orders);
  });

  app.post('/api/orders', (req, res) => {
    const { patientName, patientEmail, items, type, deliveryAddress, deliverySchedule, totalAmount, prescriptionId } = req.body;
    
    // Check stock and deduct
    items.forEach((item: any) => {
      const prod = products.find(p => p.id === item.productId);
      if (prod) {
        prod.stock = Math.max(0, prod.stock - item.quantity);
      }
    });

    const newOrder: Order = {
      id: `ord-2026-${Math.floor(100 + Math.random() * 900)}`,
      patientName: patientName || 'Jane Doe',
      patientEmail: patientEmail || 'tom@ahyx.org',
      items,
      status: 'Pending Review',
      type,
      deliveryAddress,
      deliverySchedule,
      totalAmount,
      paymentStatus: 'Paid', // simulated successful payment
      prescriptionId,
      createdAt: new Date().toISOString()
    };

    orders.unshift(newOrder);
    logAction(newOrder.patientName, 'Patient', 'Order Placed', 'Success', `Created order ${newOrder.id} totaling £${totalAmount.toFixed(2)} (${type}).`);
    res.json(newOrder);
  });

  // Update order status (Pharmacist/Admin)
  app.post('/api/orders/:id/status', (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    const index = orders.findIndex(o => o.id === id);
    if (index !== -1) {
      orders[index].status = status;
      logAction('System', 'System', 'Order Status Update', 'Success', `Order ${id} shifted to state: ${status}.`);
      return res.json(orders[index]);
    }
    res.status(404).json({ error: 'Order not found' });
  });

  // 4. CHAT MESSAGES API & SECURE MESSAGING WITH PHARMACIST (Gemini Integrated)
  app.get('/api/messages', (req, res) => {
    res.json(messages);
  });

  app.post('/api/messages', async (req, res) => {
    const { sender, text, patientEmail } = req.body;
    const patientMail = patientEmail || 'tom@ahyx.org';

    const newMsg: Message = {
      id: `m-${Date.now()}`,
      sender,
      timestamp: new Date().toISOString(),
      text,
      patientEmail: patientMail
    };

    messages.push(newMsg);

    if (sender === 'Patient') {
      logAction('Jane Doe', 'Patient', 'Sent Secure Message', 'Success', 'Dispatched clinical query to secure pharmacist router.');
      
      // Request Gemini clinical feedback
      const ai = getAI();
      if (ai) {
        try {
          // Construct chat context from recent history
          const lastMessages = messages
            .filter(m => m.patientEmail === patientMail)
            .slice(-6)
            .map(m => `${m.sender}: ${m.text}`)
            .join('\n');

          const response = await ai.models.generateContent({
            model: 'gemini-3.5-flash',
            contents: `You are Dr. Sarah Vance, PharmD, a highly certified clinical pharmacist at MedBridge.
Answer the patient's medical and pharmaceutical queries with absolute safety, professional caution, and clear, structured guidance.
Follow these guidelines:
- Be highly supportive and professional.
- Refer to active ingredients, warnings, and safe practices.
- Remind patients to consult their primary care physician for diagnosis.
- Keep the response fully therapeutic and clinically objective. Avoid fluff.
- Use simple, reassuring bullet points if describing complex instructions.

Here is the secure communication thread with patient:
${lastMessages}

Your Response (as Pharmacist, without prefixes like "Pharmacist:" or "Sarah Vance:"):`,
          });

          const replyText = response.text || "Thank you for reaching out. Let me review your request details shortly.";
          
          const rxMsg: Message = {
            id: `m-${Date.now() + 1}`,
            sender: 'Pharmacist',
            timestamp: new Date().toISOString(),
            text: replyText,
            patientEmail: patientMail
          };
          messages.push(rxMsg);
          logAction('Dr. Sarah Vance, PharmD', 'Pharmacist', 'Sent Clinical Advice', 'Success', `Delivered expert pharmacist counsel regarding patient query.`);
          return res.json({ patientMessage: newMsg, pharmacistMessage: rxMsg });
        } catch (err: any) {
          console.error('Gemini pharmacy chat failed:', err);
        }
      }

      // Simulated Pharmacist Fallback when Gemini is missing/fails
      setTimeout(() => {
        let simulatedReply = "Thank you for consulting MedBridge Pharmacy. I have received your clinical query. Let me review your pharmaceutical records and I will respond to you right away.";
        
        const lowerText = text.toLowerCase();
        if (lowerText.includes('ibuprofen') && lowerText.includes('atorvastatin') || lowerText.includes('lipitor')) {
          simulatedReply = "Hello! I am Dr. Sarah Vance, PharmD. In general, there is no major direct interaction between Atorvastatin (Lipitor) and Ibuprofen (Advil). However, NSAIDs like ibuprofen should be used with extreme caution if you suffer from high blood pressure, coronary artery disease, or kidney impairment, as they can retain fluid and worsen kidney performance. Ensure you keep your dosing minimal (e.g. 200-400mg as needed) and monitor for any sudden ankle swelling or blood pressure rises. What other medications are you currently taking?";
        } else if (lowerText.includes('antibiotic') || lowerText.includes('amoxicillin')) {
          simulatedReply = "Yes, amoxicillin is an antibiotic that must be taken continuously until the prescription course is fully finished, even if symptoms clear up. Skipping or ending doses early risks developing bacterial resistance. Take it with or without meals, but drink plenty of water. If you experience severe diarrhea or hypersensitivity rashes, stop usage immediately and notify us.";
        } else if (lowerText.includes('side effect') || lowerText.includes('statin')) {
          simulatedReply = "Statins like Atorvastatin are generally safe, but common side effects can include mild muscle aches, joint pain, or headaches. In very rare cases, they can cause serious muscle breakdown (rhabdomyolysis) or liver enzymes elevation. If you notice unusually dark cola-colored urine or severe, unexplained muscle weakness, contact your healthcare provider immediately.";
        }

        const rxMsg: Message = {
          id: `m-${Date.now() + 5}`,
          sender: 'Pharmacist',
          timestamp: new Date().toISOString(),
          text: simulatedReply,
          patientEmail: patientMail
        };
        messages.push(rxMsg);
        logAction('Dr. Sarah Vance, PharmD', 'Pharmacist', 'Sent Simulated Clinical Advice', 'Success', 'Delivered standard simulated pharmacist counsel.');
      }, 1000);
    }

    res.json({ patientMessage: newMsg });
  });

  // 5. MEDICATION REMINDERS API
  app.get('/api/reminders', (req, res) => {
    res.json(reminders);
  });

  app.post('/api/reminders', (req, res) => {
    const { medicationName, time, frequency, patientEmail } = req.body;
    const newReminder: ReminderSetting = {
      id: `rem-${Date.now()}`,
      patientEmail: patientEmail || 'tom@ahyx.org',
      medicationName,
      time,
      frequency,
      isActive: true
    };
    reminders.push(newReminder);
    logAction('Jane Doe', 'Patient', 'Reminder Created', 'Success', `Added daily medication alert for ${medicationName} at ${time}.`);
    res.json(newReminder);
  });

  app.post('/api/reminders/:id/toggle', (req, res) => {
    const { id } = req.params;
    const index = reminders.findIndex(r => r.id === id);
    if (index !== -1) {
      reminders[index].isActive = !reminders[index].isActive;
      logAction('Jane Doe', 'Patient', 'Reminder Toggled', 'Success', `Reminder for ${reminders[index].medicationName} status changed to ${reminders[index].isActive ? 'ACTIVE' : 'INACTIVE'}.`);
      return res.json(reminders[index]);
    }
    res.status(404).json({ error: 'Reminder not found' });
  });

  app.delete('/api/reminders/:id', (req, res) => {
    const { id } = req.params;
    const index = reminders.findIndex(r => r.id === id);
    if (index !== -1) {
      const removed = reminders.splice(index, 1);
      logAction('Jane Doe', 'Patient', 'Reminder Deleted', 'Success', `Removed medication alert for ${removed[0].medicationName}.`);
      return res.json({ success: true, removed: removed[0] });
    }
    res.status(404).json({ error: 'Reminder not found' });
  });

  // 6. SYSTEM AUDIT LOGS API
  app.get('/api/audit-logs', (req, res) => {
    res.json(auditLogs);
  });

  // 7. ANALYTICS API (For Administrative View)
  app.get('/api/analytics', (req, res) => {
    const totalSales = orders.filter(o => o.paymentStatus === 'Paid').reduce((sum, o) => sum + o.totalAmount, 0);
    const activePatients = 124; // Simulated static count + current patient
    const pendingPrescriptions = prescriptions.filter(p => p.status === 'Pending Review').length;
    const lowStockItems = products.filter(p => p.stock < 100).length;

    // Monthly orders distribution
    const salesOverTime = [
      { name: 'Feb', sales: 1200 },
      { name: 'Mar', sales: 1850 },
      { name: 'Apr', sales: 2400 },
      { name: 'May', sales: 3100 },
      { name: 'Jun', sales: 4200 },
      { name: 'Jul', sales: totalSales + 500 }
    ];

    // Category breakdown
    const categoryDistribution = [
      { name: 'Rx Medicines', count: products.filter(p => p.category === 'Prescription').length },
      { name: 'OTC', count: products.filter(p => p.category === 'OTC').length },
      { name: 'Wellness', count: products.filter(p => p.category === 'Wellness').length },
      { name: 'Devices', count: products.filter(p => p.category === 'Devices').length },
      { name: 'Vitamins', count: products.filter(p => p.category === 'Vitamins').length }
    ];

    res.json({
      metrics: {
        totalRevenue: totalSales + 12850, // base historical revenue + new ones
        activePatients,
        pendingRxCount: pendingPrescriptions,
        lowStockAlerts: lowStockItems,
        dispenseSuccessRate: 99.4
      },
      salesOverTime,
      categoryDistribution
    });
  });

  // 8. ADVANCED GEMINI PRESCRIPTION DECODER & CLINICAL SAFETY CHECK API
  // Parses a simulation of prescription content (via text or raw file data simulation)
  app.post('/api/analyze-prescription', async (req, res) => {
    const { id, fileName, fileData, mockOption } = req.body;

    const ai = getAI();
    
    // Choose input script or trigger default based on user selection
    let originalTextText = "Rx Prescription Slip\nPATIENT: Jane Doe\nPRESCRIBER: Dr. Robert Chen, MD\nREG: LIC-774920-MD\nDATE: July 15, 2026\nRx:\nAmoxicillin Trihydrate 500mg capsules\nDisp: 30 (thirty)\nSig: Take 1 capsule by mouth three times daily for 10 days until finished.";
    
    if (mockOption === 'lisinopril') {
      originalTextText = "Rx Prescription Slip\nPATIENT: Jane Doe\nPRESCRIBER: Dr. Robert Chen, MD\nREG: LIC-774920-MD\nRx:\nLisinopril 10mg tablets\nDisp: 90 (ninety)\nSig: Take 1 tablet daily in the morning for hypertension control.";
    } else if (mockOption === 'atorvastatin') {
      originalTextText = "Rx Prescription Slip\nPATIENT: Jane Doe\nPRESCRIBER: Dr. Robert Chen, MD\nREG: LIC-774920-MD\nRx:\nAtorvastatin (Lipitor) 20mg\nDisp: 30 tablets\nSig: Take 1 tablet by mouth daily in the evening for hyperlipidemia.";
    }

    if (ai) {
      try {
        logAction('System', 'System', 'Gemini AI Call', 'Success', `Invoked Gemini-3.5-Flash to evaluate prescription: ${fileName || 'Digital Rx Link'}`);
        
        const response = await ai.models.generateContent({
          model: 'gemini-3.5-flash',
          contents: `Analyze this prescription transcript text and provide a valid JSON analysis.
You are an expert clinical pharmacy compliance assistant. Check for safety, identify dosage form, extract doctor licenses, and evaluate warnings/contraindications against typical patient guidelines.

Prescription Transcript:
"""
${originalTextText}
"""

Return your response strictly in JSON format as defined below:
{
  "medicationName": "string representing the medicine name",
  "strength": "extracted strength (e.g. 500mg or 10mg)",
  "dosage": "dosage instructions (e.g. 3 times daily, or once daily)",
  "directions": "detailed patient-facing sig instructions",
  "doctorName": "doctor name",
  "doctorLicense": "license registry number",
  "contraindicationsCheck": "One of 'Safe' | 'Warning' | 'Critical'",
  "aiAnalysis": "A detailed 2-3 sentence paragraph validating the prescription authenticity, clinical match, and important alerts for pharmacists (e.g. avoid grapefruit with atorvastatin, or take full course of amoxicillin)."
}`,
          config: {
            responseMimeType: 'application/json'
          }
        });

        const textResponse = response.text || '';
        try {
          const parsed = JSON.parse(textResponse);
          // If we had a prescription ID, update it
          if (id) {
            const index = prescriptions.findIndex(rx => rx.id === id);
            if (index !== -1) {
              prescriptions[index] = {
                ...prescriptions[index],
                ...parsed,
                status: 'Pending Review' // Reset status to let pharmacist approve
              };
              return res.json(prescriptions[index]);
            }
          }
          return res.json({ id: 'temp-rx', ...parsed });
        } catch (parseErr) {
          console.error('Failed to parse Gemini JSON output:', parseErr);
        }
      } catch (geminiErr: any) {
        console.error('Gemini call failed during prescription evaluation:', geminiErr);
      }
    }

    // High fidelity, responsive clinical mock fallback (runs instant when key is missing or failed)
    logAction('System', 'System', 'Prescription Safe Scan', 'Success', `Extracted details from "${fileName || 'Rx Slip'}" using MedBridge local parser.`);
    
    let simulatedResult: Partial<Prescription> = {
      medicationName: 'Amoxicillin Trihydrate',
      strength: '500mg',
      dosage: '3 times daily',
      directions: 'Take 1 capsule every 8 hours for 10 days until completely finished.',
      doctorName: 'Dr. Robert Chen, MD',
      doctorLicense: 'LIC-774920-MD',
      contraindicationsCheck: 'Safe',
      aiAnalysis: 'PRESCRIPTION VALIDATION SUMMARY:\n- Patient name match verified (Jane Doe).\n- Prescription is for Amoxicillin Trihydrate 500mg, an antibiotic.\n- Safe dosage verified. Instruct patient to take all tablets to prevent drug resistance.'
    };

    if (mockOption === 'lisinopril' || (fileName && fileName.toLowerCase().includes('lisinopril'))) {
      simulatedResult = {
        medicationName: 'Lisinopril (Zestril)',
        strength: '10mg',
        dosage: '1 tablet daily',
        directions: 'Take 1 tablet daily in the morning with a full glass of water.',
        doctorName: 'Dr. Robert Chen, MD',
        doctorLicense: 'LIC-774920-MD',
        contraindicationsCheck: 'Warning',
        aiAnalysis: 'PRESCRIPTION VALIDATION SUMMARY:\n- High safety alert: Lisinopril is an ACE inhibitor. Check blood pressure.\n- Warning: Monitor serum potassium levels for hyperkalemia risks. Absolute contraindication in pregnant patients.'
      };
    } else if (mockOption === 'atorvastatin' || (fileName && fileName.toLowerCase().includes('lipitor') || fileName && fileName.toLowerCase().includes('atorvastatin'))) {
      simulatedResult = {
        medicationName: 'Atorvastatin (Lipitor)',
        strength: '20mg',
        dosage: '1 tablet daily',
        directions: 'Take 1 tablet by mouth daily in the evening.',
        doctorName: 'Dr. Robert Chen, MD',
        doctorLicense: 'LIC-774920-MD',
        contraindicationsCheck: 'Warning',
        aiAnalysis: 'PRESCRIPTION VALIDATION SUMMARY:\n- Medication verified: Atorvastatin (Lipitor) 20mg statin.\n- Warning: Advise patient to completely avoid Grapefruit / Grapefruit Juice as it increases risk of rhabdomyolysis.'
      };
    }

    if (id) {
      const index = prescriptions.findIndex(rx => rx.id === id);
      if (index !== -1) {
        prescriptions[index] = {
          ...prescriptions[index],
          ...simulatedResult,
          status: 'Pending Review'
        };
        return res.json(prescriptions[index]);
      }
    }

    res.json({ id: 'temp-rx', ...simulatedResult });
  });

  // --- VITE DEV OR PRODUCTION CONFIGURATION ---

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MedBridge Enterprise Digital Pharmacy running on port ${PORT}`);
  });
}

startServer();
