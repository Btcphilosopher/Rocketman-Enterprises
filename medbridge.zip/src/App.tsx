import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search, Upload, ShieldAlert, CheckCircle, MessageSquare, Clock,
  Settings, Activity, FileText, Database, Cpu, User, UserCheck, BarChart3,
  Plus, Trash2, ShoppingCart, Calendar, MapPin, CreditCard, ArrowRight,
  Lock, AlertTriangle, Heart, Info, Sparkles, Droplet, ClipboardList,
  RefreshCw, Sliders, X, ChevronRight, Check
} from 'lucide-react';
import { Product, Prescription, Order, Message, AuditLog, ReminderSetting } from './types';
import { ARTIFACTS } from './data';

export default function App() {
  // Roles & View states
  const [activeRole, setActiveRole] = useState<'Patient' | 'Pharmacist' | 'Administrator'>('Patient');
  const [activeTab, setActiveTab] = useState<string>('browse');

  // Database lists fetched from Express API
  const [products, setProducts] = useState<Product[]>([]);
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [reminders, setReminders] = useState<ReminderSetting[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);

  // Interaction states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  
  // Checkout form
  const [showCheckout, setShowCheckout] = useState(false);
  const [checkoutAddress, setCheckoutAddress] = useState('144 Enterprise Blvd, London, EC1A 1AA');
  const [checkoutSchedule, setCheckoutSchedule] = useState('Standard Delivery (2-3 Business Days)');
  const [checkoutType, setCheckoutType] = useState<'Delivery' | 'Click & Collect'>('Delivery');
  const [associatedRxId, setAssociatedRxId] = useState<string>('');
  const [orderInvoice, setOrderInvoice] = useState<Order | null>(null);

  // Upload state
  const [uploadingFile, setUploadingFile] = useState<boolean>(false);
  const [selectedSampleRx, setSelectedSampleRx] = useState<string>('amoxicillin');
  const [currentScanningRx, setCurrentScanningRx] = useState<Prescription | null>(null);
  const [customFileText, setCustomFileText] = useState<string>('');

  // Secure Messaging state
  const [newMessageText, setNewMessageText] = useState('');
  const [isPharmacistTyping, setIsPharmacistTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // New Reminder state
  const [newReminderMed, setNewReminderMed] = useState('');
  const [newReminderTime, setNewReminderTime] = useState('09:00');
  const [newReminderFreq, setNewReminderFreq] = useState<'Daily' | 'Weekly' | 'Twice Daily'>('Daily');

  // Pharmacist and Admin specific states
  const [rxUnderReview, setRxUnderReview] = useState<Prescription | null>(null);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  
  // General feedback status
  const [fetchTrigger, setFetchTrigger] = useState(0);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Sync state from server on trigger or mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [prodRes, rxRes, ordRes, msgRes, remRes, logRes, polyRes] = await Promise.all([
          fetch('/api/products'),
          fetch('/api/prescriptions'),
          fetch('/api/orders'),
          fetch('/api/messages'),
          fetch('/api/reminders'),
          fetch('/api/audit-logs'),
          fetch('/api/analytics')
        ]);

        if (prodRes.ok) setProducts(await prodRes.json());
        if (rxRes.ok) setPrescriptions(await rxRes.json());
        if (ordRes.ok) setOrders(await ordRes.json());
        if (msgRes.ok) setMessages(await msgRes.json());
        if (remRes.ok) setReminders(await remRes.json());
        if (logRes.ok) setAuditLogs(await logRes.json());
        if (polyRes.ok) setAnalytics(await polyRes.json());
      } catch (err) {
        console.error('Failed to sync state from Express server:', err);
      }
    };
    fetchData();
  }, [fetchTrigger]);

  // Handle auto-scroll to latest chat message
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isPharmacistTyping]);

  // Show a temporary success toast
  const triggerToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 4000);
  };

  const forceSync = () => setFetchTrigger(prev => prev + 1);

  // CART LOGIC
  const addToCart = (product: Product) => {
    const existing = cart.find(item => item.product.id === product.id);
    if (existing) {
      setCart(cart.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { product, quantity: 1 }]);
    }
    triggerToast(`Added ${product.name} to your shopping cart.`);
  };

  const updateCartQuantity = (productId: string, qty: number) => {
    if (qty <= 0) {
      setCart(cart.filter(item => item.product.id !== productId));
    } else {
      setCart(cart.map(item => item.product.id === productId ? { ...item, quantity: qty } : item));
    }
  };

  const getCartTotal = () => cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  
  const hasPrescriptionItems = () => cart.some(item => item.product.category === 'Prescription');

  const handleCheckoutSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (cart.length === 0) return;

    if (hasPrescriptionItems() && !associatedRxId) {
      alert("This order contains a Prescription Medicine. You MUST link an APPROVED or PENDING prescription ID before checkout.");
      return;
    }

    const orderPayload = {
      patientName: 'Jane Doe',
      patientEmail: 'tom@ahyx.org',
      items: cart.map(item => ({
        productId: item.product.id,
        productName: item.product.name,
        quantity: item.quantity,
        price: item.product.price,
        isPrescription: item.product.category === 'Prescription'
      })),
      type: checkoutType,
      deliveryAddress: checkoutType === 'Delivery' ? checkoutAddress : undefined,
      deliverySchedule: checkoutSchedule,
      totalAmount: getCartTotal(),
      prescriptionId: associatedRxId || undefined
    };

    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderPayload)
      });
      if (response.ok) {
        const newOrder = await response.json();
        setOrderInvoice(newOrder);
        setCart([]);
        setShowCheckout(false);
        setAssociatedRxId('');
        forceSync();
        triggerToast("Order placed and payment processed successfully!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // PRESCRIPTION UPLOAD & DECODE (Gemini Powered)
  const handlePrescriptionDecode = async (mockType: string) => {
    setUploadingFile(true);
    setCurrentScanningRx(null);
    try {
      // 1. Save dummy rx record first
      const uploadRes = await fetch('/api/prescriptions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientName: 'Jane Doe',
          patientEmail: 'tom@ahyx.org',
          fileName: `medical_rx_${mockType}_scanned_2026.pdf`
        })
      });
      
      if (uploadRes.ok) {
        const uploadedRx = await uploadRes.ok ? await uploadRes.json() : null;
        if (!uploadedRx) return;

        // 2. Invoke the Gemini safety and parsing decoder
        const decodeRes = await fetch('/api/analyze-prescription', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: uploadedRx.id,
            fileName: uploadedRx.fileName,
            mockOption: mockType
          })
        });

        if (decodeRes.ok) {
          const decodedRx = await decodeRes.json();
          setCurrentScanningRx(decodedRx);
          forceSync();
          triggerToast(`Gemini AI decoded Rx and calculated safety profiles: ${decodedRx.medicationName}`);
        }
      }
    } catch (err) {
      console.error('Failed to decode prescription:', err);
    } finally {
      setUploadingFile(false);
    }
  };

  // SECURE MESSAGING SENDS
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessageText.trim()) return;

    const userMsg = newMessageText;
    setNewMessageText('');
    setIsPharmacistTyping(true);

    // optimistic update
    setMessages(prev => [...prev, {
      id: `temp-${Date.now()}`,
      sender: 'Patient',
      timestamp: new Date().toISOString(),
      text: userMsg,
      patientEmail: 'tom@ahyx.org'
    }]);

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sender: 'Patient',
          text: userMsg,
          patientEmail: 'tom@ahyx.org'
        })
      });
      if (response.ok) {
        forceSync();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setTimeout(() => setIsPharmacistTyping(false), 1200);
    }
  };

  // CREATING REMINDERS
  const handleAddReminder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReminderMed.trim()) return;

    try {
      const response = await fetch('/api/reminders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          medicationName: newReminderMed,
          time: newReminderTime,
          frequency: newReminderFreq,
          patientEmail: 'tom@ahyx.org'
        })
      });
      if (response.ok) {
        setNewReminderMed('');
        forceSync();
        triggerToast(`Medication reminder scheduled for ${newReminderMed}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleToggleReminder = async (id: string) => {
    try {
      const response = await fetch(`/api/reminders/${id}/toggle`, { method: 'POST' });
      if (response.ok) {
        forceSync();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeleteReminder = async (id: string) => {
    try {
      const response = await fetch(`/api/reminders/${id}`, { method: 'DELETE' });
      if (response.ok) {
        forceSync();
        triggerToast("Reminder deleted successfully.");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // PHARMACIST WORKFLOW APPROVALS
  const handleReviewDecision = async (status: 'Approved' | 'Rejected') => {
    if (!rxUnderReview) return;
    try {
      const response = await fetch(`/api/prescriptions/${rxUnderReview.id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          status,
          pharmacistNotes: rxUnderReview.pharmacistNotes || 'Reviewed and matched against electronic state registries.',
          medicationName: rxUnderReview.medicationName,
          strength: rxUnderReview.strength,
          dosage: rxUnderReview.dosage,
          directions: rxUnderReview.directions,
          doctorName: rxUnderReview.doctorName,
          doctorLicense: rxUnderReview.doctorLicense,
          contraindicationsCheck: rxUnderReview.contraindicationsCheck
        })
      });
      if (response.ok) {
        setRxUnderReview(null);
        forceSync();
        triggerToast(`Prescription ${rxUnderReview.id} status marked as: ${status}`);
      }
    } catch (err) {
      console.error(err);
    }
  };

  // ADMIN OPERATIONS: ADD/EDIT PRODUCT
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    try {
      const response = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editingProduct)
      });
      if (response.ok) {
        setEditingProduct(null);
        forceSync();
        triggerToast("Product catalogue successfully updated!");
      }
    } catch (err) {
      console.error(err);
    }
  };

  // FILTERING THE MEDS LIST
  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.activeIngredients.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  // Force default tab selection on switching roles to ensure correct UI boundaries
  const handleRoleChange = (role: 'Patient' | 'Pharmacist' | 'Administrator') => {
    setActiveRole(role);
    if (role === 'Patient') setActiveTab('browse');
    else if (role === 'Pharmacist') setActiveTab('rx-queue');
    else setActiveTab('analytics');
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-emerald-100 selection:text-emerald-900">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {successToast && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -10, scale: 0.95 }}
            className="fixed top-4 right-4 z-50 flex items-center gap-3 bg-emerald-900 text-emerald-50 px-5 py-4 rounded-xl shadow-xl border border-emerald-800"
          >
            <CheckCircle className="h-5 w-5 text-emerald-400 shrink-0" />
            <span className="text-sm font-medium">{successToast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Top Professional Regulatory Banner */}
      <div className="bg-slate-900 text-slate-400 py-1.5 px-4 text-xs font-mono tracking-tight flex flex-wrap justify-between items-center border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="inline-block h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span>MEDBRIDGE ENTERPRISE LICENSED PLATFORM ● ID: PH-2026-9042</span>
        </div>
        <div className="flex items-center gap-4">
          <span>GSL DATABASE COMPLIANT</span>
          <span>REGULATED IN EU & UK GPhC</span>
        </div>
      </div>

      {/* Corporate Premium Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand Logo & Name */}
          <div className="flex items-center gap-3">
            <div className="bg-emerald-600 text-white p-2.5 rounded-xl shadow-md shadow-emerald-100 flex items-center justify-center">
              <Heart className="h-6 w-6 text-white animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight text-slate-900">MedBridge</h1>
                <span className="bg-emerald-50 text-emerald-700 text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border border-emerald-200">
                  Licensed Pharmacy
                </span>
              </div>
              <p className="text-xs text-slate-500">Enterprise Digital Clinical Healthcare Platform</p>
            </div>
          </div>

          {/* Role Switching Selector (For Live Interactive Prototyping) */}
          <div className="flex items-center gap-3 bg-slate-100 p-1.5 rounded-2xl border border-slate-200 self-start md:self-auto">
            <span className="text-xs font-medium text-slate-500 pl-2 pr-1 hidden lg:inline">Active Role:</span>
            <button
              onClick={() => handleRoleChange('Patient')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                activeRole === 'Patient'
                  ? 'bg-white text-emerald-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <User className="h-3.5 w-3.5" />
              Patient Portal
            </button>
            <button
              onClick={() => handleRoleChange('Pharmacist')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                activeRole === 'Pharmacist'
                  ? 'bg-white text-blue-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <UserCheck className="h-3.5 w-3.5" />
              Pharmacist Panel
            </button>
            <button
              onClick={() => handleRoleChange('Administrator')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                activeRole === 'Administrator'
                  ? 'bg-white text-purple-700 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
              }`}
            >
              <Sliders className="h-3.5 w-3.5" />
              Admin Dashboard
            </button>
          </div>

        </div>

        {/* Navigation Tabs based on Selected Role */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-100">
          <div className="flex gap-6 overflow-x-auto py-3 no-scrollbar">
            {activeRole === 'Patient' && (
              <>
                <button
                  onClick={() => setActiveTab('browse')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'browse' ? 'border-emerald-600 text-emerald-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Activity className="h-4 w-4" />
                  Browse Medicines
                </button>
                <button
                  onClick={() => setActiveTab('upload-rx')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'upload-rx' ? 'border-emerald-600 text-emerald-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Upload className="h-4 w-4" />
                  Upload Prescription
                </button>
                <button
                  onClick={() => setActiveTab('cart')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 relative ${
                    activeTab === 'cart' ? 'border-emerald-600 text-emerald-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ShoppingCart className="h-4 w-4" />
                  Cart
                  {cart.length > 0 && (
                    <span className="absolute -top-1 -right-3.5 bg-emerald-600 text-white text-[10px] h-4 w-4 rounded-full flex items-center justify-center font-bold">
                      {cart.reduce((s, c) => s + c.quantity, 0)}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('chat')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'chat' ? 'border-emerald-600 text-emerald-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <MessageSquare className="h-4 w-4" />
                  Consult Pharmacist
                  <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                </button>
                <button
                  onClick={() => setActiveTab('reminders')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'reminders' ? 'border-emerald-600 text-emerald-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Clock className="h-4 w-4" />
                  Med Reminders
                </button>
              </>
            )}

            {activeRole === 'Pharmacist' && (
              <>
                <button
                  onClick={() => setActiveTab('rx-queue')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'rx-queue' ? 'border-blue-600 text-blue-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <ClipboardList className="h-4 w-4" />
                  Rx Review Queue
                  {prescriptions.filter(p => p.status === 'Pending Review').length > 0 && (
                    <span className="bg-blue-600 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                      {prescriptions.filter(p => p.status === 'Pending Review').length}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('inventory')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'inventory' ? 'border-blue-600 text-blue-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Database className="h-4 w-4" />
                  Inventory Management
                </button>
                <button
                  onClick={() => setActiveTab('ph-chat')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'ph-chat' ? 'border-blue-600 text-blue-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <MessageSquare className="h-4 w-4" />
                  Patient Consultation Hub
                </button>
              </>
            )}

            {activeRole === 'Administrator' && (
              <>
                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'analytics' ? 'border-purple-600 text-purple-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <BarChart3 className="h-4 w-4" />
                  Operations Analytics
                </button>
                <button
                  onClick={() => setActiveTab('catalogue-admin')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'catalogue-admin' ? 'border-purple-600 text-purple-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <FileText className="h-4 w-4" />
                  Product Catalogue Editor
                </button>
                <button
                  onClick={() => setActiveTab('compliance')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'compliance' ? 'border-purple-600 text-purple-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Cpu className="h-4 w-4" />
                  CI/CD & K8s Infrastructure
                </button>
                <button
                  onClick={() => setActiveTab('audit-logs')}
                  className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ${
                    activeTab === 'audit-logs' ? 'border-purple-600 text-purple-600 font-semibold' : 'border-transparent text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Lock className="h-4 w-4" />
                  Security Audit Logs
                </button>
              </>
            )}

            {/* Always Visible REST APIs Specs Tab */}
            <button
              onClick={() => setActiveTab('api-specs')}
              className={`flex items-center gap-2 text-sm font-medium transition-colors border-b-2 pb-3 -mb-3.5 ml-auto ${
                activeTab === 'api-specs' ? 'border-slate-800 text-slate-800 font-semibold' : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Settings className="h-4 w-4" />
              REST API Spec
            </button>
          </div>
        </div>
      </header>

      {/* Main Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={`${activeRole}-${activeTab}`}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >

            {/* ==================== ROLE: PATIENT / TAB: BROWSE ==================== */}
            {activeRole === 'Patient' && activeTab === 'browse' && (
              <div className="space-y-6">
                
                {/* Search & Category filter panel */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="relative w-full md:max-w-md">
                    <Search className="absolute left-3.5 top-3 h-5 w-5 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search by name, active ingredient or condition..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 pl-11 pr-4 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                    />
                  </div>
                  
                  {/* Category Pill Filters */}
                  <div className="flex flex-wrap gap-2 w-full md:w-auto justify-start md:justify-end">
                    {['All', 'Prescription', 'OTC', 'Vitamins', 'Devices', 'Wellness', 'Personal Care'].map(category => (
                      <button
                        key={category}
                        onClick={() => setSelectedCategory(category)}
                        className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all ${
                          selectedCategory === category
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200/60'
                        }`}
                      >
                        {category}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Grid layout for products catalogue */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map(product => (
                    <div
                      key={product.id}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                    >
                      <div className="p-6 space-y-4">
                        {/* Header badge & Price */}
                        <div className="flex items-center justify-between">
                          <span className={`text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                            product.category === 'Prescription'
                              ? 'bg-red-50 text-red-700 border-red-200'
                              : 'bg-emerald-50 text-emerald-700 border-emerald-200'
                          }`}>
                            {product.category} {product.isAccessControlled && '🔐 Access-Controlled'}
                          </span>
                          <span className="text-xl font-bold text-slate-900">£{product.price.toFixed(2)}</span>
                        </div>

                        {/* Title and Ingredients */}
                        <div>
                          <h3 className="font-semibold text-lg text-slate-900 tracking-tight leading-tight">{product.name}</h3>
                          <p className="text-xs text-slate-500 mt-1 font-mono">Active: {product.activeIngredients} ({product.strength})</p>
                        </div>

                        <p className="text-sm text-slate-600 line-clamp-3 leading-relaxed">{product.description}</p>
                        
                        {/* Regulatory Alert snippet */}
                        {product.category === 'Prescription' && (
                          <div className="bg-red-50/50 rounded-xl p-3 border border-red-100 flex gap-2 items-start text-xs text-red-800">
                            <ShieldAlert className="h-4 w-4 text-red-500 shrink-0 mt-0.5" />
                            <div>
                              <p className="font-semibold">Rx-Only Medication</p>
                              <p className="text-[11px] text-red-700">Requires verified electronic or PDF prescription upload.</p>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Footer Actions */}
                      <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex gap-3 items-center">
                        <button
                          onClick={() => setSelectedProduct(product)}
                          className="flex-1 text-center bg-white hover:bg-slate-100 border border-slate-200 rounded-xl py-2 text-xs font-semibold text-slate-700 transition-colors"
                        >
                          Details & Usage
                        </button>
                        <button
                          onClick={() => addToCart(product)}
                          disabled={product.stock <= 0}
                          className={`flex-1 flex items-center justify-center gap-1.5 rounded-xl py-2 text-xs font-semibold text-white transition-all ${
                            product.stock <= 0 
                              ? 'bg-slate-300 cursor-not-allowed'
                              : 'bg-emerald-600 hover:bg-emerald-700 shadow-sm'
                          }`}
                        >
                          <ShoppingCart className="h-3.5 w-3.5" />
                          {product.stock <= 0 ? 'Out of stock' : 'Add to Cart'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>

                {filteredProducts.length === 0 && (
                  <div className="text-center py-16 bg-white rounded-2xl border border-slate-200">
                    <Activity className="h-12 w-12 text-slate-300 mx-auto mb-3" />
                    <h3 className="font-semibold text-lg text-slate-700">No medical items matching search criteria</h3>
                    <p className="text-sm text-slate-500 max-w-sm mx-auto mt-1">Try broadening your search term or selecting a different pharmaceutical category filter.</p>
                  </div>
                )}

                {/* Product Detail Modal */}
                {selectedProduct && (
                  <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
                    <motion.div
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-2xl w-full max-h-[85vh] overflow-y-auto"
                    >
                      <div className="sticky top-0 bg-white px-6 py-4 border-b border-slate-100 flex justify-between items-center z-10">
                        <h3 className="text-lg font-bold text-slate-900">Clinical Medication Details</h3>
                        <button onClick={() => setSelectedProduct(null)} className="text-slate-400 hover:text-slate-600">
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                      
                      <div className="p-6 space-y-6">
                        <div>
                          <div className="flex gap-2 items-center">
                            <h4 className="text-2xl font-bold text-slate-900">{selectedProduct.name}</h4>
                            <span className="bg-slate-100 text-slate-700 font-mono text-xs px-2.5 py-0.5 rounded-lg border border-slate-200">
                              {selectedProduct.strength}
                            </span>
                          </div>
                          <p className="text-sm text-slate-500 mt-1">Manufactured by: {selectedProduct.manufacturer}</p>
                        </div>

                        {/* Interactive Warning Callout */}
                        {selectedProduct.category === 'Prescription' && (
                          <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex gap-3 items-start text-red-800">
                            <AlertTriangle className="h-5 w-5 text-red-600 shrink-0 mt-0.5" />
                            <div className="space-y-1">
                              <p className="font-bold text-sm">Regulatory Safety Restriction (Rx-Only)</p>
                              <p className="text-xs text-red-700">{selectedProduct.regulatoryInfo}</p>
                            </div>
                          </div>
                        )}

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm bg-slate-50 p-4 rounded-xl border border-slate-100">
                          <div>
                            <span className="text-slate-500 font-medium block">Dosage Form:</span>
                            <span className="font-semibold text-slate-900">{selectedProduct.dosageForm}</span>
                          </div>
                          <div>
                            <span className="text-slate-500 font-medium block">Active ingredients:</span>
                            <span className="font-semibold text-slate-900">{selectedProduct.activeIngredients}</span>
                          </div>
                        </div>

                        {/* Usage & Clinical Safety guidelines */}
                        <div className="space-y-4">
                          <div>
                            <span className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                              <Info className="h-4 w-4 text-emerald-600" />
                              Directions for Use
                            </span>
                            <p className="text-sm text-slate-600 mt-1 leading-relaxed">{selectedProduct.directions}</p>
                          </div>

                          <div>
                            <span className="flex items-center gap-2 text-sm font-semibold text-slate-950">
                              <AlertTriangle className="h-4 w-4 text-amber-500" />
                              Contraindications & Precautions
                            </span>
                            <p className="text-sm text-slate-600 mt-1 leading-relaxed">{selectedProduct.contraindications}</p>
                          </div>

                          <div>
                            <span className="flex items-center gap-2 text-sm font-semibold text-slate-950">
                              <ShieldAlert className="h-4 w-4 text-red-500" />
                              Clinical Warnings
                            </span>
                            <p className="text-sm text-slate-600 mt-1 leading-relaxed">{selectedProduct.warnings}</p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex gap-4 justify-end">
                        <button
                          onClick={() => setSelectedProduct(null)}
                          className="px-4 py-2 border border-slate-200 rounded-xl text-sm font-semibold text-slate-700 bg-white hover:bg-slate-50"
                        >
                          Close Details
                        </button>
                        <button
                          onClick={() => {
                            addToCart(selectedProduct);
                            setSelectedProduct(null);
                          }}
                          className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold shadow-sm flex items-center gap-1.5"
                        >
                          <ShoppingCart className="h-4 w-4" />
                          Add to Cart
                        </button>
                      </div>
                    </motion.div>
                  </div>
                )}

              </div>
            )}


            {/* ==================== ROLE: PATIENT / TAB: UPLOAD PRESCRIPTION ==================== */}
            {activeRole === 'Patient' && activeTab === 'upload-rx' && (
              <div className="space-y-8">
                
                {/* Intro Compliance Callout */}
                <div className="bg-emerald-950 text-emerald-100 rounded-2xl p-6 shadow-sm border border-emerald-900 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                  <div className="space-y-1">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-emerald-400" />
                      Gemini AI-Powered Secure Prescription Decoder
                    </h3>
                    <p className="text-sm text-emerald-200 max-w-2xl">
                      Upload your electronic prescription slip. MedBridge uses highly safe Gemini models to extract clinicians, dosage forms, check contraindications, and streamline pharmacist audits instantly.
                    </p>
                  </div>
                  <div className="bg-emerald-900/60 border border-emerald-800 px-4 py-2.5 rounded-xl text-xs font-mono shrink-0">
                    STATUS: SECURE PIPELINE ONLINE
                  </div>
                </div>

                {/* Main upload workspace */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left Column: Interactive Upload Trigger */}
                  <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
                    <h4 className="font-bold text-slate-900 text-lg">Upload Prescription</h4>
                    
                    {/* Simulated Drag & Drop with Selector */}
                    <div className="border-2 border-dashed border-slate-200 hover:border-emerald-500 rounded-xl p-8 text-center bg-slate-50 cursor-pointer transition-colors space-y-4">
                      <div className="bg-emerald-50 h-12 w-12 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                        <Upload className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-slate-800">Drag & Drop prescription document</p>
                        <p className="text-xs text-slate-400 mt-1">Accepts PDF, JPG, PNG up to 10MB</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Or Select Corporate Demo Sample:</label>
                      <select
                        value={selectedSampleRx}
                        onChange={(e) => setSelectedSampleRx(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-3.5 text-sm focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
                      >
                        <option value="amoxicillin">Amoxicillin Trihydrate 500mg (Antibiotic - SAFE)</option>
                        <option value="lisinopril">Lisinopril 10mg (ACE Inhibitor - WARNING)</option>
                        <option value="atorvastatin">Atorvastatin 20mg (Statin - WARNING)</option>
                      </select>
                      
                      <button
                        onClick={() => handlePrescriptionDecode(selectedSampleRx)}
                        disabled={uploadingFile}
                        className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 px-4 rounded-xl text-sm shadow-sm flex items-center justify-center gap-2 transition-colors"
                      >
                        {uploadingFile ? (
                          <>
                            <RefreshCw className="h-4 w-4 animate-spin text-emerald-400" />
                            Gemini Extracting & Analyzing...
                          </>
                        ) : (
                          <>
                            <Activity className="h-4 w-4 text-emerald-400" />
                            Trigger Gemini AI Scan & Save
                          </>
                        )}
                      </button>
                    </div>

                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 space-y-1">
                      <span className="text-xs font-semibold text-slate-500 block">Pre-Auth Patient Details:</span>
                      <p className="text-sm font-semibold text-slate-900">Jane Doe (tom@ahyx.org)</p>
                      <p className="text-xs text-slate-500">Auto-synchronized with verified NHS / GSL patient records.</p>
                    </div>

                  </div>

                  {/* Right Column: AI Extraction & Compliance Audit */}
                  <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200">
                    <h4 className="font-bold text-slate-900 text-lg mb-6 flex items-center justify-between">
                      <span>Real-Time AI Clinical Output</span>
                      {currentScanningRx && (
                        <span className={`text-xs font-semibold uppercase px-2.5 py-1 rounded-md ${
                          currentScanningRx.contraindicationsCheck === 'Safe'
                            ? 'bg-emerald-50 text-emerald-700'
                            : 'bg-amber-50 text-amber-700'
                        }`}>
                          Safety: {currentScanningRx.contraindicationsCheck}
                        </span>
                      )}
                    </h4>

                    {currentScanningRx ? (
                      <div className="space-y-6">
                        
                        {/* Summary Block */}
                        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-mono font-bold text-emerald-700 tracking-wider">RX IDENTIFIER: {currentScanningRx.id}</span>
                            <span className="text-xs text-slate-500">{new Date(currentScanningRx.uploadedAt).toLocaleTimeString()}</span>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm border-t border-slate-200/60 pt-3">
                            <div>
                              <span className="text-xs text-slate-400 block">Patient Name:</span>
                              <span className="font-semibold text-slate-800">{currentScanningRx.patientName}</span>
                            </div>
                            <div>
                              <span className="text-xs text-slate-400 block">Prescribed Medication:</span>
                              <span className="font-semibold text-slate-900 text-emerald-800">{currentScanningRx.medicationName} ({currentScanningRx.strength})</span>
                            </div>
                            <div>
                              <span className="text-xs text-slate-400 block">Dosing Regimen:</span>
                              <span className="font-semibold text-slate-800">{currentScanningRx.dosage}</span>
                            </div>
                            <div>
                              <span className="text-xs text-slate-400 block">Doctor / prescriber:</span>
                              <span className="font-semibold text-slate-800">{currentScanningRx.doctorName || 'Not Found'}</span>
                            </div>
                          </div>

                          <div className="border-t border-slate-200/60 pt-3 text-sm">
                            <span className="text-xs text-slate-400 block">Directions (Sig):</span>
                            <span className="font-semibold text-slate-800 italic">"{currentScanningRx.directions}"</span>
                          </div>
                        </div>

                        {/* AI Clinical Check Result */}
                        <div className="space-y-2">
                          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Gemini Safety Insight & Contraindications Audit:</span>
                          <div className="bg-slate-900 text-slate-100 rounded-xl p-4 font-mono text-xs leading-relaxed border border-slate-800 whitespace-pre-line">
                            {currentScanningRx.aiAnalysis}
                          </div>
                        </div>

                        {/* Prompt patient */}
                        <div className="bg-amber-50/60 border border-amber-200 rounded-xl p-4 text-xs text-amber-800 flex gap-3 items-start">
                          <Info className="h-4 w-4 shrink-0 mt-0.5 text-amber-600" />
                          <div>
                            <p className="font-bold">Awaiting Pharmacist Verification</p>
                            <p className="mt-0.5 leading-relaxed text-amber-700">
                              While Gemini validates compliance parameters, a registered pharmacist at MedBridge will verify the prescription authenticity shortly before dispensing. You can add items to your cart immediately and link this ID during checkout!
                            </p>
                          </div>
                        </div>

                      </div>
                    ) : uploadingFile ? (
                      <div className="h-64 flex flex-col items-center justify-center space-y-4">
                        <RefreshCw className="h-10 w-10 text-emerald-600 animate-spin" />
                        <div className="text-center space-y-1">
                          <p className="font-semibold text-slate-800 text-sm">Executing Server-Side Gemini API Analysis...</p>
                          <p className="text-xs text-slate-400 max-w-sm">Parsing text formats, validating clinical parameters, and building the compliance audit.</p>
                        </div>
                      </div>
                    ) : (
                      <div className="h-64 flex flex-col items-center justify-center border-2 border-dashed border-slate-100 rounded-xl text-center p-6 text-slate-400">
                        <ClipboardList className="h-12 w-12 text-slate-300 mb-2" />
                        <h5 className="font-semibold text-slate-700 text-sm">No Active Prescription Audit</h5>
                        <p className="text-xs max-w-xs mx-auto mt-1 text-slate-500">Trigger a simulated scanned upload on the left. The results will extract and check safety benchmarks here in real-time.</p>
                      </div>
                    )}

                  </div>

                </div>

                {/* History list of uploaded prescriptions for reference */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <h4 className="font-bold text-slate-900 text-lg mb-4">Your Prescription Upload History</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-slate-600">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                          <th className="px-4 py-3">Prescription ID</th>
                          <th className="px-4 py-3">Medicine</th>
                          <th className="px-4 py-3">Clinician Prescriber</th>
                          <th className="px-4 py-3">Uploaded At</th>
                          <th className="px-4 py-3">Safety Status</th>
                          <th className="px-4 py-3">Verification Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {prescriptions.map(rx => (
                          <tr key={rx.id} className="hover:bg-slate-50/50">
                            <td className="px-4 py-3.5 font-mono font-bold text-slate-900 text-xs">{rx.id}</td>
                            <td className="px-4 py-3.5">
                              <div>
                                <span className="font-semibold text-slate-800">{rx.medicationName || 'Scanning...'}</span>
                                <span className="text-xs text-slate-500 font-mono block">{rx.strength}</span>
                              </div>
                            </td>
                            <td className="px-4 py-3.5">{rx.doctorName || 'Extracting...'}</td>
                            <td className="px-4 py-3.5 text-xs text-slate-500">{new Date(rx.uploadedAt).toLocaleDateString()}</td>
                            <td className="px-4 py-3.5">
                              <span className={`text-[11px] font-bold uppercase px-2 py-0.5 rounded-full ${
                                rx.contraindicationsCheck === 'Safe'
                                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                  : 'bg-amber-50 text-amber-700 border border-amber-200'
                              }`}>
                                {rx.contraindicationsCheck || 'Scanning'}
                              </span>
                            </td>
                            <td className="px-4 py-3.5">
                              <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-lg ${
                                rx.status === 'Approved'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : rx.status === 'Rejected'
                                    ? 'bg-red-100 text-red-800'
                                    : 'bg-amber-100 text-amber-800'
                              }`}>
                                {rx.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}


            {/* ==================== ROLE: PATIENT / TAB: CART ==================== */}
            {activeRole === 'Patient' && activeTab === 'cart' && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left Column: Cart items */}
                  <div className="lg:col-span-8 bg-white p-6 rounded-2xl border border-slate-200">
                    <h3 className="text-xl font-bold text-slate-900 mb-6">Shopping Cart</h3>
                    
                    {cart.length > 0 ? (
                      <div className="divide-y divide-slate-100 space-y-4">
                        {cart.map(item => (
                          <div key={item.product.id} className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-4 gap-4">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <span className="font-semibold text-slate-900">{item.product.name}</span>
                                {item.product.category === 'Prescription' && (
                                  <span className="bg-red-50 text-red-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-200 uppercase">
                                    Prescription 🔐
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-slate-400 font-mono">Active: {item.product.activeIngredients} ({item.product.strength})</p>
                              <p className="text-sm font-semibold text-slate-800">£{item.product.price.toFixed(2)} each</p>
                            </div>

                            <div className="flex items-center gap-6">
                              <div className="flex items-center gap-2 border border-slate-200 rounded-xl bg-slate-50 p-1">
                                <button
                                  onClick={() => updateCartQuantity(item.product.id, item.quantity - 1)}
                                  className="h-7 w-7 rounded-lg hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-sm"
                                >
                                  -
                                </button>
                                <span className="w-8 text-center text-sm font-semibold">{item.quantity}</span>
                                <button
                                  onClick={() => updateCartQuantity(item.product.id, item.quantity + 1)}
                                  className="h-7 w-7 rounded-lg hover:bg-slate-200 text-slate-600 flex items-center justify-center font-bold text-sm"
                                >
                                  +
                                </button>
                              </div>

                              <span className="text-base font-bold text-slate-900 w-20 text-right">
                                £{(item.product.price * item.quantity).toFixed(2)}
                              </span>

                              <button
                                onClick={() => updateCartQuantity(item.product.id, 0)}
                                className="text-slate-400 hover:text-red-600"
                              >
                                <Trash2 className="h-5 w-5" />
                              </button>
                            </div>
                          </div>
                        ))}

                        <div className="border-t border-slate-100 pt-6 flex justify-between items-center">
                          <span className="text-sm text-slate-500">Cart subtotal:</span>
                          <span className="text-2xl font-bold text-slate-955">£{getCartTotal().toFixed(2)}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center py-16">
                        <ShoppingCart className="h-12 w-12 text-slate-300 mx-auto mb-2" />
                        <h4 className="font-semibold text-slate-700 text-base">Your shopping cart is currently empty</h4>
                        <p className="text-xs text-slate-500 mt-1">Browse our medical catalogues to add over-the-counter and wellness products.</p>
                      </div>
                    )}
                  </div>

                  {/* Right Column: Checkout Details */}
                  <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200 space-y-6 self-start">
                    <h4 className="font-bold text-slate-900 text-lg">Order Summary</h4>
                    
                    {hasPrescriptionItems() && (
                      <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs text-red-800 space-y-2">
                        <div className="flex gap-2 items-start font-bold">
                          <ShieldAlert className="h-4.5 w-4.5 text-red-600 shrink-0 mt-0.5" />
                          <span>PRESCRIPTION ATTESTATION MANDATORY</span>
                        </div>
                        <p className="text-[11px] text-red-700">
                          Your cart contains regulated prescription-only medication. To execute checkout, you must paste/select a valid Prescription ID below from your Upload History.
                        </p>
                        
                        <div className="space-y-1 mt-2">
                          <label className="font-semibold block text-slate-500">Associate Prescription ID:</label>
                          <select
                            value={associatedRxId}
                            onChange={(e) => setAssociatedRxId(e.target.value)}
                            className="w-full bg-white border border-red-200 rounded-lg py-1.5 px-2.5 text-xs text-slate-900 focus:ring-1 focus:ring-red-400"
                          >
                            <option value="">-- Choose Approved/Pending Rx ID --</option>
                            {prescriptions.map(rx => (
                              <option key={rx.id} value={rx.id}>
                                {rx.id} ({rx.medicationName || 'Medication'} - {rx.status})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    )}

                    <div className="space-y-2 text-sm text-slate-600">
                      <div className="flex justify-between">
                        <span>Items Subtotal:</span>
                        <span className="font-semibold text-slate-900">£{getCartTotal().toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Packaging & Delivery:</span>
                        <span className="font-semibold text-slate-900">FREE</span>
                      </div>
                      <div className="flex justify-between text-base font-bold text-slate-900 border-t border-slate-100 pt-3">
                        <span>Total Payable:</span>
                        <span>£{getCartTotal().toFixed(2)}</span>
                      </div>
                    </div>

                    <button
                      disabled={cart.length === 0}
                      onClick={() => setShowCheckout(true)}
                      className={`w-full text-center py-3 rounded-xl text-sm font-semibold text-white shadow-sm transition-all ${
                        cart.length === 0 
                          ? 'bg-slate-300 cursor-not-allowed'
                          : 'bg-emerald-600 hover:bg-emerald-700'
                      }`}
                    >
                      Proceed to Checkout
                    </button>
                  </div>

                </div>

                {/* Checkout Modal Form */}
                {showCheckout && (
                  <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
                    <motion.div
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-6 space-y-6"
                    >
                      <div className="flex justify-between items-center border-b border-slate-100 pb-3">
                        <h4 className="font-bold text-lg text-slate-900">Enterprise Secure Checkout</h4>
                        <button onClick={() => setShowCheckout(false)} className="text-slate-400 hover:text-slate-600">
                          <X className="h-5 w-5" />
                        </button>
                      </div>

                      <form onSubmit={handleCheckoutSubmit} className="space-y-4">
                        
                        {/* Fulfillment type */}
                        <div className="space-y-1.5">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Fulfillment Method:</label>
                          <div className="grid grid-cols-2 gap-3">
                            <button
                              type="button"
                              onClick={() => setCheckoutType('Delivery')}
                              className={`py-2 px-3 border rounded-xl text-xs font-semibold transition-all ${
                                checkoutType === 'Delivery'
                                  ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                                  : 'bg-white border-slate-200 text-slate-600'
                              }`}
                            >
                              Home Delivery
                            </button>
                            <button
                              type="button"
                              onClick={() => setCheckoutType('Click & Collect')}
                              className={`py-2 px-3 border rounded-xl text-xs font-semibold transition-all ${
                                checkoutType === 'Click & Collect'
                                  ? 'bg-emerald-50 border-emerald-400 text-emerald-800'
                                  : 'bg-white border-slate-200 text-slate-600'
                              }`}
                            >
                              Click & Collect
                            </button>
                          </div>
                        </div>

                        {/* Condition Address display */}
                        {checkoutType === 'Delivery' ? (
                          <div className="space-y-1">
                            <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Home Delivery Address:</label>
                            <input
                              type="text"
                              required
                              value={checkoutAddress}
                              onChange={(e) => setCheckoutAddress(e.target.value)}
                              className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                            />
                          </div>
                        ) : (
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs text-slate-600">
                            <p className="font-bold text-slate-800">Collection Point:</p>
                            <p className="mt-0.5">MedBridge London Central Pharmacy, EC1A 1AA</p>
                            <p className="mt-1 text-emerald-700 font-semibold">Available for collect in 2 hours.</p>
                          </div>
                        )}

                        {/* Delivery Scheduling */}
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Scheduled Delivery Timeframe:</label>
                          <select
                            value={checkoutSchedule}
                            onChange={(e) => setCheckoutSchedule(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          >
                            <option value="Standard Delivery (2-3 Business Days)">Standard Delivery (2-3 Business Days)</option>
                            <option value="Next-Day Secure Pharmacy Courier">Next-Day Secure Pharmacy Courier (Complimentary)</option>
                            <option value="Same-Day Express Emergency Despatch">Same-Day Express Emergency Despatch (Priority)</option>
                          </select>
                        </div>

                        {/* Payment provider certification note */}
                        <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl text-[11px] text-slate-500 space-y-1">
                          <p className="font-bold flex items-center gap-1 text-slate-700">
                            <Lock className="h-3 w-3 text-emerald-600" />
                            Stripe Healthcare PCI-DSS Compliant Payment
                          </p>
                          <p>Payments are tokenized and encrypted. MedBridge complies with rigorous HIPAA, PCI, and local pharmacist regulations.</p>
                        </div>

                        <button
                          type="submit"
                          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 rounded-xl text-sm shadow-sm transition-colors"
                        >
                          Process Payment £{getCartTotal().toFixed(2)}
                        </button>

                      </form>
                    </motion.div>
                  </div>
                )}

                {/* Digital Invoice Modal upon successful checkout */}
                {orderInvoice && (
                  <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
                    <motion.div
                      initial={{ scale: 0.95, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="bg-white rounded-2xl shadow-xl border border-slate-200 max-w-md w-full p-6 space-y-6 font-sans text-left"
                    >
                      <div className="text-center space-y-2">
                        <div className="bg-emerald-50 h-12 w-12 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                          <Check className="h-6 w-6" />
                        </div>
                        <h3 className="text-xl font-bold text-slate-900">Digital Invoice & Order Confirmed</h3>
                        <p className="text-xs text-slate-400 font-mono">ORDER ID: {orderInvoice.id}</p>
                      </div>

                      <div className="border-t border-b border-slate-100 py-4 text-sm space-y-2">
                        <div className="flex justify-between">
                          <span className="text-slate-500">Invoice Patient:</span>
                          <span className="font-semibold text-slate-800">{orderInvoice.patientName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Method:</span>
                          <span className="font-semibold text-slate-800">{orderInvoice.type}</span>
                        </div>
                        {orderInvoice.deliveryAddress && (
                          <div className="flex justify-between">
                            <span className="text-slate-500">Ship Address:</span>
                            <span className="font-semibold text-slate-800 text-right max-w-xs">{orderInvoice.deliveryAddress}</span>
                          </div>
                        )}
                        <div className="flex justify-between">
                          <span className="text-slate-500">Scheduled:</span>
                          <span className="font-semibold text-slate-800">{orderInvoice.deliverySchedule}</span>
                        </div>
                        {orderInvoice.prescriptionId && (
                          <div className="flex justify-between text-red-700">
                            <span className="font-semibold">Linked Rx ID:</span>
                            <span className="font-mono font-bold">{orderInvoice.prescriptionId}</span>
                          </div>
                        )}
                      </div>

                      <div className="space-y-3">
                        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Purchased Medications:</span>
                        <div className="space-y-1 text-sm bg-slate-50 p-3 rounded-xl">
                          {orderInvoice.items.map((item, idx) => (
                            <div key={idx} className="flex justify-between text-slate-600">
                              <span>{item.productName} (x{item.quantity})</span>
                              <span className="font-semibold text-slate-800">£{(item.price * item.quantity).toFixed(2)}</span>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex justify-between items-center text-lg font-bold text-slate-900">
                        <span>Paid Total:</span>
                        <span>£{orderInvoice.totalAmount.toFixed(2)}</span>
                      </div>

                      <div className="bg-slate-900 text-slate-400 rounded-xl p-3 text-[10px] font-mono text-center">
                        TAX INVOICE SECURED - VAT NO: GB-99403810
                      </div>

                      <button
                        onClick={() => {
                          setOrderInvoice(null);
                          setActiveTab('browse');
                        }}
                        className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-2.5 rounded-xl text-sm transition-colors"
                      >
                        Close & Continue Shopping
                      </button>
                    </motion.div>
                  </div>
                )}

              </div>
            )}


            {/* ==================== ROLE: PATIENT / TAB: CLINICAL SECURE CHAT ==================== */}
            {activeRole === 'Patient' && activeTab === 'chat' && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[70vh]">
                  
                  {/* Left panel: Clinical details & info */}
                  <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200 flex flex-col justify-between">
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <h3 className="font-bold text-lg text-slate-900">Clinical Pharmacy Consultation</h3>
                        <p className="text-xs text-slate-500 leading-relaxed">
                          Consult Dr. Sarah Vance, PharmD. Ask about contraindications, daily dosages, interactions with common NSAIDs, vitamins, or specific side effects of statins and ACE inhibitors.
                        </p>
                      </div>

                      <div className="space-y-3">
                        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Clinical Safety Tips:</span>
                        
                        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex gap-2 text-xs text-slate-600 leading-relaxed">
                          <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0 mt-0.5" />
                          <p>Always state all current wellness products or vitamins you are actively taking.</p>
                        </div>

                        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 flex gap-2 text-xs text-slate-600 leading-relaxed">
                          <CheckCircle className="h-4.5 w-4.5 text-emerald-600 shrink-0 mt-0.5" />
                          <p>Ask about active ingredients of statins before combining them with grapefruit juice products.</p>
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-slate-100 pt-6 space-y-2 text-xs text-slate-400">
                      <p>● Chat runs under secure end-to-end encryption standards.</p>
                      <p>● Responses are driven by Gemini models with medical guideline templates.</p>
                    </div>
                  </div>

                  {/* Right panel: Active chat workspace */}
                  <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 flex flex-col h-full overflow-hidden">
                    
                    {/* Chat Header */}
                    <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <div className="h-10 w-10 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700 border border-slate-300">
                            SV
                          </div>
                          <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-500 ring-2 ring-white"></span>
                        </div>
                        <div>
                          <p className="font-semibold text-slate-900 text-sm">Dr. Sarah Vance, PharmD</p>
                          <p className="text-xs text-slate-400">MedBridge Chief Clinical Pharmacist</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-mono bg-slate-200/60 px-2 py-0.5 rounded-sm">ROOM #E2EE-429</span>
                    </div>

                    {/* Message Log */}
                    <div className="flex-1 overflow-y-auto p-6 space-y-4">
                      {messages.map(msg => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.sender === 'Patient' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm ${
                            msg.sender === 'Patient'
                              ? 'bg-emerald-600 text-white rounded-tr-none'
                              : msg.sender === 'System'
                                ? 'bg-slate-100 text-slate-500 text-xs italic border border-slate-200'
                                : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200/60'
                          }`}>
                            <p className="leading-relaxed">{msg.text}</p>
                            <span className="block text-[9px] text-right mt-1 opacity-70">
                              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                      ))}

                      {isPharmacistTyping && (
                        <div className="flex justify-start">
                          <div className="bg-slate-100 border border-slate-200 rounded-2xl rounded-tl-none px-4 py-3 flex gap-1 items-center">
                            <span className="h-2 w-2 rounded-full bg-slate-400 animate-bounce"></span>
                            <span className="h-2 w-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.2s]"></span>
                            <span className="h-2 w-2 rounded-full bg-slate-400 animate-bounce [animation-delay:0.4s]"></span>
                          </div>
                        </div>
                      )}

                      <div ref={chatEndRef} />
                    </div>

                    {/* Message input form */}
                    <form onSubmit={handleSendMessage} className="p-4 border-t border-slate-100 flex gap-3">
                      <input
                        type="text"
                        required
                        value={newMessageText}
                        onChange={(e) => setNewMessageText(e.target.value)}
                        placeholder="Type medical questions, drug interactions check..."
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                      />
                      <button
                        type="submit"
                        className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl px-5 py-2.5 text-sm font-semibold shadow-sm flex items-center gap-1.5 shrink-0"
                      >
                        <span>Send</span>
                        <ArrowRight className="h-4 w-4" />
                      </button>
                    </form>

                  </div>

                </div>

              </div>
            )}


            {/* ==================== ROLE: PATIENT / TAB: REMINDERS ==================== */}
            {activeRole === 'Patient' && activeTab === 'reminders' && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left panel: Add a reminder */}
                  <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
                    <h3 className="text-lg font-bold text-slate-900">Add Medication Reminder</h3>
                    
                    <form onSubmit={handleAddReminder} className="space-y-4">
                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Medication Name:</label>
                        <input
                          type="text"
                          required
                          value={newReminderMed}
                          onChange={(e) => setNewReminderMed(e.target.value)}
                          placeholder="e.g. Atorvastatin 20mg"
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Alert Time:</label>
                          <input
                            type="time"
                            required
                            value={newReminderTime}
                            onChange={(e) => setNewReminderTime(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Frequency:</label>
                          <select
                            value={newReminderFreq}
                            onChange={(e: any) => setNewReminderFreq(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          >
                            <option value="Daily">Daily</option>
                            <option value="Weekly">Weekly</option>
                            <option value="Twice Daily">Twice Daily</option>
                          </select>
                        </div>
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-2.5 rounded-xl text-sm shadow-sm transition-colors"
                      >
                        Schedule Notification Alert
                      </button>
                    </form>

                    <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 text-xs text-emerald-800 space-y-1.5">
                      <p className="font-bold">Compliance Adherence Engine</p>
                      <p className="text-[11px] leading-relaxed text-emerald-700">
                        Patients taking critical medications daily show up to a 42% decrease in urgent clinical readmissions when maintaining a synchronized medication calendar tracker.
                      </p>
                    </div>
                  </div>

                  {/* Right panel: Active Alarm list */}
                  <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-6">Scheduled Medication Alerts</h3>
                    
                    {reminders.length > 0 ? (
                      <div className="divide-y divide-slate-100 space-y-3">
                        {reminders.map(rem => (
                          <div key={rem.id} className="flex items-center justify-between py-3">
                            <div className="flex items-center gap-3">
                              <div className={`h-10 w-10 rounded-full flex items-center justify-center border ${
                                rem.isActive 
                                  ? 'bg-emerald-50 text-emerald-600 border-emerald-200' 
                                  : 'bg-slate-100 text-slate-400 border-slate-200'
                              }`}>
                                <Clock className="h-5 w-5" />
                              </div>
                              <div>
                                <p className={`font-semibold text-sm ${rem.isActive ? 'text-slate-900' : 'text-slate-400 line-through'}`}>
                                  {rem.medicationName}
                                </p>
                                <p className="text-xs text-slate-400 font-mono">Scheduled: {rem.time} ({rem.frequency})</p>
                              </div>
                            </div>

                            <div className="flex items-center gap-4">
                              {/* Toggle slide */}
                              <button
                                onClick={() => handleToggleReminder(rem.id)}
                                className={`w-11 h-6 rounded-full transition-colors relative ${
                                  rem.isActive ? 'bg-emerald-600' : 'bg-slate-300'
                                }`}
                              >
                                <span className={`absolute top-0.5 left-0.5 h-5 w-5 bg-white rounded-full transition-transform ${
                                  rem.isActive ? 'transform translate-x-5' : ''
                                }`}></span>
                              </button>

                              <button
                                onClick={() => handleDeleteReminder(rem.id)}
                                className="text-slate-300 hover:text-red-600"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-16 text-slate-400">
                        <Clock className="h-10 w-10 mx-auto text-slate-300 mb-2" />
                        <h4 className="font-semibold text-slate-700 text-sm">No Active Medication Alarms</h4>
                        <p className="text-xs text-slate-500 mt-1">Schedule alert times on the left to activate compliant push alarms.</p>
                      </div>
                    )}
                  </div>

                </div>

              </div>
            )}


            {/* ==================== ROLE: PHARMACIST / TAB: RX REVIEW QUEUE ==================== */}
            {activeRole === 'Pharmacist' && activeTab === 'rx-queue' && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left Column: List of rx queue */}
                  <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-4">Patient Prescription Queue</h3>
                    
                    <div className="space-y-3">
                      {prescriptions.map(rx => (
                        <div
                          key={rx.id}
                          onClick={() => setRxUnderReview(rx)}
                          className={`p-4 rounded-xl border transition-all cursor-pointer flex justify-between items-center ${
                            rxUnderReview?.id === rx.id
                              ? 'bg-blue-50/50 border-blue-400 shadow-xs'
                              : 'bg-white border-slate-200 hover:bg-slate-50/50'
                          }`}
                        >
                          <div className="space-y-1">
                            <span className="text-[10px] font-bold text-slate-400 font-mono uppercase">ID: {rx.id}</span>
                            <h4 className="font-semibold text-slate-800 text-sm">{rx.medicationName || rx.fileName}</h4>
                            <p className="text-xs text-slate-500">Patient: {rx.patientName}</p>
                          </div>

                          <div className="text-right space-y-1.5">
                            <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full block text-center ${
                              rx.status === 'Approved'
                                ? 'bg-emerald-100 text-emerald-800'
                                : rx.status === 'Rejected'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-amber-100 text-amber-800'
                            }`}>
                              {rx.status}
                            </span>
                            <span className="text-[10px] font-mono text-slate-400">{new Date(rx.uploadedAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right Column: Workstation audit space */}
                  <div className="lg:col-span-6 bg-white p-6 rounded-2xl border border-slate-200">
                    <h3 className="text-lg font-bold text-slate-900 mb-6">Compliance Review Workstation</h3>

                    {rxUnderReview ? (
                      <div className="space-y-6">
                        
                        {/* Prescription Metadata */}
                        <div className="space-y-3 bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm">
                          <div className="flex justify-between items-center">
                            <span className="font-mono font-bold text-blue-800">PRESCRIPTION AUDIT FILE</span>
                            <span className="text-xs text-slate-400">{rxUnderReview.id}</span>
                          </div>

                          <div className="space-y-2 border-t border-slate-200 pt-3">
                            <div>
                              <label className="text-[11px] font-semibold text-slate-400 block uppercase">Decoded Medication Name:</label>
                              <input
                                type="text"
                                value={rxUnderReview.medicationName || ''}
                                onChange={(e) => setRxUnderReview({ ...rxUnderReview, medicationName: e.target.value })}
                                className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 focus:outline-hidden focus:ring-1 focus:ring-blue-400"
                              />
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="text-[11px] font-semibold text-slate-400 block uppercase">Strength:</label>
                                <input
                                  type="text"
                                  value={rxUnderReview.strength || ''}
                                  onChange={(e) => setRxUnderReview({ ...rxUnderReview, strength: e.target.value })}
                                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                                />
                              </div>
                              <div>
                                <label className="text-[11px] font-semibold text-slate-400 block uppercase">Dosage Form:</label>
                                <input
                                  type="text"
                                  value={rxUnderReview.dosage || ''}
                                  onChange={(e) => setRxUnderReview({ ...rxUnderReview, dosage: e.target.value })}
                                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-3">
                              <div>
                                <label className="text-[11px] font-semibold text-slate-400 block uppercase">Prescriber MD:</label>
                                <input
                                  type="text"
                                  value={rxUnderReview.doctorName || ''}
                                  onChange={(e) => setRxUnderReview({ ...rxUnderReview, doctorName: e.target.value })}
                                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                                />
                              </div>
                              <div>
                                <label className="text-[11px] font-semibold text-slate-400 block uppercase">MD License Registry:</label>
                                <input
                                  type="text"
                                  value={rxUnderReview.doctorLicense || ''}
                                  onChange={(e) => setRxUnderReview({ ...rxUnderReview, doctorLicense: e.target.value })}
                                  className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                                />
                              </div>
                            </div>

                            <div>
                              <label className="text-[11px] font-semibold text-slate-400 block uppercase">Prescriber's Directions (Sig):</label>
                              <textarea
                                value={rxUnderReview.directions || ''}
                                rows={2}
                                onChange={(e) => setRxUnderReview({ ...rxUnderReview, directions: e.target.value })}
                                className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-900"
                              />
                            </div>
                          </div>
                        </div>

                        {/* Smart AI clinical advisor notes */}
                        <div className="space-y-1.5">
                          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block">Gemini Clinical Advisory Support:</span>
                          <div className="bg-slate-900 text-slate-100 p-4 rounded-xl font-mono text-xs leading-relaxed">
                            {rxUnderReview.aiAnalysis || 'No active AI scan data compiled.'}
                          </div>
                        </div>

                        {/* Pharmacist validation notes */}
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Add Pharmacist Clinical Notes (Required for Audit):</label>
                          <textarea
                            rows={2}
                            value={rxUnderReview.pharmacistNotes || ''}
                            onChange={(e) => setRxUnderReview({ ...rxUnderReview, pharmacistNotes: e.target.value })}
                            placeholder="Add registry check comments, telehealth consult verification, etc."
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          />
                        </div>

                        {/* Approve/Reject decision */}
                        <div className="flex gap-4 border-t border-slate-100 pt-4">
                          <button
                            onClick={() => handleReviewDecision('Rejected')}
                            className="flex-1 border border-red-200 text-red-700 bg-red-50 hover:bg-red-100/60 rounded-xl py-2.5 text-xs font-bold transition-colors"
                          >
                            Reject & Flag Prescription
                          </button>
                          <button
                            onClick={() => handleReviewDecision('Approved')}
                            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white rounded-xl py-2.5 text-xs font-bold transition-all shadow-sm"
                          >
                            Approve & Sign Electronic Release
                          </button>
                        </div>

                      </div>
                    ) : (
                      <div className="h-64 flex flex-col items-center justify-center text-center text-slate-400 border-2 border-dashed border-slate-100 rounded-xl p-6">
                        <UserCheck className="h-12 w-12 text-slate-200 mb-2" />
                        <h5 className="font-semibold text-slate-700 text-sm">Select Prescription from Queue</h5>
                        <p className="text-xs text-slate-500 max-w-xs mx-auto mt-1">Review Patient details, inspect automatic Gemini Safety flags, insert clinician logs, and approve medicines for dispatch.</p>
                      </div>
                    )}
                  </div>

                </div>

              </div>
            )}


            {/* ==================== ROLE: PHARMACIST / TAB: INVENTORY ==================== */}
            {activeRole === 'Pharmacist' && activeTab === 'inventory' && (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
                
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Active Pharmacy Stock Inventory</h3>
                    <p className="text-xs text-slate-500">Live regulatory logs of access-controlled prescription medicines and OTCs.</p>
                  </div>
                  <button
                    onClick={() => {
                      setEditingProduct({
                        name: '',
                        category: 'OTC',
                        activeIngredients: '',
                        strength: '',
                        dosageForm: '',
                        manufacturer: '',
                        regulatoryInfo: '',
                        contraindications: '',
                        warnings: '',
                        directions: '',
                        stock: 100,
                        price: 15.00,
                        image: 'Tablet',
                        description: ''
                      });
                      setActiveRole('Administrator');
                      setActiveTab('catalogue-admin');
                    }}
                    className="bg-slate-900 hover:bg-slate-800 text-white font-semibold py-2 px-4 rounded-xl text-xs flex items-center gap-1.5 shadow-sm"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    Add Product
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm text-slate-600">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                        <th className="px-4 py-3">Medication Name</th>
                        <th className="px-4 py-3">Category</th>
                        <th className="px-4 py-3">Active Ingredients</th>
                        <th className="px-4 py-3">Stock Units</th>
                        <th className="px-4 py-3">Unit Price</th>
                        <th className="px-4 py-3">Audit Alert Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {products.map(p => (
                        <tr key={p.id} className="hover:bg-slate-50/50">
                          <td className="px-4 py-3.5 font-bold text-slate-800 text-sm">
                            <div className="flex items-center gap-2">
                              <span>{p.name}</span>
                              {p.isAccessControlled && (
                                <span className="bg-red-50 text-red-700 text-[9px] px-1.5 py-0.5 rounded-md font-mono">SECURE</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3.5">
                            <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-md">
                              {p.category}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 font-mono text-xs text-slate-500">{p.activeIngredients} ({p.strength})</td>
                          <td className="px-4 py-3.5">
                            <span className={`font-mono text-xs font-semibold ${p.stock < 100 ? 'text-red-600 font-bold' : 'text-slate-800'}`}>
                              {p.stock}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 font-mono text-xs font-semibold">£{p.price.toFixed(2)}</td>
                          <td className="px-4 py-3.5">
                            {p.stock < 100 ? (
                              <span className="text-[10px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full uppercase">
                                Low Stock Alert
                              </span>
                            ) : (
                              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full uppercase">
                                Stock Stable
                              </span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>
            )}


            {/* ==================== ROLE: PHARMACIST / TAB: PATIENT CONSULTATION HUB ==================== */}
            {activeRole === 'Pharmacist' && activeTab === 'ph-chat' && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[65vh]">
                  
                  {/* Patients list column */}
                  <div className="lg:col-span-4 bg-white p-6 rounded-2xl border border-slate-200 flex flex-col justify-between">
                    <div className="space-y-6">
                      <h4 className="font-bold text-slate-900 text-lg">Active Consultations</h4>
                      
                      <div className="p-4 bg-blue-50/40 border border-blue-200 rounded-xl space-y-1 cursor-pointer">
                        <div className="flex justify-between items-center">
                          <span className="font-semibold text-slate-800 text-sm">Jane Doe</span>
                          <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                        </div>
                        <p className="text-xs text-slate-500">tom@ahyx.org</p>
                        <p className="text-[11px] text-blue-700 font-semibold mt-1">Statin & Ibuprofen interaction query</p>
                      </div>
                    </div>

                    <p className="text-xs text-slate-400">MedBridge Pharmacy Consult Room v2.4.9</p>
                  </div>

                  {/* Pharmacist answer panel */}
                  <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 flex flex-col overflow-hidden h-full">
                    
                    <div className="bg-slate-50 px-6 py-4 border-b border-slate-100 flex justify-between items-center">
                      <div>
                        <p className="font-semibold text-slate-900 text-sm">Consultation: Jane Doe</p>
                        <p className="text-xs text-slate-400 font-mono">Registry NHS No: NHS-99420-G</p>
                      </div>
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] px-2.5 py-0.5 rounded-full font-bold">ONLINE CHAT</span>
                    </div>

                    {/* Messages logs */}
                    <div className="flex-1 overflow-y-auto p-6 space-y-4">
                      {messages.map(msg => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.sender === 'Pharmacist' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm ${
                            msg.sender === 'Pharmacist'
                              ? 'bg-blue-600 text-white rounded-tr-none'
                              : 'bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200/60'
                          }`}>
                            <p className="leading-relaxed">{msg.text}</p>
                            <span className="block text-[9px] text-right mt-1 opacity-70">
                              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Reply Form */}
                    <div className="p-4 border-t border-slate-100 bg-slate-50 text-xs text-slate-500 text-center italic">
                      Consultation responses must be logged in accordance with General Pharmaceutical Council directives. Switch to the 'Patient Portal' to interact and chat live with the pharmacist assistant!
                    </div>

                  </div>

                </div>

              </div>
            )}


            {/* ==================== ROLE: ADMINISTRATOR / TAB: OPERATIONS ANALYTICS ==================== */}
            {activeRole === 'Administrator' && activeTab === 'analytics' && (
              <div className="space-y-8">
                
                {/* Metrics Stats grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                  
                  <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
                    <span className="text-slate-400 text-xs font-semibold uppercase block">Total Store Sales</span>
                    <p className="text-3xl font-extrabold text-slate-900">£{(analytics?.metrics?.totalRevenue || 12850.00).toFixed(2)}</p>
                    <span className="text-emerald-600 text-xs font-semibold block">▲ +14.2% Month-Over-Month</span>
                  </div>

                  <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
                    <span className="text-slate-400 text-xs font-semibold uppercase block">Active Reg Patients</span>
                    <p className="text-3xl font-extrabold text-slate-900">{analytics?.metrics?.activePatients || 124}</p>
                    <span className="text-slate-500 text-xs block">Clinical telemetry synchronized</span>
                  </div>

                  <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
                    <span className="text-slate-400 text-xs font-semibold uppercase block">Pending Prescription reviews</span>
                    <p className="text-3xl font-extrabold text-slate-900">{analytics?.metrics?.pendingRxCount || 1}</p>
                    <span className="text-amber-600 text-xs font-semibold block">● Urgent pharmacist action required</span>
                  </div>

                  <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-2">
                    <span className="text-slate-400 text-xs font-semibold uppercase block">Low Stock Alerts</span>
                    <p className="text-3xl font-extrabold text-slate-900">{analytics?.metrics?.lowStockAlerts || 1}</p>
                    <span className="text-red-600 text-xs font-semibold block">▼ Below safe boundary thresholds</span>
                  </div>

                </div>

                {/* Simulated SVG High Fidelity Charts */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Sales performance chart */}
                  <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
                    <div>
                      <h4 className="font-bold text-slate-900 text-base">Monthly Corporate Gross Profit (£)</h4>
                      <p className="text-xs text-slate-500 font-mono">Fiscal Year 2026 - Secure EHR & Dispensing</p>
                    </div>

                    <div className="h-64 flex items-end justify-between pt-6 px-4">
                      {analytics?.salesOverTime?.map((d: any, idx: number) => (
                        <div key={idx} className="flex flex-col items-center gap-2 w-12">
                          <span className="text-[10px] font-mono font-semibold text-slate-600">£{d.sales}</span>
                          <div
                            style={{ height: `${(d.sales / 5000) * 160}px` }}
                            className="w-full bg-purple-600 hover:bg-purple-700 rounded-t-lg transition-all"
                          ></div>
                          <span className="text-xs font-semibold text-slate-400 mt-1">{d.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Category breakdown pie chart */}
                  <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
                    <h4 className="font-bold text-slate-900 text-base">Medication Type Distribution</h4>
                    
                    <div className="space-y-3 pt-4">
                      {analytics?.categoryDistribution?.map((c: any, idx: number) => (
                        <div key={idx} className="space-y-1">
                          <div className="flex justify-between text-xs font-semibold text-slate-600">
                            <span>{c.name}</span>
                            <span className="font-mono">{c.count} items ({Math.round((c.count / products.length) * 100)}%)</span>
                          </div>
                          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                            <div
                              style={{ width: `${(c.count / products.length) * 100}%` }}
                              className={`h-full rounded-full ${
                                idx === 0 ? 'bg-emerald-600' :
                                idx === 1 ? 'bg-blue-600' :
                                idx === 2 ? 'bg-amber-500' : 'bg-purple-600'
                              }`}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

                {/* EHR Compliance Metrics */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200">
                  <h4 className="font-bold text-slate-900 text-base mb-4">Enterprise Pharmacy Quality Metrics</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
                    <div className="space-y-1">
                      <span className="text-2xl font-bold text-slate-900 font-mono">99.4%</span>
                      <p className="text-xs text-slate-500">Perfect Dispense Accuracy Rate</p>
                    </div>
                    <div className="space-y-1 border-y sm:border-y-0 sm:border-x border-slate-100 py-3 sm:py-0">
                      <span className="text-2xl font-bold text-slate-900 font-mono">&lt; 4 mins</span>
                      <p className="text-xs text-slate-500">Gemini Rx Decoding Latency</p>
                    </div>
                    <div className="space-y-1">
                      <span className="text-2xl font-bold text-slate-900 font-mono">100%</span>
                      <p className="text-xs text-slate-500">HIPAA & GPhC Reg Audit Compliance</p>
                    </div>
                  </div>
                </div>

              </div>
            )}


            {/* ==================== ROLE: ADMINISTRATOR / TAB: CATALOGUE EDITOR ==================== */}
            {activeRole === 'Administrator' && activeTab === 'catalogue-admin' && (
              <div className="space-y-6">
                
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                  
                  {/* Left Column: Editor Form */}
                  <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
                    <h3 className="text-lg font-bold text-slate-900">
                      {editingProduct?.id ? 'Modify Medical Item' : 'Register New Medical Item'}
                    </h3>

                    <form onSubmit={handleSaveProduct} className="space-y-4">
                      
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Medicine Name:</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Lipitor"
                            value={editingProduct?.name || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm focus:outline-hidden"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Category:</label>
                          <select
                            value={editingProduct?.category || 'OTC'}
                            onChange={(e: any) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          >
                            <option value="Prescription">Prescription (Rx)</option>
                            <option value="OTC">Over-the-Counter (OTC)</option>
                            <option value="Vitamins">Vitamins</option>
                            <option value="Devices">Devices</option>
                            <option value="Wellness">Wellness</option>
                            <option value="Personal Care">Personal Care</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Active Ingredients:</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. Atorvastatin"
                            value={editingProduct?.activeIngredients || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, activeIngredients: e.target.value })}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Strength:</label>
                          <input
                            type="text"
                            required
                            placeholder="e.g. 20mg"
                            value={editingProduct?.strength || ''}
                            onChange={(e) => setEditingProduct({ ...editingProduct, strength: e.target.value })}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Stock Level (Units):</label>
                          <input
                            type="number"
                            required
                            value={editingProduct?.stock || 100}
                            onChange={(e) => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Price (£ GBP):</label>
                          <input
                            type="number"
                            step="0.01"
                            required
                            value={editingProduct?.price || 10.00}
                            onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Regulatory Info (EHR constraints):</label>
                        <input
                          type="text"
                          placeholder="FDA Approved Schedule..."
                          value={editingProduct?.regulatoryInfo || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, regulatoryInfo: e.target.value })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Warnings & Contraindications:</label>
                        <textarea
                          rows={2}
                          placeholder="May cause myopathy, rhabdomyolysis..."
                          value={editingProduct?.warnings || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, warnings: e.target.value })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm text-xs font-sans"
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Brief Description:</label>
                        <textarea
                          rows={2}
                          placeholder="Lipid-lowering HMG-CoA statin..."
                          value={editingProduct?.description || ''}
                          onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-sm text-xs font-sans"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2.5 rounded-xl text-sm shadow-sm transition-colors"
                      >
                        Save & Commit to DB Catalogue
                      </button>

                    </form>
                  </div>

                  {/* Right Column: Listing for selection */}
                  <div className="lg:col-span-7 bg-white p-6 rounded-2xl border border-slate-200 space-y-4">
                    <h3 className="text-lg font-bold text-slate-900">Catalogue Management Directory</h3>
                    
                    <div className="space-y-3 overflow-y-auto max-h-[75vh]">
                      {products.map(p => (
                        <div key={p.id} className="flex justify-between items-center p-3.5 border border-slate-100 rounded-xl hover:bg-slate-50">
                          <div className="space-y-0.5">
                            <h4 className="font-semibold text-slate-800 text-sm">{p.name}</h4>
                            <p className="text-xs font-mono text-slate-400">ID: {p.id} | active: {p.activeIngredients}</p>
                          </div>
                          
                          <button
                            onClick={() => setEditingProduct(p)}
                            className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold py-1 px-3.5 rounded-lg text-xs"
                          >
                            Edit
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>

              </div>
            )}


            {/* ==================== ROLE: ADMINISTRATOR / TAB: SECURE COMPLIANCE INFRASTRUCTURE ==================== */}
            {activeRole === 'Administrator' && activeTab === 'compliance' && (
              <div className="space-y-6">
                
                <div className="bg-slate-900 text-slate-200 p-6 rounded-2xl border border-slate-800 flex justify-between items-center">
                  <div className="space-y-1">
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Cpu className="h-5 w-5 text-emerald-400" />
                      MedBridge GKE & Docker Enterprise Configurations
                    </h3>
                    <p className="text-xs text-slate-400 max-w-2xl">
                      Production Kubernetes container descriptors, load-balancer ingresses, multi-replica setups, and automated GitHub Action security scan (SAST) pipelines for high availability deployment.
                    </p>
                  </div>
                  <span className="bg-emerald-900/40 text-emerald-400 border border-emerald-800 text-xs font-mono px-3 py-1 rounded-md">
                    VERSION v1.2.4
                  </span>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                  
                  {/* Dockerfile Panel */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between">
                    <div className="space-y-3">
                      <h4 className="font-bold text-slate-900 text-base">Dockerfile</h4>
                      <p className="text-xs text-slate-400">Production Node.js Alpine multi-stage builder targeting minimized container size.</p>
                      
                      <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl max-h-96 overflow-y-auto whitespace-pre leading-relaxed border border-slate-900">
                        {ARTIFACTS.dockerfile}
                      </div>
                    </div>
                  </div>

                  {/* Kubernetes YAML Panel */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between">
                    <div className="space-y-3">
                      <h4 className="font-bold text-slate-900 text-base">Kubernetes Deployment</h4>
                      <p className="text-xs text-slate-400">Enterprise deployment descriptor with liveness probes and resource boundary bounds.</p>
                      
                      <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl max-h-96 overflow-y-auto whitespace-pre leading-relaxed border border-slate-900">
                        {ARTIFACTS.kubernetes}
                      </div>
                    </div>
                  </div>

                  {/* GitHub Actions YAML Panel */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 flex flex-col justify-between">
                    <div className="space-y-3">
                      <h4 className="font-bold text-slate-900 text-base">CI/CD Production YAML</h4>
                      <p className="text-xs text-slate-400">GitHub Workflows checking SAST scans, build validation, and rolling out to GKE.</p>
                      
                      <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl max-h-96 overflow-y-auto whitespace-pre leading-relaxed border border-slate-900">
                        {ARTIFACTS.cicd}
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            )}


            {/* ==================== ROLE: ADMINISTRATOR / TAB: SECURITY AUDIT LOGS ==================== */}
            {activeRole === 'Administrator' && activeTab === 'audit-logs' && (
              <div className="bg-white p-6 rounded-2xl border border-slate-200 space-y-6">
                
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-slate-900">Real-Time System Audit Logs</h3>
                    <p className="text-xs text-slate-500 font-sans">Mandatory HIPAA and pharmaceutical compliance logs detailing logins, reviews, and GSL syncs.</p>
                  </div>
                  <button
                    onClick={forceSync}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 transition-colors"
                  >
                    <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                    Refresh Logs
                  </button>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm text-slate-600">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-100 text-slate-500 font-medium">
                        <th className="px-4 py-3">Timestamp</th>
                        <th className="px-4 py-3">Operator</th>
                        <th className="px-4 py-3">Role</th>
                        <th className="px-4 py-3">Action Description</th>
                        <th className="px-4 py-3">Compliance status</th>
                        <th className="px-4 py-3">Details</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-sans">
                      {auditLogs.map(log => (
                        <tr key={log.id} className="hover:bg-slate-50/50">
                          <td className="px-4 py-3.5 text-xs text-slate-400 font-mono">
                            {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                          </td>
                          <td className="px-4 py-3.5 font-semibold text-slate-800 text-xs">{log.user}</td>
                          <td className="px-4 py-3.5">
                            <span className="text-xs font-semibold text-slate-500 font-mono">{log.role}</span>
                          </td>
                          <td className="px-4 py-3.5 font-semibold text-slate-900 text-xs">{log.action}</td>
                          <td className="px-4 py-3.5">
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                              log.status === 'Success'
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-red-50 text-red-700 border border-red-200'
                            }`}>
                              {log.status}
                            </span>
                          </td>
                          <td className="px-4 py-3.5 text-xs text-slate-500 italic max-w-xs truncate">{log.details}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

              </div>
            )}


            {/* ==================== BOTH: REST API SPECS TAB ==================== */}
            {activeTab === 'api-specs' && (
              <div className="space-y-6">
                
                <div className="bg-slate-900 text-slate-200 p-6 rounded-2xl border border-slate-800 flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Database className="h-5 w-5 text-emerald-400" />
                      MedBridge Production JSON REST APIs Specs
                    </h3>
                    <p className="text-xs text-slate-400 max-w-2xl">
                      Exposed REST endpoints serving backend products inventories, encrypted chat payloads, safety validations, and audit logs complying with GSL standards.
                    </p>
                  </div>
                  <span className="bg-emerald-900/40 text-emerald-400 border border-emerald-800 text-xs font-mono px-3 py-1 rounded-md">
                    HTTPS PROTOCOL ACTIVE
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  
                  {/* Products API */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="bg-emerald-50 text-emerald-800 text-xs font-bold font-mono px-2 py-0.5 rounded-md uppercase">GET /api/products</span>
                      <span className="text-xs text-slate-400">Fetch Medicine Inventory</span>
                    </div>
                    <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl leading-relaxed border border-slate-900">
{`Response Array Schema:
[
  {
    "id": "p-1",
    "name": "Atorvastatin (Lipitor)",
    "category": "Prescription",
    "activeIngredients": "Atorvastatin Calcium",
    "strength": "20mg",
    "stock": 240,
    "price": 45.00
  }
]`}
                    </div>
                  </div>

                  {/* Prescriptions API */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="bg-emerald-50 text-emerald-800 text-xs font-bold font-mono px-2 py-0.5 rounded-md uppercase">POST /api/prescriptions</span>
                      <span className="text-xs text-slate-400">Upload & Gemini Safety Scan</span>
                    </div>
                    <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl leading-relaxed border border-slate-900">
{`Payload Body JSON:
{
  "patientName": "Jane Doe",
  "patientEmail": "tom@ahyx.org",
  "fileName": "prescription_doe_2026.pdf"
}

Response Decoded Output:
{
  "id": "rx-904",
  "medicationName": "Amoxicillin Trihydrate",
  "contraindicationsCheck": "Safe",
  "aiAnalysis": "PRESCRIPTION VALIDATION SUMMARY..."
}`}
                    </div>
                  </div>

                  {/* Orders API */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="bg-blue-50 text-blue-800 text-xs font-bold font-mono px-2 py-0.5 rounded-md uppercase">POST /api/orders</span>
                      <span className="text-xs text-slate-400">Checkout Dispatch Order</span>
                    </div>
                    <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl leading-relaxed border border-slate-900">
{`Payload Body JSON:
{
  "patientName": "Jane Doe",
  "items": [{ "productId": "p-1", "quantity": 1 }],
  "type": "Delivery",
  "totalAmount": 45.00,
  "prescriptionId": "rx-102"
}

Response Invoice Output:
{
  "id": "ord-2026-340",
  "status": "Pending Review",
  "paymentStatus": "Paid"
}`}
                    </div>
                  </div>

                  {/* Secure Messages API */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="bg-purple-50 text-purple-800 text-xs font-bold font-mono px-2 py-0.5 rounded-md uppercase">POST /api/messages</span>
                      <span className="text-xs text-slate-400">Secure Pharmacist E2EE Chat</span>
                    </div>
                    <div className="bg-slate-950 text-slate-300 font-mono text-[10px] p-4 rounded-xl leading-relaxed border border-slate-900">
{`Payload Body JSON:
{
  "sender": "Patient",
  "text": "Can I take ibuprofen with atorvastatin?"
}

Response Clinical Output:
{
  "patientMessage": { "id": "m-102", "text": "..." },
  "pharmacistMessage": { "id": "m-103", "text": "Hello, there is no major interaction..." }
}`}
                    </div>
                  </div>

                </div>

              </div>
            )}

          </motion.div>
        </AnimatePresence>
      </main>

      {/* Modern, Clean Professional Footer */}
      <footer className="bg-white border-t border-slate-200 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4 text-slate-500 text-xs font-mono">
          <div className="flex items-center gap-2">
            <ShieldAlert className="h-4.5 w-4.5 text-emerald-600" />
            <span>MedBridge Enterprise Pharmacy Services Inc. Reg: PH-2026-9042</span>
          </div>
          <div className="flex gap-6">
            <span>GDPR COMPLIANT</span>
            <span>HIPAA PRIVACY CIPHER</span>
            <span>GPhC REGISTERED</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
