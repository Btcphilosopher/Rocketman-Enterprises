export interface Product {
  id: string;
  name: string;
  category: 'Prescription' | 'OTC' | 'Vitamins' | 'Devices' | 'Wellness' | 'Personal Care';
  activeIngredients: string;
  strength: string;
  dosageForm: string;
  manufacturer: string;
  regulatoryInfo: string;
  contraindications: string;
  warnings: string;
  directions: string;
  stock: number;
  price: number;
  image: string; // Icon name from lucide-react or class
  description: string;
  isAccessControlled?: boolean;
}

export interface Prescription {
  id: string;
  patientName: string;
  patientEmail: string;
  uploadedAt: string;
  fileName: string;
  fileData?: string; // base64 representation if uploaded
  status: 'Pending Review' | 'Approved' | 'Rejected';
  medicationName?: string;
  strength?: string;
  dosage?: string;
  directions?: string;
  doctorName?: string;
  doctorLicense?: string;
  pharmacistNotes?: string;
  aiAnalysis?: string;
  contraindicationsCheck?: 'Safe' | 'Warning' | 'Critical';
}

export interface Order {
  id: string;
  patientName: string;
  patientEmail: string;
  items: {
    productId: string;
    productName: string;
    quantity: number;
    price: number;
    isPrescription: boolean;
  }[];
  status: 'Pending Review' | 'Processing' | 'Dispensed' | 'Shipped' | 'Delivered' | 'Cancelled';
  type: 'Delivery' | 'Click & Collect';
  deliveryAddress?: string;
  deliverySchedule?: string;
  totalAmount: number;
  paymentStatus: 'Pending' | 'Paid' | 'Refunded';
  prescriptionId?: string;
  createdAt: string;
}

export interface Message {
  id: string;
  sender: 'Patient' | 'Pharmacist' | 'System';
  timestamp: string;
  text: string;
  patientEmail: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  user: string;
  role: 'Patient' | 'Pharmacist' | 'Administrator' | 'System';
  action: string;
  status: 'Success' | 'Failed' | 'Warning';
  details: string;
}

export interface ReminderSetting {
  id: string;
  patientEmail: string;
  medicationName: string;
  time: string; // e.g. "08:00", "20:00"
  frequency: 'Daily' | 'Weekly' | 'Twice Daily';
  isActive: boolean;
}
