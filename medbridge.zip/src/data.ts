import { Product } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'p-1',
    name: 'Atorvastatin (Lipitor)',
    category: 'Prescription',
    activeIngredients: 'Atorvastatin Calcium',
    strength: '20mg',
    dosageForm: 'Oral Tablet',
    manufacturer: 'Pfizer Inc.',
    regulatoryInfo: 'FDA Approved - Schedule IV Prescription Medicine. Requires valid medical doctor prescription upload.',
    contraindications: 'Active liver disease, pregnancy, breastfeeding, co-administration with strong CYP3A4 inhibitors (e.g., ketoconazole).',
    warnings: 'May cause myopathy, rhabdomyolysis, liver enzyme elevations. Monitor liver function tests (LFT) and creatine kinase (CK) if muscle pain occurs.',
    directions: 'Take 1 tablet daily in the evening, with or without food. Avoid excessive consumption of grapefruit juice.',
    stock: 240,
    price: 45.00,
    image: 'Pills',
    description: 'HMG-CoA reductase inhibitor (statin) used to lower cholesterol, low-density lipoproteins (LDL), and triglycerides, and to reduce risk of cardiovascular events.',
    isAccessControlled: true
  },
  {
    id: 'p-2',
    name: 'Amoxicillin Trihydrate',
    category: 'Prescription',
    activeIngredients: 'Amoxicillin',
    strength: '500mg',
    dosageForm: 'Oral Capsule',
    manufacturer: 'Sandoz Pharmaceuticals',
    regulatoryInfo: 'FDA Approved - Antibiotic Rx-only medication. Strict dispensing logs required.',
    contraindications: 'Hypersensitivity to penicillin, ampicillin, or other beta-lactam antibiotics.',
    warnings: 'Serious and occasionally fatal hypersensitivity (anaphylactic) reactions reported. Pseudomembranous colitis risk (Clostridioides difficile-associated diarrhea).',
    directions: 'Take 1 capsule every 8 hours for 7-10 days as prescribed. Complete the full course even if feeling better.',
    stock: 180,
    price: 22.50,
    image: 'Pills',
    description: 'Broad-spectrum penicillin antibiotic indicated for the treatment of infections of the ear, nose, throat, genitourinary tract, skin, and lower respiratory tract.',
    isAccessControlled: true
  },
  {
    id: 'p-3',
    name: 'Lisinopril (Zestril)',
    category: 'Prescription',
    activeIngredients: 'Lisinopril Anhydrous',
    strength: '10mg',
    dosageForm: 'Oral Tablet',
    manufacturer: 'AstraZeneca',
    regulatoryInfo: 'FDA Approved - ACE Inhibitor Prescription Medication.',
    contraindications: 'History of angioedema related to previous ACE inhibitor treatment, co-administration with aliskiren in patients with diabetes, pregnancy (fetal toxicity).',
    warnings: 'Risk of angioedema (swelling of face/throat), severe hypotension, hyperkalemia, and impaired renal function.',
    directions: 'Take 1 tablet daily at the same time every morning. Monitor serum potassium and blood pressure regularly.',
    stock: 310,
    price: 15.80,
    image: 'Pills',
    description: 'Angiotensin-Converting Enzyme (ACE) inhibitor indicated for the treatment of hypertension, adjunctive therapy in heart failure, and post-myocardial infarction recovery.',
    isAccessControlled: true
  },
  {
    id: 'p-4',
    name: 'Acetaminophen (Tylenol Extra Strength)',
    category: 'OTC',
    activeIngredients: 'Acetaminophen (Paracetamol)',
    strength: '500mg',
    dosageForm: 'Oral Caplet',
    manufacturer: 'McNeil Consumer Healthcare',
    regulatoryInfo: 'Approved Over-the-Counter medicine. General sale list.',
    contraindications: 'Severe hepatic impairment, severe active liver disease, hypersensitivity to paracetamol.',
    warnings: 'Liver warning: This product contains acetaminophen. Severe liver damage may occur if you take more than 4,000 mg in 24 hours, or take with other drugs containing acetaminophen.',
    directions: 'Take 1-2 caplets every 6 hours while symptoms last. Do not exceed 8 caplets (4,000 mg) in any 24-hour period unless directed by a doctor.',
    stock: 850,
    price: 9.99,
    image: 'Tablet',
    description: 'Fast-acting fever reducer and pain reliever for minor aches, headache, backache, toothache, and common cold symptoms.'
  },
  {
    id: 'p-5',
    name: 'Ibuprofen (Advil Liquid-Gels)',
    category: 'OTC',
    activeIngredients: 'Ibuprofen Potassium',
    strength: '200mg',
    dosageForm: 'Liquid-Filled Capsule',
    manufacturer: 'Haleon',
    regulatoryInfo: 'Approved Over-the-Counter NSAID medicine.',
    contraindications: 'Active gastrointestinal bleeding, history of aspirin-sensitive asthma, severe heart failure, coronary artery bypass graft (CABG) surgery peri-operative pain.',
    warnings: 'NSAID warning: May cause severe stomach bleeding. Risk of heart attack or stroke increases if you use more than directed or for longer than directed.',
    directions: 'Take 1 capsule every 4 to 6 hours while symptoms persist. If pain or fever does not respond to 1 capsule, 2 capsules may be used. Do not exceed 6 capsules in 24 hours.',
    stock: 620,
    price: 12.49,
    image: 'Tablet',
    description: 'Nonsteroidal anti-inflammatory drug (NSAID) used to temporarily relieve minor aches and pains, headaches, menstrual cramps, toothache, and temporarily reduce fever.'
  },
  {
    id: 'p-6',
    name: 'Methylcobalamin B12 Wellness',
    category: 'Vitamins',
    activeIngredients: 'Methylcobalamin (Vitamin B12)',
    strength: '5000mcg',
    dosageForm: 'Sublingual Tablet',
    manufacturer: 'Solgar Nutritional Supplements',
    regulatoryInfo: 'Dietary Supplement. FDA statements not evaluated for curing disease.',
    contraindications: 'Hypersensitivity to cobalt or cobalamin.',
    warnings: 'If you are pregnant, nursing, taking any medications, or have a medical condition, consult your doctor before use.',
    directions: 'As a dietary supplement, take 1 sublingual tablet daily. Place tablet under tongue for 30 seconds before swallowing.',
    stock: 400,
    price: 18.99,
    image: 'Sparkles',
    description: 'Active coenzyme form of Vitamin B12 which promotes energy production, nervous system health, and healthy red blood cells.'
  },
  {
    id: 'p-7',
    name: 'Omron Series 5 Blood Pressure Monitor',
    category: 'Devices',
    activeIngredients: 'N/A (Oscillometric Medical Device)',
    strength: 'Clinical Grade Accuracy',
    dosageForm: 'Electronic Monitor with Cuff',
    manufacturer: 'Omron Healthcare',
    regulatoryInfo: 'FDA Cleared Class II Medical Device.',
    contraindications: 'Do not use on wounded arms, or during intravenous therapies on the same limb.',
    warnings: 'Self-measurement is not self-diagnosis. Do not adjust medication dosages based on readings without consulting a doctor.',
    directions: 'Sit quietly for 5 minutes. Place cuff on upper left arm 1 inch above the elbow. Keep cuff at heart level. Press start.',
    stock: 85,
    price: 64.99,
    image: 'Activity',
    description: 'Advanced clinical oscillometric blood pressure monitor with dual-user memory, irregular heartbeat detector, and bluetooth synchronization app.'
  },
  {
    id: 'p-8',
    name: 'Organic Ashwagandha Extract',
    category: 'Wellness',
    activeIngredients: 'KSM-66 Ashwagandha Root Extract',
    strength: '600mg',
    dosageForm: 'Veggie Capsule',
    manufacturer: 'MedBridge Wellness Labs',
    regulatoryInfo: 'Premium Adaptogen Herbal Supplement. GMP Certified facility.',
    contraindications: 'Autoimmune diseases, upcoming surgeries, gastric ulcers.',
    warnings: 'Do not use if pregnant or nursing. May cause mild drowsiness; avoid combining with strong sedatives.',
    directions: 'Take 1 capsule twice daily with warm water or food, or as directed by a healthcare professional.',
    stock: 190,
    price: 24.95,
    image: 'Droplet',
    description: 'Clinically proven adaptogenic herb that helps reduce cortisol levels, stress, anxiety, and supports overall cognitive function and sleep quality.'
  },
  {
    id: 'p-9',
    name: 'First Aid Professional Kit (120 Pcs)',
    category: 'Personal Care',
    activeIngredients: 'Sterile Dressings, Antiseptic, Bandages',
    strength: 'Comprehensive Emergency Grade',
    dosageForm: 'Nylon Travel Hardcase',
    manufacturer: 'Johnson & Johnson Medical',
    regulatoryInfo: 'CE Certified & ISO 13485 Compliant First Aid Kit.',
    contraindications: 'None.',
    warnings: 'Check expiration dates on sterile components yearly. Replace used items immediately.',
    directions: 'Use for minor cuts, scrapes, burns, and orthopaedic sprains. Keep in an accessible dry location in home or vehicle.',
    stock: 120,
    price: 29.99,
    image: 'Heart',
    description: 'Complete emergency first aid preparedness kit containing antiseptic wipes, burn creams, sterile dressings, emergency blanket, CPR shield, and shears.'
  }
];

// Infrastructure Artifacts for Enterprise Compliance & Setup
export const ARTIFACTS = {
  dockerfile: `FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/package*.json ./
RUN npm ci --only=production
EXPOSE 3000
CMD ["node", "dist/server.cjs"]`,

  kubernetes: `apiVersion: apps/v1
kind: Deployment
metadata:
  name: medbridge-pharmacy
  namespace: medbridge-prod
  labels:
    app: medbridge
    tier: frontend-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: medbridge
  template:
    metadata:
      labels:
        app: medbridge
    spec:
      containers:
      - name: medbridge-app
        image: gcr.io/medbridge-enterprise/app:v1.2.4
        ports:
        - containerPort: 3000
        envFrom:
        - secretRef:
            name: medbridge-secrets
        resources:
          limits:
            cpu: "1000m"
            memory: "1024Mi"
          requests:
            cpu: "250m"
            memory: "512Mi"
        readinessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 15
          periodSeconds: 10
        livenessProbe:
          httpGet:
            path: /api/health
            port: 3000
          initialDelaySeconds: 20
          periodSeconds: 15
---
apiVersion: v1
kind: Service
metadata:
  name: medbridge-service
  namespace: medbridge-prod
spec:
  type: ClusterIP
  ports:
  - port: 80
    targetPort: 3000
  selector:
    app: medbridge`,

  cicd: `name: MedBridge Enterprise CI/CD Production Pipeline

on:
  push:
    branches: [ "main" ]
  pull_request:
    branches: [ "main" ]

jobs:
  validate-and-build:
    runs-on: ubuntu-latest
    steps:
    - name: Checkout Repository
      uses: actions/checkout@v4

    - name: Set up Node.js v20
      uses: actions/setup-node@v4
      with:
        node-version: 20
        cache: 'npm'

    - name: Install Base Dependencies
      run: npm ci

    - name: Static Security Scan (SAST)
      run: npm run lint

    - name: Run Unit & Integration Tests
      run: npm test

    - name: Configure Cloud Credentials
      uses: google-github-actions/auth@v2
      with:
        credentials_json: \${{ secrets.GCP_SA_KEY }}

    - name: Set up Cloud SDK
      uses: google-github-actions/setup-gcloud@v2

    - name: Authorize Docker Push to Artifact Registry
      run: gcloud auth configure-docker europe-west2-docker.pkg.dev

    - name: Build and Push Docker Image
      run: |
        docker build -t europe-west2-docker.pkg.dev/medbridge-gcp/prod/web:\${{ github.sha }} .
        docker push europe-west2-docker.pkg.dev/medbridge-gcp/prod/web:\${{ github.sha }}

  deploy-to-gke:
    needs: validate-and-build
    runs-on: ubuntu-latest
    steps:
    - name: Checkout Deploy Configs
      uses: actions/checkout@v4

    - name: Set up GKE Credentials
      uses: google-github-actions/get-gke-credentials@v2
      with:
        cluster_name: medbridge-prod-cluster
        location: europe-west2
        project_id: medbridge-gcp

    - name: Apply Kubernetes Manifests
      run: |
        kubectl set image deployment/medbridge-pharmacy medbridge-app=europe-west2-docker.pkg.dev/medbridge-gcp/prod/web:\${{ github.sha }} -n medbridge-prod
        kubectl rollout status deployment/medbridge-pharmacy -n medbridge-prod`
};
