export interface Event {
  id: string;
  title: string;
  city: string;
  venue: string;
  date: string; // ISO date string or YYYY-MM-DD
  time: string;
  genres: string[];
  lineup: string[];
  description: string;
  price: number;
  ticketStock: number;
  image: string;
  isFeatured: boolean;
  status: 'upcoming' | 'cancelled' | 'sold_out' | 'live';
}

export interface NewsPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  category: string;
  image: string;
  author: string;
}

export interface Product {
  id: string;
  name: string;
  price: number;
  description: string;
  images: string[];
  sizes: string[];
  stock: number;
  category: 'apparel' | 'accessories' | 'gear';
  isSpotlight: boolean;
}

export interface TicketOrder {
  id: string;
  eventId: string;
  eventTitle: string;
  eventCity: string;
  eventDate: string;
  quantity: number;
  totalPrice: number;
  purchaseDate: string;
  barcode: string;
  status: 'active' | 'used';
}

export interface MerchOrder {
  id: string;
  products: {
    productId: string;
    name: string;
    size: string;
    quantity: number;
    price: number;
  }[];
  totalPrice: number;
  status: 'pending' | 'shipped' | 'delivered';
  date: string;
}

export interface CartItem {
  id: string; // unique for item + size combo
  type: 'ticket' | 'merch';
  referenceId: string; // eventId or productId
  name: string;
  quantity: number;
  price: number;
  size?: string;
  eventDate?: string;
  eventCity?: string;
  image?: string;
}

export interface UserProfile {
  email: string;
  name: string;
  role: 'user' | 'admin';
  savedTickets: TicketOrder[];
  favorites: string[]; // list of eventIds
  orderHistory: MerchOrder[];
}

export interface UserSession {
  isAuthenticated: boolean;
  user: UserProfile | null;
}
