import { Event, NewsPost, Product } from './types';

export const INITIAL_EVENTS: Event[] = [
  {
    id: 'ev-1',
    title: 'FREQUENCY MIAMI',
    city: 'MIAMI, FL',
    venue: 'Mana Wynwood',
    date: '2026-07-12',
    time: '22:00 - 05:00',
    genres: ['Bass', 'Techno', 'House'],
    lineup: ['DESTRUCTO', 'CHRIS LAKE', 'LAYTON GIORDANI', 'VNSSA', 'AC SLATER', 'CLAWZ'],
    description: 'An immersive experience under the neon lights of Miami\'s premier art and music venue. Experience unparalleled laser systems, earth-shaking bass, and the community that drives our culture forward.',
    price: 49.99,
    ticketStock: 350,
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=600&auto=format&fit=crop',
    isFeatured: true,
    status: 'upcoming'
  },
  {
    id: 'ev-2',
    title: 'PROJECT GLOW',
    city: 'WASHINGTON, DC',
    venue: 'RFK Festival Grounds',
    date: '2026-06-07',
    time: '13:00 - 23:00',
    genres: ['Trance', 'House', 'Dubstep'],
    lineup: ['Martin Garrix', 'Illenium', 'Zedd', 'Elderbrook', 'Nora En Pure', 'Wax Motif'],
    description: 'Celebrating a decade of underground electronic dance music in the nation\'s capital. Multiple stages, dynamic graffiti installations, and food trucks supporting local underground arts.',
    price: 79.99,
    ticketStock: 1200,
    image: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=600&auto=format&fit=crop',
    isFeatured: false,
    status: 'upcoming'
  },
  {
    id: 'ev-3',
    title: 'BEYOND WONDERLAND',
    city: 'GEORGE, WA',
    venue: 'The Gorge Amphitheatre',
    date: '2026-06-21',
    time: '14:00 - 02:00',
    genres: ['Hardstyle', 'Trance', 'Psytrance'],
    lineup: ['Sub Zero Project', 'Armin van Buuren', 'Vini Vici', 'Liquid Soul', 'Blastoyz'],
    description: 'Journey down the rabbit hole at the world\'s most scenic venue. High-intensity production meets breathtaking natural canyons. A true rave pilgrimage.',
    price: 89.99,
    ticketStock: 0,
    image: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=600&auto=format&fit=crop',
    isFeatured: false,
    status: 'sold_out'
  },
  {
    id: 'ev-4',
    title: 'HARD SUMMER',
    city: 'INGLEWOOD, CA',
    venue: 'Hollywood Park',
    date: '2026-08-02',
    time: '14:00 - 23:00',
    genres: ['Trap', 'Bass House', 'Hip-Hop'],
    lineup: ['RL Grime', 'Chase & Status', 'Skrillex', 'ISOxo', 'Knock2', 'Netsky'],
    description: 'Where electronic heavy-hitters meet underground hip-hop. The annual California summer ritual returns with standard-setting multi-stage bass production.',
    price: 99.99,
    ticketStock: 850,
    image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=600&auto=format&fit=crop',
    isFeatured: false,
    status: 'upcoming'
  },
  {
    id: 'ev-5',
    title: 'SEATTLE SUBTERRANEAN',
    city: 'SEATTLE, WA',
    venue: 'Sodo Warehouse',
    date: '2026-09-18',
    time: '21:00 - 04:00',
    genres: ['Techno', 'Minimal', 'Acid'],
    lineup: ['GJones', 'Eprom', 'Alix Perez', 'Skeptical', 'Ivy Lab'],
    description: 'A dark, industrial, stripped-back warehouse setting focusing entirely on the raw sound of deep bass, high BPM, and hypnotic minimal techno rhythms.',
    price: 35.00,
    ticketStock: 180,
    image: 'https://images.unsplash.com/photo-1482440308425-276ad0f28b19?q=80&w=600&auto=format&fit=crop',
    isFeatured: false,
    status: 'upcoming'
  },
  {
    id: 'ev-6',
    title: 'RESONANCE CHICAGO',
    city: 'CHICAGO, IL',
    venue: 'Radius Chicago',
    date: '2026-10-31',
    time: '22:00 - 05:00',
    genres: ['Industrial Techno', 'Dark Acid'],
    lineup: ['Charlotte de Witte', 'Enrico Sangiuliano', 'Sama\' Abdulhadi', 'Indira Paganotto'],
    description: 'Chicago\'s premier warehouse venue transformed into an industrial techno playground for an extended Halloween night session. Experience pristine sound systems and immersive visuals.',
    price: 55.00,
    ticketStock: 450,
    image: 'https://images.unsplash.com/photo-1519750157634-b6d493a0f77c?q=80&w=600&auto=format&fit=crop',
    isFeatured: false,
    status: 'live'
  }
];

export const INITIAL_NEWS: NewsPost[] = [
  {
    id: 'news-1',
    title: 'Insomniac Announces EDC Orlando 2026',
    excerpt: 'Get ready for a massive return to Tinker Field with brand new stages and production.',
    content: 'Insomniac has officially revealed the first details for Electric Daisy Carnival (EDC) Orlando 2026, scheduled to take over Tinker Field from November 6-8, 2026. Organizers promise an expanded kineticFIELD, an entirely reimagined circuitGROUNDS, and a brand-new art car lineup. "Orlando holds a special place in our hearts," said Pasquale Rotella, Founder of Insomniac. "The energy of the East Coast headliners is unmatched. For 2026, we are pushing the boundaries of technology and art closer together." Early bird tickets go on sale next Friday, with pre-registrations opening today.',
    date: '2026-05-20',
    category: 'Festivals',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=600&auto=format&fit=crop',
    author: 'PLUR Reporter'
  },
  {
    id: 'news-2',
    title: 'Movement Festival 2026 Reveals Phase 2 Lineup',
    excerpt: 'Detroit\'s techno pilgrimage adds historic legends, avant-garde selectors, and fresh regional talent.',
    content: 'Movement Music Festival in Detroit has dropped its highly anticipated Phase 2 lineup for the 2026 edition, solidifying its place as the global epicenter of techno. Newly added headliners include pioneers of the genre alongside modern iconoclasts. Stage takeovers by prominent underground collectives from Berlin, London, and Tokyo have also been confirmed. With six stages situated across Hart Plaza, the 2026 festival is gearing up to be a stunning homage to Detroit\'s musical legacy and its global impact.',
    date: '2026-05-18',
    category: 'Lineups',
    image: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=600&auto=format&fit=crop',
    author: 'BassHead 4 Life'
  },
  {
    id: 'news-3',
    title: 'The Rise of Underground: A New Wave in US Rave Culture',
    excerpt: 'How DIY warehouse spaces are capturing the authentic vibe of the 90s across major cities.',
    content: 'A quiet revolution is happening in the American electronic music landscape. Tired of commercialized multi-hundred-dollar festivals, a new generation of ravers is turning back to the roots. From abandoned warehouses in Brooklyn and industrial lofts in Chicago to hidden desert valleys in Southern California, DIY rave crews are restoring the original tenets of PLUR (Peace, Love, Unity, Respect). These events prioritize intimate vibes, sound quality over heavy marketing, and local community. We explore the organizers, sound engineers, and dancers making it happen.',
    date: '2026-05-15',
    category: 'Culture',
    image: 'https://images.unsplash.com/photo-1482440308425-276ad0f28b19?q=80&w=600&auto=format&fit=crop',
    author: 'Techno Scholar'
  }
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'RAVE SCENE TEE',
    price: 34.99,
    description: 'Premium heavyweight cotton tee featuring the iconic American Rave Scene fluorescent graffiti graphics on front and back. Boxy fit, preshrunk, and perfect for long dance floor sessions.',
    images: ['https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=600&auto=format&fit=crop'],
    sizes: ['S', 'M', 'L', 'XL'],
    stock: 45,
    category: 'apparel',
    isSpotlight: true
  },
  {
    id: 'prod-2',
    name: 'UNITED HOODIE',
    price: 69.99,
    description: 'Double-lined premium fleece hoodie with electric pink embroidery and neon back-print detailing. Designed to keep you warm during cold festival nights and outdoor sunrise sets.',
    images: ['https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop'],
    sizes: ['M', 'L', 'XL', 'XXL'],
    stock: 22,
    category: 'apparel',
    isSpotlight: true
  },
  {
    id: 'prod-3',
    name: 'RAVE SCENE FAN',
    price: 15.99,
    description: 'High-grade bamboo hand fan with UV-reactive holographic print. Durable ribbing creates a loud, crisp "clack" and maximum wind flow on packed dance floors.',
    images: ['https://images.unsplash.com/photo-1571844307560-f40a15320502?q=80&w=600&auto=format&fit=crop'],
    sizes: ['O/S'],
    stock: 80,
    category: 'accessories',
    isSpotlight: true
  },
  {
    id: 'prod-4',
    name: 'NEON GAFFER CAP',
    price: 24.99,
    description: 'Acid green distressed structural baseball cap with embroidered rave glyphs and an adjustable strap. Heavy duty and festival dirt-proof.',
    images: ['https://images.unsplash.com/photo-1588850561407-ed78c282e89b?q=80&w=600&auto=format&fit=crop'],
    sizes: ['O/S'],
    stock: 12,
    category: 'apparel',
    isSpotlight: false
  },
  {
    id: 'prod-5',
    name: 'CYBER LASH SHADES',
    price: 19.99,
    description: 'Wrap-around mirrored visor sunglasses with UV400 protection. Shield your eyes from intense lasers, strobe lights, and morning sunshine.',
    images: ['https://images.unsplash.com/photo-1511499767150-a48a237f0083?q=80&w=600&auto=format&fit=crop'],
    sizes: ['O/S'],
    stock: 15,
    category: 'accessories',
    isSpotlight: false
  },
  {
    id: 'prod-6',
    name: 'PLUR BACKPACK',
    price: 45.00,
    description: 'Compact holographic hydration backpack equipped with a 2L leak-proof bladder, dual zip pockets, and fluorescent chest straps.',
    images: ['https://images.unsplash.com/photo-1553062407-98eeb64c6a62?q=80&w=600&auto=format&fit=crop'],
    sizes: ['O/S'],
    stock: 8,
    category: 'gear',
    isSpotlight: false
  }
];
