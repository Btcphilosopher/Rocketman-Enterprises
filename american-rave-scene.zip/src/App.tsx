import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  MapPin,
  Calendar,
  Ticket,
  Instagram,
  Youtube,
  Send,
  Sparkles,
  ArrowRight,
  Info,
  X,
  Music,
  Radio,
  FileText
} from 'lucide-react';

import { Event, NewsPost, Product, CartItem, UserProfile } from './types';
import { INITIAL_EVENTS, INITIAL_NEWS, INITIAL_PRODUCTS } from './mockData';

// Modular Components
import ParticleSplash from './components/ParticleSplash';
import Navbar from './components/Navbar';
import Ticker from './components/Ticker';
import Footer from './components/Footer';
import EventDirectory from './components/EventDirectory';
import NewsBlog from './components/NewsBlog';
import MerchStore from './components/MerchStore';
import CheckoutFlow from './components/CheckoutFlow';
import UserDashboard from './components/UserDashboard';
import AdminCMS from './components/AdminCMS';

export default function App() {
  // Navigation & View Route State
  const [activeTab, setActiveTab] = useState<string>('home');
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Persisted Database States (Events, News, Products)
  const [events, setEvents] = useState<Event[]>(() => {
    const saved = localStorage.getItem('ars_events');
    return saved ? JSON.parse(saved) : INITIAL_EVENTS;
  });

  const [news, setNews] = useState<NewsPost[]>(() => {
    const saved = localStorage.getItem('ars_news');
    return saved ? JSON.parse(saved) : INITIAL_NEWS;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('ars_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  // User Session Profile State
  const [user, setUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('ars_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Cart State
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('ars_cart');
    return saved ? JSON.parse(saved) : [];
  });

  // Bookmarks/Favorites State
  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('ars_favorites');
    return saved ? JSON.parse(saved) : [];
  });

  // Detail Navigation References
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [selectedNewsId, setSelectedNewsId] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);

  // Newsletter Signup State
  const [emailInput, setEmailInput] = useState<string>('');

  // Synchronize localStorage effects
  useEffect(() => {
    localStorage.setItem('ars_events', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('ars_news', JSON.stringify(news));
  }, [news]);

  useEffect(() => {
    localStorage.setItem('ars_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('ars_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('ars_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('ars_favorites', JSON.stringify(favorites));
  }, [favorites]);

  // Auth Operations
  const handleLogin = (name: string, email: string) => {
    const profile: UserProfile = {
      name,
      email,
      role: email.includes('promoter') || email.includes('admin') ? 'admin' : 'user',
      savedTickets: [],
      favorites: [],
      orderHistory: [],
    };
    setUser(profile);
    alert(`Connected as ${name}! Check profile or permissions.`);
  };

  const handleLogout = () => {
    setUser(null);
    alert('Disconnected securely.');
  };

  const handleSetUserRole = (role: 'user' | 'admin') => {
    if (user) {
      setUser({ ...user, role });
    }
  };

  // Bookmark toggler
  const handleToggleFavorite = (eventId: string) => {
    if (favorites.includes(eventId)) {
      setFavorites(favorites.filter((id) => id !== eventId));
    } else {
      setFavorites([...favorites, eventId]);
    }
  };

  // Cart Operations
  const handleAddToCart = (item: CartItem) => {
    const existing = cart.find((i) => i.id === item.id);
    if (existing) {
      setCart(
        cart.map((i) => (i.id === item.id ? { ...i, quantity: i.quantity + item.quantity } : i))
      );
    } else {
      setCart([...cart, item]);
    }
  };

  const handleBuyTicketsDirect = (event: Event) => {
    const cartItem: CartItem = {
      id: `ticket-${event.id}`,
      type: 'ticket',
      referenceId: event.id,
      name: `${event.title} Admission Ticket`,
      quantity: 1,
      price: event.price,
      eventDate: event.date,
      eventCity: event.city,
    };
    handleAddToCart(cartItem);
    setActiveTab('cart');
  };

  // Purchase Fulfillment
  const handlePurchaseComplete = (newTickets: any[], newMerchOrders: any[]) => {
    if (!user) {
      // Create guest profile to receive tickets
      const guestProfile: UserProfile = {
        name: 'Guest Raver',
        email: 'guest@ravescene.com',
        role: 'user',
        savedTickets: newTickets,
        favorites: [],
        orderHistory: newMerchOrders,
      };
      setUser(guestProfile);
    } else {
      setUser({
        ...user,
        savedTickets: [...user.savedTickets, ...newTickets],
        orderHistory: [...user.orderHistory, ...newMerchOrders],
      });
    }
  };

  // Detail View Route Shortcuts
  const handleSelectEvent = (id: string) => {
    setSelectedEventId(id);
    setActiveTab('events');
  };

  const handleSelectNews = (id: string) => {
    setSelectedNewsId(id);
    setActiveTab('news');
  };

  const handleSelectProduct = (id: string) => {
    setSelectedProductId(id);
    setActiveTab('merch');
  };

  // Newsletter Submit
  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailInput) return;
    alert(`Transmission Secured! Welcome to the ARS Inner Circle.`);
    setEmailInput('');
  };

  // Featured and Spotlight selections
  const featuredEvent = events.find((e) => e.isFeatured) || events[0];
  const spotlightProducts = products.filter((p) => p.isSpotlight).slice(0, 3);
  const homeEvents = events.slice(0, 4);
  const homeNews = news.slice(0, 3);

  return (
    <div className="min-h-screen bg-[#0a0a0c] text-white flex flex-col justify-between overflow-x-hidden relative">
      {/* 1. Dynamic Interactive Neon Background Canvas */}
      <ParticleSplash />

      {/* 2. Brand Header Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setSelectedEventId(null);
          setSelectedNewsId(null);
          setSelectedProductId(null);
        }}
        cart={cart}
        user={user}
        onSearchClick={() => setSearchOpen(true)}
      />

      {/* 3. Infinite Scene News Feed Ticker */}
      <Ticker />

      {/* 4. Core SPA Views Router */}
      <main className="flex-grow relative z-10">
        <AnimatePresence mode="wait">
          {activeTab === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="space-y-12"
            >
              {/* Hero Featured Area */}
              <div id="hero-banner-container" className="mx-auto max-w-7xl px-4 pt-8">
                <div className="relative rounded-2xl overflow-hidden border border-zinc-900 bg-black/40 backdrop-blur-md min-h-[500px] flex flex-col lg:flex-row items-center justify-between p-6 md:p-12 gap-8 shadow-2xl">
                  {/* Wide atmospheric background lasers */}
                  <div
                    className="absolute inset-0 bg-cover bg-center opacity-25 pointer-events-none"
                    style={{
                      backgroundImage: `url('https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=1200&auto=format&fit=crop')`,
                    }}
                  />
                  {/* Neon radial splash overlay */}
                  <div className="absolute inset-0 bg-radial-at-t from-neon-pink/10 via-transparent to-black pointer-events-none" />

                  {/* Left overlay headers */}
                  <div className="relative z-10 max-w-xl text-center lg:text-left flex flex-col items-center lg:items-start">
                    <h1 className="font-display text-4xl md:text-6xl font-black tracking-tighter leading-none flex flex-col">
                      <span className="text-white">UNITED BY</span>
                      <span className="text-neon-pink drop-shadow-[0_0_12px_#ff007f] font-black italic">MUSIC.</span>
                      <span className="text-white">DRIVEN BY</span>
                      <span className="text-neon-green drop-shadow-[0_0_12px_rgba(57,255,20,0.6)] font-black">FREEDOM.</span>
                    </h1>
                    <p className="mt-6 text-sm md:text-base text-zinc-400 font-mono tracking-wide leading-relaxed">
                      Amplifying underground culture. From coast to coast. This is the American Rave Scene.
                    </p>

                    <div className="mt-8 flex flex-wrap gap-4 justify-center lg:justify-start">
                      <button
                        onClick={() => setActiveTab('events')}
                        className="font-display text-xs font-black tracking-widest text-white border-2 border-neon-pink bg-neon-pink/5 hover:bg-neon-pink hover:text-black hover:shadow-[0_0_15px_#ff007f] px-6 py-3.5 rounded transition-all cursor-pointer flex items-center gap-2 uppercase"
                      >
                        BROWSE EVENTS <ArrowRight className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setActiveTab('account')}
                        className="font-display text-xs font-black tracking-widest text-neon-green border border-neon-green/40 hover:border-neon-green hover:bg-neon-green/10 px-6 py-3.5 rounded transition-all cursor-pointer flex items-center gap-2 uppercase"
                      >
                        JOIN THE SCENE <Sparkles className="w-4 h-4 text-neon-green" />
                      </button>
                    </div>
                  </div>

                  {/* Right: Interactive FEATURED EVENT board */}
                  {featuredEvent && (
                    <div className="relative z-10 w-full lg:max-w-sm border border-neon-pink bg-black/90 p-5 rounded-lg shadow-[0_0_25px_rgba(255,0,127,0.3)] flex flex-col justify-between min-h-[350px]">
                      <div>
                        <span className="font-mono text-[9px] font-bold tracking-widest text-neon-pink block mb-2 uppercase">
                          UPCOMING FEATURED EVENT
                        </span>

                        <h2 className="font-display text-3xl font-black text-white tracking-wider">
                          {featuredEvent.title}
                        </h2>
                        <h3 className="font-display text-xl font-bold text-neon-pink uppercase tracking-wide mt-1">
                          {featuredEvent.city.split(',')[0]}
                        </h3>

                        <div className="font-mono text-xs text-neon-green font-bold mt-3 tracking-widest">
                          {new Date(featuredEvent.date).toLocaleDateString('en-US', {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric',
                          }).toUpperCase()}
                        </div>

                        <p className="font-mono text-xs text-zinc-400 mt-2">
                          {featuredEvent.venue} • {featuredEvent.time}
                        </p>

                        <div className="mt-5 border-t border-zinc-900 pt-4">
                          <span className="font-mono text-[9px] text-zinc-500 block uppercase">LINEUP HIGHLIGHTS</span>
                          <p className="font-mono text-xs text-neon-blue font-bold tracking-wide leading-relaxed mt-1">
                            {featuredEvent.lineup.slice(0, 4).join(' • ')}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleBuyTicketsDirect(featuredEvent)}
                        className="w-full font-display text-[11px] font-black tracking-widest text-white border border-neon-pink bg-neon-pink/10 hover:bg-neon-pink hover:text-black py-3 rounded mt-6 transition-all hover:shadow-[0_0_12px_#ff007f] cursor-pointer flex items-center justify-center gap-2 uppercase"
                      >
                        GET TICKETS <Ticket className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Three Column Grid layout */}
              <div className="mx-auto max-w-7xl px-4 grid grid-cols-1 lg:grid-cols-12 gap-8">
                {/* Column 1: Latest News */}
                <div className="lg:col-span-4 space-y-6">
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                    <h3 className="font-display text-lg font-black tracking-wider text-white border-l-2 border-neon-pink pl-3">
                      LATEST NEWS
                    </h3>
                  </div>

                  <div className="space-y-4">
                    {homeNews.map((item) => (
                      <div
                        key={item.id}
                        id={`home-news-${item.id}`}
                        onClick={() => handleSelectNews(item.id)}
                        className="flex gap-4 p-3 border border-zinc-900/40 hover:border-zinc-800 bg-black/40 rounded hover:shadow-[0_0_12px_rgba(255,0,127,0.05)] transition-all cursor-pointer group"
                      >
                        <img
                          src={item.image}
                          alt={item.title}
                          className="w-16 h-16 object-cover rounded shrink-0 border border-zinc-900"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <span className="font-mono text-[9px] text-zinc-500 uppercase">{item.date}</span>
                          <h4 className="font-display text-xs font-bold uppercase tracking-wide text-zinc-300 group-hover:text-neon-pink transition-colors line-clamp-2 mt-1">
                            {item.title}
                          </h4>
                        </div>
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={() => setActiveTab('news')}
                    className="w-full flex items-center justify-center gap-1.5 font-mono text-xs font-bold text-neon-pink hover:underline cursor-pointer border border-zinc-900 hover:border-zinc-800 bg-black/20 py-2.5 rounded"
                  >
                    VIEW ALL NEWS <ArrowRight className="w-4 h-4 text-neon-pink" />
                  </button>
                </div>

                {/* Column 2: Upcoming Events */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                    <h3 className="font-display text-lg font-black tracking-wider text-white border-l-2 border-neon-green pl-3">
                      UPCOMING EVENTS
                    </h3>
                  </div>

                  <div className="space-y-4">
                    {homeEvents.map((ev) => {
                      const dateObj = new Date(ev.date);
                      const month = dateObj.toLocaleString('en-US', { month: 'short' }).toUpperCase();
                      const day = String(dateObj.getDate()).padStart(2, '0');

                      return (
                        <div
                          key={ev.id}
                          id={`home-event-${ev.id}`}
                          onClick={() => handleSelectEvent(ev.id)}
                          className="flex items-center justify-between gap-4 p-3 border border-zinc-900/40 hover:border-zinc-800 bg-black/40 rounded transition-all cursor-pointer group"
                        >
                          <div className="flex items-center gap-3">
                            {/* Green date tile */}
                            <div className="flex flex-col items-center justify-center shrink-0 w-11 h-11 border border-neon-green bg-neon-green/5 text-neon-green font-mono rounded">
                              <span className="text-[9px] leading-none uppercase">{month}</span>
                              <span className="text-sm font-black tracking-tighter mt-0.5 leading-none">{day}</span>
                            </div>

                            <img
                              src={ev.image}
                              alt={ev.title}
                              className="w-10 h-10 object-cover rounded hidden sm:inline-block border border-zinc-900"
                              referrerPolicy="no-referrer"
                            />

                            <div>
                              <h4 className="font-display text-xs font-bold uppercase tracking-wide text-zinc-300 group-hover:text-neon-green transition-colors line-clamp-1">
                                {ev.title}
                              </h4>
                              <p className="font-mono text-[9px] text-zinc-500 uppercase mt-0.5">
                                {ev.venue} • {ev.city}
                              </p>
                            </div>
                          </div>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleBuyTicketsDirect(ev);
                            }}
                            className="font-display text-[9px] font-bold border border-neon-green text-neon-green hover:bg-neon-green hover:text-black px-2.5 py-1.5 rounded transition-all cursor-pointer shrink-0"
                          >
                            TICKETS
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  <button
                    onClick={() => setActiveTab('events')}
                    className="w-full flex items-center justify-center gap-1.5 font-mono text-xs font-bold text-neon-green hover:underline cursor-pointer border border-zinc-900 hover:border-zinc-800 bg-black/20 py-2.5 rounded"
                  >
                    VIEW ALL EVENTS <ArrowRight className="w-4 h-4 text-neon-green" />
                  </button>
                </div>

                {/* Column 3: Merch spotlight, newsletter, and socials */}
                <div className="lg:col-span-3 space-y-6">
                  <div className="flex items-center justify-between border-b border-zinc-900 pb-3">
                    <h3 className="font-display text-lg font-black tracking-wider text-white border-l-2 border-neon-blue pl-3">
                      MERCH SPOTLIGHT
                    </h3>
                  </div>

                  {/* Horizontal small spotlight item loops */}
                  <div className="space-y-4">
                    {spotlightProducts.map((p) => (
                      <div
                        key={p.id}
                        id={`home-merch-${p.id}`}
                        onClick={() => handleSelectProduct(p.id)}
                        className="flex items-center justify-between gap-4 p-3 border border-zinc-900/40 hover:border-zinc-800 bg-black/40 rounded transition-all cursor-pointer group"
                      >
                        <div className="flex items-center gap-3">
                          <img
                            src={p.images[0]}
                            alt={p.name}
                            className="w-10 h-10 object-cover rounded border border-zinc-900"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <h4 className="font-display text-[11px] font-bold text-zinc-300 group-hover:text-neon-blue uppercase tracking-wide leading-none">
                              {p.name}
                            </h4>
                            <span className="font-mono text-xs font-bold text-neon-pink block mt-1">
                              ${p.price.toFixed(2)}
                            </span>
                          </div>
                        </div>

                        <button className="font-mono text-[9px] text-zinc-500 hover:text-white group-hover:text-neon-blue transition-colors uppercase font-bold cursor-pointer">
                          VIEW →
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* STAY IN THE LOOP Newsletter block */}
                  <div className="p-4 border border-zinc-900 bg-black/80 rounded space-y-3 relative overflow-hidden">
                    {/* Glowing mesh */}
                    <div className="absolute -bottom-10 -right-10 w-24 h-24 bg-neon-blue/10 rounded-full blur-2xl pointer-events-none" />

                    <h4 className="font-display text-xs font-black uppercase text-neon-blue tracking-wide">
                      STAY IN THE LOOP
                    </h4>
                    <p className="text-[10px] text-zinc-500 font-mono leading-relaxed uppercase">
                      Get the latest on events, secret warehouse locations, lineups, and clothing drops.
                    </p>

                    <form onSubmit={handleNewsletterSubmit} className="flex gap-1.5 mt-2.5">
                      <input
                        id="newsletter-email-input"
                        type="email"
                        placeholder="rave@cyber.com"
                        value={emailInput}
                        onChange={(e) => setEmailInput(e.target.value)}
                        className="flex-1 bg-zinc-950 border border-zinc-800 rounded px-2.5 py-1.5 font-mono text-[10px] text-white focus:outline-none focus:border-neon-blue"
                      />
                      <button
                        type="submit"
                        className="bg-neon-blue border border-neon-blue text-black font-mono text-[10px] font-black uppercase px-3 py-1.5 rounded hover:bg-black hover:text-neon-blue transition-colors cursor-pointer"
                      >
                        SUBSCRIBE
                      </button>
                    </form>

                    {/* Social links matching footer */}
                    <div className="flex gap-4 pt-3 justify-center text-zinc-600 border-t border-zinc-900/50 mt-1">
                      <a href="#instagram" className="hover:text-neon-pink transition-colors">
                        <Instagram className="w-4 h-4" />
                      </a>
                      <a href="#tiktok" className="hover:text-neon-green transition-colors">
                        <Radio className="w-4 h-4" />
                      </a>
                      <a href="#youtube" className="hover:text-neon-blue transition-colors">
                        <Youtube className="w-4 h-4" />
                      </a>
                      <a href="#soundcloud" className="hover:text-neon-orange transition-colors">
                        <Music className="w-4 h-4" />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'events' && (
            <motion.div
              key="events"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <EventDirectory
                events={events}
                onSelectEvent={(id) => {
                  setSelectedEventId(id);
                }}
                favorites={favorites}
                toggleFavorite={handleToggleFavorite}
                onBuyTickets={handleBuyTicketsDirect}
              />

              {/* Event Detailed view block */}
              {selectedEventId && (
                <div className="mx-auto max-w-4xl px-4 pb-12">
                  {(() => {
                    const ev = events.find((e) => e.id === selectedEventId);
                    if (!ev) return null;
                    return (
                      <div className="border border-zinc-900 bg-black/90 rounded-xl p-6 md:p-8 backdrop-blur-md space-y-6 shadow-2xl relative overflow-hidden">
                        {/* Pink glowing corner */}
                        <div className="absolute top-0 right-0 w-24 h-24 bg-neon-pink/15 rounded-full blur-3xl pointer-events-none" />

                        <div className="flex flex-col sm:flex-row gap-6">
                          <img
                            src={ev.image}
                            alt={ev.title}
                            className="w-full sm:w-64 h-48 object-cover rounded border border-zinc-900 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div className="flex-grow flex flex-col justify-between">
                            <div>
                              <div className="flex gap-2">
                                {ev.genres.map((g) => (
                                  <span key={g} className="font-mono text-[9px] text-neon-blue uppercase bg-neon-blue/5 border border-neon-blue/20 px-2 py-0.5 rounded">
                                    {g}
                                  </span>
                                ))}
                              </div>
                              <h2 className="font-display text-2xl md:text-3xl font-black text-white mt-2 tracking-wide uppercase">
                                {ev.title}
                              </h2>
                              <div className="space-y-1 mt-3 font-mono text-xs text-zinc-400">
                                <p className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-neon-green" /> {ev.venue} • {ev.city}</p>
                                <p className="flex items-center gap-1.5"><Calendar className="w-4 h-4 text-neon-orange" /> {ev.date} ({ev.time})</p>
                              </div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-zinc-900/60 flex items-center justify-between">
                              <span className="font-mono text-lg font-black text-neon-pink">${ev.price.toFixed(2)}</span>
                              <button
                                onClick={() => handleBuyTicketsDirect(ev)}
                                className="font-display text-xs font-black tracking-widest text-black bg-neon-green border border-neon-green px-6 py-2.5 rounded hover:bg-black hover:text-neon-green transition-all shadow-[0_0_12px_#39ff1444] cursor-pointer"
                              >
                                BUY ADMISSION TICKETS
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-3 pt-4 border-t border-zinc-900/40">
                          <h3 className="font-display text-xs font-black uppercase text-neon-pink tracking-widest">
                            EVENT LINEUP
                          </h3>
                          <div className="font-mono text-sm text-neon-blue font-bold tracking-wide bg-zinc-950/60 p-4 rounded border border-zinc-900/60 leading-relaxed uppercase">
                            {ev.lineup.join('  •  ')}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <h3 className="font-display text-xs font-black uppercase text-neon-orange tracking-widest">
                            SESSION MEMORANDUM
                          </h3>
                          <p className="text-xs md:text-sm text-zinc-400 font-mono leading-relaxed">
                            {ev.description}
                          </p>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </motion.div>
          )}

          {activeTab === 'news' && (
            <motion.div
              key="news"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <NewsBlog
                news={news}
                currentPostId={selectedNewsId}
                setCurrentPostId={setSelectedNewsId}
              />
            </motion.div>
          )}

          {activeTab === 'merch' && (
            <motion.div
              key="merch"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <MerchStore
                products={products}
                currentProductId={selectedProductId}
                setCurrentProductId={setSelectedProductId}
                onAddToCart={handleAddToCart}
                favorites={favorites}
                toggleFavorite={handleToggleFavorite}
              />
            </motion.div>
          )}

          {activeTab === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="py-12 px-4 max-w-4xl mx-auto text-white relative z-10 font-sans space-y-8"
            >
              <div className="border border-zinc-900 bg-black/80 p-6 md:p-8 rounded-lg backdrop-blur-md space-y-6">
                <h2 className="font-display text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-neon-pink via-neon-orange to-neon-green uppercase tracking-wider">
                  OUR TRANSMISSION CORE
                </h2>

                <div className="space-y-4 text-zinc-400 font-mono text-xs md:text-sm leading-relaxed uppercase">
                  <p>
                    ESTABLISHED IN 2012, AMERICAN RAVE SCENE STANDS AS THE LEADING INDEPENDENT PORTAL DEDICATED TO EXPOSING, DOCUMENTING, AND AMPLIFYING UNDERGROUND ELECTRONIC MUSIC CULTURE IN THE UNITED STATES.
                  </p>
                  <p>
                    WE BELIEVE THAT MUSIC IS THE UNIVERSAL FREQUENCY. AND DANCING TOGETHER IS THE ABSOLUTE DEFINITION OF FREEDOM. FROM WAREHOUSE BASEMENT SESSIONS IN DETROIT AND SEATTLE, TO FLOATING STAGES IN MIAMI, TO SUNRISE CANYON GATHERINGS OUT WEST—WE PROVIDE A PREMIUM DIGITAL HARBOR FOR THOSE WHO FIND COMFORT IN THE LIGHTS.
                  </p>
                  <p>
                    OUR ENTIRE OPERATIONS PRACTICE UNDER THE ETERNAL COMMANDMENTS OF PLUR:
                  </p>
                  <div className="grid grid-cols-4 gap-3 text-center py-4 text-white">
                    <div className="p-3 border border-neon-pink bg-neon-pink/5 rounded shadow-[0_0_8px_#ff007f33]">
                      <span className="font-display font-black text-sm block">P</span>
                      <span className="text-[9px] text-zinc-500 font-mono mt-0.5 block">PEACE</span>
                    </div>
                    <div className="p-3 border border-neon-orange bg-neon-orange/5 rounded shadow-[0_0_8px_rgba(255,103,0,0.2)]">
                      <span className="font-display font-black text-sm block">L</span>
                      <span className="text-[9px] text-zinc-500 font-mono mt-0.5 block">LOVE</span>
                    </div>
                    <div className="p-3 border border-neon-blue bg-neon-blue/5 rounded shadow-[0_0_8px_rgba(0,240,255,0.2)]">
                      <span className="font-display font-black text-sm block">U</span>
                      <span className="text-[9px] text-zinc-500 font-mono mt-0.5 block">UNITY</span>
                    </div>
                    <div className="p-3 border border-neon-green bg-neon-green/5 rounded shadow-[0_0_8px_rgba(57,255,20,0.2)]">
                      <span className="font-display font-black text-sm block">R</span>
                      <span className="text-[9px] text-zinc-500 font-mono mt-0.5 block">RESPECT</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border border-zinc-900 bg-black/80 p-6 md:p-8 rounded-lg backdrop-blur-md space-y-4">
                <h3 className="font-display text-lg font-black text-white uppercase tracking-wider">
                  CONTACT HEADQUARTERS
                </h3>
                <p className="font-mono text-xs text-zinc-500 uppercase leading-relaxed">
                  Got line-up leaks? Hosting a private underground warehouse party? Want to distribute custom merchandise designs? Securely transmit details below.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-4 border border-zinc-900 bg-zinc-950 rounded">
                    <span className="font-mono text-[9px] text-zinc-500 font-bold uppercase">EDITORIALS DESK</span>
                    <p className="font-mono text-sm text-neon-blue mt-1">press@americanravescene.com</p>
                  </div>
                  <div className="p-4 border border-zinc-900 bg-zinc-950 rounded">
                    <span className="font-mono text-[9px] text-zinc-500 font-bold uppercase">ORGANIZATION & TICKETS</span>
                    <p className="font-mono text-sm text-neon-green mt-1">promoters@americanravescene.com</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {activeTab === 'cart' && (
            <motion.div
              key="cart"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <CheckoutFlow
                cart={cart}
                setCart={setCart}
                user={user}
                onPurchaseComplete={handlePurchaseComplete}
                setActiveTab={setActiveTab}
                onClearCart={() => setCart([])}
              />
            </motion.div>
          )}

          {activeTab === 'account' && (
            <motion.div
              key="account"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <UserDashboard
                user={user}
                events={events}
                onLogin={handleLogin}
                onLogout={handleLogout}
                onToggleFavorite={handleToggleFavorite}
                favorites={favorites}
                onSetUserRole={handleSetUserRole}
                onSelectEvent={handleSelectEvent}
              />
            </motion.div>
          )}

          {activeTab === 'admin' && (
            <motion.div
              key="admin"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <AdminCMS
                events={events}
                setEvents={setEvents}
                news={news}
                setNews={setNews}
                products={products}
                setProducts={setProducts}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* 5. Central Search and Filter Overlay modal */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4 font-sans"
          >
            <div className="w-full max-w-2xl border border-zinc-900 bg-black p-6 rounded-lg relative space-y-4 shadow-[0_0_50px_#00f0ff33]">
              <button
                onClick={() => {
                  setSearchOpen(false);
                  setSearchQuery('');
                }}
                className="absolute top-4 right-4 text-zinc-500 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 border-b border-zinc-800 pb-3">
                <Search className="w-5 h-5 text-neon-blue shrink-0 animate-pulse" />
                <input
                  id="search-overlay-input"
                  type="text"
                  placeholder="SEARCH ENTIRE RAVE ARCHIVE (ARTISTS, CITIES, NEWS)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-transparent font-mono text-sm tracking-wide text-white focus:outline-none uppercase"
                  autoFocus
                />
              </div>

              {/* Instant Search outcomes */}
              <div className="max-h-96 overflow-y-auto space-y-3 font-mono text-xs text-zinc-400 scrollbar-none pr-1">
                {searchQuery.trim() === '' ? (
                  <p className="text-zinc-600 italic text-center py-6">INITIALIZE TRANSMISSION BY TYPING...</p>
                ) : (
                  <>
                    {/* Events Outcomes */}
                    {events.filter((e) =>
                      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      e.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      e.lineup.some((l) => l.toLowerCase().includes(searchQuery.toLowerCase()))
                    ).map((e) => (
                      <div
                        key={e.id}
                        onClick={() => {
                          handleSelectEvent(e.id);
                          setSearchOpen(false);
                          setSearchQuery('');
                        }}
                        className="p-3 border border-zinc-900 bg-zinc-950/60 hover:bg-zinc-900 rounded cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <span className="text-neon-green uppercase font-bold">EVENT: {e.title}</span>
                          <span className="text-zinc-600 block mt-0.5">{e.venue} • {e.city}</span>
                        </div>
                        <span className="text-[9px] text-zinc-500 uppercase">{e.date}</span>
                      </div>
                    ))}

                    {/* News outcomes */}
                    {news.filter((n) =>
                      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      n.content.toLowerCase().includes(searchQuery.toLowerCase())
                    ).map((n) => (
                      <div
                        key={n.id}
                        onClick={() => {
                          handleSelectNews(n.id);
                          setSearchOpen(false);
                          setSearchQuery('');
                        }}
                        className="p-3 border border-zinc-900 bg-zinc-950/60 hover:bg-zinc-900 rounded cursor-pointer flex items-center justify-between"
                      >
                        <div>
                          <span className="text-neon-pink uppercase font-bold">JOURNAL: {n.title}</span>
                          <span className="text-zinc-600 block mt-0.5 truncate max-w-sm">{n.excerpt}</span>
                        </div>
                        <span className="text-[9px] text-zinc-500 uppercase">{n.date}</span>
                      </div>
                    ))}

                    {/* Check if null */}
                    {events.filter((e) =>
                      e.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      e.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      e.lineup.some((l) => l.toLowerCase().includes(searchQuery.toLowerCase()))
                    ).length === 0 &&
                    news.filter((n) =>
                      n.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      n.content.toLowerCase().includes(searchQuery.toLowerCase())
                    ).length === 0 && (
                      <p className="text-center text-zinc-600 py-6">NO ACTIVE RECORDS IDENTIFIED MATCHING '{searchQuery.toUpperCase()}'</p>
                    )}
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 6. Footer Layout */}
      <Footer setActiveTab={setActiveTab} />
    </div>
  );
}
