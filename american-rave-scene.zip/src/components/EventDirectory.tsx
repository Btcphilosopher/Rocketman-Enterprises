import { useState, useEffect } from 'react';
import { Search, MapPin, Calendar, Music, Clock, Sparkles, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Event } from '../types';

interface EventDirectoryProps {
  events: Event[];
  onSelectEvent: (eventId: string) => void;
  favorites: string[];
  toggleFavorite: (eventId: string) => void;
  onBuyTickets: (event: Event) => void;
}

export default function EventDirectory({
  events,
  onSelectEvent,
  favorites,
  toggleFavorite,
  onBuyTickets,
}: EventDirectoryProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCity, setSelectedCity] = useState('ALL');
  const [selectedGenre, setSelectedGenre] = useState('ALL');
  const [selectedStatus, setSelectedStatus] = useState('ALL');

  // Unique cities and genres for filter selectors
  const cities = ['ALL', ...Array.from(new Set(events.map((e) => e.city.split(',')[0].trim())))];
  const genres = ['ALL', ...Array.from(new Set(events.flatMap((e) => e.genres)))];

  // Filters calculation
  const filteredEvents = events.filter((ev) => {
    const matchesSearch =
      ev.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ev.lineup.some((l) => l.toLowerCase().includes(searchTerm.toLowerCase())) ||
      ev.venue.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesCity = selectedCity === 'ALL' || ev.city.toUpperCase().includes(selectedCity.toUpperCase());
    const matchesGenre = selectedGenre === 'ALL' || ev.genres.includes(selectedGenre);
    const matchesStatus =
      selectedStatus === 'ALL' ||
      (selectedStatus === 'LIVE' && ev.status === 'live') ||
      (selectedStatus === 'UPCOMING' && ev.status === 'upcoming') ||
      (selectedStatus === 'SOLD_OUT' && ev.status === 'sold_out');

    return matchesSearch && matchesCity && matchesGenre && matchesStatus;
  });

  return (
    <div id="event-directory-container" className="py-8 px-4 font-sans max-w-7xl mx-auto relative z-10 text-white">
      {/* Title & Stats */}
      <div className="mb-8 text-center md:text-left">
        <h2 className="font-display text-3xl md:text-4xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-neon-green via-neon-blue to-neon-violet">
          UNDERGROUND EVENT DIRECTORY
        </h2>
        <p className="font-mono text-xs text-zinc-400 mt-2">
          EXPLORING {filteredEvents.length} OF {events.length} SESSIONS COAST-TO-COAST
        </p>
      </div>

      {/* Filter Control Box */}
      <div className="p-5 border border-zinc-900 bg-black/80 rounded-lg mb-8 grid grid-cols-1 md:grid-cols-4 gap-4 backdrop-blur-md">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-3.5 h-4 w-4 text-zinc-500" />
          <input
            id="event-search-input"
            type="text"
            placeholder="Search artists, venues..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-zinc-950 border border-zinc-800 text-sm rounded focus:outline-none focus:border-neon-green font-mono transition-colors"
          />
        </div>

        {/* City Filter */}
        <div>
          <select
            id="filter-city-select"
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="w-full px-3 py-2.5 bg-zinc-950 border border-zinc-800 text-sm rounded focus:outline-none focus:border-neon-blue font-mono transition-colors text-zinc-300"
          >
            <option value="ALL">ALL CITIES</option>
            {cities.map(
              (city) =>
                city !== 'ALL' && (
                  <option key={city} value={city}>
                    {city.toUpperCase()}
                  </option>
                )
            )}
          </select>
        </div>

        {/* Genre Filter */}
        <div>
          <select
            id="filter-genre-select"
            value={selectedGenre}
            onChange={(e) => setSelectedGenre(e.target.value)}
            className="w-full px-3 py-2.5 bg-zinc-950 border border-zinc-800 text-sm rounded focus:outline-none focus:border-neon-pink font-mono transition-colors text-zinc-300"
          >
            <option value="ALL">ALL GENRES</option>
            {genres.map(
              (genre) =>
                genre !== 'ALL' && (
                  <option key={genre} value={genre}>
                    {genre.toUpperCase()}
                  </option>
                )
            )}
          </select>
        </div>

        {/* Status Filter */}
        <div>
          <select
            id="filter-status-select"
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="w-full px-3 py-2.5 bg-zinc-950 border border-zinc-800 text-sm rounded focus:outline-none focus:border-neon-orange font-mono transition-colors text-zinc-300"
          >
            <option value="ALL">ALL STATUSES</option>
            <option value="UPCOMING">UPCOMING</option>
            <option value="LIVE">LIVE NOW</option>
            <option value="SOLD_OUT">SOLD OUT</option>
          </select>
        </div>
      </div>

      {/* Grid List */}
      {filteredEvents.length === 0 ? (
        <div className="text-center py-20 border border-dashed border-zinc-800 rounded bg-black/40">
          <p className="font-mono text-zinc-500">NO WAREHOUSE OR FIELD SETS FOUND MATCHING SPECIFIED CRITERIA.</p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCity('ALL');
              setSelectedGenre('ALL');
              setSelectedStatus('ALL');
            }}
            className="mt-4 font-mono text-xs text-neon-pink border border-neon-pink/40 hover:bg-neon-pink/10 px-4 py-2 rounded transition-all"
          >
            CLEAR FILTERS
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence mode="popLayout">
            {filteredEvents.map((ev, idx) => (
              <EventCard
                key={ev.id}
                event={ev}
                index={idx}
                onSelect={onSelectEvent}
                isFav={favorites.includes(ev.id)}
                toggleFav={() => toggleFavorite(ev.id)}
                onBuy={onBuyTickets}
              />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

// Sub-component: EventCard
function EventCard({
  event,
  index,
  onSelect,
  isFav,
  toggleFav,
  onBuy,
}: {
  event: Event;
  index: number;
  onSelect: (id: string) => void;
  isFav: boolean;
  toggleFav: () => void;
  onBuy: (ev: Event) => void;
  key?: string;
}) {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, mins: 0 });

  useEffect(() => {
    if (event.status !== 'upcoming') return;

    const calcTime = () => {
      const difference = +new Date(event.date) - +new Date();
      if (difference <= 0) return { days: 0, hours: 0, mins: 0 };
      return {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        mins: Math.floor((difference / 1000 / 60) % 60),
      };
    };

    setTimeLeft(calcTime());
    const interval = setInterval(() => setTimeLeft(calcTime()), 60000);
    return () => clearInterval(interval);
  }, [event]);

  // Status-specific color configurations
  const statusConfig = {
    live: { text: 'LIVE NOW', badgeClass: 'bg-neon-green/10 border-neon-green text-neon-green glow-green' },
    sold_out: { text: 'SOLD OUT', badgeClass: 'bg-red-500/10 border-red-500 text-red-500' },
    cancelled: { text: 'CANCELLED', badgeClass: 'bg-zinc-800 border-zinc-700 text-zinc-500 line-through' },
    upcoming: { text: 'UPCOMING', badgeClass: 'bg-neon-blue/10 border-neon-blue text-neon-blue' },
  };

  const currStatus = statusConfig[event.status];

  return (
    <motion.div
      id={`event-card-${event.id}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3, delay: Math.min(index * 0.05, 0.3) }}
      className="group border border-zinc-900 bg-black/60 rounded-lg overflow-hidden flex flex-col justify-between hover:border-zinc-700 hover:shadow-[0_0_20px_rgba(0,240,255,0.1)] transition-all duration-300 backdrop-blur-md relative"
    >
      {/* Event Header Image */}
      <div className="relative h-48 overflow-hidden">
        <img
          src={event.image}
          alt={event.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />

        {/* Favorite Icon */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleFav();
          }}
          className="absolute top-3 right-3 p-2 bg-black/60 rounded-full border border-zinc-800 text-zinc-400 hover:text-neon-pink hover:border-neon-pink transition-all cursor-pointer"
        >
          <Heart className={`w-4 h-4 ${isFav ? 'fill-neon-pink text-neon-pink' : ''}`} />
        </button>

        {/* Dynamic status badge */}
        <span
          className={`absolute top-3 left-3 px-2 py-0.5 border rounded font-mono text-[9px] font-bold tracking-wider ${currStatus.badgeClass}`}
        >
          {currStatus.text}
        </span>
      </div>

      {/* Details Area */}
      <div className="p-4 flex-grow flex flex-col justify-between">
        <div>
          {/* Genre Glyphs */}
          <div className="flex gap-1.5 mb-2.5 overflow-x-auto scrollbar-none">
            {event.genres.map((g) => (
              <span
                key={g}
                className="font-mono text-[9px] tracking-wider text-neon-blue uppercase bg-neon-blue/5 border border-neon-blue/10 px-1.5 py-0.5 rounded-xs"
              >
                {g}
              </span>
            ))}
          </div>

          <h3
            onClick={() => onSelect(event.id)}
            className="font-display text-xl font-black text-white hover:text-neon-pink cursor-pointer tracking-wider transition-colors"
          >
            {event.title}
          </h3>

          <div className="flex flex-col gap-1.5 mt-3 font-mono text-xs text-zinc-400">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-neon-green shrink-0" />
              <span>{event.venue} • {event.city}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-neon-orange shrink-0" />
              <span>{new Date(event.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}</span>
            </div>
          </div>

          {/* Lineup display */}
          <div className="mt-4 border-t border-zinc-900/50 pt-3">
            <p className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest mb-1">LINEUP HIGHLIGHTS</p>
            <p className="font-mono text-xs text-neon-blue font-semibold tracking-wide truncate">
              {event.lineup.join(' • ')}
            </p>
          </div>
        </div>

        {/* Lower row: Countdown & Purchase buttons */}
        <div className="mt-5 border-t border-zinc-900 pt-4 flex items-center justify-between">
          <div>
            {event.status === 'upcoming' ? (
              <div className="flex flex-col">
                <span className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest flex items-center gap-1">
                  <Clock className="w-2.5 h-2.5" /> COUNTDOWN
                </span>
                <span className="font-mono text-xs font-bold text-neon-green mt-0.5">
                  {timeLeft.days}D {timeLeft.hours}H {timeLeft.mins}M
                </span>
              </div>
            ) : event.status === 'live' ? (
              <div className="flex flex-col">
                <span className="font-mono text-[8px] text-neon-green uppercase tracking-widest flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5" /> HAPPENING NOW
                </span>
                <span className="font-mono text-xs font-bold text-white mt-0.5 animate-pulse">
                  IN SESSION
                </span>
              </div>
            ) : (
              <div className="flex flex-col">
                <span className="font-mono text-[8px] text-zinc-600 uppercase tracking-widest">
                  REGISTRATION
                </span>
                <span className="font-mono text-xs font-bold text-zinc-500 mt-0.5">
                  CLOSED
                </span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="font-mono text-sm font-black text-white">${event.price.toFixed(2)}</span>
            {event.status === 'upcoming' && event.ticketStock > 0 ? (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onBuy(event);
                }}
                className="font-display text-[10px] font-bold tracking-wider text-neon-green border border-neon-green/40 hover:border-neon-green hover:bg-neon-green/10 px-3 py-1.5 rounded transition-all cursor-pointer"
              >
                TICKETS
              </button>
            ) : event.status === 'live' && event.ticketStock > 0 ? (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onBuy(event);
                }}
                className="font-display text-[10px] font-bold tracking-wider text-white bg-neon-green/20 border border-neon-green px-3 py-1.5 rounded transition-all cursor-pointer"
              >
                JOIN LIVE
              </button>
            ) : (
              <button
                disabled
                className="font-display text-[10px] font-bold tracking-wider text-zinc-600 border border-zinc-800 px-3 py-1.5 rounded cursor-not-allowed"
              >
                UNAVAILABLE
              </button>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
