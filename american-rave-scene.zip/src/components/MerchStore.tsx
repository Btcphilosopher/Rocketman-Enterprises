import { useState } from 'react';
import { ShoppingCart, Heart, ArrowLeft, ShieldCheck, Truck, RefreshCw, Eye } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, CartItem } from '../types';

interface MerchStoreProps {
  products: Product[];
  currentProductId: string | null;
  setCurrentProductId: (id: string | null) => void;
  onAddToCart: (item: CartItem) => void;
  favorites: string[];
  toggleFavorite: (id: string) => void;
}

export default function MerchStore({
  products,
  currentProductId,
  setCurrentProductId,
  onAddToCart,
  favorites,
  toggleFavorite,
}: MerchStoreProps) {
  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'apparel' | 'accessories' | 'gear'>('ALL');
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [qty, setQty] = useState<number>(1);

  const categories: ('ALL' | 'apparel' | 'accessories' | 'gear')[] = ['ALL', 'apparel', 'accessories', 'gear'];

  const filteredProducts = products.filter((p) => {
    return selectedCategory === 'ALL' || p.category === selectedCategory;
  });

  const activeProduct = products.find((p) => p.id === currentProductId);

  // Initialize size when active product shifts
  useState(() => {
    if (activeProduct && activeProduct.sizes.length > 0) {
      setSelectedSize(activeProduct.sizes[0]);
    }
  });

  const handleProductSelect = (id: string) => {
    const p = products.find((prod) => prod.id === id);
    if (p) {
      setSelectedSize(p.sizes[0] || 'O/S');
      setQty(1);
    }
    setCurrentProductId(id);
  };

  // Product detail page
  if (activeProduct) {
    const isFav = favorites.includes(activeProduct.id);

    const handleAdd = () => {
      const sizeStr = selectedSize || activeProduct.sizes[0] || 'O/S';
      onAddToCart({
        id: `${activeProduct.id}-${sizeStr}`,
        type: 'merch',
        referenceId: activeProduct.id,
        name: `${activeProduct.name} (${sizeStr})`,
        quantity: qty,
        price: activeProduct.price,
        size: sizeStr,
        image: activeProduct.images[0],
      });
      alert(`${qty} x ${activeProduct.name} (${sizeStr}) added to cart!`);
    };

    return (
      <div id="product-detail-container" className="py-8 px-4 font-sans max-w-5xl mx-auto relative z-10 text-white">
        <button
          onClick={() => setCurrentProductId(null)}
          className="flex items-center gap-2 font-mono text-xs text-zinc-400 hover:text-white mb-8 border border-zinc-800 bg-black/60 px-3 py-1.5 rounded cursor-pointer transition-all"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-neon-pink" /> BACK TO APPAREL STORE
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 border border-zinc-900 bg-black/80 rounded-lg p-6 md:p-8 backdrop-blur-md">
          {/* Left: Images */}
          <div className="flex flex-col gap-4">
            <div className="aspect-square w-full rounded border border-zinc-850 bg-zinc-950 overflow-hidden">
              <img
                src={activeProduct.images[0]}
                alt={activeProduct.name}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <div className="aspect-square border border-neon-blue rounded overflow-hidden opacity-100 cursor-pointer">
                <img
                  src={activeProduct.images[0]}
                  alt="thumbnail"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </div>

          {/* Right: details */}
          <div className="flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="font-mono text-[9px] font-bold tracking-widest text-neon-blue uppercase bg-neon-blue/10 border border-neon-blue/20 px-2 py-0.5 rounded">
                  {activeProduct.category}
                </span>
                <span className="font-mono text-xs text-zinc-500">
                  {activeProduct.stock > 0 ? `IN STOCK (${activeProduct.stock})` : 'SOLD OUT'}
                </span>
              </div>

              <h1 className="font-display text-2xl md:text-3xl font-black text-white uppercase tracking-wider">
                {activeProduct.name}
              </h1>

              <div className="font-mono text-2xl font-bold text-neon-pink mt-2">
                ${activeProduct.price.toFixed(2)}
              </div>

              <p className="text-sm text-zinc-400 mt-4 leading-relaxed">
                {activeProduct.description}
              </p>

              {/* Sizing selection */}
              {activeProduct.sizes.length > 0 && activeProduct.sizes[0] !== 'O/S' && (
                <div className="mt-6">
                  <span className="font-mono text-xs text-zinc-400 block mb-2 font-bold uppercase tracking-wider">
                    SELECT SIZE
                  </span>
                  <div className="flex gap-2">
                    {activeProduct.sizes.map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSize(sz)}
                        className={`font-mono text-xs font-bold w-10 h-10 border rounded flex items-center justify-center transition-all cursor-pointer ${
                          selectedSize === sz
                            ? 'border-neon-pink text-neon-pink bg-neon-pink/10 shadow-[0_0_8px_rgba(255,0,127,0.3)]'
                            : 'border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600'
                        }`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity selector */}
              <div className="mt-6">
                <span className="font-mono text-xs text-zinc-400 block mb-2 font-bold uppercase tracking-wider">
                  QUANTITY
                </span>
                <div className="flex items-center gap-3">
                  <div className="flex items-center border border-zinc-800 rounded bg-zinc-950 overflow-hidden">
                    <button
                      onClick={() => setQty(Math.max(1, qty - 1))}
                      className="px-3 py-1.5 font-mono text-zinc-400 hover:text-white hover:bg-zinc-900 border-r border-zinc-800 cursor-pointer"
                    >
                      -
                    </button>
                    <span className="px-4 py-1.5 font-mono text-sm">{qty}</span>
                    <button
                      onClick={() => setQty(Math.min(activeProduct.stock, qty + 1))}
                      className="px-3 py-1.5 font-mono text-zinc-400 hover:text-white hover:bg-zinc-900 border-l border-zinc-800 cursor-pointer"
                    >
                      +
                    </button>
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500">
                    MAX STOCK LIMIT: {activeProduct.stock}
                  </span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 pt-6 border-t border-zinc-900 flex flex-col sm:flex-row gap-3">
              <button
                onClick={handleAdd}
                disabled={activeProduct.stock <= 0}
                className="flex-1 flex items-center justify-center gap-2 font-display text-xs font-black tracking-widest text-black bg-neon-pink border border-neon-pink rounded py-3 hover:bg-black hover:text-neon-pink hover:shadow-[0_0_15px_rgba(255,0,127,0.5)] transition-all cursor-pointer"
              >
                <ShoppingCart className="w-4 h-4" /> ADD TO CART
              </button>

              <button
                onClick={() => toggleFavorite(activeProduct.id)}
                className="flex h-12 w-12 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-pink hover:text-neon-pink cursor-pointer transition-all text-zinc-400"
              >
                <Heart className={`w-5 h-5 ${isFav ? 'fill-neon-pink text-neon-pink' : ''}`} />
              </button>
            </div>

            {/* Guarantees */}
            <div className="grid grid-cols-3 gap-2 mt-6 border-t border-zinc-900/40 pt-4 font-mono text-[9px] text-zinc-500 text-center">
              <div className="flex flex-col items-center gap-1.5">
                <Truck className="w-4 h-4 text-neon-green" />
                <span>SHIPS WORLDWIDE</span>
              </div>
              <div className="flex flex-col items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-neon-blue" />
                <span>SECURE CHECKOUT</span>
              </div>
              <div className="flex flex-col items-center gap-1.5">
                <RefreshCw className="w-4 h-4 text-neon-orange" />
                <span>30-DAY RETURNS</span>
              </div>
            </div>

          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="merch-store-container" className="py-8 px-4 font-sans max-w-7xl mx-auto relative z-10 text-white">
      {/* Merch Header */}
      <div className="mb-8 text-center md:text-left flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-3xl md:text-4xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-neon-pink via-neon-orange to-neon-violet">
            OFFICIAL MERCHANDISE
          </h2>
          <p className="font-mono text-xs text-zinc-400 mt-2">
            STREETWEAR AND ACCESSORIES PACKED WITH UNDERGROUND GLYPHS AND NEON EMBROIDERY
          </p>
        </div>

        {/* Category filtering */}
        <div className="flex gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`font-mono text-[10px] font-bold tracking-widest uppercase border px-3 py-1.5 rounded transition-all cursor-pointer ${
                selectedCategory === cat
                  ? 'border-neon-pink text-neon-pink bg-neon-pink/10'
                  : 'border-zinc-800 text-zinc-500 hover:text-white hover:border-zinc-600'
              }`}
            >
              {cat === 'ALL' ? 'ALL DROPS' : cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of merch */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredProducts.map((p) => {
          const isFav = favorites.includes(p.id);
          return (
            <motion.div
              key={p.id}
              id={`product-card-${p.id}`}
              whileHover={{ y: -5 }}
              className="group border border-zinc-900 bg-black/60 rounded-lg overflow-hidden flex flex-col justify-between hover:border-zinc-700 hover:shadow-[0_0_20px_rgba(0,240,255,0.08)] transition-all duration-300 backdrop-blur-md relative"
            >
              {/* Product Card Media */}
              <div className="relative aspect-square overflow-hidden bg-zinc-950">
                <img
                  src={p.images[0]}
                  alt={p.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />

                {/* Badges */}
                {p.isSpotlight && (
                  <span className="absolute top-3 left-3 font-mono text-[9px] font-bold tracking-widest text-white border border-neon-pink bg-neon-pink/20 px-2 py-0.5 rounded-xs uppercase shadow-[0_0_5px_#ff007f]">
                    SPOTLIGHT
                  </span>
                )}

                {/* Fav */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleFavorite(p.id);
                  }}
                  className="absolute top-3 right-3 p-2 bg-black/60 rounded-full border border-zinc-800 text-zinc-400 hover:text-neon-pink hover:border-neon-pink transition-all cursor-pointer"
                >
                  <Heart className={`w-4 h-4 ${isFav ? 'fill-neon-pink text-neon-pink' : ''}`} />
                </button>
              </div>

              {/* Bottom details card */}
              <div className="p-4 flex-grow flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-mono text-[9px] text-zinc-500 tracking-wider uppercase">
                      {p.category}
                    </span>
                    <span className="font-mono text-[9px] text-zinc-500 uppercase">
                      {p.stock > 0 ? `STOCK: ${p.stock}` : 'OUT OF STOCK'}
                    </span>
                  </div>

                  <h3
                    onClick={() => handleProductSelect(p.id)}
                    className="font-display text-base font-black text-white hover:text-neon-pink cursor-pointer uppercase tracking-wider transition-colors line-clamp-1"
                  >
                    {p.name}
                  </h3>

                  <div className="font-mono text-sm font-bold text-neon-pink mt-1.5">
                    ${p.price.toFixed(2)}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-zinc-900/50 flex gap-2">
                  <button
                    onClick={() => handleProductSelect(p.id)}
                    className="flex-1 flex items-center justify-center gap-1.5 font-mono text-[10px] font-bold tracking-widest text-zinc-400 hover:text-white border border-zinc-800 hover:border-zinc-600 rounded py-2 transition-all cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" /> DETAILS
                  </button>

                  <button
                    onClick={() => {
                      onAddToCart({
                        id: `${p.id}-${p.sizes[0] || 'O/S'}`,
                        type: 'merch',
                        referenceId: p.id,
                        name: `${p.name} (${p.sizes[0] || 'O/S'})`,
                        quantity: 1,
                        price: p.price,
                        size: p.sizes[0] || 'O/S',
                        image: p.images[0],
                      });
                      alert(`1 x ${p.name} added to cart!`);
                    }}
                    disabled={p.stock <= 0}
                    className="flex-1 flex items-center justify-center gap-1.5 font-mono text-[10px] font-bold tracking-widest text-black bg-neon-blue border border-neon-blue rounded py-2 hover:bg-black hover:text-neon-blue transition-all cursor-pointer"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" /> QUICK ADD
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
