import React, { useState } from 'react';
import { ShoppingCart, Trash2, ArrowRight, ShieldCheck, Mail, MapPin, Calendar, CreditCard, CheckCircle, Ticket } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem, UserProfile, TicketOrder, MerchOrder } from '../types';

interface CheckoutFlowProps {
  cart: CartItem[];
  setCart: (cart: CartItem[]) => void;
  user: UserProfile | null;
  onPurchaseComplete: (tickets: TicketOrder[], merchOrders: MerchOrder[]) => void;
  setActiveTab: (tab: string) => void;
  onClearCart: () => void;
}

export default function CheckoutFlow({
  cart,
  setCart,
  user,
  onPurchaseComplete,
  setActiveTab,
  onClearCart,
}: CheckoutFlowProps) {
  const [step, setStep] = useState<'cart' | 'checkout' | 'success'>('cart');
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    address: '123 Rave Ave',
    city: 'Detroit',
    zip: '48201',
    cardName: user?.name || '',
    cardNumber: '4111 2222 3333 4444',
    cardExpiry: '12/28',
    cardCVV: '123',
  });

  const [generatedTickets, setGeneratedTickets] = useState<TicketOrder[]>([]);
  const [generatedMerchOrders, setGeneratedMerchOrders] = useState<MerchOrder[]>([]);

  // Calculations
  const ticketItems = cart.filter((item) => item.type === 'ticket');
  const merchItems = cart.filter((item) => item.type === 'merch');

  const ticketSubtotal = ticketItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  const serviceFees = ticketItems.reduce((acc, item) => acc + 4.5 * item.quantity, 0); // $4.50 service charge per ticket
  const merchSubtotal = merchItems.reduce((acc, item) => acc + item.price * item.quantity, 0);

  const subtotal = ticketSubtotal + merchSubtotal;
  const total = subtotal + serviceFees;

  const handleRemove = (id: string) => {
    setCart(cart.filter((item) => item.id !== id));
  };

  const handleQuantityUpdate = (id: string, qty: number) => {
    setCart(
      cart.map((item) => (item.id === id ? { ...item, quantity: Math.max(1, qty) } : item))
    );
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email) {
      alert('Please fill out all required contact fields.');
      return;
    }

    // Process Purchase
    const newTickets: TicketOrder[] = [];
    const merchProducts: { productId: string; name: string; size: string; quantity: number; price: number }[] = [];

    cart.forEach((item) => {
      if (item.type === 'ticket') {
        const orderId = `TKT-${Math.floor(100000 + Math.random() * 900000)}`;
        newTickets.push({
          id: orderId,
          eventId: item.referenceId,
          eventTitle: item.name.replace(' Admission Ticket', ''),
          eventCity: item.eventCity || 'Underground Venue',
          eventDate: item.eventDate || 'TBA',
          quantity: item.quantity,
          totalPrice: (item.price + 4.5) * item.quantity,
          purchaseDate: new Date().toISOString().split('T')[0],
          barcode: `ARS-${Math.floor(1000000000 + Math.random() * 9000000000)}`,
          status: 'active',
        });
      } else {
        merchProducts.push({
          productId: item.referenceId,
          name: item.name,
          size: item.size || 'O/S',
          quantity: item.quantity,
          price: item.price,
        });
      }
    });

    const newMerchOrders: MerchOrder[] = [];
    if (merchProducts.length > 0) {
      const orderId = `ARS-MRCH-${Math.floor(100000 + Math.random() * 900000)}`;
      newMerchOrders.push({
        id: orderId,
        products: merchProducts,
        totalPrice: merchSubtotal,
        status: 'pending',
        date: new Date().toISOString().split('T')[0],
      });
    }

    setGeneratedTickets(newTickets);
    setGeneratedMerchOrders(newMerchOrders);
    onPurchaseComplete(newTickets, newMerchOrders);
    onClearCart();
    setStep('success');
  };

  if (cart.length === 0 && step !== 'success') {
    return (
      <div className="py-20 px-4 text-center font-sans max-w-md mx-auto text-white relative z-10">
        <ShoppingCart className="w-16 h-16 text-zinc-700 mx-auto mb-6 animate-pulse" />
        <h2 className="font-display text-2xl font-black uppercase tracking-wider mb-2">YOUR CART IS VACANT</h2>
        <p className="text-sm text-zinc-500 mb-6 font-mono">
          Explore our directory of events or stock up on official streetwear to join the crowd.
        </p>
        <button
          onClick={() => setActiveTab('events')}
          className="font-display text-xs font-black tracking-widest text-black bg-neon-green border border-neon-green hover:shadow-[0_0_12px_#39ff1488] px-6 py-3 rounded transition-all cursor-pointer"
        >
          BROWSE SESSIONS
        </button>
      </div>
    );
  }

  return (
    <div className="py-8 px-4 font-sans max-w-6xl mx-auto relative z-10 text-white">
      {/* Checkout Steps */}
      <div className="flex justify-center items-center gap-4 mb-8 font-mono text-xs select-none">
        <span className={`pb-1 border-b-2 ${step === 'cart' ? 'border-neon-pink text-neon-pink font-bold' : 'border-transparent text-zinc-500'}`}>
          01. SHOPPING BAG
        </span>
        <span className="text-zinc-700">/</span>
        <span className={`pb-1 border-b-2 ${step === 'checkout' ? 'border-neon-pink text-neon-pink font-bold' : 'border-transparent text-zinc-500'}`}>
          02. SECURE GATEWAY
        </span>
        <span className="text-zinc-700">/</span>
        <span className={`pb-1 border-b-2 ${step === 'success' ? 'border-neon-green text-neon-green font-bold' : 'border-transparent text-zinc-500'}`}>
          03. TRANSMISSION COMPLETE
        </span>
      </div>

      <AnimatePresence mode="wait">
        {step === 'cart' && (
          <motion.div
            key="cart"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            {/* Cart list items */}
            <div className="lg:col-span-2 space-y-4">
              <h2 className="font-display text-xl font-black uppercase tracking-wider text-neon-pink mb-4">
                SELECTED SHIPMENTS
              </h2>
              {cart.map((item) => (
                <div
                  key={item.id}
                  id={`cart-item-${item.id}`}
                  className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-4 border border-zinc-900 bg-black/70 rounded-lg backdrop-blur-md"
                >
                  <div className="flex items-center gap-4">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 object-cover rounded border border-zinc-850 shrink-0"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-16 h-16 rounded border border-zinc-800 bg-zinc-950 flex items-center justify-center text-neon-pink shrink-0">
                        <Ticket className="w-8 h-8" />
                      </div>
                    )}
                    <div>
                      <h3 className="font-display font-black text-sm uppercase tracking-wide text-white">
                        {item.name}
                      </h3>
                      {item.type === 'ticket' && (
                        <p className="font-mono text-[10px] text-zinc-500 mt-0.5 uppercase">
                          {item.eventCity} • {item.eventDate}
                        </p>
                      )}
                      <p className="font-mono text-xs text-neon-blue font-semibold mt-1">
                        ${item.price.toFixed(2)} {item.type === 'ticket' && '+ $4.50 Fee'}
                      </p>
                    </div>
                  </div>

                  {/* Quantity and Actions */}
                  <div className="flex items-center justify-between w-full sm:w-auto gap-6 border-t sm:border-t-0 border-zinc-900 pt-3 sm:pt-0">
                    <div className="flex items-center border border-zinc-800 bg-zinc-950 rounded overflow-hidden">
                      <button
                        onClick={() => handleQuantityUpdate(item.id, item.quantity - 1)}
                        className="px-2 py-1 font-mono text-zinc-500 hover:text-white hover:bg-zinc-900 border-r border-zinc-800 cursor-pointer"
                      >
                        -
                      </button>
                      <span className="px-3 py-1 font-mono text-xs">{item.quantity}</span>
                      <button
                        onClick={() => handleQuantityUpdate(item.id, item.quantity + 1)}
                        className="px-2 py-1 font-mono text-zinc-500 hover:text-white hover:bg-zinc-900 border-l border-zinc-800 cursor-pointer"
                      >
                        +
                      </button>
                    </div>

                    <div className="flex items-center gap-4">
                      <span className="font-mono text-sm font-bold text-white">
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                      <button
                        onClick={() => handleRemove(item.id)}
                        className="p-1.5 text-zinc-500 hover:text-neon-pink transition-colors cursor-pointer"
                        title="Remove shipment"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Total breakdown */}
            <div className="border border-zinc-900 bg-black/80 rounded-lg p-6 backdrop-blur-md h-fit">
              <h3 className="font-display text-base font-black uppercase tracking-wider text-white border-b border-zinc-900 pb-3 mb-4">
                ORDER BREAKDOWN
              </h3>

              <div className="space-y-2.5 font-mono text-xs text-zinc-400">
                <div className="flex justify-between">
                  <span>ITEMS SUB-TOTAL:</span>
                  <span className="text-white">${subtotal.toFixed(2)}</span>
                </div>
                {serviceFees > 0 && (
                  <div className="flex justify-between">
                    <span>TICKET SERVICE CHARGE:</span>
                    <span className="text-neon-pink">${serviceFees.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between border-t border-zinc-900 pt-3 text-sm font-bold">
                  <span className="text-white font-display">TOTAL SECURED AMOUNT:</span>
                  <span className="text-neon-green">${total.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={() => setStep('checkout')}
                className="w-full flex items-center justify-center gap-2 font-display text-xs font-black tracking-widest text-black bg-neon-pink hover:bg-black hover:text-neon-pink border border-neon-pink py-3 rounded mt-6 hover:shadow-[0_0_15px_rgba(255,0,127,0.4)] transition-all cursor-pointer"
              >
                PROCEED TO GATEWAY <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center gap-1.5 justify-center mt-4 font-mono text-[10px] text-zinc-500">
                <ShieldCheck className="w-3.5 h-3.5 text-neon-blue" />
                <span>256-BIT ENCRYPTED TUNNEL SECURED</span>
              </div>
            </div>
          </motion.div>
        )}

        {step === 'checkout' && (
          <motion.div
            key="checkout"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 10 }}
            className="grid grid-cols-1 lg:grid-cols-3 gap-8"
          >
            {/* Form payment details */}
            <form onSubmit={handleCheckoutSubmit} className="lg:col-span-2 space-y-6">
              <div className="border border-zinc-900 bg-black/80 p-6 rounded-lg backdrop-blur-md space-y-4">
                <h3 className="font-display text-base font-black uppercase tracking-wider text-neon-blue border-b border-zinc-900 pb-3 mb-4">
                  01. CONTACT AND SHIPMENT DETAILS
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                      RAVER FULL NAME *
                    </label>
                    <input
                      required
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-blue"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                      EMAIL FOR TRANSFERS *
                    </label>
                    <input
                      required
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-blue"
                    />
                  </div>
                </div>

                {merchItems.length > 0 && (
                  <div className="space-y-4 pt-4 border-t border-zinc-900/40">
                    <div>
                      <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                        DELIVERY RESIDENCE ADDRESS
                      </label>
                      <input
                        type="text"
                        name="address"
                        value={formData.address}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-blue"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                          TOWN / CITY
                        </label>
                        <input
                          type="text"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-blue"
                        />
                      </div>
                      <div>
                        <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                          POSTCODE / ZIP
                        </label>
                        <input
                          type="text"
                          name="zip"
                          value={formData.zip}
                          onChange={handleInputChange}
                          className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-blue"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Card visual detail */}
              <div className="border border-zinc-900 bg-black/80 p-6 rounded-lg backdrop-blur-md space-y-4">
                <h3 className="font-display text-base font-black uppercase tracking-wider text-neon-orange border-b border-zinc-900 pb-3 mb-4">
                  02. CRYPTO-SHIELDED PAYMENT GATEWAY
                </h3>

                {/* Virtual Neon Card Representation */}
                <div className="relative mx-auto max-w-sm h-48 bg-gradient-to-br from-zinc-950 to-neutral-900 border border-neon-pink/30 rounded-xl p-5 shadow-[0_0_20px_rgba(255,0,127,0.15)] flex flex-col justify-between overflow-hidden select-none">
                  {/* Subtle Grid overlay on card */}
                  <div className="absolute inset-0 bg-radial-at-t from-transparent via-black/40 to-transparent pointer-events-none" />
                  <div className="flex items-center justify-between">
                    <span className="font-display font-black text-xs text-white">AMERICAN RAVE CARD</span>
                    <CreditCard className="w-5 h-5 text-neon-pink" />
                  </div>
                  <div className="font-mono text-lg tracking-widest text-neon-blue mt-4">
                    {formData.cardNumber || '•••• •••• •••• ••••'}
                  </div>
                  <div className="flex justify-between items-end mt-4">
                    <div>
                      <span className="block font-mono text-[7px] text-zinc-600 uppercase">CARDHOLDER</span>
                      <span className="font-mono text-xs text-zinc-300 tracking-wider truncate block max-w-[180px]">
                        {(formData.cardName || 'RAVER NAME').toUpperCase()}
                      </span>
                    </div>
                    <div className="flex gap-4">
                      <div>
                        <span className="block font-mono text-[7px] text-zinc-600 uppercase">EXPIRY</span>
                        <span className="font-mono text-xs text-zinc-300">{formData.cardExpiry || 'MM/YY'}</span>
                      </div>
                      <div>
                        <span className="block font-mono text-[7px] text-zinc-600 uppercase">CVV</span>
                        <span className="font-mono text-xs text-zinc-300">{formData.cardCVV || '•••'}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card input forms */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                  <div className="sm:col-span-2">
                    <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                      CARDHOLDER NAME
                    </label>
                    <input
                      type="text"
                      name="cardName"
                      value={formData.cardName}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-orange"
                    />
                  </div>
                  <div>
                    <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                      CREDIT CARD NUMBER
                    </label>
                    <input
                      type="text"
                      name="cardNumber"
                      value={formData.cardNumber}
                      onChange={handleInputChange}
                      className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-orange"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                        EXPIRY DATE
                      </label>
                      <input
                        type="text"
                        name="cardExpiry"
                        value={formData.cardExpiry}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-orange"
                        placeholder="MM/YY"
                      />
                    </div>
                    <div>
                      <label className="block font-mono text-[10px] text-zinc-400 uppercase font-bold mb-1.5">
                        CVV SHIELD
                      </label>
                      <input
                        type="text"
                        name="cardCVV"
                        value={formData.cardCVV}
                        onChange={handleInputChange}
                        className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-orange"
                        placeholder="123"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="font-mono text-xs text-zinc-400 hover:text-white bg-zinc-950 border border-zinc-850 rounded px-6 py-3 cursor-pointer"
                >
                  RETURN TO BAG
                </button>
                <button
                  type="submit"
                  className="flex-1 font-display text-xs font-black tracking-widest text-black bg-neon-green hover:bg-black hover:text-neon-green border border-neon-green py-3 rounded hover:shadow-[0_0_15px_#39ff1488] transition-all cursor-pointer"
                >
                  AUTHORIZE SECURE SHIPMENT
                </button>
              </div>
            </form>

            {/* Sticky summary */}
            <div className="border border-zinc-900 bg-black/80 rounded-lg p-6 backdrop-blur-md h-fit">
              <h3 className="font-display text-base font-black uppercase tracking-wider text-white border-b border-zinc-900 pb-3 mb-4">
                FINAL CHECK
              </h3>

              <div className="space-y-3 font-mono text-xs text-zinc-400 border-b border-zinc-900 pb-4">
                {cart.map((item) => (
                  <div key={item.id} className="flex justify-between items-start">
                    <span className="truncate max-w-[150px] uppercase">
                      {item.quantity}x {item.name}
                    </span>
                    <span className="text-zinc-300 font-semibold">${(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-2.5 font-mono text-[11px] text-zinc-500 pt-4">
                <div className="flex justify-between">
                  <span>SUB-TOTAL:</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                {serviceFees > 0 && (
                  <div className="flex justify-between">
                    <span>TICKET SERVICE FEES:</span>
                    <span>${serviceFees.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-white font-bold border-t border-zinc-900 pt-3 text-xs">
                  <span>TOTAL DUE:</span>
                  <span className="text-neon-green">${total.toFixed(2)}</span>
                </div>
              </div>

              <p className="text-[10px] font-mono text-zinc-500 italic text-center mt-5 leading-snug">
                By completing transaction, you agree to rave safety policies, age limitations, and electronic PLUR transfers.
              </p>
            </div>
          </motion.div>
        )}

        {step === 'success' && (
          <motion.div
            key="success"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="border border-zinc-900 bg-black/80 rounded-lg p-6 md:p-8 backdrop-blur-md max-w-4xl mx-auto space-y-8"
          >
            {/* Header banner */}
            <div className="text-center space-y-3">
              <CheckCircle className="w-14 h-14 text-neon-green mx-auto glow-green" />
              <h2 className="font-display text-2xl md:text-3xl font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-neon-green to-neon-blue">
                SECURED TRANSACTION SUCCESSFUL
              </h2>
              <p className="font-mono text-xs text-zinc-400">
                TRANSFERRED VIA SECURE RAVE-CRYPT CHANNELS. EMAIL SENT TO {formData.email.toUpperCase()}
              </p>
            </div>

            {/* Generated E-Tickets */}
            {generatedTickets.length > 0 && (
              <div className="space-y-4">
                <h3 className="font-display text-xs font-black uppercase tracking-widest text-neon-pink border-b border-zinc-900 pb-2">
                  YOUR COMPLETED ADMISSION CARDS
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {generatedTickets.map((tkt) => (
                    <div
                      key={tkt.id}
                      id={`ticket-${tkt.id}`}
                      className="border border-dashed border-zinc-800 bg-zinc-950 p-4 rounded-lg flex flex-col justify-between gap-4 relative overflow-hidden"
                    >
                      {/* Left vertical fluorescent color blocks */}
                      <div className="absolute top-0 left-0 w-1.5 h-full bg-gradient-to-b from-neon-pink via-neon-orange to-neon-green" />

                      <div className="pl-3">
                        <div className="flex justify-between items-start gap-2">
                          <span className="font-mono text-[9px] font-bold text-neon-pink border border-neon-pink/20 bg-neon-pink/5 px-1.5 py-0.5 rounded">
                            {tkt.id}
                          </span>
                          <span className="font-mono text-[9px] text-zinc-500">ARS DIGITAL SYSTEM</span>
                        </div>

                        <h4 className="font-display font-black text-sm text-white uppercase tracking-wider mt-2">
                          {tkt.eventTitle}
                        </h4>

                        <div className="grid grid-cols-2 gap-2 mt-3 font-mono text-[10px] text-zinc-400">
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-neon-green shrink-0" />
                            <span className="truncate">{tkt.eventCity}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-neon-orange shrink-0" />
                            <span>{tkt.eventDate}</span>
                          </div>
                        </div>

                        <div className="mt-3 font-mono text-[9px] text-zinc-500">
                          HOLDER: {formData.name.toUpperCase()} • QTY: {tkt.quantity} ADMISSION(S)
                        </div>
                      </div>

                      {/* Mock barcode generator */}
                      <div className="border-t border-zinc-900/80 pt-3 flex flex-col items-center justify-center bg-zinc-950/80 pl-3">
                        {/* Barcode representation */}
                        <div className="h-10 w-full flex items-end justify-center gap-[1px] bg-black p-1 rounded">
                          {Array.from({ length: 48 }).map((_, idx) => (
                            <span
                              key={idx}
                              className="bg-zinc-300 h-full"
                              style={{
                                width: idx % 3 === 0 ? '3px' : idx % 5 === 0 ? '1px' : '2px',
                                opacity: idx % 7 === 0 ? 0.3 : 1,
                              }}
                            />
                          ))}
                        </div>
                        <span className="font-mono text-[8px] text-zinc-500 tracking-[0.25em] mt-1.5 uppercase">
                          {tkt.barcode}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Merch receipts */}
            {generatedMerchOrders.length > 0 && (
              <div className="space-y-3">
                <h3 className="font-display text-xs font-black uppercase tracking-widest text-neon-blue border-b border-zinc-900 pb-2">
                  MERCHANDISE ORDER RECOGNITION
                </h3>
                {generatedMerchOrders.map((ord) => (
                  <div key={ord.id} className="p-4 border border-zinc-900 bg-zinc-950 rounded font-mono text-xs space-y-2">
                    <div className="flex justify-between font-bold">
                      <span className="text-neon-blue">ID: {ord.id}</span>
                      <span className="text-zinc-500">STATUS: PENDING DISPATCH</span>
                    </div>
                    <ul className="text-zinc-400 space-y-1">
                      {ord.products.map((item, index) => (
                        <li key={index} className="flex justify-between text-[11px]">
                          <span>{item.quantity} x {item.name}</span>
                          <span>${(item.price * item.quantity).toFixed(2)}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="border-t border-zinc-900 pt-2 flex justify-between font-bold text-white text-[11px]">
                      <span>SHIPPED TO:</span>
                      <span className="text-zinc-300 uppercase">{formData.name} • {formData.city}, {formData.zip}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Next movements */}
            <div className="pt-6 border-t border-zinc-900 flex flex-col sm:flex-row gap-4 items-center justify-between">
              <span className="font-mono text-xs text-zinc-500">
                TICKETS & ORDER HISTORY ARE INSTANTLY AVAILABLE IN YOUR USER CABINET.
              </span>
              <div className="flex gap-3">
                <button
                  onClick={() => setActiveTab('account')}
                  className="font-mono text-xs text-neon-blue hover:underline bg-zinc-950 border border-zinc-800 rounded px-4 py-2 cursor-pointer"
                >
                  VIEW PROFILE CABINET
                </button>
                <button
                  onClick={() => {
                    setGeneratedTickets([]);
                    setGeneratedMerchOrders([]);
                    setStep('cart');
                    setActiveTab('home');
                  }}
                  className="font-display text-[10px] font-black tracking-widest text-black bg-neon-pink rounded px-5 py-2.5 cursor-pointer hover:shadow-[0_0_10px_#ff007f]"
                >
                  RETURN TO HOME
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
