import { Search, User, ShoppingCart, Lock } from 'lucide-react';
import { motion } from 'motion/react';
import { CartItem, UserProfile } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cart: CartItem[];
  user: UserProfile | null;
  onSearchClick: () => void;
}

export default function Navbar({ activeTab, setActiveTab, cart, user, onSearchClick }: NavbarProps) {
  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0);

  const navLinks = [
    { id: 'home', label: 'HOME' },
    { id: 'events', label: 'EVENTS' },
    { id: 'news', label: 'NEWS' },
    { id: 'merch', label: 'MERCH' },
    { id: 'about', label: 'ABOUT' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-zinc-900 bg-black/90 backdrop-blur-xl px-4 py-3 select-none">
      <div className="mx-auto flex max-w-7xl items-center justify-between">
        {/* Logo block */}
        <div
          id="brand-logo-container"
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 cursor-pointer group"
        >
          {/* Glowing hexagon logo matching mockup */}
          <div className="relative flex h-9 w-9 items-center justify-center">
            <div className="absolute inset-0 rounded-lg border-2 border-neon-pink/40 bg-neon-pink/5 blur-[4px] group-hover:border-neon-pink group-hover:blur-[8px] transition-all duration-300" />
            <div className="absolute inset-1 rounded-md border border-neon-orange/60 bg-black flex items-center justify-center font-black text-xs text-neon-pink tracking-tighter">
              <span className="text-neon-pink font-bold">A</span>
              <span className="text-neon-orange font-bold">R</span>
              <span className="text-neon-green font-bold">S</span>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="font-display text-base font-black tracking-widest text-white leading-none group-hover:text-neon-pink transition-colors duration-200">
              AMERICAN
            </span>
            <span className="font-display text-[10px] font-bold tracking-[0.27em] text-neon-pink leading-none mt-0.5">
              RAVE SCENE
            </span>
          </div>
        </div>

        {/* Desktop nav links */}
        <nav className="hidden md:flex items-center gap-6 lg:gap-8">
          {navLinks.map((link) => {
            const isActive = activeTab === link.id;
            return (
              <button
                key={link.id}
                id={`nav-${link.id}`}
                onClick={() => setActiveTab(link.id)}
                className={`relative font-display text-xs font-bold tracking-widest transition-colors duration-200 cursor-pointer ${
                  isActive ? 'text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                {link.label}
                {isActive && (
                  <motion.div
                    layoutId="activeNavIndicator"
                    className="absolute -bottom-[17px] left-0 right-0 h-[2px] bg-gradient-to-r from-neon-pink via-neon-orange to-neon-green shadow-[0_0_10px_rgba(255,0,127,0.8)]"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            );
          })}

          {/* Render admin link if role is admin */}
          {user && user.role === 'admin' && (
            <button
              id="nav-admin"
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1 font-display text-xs font-bold tracking-widest transition-colors duration-200 cursor-pointer ${
                activeTab === 'admin' ? 'text-neon-green' : 'text-zinc-500 hover:text-neon-green'
              }`}
            >
              <Lock className="w-3.5 h-3.5 animate-pulse" />
              CMS
            </button>
          )}
        </nav>

        {/* Right tools (Search, User, Cart, Button) */}
        <div className="flex items-center gap-3 lg:gap-4">
          {/* Search trigger */}
          <button
            id="nav-search-btn"
            onClick={onSearchClick}
            className="p-2 text-zinc-400 hover:text-white hover:scale-115 transition-all duration-150 cursor-pointer rounded-full hover:bg-zinc-900/40"
            title="Search database"
          >
            <Search className="h-4.5 w-4.5" />
          </button>

          {/* User Profile */}
          <button
            id="nav-account-btn"
            onClick={() => setActiveTab('account')}
            className={`p-2 hover:scale-115 transition-all duration-150 cursor-pointer rounded-full hover:bg-zinc-900/40 ${
              user ? 'text-neon-blue shadow-[0_0_8px_rgba(0,240,255,0.2)]' : 'text-zinc-400 hover:text-white'
            }`}
            title={user ? `Dashboard: ${user.name}` : 'Login / Register'}
          >
            <User className="h-4.5 w-4.5" />
          </button>

          {/* Interactive Cart trigger */}
          <button
            id="nav-cart-btn"
            onClick={() => setActiveTab('cart')}
            className={`p-2 relative hover:scale-115 transition-all duration-150 cursor-pointer rounded-full hover:bg-zinc-900/40 ${
              totalItems > 0 ? 'text-neon-pink shadow-[0_0_8px_rgba(255,0,127,0.2)]' : 'text-zinc-400 hover:text-white'
            }`}
            title="Checkout cart"
          >
            <ShoppingCart className="h-4.5 w-4.5" />
            {totalItems > 0 && (
              <motion.span
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute -top-0.5 -right-0.5 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-neon-pink text-[9px] font-mono font-bold text-white shadow-[0_0_5px_#ff007f]"
              >
                {totalItems}
              </motion.span>
            )}
          </button>

          {/* Dynamic Action Button */}
          {user ? (
            <button
              id="nav-logout-btn"
              onClick={() => setActiveTab('account')}
              className="hidden sm:inline-block font-display text-[10px] font-bold tracking-widest text-zinc-400 border border-zinc-800 hover:border-zinc-500 rounded px-3 py-1.5 transition-colors duration-200 cursor-pointer"
            >
              MY ACCOUNT
            </button>
          ) : (
            <button
              id="nav-join-btn"
              onClick={() => {
                setActiveTab('account');
              }}
              className="font-display text-[10px] font-black tracking-widest text-white border border-neon-pink bg-neon-pink/10 hover:bg-neon-pink/20 rounded px-4 py-1.5 transition-all duration-200 cursor-pointer hover:shadow-[0_0_12px_rgba(255,0,127,0.4)]"
            >
              JOIN THE SCENE
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
