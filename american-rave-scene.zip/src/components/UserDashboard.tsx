import React, { useState } from 'react';
import { User, Ticket, ShoppingBag, Heart, ShieldAlert, LogOut, Sparkles, MapPin, Calendar, QrCode } from 'lucide-react';
import { motion } from 'motion/react';
import { UserProfile, Event, TicketOrder, MerchOrder } from '../types';

interface UserDashboardProps {
  user: UserProfile | null;
  events: Event[];
  onLogin: (name: string, email: string) => void;
  onLogout: () => void;
  onToggleFavorite: (eventId: string) => void;
  favorites: string[];
  onSetUserRole: (role: 'user' | 'admin') => void;
  onSelectEvent: (id: string) => void;
}

export default function UserDashboard({
  user,
  events,
  onLogin,
  onLogout,
  onToggleFavorite,
  favorites,
  onSetUserRole,
  onSelectEvent,
}: UserDashboardProps) {
  const [activeTab, setActiveTab] = useState<'tickets' | 'merch' | 'favorites' | 'profile'>('tickets');
  const [loginName, setLoginName] = useState('');
  const [loginEmail, setLoginEmail] = useState('');

  const favoriteEvents = events.filter((ev) => favorites.includes(ev.id));

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginName || !loginEmail) return;
    onLogin(loginName, loginEmail);
  };

  // If user is not logged in, show the login portal
  if (!user) {
    return (
      <div className="py-12 px-4 max-w-md mx-auto text-white relative z-10 font-sans">
        <div className="border border-zinc-900 bg-black/90 p-6 md:p-8 rounded-lg shadow-[0_0_30px_rgba(255,0,127,0.15)] backdrop-blur-xl relative overflow-hidden">
          {/* Neon accent corner */}
          <div className="absolute top-0 right-0 w-20 h-20 bg-neon-pink/10 rounded-full blur-2xl" />

          <div className="text-center space-y-2 mb-6">
            <div className="h-12 w-12 rounded-full border border-neon-pink/40 bg-neon-pink/5 flex items-center justify-center mx-auto text-neon-pink">
              <User className="w-6 h-6 animate-pulse" />
            </div>
            <h2 className="font-display text-2xl font-black uppercase tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-white via-zinc-200 to-neon-pink">
              JOIN THE MOVEMENT
            </h2>
            <p className="font-mono text-[10px] text-zinc-500 uppercase tracking-widest leading-relaxed">
              Create an account or sign in to save admission tickets, merchandise shipments, and bookmark your next sets.
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            <div>
              <label className="block font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold mb-1.5">
                RAVER USERNAME
              </label>
              <input
                id="login-name-input"
                required
                type="text"
                placeholder="e.g. AcidRaver99"
                value={loginName}
                onChange={(e) => setLoginName(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-pink"
              />
            </div>

            <div>
              <label className="block font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold mb-1.5">
                EMAIL TRANSMISSION ADDRESS
              </label>
              <input
                id="login-email-input"
                required
                type="email"
                placeholder="e.g. cyber@rave.com"
                value={loginEmail}
                onChange={(e) => setLoginEmail(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-zinc-950 border border-zinc-800 text-sm font-mono rounded text-white focus:outline-none focus:border-neon-pink"
              />
            </div>

            <button
              type="submit"
              className="w-full font-display text-xs font-black tracking-widest text-black bg-neon-pink border border-neon-pink py-3 rounded cursor-pointer hover:bg-black hover:text-neon-pink hover:shadow-[0_0_15px_rgba(255,0,127,0.4)] transition-all"
            >
              INITIALIZE CONNECTION
            </button>
          </form>

          <p className="text-[10px] text-zinc-600 text-center font-mono mt-6 leading-relaxed">
            By connecting, you register a secure simulated local account stored directly inside your browser storage.
          </p>
        </div>
      </div>
    );
  }

  // Logged in Dashboard
  return (
    <div id="user-dashboard-container" className="py-8 px-4 font-sans max-w-5xl mx-auto relative z-10 text-white">
      {/* Profile Header */}
      <div className="border border-zinc-900 bg-black/80 rounded-lg p-6 backdrop-blur-md mb-8 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
        {/* Glow behind */}
        <div className="absolute -top-10 -left-10 w-40 h-40 bg-neon-blue/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-full border border-neon-blue bg-neon-blue/10 flex items-center justify-center text-neon-blue shadow-[0_0_10px_rgba(0,240,255,0.2)]">
            <User className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display text-xl font-black uppercase tracking-wider text-white">
                {user.name}
              </h2>
              <span className={`font-mono text-[9px] font-bold px-2 py-0.5 rounded border ${
                user.role === 'admin'
                  ? 'border-neon-green text-neon-green bg-neon-green/5'
                  : 'border-zinc-800 text-zinc-500'
              }`}>
                {user.role.toUpperCase()}
              </span>
            </div>
            <p className="font-mono text-[10px] text-zinc-500 mt-0.5">{user.email.toUpperCase()}</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 font-mono text-[10px] text-zinc-400 hover:text-neon-pink border border-zinc-800 hover:border-neon-pink px-3.5 py-2 rounded transition-all cursor-pointer bg-zinc-950/40"
          >
            <LogOut className="w-3.5 h-3.5" /> LOG OUT
          </button>
        </div>
      </div>

      {/* Dashboard Sub-navigation tabs */}
      <div className="flex border-b border-zinc-900 mb-6 gap-2 sm:gap-4 overflow-x-auto select-none">
        <button
          onClick={() => setActiveTab('tickets')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeTab === 'tickets' ? 'border-neon-pink text-neon-pink' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <Ticket className="w-4 h-4" /> MY ADMISSIONS ({user.savedTickets.length})
        </button>
        <button
          onClick={() => setActiveTab('merch')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeTab === 'merch' ? 'border-neon-pink text-neon-pink' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <ShoppingBag className="w-4 h-4" /> STREETWEAR ({user.orderHistory.length})
        </button>
        <button
          onClick={() => setActiveTab('favorites')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeTab === 'favorites' ? 'border-neon-pink text-neon-pink' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <Heart className="w-4 h-4" /> FAVORITES ({favorites.length})
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeTab === 'profile' ? 'border-neon-pink text-neon-pink' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <ShieldAlert className="w-4 h-4" /> CREDENTIAL SECURITY
        </button>
      </div>

      {/* Tab Panels */}
      <div>
        {activeTab === 'tickets' && (
          <div className="space-y-4">
            {user.savedTickets.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-zinc-800 bg-black/40 rounded-lg">
                <Ticket className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
                <p className="font-mono text-zinc-500 text-xs uppercase">No active admissions stored in profile.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {user.savedTickets.map((tkt) => (
                  <div
                    key={tkt.id}
                    id={`saved-ticket-${tkt.id}`}
                    className="border border-zinc-900 bg-zinc-950 p-5 rounded-lg flex justify-between gap-4 relative overflow-hidden"
                  >
                    <div className="absolute top-0 left-0 w-1.5 h-full bg-neon-pink" />
                    <div className="pl-3 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-mono text-[9px] font-bold text-neon-pink border border-neon-pink/20 bg-neon-pink/5 px-2 py-0.5 rounded">
                            {tkt.id}
                          </span>
                          <span className="font-mono text-[8px] text-zinc-500 uppercase">ACTIVE ADMISSION</span>
                        </div>
                        <h3 className="font-display text-base font-black uppercase text-white mt-2 tracking-wide truncate max-w-[200px]">
                          {tkt.eventTitle}
                        </h3>
                        <div className="space-y-1 mt-2.5 font-mono text-[10px] text-zinc-400">
                          <p className="flex items-center gap-1"><MapPin className="w-3 h-3 text-neon-green" /> {tkt.eventCity}</p>
                          <p className="flex items-center gap-1"><Calendar className="w-3 h-3 text-neon-orange" /> {tkt.eventDate}</p>
                        </div>
                      </div>
                      <div className="mt-4 text-[9px] font-mono text-zinc-500 uppercase">
                        QTY: {tkt.quantity} • SECURED: {tkt.purchaseDate}
                      </div>
                    </div>

                    <div className="border-l border-zinc-900 pl-4 flex flex-col items-center justify-center shrink-0">
                      <QrCode className="w-16 h-16 text-white" />
                      <span className="font-mono text-[7px] text-zinc-500 tracking-wider mt-1">{tkt.barcode}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'merch' && (
          <div className="space-y-4">
            {user.orderHistory.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-zinc-800 bg-black/40 rounded-lg">
                <ShoppingBag className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
                <p className="font-mono text-zinc-500 text-xs uppercase">No merchandise order history stored.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {user.orderHistory.map((ord) => (
                  <div key={ord.id} className="border border-zinc-900 bg-zinc-950 p-4 rounded-lg font-mono text-xs">
                    <div className="flex justify-between border-b border-zinc-900 pb-2 mb-2">
                      <span className="font-bold text-neon-blue">ORDER: {ord.id}</span>
                      <span className="font-bold text-neon-orange">STATUS: {ord.status.toUpperCase()}</span>
                    </div>
                    <ul className="space-y-1.5 text-zinc-400">
                      {ord.products.map((p, idx) => (
                        <li key={idx} className="flex justify-between">
                          <span>{p.quantity} x {p.name} ({p.size})</span>
                          <span>${(p.price * p.quantity).toFixed(2)}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="border-t border-zinc-900 pt-2.5 mt-2 flex justify-between font-bold text-white">
                      <span>SECURED ON: {ord.date}</span>
                      <span className="text-neon-green">TOTAL: ${ord.totalPrice.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'favorites' && (
          <div className="space-y-4">
            {favoriteEvents.length === 0 ? (
              <div className="text-center py-12 border border-dashed border-zinc-800 bg-black/40 rounded-lg">
                <Heart className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
                <p className="font-mono text-zinc-500 text-xs uppercase">No event bookmarks added. Tap the heart on event cards.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {favoriteEvents.map((ev) => (
                  <div
                    key={ev.id}
                    className="p-4 border border-zinc-900 bg-zinc-950 rounded-lg flex items-center justify-between gap-4"
                  >
                    <div>
                      <h3 className="font-display font-black text-sm uppercase text-white truncate max-w-[180px]">
                        {ev.title}
                      </h3>
                      <p className="font-mono text-[10px] text-zinc-500 mt-1 uppercase">
                        {ev.venue} • {ev.city}
                      </p>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => onSelectEvent(ev.id)}
                        className="font-mono text-[9px] font-bold border border-zinc-800 text-zinc-400 hover:text-white px-2.5 py-1.5 rounded transition-colors cursor-pointer"
                      >
                        VIEW
                      </button>
                      <button
                        onClick={() => onToggleFavorite(ev.id)}
                        className="p-1.5 border border-zinc-800 text-neon-pink hover:bg-neon-pink/10 rounded cursor-pointer transition-colors"
                      >
                        <Heart className="w-3.5 h-3.5 fill-neon-pink text-neon-pink" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="border border-zinc-900 bg-black/80 rounded-lg p-6 backdrop-blur-md max-w-lg">
            <h3 className="font-display text-sm font-black uppercase tracking-wider text-neon-pink border-b border-zinc-900 pb-3 mb-4 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-neon-pink" /> SECURITY ELEVATION CABINET
            </h3>

            <div className="space-y-4">
              <p className="text-xs text-zinc-400 font-mono leading-relaxed">
                As a member of the American Rave Scene, you can toggle developer permissions to test promoters, organizers, and merchandise inventories in real-time.
              </p>

              <div className="p-4 border border-zinc-900 bg-zinc-950/60 rounded flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-mono text-xs font-bold text-white">PROMOTER ACCESS (ADMIN PANEL)</h4>
                  <p className="text-[10px] text-zinc-500 font-mono mt-1">Unlocks the interactive CMS system to add and edit events, write news editorials, and manage products.</p>
                </div>

                <button
                  onClick={() => {
                    const newRole = user.role === 'admin' ? 'user' : 'admin';
                    onSetUserRole(newRole);
                    alert(`Access Elevated! Role updated to: ${newRole.toUpperCase()}. Check navigation headers!`);
                  }}
                  className={`font-mono text-[10px] font-bold tracking-widest uppercase border px-3 py-1.5 rounded transition-all cursor-pointer shrink-0 ${
                    user.role === 'admin'
                      ? 'border-neon-green text-neon-green bg-neon-green/5 shadow-[0_0_8px_#39ff1488]'
                      : 'border-zinc-800 text-zinc-400 hover:text-white hover:border-zinc-600'
                  }`}
                >
                  {user.role === 'admin' ? 'REVOKE ACCESS' : 'ELEVATE ACCESS'}
                </button>
              </div>

              <div className="border-t border-zinc-900/60 pt-4 font-mono text-[9px] text-zinc-600 leading-snug">
                ARS CREDENTIAL MANAGER SECURITY SYSTEM v4.11 / DETROIT CORE GATEWAY
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
