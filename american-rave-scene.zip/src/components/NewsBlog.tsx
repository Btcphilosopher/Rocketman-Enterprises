import { useState } from 'react';
import { Calendar, User, ArrowLeft, Share2, Tag, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';
import { NewsPost } from '../types';

interface NewsBlogProps {
  news: NewsPost[];
  currentPostId: string | null;
  setCurrentPostId: (id: string | null) => void;
}

export default function NewsBlog({ news, currentPostId, setCurrentPostId }: NewsBlogProps) {
  const [selectedCategory, setSelectedCategory] = useState('ALL');

  const categories = ['ALL', ...Array.from(new Set(news.map((n) => n.category)))];

  const filteredNews = news.filter((n) => {
    return selectedCategory === 'ALL' || n.category === selectedCategory;
  });

  const activePost = news.find((n) => n.id === currentPostId);

  // Detail Article view mode
  if (activePost) {
    return (
      <div id="news-detail-container" className="py-8 px-4 font-sans max-w-4xl mx-auto relative z-10 text-white">
        <button
          onClick={() => setCurrentPostId(null)}
          className="flex items-center gap-2 font-mono text-xs text-zinc-400 hover:text-white mb-6 border border-zinc-800 bg-black/60 px-3 py-1.5 rounded cursor-pointer transition-all"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-neon-pink" /> BACK TO SCENE JOURNAL
        </button>

        <article className="border border-zinc-900 bg-black/80 rounded-lg overflow-hidden p-6 md:p-8 backdrop-blur-md shadow-2xl">
          <div className="flex items-center gap-2 mb-4 font-mono text-xs">
            <span className="text-neon-pink font-semibold border border-neon-pink/20 bg-neon-pink/5 px-2 py-0.5 rounded uppercase">
              {activePost.category}
            </span>
            <span className="text-zinc-500">•</span>
            <div className="flex items-center gap-1 text-zinc-400">
              <Calendar className="w-3.5 h-3.5" />
              <span>{activePost.date}</span>
            </div>
            <span className="text-zinc-500">•</span>
            <div className="flex items-center gap-1 text-zinc-400">
              <User className="w-3.5 h-3.5 text-neon-blue" />
              <span>{activePost.author}</span>
            </div>
          </div>

          <h1 className="font-display text-2xl md:text-4xl font-black tracking-tight text-white mb-6 uppercase">
            {activePost.title}
          </h1>

          <div className="h-64 md:h-96 w-full rounded overflow-hidden mb-6 border border-zinc-850">
            <img
              src={activePost.image}
              alt={activePost.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="flex justify-between items-center border-y border-zinc-900 py-3 mb-6">
            <span className="font-mono text-xs text-zinc-500">AMERICAN RAVE SCENE PRESS OFFICE</span>
            <button
              onClick={() => alert('Share link copied to clipboard!')}
              className="flex items-center gap-1.5 font-mono text-xs text-neon-blue hover:text-white transition-colors cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" /> SHARE STORY
            </button>
          </div>

          <p className="font-mono text-sm text-zinc-400 italic mb-6 leading-relaxed border-l-2 border-neon-pink pl-4 bg-zinc-950/40 py-2">
            "{activePost.excerpt}"
          </p>

          <div className="text-sm md:text-base text-zinc-300 space-y-4 font-normal leading-relaxed whitespace-pre-line">
            {activePost.content}
          </div>

          <div className="mt-12 pt-6 border-t border-zinc-900 flex flex-col sm:flex-row items-center justify-between gap-4 bg-zinc-950/30 p-4 rounded border border-zinc-900/50">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-neon-pink/10 border border-neon-pink flex items-center justify-center font-bold text-neon-pink text-xs">
                ARS
              </div>
              <div className="flex flex-col">
                <span className="font-mono text-xs font-bold text-white">{activePost.author}</span>
                <span className="text-[10px] text-zinc-500">Underground culture editorial desk</span>
              </div>
            </div>
            <button
              onClick={() => setCurrentPostId(null)}
              className="font-mono text-xs text-neon-pink hover:underline cursor-pointer"
            >
              BROWSE MORE JOURNAL ENTRIES
            </button>
          </div>
        </article>
      </div>
    );
  }

  return (
    <div id="news-blog-container" className="py-8 px-4 font-sans max-w-7xl mx-auto relative z-10 text-white">
      {/* News header */}
      <div className="mb-8 text-center md:text-left flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-3xl md:text-4xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-neon-pink via-neon-orange to-neon-violet">
            SCENE JOURNAL
          </h2>
          <p className="font-mono text-xs text-zinc-400 mt-2">
            LATEST UNDERGROUND TRANSMISSIONS, FESTIVAL NEWS, AND PLUR EDITORIALS
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex gap-2 overflow-x-auto max-w-full pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`font-mono text-[10px] font-bold tracking-widest uppercase border px-3 py-1.5 rounded transition-all cursor-pointer whitespace-nowrap ${
                selectedCategory === cat
                  ? 'border-neon-pink text-neon-pink bg-neon-pink/10 shadow-[0_0_10px_rgba(255,0,127,0.2)]'
                  : 'border-zinc-800 text-zinc-500 hover:text-white hover:border-zinc-600'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of posts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {filteredNews.map((post) => (
          <motion.div
            key={post.id}
            id={`news-card-${post.id}`}
            whileHover={{ y: -5 }}
            className="group border border-zinc-900 bg-black/60 rounded-lg overflow-hidden flex flex-col justify-between hover:border-zinc-700 hover:shadow-[0_0_20px_rgba(255,0,127,0.08)] transition-all duration-300 backdrop-blur-md cursor-pointer"
            onClick={() => setCurrentPostId(post.id)}
          >
            <div>
              <div className="relative h-44 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <span className="absolute top-3 left-3 font-mono text-[9px] font-bold tracking-widest text-white border border-neon-pink bg-neon-pink/20 px-2 py-0.5 rounded-xs uppercase shadow-[0_0_5px_#ff007f]">
                  {post.category}
                </span>
              </div>

              <div className="p-4">
                <div className="flex items-center gap-1.5 font-mono text-[10px] text-zinc-500 mb-2">
                  <Calendar className="w-3 h-3" />
                  <span>{post.date}</span>
                </div>

                <h3 className="font-display text-lg font-black leading-snug group-hover:text-neon-pink transition-colors uppercase">
                  {post.title}
                </h3>

                <p className="text-xs text-zinc-400 mt-2 line-clamp-3">
                  {post.excerpt}
                </p>
              </div>
            </div>

            <div className="p-4 pt-0">
              <div className="border-t border-zinc-950 py-3 flex items-center justify-between font-mono text-[10px] text-neon-blue font-bold group-hover:text-white transition-colors">
                <span className="flex items-center gap-1">
                  <BookOpen className="w-3.5 h-3.5" /> READ ARTICLE
                </span>
                <span>BY {post.author.toUpperCase()}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
