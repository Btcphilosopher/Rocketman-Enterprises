import { motion } from 'motion/react';

export default function Ticker() {
  const announcements = [
    'BREAKING: Movement Festival 2026 phase 2 lineup announced!',
    'EDC Las Vegas 2026 sold out',
    'New warehouse series announced in Chicago',
    'Bass Coast 2026 tickets on sale now',
    'Ultra Miami reveals resistance stage mega-structure',
    'Detroit Techno Museum opens historical archive archive online',
  ];

  // Repeat items to fill wide displays and ensure seamless loop
  const repeatedText = [...announcements, ...announcements, ...announcements].join('   •   ');

  return (
    <div id="scene-feed-ticker" className="border-y border-zinc-800 bg-black/80 py-2.5 backdrop-blur-md relative overflow-hidden select-none z-10 flex items-center">
      <div className="px-4 font-mono text-xs tracking-wider text-neon-pink font-bold border-r border-zinc-800 whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-[0_0_10px_rgba(255,0,127,0.1)]">
        <span className="inline-block w-2 h-2 rounded-full bg-neon-pink animate-ping" />
        SCENE FEED
      </div>
      <div className="overflow-hidden flex w-full">
        <motion.div
          initial={{ x: 0 }}
          animate={{ x: '-33.3333%' }}
          transition={{
            repeat: Infinity,
            repeatType: 'loop',
            duration: 35,
            ease: 'linear',
          }}
          className="whitespace-nowrap font-mono text-xs tracking-widest text-zinc-300 uppercase flex gap-4 pl-4"
        >
          {repeatedText}
        </motion.div>
      </div>
    </div>
  );
}
