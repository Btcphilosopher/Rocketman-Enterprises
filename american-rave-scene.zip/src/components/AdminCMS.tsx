import React, { useState } from 'react';
import { Calendar, Plus, Trash2, LineChart, Shield, Ticket, Newspaper, ShoppingBag, DollarSign } from 'lucide-react';
import { motion } from 'motion/react';
import { Event, NewsPost, Product } from '../types';

interface AdminCMSProps {
  events: Event[];
  setEvents: (events: Event[]) => void;
  news: NewsPost[];
  setNews: (news: NewsPost[]) => void;
  products: Product[];
  setProducts: (products: Product[]) => void;
}

export default function AdminCMS({
  events,
  setEvents,
  news,
  setNews,
  products,
  setProducts,
}: AdminCMSProps) {
  const [activeSubTab, setActiveSubTab] = useState<'events' | 'news' | 'merch'>('events');

  // Interactive state forms
  const [eventForm, setEventForm] = useState({
    title: '',
    city: '',
    venue: '',
    date: '',
    time: '22:00 - 05:00',
    genres: '',
    lineup: '',
    description: '',
    price: '',
    ticketStock: '',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=600&auto=format&fit=crop',
    isFeatured: 'false',
    status: 'upcoming' as 'upcoming' | 'cancelled' | 'sold_out' | 'live',
  });

  const [newsForm, setNewsForm] = useState({
    title: '',
    excerpt: '',
    content: '',
    category: 'Festivals',
    image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=600&auto=format&fit=crop',
    author: 'Promoter Desk',
  });

  const [productForm, setProductForm] = useState({
    name: '',
    price: '',
    description: '',
    category: 'apparel' as 'apparel' | 'accessories' | 'gear',
    sizes: 'S, M, L, XL',
    stock: '',
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=600&auto=format&fit=crop',
    isSpotlight: 'false',
  });

  // Action handlers
  const handleAddEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!eventForm.title || !eventForm.city || !eventForm.price) return;

    const newEv: Event = {
      id: `ev-${Date.now()}`,
      title: eventForm.title.toUpperCase(),
      city: eventForm.city.toUpperCase(),
      venue: eventForm.venue,
      date: eventForm.date || new Date().toISOString().split('T')[0],
      time: eventForm.time,
      genres: eventForm.genres.split(',').map((g) => g.trim()),
      lineup: eventForm.lineup.split(',').map((l) => l.trim()),
      description: eventForm.description,
      price: parseFloat(eventForm.price) || 29.99,
      ticketStock: parseInt(eventForm.ticketStock) || 100,
      image: eventForm.image,
      isFeatured: eventForm.isFeatured === 'true',
      status: eventForm.status,
    };

    setEvents([newEv, ...events]);
    setEventForm({
      title: '',
      city: '',
      venue: '',
      date: '',
      time: '22:00 - 05:00',
      genres: '',
      lineup: '',
      description: '',
      price: '',
      ticketStock: '',
      image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=600&auto=format&fit=crop',
      isFeatured: 'false',
      status: 'upcoming',
    });
    alert('Event added to directory successfully!');
  };

  const handleDeleteEvent = (id: string) => {
    if (confirm('Delete this event?')) {
      setEvents(events.filter((e) => e.id !== id));
    }
  };

  const handleAddNews = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsForm.title || !newsForm.content) return;

    const newPost: NewsPost = {
      id: `news-${Date.now()}`,
      title: newsForm.title,
      excerpt: newsForm.excerpt,
      content: newsForm.content,
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }),
      category: newsForm.category,
      image: newsForm.image,
      author: newsForm.author,
    };

    setNews([newPost, ...news]);
    setNewsForm({
      title: '',
      excerpt: '',
      content: '',
      category: 'Festivals',
      image: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?q=80&w=600&auto=format&fit=crop',
      author: 'Promoter Desk',
    });
    alert('News article published successfully!');
  };

  const handleDeleteNews = (id: string) => {
    if (confirm('Delete this post?')) {
      setNews(news.filter((n) => n.id !== id));
    }
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name || !productForm.price || !productForm.stock) return;

    const newProd: Product = {
      id: `prod-${Date.now()}`,
      name: productForm.name.toUpperCase(),
      price: parseFloat(productForm.price) || 19.99,
      description: productForm.description,
      images: [productForm.image],
      sizes: productForm.sizes.split(',').map((s) => s.trim()),
      stock: parseInt(productForm.stock) || 50,
      category: productForm.category,
      isSpotlight: productForm.isSpotlight === 'true',
    };

    setProducts([newProd, ...products]);
    setProductForm({
      name: '',
      price: '',
      description: '',
      category: 'apparel',
      sizes: 'S, M, L, XL',
      stock: '',
      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?q=80&w=600&auto=format&fit=crop',
      isSpotlight: 'false',
    });
    alert('Product added to catalog!');
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('Delete this product?')) {
      setProducts(products.filter((p) => p.id !== id));
    }
  };

  return (
    <div id="admin-cms-container" className="py-8 px-4 font-sans max-w-7xl mx-auto relative z-10 text-white">
      {/* CMS Header banner */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8 border border-zinc-900 bg-black/95 p-6 rounded-lg backdrop-blur-md relative overflow-hidden">
        {/* Glow */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-neon-green/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded border border-neon-green bg-neon-green/10 flex items-center justify-center text-neon-green">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h2 className="font-display text-2xl font-black uppercase tracking-wider text-white">
              ARS PROMOTER DESK
            </h2>
            <p className="font-mono text-[10px] text-zinc-500 mt-0.5 uppercase">ADMINISTRATIVE PORTAL & CENTRAL CONTROL INVENTORY</p>
          </div>
        </div>

        {/* Stats strip */}
        <div className="grid grid-cols-3 gap-6 font-mono text-[11px] text-zinc-400">
          <div className="flex flex-col">
            <span className="text-zinc-600">SESSIONS</span>
            <span className="font-bold text-white text-sm mt-0.5">{events.length}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-zinc-600">JOURNALS</span>
            <span className="font-bold text-white text-sm mt-0.5">{news.length}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-zinc-600">STOCK LINES</span>
            <span className="font-bold text-white text-sm mt-0.5">{products.length}</span>
          </div>
        </div>
      </div>

      {/* Sub tabs */}
      <div className="flex border-b border-zinc-900 mb-6 gap-2 sm:gap-4 select-none overflow-x-auto">
        <button
          onClick={() => setActiveSubTab('events')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeSubTab === 'events' ? 'border-neon-green text-neon-green' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <Ticket className="w-4 h-4" /> MANAGING DIRECTORY
        </button>
        <button
          onClick={() => setActiveSubTab('news')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeSubTab === 'news' ? 'border-neon-green text-neon-green' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <Newspaper className="w-4 h-4" /> MANAGING EDITORIALS
        </button>
        <button
          onClick={() => setActiveSubTab('merch')}
          className={`pb-3 font-mono text-xs font-bold tracking-widest uppercase flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
            activeSubTab === 'merch' ? 'border-neon-green text-neon-green' : 'border-transparent text-zinc-500 hover:text-white'
          }`}
        >
          <ShoppingBag className="w-4 h-4" /> MANAGING STOCK
        </button>
      </div>

      {/* Panels */}
      <div>
        {activeSubTab === 'events' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left: Add Form */}
            <div className="border border-zinc-900 bg-black/80 p-5 rounded-lg h-fit space-y-4">
              <h3 className="font-display text-sm font-black text-neon-green uppercase border-b border-zinc-900 pb-2">
                ADD NEW WAREHOUSE SESSION
              </h3>

              <form onSubmit={handleAddEvent} className="space-y-3 font-mono text-xs text-zinc-300">
                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">EVENT TITLE</label>
                  <input
                    required
                    type="text"
                    value={eventForm.title}
                    onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                    placeholder="e.g. SUB SONIC WAREHOUSE"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">CITY / STATE</label>
                    <input
                      required
                      type="text"
                      value={eventForm.city}
                      onChange={(e) => setEventForm({ ...eventForm, city: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                      placeholder="e.g. DETROIT, MI"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">VENUE NAME</label>
                    <input
                      required
                      type="text"
                      value={eventForm.venue}
                      onChange={(e) => setEventForm({ ...eventForm, venue: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                      placeholder="e.g. Packard Plant"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">DATE (YYYY-MM-DD)</label>
                    <input
                      required
                      type="date"
                      value={eventForm.date}
                      onChange={(e) => setEventForm({ ...eventForm, date: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">HOURS</label>
                    <input
                      type="text"
                      value={eventForm.time}
                      onChange={(e) => setEventForm({ ...eventForm, time: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">GENRES (comma separated)</label>
                  <input
                    type="text"
                    value={eventForm.genres}
                    onChange={(e) => setEventForm({ ...eventForm, genres: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                    placeholder="e.g. Techno, Acid, Industrial"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">ARTIST LINEUP (comma separated)</label>
                  <input
                    type="text"
                    value={eventForm.lineup}
                    onChange={(e) => setEventForm({ ...eventForm, lineup: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                    placeholder="e.g. EProm, GJones"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">TICKET PRICE ($)</label>
                    <input
                      required
                      type="number"
                      step="0.01"
                      value={eventForm.price}
                      onChange={(e) => setEventForm({ ...eventForm, price: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                      placeholder="45.00"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">STOCK CAPACITY</label>
                    <input
                      required
                      type="number"
                      value={eventForm.ticketStock}
                      onChange={(e) => setEventForm({ ...eventForm, ticketStock: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green"
                      placeholder="400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">STATUS</label>
                  <select
                    value={eventForm.status}
                    onChange={(e) => setEventForm({ ...eventForm, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-zinc-300 focus:outline-none focus:border-neon-green"
                  >
                    <option value="upcoming">UPCOMING</option>
                    <option value="live">LIVE NOW</option>
                    <option value="sold_out">SOLD OUT</option>
                    <option value="cancelled">CANCELLED</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">IMAGE URL</label>
                  <input
                    type="text"
                    value={eventForm.image}
                    onChange={(e) => setEventForm({ ...eventForm, image: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full font-display text-[11px] font-black tracking-widest text-black bg-neon-green rounded py-2.5 cursor-pointer hover:bg-black hover:text-neon-green border border-neon-green transition-all mt-4"
                >
                  ADD EVENT TO CATALOG
                </button>
              </form>
            </div>

            {/* Right: Lists */}
            <div className="lg:col-span-2 space-y-4">
              <h3 className="font-display text-sm font-black uppercase text-zinc-400">
                ACTIVE SESSIONS IN REGISTRY ({events.length})
              </h3>

              <div className="space-y-2">
                {events.map((ev) => (
                  <div
                    key={ev.id}
                    className="flex items-center justify-between gap-4 p-4 border border-zinc-900 bg-zinc-950 rounded"
                  >
                    <div>
                      <h4 className="font-mono text-xs font-bold text-white uppercase tracking-wide">
                        {ev.title}
                      </h4>
                      <p className="font-mono text-[10px] text-zinc-500 mt-1 uppercase">
                        {ev.venue} • {ev.city} • ${ev.price} • STOCK: {ev.ticketStock}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeleteEvent(ev.id)}
                      className="p-2 text-zinc-600 hover:text-neon-pink cursor-pointer transition-colors"
                      title="Delete event"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'news' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Form */}
            <div className="border border-zinc-900 bg-black/80 p-5 rounded-lg h-fit space-y-4">
              <h3 className="font-display text-sm font-black text-neon-green uppercase border-b border-zinc-900 pb-2">
                PUBLISH EDITORIAL TRANSMISSION
              </h3>

              <form onSubmit={handleAddNews} className="space-y-3 font-mono text-xs text-zinc-300">
                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">STORY TITLE</label>
                  <input
                    required
                    type="text"
                    value={newsForm.title}
                    onChange={(e) => setNewsForm({ ...newsForm, title: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none"
                    placeholder="e.g. WAREHOUSE DEEDS"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">CATEGORY</label>
                  <input
                    required
                    type="text"
                    value={newsForm.category}
                    onChange={(e) => setNewsForm({ ...newsForm, category: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">SHORT EXCERPT</label>
                  <input
                    required
                    type="text"
                    value={newsForm.excerpt}
                    onChange={(e) => setNewsForm({ ...newsForm, excerpt: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">FULL ARTICLE CONTENT</label>
                  <textarea
                    required
                    rows={6}
                    value={newsForm.content}
                    onChange={(e) => setNewsForm({ ...newsForm, content: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none focus:border-neon-green resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full font-display text-[11px] font-black tracking-widest text-black bg-neon-green rounded py-2.5 cursor-pointer hover:bg-black hover:text-neon-green border border-neon-green transition-all"
                >
                  PUBLISH ARTICLE
                </button>
              </form>
            </div>

            {/* List */}
            <div className="lg:col-span-2 space-y-4">
              <h3 className="font-display text-sm font-black uppercase text-zinc-400">
                ACTIVE EDITORIALS ({news.length})
              </h3>
              <div className="space-y-2">
                {news.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between gap-4 p-4 border border-zinc-900 bg-zinc-950 rounded"
                  >
                    <div>
                      <h4 className="font-mono text-xs font-bold text-white uppercase tracking-wide">
                        {item.title}
                      </h4>
                      <p className="font-mono text-[10px] text-zinc-500 mt-1 uppercase">
                        CATEGORY: {item.category} • {item.date} • BY {item.author.toUpperCase()}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeleteNews(item.id)}
                      className="p-2 text-zinc-600 hover:text-neon-pink cursor-pointer transition-colors"
                      title="Delete story"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'merch' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Form */}
            <div className="border border-zinc-900 bg-black/80 p-5 rounded-lg h-fit space-y-4">
              <h3 className="font-display text-sm font-black text-neon-green uppercase border-b border-zinc-900 pb-2">
                ADD MERCHANDISE STOCK LINE
              </h3>

              <form onSubmit={handleAddProduct} className="space-y-3 font-mono text-xs text-zinc-300">
                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">PRODUCT NAME</label>
                  <input
                    required
                    type="text"
                    value={productForm.name}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white"
                    placeholder="e.g. GID SWEATSHIRT"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">CATEGORY</label>
                    <select
                      value={productForm.category}
                      onChange={(e) => setProductForm({ ...productForm, category: e.target.value as any })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-zinc-300 focus:outline-none"
                    >
                      <option value="apparel">APPAREL</option>
                      <option value="accessories">ACCESSORIES</option>
                      <option value="gear">GEAR</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">SIZES AVAILABLE</label>
                    <input
                      type="text"
                      value={productForm.sizes}
                      onChange={(e) => setProductForm({ ...productForm, sizes: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white"
                      placeholder="e.g. S, M, L, XL"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">PRICE ($)</label>
                    <input
                      required
                      type="number"
                      step="0.01"
                      value={productForm.price}
                      onChange={(e) => setProductForm({ ...productForm, price: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">INITIAL STOCK</label>
                    <input
                      required
                      type="number"
                      value={productForm.stock}
                      onChange={(e) => setProductForm({ ...productForm, stock: e.target.value })}
                      className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">SPOTLIGHT PRODUCT</label>
                  <select
                    value={productForm.isSpotlight}
                    onChange={(e) => setProductForm({ ...productForm, isSpotlight: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-zinc-300"
                  >
                    <option value="false">NO</option>
                    <option value="true">YES (HIGHLIGHTS ON HOME)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">IMAGE URL</label>
                  <input
                    type="text"
                    value={productForm.image}
                    onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] text-zinc-500 mb-1 uppercase font-bold">DESCRIPTION</label>
                  <textarea
                    rows={3}
                    value={productForm.description}
                    onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 text-xs rounded text-white resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full font-display text-[11px] font-black tracking-widest text-black bg-neon-green rounded py-2.5 cursor-pointer hover:bg-black hover:text-neon-green border border-neon-green transition-all"
                >
                  ADD PRODUCT TO CATALOG
                </button>
              </form>
            </div>

            {/* List */}
            <div className="lg:col-span-2 space-y-4">
              <h3 className="font-display text-sm font-black uppercase text-zinc-400">
                ACTIVE STOCK LINES ({products.length})
              </h3>
              <div className="space-y-2">
                {products.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center justify-between gap-4 p-4 border border-zinc-900 bg-zinc-950 rounded"
                  >
                    <div>
                      <h4 className="font-mono text-xs font-bold text-white uppercase tracking-wide">
                        {p.name}
                      </h4>
                      <p className="font-mono text-[10px] text-zinc-500 mt-1 uppercase">
                        CATEGORY: {p.category} • PRICE: ${p.price} • STOCK: {p.stock}
                      </p>
                    </div>

                    <button
                      onClick={() => handleDeleteProduct(p.id)}
                      className="p-2 text-zinc-600 hover:text-neon-pink cursor-pointer transition-colors"
                      title="Delete product"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
