import { Heart, Globe, Star, Smile, Flame, Crown } from 'lucide-react';

interface FooterProps {
  setActiveTab: (tab: string) => void;
}

export default function Footer({ setActiveTab }: FooterProps) {
  const currentYear = new Date().getFullYear();

  return (
    <footer id="footer-container" className="border-t border-zinc-900 bg-black/95 text-zinc-400 py-12 px-6 select-none relative z-10 font-sans">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 lg:gap-10 pb-10 border-b border-zinc-900">
          
          {/* Logo & Manifesto Column */}
          <div className="lg:col-span-1 flex flex-col gap-4">
            <div className="flex items-center gap-2 cursor-pointer group" onClick={() => setActiveTab('home')}>
              <div className="relative flex h-8 w-8 items-center justify-center">
                <div className="absolute inset-0 rounded bg-neon-pink/10 border border-neon-pink/40 blur-[2px]" />
                <span className="font-display font-black text-xs text-neon-pink">A</span>
              </div>
              <span className="font-display font-black tracking-widest text-white text-sm">AMERICAN RAVE SCENE</span>
            </div>
            <p className="text-xs text-zinc-500 leading-relaxed max-w-xs">
              The pulse of the underground. The voice of a movement. From coast to coast, we gather under lasers to share energy. One scene. Infinite unity.
            </p>
            <p className="font-mono text-[9px] text-zinc-600 tracking-wider">
              EST. 2012 / DIGITAL HOME OF PLUR
            </p>
          </div>

          {/* Navigation Column */}
          <div className="flex flex-col gap-3 text-xs">
            <h4 className="font-display text-white font-bold tracking-widest uppercase text-[11px] text-neon-pink">NAVIGATE</h4>
            <ul className="flex flex-col gap-2 font-medium">
              <li><button onClick={() => setActiveTab('home')} className="hover:text-white transition-colors cursor-pointer text-left">Home</button></li>
              <li><button onClick={() => setActiveTab('events')} className="hover:text-white transition-colors cursor-pointer text-left">Events Directory</button></li>
              <li><button onClick={() => setActiveTab('news')} className="hover:text-white transition-colors cursor-pointer text-left">News & Blog</button></li>
              <li><button onClick={() => setActiveTab('merch')} className="hover:text-white transition-colors cursor-pointer text-left">Official Merch</button></li>
              <li><button onClick={() => setActiveTab('about')} className="hover:text-white transition-colors cursor-pointer text-left">About Us</button></li>
            </ul>
          </div>

          {/* Info Column */}
          <div className="flex flex-col gap-3 text-xs">
            <h4 className="font-display text-white font-bold tracking-widest uppercase text-[11px] text-neon-orange">INFO</h4>
            <ul className="flex flex-col gap-2 font-medium">
              <li><a href="#faq" className="hover:text-white transition-colors text-left">FAQ</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors text-left">Contact Us</a></li>
              <li><a href="#press" className="hover:text-white transition-colors text-left">Press Kit</a></li>
              <li><a href="#partners" className="hover:text-white transition-colors text-left">Brand Partners</a></li>
              <li><a href="#privacy" className="hover:text-white transition-colors text-left">Privacy Policy</a></li>
              <li><a href="#terms" className="hover:text-white transition-colors text-left">Terms of Service</a></li>
            </ul>
          </div>

          {/* Support Column */}
          <div className="flex flex-col gap-3 text-xs">
            <h4 className="font-display text-white font-bold tracking-widest uppercase text-[11px] text-neon-green">SUPPORT</h4>
            <ul className="flex flex-col gap-2 font-medium">
              <li><a href="#help" className="hover:text-white transition-colors text-left">Help Center</a></li>
              <li><a href="#shipping" className="hover:text-white transition-colors text-left">Shipping Info</a></li>
              <li><a href="#returns" className="hover:text-white transition-colors text-left">Returns & Exchanges</a></li>
              <li><a href="#accessibility" className="hover:text-white transition-colors text-left">Accessibility</a></li>
            </ul>
          </div>

          {/* JOIN THE MOVEMENT Column - Glow sketch style */}
          <div className="flex flex-col gap-4">
            <h4 className="font-display text-white font-bold tracking-widest uppercase text-[11px] text-neon-violet">JOIN THE MOVEMENT</h4>
            <div className="grid grid-cols-4 gap-2.5 max-w-[180px]">
              {/* Stars, smiley, heart, globe inline icons with neon colors and custom glow classes */}
              <div className="flex h-10 w-10 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-pink hover:text-neon-pink hover:shadow-[0_0_10px_rgba(255,0,127,0.4)] transition-all duration-300 cursor-pointer text-zinc-600" title="Rave Unity">
                <Smile className="w-5 h-5" />
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-green hover:text-neon-green hover:shadow-[0_0_10px_#39ff1488] transition-all duration-300 cursor-pointer text-zinc-600" title="Star Kid">
                <Star className="w-5 h-5" />
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-blue hover:text-neon-blue hover:shadow-[0_0_10px_rgba(0,240,255,0.4)] transition-all duration-300 cursor-pointer text-zinc-600" title="Global Beats">
                <Globe className="w-5 h-5" />
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-pink hover:text-neon-pink hover:shadow-[0_0_10px_rgba(255,0,127,0.4)] transition-all duration-300 cursor-pointer text-zinc-600" title="PLUR Heart">
                <Heart className="w-5 h-5" />
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-orange hover:text-neon-orange hover:shadow-[0_0_10px_rgba(255,103,0,0.4)] transition-all duration-300 cursor-pointer text-zinc-600" title="On Fire">
                <Flame className="w-5 h-5" />
              </div>
              <div className="flex h-10 w-10 items-center justify-center rounded border border-zinc-800 bg-black hover:border-neon-violet hover:text-neon-violet hover:shadow-[0_0_10px_rgba(157,0,255,0.4)] transition-all duration-300 cursor-pointer text-zinc-600" title="Rave Royalty">
                <Crown className="w-5 h-5" />
              </div>
            </div>
            <p className="text-[10px] text-zinc-500 italic leading-snug">
              Unlock VIP access, line-up leaks, and priority pre-sale ticket drops.
            </p>
          </div>

        </div>

        {/* Bottom Sub-footer */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col gap-1 text-center md:text-left">
            <span className="text-[11px] text-zinc-600 font-mono">
              &copy; {currentYear} American Rave Scene. All Rights Reserved.
            </span>
            <span className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest">
              UNITED BY MUSIC. DRIVEN BY FREEDOM.
            </span>
          </div>

          {/* Secure Payment Badges & US Flag info */}
          <div className="flex flex-col items-center md:items-end gap-2 shrink-0">
            <div className="flex items-center gap-2">
              {/* Payment Methods mock images styled nicely */}
              <span className="px-1.5 py-0.5 rounded border border-zinc-800 bg-black font-mono text-[9px] font-bold text-zinc-400 tracking-wider">VISA</span>
              <span className="px-1.5 py-0.5 rounded border border-zinc-800 bg-black font-mono text-[9px] font-bold text-zinc-400 tracking-wider">MC</span>
              <span className="px-1.5 py-0.5 rounded border border-zinc-800 bg-black font-mono text-[9px] font-bold text-zinc-400 tracking-wider">AMEX</span>
              <span className="px-1.5 py-0.5 rounded border border-zinc-800 bg-black font-mono text-[9px] font-bold text-zinc-400 tracking-wider"> PAY</span>
              <span className="px-1.5 py-0.5 rounded border border-zinc-800 bg-black font-mono text-[9px] font-bold text-zinc-400 tracking-wider">G PAY</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono text-[10px] text-zinc-600">
              <span>Built for the scene. Made in the USA.</span>
              <span className="inline-block w-4 h-2.5 bg-gradient-to-r from-blue-900 via-white to-red-600 relative overflow-hidden rounded-xs" title="USA">
                <span className="absolute top-0 left-0 w-1.5 h-1.5 bg-blue-900 text-[3px] text-white flex items-start justify-start leading-[2px]">*</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
