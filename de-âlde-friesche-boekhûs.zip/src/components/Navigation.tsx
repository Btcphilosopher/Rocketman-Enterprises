import React, { useState, useEffect } from 'react';
import { Search, ShoppingBag, Heart, User, Volume2, VolumeX, Menu, X, BookOpen, Compass } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const Navigation: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const {
    cartCount,
    wishlist,
    setIsCartOpen,
    setIsWishlistOpen,
    setIsAccountOpen,
    setIsSearchOpen,
    ambientSoundPlaying,
    toggleAmbientSound,
  } = useShop();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const elem = document.getElementById(id);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 ${
        isScrolled
          ? 'bg-[#102218]/95 backdrop-blur-md border-b border-[#C5A059]/20 py-3 shadow-2xl'
          : 'bg-gradient-to-b from-[#102218]/95 via-[#102218]/70 to-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          
          {/* Logo - Left */}
          <a
            href="#"
            className="flex items-center gap-3 group focus:outline-none"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          >
            <div className="w-9 h-9 rounded-full bg-[#0D1A12] border border-[#C5A059]/40 flex items-center justify-center text-[#C5A059] group-hover:border-[#C5A059] transition-colors shadow-inner">
              <span className="font-blackletter text-xl">ᚠ</span>
            </div>
            <div>
              <span className="font-cinzel text-xs font-bold tracking-[0.25em] text-[#C5A059] group-hover:text-[#D4B478] transition-colors block leading-tight uppercase">
                De Âlde Friesche Boekhûs
              </span>
              <span className="font-sans text-[9px] tracking-[0.2em] uppercase text-[#F5F2ED]/50 block">
                Bremen & Hanse • Anno 1642
              </span>
            </div>
          </a>

          {/* Desktop Navigation - Center Links */}
          <nav className="hidden lg:flex items-center gap-6 font-sans text-[10px] tracking-[0.2em] uppercase font-semibold text-[#F5F2ED]/70">
            <button
              onClick={() => scrollToSection('top')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Thús
            </button>
            <button
              onClick={() => scrollToSection('kolleksje')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Boeken
            </button>
            <button
              onClick={() => scrollToSection('nije-oankomsten')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Nije Oankomsten
            </button>
            <button
              onClick={() => scrollToSection('seldsume-edysjes')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Seldsume Edysjes
            </button>
            <button
              onClick={() => scrollToSection('lêskeamer')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Lêskeamer
            </button>
            <button
              onClick={() => scrollToSection('kafee')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Kafee
            </button>
            <button
              onClick={() => scrollToSection('eveneminten')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Eveneminten
            </button>
            <button
              onClick={() => scrollToSection('erfskip')}
              className="hover:text-[#C5A059] transition-colors hover-gold-underline py-1"
            >
              Taal
            </button>
          </nav>

          {/* Action Icons - Right */}
          <div className="flex items-center gap-3 text-[#C5A059]">
            
            {/* Ambient sound toggle */}
            <button
              onClick={toggleAmbientSound}
              title={ambientSoundPlaying ? 'Lêskeamer sfearlûden út' : 'Lêskeamer sfearlûden oan (Kears & Hout)'}
              className={`p-2 rounded-full border transition-all ${
                ambientSoundPlaying
                  ? 'bg-[#1c3225] border-[#C5A059] text-[#C5A059] shadow-[0_0_10px_rgba(197,160,89,0.3)]'
                  : 'bg-[#0D1A12] border-[#C5A059]/30 text-[#F5F2ED]/80 hover:border-[#C5A059] hover:text-[#C5A059]'
              }`}
            >
              {ambientSoundPlaying ? <Volume2 className="w-4 h-4 animate-pulse" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Search */}
            <button
              onClick={() => setIsSearchOpen(true)}
              className="p-2 text-[#F5F2ED]/80 hover:text-[#C5A059] transition-colors focus:outline-none"
              title="Sykje yn Boeken (Search)"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Wishlist */}
            <button
              onClick={() => setIsWishlistOpen(true)}
              className="p-2 text-[#F5F2ED]/80 hover:text-[#C5A059] transition-colors relative focus:outline-none"
              title="Bewarre Boeken (Wishlist)"
            >
              <Heart className="w-4 h-4" />
              {wishlist.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#C5A059] text-[#102218] font-sans text-[9px] font-bold rounded-full flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </button>

            {/* User Account */}
            <button
              onClick={() => setIsAccountOpen(true)}
              className="p-2 text-[#F5F2ED]/80 hover:text-[#C5A059] transition-colors focus:outline-none"
              title="Mijn Account & Bestellingen"
            >
              <User className="w-4 h-4" />
            </button>

            {/* Cart Basket */}
            <button
              onClick={() => setIsCartOpen(true)}
              className="flex items-center gap-2 px-3 py-1.5 rounded bg-[#0D1A12] border border-[#C5A059]/40 hover:border-[#C5A059] text-[#F5F2ED] transition-all group focus:outline-none"
              title="Winkelkoer (Shopping Basket)"
            >
              <ShoppingBag className="w-4 h-4 text-[#C5A059] group-hover:scale-110 transition-transform" />
              <span className="font-sans text-xs font-bold text-[#C5A059]">({cartCount})</span>
            </button>

            {/* Mobile menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-[#F5F2ED] hover:text-[#C5A059] focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#09100c]/98 border-b border-[#c8aa6e]/30 px-6 py-6 font-cinzel text-sm space-y-4 shadow-2xl animate-fadeIn">
          <button
            onClick={() => scrollToSection('top')}
            className="block w-full text-left py-2 text-[#f4efe6] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            Thús (Home)
          </button>
          <button
            onClick={() => scrollToSection('kolleksje')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            Boeken & Kolleksjes
          </button>
          <button
            onClick={() => scrollToSection('nije-oankomsten')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            Nije Oankomsten
          </button>
          <button
            onClick={() => scrollToSection('seldsume-edysjes')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            Seldsume Edysjes
          </button>
          <button
            onClick={() => scrollToSection('lêskeamer')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            Lêskeamer (Reading Room)
          </button>
          <button
            onClick={() => scrollToSection('kafee')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            It Friesch Koffy- & Teehûs
          </button>
          <button
            onClick={() => scrollToSection('eveneminten')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e] border-b border-[#1c3225]"
          >
            Eveneminten (Events)
          </button>
          <button
            onClick={() => scrollToSection('erfskip')}
            className="block w-full text-left py-2 text-[#e8dfce] hover:text-[#c8aa6e]"
          >
            Frisian Taal & Skiednis
          </button>
        </div>
      )}
    </header>
  );
};
