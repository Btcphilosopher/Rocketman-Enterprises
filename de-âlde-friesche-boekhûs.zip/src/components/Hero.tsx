import React from 'react';
import { ArrowRight, BookOpen, Compass, ShieldCheck } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const Hero: React.FC = () => {
  const { setSelectedCategory } = useShop();

  const scrollToSection = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="top" className="relative min-h-[90vh] pt-28 pb-20 flex items-center bg-[#102218] overflow-hidden border-b border-[#C5A059]/20">
      
      {/* Background ambient warm gold glow */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-[#C5A059]/5 rounded-full blur-3xl pointer-events-none candle-glow" />
      <div className="absolute bottom-10 right-1/3 w-80 h-80 bg-[#0D1A12]/80 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column - Typography & Philosophy */}
          <div className="lg:col-span-6 space-y-6 pr-0 lg:pr-6">
            
            {/* Top eyebrow */}
            <span className="text-[#C5A059] text-[10px] uppercase tracking-[0.4em] font-sans font-bold block">
              Sûnt 1642 • Hanseatyk Erfskip
            </span>

            {/* Main Editorial Headline */}
            <h1 className="font-serif text-5xl sm:text-6xl lg:text-7xl leading-[1.08] font-light italic tracking-tight text-[#F5F2ED]">
              Wolkom yn De Âlde <br />
              <span className="not-italic font-blackletter text-[#C5A059]">Friesche Boekhûs</span>
            </h1>

            {/* Subheading */}
            <p className="font-serif-cormorant text-2xl sm:text-3xl italic text-[#C5A059]/90 font-light">
              “Boeken fan Wysheit, Skiednis en Siel.”
            </p>

            {/* Philosophy Paragraph */}
            <p className="font-serif text-[#F5F2ED]/60 text-base sm:text-lg leading-relaxed font-light max-w-xl">
              A sanctuary for the printed word, where Hanseatic tradition meets modern scholarship. Yn ús boekhûs fine jo wurden dy’t tiden oerstizje, ferhalen dy’t de wrâld foarmje, en kennis dy’t de siel ferljochtet.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-5 pt-4">
              <button
                onClick={() => scrollToSection('kolleksje')}
                className="px-8 py-4 bg-[#C5A059] text-[#102218] text-xs font-sans font-bold uppercase tracking-widest hover:bg-[#D4B478] transition-all shadow-[0_4px_20px_rgba(197,160,89,0.25)] flex items-center gap-3"
              >
                <span>Ûs Kolleksje</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => scrollToSection('erfskip')}
                className="px-8 py-4 border border-[#C5A059]/40 text-[#C5A059] text-xs font-sans font-bold uppercase tracking-widest hover:bg-[#C5A059]/10 transition-all"
              >
                <span>Us Ferhaal</span>
              </button>
            </div>

            {/* Key assurances grid */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-[#C5A059]/15 text-xs text-[#F5F2ED]/70 font-sans">
              <div>
                <span className="block text-[#C5A059] font-bold text-sm">1642</span>
                <span className="text-[10px] tracking-[0.2em] uppercase text-[#F5F2ED]/50">Hanseatyk Netwurk</span>
              </div>
              <div>
                <span className="block text-[#C5A059] font-bold text-sm">100%</span>
                <span className="text-[10px] tracking-[0.2em] uppercase text-[#F5F2ED]/50">Klassyk Hânskrift</span>
              </div>
              <div>
                <span className="block text-[#C5A059] font-bold text-sm">Seldsum</span>
                <span className="text-[10px] tracking-[0.2em] uppercase text-[#F5F2ED]/50">Bremensk Argyf</span>
              </div>
            </div>

          </div>

          {/* Right Column - Atmospheric Editorial Illustration / Image */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-sm overflow-hidden border border-[#C5A059]/30 bg-[#08120C] shadow-[0_20px_50px_rgba(0,0,0,0.8)] group">
              <img
                src="https://images.unsplash.com/photo-1507842229565-8a496b46187f?auto=format&fit=crop&w=1200&q=80"
                alt="De Âlde Friesche Boekhûs Interior"
                className="w-full h-[520px] sm:h-[600px] object-cover filter brightness-[0.85] contrast-[1.1] group-hover:scale-105 transition-transform duration-1000"
              />
              
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#102218] via-transparent to-transparent opacity-80" />

              {/* Floating illuminated manuscript quote card */}
              <div className="absolute bottom-6 left-6 right-6 p-6 rounded-sm bg-[#0D1A12]/90 backdrop-blur-md border border-[#C5A059]/40 shadow-2xl">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-full bg-[#102218] border border-[#C5A059]/50 flex items-center justify-center text-[#C5A059] shrink-0 mt-0.5">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-serif-cormorant text-xl italic text-[#F5F2ED] leading-snug">
                      “Lêze is reizgje sûnder fuort te gean.”
                    </p>
                    <p className="font-sans text-[10px] text-[#C5A059] tracking-[0.2em] uppercase mt-1">
                      — Âldfryske Utspraak fan de Lêskeamer
                    </p>
                  </div>
                </div>
              </div>

              {/* Corner framing lines matching the design pattern */}
              <div className="absolute top-4 left-4 w-10 h-10 border-t-2 border-l-2 border-[#C5A059]/60 pointer-events-none" />
              <div className="absolute top-4 right-4 w-10 h-10 border-t-2 border-r-2 border-[#C5A059]/60 pointer-events-none" />
              <div className="absolute bottom-4 left-4 w-10 h-10 border-b-2 border-l-2 border-[#C5A059]/60 pointer-events-none" />
              <div className="absolute bottom-4 right-4 w-10 h-10 border-b-2 border-r-2 border-[#C5A059]/60 pointer-events-none" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
