import React from 'react';
import { X, User, ShieldCheck, Package, BookMarked, Award } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const AccountModal: React.FC = () => {
  const { isAccountOpen, setIsAccountOpen, userOrders } = useShop();

  if (!isAccountOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#09100c]/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#102218] border border-[#c8aa6e]/50 rounded-sm max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl text-[#f4efe6] space-y-6 max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={() => setIsAccountOpen(false)}
          className="absolute top-4 right-4 p-2 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
        >
          <X className="w-6 h-6" />
        </button>

        {/* User Header */}
        <div className="flex items-center gap-4 border-b border-[#c8aa6e]/20 pb-6">
          <div className="w-14 h-14 rounded-full bg-[#1c3225] border-2 border-[#c8aa6e] text-[#c8aa6e] flex items-center justify-center font-blackletter text-2xl shadow-xl">
            ᚠ
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-blackletter text-2xl text-[#f4efe6]">
                Jan de Hanse
              </h2>
              <span className="px-2 py-0.5 rounded bg-[#c8aa6e] text-[#09100c] font-cinzel text-[9px] uppercase font-bold tracking-widest">
                Boekhûs Freon
              </span>
            </div>
            <p className="font-serif-cormorant text-sm italic text-[#c8aa6e]">
              Lid sûnt 2024 • Bremen & Hanse-Syndikaat
            </p>
          </div>
        </div>

        {/* Member assurances bar */}
        <div className="grid grid-cols-3 gap-3 text-center text-xs font-cinzel bg-[#09100c] p-3 rounded border border-[#c8aa6e]/20 text-[#c8aa6e]">
          <div>
            <span className="block text-[#f4efe6] font-bold">12</span>
            <span>Boeken Gelezen</span>
          </div>
          <div>
            <span className="block text-[#f4efe6] font-bold">{userOrders.length}</span>
            <span>Bestellingen</span>
          </div>
          <div>
            <span className="block text-[#f4efe6] font-bold">Goud</span>
            <span>Lêskeamer Rang</span>
          </div>
        </div>

        {/* Order History */}
        <div className="space-y-4">
          <h3 className="font-cinzel text-xs font-bold uppercase tracking-wider text-[#c8aa6e] flex items-center gap-2">
            <Package className="w-4 h-4" />
            <span>Bestel-Histoarje & Track & Trace</span>
          </h3>

          <div className="space-y-3">
            {userOrders.map((order) => (
              <div
                key={order.orderId}
                className="bg-[#09100c] border border-[#c8aa6e]/20 rounded p-4 space-y-3 text-xs"
              >
                <div className="flex justify-between items-center text-[#c8aa6e] font-cinzel">
                  <span className="font-bold">{order.orderId}</span>
                  <span className="px-2 py-0.5 bg-[#1c3225] rounded text-[#f4efe6] font-semibold">
                    {order.status}
                  </span>
                </div>

                <div className="text-[#bfae93] space-y-1">
                  <div className="flex justify-between">
                    <span>Datum:</span>
                    <span>{order.date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Track & Trace Kode:</span>
                    <span className="text-[#c8aa6e] font-mono">{order.trackingNumber}</span>
                  </div>
                  <div className="flex justify-between font-bold text-[#f4efe6] pt-1 border-t border-[#c8aa6e]/10">
                    <span>Totaal:</span>
                    <span className="text-[#c8aa6e]">€{order.total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={() => setIsAccountOpen(false)}
          className="w-full py-3 bg-[#102218] border border-[#c8aa6e]/40 text-[#f4efe6] font-cinzel text-xs uppercase font-bold rounded-sm"
        >
          Slút Account
        </button>

      </div>
    </div>
  );
};
