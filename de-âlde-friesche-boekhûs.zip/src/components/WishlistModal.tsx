import React from 'react';
import { X, Heart, Trash2, ShoppingBag } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const WishlistModal: React.FC = () => {
  const { wishlist, isWishlistOpen, setIsWishlistOpen, toggleWishlist, addToCart } = useShop();

  if (!isWishlistOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-[#09100c]/80 backdrop-blur-sm flex justify-end animate-fadeIn">
      <div className="bg-[#09100c] border-l border-[#c8aa6e]/30 w-full max-w-md h-full flex flex-col justify-between p-6 shadow-2xl relative text-[#f4efe6]">
        
        <div className="flex justify-between items-center border-b border-[#c8aa6e]/20 pb-4">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#c8aa6e] fill-current" />
            <h2 className="font-blackletter text-2xl text-[#f4efe6]">
              Bewarre Boeken
            </h2>
          </div>
          <button
            onClick={() => setIsWishlistOpen(false)}
            className="p-1.5 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-grow overflow-y-auto py-4 space-y-4 pr-1">
          {wishlist.length === 0 ? (
            <div className="text-center py-16 space-y-3 text-[#bfae93]">
              <Heart className="w-12 h-12 text-[#c8aa6e] mx-auto opacity-40" />
              <p className="font-serif-cormorant text-lg italic">
                Jo hawwe noch gjin boeken bewarre yn jo verlanglijst.
              </p>
            </div>
          ) : (
            wishlist.map((item) => (
              <div
                key={item.book.id}
                className="bg-[#102218] border border-[#c8aa6e]/20 rounded-sm p-4 flex gap-4 items-center justify-between"
              >
                <img
                  src={item.book.coverImage}
                  alt={item.book.titleOldFrisian}
                  className="w-14 h-18 object-cover rounded-sm border border-[#c8aa6e]/30 shrink-0"
                />

                <div className="flex-grow space-y-1 text-xs">
                  <h4 className="font-blackletter text-base text-[#f4efe6] line-clamp-1">
                    {item.book.titleOldFrisian}
                  </h4>
                  <p className="font-serif-cormorant italic text-[#c8aa6e]">
                    €{item.book.price.toFixed(2)}
                  </p>
                  <span className="text-[10px] text-[#bfae93]/60 block font-cinzel">
                    Bewarre op: {item.addedAt}
                  </span>
                </div>

                <div className="flex flex-col gap-2">
                  <button
                    onClick={() => {
                      addToCart(item.book);
                      toggleWishlist(item.book);
                    }}
                    className="p-2 bg-[#c8aa6e] text-[#09100c] rounded hover:bg-[#e6ce8a] transition-colors"
                    title="Ferhûzje nei Koer"
                  >
                    <ShoppingBag className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => toggleWishlist(item.book)}
                    className="p-2 text-[#e8dfce]/60 hover:text-red-400 transition-colors"
                    title="Ferwiderje"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="border-t border-[#c8aa6e]/20 pt-4">
          <button
            onClick={() => setIsWishlistOpen(false)}
            className="w-full py-3 rounded-sm bg-[#102218] border border-[#c8aa6e]/40 text-[#c8aa6e] font-cinzel text-xs uppercase font-bold"
          >
            Trochgean mei Blêdzjen
          </button>
        </div>

      </div>
    </div>
  );
};
