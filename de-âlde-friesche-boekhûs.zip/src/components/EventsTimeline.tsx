import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, Ticket, Check, X } from 'lucide-react';
import { EVENTS } from '../data/events';
import { EventItem } from '../types';
import { useShop } from '../context/ShopContext';

export const EventsTimeline: React.FC = () => {
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);
  const [ticketCount, setTicketCount] = useState<number>(1);
  const [bookedSuccess, setBookedSuccess] = useState<string | null>(null);
  const { showToast } = useShop();

  const handleBookTickets = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEvent) return;
    const ticketCode = `AFB-TICKET-${Math.floor(10000 + Math.random() * 90000)}`;
    setBookedSuccess(ticketCode);
    showToast(`Tickets foar "${selectedEvent.titleOldFrisian}" resergearre! Kode: ${ticketCode}`);
  };

  return (
    <section id="eveneminten" className="py-24 bg-[#0b140f] text-[#f4efe6] relative">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#102218] border border-[#c8aa6e]/30 text-[#c8aa6e]">
            <Calendar className="w-4 h-4" />
            <span className="font-cinzel text-xs tracking-widest uppercase font-semibold">
              Kulturele Moetingen
            </span>
          </div>
          <h2 className="font-blackletter text-4xl sm:text-5xl text-[#f4efe6]">
            Nijs & Eveneminten
          </h2>
          <p className="font-serif-cormorant text-xl text-[#bfae93] italic">
            Boekpresintaasjes, poëzij-jûnen, taal-syndikaten en skiednis-lesings by kearsljocht.
          </p>
        </div>

        {/* Timeline Grid */}
        <div className="space-y-8 relative before:absolute before:inset-0 before:left-1/2 before:-translate-x-1/2 before:w-0.5 before:bg-[#c8aa6e]/30 hidden md:block">
          {EVENTS.map((evt, idx) => {
            const isEven = idx % 2 === 0;

            return (
              <div
                key={evt.id}
                className={`flex items-center justify-between w-full ${
                  isEven ? 'flex-row-reverse' : ''
                }`}
              >
                {/* Empty side for layout balance */}
                <div className="w-5/12" />

                {/* Timeline Center Emblem */}
                <div className="z-10 w-10 h-10 rounded-full bg-[#102218] border-2 border-[#c8aa6e] text-[#c8aa6e] flex items-center justify-center font-blackletter text-lg shadow-xl">
                  ᛭
                </div>

                {/* Card Content */}
                <div className="w-5/12 bg-[#102218] border border-[#c8aa6e]/30 hover:border-[#c8aa6e] rounded-sm p-6 shadow-2xl transition-all duration-300 space-y-4 group">
                  <div className="relative aspect-[16/9] rounded-sm overflow-hidden bg-[#09100c]">
                    <img
                      src={evt.image}
                      alt={evt.titleOldFrisian}
                      className="w-full h-full object-cover filter brightness-90 group-hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-3 left-3 px-3 py-1 rounded bg-[#c8aa6e] text-[#09100c] font-cinzel text-[10px] uppercase font-bold tracking-widest">
                      {evt.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-cinzel text-[#c8aa6e]">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5" />
                      {evt.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      {evt.time}
                    </span>
                  </div>

                  <h3 className="font-blackletter text-2xl text-[#f4efe6] group-hover:text-[#c8aa6e] transition-colors">
                    {evt.titleOldFrisian}
                  </h3>

                  <p className="font-serif-cormorant text-sm italic text-[#c8aa6e]">
                    {evt.titleGerman}
                  </p>

                  <p className="font-sans-inter text-xs text-[#bfae93] leading-relaxed">
                    {evt.description}
                  </p>

                  <div className="pt-2 border-t border-[#c8aa6e]/20 flex items-center justify-between">
                    <div className="text-xs font-cinzel text-[#e8dfce]">
                      <span className="text-[#c8aa6e] font-bold">
                        {evt.totalSeats - evt.bookedSeats} Stoelen oer
                      </span>{' '}
                      / {evt.totalSeats} totaal
                    </div>

                    <button
                      onClick={() => {
                        setSelectedEvent(evt);
                        setBookedSuccess(null);
                        setTicketCount(1);
                      }}
                      className="inline-flex items-center gap-2 px-4 py-2 rounded-sm bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-wider hover:bg-[#e6ce8a] transition-all"
                    >
                      <Ticket className="w-3.5 h-3.5" />
                      <span>Reservearje (€{evt.price.toFixed(2)})</span>
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Mobile View Stack */}
        <div className="md:hidden space-y-6">
          {EVENTS.map((evt) => (
            <div
              key={evt.id}
              className="bg-[#102218] border border-[#c8aa6e]/30 rounded-sm p-5 space-y-4"
            >
              <img
                src={evt.image}
                alt={evt.titleOldFrisian}
                className="w-full h-44 object-cover rounded-sm"
              />
              <span className="inline-block px-2.5 py-1 rounded bg-[#c8aa6e] text-[#09100c] font-cinzel text-[10px] uppercase font-bold">
                {evt.category}
              </span>
              <h3 className="font-blackletter text-2xl text-[#f4efe6]">{evt.titleOldFrisian}</h3>
              <p className="font-serif-cormorant text-sm italic text-[#c8aa6e]">{evt.titleGerman}</p>
              <p className="font-sans-inter text-xs text-[#bfae93]">{evt.description}</p>

              <button
                onClick={() => {
                  setSelectedEvent(evt);
                  setBookedSuccess(null);
                  setTicketCount(1);
                }}
                className="w-full py-2.5 bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold rounded-sm"
              >
                Reservearje (€{evt.price.toFixed(2)})
              </button>
            </div>
          ))}
        </div>

      </div>

      {/* Booking Ticket Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 bg-[#09100c]/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-[#102218] border border-[#c8aa6e]/50 rounded-sm max-w-md w-full p-6 space-y-6 relative shadow-2xl">
            
            <button
              onClick={() => setSelectedEvent(null)}
              className="absolute top-4 right-4 p-2 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
            >
              <X className="w-5 h-5" />
            </button>

            {!bookedSuccess ? (
              <form onSubmit={handleBookTickets} className="space-y-4">
                <div className="flex items-center gap-2 text-[#c8aa6e]">
                  <Ticket className="w-5 h-5" />
                  <span className="font-cinzel text-xs font-bold uppercase tracking-wider">
                    Evenemint Resergearre
                  </span>
                </div>

                <h3 className="font-blackletter text-2xl text-[#f4efe6]">
                  {selectedEvent.titleOldFrisian}
                </h3>
                <p className="font-serif-cormorant text-sm italic text-[#c8aa6e]">
                  {selectedEvent.date} • {selectedEvent.time}
                </p>

                <div className="p-3 bg-[#09100c] rounded border border-[#c8aa6e]/20 space-y-2 text-xs font-sans-inter text-[#bfae93]">
                  <div className="flex justify-between">
                    <span>Sprekker:</span>
                    <span className="text-[#f4efe6] font-semibold">{selectedEvent.speaker}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Lokaasje:</span>
                    <span className="text-[#f4efe6] font-semibold">{selectedEvent.location}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block font-cinzel text-xs text-[#e8dfce] uppercase">
                    Aantal Stoelen (Tickets):
                  </label>
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setTicketCount(Math.max(1, ticketCount - 1))}
                      className="w-9 h-9 bg-[#09100c] border border-[#c8aa6e]/30 rounded text-[#f4efe6] font-bold"
                    >
                      -
                    </button>
                    <span className="font-cinzel text-lg font-bold text-[#c8aa6e] w-8 text-center">
                      {ticketCount}
                    </span>
                    <button
                      type="button"
                      onClick={() => setTicketCount(Math.min(5, ticketCount + 1))}
                      className="w-9 h-9 bg-[#09100c] border border-[#c8aa6e]/30 rounded text-[#f4efe6] font-bold"
                    >
                      +
                    </button>
                  </div>
                </div>

                <div className="pt-3 border-t border-[#c8aa6e]/20 flex justify-between items-center font-cinzel">
                  <span className="text-xs text-[#e8dfce] uppercase">Totaal Priis:</span>
                  <span className="text-xl font-bold text-[#c8aa6e]">
                    €{(selectedEvent.price * ticketCount).toFixed(2)}
                  </span>
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-widest rounded-sm hover:bg-[#e6ce8a] transition-all"
                >
                  Befêstigje Reservering
                </button>
              </form>
            ) : (
              <div className="text-center space-y-4 py-4">
                <div className="w-12 h-12 rounded-full bg-[#1c3225] border border-[#c8aa6e] text-[#c8aa6e] flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <h3 className="font-blackletter text-3xl text-[#f4efe6]">Reservering Befêstige!</h3>
                <p className="font-serif-cormorant text-base text-[#bfae93]">
                  Jo binne wolkom op {selectedEvent.date}. Wy hawwe jo stoelen fêstlein.
                </p>
                <div className="p-4 bg-[#09100c] border border-[#c8aa6e] rounded text-[#c8aa6e] font-cinzel text-sm font-bold tracking-widest">
                  TICKET KODE: {bookedSuccess}
                </div>
                <button
                  onClick={() => setSelectedEvent(null)}
                  className="w-full py-2.5 bg-[#102218] border border-[#c8aa6e]/40 text-[#f4efe6] font-cinzel text-xs uppercase font-bold rounded-sm"
                >
                  Slút
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
