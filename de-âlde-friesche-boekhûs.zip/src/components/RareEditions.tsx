import React from 'react';
import { Scroll, Sparkles, Shield, ArrowRight, BookOpen } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { BOOKS } from '../data/books';

export const RareEditions: React.FC = () => {
  const { setQuickViewBook, addToCart } = useShop();
  const rareBook = BOOKS.find((b) => b.rareEdition) || BOOKS[0];

  return (
    <section id="seldsume-edysjes" className="py-24 bg-[#102218] text-[#F5F2ED] relative overflow-hidden border-b border-[#C5A059]/20">
      
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-[#C5A059]/5 rounded-full blur-3xl pointer-events-none candle-glow" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <span className="text-[#C5A059] text-[10px] uppercase tracking-[0.4em] font-sans font-bold block">
            Kabinèt fan Seldsumheden
          </span>
          <h2 className="font-serif italic text-4xl sm:text-5xl text-[#F5F2ED]">
            Seldsume Edysjes & Hânskriften
          </h2>
          <p className="font-serif text-lg text-[#F5F2ED]/60 italic">
            Magazine-edysje oer ús meast kostbere middeleeuwske boeken.
          </p>
        </div>

        {/* Editorial Feature Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-[#0D1A12] border border-[#C5A059]/30 rounded-none p-6 sm:p-10 shadow-2xl relative">
          
          {/* Decorative Corner Accents */}
          <div className="absolute top-3 left-3 w-6 h-6 border-t-2 border-l-2 border-[#C5A059]/60 pointer-events-none" />
          <div className="absolute top-3 right-3 w-6 h-6 border-t-2 border-r-2 border-[#C5A059]/60 pointer-events-none" />
          <div className="absolute bottom-3 left-3 w-6 h-6 border-b-2 border-l-2 border-[#C5A059]/60 pointer-events-none" />
          <div className="absolute bottom-3 right-3 w-6 h-6 border-b-2 border-r-2 border-[#C5A059]/60 pointer-events-none" />

          {/* Left Editorial Photo & Provenance Tag */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-none overflow-hidden border border-[#C5A059]/40 shadow-2xl group">
              <img
                src={rareBook.coverImage}
                alt={rareBook.titleOldFrisian}
                className="w-full h-[460px] object-cover filter brightness-[0.9] contrast-[1.1] group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#08120C] via-transparent to-transparent opacity-70" />

              {/* Gold seal overlay */}
              <div className="absolute top-6 left-6 p-3 rounded-full bg-[#102218]/90 border border-[#C5A059] text-[#C5A059] shadow-xl">
                <Shield className="w-6 h-6" />
              </div>

              {/* Provenance note at bottom of photo */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-none bg-[#08120C]/90 backdrop-blur-md border border-[#C5A059]/30 text-xs text-[#F5F2ED]/90 space-y-1">
                <span className="font-sans text-[9px] text-[#C5A059] font-bold uppercase block tracking-[0.2em]">
                  Argyf Bewearing (Provenance):
                </span>
                <p className="font-serif italic">
                  {rareBook.provenance || 'Orizjineel bûn yn de Hânse-stêd Bremen, bewenne yn ’t kluis.'}
                </p>
              </div>
            </div>
          </div>

          {/* Right Content & Storytelling */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 bg-[#C5A059] text-[#102218] font-sans text-[10px] font-bold uppercase tracking-widest">
                Anno {rareBook.year}
              </span>
              <span className="font-sans text-[10px] text-[#C5A059] uppercase tracking-wider">
                Bining: {rareBook.binding}
              </span>
            </div>

            <h3 className="font-blackletter text-3xl sm:text-4xl text-[#F5F2ED] leading-tight">
              {rareBook.titleOldFrisian}
            </h3>

            <p className="font-serif text-xl text-[#C5A059] italic">
              {rareBook.titleGerman}
            </p>

            <p className="font-serif text-base text-[#F5F2ED]/70 leading-relaxed font-light">
              {rareBook.description}
            </p>

            {/* Historical excerpt preview box */}
            <div className="p-4 rounded-none bg-[#08120C] border border-[#C5A059]/30 font-serif italic text-base text-[#F5F2ED] relative">
              <span className="absolute -top-3 left-4 px-2 bg-[#0D1A12] text-[#C5A059] font-sans text-[9px] uppercase tracking-widest font-bold">
                Citaat út de Kronyk
              </span>
              “{rareBook.excerpt}”
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs font-sans text-[#F5F2ED]/80 pt-2">
              <div className="p-3 bg-[#08120C] border border-[#C5A059]/20">
                <span className="text-[#C5A059] block font-bold text-[10px] uppercase tracking-wider">Perkamint Kwaliteit</span>
                <span className="font-serif text-xs">Swier 100g Hand-mêd papier</span>
              </div>
              <div className="p-3 bg-[#08120C] border border-[#C5A059]/20">
                <span className="text-[#C5A059] block font-bold text-[10px] uppercase tracking-wider">Foarried yn Kluis</span>
                <span className="font-serif text-xs">Allinnich {rareBook.stock} eksimplaren</span>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-4">
              <button
                onClick={() => addToCart(rareBook)}
                className="px-6 py-3.5 bg-[#C5A059] text-[#102218] font-sans text-xs uppercase tracking-widest font-bold hover:bg-[#D4B478] transition-all shadow-lg"
              >
                Bestel Dizze Edysje (€{rareBook.price.toFixed(2)})
              </button>

              <button
                onClick={() => setQuickViewBook(rareBook)}
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#102218] text-[#F5F2ED] border border-[#C5A059]/40 font-sans text-xs uppercase tracking-widest font-bold hover:border-[#C5A059] hover:text-[#C5A059] transition-all"
              >
                <BookOpen className="w-4 h-4" />
                <span>Bekijk Hânskrift Preview</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
