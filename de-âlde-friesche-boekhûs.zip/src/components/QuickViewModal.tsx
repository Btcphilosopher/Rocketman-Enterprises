import React, { useState } from 'react';
import { X, ShoppingBag, Heart, Star, Shield, BookOpen, Scroll, Check } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { Book } from '../types';

export const QuickViewModal: React.FC = () => {
  const {
    quickViewBook,
    setQuickViewBook,
    addToCart,
    toggleWishlist,
    isInWishlist,
  } = useShop();

  const [activeTab, setActiveTab] = useState<'info' | 'excerpt' | 'reviews'>('info');
  const [giftWrap, setGiftWrap] = useState(false);
  const [inscription, setInscription] = useState('');

  if (!quickViewBook) return null;

  const wishlisted = isInWishlist(quickViewBook.id);

  const handleAddToCart = () => {
    addToCart(quickViewBook, giftWrap, inscription);
    setQuickViewBook(null);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#09100c]/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#102218] border border-[#c8aa6e]/50 rounded-sm max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6 sm:p-8 relative shadow-2xl text-[#f4efe6] space-y-6">
        
        {/* Close Button */}
        <button
          onClick={() => setQuickViewBook(null)}
          className="absolute top-4 right-4 p-2 text-[#e8dfce]/80 hover:text-[#c8aa6e] transition-colors z-20"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Left Column - Book Cover & Badges */}
          <div className="md:col-span-5 space-y-4">
            <div className="relative aspect-[3/4] rounded-sm overflow-hidden bg-[#09100c] border border-[#c8aa6e]/30 shadow-2xl">
              <img
                src={quickViewBook.coverImage}
                alt={quickViewBook.titleOldFrisian}
                className="w-full h-full object-cover filter brightness-[0.95]"
              />
              <div className="absolute top-3 left-3 flex flex-col gap-1">
                {quickViewBook.rareEdition && (
                  <span className="px-2.5 py-1 bg-[#c8aa6e] text-[#09100c] font-cinzel text-[10px] uppercase font-bold tracking-widest">
                    Seldsum Manuscript
                  </span>
                )}
                {quickViewBook.illuminated && (
                  <span className="px-2.5 py-1 bg-[#1c3225] border border-[#c8aa6e]/60 text-[#c8aa6e] font-cinzel text-[10px] uppercase font-bold tracking-widest">
                    Goud-Yllustrearre
                  </span>
                )}
              </div>
            </div>

            <div className="p-4 bg-[#09100c] rounded border border-[#c8aa6e]/20 text-xs font-sans-inter space-y-2 text-[#bfae93]">
              <div className="flex justify-between">
                <span>ISBN:</span>
                <span className="text-[#f4efe6] font-mono">{quickViewBook.isbn}</span>
              </div>
              <div className="flex justify-between">
                <span>Bining:</span>
                <span className="text-[#c8aa6e] font-semibold">{quickViewBook.binding}</span>
              </div>
              <div className="flex justify-between">
                <span>Aantal Siden:</span>
                <span className="text-[#f4efe6] font-semibold">{quickViewBook.pages}</span>
              </div>
              <div className="flex justify-between">
                <span>Voorraad:</span>
                <span className="text-[#c8aa6e] font-semibold">{quickViewBook.stock} eksimplaren</span>
              </div>
            </div>
          </div>

          {/* Right Column - Details, Tabs, Actions */}
          <div className="md:col-span-7 space-y-6">
            
            <div>
              <div className="flex items-center gap-2 text-xs font-cinzel text-[#c8aa6e] uppercase tracking-wider mb-1">
                <span>{quickViewBook.author}</span>
                <span>•</span>
                <span>Anno {quickViewBook.year}</span>
              </div>

              <h2 className="font-blackletter text-3xl sm:text-4xl text-[#f4efe6]">
                {quickViewBook.titleOldFrisian}
              </h2>

              <p className="font-serif-cormorant text-lg italic text-[#c8aa6e]">
                {quickViewBook.titleGerman}
              </p>
            </div>

            {/* Price Tag */}
            <div className="flex items-baseline gap-3">
              <span className="font-cinzel text-3xl font-bold text-[#c8aa6e]">
                €{quickViewBook.price.toFixed(2)}
              </span>
              {quickViewBook.originalPrice && (
                <span className="font-sans-inter text-sm text-[#bfae93]/60 line-through">
                  €{quickViewBook.originalPrice.toFixed(2)}
                </span>
              )}
            </div>

            {/* Navigation Tabs inside modal */}
            <div className="flex border-b border-[#c8aa6e]/20 gap-4 font-cinzel text-xs uppercase">
              <button
                onClick={() => setActiveTab('info')}
                className={`pb-2 transition-colors border-b-2 ${
                  activeTab === 'info'
                    ? 'border-[#c8aa6e] text-[#c8aa6e] font-bold'
                    : 'border-transparent text-[#e8dfce]/70 hover:text-[#f4efe6]'
                }`}
              >
                Ynformaasje
              </button>
              <button
                onClick={() => setActiveTab('excerpt')}
                className={`pb-2 transition-colors border-b-2 ${
                  activeTab === 'excerpt'
                    ? 'border-[#c8aa6e] text-[#c8aa6e] font-bold'
                    : 'border-transparent text-[#e8dfce]/70 hover:text-[#f4efe6]'
                }`}
              >
                Citaat & Perkamint
              </button>
              <button
                onClick={() => setActiveTab('reviews')}
                className={`pb-2 transition-colors border-b-2 ${
                  activeTab === 'reviews'
                    ? 'border-[#c8aa6e] text-[#c8aa6e] font-bold'
                    : 'border-transparent text-[#e8dfce]/70 hover:text-[#f4efe6]'
                }`}
              >
                Beoardielings ({quickViewBook.reviewsCount})
              </button>
            </div>

            {/* Tab Content */}
            {activeTab === 'info' && (
              <div className="space-y-4 font-sans-inter text-xs text-[#bfae93] leading-relaxed">
                <p>{quickViewBook.description}</p>
                <div className="p-3 bg-[#09100c] rounded border border-[#c8aa6e]/20">
                  <span className="font-cinzel text-[#c8aa6e] font-bold uppercase block text-[10px] mb-1">
                    Taal-opmerkingen:
                  </span>
                  <p>{quickViewBook.languageNotes}</p>
                </div>
              </div>
            )}

            {activeTab === 'excerpt' && (
              <div className="p-4 rounded bg-[#09100c] border border-[#c8aa6e]/30 font-serif-cormorant italic text-base text-[#e8dfce] leading-relaxed">
                “{quickViewBook.excerpt}”
              </div>
            )}

            {activeTab === 'reviews' && (
              <div className="space-y-3 font-sans-inter text-xs">
                <div className="p-3 bg-[#09100c] rounded border border-[#c8aa6e]/20 space-y-1">
                  <div className="flex justify-between items-center text-[#c8aa6e]">
                    <span className="font-bold">Prof. Dr. Janneke v.d. Wall</span>
                    <span className="flex text-[#c8aa6e]"><Star className="w-3.5 h-3.5 fill-current" /><Star className="w-3.5 h-3.5 fill-current" /><Star className="w-3.5 h-3.5 fill-current" /><Star className="w-3.5 h-3.5 fill-current" /><Star className="w-3.5 h-3.5 fill-current" /></span>
                  </div>
                  <p className="text-[#bfae93]">
                    "In meesterwurk fan restauraasje. De goudblêd yllustraasjes binne fan ungewoane kwaliteit."
                  </p>
                </div>
              </div>
            )}

            {/* Customization options (Gift Wrapping & Inscription) */}
            <div className="p-4 bg-[#09100c]/80 rounded border border-[#c8aa6e]/25 space-y-3 font-sans-inter text-xs">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={giftWrap}
                  onChange={(e) => setGiftWrap(e.target.checked)}
                  className="accent-[#c8aa6e] w-4 h-4 rounded"
                />
                <span className="text-[#f4efe6] font-cinzel uppercase text-[11px] font-semibold">
                  Echte Hanseatyk Kado-ferpakking mei Goudband (+ €5.00)
                </span>
              </label>

              {giftWrap && (
                <input
                  type="text"
                  value={inscription}
                  onChange={(e) => setInscription(e.target.value)}
                  placeholder="Persoonlike kalligrafyske ynskripsje yn 't boek..."
                  className="w-full px-3 py-2 rounded bg-[#102218] border border-[#c8aa6e]/30 text-[#f4efe6] placeholder-[#e8dfce]/40 text-xs focus:outline-none focus:border-[#c8aa6e]"
                />
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-4 pt-2">
              <button
                onClick={handleAddToCart}
                className="flex-grow py-3.5 rounded-sm bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-widest hover:bg-[#e6ce8a] transition-all shadow-lg flex items-center justify-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Tafoegje oan Winkelkoer</span>
              </button>

              <button
                onClick={() => toggleWishlist(quickViewBook)}
                className={`p-3.5 rounded-sm border transition-colors ${
                  wishlisted
                    ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e]'
                    : 'bg-[#09100c] text-[#e8dfce] border-[#c8aa6e]/40 hover:border-[#c8aa6e] hover:text-[#c8aa6e]'
                }`}
                title="Bewarje yn Verlanglijst"
              >
                <Heart className={`w-5 h-5 ${wishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
