import React from 'react';
import { Coffee, Flame, Lamp, Volume2, VolumeX, BookOpen, Clock } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const ReadingRoom: React.FC = () => {
  const { ambientSoundPlaying, toggleAmbientSound } = useShop();

  return (
    <section id="lêskeamer" className="py-24 bg-[#0b140f] text-[#f4efe6] relative overflow-hidden">
      
      {/* Background candle glow effect */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#c8aa6e]/5 rounded-full blur-3xl pointer-events-none candle-glow" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#102218] border border-[#c8aa6e]/30 text-[#c8aa6e]">
            <Flame className="w-4 h-4 text-[#ffb74d] animate-pulse" />
            <span className="font-cinzel text-xs tracking-widest uppercase font-semibold">
              It Hillichdom fan Stilte
            </span>
          </div>
          <h2 className="font-blackletter text-4xl sm:text-5xl text-[#f4efe6]">
            Ús Lêskeamer & Eiken Tafels
          </h2>
          <p className="font-serif-cormorant text-xl text-[#bfae93] italic">
            Nimme jo tiid. Sit yn 'e swiere eiken stuollen, genietsje fan in kopke East-Fryske tee en ferdwyn yn 't ferline.
          </p>
        </div>

        {/* 2x2 Grid with Atmospheric Details */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Main Large Image Feature */}
          <div className="lg:col-span-7 relative rounded-sm overflow-hidden border border-[#c8aa6e]/30 shadow-2xl min-h-[420px] group">
            <img
              src="https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1200&q=80"
              alt="Eiken Lêskeamer mei kearsen"
              className="w-full h-full object-cover filter brightness-[0.85] contrast-[1.1] group-hover:scale-105 transition-transform duration-1000"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#09100c] via-[#09100c]/40 to-transparent" />

            <div className="absolute bottom-6 left-6 right-6 p-6 rounded bg-[#102218]/90 backdrop-blur-md border border-[#c8aa6e]/40 space-y-2">
              <span className="font-cinzel text-xs text-[#c8aa6e] uppercase tracking-widest font-bold">
                Bremen & Hanse Boekhûs • Iepeningstiden: 09:00 - 20:00
              </span>
              <h3 className="font-blackletter text-2xl text-[#f4efe6]">
                Eiken Tafels, Messing Lampen & De Haard
              </h3>
              <p className="font-sans-inter text-xs text-[#bfae93] leading-relaxed">
                Elke besiker is wolkom om oerenlang stil te lêzen sûnder ferplichting. Us lêskeamer biedt natuerlik ljocht oer dei en kearsljocht yn de jûn.
              </p>
            </div>
          </div>

          {/* Right Cards Breakdown */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-4">
            
            <div className="p-6 rounded bg-[#102218] border border-[#c8aa6e]/20 space-y-3">
              <div className="flex items-center gap-3 text-[#c8aa6e]">
                <Flame className="w-5 h-5" />
                <h4 className="font-cinzel text-sm font-bold uppercase tracking-wider text-[#f4efe6]">
                  De Knapperjende Haard
                </h4>
              </div>
              <p className="font-serif-cormorant text-sm text-[#e8dfce]/90 leading-relaxed">
                Yn de wintermoannen baant it fjoer yn de klassike stiennen haard in waarme gloed oer de perkamint siden.
              </p>
            </div>

            <div className="p-6 rounded bg-[#102218] border border-[#c8aa6e]/20 space-y-3">
              <div className="flex items-center gap-3 text-[#c8aa6e]">
                <Coffee className="w-5 h-5" />
                <h4 className="font-cinzel text-sm font-bold uppercase tracking-wider text-[#f4efe6]">
                  Verse Kofje & East-Fryske Tee
                </h4>
              </div>
              <p className="font-serif-cormorant text-sm text-[#e8dfce]/90 leading-relaxed">
                Us obers tsjinje yn alle stilte amandelknoppen, sukerbôle en East-Fryske tee mei Kluntje oan jo lês-tafel.
              </p>
            </div>

            <div className="p-6 rounded bg-[#102218] border border-[#c8aa6e]/30 space-y-4 bg-gradient-to-br from-[#102218] to-[#1c3225]/40 shadow-inner">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#c8aa6e] text-[#09100c] flex items-center justify-center font-bold">
                    <Lamp className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-cinzel text-xs font-bold uppercase tracking-wider text-[#f4efe6]">
                      Digital Lêskeamer Sfear
                    </h4>
                    <span className="font-serif-cormorant text-xs italic text-[#c8aa6e]">
                      {ambientSoundPlaying ? 'Lûden binne aktyf' : 'Aktivearje knapperend hout & kearsen'}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={toggleAmbientSound}
                className={`w-full py-3 rounded-sm font-cinzel text-xs uppercase tracking-widest font-bold transition-all flex items-center justify-center gap-2 border ${
                  ambientSoundPlaying
                    ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e] shadow-lg'
                    : 'bg-[#09100c] text-[#c8aa6e] border-[#c8aa6e]/40 hover:border-[#c8aa6e] hover:bg-[#102218]'
                }`}
              >
                {ambientSoundPlaying ? (
                  <>
                    <Volume2 className="w-4 h-4 animate-pulse" />
                    <span>Stopje Lêskeamer Lûden</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="w-4 h-4" />
                    <span>Start Sfear-Lûden (Fireplace & Paper)</span>
                  </>
                )}
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
