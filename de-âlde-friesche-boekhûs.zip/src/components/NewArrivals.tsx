import React from 'react';
import { Eye, Heart, ShoppingBag, Star, Sparkles, Filter } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { BOOKS } from '../data/books';
import { CategoryId } from '../types';

const CATEGORIES: { id: CategoryId; labelOldFrisian: string }[] = [
  { id: 'all', labelOldFrisian: 'Alle Boeken' },
  { id: 'history', labelOldFrisian: 'Skiednis' },
  { id: 'language', labelOldFrisian: 'Frisian Taal' },
  { id: 'philosophy', labelOldFrisian: 'Filosofy' },
  { id: 'poetry', labelOldFrisian: 'Poëzij' },
  { id: 'maps', labelOldFrisian: 'Kartografy' },
  { id: 'rare', labelOldFrisian: 'Seldsume Edysjes' },
  { id: 'classics', labelOldFrisian: 'Klassiken' },
  { id: 'children', labelOldFrisian: 'Lytse Lêzers' },
];

export const NewArrivals: React.FC = () => {
  const {
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setQuickViewBook,
    addToCart,
    toggleWishlist,
    isInWishlist,
  } = useShop();

  const filteredBooks = BOOKS.filter((book) => {
    const matchesCat = selectedCategory === 'all' || book.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      book.titleOldFrisian.toLowerCase().includes(q) ||
      book.titleGerman.toLowerCase().includes(q) ||
      book.author.toLowerCase().includes(q) ||
      book.description.toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  return (
    <section id="nije-oankomsten" className="py-24 bg-[#102218] text-[#F5F2ED] relative border-b border-[#C5A059]/20">
      
      {/* Background glow */}
      <div className="absolute top-1/2 right-10 w-96 h-96 bg-[#C5A059]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 border-b border-[#C5A059]/20 pb-8 gap-6">
          <div className="space-y-2">
            <span className="text-[#C5A059] text-[10px] uppercase tracking-[0.4em] font-sans font-bold block">
              Katalogus fan de Hanse
            </span>
            <h2 className="font-serif italic text-4xl sm:text-5xl text-[#F5F2ED]">
              Nije Oankomsten & Kolleksje
            </h2>
            <p className="font-serif text-base text-[#F5F2ED]/60 italic">
              Selektekearre boeken en seldsume hânskriften út Bremen, Hamburg & Leeuwarden.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-none font-sans text-[10px] uppercase tracking-[0.2em] whitespace-nowrap transition-all border ${
                  selectedCategory === cat.id
                    ? 'bg-[#C5A059] text-[#102218] border-[#C5A059] font-bold shadow-[0_4px_12px_rgba(197,160,89,0.25)]'
                    : 'bg-[#0D1A12] text-[#F5F2ED]/70 border-[#C5A059]/20 hover:border-[#C5A059] hover:text-[#C5A059]'
                }`}
              >
                {cat.labelOldFrisian}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        {filteredBooks.length === 0 ? (
          <div className="text-center py-20 bg-[#0D1A12] border border-[#C5A059]/20 p-8 max-w-lg mx-auto space-y-4">
            <Filter className="w-10 h-10 text-[#C5A059] mx-auto opacity-60" />
            <h3 className="font-serif italic text-2xl text-[#F5F2ED]">Geen Boeken Fûn</h3>
            <p className="font-serif text-base text-[#F5F2ED]/60">
              Er binne op dit stuit gjin boeken dy’t foldogge oan dizze sykopdracht.
            </p>
            <button
              onClick={() => {
                setSelectedCategory('all');
              }}
              className="px-6 py-2 bg-[#C5A059] text-[#102218] font-sans text-xs uppercase font-bold tracking-widest"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredBooks.map((book) => {
              const wishlisted = isInWishlist(book.id);

              return (
                <div
                  key={book.id}
                  className="bg-[#0D1A12] border border-[#C5A059]/20 hover:border-[#C5A059] transition-all duration-300 p-5 flex flex-col justify-between group shadow-xl relative"
                >
                  {/* Rare or New badge */}
                  <div className="absolute top-7 left-7 z-20 flex flex-col gap-1">
                    {book.rareEdition && (
                      <span className="px-2.5 py-1 bg-[#C5A059] text-[#102218] font-sans text-[9px] uppercase font-bold tracking-[0.2em]">
                        Seldsum Manuscripts
                      </span>
                    )}
                    {book.isNewArrival && !book.rareEdition && (
                      <span className="px-2.5 py-1 bg-[#102218] border border-[#C5A059]/50 text-[#C5A059] font-sans text-[9px] uppercase font-bold tracking-[0.2em]">
                        Nij Oankommen
                      </span>
                    )}
                  </div>

                  {/* Wishlist toggle top right */}
                  <button
                    onClick={() => toggleWishlist(book)}
                    className={`absolute top-7 right-7 z-20 p-2 rounded-full backdrop-blur-md transition-colors border ${
                      wishlisted
                        ? 'bg-[#C5A059] text-[#102218] border-[#C5A059]'
                        : 'bg-[#102218]/80 text-[#F5F2ED] border-[#C5A059]/30 hover:border-[#C5A059] hover:text-[#C5A059]'
                    }`}
                    title={wishlisted ? 'Ferwiderje út bewarre boeken' : 'Bewarje yn verlanglijst'}
                  >
                    <Heart className={`w-4 h-4 ${wishlisted ? 'fill-current' : ''}`} />
                  </button>

                  {/* Book Cover Container */}
                  <div
                    onClick={() => setQuickViewBook(book)}
                    className="relative mb-5 cursor-pointer book-lift aspect-[3/4] overflow-hidden bg-[#08120C] border border-[#C5A059]/10"
                  >
                    <img
                      src={book.coverImage}
                      alt={book.titleOldFrisian}
                      className="w-full h-full object-cover filter brightness-[0.9] contrast-[1.1] group-hover:scale-105 transition-transform duration-500"
                    />

                    {/* Quick view overlay on hover */}
                    <div className="absolute inset-0 bg-[#0D1A12]/85 backdrop-blur-[2px] opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-3 p-4 text-center">
                      <span className="w-10 h-10 rounded-full bg-[#C5A059] text-[#102218] flex items-center justify-center">
                        <Eye className="w-5 h-5" />
                      </span>
                      <span className="font-sans text-[10px] uppercase font-bold text-[#F5F2ED] tracking-[0.2em]">
                        Snelle Ynseh (Quick View)
                      </span>
                      <span className="font-serif text-xs italic text-[#C5A059]">
                        {book.pages} siden • {book.binding}
                      </span>
                    </div>
                  </div>

                  {/* Book Info */}
                  <div className="space-y-2 flex-grow">
                    <div className="flex items-center justify-between text-xs text-[#C5A059]">
                      <span className="font-sans text-[10px] tracking-[0.15em] uppercase font-bold">
                        {book.author}
                      </span>
                      <span className="flex items-center gap-1 font-sans text-xs">
                        <Star className="w-3.5 h-3.5 fill-[#C5A059] text-[#C5A059]" />
                        <span>{book.rating.toFixed(1)}</span>
                      </span>
                    </div>

                    <h3
                      onClick={() => setQuickViewBook(book)}
                      className="font-blackletter text-2xl text-[#F5F2ED] hover:text-[#C5A059] transition-colors cursor-pointer leading-tight line-clamp-2"
                    >
                      {book.titleOldFrisian}
                    </h3>

                    <p className="font-serif text-sm italic text-[#F5F2ED]/60 line-clamp-1">
                      {book.titleGerman}
                    </p>
                  </div>

                  {/* Price & Action Button */}
                  <div className="pt-4 mt-4 border-t border-[#C5A059]/20 flex items-center justify-between">
                    <div>
                      <div className="font-serif text-lg font-bold text-[#C5A059]">
                        €{book.price.toFixed(2)}
                      </div>
                      {book.originalPrice && (
                        <div className="font-sans text-xs text-[#F5F2ED]/40 line-through">
                          €{book.originalPrice.toFixed(2)}
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => addToCart(book)}
                      className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#102218] border border-[#C5A059]/40 text-[#C5A059] font-sans text-[10px] uppercase font-bold tracking-[0.15em] hover:bg-[#C5A059] hover:text-[#102218] transition-all"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Bestel</span>
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        )}

      </div>
    </section>
  );
};
