import React, { useState } from 'react';
import { Coffee, Cake, Utensils, Sparkles, Check } from 'lucide-react';
import { CAFE_ITEMS } from '../data/cafe';
import { useShop } from '../context/ShopContext';

export const CafeSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'all' | 'thee' | 'koffie' | 'gebak' | 'brea'>('all');
  const { showToast } = useShop();

  const filteredItems = CAFE_ITEMS.filter(
    (item) => activeTab === 'all' || item.category === activeTab
  );

  return (
    <section id="kafee" className="py-24 bg-[#09100c] text-[#f4efe6] relative">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#102218] border border-[#c8aa6e]/30 text-[#c8aa6e]">
            <Coffee className="w-4 h-4" />
            <span className="font-cinzel text-xs tracking-widest uppercase font-semibold">
              Klassike Gastfrijheid
            </span>
          </div>
          <h2 className="font-blackletter text-4xl sm:text-5xl text-[#f4efe6]">
            It Friesch Koffy- & Teehûs
          </h2>
          <p className="font-serif-cormorant text-xl text-[#bfae93] italic">
            Donker eikenhout, Dútske gebakken, Fryske sûkerbôle en de orizjinele East-Fryske teeserymonje.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex justify-center items-center gap-2 mb-12 flex-wrap">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-5 py-2.5 rounded-sm font-cinzel text-xs uppercase tracking-wider transition-all border ${
              activeTab === 'all'
                ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e] font-bold'
                : 'bg-[#102218] text-[#e8dfce]/80 border-[#c8aa6e]/20 hover:border-[#c8aa6e]'
            }`}
          >
            Alle Lekkernijen
          </button>
          <button
            onClick={() => setActiveTab('thee')}
            className={`px-5 py-2.5 rounded-sm font-cinzel text-xs uppercase tracking-wider transition-all border ${
              activeTab === 'thee'
                ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e] font-bold'
                : 'bg-[#102218] text-[#e8dfce]/80 border-[#c8aa6e]/20 hover:border-[#c8aa6e]'
            }`}
          >
            East-Fryske Tee
          </button>
          <button
            onClick={() => setActiveTab('koffie')}
            className={`px-5 py-2.5 rounded-sm font-cinzel text-xs uppercase tracking-wider transition-all border ${
              activeTab === 'koffie'
                ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e] font-bold'
                : 'bg-[#102218] text-[#e8dfce]/80 border-[#c8aa6e]/20 hover:border-[#c8aa6e]'
            }`}
          >
            Hanseatyk Kofje
          </button>
          <button
            onClick={() => setActiveTab('gebak')}
            className={`px-5 py-2.5 rounded-sm font-cinzel text-xs uppercase tracking-wider transition-all border ${
              activeTab === 'gebak'
                ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e] font-bold'
                : 'bg-[#102218] text-[#e8dfce]/80 border-[#c8aa6e]/20 hover:border-[#c8aa6e]'
            }`}
          >
            Dútske & Fryske Gebakken
          </button>
          <button
            onClick={() => setActiveTab('brea')}
            className={`px-5 py-2.5 rounded-sm font-cinzel text-xs uppercase tracking-wider transition-all border ${
              activeTab === 'brea'
                ? 'bg-[#c8aa6e] text-[#09100c] border-[#c8aa6e] font-bold'
                : 'bg-[#102218] text-[#e8dfce]/80 border-[#c8aa6e]/20 hover:border-[#c8aa6e]'
            }`}
          >
            Ambachtlik Brea
          </button>
        </div>

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="bg-[#102218] border border-[#c8aa6e]/25 hover:border-[#c8aa6e] rounded-sm p-6 flex flex-col justify-between group transition-all duration-300 shadow-xl"
            >
              <div className="space-y-4">
                <div className="aspect-[16/10] rounded-sm overflow-hidden bg-[#09100c]">
                  <img
                    src={item.image}
                    alt={item.nameOldFrisian}
                    className="w-full h-full object-cover filter brightness-90 group-hover:scale-105 transition-transform duration-500"
                  />
                </div>

                <div>
                  <div className="flex justify-between items-start gap-2">
                    <h3 className="font-blackletter text-2xl text-[#f4efe6] group-hover:text-[#c8aa6e] transition-colors">
                      {item.nameOldFrisian}
                    </h3>
                    <span className="font-cinzel text-base font-bold text-[#c8aa6e]">
                      €{item.price.toFixed(2)}
                    </span>
                  </div>

                  <p className="font-serif-cormorant text-sm italic text-[#c8aa6e] pt-0.5">
                    {item.nameGerman}
                  </p>
                </div>

                <p className="font-sans-inter text-xs text-[#bfae93] leading-relaxed">
                  {item.description}
                </p>

                <div className="p-3 bg-[#09100c]/70 rounded border border-[#c8aa6e]/15 text-[11px] font-cinzel text-[#e8dfce]/80 flex items-start gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-[#c8aa6e] shrink-0 mt-0.5" />
                  <span>{item.authenticDetails}</span>
                </div>
              </div>

              <button
                onClick={() => showToast(`Tafel-reservaasje foar "${item.nameOldFrisian}" fêstlein yn de Lêskeamer.`)}
                className="mt-6 w-full py-2.5 rounded-sm bg-[#1c3225] text-[#f4efe6] hover:bg-[#c8aa6e] hover:text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-wider transition-all border border-[#c8aa6e]/30"
              >
                Bestel oan Tafel / Reservearje
              </button>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
