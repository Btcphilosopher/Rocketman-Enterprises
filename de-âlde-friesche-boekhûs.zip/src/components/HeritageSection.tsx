import React, { useState } from 'react';
import { Scroll, Compass, BookOpen, Volume2, Copy, Check, Sparkles } from 'lucide-react';
import { DICTIONARY_PHRASES, HERITAGE_ARTICLES } from '../data/heritage';
import { useShop } from '../context/ShopContext';

export const HeritageSection: React.FC = () => {
  const [copiedPhrase, setCopiedPhrase] = useState<string | null>(null);
  const { showToast } = useShop();

  const handleCopy = (phrase: string) => {
    navigator.clipboard.writeText(phrase);
    setCopiedPhrase(phrase);
    showToast(`Kopiearre: "${phrase}"`);
    setTimeout(() => setCopiedPhrase(null), 2500);
  };

  return (
    <section id="erfskip" className="py-24 bg-[#09100c] text-[#f4efe6] relative overflow-hidden">
      
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-10 w-96 h-96 bg-[#c8aa6e]/5 rounded-full blur-3xl pointer-events-none candle-glow" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#102218] border border-[#c8aa6e]/30 text-[#c8aa6e]">
            <Scroll className="w-4 h-4" />
            <span className="font-cinzel text-xs tracking-widest uppercase font-semibold">
              Kultuer & Erfskip fan it Noarden
            </span>
          </div>
          <h2 className="font-blackletter text-4xl sm:text-5xl text-[#f4efe6]">
            It Âldfryske Erfskip & De Hanse
          </h2>
          <p className="font-serif-cormorant text-xl text-[#bfae93] italic">
            Wêrom wy in Dútske boekhannel binne dy't har hiele identity yn it Âldfrysk skriuwt.
          </p>
        </div>

        {/* 2-Column Heritage History Articles */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20">
          {HERITAGE_ARTICLES.map((art) => (
            <div
              key={art.id}
              className="bg-[#102218] border border-[#c8aa6e]/30 rounded-sm p-8 space-y-6 shadow-xl relative"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#1c3225] border border-[#c8aa6e]/50 text-[#c8aa6e] flex items-center justify-center font-blackletter text-xl">
                  ᛭
                </div>
                <div>
                  <h3 className="font-blackletter text-2xl text-[#f4efe6]">
                    {art.titleOldFrisian}
                  </h3>
                  <span className="font-serif-cormorant text-sm italic text-[#c8aa6e]">
                    {art.titleGerman}
                  </span>
                </div>
              </div>

              <div className="aspect-[16/9] rounded-sm overflow-hidden bg-[#09100c]">
                <img
                  src={art.manuscriptIllustration}
                  alt={art.titleOldFrisian}
                  className="w-full h-full object-cover filter brightness-90"
                />
              </div>

              <p className="font-sans-inter text-sm text-[#bfae93] leading-relaxed">
                {art.content}
              </p>
            </div>
          ))}
        </div>

        {/* Interactive Old Frisian Dictionary Section */}
        <div className="bg-[#102218]/90 border border-[#c8aa6e]/40 rounded-sm p-8 space-y-8 shadow-2xl relative">
          
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-[#c8aa6e]/20 pb-6 gap-4">
            <div>
              <div className="flex items-center gap-2 text-[#c8aa6e] mb-1">
                <Sparkles className="w-4 h-4" />
                <span className="font-cinzel text-xs uppercase tracking-widest font-semibold">
                  Interaktyf Âldfrysk Wurdboek
                </span>
              </div>
              <h3 className="font-blackletter text-3xl text-[#f4efe6]">
                Learje de Fryske Zinnen & Klanken
              </h3>
            </div>
            <span className="font-serif-cormorant text-sm italic text-[#bfae93]">
              Klik op in zin om it te kopiearjen foar jo oantekeningen.
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {DICTIONARY_PHRASES.map((item, idx) => (
              <div
                key={idx}
                className="bg-[#09100c] border border-[#c8aa6e]/20 hover:border-[#c8aa6e] rounded-sm p-5 space-y-3 transition-colors group relative"
              >
                <div className="flex justify-between items-start gap-4">
                  <h4 className="font-blackletter text-xl text-[#f4efe6] group-hover:text-[#c8aa6e] transition-colors">
                    {item.oldFrisian}
                  </h4>

                  <button
                    onClick={() => handleCopy(item.oldFrisian)}
                    className="p-1.5 rounded bg-[#102218] border border-[#c8aa6e]/30 text-[#e8dfce] hover:text-[#c8aa6e] transition-colors shrink-0"
                    title="Kopiearje nei klipboord"
                  >
                    {copiedPhrase === item.oldFrisian ? (
                      <Check className="w-4 h-4 text-[#c8aa6e]" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </button>
                </div>

                <div className="font-serif-cormorant text-xs italic text-[#c8aa6e] flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5" />
                  <span>Utsprutsen: "{item.pronunciation}"</span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs font-sans-inter pt-2 border-t border-[#c8aa6e]/10">
                  <div>
                    <span className="text-[#c8aa6e] block font-semibold text-[10px] uppercase font-cinzel">
                      Dútsk:
                    </span>
                    <span className="text-[#bfae93]">{item.german}</span>
                  </div>
                  <div>
                    <span className="text-[#c8aa6e] block font-semibold text-[10px] uppercase font-cinzel">
                      Ingelsk:
                    </span>
                    <span className="text-[#bfae93]">{item.english}</span>
                  </div>
                </div>

                <p className="font-sans-inter text-[11px] text-[#e8dfce]/70 pt-1">
                  {item.context}
                </p>
              </div>
            ))}
          </div>

        </div>

      </div>
    </section>
  );
};
