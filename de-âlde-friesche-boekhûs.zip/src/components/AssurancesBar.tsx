import React from 'react';
import { BookMarked, Feather, Anchor, Gem } from 'lucide-react';

export const AssurancesBar: React.FC = () => {
  return (
    <section className="bg-gradient-to-r from-[#e8dfce] via-[#f4efe6] to-[#e8dfce] text-[#09100c] py-8 border-y border-[#c8aa6e]/40 shadow-inner">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center sm:text-left">
          
          <div className="flex items-center gap-4 p-3 rounded bg-black/5 hover:bg-black/10 transition-colors">
            <div className="w-12 h-12 rounded-full bg-[#102218] text-[#c8aa6e] flex items-center justify-center shrink-0 shadow">
              <BookMarked className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-cinzel text-xs font-bold uppercase tracking-wider text-[#102218]">
                Selektekearre mei Soarch
              </h4>
              <p className="font-serif-cormorant text-sm text-[#3c3226]">
                Allinnich boeken fan kwaliteit, selektearre foar har tydloze wearde.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-3 rounded bg-black/5 hover:bg-black/10 transition-colors">
            <div className="w-12 h-12 rounded-full bg-[#102218] text-[#c8aa6e] flex items-center justify-center shrink-0 shadow">
              <Feather className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-cinzel text-xs font-bold uppercase tracking-wider text-[#102218]">
                Yn it Frysk & Dútsk
              </h4>
              <p className="font-serif-cormorant text-sm text-[#3c3226]">
                Wy stypje en befoarderje de Fryske taal en kultuer.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-3 rounded bg-black/5 hover:bg-black/10 transition-colors">
            <div className="w-12 h-12 rounded-full bg-[#102218] text-[#c8aa6e] flex items-center justify-center shrink-0 shadow">
              <Anchor className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-cinzel text-xs font-bold uppercase tracking-wider text-[#102218]">
                Skiednis & Hanse-Erfskip
              </h4>
              <p className="font-serif-cormorant text-sm text-[#3c3226]">
                Fan âlde kroniken oant moderne wurk — ús kolleksje fertelt ús ferhaal.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-3 rounded bg-black/5 hover:bg-black/10 transition-colors">
            <div className="w-12 h-12 rounded-full bg-[#102218] text-[#c8aa6e] flex items-center justify-center shrink-0 shadow">
              <Gem className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-cinzel text-xs font-bold uppercase tracking-wider text-[#102218]">
                Wizheit foar de Siel
              </h4>
              <p className="font-serif-cormorant text-sm text-[#3c3226]">
                Boeken dy’t net allinnich de geast, mar ek it hert oansprekke.
              </p>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
