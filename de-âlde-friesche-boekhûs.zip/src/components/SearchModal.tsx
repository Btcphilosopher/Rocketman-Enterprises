import React from 'react';
import { X, Search, BookOpen, ArrowRight } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { BOOKS } from '../data/books';

export const SearchModal: React.FC = () => {
  const {
    isSearchOpen,
    setIsSearchOpen,
    searchQuery,
    setSearchQuery,
    setQuickViewBook,
  } = useShop();

  if (!isSearchOpen) return null;

  const results = BOOKS.filter((book) => {
    if (!searchQuery.trim()) return false;
    const q = searchQuery.toLowerCase();
    return (
      book.titleOldFrisian.toLowerCase().includes(q) ||
      book.titleGerman.toLowerCase().includes(q) ||
      book.author.toLowerCase().includes(q) ||
      book.category.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 bg-[#09100c]/85 backdrop-blur-md flex items-start justify-center pt-20 p-4 animate-fadeIn">
      <div className="bg-[#102218] border border-[#c8aa6e]/50 rounded-sm max-w-2xl w-full p-6 relative shadow-2xl text-[#f4efe6] space-y-6">
        
        <button
          onClick={() => {
            setIsSearchOpen(false);
            setSearchQuery('');
          }}
          className="absolute top-4 right-4 p-2 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-3 border-b border-[#c8aa6e]/30 pb-3">
          <Search className="w-5 h-5 text-[#c8aa6e]" />
          <input
            type="text"
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Sykje op titel, auteur, ûnderwerp of runen (e.g. Lex Frisionum, Hanse, Blaeu)..."
            className="w-full bg-transparent text-lg text-[#f4efe6] placeholder-[#e8dfce]/40 focus:outline-none font-serif-cormorant italic"
          />
        </div>

        {/* Quick Suggestion Pills */}
        {!searchQuery && (
          <div className="space-y-3 font-cinzel text-xs">
            <span className="text-[#c8aa6e] uppercase tracking-wider block font-bold">
              Populêre Sykopdrachten:
            </span>
            <div className="flex flex-wrap gap-2">
              {['Lex Frisionum', 'Hanseatyk', 'Kartografy', 'Runen', 'Oera Linda', 'Poëzij'].map(
                (term) => (
                  <button
                    key={term}
                    onClick={() => setSearchQuery(term)}
                    className="px-3 py-1.5 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#e8dfce] hover:border-[#c8aa6e] hover:text-[#c8aa6e]"
                  >
                    {term}
                  </button>
                )
              )}
            </div>
          </div>
        )}

        {/* Results List */}
        {searchQuery && (
          <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
            <span className="font-cinzel text-xs text-[#c8aa6e] uppercase font-bold block">
              Resultaten ({results.length})
            </span>

            {results.length === 0 ? (
              <p className="font-serif-cormorant italic text-[#bfae93] py-4">
                Gjin boeken fûn foar "{searchQuery}". Probearje in oar trefwurd.
              </p>
            ) : (
              results.map((book) => (
                <div
                  key={book.id}
                  onClick={() => {
                    setQuickViewBook(book);
                    setIsSearchOpen(false);
                  }}
                  className="p-3 bg-[#09100c] border border-[#c8aa6e]/20 hover:border-[#c8aa6e] rounded flex items-center justify-between cursor-pointer group transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={book.coverImage}
                      alt={book.titleOldFrisian}
                      className="w-10 h-14 object-cover rounded"
                    />
                    <div>
                      <h4 className="font-blackletter text-lg text-[#f4efe6] group-hover:text-[#c8aa6e]">
                        {book.titleOldFrisian}
                      </h4>
                      <p className="font-serif-cormorant text-xs italic text-[#c8aa6e]">
                        {book.author} • €{book.price.toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <ArrowRight className="w-4 h-4 text-[#c8aa6e] group-hover:translate-x-1 transition-transform" />
                </div>
              ))
            )}
          </div>
        )}

      </div>
    </div>
  );
};
