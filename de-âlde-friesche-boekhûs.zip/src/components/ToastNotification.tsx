import React from 'react';
import { Sparkles } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const ToastNotification: React.FC = () => {
  const { toastMessage } = useShop();

  if (!toastMessage) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 animate-bounce">
      <div className="bg-[#102218] border-2 border-[#c8aa6e] text-[#f4efe6] px-5 py-3.5 rounded-sm shadow-[0_10px_30px_rgba(0,0,0,0.8)] flex items-center gap-3 max-w-md">
        <Sparkles className="w-5 h-5 text-[#c8aa6e] shrink-0" />
        <span className="font-serif-cormorant text-base italic leading-snug">
          {toastMessage}
        </span>
      </div>
    </div>
  );
};
