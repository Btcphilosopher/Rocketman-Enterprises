import React, { useState } from 'react';
import { X, ShieldCheck, Check, CreditCard, Truck, MapPin } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const CheckoutModal: React.FC = () => {
  const { isCheckoutOpen, setIsCheckoutOpen, cart, cartTotal, placeOrder } = useShop();

  const [step, setStep] = useState<'shipping' | 'payment' | 'done'>('shipping');
  const [formData, setFormData] = useState({
    name: 'Jan de Hanse',
    email: 'jan@hanse-bremen.de',
    address: 'Schnoor-Allee 14',
    city: 'Bremen',
    zip: '28195',
    country: 'Dútslân (Germany)',
    deliverySpeed: 'Hanse Postkoets Standard (€4.50)',
    paymentMethod: 'Kredytkaart / SEPA',
  });

  if (!isCheckoutOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 'shipping') {
      setStep('payment');
    } else if (step === 'payment') {
      placeOrder(formData);
      setStep('done');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#09100c]/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#102218] border border-[#c8aa6e]/50 rounded-sm max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl text-[#f4efe6] space-y-6 max-h-[90vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={() => setIsCheckoutOpen(false)}
          className="absolute top-4 right-4 p-2 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="flex items-center gap-3 border-b border-[#c8aa6e]/20 pb-4">
          <ShieldCheck className="w-6 h-6 text-[#c8aa6e]" />
          <div>
            <h2 className="font-blackletter text-2xl text-[#f4efe6]">
              Feilige Hanse Bestelling
            </h2>
            <p className="font-cinzel text-xs text-[#c8aa6e] uppercase tracking-wider">
              Bremen & Leeuwarden Kassa
            </p>
          </div>
        </div>

        {step !== 'done' ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Steps indicator */}
            <div className="flex justify-between text-xs font-cinzel text-[#c8aa6e] border-b border-[#c8aa6e]/15 pb-3 uppercase tracking-wider">
              <span className={step === 'shipping' ? 'font-bold text-[#f4efe6]' : ''}>
                1. Adres & Postkoets
              </span>
              <span className={step === 'payment' ? 'font-bold text-[#f4efe6]' : ''}>
                2. Betelling & Befêstiging
              </span>
            </div>

            {step === 'shipping' && (
              <div className="space-y-4 text-xs font-sans-inter">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#e8dfce] font-cinzel mb-1">Volledige Naam:</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#f4efe6]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#e8dfce] font-cinzel mb-1">E-postadres:</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#f4efe6]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-[#e8dfce] font-cinzel mb-1">Straat & Húsnûmer:</label>
                    <input
                      type="text"
                      required
                      value={formData.address}
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#f4efe6]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#e8dfce] font-cinzel mb-1">Postkoade:</label>
                    <input
                      type="text"
                      required
                      value={formData.zip}
                      onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#f4efe6]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[#e8dfce] font-cinzel mb-1">Stêd:</label>
                    <input
                      type="text"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#f4efe6]"
                    />
                  </div>

                  <div>
                    <label className="block text-[#e8dfce] font-cinzel mb-1">Lân (Country):</label>
                    <select
                      value={formData.country}
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                      className="w-full px-3 py-2 rounded bg-[#09100c] border border-[#c8aa6e]/30 text-[#f4efe6]"
                    >
                      <option>Dútslân (Germany)</option>
                      <option>Nederlân (Netherlands)</option>
                      <option>Belgje (Belgium)</option>
                      <option>Denemarken (Denmark)</option>
                      <option>Eastenryk (Austria)</option>
                      <option>Switserlân (Switzerland)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {step === 'payment' && (
              <div className="space-y-4 text-xs font-sans-inter">
                <div className="p-4 bg-[#09100c] rounded border border-[#c8aa6e]/30 space-y-2">
                  <span className="font-cinzel text-[#c8aa6e] font-bold uppercase block">
                    Bestelling Samenvatting
                  </span>
                  {cart.map((item) => (
                    <div key={item.book.id} className="flex justify-between text-[#bfae93]">
                      <span>{item.quantity}x {item.book.titleOldFrisian}</span>
                      <span>€{(item.book.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-[#c8aa6e]/20 flex justify-between font-bold text-[#f4efe6]">
                    <span>Totaal bedrach:</span>
                    <span className="text-[#c8aa6e]">€{cartTotal.toFixed(2)}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="block text-[#e8dfce] font-cinzel mb-1">Betelmethode:</label>
                  <div className="space-y-2">
                    <label className="flex items-center gap-3 p-3 bg-[#09100c] rounded border border-[#c8aa6e]/30 cursor-pointer">
                      <input
                        type="radio"
                        name="payment"
                        defaultChecked
                        className="accent-[#c8aa6e]"
                      />
                      <span className="text-[#f4efe6] font-cinzel text-xs font-semibold">
                        Kredytkaart / SEPA Overboeking (Hanse Verified)
                      </span>
                    </label>
                    <label className="flex items-center gap-3 p-3 bg-[#09100c] rounded border border-[#c8aa6e]/20 cursor-pointer">
                      <input
                        type="radio"
                        name="payment"
                        className="accent-[#c8aa6e]"
                      />
                      <span className="text-[#f4efe6] font-cinzel text-xs font-semibold">
                        PayPal / Klarna Pay Later
                      </span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            <div className="pt-4 border-t border-[#c8aa6e]/20 flex justify-between items-center">
              {step === 'payment' && (
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="px-4 py-2 rounded bg-[#102218] border border-[#c8aa6e]/30 text-[#e8dfce] font-cinzel text-xs uppercase"
                >
                  Werom
                </button>
              )}

              <button
                type="submit"
                className="ml-auto px-6 py-3 rounded bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-wider hover:bg-[#e6ce8a] shadow-lg"
              >
                {step === 'shipping' ? 'Fierder nei Betelling' : 'Plaats Bestelling'}
              </button>
            </div>

          </form>
        ) : (
          <div className="text-center py-8 space-y-4">
            <div className="w-16 h-16 rounded-full bg-[#1c3225] border-2 border-[#c8aa6e] text-[#c8aa6e] flex items-center justify-center mx-auto shadow-xl">
              <Check className="w-8 h-8" />
            </div>

            <h3 className="font-blackletter text-3xl text-[#f4efe6]">
              Tank foar jo Bestelling!
            </h3>

            <p className="font-serif-cormorant text-lg text-[#bfae93] max-w-md mx-auto">
              Jo boeken meitsje har ree foar verzending per Postkoets út de Hanse-stêd Bremen.
            </p>

            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="px-8 py-3 bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold rounded-sm tracking-widest"
            >
              Werom nei Boekhûs
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
