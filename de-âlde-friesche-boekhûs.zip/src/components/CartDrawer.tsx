import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    cartTotal,
    setIsCheckoutOpen,
    showToast,
  } = useShop();

  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);

  if (!isCartOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.toUpperCase() === 'HANSE1650') {
      setDiscount(0.10); // 10% off
      showToast('Kortingskode HANSE1650 tagepast (10% koarting)!');
    } else {
      showToast('Unbekende koartingskode.');
    }
  };

  const finalTotal = cartTotal * (1 - discount);

  return (
    <div className="fixed inset-0 z-50 bg-[#09100c]/80 backdrop-blur-sm flex justify-end animate-fadeIn">
      <div className="bg-[#09100c] border-l border-[#c8aa6e]/30 w-full max-w-md h-full flex flex-col justify-between p-6 shadow-2xl relative text-[#f4efe6]">
        
        {/* Drawer Header */}
        <div className="flex justify-between items-center border-b border-[#c8aa6e]/20 pb-4">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#c8aa6e]" />
            <h2 className="font-blackletter text-2xl text-[#f4efe6]">
              Jo Winkelkoer
            </h2>
          </div>
          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1.5 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Cart Items List */}
        <div className="flex-grow overflow-y-auto py-4 space-y-4 pr-1">
          {cart.length === 0 ? (
            <div className="text-center py-16 space-y-3 text-[#bfae93]">
              <ShoppingBag className="w-12 h-12 text-[#c8aa6e] mx-auto opacity-40" />
              <p className="font-serif-cormorant text-lg italic">
                Jo winkelkoer is op dit stuit leech.
              </p>
              <button
                onClick={() => setIsCartOpen(false)}
                className="px-6 py-2 bg-[#102218] border border-[#c8aa6e]/40 text-[#c8aa6e] font-cinzel text-xs uppercase font-bold rounded-sm"
              >
                Ferken Boeken
              </button>
            </div>
          ) : (
            cart.map((item) => {
              const itemPrice = item.book.price + (item.giftWrap ? 5.00 : 0);

              return (
                <div
                  key={item.book.id}
                  className="bg-[#102218] border border-[#c8aa6e]/20 rounded-sm p-4 flex gap-4 items-center justify-between"
                >
                  <img
                    src={item.book.coverImage}
                    alt={item.book.titleOldFrisian}
                    className="w-16 h-20 object-cover rounded-sm border border-[#c8aa6e]/30 shrink-0"
                  />

                  <div className="flex-grow space-y-1 text-xs">
                    <h4 className="font-blackletter text-base text-[#f4efe6] line-clamp-1">
                      {item.book.titleOldFrisian}
                    </h4>
                    <p className="font-serif-cormorant italic text-[#c8aa6e]">
                      €{itemPrice.toFixed(2)} / eksimplaar
                    </p>

                    {item.giftWrap && (
                      <span className="inline-block px-1.5 py-0.5 bg-[#c8aa6e]/20 border border-[#c8aa6e]/40 text-[#c8aa6e] text-[9px] uppercase font-cinzel rounded">
                        Kado-ferpakking (+€5.00)
                      </span>
                    )}

                    {/* Quantity controls */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={() => updateQuantity(item.book.id, item.quantity - 1)}
                        className="w-6 h-6 bg-[#09100c] border border-[#c8aa6e]/30 rounded flex items-center justify-center text-[#f4efe6]"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-cinzel text-xs font-bold text-[#c8aa6e] w-4 text-center">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.book.id, item.quantity + 1)}
                        className="w-6 h-6 bg-[#09100c] border border-[#c8aa6e]/30 rounded flex items-center justify-center text-[#f4efe6]"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Remove Button */}
                  <button
                    onClick={() => removeFromCart(item.book.id)}
                    className="p-2 text-[#e8dfce]/60 hover:text-red-400 transition-colors"
                    title="Ferwiderje"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })
          )}
        </div>

        {/* Footer & Summary */}
        {cart.length > 0 && (
          <div className="border-t border-[#c8aa6e]/20 pt-4 space-y-4">
            
            {/* Promo code */}
            <form onSubmit={handleApplyPromo} className="flex gap-2">
              <input
                type="text"
                value={promoCode}
                onChange={(e) => setPromoCode(e.target.value)}
                placeholder="Koartingskode (e.g. HANSE1650)..."
                className="flex-grow px-3 py-1.5 rounded bg-[#102218] border border-[#c8aa6e]/30 text-xs text-[#f4efe6] placeholder-[#e8dfce]/40 font-sans-inter focus:outline-none focus:border-[#c8aa6e]"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-[#102218] border border-[#c8aa6e]/40 text-[#c8aa6e] font-cinzel text-[10px] uppercase font-bold rounded hover:border-[#c8aa6e]"
              >
                Toe-passe
              </button>
            </form>

            <div className="space-y-1.5 text-xs font-cinzel">
              <div className="flex justify-between text-[#bfae93]">
                <span>Subtotaal:</span>
                <span>€{cartTotal.toFixed(2)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-[#c8aa6e]">
                  <span>Hanse Koarting (10%):</span>
                  <span>-€{(cartTotal * discount).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-[#f4efe6] pt-1 border-t border-[#c8aa6e]/20">
                <span>Eindbedrach:</span>
                <span className="text-[#c8aa6e]">€{finalTotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => {
                setIsCheckoutOpen(true);
              }}
              className="w-full py-3.5 rounded-sm bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-widest hover:bg-[#e6ce8a] transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              <span>Naar de Kassa (Checkout)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>
    </div>
  );
};
