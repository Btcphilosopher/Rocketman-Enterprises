import React, { useState } from 'react';
import { Mail, ArrowRight, Check, Sparkles } from 'lucide-react';
import { useShop } from '../context/ShopContext';

export const Newsletter: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);
  const { showToast } = useShop();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) return;
    setSubscribed(true);
    showToast(`Tank foar jo ynskriuwing (${email})! Jo binne no Boekhûs Freon.`);
  };

  return (
    <section className="py-20 bg-[#09100c] text-[#f4efe6] relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Luxury Parchment Card with Gold Border */}
        <div className="relative rounded-sm bg-[#102218] border-2 border-[#c8aa6e] p-8 sm:p-12 shadow-[0_20px_50px_rgba(0,0,0,0.8)] dark-parchment text-center space-y-6">
          
          {/* Decorative Corner Accents */}
          <div className="absolute top-2 left-2 w-4 h-4 border-t-2 border-l-2 border-[#c8aa6e]" />
          <div className="absolute top-2 right-2 w-4 h-4 border-t-2 border-r-2 border-[#c8aa6e]" />
          <div className="absolute bottom-2 left-2 w-4 h-4 border-b-2 border-l-2 border-[#c8aa6e]" />
          <div className="absolute bottom-2 right-2 w-4 h-4 border-b-2 border-r-2 border-[#c8aa6e]" />

          <div className="w-12 h-12 rounded-full bg-[#1c3225] border border-[#c8aa6e] text-[#c8aa6e] flex items-center justify-center mx-auto shadow-inner">
            <Mail className="w-6 h-6" />
          </div>

          <div className="space-y-2">
            <span className="font-cinzel text-xs text-[#c8aa6e] uppercase tracking-widest font-bold block">
              De Hanseatyk Post & Postkoets
            </span>
            <h2 className="font-blackletter text-3xl sm:text-4xl text-[#f4efe6]">
              Wurd Freon fan De Âlde Friesche Boekhûs
            </h2>
            <p className="font-serif-cormorant text-lg text-[#bfae93] italic max-w-xl mx-auto">
              Untfang moanlikse kranyken oer seldsume hânskriften, ôfspraak-útnoegings foar kearsljocht-jûnen en eksklusiver boek-stúdzjes.
            </p>
          </div>

          {!subscribed ? (
            <form onSubmit={handleSubmit} className="max-w-md mx-auto flex flex-col sm:flex-row gap-3 pt-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Jo e-postadres (e.g. hanse@boekhus.de)..."
                className="flex-grow px-4 py-3 rounded-sm bg-[#09100c] border border-[#c8aa6e]/40 text-[#f4efe6] placeholder-[#e8dfce]/40 font-sans-inter text-xs focus:outline-none focus:border-[#c8aa6e]"
              />
              <button
                type="submit"
                className="px-6 py-3 rounded-sm bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold tracking-widest hover:bg-[#e6ce8a] transition-all whitespace-nowrap flex items-center justify-center gap-2 shadow-lg"
              >
                <span>Ynskriuwe</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            <div className="p-4 rounded bg-[#1c3225] border border-[#c8aa6e] text-[#c8aa6e] max-w-md mx-auto font-cinzel text-xs uppercase font-bold tracking-wider flex items-center justify-center gap-2">
              <Check className="w-4 h-4" />
              <span>Jo binne ynskreaun as Boekhûs Freon!</span>
            </div>
          )}

          <p className="font-sans-inter text-[11px] text-[#e8dfce]/60 pt-2">
            Wy respektearje jo privacy. Gjin spam, allinnich wysheit en kultuer.
          </p>

        </div>

      </div>
    </section>
  );
};
