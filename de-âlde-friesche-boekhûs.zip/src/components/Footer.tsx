import React, { useState } from 'react';
import { MapPin, Clock, Phone, Mail, Compass, Globe, X } from 'lucide-react';

export const Footer: React.FC = () => {
  const [showMapModal, setShowMapModal] = useState(false);

  // Structured Data JSON-LD for Search Engine Optimization
  const jsonLdData = {
    "@context": "https://schema.org",
    "@type": "BookStore",
    "name": "De Âlde Friesche Boekhûs",
    "description": "Traditional German independent bookstore in Bremen & Hamburg written in Old Frisian. Rare manuscripts, history, coffee house & literature.",
    "url": "https://de-alde-friesche-boekhus.de",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Schnoor 42 / Hanse-Allee 12",
      "addressLocality": "Bremen",
      "postalCode": "28195",
      "addressCountry": "DE"
    },
    "openingHours": "Mo-Sa 09:00-20:00",
    "priceRange": "€€€"
  };

  return (
    <footer className="bg-[#08120C] text-[#F5F2ED] border-t border-[#C5A059]/20 pt-16 pb-12 font-sans relative">
      
      {/* JSON-LD Script */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLdData) }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#C5A059]/15">
          
          {/* Col 1: Brand & Philosophy */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-[#102218] border border-[#C5A059] text-[#C5A059] flex items-center justify-center font-blackletter text-xl">
                ᚠ
              </div>
              <span className="font-serif text-2xl text-[#F5F2ED]">
                De Âlde Friesche Boekhûs
              </span>
            </div>

            <p className="font-serif text-base italic text-[#F5F2ED]/60 leading-relaxed max-w-sm">
              “In oereleaze Dútske ûnôfhinklike boekhannel mei in Fryske siel. Tradysjoneel fakwurk, middeleeuwske wetboeken en de geast fan de Hanse.”
            </p>

            <div className="pt-2 text-xs font-sans text-[#C5A059] space-y-1">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#C5A059]" />
                <span className="text-[#F5F2ED]/70">Schnoor 42, 28195 Bremen • Dútslân</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#C5A059]" />
                <span className="text-[#F5F2ED]/70">info@friesche-boekhus.de</span>
              </div>
            </div>
          </div>

          {/* Col 2: Navigation */}
          <div className="space-y-3">
            <h4 className="font-sans text-[10px] uppercase font-bold tracking-[0.2em] text-[#C5A059]">
              Navigaasje
            </h4>
            <ul className="space-y-2 text-xs font-serif text-[#F5F2ED]/60">
              <li><a href="#top" className="hover:text-[#C5A059] transition-colors">Thús (Home)</a></li>
              <li><a href="#kolleksje" className="hover:text-[#C5A059] transition-colors">Boeken & Kolleksjes</a></li>
              <li><a href="#seldsume-edysjes" className="hover:text-[#C5A059] transition-colors">Seldsume Edysjes</a></li>
              <li><a href="#lêskeamer" className="hover:text-[#C5A059] transition-colors">De Lêskeamer</a></li>
              <li><a href="#kafee" className="hover:text-[#C5A059] transition-colors">It Friesch Teehûs</a></li>
              <li><a href="#eveneminten" className="hover:text-[#C5A059] transition-colors">Eveneminten</a></li>
            </ul>
          </div>

          {/* Col 3: Iepeningstiden (Hours) */}
          <div className="space-y-3">
            <h4 className="font-sans text-[10px] uppercase font-bold tracking-[0.2em] text-[#C5A059]">
              Iepeningstiden
            </h4>
            <ul className="space-y-2 text-xs font-sans text-[#F5F2ED]/60">
              <li className="flex justify-between">
                <span>Moandei - Freed:</span>
                <span className="text-[#F5F2ED] font-semibold">09:00 - 20:00</span>
              </li>
              <li className="flex justify-between">
                <span>Sneon:</span>
                <span className="text-[#F5F2ED] font-semibold">10:00 - 18:00</span>
              </li>
              <li className="flex justify-between">
                <span>Snein:</span>
                <span className="text-[#C5A059] font-semibold">Lêskeamer Alleen</span>
              </li>
            </ul>

            <button
              onClick={() => setShowMapModal(true)}
              className="mt-3 w-full py-2 px-3 rounded-none bg-[#102218] border border-[#C5A059]/30 text-[#C5A059] hover:border-[#C5A059] font-sans text-[10px] uppercase font-bold tracking-[0.15em] transition-all flex items-center justify-center gap-1.5"
            >
              <Compass className="w-3.5 h-3.5" />
              <span>Bekijk Hanse Kaart</span>
            </button>
          </div>

          {/* Col 4: Hanse Stêden */}
          <div className="space-y-3">
            <h4 className="font-sans text-[10px] uppercase font-bold tracking-[0.2em] text-[#C5A059]">
              Hanseatyk Netwurk
            </h4>
            <p className="text-xs font-serif text-[#F5F2ED]/60 leading-relaxed">
              Wy leverje seldsume edysjes oer it gânse Hanse-netwurk: Bremen, Hamburg, Lübeck, Groningen en Leeuwarden.
            </p>
            <div className="pt-1 flex items-center gap-3 text-lg text-[#C5A059]">
              <span title="Bremen Archief">🏛️</span>
              <span title="Hanse Kogge">⛵</span>
              <span title="Scriptorium">📜</span>
              <span title="Perkamint Restauraasje">✒️</span>
            </div>
          </div>

        </div>

        {/* Bottom copyright row */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#F5F2ED]/50 gap-4 font-sans">
          <p>
            © {new Date().getFullYear()} De Âlde Friesche Boekhûs GMBH. Alle rjochten foarbehâlden.
          </p>
          <div className="flex gap-4 uppercase tracking-[0.15em] text-[9px]">
            <a href="#" className="hover:text-[#C5A059]">Privacy Wetten</a>
            <span>•</span>
            <a href="#" className="hover:text-[#C5A059]">Hanse Bepalings</a>
            <span>•</span>
            <a href="#" className="hover:text-[#C5A059]">Impressum</a>
          </div>
        </div>

      </div>

      {/* Map Modal */}
      {showMapModal && (
        <div className="fixed inset-0 z-50 bg-[#09100c]/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#102218] border border-[#c8aa6e]/50 rounded-sm max-w-xl w-full p-6 relative space-y-4 shadow-2xl">
            <button
              onClick={() => setShowMapModal(false)}
              className="absolute top-4 right-4 text-[#e8dfce]/80 hover:text-[#c8aa6e]"
            >
              <X className="w-5 h-5" />
            </button>
            
            <h3 className="font-blackletter text-2xl text-[#f4efe6]">
              Lokaasje yn de Hanse-stêd Bremen
            </h3>
            <p className="font-serif-cormorant text-sm italic text-[#c8aa6e]">
              Historische Schnoor-wyk, 28195 Bremen • Dútslân
            </p>

            <div className="aspect-[16/9] rounded border border-[#c8aa6e]/30 overflow-hidden relative">
              <img
                src="https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=1000&q=80"
                alt="Bremen Hanse Map"
                className="w-full h-full object-cover filter brightness-90"
              />
              <div className="absolute inset-0 bg-[#09100c]/40 flex items-center justify-center">
                <div className="p-3 bg-[#102218]/90 border border-[#c8aa6e] text-center rounded">
                  <span className="font-blackletter text-lg text-[#f4efe6] block">
                    De Âlde Friesche Boekhûs
                  </span>
                  <span className="font-cinzel text-xs text-[#c8aa6e] uppercase font-bold">
                    Schnoor-wyk 42
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowMapModal(false)}
              className="w-full py-2 bg-[#c8aa6e] text-[#09100c] font-cinzel text-xs uppercase font-bold rounded-sm"
            >
              Slút Kaart
            </button>
          </div>
        </div>
      )}

    </footer>
  );
};
