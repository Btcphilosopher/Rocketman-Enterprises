import React from 'react';
import { ArrowRight, Compass, BookOpen, Scroll, MapPin, Sparkles, HeartHandshake, Baby } from 'lucide-react';
import { useShop } from '../context/ShopContext';
import { CategoryId } from '../types';

interface CollectionCard {
  id: CategoryId;
  nameOldFrisian: string;
  nameGerman: string;
  description: string;
  image: string;
  count: number;
  icon: React.ReactNode;
}

const COLLECTIONS: CollectionCard[] = [
  {
    id: 'history',
    nameOldFrisian: 'Skiednis & Hanseatyk',
    nameGerman: 'Geschichte & Hanseaten',
    description: 'Âlde kroniken van de Noardsee, handelsbetrekkingen en Fryske frijheid.',
    image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=800&q=80',
    count: 24,
    icon: <Compass className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'language',
    nameOldFrisian: 'Frisian Taal & Grammatica',
    nameGerman: 'Friesische Sprache & Sprachwissenschaft',
    description: 'De ferbining tusken Âldfrysk, Âld-Ingelsk en de Germaanske wreld.',
    image: 'https://images.unsplash.com/photo-1461360370896-922624d12aa1?auto=format&fit=crop&w=800&q=80',
    count: 16,
    icon: <Scroll className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'philosophy',
    nameOldFrisian: 'Wysheit & Filosofy',
    nameGerman: 'Philosophie & Küsten-Stoa',
    description: 'Nije en klassike ferhannelings oer minsk, natuer en oereleaze stilte.',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?auto=format&fit=crop&w=800&q=80',
    count: 19,
    icon: <BookOpen className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'poetry',
    nameOldFrisian: 'Lietboeken & Poëzij',
    nameGerman: 'Poesie & Friesische Lyrik',
    description: 'Siel-ferhalen en rimeryen oer de Wadden, kearsjûnen en de seewyn.',
    image: 'https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=800&q=80',
    count: 14,
    icon: <Sparkles className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'maps',
    nameOldFrisian: 'Kartografy & Atlasen',
    nameGerman: 'Historische Karten & Atlanten',
    description: 'Kopergravueres en hânkleure kaarten fan de 16e oant 18e iuw.',
    image: 'https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?auto=format&fit=crop&w=800&q=80',
    count: 11,
    icon: <MapPin className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'rare',
    nameOldFrisian: 'Seldsume Hânskriften',
    nameGerman: 'Rara & Handschriften (13. - 17. Jh.)',
    description: 'Perkamint-edysjes mei goudblêd, fergulde slutingen en leginden.',
    image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80',
    count: 8,
    icon: <Sparkles className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'classics',
    nameOldFrisian: 'Klassiken & Sagen',
    nameGerman: 'Klassiker & Volkssagen',
    description: 'Ferhale-keunst fan foarfaars en de obskuere geasten fan it Rungholt.',
    image: 'https://images.unsplash.com/photo-1516979187457-637abb4f9353?auto=format&fit=crop&w=800&q=80',
    count: 22,
    icon: <HeartHandshake className="w-5 h-5 text-[#c8aa6e]" />
  },
  {
    id: 'children',
    nameOldFrisian: 'Lytse Lêzers (Children)',
    nameGerman: 'Friesische Kinderbücher',
    description: 'Hân-yllustrearre bânen mei leginden foar de jongste Fryske sielen.',
    image: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?auto=format&fit=crop&w=800&q=80',
    count: 12,
    icon: <Baby className="w-5 h-5 text-[#c8aa6e]" />
  }
];

export const FeaturedCollections: React.FC = () => {
  const { setSelectedCategory } = useShop();

  const handleSelectCategory = (catId: CategoryId) => {
    setSelectedCategory(catId);
    const elem = document.getElementById('nije-oankomsten');
    if (elem) elem.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="kolleksje" className="py-20 bg-[#0A1610] text-[#F5F2ED] relative border-b border-[#C5A059]/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between pb-12 mb-12 border-b border-[#C5A059]/15 gap-4">
          <div>
            <span className="text-[#C5A059] text-[10px] uppercase tracking-[0.4em] font-sans font-bold block mb-2">
              Ûs Tema’s & Kolleksjes
            </span>
            <h2 className="font-serif italic text-4xl sm:text-5xl text-[#F5F2ED] tracking-tight">
              Boeken fan Wysheit & Skiednis
            </h2>
          </div>
          <p className="font-serif text-base text-[#F5F2ED]/50 italic max-w-md">
            Fan middeleeuwske siel-hânskriften oant Hanseatyk kartografy en Dútsk-Fryske filosoof-boeken.
          </p>
        </div>

        {/* Grid of Editorial Collection Cards with Index Numbers */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 border border-[#C5A059]/15 bg-[#102218] divide-y lg:divide-y-0 lg:divide-x divide-[#C5A059]/15">
          {COLLECTIONS.map((item, idx) => {
            const indexStr = (idx + 1).toString().padStart(2, '0');
            return (
              <div
                key={item.id}
                onClick={() => handleSelectCategory(item.id)}
                className="p-8 hover:bg-[#C5A059]/5 transition-colors cursor-pointer group flex flex-col justify-between relative"
              >
                <div>
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-[#C5A059] text-[10px] uppercase tracking-[0.3em] font-sans font-bold">
                      {indexStr}
                    </span>
                    <span className="text-[10px] tracking-wider uppercase font-sans text-[#C5A059]/70 bg-[#08120C] px-2 py-0.5 rounded border border-[#C5A059]/20">
                      {item.count} Boeken
                    </span>
                  </div>

                  <h3 className="text-2xl font-serif text-[#F5F2ED] group-hover:text-[#C5A059] transition-colors mb-2 leading-tight">
                    {item.nameOldFrisian}
                  </h3>

                  <p className="font-sans text-[10px] text-[#C5A059] uppercase tracking-[0.2em] mb-3 font-semibold">
                    {item.nameGerman}
                  </p>

                  <p className="font-serif text-xs text-[#F5F2ED]/50 leading-relaxed line-clamp-3">
                    {item.description}
                  </p>
                </div>

                <div className="mt-8">
                  <div className="flex items-center gap-2 font-sans text-[10px] uppercase tracking-[0.2em] text-[#C5A059] font-bold">
                    <span>Bekijk Kolleksje</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                  {/* Subtle underline border animation */}
                  <div className="mt-4 h-px w-0 group-hover:w-full bg-[#C5A059] transition-all duration-500" />
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
