export interface DictionaryPhrase {
  oldFrisian: string;
  pronunciation: string;
  german: string;
  english: string;
  context: string;
}

export const DICTIONARY_PHRASES: DictionaryPhrase[] = [
  {
    oldFrisian: 'Wolkom yn De Âlde Friesche Boekhûs',
    pronunciation: 'Wahl-kom in Duh Ahl-duh Free-shuh Book-hoos',
    german: 'Willkommen im Alten Friesischen Buchhaus',
    english: 'Welcome to the Old Frisian Book House',
    context: 'Tradysjonele Fryske wolkom hjitten foar gasten dy\'t de winkel ynstappe.'
  },
  {
    oldFrisian: 'Boeken fan Wysheit, Skiednis en Siel',
    pronunciation: 'Book-en fahn Vees-hite, Skee-dnis en Seel',
    german: 'Bücher der Weisheit, Geschichte und Seele',
    english: 'Books of Wisdom, History and Soul',
    context: 'It motto fan de boekhannel op de foargevel yn Bremen.'
  },
  {
    oldFrisian: 'Freon fan it Wurd',
    pronunciation: 'Fray-on fahn it Voord',
    german: 'Freund des Wortes',
    english: 'Friend of the Word / Scholar',
    context: 'Eretitel foar fêste lêzers en leden fan it Boekhûs.'
  },
  {
    oldFrisian: 'De Frysk sil frij wêze sa lang’t de wyn waait',
    pronunciation: 'Duh Free-sk sil fray vay-zuh sah lahn-gt duh veen veye-t',
    german: 'Der Friese soll frei sein, solange der Wind weht',
    english: 'The Frisian shall be free as long as the wind blows',
    context: 'De Âldfryske rjochtspreuk fan it Lex Frisionum út de 9e iuw.'
  },
  {
    oldFrisian: 'Thús, Boeken en Kofje',
    pronunciation: 'Toos, Book-en en Koh-fyuh',
    german: 'Zuhause, Bücher und Kaffee',
    english: 'Home, Books, and Coffee',
    context: 'De trije pylders fan de lêskeamer.'
  }
];

export const HERITAGE_ARTICLES = [
  {
    id: 'h1',
    titleOldFrisian: 'De Âldfryske Taal & de Hanseatyk',
    titleGerman: 'Altfriesisch im Hanseeraum',
    content: `Yn de Midsiuwen wie it Âldfrysk net allinnich de taal fan de Fryske marren en kwelders, mar in wittenskiplike en juridyske taal dy't oant yn Hamburg, Bremen en de Baltyske havens te hearren wie. De Fryske hannelers farden op de Kogges fan de Hanse en brochten hânskriften, parcaminten en wetboeken mei oer de hiele Noardsee.`,
    manuscriptIllustration: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'h2',
    titleOldFrisian: 'It Restaurearjen fan Seldsume Boeken',
    titleGerman: 'Die Kunst der Hanseatischen Buchrestaurierung',
    content: `Yn it atelier achter ús lêskeamer wurde âlde banden fan leder en eikenhout mei de hân restaurearre. Elk boek wurdt behannele mei natuerlike waaks, goudfolie en tradisjoneel bining-garen dat al fjouwer iuwen lang brûkt wurdt.`,
    manuscriptIllustration: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&w=800&q=80'
  }
];
