import { EventItem } from '../types';

export const EVENTS: EventItem[] = [
  {
    id: 'e1',
    titleOldFrisian: 'De Nacht fan de Âlde Manuscripts & Perkamint',
    titleGerman: 'Die Hanseatische Pergament-Nacht',
    date: '18. Oktober 2026',
    time: '19:30 - 23:00',
    location: 'De Âlde Boekhûs - Grote Keamer & Lês-zaal, Bremen / Hamburg',
    speaker: 'Prof. Dr. Janneke van der Wall & Restaurearder Gabriel Hanz',
    category: 'Skiednis-lesing',
    price: 35.00,
    totalSeats: 30,
    bookedSeats: 22,
    description: 'In eksklusiver jûn mei ekspert-restauraasje fan 13e-ieuske hânskriften by kearsljocht. Wy iepenje it kluis fan seldsume papieren en proefje orizjinele Frisian likeur.',
    image: 'https://images.unsplash.com/photo-1507842229565-8a496b46187f?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'e2',
    titleOldFrisian: 'Frysk Taal-syndikaat: Âldfrysk foar Begjinnend Wittenskip',
    titleGerman: 'Altfriesisch-Workshop für Linguisten & Liebhaber',
    date: '02. November 2026',
    time: '14:00 - 18:00',
    location: 'Studiezaal de Hanse',
    speaker: 'Dr. Sytze fan Staveren',
    category: 'Taalsyndikaat',
    price: 45.00,
    totalSeats: 20,
    bookedSeats: 15,
    description: 'Learje de spraakkunst, runen-tekens en klankrjochten fan it klassike Âldfrysk yn fergelyk mei it Âld-Ingelsk en Âld-Saksysk. Inklusyf perkamint en inket-set.',
    image: 'https://images.unsplash.com/photo-1455390582262-044cdead277a?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'e3',
    titleOldFrisian: 'Poëzij-jûn by Kears & Kofje: De Lûden fan de Wadden',
    titleGerman: 'Friesische Poesienacht & Tee-Ceremonie',
    date: '21. November 2026',
    time: '20:00 - 22:30',
    location: 'It Friesch Koffy- & Teehûs',
    speaker: 'Dichteresse Marrit von Jever & Mûsikant Lennart Hanz',
    category: 'Poëzij-jûn',
    price: 25.00,
    totalSeats: 35,
    bookedSeats: 28,
    description: 'Resitaasjes fan 17e-ieuske Fryske gedichten begelaat troch de lút en klavesimbel. Tsjinne mei tradisjonele East-Fryske tee mei Kluntje en Sahne.',
    image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'e4',
    titleOldFrisian: 'Boekpresintaasje: Atlas Kartografia Frisia 1650',
    titleGerman: 'Buchpräsentation: Grosser Friesischer Hanse-Atlas',
    date: '05. Dezember 2026',
    time: '18:00 - 21:00',
    location: 'Grote Galerij',
    speaker: 'Kartograaf Henk van de Weser',
    category: 'Boekpresintaasje',
    price: 20.00,
    totalSeats: 40,
    bookedSeats: 38,
    description: 'De ûnthulling fan in nij facsimile-útjefte fan de Blaeu-kaart fan de Fryske Noardseekust. Mei in lezing oer de Hanseatyk kartografy.',
    image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=800&q=80'
  }
];
