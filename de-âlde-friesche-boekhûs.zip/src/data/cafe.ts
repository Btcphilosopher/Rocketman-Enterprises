import { CafeItem } from '../types';

export const CAFE_ITEMS: CafeItem[] = [
  {
    id: 'c1',
    nameOldFrisian: 'East-Fryske Tee-Serymonje mei Kluntje',
    nameGerman: 'Ostfriesische Tee-Zeremonie mit Kluntje & Sahne',
    category: 'thee',
    price: 6.80,
    description: 'Echte East-Fryske Assam-blend tsjinne yn in porslein poske mei in kandij-stien (Kluntje) en in wolkje fryske room (Sahne), net roerd.',
    authenticDetails: 'Tradisjoneel tsjinne mei in silver leppelke en in lyts Fryske bûterkoekje.',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'c2',
    nameOldFrisian: 'Eiken-Boekhûs Filter Kofje',
    nameGerman: 'Bremer Hanse Filterkaffee aus der Kupferkanne',
    category: 'koffie',
    price: 4.90,
    description: 'Stadich opgûne filterkofje fan bio-boanen, geroostere yn in 19e-ieuske rosterij by de Weser-kaai.',
    authenticDetails: 'Skaaimerk: Notige smaak, tsjinne yn in swier ierdewurk kopke.',
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'c3',
    nameOldFrisian: 'Fryske Sûkerbôle mei Amandel-Bûter',
    nameGerman: 'Friesisches Zuckerbrot mit Mandelbutter',
    category: 'gebak',
    price: 5.50,
    description: 'Waarm Fryske sûkerbôle mei karamellisearre sûker-stikken en in touch fan kaniel en gember, tsjinne mei hânkarne bûter.',
    authenticDetails: 'Bakt folgens in famyljeresept út 1888.',
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'c4',
    nameOldFrisian: 'Friesentorte mei Pruimen & Room',
    nameGerman: 'Klassische Friesentorte mit Pflaumenmus & Baiser',
    category: 'gebak',
    price: 6.90,
    description: 'Machtige Noard-Fryske taart fan knapperich bladerdeeg, pruimemusse en farske room mei in touch fan kardemom.',
    authenticDetails: 'De favoryt fan ús lêzers yn de Grote Keamer.',
    image: 'https://images.unsplash.com/photo-1535141192574-5d4897c13136?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'c5',
    nameOldFrisian: 'Doperske Kardemom-Brea',
    nameGerman: 'Hanseatisches Kardamom-Roggenbrot',
    category: 'brea',
    price: 4.20,
    description: 'Mûtse-roggeburch brea mei kardemom, spysker-oalje en âlde Fryske tsiis.',
    authenticDetails: 'Ideaal by in glês donkere Fryske porter as krûdetee.',
    image: 'https://images.unsplash.com/photo-1586444248902-2f64eddc13df?auto=format&fit=crop&w=800&q=80'
  }
];
