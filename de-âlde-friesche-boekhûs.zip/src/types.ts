export type CategoryId = 
  | 'all'
  | 'history' 
  | 'language' 
  | 'philosophy' 
  | 'poetry' 
  | 'maps' 
  | 'classics' 
  | 'rare' 
  | 'children';

export interface Book {
  id: string;
  titleOldFrisian: string;
  titleGerman: string;
  titleEnglish: string;
  author: string;
  year: number;
  category: CategoryId;
  price: number;
  originalPrice?: number;
  rareEdition: boolean;
  isNewArrival: boolean;
  featured: boolean;
  coverImage: string;
  description: string;
  pages: number;
  languageNotes: string;
  rating: number;
  reviewsCount: number;
  stock: number;
  binding: 'Leder yn Goud' | 'Perkamint' | 'Eiken Hout' | 'Linnen' | 'Klassyk Papier';
  isbn: string;
  illuminated: boolean;
  excerpt: string;
  provenance?: string;
}

export interface CartItem {
  book: Book;
  quantity: number;
  giftWrap: boolean;
  personalizedInscription?: string;
}

export interface WishlistItem {
  book: Book;
  addedAt: string;
}

export interface EventItem {
  id: string;
  titleOldFrisian: string;
  titleGerman: string;
  date: string;
  time: string;
  location: string;
  speaker: string;
  category: 'Boekpresintaasje' | 'Poëzij-jûn' | 'Taalsyndikaat' | 'Skiednis-lesing';
  price: number;
  totalSeats: number;
  bookedSeats: number;
  description: string;
  image: string;
}

export interface CafeItem {
  id: string;
  nameOldFrisian: string;
  nameGerman: string;
  category: 'koffie' | 'thee' | 'gebak' | 'brea';
  price: number;
  description: string;
  authenticDetails: string;
  image: string;
}

export interface Review {
  id: string;
  bookId: string;
  authorName: string;
  rating: number;
  date: string;
  comment: string;
  location: string;
}

export interface UserOrder {
  orderId: string;
  date: string;
  items: CartItem[];
  total: number;
  status: 'In bewurking' | 'Ferstjoerd' | 'Oankommen';
  trackingNumber: string;
}
