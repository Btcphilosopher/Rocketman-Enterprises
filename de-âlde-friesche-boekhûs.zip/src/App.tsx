/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ShopProvider } from './context/ShopContext';
import { Navigation } from './components/Navigation';
import { Hero } from './components/Hero';
import { AssurancesBar } from './components/AssurancesBar';
import { FeaturedCollections } from './components/FeaturedCollections';
import { NewArrivals } from './components/NewArrivals';
import { RareEditions } from './components/RareEditions';
import { ReadingRoom } from './components/ReadingRoom';
import { CafeSection } from './components/CafeSection';
import { EventsTimeline } from './components/EventsTimeline';
import { HeritageSection } from './components/HeritageSection';
import { Newsletter } from './components/Newsletter';
import { Footer } from './components/Footer';
import { QuickViewModal } from './components/QuickViewModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistModal } from './components/WishlistModal';
import { AccountModal } from './components/AccountModal';
import { SearchModal } from './components/SearchModal';
import { ToastNotification } from './components/ToastNotification';

export default function App() {
  return (
    <ShopProvider>
      <div className="min-h-screen bg-[#102218] text-[#F5F2ED] font-serif selection:bg-[#C5A059]/30 selection:text-[#F5F2ED]">
        {/* Sticky Header Navigation */}
        <Navigation />

        {/* Hero Section */}
        <Hero />

        {/* Assurances Ribbon */}
        <AssurancesBar />

        {/* Featured Editorial Collections */}
        <FeaturedCollections />

        {/* New Arrivals & Main Book Grid */}
        <NewArrivals />

        {/* Rare Editions Magazine Section */}
        <RareEditions />

        {/* Reading Room & Quiet Sanctuary */}
        <ReadingRoom />

        {/* It Friesch Koffy- & Teehûs (Café) */}
        <CafeSection />

        {/* Events Timeline */}
        <EventsTimeline />

        {/* Old Frisian Heritage & Interactive Phrasebook */}
        <HeritageSection />

        {/* Luxury Newsletter */}
        <Newsletter />

        {/* Dark Minimal Footer */}
        <Footer />

        {/* Modals & Overlays */}
        <QuickViewModal />
        <CartDrawer />
        <CheckoutModal />
        <WishlistModal />
        <AccountModal />
        <SearchModal />
        <ToastNotification />
      </div>
    </ShopProvider>
  );
}
