import React, { createContext, useContext, useState, useEffect } from 'react';
import { Book, CartItem, WishlistItem, UserOrder } from '../types';
import { BOOKS } from '../data/books';

interface ShopContextType {
  cart: CartItem[];
  wishlist: WishlistItem[];
  userOrders: UserOrder[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  quickViewBook: Book | null;
  setQuickViewBook: (book: Book | null) => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isWishlistOpen: boolean;
  setIsWishlistOpen: (open: boolean) => void;
  isAccountOpen: boolean;
  setIsAccountOpen: (open: boolean) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  ambientSoundPlaying: boolean;
  toggleAmbientSound: () => void;
  addToCart: (book: Book, giftWrap?: boolean, personalizedInscription?: string) => void;
  removeFromCart: (bookId: string) => void;
  updateQuantity: (bookId: string, quantity: number) => void;
  toggleWishlist: (book: Book) => void;
  isInWishlist: (bookId: string) => boolean;
  cartTotal: number;
  cartCount: number;
  placeOrder: (shippingDetails: any) => UserOrder;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('alde_friesche_cart');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<WishlistItem[]>(() => {
    try {
      const saved = localStorage.getItem('alde_friesche_wishlist');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [userOrders, setUserOrders] = useState<UserOrder[]>(() => {
    try {
      const saved = localStorage.getItem('alde_friesche_orders');
      return saved ? JSON.parse(saved) : [
        {
          orderId: 'AFB-1650-892',
          date: '14. Juli 2026',
          items: [{ book: BOOKS[0], quantity: 1, giftWrap: true }],
          total: 345.00,
          status: 'Ferstjoerd',
          trackingNumber: 'HANSE-DE-892347-FY'
        }
      ];
    } catch (e) {
      return [];
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [quickViewBook, setQuickViewBook] = useState<Book | null>(null);

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isAccountOpen, setIsAccountOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [ambientSoundPlaying, setAmbientSoundPlaying] = useState(false);
  const [audioCtx, setAudioCtx] = useState<AudioContext | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('alde_friesche_cart', JSON.stringify(cart));
    } catch (e) {}
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('alde_friesche_wishlist', JSON.stringify(wishlist));
    } catch (e) {}
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem('alde_friesche_orders', JSON.stringify(userOrders));
    } catch (e) {}
  }, [userOrders]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const addToCart = (book: Book, giftWrap = false, personalizedInscription = '') => {
    setCart((prev) => {
      const existing = prev.find((item) => item.book.id === book.id);
      if (existing) {
        return prev.map((item) =>
          item.book.id === book.id
            ? { ...item, quantity: item.quantity + 1, giftWrap: giftWrap || item.giftWrap }
            : item
        );
      }
      return [...prev, { book, quantity: 1, giftWrap, personalizedInscription }];
    });
    showToast(`"${book.titleOldFrisian}" is tafoege oan jo winkelkoer.`);
  };

  const removeFromCart = (bookId: string) => {
    setCart((prev) => prev.filter((item) => item.book.id !== bookId));
  };

  const updateQuantity = (bookId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(bookId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.book.id === bookId ? { ...item, quantity } : item))
    );
  };

  const toggleWishlist = (book: Book) => {
    setWishlist((prev) => {
      const exists = prev.some((item) => item.book.id === book.id);
      if (exists) {
        showToast(`"${book.titleOldFrisian}" ferwidere út bewarre boeken.`);
        return prev.filter((item) => item.book.id !== book.id);
      } else {
        showToast(`"${book.titleOldFrisian}" tafoege oan jo bewarre boeken.`);
        return [...prev, { book, addedAt: new Date().toLocaleDateString('fy-NL') }];
      }
    });
  };

  const isInWishlist = (bookId: string) => {
    return wishlist.some((item) => item.book.id === bookId);
  };

  const cartTotal = cart.reduce((sum, item) => {
    const giftCost = item.giftWrap ? 5.00 : 0;
    return sum + (item.book.price + giftCost) * item.quantity;
  }, 0);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const placeOrder = (shippingDetails: any): UserOrder => {
    const newOrder: UserOrder = {
      orderId: `AFB-${Math.floor(1000 + Math.random() * 9000)}-${new Date().getFullYear()}`,
      date: new Date().toLocaleDateString('de-DE', { day: '2-digit', month: 'long', year: 'numeric' }),
      items: [...cart],
      total: cartTotal,
      status: 'In bewurking',
      trackingNumber: `HANSE-FY-${Math.floor(100000 + Math.random() * 900000)}`
    };

    setUserOrders((prev) => [newOrder, ...prev]);
    setCart([]);
    setIsCheckoutOpen(false);
    setIsCartOpen(false);
    showToast(`Tank foar jo bestelling! Bestelnûmer: ${newOrder.orderId}`);
    return newOrder;
  };

  // Web Audio ambient fireplace & page soundscape synthesizer
  const toggleAmbientSound = () => {
    if (ambientSoundPlaying) {
      if (audioCtx) {
        audioCtx.close();
        setAudioCtx(null);
      }
      setAmbientSoundPlaying(false);
      showToast('Lêskeamer lûden útset.');
    } else {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        
        // Soft white noise buffer for fireplace crackle & paper rustle
        const bufferSize = ctx.sampleRate * 2;
        const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = ctx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        // Bandpass filter to sound like warm fireplace & paper
        const filter = ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 450;
        filter.Q.value = 1.2;

        const gainNode = ctx.createGain();
        gainNode.gain.value = 0.025; // Quiet background warmth

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(ctx.destination);

        whiteNoise.start();
        setAudioCtx(ctx);
        setAmbientSoundPlaying(true);
        showToast('Lêskeamer lûden oan (Kearsljocht & Knapperend Hout).');
      } catch (err) {
        console.error(err);
      }
    }
  };

  return (
    <ShopContext.Provider
      value={{
        cart,
        wishlist,
        userOrders,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        quickViewBook,
        setQuickViewBook,
        isCartOpen,
        setIsCartOpen,
        isWishlistOpen,
        setIsWishlistOpen,
        isAccountOpen,
        setIsAccountOpen,
        isSearchOpen,
        setIsSearchOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        ambientSoundPlaying,
        toggleAmbientSound,
        addToCart,
        removeFromCart,
        updateQuantity,
        toggleWishlist,
        isInWishlist,
        cartTotal,
        cartCount,
        placeOrder,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) throw new Error('useShop must be used within ShopProvider');
  return context;
};
