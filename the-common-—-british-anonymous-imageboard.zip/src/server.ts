import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

import { INITIAL_BOARDS, Board, Thread, Post, Report, AuditLog, Attachment } from './server/data';
import { INITIAL_THREADS, INITIAL_REPORTS, INITIAL_AUDIT_LOGS, formatUkBoardDate } from './server/seed-threads';

// In-memory runtime database for The Common
const boards: Board[] = [...INITIAL_BOARDS];
const threads: Thread[] = JSON.parse(JSON.stringify(INITIAL_THREADS));
const reports: Report[] = [...INITIAL_REPORTS];
const auditLogs: AuditLog[] = [...INITIAL_AUDIT_LOGS];

let nextPostId = 4918900;
let nextThreadId = 10500;
const activeUsersCount = 12427;

// Helper to parse >>123456 quotes from comment text
function extractQuotedPostIds(text: string): number[] {
  const matches = text.match(/>>(\d+)/g);
  if (!matches) return [];
  const ids = matches.map(m => parseInt(m.replace('>>', ''), 10));
  return Array.from(new Set(ids));
}

// Generate pseudonymous hash for thread (e.g. "aB84x")
function generateAnonId(threadId: number, seed: string): string {
  let hash = 0;
  const str = `anon-${threadId}-${seed}`;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  const hex = Math.abs(hash).toString(16).padStart(6, '0').slice(-6);
  return hex;
}

app.use(express.json({ limit: '15mb' }));

/**
 * REST API ENDPOINTS FOR THE COMMON
 */

// 1. Get platform stats
app.get('/api/v1/stats', (req, res) => {
  const totalPosts = boards.reduce((acc, b) => acc + b.postCount, 0);
  const totalThreads = threads.length;
  res.json({
    totalPosts,
    totalThreads,
    activeBoards: boards.length,
    onlineUsers: activeUsersCount + Math.floor(Math.random() * 20 - 10),
    serverGmt: formatUkBoardDate(new Date())
  });
});

// 2. List all boards
app.get('/api/v1/boards', (req, res) => {
  res.json(boards);
});

// 3. Get single board details
app.get('/api/v1/boards/:slug', (req, res) => {
  const board = boards.find(b => b.slug.toLowerCase() === req.params.slug.toLowerCase());
  if (!board) {
    res.status(404).json({ error: 'Board not found' });
    return;
  }
  res.json(board);
});

// 4. List threads (supports board filter, search, sort: bump/new/replies/images, catalogue/classic)
app.get('/api/v1/threads', (req, res) => {
  const boardSlug = req.query['board'] as string | undefined;
  const searchQuery = (req.query['search'] as string || '').toLowerCase().trim();
  const sort = (req.query['sort'] as string || 'bump');
  const archived = req.query['archived'] === 'true';

  let list = [...threads];

  if (boardSlug && boardSlug !== 'all') {
    list = list.filter(t => t.boardSlug.toLowerCase() === boardSlug.toLowerCase());
  }

  if (archived) {
    list = list.filter(t => t.isArchived);
  } else {
    list = list.filter(t => !t.isArchived);
  }

  if (searchQuery) {
    list = list.filter(t => {
      const matchSubject = t.subject.toLowerCase().includes(searchQuery);
      const matchBoard = t.boardSlug.toLowerCase().includes(searchQuery);
      const matchPosts = t.posts.some(p => p.comment.toLowerCase().includes(searchQuery));
      return matchSubject || matchBoard || matchPosts;
    });
  }

  // Sorting
  if (sort === 'bump') {
    // Stickies first, then last bump
    list.sort((a, b) => {
      if (a.isSticky && !b.isSticky) return -1;
      if (!a.isSticky && b.isSticky) return 1;
      return b.lastBumpAt - a.lastBumpAt;
    });
  } else if (sort === 'new') {
    list.sort((a, b) => b.id - a.id);
  } else if (sort === 'replies') {
    list.sort((a, b) => b.replyCount - a.replyCount);
  } else if (sort === 'images') {
    list.sort((a, b) => b.imageCount - a.imageCount);
  }

  res.json(list);
});

// 5. Get thread detail by ID
app.get('/api/v1/threads/:id', (req, res) => {
  const threadId = parseInt(req.params.id, 10);
  const thread = threads.find(t => t.id === threadId);
  if (!thread) {
    res.status(404).json({ error: 'Thread not found' });
    return;
  }
  res.json(thread);
});

// 6. Create new thread
app.post('/api/v1/threads', (req, res) => {
  const { boardSlug, subject, comment, author, attachment } = req.body;

  if (!boardSlug || !comment) {
    res.status(400).json({ error: 'Board and comment are required' });
    return;
  }

  const board = boards.find(b => b.slug.toLowerCase() === boardSlug.toLowerCase());
  if (!board) {
    res.status(404).json({ error: 'Board does not exist' });
    return;
  }

  const threadId = nextThreadId++;
  const postId = nextPostId++;
  const now = Date.now();
  const dateStr = formatUkBoardDate(new Date(now));
  const anonId = generateAnonId(threadId, (author || 'Anon') + now);

  const opPost: Post = {
    id: postId,
    threadId,
    boardSlug: board.slug,
    isOp: true,
    subject: subject || (comment.slice(0, 50) + '...'),
    author: (author && author.trim()) ? author.trim() : 'Anonymous',
    authorId: anonId,
    createdAt: dateStr,
    timestamp: now,
    comment: comment.trim(),
    attachment: attachment || undefined,
    replyToIds: [],
    repliesFromIds: []
  };

  const newThread: Thread = {
    id: threadId,
    boardSlug: board.slug,
    subject: opPost.subject || 'Untitled Thread',
    opPostId: postId,
    createdAt: dateStr,
    lastBumpAt: now,
    replyCount: 0,
    imageCount: attachment ? 1 : 0,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [opPost]
  };

  threads.unshift(newThread);
  board.threadCount += 1;
  board.postCount += 1;

  res.status(201).json(newThread);
});

// 7. Post a reply to a thread
app.post('/api/v1/threads/:id/replies', (req, res) => {
  const threadId = parseInt(req.params.id, 10);
  const thread = threads.find(t => t.id === threadId);

  if (!thread) {
    res.status(404).json({ error: 'Thread not found' });
    return;
  }

  if (thread.isLocked) {
    res.status(403).json({ error: 'Thread is locked. No replies permitted.' });
    return;
  }

  const { comment, author, attachment } = req.body;
  if (!comment && !attachment) {
    res.status(400).json({ error: 'Comment or image required' });
    return;
  }

  const postId = nextPostId++;
  const now = Date.now();
  const dateStr = formatUkBoardDate(new Date(now));
  const quotedIds = extractQuotedPostIds(comment || '');

  const anonId = generateAnonId(thread.id, (author || 'Anon') + (req.ip || 'ip'));

  const newPost: Post = {
    id: postId,
    threadId,
    boardSlug: thread.boardSlug,
    isOp: false,
    author: (author && author.trim()) ? author.trim() : 'Anonymous',
    authorId: anonId,
    createdAt: dateStr,
    timestamp: now,
    comment: (comment || '').trim(),
    attachment: attachment || undefined,
    replyToIds: quotedIds,
    repliesFromIds: []
  };

  // Update backlinks on existing posts in the thread
  for (const qId of quotedIds) {
    const targetPost = thread.posts.find(p => p.id === qId);
    if (targetPost && !targetPost.repliesFromIds.includes(postId)) {
      targetPost.repliesFromIds.push(postId);
    }
  }

  thread.posts.push(newPost);
  thread.replyCount += 1;
  if (attachment) {
    thread.imageCount += 1;
  }

  // Bump thread if within bump limit
  const board = boards.find(b => b.slug === thread.boardSlug);
  const bumpLimit = board ? board.bumpLimit : 350;
  if (thread.replyCount < bumpLimit) {
    thread.lastBumpAt = now;
  }

  if (board) {
    board.postCount += 1;
  }

  res.status(201).json(newPost);
});

// 8. Submit report
app.post('/api/v1/reports', (req, res) => {
  const { postId, threadId, boardSlug, reason, details } = req.body;
  if (!postId || !reason) {
    res.status(400).json({ error: 'Post ID and reason are required' });
    return;
  }

  const newReport: Report = {
    id: `rep-${Date.now()}`,
    postId: Number(postId),
    threadId: Number(threadId || 0),
    boardSlug: boardSlug || 'uk',
    reason: reason,
    details: details || 'No additional comment provided',
    createdAt: formatUkBoardDate(new Date()),
    status: 'pending'
  };

  reports.unshift(newReport);
  res.status(201).json({ message: 'Report submitted for review', report: newReport });
});

// 9. Moderation endpoints
app.get('/api/v1/moderation/reports', (req, res) => {
  res.json(reports);
});

app.get('/api/v1/moderation/audit-logs', (req, res) => {
  res.json(auditLogs);
});

app.post('/api/v1/moderation/action', (req, res) => {
  const { action, targetId, reason, moderator } = req.body;
  const modName = moderator || 'Board Moderator';
  const nowStr = formatUkBoardDate(new Date());

  if (action === 'delete-post') {
    const pId = Number(targetId);
    for (const t of threads) {
      const idx = t.posts.findIndex(p => p.id === pId);
      if (idx !== -1) {
        t.posts[idx].moderated = true;
        t.posts[idx].comment = '[This post was removed by a moderator for violating British internet decency / board rules]';
        t.posts[idx].attachment = undefined;
        auditLogs.unshift({
          id: `audit-${Date.now()}`,
          moderator: modName,
          action: 'Delete Post',
          targetId: String(pId),
          targetType: 'post',
          timestamp: nowStr,
          reason: reason || 'Community standards violation'
        });
        res.json({ success: true, message: `Post #${pId} removed` });
        return;
      }
    }
    res.status(404).json({ error: 'Post not found' });
    return;
  }

  if (action === 'toggle-sticky') {
    const tId = Number(targetId);
    const t = threads.find(x => x.id === tId);
    if (t) {
      t.isSticky = !t.isSticky;
      auditLogs.unshift({
        id: `audit-${Date.now()}`,
        moderator: modName,
        action: t.isSticky ? 'Sticky Thread' : 'Unsticky Thread',
        targetId: String(tId),
        targetType: 'thread',
        timestamp: nowStr,
        reason: reason || 'Moderator preference'
      });
      res.json({ success: true, isSticky: t.isSticky });
      return;
    }
  }

  if (action === 'toggle-lock') {
    const tId = Number(targetId);
    const t = threads.find(x => x.id === tId);
    if (t) {
      t.isLocked = !t.isLocked;
      auditLogs.unshift({
        id: `audit-${Date.now()}`,
        moderator: modName,
        action: t.isLocked ? 'Lock Thread' : 'Unlock Thread',
        targetId: String(tId),
        targetType: 'thread',
        timestamp: nowStr,
        reason: reason || 'Prevent off-topic flame war'
      });
      res.json({ success: true, isLocked: t.isLocked });
      return;
    }
  }

  if (action === 'resolve-report') {
    const report = reports.find(r => r.id === targetId);
    if (report) {
      report.status = 'resolved';
      res.json({ success: true });
      return;
    }
  }

  if (action === 'dismiss-report') {
    const report = reports.find(r => r.id === targetId);
    if (report) {
      report.status = 'dismissed';
      res.json({ success: true });
      return;
    }
  }

  res.status(400).json({ error: 'Unknown moderation action' });
});

// 10. Image upload simulation with EXIF stripping and dimensions
app.post('/api/v1/upload', (req, res) => {
  const { fileName, dataUrl, sizeBytes, width, height } = req.body;
  if (!dataUrl) {
    res.status(400).json({ error: 'Missing image payload' });
    return;
  }

  const att: Attachment = {
    id: `att-${Date.now()}`,
    url: dataUrl,
    thumbnailUrl: dataUrl,
    fileName: fileName || `image_${Date.now()}.jpg`,
    fileSize: `${Math.round((sizeBytes || 250000) / 1024)} KB`,
    dimensions: `${width || 1280}x${height || 720}`,
    type: 'image/jpeg'
  };

  res.json(att);
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
