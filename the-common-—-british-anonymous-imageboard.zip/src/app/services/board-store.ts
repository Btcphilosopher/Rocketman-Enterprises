import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Board, Thread, Post, Report, AuditLog, Attachment } from '../../server/data';

@Injectable({
  providedIn: 'root'
})
export class BoardStore {
  private http = inject(HttpClient);

  // Core State Signals
  boards = signal<Board[]>([]);
  threads = signal<Thread[]>([]);
  activeThread = signal<Thread | null>(null);
  currentBoardSlug = signal<string | null>(null); // null = Home
  viewMode = signal<'catalogue' | 'classic'>('catalogue');
  sortBy = signal<'bump' | 'new' | 'replies' | 'images'>('bump');
  searchQuery = signal<string>('');
  activeTab = signal<'all' | 'society' | 'regional' | 'specialist'>('all');

  // UI State
  activeTheme = signal<'classic' | 'dark' | 'yotsuba' | 'monochrome'>('classic');
  liveUpdates = signal<boolean>(true);
  soundEnabled = signal<boolean>(true);
  newRepliesCount = signal<number>(0);
  isLoading = signal<boolean>(false);

  // Modals & Popups
  isNewThreadOpen = signal<boolean>(false);
  isQuickReplyOpen = signal<boolean>(false);
  quickReplyThreadId = signal<number | null>(null);
  quickReplyInitialText = signal<string>('');
  
  isReportModalOpen = signal<boolean>(false);
  reportingPost = signal<{ postId: number; threadId: number; boardSlug: string } | null>(null);

  isRulesModalOpen = signal<boolean>(false);
  isSettingsModalOpen = signal<boolean>(false);
  isModDashboardOpen = signal<boolean>(false);
  isModLoggedIn = signal<boolean>(false);

  // Lightbox & Hover Quote
  lightboxImage = signal<Attachment | null>(null);
  hoverQuote = signal<{ post: Post; x: number; y: number } | null>(null);

  // Bookmarks (persisted locally in browser)
  bookmarks = signal<number[]>([]);

  // Platform statistics
  stats = signal({
    totalPosts: 27482761,
    totalThreads: 84920,
    activeBoards: 28,
    onlineUsers: 12427,
    serverGmt: ''
  });

  // Moderation state
  reports = signal<Report[]>([]);
  auditLogs = signal<AuditLog[]>([]);

  // Derived
  currentBoard = computed(() => {
    const slug = this.currentBoardSlug();
    if (!slug) return null;
    return this.boards().find(b => b.slug.toLowerCase() === slug.toLowerCase()) || null;
  });

  latestThreads = computed(() => {
    return this.threads().slice(0, 6);
  });

  filteredBoards = computed(() => {
    const tab = this.activeTab();
    const list = this.boards();
    if (tab === 'all') return list;
    return list.filter(b => b.category === tab);
  });

  constructor() {
    this.initLocalPreferences();
    this.loadStats();
    this.loadBoards();
    this.loadThreads();
    this.startLiveHeartbeat();
  }

  private initLocalPreferences(): void {
    if (typeof window !== 'undefined') {
      try {
        const savedTheme = localStorage.getItem('tc_theme') as 'classic' | 'dark' | 'yotsuba' | 'monochrome';
        if (savedTheme) {
          this.setTheme(savedTheme);
        }
        const savedBookmarks = localStorage.getItem('tc_bookmarks');
        if (savedBookmarks) {
          this.bookmarks.set(JSON.parse(savedBookmarks));
        }
        const savedMode = localStorage.getItem('tc_view_mode') as 'catalogue' | 'classic';
        if (savedMode) {
          this.viewMode.set(savedMode);
        }
      } catch (e) {
        console.warn('LocalStorage not accessible', e);
      }
    }
  }

  setTheme(theme: 'classic' | 'dark' | 'yotsuba' | 'monochrome'): void {
    this.activeTheme.set(theme);
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-theme', theme);
      try {
        localStorage.setItem('tc_theme', theme);
      } catch (e) {
        console.debug('Theme save error', e);
      }
    }
  }

  setViewMode(mode: 'catalogue' | 'classic'): void {
    this.viewMode.set(mode);
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('tc_view_mode', mode);
      } catch (e) {
        console.debug('View mode save error', e);
      }
    }
  }

  toggleBookmark(threadId: number): void {
    const current = this.bookmarks();
    let updated: number[];
    if (current.includes(threadId)) {
      updated = current.filter(id => id !== threadId);
    } else {
      updated = [...current, threadId];
    }
    this.bookmarks.set(updated);
    if (typeof localStorage !== 'undefined') {
      try {
        localStorage.setItem('tc_bookmarks', JSON.stringify(updated));
      } catch (e) {
        console.debug('Bookmark save error', e);
      }
    }
  }

  isBookmarked(threadId: number): boolean {
    return this.bookmarks().includes(threadId);
  }

  loadStats(): void {
    this.http.get<{
      totalPosts: number;
      totalThreads: number;
      activeBoards: number;
      onlineUsers: number;
      serverGmt: string;
    }>('/api/v1/stats').subscribe({
      next: (data) => {
        if (data) this.stats.set(data);
      },
      error: (err) => {
        console.debug('Failed to load stats', err);
      }
    });
  }

  loadBoards(): void {
    this.http.get<Board[]>('/api/v1/boards').subscribe({
      next: (data) => {
        if (data && data.length) {
          this.boards.set(data);
        }
      },
      error: (err) => {
        console.debug('Failed to load boards', err);
      }
    });
  }

  loadThreads(): void {
    this.isLoading.set(true);
    const board = this.currentBoardSlug() || '';
    const sort = this.sortBy();
    const search = this.searchQuery();
    
    let url = `/api/v1/threads?sort=${sort}`;
    if (board) url += `&board=${board}`;
    if (search) url += `&search=${encodeURIComponent(search)}`;

    this.http.get<Thread[]>(url).subscribe({
      next: (data) => {
        this.threads.set(data);
        this.isLoading.set(false);
      },
      error: () => {
        this.isLoading.set(false);
      }
    });
  }

  openThread(id: number): void {
    this.isLoading.set(true);
    this.http.get<Thread>(`/api/v1/threads/${id}`).subscribe({
      next: (data) => {
        this.activeThread.set(data);
        this.currentBoardSlug.set(data.boardSlug);
        this.isLoading.set(false);
        this.newRepliesCount.set(0);
        if (typeof window !== 'undefined') {
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      },
      error: () => {
        this.isLoading.set(false);
      }
    });
  }

  navigateBoard(slug: string | null): void {
    this.currentBoardSlug.set(slug);
    this.activeThread.set(null);
    this.newRepliesCount.set(0);
    this.loadThreads();
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  refreshActiveThread(): void {
    const thread = this.activeThread();
    if (!thread) return;

    this.http.get<Thread>(`/api/v1/threads/${thread.id}`).subscribe({
      next: (fresh) => {
        if (fresh.posts.length > thread.posts.length) {
          const delta = fresh.posts.length - thread.posts.length;
          this.newRepliesCount.update(c => c + delta);
          this.activeThread.set(fresh);
          this.playNotificationSound();
        }
      }
    });
  }

  createThread(payload: { boardSlug: string; subject: string; comment: string; author?: string; attachment?: Attachment }, onSuccess: () => void): void {
    this.http.post<Thread>('/api/v1/threads', payload).subscribe({
      next: (newThread) => {
        this.threads.update(list => [newThread, ...list]);
        this.openThread(newThread.id);
        this.isNewThreadOpen.set(false);
        this.loadStats();
        onSuccess();
      },
      error: (err) => {
        alert(err?.error?.error || 'Failed to create thread.');
      }
    });
  }

  postReply(threadId: number, payload: { comment: string; author?: string; attachment?: Attachment }, onSuccess: () => void): void {
    this.http.post<Post>(`/api/v1/threads/${threadId}/replies`, payload).subscribe({
      next: (newPost) => {
        const current = this.activeThread();
        if (current && current.id === threadId) {
          const updatedPosts = [...current.posts, newPost];
          // update backlinks
          for (const qId of newPost.replyToIds) {
            const target = updatedPosts.find(p => p.id === qId);
            if (target && !target.repliesFromIds.includes(newPost.id)) {
              target.repliesFromIds = [...target.repliesFromIds, newPost.id];
            }
          }
          this.activeThread.set({
            ...current,
            replyCount: current.replyCount + 1,
            imageCount: newPost.attachment ? current.imageCount + 1 : current.imageCount,
            posts: updatedPosts
          });
        }
        this.isQuickReplyOpen.set(false);
        this.loadStats();
        onSuccess();
      },
      error: (err) => {
        alert(err?.error?.error || 'Failed to post reply.');
      }
    });
  }

  submitReport(reason: 'doxxing' | 'spam' | 'harassment' | 'illegal' | 'off-topic', details: string): void {
    const target = this.reportingPost();
    if (!target) return;

    this.http.post('/api/v1/reports', {
      postId: target.postId,
      threadId: target.threadId,
      boardSlug: target.boardSlug,
      reason,
      details
    }).subscribe({
      next: () => {
        this.isReportModalOpen.set(false);
        this.reportingPost.set(null);
        alert('Thank you. The report has been logged for moderator review.');
      },
      error: () => {
        alert('Could not submit report. Please try again.');
      }
    });
  }

  // Moderation actions
  loadModerationData(): void {
    this.http.get<Report[]>('/api/v1/moderation/reports').subscribe({
      next: (data) => this.reports.set(data)
    });
    this.http.get<AuditLog[]>('/api/v1/moderation/audit-logs').subscribe({
      next: (data) => this.auditLogs.set(data)
    });
  }

  performModAction(action: string, targetId: string | number, reason: string): void {
    this.http.post('/api/v1/moderation/action', {
      action,
      targetId,
      reason,
      moderator: 'Janitor'
    }).subscribe({
      next: () => {
        this.loadModerationData();
        if (this.activeThread()) {
          this.openThread(this.activeThread()!.id);
        } else {
          this.loadThreads();
        }
      }
    });
  }

  // Audio effect on new replies (synthesised via Web Audio API)
  playNotificationSound(): void {
    if (!this.soundEnabled() || typeof window === 'undefined') return;
    try {
      const win = window as unknown as { AudioContext?: typeof AudioContext; webkitAudioContext?: typeof AudioContext };
      const AudioCtx = win.AudioContext || win.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime); // A5 note
      osc.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.08); // E6
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.2);
    } catch (e) {
      console.debug('Audio not supported', e);
    }
  }

  private startLiveHeartbeat(): void {
    if (typeof window === 'undefined') return;
    // Heartbeat every 8 seconds when active thread is open
    setInterval(() => {
      if (this.liveUpdates() && this.activeThread()) {
        this.refreshActiveThread();
      }
      // slight online count fluctuation
      this.stats.update(s => ({
        ...s,
        onlineUsers: Math.max(12000, s.onlineUsers + Math.floor(Math.random() * 5 - 2))
      }));
    }, 8000);
  }
}
