export interface FormattedLine {
  type: 'greentext' | 'quote' | 'normal' | 'code' | 'empty';
  text: string;
  quotedPostId?: number;
}

export function parsePostComment(text: string): FormattedLine[] {
  if (!text) return [];

  const lines = text.split('\n');
  const result: FormattedLine[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) {
      result.push({ type: 'empty', text: '' });
      continue;
    }

    // Greentext starts with '>' but not '>>' (which is a quote)
    if (trimmed.startsWith('>') && !trimmed.startsWith('>>')) {
      result.push({ type: 'greentext', text: line });
      continue;
    }

    // Line starting with >>postNo
    const quoteMatch = trimmed.match(/^>>(\d+)(.*)/);
    if (quoteMatch) {
      result.push({
        type: 'quote',
        text: line,
        quotedPostId: parseInt(quoteMatch[1], 10)
      });
      continue;
    }

    // Normal line (might still contain inline >>12345)
    result.push({ type: 'normal', text: line });
  }

  return result;
}
