import { ChangeDetectionStrategy, Component, inject, signal, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';
import { Attachment } from '../../server/data';

@Component({
  selector: 'app-quick-reply-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.isQuickReplyOpen()) {
      <div class="fixed bottom-4 right-4 z-40 w-96 max-w-[95vw] bg-white dark:bg-slate-900 border-2 border-[var(--board-header)] rounded shadow-2xl overflow-hidden qr-window animate-in fade-in slide-in-from-bottom-4 duration-150 text-xs">
        
        <!-- Draggable-style Header -->
        <div class="bg-[var(--board-header)] text-[var(--board-header-text)] px-3 py-1.5 flex items-center justify-between cursor-move select-none">
          <div class="flex items-center gap-1.5 font-bold font-mono-board text-[11px]">
            <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">reply</mat-icon>
            Reply to Thread #{{ store.quickReplyThreadId() }}
          </div>
          <button 
            type="button" 
            (click)="store.isQuickReplyOpen.set(false)"
            class="hover:opacity-75 cursor-pointer">
            <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">close</mat-icon>
          </button>
        </div>

        <!-- Form Body -->
        <form [formGroup]="form" (ngSubmit)="onSubmit()" class="p-3 space-y-2.5">
          
          <!-- Name / Options -->
          <div class="flex items-center gap-2">
            <input 
              type="text" 
              formControlName="author" 
              placeholder="Anonymous"
              class="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 outline-none font-mono-board text-xs" />
            <span class="text-[10px] text-slate-400 font-mono-board">Ctrl+Enter to post</span>
          </div>

          <!-- Formatting shortcuts -->
          <div class="flex items-center gap-1 font-mono-board text-[10px]">
            <button type="button" (click)="insertSyntax('>')" class="px-1 py-0.5 bg-slate-100 dark:bg-slate-800 rounded border hover:bg-slate-200 text-green-700 cursor-pointer">&gt;greentext</button>
            <button type="button" (click)="insertSyntax('**')" class="px-1 py-0.5 bg-slate-100 dark:bg-slate-800 rounded border hover:bg-slate-200 cursor-pointer">**bold**</button>
            <button type="button" (click)="insertSyntax('>>')" class="px-1 py-0.5 bg-slate-100 dark:bg-slate-800 rounded border hover:bg-slate-200 text-blue-700 cursor-pointer">&gt;&gt;quote</button>
          </div>

          <!-- Comment Textarea -->
          <textarea 
            #replyTextarea
            formControlName="comment" 
            rows="5"
            (keydown.control.enter)="onSubmit()"
            (keydown.meta.enter)="onSubmit()"
            placeholder="Type your reply here..."
            class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded p-2 focus:border-[var(--board-link)] outline-none font-mono-board text-xs resize-y"></textarea>

          <!-- Attachment Section -->
          <div class="border border-slate-200 dark:border-slate-800 p-2 rounded bg-slate-50/50 dark:bg-slate-800/30">
            <div class="flex items-center justify-between text-[11px] mb-1">
              <span class="font-medium text-slate-600 dark:text-slate-300">File Attachment (Optional)</span>
              @if (currentAttachment()) {
                <button type="button" (click)="currentAttachment.set(null)" class="text-red-500 hover:underline cursor-pointer">Remove</button>
              }
            </div>

            @if (!currentAttachment()) {
              <input 
                type="file" 
                accept="image/*" 
                (change)="onFileSelected($event)" 
                class="text-[10px] text-slate-500 file:mr-2 file:py-0.5 file:px-2 file:rounded file:border-0 file:text-[10px] file:bg-slate-200 file:text-slate-700 hover:file:bg-slate-300 cursor-pointer w-full" />
            } @else {
              <div class="flex items-center gap-2 text-[10px] font-mono-board text-slate-600 dark:text-slate-300 truncate">
                <img [src]="currentAttachment()!.thumbnailUrl" class="w-8 h-8 rounded object-cover" alt="" />
                <span class="truncate">{{ currentAttachment()!.fileName }}</span>
              </div>
            }
          </div>

          <!-- Submit Buttons -->
          <div class="flex items-center justify-end gap-2 pt-1 border-t border-slate-200 dark:border-slate-800">
            <button 
              type="button" 
              (click)="store.isQuickReplyOpen.set(false)"
              class="px-2.5 py-1 rounded border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer font-medium">
              Close
            </button>
            <button 
              type="submit" 
              [disabled]="form.invalid || isSubmitting()"
              class="px-4 py-1 bg-[var(--board-header)] text-[var(--board-header-text)] rounded font-bold hover:opacity-90 cursor-pointer disabled:opacity-50">
              {{ isSubmitting() ? 'Posting...' : 'Post Reply' }}
            </button>
          </div>

        </form>

      </div>
    }
  `
})
export class QuickReplyModal {
  store = inject(BoardStore);

  isSubmitting = signal<boolean>(false);
  currentAttachment = signal<Attachment | null>(null);

  form = new FormGroup({
    author: new FormControl<string>(''),
    comment: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] })
  });

  constructor() {
    // Whenever quickReplyInitialText changes, append or set it
    effect(() => {
      const initText = this.store.quickReplyInitialText();
      if (initText) {
        const cur = this.form.controls.comment.value;
        this.form.controls.comment.setValue(cur ? cur + '\n' + initText : initText);
        this.store.quickReplyInitialText.set('');
      }
    });
  }

  insertSyntax(syntax: string): void {
    const val = this.form.controls.comment.value;
    this.form.controls.comment.setValue(val + (val ? '\n' : '') + syntax);
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        this.currentAttachment.set({
          id: `att-${Date.now()}`,
          url: dataUrl,
          thumbnailUrl: dataUrl,
          fileName: file.name,
          fileSize: `${Math.round(file.size / 1024)} KB`,
          dimensions: '1920x1080',
          type: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    const threadId = this.store.quickReplyThreadId();
    if (!threadId) return;

    this.isSubmitting.set(true);
    const { author, comment } = this.form.getRawValue();

    this.store.postReply(threadId, {
      author: author || 'Anonymous',
      comment,
      attachment: this.currentAttachment() || undefined
    }, () => {
      this.isSubmitting.set(false);
      this.form.reset();
      this.currentAttachment.set(null);
    });
  }
}
