import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-lightbox-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (store.lightboxImage(); as img) {
      <div 
        role="dialog"
        aria-modal="true"
        aria-label="Image Lightbox"
        class="fixed inset-0 z-50 flex flex-col items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-150">
        
        <!-- Backdrop dismiss button -->
        <button 
          type="button" 
          (click)="store.lightboxImage.set(null)"
          aria-label="Close image lightbox"
          class="absolute inset-0 w-full h-full cursor-zoom-out bg-transparent border-0"></button>

        <!-- Top Toolbar -->
        <div class="relative z-10 w-full max-w-5xl px-4 py-2 bg-black/80 rounded-t flex items-center justify-between text-white text-xs font-mono-board">
          <div class="truncate">
            <span class="font-bold">{{ img.fileName }}</span>
            <span class="text-slate-400 ml-2">({{ img.fileSize }}, {{ img.dimensions }})</span>
          </div>

          <div class="flex items-center gap-3">
            <a 
              [href]="img.url" 
              target="_blank" 
              download 
              class="hover:text-sky-300 flex items-center gap-1">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">download</mat-icon>
              Save
            </a>
            <button 
              type="button" 
              (click)="store.lightboxImage.set(null)"
              class="hover:text-red-400 cursor-pointer">
              <mat-icon class="!text-[20px] !w-[20px] !h-[20px]">close</mat-icon>
            </button>
          </div>
        </div>

        <!-- Image Container -->
        <div class="relative z-10 max-w-5xl max-h-[85vh] flex items-center justify-center overflow-hidden">
          <img 
            [src]="img.url" 
            [alt]="img.fileName"
            referrerpolicy="no-referrer"
            class="max-w-full max-h-[80vh] object-contain rounded-b shadow-2xl border border-white/10" />
        </div>

        <div class="text-[11px] text-slate-400 font-mono-board mt-2">
          Click outside image or press ESC to dismiss.
        </div>

      </div>
    }
  `
})
export class LightboxModal {
  store = inject(BoardStore);
}
