import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BoardStore } from '../services/board-store';
import { parsePostComment } from '../utils/post-formatter';

@Component({
  selector: 'app-hover-quote-popover',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule],
  template: `
    @if (store.hoverQuote(); as hq) {
      <div 
        class="fixed z-50 pointer-events-none quote-popover max-w-sm sm:max-w-md bg-[var(--board-reply-bg)] border border-[var(--board-reply-border)] p-2.5 rounded shadow-xl text-xs"
        [style.left.px]="clampX(hq.x)"
        [style.top.px]="clampY(hq.y)">
        
        <!-- Header -->
        <div class="flex items-center gap-1.5 font-mono-board text-[11px] text-slate-500 mb-1 border-b border-black/5 dark:border-white/5 pb-1">
          <span class="font-bold text-[#117743]">{{ hq.post.author || 'Anonymous' }}</span>
          <span>No.{{ hq.post.id }}</span>
          <span>{{ hq.post.createdAt }}</span>
        </div>

        <!-- Attachment thumb if present -->
        @if (hq.post.attachment; as att) {
          <div class="float-left mr-2.5 mb-1">
            <img 
              [src]="att.thumbnailUrl" 
              class="w-16 h-16 object-cover rounded border border-slate-300 dark:border-slate-700" 
              alt="" />
          </div>
        }

        <!-- Comment snippet -->
        <div class="leading-relaxed whitespace-pre-wrap break-words text-[12px]">
          @for (line of getParsed(hq.post.comment); track $index) {
            @if (line.type === 'greentext') {
              <div class="greentext font-mono-board">{{ line.text }}</div>
            } @else {
              <div>{{ line.text }}</div>
            }
          }
        </div>
        <div class="clear-both"></div>
      </div>
    }
  `
})
export class HoverQuotePopover {
  store = inject(BoardStore);

  getParsed(text: string) {
    return parsePostComment(text);
  }

  clampX(x: number): number {
    if (typeof window !== 'undefined') {
      return Math.min(x, window.innerWidth - 380);
    }
    return x;
  }

  clampY(y: number): number {
    if (typeof window !== 'undefined') {
      return Math.min(y, window.innerHeight - 200);
    }
    return y;
  }
}
