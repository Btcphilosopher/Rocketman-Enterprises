import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';
import { Attachment } from '../../server/data';

@Component({
  selector: 'app-new-thread-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.isNewThreadOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-2xs">
        
        <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-full max-w-xl rounded shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
          
          <!-- Header -->
          <div class="bg-[#1c2d42] text-white px-4 py-2.5 flex items-center justify-between">
            <div class="flex items-center gap-2">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-sky-400">post_add</mat-icon>
              <h3 class="font-bold text-sm">Start a New Thread</h3>
            </div>
            <button 
              type="button" 
              (click)="store.isNewThreadOpen.set(false)"
              class="text-slate-300 hover:text-white cursor-pointer">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">close</mat-icon>
            </button>
          </div>

          <!-- Form -->
          <form [formGroup]="form" (ngSubmit)="onSubmit()" class="p-4 space-y-3.5 text-xs">
            
            <!-- Board Selection & Subject -->
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div>
                <label for="board-slug-select" class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Board</label>
                <select 
                  id="board-slug-select"
                  formControlName="boardSlug" 
                  class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 cursor-pointer font-mono-board">
                  @for (b of store.boards(); track b.slug) {
                    <option [value]="b.slug">/{{ b.slug }}/ — {{ b.name }}</option>
                  }
                </select>
              </div>

              <div class="sm:col-span-2">
                <label for="subject-input" class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Subject (Thread Title)</label>
                <input 
                  id="subject-input"
                  type="text" 
                  formControlName="subject" 
                  placeholder="e.g. Energy resilience in 2030"
                  class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 focus:border-[var(--board-link)] outline-none" />
              </div>
            </div>

            <!-- Name / Tripcode -->
            <div class="grid grid-cols-2 gap-2">
              <div>
                <label for="author-input" class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Name (optional)</label>
                <input 
                  id="author-input"
                  type="text" 
                  formControlName="author" 
                  placeholder="Anonymous"
                  class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 focus:border-[var(--board-link)] outline-none font-mono-board" />
              </div>
              <div>
                <span class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Verification</span>
                <div class="text-[11px] text-slate-500 py-2 font-mono-board">
                  ✓ Pseudonymous Tripcode
                </div>
              </div>
            </div>

            <!-- Formatting Helper Toolbar -->
            <div>
              <div class="flex items-center justify-between mb-1">
                <label for="comment-textarea" class="font-semibold text-slate-700 dark:text-slate-300">Comment (Greentext &gt; supported)</label>
                <div class="flex items-center gap-1 font-mono-board text-[10px]">
                  <button type="button" (click)="insertSyntax('>')" class="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 border rounded hover:bg-slate-200 text-green-700 cursor-pointer">&gt;greentext</button>
                  <button type="button" (click)="insertSyntax('**')" class="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 border rounded hover:bg-slate-200 cursor-pointer">**bold**</button>
                  <button type="button" (click)="insertSyntax('>>')" class="px-1.5 py-0.5 bg-slate-100 dark:bg-slate-800 border rounded hover:bg-slate-200 text-blue-700 cursor-pointer">&gt;&gt;quote</button>
                </div>
              </div>

              <textarea 
                #commentInput
                id="comment-textarea"
                formControlName="comment" 
                rows="6"
                placeholder="Write your discussion prompt... Start a line with '>' for classic greentext."
                class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded p-2.5 focus:border-[var(--board-link)] outline-none font-mono-board text-xs resize-y"></textarea>
            </div>

            <!-- Image Upload Section -->
            <div class="border border-dashed border-slate-300 dark:border-slate-700 p-3 rounded bg-slate-50/50 dark:bg-slate-800/30">
              <label for="attachment-file-input" class="block font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span class="flex items-center gap-1">
                  <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">image</mat-icon>
                  Attachment (JPEG, PNG, WebP)
                </span>
                <span class="text-[10px] text-slate-400 font-mono-board">Max 10MB • EXIF Auto-Stripped</span>
              </label>

              <!-- Upload File Picker -->
              <div class="flex items-center gap-2 mt-1.5">
                <input 
                  id="attachment-file-input"
                  type="file" 
                  accept="image/*" 
                  (change)="onFileSelected($event)" 
                  class="text-xs text-slate-500 file:mr-2 file:py-1 file:px-3 file:rounded file:border-0 file:text-xs file:font-semibold file:bg-[var(--board-header)] file:text-white hover:file:opacity-90 cursor-pointer" />
              </div>

              <!-- Quick Sample Image Picker (For easy demo) -->
              <div class="mt-2.5 pt-2 border-t border-slate-200 dark:border-slate-700/60">
                <span class="text-[10px] text-slate-500 block mb-1">Or choose a British reaction asset:</span>
                <div class="flex gap-2 overflow-x-auto pb-1">
                  @for (sample of sampleImages; track sample.name) {
                    <button 
                      type="button" 
                      (click)="selectSample(sample)"
                      class="shrink-0 flex items-center gap-1.5 px-2 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-[10px] hover:border-[var(--board-link)] cursor-pointer">
                      <img [src]="sample.url" class="w-4 h-4 rounded object-cover" alt="" />
                      <span>{{ sample.name }}</span>
                    </button>
                  }
                </div>
              </div>

              <!-- Image Preview -->
              @if (currentAttachment(); as att) {
                <div class="mt-2 flex items-center gap-3 p-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded">
                  <img [src]="att.thumbnailUrl" class="w-12 h-12 object-cover rounded" alt="Preview" />
                  <div class="text-[11px] font-mono-board text-slate-600 dark:text-slate-300 flex-1 truncate">
                    <div class="font-bold truncate">{{ att.fileName }}</div>
                    <div class="text-[10px] text-slate-400">{{ att.fileSize }} • {{ att.dimensions }}</div>
                  </div>
                  <button type="button" (click)="currentAttachment.set(null)" class="text-red-500 hover:text-red-700 p-1 cursor-pointer">
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">delete</mat-icon>
                  </button>
                </div>
              }
            </div>

            <!-- Footer Action Buttons -->
            <div class="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-800">
              <span class="text-[11px] text-slate-500">
                Posts are anonymous by default.
              </span>
              <div class="flex items-center gap-2">
                <button 
                  type="button" 
                  (click)="store.isNewThreadOpen.set(false)"
                  class="px-3 py-1.5 rounded border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer font-medium">
                  Cancel
                </button>
                <button 
                  type="submit" 
                  [disabled]="form.invalid || isSubmitting()"
                  class="px-4 py-1.5 bg-[var(--board-header)] text-[var(--board-header-text)] rounded font-bold hover:opacity-90 transition-opacity cursor-pointer disabled:opacity-50 shadow-xs flex items-center gap-1.5">
                  <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">send</mat-icon>
                  {{ isSubmitting() ? 'Submitting...' : 'Post Thread' }}
                </button>
              </div>
            </div>

          </form>

        </div>

      </div>
    }
  `
})
export class NewThreadModal {
  store = inject(BoardStore);

  isSubmitting = signal<boolean>(false);
  currentAttachment = signal<Attachment | null>(null);

  form = new FormGroup({
    boardSlug: new FormControl<string>(this.store.currentBoardSlug() || 'uk', { nonNullable: true, validators: [Validators.required] }),
    subject: new FormControl<string>(''),
    author: new FormControl<string>(''),
    comment: new FormControl<string>('', { nonNullable: true, validators: [Validators.required] })
  });

  sampleImages = [
    {
      name: 'Big Ben Dawn',
      url: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=800&q=80',
      fileName: 'westminster_dawn.jpg',
      size: '420 KB',
      dim: '1920x1080'
    },
    {
      name: 'Yorkshire Bitter',
      url: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&w=800&q=80',
      fileName: 'cask_ale_pint.jpg',
      size: '380 KB',
      dim: '1600x1200'
    },
    {
      name: 'Stonehenge Sunset',
      url: 'https://images.unsplash.com/photo-1599833975787-5c143f373c30?auto=format&fit=crop&w=800&q=80',
      fileName: 'stonehenge_megalith.jpg',
      size: '510 KB',
      dim: '1920x1080'
    },
    {
      name: 'Proper Tea',
      url: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80',
      fileName: 'builders_tea.jpg',
      size: '310 KB',
      dim: '1280x850'
    }
  ];

  selectSample(s: { name: string; url: string; fileName: string; size: string; dim: string }): void {
    this.currentAttachment.set({
      id: `att-${Date.now()}`,
      url: s.url,
      thumbnailUrl: s.url,
      fileName: s.fileName,
      fileSize: s.size,
      dimensions: s.dim,
      type: 'image/jpeg'
    });
  }

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) {
      const file = input.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        const dataUrl = e.target?.result as string;
        this.currentAttachment.set({
          id: `att-${Date.now()}`,
          url: dataUrl,
          thumbnailUrl: dataUrl,
          fileName: file.name,
          fileSize: `${Math.round(file.size / 1024)} KB`,
          dimensions: '1920x1080',
          type: file.type
        });
      };
      reader.readAsDataURL(file);
    }
  }

  insertSyntax(syntax: string): void {
    const val = this.form.controls.comment.value;
    this.form.controls.comment.setValue(val + (val ? '\n' : '') + syntax);
  }

  onSubmit(): void {
    if (this.form.invalid) return;

    this.isSubmitting.set(true);
    const { boardSlug, subject, author, comment } = this.form.getRawValue();

    this.store.createThread({
      boardSlug,
      subject: subject || (comment.slice(0, 50) + '...'),
      author: author || 'Anonymous',
      comment,
      attachment: this.currentAttachment() || undefined
    }, () => {
      this.isSubmitting.set(false);
      this.form.reset();
      this.currentAttachment.set(null);
    });
  }
}
