import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-settings-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (store.isSettingsModalOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-2xs">
        <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-full max-w-lg rounded shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs">
          
          <div class="bg-[#1c2d42] text-white px-4 py-2.5 flex items-center justify-between">
            <div class="flex items-center gap-2 font-bold">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-sky-400">tune</mat-icon>
              Interface &amp; Reading Settings
            </div>
            <button (click)="store.isSettingsModalOpen.set(false)" class="text-white/80 hover:text-white cursor-pointer">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">close</mat-icon>
            </button>
          </div>

          <div class="p-5 space-y-4">
            
            <!-- Theme Selection -->
            <div>
              <span class="block font-semibold text-slate-700 dark:text-slate-300 mb-2">Visual Theme</span>
              <div class="grid grid-cols-2 gap-2">
                <button 
                  type="button" 
                  (click)="store.setTheme('classic')"
                  class="p-2.5 rounded border text-left cursor-pointer transition-all flex items-center justify-between"
                  [class.border-blue-600]="store.activeTheme() === 'classic'"
                  [class.bg-blue-50/50]="store.activeTheme() === 'classic'"
                  [class.dark:bg-blue-950/30]="store.activeTheme() === 'classic'">
                  <div>
                    <div class="font-bold">British Classic</div>
                    <div class="text-[10px] text-slate-500">Cream &amp; Navy Blue</div>
                  </div>
                  @if (store.activeTheme() === 'classic') {
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-blue-600">check_circle</mat-icon>
                  }
                </button>

                <button 
                  type="button" 
                  (click)="store.setTheme('dark')"
                  class="p-2.5 rounded border text-left cursor-pointer transition-all flex items-center justify-between"
                  [class.border-blue-600]="store.activeTheme() === 'dark'"
                  [class.bg-blue-50/50]="store.activeTheme() === 'dark'"
                  [class.dark:bg-blue-950/30]="store.activeTheme() === 'dark'">
                  <div>
                    <div class="font-bold">Westminster Dark</div>
                    <div class="text-[10px] text-slate-500">Charcoal &amp; Slate</div>
                  </div>
                  @if (store.activeTheme() === 'dark') {
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-blue-600">check_circle</mat-icon>
                  }
                </button>

                <button 
                  type="button" 
                  (click)="store.setTheme('yotsuba')"
                  class="p-2.5 rounded border text-left cursor-pointer transition-all flex items-center justify-between"
                  [class.border-blue-600]="store.activeTheme() === 'yotsuba'"
                  [class.bg-blue-50/50]="store.activeTheme() === 'yotsuba'"
                  [class.dark:bg-blue-950/30]="store.activeTheme() === 'yotsuba'">
                  <div>
                    <div class="font-bold">Yotsuba Retro</div>
                    <div class="text-[10px] text-slate-500">Ochre &amp; Crimson</div>
                  </div>
                  @if (store.activeTheme() === 'yotsuba') {
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-blue-600">check_circle</mat-icon>
                  }
                </button>

                <button 
                  type="button" 
                  (click)="store.setTheme('monochrome')"
                  class="p-2.5 rounded border text-left cursor-pointer transition-all flex items-center justify-between"
                  [class.border-blue-600]="store.activeTheme() === 'monochrome'"
                  [class.bg-blue-50/50]="store.activeTheme() === 'monochrome'"
                  [class.dark:bg-blue-950/30]="store.activeTheme() === 'monochrome'">
                  <div>
                    <div class="font-bold">Fleet Street Newsprint</div>
                    <div class="text-[10px] text-slate-500">Monochrome Editorial</div>
                  </div>
                  @if (store.activeTheme() === 'monochrome') {
                    <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-blue-600">check_circle</mat-icon>
                  }
                </button>
              </div>
            </div>

            <!-- Audio Alerts -->
            <div class="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <div class="font-semibold text-slate-700 dark:text-slate-300">Acoustic Chime on New Reply</div>
                <div class="text-[11px] text-slate-500">Synthesized teacup bell when active thread receives replies</div>
              </div>
              <button 
                type="button" 
                (click)="store.soundEnabled.set(!store.soundEnabled())"
                class="px-3 py-1 rounded border font-mono-board text-[11px] cursor-pointer"
                [class.bg-emerald-100]="store.soundEnabled()"
                [class.text-emerald-800]="store.soundEnabled()">
                {{ store.soundEnabled() ? 'ENABLED' : 'MUTED' }}
              </button>
            </div>

            <!-- Bookmarked Threads list -->
            <div class="pt-2 border-t border-slate-200 dark:border-slate-800">
              <div class="font-semibold text-slate-700 dark:text-slate-300 mb-1 flex items-center justify-between">
                <span>Saved Bookmarks ({{ store.bookmarks().length }})</span>
                @if (store.bookmarks().length > 0) {
                  <button (click)="store.bookmarks.set([])" class="text-red-500 hover:underline text-[10px] cursor-pointer">Clear All</button>
                }
              </div>
              @if (store.bookmarks().length === 0) {
                <div class="text-[11px] text-slate-400">No bookmarked threads yet. Click the star icon on any thread card to save it.</div>
              } @else {
                <div class="space-y-1 max-h-32 overflow-y-auto">
                  @for (id of store.bookmarks(); track id) {
                    <div class="flex items-center justify-between p-1.5 bg-slate-50 dark:bg-slate-800 rounded font-mono-board text-[11px]">
                      <button (click)="store.openThread(id); store.isSettingsModalOpen.set(false)" class="text-[var(--board-link)] hover:underline truncate">
                        Thread #{{ id }}
                      </button>
                      <button (click)="store.toggleBookmark(id)" class="text-slate-400 hover:text-red-500 cursor-pointer">
                        <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">close</mat-icon>
                      </button>
                    </div>
                  }
                </div>
              }
            </div>

          </div>

          <div class="p-3 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex justify-end">
            <button 
              type="button" 
              (click)="store.isSettingsModalOpen.set(false)"
              class="px-4 py-1.5 bg-[var(--board-header)] text-[var(--board-header-text)] rounded font-semibold cursor-pointer">
              Done
            </button>
          </div>

        </div>
      </div>
    }
  `
})
export class SettingsModal {
  store = inject(BoardStore);
}
