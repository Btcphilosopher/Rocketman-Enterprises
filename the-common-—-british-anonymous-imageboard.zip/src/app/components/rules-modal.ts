import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-rules-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (store.isRulesModalOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-2xs">
        <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-full max-w-2xl rounded shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs flex flex-col max-h-[85vh]">
          
          <!-- Header -->
          <div class="bg-[#1c2d42] text-white px-5 py-3 flex items-center justify-between">
            <div class="flex items-center gap-2 font-cinzel font-bold text-sm tracking-wide">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-400">menu_book</mat-icon>
              THE COMMON CHARTER &amp; PLATFORM RULES
            </div>
            <button (click)="store.isRulesModalOpen.set(false)" class="text-white/80 hover:text-white cursor-pointer">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">close</mat-icon>
            </button>
          </div>

          <!-- Body -->
          <div class="p-5 space-y-4 overflow-y-auto leading-relaxed text-slate-700 dark:text-slate-300">
            <div>
              <h4 class="font-bold text-sm text-[var(--board-highlight)] mb-1">1. The Internet Without The Performance</h4>
              <p>
                The Common exists to provide an uncurated, pseudonymous forum where ideas are weighed on their merit rather than the social clout of the speaker. No follower counts, no algorithmic rage engines, no influencer sponsorship deals.
              </p>
            </div>

            <div class="p-3 bg-red-50 dark:bg-red-950/30 border-l-4 border-red-600 rounded">
              <h4 class="font-bold text-sm text-red-900 dark:text-red-200 mb-1">2. Zero Tolerance for Doxxing &amp; Personal Data</h4>
              <p class="text-red-800 dark:text-red-300 text-[11px]">
                Posting home addresses, real telephone numbers, workplaces, private correspondence, or attempting to unmask anonymous posters will result in immediate permanent bans and deletion without right of appeal.
              </p>
            </div>

            <div>
              <h4 class="font-bold text-sm text-[var(--board-highlight)] mb-1">3. British Decency &amp; Banter Boundary</h4>
              <p>
                Sharp wit, irreverence, satire, and spirited debate are welcome and encouraged. However, coordinated campaigns of abuse, credible threats of violence, and harassment cross the line into illegality under the Communications Act and Malicious Communications Act.
              </p>
            </div>

            <div>
              <h4 class="font-bold text-sm text-[var(--board-highlight)] mb-1">4. Strictly Prohibited Uploads</h4>
              <p>
                Any child sexual abuse material (CSAM), non-consensual intimate imagery, malware payloads, or copyright infringement will be purged and reported to the Internet Watch Foundation (IWF) and relevant authorities. All uploads are stripped of EXIF data.
              </p>
            </div>

            <div>
              <h4 class="font-bold text-sm text-[var(--board-highlight)] mb-1">5. Board Autonomy &amp; Topicality</h4>
              <p>
                Keep posts on topic for the board you are in. Technical debates belong on /comp/ or /tech/; Premier League discussions belong on /sp/; proper tea protocol belongs on /b/ or /food/.
              </p>
            </div>
          </div>

          <!-- Footer -->
          <div class="p-3 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex justify-end">
            <button 
              type="button" 
              (click)="store.isRulesModalOpen.set(false)"
              class="px-4 py-1.5 bg-[var(--board-header)] text-[var(--board-header-text)] rounded font-semibold cursor-pointer">
              Understood
            </button>
          </div>

        </div>
      </div>
    }
  `
})
export class RulesModal {
  store = inject(BoardStore);
}
