import { ChangeDetectionStrategy, Component, input, output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Thread } from '../../server/data';
import { BoardStore } from '../services/board-store';
import { PostView } from './post-view';

@Component({
  selector: 'app-thread-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule, PostView],
  template: `
    @if (thread(); as t) {
      <div class="thread-container my-4">
        
        <!-- Thread Navigation & Action Bar -->
        <div class="sticky top-12 z-20 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border border-slate-300 dark:border-slate-800 p-2.5 rounded shadow-xs mb-5 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          <!-- Breadcrumb links -->
          <div class="flex items-center gap-2 font-semibold">
            <button 
              type="button" 
              (click)="goBack.emit()" 
              class="text-[var(--board-link)] hover:underline flex items-center gap-1 cursor-pointer">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">arrow_back</mat-icon>
              Return to /{{ t.boardSlug }}/
            </button>
            <span class="text-slate-400">/</span>
            <span class="text-slate-600 dark:text-slate-300 font-mono-board">Thread #{{ t.id }}</span>
          </div>

          <!-- Live & Controls -->
          <div class="flex items-center gap-2.5 font-mono-board">
            
            <!-- Live updates toggle -->
            <button 
              type="button" 
              (click)="store.liveUpdates.set(!store.liveUpdates())"
              class="px-2 py-1 rounded border flex items-center gap-1.5 cursor-pointer text-[11px]"
              [class.bg-emerald-50]="store.liveUpdates()"
              [class.border-emerald-300]="store.liveUpdates()"
              [class.text-emerald-800]="store.liveUpdates()"
              [class.dark:bg-emerald-950/40]="store.liveUpdates()"
              [class.dark:text-emerald-300]="store.liveUpdates()">
              <span class="w-2 h-2 rounded-full" [class.bg-emerald-500]="store.liveUpdates()" [class.bg-slate-400]="!store.liveUpdates()"></span>
              Live Updates {{ store.liveUpdates() ? 'ON' : 'OFF' }}
            </button>

            <!-- Manual Refresh -->
            <button 
              type="button" 
              (click)="store.refreshActiveThread()"
              title="Check for new replies now"
              class="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-300 cursor-pointer">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">refresh</mat-icon>
            </button>

            <!-- Bookmark toggle -->
            <button 
              type="button" 
              (click)="store.toggleBookmark(t.id)"
              class="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 flex items-center gap-1 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-[11px]">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]" [class.text-amber-500]="store.isBookmarked(t.id)">
                {{ store.isBookmarked(t.id) ? 'star' : 'star_border' }}
              </mat-icon>
              {{ store.isBookmarked(t.id) ? 'Bookmarked' : 'Bookmark' }}
            </button>

            <!-- Quick Reply button -->
            <button 
              type="button" 
              [disabled]="t.isLocked"
              (click)="openReplyModal()"
              class="px-3 py-1 bg-[var(--board-header)] text-[var(--board-header-text)] rounded hover:opacity-90 transition-opacity flex items-center gap-1 cursor-pointer font-sans disabled:opacity-50">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">reply</mat-icon>
              Post Reply
            </button>

            <!-- Jump to Bottom -->
            <button 
              type="button" 
              (click)="scrollToBottom()"
              title="Jump to bottom"
              class="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-300 cursor-pointer">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">arrow_downward</mat-icon>
            </button>
          </div>
        </div>

        <!-- Floating New Reply Banner -->
        @if (store.newRepliesCount() > 0) {
          <div 
            role="button"
            tabindex="0"
            (click)="scrollToBottom(); store.newRepliesCount.set(0)"
            (keydown.enter)="scrollToBottom(); store.newRepliesCount.set(0)"
            class="sticky top-24 z-30 mx-auto max-w-md bg-emerald-600 text-white text-xs font-semibold py-2 px-4 rounded-full shadow-lg flex items-center justify-between cursor-pointer hover:bg-emerald-700 transition-all animate-bounce">
            <span class="flex items-center gap-2">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">mark_chat_unread</mat-icon>
              {{ store.newRepliesCount() }} new {{ store.newRepliesCount() === 1 ? 'reply' : 'replies' }} received
            </span>
            <span class="underline text-[11px]">Click to jump to latest</span>
          </div>
        }

        <!-- OP Post -->
        @if (t.posts.length > 0) {
          <div class="mb-4">
            <app-post-view 
              [post]="t.posts[0]" 
              [allPostsInThread]="t.posts"
              (replyClicked)="onReplyClicked($event)"
              (quoteClicked)="onQuoteClicked($event)" />
          </div>
        }

        <!-- Replies List -->
        <div class="replies-list ml-2 sm:ml-6 md:ml-8 space-y-3">
          @for (post of t.posts.slice(1); track post.id) {
            <app-post-view 
              [post]="post" 
              [allPostsInThread]="t.posts"
              (replyClicked)="onReplyClicked($event)"
              (quoteClicked)="onQuoteClicked($event)" />
          }
        </div>

        <div id="thread-bottom"></div>

        <!-- Thread Footer Actions -->
        <div class="mt-8 pt-4 border-t border-slate-300 dark:border-slate-800 flex items-center justify-between text-xs font-mono-board">
          <div class="text-slate-500">
            Total replies: {{ t.replyCount }} | Images: {{ t.imageCount }}
          </div>
          <div class="flex items-center gap-3">
            <button 
              type="button" 
              (click)="scrollToTop()"
              class="text-[var(--board-link)] hover:underline flex items-center gap-1 cursor-pointer">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">arrow_upward</mat-icon>
              Top of Thread
            </button>
            <button 
              type="button" 
              (click)="goBack.emit()"
              class="text-[var(--board-link)] hover:underline flex items-center gap-1 cursor-pointer">
              Return to /{{ t.boardSlug }}/
            </button>
          </div>
        </div>

      </div>
    }
  `
})
export class ThreadView {
  thread = input.required<Thread | null>();
  goBack = output<void>();

  store = inject(BoardStore);

  openReplyModal(): void {
    if (this.thread()) {
      this.store.quickReplyThreadId.set(this.thread()!.id);
      this.store.isQuickReplyOpen.set(true);
    }
  }

  onReplyClicked(postId: number): void {
    if (this.thread()) {
      this.store.quickReplyThreadId.set(this.thread()!.id);
      this.store.quickReplyInitialText.set(`>>${postId}\n`);
      this.store.isQuickReplyOpen.set(true);
    }
  }

  onQuoteClicked(postId: number): void {
    if (this.thread()) {
      this.store.quickReplyThreadId.set(this.thread()!.id);
      this.store.quickReplyInitialText.set(`>>${postId}\n`);
      this.store.isQuickReplyOpen.set(true);
    }
  }

  scrollToBottom(): void {
    const el = document.getElementById('thread-bottom');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  }

  scrollToTop(): void {
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }
}
