import { ChangeDetectionStrategy, Component, input, output, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Post, Attachment } from '../../server/data';
import { BoardStore } from '../services/board-store';
import { parsePostComment } from '../utils/post-formatter';

@Component({
  selector: 'app-post-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div 
      [id]="'p' + post().id"
      [class]="post().isOp ? 'op-container mb-6' : 'reply-container mb-3.5 max-w-4xl'"
      [class.opacity-60]="post().moderated">
      
      <!-- Inner Post Card -->
      <div 
        [class]="post().isOp 
          ? 'bg-transparent text-[var(--board-text)]' 
          : 'reply-box rounded-xs p-3 text-[13px] leading-relaxed shadow-xs transition-colors hover:border-[#89a]'">
        
        <!-- Post Header -->
        <div class="flex flex-wrap items-center gap-x-2 gap-y-1 mb-2 text-xs">
          <!-- OP Subject -->
          @if (post().subject) {
            <span class="font-bold text-sm text-[var(--board-highlight)] tracking-tight">
              {{ post().subject }}
            </span>
          }

          <!-- Author -->
          <span class="font-semibold text-[#117743] hover:underline cursor-pointer">
            {{ post().author || 'Anonymous' }}
          </span>

          <!-- Pseudonymous ID -->
          <span 
            class="px-1.5 py-0.5 rounded text-[10px] font-mono-board text-white select-none font-bold shadow-2xs"
            [style.backgroundColor]="getIdColor(post().authorId)"
            [title]="'Pseudonym ID within this thread'">
            ID: {{ post().authorId }}
          </span>

          <!-- Timestamp -->
          <span class="text-slate-500 font-mono-board text-[11px]">
            {{ post().createdAt }}
          </span>

          <!-- Post Number & Link -->
          <span class="text-slate-500 font-mono-board font-medium">
            No. <button 
              type="button" 
              (click)="onQuoteClick(post().id)" 
              class="text-slate-700 dark:text-slate-300 hover:text-[var(--board-highlight)] hover:underline cursor-pointer">
              {{ post().id }}
            </button>
          </span>

          <!-- Post Badges (Sticky, Locked) -->
          @if (post().isSticky) {
            <span class="inline-flex items-center gap-0.5 text-amber-600 font-bold text-[11px] bg-amber-50 dark:bg-amber-950/50 px-1 rounded">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">push_pin</mat-icon> Sticky
            </span>
          }
          @if (post().isLocked) {
            <span class="inline-flex items-center gap-0.5 text-red-600 font-bold text-[11px] bg-red-50 dark:bg-red-950/50 px-1 rounded">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]">lock</mat-icon> Closed
            </span>
          }

          <!-- Quick Action Buttons -->
          <div class="ml-auto flex items-center gap-1.5 text-[11px] text-slate-500">
            <button 
              type="button" 
              (click)="onReplyClick(post().id)"
              class="hover:text-[var(--board-link)] font-medium cursor-pointer px-1 hover:bg-black/5 dark:hover:bg-white/5 rounded">
              [Reply]
            </button>
            <button 
              type="button" 
              (click)="onReportClick(post())"
              class="hover:text-red-600 font-medium cursor-pointer px-1 hover:bg-red-50 dark:hover:bg-red-950/30 rounded"
              title="Report post to moderators">
              [Report]
            </button>
            @if (store.isModLoggedIn()) {
              <button 
                type="button" 
                (click)="onModDelete(post().id)"
                class="text-red-700 dark:text-red-400 font-bold cursor-pointer px-1 bg-red-100 dark:bg-red-900/40 rounded">
                [Mod Del]
              </button>
            }
          </div>
        </div>

        <!-- Attachment Details & Thumbnail -->
        @if (post().attachment; as att) {
          <div class="mb-2.5">
            <div class="text-[11px] text-slate-500 font-mono-board mb-1 flex items-center gap-2">
              <span>File: </span>
              <a 
                [href]="att.url" 
                target="_blank" 
                class="text-[var(--board-link)] hover:underline truncate max-w-xs font-semibold"
                (click)="$event.preventDefault(); openLightbox(att)">
                {{ att.fileName }}
              </a>
              <span>({{ att.fileSize }}, {{ att.dimensions }})</span>
            </div>

            <!-- Image View -->
            <div class="float-left mr-4 mb-2">
              <img 
                [src]="att.thumbnailUrl" 
                [alt]="att.fileName"
                referrerpolicy="no-referrer"
                role="button"
                tabindex="0"
                (click)="toggleImageExpand()"
                (keydown.enter)="toggleImageExpand()"
                class="cursor-zoom-in rounded border border-slate-300 dark:border-slate-700 shadow-xs transition-all hover:brightness-95 object-cover"
                [class.max-w-[220px]]="!isExpanded()"
                [class.max-h-[220px]]="!isExpanded()"
                [class.max-w-full]="isExpanded()"
                [class.max-h-none]="isExpanded()" />
            </div>
          </div>
        }

        <!-- Post Body Content -->
        <div class="comment-body whitespace-pre-wrap break-words min-h-[1.5rem]">
          @for (line of parsedLines(); track $index) {
            @switch (line.type) {
              @case ('greentext') {
                <div class="greentext font-mono-board">{{ line.text }}</div>
              }
              @case ('quote') {
                <div class="my-0.5">
                  <span 
                    class="quotelink font-mono-board"
                    role="button"
                    tabindex="0"
                    (click)="jumpToPost(line.quotedPostId!)"
                    (keydown.enter)="jumpToPost(line.quotedPostId!)"
                    (mouseenter)="showHoverQuote(line.quotedPostId!, $event)"
                    (mouseleave)="hideHoverQuote()">
                    {{ line.text }}
                  </span>
                </div>
              }
              @case ('empty') {
                <div class="h-2"></div>
              }
              @default {
                <div>{{ line.text }}</div>
              }
            }
          }
        </div>

        <div class="clear-both"></div>

        <!-- Backlinks (Posts replying to this post) -->
        @if (post().repliesFromIds.length > 0) {
          <div class="mt-2.5 pt-1.5 border-t border-black/5 dark:border-white/10 text-[11px] font-mono-board text-slate-500 flex flex-wrap items-center gap-1.5">
            <span class="font-bold text-slate-600 dark:text-slate-400">Replies:</span>
            @for (replyId of post().repliesFromIds; track replyId) {
              <a 
                [href]="'#p' + replyId" 
                (click)="$event.preventDefault(); jumpToPost(replyId)"
                (mouseenter)="showHoverQuote(replyId, $event)"
                (mouseleave)="hideHoverQuote()"
                class="quotelink hover:text-red-700">
                >>{{ replyId }}
              </a>
            }
          </div>
        }

      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
    }
  `]
})
export class PostView {
  post = input.required<Post>();
  allPostsInThread = input<Post[]>([]);

  replyClicked = output<number>();
  quoteClicked = output<number>();

  store = inject(BoardStore);
  isExpanded = signal<boolean>(false);

  parsedLines = () => parsePostComment(this.post().comment);

  getIdColor(id: string): string {
    let hash = 0;
    for (let i = 0; i < id.length; i++) {
      hash = id.charCodeAt(i) + ((hash << 5) - hash);
    }
    const c = (hash & 0x00FFFFFF).toString(16).toUpperCase();
    return '#' + '00000'.substring(0, 6 - c.length) + c;
  }

  toggleImageExpand(): void {
    this.isExpanded.update(v => !v);
  }

  openLightbox(att: Attachment): void {
    this.store.lightboxImage.set(att);
  }

  onReplyClick(postId: number): void {
    this.replyClicked.emit(postId);
    this.store.quickReplyThreadId.set(this.post().threadId);
    this.store.isQuickReplyOpen.set(true);
  }

  onQuoteClick(postId: number): void {
    this.quoteClicked.emit(postId);
    this.store.quickReplyThreadId.set(this.post().threadId);
    this.store.quickReplyInitialText.set(`>>${postId}\n`);
    this.store.isQuickReplyOpen.set(true);
  }

  onReportClick(post: Post): void {
    this.store.reportingPost.set({
      postId: post.id,
      threadId: post.threadId,
      boardSlug: post.boardSlug
    });
    this.store.isReportModalOpen.set(true);
  }

  onModDelete(postId: number): void {
    const reason = prompt('Reason for removing post #' + postId + ':', 'Rule violation / spam');
    if (reason) {
      this.store.performModAction('delete-post', postId, reason);
    }
  }

  jumpToPost(postId: number): void {
    const el = document.getElementById('p' + postId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      el.classList.add('ring-2', 'ring-red-500', 'bg-red-50/20');
      setTimeout(() => {
        el.classList.remove('ring-2', 'ring-red-500', 'bg-red-50/20');
      }, 1500);
    }
  }

  showHoverQuote(postId: number, event: MouseEvent): void {
    const target = this.allPostsInThread().find(p => p.id === postId);
    if (target) {
      this.store.hoverQuote.set({
        post: target,
        x: event.clientX + 10,
        y: event.clientY + 10
      });
    }
  }

  hideHoverQuote(): void {
    this.store.hoverQuote.set(null);
  }
}
