import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-mod-dashboard-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    @if (store.isModDashboardOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-2xs">
        <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-full max-w-4xl rounded shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs flex flex-col max-h-[90vh]">
          
          <!-- Header -->
          <div class="bg-[#1c2d42] text-white px-5 py-3 flex items-center justify-between border-b border-sky-900">
            <div class="flex items-center gap-2 font-bold text-sm tracking-wide">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-400">admin_panel_settings</mat-icon>
              THE COMMON — JANITOR &amp; MODERATION DESK
            </div>

            <div class="flex items-center gap-3">
              @if (!store.isModLoggedIn()) {
                <button 
                  type="button" 
                  (click)="loginAsMod()"
                  class="px-2.5 py-1 bg-amber-500 hover:bg-amber-600 text-black font-bold rounded text-[11px] cursor-pointer">
                  Authenticate as Janitor
                </button>
              } @else {
                <span class="text-emerald-400 font-mono-board text-[11px] flex items-center gap-1">
                  <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                  Authenticated: Senior Janitor
                </span>
              }
              <button (click)="store.isModDashboardOpen.set(false)" class="text-white/80 hover:text-white cursor-pointer">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">close</mat-icon>
              </button>
            </div>
          </div>

          <!-- Mod Tabs -->
          <div class="flex items-center border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-4 pt-2 gap-2">
            <button 
              type="button" 
              (click)="activeTab.set('reports')"
              class="px-3 py-1.5 font-bold border-b-2 cursor-pointer transition-colors"
              [class.border-blue-600]="activeTab() === 'reports'"
              [class.text-blue-600]="activeTab() === 'reports'"
              [class.border-transparent]="activeTab() !== 'reports'"
              [class.text-slate-500]="activeTab() !== 'reports'">
              Reports Queue ({{ pendingReportsCount() }})
            </button>

            <button 
              type="button" 
              (click)="activeTab.set('audit')"
              class="px-3 py-1.5 font-bold border-b-2 cursor-pointer transition-colors"
              [class.border-blue-600]="activeTab() === 'audit'"
              [class.text-blue-600]="activeTab() === 'audit'"
              [class.border-transparent]="activeTab() !== 'audit'"
              [class.text-slate-500]="activeTab() !== 'audit'">
              Audit Logs ({{ store.auditLogs().length }})
            </button>

            <button 
              type="button" 
              (click)="activeTab.set('stats')"
              class="px-3 py-1.5 font-bold border-b-2 cursor-pointer transition-colors"
              [class.border-blue-600]="activeTab() === 'stats'"
              [class.text-blue-600]="activeTab() === 'stats'"
              [class.border-transparent]="activeTab() !== 'stats'"
              [class.text-slate-500]="activeTab() !== 'stats'">
              Health &amp; Retention
            </button>
          </div>

          <!-- Content Body -->
          <div class="p-4 overflow-y-auto flex-1 space-y-4">
            
            @if (activeTab() === 'reports') {
              <div class="space-y-3">
                @if (store.reports().length === 0) {
                  <div class="text-center py-8 text-slate-400">
                    <mat-icon class="!text-3xl !w-8 !h-8 mb-1">done_all</mat-icon>
                    <div>Reports queue is completely clear. Good job!</div>
                  </div>
                } @else {
                  @for (rep of store.reports(); track rep.id) {
                    <div class="p-3 border rounded bg-slate-50 dark:bg-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      [class.border-amber-400]="rep.status === 'pending'"
                      [class.border-slate-300]="rep.status !== 'pending'">
                      <div>
                        <div class="flex items-center gap-2 mb-1">
                          <span class="px-2 py-0.5 rounded font-mono-board font-bold uppercase text-[10px]"
                            [class.bg-red-100]="rep.reason === 'doxxing' || rep.reason === 'illegal'"
                            [class.text-red-800]="rep.reason === 'doxxing' || rep.reason === 'illegal'"
                            [class.bg-amber-100]="rep.reason === 'spam' || rep.reason === 'harassment'"
                            [class.text-amber-800]="rep.reason === 'spam' || rep.reason === 'harassment'">
                            {{ rep.reason }}
                          </span>
                          <span class="font-bold text-slate-700 dark:text-slate-200">
                            Post #{{ rep.postId }} in /{{ rep.boardSlug }}/
                          </span>
                          <span class="text-slate-400 font-mono-board text-[10px]">{{ rep.createdAt }}</span>
                        </div>
                        <p class="text-slate-600 dark:text-slate-300 text-xs italic">
                          "{{ rep.details }}"
                        </p>
                      </div>

                      <div class="flex items-center gap-1.5 shrink-0">
                        @if (rep.status === 'pending') {
                          <button 
                            type="button" 
                            (click)="deletePost(rep.postId)"
                            class="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded cursor-pointer">
                            Delete Post
                          </button>
                          <button 
                            type="button" 
                            (click)="resolveReport(rep.id)"
                            class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded cursor-pointer">
                            Resolve
                          </button>
                          <button 
                            type="button" 
                            (click)="dismissReport(rep.id)"
                            class="px-2.5 py-1 border border-slate-300 dark:border-slate-600 hover:bg-slate-200 rounded cursor-pointer">
                            Dismiss
                          </button>
                        } @else {
                          <span class="text-slate-400 font-mono-board text-[11px] capitalize">
                            Status: {{ rep.status }}
                          </span>
                        }
                      </div>
                    </div>
                  }
                }
              </div>
            }

            @if (activeTab() === 'audit') {
              <div class="space-y-2 font-mono-board text-[11px]">
                <div class="grid grid-cols-5 font-bold p-2 bg-slate-100 dark:bg-slate-800 rounded text-slate-600 dark:text-slate-300">
                  <span>Timestamp</span>
                  <span>Janitor / Mod</span>
                  <span>Action</span>
                  <span>Target</span>
                  <span>Reason</span>
                </div>
                @for (log of store.auditLogs(); track log.id) {
                  <div class="grid grid-cols-5 p-2 border-b border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <span class="text-slate-400">{{ log.timestamp }}</span>
                    <span class="font-semibold text-blue-600 dark:text-sky-400">{{ log.moderator }}</span>
                    <span class="font-bold">{{ log.action }}</span>
                    <span>{{ log.targetType }} #{{ log.targetId }}</span>
                    <span class="text-slate-500 truncate">{{ log.reason }}</span>
                  </div>
                }
              </div>
            }

            @if (activeTab() === 'stats') {
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div class="p-3 bg-slate-50 dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">
                  <div class="text-2xl font-bold font-mono-board text-[var(--board-highlight)]">{{ store.stats().totalPosts }}</div>
                  <div class="text-[10px] text-slate-500 uppercase mt-1">Total Posts Made</div>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">
                  <div class="text-2xl font-bold font-mono-board text-emerald-600">{{ store.stats().onlineUsers }}</div>
                  <div class="text-[10px] text-slate-500 uppercase mt-1">Estimated Anons Online</div>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">
                  <div class="text-2xl font-bold font-mono-board text-sky-600">{{ store.boards().length }}</div>
                  <div class="text-[10px] text-slate-500 uppercase mt-1">Active Boards</div>
                </div>
                <div class="p-3 bg-slate-50 dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">
                  <div class="text-2xl font-bold font-mono-board text-amber-600">350</div>
                  <div class="text-[10px] text-slate-500 uppercase mt-1">Thread Bump Limit</div>
                </div>
              </div>
            }

          </div>

          <!-- Footer -->
          <div class="p-3 bg-slate-50 dark:bg-slate-800 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center text-slate-500 text-[11px]">
            <span>All janitorial moderation decisions are permanently auditable.</span>
            <button 
              type="button" 
              (click)="store.isModDashboardOpen.set(false)"
              class="px-4 py-1.5 bg-[var(--board-header)] text-[var(--board-header-text)] rounded font-semibold cursor-pointer">
              Close Desk
            </button>
          </div>

        </div>
      </div>
    }
  `
})
export class ModDashboardModal {
  store = inject(BoardStore);
  activeTab = signal<'reports' | 'audit' | 'stats'>('reports');

  pendingReportsCount = () => {
    return this.store.reports().filter(r => r.status === 'pending').length;
  };

  loginAsMod(): void {
    this.store.isModLoggedIn.set(true);
    this.store.loadModerationData();
    alert('Logged in as Board Janitor. Mod tools enabled across threads.');
  }

  deletePost(postId: number): void {
    const reason = prompt('Reason for deleting post #' + postId + ':', 'Terms violation / spam');
    if (reason) {
      this.store.performModAction('delete-post', postId, reason);
    }
  }

  resolveReport(reportId: string): void {
    this.store.performModAction('resolve-report', reportId, 'Marked resolved');
  }

  dismissReport(reportId: string): void {
    this.store.performModAction('dismiss-report', reportId, 'Report dismissed as unwarranted');
  }
}
