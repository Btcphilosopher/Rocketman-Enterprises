import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-report-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    @if (store.isReportModalOpen()) {
      <div class="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-2xs">
        <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 w-full max-w-md rounded shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150 text-xs">
          
          <div class="bg-red-800 text-white px-4 py-2.5 flex items-center justify-between">
            <div class="flex items-center gap-2 font-bold">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">report_problem</mat-icon>
              Report Post #{{ store.reportingPost()?.postId }}
            </div>
            <button (click)="store.isReportModalOpen.set(false)" class="text-white/80 hover:text-white cursor-pointer">
              <mat-icon class="!text-[18px] !w-[18px] !h-[18px]">close</mat-icon>
            </button>
          </div>

          <form [formGroup]="form" (ngSubmit)="onSubmit()" class="p-4 space-y-3.5">
            <p class="text-slate-600 dark:text-slate-300">
              The Common operates a serious, transparent moderation regime. Reports are reviewed by human board janitors.
            </p>

            <div>
              <label for="report-reason-select" class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Violation Category</label>
              <select 
                id="report-reason-select"
                formControlName="reason" 
                class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded p-2">
                <option value="doxxing">Doxxing / Personal Identifying Info (UK GDPR)</option>
                <option value="illegal">Unlawful or Prohibited Material under UK Law</option>
                <option value="harassment">Targeted Threats or Menace</option>
                <option value="spam">Commercial Spam / Crypto Pump / Bot Flooding</option>
                <option value="off-topic">Grossly Off-Topic for Board</option>
              </select>
            </div>

            <div>
              <label for="report-details-textarea" class="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Specific Context</label>
              <textarea 
                id="report-details-textarea"
                formControlName="details" 
                rows="3" 
                placeholder="Explain the violation for the moderator..." 
                class="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded p-2 outline-none font-mono-board text-xs resize-none"></textarea>
            </div>

            <div class="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button 
                type="button" 
                (click)="store.isReportModalOpen.set(false)" 
                class="px-3 py-1.5 border border-slate-300 dark:border-slate-700 rounded hover:bg-slate-100 cursor-pointer">
                Cancel
              </button>
              <button 
                type="submit" 
                class="px-4 py-1.5 bg-red-700 hover:bg-red-800 text-white rounded font-bold cursor-pointer shadow-xs">
                Submit Report
              </button>
            </div>
          </form>

        </div>
      </div>
    }
  `
})
export class ReportModal {
  store = inject(BoardStore);

  form = new FormGroup({
    reason: new FormControl<'doxxing' | 'spam' | 'harassment' | 'illegal' | 'off-topic'>('spam', { nonNullable: true, validators: [Validators.required] }),
    details: new FormControl<string>('')
  });

  onSubmit(): void {
    const { reason, details } = this.form.getRawValue();
    this.store.submitReport(reason, details || '');
  }
}
