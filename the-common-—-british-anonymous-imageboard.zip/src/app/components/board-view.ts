import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';
import { CatalogueView } from './catalogue-view';
import { PostView } from './post-view';

@Component({
  selector: 'app-board-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule, CatalogueView, PostView],
  template: `
    @if (store.currentBoard(); as b) {
      <div class="board-page my-3">
        
        <!-- Board Header Banner -->
        <div class="text-center py-4 border-b border-slate-300 dark:border-slate-800 mb-4 bg-white/50 dark:bg-slate-900/40 rounded p-4 shadow-2xs">
          <div class="text-xs uppercase tracking-widest text-slate-500 font-mono-board mb-1">
            THE COMMON — BOARD DIRECTORY
          </div>
          <h2 class="text-2xl sm:text-3xl font-extrabold text-[var(--board-highlight)] tracking-tight font-cinzel">
            /{{ b.slug }}/ — {{ b.name }}
          </h2>
          <p class="text-sm text-slate-600 dark:text-slate-300 max-w-2xl mx-auto mt-1.5 leading-relaxed">
            {{ b.description }}
          </p>

          <!-- Board Rules summary -->
          <div class="mt-3 inline-flex flex-wrap items-center justify-center gap-2 text-xs text-slate-500 font-mono-board">
            <span class="font-semibold text-slate-700 dark:text-slate-300">Rules:</span>
            @for (rule of b.rules; track rule) {
              <span class="bg-black/5 dark:bg-white/5 px-2 py-0.5 rounded border border-black/5 dark:border-white/5">
                • {{ rule }}
              </span>
            }
          </div>
        </div>

        <!-- Board Toolbar -->
        <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 p-2.5 rounded shadow-2xs mb-4 flex flex-wrap items-center justify-between gap-3 text-xs">
          
          <!-- Left: New Thread + Breadcrumbs -->
          <div class="flex items-center gap-2">
            <button 
              type="button" 
              (click)="store.isNewThreadOpen.set(true)"
              class="px-3.5 py-1.5 bg-[var(--board-header)] text-[var(--board-header-text)] rounded font-semibold flex items-center gap-1.5 hover:opacity-90 transition-opacity cursor-pointer shadow-xs">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">add_circle</mat-icon>
              Start New Thread
            </button>

            <button 
              type="button" 
              (click)="store.navigateBoard(null)"
              class="text-[var(--board-link)] hover:underline ml-2 cursor-pointer font-medium">
              [Board Directory]
            </button>
          </div>

          <!-- Right: View Mode Toggle & Sort -->
          <div class="flex flex-wrap items-center gap-2 font-mono-board text-[11px]">
            <!-- View Mode Switch -->
            <div class="inline-flex rounded border border-slate-300 dark:border-slate-700 p-0.5 bg-slate-100 dark:bg-slate-800">
              <button 
                type="button" 
                (click)="store.setViewMode('catalogue')"
                class="px-2.5 py-1 rounded cursor-pointer transition-colors"
                [class.bg-white]="store.viewMode() === 'catalogue'"
                [class.dark:bg-slate-700]="store.viewMode() === 'catalogue'"
                [class.font-bold]="store.viewMode() === 'catalogue'"
                [class.shadow-2xs]="store.viewMode() === 'catalogue'">
                Catalogue
              </button>
              <button 
                type="button" 
                (click)="store.setViewMode('classic')"
                class="px-2.5 py-1 rounded cursor-pointer transition-colors"
                [class.bg-white]="store.viewMode() === 'classic'"
                [class.dark:bg-slate-700]="store.viewMode() === 'classic'"
                [class.font-bold]="store.viewMode() === 'classic'"
                [class.shadow-2xs]="store.viewMode() === 'classic'">
                Classic View
              </button>
            </div>

            <!-- Sort dropdown -->
            <div class="flex items-center gap-1 text-slate-500">
              <span>Sort:</span>
              <select 
                [value]="store.sortBy()"
                (change)="onSortChange($event)"
                class="bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-1.5 py-1 cursor-pointer">
                <option value="bump">Recent Bump</option>
                <option value="new">Newest First</option>
                <option value="replies">Most Replies</option>
                <option value="images">Most Images</option>
              </select>
            </div>

            <!-- Refresh button -->
            <button 
              type="button" 
              (click)="store.loadThreads()"
              title="Refresh threads"
              class="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded cursor-pointer text-slate-600 dark:text-slate-300">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">refresh</mat-icon>
            </button>
          </div>

        </div>

        <!-- Content rendering based on View Mode -->
        @if (store.threads().length === 0) {
          <div class="text-center py-12 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded my-4 p-6">
            <mat-icon class="!text-4xl !w-10 !h-10 text-slate-400 mb-2">inbox</mat-icon>
            <p class="text-slate-600 dark:text-slate-300 text-sm font-medium">No threads found in /{{ b.slug }}/ matching criteria.</p>
            <button 
              type="button" 
              (click)="store.isNewThreadOpen.set(true)"
              class="mt-3 px-4 py-1.5 bg-[var(--board-header)] text-[var(--board-header-text)] rounded text-xs font-semibold cursor-pointer">
              Be the first to start a thread
            </button>
          </div>
        } @else if (store.viewMode() === 'catalogue') {
          <app-catalogue-view 
            [threads]="store.threads()" 
            (selectThread)="store.openThread($event)" />
        } @else {
          <!-- Classic View: Chronological list of threads with OP and preview replies -->
          <div class="space-y-8 my-4">
            @for (thread of store.threads(); track thread.id) {
              <div class="border-b border-slate-300 dark:border-slate-800 pb-6">
                <!-- Thread header / link -->
                <div class="mb-3 flex items-center justify-between text-xs">
                  <button 
                    type="button" 
                    (click)="store.openThread(thread.id)"
                    class="font-bold text-base text-[var(--board-highlight)] hover:underline flex items-center gap-1.5 cursor-pointer">
                    @if (thread.isSticky) {
                      <mat-icon class="!text-[16px] !w-[16px] !h-[16px] text-amber-600">push_pin</mat-icon>
                    }
                    {{ thread.subject }}
                  </button>

                  <button 
                    type="button" 
                    (click)="store.openThread(thread.id)"
                    class="px-2.5 py-1 bg-slate-200 dark:bg-slate-800 text-[var(--board-link)] font-semibold rounded hover:bg-slate-300 dark:hover:bg-slate-700 cursor-pointer">
                    View Thread ({{ thread.replyCount }} {{ thread.replyCount === 1 ? 'reply' : 'replies' }}) →
                  </button>
                </div>

                <!-- OP Post -->
                @if (thread.posts.length > 0) {
                  <app-post-view 
                    [post]="thread.posts[0]" 
                    [allPostsInThread]="thread.posts"
                    (replyClicked)="store.openThread(thread.id)"
                    (quoteClicked)="store.openThread(thread.id)" />
                }

                <!-- Preview of last 2 replies if any -->
                @if (thread.posts.length > 1) {
                  <div class="ml-4 sm:ml-8 mt-2 space-y-2">
                    @if (thread.posts.length > 3) {
                      <div class="text-[11px] text-slate-500 font-mono-board mb-1">
                        ... {{ thread.posts.length - 3 }} earlier replies omitted. 
                        <button (click)="store.openThread(thread.id)" class="text-[var(--board-link)] underline cursor-pointer">Click to view full thread</button>
                      </div>
                    }
                    @for (reply of thread.posts.slice(-2); track reply.id) {
                      <app-post-view 
                        [post]="reply" 
                        [allPostsInThread]="thread.posts"
                        (replyClicked)="store.openThread(thread.id)"
                        (quoteClicked)="store.openThread(thread.id)" />
                    }
                  </div>
                }
              </div>
            }
          </div>
        }

      </div>
    }
  `
})
export class BoardView {
  store = inject(BoardStore);

  onSortChange(event: Event): void {
    const val = (event.target as HTMLSelectElement).value as 'bump' | 'new' | 'replies' | 'images';
    this.store.sortBy.set(val);
    this.store.loadThreads();
  }
}
