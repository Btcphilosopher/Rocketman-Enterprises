import { ChangeDetectionStrategy, Component, input, output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Thread } from '../../server/data';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-catalogue-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5 my-4">
      @for (thread of threads(); track thread.id) {
        <div 
          role="button"
          tabindex="0"
          (click)="selectThread.emit(thread.id)"
          (keydown.enter)="selectThread.emit(thread.id)"
          class="group bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-sm p-2 cursor-pointer shadow-xs hover:border-[var(--board-highlight)] hover:shadow-md transition-all flex flex-col justify-between text-xs relative overflow-hidden">
          
          <!-- Sticky / Locked Badge -->
          <div class="absolute top-1.5 left-1.5 z-10 flex gap-1">
            @if (thread.isSticky) {
              <span class="bg-amber-600 text-white p-0.5 rounded shadow-xs" title="Sticky Thread">
                <mat-icon class="!text-[12px] !w-[12px] !h-[12px]">push_pin</mat-icon>
              </span>
            }
            @if (thread.isLocked) {
              <span class="bg-red-600 text-white p-0.5 rounded shadow-xs" title="Locked Thread">
                <mat-icon class="!text-[12px] !w-[12px] !h-[12px]">lock</mat-icon>
              </span>
            }
          </div>

          <!-- Thumbnail Box -->
          <div class="w-full aspect-square bg-slate-100 dark:bg-slate-950 rounded-xs overflow-hidden mb-2 flex items-center justify-center border border-slate-200 dark:border-slate-800 relative">
            @if (thread.posts[0]?.attachment; as att) {
              <img 
                [src]="att.thumbnailUrl" 
                [alt]="thread.subject"
                referrerpolicy="no-referrer"
                class="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" />
            } @else {
              <div class="text-slate-400 flex flex-col items-center">
                <mat-icon class="!text-3xl !w-7 !h-7">forum</mat-icon>
                <span class="text-[10px] mt-1 font-mono-board">Text OP</span>
              </div>
            }

            <!-- Reply and Image Count Pill -->
            <div class="absolute bottom-1 right-1 bg-black/80 text-white font-mono-board text-[10px] px-1.5 py-0.5 rounded flex items-center gap-1.5 backdrop-blur-xs">
              <span class="flex items-center gap-0.5">
                <mat-icon class="!text-[10px] !w-[10px] !h-[10px]">chat_bubble</mat-icon>
                {{ thread.replyCount }}
              </span>
              @if (thread.imageCount > 0) {
                <span class="flex items-center gap-0.5 text-sky-300">
                  <mat-icon class="!text-[10px] !w-[10px] !h-[10px]">image</mat-icon>
                  {{ thread.imageCount }}
                </span>
              }
            </div>
          </div>

          <!-- Content Details -->
          <div class="flex-1 flex flex-col">
            <!-- Subject -->
            <h4 class="font-bold text-[12px] line-clamp-2 text-[var(--board-highlight)] group-hover:underline mb-1 leading-snug">
              {{ thread.subject }}
            </h4>

            <!-- OP Comment Snippet -->
            <p class="text-slate-600 dark:text-slate-400 line-clamp-3 text-[11px] leading-tight mb-2">
              {{ thread.posts[0]?.comment || '' }}
            </p>
          </div>

          <!-- Footer Metadata -->
          <div class="pt-1 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 font-mono-board flex items-center justify-between">
            <span>No.{{ thread.id }}</span>
            <button 
              type="button" 
              (click)="$event.stopPropagation(); store.toggleBookmark(thread.id)"
              class="hover:text-amber-500 cursor-pointer p-0.5">
              <mat-icon class="!text-[14px] !w-[14px] !h-[14px]" [class.text-amber-500]="store.isBookmarked(thread.id)">
                {{ store.isBookmarked(thread.id) ? 'star' : 'star_border' }}
              </mat-icon>
            </button>
          </div>

        </div>
      }
    </div>
  `
})
export class CatalogueView {
  threads = input.required<Thread[]>();
  selectThread = output<number>();
  store = inject(BoardStore);
}
