import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from '../services/board-store';

@Component({
  selector: 'app-home-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="home-container">
      
      <!-- HERO BANNER (matches uploaded design) -->
      <div class="relative w-full rounded-sm overflow-hidden mb-6 border border-slate-300 dark:border-slate-800 shadow-sm bg-slate-900 min-h-[170px] sm:min-h-[200px] flex items-center">
        <!-- Background Westminster Sunset Skyline -->
        <div 
          class="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-luminosity filter contrast-125"
          style="background-image: url('https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1920&q=80');">
        </div>
        <div class="absolute inset-0 bg-gradient-to-r from-[#0d1624]/95 via-[#162238]/85 to-transparent"></div>

        <!-- Banner Content -->
        <div class="relative z-10 w-full px-6 py-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          
          <!-- Logo & Wordmark -->
          <div class="flex items-center gap-4">
            
            <!-- British Clover Emblem -->
            <div class="w-14 h-14 sm:w-18 sm:h-18 shrink-0 flex items-center justify-center relative">
              <svg viewBox="0 0 100 100" class="w-full h-full drop-shadow-md">
                <!-- Clover 4-leaf shape with Union Jack palette -->
                <circle cx="35" cy="35" r="22" fill="#00247d" stroke="#cf142b" stroke-width="4" />
                <circle cx="65" cy="35" r="22" fill="#00247d" stroke="#cf142b" stroke-width="4" />
                <circle cx="35" cy="65" r="22" fill="#00247d" stroke="#cf142b" stroke-width="4" />
                <circle cx="65" cy="65" r="22" fill="#00247d" stroke="#cf142b" stroke-width="4" />
                <path d="M 50 15 L 50 85 M 15 50 L 85 50" stroke="#ffffff" stroke-width="6" />
                <path d="M 50 15 L 50 85 M 15 50 L 85 50" stroke="#cf142b" stroke-width="3" />
                <path d="M 22 22 L 78 78 M 22 78 L 78 22" stroke="#ffffff" stroke-width="4" />
                <path d="M 22 22 L 78 78 M 22 78 L 78 22" stroke="#cf142b" stroke-width="2" />
                <circle cx="50" cy="50" r="10" fill="#00247d" stroke="#ffffff" stroke-width="2" />
              </svg>
            </div>

            <!-- Typography -->
            <div>
              <div class="flex items-baseline gap-2">
                <h1 class="text-3xl sm:text-4xl font-extrabold tracking-tight text-white font-cinzel">
                  THE COMMON
                </h1>
                <span class="text-xs uppercase font-mono-board text-sky-400 font-semibold tracking-wider">
                  thecommon.uk
                </span>
              </div>
              <div class="text-[11px] font-mono-board tracking-[0.25em] text-slate-300 font-medium mt-0.5">
                DISCUSS • DEBATE • POST
              </div>
            </div>

          </div>

          <!-- Slogan & Red-Blue Underline -->
          <div class="hidden md:flex flex-col items-end pr-4">
            <span class="text-xl lg:text-2xl italic font-serif text-white tracking-wide">
              A proper British imageboard.
            </span>
            <div class="w-36 h-0.5 bg-gradient-to-r from-red-600 via-white to-blue-700 mt-1"></div>
            <span class="text-[10px] text-slate-300 font-mono-board mt-1">
              The Internet, without the performance.
            </span>
          </div>

        </div>
      </div>

      <!-- MAIN CONTENT TWO-COLUMN GRID (Matching screenshot) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-5 mb-8">
        
        <!-- LEFT COLUMN: BOARDS DIRECTORY (8 cols) -->
        <div class="lg:col-span-8">
          
          <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-sm shadow-xs overflow-hidden">
            
            <!-- Box Header -->
            <div class="bg-[#1c2d42] text-white px-4 py-2.5 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-sky-400">dashboard</mat-icon>
                <h2 class="font-bold text-sm tracking-wide">Boards</h2>
              </div>

              <!-- Quick category filter pills -->
              <div class="flex items-center gap-1 text-[11px] font-mono-board">
                <button 
                  type="button" 
                  (click)="store.activeTab.set('all')"
                  class="px-2 py-0.5 rounded cursor-pointer transition-colors"
                  [class.bg-white]="store.activeTab() === 'all'"
                  [class.text-[#1c2d42]]="store.activeTab() === 'all'"
                  [class.font-bold]="store.activeTab() === 'all'"
                  [class.text-slate-300]="store.activeTab() !== 'all'">
                  All
                </button>
                <button 
                  type="button" 
                  (click)="store.activeTab.set('society')"
                  class="px-2 py-0.5 rounded cursor-pointer transition-colors"
                  [class.bg-white]="store.activeTab() === 'society'"
                  [class.text-[#1c2d42]]="store.activeTab() === 'society'"
                  [class.font-bold]="store.activeTab() === 'society'"
                  [class.text-slate-300]="store.activeTab() !== 'society'">
                  Society
                </button>
                <button 
                  type="button" 
                  (click)="store.activeTab.set('regional')"
                  class="px-2 py-0.5 rounded cursor-pointer transition-colors"
                  [class.bg-white]="store.activeTab() === 'regional'"
                  [class.text-[#1c2d42]]="store.activeTab() === 'regional'"
                  [class.font-bold]="store.activeTab() === 'regional'"
                  [class.text-slate-300]="store.activeTab() !== 'regional'">
                  Regional
                </button>
                <button 
                  type="button" 
                  (click)="store.activeTab.set('specialist')"
                  class="px-2 py-0.5 rounded cursor-pointer transition-colors"
                  [class.bg-white]="store.activeTab() === 'specialist'"
                  [class.text-[#1c2d42]]="store.activeTab() === 'specialist'"
                  [class.font-bold]="store.activeTab() === 'specialist'"
                  [class.text-slate-300]="store.activeTab() !== 'specialist'">
                  Specialist
                </button>
              </div>
            </div>

            <!-- 3-Column Board List Grid -->
            <div class="p-3 sm:p-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-3.5 bg-[var(--board-box-bg)]">
              @for (b of store.filteredBoards(); track b.slug) {
                <div 
                  role="button"
                  tabindex="0"
                  (click)="store.navigateBoard(b.slug)"
                  (keydown.enter)="store.navigateBoard(b.slug)"
                  class="group p-2 rounded-xs border-b sm:border-b-0 border-slate-100 dark:border-slate-800/80 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors">
                  
                  <!-- Board Title & Link -->
                  <div class="flex items-center gap-1.5 font-bold text-xs text-[var(--board-link)] group-hover:text-[var(--board-highlight)] group-hover:underline">
                    <span>/{{ b.slug }}/ — {{ b.name }}</span>
                  </div>

                  <!-- Board Description -->
                  <div class="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2 leading-snug">
                    {{ b.description }}
                  </div>

                  <!-- Post count -->
                  <div class="text-[10px] text-slate-400 font-mono-board mt-1">
                    {{ formatNumber(b.postCount) }} posts
                  </div>

                </div>
              }
            </div>

          </div>

          <!-- Anonymity Declaration & Charter Note -->
          <div class="mt-4 p-3 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-sm text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            <span class="font-bold text-[var(--board-highlight)]">The Common Principles:</span> 
            No follower counts, no algorithmically inflated outrage, no personal profiles required. Post freely under a pseudonym or pure anonymity, adhering to the British Internet Charter.
          </div>

        </div>

        <!-- RIGHT COLUMN: LATEST THREADS SIDEBAR (4 cols) -->
        <div class="lg:col-span-4">
          
          <div class="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-sm shadow-xs overflow-hidden">
            
            <!-- Box Header -->
            <div class="bg-[#1c2d42] text-white px-4 py-2.5 flex items-center justify-between">
              <div class="flex items-center gap-2">
                <mat-icon class="!text-[18px] !w-[18px] !h-[18px] text-amber-400">whatshot</mat-icon>
                <h3 class="font-bold text-sm tracking-wide">Latest Threads</h3>
              </div>
            </div>

            <!-- Thread Items with Thumbnails -->
            <div class="divide-y divide-slate-100 dark:divide-slate-800">
              @for (thread of store.latestThreads(); track thread.id) {
                <div 
                  role="button"
                  tabindex="0"
                  (click)="store.openThread(thread.id)"
                  (keydown.enter)="store.openThread(thread.id)"
                  class="p-2.5 hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors flex items-center gap-3">
                  
                  <!-- Thumbnail Image -->
                  <div class="w-14 h-14 rounded-xs shrink-0 overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                    @if (thread.posts[0]?.attachment; as att) {
                      <img 
                        [src]="att.thumbnailUrl" 
                        [alt]="thread.subject"
                        referrerpolicy="no-referrer"
                        class="w-full h-full object-cover" />
                    } @else {
                      <mat-icon class="!text-2xl !w-6 !h-6 text-slate-400">forum</mat-icon>
                    }
                  </div>

                  <!-- Details -->
                  <div class="flex-1 min-w-0">
                    <h4 class="text-xs font-bold text-[#1e3a8a] dark:text-sky-400 hover:underline line-clamp-2 leading-tight">
                      {{ thread.subject }}
                    </h4>
                    <div class="text-[11px] text-slate-500 font-mono-board mt-1 flex items-center gap-2">
                      <span class="text-slate-700 dark:text-slate-300 font-semibold">/{{ thread.boardSlug }}/</span>
                      <span>— {{ thread.replyCount }} {{ thread.replyCount === 1 ? 'reply' : 'replies' }}</span>
                    </div>
                  </div>

                </div>
              }
            </div>

            <!-- View More Button -->
            <div class="p-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
              <button 
                type="button" 
                (click)="store.navigateBoard('uk')"
                class="w-full py-2 bg-gradient-to-r from-[#1c2d42] to-[#273d57] text-white text-xs font-bold rounded-xs hover:brightness-110 transition-all flex items-center justify-center gap-1 cursor-pointer shadow-xs">
                View more threads →
              </button>
            </div>

          </div>

          <!-- Quick Platform Rules Box -->
          <div class="mt-4 p-3.5 bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 rounded-sm text-xs">
            <div class="font-bold text-amber-900 dark:text-amber-200 mb-1 flex items-center gap-1">
              <mat-icon class="!text-[16px] !w-[16px] !h-[16px]">gavel</mat-icon>
              Essential Decency
            </div>
            <p class="text-amber-800/90 dark:text-amber-300/80 text-[11px] leading-relaxed">
              Strictly zero doxxing, no distribution of malware or unlawful imagery. Witty banter encouraged, malice moderated.
            </p>
            <button 
              type="button" 
              (click)="store.isRulesModalOpen.set(true)"
              class="mt-2 text-amber-900 dark:text-amber-200 font-semibold underline text-[11px] cursor-pointer">
              Read The Full Charter →
            </button>
          </div>

        </div>

      </div>

    </div>
  `
})
export class HomeView {
  store = inject(BoardStore);

  formatNumber(num: number): string {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    }
    if (num >= 1000) {
      return (num / 1000).toFixed(0) + 'K';
    }
    return String(num);
  }
}
