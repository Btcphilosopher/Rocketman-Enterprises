import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BoardStore } from './services/board-store';
import { HomeView } from './components/home-view';
import { BoardView } from './components/board-view';
import { ThreadView } from './components/thread-view';
import { NewThreadModal } from './components/new-thread-modal';
import { QuickReplyModal } from './components/quick-reply-modal';
import { ReportModal } from './components/report-modal';
import { RulesModal } from './components/rules-modal';
import { SettingsModal } from './components/settings-modal';
import { ModDashboardModal } from './components/mod-dashboard-modal';
import { LightboxModal } from './components/lightbox-modal';
import { HoverQuotePopover } from './components/hover-quote-popover';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatIconModule,
    HomeView,
    BoardView,
    ThreadView,
    NewThreadModal,
    QuickReplyModal,
    ReportModal,
    RulesModal,
    SettingsModal,
    ModDashboardModal,
    LightboxModal,
    HoverQuotePopover
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  store = inject(BoardStore);

  searchControl = new FormControl<string>('');
  isMoreBoardsOpen = signal<boolean>(false);

  // Quick ticker boards shown in the top navigation bar (matching screenshot)
  tickerBoards = [
    { slug: 'b', name: 'Random' },
    { slug: 'uk', name: 'UK Politics' },
    { slug: 'lon', name: 'London' },
    { slug: 'north', name: 'The North' },
    { slug: 'tech', name: 'Tech' },
    { slug: 'comp', name: 'Computing' },
    { slug: 'hist', name: 'History' },
    { slug: 'food', name: 'Food & Cooking' },
    { slug: 'sport', name: 'Sport' },
    { slug: 'music', name: 'Music' }
  ];

  onSearchSubmit(): void {
    const query = this.searchControl.value || '';
    this.store.searchQuery.set(query);
    this.store.loadThreads();
  }

  clearSearch(): void {
    this.searchControl.setValue('');
    this.store.searchQuery.set('');
    this.store.loadThreads();
  }
}
