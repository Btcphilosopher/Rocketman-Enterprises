export interface Board {
  slug: string;
  name: string;
  category: 'society' | 'regional' | 'specialist';
  description: string;
  rules: string[];
  postCount: number;
  threadCount: number;
  nsfw: boolean;
  bumpLimit: number;
  cooldownSeconds: number;
}

export interface Attachment {
  id: string;
  url: string;
  thumbnailUrl: string;
  fileName: string;
  fileSize: string;
  dimensions: string;
  type: string;
}

export interface Post {
  id: number;
  threadId: number;
  boardSlug: string;
  isOp: boolean;
  subject?: string;
  author: string;
  authorId: string; // Pseudonymous hash for thread, e.g. "x8Ab9"
  tripcode?: string;
  createdAt: string;
  timestamp: number;
  comment: string;
  attachment?: Attachment;
  replyToIds: number[]; // quotes inside this comment (e.g. >>12345)
  repliesFromIds: number[]; // backlinks to this post
  isSticky?: boolean;
  isLocked?: boolean;
  isArchived?: boolean;
  moderated?: boolean;
}

export interface Thread {
  id: number;
  boardSlug: string;
  subject: string;
  opPostId: number;
  createdAt: string;
  lastBumpAt: number;
  replyCount: number;
  imageCount: number;
  isSticky: boolean;
  isLocked: boolean;
  isArchived: boolean;
  posts: Post[];
}

export interface Report {
  id: string;
  postId: number;
  threadId: number;
  boardSlug: string;
  reason: 'doxxing' | 'spam' | 'harassment' | 'illegal' | 'off-topic';
  details: string;
  createdAt: string;
  status: 'pending' | 'resolved' | 'dismissed';
}

export interface AuditLog {
  id: string;
  moderator: string;
  action: string;
  targetId: string;
  targetType: 'thread' | 'post' | 'user' | 'board';
  timestamp: string;
  reason: string;
}

export const INITIAL_BOARDS: Board[] = [
  // British Society and Culture
  {
    slug: 'b',
    name: 'General Discussion',
    category: 'society',
    description: 'British everyday life, internet culture, random conversations and banter.',
    rules: ['No illegal content under UK law', 'No doxxing or personal data', 'No spamming'],
    postCount: 3749810,
    threadCount: 14200,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 15
  },
  {
    slug: 'uk',
    name: 'United Kingdom',
    category: 'society',
    description: 'British politics, public affairs, institutions, national life and current events.',
    rules: ['Keep discussions civilised', 'Provide sources for extraordinary claims', 'No party campaign bots'],
    postCount: 953420,
    threadCount: 4200,
    nsfw: false,
    bumpLimit: 400,
    cooldownSeconds: 20
  },
  {
    slug: 'eng',
    name: 'England',
    category: 'regional',
    description: 'English culture, regional identity, history, countryside and contemporary society.',
    rules: ['English regional affairs focus', 'No targeted bigotry'],
    postCount: 684200,
    threadCount: 3100,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'scot',
    name: 'Scotland',
    category: 'regional',
    description: 'Scottish society, Highlands & Lowlands, culture, politics and debate.',
    rules: ['Civic debate welcomed', 'No tribal sectarian abuse'],
    postCount: 412900,
    threadCount: 1850,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'wales',
    name: 'Wales',
    category: 'regional',
    description: 'Welsh culture, language, valleys, coastlines, and national discussion.',
    rules: ['Cymraeg and English both welcomed', 'Respect regional heritage'],
    postCount: 224100,
    threadCount: 940,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'ire',
    name: 'Ireland',
    category: 'regional',
    description: 'Irish culture, history, cross-border affairs and archipelago dialogue.',
    rules: ['Respect historical sensitivities', 'Good faith discussion'],
    postCount: 341800,
    threadCount: 1400,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'lon',
    name: 'London',
    category: 'regional',
    description: 'London transport, housing, architecture, nightlife, TfL and capital life.',
    rules: ['Metropolitan focus', 'No housing fraud advertisements'],
    postCount: 789300,
    threadCount: 3400,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 15
  },
  {
    slug: 'north',
    name: 'The North',
    category: 'regional',
    description: 'Northern England: Manchester, Leeds, Sheffield, Newcastle, Yorkshire and regional soul.',
    rules: ['Proper northern grit', 'Chip shop etiquette is strictly enforced'],
    postCount: 512400,
    threadCount: 2200,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 15
  },
  // Specialist & Interests
  {
    slug: 'tech',
    name: 'Technology',
    category: 'specialist',
    description: 'British & international tech industry, hardware, semiconductors, gadgets and innovation.',
    rules: ['Technical discussion preferred', 'No affiliate links'],
    postCount: 942100,
    threadCount: 3800,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'comp',
    name: 'Computing',
    category: 'specialist',
    description: 'Computer science, Linux, BSD, vintage British hardware (BBC Micro, ZX Spectrum, ARM).',
    rules: ['Share code snippets in [code] tags', 'Open source advocacy encouraged'],
    postCount: 1240000,
    threadCount: 4900,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'ai',
    name: 'Artificial Intelligence',
    category: 'specialist',
    description: 'Machine learning, neural networks, ethics, robotics and the frontier.',
    rules: ['Evidence-based technical critiques', 'Distinguish hype from capability'],
    postCount: 510400,
    threadCount: 2100,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'eco',
    name: 'Economics & Finance',
    category: 'specialist',
    description: 'The City of London, Bank of England, macroeconomics, property, pensions and markets.',
    rules: ['No financial pump & dumps', 'Data-driven analysis appreciated'],
    postCount: 631000,
    threadCount: 2600,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'biz',
    name: 'Business & Enterprise',
    category: 'specialist',
    description: 'UK SMEs, startup ventures, manufacturing, British commerce and trade.',
    rules: ['No unvetted promotions', 'Real case studies welcomed'],
    postCount: 310000,
    threadCount: 1300,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'arch',
    name: 'Architecture',
    category: 'specialist',
    description: 'Georgian, Gothic revival, Brutalism, town planning, urban regeneration and design.',
    rules: ['Include architect or location where known', 'Polite critiques'],
    postCount: 420000,
    threadCount: 1750,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'engg',
    name: 'Engineering',
    category: 'specialist',
    description: 'Civil, mechanical, aerospace (Rolls-Royce, BAE), maritime and structural engineering.',
    rules: ['Blueprints and schematics welcomed', 'Safety standards respected'],
    postCount: 390000,
    threadCount: 1600,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'sci',
    name: 'Science',
    category: 'specialist',
    description: 'Physics, biology, astronomy, Royal Society heritage, climate and pure research.',
    rules: ['Peer review mindset', 'Cite papers where appropriate'],
    postCount: 480000,
    threadCount: 2000,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'hist',
    name: 'History',
    category: 'specialist',
    description: 'British, European and global history, archaeology, Roman Britain, industrial era.',
    rules: ['Historiographical rigor', 'No denialism or revisionist propaganda'],
    postCount: 621000,
    threadCount: 2800,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'phil',
    name: 'Philosophy',
    category: 'specialist',
    description: 'British empiricism (Locke, Hume), continental thought, logic, epistemology and ethics.',
    rules: ['Formulate clear premises', 'Steel-man opposing arguments'],
    postCount: 380000,
    threadCount: 1600,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'lit',
    name: 'Literature',
    category: 'specialist',
    description: 'Shakespeare, Orwell, Tolkien, Virginia Woolf, poetry, essays and book reviews.',
    rules: ['Spoilers must use [spoiler] tags', 'Original writing critiques'],
    postCount: 450000,
    threadCount: 1900,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'music',
    name: 'Music',
    category: 'specialist',
    description: 'British rock, grime, jungle, electronic, classical, indie, vinyl and live gigs.',
    rules: ['Share track names and years', 'No spamming self-promo'],
    postCount: 1100000,
    threadCount: 4300,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'film',
    name: 'Film & Television',
    category: 'specialist',
    description: 'British cinema, BBC drama, Channel 4 classics, documentary filmmaking and critique.',
    rules: ['Use spoiler tags for plot twists', 'Review analysis welcomed'],
    postCount: 1200000,
    threadCount: 4600,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'art',
    name: 'Art & Design',
    category: 'specialist',
    description: 'Typography, illustration, Turner, Constable, modernism, graphic design and print.',
    rules: ['Credit creators', 'High resolution images appreciated'],
    postCount: 310000,
    threadCount: 1200,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'games',
    name: 'Gaming',
    category: 'specialist',
    description: 'Video games, UK development studios (DMA Design, Rare, Rockstar North, Frontier).',
    rules: ['No piracy links', 'Platform banter permitted in good fun'],
    postCount: 1800000,
    threadCount: 6500,
    nsfw: false,
    bumpLimit: 350,
    cooldownSeconds: 20
  },
  {
    slug: 'auto',
    name: 'Cars & Motoring',
    category: 'specialist',
    description: 'Aston Martin, Jaguar, Land Rover, classics, motorways, track days and engineering.',
    rules: ['No street racing endorsements', 'Show and tell builds welcomed'],
    postCount: 520000,
    threadCount: 2100,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'travel',
    name: 'Travel & Geography',
    category: 'specialist',
    description: 'Coast paths, Lake District, Scottish Highlands, Ordnance Survey maps and global travel.',
    rules: ['Share coordinates or route tips', 'Leave no trace in nature'],
    postCount: 487000,
    threadCount: 1900,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'rail',
    name: 'Railways & Transport',
    category: 'specialist',
    description: 'British Rail heritage, High Speed 2, rolling stock, steam specials, TfL networks.',
    rules: ['Trainspotting logs encouraged', 'Timetable accuracy prized'],
    postCount: 395000,
    threadCount: 1600,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'food',
    name: 'Food & Cooking',
    category: 'specialist',
    description: 'Traditional pies, Sunday roasts, fish & chips, baking, ales, tea and gastro-pubs.',
    rules: ['Post your recipes', 'Beans on toast critique is subject to scrutiny'],
    postCount: 512000,
    threadCount: 2300,
    nsfw: false,
    bumpLimit: 300,
    cooldownSeconds: 20
  },
  {
    slug: 'sport',
    name: 'Sport',
    category: 'specialist',
    description: 'Premier League, EFL, Six Nations Rugby, Cricket, Wimbledon, Formula 1 and Athletics.',
    rules: ['Match threads only during fixtures', 'No pitch invasion glorification'],
    postCount: 1400000,
    threadCount: 5200,
    nsfw: false,
    bumpLimit: 400,
    cooldownSeconds: 15
  }
];
