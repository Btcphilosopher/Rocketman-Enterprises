import { Thread, Report, AuditLog } from './data';

// Helper to format date in classic imageboard UK format: DD/MM/YY(Day)HH:MM:SS
export function formatUkBoardDate(d: Date): string {
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = String(d.getFullYear()).slice(-2);
  const dayName = days[d.getDay()];
  const hh = String(d.getHours()).padStart(2, '0');
  const min = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${dd}/${mm}/${yy}(${dayName})${hh}:${min}:${ss}`;
}

export const INITIAL_THREADS: Thread[] = [
  {
    id: 10428,
    boardSlug: 'uk',
    subject: "The UK's future in 2030? Energy, infrastructure and productivity",
    opPostId: 4918201,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 5)),
    lastBumpAt: Date.now() - 1000 * 60 * 8,
    replyCount: 14,
    imageCount: 3,
    isSticky: true,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918201,
        threadId: 10428,
        boardSlug: 'uk',
        isOp: true,
        subject: "The UK's future in 2030? Energy, infrastructure and productivity",
        author: 'Anonymous',
        authorId: 'ox9F2b',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 5)),
        timestamp: Date.now() - 3600000 * 5,
        comment: `Where do you see the British economy and public infrastructure realistically by 2030?

>North Sea wind generation expanding rapidly
>Grid connectivity still bottle-necked in central corridors
>Sizewell C progress underway
>R&D clusters around Oxford, Cambridge and Edinburgh booming

Will we finally solve regional transport bottlenecks or are we fated to keep debating railway spurs for another twenty years? Sensible thoughts only.`,
        attachment: {
          id: 'att-1',
          url: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=400&q=70',
          fileName: 'london_parliament_dawn.jpg',
          fileSize: '438 KB',
          dimensions: '1920x1080',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: [4918205, 4918212, 4918224]
      },
      {
        id: 4918205,
        threadId: 10428,
        boardSlug: 'uk',
        isOp: false,
        author: 'Anonymous',
        authorId: '7aC41e',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 4.6)),
        timestamp: Date.now() - 3600000 * 4.6,
        comment: `>>4918201
>Will we finally solve regional transport bottlenecks
Not without serious planning deregulation. 

The issue has never been lack of civil engineers or capital; it's that every two miles of railway track in England requires six environmental impact assessments, eleven judicial reviews and a consultation with the local vicar's badger appreciation society.`,
        replyToIds: [4918201],
        repliesFromIds: [4918209]
      },
      {
        id: 4918209,
        threadId: 10428,
        boardSlug: 'uk',
        isOp: false,
        author: 'Anonymous',
        authorId: '3dE89a',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 4.1)),
        timestamp: Date.now() - 3600000 * 4.1,
        comment: `>>4918205
Spot on. Look at France or Spain: they build high speed track at €15m per kilometre. We were paying £120m/km on HS2 because of endless tunneling to avoid ruining someone's view of an abandoned field in Buckinghamshire.

If the UK wants clean cheap energy by 2030 we need to build the pylons across East Anglia immediately.`,
        replyToIds: [4918205],
        repliesFromIds: [4918212]
      },
      {
        id: 4918212,
        threadId: 10428,
        boardSlug: 'uk',
        isOp: false,
        author: 'Anonymous',
        authorId: 'ox9F2b',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 3.5)),
        timestamp: Date.now() - 3600000 * 3.5,
        comment: `>>4918201 >>4918209
>If the UK wants clean cheap energy by 2030 we need to build the pylons across East Anglia immediately.
Agreed OP here. Offshore wind in the Dogger Bank is world class. Scotland generates over 100% of its electricity demand from renewables on windy days, but England can't take the transmission load due to constrained interconnectors.

Fixing grid storage and interconnections is the single highest ROI national project right now.`,
        replyToIds: [4918201, 4918209],
        repliesFromIds: [4918218]
      },
      {
        id: 4918218,
        threadId: 10428,
        boardSlug: 'uk',
        isOp: false,
        author: 'Anonymous',
        authorId: 'bB4920',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 2.2)),
        timestamp: Date.now() - 3600000 * 2.2,
        comment: `>>4918212
Don't underestimate British life sciences and biotech though. The Golden Triangle (London-Oxford-Cambridge) raises more venture funding than France and Germany combined.

If we combine that with domestic clean power, the 2030 picture is far brighter than the Sunday tabloids would have you believe.`,
        replyToIds: [4918212],
        repliesFromIds: []
      },
      {
        id: 4918224,
        threadId: 10428,
        boardSlug: 'uk',
        isOp: false,
        author: 'Anonymous',
        authorId: 'c12Fa0',
        createdAt: formatUkBoardDate(new Date(Date.now() - 1000 * 60 * 8)),
        timestamp: Date.now() - 1000 * 60 * 8,
        comment: `>>4918201
Just build houses where the jobs are. It genuinely is that simple. When a 1-bed flat in Zone 3 costs 12x median income, people can't start families or take career risks. Fix housing supply, fix the country.`,
        replyToIds: [4918201],
        repliesFromIds: []
      }
    ]
  },
  {
    id: 10432,
    boardSlug: 'sp',
    subject: "Premier League tactical trends: Man United and the low-block resurgence",
    opPostId: 4918301,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 7)),
    lastBumpAt: Date.now() - 1000 * 60 * 14,
    replyCount: 22,
    imageCount: 2,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918301,
        threadId: 10432,
        boardSlug: 'sp',
        isOp: true,
        subject: "Premier League tactical trends: Man United and the low-block resurgence",
        author: 'Anonymous',
        authorId: '88aB1c',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 7)),
        timestamp: Date.now() - 3600000 * 7,
        comment: `Can we talk about the death of pure possession football in the English top flight?

Mid-table sides used to try and out-pass City and Arsenal and get ripped open 5-0. Now everyone is running 5-4-1 mid-blocks with explosive transitional wingers and long throws.

>Pep looking exhausted on the touchline
>Every corner taking 90 seconds of set-piece wrestling
>Proper physical English football returning to the menus

Thoughts on whether this is sustainable or just a cyclical phase?`,
        attachment: {
          id: 'att-2',
          url: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&w=400&q=70',
          fileName: 'wembley_matchday.jpg',
          fileSize: '512 KB',
          dimensions: '1920x1280',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: [4918305, 4918310]
      },
      {
        id: 4918305,
        threadId: 10432,
        boardSlug: 'sp',
        isOp: false,
        author: 'Anonymous',
        authorId: 'fe2910',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 5.8)),
        timestamp: Date.now() - 3600000 * 5.8,
        comment: `>>4918301
Set pieces account for over 35% of all non-penalty xG this season. Clubs literally hired NFL kicking coaches to drill in-swinging corners right under the crossbar.

The goalkeeper harassment rule will get updated in the summer, mark my words.`,
        replyToIds: [4918301],
        repliesFromIds: []
      },
      {
        id: 4918310,
        threadId: 10432,
        boardSlug: 'sp',
        isOp: false,
        author: 'Anonymous',
        authorId: '990a44',
        createdAt: formatUkBoardDate(new Date(Date.now() - 1000 * 60 * 14)),
        timestamp: Date.now() - 1000 * 60 * 14,
        comment: `>>4918301
>Proper physical English football returning
Nature is healing. Watching 800 sideways passes between centre-backs on a cold wet Tuesday was soul destroying. Give me a 40-yard diagonal ball into the mixer any day of the week.`,
        replyToIds: [4918301],
        repliesFromIds: []
      }
    ]
  },
  {
    id: 10440,
    boardSlug: 'hist',
    subject: "Stonehenge & Salisbury Plain: New magnetometry survey revelations",
    opPostId: 4918401,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 12)),
    lastBumpAt: Date.now() - 1000 * 60 * 32,
    replyCount: 18,
    imageCount: 4,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918401,
        threadId: 10440,
        boardSlug: 'hist',
        isOp: true,
        subject: "Stonehenge & Salisbury Plain: New magnetometry survey revelations",
        author: 'Anonymous',
        authorId: 'aa14F0',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 12)),
        timestamp: Date.now() - 3600000 * 12,
        comment: `The latest lidar and ground-penetrating radar across the greater Salisbury Plain landscape shows Stonehenge was merely one node in an interconnected ceremonial complex spanning over 20 square kilometres.

>Durrington Walls timber monument
>The Greater Cursus pre-dating the sarsen circle by centuries
>Avenue aligning precisely with winter solstice sunset

The sheer logistical feat of moving 4-ton bluestones from the Preseli Hills in Pembrokeshire, Wales across 140 miles of Neolithic terrain is still mind-boggling. How did they cross the Severn estuary? Rafts or land haulage?`,
        attachment: {
          id: 'att-3',
          url: 'https://images.unsplash.com/photo-1599833975787-5c143f373c30?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1599833975787-5c143f373c30?auto=format&fit=crop&w=400&q=70',
          fileName: 'stonehenge_mist_salisbury.jpg',
          fileSize: '612 KB',
          dimensions: '1920x1080',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: [4918408]
      },
      {
        id: 4918408,
        threadId: 10440,
        boardSlug: 'hist',
        isOp: false,
        author: 'Anonymous',
        authorId: '772bC1',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 8)),
        timestamp: Date.now() - 3600000 * 8,
        comment: `>>4918401
Experimental archaeology in 2018 practically ruled out maritime rafting for the heaviest megaliths due to tidal bores in the Bristol Channel. 

Current consensus leans toward overland trackways using grease-soaked oak sledges on wooden rails. It required an organised workforce of several thousand people, proving Britain had advanced social cooperation as early as 3000 BC.`,
        replyToIds: [4918401],
        repliesFromIds: []
      }
    ]
  },
  {
    id: 10455,
    boardSlug: 'tech',
    subject: "Semiconductor sovereignty: The UK's quiet dominance in compound silicon & ARM",
    opPostId: 4918501,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 15)),
    lastBumpAt: Date.now() - 1000 * 60 * 45,
    replyCount: 29,
    imageCount: 3,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918501,
        threadId: 10455,
        boardSlug: 'tech',
        isOp: true,
        subject: "Semiconductor sovereignty: The UK's quiet dominance in compound silicon & ARM",
        author: 'Anonymous',
        authorId: '10fF3c',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 15)),
        timestamp: Date.now() - 3600000 * 15,
        comment: `People lament that Britain doesn't have a giant TSMC or Samsung fab, but they completely miss what the UK actually excels at:

1. ARM architecture (Cambridge) - powers 99% of smartphones on earth and now conquering data centres and Apple Silicon.
2. Compound semiconductors in South Wales (Newport cluster) - GaN (Gallium Nitride) and InP for photonics, EV inverters and 6G telecom.
3. Graphcore / AI accelerator design.

You don't need to pour billions into 2nm silicon fabs when you design the fundamental instruction sets and RF photonics the world can't live without.`,
        attachment: {
          id: 'att-4',
          url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=400&q=70',
          fileName: 'silicon_wafer_microchip.jpg',
          fileSize: '584 KB',
          dimensions: '1920x1200',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: [4918507]
      },
      {
        id: 4918507,
        threadId: 10455,
        boardSlug: 'tech',
        isOp: false,
        author: 'Anonymous',
        authorId: 'e81a02',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 6)),
        timestamp: Date.now() - 3600000 * 6,
        comment: `>>4918501
>ARM architecture (Cambridge)
Lest anyone forgets, ARM began life in 1985 as 'Acorn RISC Machine' inside a converted watermill in Cambridge to run educational software on the BBC Micro.

Sophie Wilson and Steve Furber designed the original 32-bit RISC core with less than 25,000 transistors. Pure British engineering elegance.`,
        replyToIds: [4918501],
        repliesFromIds: []
      }
    ]
  },
  {
    id: 10460,
    boardSlug: 'food',
    subject: "Traditional British Ales: The revival of cask conditioned bitter & mild",
    opPostId: 4918601,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 20)),
    lastBumpAt: Date.now() - 1000 * 60 * 55,
    replyCount: 34,
    imageCount: 5,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918601,
        threadId: 10460,
        boardSlug: 'food',
        isOp: true,
        subject: "Traditional British Ales: The revival of cask conditioned bitter & mild",
        author: 'Anonymous',
        authorId: '54cB91',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 20)),
        timestamp: Date.now() - 3600000 * 20,
        comment: `Tired of over-hopped 8.5% murky grapefruit NEIPAs that cost £8.50 a schooner.

Nothing beats a proper pint of cellar-temperature, hand-pulled Yorkshire bitter with a creamy tight head. Fuggles and Goldings hops, Maris Otter malt, natural secondary fermentation in the wood.

What is your local independent brewery championing traditional cask?
CAMRA members and pub regulars assemble.`,
        attachment: {
          id: 'att-5',
          url: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1535958636474-b021ee887b13?auto=format&fit=crop&w=400&q=70',
          fileName: 'cask_ale_pub_pint.jpg',
          fileSize: '410 KB',
          dimensions: '1600x1066',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: [4918610]
      },
      {
        id: 4918610,
        threadId: 10460,
        boardSlug: 'food',
        isOp: false,
        author: 'Anonymous',
        authorId: '33b491',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 14)),
        timestamp: Date.now() - 3600000 * 14,
        comment: `>>4918601
Timothy Taylor's Landlord and Theakston Old Peculier are national treasures. 

There is an art to cellar keeping that craft keg joints completely lack. If the landlord hasn't cleaned the lines on Tuesday and vented the spile properly, you can taste it in a heartbeat.`,
        replyToIds: [4918601],
        repliesFromIds: []
      }
    ]
  },
  {
    id: 10472,
    boardSlug: 'b',
    subject: "A proper cuppa: The definitive tea ranking and protocol",
    opPostId: 4918701,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 2)),
    lastBumpAt: Date.now() - 1000 * 60 * 3,
    replyCount: 42,
    imageCount: 6,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918701,
        threadId: 10472,
        boardSlug: 'b',
        isOp: true,
        subject: "A proper cuppa: The definitive tea ranking and protocol",
        author: 'Anonymous',
        authorId: 'te4B00',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 2)),
        timestamp: Date.now() - 3600000 * 2,
        comment: `>Wake up in foggy Leeds
>Put the kettle on, fresh water from the cold tap
>Yorkshire Gold teabag in earthenware mug
>Water boiled to vigorous 100°C
>Pour immediately over bag
>Steep for minimum four full minutes, no early squeezing
>Remove bag with dignity
>Splash of whole milk until it matches Pantone 7508 C (golden biscuit)
>Zero sugar because we are civilised adults

Post your tea setup. Anyone putting milk in before hot water will be reported for crimes against the realm.`,
        attachment: {
          id: 'att-6',
          url: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=400&q=70',
          fileName: 'proper_british_tea.jpg',
          fileSize: '390 KB',
          dimensions: '1920x1280',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: [4918704, 4918709]
      },
      {
        id: 4918704,
        threadId: 10472,
        boardSlug: 'b',
        isOp: false,
        author: 'Anonymous',
        authorId: '98dD11',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 1.5)),
        timestamp: Date.now() - 3600000 * 1.5,
        comment: `>>4918701
>Splash of whole milk until it matches Pantone 7508 C
Based and tea-pilled. 

The worst offenders are people who squeeze the bag against the spoon with the fury of a thousand suns, releasing all the harsh bitter tannins into what could have been a sublime brew.`,
        replyToIds: [4918701],
        repliesFromIds: []
      },
      {
        id: 4918709,
        threadId: 10472,
        boardSlug: 'b',
        isOp: false,
        author: 'Anonymous',
        authorId: 'fa3108',
        createdAt: formatUkBoardDate(new Date(Date.now() - 1000 * 60 * 3)),
        timestamp: Date.now() - 1000 * 60 * 3,
        comment: `>>4918701
What biscuit are we accompanying with this? 
Dark chocolate digestive, ginger nut or rich tea? 
Choose carefully. Your citizenship depends on this answer.`,
        replyToIds: [4918701],
        repliesFromIds: []
      }
    ]
  },
  {
    id: 10480,
    boardSlug: 'lon',
    subject: "Elizabeth Line & Crossrail 2: Urban transit engineering masterclass",
    opPostId: 4918801,
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 8)),
    lastBumpAt: Date.now() - 1000 * 60 * 18,
    replyCount: 16,
    imageCount: 2,
    isSticky: false,
    isLocked: false,
    isArchived: false,
    posts: [
      {
        id: 4918801,
        threadId: 10480,
        boardSlug: 'lon',
        isOp: true,
        subject: "Elizabeth Line & Crossrail 2: Urban transit engineering masterclass",
        author: 'Anonymous',
        authorId: 'lon77A',
        createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 8)),
        timestamp: Date.now() - 3600000 * 8,
        comment: `Stepping into Paddington or Tottenham Court Road Elizabeth Line stations feels like arriving in 2045 compared to the 120-year-old Central line platforms.

Full platform screen doors, air conditioning that actually functions during July heatwaves, 200m walk-through carriages, smooth regenerative braking.

Why did we put Crossrail 2 on ice? Wimbledon to Tottenham Hale would unlock thousands of homes. Discuss.`,
        attachment: {
          id: 'att-7',
          url: 'https://images.unsplash.com/photo-1543783207-ec64e4d95325?auto=format&fit=crop&w=1200&q=80',
          thumbnailUrl: 'https://images.unsplash.com/photo-1543783207-ec64e4d95325?auto=format&fit=crop&w=400&q=70',
          fileName: 'elizabeth_line_station.jpg',
          fileSize: '462 KB',
          dimensions: '1920x1080',
          type: 'image/jpeg'
        },
        replyToIds: [],
        repliesFromIds: []
      }
    ]
  }
];

export const INITIAL_REPORTS: Report[] = [
  {
    id: 'rep-1',
    postId: 4918205,
    threadId: 10428,
    boardSlug: 'uk',
    reason: 'spam',
    details: 'User alleged repeated duplicate phrasing across multiple threads.',
    createdAt: formatUkBoardDate(new Date(Date.now() - 3600000 * 2)),
    status: 'pending'
  }
];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'audit-1',
    moderator: 'Senior Mod #4 (Janitor)',
    action: 'Sticky Thread',
    targetId: '10428',
    targetType: 'thread',
    timestamp: formatUkBoardDate(new Date(Date.now() - 3600000 * 4)),
    reason: 'High-value national discussion sticky'
  },
  {
    id: 'audit-2',
    moderator: 'Board Mod /uk/',
    action: 'Clean Spam',
    targetId: '4917992',
    targetType: 'post',
    timestamp: formatUkBoardDate(new Date(Date.now() - 3600000 * 18)),
    reason: 'Automated crypto pump bot removed'
  }
];
