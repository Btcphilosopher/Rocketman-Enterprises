import { Injectable, signal, computed } from '@angular/core';
import { 
  Recipe, 
  Ingredient, 
  Machine, 
  ProductionBatch, 
  ProductionOrder, 
  CCPMonitor, 
  SPCMetricSeries, 
  QualitySample, 
  ViewMode, 
  MachineStatus,
  TestKitchenExperiment,
  BatchStage
} from '../models/bakery.models';
import { 
  INITIAL_INGREDIENTS, 
  RECIPES_CATALOG, 
  INITIAL_MACHINES, 
  INITIAL_BATCHES, 
  INITIAL_ORDERS, 
  INITIAL_CCPS, 
  INITIAL_SPC_METRICS 
} from '../data/initial-bakery-data';

export type NavigationTab = 
  | 'control-room'
  | 'factory-floor'
  | 'signature-run'
  | 'recipes'
  | 'machine-twins'
  | 'weighing-dosing'
  | 'stop-clock'
  | 'planner'
  | 'quality-spc'
  | 'haccp'
  | 'traceability'
  | 'test-kitchen'
  | 'maintenance';

export interface FactoryEventItem {
  id: string;
  timestamp: string;
  category: 'BATCH' | 'MACHINE' | 'QUALITY' | 'SAFETY' | 'ALLERGEN';
  message: string;
  machineCode?: string;
  batchId?: string;
}

@Injectable({
  providedIn: 'root'
})
export class BakeOSFactoryService {
  // Navigation & View Mode
  readonly activeTab = signal<NavigationTab>('control-room');
  readonly viewMode = signal<ViewMode>('photorealistic');

  // Master Factory Clock & Speed Control
  readonly simSpeed = signal<number>(1.0);
  readonly isSimRunning = signal<boolean>(true);
  readonly simSecondsElapsed = signal<number>(8 * 3600 + 42 * 60 + 17); // Starts at 08:42:17

  // Conveyor speed (m/min)
  readonly conveyorSpeedMPerMin = signal<number>(1.2);

  // Entities
  readonly recipes = signal<Recipe[]>(RECIPES_CATALOG);
  readonly selectedRecipe = signal<Recipe>(RECIPES_CATALOG[0]);

  readonly ingredients = signal<Ingredient[]>(INITIAL_INGREDIENTS);
  
  readonly machines = signal<Machine[]>(INITIAL_MACHINES);
  readonly selectedMachine = signal<Machine>(INITIAL_MACHINES[0]); // M-04

  readonly batches = signal<ProductionBatch[]>(INITIAL_BATCHES);
  readonly activeBatchId = signal<string>('BATCH-82041');

  readonly orders = signal<ProductionOrder[]>(INITIAL_ORDERS);
  readonly ccps = signal<CCPMonitor[]>(INITIAL_CCPS);
  readonly spcMetrics = signal<SPCMetricSeries[]>(INITIAL_SPC_METRICS);

  // Dynamic Live Twin Telemetry States
  readonly mixerTwinState = signal({
    rotationDeg: 0,
    planetaryDeg: 0,
    currentStepIndex: 1, // Stage 2
    rpm: 184,
    torqueNm: 84.2,
    bowlTempC: 19.4,
    whiskTool: 'WHISK' as 'WHISK' | 'PADDLE' | 'DOUGH_HOOK'
  });

  readonly ovenTwinState = signal({
    zone1Temp: 182.4,
    zone2Temp: 176.1,
    zone3Temp: 165.2,
    exhaustFlowM3h: 420,
    productCoreTemp: 94.2,
    targetTempCurve: [20, 65, 88, 94.0, 94.2],
    actualTempCurve: [19.8, 64.2, 87.5, 93.8, 94.2]
  });

  readonly roboticDecoratorState = signal({
    x: 100.2,
    y: 98.4,
    z: 110.0,
    speedMmS: 120,
    currentPattern: 'ROSETTE 08 / 12',
    pressureBar: 2.48,
    visionCorrectionOffsetMm: { dx: 0.12, dy: -0.08 },
    nozzleActive: true,
    turntableAngleDeg: 45
  });

  readonly scaleStationState = signal({
    ingredientName: 'West Country Farmhouse Butter',
    lotNumber: 'LOT-B-77401',
    targetKg: 56.250,
    currentKg: 56.248,
    toleranceKg: 0.020,
    status: 'IN_TOLERANCE' as 'UNDER' | 'IN_TOLERANCE' | 'OVER',
    isDispensing: false,
    authorizedOverride: false,
    scaleId: 'SCALE-W01'
  });

  readonly siloSystemState = signal({
    flourSiloLevelPercent: 64.2,
    sugarSiloLevelPercent: 78.5,
    activeDosing: false,
    targetKg: 56.25,
    actualDosedKg: 56.24,
    flowRateKgS: 0.0
  });

  // Dedicated Mechanical Chronometer & Stop Clock
  readonly stopClockState = signal({
    isRunning: true,
    elapsedMs: (4 * 60 + 32) * 1000,
    laps: [
      { id: 1, name: 'BATCH-82041 Stage 1: Creaming Butter & Sugar', timeMs: 150000 },
      { id: 2, name: 'BATCH-82041 Stage 2: Liquid Egg Dosing', timeMs: 180000 },
      { id: 3, name: 'BATCH-82041 Stage 3: Low-Shear Flour Fold', timeMs: 75000 }
    ],
    timers: [
      { id: 'T1', name: 'Batch 82041 Total Cycle', targetMs: 195 * 60 * 1000, remainingMs: 58 * 60 * 1000, isRunning: true },
      { id: 'T2', name: 'Mixer M-04 Creaming Stage', targetMs: 150 * 1000, remainingMs: 0, isRunning: false },
      { id: 'T3', name: 'Oven O-07 Residence Bake', targetMs: 22 * 60 * 1000, remainingMs: 0, isRunning: false },
      { id: 'T4', name: 'Cooling Tunnel Dwell', targetMs: 38 * 60 * 1000, remainingMs: 0, isRunning: false },
      { id: 'T5', name: 'Robotic Decorator R-07 Run', targetMs: 14 * 60 * 1000, remainingMs: 4 * 60 * 1000 + 20000, isRunning: true }
    ]
  });

  // Vision QC Live Inspections
  readonly recentQualitySamples = signal<QualitySample[]>([
    { id: 'QS-01', sampleCode: 'CAKE-82041-342', batchId: 'BATCH-82041', timestamp: '09:24:18', weightGrams: 450.4, heightMm: 110.2, diameterMm: 200.1, browningIndex: 0.94, decorationAlignmentPercent: 99.2, status: 'PASS', cameraImageUrl: '/assets/images/victoria_sponge_spec_1791368023892.jpg' },
    { id: 'QS-02', sampleCode: 'CAKE-82041-341', batchId: 'BATCH-82041', timestamp: '09:24:02', weightGrams: 449.8, heightMm: 109.8, diameterMm: 199.9, browningIndex: 0.96, decorationAlignmentPercent: 98.8, status: 'PASS', cameraImageUrl: '/assets/images/victoria_sponge_spec_1791368023892.jpg' },
    { id: 'QS-03', sampleCode: 'CAKE-82041-340', batchId: 'BATCH-82041', timestamp: '09:23:46', weightGrams: 451.2, heightMm: 110.6, diameterMm: 200.4, browningIndex: 0.92, decorationAlignmentPercent: 99.4, status: 'PASS', cameraImageUrl: '/assets/images/victoria_sponge_spec_1791368023892.jpg' },
    { id: 'QS-04', sampleCode: 'CAKE-82041-339', batchId: 'BATCH-82041', timestamp: '09:23:30', weightGrams: 433.0, heightMm: 104.2, diameterMm: 197.8, browningIndex: 1.45, decorationAlignmentPercent: 94.1, status: 'REJECT', defectReason: 'Underweight (-17g below min 435g tolerance)', cameraImageUrl: '/assets/images/victoria_sponge_spec_1791368023892.jpg' },
    { id: 'QS-05', sampleCode: 'CAKE-82041-338', batchId: 'BATCH-82041', timestamp: '09:23:14', weightGrams: 450.6, heightMm: 110.1, diameterMm: 200.0, browningIndex: 0.95, decorationAlignmentPercent: 98.9, status: 'PASS', cameraImageUrl: '/assets/images/victoria_sponge_spec_1791368023892.jpg' }
  ]);

  // Event stream
  readonly eventStream = signal<FactoryEventItem[]>([
    { id: 'EVT-101', timestamp: '09:24:18', category: 'QUALITY', message: 'Vision QC Inspector V-01 verified sample CAKE-82041-342: PASS (Weight 450.4g, Alignment 99.2%)', machineCode: 'V-01', batchId: 'BATCH-82041' },
    { id: 'EVT-100', timestamp: '09:23:30', category: 'QUALITY', message: 'Vision QC Inspector V-01 flagged sample CAKE-82041-339: REJECT (Weight 433.0g < 435.0g LSL) -> Diverted to Scrap bin #2', machineCode: 'V-01', batchId: 'BATCH-82041' },
    { id: 'EVT-099', timestamp: '09:20:45', category: 'MACHINE', message: '6-Axis Robotic Decorator R-07 closed-loop offset recalibrated: dx=+0.12mm, dy=-0.08mm', machineCode: 'R-07', batchId: 'BATCH-82041' },
    { id: 'EVT-098', timestamp: '09:15:00', category: 'ALLERGEN', message: 'Allergen Changeover Line Washout swab test verified for Milk/Egg line', machineCode: 'M-04' },
    { id: 'EVT-097', timestamp: '09:02:10', category: 'BATCH', message: 'Batch 82041 sponges exited Cooling Tunnel C-02 at nominal 19.4°C', machineCode: 'C-02', batchId: 'BATCH-82041' },
    { id: 'EVT-096', timestamp: '08:45:12', category: 'SAFETY', message: 'Safety Interlocks all verified OK (Plexiglass guards, E-Stops, Light Curtains active)', machineCode: 'O-07' }
  ]);

  // Urgent Alerts
  readonly urgentAlerts = signal<{ id: string; level: 'CRITICAL' | 'WARNING'; message: string; machineCode: string; time: string }[]>([
    { id: 'ALT-01', level: 'WARNING', message: 'Mixer M-04 scheduled lubrication due in 80 running hours', machineCode: 'M-04', time: '08:15' },
    { id: 'ALT-02', level: 'WARNING', message: 'Silopark Flour Silo 01 bulk level at 24% - scheduled bulk delivery 14:00', machineCode: 'SILO-01', time: '07:45' }
  ]);

  // Test Kitchen State
  readonly testKitchenExperiment = signal<TestKitchenExperiment>({
    id: 'EXP-VS-15',
    name: 'Victoria Sponge V15 Trial - Reduced Crumb Densification & Enhanced Butter Emulsion',
    baseRecipeId: 'REC-VS-001',
    targetVersion: 15,
    notes: 'Optimising creaming cycle from 150s to 170s and increasing West Country Butter fat fraction by +2.5% to achieve a +3.1% rise and -18% reject variance.',
    modifications: [
      { parameter: 'Butter Fraction', baseValue: '56.25 kg (100%)', experimentValue: '57.65 kg (102.5%)', deltaPercent: 2.5 },
      { parameter: 'Creaming Duration', baseValue: '150 seconds', experimentValue: '170 seconds', deltaPercent: 13.3 },
      { parameter: 'Oven Zone 2 Temp', baseValue: '176.0 °C', experimentValue: '174.5 °C', deltaPercent: -0.85 }
    ],
    status: 'SIMULATION_COMPLETE',
    simulationResults: {
      heightDeltaPercent: 3.1,
      varianceReductionPercent: 18.4,
      moistureProxyPercent: 1.8,
      energyDeltaPercent: -2.1,
      costDeltaGbp: 0.07,
      rejectRateDeltaPercent: -18.2,
      rReportSummary: 'Monte Carlo 500-iteration trial indicates significant improvement in height uniformity (p < 0.001) with reduced crumb browning variance.'
    }
  });

  // Computed Values
  readonly activeBatch = computed(() => {
    return this.batches().find(b => b.id === this.activeBatchId()) || this.batches()[0];
  });

  readonly formattedSimClock = computed(() => {
    const totalSec = this.simSecondsElapsed();
    const hours = Math.floor(totalSec / 3600) % 24;
    const mins = Math.floor((totalSec % 3600) / 60);
    const secs = totalSec % 60;
    const hh = String(hours).padStart(2, '0');
    const mm = String(mins).padStart(2, '0');
    const ss = String(secs).padStart(2, '0');
    return `${hh}:${mm}:${ss}`;
  });

  readonly plantOeeSummary = computed(() => {
    const m = this.machines();
    const avgAvail = m.reduce((acc, x) => acc + x.oee.availability, 0) / m.length;
    const avgPerf = m.reduce((acc, x) => acc + x.oee.performance, 0) / m.length;
    const avgQual = m.reduce((acc, x) => acc + x.oee.quality, 0) / m.length;
    const avgOee = (avgAvail * avgPerf * avgQual) / 10000;
    return {
      availability: +avgAvail.toFixed(1),
      performance: +avgPerf.toFixed(1),
      quality: +avgQual.toFixed(1),
      overall: +avgOee.toFixed(1)
    };
  });

  readonly activeMachinesCount = computed(() => {
    return this.machines().filter(m => m.status === 'RUNNING' || m.status === 'READY').length;
  });

  readonly bottleneckAnalysis = computed(() => {
    return {
      stages: [
        { name: 'Ingredient Dispensing & Weighing', utilisation: 62, bottleneck: false, status: 'NOMINAL', capacityKgH: 450 },
        { name: 'Planetary Mixing (M-04)', utilisation: 88, bottleneck: false, status: 'HIGH_LOAD', capacityKgH: 400 },
        { name: 'Volumetric Depositing (D-02)', utilisation: 74, bottleneck: false, status: 'NOMINAL', capacityKgH: 380 },
        { name: 'Tunnel Oven Hall (O-07)', utilisation: 98, bottleneck: true, status: 'CONSTRAINED_BOTTLENECK', capacityKgH: 350, reason: 'Thermal dwell time is 22:00 min fixed thermal kill step.' },
        { name: 'Cooling Tunnel (C-02)', utilisation: 71, bottleneck: false, status: 'NOMINAL', capacityKgH: 420 },
        { name: '6-Axis Robotic Decorator (R-07)', utilisation: 84, bottleneck: false, status: 'HIGH_LOAD', capacityKgH: 360 },
        { name: 'Carton Packaging & Casing (P-11)', utilisation: 63, bottleneck: false, status: 'EXCESS_CAPACITY', capacityKgH: 500 }
      ],
      currentBottleneckName: 'Tunnel Oven O-07 (98% Utilisation)',
      recommendedAction: 'Pre-heat rotary rack oven O-02 for surge relief or stagger batch intervals by +4.5 min.'
    };
  });

  constructor() {
    // Start continuous factory physics and simulation clock
    if (typeof window !== 'undefined') {
      setInterval(() => {
        if (!this.isSimRunning()) return;
        const speed = this.simSpeed();
        
        // Advance clock
        this.simSecondsElapsed.update(s => s + 1);

        // Advance machine kinetics & telemetry
        this.updateKinetics(speed);
      }, 1000);
    }
  }

  private updateKinetics(speedMultiplier: number) {
    // Planetary mixer rotation
    this.mixerTwinState.update(state => {
      const newRot = (state.rotationDeg + state.rpm * 0.1 * speedMultiplier) % 360;
      const newPlanetary = (state.planetaryDeg + state.rpm * 0.04 * speedMultiplier) % 360;
      const torqueFluctuation = 84.2 + (Math.sin(Date.now() / 1000) * 2.8);
      return {
        ...state,
        rotationDeg: newRot,
        planetaryDeg: newPlanetary,
        torqueNm: +torqueFluctuation.toFixed(1)
      };
    });

    // Robotic decorator kinematics
    this.roboticDecoratorState.update(state => {
      const angle = (state.turntableAngleDeg + 1.2 * speedMultiplier) % 360;
      const rad = (angle * Math.PI) / 180;
      const newX = 100 + Math.cos(rad * 4) * 45;
      const newY = 100 + Math.sin(rad * 4) * 45;
      return {
        ...state,
        turntableAngleDeg: angle,
        x: +newX.toFixed(1),
        y: +newY.toFixed(1),
        pressureBar: +(2.48 + Math.sin(Date.now() / 800) * 0.08).toFixed(2)
      };
    });

    // Stop clock increment
    this.stopClockState.update(clock => {
      if (!clock.isRunning) return clock;
      const addedMs = 1000 * speedMultiplier;
      return {
        ...clock,
        elapsedMs: clock.elapsedMs + addedMs,
        timers: clock.timers.map(t => {
          if (!t.isRunning || t.remainingMs <= 0) return t;
          return { ...t, remainingMs: Math.max(0, t.remainingMs - addedMs) };
        })
      };
    });

    // Active batch incremental production
    this.batches.update(all => {
      return all.map(b => {
        if (b.id === this.activeBatchId() && b.progressPercent < 100) {
          const newActual = Math.min(b.targetQuantity, b.actualProducedQuantity + 0.1 * speedMultiplier);
          const newProgress = Math.min(100, (newActual / b.targetQuantity) * 100);
          return {
            ...b,
            actualProducedQuantity: Math.floor(newActual),
            progressPercent: +newProgress.toFixed(1)
          };
        }
        return b;
      });
    });
  }

  // Navigation actions
  setTab(tab: NavigationTab) {
    this.activeTab.set(tab);
  }

  toggleViewMode() {
    this.viewMode.update(m => m === 'photorealistic' ? 'engineering' : 'photorealistic');
  }

  setSimSpeed(speed: number) {
    this.simSpeed.set(speed);
  }

  toggleSimRunning() {
    this.isSimRunning.update(r => !r);
  }

  stepForward() {
    this.simSecondsElapsed.update(s => s + 60);
    this.updateKinetics(5.0);
  }

  setConveyorSpeed(mPerMin: number) {
    this.conveyorSpeedMPerMin.set(mPerMin);
    this.addEvent('MACHINE', `Conveyor speed adjusted to ${mPerMin} m/min. Line balance recalibrated.`, 'O-07');
  }

  // Recipe selection and Execution
  selectRecipe(recipe: Recipe) {
    this.selectedRecipe.set(recipe);
  }

  runRecipeInFactory(recipe: Recipe) {
    this.selectedRecipe.set(recipe);
    // Create new batch from recipe
    const newBatchId = `BATCH-${Math.floor(80000 + Math.random() * 10000)}`;
    const newBatch: ProductionBatch = {
      id: newBatchId,
      orderId: `ORD-${Math.floor(820000 + Math.random() * 10000)}`,
      customerName: 'Direct Production Order',
      recipeId: recipe.id,
      recipeCode: recipe.recipeCode,
      recipeVersion: recipe.version,
      productName: recipe.name,
      targetQuantity: recipe.targetBatchYieldCount,
      actualProducedQuantity: 0,
      rejectedQuantity: 0,
      stage: 'INGREDIENT_DISPENSE',
      startTime: this.formattedSimClock(),
      scheduledEndTime: '12:30',
      progressPercent: 0,
      assignedMachines: {
        weighScale: 'SCALE-W01',
        mixer: 'M-04',
        depositor: 'D-02',
        oven: 'O-07',
        coolingTunnel: 'C-02',
        decorator: 'R-07',
        qcStation: 'V-01',
        packer: 'P-11'
      },
      allocatedLots: recipe.ingredients.map(ing => ({
        ingredientName: ing.name,
        lotNumber: `LOT-${Math.floor(10000 + Math.random() * 90000)}`,
        allocatedWeightKg: ing.batchWeightKg,
        dispensedWeightKg: ing.batchWeightKg,
        withinTolerance: true
      })),
      processTelemetry: {
        currentMixSpeedRpm: recipe.mixingProgramme.steps[0].speedRpm,
        currentMixTorqueNm: 78.5,
        mixElapsedTimeSec: 0,
        ovenChamberTempC: recipe.bakingProgramme.zones[0].targetTempC,
        productCoreTempC: 18.5,
        coolingTempC: 18.0,
        icingDepositThicknessMm: recipe.decoratingProgramme.icingThicknessMm,
        visionPassRatePercent: 100.0
      },
      events: [
        { timestamp: this.formattedSimClock(), stage: 'QUEUED', description: `Executable recipe ${recipe.recipeCode} V${recipe.version} loaded to factory line`, operator: 'Master Scheduler' }
      ]
    };

    this.batches.update(b => [newBatch, ...b]);
    this.activeBatchId.set(newBatchId);
    this.activeTab.set('signature-run');
    this.addEvent('BATCH', `Recipe ${recipe.name} loaded into Production Line 1 (${recipe.targetBatchYieldCount} units)`, undefined, newBatchId);
  }

  // Machine selection & control
  selectMachine(machine: Machine) {
    this.selectedMachine.set(machine);
  }

  setMachineStatus(machineCode: string, newStatus: MachineStatus) {
    this.machines.update(list => list.map(m => {
      if (m.code === machineCode) {
        return { ...m, status: newStatus };
      }
      return m;
    }));
    this.addEvent('MACHINE', `Machine ${machineCode} status changed to ${newStatus}`, machineCode);
  }

  toggleSafetyInterlock(machineCode: string) {
    this.machines.update(list => list.map(m => {
      if (m.code === machineCode) {
        const nextState = !m.safetyInterlockOk;
        return {
          ...m,
          safetyInterlockOk: nextState,
          status: nextState ? 'READY' : 'EMERGENCY_STOP'
        };
      }
      return m;
    }));
    this.addEvent('SAFETY', `Safety Interlock for ${machineCode} toggled`, machineCode);
  }

  // Weigh Station Simulation
  addWeightToScale(deltaKg: number) {
    this.scaleStationState.update(st => {
      const newWeight = +(st.currentKg + deltaKg).toFixed(3);
      let status: 'UNDER' | 'IN_TOLERANCE' | 'OVER' = 'IN_TOLERANCE';
      if (newWeight < st.targetKg - st.toleranceKg) {
        status = 'UNDER';
      } else if (newWeight > st.targetKg + st.toleranceKg) {
        status = 'OVER';
      }
      return {
        ...st,
        currentKg: newWeight,
        status
      };
    });
  }

  resetScaleTarget(targetKg: number, ingredientName: string, lotNumber: string) {
    this.scaleStationState.set({
      ingredientName,
      lotNumber,
      targetKg,
      currentKg: 0,
      toleranceKg: 0.020,
      status: 'UNDER',
      isDispensing: false,
      authorizedOverride: false,
      scaleId: 'SCALE-W01'
    });
  }

  setAuthorizedOverride() {
    this.scaleStationState.update(st => ({ ...st, authorizedOverride: true }));
    this.addEvent('QUALITY', `Quality Lead authorized weight tolerance override for ${this.scaleStationState().ingredientName}`);
  }

  // Silo Dosing Simulation
  startSiloDosing() {
    this.siloSystemState.update(s => ({ ...s, activeDosing: true, flowRateKgS: 2.8 }));
    const interval = setInterval(() => {
      this.siloSystemState.update(s => {
        if (!s.activeDosing) {
          clearInterval(interval);
          return s;
        }
        const nextDosed = +(s.actualDosedKg + 1.4).toFixed(2);
        if (nextDosed >= s.targetKg) {
          clearInterval(interval);
          this.addEvent('BATCH', `Automated Silo 03 dosing complete: ${s.targetKg}kg flour delivered directly to Mixer M-04`, 'SILO-03');
          return {
            ...s,
            actualDosedKg: s.targetKg,
            activeDosing: false,
            flowRateKgS: 0
          };
        }
        return {
          ...s,
          actualDosedKg: nextDosed,
          flourSiloLevelPercent: Math.max(0, +(s.flourSiloLevelPercent - 0.05).toFixed(1))
        };
      });
    }, 200);
  }

  // Stop Clock Operations
  toggleStopClock() {
    this.stopClockState.update(c => ({ ...c, isRunning: !c.isRunning }));
  }

  resetStopClock() {
    this.stopClockState.update(c => ({ ...c, elapsedMs: 0, laps: [] }));
  }

  addStopClockLap(name: string) {
    this.stopClockState.update(c => ({
      ...c,
      laps: [{ id: c.laps.length + 1, name, timeMs: c.elapsedMs }, ...c.laps]
    }));
  }

  // Recipe Experiment Simulator (Test Kitchen)
  runExperimentSimulation(modifiedButterPct: number, modifiedCreamingSec: number, modifiedBakeTemp: number) {
    const deltaButter = ((modifiedButterPct - 100) / 100) * 100;
    const deltaCreaming = ((modifiedCreamingSec - 150) / 150) * 100;
    const deltaTemp = ((modifiedBakeTemp - 176) / 176) * 100;

    const heightGain = +(2.0 + deltaCreaming * 0.15 + deltaButter * 0.08).toFixed(1);
    const varianceRed = +(12.0 + deltaCreaming * 0.45).toFixed(1);
    const costDelta = +(0.03 + (deltaButter > 0 ? 0.05 : 0)).toFixed(2);
    const rejectDelta = +(-10.0 - deltaCreaming * 0.6).toFixed(1);

    const experiment: TestKitchenExperiment = {
      id: `EXP-VS-${Math.floor(15 + Math.random() * 5)}`,
      name: `Victoria Sponge V15 Trial - Aeration & Crumb Structure Optimization`,
      baseRecipeId: 'REC-VS-001',
      targetVersion: 15,
      notes: `Parameters adjusted: Butter fraction (${modifiedButterPct}%), Creaming duration (${modifiedCreamingSec}s), Zone 2 Bake Temp (${modifiedBakeTemp}°C).`,
      modifications: [
        { parameter: 'Butter Fraction', baseValue: '56.25 kg (100%)', experimentValue: `${(56.25 * (modifiedButterPct / 100)).toFixed(2)} kg (${modifiedButterPct}%)`, deltaPercent: +deltaButter.toFixed(1) },
        { parameter: 'Creaming Duration', baseValue: '150 seconds', experimentValue: `${modifiedCreamingSec} seconds`, deltaPercent: +deltaCreaming.toFixed(1) },
        { parameter: 'Oven Zone 2 Temp', baseValue: '176.0 °C', experimentValue: `${modifiedBakeTemp.toFixed(1)} °C`, deltaPercent: +deltaTemp.toFixed(1) }
      ],
      simulationResults: {
        heightDeltaPercent: heightGain,
        varianceReductionPercent: varianceRed,
        moistureProxyPercent: 1.6,
        energyDeltaPercent: +(deltaTemp * 0.5).toFixed(1),
        costDeltaGbp: costDelta,
        rejectRateDeltaPercent: rejectDelta,
        rReportSummary: `R statistical model evaluated 500 simulated batches. Predicted mean height +${heightGain}%, weight standard deviation reduced by ${varianceRed}%, and defect rate down ${Math.abs(rejectDelta)}%.`
      },
      status: 'SIMULATION_COMPLETE'
    };

    this.testKitchenExperiment.set(experiment);
    this.addEvent('QUALITY', `Test Kitchen simulation completed for Victoria Sponge V15 trial`);
  }

  // Advance Signature Run Stage
  advanceBatchStage(batchId: string, targetStage: BatchStage) {
    this.batches.update(list => list.map(b => {
      if (b.id === batchId) {
        return {
          ...b,
          stage: targetStage,
          events: [
            { timestamp: this.formattedSimClock(), stage: targetStage, description: `Batch transitioned to stage ${targetStage}`, operator: 'Line Lead' },
            ...b.events
          ]
        };
      }
      return b;
    }));
    this.addEvent('BATCH', `Batch ${batchId} advanced to stage ${targetStage}`, undefined, batchId);
  }

  addEvent(category: 'BATCH' | 'MACHINE' | 'QUALITY' | 'SAFETY' | 'ALLERGEN', message: string, machineCode?: string, batchId?: string) {
    const newEvent: FactoryEventItem = {
      id: `EVT-${Date.now()}`,
      timestamp: this.formattedSimClock(),
      category,
      message,
      machineCode,
      batchId
    };
    this.eventStream.update(evts => [newEvent, ...evts.slice(0, 49)]);
  }
}
