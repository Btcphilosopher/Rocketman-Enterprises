import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService, NavigationTab } from '../../services/bakeos-factory.service';

interface NavItem {
  id: NavigationTab;
  label: string;
  icon: string;
  category: 'OPERATIONS' | 'ENGINEERING' | 'QUALITY_SAFETY' | 'R&D';
}

@Component({
  selector: 'app-sidebar',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <aside class="w-64 border-r border-slate-800 bg-slate-950 flex flex-col justify-between shrink-0 select-none overflow-y-auto">
      <div class="p-3 space-y-5">
        <!-- Operations Section -->
        <div>
          <div class="px-3 pb-1.5 text-[10px] font-mono tracking-wider text-slate-500 uppercase">Production Control</div>
          <div class="space-y-0.5">
            @for (item of operationsNav; track item.id) {
              <button
                (click)="factory.setTab(item.id)"
                [class.bg-amber-500/10]="factory.activeTab() === item.id"
                [class.text-amber-400]="factory.activeTab() === item.id"
                [class.border-amber-500/30]="factory.activeTab() === item.id"
                [class.text-slate-400]="factory.activeTab() !== item.id"
                [class.hover:text-slate-200]="factory.activeTab() !== item.id"
                [class.hover:bg-slate-900]="factory.activeTab() !== item.id"
                class="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium border border-transparent transition-colors text-left">
                <mat-icon class="text-base shrink-0">{{ item.icon }}</mat-icon>
                <span class="truncate">{{ item.label }}</span>
                @if (item.id === 'signature-run') {
                  <span class="ml-auto text-[9px] font-mono px-1.5 py-0.2 bg-amber-500 text-slate-950 rounded font-bold">500 pcs</span>
                }
              </button>
            }
          </div>
        </div>

        <!-- Recipe & Machinery Section -->
        <div>
          <div class="px-3 pb-1.5 text-[10px] font-mono tracking-wider text-slate-500 uppercase">Engineering & Process</div>
          <div class="space-y-0.5">
            @for (item of engineeringNav; track item.id) {
              <button
                (click)="factory.setTab(item.id)"
                [class.bg-amber-500/10]="factory.activeTab() === item.id"
                [class.text-amber-400]="factory.activeTab() === item.id"
                [class.border-amber-500/30]="factory.activeTab() === item.id"
                [class.text-slate-400]="factory.activeTab() !== item.id"
                [class.hover:text-slate-200]="factory.activeTab() !== item.id"
                [class.hover:bg-slate-900]="factory.activeTab() !== item.id"
                class="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium border border-transparent transition-colors text-left">
                <mat-icon class="text-base shrink-0">{{ item.icon }}</mat-icon>
                <span class="truncate">{{ item.label }}</span>
              </button>
            }
          </div>
        </div>

        <!-- Quality, Safety & Traceability -->
        <div>
          <div class="px-3 pb-1.5 text-[10px] font-mono tracking-wider text-slate-500 uppercase">Quality & Food Safety</div>
          <div class="space-y-0.5">
            @for (item of qualityNav; track item.id) {
              <button
                (click)="factory.setTab(item.id)"
                [class.bg-amber-500/10]="factory.activeTab() === item.id"
                [class.text-amber-400]="factory.activeTab() === item.id"
                [class.border-amber-500/30]="factory.activeTab() === item.id"
                [class.text-slate-400]="factory.activeTab() !== item.id"
                [class.hover:text-slate-200]="factory.activeTab() !== item.id"
                [class.hover:bg-slate-900]="factory.activeTab() !== item.id"
                class="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium border border-transparent transition-colors text-left">
                <mat-icon class="text-base shrink-0">{{ item.icon }}</mat-icon>
                <span class="truncate">{{ item.label }}</span>
              </button>
            }
          </div>
        </div>

        <!-- R&D and Maintenance -->
        <div>
          <div class="px-3 pb-1.5 text-[10px] font-mono tracking-wider text-slate-500 uppercase">R&D & Maintenance</div>
          <div class="space-y-0.5">
            @for (item of rdNav; track item.id) {
              <button
                (click)="factory.setTab(item.id)"
                [class.bg-amber-500/10]="factory.activeTab() === item.id"
                [class.text-amber-400]="factory.activeTab() === item.id"
                [class.border-amber-500/30]="factory.activeTab() === item.id"
                [class.text-slate-400]="factory.activeTab() !== item.id"
                [class.hover:text-slate-200]="factory.activeTab() !== item.id"
                [class.hover:bg-slate-900]="factory.activeTab() !== item.id"
                class="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium border border-transparent transition-colors text-left">
                <mat-icon class="text-base shrink-0">{{ item.icon }}</mat-icon>
                <span class="truncate">{{ item.label }}</span>
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Footer Telemetry & System Status -->
      <div class="p-3 border-t border-slate-900 bg-slate-950/80">
        <div class="flex items-center justify-between text-[11px] text-slate-400">
          <span>Active Batches</span>
          <span class="font-mono font-semibold text-slate-200">18 in-flight</span>
        </div>
        <div class="flex items-center justify-between text-[11px] text-slate-400 mt-1">
          <span>Plant OEE</span>
          <span class="font-mono font-semibold text-emerald-400">88.3%</span>
        </div>
        <div class="mt-2 pt-2 border-t border-slate-900 text-[10px] text-slate-500 font-mono flex items-center justify-between">
          <span>BAKEOS v4.0.8-UK</span>
          <span class="text-emerald-500 flex items-center gap-1">
            <span class="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> SYNC
          </span>
        </div>
      </div>
    </aside>
  `
})
export class SidebarComponent {
  readonly factory = inject(BakeOSFactoryService);

  readonly operationsNav: NavItem[] = [
    { id: 'control-room', label: 'Factory Control Room', icon: 'dashboard', category: 'OPERATIONS' },
    { id: 'factory-floor', label: 'Factory Digital Twin (2D/3D)', icon: 'domain', category: 'OPERATIONS' },
    { id: 'signature-run', label: 'Victoria Sponge Run', icon: 'play_circle_filled', category: 'OPERATIONS' },
    { id: 'planner', label: 'Production Planner & OEE', icon: 'calendar_today', category: 'OPERATIONS' }
  ];

  readonly engineeringNav: NavItem[] = [
    { id: 'recipes', label: 'Recipe Studio & Process', icon: 'menu_book', category: 'ENGINEERING' },
    { id: 'machine-twins', label: 'Machine Digital Twins', icon: 'precision_manufacturing', category: 'ENGINEERING' },
    { id: 'weighing-dosing', label: 'Precision Scale & Silo', icon: 'scale', category: 'ENGINEERING' },
    { id: 'stop-clock', label: 'Industrial Chronometer', icon: 'timer', category: 'ENGINEERING' }
  ];

  readonly qualityNav: NavItem[] = [
    { id: 'quality-spc', label: 'Vision QC & SPC Charts', icon: 'camera', category: 'QUALITY_SAFETY' },
    { id: 'haccp', label: 'HACCP & Allergen Engine', icon: 'verified_user', category: 'QUALITY_SAFETY' },
    { id: 'traceability', label: 'Lot Traceability & Thread', icon: 'hub', category: 'QUALITY_SAFETY' }
  ];

  readonly rdNav: NavItem[] = [
    { id: 'test-kitchen', label: 'Test Kitchen (R Analytics)', icon: 'science', category: 'R&D' },
    { id: 'maintenance', label: 'Bakery Maintenance OS', icon: 'build', category: 'R&D' }
  ];
}
