import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-header',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <header class="h-16 border-b border-slate-800 bg-slate-950/95 backdrop-blur px-5 flex items-center justify-between z-30 shrink-0 select-none">
      <!-- Zone 1: Wordmark / Facility Title -->
      <div class="flex items-center gap-3">
        <div class="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
          <mat-icon class="text-xl">factory</mat-icon>
        </div>
        <div>
          <div class="flex items-center gap-2">
            <span class="font-brand font-bold text-lg text-slate-100 tracking-wider">BAKEOS 4.0</span>
            <span class="text-xs text-amber-400/80 font-mono uppercase tracking-wider">UK Plant 01</span>
          </div>
          <div class="text-[11px] text-slate-400 font-medium">The Northshire Bakery · Digital Twin & Manufacturing OS</div>
        </div>
      </div>

      <!-- Zone 2: Simulation Master Clock & Speed Telemetry -->
      <div class="flex items-center gap-3 bg-slate-900/80 border border-slate-800 px-3 py-1.5 rounded-lg">
        <div class="flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span class="text-[11px] text-slate-400 font-mono uppercase">Factory Time:</span>
          <span class="text-sm font-mono font-semibold text-emerald-400 tabular-nums">
            {{ factory.formattedSimClock() }}
          </span>
          <span class="text-[11px] text-slate-500 font-mono">Shift 01</span>
        </div>

        <div class="h-4 w-px bg-slate-700 mx-1"></div>

        <!-- Speed Selector Buttons -->
        <div class="flex items-center gap-1">
          <button 
            (click)="factory.toggleSimRunning()" 
            [title]="factory.isSimRunning() ? 'Pause Simulation' : 'Resume Simulation'"
            class="p-1 rounded text-slate-300 hover:text-white hover:bg-slate-800 transition-colors flex items-center justify-center">
            <mat-icon class="text-sm">{{ factory.isSimRunning() ? 'pause' : 'play_arrow' }}</mat-icon>
          </button>

          <button 
            (click)="factory.stepForward()" 
            title="Step Forward (+1 min)"
            class="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex items-center justify-center">
            <mat-icon class="text-sm">skip_next</mat-icon>
          </button>

          <div class="flex items-center gap-0.5 bg-slate-950 p-0.5 rounded border border-slate-800">
            @for (spd of [0.5, 1.0, 2.0, 5.0, 10.0]; track spd) {
              <button 
                (click)="factory.setSimSpeed(spd)"
                [class.bg-amber-500]="factory.simSpeed() === spd"
                [class.text-slate-950]="factory.simSpeed() === spd"
                [class.font-bold]="factory.simSpeed() === spd"
                [class.text-slate-400]="factory.simSpeed() !== spd"
                class="px-1.5 py-0.5 text-[10px] font-mono rounded transition-colors hover:text-white">
                {{ spd }}×
              </button>
            }
          </div>
        </div>
      </div>

      <!-- Zone 3: Viewport Mode & High Level Status Action -->
      <div class="flex items-center gap-3">
        <!-- View Mode Switcher: Photorealistic vs CAD Engineering -->
        <button 
          (click)="factory.toggleViewMode()"
          class="flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium transition-all"
          [class.bg-blue-950]="factory.viewMode() === 'engineering'"
          [class.border-blue-700]="factory.viewMode() === 'engineering'"
          [class.text-blue-300]="factory.viewMode() === 'engineering'"
          [class.bg-slate-900]="factory.viewMode() === 'photorealistic'"
          [class.border-slate-800]="factory.viewMode() === 'photorealistic'"
          [class.text-slate-300]="factory.viewMode() === 'photorealistic'">
          <mat-icon class="text-sm">{{ factory.viewMode() === 'engineering' ? 'architecture' : 'view_in_ar' }}</mat-icon>
          <span>{{ factory.viewMode() === 'engineering' ? 'CAD Engineering Mode' : 'Photorealistic Mode' }}</span>
        </button>

        <!-- Signature Victoria Sponge Fast Run Button -->
        <button 
          (click)="factory.setTab('signature-run')"
          class="flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-semibold text-xs hover:bg-amber-400 transition-colors shadow-sm">
          <mat-icon class="text-sm">cake</mat-icon>
          <span>Victoria Sponge Run</span>
        </button>
      </div>
    </header>
  `
})
export class HeaderComponent {
  readonly factory = inject(BakeOSFactoryService);
}
