import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header';
import { SidebarComponent } from './components/sidebar/sidebar';
import { ControlRoomComponent } from './views/control-room/control-room';
import { FactoryFloorComponent } from './views/factory-floor/factory-floor';
import { SignatureRunComponent } from './views/signature-run/signature-run';
import { RecipeStudioComponent } from './views/recipe-studio/recipe-studio';
import { MachineTwinsComponent } from './views/machine-twins/machine-twins';
import { WeighingDosingComponent } from './views/weighing-dosing/weighing-dosing';
import { StopClockComponent } from './views/stop-clock/stop-clock';
import { PlannerComponent } from './views/planner/planner';
import { QualitySpcComponent } from './views/quality-spc/quality-spc';
import { HaccpComponent } from './views/haccp/haccp';
import { TraceabilityComponent } from './views/traceability/traceability';
import { TestKitchenComponent } from './views/test-kitchen/test-kitchen';
import { MaintenanceComponent } from './views/maintenance/maintenance';
import { BakeOSFactoryService } from './services/bakeos-factory.service';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [
    CommonModule,
    HeaderComponent,
    SidebarComponent,
    ControlRoomComponent,
    FactoryFloorComponent,
    SignatureRunComponent,
    RecipeStudioComponent,
    MachineTwinsComponent,
    WeighingDosingComponent,
    StopClockComponent,
    PlannerComponent,
    QualitySpcComponent,
    HaccpComponent,
    TraceabilityComponent,
    TestKitchenComponent,
    MaintenanceComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  readonly factory = inject(BakeOSFactoryService);
}

