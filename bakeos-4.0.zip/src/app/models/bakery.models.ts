export type ViewMode = 'photorealistic' | 'engineering';

export type MachineStatus = 
  | 'OFFLINE'
  | 'IDLE'
  | 'READY'
  | 'LOADING'
  | 'RUNNING'
  | 'PAUSED'
  | 'FAULT'
  | 'CLEANING'
  | 'MAINTENANCE'
  | 'CHANGEOVER'
  | 'EMERGENCY_STOP';

export type HygieneStatus = 'CLEAN' | 'SANITISED' | 'READY' | 'IN_PRODUCTION' | 'CLEANING_REQUIRED';

export type RecipeStatus = 'DRAFT' | 'TEST' | 'TRIAL' | 'APPROVED' | 'SUPERSEDED' | 'ARCHIVED';

export type AllergenType = 'WHEAT_GLUTEN' | 'EGG' | 'MILK' | 'NUTS' | 'SOYA' | 'SULPHITES' | 'SESAME';

export interface Ingredient {
  id: string;
  name: string;
  category: 'DRY_POWDER' | 'FAT' | 'LIQUID' | 'SUGAR' | 'LEAVENING' | 'FLAVOUR' | 'DECORATION';
  supplier: string;
  storage: 'AMBIENT_SILO' | 'CHILLED' | 'FREEZER' | 'AMBIENT_RACK';
  targetTempC: number;
  unit: 'kg' | 'L' | 'g';
  costPerKg: number;
  allergens: AllergenType[];
  stockQuantity: number;
  reorderPoint: number;
  countryOfOrigin: string;
  currentLots: IngredientLot[];
}

export interface IngredientLot {
  lotNumber: string;
  ingredientId: string;
  receivedDate: string;
  expiryDate: string;
  initialWeightKg: number;
  remainingWeightKg: number;
  moisturePercent: number;
  proteinPercent?: number;
  qcStatus: 'APPROVED' | 'QUARANTINE' | 'REJECTED';
  supplierCertUrl: string;
}

export interface BakerIngredientSpec {
  ingredientId: string;
  name: string;
  bakersPercentage: number; // flour = 100%
  batchWeightKg: number;
  dosingMethod: 'AUTOMATED_SILO' | 'AUTOMATED_LIQUID' | 'MANUAL_PRECISION_SCALE';
  toleranceKg: number;
  targetTempC?: number;
}

export interface MixingStep {
  stepNumber: number;
  name: string;
  tool: 'WHISK' | 'PADDLE' | 'DOUGH_HOOK' | 'SPIRAL';
  speedRpm: number;
  durationSeconds: number;
  targetTempC: number;
  description: string;
  ingredientsAdded: string[];
}

export interface OvenZoneProfile {
  zoneIndex: number;
  name: string;
  targetTempC: number;
  fanSpeedPercent: number;
  topHeatPercent: number;
  bottomHeatPercent: number;
}

export interface PipingPatternSpec {
  patternType: 'ROSETTE' | 'SHELL' | 'SPIRAL' | 'BORDER_WAVE' | 'DRIP' | 'PLAQUE_CENTRE';
  pointsCount: number;
  nozzleSizeMm: number;
  depositionPressureBar: number;
  heightMm: number;
  colorHex: string;
  icingMaterial: 'VANILLA_BUTTERCREAM' | 'RASPBERRY_COMPOTE' | 'CHOCOLATE_GANACHE' | 'LEMON_FONDANT';
}

export interface Recipe {
  id: string;
  name: string;
  category: 'CAKES' | 'BREAD' | 'PASTRY' | 'BISCUITS' | 'CONFECTIONERY';
  version: number;
  recipeCode: string; // e.g. VS-001
  status: RecipeStatus;
  author: string;
  approvedBy: string;
  approvalDate: string;
  imageUrl: string;
  description: string;
  targetBatchYieldCount: number;
  unitWeightGrams: number;
  shelfLifeDays: number;
  dimensionsMm: {
    diameterOrLength: number;
    width?: number;
    height: number;
    layers: number;
  };
  ingredients: BakerIngredientSpec[];
  mixingProgramme: {
    totalDurationSec: number;
    steps: MixingStep[];
    targetHydrationPercent: number;
  };
  depositingProgramme: {
    nozzleType: string;
    depositWeightGrams: number;
    depositToleranceGrams: number;
    cycleTimeSec: number;
  };
  bakingProgramme: {
    ovenType: 'TUNNEL' | 'ROTARY_RACK' | 'DECK';
    preheatTempC: number;
    bakeTimeMinutes: number;
    steamInjectionSeconds: number;
    zones: OvenZoneProfile[];
    targetCoreTempC: number;
  };
  coolingProgramme: {
    targetTunnelExitTempC: number;
    dwellTimeMinutes: number;
    airVelocityMs: number;
  };
  decoratingProgramme: {
    icingThicknessMm: number;
    icingToleranceMm: number;
    roboticPatterns: PipingPatternSpec[];
    requiresVisionClosedLoop: boolean;
  };
  packagingProgramme: {
    primaryPackType: 'INDIVIDUAL_CARTON' | 'FLOW_WRAP' | 'TRAY_AND_SLEEVE';
    cartonsPerCase: number;
    modifiedAtmosphereGas: string;
    targetNetWeightGrams: number;
    labelFormatId: string;
  };
  costing: {
    ingredientCostGbp: number;
    labourCostGbp: number;
    energyCostGbp: number;
    packagingCostGbp: number;
    wasteAllowanceGbp: number;
    totalUnitCostGbp: number;
    targetRetailGbp: number;
  };
  allergens: AllergenType[];
  qualityTolerances: {
    weightMinG: number;
    weightMaxG: number;
    heightMinMm: number;
    heightMaxMm: number;
    diameterMinMm: number;
    diameterMaxMm: number;
    browningDeltaEMax: number;
    decorationAlignmentMinPercent: number;
  };
}

export interface Machine {
  id: string;
  name: string;
  code: string; // e.g. M-04, O-07, R-07, P-11
  department: 'SILO_PARK' | 'WEIGHING' | 'MIXING' | 'FORMING' | 'BAKING' | 'COOLING' | 'DECORATING' | 'PACKAGING' | 'WAREHOUSE';
  type: 'MIXER_PLANETARY' | 'MIXER_SPIRAL' | 'DEPOSITOR' | 'TUNNEL_OVEN' | 'COOLING_TUNNEL' | 'ROBOTIC_DECORATOR' | 'VISION_QC' | 'FLOW_WRAPPER' | 'CASE_PACKER' | 'SILO_SYSTEM';
  status: MachineStatus;
  hygieneStatus: HygieneStatus;
  safetyInterlockOk: boolean;
  currentRecipeId?: string;
  currentBatchId?: string;
  speedActual: number; // RPM, mm/s, packs/min
  speedTarget: number;
  temperatureC: number;
  loadPercent: number;
  vibrationMmS: number;
  powerKw: number;
  runningHoursTotal: number;
  hoursUntilMaintenance: number;
  oee: {
    availability: number; // percentage 0-100
    performance: number;  // percentage 0-100
    quality: number;      // percentage 0-100
    overall: number;      // percentage 0-100
  };
  alarms: {
    id: string;
    level: 'INFO' | 'WARNING' | 'CRITICAL';
    timestamp: string;
    message: string;
    acknowledged: boolean;
  }[];
}

export type BatchStage = 
  | 'QUEUED'
  | 'INGREDIENT_DISPENSE'
  | 'MIXING'
  | 'DEPOSITING'
  | 'BAKING'
  | 'COOLING'
  | 'FILLING_ICING'
  | 'ROBOTIC_DECORATION'
  | 'VISION_QC'
  | 'PACKAGING'
  | 'PALLETIZED'
  | 'DISPATCHED';

export interface ProductionBatch {
  id: string; // e.g. BATCH-82041
  orderId: string;
  customerName: string;
  recipeId: string;
  recipeCode: string;
  recipeVersion: number;
  productName: string;
  targetQuantity: number;
  actualProducedQuantity: number;
  rejectedQuantity: number;
  stage: BatchStage;
  startTime: string;
  scheduledEndTime: string;
  progressPercent: number;
  assignedMachines: {
    weighScale: string;
    mixer: string;
    depositor: string;
    oven: string;
    coolingTunnel: string;
    decorator: string;
    qcStation: string;
    packer: string;
  };
  allocatedLots: {
    ingredientName: string;
    lotNumber: string;
    allocatedWeightKg: number;
    dispensedWeightKg: number;
    withinTolerance: boolean;
  }[];
  processTelemetry: {
    currentMixSpeedRpm: number;
    currentMixTorqueNm: number;
    mixElapsedTimeSec: number;
    ovenChamberTempC: number;
    productCoreTempC: number;
    coolingTempC: number;
    icingDepositThicknessMm: number;
    visionPassRatePercent: number;
  };
  events: {
    timestamp: string;
    stage: BatchStage;
    description: string;
    operator: string;
  }[];
}

export interface ProductionOrder {
  id: string; // e.g. ORD-820481
  customer: string;
  productName: string;
  recipeId: string;
  quantity: number;
  orderDate: string;
  deliveryDate: string;
  status: 'PENDING' | 'SCHEDULED' | 'IN_PRODUCTION' | 'COMPLETED' | 'DISPATCHED';
  priority: 'NORMAL' | 'HIGH' | 'CRITICAL';
  batchId?: string;
}

export interface QualitySample {
  id: string;
  sampleCode: string; // e.g. CAKE-82041-17
  batchId: string;
  timestamp: string;
  weightGrams: number;
  heightMm: number;
  diameterMm: number;
  browningIndex: number;
  decorationAlignmentPercent: number;
  status: 'PASS' | 'HOLD' | 'REJECT';
  defectReason?: string;
  cameraImageUrl?: string;
}

export interface SPCMetricSeries {
  parameterName: string;
  unit: string;
  target: number;
  ucl: number; // Upper Control Limit
  lcl: number; // Lower Control Limit
  usl: number; // Upper Spec Limit
  lsl: number; // Lower Spec Limit
  readings: { timestamp: string; value: number; batchId: string }[];
  cpk: number;
}

export interface CCPMonitor {
  ccpNumber: string; // e.g. CCP-01
  name: string;
  hazardType: 'MICROBIOLOGICAL' | 'PHYSICAL' | 'ALLERGENIC' | 'CHEMICAL';
  criticalLimit: string;
  currentValue: string;
  status: 'COMPLIANT' | 'WARNING' | 'BREACH';
  monitoringFrequency: string;
  lastVerified: string;
  verifierName: string;
}

export interface TestKitchenExperiment {
  id: string;
  name: string;
  baseRecipeId: string;
  targetVersion: number;
  notes: string;
  modifications: {
    parameter: string;
    baseValue: string;
    experimentValue: string;
    deltaPercent: number;
  }[];
  simulationResults?: {
    heightDeltaPercent: number;
    varianceReductionPercent: number;
    moistureProxyPercent: number;
    energyDeltaPercent: number;
    costDeltaGbp: number;
    rejectRateDeltaPercent: number;
    rReportSummary: string;
  };
  status: 'DRAFT' | 'SIMULATION_COMPLETE' | 'SUBMITTED_FOR_APPROVAL' | 'APPROVED_FOR_TRIAL';
}
