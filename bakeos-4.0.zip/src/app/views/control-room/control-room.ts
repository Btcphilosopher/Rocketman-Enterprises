import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-control-room',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Top Title & Quick Action Banner -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">NORTHSHIRE BAKERY CONTROL ROOM</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              ALL SYSTEMS RUNNING
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Plant 01 · 12 Continuous Production Lines · Full Industrial Digital Twin Synchronisation
          </p>
        </div>

        <!-- Conveyor Speed & Quick Link -->
        <div class="flex items-center gap-4 bg-slate-900/90 border border-slate-800 px-4 py-2 rounded-xl">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400 text-sm">speed</mat-icon>
            <span class="text-xs text-slate-400">Master Line Speed:</span>
            <span class="text-xs font-mono font-bold text-slate-100 tabular-nums">{{ factory.conveyorSpeedMPerMin() }} m/min</span>
          </div>
          <input 
            type="range" 
            min="0.4" 
            max="2.5" 
            step="0.1" 
            [value]="factory.conveyorSpeedMPerMin()"
            (input)="onConveyorSpeedChange($event)"
            class="w-24 accent-amber-500 cursor-pointer" />

          <button 
            (click)="factory.setTab('signature-run')"
            class="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5">
            <mat-icon class="text-xs">play_arrow</mat-icon>
            <span>Run Victoria Sponge (500 pcs)</span>
          </button>
        </div>
      </div>

      <!-- 7 Top High-Level Metrics (Matches Specification) -->
      <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Production Output</div>
          <div class="text-2xl font-mono font-bold text-slate-100 mt-1 tabular-nums">82.4%</div>
          <div class="text-[10px] text-emerald-400 mt-0.5 flex items-center gap-1">
            <mat-icon class="text-[12px]">trending_up</mat-icon> +3.2% vs target
          </div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Quality Pass Rate</div>
          <div class="text-2xl font-mono font-bold text-emerald-400 mt-1 tabular-nums">98.7%</div>
          <div class="text-[10px] text-slate-400 mt-0.5">Vision QC Verified</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Plant OEE</div>
          <div class="text-2xl font-mono font-bold text-amber-400 mt-1 tabular-nums">{{ factory.plantOeeSummary().overall }}%</div>
          <div class="text-[10px] text-slate-400 mt-0.5">Avail 96% · Perf 93%</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Active Batches</div>
          <div class="text-2xl font-mono font-bold text-slate-100 mt-1 tabular-nums">18</div>
          <div class="text-[10px] text-slate-400 mt-0.5">3 in high priority</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Machines Online</div>
          <div class="text-2xl font-mono font-bold text-blue-400 mt-1 tabular-nums">42 <span class="text-xs text-slate-500 font-normal">/ 46</span></div>
          <div class="text-[10px] text-emerald-400 mt-0.5">4 scheduled CIP clean</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Open Orders</div>
          <div class="text-2xl font-mono font-bold text-slate-100 mt-1 tabular-nums">31</div>
          <div class="text-[10px] text-slate-400 mt-0.5">Waitrose, M&S, Harrods</div>
        </div>

        <div class="bg-slate-900/80 border border-slate-800 p-3.5 rounded-xl">
          <div class="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Urgent Alerts</div>
          <div class="text-2xl font-mono font-bold text-amber-500 mt-1 tabular-nums">2</div>
          <div class="text-[10px] text-amber-400/80 mt-0.5">Lubrication & Silo load</div>
        </div>
      </div>

      <!-- Main Animated Factory Digital Twin Pipeline Canvas -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
        <div class="flex items-center justify-between mb-4">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400">precision_manufacturing</mat-icon>
            <h2 class="font-brand font-bold text-base text-slate-100">CONTINUOUS PRODUCTION DIGITAL TWIN — LINE 01</h2>
          </div>
          <div class="flex items-center gap-3 text-xs">
            <div class="flex items-center gap-1.5 text-slate-400">
              <span class="w-2 h-2 rounded-full bg-blue-500"></span> Raw Silo
            </div>
            <div class="flex items-center gap-1.5 text-slate-400">
              <span class="w-2 h-2 rounded-full bg-amber-500"></span> Mixing
            </div>
            <div class="flex items-center gap-1.5 text-slate-400">
              <span class="w-2 h-2 rounded-full bg-red-500"></span> Baking (180°C)
            </div>
            <div class="flex items-center gap-1.5 text-slate-400">
              <span class="w-2 h-2 rounded-full bg-cyan-500"></span> Cooling (19°C)
            </div>
            <div class="flex items-center gap-1.5 text-slate-400">
              <span class="w-2 h-2 rounded-full bg-purple-500"></span> Robotics
            </div>
            <div class="flex items-center gap-1.5 text-slate-400">
              <span class="w-2 h-2 rounded-full bg-emerald-500"></span> Vision QC
            </div>
          </div>
        </div>

        <!-- Interactive SVG Factory Twin Pipeline -->
        <div class="w-full bg-slate-950 border border-slate-800 rounded-xl p-4 overflow-x-auto" [class.engineering-grid]="factory.viewMode() === 'engineering'">
          <svg viewBox="0 0 1200 320" class="w-full min-w-[950px] h-auto select-none">
            <!-- Background Conveyor Rail -->
            <rect x="50" y="160" width="1100" height="24" rx="4" fill="#1e293b" stroke="#334155" stroke-width="2"/>
            
            <!-- Moving Conveyor Texture Stripes -->
            <g class="animate-[marquee_3s_linear_infinite]">
              @for (i of [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]; track i) {
                <line [attr.x1]="50 + i * 55" y1="162" [attr.x2]="60 + i * 55" y2="182" stroke="#475569" stroke-width="3" />
              }
            </g>

            <!-- 1. Silo Park Station -->
            <g class="cursor-pointer group" (click)="factory.setTab('weighing-dosing')">
              <rect x="40" y="30" width="90" height="120" rx="6" fill="#0f172a" stroke="#3b82f6" stroke-width="2"/>
              <path d="M40,110 Q85,145 130,110 Z" fill="#1e3a8a"/>
              <text x="85" y="55" font-size="11" font-weight="bold" fill="#93c5fd" text-anchor="middle" font-family="JetBrains Mono">SILO 03</text>
              <text x="85" y="75" font-size="10" fill="#cbd5e1" text-anchor="middle">Flour 64%</text>
              <text x="85" y="95" font-size="9" fill="#60a5fa" text-anchor="middle">Auto-Dosing</text>
              <line x1="85" y1="150" x2="85" y2="160" stroke="#3b82f6" stroke-width="4" stroke-dasharray="2 2"/>
            </g>

            <!-- 2. Weigh Scale Station -->
            <g class="cursor-pointer group" (click)="factory.setTab('weighing-dosing')">
              <rect x="160" y="70" width="80" height="80" rx="6" fill="#0f172a" stroke="#64748b" stroke-width="1.5"/>
              <circle cx="200" cy="100" r="16" fill="#1e293b" stroke="#f59e0b" stroke-width="2"/>
              <text x="200" y="104" font-size="9" font-family="JetBrains Mono" fill="#fbbf24" text-anchor="middle">SCALE</text>
              <text x="200" y="135" font-size="10" font-weight="bold" fill="#f8fafc" text-anchor="middle">W-01</text>
              <text x="200" y="146" font-size="8" fill="#10b981" text-anchor="middle">56.25 kg</text>
            </g>

            <!-- 3. Planetary Mixer M-04 -->
            <g class="cursor-pointer group" (click)="factory.setTab('machine-twins')">
              <rect x="270" y="20" width="110" height="130" rx="8" fill="#0f172a" stroke="#f59e0b" stroke-width="2"/>
              <circle cx="325" cy="65" r="28" fill="#1e293b" stroke="#d97706" stroke-width="2"/>
              <!-- Whisk rotating animation -->
              <g [style.transform]="'rotate(' + factory.mixerTwinState().planetaryDeg + 'deg)'" style="transform-origin: 325px 65px;">
                <line x1="325" y1="45" x2="325" y2="85" stroke="#fbbf24" stroke-width="3"/>
                <line x1="305" y1="65" x2="345" y2="65" stroke="#fbbf24" stroke-width="3"/>
                <circle cx="335" cy="55" r="4" fill="#fbbf24"/>
              </g>
              <text x="325" y="110" font-size="11" font-weight="bold" fill="#fbbf24" text-anchor="middle" font-family="JetBrains Mono">MIXER M-04</text>
              <text x="325" y="125" font-size="9" fill="#f8fafc" text-anchor="middle">184 RPM · 19.4°C</text>
              <text x="325" y="140" font-size="8" fill="#10b981" text-anchor="middle">CREAMING</text>
            </g>

            <!-- 4. Depositor D-02 -->
            <g class="cursor-pointer group" (click)="factory.setTab('machine-twins')">
              <rect x="410" y="60" width="85" height="90" rx="6" fill="#0f172a" stroke="#64748b" stroke-width="1.5"/>
              <polygon points="430,70 475,70 460,110 445,110" fill="#334155"/>
              <line x1="452" y1="110" x2="452" y2="155" stroke="#f59e0b" stroke-width="3" stroke-dasharray="4 2"/>
              <text x="452" y="130" font-size="10" font-weight="bold" fill="#f8fafc" text-anchor="middle">DEPOSIT D-02</text>
              <text x="452" y="144" font-size="8" fill="#94a3b8" text-anchor="middle">225g × 2</text>
            </g>

            <!-- Moving Cake Sponges on Conveyor -->
            <g>
              <circle cx="515" cy="155" r="10" fill="#fef08a" stroke="#d97706" stroke-width="1.5"/>
              <circle cx="535" cy="155" r="10" fill="#fef08a" stroke="#d97706" stroke-width="1.5"/>
            </g>

            <!-- 5. 3-Zone Industrial Tunnel Oven O-07 -->
            <g class="cursor-pointer group" (click)="factory.setTab('machine-twins')">
              <rect x="560" y="30" width="170" height="120" rx="8" fill="#450a0a" stroke="#ef4444" stroke-width="2"/>
              <!-- Zone partitions -->
              <line x1="615" y1="30" x2="615" y2="150" stroke="#7f1d1d" stroke-width="1.5" stroke-dasharray="3 3"/>
              <line x1="675" y1="30" x2="675" y2="150" stroke="#7f1d1d" stroke-width="1.5" stroke-dasharray="3 3"/>
              
              <text x="645" y="55" font-size="11" font-weight="bold" fill="#fca5a5" text-anchor="middle" font-family="JetBrains Mono">TUNNEL OVEN O-07</text>
              <text x="590" y="80" font-size="9" fill="#fecaca" text-anchor="middle">Z1: 182°C</text>
              <text x="645" y="80" font-size="9" fill="#fecaca" text-anchor="middle">Z2: 176°C</text>
              <text x="705" y="80" font-size="9" fill="#fecaca" text-anchor="middle">Z3: 165°C</text>
              <rect x="580" y="100" width="130" height="18" rx="3" fill="#7f1d1d"/>
              <text x="645" y="113" font-size="9" font-family="JetBrains Mono" font-weight="bold" fill="#ffffff" text-anchor="middle">CORE: 94.2°C (PASS)</text>
              <text x="645" y="138" font-size="8" fill="#f87171" text-anchor="middle">22:00 MIN DWELL</text>
            </g>

            <!-- 6. Dynamic Cooling Tunnel C-02 -->
            <g class="cursor-pointer group" (click)="factory.setTab('machine-twins')">
              <rect x="750" y="40" width="110" height="110" rx="8" fill="#083344" stroke="#06b6d4" stroke-width="2"/>
              <circle cx="805" cy="75" r="18" fill="#164e63" stroke="#22d3ee" stroke-width="1.5"/>
              <mat-icon x="795" y="65">ac_unit</mat-icon>
              <text x="805" y="110" font-size="10" font-weight="bold" fill="#a5f3fc" text-anchor="middle">COOLER C-02</text>
              <text x="805" y="125" font-size="9" fill="#cffafe" text-anchor="middle">Exit: 19.4°C</text>
              <text x="805" y="138" font-size="8" fill="#67e8f9" text-anchor="middle">38m Dwell</text>
            </g>

            <!-- 7. 6-Axis Robotic Decorator R-07 -->
            <g class="cursor-pointer group" (click)="factory.setTab('machine-twins')">
              <rect x="880" y="20" width="115" height="130" rx="8" fill="#2e1065" stroke="#a855f7" stroke-width="2"/>
              <!-- Robotic Arm Simulation -->
              <circle cx="937" cy="45" r="10" fill="#581c87" stroke="#c084fc" stroke-width="2"/>
              <line x1="937" y1="45" [attr.x2]="920 + factory.roboticDecoratorState().x * 0.2" [attr.y2]="75" stroke="#e9d5ff" stroke-width="4"/>
              <line [attr.x1]="920 + factory.roboticDecoratorState().x * 0.2" y1="75" [attr.x2]="937" y2="110" stroke="#c084fc" stroke-width="3"/>
              <circle cx="937" cy="110" r="4" fill="#fbbf24"/>
              
              <text x="937" y="125" font-size="10" font-weight="bold" fill="#e9d5ff" text-anchor="middle" font-family="JetBrains Mono">ROBOT R-07</text>
              <text x="937" y="140" font-size="8" fill="#d8b4fe" text-anchor="middle">12 ROSETTES · VISION OK</text>
            </g>

            <!-- 8. Dual-Camera Vision QC V-01 -->
            <g class="cursor-pointer group" (click)="factory.setTab('quality-spc')">
              <rect x="1015" y="50" width="75" height="100" rx="6" fill="#064e3b" stroke="#10b981" stroke-width="2"/>
              <circle cx="1052" cy="78" r="14" fill="#047857" stroke="#34d399" stroke-width="2"/>
              <circle cx="1052" cy="78" r="4" fill="#10b981"/>
              <!-- Laser scanning cone -->
              <polygon points="1040,88 1064,88 1070,160 1034,160" fill="rgba(16, 185, 129, 0.15)"/>
              
              <text x="1052" y="115" font-size="10" font-weight="bold" fill="#6ee7b7" text-anchor="middle">VISION QC</text>
              <text x="1052" y="130" font-size="9" fill="#a7f3d0" text-anchor="middle">98.7% PASS</text>
              <text x="1052" y="142" font-size="8" fill="#34d399" text-anchor="middle">450g ±2g</text>
            </g>

            <!-- 9. Case Packer P-11 & Finished Goods Warehouse -->
            <g class="cursor-pointer group" (click)="factory.setTab('planner')">
              <rect x="1105" y="50" width="75" height="100" rx="6" fill="#0f172a" stroke="#64748b" stroke-width="1.5"/>
              <rect x="1120" y="70" width="45" height="40" fill="#334155" stroke="#94a3b8" stroke-width="1"/>
              <text x="1142" y="125" font-size="10" font-weight="bold" fill="#f8fafc" text-anchor="middle">PACKER</text>
              <text x="1142" y="140" font-size="8" fill="#94a3b8" text-anchor="middle">PALLET #14</text>
            </g>

            <!-- Dynamic Flow arrows below conveyor -->
            <path d="M100,210 L1150,210" stroke="#475569" stroke-width="1" stroke-dasharray="6 4"/>
            <text x="600" y="235" font-size="11" fill="#94a3b8" text-anchor="middle" font-family="JetBrains Mono">
              PRODUCTION FLOW: INGREDIENTS → MIXING → FORMING → BAKING → COOLING → DECORATING → QC → DISPATCH
            </text>
          </svg>
        </div>
      </div>

      <!-- Bottom Split: Active Production Batches & Live Event Log -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Active Batches Table (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
          <div class="flex items-center justify-between mb-4">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400 text-base">format_list_bulleted</mat-icon>
              <h3 class="font-brand font-bold text-sm text-slate-100 uppercase tracking-wide">In-Flight Production Batches</h3>
            </div>
            <span class="text-xs text-slate-400 font-mono">{{ factory.batches().length }} Active Batches</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs">
              <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 font-mono">
                <tr>
                  <th class="py-2.5 px-3">Batch ID</th>
                  <th class="py-2.5 px-3">Product / Customer</th>
                  <th class="py-2.5 px-3">Stage</th>
                  <th class="py-2.5 px-3">Progress</th>
                  <th class="py-2.5 px-3 text-right">Yield</th>
                  <th class="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60 font-medium">
                @for (batch of factory.batches(); track batch.id) {
                  <tr class="hover:bg-slate-800/40 transition-colors">
                    <td class="py-3 px-3 font-mono text-amber-400 font-semibold">{{ batch.id }}</td>
                    <td class="py-3 px-3">
                      <div class="text-slate-100 font-semibold truncate max-w-[180px]">{{ batch.productName }}</div>
                      <div class="text-[11px] text-slate-400 truncate">{{ batch.customerName }}</div>
                    </td>
                    <td class="py-3 px-3 font-mono">
                      <span class="px-2 py-0.5 rounded text-[10px] bg-slate-800 border border-slate-700 text-slate-300">
                        {{ batch.stage }}
                      </span>
                    </td>
                    <td class="py-3 px-3">
                      <div class="w-24 bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                        <div class="bg-amber-500 h-full rounded-full transition-all duration-500" [style.width.%]="batch.progressPercent"></div>
                      </div>
                      <span class="text-[10px] font-mono text-slate-400 mt-0.5 block">{{ batch.progressPercent }}%</span>
                    </td>
                    <td class="py-3 px-3 text-right font-mono text-slate-200">
                      {{ batch.actualProducedQuantity }} / {{ batch.targetQuantity }}
                    </td>
                    <td class="py-3 px-3 text-right">
                      <button 
                        (click)="inspectBatch(batch.id)"
                        class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-[11px] transition-colors">
                        Inspect
                      </button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Live Factory Event Stream (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <div class="flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-base">rss_feed</mat-icon>
                <h3 class="font-brand font-bold text-sm text-slate-100 uppercase tracking-wide">Live Audit Event Stream</h3>
              </div>
              <span class="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> Real-time
              </span>
            </div>

            <div class="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
              @for (evt of factory.eventStream().slice(0, 7); track evt.id) {
                <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80 text-xs flex items-start gap-2.5">
                  <span class="text-[10px] font-mono text-slate-400 shrink-0 mt-0.5">{{ evt.timestamp }}</span>
                  <div class="space-y-0.5 flex-1">
                    <div class="flex items-center gap-2">
                      <span class="text-[9px] font-mono px-1.5 py-0.2 rounded font-bold"
                        [class.bg-blue-950]="evt.category === 'BATCH'"
                        [class.text-blue-300]="evt.category === 'BATCH'"
                        [class.bg-amber-950]="evt.category === 'MACHINE'"
                        [class.text-amber-300]="evt.category === 'MACHINE'"
                        [class.bg-emerald-950]="evt.category === 'QUALITY'"
                        [class.text-emerald-300]="evt.category === 'QUALITY'"
                        [class.bg-purple-950]="evt.category === 'ALLERGEN'"
                        [class.text-purple-300]="evt.category === 'ALLERGEN'"
                        [class.bg-red-950]="evt.category === 'SAFETY'"
                        [class.text-red-300]="evt.category === 'SAFETY'">
                        {{ evt.category }}
                      </span>
                      @if (evt.machineCode) {
                        <span class="text-[10px] font-mono text-slate-400">{{ evt.machineCode }}</span>
                      }
                    </div>
                    <p class="text-slate-300 text-[11px] leading-relaxed">{{ evt.message }}</p>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
            <span>Deterministic Seed: #0x82041-UK</span>
            <button (click)="factory.setTab('traceability')" class="text-amber-400 hover:underline flex items-center gap-1">
              <span>View Full Lot Thread</span>
              <mat-icon class="text-xs">arrow_forward</mat-icon>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ControlRoomComponent {
  readonly factory = inject(BakeOSFactoryService);

  onConveyorSpeedChange(event: Event) {
    const input = event.target as HTMLInputElement;
    this.factory.setConveyorSpeed(+input.value);
  }

  inspectBatch(batchId: string) {
    this.factory.activeBatchId.set(batchId);
    this.factory.setTab('signature-run');
  }
}
