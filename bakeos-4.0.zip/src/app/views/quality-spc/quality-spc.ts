import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-quality-spc',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">VISION QC & STATISTICAL PROCESS CONTROL (SPC)</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              INSPECTION STATION V-01
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Dual-camera 3D laser profiler, browning spectrophotometry, and Shewhart X-bar capability monitoring
          </p>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <span class="text-slate-400">Current Process Cpk:</span>
          <span class="px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800">
            1.64 (Six Sigma Standard)
          </span>
        </div>
      </div>

      <!-- Live Vision Camera Inspection Feed (Top) -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Overhead & Laser Camera (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">camera_alt</mat-icon>
              <div>
                <div class="text-xs font-mono text-slate-400">CAMERA V-01 OPTICAL FEED</div>
                <h2 class="font-brand font-bold text-base text-slate-100">Live Continuous Cake Inspection</h2>
              </div>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 animate-pulse border border-emerald-800">
              LIVE 60 FPS
            </span>
          </div>

          <!-- Camera Image Frame with Laser Scanning Overlay -->
          <div class="relative rounded-xl overflow-hidden border border-slate-700 bg-slate-950">
            <img 
              src="/assets/images/victoria_sponge_spec_1791368023892.jpg" 
              alt="Live Vision Inspection Sample"
              referrerpolicy="no-referrer"
              class="w-full h-64 object-cover object-center brightness-90 contrast-110" />

            <!-- CAD Machine Vision Overlay Graphics -->
            <div class="absolute inset-0 p-4 pointer-events-none flex flex-col justify-between select-none">
              <div class="flex justify-between items-start text-[10px] font-mono text-emerald-400">
                <div class="bg-slate-950/80 p-1.5 rounded border border-emerald-500/40 backdrop-blur">
                  SAMPLE: CAKE-82041-342<br/>
                  DIAMETER: 200.1 mm [OK]<br/>
                  HEIGHT: 110.2 mm [OK]
                </div>
                <div class="bg-slate-950/80 p-1.5 rounded border border-emerald-500/40 backdrop-blur text-right">
                  WEIGHT: 450.4 g<br/>
                  BROWNING ΔE: 0.94<br/>
                  ROSETTE ALIGN: 99.2%
                </div>
              </div>

              <!-- Center Crosshairs & Circular Boundary Box -->
              <div class="self-center flex items-center justify-center w-36 h-36 border-2 border-dashed border-emerald-400 rounded-full relative">
                <div class="w-2 h-2 rounded-full bg-emerald-400"></div>
                <div class="absolute -top-3 px-1 bg-slate-950 text-[9px] font-mono text-emerald-300">EDGE BOUNDARY 200mm</div>
              </div>

              <!-- Verdict Banner -->
              <div class="self-center bg-emerald-500 text-slate-950 px-4 py-1 rounded-full font-mono font-bold text-xs shadow-lg">
                STATUS: PASS (DIVERT TO PACKAGING)
              </div>
            </div>
          </div>

          <!-- Real-Time Sample History -->
          <div>
            <div class="text-xs font-mono text-slate-400 mb-2 uppercase">Recent Unit Inspections</div>
            <div class="space-y-1.5">
              @for (sample of factory.recentQualitySamples(); track sample.id) {
                <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between text-xs font-mono">
                  <div class="flex items-center gap-3">
                    <span class="text-slate-400 text-[10px]">{{ sample.timestamp }}</span>
                    <span class="font-bold text-slate-200">{{ sample.sampleCode }}</span>
                    <span class="text-slate-400">{{ sample.weightGrams }}g · {{ sample.heightMm }}mm</span>
                  </div>
                  <div>
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-950]="sample.status === 'PASS'"
                      [class.text-emerald-400]="sample.status === 'PASS'"
                      [class.border-emerald-800]="sample.status === 'PASS'"
                      [class.bg-red-950]="sample.status === 'REJECT'"
                      [class.text-red-400]="sample.status === 'REJECT'"
                      [class.border-red-800]="sample.status === 'REJECT'"
                      [class.border]="true">
                      {{ sample.status }}
                    </span>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Shewhart SPC Control Charts (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-blue-400">analytics</mat-icon>
              <div>
                <div class="text-xs font-mono text-slate-400">STATISTICAL PROCESS CONTROL</div>
                <h2 class="font-brand font-bold text-base text-slate-100">Weight & Height X-Bar Chart</h2>
              </div>
            </div>
            <span class="text-xs font-mono text-slate-400">N = 50 Samples</span>
          </div>

          <!-- Shewhart Control Chart SVG -->
          <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div class="flex justify-between items-center text-xs font-mono">
              <span class="text-slate-300 font-bold">Victoria Sponge Net Weight (g)</span>
              <span class="text-emerald-400">Cpk: 1.64</span>
            </div>

            <svg viewBox="0 0 400 180" class="w-full h-44 select-none">
              <!-- UCL Line (458.5g) -->
              <line x1="30" y1="30" x2="380" y2="30" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4 2"/>
              <text x="385" y="34" font-size="8" fill="#ef4444" font-family="JetBrains Mono">UCL 458.5</text>

              <!-- Center Target Line (450.0g) -->
              <line x1="30" y1="90" x2="380" y2="90" stroke="#10b981" stroke-width="2"/>
              <text x="385" y="94" font-size="8" fill="#10b981" font-family="JetBrains Mono">CL 450.0</text>

              <!-- LCL Line (441.5g) -->
              <line x1="30" y1="150" x2="380" y2="150" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="4 2"/>
              <text x="385" y="154" font-size="8" fill="#ef4444" font-family="JetBrains Mono">LCL 441.5</text>

              <!-- Measured Data Polyline -->
              <polyline 
                points="40,95 80,82 120,88 160,102 200,78 240,86 280,91 320,84 360,88" 
                fill="none" 
                stroke="#60a5fa" 
                stroke-width="2.5"/>

              <!-- Individual Points -->
              <circle cx="40" cy="95" r="3.5" fill="#60a5fa"/>
              <circle cx="80" cy="82" r="3.5" fill="#60a5fa"/>
              <circle cx="120" cy="88" r="3.5" fill="#60a5fa"/>
              <circle cx="160" cy="102" r="3.5" fill="#60a5fa"/>
              <circle cx="200" cy="78" r="3.5" fill="#60a5fa"/>
              <circle cx="240" cy="86" r="3.5" fill="#60a5fa"/>
              <circle cx="280" cy="91" r="3.5" fill="#60a5fa"/>
              <circle cx="320" cy="84" r="3.5" fill="#60a5fa"/>
              <circle cx="360" cy="88" r="3.5" fill="#60a5fa"/>
            </svg>

            <div class="text-[11px] text-slate-400 font-mono flex items-center justify-between border-t border-slate-800 pt-2">
              <span>Western Electric Rules: All In Control</span>
              <span class="text-emerald-400">Zero Process Drift</span>
            </div>
          </div>

          <!-- Quality Defect Matrix Breakdown -->
          <div class="space-y-2 text-xs">
            <div class="font-mono text-slate-400 font-bold uppercase">Pareto Defect Classification</div>
            
            <div class="space-y-1.5 font-mono">
              <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                <span class="text-slate-300">Weight Variance (< 435g or > 465g):</span>
                <span class="text-slate-100 font-bold">0.8% (4 / 500)</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                <span class="text-slate-300">Browning Color Gradient Deviation:</span>
                <span class="text-slate-100 font-bold">0.3% (1 / 500)</span>
              </div>
              <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                <span class="text-slate-300">Rosette Piping Misalignment:</span>
                <span class="text-slate-100 font-bold">0.2% (1 / 500)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class QualitySpcComponent {
  readonly factory = inject(BakeOSFactoryService);
}
