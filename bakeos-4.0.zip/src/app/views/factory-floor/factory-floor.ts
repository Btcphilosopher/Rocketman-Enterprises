import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

interface Department {
  id: string;
  name: string;
  zone: string;
  status: 'NOMINAL' | 'BUSY' | 'CLEANING';
  temperatureC: number;
  humidityPercent: number;
  machinesCount: number;
  activeBatch?: string;
  x: number;
  y: number;
  w: number;
  h: number;
  description: string;
}

@Component({
  selector: 'app-factory-floor',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Top Title and Department Selector -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">PLANT DIGITAL TWIN — THE NORTHSHIRE BAKERY</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30">
              18,500 m² FACILITY
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Real-time multi-zone plant spatial model · Click any department to inspect machine cluster & environmental telemetry
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="selectedDept.set(null)"
            class="px-3 py-1.5 rounded-lg border text-xs font-mono transition-colors"
            [class.bg-amber-500]="selectedDept() === null"
            [class.text-slate-950]="selectedDept() === null"
            [class.font-bold]="selectedDept() === null"
            [class.border-amber-500]="selectedDept() === null"
            [class.bg-slate-900]="selectedDept() !== null"
            [class.text-slate-300]="selectedDept() !== null"
            [class.border-slate-800]="selectedDept() !== null">
            Full Facility View
          </button>
        </div>
      </div>

      <!-- Main Interactive Blueprint / 3D Isometric Factory Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Factory Map Canvas (8 Cols) -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-2xl relative"
             [class.engineering-grid-dense]="factory.viewMode() === 'engineering'">
          
          <div class="flex items-center justify-between mb-3 text-xs text-slate-400">
            <span class="font-mono">Spatial Grid: 100m × 60m Ground Floor</span>
            <span class="font-mono text-emerald-400">Status: Live IoT Synchronised</span>
          </div>

          <!-- Interactive SVG Architectural Plant Floor -->
          <div class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2 overflow-hidden">
            <svg viewBox="0 0 1000 620" class="w-full h-auto select-none">
              <!-- Grid background lines -->
              <defs>
                <pattern id="factoryGrid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(51, 65, 85, 0.25)" stroke-width="1"/>
                </pattern>
              </defs>
              <rect width="1000" height="620" fill="url(#factoryGrid)"/>

              <!-- Outer Building Walls -->
              <rect x="20" y="20" width="960" height="580" rx="12" fill="#090d16" stroke="#475569" stroke-width="3"/>

              <!-- Department Zones -->
              @for (dept of departments; track dept.id) {
                <g class="cursor-pointer group" (click)="selectDepartment(dept)">
                  <rect 
                    [attr.x]="dept.x" 
                    [attr.y]="dept.y" 
                    [attr.width]="dept.w" 
                    [attr.height]="dept.h" 
                    rx="8" 
                    [attr.fill]="selectedDept()?.id === dept.id ? '#1e293b' : '#0f172a'"
                    [attr.stroke]="selectedDept()?.id === dept.id ? '#f59e0b' : '#334155'"
                    stroke-width="2"
                    class="transition-all duration-300 group-hover:stroke-amber-400 group-hover:fill-slate-800/80"/>
                  
                  <!-- Department Header bar -->
                  <rect 
                    [attr.x]="dept.x" 
                    [attr.y]="dept.y" 
                    [attr.width]="dept.w" 
                    height="24" 
                    rx="6" 
                    [attr.fill]="selectedDept()?.id === dept.id ? '#f59e0b' : '#1e293b'"/>
                  
                  <text 
                    [attr.x]="dept.x + 10" 
                    [attr.y]="dept.y + 16" 
                    font-size="11" 
                    font-weight="bold" 
                    [attr.fill]="selectedDept()?.id === dept.id ? '#0f172a' : '#f8fafc'" 
                    font-family="Plus Jakarta Sans">
                    {{ dept.name }}
                  </text>

                  <!-- Temperature & Machine Badge -->
                  <text 
                    [attr.x]="dept.x + dept.w - 10" 
                    [attr.y]="dept.y + 16" 
                    font-size="10" 
                    font-family="JetBrains Mono"
                    text-anchor="end"
                    [attr.fill]="selectedDept()?.id === dept.id ? '#0f172a' : '#94a3b8'">
                    {{ dept.temperatureC }}°C · {{ dept.machinesCount }} Units
                  </text>

                  <!-- Internal Details -->
                  <text 
                    [attr.x]="dept.x + 12" 
                    [attr.y]="dept.y + 50" 
                    font-size="9" 
                    fill="#94a3b8" 
                    font-family="JetBrains Mono">
                    Zone: {{ dept.zone }}
                  </text>
                  <text 
                    [attr.x]="dept.x + 12" 
                    [attr.y]="dept.y + 68" 
                    font-size="9" 
                    fill="#cbd5e1">
                    {{ dept.description }}
                  </text>
                  @if (dept.activeBatch) {
                    <rect 
                      [attr.x]="dept.x + 10" 
                      [attr.y]="dept.y + dept.h - 26" 
                      [attr.width]="dept.w - 20" 
                      height="18" 
                      rx="3" 
                      fill="#064e3b" 
                      stroke="#10b981" 
                      stroke-width="1"/>
                    <text 
                      [attr.x]="dept.x + dept.w / 2" 
                      [attr.y]="dept.y + dept.h - 13" 
                      font-size="9" 
                      font-family="JetBrains Mono" 
                      fill="#6ee7b7" 
                      text-anchor="middle">
                      {{ dept.activeBatch }} (ACTIVE)
                    </text>
                  }
                </g>
              }

              <!-- Central Main Production Corridor & Conveyor Flow -->
              <path d="M 280 230 L 280 430 L 740 430 L 740 230" fill="none" stroke="#f59e0b" stroke-width="3" stroke-dasharray="8 4"/>
              <text x="500" y="445" font-size="10" fill="#f59e0b" font-family="JetBrains Mono" text-anchor="middle">
                MAIN AUTOMATED CONVEYOR ARTERY — LINE 1 & 2
              </text>
            </svg>
          </div>
        </div>

        <!-- Selected Department Deep Dive Panel (4 Cols) -->
        <div class="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          @if (selectedDept()) {
            <div class="space-y-4">
              <div class="border-b border-slate-800 pb-3">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-mono text-amber-400">{{ selectedDept()?.zone }}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                    {{ selectedDept()?.status }}
                  </span>
                </div>
                <h2 class="font-brand font-bold text-lg text-slate-100 mt-1">{{ selectedDept()?.name }}</h2>
                <p class="text-xs text-slate-400 mt-1">{{ selectedDept()?.description }}</p>
              </div>

              <!-- Environmental Telemetry -->
              <div class="grid grid-cols-2 gap-3">
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div class="text-[10px] text-slate-500 uppercase font-mono">Ambient Temp</div>
                  <div class="text-lg font-mono font-bold text-slate-100 mt-0.5">{{ selectedDept()?.temperatureC }}°C</div>
                  <div class="text-[9px] text-slate-400">HVAC Zone Nominal</div>
                </div>
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <div class="text-[10px] text-slate-500 uppercase font-mono">Relative Humidity</div>
                  <div class="text-lg font-mono font-bold text-cyan-400 mt-0.5">{{ selectedDept()?.humidityPercent }}%</div>
                  <div class="text-[9px] text-slate-400">Dew Point: 11.2°C</div>
                </div>
              </div>

              <!-- Machinery in this department -->
              <div>
                <div class="text-xs font-mono font-bold text-slate-300 uppercase mb-2">Installed Machinery Units</div>
                <div class="space-y-2">
                  @for (m of getMachinesInDept(selectedDept()!.id); track m.id) {
                    <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex items-center justify-between">
                      <div class="space-y-0.5">
                        <div class="text-xs font-bold text-slate-200">{{ m.name }}</div>
                        <div class="text-[10px] font-mono text-amber-400">{{ m.code }} · {{ m.type }}</div>
                      </div>
                      <div class="text-right">
                        <span class="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold"
                          [class.bg-emerald-950]="m.status === 'RUNNING'"
                          [class.text-emerald-400]="m.status === 'RUNNING'"
                          [class.bg-slate-800]="m.status === 'READY'"
                          [class.text-slate-300]="m.status === 'READY'">
                          {{ m.status }}
                        </span>
                        <div class="text-[10px] font-mono text-slate-400 mt-0.5">OEE: {{ m.oee.overall }}%</div>
                      </div>
                    </div>
                  }
                </div>
              </div>

              <!-- Quick action to twin view -->
              <button 
                (click)="factory.setTab('machine-twins')"
                class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5">
                <mat-icon class="text-sm">precision_manufacturing</mat-icon>
                <span>Open Digital Twin Telemetry</span>
              </button>
            </div>
          } @else {
            <div class="space-y-4">
              <div class="border-b border-slate-800 pb-3">
                <div class="text-xs font-mono text-slate-400">FACILITY OVERVIEW</div>
                <h2 class="font-brand font-bold text-lg text-slate-100 mt-1">The Northshire Bakery Infrastructure</h2>
                <p class="text-xs text-slate-400 mt-1">Select any department zone from the spatial map to view machinery telemetry and environmental controls.</p>
              </div>

              <div class="space-y-2 text-xs text-slate-300">
                <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span class="text-slate-400">Total Factory Area:</span>
                  <span class="font-mono font-bold text-slate-100">18,500 m²</span>
                </div>
                <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span class="text-slate-400">Production Lines:</span>
                  <span class="font-mono font-bold text-amber-400">12 Lines (3 High-Speed Cake, 4 Bread, 5 Pastry)</span>
                </div>
                <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span class="text-slate-400">Cleanroom Classification:</span>
                  <span class="font-mono font-bold text-emerald-400">ISO Class 8 (Decorating & Packing)</span>
                </div>
                <div class="flex justify-between p-2 rounded bg-slate-950 border border-slate-800">
                  <span class="text-slate-400">HACCP Critical Control Points:</span>
                  <span class="font-mono font-bold text-blue-400">4 Active In-Line CCPs</span>
                </div>
              </div>

              <div class="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs leading-relaxed">
                <div class="font-bold flex items-center gap-1 mb-1">
                  <mat-icon class="text-sm">info</mat-icon>
                  <span>Line 01 Live Run</span>
                </div>
                The Northshire Heritage Victoria Sponge (500 units) is currently in continuous transit across Mixing (M-04), Oven (O-07), Cooler (C-02) and Robot (R-07).
              </div>
            </div>
          }

          <div class="pt-4 border-t border-slate-800 flex justify-between items-center text-[11px] text-slate-400">
            <span>Plant Energy: 242 kW</span>
            <span class="text-emerald-400 font-mono">BSI / FSA Certified</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FactoryFloorComponent {
  readonly factory = inject(BakeOSFactoryService);

  readonly departments: Department[] = [
    { id: 'SILO_PARK', name: 'Raw Material Silo Park', zone: 'ZONE-A1', status: 'NOMINAL', temperatureC: 18.0, humidityPercent: 45, machinesCount: 6, x: 40, y: 40, w: 220, h: 140, description: 'Flour & sugar pneumatic bulk silos, liquid egg refrigerated tanks.', activeBatch: 'BATCH-82041' },
    { id: 'WEIGHING', name: 'Micro-Ingredient Weighing', zone: 'ZONE-A2', status: 'NOMINAL', temperatureC: 19.5, humidityPercent: 50, machinesCount: 4, x: 40, y: 200, w: 220, h: 130, description: 'Mettler-Toledo precision balances for leaveners, extracts, salt.', activeBatch: 'BATCH-82043' },
    { id: 'CHILLED', name: 'Chilled Storage & Dairy', zone: 'ZONE-A3', status: 'NOMINAL', temperatureC: 3.8, humidityPercent: 75, machinesCount: 2, x: 40, y: 350, w: 220, h: 110, description: 'West Country butter, Cornish clotted cream, British fresh milk.', activeBatch: undefined },
    { id: 'MIXING', name: 'Planetary & Spiral Mixing Hall', zone: 'ZONE-B1', status: 'BUSY', temperatureC: 19.2, humidityPercent: 52, machinesCount: 8, x: 280, y: 40, w: 210, h: 170, description: 'Planetary M-04, Spiral S-01, temperature-controlled jacketed bowls.', activeBatch: 'BATCH-82041' },
    { id: 'FORMING', name: 'Volumetric Depositing & Moulding', zone: 'ZONE-B2', status: 'NOMINAL', temperatureC: 20.0, humidityPercent: 50, machinesCount: 5, x: 280, y: 230, w: 210, h: 140, description: 'Piston depositor D-02, automatic tin greasing, paper liner placer.', activeBatch: 'BATCH-82041' },
    { id: 'OVEN_HALL', name: 'Industrial Oven Hall', zone: 'ZONE-C1', status: 'BUSY', temperatureC: 32.0, humidityPercent: 35, machinesCount: 6, x: 510, y: 40, w: 220, h: 200, description: '3-Zone Tunnel Oven O-07, Rotary Rack O-03, Deck Hearth O-01.', activeBatch: 'BATCH-82041' },
    { id: 'COOLING', name: 'Dynamic Cooling Tunnel Hall', zone: 'ZONE-C2', status: 'NOMINAL', temperatureC: 16.5, humidityPercent: 60, machinesCount: 3, x: 510, y: 260, w: 220, h: 120, description: 'Rapid convective cooling tunnel C-02, HEPA filtered laminar flow.', activeBatch: 'BATCH-82041' },
    { id: 'DECORATING', name: '6-Axis Robotic Decorating Room', zone: 'ZONE-D1', status: 'BUSY', temperatureC: 18.0, humidityPercent: 48, machinesCount: 5, x: 750, y: 40, w: 210, h: 180, description: 'Robot R-07, vision closed-loop piping, chocolate tempering enrober.', activeBatch: 'BATCH-82041' },
    { id: 'PACKAGING', name: 'Automated Packaging & Carton Hall', zone: 'ZONE-D2', status: 'NOMINAL', temperatureC: 20.5, humidityPercent: 45, machinesCount: 7, x: 750, y: 240, w: 210, h: 140, description: 'Cartoner P-11, checkweigher, metal detector, case palletizer.', activeBatch: 'BATCH-82041' },
    { id: 'WAREHOUSE', name: 'Finished Goods Warehouse & Dispatch', zone: 'ZONE-E1', status: 'NOMINAL', temperatureC: 15.0, humidityPercent: 55, machinesCount: 4, x: 40, y: 480, w: 920, h: 100, description: 'High-density FEFO automated racking, temperature controlled dispatch bays.', activeBatch: undefined }
  ];

  readonly selectedDept = signal<Department | null>(this.departments[3]); // Mixing default

  selectDepartment(dept: Department) {
    this.selectedDept.set(dept);
  }

  getMachinesInDept(deptId: string) {
    return this.factory.machines().filter(m => {
      if (deptId === 'MIXING') return m.department === 'MIXING';
      if (deptId === 'FORMING') return m.department === 'FORMING';
      if (deptId === 'OVEN_HALL') return m.department === 'BAKING';
      if (deptId === 'COOLING') return m.department === 'COOLING';
      if (deptId === 'DECORATING') return m.department === 'DECORATING';
      if (deptId === 'PACKAGING') return m.department === 'PACKAGING';
      return false;
    });
  }
}
