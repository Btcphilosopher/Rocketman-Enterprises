import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-planner',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">BAKERY PRODUCTION PLANNER & BOTTLENECK MODEL</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30">
              HEURISTIC SCHEDULE OPTIMIZATION
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Sequence scheduling, changeover allergen washout buffers, and real-time machine capacity utilization
          </p>
        </div>

        <div class="text-right text-xs font-mono">
          <span class="text-slate-400">Target Shift Delivery:</span>
          <span class="text-emerald-400 font-bold ml-1">99.4% On-Time In-Full (OTIF)</span>
        </div>
      </div>

      <!-- Bottleneck Diagnostic Card (Specification Section 51) -->
      <div class="p-5 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-3">
        <div class="flex items-center justify-between">
          <div class="flex items-center gap-2 text-amber-300 font-brand font-bold text-sm">
            <mat-icon class="text-amber-400">warning_amber</mat-icon>
            <span>LIVE FACTORY BOTTLENECK: {{ factory.bottleneckAnalysis().currentBottleneckName }}</span>
          </div>
          <span class="text-xs font-mono text-amber-300/80">Constraint Score: 98%</span>
        </div>
        <p class="text-xs text-amber-200/90 leading-relaxed">
          {{ factory.bottleneckAnalysis().recommendedAction }}
        </p>
      </div>

      <!-- Machine Utilisation Breakdown Bars -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div class="text-xs font-mono text-slate-400 uppercase tracking-wider">
          Production Stage Capacity & Utilisation Breakdown
        </div>

        <div class="space-y-3">
          @for (stg of factory.bottleneckAnalysis().stages; track stg.name) {
            <div class="p-3 rounded-xl bg-slate-950 border border-slate-800/80 space-y-1.5 text-xs">
              <div class="flex justify-between items-center">
                <div class="flex items-center gap-2">
                  <span class="font-bold text-slate-200">{{ stg.name }}</span>
                  <span class="text-[10px] font-mono text-slate-500">({{ stg.capacityKgH }} kg/h max)</span>
                </div>
                <div class="font-mono font-bold"
                  [class.text-red-400]="stg.utilisation >= 95"
                  [class.text-amber-400]="stg.utilisation >= 80 && stg.utilisation < 95"
                  [class.text-emerald-400]="stg.utilisation < 80">
                  {{ stg.utilisation }}% Utilisation
                </div>
              </div>

              <!-- Progress bar -->
              <div class="w-full bg-slate-900 rounded-full h-2 overflow-hidden border border-slate-800">
                <div 
                  class="h-full rounded-full transition-all duration-500"
                  [class.bg-red-500]="stg.utilisation >= 95"
                  [class.bg-amber-500]="stg.utilisation >= 80 && stg.utilisation < 95"
                  [class.bg-emerald-500]="stg.utilisation < 80"
                  [style.width.%]="stg.utilisation">
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Orders & Shift Gantt Schedule -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div class="flex items-center gap-2">
            <mat-icon class="text-blue-400">calendar_month</mat-icon>
            <h2 class="font-brand font-bold text-base text-slate-100">COMMERCIAL PRODUCTION ORDERS & DISPATCH SCHEDULE</h2>
          </div>
          <span class="text-xs font-mono text-slate-400">{{ factory.orders().length }} Customer Orders</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs">
            <thead class="bg-slate-950 text-slate-400 font-mono border-b border-slate-800">
              <tr>
                <th class="py-2.5 px-3">Order ID</th>
                <th class="py-2.5 px-3">Customer</th>
                <th class="py-2.5 px-3">Product Description</th>
                <th class="py-2.5 px-3 text-right">Quantity</th>
                <th class="py-2.5 px-3">Delivery</th>
                <th class="py-2.5 px-3">Priority</th>
                <th class="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60 font-medium">
              @for (ord of factory.orders(); track ord.id) {
                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="py-3 px-3 font-mono text-amber-400 font-semibold">{{ ord.id }}</td>
                  <td class="py-3 px-3 font-semibold text-slate-100">{{ ord.customer }}</td>
                  <td class="py-3 px-3 text-slate-300">{{ ord.productName }}</td>
                  <td class="py-3 px-3 text-right font-mono text-slate-100 font-bold">{{ ord.quantity }}</td>
                  <td class="py-3 px-3 font-mono text-slate-400">{{ ord.deliveryDate }}</td>
                  <td class="py-3 px-3 font-mono">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-red-950]="ord.priority === 'CRITICAL'"
                      [class.text-red-400]="ord.priority === 'CRITICAL'"
                      [class.bg-amber-950]="ord.priority === 'HIGH'"
                      [class.text-amber-400]="ord.priority === 'HIGH'"
                      [class.bg-slate-800]="ord.priority === 'NORMAL'"
                      [class.text-slate-300]="ord.priority === 'NORMAL'">
                      {{ ord.priority }}
                    </span>
                  </td>
                  <td class="py-3 px-3 text-right font-mono">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      {{ ord.status }}
                    </span>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class PlannerComponent {
  readonly factory = inject(BakeOSFactoryService);
}
