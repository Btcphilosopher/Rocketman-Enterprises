import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-maintenance',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">BAKERY MAINTENANCE OS & PREDICTIVE ASSET HEALTH</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30">
              BS EN 1672-2 HYGIENE & MACHINERY COMPLIANT
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Vibration FFT spectrum analysis · Thermal degradation modeling · Automated work order generation
          </p>
        </div>

        <div class="flex items-center gap-2 font-mono text-xs">
          <span class="text-slate-400">Plant Health Index:</span>
          <span class="px-2.5 py-1 rounded bg-emerald-950 text-emerald-400 font-bold border border-emerald-800">
            94.8% Nominal
          </span>
        </div>
      </div>

      <!-- Machinery Health Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        @for (m of factory.machines(); track m.id) {
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
            <div class="flex items-center justify-between">
              <div>
                <span class="text-xs font-mono text-amber-400 font-bold">{{ m.code }}</span>
                <h3 class="font-brand font-bold text-sm text-slate-100 mt-0.5">{{ m.name }}</h3>
              </div>
              <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                [class.bg-emerald-950]="m.hoursUntilMaintenance > 100"
                [class.text-emerald-400]="m.hoursUntilMaintenance > 100"
                [class.bg-amber-950]="m.hoursUntilMaintenance <= 100"
                [class.text-amber-400]="m.hoursUntilMaintenance <= 100">
                {{ m.hoursUntilMaintenance <= 100 ? 'SERVICE DUE' : 'NOMINAL' }}
              </span>
            </div>

            <!-- Health Telemetry Metrics -->
            <div class="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div>
                <span class="text-slate-500 block text-[10px] uppercase">Running Hours</span>
                <span class="text-slate-200 font-bold">{{ m.runningHoursTotal }} hrs</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px] uppercase">Next Service In</span>
                <span class="font-bold" [class.text-amber-400]="m.hoursUntilMaintenance <= 100" [class.text-blue-400]="m.hoursUntilMaintenance > 100">
                  {{ m.hoursUntilMaintenance }} hrs
                </span>
              </div>
              <div class="pt-1.5 border-t border-slate-800">
                <span class="text-slate-500 block text-[10px] uppercase">Vibration (RMS)</span>
                <span class="text-emerald-400 font-bold">{{ m.vibrationMmS }} mm/s</span>
              </div>
              <div class="pt-1.5 border-t border-slate-800">
                <span class="text-slate-500 block text-[10px] uppercase">Calculated OEE</span>
                <span class="text-amber-300 font-bold">{{ m.oee.overall }}%</span>
              </div>
            </div>

            <div class="flex items-center justify-between pt-1">
              <span class="text-[11px] font-mono text-slate-400">Hygiene: {{ m.hygieneStatus }}</span>
              <button 
                (click)="logMaintenanceOrder(m.code)"
                class="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs transition-colors">
                Schedule Work Order
              </button>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class MaintenanceComponent {
  readonly factory = inject(BakeOSFactoryService);

  logMaintenanceOrder(machineCode: string) {
    this.factory.addEvent('MACHINE', `Maintenance Work Order dispatched for ${machineCode}: Scheduled mechanical inspection and food-grade lubrication.`);
  }
}
