import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-weighing-dosing',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">PRECISION WEIGHING & AUTOMATED DOSING</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30">
              STATION W-01 & SILO PARK
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Simulated strain-gauge load cell telemetry · Strict ±0.020 kg tolerance enforcement with quality sign-off
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-slate-400">Scale Calibration:</span>
          <span class="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 font-mono text-xs font-bold border border-emerald-800">
            NTEP / UK Trade Approved
          </span>
        </div>
      </div>

      <!-- Main Split: Precision Digital Scale vs Automated Silo Dosing -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Precision Weigh Scale (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
          @let scale = factory.scaleStationState();

          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-amber-400">scale</mat-icon>
              <div>
                <div class="text-xs font-mono text-slate-400">{{ scale.scaleId }} · METTLER TOLEDO BENCHTOP</div>
                <h2 class="font-brand font-bold text-lg text-slate-100">{{ scale.ingredientName }}</h2>
              </div>
            </div>

            <!-- Tolerance State Indicator Badge -->
            <div class="text-right">
              <span class="px-3 py-1 rounded-lg text-xs font-mono font-bold uppercase tracking-wider"
                [class.bg-emerald-500]="scale.status === 'IN_TOLERANCE'"
                [class.text-slate-950]="scale.status === 'IN_TOLERANCE'"
                [class.bg-blue-900]="scale.status === 'UNDER'"
                [class.text-blue-200]="scale.status === 'UNDER'"
                [class.bg-red-500]="scale.status === 'OVER'"
                [class.text-white]="scale.status === 'OVER'">
                {{ scale.status === 'IN_TOLERANCE' ? 'WITHIN TOLERANCE' : scale.status }}
              </span>
              <div class="text-[10px] font-mono text-slate-400 mt-1">Tolerance: ±{{ scale.toleranceKg.toFixed(3) }} kg</div>
            </div>
          </div>

          <!-- Digital Scale Big Telemetry Display (British Industrial Style) -->
          <div class="bg-slate-950 border-2 rounded-2xl p-6 text-center space-y-2 relative transition-all"
            [class.border-emerald-500]="scale.status === 'IN_TOLERANCE'"
            [class.border-blue-700]="scale.status === 'UNDER'"
            [class.border-red-500]="scale.status === 'OVER'">
            
            <div class="text-xs font-mono text-slate-400 flex items-center justify-between">
              <span>ACTIVE INGREDIENT LOT: {{ scale.lotNumber }}</span>
              <span>NET WEIGHT</span>
            </div>

            <!-- Big Tabular Numerals -->
            <div class="text-6xl font-mono font-bold tracking-tight tabular-nums py-2"
              [class.text-emerald-400]="scale.status === 'IN_TOLERANCE'"
              [class.text-blue-400]="scale.status === 'UNDER'"
              [class.text-red-400]="scale.status === 'OVER'">
              {{ scale.currentKg.toFixed(3) }} <span class="text-3xl font-normal text-slate-500">kg</span>
            </div>

            <!-- Target vs Difference Bar -->
            <div class="flex items-center justify-between text-xs font-mono pt-3 border-t border-slate-800 text-slate-300">
              <span>TARGET: <strong class="text-slate-100">{{ scale.targetKg.toFixed(3) }} kg</strong></span>
              <span>DELTA: 
                <strong [class.text-emerald-400]="scale.status === 'IN_TOLERANCE'"
                        [class.text-blue-400]="scale.status === 'UNDER'"
                        [class.text-red-400]="scale.status === 'OVER'">
                  {{ (scale.currentKg - scale.targetKg > 0 ? '+' : '') + (scale.currentKg - scale.targetKg).toFixed(3) }} kg
                </strong>
              </span>
            </div>
          </div>

          <!-- Operator Interactive Dosing Controls -->
          <div class="space-y-3">
            <div class="text-xs font-mono text-slate-400">OPERATOR SIMULATED SCOOP & DISPENSE CONTROLS:</div>
            
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button 
                (click)="factory.addWeightToScale(1.0)"
                class="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-100 font-mono text-xs rounded-xl font-bold transition-colors">
                +1.000 kg (Bulk)
              </button>
              <button 
                (click)="factory.addWeightToScale(0.100)"
                class="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-100 font-mono text-xs rounded-xl font-bold transition-colors">
                +0.100 kg (Scoop)
              </button>
              <button 
                (click)="factory.addWeightToScale(0.010)"
                class="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-100 font-mono text-xs rounded-xl font-bold transition-colors">
                +0.010 kg (Fine)
              </button>
              <button 
                (click)="factory.addWeightToScale(-0.100)"
                class="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-red-400 font-mono text-xs rounded-xl font-bold transition-colors border border-slate-800">
                -0.100 kg (Remove)
              </button>
            </div>

            <!-- Interlock Gate & Quality Override -->
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
              <div>
                <div class="font-bold text-slate-200">Production Release Interlock</div>
                <div class="text-slate-400 text-[11px] mt-0.5">
                  @if (scale.status === 'IN_TOLERANCE') {
                    <span class="text-emerald-400">✓ Weight within strict ±0.020kg spec. Batch authorized to proceed to Mixer M-04.</span>
                  } @else if (scale.authorizedOverride) {
                    <span class="text-amber-400">⚠ Production proceeding under Quality Lead Authorized Override.</span>
                  } @else {
                    <span class="text-red-400">✕ Gate locked: Critical ingredient is out of tolerance.</span>
                  }
                </div>
              </div>

              @if (scale.status !== 'IN_TOLERANCE' && !scale.authorizedOverride) {
                <button 
                  (click)="factory.setAuthorizedOverride()"
                  class="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-lg transition-colors font-mono">
                  Authorize Override
                </button>
              }
            </div>
          </div>
        </div>

        <!-- Automated Silo & Hopper Dosing (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-blue-400">grain</mat-icon>
              <div>
                <div class="text-xs font-mono text-slate-400">PNEUMATIC BULK FEED</div>
                <h2 class="font-brand font-bold text-lg text-slate-100">Automated Silo Dosing</h2>
              </div>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-950 text-blue-400 border border-blue-800">
              SILO-03 ACTIVE
            </span>
          </div>

          <!-- Silo Vessel Levels -->
          <div class="grid grid-cols-2 gap-4">
            <!-- Flour Silo -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center space-y-2">
              <div class="text-xs font-mono font-bold text-slate-300">FLOUR SILO 03</div>
              <div class="w-16 h-28 bg-slate-900 border border-slate-700 rounded-lg mx-auto relative overflow-hidden flex items-end">
                <div class="w-full bg-blue-500/60 transition-all duration-300 rounded-b-lg" [style.height.%]="factory.siloSystemState().flourSiloLevelPercent"></div>
                <span class="absolute inset-0 flex items-center justify-center text-xs font-mono font-bold text-slate-100">
                  {{ factory.siloSystemState().flourSiloLevelPercent }}%
                </span>
              </div>
              <div class="text-[10px] font-mono text-slate-400">Shipton Mill Cake Flour</div>
            </div>

            <!-- Sugar Silo -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-4 text-center space-y-2">
              <div class="text-xs font-mono font-bold text-slate-300">SUGAR HOPPER 01</div>
              <div class="w-16 h-28 bg-slate-900 border border-slate-700 rounded-lg mx-auto relative overflow-hidden flex items-end">
                <div class="w-full bg-amber-500/60 transition-all duration-300 rounded-b-lg" [style.height.%]="factory.siloSystemState().sugarSiloLevelPercent"></div>
                <span class="absolute inset-0 flex items-center justify-center text-xs font-mono font-bold text-slate-100">
                  {{ factory.siloSystemState().sugarSiloLevelPercent }}%
                </span>
              </div>
              <div class="text-[10px] font-mono text-slate-400">British Caster Sugar</div>
            </div>
          </div>

          <!-- Automated Dosing Live Meter -->
          <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <div class="flex justify-between items-center text-xs font-mono">
              <span class="text-slate-400">AUTOMATED DOSE TO M-04:</span>
              <span class="text-emerald-400 font-bold">
                {{ factory.siloSystemState().activeDosing ? 'FEEDING ACTIVE (2.8 kg/s)' : 'STANDBY' }}
              </span>
            </div>

            <div class="text-2xl font-mono font-bold text-slate-100 text-center py-1 tabular-nums">
              {{ factory.siloSystemState().actualDosedKg.toFixed(2) }} <span class="text-sm font-normal text-slate-500">/ {{ factory.siloSystemState().targetKg.toFixed(2) }} kg</span>
            </div>

            <button 
              (click)="factory.startSiloDosing()"
              [disabled]="factory.siloSystemState().activeDosing"
              class="w-full py-2.5 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-md">
              <mat-icon class="text-sm">play_arrow</mat-icon>
              <span>{{ factory.siloSystemState().activeDosing ? 'Dosing in Progress...' : 'Start Automated Flour Silo Dosing' }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class WeighingDosingComponent {
  readonly factory = inject(BakeOSFactoryService);
}
