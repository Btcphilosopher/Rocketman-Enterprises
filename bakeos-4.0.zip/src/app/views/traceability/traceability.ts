import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-traceability',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">LOT TRACEABILITY & DIGITAL THREAD</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-blue-500/10 text-blue-400 border border-blue-500/30">
              BIDIRECTIONAL GENEALOGY
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Trace from raw ingredient supplier lot to finished customer pallet, or reverse-audit from barcode to farm
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="directionMode.set('FORWARD')"
            class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
            [class.bg-amber-500]="directionMode() === 'FORWARD'"
            [class.text-slate-950]="directionMode() === 'FORWARD'"
            [class.font-bold]="directionMode() === 'FORWARD'"
            [class.bg-slate-900]="directionMode() !== 'FORWARD'"
            [class.text-slate-300]="directionMode() !== 'FORWARD'">
            Forward (Lot → Finished)
          </button>
          <button 
            (click)="directionMode.set('BACKWARD')"
            class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors"
            [class.bg-amber-500]="directionMode() === 'BACKWARD'"
            [class.text-slate-950]="directionMode() === 'BACKWARD'"
            [class.font-bold]="directionMode() === 'BACKWARD'"
            [class.bg-slate-900]="directionMode() !== 'BACKWARD'"
            [class.text-slate-300]="directionMode() !== 'BACKWARD'">
            Reverse (Carton → Ingredient Lots)
          </button>
        </div>
      </div>

      <!-- Search & Lot Selector Bar -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div class="flex items-center gap-2">
          <mat-icon class="text-slate-400 text-sm">search</mat-icon>
          <span class="text-xs font-mono text-slate-400">Quick Query:</span>
          <div class="flex items-center gap-1.5 overflow-x-auto">
            @for (lot of quickLots; track lot.code) {
              <button 
                (click)="selectedLotCode.set(lot.code)"
                [class.bg-amber-500]="selectedLotCode() === lot.code"
                [class.text-slate-950]="selectedLotCode() === lot.code"
                [class.font-bold]="selectedLotCode() === lot.code"
                [class.bg-slate-950]="selectedLotCode() !== lot.code"
                [class.text-slate-300]="selectedLotCode() !== lot.code"
                class="px-2.5 py-1 rounded-lg text-[11px] font-mono border border-slate-800 transition-colors">
                {{ lot.code }} ({{ lot.name }})
              </button>
            }
          </div>
        </div>

        <span class="text-xs font-mono text-emerald-400">Provenance Status: 100% Verified</span>
      </div>

      <!-- Digital Thread Visual Flow Map (Specification Section 73) -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <h2 class="font-brand font-bold text-base text-slate-100 flex items-center gap-2">
            <mat-icon class="text-amber-400">hub</mat-icon>
            <span>DIGITAL THREAD GENEALOGY GRAPH — {{ selectedLotCode() }}</span>
          </h2>
          <span class="text-xs font-mono text-slate-400">Chain Length: 6 Nodes</span>
        </div>

        <!-- Node Chain -->
        <div class="grid grid-cols-1 md:grid-cols-6 gap-3 select-none">
          <!-- Node 1: Raw Ingredient Lot -->
          <div class="p-4 rounded-xl bg-slate-950 border border-amber-500/40 space-y-2 text-xs">
            <div class="font-mono text-amber-400 font-bold text-[10px]">1. INGREDIENT LOT</div>
            <div class="font-bold text-slate-100 text-sm">Shipton Mill Flour</div>
            <div class="font-mono text-[11px] text-slate-300">LOT-F-28471</div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              Supplier: Shipton Mill Ltd<br/>
              Protein: 10.4% · Moist: 13.8%
            </div>
          </div>

          <!-- Node 2: Production Batch -->
          <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            <div class="font-mono text-blue-400 font-bold text-[10px]">2. PRODUCTION BATCH</div>
            <div class="font-bold text-slate-100 text-sm">BATCH-82041</div>
            <div class="font-mono text-[11px] text-slate-300">500 Victoria Sponges</div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              Order: ORD-820481<br/>
              Recipe: VS-001 REV 14
            </div>
          </div>

          <!-- Node 3: Process Machines -->
          <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            <div class="font-mono text-purple-400 font-bold text-[10px]">3. MACHINE ENGINE</div>
            <div class="font-bold text-slate-100 text-sm">Line 1 Assets</div>
            <div class="font-mono text-[11px] text-slate-300">M-04 → O-07 → R-07</div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              Oven: 180°C · 22:00 min<br/>
              Robotic Rosettes: 12 Piped
            </div>
          </div>

          <!-- Node 4: Quality Vision Scan -->
          <div class="p-4 rounded-xl bg-slate-950 border border-emerald-500/40 space-y-2 text-xs">
            <div class="font-mono text-emerald-400 font-bold text-[10px]">4. VISION QC PASS</div>
            <div class="font-bold text-slate-100 text-sm">Station V-01</div>
            <div class="font-mono text-[11px] text-emerald-300">CAKE-82041-342</div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              Weight: 450.4g (±15g Tol)<br/>
              Delta-E: 0.94 (Optimal)
            </div>
          </div>

          <!-- Node 5: Packaging & MAP Label -->
          <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            <div class="font-mono text-yellow-400 font-bold text-[10px]">5. CARTON & LABEL</div>
            <div class="font-bold text-slate-100 text-sm">Packer P-11</div>
            <div class="font-mono text-[11px] text-slate-300">PACK-82041-001</div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              Best Before: 24 SEP 2026<br/>
              Gas Flush: N2 98.5%
            </div>
          </div>

          <!-- Node 6: Customer Dispatch -->
          <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
            <div class="font-mono text-cyan-400 font-bold text-[10px]">6. WAREHOUSE & FEFO</div>
            <div class="font-bold text-slate-100 text-sm">Pallet #14</div>
            <div class="font-mono text-[11px] text-slate-300">Waitrose Delivery</div>
            <div class="text-[10px] text-slate-400 pt-1 border-t border-slate-800">
              Dock 02 · Temp: 14°C<br/>
              Dispatch: 22 SEP 06:00
            </div>
          </div>
        </div>

        <!-- Generated Production Label Preview (Specification Section 61) -->
        <div class="p-5 rounded-xl bg-slate-950 border border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4">
          <div class="space-y-1">
            <div class="text-xs font-mono text-slate-400 uppercase">Simulated Automated Production Label</div>
            <div class="font-brand font-bold text-base text-slate-100">THE NORTHSHIRE BAKERY · VICTORIA SPONGE</div>
            <div class="text-xs font-mono text-slate-300">
              LOT: VS-82041 · BEST BEFORE: 24 SEP 2026 · NET WT: 450g
            </div>
            <div class="text-[11px] text-red-300 font-mono">
              ALLERGEN DECLARATION: Contains wheat (gluten), free-range egg, cow's milk
            </div>
          </div>

          <div class="p-3 bg-white text-slate-950 rounded-lg text-center font-mono text-xs font-bold shrink-0">
            <div class="tracking-widest">||| | |||| ||| |||||</div>
            <div class="text-[10px] mt-1">5012345678901</div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class TraceabilityComponent {
  readonly factory = inject(BakeOSFactoryService);

  readonly directionMode = signal<'FORWARD' | 'BACKWARD'>('FORWARD');
  readonly selectedLotCode = signal<string>('LOT-F-28471');

  readonly quickLots = [
    { code: 'LOT-F-28471', name: 'Shipton Mill Flour' },
    { code: 'LOT-B-77401', name: 'West Country Butter' },
    { code: 'LOT-S-99120', name: 'British Caster Sugar' },
    { code: 'LOT-E-63029', name: 'Liquid Egg' },
    { code: 'BATCH-82041', name: 'Finished Cake Batch' }
  ];
}
