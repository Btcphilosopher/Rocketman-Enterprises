import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-machine-twins',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title & Machine Tabs -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">MACHINE DIGITAL TWINS</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30">
              PHYSICAL ASSET TELEMETRY
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Deterministic kinematics, thermal profiles, vibration spectrum, and overall equipment effectiveness (OEE)
          </p>
        </div>

        <!-- Machine Switcher Buttons -->
        <div class="flex items-center gap-1.5 overflow-x-auto bg-slate-900 p-1 rounded-xl border border-slate-800">
          @for (m of factory.machines(); track m.id) {
            <button 
              (click)="factory.selectMachine(m)"
              [class.bg-amber-500]="factory.selectedMachine().id === m.id"
              [class.text-slate-950]="factory.selectedMachine().id === m.id"
              [class.font-bold]="factory.selectedMachine().id === m.id"
              [class.text-slate-400]="factory.selectedMachine().id !== m.id"
              class="px-3 py-1.5 rounded-lg text-xs font-mono transition-colors hover:text-white whitespace-nowrap">
              {{ m.code }} ({{ m.name.split(' ')[0] }})
            </button>
          }
        </div>
      </div>

      <!-- Main Machine Twin Workspace: 2-Column Split -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        @let mach = factory.selectedMachine();

        <!-- Machine Kinematics & Interactive Cross-Section Canvas (8 Cols) -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5"
             [class.engineering-grid]="factory.viewMode() === 'engineering'">
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <div class="text-xs font-mono text-amber-400">{{ mach.code }} · {{ mach.department }}</div>
              <h2 class="font-brand font-bold text-xl text-slate-100 mt-0.5">{{ mach.name }}</h2>
            </div>
            
            <div class="flex items-center gap-2">
              <span class="px-2.5 py-1 rounded text-xs font-mono font-bold"
                [class.bg-emerald-950]="mach.status === 'RUNNING'"
                [class.text-emerald-400]="mach.status === 'RUNNING'"
                [class.border]="true"
                [class.border-emerald-800]="mach.status === 'RUNNING'"
                [class.bg-red-950]="mach.status === 'EMERGENCY_STOP'"
                [class.text-red-400]="mach.status === 'EMERGENCY_STOP'"
                [class.bg-slate-800]="mach.status !== 'RUNNING' && mach.status !== 'EMERGENCY_STOP'">
                {{ mach.status }}
              </span>

              <!-- Safety Interlock / E-Stop Toggle Button -->
              <button 
                (click)="factory.toggleSafetyInterlock(mach.code)"
                [title]="mach.safetyInterlockOk ? 'Simulate Guard Open / Trip Interlock' : 'Reset Safety Guard'"
                class="px-3 py-1 rounded text-xs font-mono transition-colors flex items-center gap-1"
                [class.bg-red-500]="!mach.safetyInterlockOk"
                [class.text-white]="!mach.safetyInterlockOk"
                [class.bg-slate-800]="mach.safetyInterlockOk"
                [class.text-slate-300]="mach.safetyInterlockOk">
                <mat-icon class="text-xs">{{ mach.safetyInterlockOk ? 'lock' : 'lock_open' }}</mat-icon>
                <span>{{ mach.safetyInterlockOk ? 'Trip Interlock' : 'Reset Safety' }}</span>
              </button>
            </div>
          </div>

          <!-- Machine-Specific Cross-Section Visualizations -->
          @if (mach.code === 'M-04') {
            <!-- Planetary Mixer M-04 Deep View -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center relative min-h-[340px]">
              <div class="text-xs font-mono text-slate-400 absolute top-4 left-4">
                CROSS-SECTION: PLANETARY HEAD & 120L JACKETED BOWL
              </div>

              <svg viewBox="0 0 400 300" class="w-80 h-64 select-none">
                <!-- Outer Casting Frame -->
                <rect x="80" y="20" width="240" height="50" rx="8" fill="#1e293b" stroke="#475569" stroke-width="2"/>
                <text x="200" y="50" font-size="12" font-family="JetBrains Mono" font-weight="bold" fill="#f8fafc" text-anchor="middle">
                  HEAVY GEAR DRIVE (184 RPM)
                </text>

                <!-- Bowl Jacket & Cavity -->
                <path d="M 70 80 L 70 230 Q 70 280 200 280 Q 330 280 330 230 L 330 80 Z" fill="#090d16" stroke="#94a3b8" stroke-width="3"/>
                <!-- Thermal cooling jacket lines -->
                <path d="M 60 90 L 60 230 Q 60 290 200 290 Q 340 290 340 230 L 340 90" fill="none" stroke="#3b82f6" stroke-width="2" stroke-dasharray="4 4"/>
                
                <!-- Cake Batter Filling -->
                <path d="M 74 150 Q 130 142 200 150 Q 270 158 326 150 L 326 230 Q 326 276 200 276 Q 74 276 74 230 Z" fill="#fef08a" opacity="0.95"/>

                <!-- Planetary Motion Kinematic Arm -->
                <g [style.transform]="'rotate(' + factory.mixerTwinState().planetaryDeg + 'deg)'" style="transform-origin: 200px 70px;">
                  <line x1="200" y1="50" x2="200" y2="100" stroke="#94a3b8" stroke-width="8"/>
                  <circle cx="240" cy="100" r="14" fill="#334155" stroke="#f59e0b" stroke-width="3"/>

                  <!-- Whisk Tool Spin -->
                  <g [style.transform]="'rotate(' + factory.mixerTwinState().rotationDeg + 'deg)'" style="transform-origin: 240px 100px;">
                    <ellipse cx="240" cy="180" rx="30" ry="70" fill="none" stroke="#f8fafc" stroke-width="3"/>
                    <ellipse cx="240" cy="180" rx="16" ry="70" fill="none" stroke="#e2e8f0" stroke-width="2.5"/>
                    <line x1="240" y1="100" x2="240" y2="250" stroke="#cbd5e1" stroke-width="4"/>
                  </g>
                </g>
              </svg>

              <!-- Live Tool Controls -->
              <div class="flex items-center gap-3 mt-4 text-xs font-mono">
                <span class="text-slate-400">Tool Attached:</span>
                <span class="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-amber-300 font-bold">
                  {{ factory.mixerTwinState().whiskTool }}
                </span>
                <span class="text-slate-500">·</span>
                <span class="text-slate-400">Hydration:</span>
                <span class="text-emerald-400 font-bold">78.5%</span>
              </div>
            </div>
          } @else if (mach.code === 'O-07') {
            <!-- Tunnel Oven O-07 Baking Curve & Thermal Profile -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 space-y-4">
              <div class="flex justify-between items-center text-xs font-mono text-slate-400">
                <span>TUNNEL OVEN O-07: LIVE BAKING CURVE vs TARGET SPEC</span>
                <span class="text-red-400">Length: 28 Metres · 3 Zones</span>
              </div>

              <!-- Baking Curve Chart SVG -->
              <svg viewBox="0 0 500 200" class="w-full h-52 select-none">
                <!-- Grid lines -->
                <line x1="40" y1="30" x2="480" y2="30" stroke="#1e293b" stroke-width="1"/>
                <line x1="40" y1="80" x2="480" y2="80" stroke="#1e293b" stroke-width="1"/>
                <line x1="40" y1="130" x2="480" y2="130" stroke="#1e293b" stroke-width="1"/>
                <line x1="40" y1="170" x2="480" y2="170" stroke="#334155" stroke-width="2"/>
                <line x1="40" y1="20" x2="40" y2="170" stroke="#334155" stroke-width="2"/>

                <!-- Y Axis Labels (°C) -->
                <text x="32" y="34" font-size="9" fill="#94a3b8" text-anchor="end" font-family="JetBrains Mono">180°</text>
                <text x="32" y="84" font-size="9" fill="#94a3b8" text-anchor="end" font-family="JetBrains Mono">120°</text>
                <text x="32" y="134" font-size="9" fill="#94a3b8" text-anchor="end" font-family="JetBrains Mono">60°</text>
                <text x="32" y="174" font-size="9" fill="#94a3b8" text-anchor="end" font-family="JetBrains Mono">20°</text>

                <!-- Target Baking Chamber Curve (Red dashed) -->
                <path d="M 40 30 L 180 30 L 320 38 L 480 50" fill="none" stroke="#ef4444" stroke-width="2.5" stroke-dasharray="6 4"/>

                <!-- Product Core Temperature Heat Rise Curve (Cyan) -->
                <path d="M 40 170 C 120 160, 220 100, 360 65 L 480 62" fill="none" stroke="#06b6d4" stroke-width="3"/>
                
                <!-- Probe Measurement Points -->
                <circle cx="40" cy="170" r="4" fill="#06b6d4"/>
                <circle cx="180" cy="120" r="4" fill="#06b6d4"/>
                <circle cx="320" cy="75" r="4" fill="#06b6d4"/>
                <circle cx="480" cy="62" r="6" fill="#10b981" stroke="#ffffff" stroke-width="2"/>

                <!-- Label for Core Kill Point -->
                <text x="475" y="48" font-size="10" font-family="JetBrains Mono" font-weight="bold" fill="#10b981" text-anchor="end">
                  Core 94.2°C (PASS)
                </text>
              </svg>

              <div class="flex items-center justify-between text-xs font-mono text-slate-400 pt-2 border-t border-slate-800">
                <span class="flex items-center gap-1.5"><span class="w-3 h-0.5 bg-red-500"></span> Target Chamber Temp (182°C / 176°C / 165°C)</span>
                <span class="flex items-center gap-1.5"><span class="w-3 h-0.5 bg-cyan-400"></span> Actual Product Core Temp Rise</span>
              </div>
            </div>
          } @else if (mach.code === 'R-07') {
            <!-- 6-Axis Robot R-07 Closed Loop Camera Workspace -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center">
              <div class="text-xs font-mono text-slate-400 mb-4 self-start">
                6-AXIS ARTICULATED ARM KINEMATICS & VISION OVERLAY
              </div>
              <div class="w-full max-w-md bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-3">
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-slate-400">X Position:</span>
                  <span class="text-slate-100 font-bold tabular-nums">{{ factory.roboticDecoratorState().x }} mm</span>
                </div>
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-slate-400">Y Position:</span>
                  <span class="text-slate-100 font-bold tabular-nums">{{ factory.roboticDecoratorState().y }} mm</span>
                </div>
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-slate-400">Z Position:</span>
                  <span class="text-slate-100 font-bold tabular-nums">{{ factory.roboticDecoratorState().z }} mm</span>
                </div>
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-slate-400">Linear Tool Speed:</span>
                  <span class="text-emerald-400 font-bold tabular-nums">{{ factory.roboticDecoratorState().speedMmS }} mm/s</span>
                </div>
                <div class="flex justify-between text-xs font-mono">
                  <span class="text-slate-400">Closed-Loop Vision Offset:</span>
                  <span class="text-blue-400 font-bold font-mono">dx: +0.12mm · dy: -0.08mm</span>
                </div>
              </div>
            </div>
          } @else {
            <!-- Generic Machine Telemetry Display -->
            <div class="bg-slate-950 border border-slate-800 rounded-xl p-6 flex flex-col items-center justify-center text-center py-16">
              <mat-icon class="text-5xl text-amber-400 mb-3">precision_manufacturing</mat-icon>
              <h3 class="font-brand font-bold text-lg text-slate-100">{{ mach.name }}</h3>
              <p class="text-xs text-slate-400 max-w-md mt-1">
                Active in continuous production line. Running at {{ mach.speedActual }} {{ mach.type === 'MIXER_PLANETARY' ? 'RPM' : 'units/min' }} with {{ mach.loadPercent }}% torque load.
              </p>
            </div>
          }

          <!-- Sensor IoT Telemetry Bar -->
          <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div class="text-[10px] text-slate-500 uppercase">Vibration (RMS)</div>
              <div class="text-base font-bold text-slate-100 mt-0.5 tabular-nums">{{ mach.vibrationMmS }} mm/s</div>
              <div class="text-[9px] text-emerald-400">ISO 10816 Zone A</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div class="text-[10px] text-slate-500 uppercase">Power Draw</div>
              <div class="text-base font-bold text-amber-400 mt-0.5 tabular-nums">{{ mach.powerKw }} kW</div>
              <div class="text-[9px] text-slate-400">415V 3-Phase 50Hz</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div class="text-[10px] text-slate-500 uppercase">Total Run Hours</div>
              <div class="text-base font-bold text-slate-100 mt-0.5 tabular-nums">{{ mach.runningHoursTotal }} hrs</div>
              <div class="text-[9px] text-slate-400">Since Commissioning</div>
            </div>
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
              <div class="text-[10px] text-slate-500 uppercase">Next Service In</div>
              <div class="text-base font-bold text-blue-400 mt-0.5 tabular-nums">{{ mach.hoursUntilMaintenance }} hrs</div>
              <div class="text-[9px] text-slate-400">Lubrication & Bearings</div>
            </div>
          </div>
        </div>

        <!-- Machine OEE & Diagnostic Sidebar (4 Cols) -->
        <div class="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4">
          <div class="space-y-4">
            <div class="border-b border-slate-800 pb-3">
              <div class="text-xs font-mono text-amber-400 uppercase">Overall Equipment Effectiveness</div>
              <div class="text-3xl font-mono font-bold text-emerald-400 mt-1 tabular-nums">{{ mach.oee.overall }}%</div>
              <div class="text-xs text-slate-400 mt-0.5">Industry 4.0 Standard: World-Class Benchmark</div>
            </div>

            <!-- OEE Breakdown Bars -->
            <div class="space-y-3 text-xs">
              <div>
                <div class="flex justify-between font-mono mb-1">
                  <span class="text-slate-300">Availability:</span>
                  <span class="font-bold text-slate-100">{{ mach.oee.availability }}%</span>
                </div>
                <div class="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div class="bg-emerald-500 h-full rounded-full" [style.width.%]="mach.oee.availability"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between font-mono mb-1">
                  <span class="text-slate-300">Performance:</span>
                  <span class="font-bold text-slate-100">{{ mach.oee.performance }}%</span>
                </div>
                <div class="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div class="bg-blue-500 h-full rounded-full" [style.width.%]="mach.oee.performance"></div>
                </div>
              </div>

              <div>
                <div class="flex justify-between font-mono mb-1">
                  <span class="text-slate-300">Quality:</span>
                  <span class="font-bold text-slate-100">{{ mach.oee.quality }}%</span>
                </div>
                <div class="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                  <div class="bg-amber-500 h-full rounded-full" [style.width.%]="mach.oee.quality"></div>
                </div>
              </div>
            </div>

            <!-- Hygiene & Sanitation State (BSI Food Machinery Standard) -->
            <div class="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
              <div class="flex items-center justify-between font-mono">
                <span class="text-slate-400 font-bold">HYGIENE STATUS:</span>
                <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {{ mach.hygieneStatus }}
                </span>
              </div>
              <p class="text-slate-400 text-[11px] leading-relaxed">
                CIP automatic caustic wash & rinse cycle logged at 06:15. Microbiological swab cleared.
              </p>
            </div>
          </div>

          <div class="pt-3 border-t border-slate-800 space-y-2">
            <button 
              (click)="factory.setTab('maintenance')"
              class="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors flex items-center justify-center gap-1.5">
              <mat-icon class="text-sm">build</mat-icon>
              <span>View Maintenance Work Orders</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MachineTwinsComponent {
  readonly factory = inject(BakeOSFactoryService);
}
