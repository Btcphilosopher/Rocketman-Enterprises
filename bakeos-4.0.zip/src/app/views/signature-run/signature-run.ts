import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';
import { BatchStage } from '../../models/bakery.models';

interface StageDefinition {
  id: BatchStage;
  label: string;
  stepNumber: string;
  machineCode: string;
  durationEst: string;
  icon: string;
  keyMetric: string;
  tolerance: string;
  description: string;
}

@Component({
  selector: 'app-signature-run',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title & Live Batch Header Banner -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">SIGNATURE RUN: VICTORIA SPONGE V14</h1>
            <span class="px-2.5 py-0.5 rounded text-[11px] font-mono font-bold bg-amber-500 text-slate-950">
              500 CAKES IN FLIGHT
            </span>
          </div>
          <div class="text-xs text-slate-400 mt-1 flex items-center gap-3 font-mono">
            <span>BATCH: BATCH-82041</span>
            <span>·</span>
            <span>CUSTOMER: Waitrose & Partners / Marks & Spencer</span>
            <span>·</span>
            <span>RECIPE: VS-001 REV 14</span>
            <span>·</span>
            <span>EST. FINISH: 10:45</span>
          </div>
        </div>

        <!-- Master Batch Progress & Stage Jumper -->
        <div class="flex items-center gap-4 bg-slate-900/90 border border-slate-800 px-5 py-3 rounded-2xl">
          <div class="text-right">
            <div class="text-[10px] text-slate-400 font-mono uppercase">Batch Completion</div>
            <div class="text-xl font-mono font-bold text-amber-400 tabular-nums">
              {{ activeBatch().actualProducedQuantity }} / {{ activeBatch().targetQuantity }} pcs
            </div>
          </div>
          <div class="w-32 bg-slate-950 rounded-full h-3 overflow-hidden border border-slate-800">
            <div class="bg-amber-500 h-full rounded-full transition-all duration-500" [style.width.%]="activeBatch().progressPercent"></div>
          </div>
          <div class="text-xs font-mono font-bold text-slate-200">
            {{ activeBatch().progressPercent }}%
          </div>
        </div>
      </div>

      <!-- Linear Manufacturing Digital Thread Stepper -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-xl overflow-x-auto">
        <div class="text-xs font-mono text-slate-400 mb-3 uppercase tracking-wider flex items-center justify-between">
          <span>End-to-End Production Chain (Click any stage to inspect machine instructions)</span>
          <span class="text-amber-400">Current Active: {{ activeBatch().stage }}</span>
        </div>

        <div class="flex items-center gap-2 min-w-[1100px] select-none">
          @for (stg of productionStages; track stg.id; let idx = $index) {
            <button 
              type="button"
              (click)="selectedStage.set(stg.id)"
              class="flex-1 text-left p-3 rounded-xl border transition-all cursor-pointer relative"
              [class.bg-amber-500/15]="selectedStage() === stg.id"
              [class.border-amber-500]="selectedStage() === stg.id"
              [class.text-amber-300]="selectedStage() === stg.id"
              [class.bg-slate-950]="selectedStage() !== stg.id"
              [class.border-slate-800]="selectedStage() !== stg.id"
              [class.text-slate-400]="selectedStage() !== stg.id">
              
              <!-- Indicator top badge -->
              <div class="flex items-center justify-between text-[10px] font-mono mb-1">
                <span class="font-bold">{{ stg.stepNumber }}</span>
                <span class="px-1.5 py-0.2 rounded text-[9px]"
                  [class.bg-emerald-950]="isStagePassed(stg.id)"
                  [class.text-emerald-400]="isStagePassed(stg.id)"
                  [class.bg-amber-500]="activeBatch().stage === stg.id"
                  [class.text-slate-950]="activeBatch().stage === stg.id"
                  [class.bg-slate-800]="!isStagePassed(stg.id) && activeBatch().stage !== stg.id">
                  {{ activeBatch().stage === stg.id ? 'RUNNING' : (isStagePassed(stg.id) ? 'DONE' : 'QUEUED') }}
                </span>
              </div>

              <div class="font-bold text-xs text-slate-200 truncate">{{ stg.label }}</div>
              <div class="text-[10px] font-mono text-slate-400 mt-0.5">{{ stg.machineCode }}</div>
            </button>

            @if (idx < productionStages.length - 1) {
              <mat-icon class="text-slate-700 text-xs shrink-0">chevron_right</mat-icon>
            }
          }
        </div>
      </div>

      <!-- Stage Deep Dive & Live Machine Interaction Workspace -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Main Stage Workspace (8 Cols) -->
        <div class="lg:col-span-8 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
          @let currentStg = getCurrentStageDef();
          
          <div class="flex items-center justify-between border-b border-slate-800 pb-4">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
                <mat-icon class="text-2xl">{{ currentStg.icon }}</mat-icon>
              </div>
              <div>
                <div class="text-xs font-mono text-amber-400">{{ currentStg.stepNumber }} · {{ currentStg.machineCode }}</div>
                <h2 class="font-brand font-bold text-xl text-slate-100">{{ currentStg.label }}</h2>
              </div>
            </div>

            <!-- Action Button to Advance / Re-run stage -->
            <button 
              (click)="advanceToNextStage(currentStg.id)"
              class="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition-colors flex items-center gap-1.5 shadow-md">
              <mat-icon class="text-sm">fast_forward</mat-icon>
              <span>Advance Stage to Next Step</span>
            </button>
          </div>

          <!-- Dynamic Stage Interactive Views -->
          @switch (currentStg.id) {
            @case ('MIXING') {
              <!-- Planetary Mixer M-04 Live Visualizer -->
              <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div class="md:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center justify-center relative min-h-[260px]">
                  <div class="text-xs font-mono text-slate-400 absolute top-3 left-3">PLANETARY MIXER M-04 CROSS-SECTION</div>
                  
                  <!-- Animated Planetary Mixing SVG Cross-Section -->
                  <svg viewBox="0 0 280 220" class="w-56 h-48 select-none mt-4">
                    <!-- Machine Cast Iron Frame -->
                    <rect x="60" y="10" width="160" height="35" rx="6" fill="#1e293b" stroke="#475569" stroke-width="2"/>
                    <text x="140" y="32" font-size="10" font-family="JetBrains Mono" fill="#94a3b8" text-anchor="middle">MOTOR & GEARBOX 14kW</text>
                    
                    <!-- Stainless Steel Bowl (120 Litres) -->
                    <path d="M 50 60 L 50 160 Q 50 200 140 200 Q 230 200 230 160 L 230 60 Z" fill="#0f172a" stroke="#94a3b8" stroke-width="2"/>
                    
                    <!-- Cake Batter Emulsion Simulation -->
                    <path d="M 54 110 Q 95 105 140 110 Q 185 115 226 110 L 226 160 Q 226 196 140 196 Q 54 196 54 160 Z" fill="#fef08a" opacity="0.9"/>
                    
                    <!-- Planetary Whisk Rotating Mechanical Assembly -->
                    <g [style.transform]="'rotate(' + factory.mixerTwinState().planetaryDeg + 'deg)'" style="transform-origin: 140px 60px;">
                      <!-- Central Drive Shaft -->
                      <line x1="140" y1="45" x2="140" y2="75" stroke="#cbd5e1" stroke-width="6"/>
                      <!-- Offset Planetary Head -->
                      <circle cx="165" cy="80" r="10" fill="#334155" stroke="#f59e0b" stroke-width="2"/>
                      
                      <!-- Whisk Wires rotating around offset axis -->
                      <g [style.transform]="'rotate(' + factory.mixerTwinState().rotationDeg + 'deg)'" style="transform-origin: 165px 80px;">
                        <ellipse cx="165" cy="130" rx="20" ry="45" fill="none" stroke="#e2e8f0" stroke-width="2.5"/>
                        <ellipse cx="165" cy="130" rx="10" ry="45" fill="none" stroke="#e2e8f0" stroke-width="2"/>
                        <line x1="165" y1="80" x2="165" y2="175" stroke="#cbd5e1" stroke-width="3"/>
                      </g>
                    </g>
                  </svg>
                </div>

                <div class="md:col-span-5 space-y-3">
                  <div class="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs">
                    <div class="font-mono text-amber-400 font-bold">EXECUTING PROGRAMME: VS-MIX-01</div>
                    <div class="flex justify-between text-slate-300">
                      <span>Current Tool:</span>
                      <span class="font-mono font-bold text-slate-100">Stainless Balloon Whisk</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                      <span>Tool Speed:</span>
                      <span class="font-mono font-bold text-emerald-400 tabular-nums">184 RPM (Nominal)</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                      <span>Drive Torque:</span>
                      <span class="font-mono font-bold text-amber-400 tabular-nums">{{ factory.mixerTwinState().torqueNm }} Nm</span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                      <span>Batter Temperature:</span>
                      <span class="font-mono font-bold text-slate-100 tabular-nums">19.4°C</span>
                    </div>
                  </div>

                  <div class="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs space-y-1">
                    <div class="font-mono text-slate-400 font-bold">STAGE 2 / 3: EGG ADDITION</div>
                    <p class="text-slate-300 text-[11px] leading-relaxed">
                      Liquid whole egg dosed at 0.42 kg/s. Emulsion stability coefficient: 0.94 (Optimal).
                    </p>
                  </div>
                </div>
              </div>
            }

            @case ('BAKING') {
              <!-- Tunnel Oven O-07 Live Cutaway -->
              <div class="space-y-4">
                <div class="bg-slate-950 border border-slate-800 rounded-xl p-4">
                  <div class="flex justify-between items-center text-xs font-mono text-slate-400 mb-2">
                    <span>3-ZONE CONVECTION TUNNEL OVEN O-07</span>
                    <span class="text-red-400">Total Dwell: 22:00 MIN</span>
                  </div>

                  <!-- 3 Thermal Zones Visualization -->
                  <div class="grid grid-cols-3 gap-3 text-xs">
                    <div class="p-3 rounded-lg bg-red-950/40 border border-red-800/80">
                      <div class="text-red-400 font-mono font-bold">ZONE 1: RISE</div>
                      <div class="text-xl font-mono font-bold text-slate-100 mt-1">182.4°C</div>
                      <div class="text-[10px] text-slate-400 mt-0.5">Top: 70% · Bottom: 80%</div>
                      <div class="text-[10px] text-red-300 mt-1">Expansion & Aeration</div>
                    </div>
                    <div class="p-3 rounded-lg bg-amber-950/40 border border-amber-800/80">
                      <div class="text-amber-400 font-mono font-bold">ZONE 2: SET</div>
                      <div class="text-xl font-mono font-bold text-slate-100 mt-1">176.1°C</div>
                      <div class="text-[10px] text-slate-400 mt-0.5">Top: 65% · Bottom: 65%</div>
                      <div class="text-[10px] text-amber-300 mt-1">Crumb Gelatinisation</div>
                    </div>
                    <div class="p-3 rounded-lg bg-yellow-950/40 border border-yellow-800/80">
                      <div class="text-yellow-400 font-mono font-bold">ZONE 3: CRUST</div>
                      <div class="text-xl font-mono font-bold text-slate-100 mt-1">165.2°C</div>
                      <div class="text-[10px] text-slate-400 mt-0.5">Top: 60% · Bottom: 50%</div>
                      <div class="text-[10px] text-yellow-300 mt-1">Golden Crusting & Drying</div>
                    </div>
                  </div>

                  <!-- Product Core Temp Probe Telemetry (CCP-02) -->
                  <div class="mt-3 p-3 bg-slate-900 border border-slate-800 rounded-lg flex items-center justify-between text-xs">
                    <div class="flex items-center gap-2">
                      <mat-icon class="text-emerald-400">verified</mat-icon>
                      <span class="font-bold text-slate-100">CCP-02 Kill Step: Product Core Exit Temperature</span>
                    </div>
                    <div class="font-mono font-bold text-emerald-400 text-sm">94.2°C (Min 92.0°C Required) — PASS</div>
                  </div>
                </div>
              </div>
            }

            @case ('ROBOTIC_DECORATION') {
              <!-- 6-Axis Robot R-07 Closed-Loop Workspace -->
              <div class="grid grid-cols-1 md:grid-cols-12 gap-4">
                <div class="md:col-span-7 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col items-center justify-center relative min-h-[260px]">
                  <div class="text-xs font-mono text-slate-400 absolute top-3 left-3">ROBOT R-07 REAL-TIME TOOL COORDINATES</div>

                  <!-- Robotic Arm and Cake Turntable SVG -->
                  <svg viewBox="0 0 280 220" class="w-56 h-48 select-none mt-4">
                    <!-- Rotating Turntable -->
                    <ellipse cx="140" cy="170" rx="90" ry="30" fill="#1e293b" stroke="#64748b" stroke-width="2"/>
                    <!-- Victoria Sponge Base with Piped Rosettes -->
                    <ellipse cx="140" cy="160" rx="65" ry="22" fill="#fef08a" stroke="#d97706" stroke-width="2"/>
                    <ellipse cx="140" cy="148" rx="65" ry="22" fill="#fef3c7" stroke="#b45309" stroke-width="1.5"/>
                    
                    <!-- 12 Piped Buttercream Rosettes -->
                    @for (r of [0, 30, 60, 90, 120, 150, 180, 210, 240, 270, 300, 330]; track r) {
                      <circle 
                        [attr.cx]="140 + 48 * Math.cos(r * Math.PI / 180)" 
                        [attr.cy]="148 + 16 * Math.sin(r * Math.PI / 180)" 
                        r="4" 
                        fill="#fffbeb" 
                        stroke="#d97706" 
                        stroke-width="1"/>
                    }

                    <!-- Robotic Kinematic Linkage -->
                    <circle cx="230" cy="40" r="12" fill="#475569" stroke="#94a3b8" stroke-width="2"/>
                    <line x1="230" y1="40" [attr.x2]="factory.roboticDecoratorState().x + 20" [attr.y2]="70" stroke="#cbd5e1" stroke-width="6"/>
                    <circle [attr.cx]="factory.roboticDecoratorState().x + 20" cy="70" r="8" fill="#334155" stroke="#f59e0b" stroke-width="2"/>
                    <line [attr.x1]="factory.roboticDecoratorState().x + 20" y1="70" [attr.x2]="factory.roboticDecoratorState().x" [attr.y2]="130" stroke="#94a3b8" stroke-width="4"/>
                    <!-- Piping Nozzle Tip -->
                    <polygon [attr.points]="(factory.roboticDecoratorState().x - 4) + ',130 ' + (factory.roboticDecoratorState().x + 4) + ',130 ' + factory.roboticDecoratorState().x + ',144'" fill="#fbbf24"/>
                    
                    <!-- Vision Alignment Crosshair -->
                    <circle [attr.cx]="factory.roboticDecoratorState().x" cy="144" r="14" fill="none" stroke="#10b981" stroke-width="1.5" stroke-dasharray="3 3"/>
                  </svg>
                </div>

                <div class="md:col-span-5 space-y-3">
                  <div class="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-2 text-xs">
                    <div class="font-mono text-purple-400 font-bold">CLOSED-LOOP VISION CORRECTION</div>
                    <div class="flex justify-between text-slate-300">
                      <span>Tool X/Y/Z:</span>
                      <span class="font-mono font-bold text-slate-100 tabular-nums">
                        {{ factory.roboticDecoratorState().x }} / {{ factory.roboticDecoratorState().y }} / {{ factory.roboticDecoratorState().z }} mm
                      </span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                      <span>Nozzle Pressure:</span>
                      <span class="font-mono font-bold text-emerald-400 tabular-nums">
                        {{ factory.roboticDecoratorState().pressureBar }} bar
                      </span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                      <span>Vision Offset (dx/dy):</span>
                      <span class="font-mono font-bold text-blue-400 tabular-nums">
                        +0.12 mm / -0.08 mm
                      </span>
                    </div>
                    <div class="flex justify-between text-slate-300">
                      <span>Piping Pattern:</span>
                      <span class="font-mono font-bold text-amber-400">12 Classical Rosettes</span>
                    </div>
                  </div>

                  <div class="p-3 bg-slate-950 border border-slate-800 rounded-xl text-xs space-y-1">
                    <div class="font-mono text-slate-400 font-bold">QUALITY ALIGNMENT SCORE</div>
                    <div class="text-xl font-mono font-bold text-emerald-400">99.2% Nominal</div>
                    <p class="text-slate-400 text-[11px]">Camera detects zero icing splatter or edge deformation.</p>
                  </div>
                </div>
              </div>
            }

            @default {
              <!-- General Process Details Container -->
              <div class="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3">
                <div class="text-xs font-mono text-amber-400 font-bold">PROCESS SPECIFICATION & TOLERANCES</div>
                <p class="text-slate-300 text-sm leading-relaxed">{{ currentStg.description }}</p>
                <div class="grid grid-cols-2 gap-3 pt-3 border-t border-slate-800 text-xs">
                  <div>
                    <span class="text-slate-400">Key Target Parameter:</span>
                    <div class="font-mono font-bold text-slate-100 mt-0.5">{{ currentStg.keyMetric }}</div>
                  </div>
                  <div>
                    <span class="text-slate-400">Engineering Tolerance:</span>
                    <div class="font-mono font-bold text-emerald-400 mt-0.5">{{ currentStg.tolerance }}</div>
                  </div>
                </div>
              </div>
            }
          }
        </div>

        <!-- Recipe & Lot Provenance Panel (4 Cols) -->
        <div class="lg:col-span-4 bg-slate-900/80 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4">
          <div>
            <div class="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <span class="text-xs font-mono text-amber-400">BATCH LOT ALLOCATION</span>
              <span class="text-[10px] font-mono text-slate-400">7 LOTS VERIFIED</span>
            </div>

            <!-- Product Showcase Card -->
            <div class="relative rounded-xl overflow-hidden border border-slate-800 mb-4 group">
              <img 
                src="/assets/images/victoria_sponge_spec_1791368023892.jpg" 
                alt="Victoria Sponge Specification"
                referrerpolicy="no-referrer"
                class="w-full h-36 object-cover object-center" />
              <div class="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent flex items-end p-3">
                <div>
                  <div class="text-xs font-bold text-slate-100">The Northshire Heritage Victoria Sponge</div>
                  <div class="text-[10px] text-amber-300 font-mono">VS-001 · 450g Net Weight</div>
                </div>
              </div>
            </div>

            <!-- Allocated Lots List -->
            <div class="space-y-1.5 max-h-[220px] overflow-y-auto pr-1">
              @for (lot of activeBatch().allocatedLots; track lot.lotNumber) {
                <div class="p-2 rounded bg-slate-950 border border-slate-800/80 flex items-center justify-between text-[11px]">
                  <div class="space-y-0.5">
                    <div class="font-semibold text-slate-200 truncate max-w-[150px]">{{ lot.ingredientName }}</div>
                    <div class="font-mono text-[10px] text-slate-400">{{ lot.lotNumber }}</div>
                  </div>
                  <div class="text-right font-mono">
                    <div class="text-slate-100 font-bold">{{ lot.dispensedWeightKg }} kg</div>
                    <div class="text-[9px] text-emerald-400">✓ In Tol</div>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Unit Cost & Yield Summary -->
          <div class="pt-3 border-t border-slate-800 space-y-1.5 text-xs">
            <div class="flex justify-between text-slate-400">
              <span>Unit Manufacturing Cost:</span>
              <span class="font-mono font-bold text-slate-200">£11.02 / cake</span>
            </div>
            <div class="flex justify-between text-slate-400">
              <span>Target Batch Gross Value:</span>
              <span class="font-mono font-bold text-emerald-400">£9,250.00</span>
            </div>
            <button 
              (click)="factory.setTab('recipes')"
              class="w-full py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs transition-colors flex items-center justify-center gap-1">
              <mat-icon class="text-sm">menu_book</mat-icon>
              <span>View Full Recipe Specification</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SignatureRunComponent {
  readonly factory = inject(BakeOSFactoryService);
  readonly Math = Math;

  readonly productionStages: StageDefinition[] = [
    { id: 'INGREDIENT_DISPENSE', label: '1. Dispense & Weigh', stepNumber: 'STEP 01', machineCode: 'SILO-03 & SCALE-W01', durationEst: '08:00', icon: 'scale', keyMetric: '56.250 kg Butter/Flour/Sugar/Egg', tolerance: '±0.020 kg', description: 'Automated pneumatic silo metering and manual micro-balance dosing.' },
    { id: 'MIXING', label: '2. Planetary Mixing', stepNumber: 'STEP 02', machineCode: 'MIXER M-04', durationEst: '06:45', icon: 'sync', keyMetric: '184 RPM · 19.4°C', tolerance: '±1.0°C Batter Temp', description: '3-stage creaming, emulsification, and low-shear folding.' },
    { id: 'DEPOSITING', label: '3. Volumetric Forming', stepNumber: 'STEP 03', machineCode: 'DEPOSITOR D-02', durationEst: '04:10', icon: 'view_agenda', keyMetric: '225g per sandwich tier', tolerance: '±3.0g deposit', description: 'Continuous volumetric piston deposit into 200mm tins.' },
    { id: 'BAKING', label: '4. Tunnel Oven Hall', stepNumber: 'STEP 04', machineCode: 'OVEN O-07', durationEst: '22:00', icon: 'local_fire_department', keyMetric: '182°C / 176°C / 165°C', tolerance: '≥ 92.0°C Core Temp', description: '3-zone thermal rise, crumb setting and crust coloration.' },
    { id: 'COOLING', label: '5. Rapid Cooling Tunnel', stepNumber: 'STEP 05', machineCode: 'COOLER C-02', durationEst: '38:00', icon: 'ac_unit', keyMetric: '19.5°C Exit Temp', tolerance: '≤ 20.0°C Core', description: 'HEPA laminar airflow to reach decoration readiness.' },
    { id: 'ROBOTIC_DECORATION', label: '6. Robotic Decorating', stepNumber: 'STEP 06', machineCode: 'ROBOT R-07', durationEst: '14:00', icon: 'precision_manufacturing', keyMetric: '12 Rosettes + Compote', tolerance: '±0.2mm offset', description: '6-axis closed loop vision piping and raspberry compote injection.' },
    { id: 'VISION_QC', label: '7. Vision QC Station', stepNumber: 'STEP 07', machineCode: 'INSPECTOR V-01', durationEst: '02:00', icon: 'camera', keyMetric: '450g Net · 110mm H', tolerance: '±15g / ±4mm', description: 'Dual camera 3D profile laser scan & browning Delta-E.' },
    { id: 'PACKAGING', label: '8. Automated Packing', stepNumber: 'STEP 08', machineCode: 'PACKER P-11', durationEst: '05:00', icon: 'inventory_2', keyMetric: 'Carton of 6 / Pallet', tolerance: '100% Barcode Pass', description: 'MAP gas flushed cartons and FEFO pallet allocation.' }
  ];

  readonly selectedStage = signal<BatchStage>('ROBOTIC_DECORATION');

  readonly activeBatch = this.factory.activeBatch;

  getCurrentStageDef(): StageDefinition {
    return this.productionStages.find(s => s.id === this.selectedStage()) || this.productionStages[1];
  }

  isStagePassed(stageId: BatchStage): boolean {
    const stageOrder: BatchStage[] = ['QUEUED', 'INGREDIENT_DISPENSE', 'MIXING', 'DEPOSITING', 'BAKING', 'COOLING', 'FILLING_ICING', 'ROBOTIC_DECORATION', 'VISION_QC', 'PACKAGING', 'PALLETIZED', 'DISPATCHED'];
    const currentIdx = stageOrder.indexOf(this.activeBatch().stage);
    const checkIdx = stageOrder.indexOf(stageId);
    return currentIdx > checkIdx;
  }

  advanceToNextStage(currentStage: BatchStage) {
    const stageOrder: BatchStage[] = ['INGREDIENT_DISPENSE', 'MIXING', 'DEPOSITING', 'BAKING', 'COOLING', 'ROBOTIC_DECORATION', 'VISION_QC', 'PACKAGING'];
    const currentIdx = stageOrder.indexOf(currentStage);
    if (currentIdx < stageOrder.length - 1) {
      const nextStage = stageOrder[currentIdx + 1];
      this.selectedStage.set(nextStage);
      this.factory.advanceBatchStage(this.activeBatch().id, nextStage);
    }
  }
}
