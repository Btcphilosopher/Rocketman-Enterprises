import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';
import { Recipe } from '../../models/bakery.models';

@Component({
  selector: 'app-recipe-studio',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Top Title & Filter Bar -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">BAKEOS RECIPE & PROCESS STUDIO</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              EXECUTABLE MANUFACTURING FORMULAS
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Controlled British Bakery Standards · Versioned engineering process sheets with automated line compiling
          </p>
        </div>

        <!-- Recipe Category Tabs -->
        <div class="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          @for (cat of categories; track cat) {
            <button 
              (click)="selectedCategory.set(cat)"
              [class.bg-amber-500]="selectedCategory() === cat"
              [class.text-slate-950]="selectedCategory() === cat"
              [class.font-bold]="selectedCategory() === cat"
              [class.text-slate-400]="selectedCategory() !== cat"
              class="px-3 py-1.5 rounded-lg transition-colors hover:text-white font-medium">
              {{ cat }}
            </button>
          }
        </div>
      </div>

      <!-- Main Recipe Studio 2-Column Split: Catalog List & Master Recipe Sheet -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Recipe Catalog Grid (4 Cols) -->
        <div class="lg:col-span-4 space-y-3">
          <div class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">
            Formulation Catalog ({{ filteredRecipes().length }} Formulas)
          </div>

          <div class="space-y-3">
            @for (rec of filteredRecipes(); track rec.id) {
              <button 
                type="button"
                (click)="factory.selectRecipe(rec)"
                class="w-full text-left p-3.5 rounded-2xl border transition-all cursor-pointer flex gap-3.5 group"
                [class.bg-slate-900]="factory.selectedRecipe().id === rec.id"
                [class.border-amber-500]="factory.selectedRecipe().id === rec.id"
                [class.shadow-lg]="factory.selectedRecipe().id === rec.id"
                [class.bg-slate-950]="factory.selectedRecipe().id !== rec.id"
                [class.border-slate-800]="factory.selectedRecipe().id !== rec.id">
                
                <img 
                  [src]="rec.imageUrl" 
                  [alt]="rec.name"
                  referrerpolicy="no-referrer"
                  class="w-20 h-20 rounded-xl object-cover object-center shrink-0 border border-slate-800 group-hover:border-slate-600 transition-colors" />

                <div class="flex-1 min-w-0 space-y-1">
                  <div class="flex items-center justify-between">
                    <span class="font-mono text-[10px] text-amber-400 font-bold">{{ rec.recipeCode }} V{{ rec.version }}</span>
                    <span class="text-[9px] font-mono px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 font-bold">
                      {{ rec.status }}
                    </span>
                  </div>
                  <h3 class="font-bold text-xs text-slate-100 truncate group-hover:text-amber-300 transition-colors">
                    {{ rec.name }}
                  </h3>
                  <div class="text-[11px] text-slate-400 font-mono">
                    Batch: {{ rec.targetBatchYieldCount }} pcs · {{ rec.unitWeightGrams }}g
                  </div>
                  <div class="text-[10px] text-slate-500 flex items-center gap-2">
                    <span>Cost: £{{ rec.costing.totalUnitCostGbp.toFixed(2) }}</span>
                    <span>·</span>
                    <span>Retail: £{{ rec.costing.targetRetailGbp.toFixed(2) }}</span>
                  </div>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Master Recipe Process Document (8 Cols) -->
        <div class="lg:col-span-8 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6">
          @let rec = factory.selectedRecipe();

          <!-- Recipe Header Banner -->
          <div class="flex flex-col md:flex-row md:items-start justify-between gap-4 border-b border-slate-800 pb-5">
            <div class="flex gap-4">
              <img 
                [src]="rec.imageUrl" 
                [alt]="rec.name"
                referrerpolicy="no-referrer"
                class="w-28 h-28 rounded-2xl object-cover object-center border border-slate-700 shrink-0 shadow-md" />
              <div>
                <div class="flex items-center gap-2 font-mono text-xs">
                  <span class="text-amber-400 font-bold">{{ rec.recipeCode }}</span>
                  <span class="text-slate-500">·</span>
                  <span class="text-slate-300">REVISION {{ rec.version }}</span>
                  <span class="text-slate-500">·</span>
                  <span class="px-2 py-0.2 rounded text-[10px] bg-emerald-950 text-emerald-400 font-bold border border-emerald-800/60">
                    {{ rec.status }}
                  </span>
                </div>
                <h2 class="font-brand font-bold text-2xl text-slate-100 mt-1">{{ rec.name }}</h2>
                <p class="text-xs text-slate-400 mt-1 max-w-xl leading-relaxed">{{ rec.description }}</p>
                <div class="text-[11px] text-slate-500 font-mono mt-2">
                  Approved by: {{ rec.approvedBy }} ({{ rec.approvalDate }})
                </div>
              </div>
            </div>

            <!-- Major Action: Compile & Run in Factory -->
            <div class="flex flex-col gap-2 shrink-0">
              <button 
                (click)="factory.runRecipeInFactory(rec)"
                class="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-xl transition-colors flex items-center gap-2 shadow-lg">
                <mat-icon class="text-base">precision_manufacturing</mat-icon>
                <span>RUN THIS RECIPE (500 PCS)</span>
              </button>
              <button 
                (click)="cloneToTestKitchen(rec)"
                class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded-xl transition-colors flex items-center gap-2">
                <mat-icon class="text-sm">science</mat-icon>
                <span>Clone to Test Kitchen</span>
              </button>
            </div>
          </div>

          <!-- Section 1: Baker's Percentages & Batch Dosing Table -->
          <div>
            <div class="flex items-center justify-between mb-3">
              <h3 class="font-brand font-bold text-sm text-slate-200 uppercase tracking-wide flex items-center gap-2">
                <mat-icon class="text-amber-400 text-base">scale</mat-icon>
                <span>Baker's Percentage Formula & Dosing Allocation (Batch Yield: {{ rec.targetBatchYieldCount }} units)</span>
              </h3>
              <span class="text-[11px] font-mono text-slate-400">Total Flour Base: 100.0%</span>
            </div>

            <div class="overflow-x-auto bg-slate-950 rounded-xl border border-slate-800">
              <table class="w-full text-left text-xs">
                <thead class="bg-slate-900 text-slate-400 font-mono border-b border-slate-800">
                  <tr>
                    <th class="py-2.5 px-3">Ingredient</th>
                    <th class="py-2.5 px-3 text-right">Baker's %</th>
                    <th class="py-2.5 px-3 text-right">Batch Weight (kg)</th>
                    <th class="py-2.5 px-3">Dosing Method</th>
                    <th class="py-2.5 px-3 text-right">Tolerance</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60 font-medium">
                  @for (ing of rec.ingredients; track ing.ingredientId) {
                    <tr class="hover:bg-slate-900/40 transition-colors">
                      <td class="py-2.5 px-3 font-semibold text-slate-200">{{ ing.name }}</td>
                      <td class="py-2.5 px-3 text-right font-mono text-amber-400">{{ ing.bakersPercentage.toFixed(1) }}%</td>
                      <td class="py-2.5 px-3 text-right font-mono text-slate-100 font-bold">{{ ing.batchWeightKg.toFixed(2) }} kg</td>
                      <td class="py-2.5 px-3 font-mono">
                        <span class="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                          {{ ing.dosingMethod }}
                        </span>
                      </td>
                      <td class="py-2.5 px-3 text-right font-mono text-emerald-400">±{{ ing.toleranceKg.toFixed(3) }} kg</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>

          <!-- Section 2: Executable Machine Programmes (Mixing, Baking, Cooling, Decoration) -->
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <!-- Mixing Programme Card -->
            <div class="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <span class="text-xs font-mono font-bold text-amber-400">1. MIXING PROGRAMME</span>
                <span class="text-[11px] font-mono text-slate-400">{{ rec.mixingProgramme.totalDurationSec }}s Total</span>
              </div>
              <div class="space-y-2">
                @for (step of rec.mixingProgramme.steps; track step.stepNumber) {
                  <div class="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                    <div class="flex justify-between font-mono">
                      <span class="font-bold text-slate-200">{{ step.name }}</span>
                      <span class="text-amber-400">{{ step.speedRpm }} RPM ({{ step.durationSeconds }}s)</span>
                    </div>
                    <p class="text-slate-400 text-[11px]">{{ step.description }}</p>
                    <div class="text-[10px] font-mono text-slate-500">Tool: {{ step.tool }} · Target Temp: {{ step.targetTempC }}°C</div>
                  </div>
                }
              </div>
            </div>

            <!-- Baking & Thermal Programme Card -->
            <div class="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <span class="text-xs font-mono font-bold text-red-400">2. BAKING & THERMAL CURVE</span>
                <span class="text-[11px] font-mono text-slate-400">{{ rec.bakingProgramme.bakeTimeMinutes }}:00 Min</span>
              </div>
              <div class="space-y-2">
                <div class="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                  <div class="flex justify-between font-mono">
                    <span class="font-bold text-slate-200">Oven Type: {{ rec.bakingProgramme.ovenType }}</span>
                    <span class="text-red-400">Preheat: {{ rec.bakingProgramme.preheatTempC }}°C</span>
                  </div>
                  <div class="grid grid-cols-3 gap-1 pt-1 font-mono text-[10px] text-center">
                    @for (z of rec.bakingProgramme.zones; track z.zoneIndex) {
                      <div class="p-1 rounded bg-slate-950 border border-slate-800">
                        <div class="text-slate-400">{{ z.name.split(':')[0] }}</div>
                        <div class="font-bold text-slate-100">{{ z.targetTempC }}°C</div>
                      </div>
                    }
                  </div>
                  <div class="text-[10px] font-mono text-emerald-400 mt-1">
                    CCP-02 Core Kill Step: {{ rec.bakingProgramme.targetCoreTempC }}°C Target
                  </div>
                </div>

                <!-- Robotic Decorating & Piping -->
                <div class="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs space-y-1">
                  <div class="flex justify-between font-mono">
                    <span class="font-bold text-purple-300">3. Robotic Decorator</span>
                    <span class="text-purple-400">{{ rec.decoratingProgramme.icingThicknessMm }}mm Icing</span>
                  </div>
                  <p class="text-slate-400 text-[11px]">
                    Vision closed loop enabled. Piped patterns: {{ rec.decoratingProgramme.roboticPatterns.length }} vectors.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <!-- Section 3: Costing Breakdown & Allergen Profile -->
          <div class="grid grid-cols-1 md:grid-cols-12 gap-4 pt-2">
            <!-- Costing Breakdown (7 Cols) -->
            <div class="md:col-span-7 bg-slate-950 border border-slate-800 p-4 rounded-xl text-xs space-y-2">
              <div class="font-mono text-slate-400 font-bold uppercase mb-1">Standard Cost Breakdown (Per Unit)</div>
              <div class="grid grid-cols-3 gap-2 font-mono">
                <div class="p-2 rounded bg-slate-900 border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">Ingredients</span>
                  <span class="font-bold text-slate-200">£{{ rec.costing.ingredientCostGbp.toFixed(2) }}</span>
                </div>
                <div class="p-2 rounded bg-slate-900 border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">Direct Labour</span>
                  <span class="font-bold text-slate-200">£{{ rec.costing.labourCostGbp.toFixed(2) }}</span>
                </div>
                <div class="p-2 rounded bg-slate-900 border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">Energy (Gas/Elec)</span>
                  <span class="font-bold text-slate-200">£{{ rec.costing.energyCostGbp.toFixed(2) }}</span>
                </div>
                <div class="p-2 rounded bg-slate-900 border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">Packaging</span>
                  <span class="font-bold text-slate-200">£{{ rec.costing.packagingCostGbp.toFixed(2) }}</span>
                </div>
                <div class="p-2 rounded bg-slate-900 border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">Waste Allowance</span>
                  <span class="font-bold text-slate-200">£{{ rec.costing.wasteAllowanceGbp.toFixed(2) }}</span>
                </div>
                <div class="p-2 rounded bg-amber-500/10 border border-amber-500/30">
                  <span class="text-amber-400 block text-[10px]">Total Unit Cost</span>
                  <span class="font-bold text-amber-300">£{{ rec.costing.totalUnitCostGbp.toFixed(2) }}</span>
                </div>
              </div>
            </div>

            <!-- Allergen Declaration (5 Cols) -->
            <div class="md:col-span-5 bg-slate-950 border border-slate-800 p-4 rounded-xl text-xs space-y-2">
              <div class="font-mono text-slate-400 font-bold uppercase mb-1">Declared Food Allergens</div>
              <div class="flex flex-wrap gap-1.5">
                @for (allg of rec.allergens; track allg) {
                  <span class="px-2 py-1 rounded bg-red-950 border border-red-800/80 text-red-300 font-mono text-[10px] font-bold">
                    {{ allg }}
                  </span>
                }
              </div>
              <p class="text-slate-400 text-[10px] mt-2 leading-relaxed">
                Requires FSA validated in-line CIP wash and ATP bioluminescence swab before allergen changeover.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RecipeStudioComponent {
  readonly factory = inject(BakeOSFactoryService);

  readonly categories = ['ALL', 'CAKES', 'BREAD', 'PASTRY', 'BISCUITS'];
  readonly selectedCategory = signal<string>('ALL');

  filteredRecipes() {
    const cat = this.selectedCategory();
    if (cat === 'ALL') return this.factory.recipes();
    return this.factory.recipes().filter(r => r.category === cat);
  }

  cloneToTestKitchen(recipe: Recipe) {
    this.factory.testKitchenExperiment.set({
      id: `EXP-${recipe.recipeCode}-V${recipe.version + 1}`,
      name: `${recipe.name} V${recipe.version + 1} Formulation Trial`,
      baseRecipeId: recipe.id,
      targetVersion: recipe.version + 1,
      notes: `Cloned from approved ${recipe.recipeCode} V${recipe.version} for process and formulation experimentation.`,
      modifications: [
        { parameter: 'Flour Hydration', baseValue: '78.5%', experimentValue: '80.0%', deltaPercent: 1.9 },
        { parameter: 'Baking Zone 1 Temp', baseValue: '182.0°C', experimentValue: '180.5°C', deltaPercent: -0.8 }
      ],
      status: 'DRAFT'
    });
    this.factory.setTab('test-kitchen');
  }
}
