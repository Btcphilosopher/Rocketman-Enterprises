import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-stop-clock',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">BAKEOS INDUSTRIAL CHRONOMETER</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-amber-500/10 text-amber-400 border border-amber-500/30">
              BRITISH MECHANICAL CLOCKWORK
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Precision stage chronometry, mechanical progress arcs, and concurrent multi-batch production timers
          </p>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="factory.toggleStopClock()"
            class="px-4 py-2 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 shadow-md"
            [class.bg-amber-500]="!factory.stopClockState().isRunning"
            [class.text-slate-950]="!factory.stopClockState().isRunning"
            [class.bg-slate-800]="factory.stopClockState().isRunning"
            [class.text-slate-100]="factory.stopClockState().isRunning">
            <mat-icon class="text-sm">{{ factory.stopClockState().isRunning ? 'pause' : 'play_arrow' }}</mat-icon>
            <span>{{ factory.stopClockState().isRunning ? 'Pause Master Timer' : 'Resume Master Timer' }}</span>
          </button>
          
          <button 
            (click)="factory.resetStopClock()"
            class="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-800 transition-colors">
            <mat-icon class="text-sm">restart_alt</mat-icon>
          </button>
        </div>
      </div>

      <!-- Main Chronometer Split: Mechanical Watchface vs Concurrent Process Timers -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Mechanical Watchface Dial (6 Cols) -->
        <div class="lg:col-span-6 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col items-center justify-center relative space-y-4">
          <div class="text-xs font-mono text-slate-400 self-start">
            MECHANICAL CHRONOMETER · CALIBRE UK-4000
          </div>

          <!-- High-End British Industrial Clockwork SVG -->
          <svg viewBox="0 0 320 320" class="w-72 h-72 select-none">
            <!-- Outer Stainless Steel Bezel -->
            <circle cx="160" cy="160" r="150" fill="#090d16" stroke="#475569" stroke-width="6"/>
            <circle cx="160" cy="160" r="144" fill="#0f172a" stroke="#1e293b" stroke-width="2"/>

            <!-- 60 Precision Minute Tick Marks -->
            @for (t of [0,6,12,18,24,30,36,42,48,54,60,66,72,78,84,90,96,102,108,114,120,126,132,138,144,150,156,162,168,174,180,186,192,198,204,210,216,222,228,234,240,246,252,258,264,270,276,282,288,294,300,306,312,318,324,330,336,342,348,354]; track t) {
              <line 
                [attr.x1]="160 + 138 * Math.cos(t * Math.PI / 180)" 
                [attr.y1]="160 + 138 * Math.sin(t * Math.PI / 180)" 
                [attr.x2]="160 + (t % 30 === 0 ? 122 : 130) * Math.cos(t * Math.PI / 180)" 
                [attr.y2]="160 + (t % 30 === 0 ? 122 : 130) * Math.sin(t * Math.PI / 180)" 
                [attr.stroke]="t % 30 === 0 ? '#f59e0b' : '#64748b'" 
                [attr.stroke-width]="t % 30 === 0 ? 3 : 1.5"/>
            }

            <!-- Inner Chronometer Numerals (05, 10, 15 ... 60) -->
            <text x="160" y="55" font-size="12" font-family="JetBrains Mono" font-weight="bold" fill="#f8fafc" text-anchor="middle">60</text>
            <text x="265" y="164" font-size="12" font-family="JetBrains Mono" font-weight="bold" fill="#f8fafc" text-anchor="middle">15</text>
            <text x="160" y="275" font-size="12" font-family="JetBrains Mono" font-weight="bold" fill="#f8fafc" text-anchor="middle">30</text>
            <text x="55" y="164" font-size="12" font-family="JetBrains Mono" font-weight="bold" fill="#f8fafc" text-anchor="middle">45</text>

            <!-- Brand Monogram -->
            <text x="160" y="110" font-size="10" font-family="Syne" font-weight="bold" fill="#f59e0b" text-anchor="middle">THE NORTHSHIRE BAKERY</text>
            <text x="160" y="122" font-size="8" font-family="JetBrains Mono" fill="#94a3b8" text-anchor="middle">PRECISION TIMING</text>

            <!-- Mechanical Seconds Hand (Continuous rotation) -->
            <g [style.transform]="'rotate(' + ((factory.stopClockState().elapsedMs / 1000) * 6) + 'deg)'" style="transform-origin: 160px 160px;">
              <line x1="160" y1="185" x2="160" y2="35" stroke="#ef4444" stroke-width="2.5"/>
              <circle cx="160" cy="35" r="4" fill="#ef4444"/>
            </g>

            <!-- Minute Hand -->
            <g [style.transform]="'rotate(' + ((factory.stopClockState().elapsedMs / 60000) * 6) + 'deg)'" style="transform-origin: 160px 160px;">
              <line x1="160" y1="175" x2="160" y2="55" stroke="#fbbf24" stroke-width="4.5"/>
            </g>

            <!-- Central Jewel Pin -->
            <circle cx="160" cy="160" r="8" fill="#1e293b" stroke="#f59e0b" stroke-width="3"/>
            <circle cx="160" cy="160" r="3" fill="#ef4444"/>
          </svg>

          <!-- Large Formatted Tabular Elapsed Time -->
          <div class="text-4xl font-mono font-bold text-slate-100 tabular-nums">
            {{ formatMs(factory.stopClockState().elapsedMs) }}
          </div>

          <!-- Lap Recorder Action -->
          <button 
            (click)="recordLap()"
            class="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-mono text-xs rounded-xl font-semibold transition-colors flex items-center gap-1.5">
            <mat-icon class="text-xs">flag</mat-icon>
            <span>Record Stage Split Lap</span>
          </button>
        </div>

        <!-- Multi-Timer Staging & Lap History (6 Cols) -->
        <div class="lg:col-span-6 space-y-5">
          <!-- Concurrent Process Timers -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-mono font-bold text-amber-400">ACTIVE PRODUCTION STAGE TIMERS</span>
              <span class="text-[10px] font-mono text-slate-400">5 CHANNELS</span>
            </div>

            <div class="space-y-2.5">
              @for (timer of factory.stopClockState().timers; track timer.id) {
                <div class="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
                  <div class="space-y-0.5">
                    <div class="font-bold text-slate-200">{{ timer.name }}</div>
                    <div class="text-[10px] font-mono text-slate-500">Target: {{ formatMs(timer.targetMs) }}</div>
                  </div>
                  <div class="text-right font-mono">
                    <div class="text-sm font-bold text-amber-400 tabular-nums">
                      {{ formatMs(timer.remainingMs) }}
                    </div>
                    <span class="text-[9px] px-1.5 py-0.2 rounded font-bold"
                      [class.bg-emerald-950]="timer.isRunning && timer.remainingMs > 0"
                      [class.text-emerald-400]="timer.isRunning && timer.remainingMs > 0"
                      [class.bg-slate-800]="!timer.isRunning || timer.remainingMs === 0"
                      [class.text-slate-400]="!timer.isRunning || timer.remainingMs === 0">
                      {{ timer.remainingMs === 0 ? 'COMPLETE' : (timer.isRunning ? 'COUNTDOWN' : 'PAUSED') }}
                    </span>
                  </div>
                </div>
              }
            </div>
          </div>

          <!-- Lap Splits Table -->
          <div class="bg-slate-900/80 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <span class="text-xs font-mono font-bold text-slate-300">STAGE SPLIT HISTORY</span>
              <span class="text-[10px] font-mono text-slate-400">{{ factory.stopClockState().laps.length }} Recorded</span>
            </div>

            <div class="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
              @for (lap of factory.stopClockState().laps; track lap.id) {
                <div class="p-2 rounded-lg bg-slate-950 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                  <span class="text-slate-300 font-semibold">{{ lap.name }}</span>
                  <span class="text-emerald-400 font-bold tabular-nums">{{ formatMs(lap.timeMs) }}</span>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class StopClockComponent {
  readonly factory = inject(BakeOSFactoryService);
  readonly Math = Math;

  formatMs(totalMs: number): string {
    const totalSec = Math.floor(totalMs / 1000);
    const mm = String(Math.floor(totalSec / 60)).padStart(2, '0');
    const ss = String(totalSec % 60).padStart(2, '0');
    const cs = String(Math.floor((totalMs % 1000) / 10)).padStart(2, '0');
    return `${mm}:${ss}.${cs}`;
  }

  recordLap() {
    const name = `Stage Split at ${this.formatMs(this.factory.stopClockState().elapsedMs)}`;
    this.factory.addStopClockLap(name);
  }
}
