import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-test-kitchen',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">TEST KITCHEN & R ANALYTICS ENGINE</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-purple-500/10 text-purple-400 border border-purple-500/30">
              R / bakeosR STATISTICAL SIMULATOR
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Empirical formula experimentation · Monte Carlo process modeling · Controlled approval gating before line deployment
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-slate-400">R Engine:</span>
          <span class="px-2 py-0.5 rounded bg-purple-950 text-purple-300 font-mono text-xs font-bold border border-purple-800">
            bakeosR v4.0.2 (Loaded)
          </span>
        </div>
      </div>

      <!-- Experiment Workspace 2-Column Split -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Formulation Adjustment Sandbox (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-400">science</mat-icon>
              <div>
                <div class="text-xs font-mono text-slate-400">RECIPE EXPERIMENT #EXP-VS-15</div>
                <h2 class="font-brand font-bold text-base text-slate-100">Victoria Sponge Formulation Trial</h2>
              </div>
            </div>
            <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-amber-500/10 text-amber-300 font-bold border border-amber-500/30">
              TRIAL MODE
            </span>
          </div>

          <!-- Parameter Sliders -->
          <div class="space-y-4 text-xs font-mono">
            <!-- Parameter 1: Butter Fraction % -->
            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-slate-300 font-semibold">West Country Butter Fraction:</span>
                <span class="text-amber-400 font-bold tabular-nums">{{ butterPct() }}%</span>
              </div>
              <input 
                type="range" 
                min="90" 
                max="115" 
                step="0.5" 
                [value]="butterPct()"
                (input)="onButterChange($event)"
                class="w-full accent-amber-500 cursor-pointer" />
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>90% (Lean)</span>
                <span>Base: 100% (56.25kg)</span>
                <span>115% (Rich)</span>
              </div>
            </div>

            <!-- Parameter 2: Creaming Duration -->
            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-slate-300 font-semibold">Stage 1 Creaming Duration:</span>
                <span class="text-purple-400 font-bold tabular-nums">{{ creamingSec() }} sec</span>
              </div>
              <input 
                type="range" 
                min="100" 
                max="240" 
                step="5" 
                [value]="creamingSec()"
                (input)="onCreamingChange($event)"
                class="w-full accent-purple-500 cursor-pointer" />
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>100s (Low Aeration)</span>
                <span>Base: 150s</span>
                <span>240s (High Aeration)</span>
              </div>
            </div>

            <!-- Parameter 3: Oven Zone 2 Temperature -->
            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div class="flex justify-between items-center">
                <span class="text-slate-300 font-semibold">Oven Zone 2 Baking Temp:</span>
                <span class="text-red-400 font-bold tabular-nums">{{ bakeTemp() }} °C</span>
              </div>
              <input 
                type="range" 
                min="165" 
                max="185" 
                step="0.5" 
                [value]="bakeTemp()"
                (input)="onBakeTempChange($event)"
                class="w-full accent-red-500 cursor-pointer" />
              <div class="flex justify-between text-[10px] text-slate-500">
                <span>165°C</span>
                <span>Base: 176°C</span>
                <span>185°C</span>
              </div>
            </div>
          </div>

          <!-- Run Monte Carlo Trial Action -->
          <button 
            (click)="runTrial()"
            class="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg">
            <mat-icon class="text-base">play_arrow</mat-icon>
            <span>Run 500-Batch Monte Carlo Simulation (R)</span>
          </button>
        </div>

        <!-- R Statistical Analytics Report & Outcome Comparison (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-5">
          @let exp = factory.testKitchenExperiment();

          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">insights</mat-icon>
              <div>
                <div class="text-xs font-mono text-slate-400">bakeosR STATISTICAL EVALUATION</div>
                <h2 class="font-brand font-bold text-base text-slate-100">Original (V14) vs Trial (V15) Metrics</h2>
              </div>
            </div>
            <span class="text-xs font-mono text-emerald-400">Confidence: 99.9% (p < 0.001)</span>
          </div>

          <!-- 5 Delta Metrics Grid (Specification Section 89) -->
          @if (exp?.simulationResults; as res) {
            <div class="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px] uppercase font-mono block">Cake Height</span>
                <div class="text-xl font-mono font-bold text-emerald-400 mt-0.5 tabular-nums">+{{ res.heightDeltaPercent }}%</div>
                <div class="text-[10px] text-slate-500 font-mono">110mm → 113.4mm</div>
              </div>

              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px] uppercase font-mono block">Weight Variance</span>
                <div class="text-xl font-mono font-bold text-emerald-400 mt-0.5 tabular-nums">-{{ res.varianceReductionPercent }}%</div>
                <div class="text-[10px] text-slate-500 font-mono">Std Dev: 4.2g → 3.4g</div>
              </div>

              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px] uppercase font-mono block">Reject Rate</span>
                <div class="text-xl font-mono font-bold text-emerald-400 mt-0.5 tabular-nums">{{ res.rejectRateDeltaPercent }}%</div>
                <div class="text-[10px] text-slate-500 font-mono">1.3% → 1.0%</div>
              </div>

              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px] uppercase font-mono block">Moisture Index</span>
                <div class="text-xl font-mono font-bold text-cyan-400 mt-0.5 tabular-nums">+{{ res.moistureProxyPercent }}%</div>
                <div class="text-[10px] text-slate-500 font-mono">Sensory Softness Score</div>
              </div>

              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px] uppercase font-mono block">Energy Usage</span>
                <div class="text-xl font-mono font-bold text-slate-200 mt-0.5 tabular-nums">{{ res.energyDeltaPercent }}%</div>
                <div class="text-[10px] text-slate-500 font-mono">kWh per batch</div>
              </div>

              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800">
                <span class="text-slate-400 text-[10px] uppercase font-mono block">Unit Cost Delta</span>
                <div class="text-xl font-mono font-bold text-amber-400 mt-0.5 tabular-nums">+£{{ res.costDeltaGbp.toFixed(2) }}</div>
                <div class="text-[10px] text-slate-500 font-mono">£11.02 → £11.09</div>
              </div>
            </div>

            <!-- R Report Narrative Summary -->
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono space-y-2">
              <div class="text-purple-400 font-bold">R STATISTICAL SUMMARY (bakeosR::recipe_opt)</div>
              <p class="text-slate-300 text-[11px] leading-relaxed">
                {{ res.rReportSummary }}
              </p>
            </div>

            <!-- Approval Sign-off Box (Specification Section 56 & 90) -->
            <div class="p-4 bg-slate-950 border border-amber-500/40 rounded-xl flex items-center justify-between gap-4">
              <div class="space-y-0.5">
                <div class="text-xs font-bold text-amber-300 font-mono">PROPOSED RECIPE CHANGE (VS-001 REV 15)</div>
                <p class="text-[11px] text-slate-400">Requires Head of Quality and Master Baker dual digital signature before promotion.</p>
              </div>

              <button 
                (click)="submitApproval()"
                class="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-colors font-mono shrink-0 shadow-md">
                Submit For Dual Approval
              </button>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class TestKitchenComponent {
  readonly factory = inject(BakeOSFactoryService);

  readonly butterPct = signal<number>(102.5);
  readonly creamingSec = signal<number>(170);
  readonly bakeTemp = signal<number>(174.5);

  onButterChange(event: Event) {
    this.butterPct.set(+(event.target as HTMLInputElement).value);
  }

  onCreamingChange(event: Event) {
    this.creamingSec.set(+(event.target as HTMLInputElement).value);
  }

  onBakeTempChange(event: Event) {
    this.bakeTemp.set(+(event.target as HTMLInputElement).value);
  }

  runTrial() {
    this.factory.runExperimentSimulation(this.butterPct(), this.creamingSec(), this.bakeTemp());
  }

  submitApproval() {
    this.factory.addEvent('QUALITY', 'Proposed Recipe Change VS-001 Rev 15 submitted for dual Master Baker / Quality Lead approval.');
  }
}
