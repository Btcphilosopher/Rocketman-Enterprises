import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { BakeOSFactoryService } from '../../services/bakeos-factory.service';

@Component({
  selector: 'app-haccp',
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="p-6 space-y-6 max-w-[1600px] mx-auto">
      <!-- Title Header -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div class="flex items-center gap-3">
            <h1 class="text-2xl font-brand font-bold text-slate-100 tracking-wide">FOOD SAFETY CONTROL CENTRE (HACCP)</h1>
            <span class="px-2 py-0.5 rounded text-[11px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              FSA MyHACCP & BRCGS GRADE AA+
            </span>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            Hazard Analysis Critical Control Point system · Continuous automated validation of biological, physical & allergenic hazards
          </p>
        </div>

        <div class="flex items-center gap-2">
          <span class="text-xs font-mono text-slate-400">Audited By:</span>
          <span class="px-2 py-0.5 rounded bg-slate-900 text-slate-200 font-mono text-xs border border-slate-800">
            Dr. Eleanor Vance (Head of Technical)
          </span>
        </div>
      </div>

      <!-- 4 Critical Control Points (CCPs) Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (ccp of factory.ccps(); track ccp.ccpNumber) {
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 relative overflow-hidden">
            <div class="flex items-center justify-between">
              <span class="font-mono font-bold text-xs text-amber-400">{{ ccp.ccpNumber }}</span>
              <span class="px-2 py-0.2 rounded text-[10px] font-mono font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                {{ ccp.status }}
              </span>
            </div>

            <h3 class="font-brand font-bold text-sm text-slate-100 min-h-[38px]">{{ ccp.name }}</h3>

            <div class="space-y-2 text-xs font-mono bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div>
                <span class="text-slate-500 block text-[10px] uppercase">Hazard Type</span>
                <span class="text-slate-200 font-semibold">{{ ccp.hazardType }}</span>
              </div>
              <div>
                <span class="text-slate-500 block text-[10px] uppercase">Critical Limit</span>
                <span class="text-slate-300 text-[11px]">{{ ccp.criticalLimit }}</span>
              </div>
              <div class="pt-1 border-t border-slate-800">
                <span class="text-slate-500 block text-[10px] uppercase">Live Current Reading</span>
                <span class="text-emerald-400 font-bold text-[11px]">{{ ccp.currentValue }}</span>
              </div>
            </div>

            <div class="text-[10px] text-slate-500 font-mono flex justify-between items-center pt-1">
              <span>Verified: {{ ccp.lastVerified }}</span>
              <span>{{ ccp.verifierName.split(':')[0] }}</span>
            </div>
          </div>
        }
      </div>

      <!-- Allergen Matrix & Washout Protocol -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Allergen Cross-Contact Matrix (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-purple-400">warning</mat-icon>
              <h2 class="font-brand font-bold text-base text-slate-100">LINE ALLERGEN COMPATIBILITY & WASHOUT MATRIX</h2>
            </div>
            <span class="text-xs font-mono text-slate-400">Regulation (EU) No 1169/2011</span>
          </div>

          <p class="text-xs text-slate-300 leading-relaxed">
            The Northshire Bakery enforces rigid physical segregation and validated sanitation changeovers when transitioning lines between allergen-dense products (e.g., Nut frangipanes or Milk/Egg buttercreams) and plain artisan breads.
          </p>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs font-mono">
              <thead class="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th class="py-2.5 px-3">Product Line</th>
                  <th class="py-2.5 px-3">Declared Allergens</th>
                  <th class="py-2.5 px-3">Changeover Dwell</th>
                  <th class="py-2.5 px-3 text-right">ATP Limit</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                <tr class="hover:bg-slate-800/30">
                  <td class="py-2.5 px-3 font-semibold text-slate-200">Victoria Sponge (Line 1)</td>
                  <td class="py-2.5 px-3 text-red-300 font-bold">Wheat, Milk, Egg</td>
                  <td class="py-2.5 px-3 text-slate-300">45 mins CIP Wash</td>
                  <td class="py-2.5 px-3 text-right text-emerald-400">< 10 RLU</td>
                </tr>
                <tr class="hover:bg-slate-800/30">
                  <td class="py-2.5 px-3 font-semibold text-slate-200">Belgian Chocolate (Line 1)</td>
                  <td class="py-2.5 px-3 text-red-300 font-bold">Wheat, Milk, Egg, Soya</td>
                  <td class="py-2.5 px-3 text-slate-300">60 mins Caustic Wash</td>
                  <td class="py-2.5 px-3 text-right text-emerald-400">< 10 RLU</td>
                </tr>
                <tr class="hover:bg-slate-800/30">
                  <td class="py-2.5 px-3 font-semibold text-slate-200">Artisan Sourdough (Line 2)</td>
                  <td class="py-2.5 px-3 text-amber-300 font-bold">Wheat Gluten Only</td>
                  <td class="py-2.5 px-3 text-slate-300">30 mins Dry Vacuum</td>
                  <td class="py-2.5 px-3 text-right text-emerald-400">< 25 RLU</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Corrective Action & FSA Audit Log (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-3">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div class="flex items-center gap-2">
              <mat-icon class="text-emerald-400">fact_check</mat-icon>
              <h2 class="font-brand font-bold text-base text-slate-100">Automated Audit Trail</h2>
            </div>
            <span class="text-xs font-mono text-emerald-400">100% Traceable</span>
          </div>

          <div class="space-y-2 text-xs">
            <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div class="flex justify-between font-mono text-[10px]">
                <span class="text-slate-400">08:24:10 · CCP-02</span>
                <span class="text-emerald-400 font-bold">KILL STEP VERIFIED</span>
              </div>
              <p class="text-slate-300 text-[11px]">Victoria Sponge core temperature recorded at 94.2°C via in-line thermal camera.</p>
            </div>

            <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div class="flex justify-between font-mono text-[10px]">
                <span class="text-slate-400">08:00:00 · CCP-01</span>
                <span class="text-emerald-400 font-bold">SIEVE INTEGRITY OK</span>
              </div>
              <p class="text-slate-300 text-[11px]">Silo 03 0.8mm stainless mesh optical check passed with zero foreign debris.</p>
            </div>

            <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1">
              <div class="flex justify-between font-mono text-[10px]">
                <span class="text-slate-400">07:15:00 · CCP-04</span>
                <span class="text-emerald-400 font-bold">ATP SWAB PASSED</span>
              </div>
              <p class="text-slate-300 text-[11px]">Line 1 Mixer M-04 bioluminescence reading 4 RLU (< 10 RLU threshold).</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class HaccpComponent {
  readonly factory = inject(BakeOSFactoryService);
}
