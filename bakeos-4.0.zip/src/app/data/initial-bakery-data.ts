import { Recipe, Ingredient, Machine, ProductionBatch, ProductionOrder, CCPMonitor, SPCMetricSeries } from '../models/bakery.models';

export const INITIAL_INGREDIENTS: Ingredient[] = [
  {
    id: 'ING-FLOUR-01',
    name: 'Shipton Mill Premium Cake Flour (Wheat)',
    category: 'DRY_POWDER',
    supplier: 'Shipton Mill Ltd, Gloucestershire',
    storage: 'AMBIENT_SILO',
    targetTempC: 18.0,
    unit: 'kg',
    costPerKg: 0.85,
    allergens: ['WHEAT_GLUTEN'],
    stockQuantity: 14500,
    reorderPoint: 4000,
    countryOfOrigin: 'United Kingdom',
    currentLots: [
      {
        lotNumber: 'LOT-F-28471',
        ingredientId: 'ING-FLOUR-01',
        receivedDate: '2026-09-12',
        expiryDate: '2027-03-12',
        initialWeightKg: 10000,
        remainingWeightKg: 6420,
        moisturePercent: 13.8,
        proteinPercent: 10.4,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-SMP-28471.pdf'
      }
    ]
  },
  {
    id: 'ING-SUGAR-01',
    name: 'British Fine Caster Sugar',
    category: 'SUGAR',
    supplier: 'British Sugar PLC, Cantley',
    storage: 'AMBIENT_SILO',
    targetTempC: 20.0,
    unit: 'kg',
    costPerKg: 0.72,
    allergens: [],
    stockQuantity: 18200,
    reorderPoint: 5000,
    countryOfOrigin: 'United Kingdom',
    currentLots: [
      {
        lotNumber: 'LOT-S-99120',
        ingredientId: 'ING-SUGAR-01',
        receivedDate: '2026-09-15',
        expiryDate: '2028-09-15',
        initialWeightKg: 12000,
        remainingWeightKg: 8940,
        moisturePercent: 0.04,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-BS-99120.pdf'
      }
    ]
  },
  {
    id: 'ING-BUTTER-01',
    name: 'West Country Farmhouse Unsalted Butter 82% Fat',
    category: 'FAT',
    supplier: 'Coombe Castle Dairy, Wiltshire',
    storage: 'CHILLED',
    targetTempC: 4.0,
    unit: 'kg',
    costPerKg: 5.40,
    allergens: ['MILK'],
    stockQuantity: 3200,
    reorderPoint: 800,
    countryOfOrigin: 'United Kingdom',
    currentLots: [
      {
        lotNumber: 'LOT-B-77401',
        ingredientId: 'ING-BUTTER-01',
        receivedDate: '2026-09-18',
        expiryDate: '2026-11-20',
        initialWeightKg: 2500,
        remainingWeightKg: 1850,
        moisturePercent: 15.6,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-CCD-77401.pdf'
      }
    ]
  },
  {
    id: 'ING-EGG-01',
    name: 'British Lion Free-Range Liquid Whole Egg',
    category: 'LIQUID',
    supplier: 'Noble Foods, Hertfordshire',
    storage: 'CHILLED',
    targetTempC: 3.5,
    unit: 'kg',
    costPerKg: 3.10,
    allergens: ['EGG'],
    stockQuantity: 2400,
    reorderPoint: 600,
    countryOfOrigin: 'United Kingdom',
    currentLots: [
      {
        lotNumber: 'LOT-E-63029',
        ingredientId: 'ING-EGG-01',
        receivedDate: '2026-09-20',
        expiryDate: '2026-10-15',
        initialWeightKg: 1500,
        remainingWeightKg: 920,
        moisturePercent: 74.8,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-NF-63029.pdf'
      }
    ]
  },
  {
    id: 'ING-VANILLA-01',
    name: 'Bourbon Pure Vanilla Extract 2-Fold',
    category: 'FLAVOUR',
    supplier: 'Taylor & Colledge, Berkshire',
    storage: 'AMBIENT_RACK',
    targetTempC: 19.0,
    unit: 'kg',
    costPerKg: 88.0,
    allergens: [],
    stockQuantity: 120,
    reorderPoint: 30,
    countryOfOrigin: 'Madagascar',
    currentLots: [
      {
        lotNumber: 'LOT-V-40192',
        ingredientId: 'ING-VANILLA-01',
        receivedDate: '2026-08-01',
        expiryDate: '2028-08-01',
        initialWeightKg: 100,
        remainingWeightKg: 64,
        moisturePercent: 42.0,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-TC-40192.pdf'
      }
    ]
  },
  {
    id: 'ING-JAM-01',
    name: 'Scottish Glen Raspberry Seedless Compote 65% Fruit',
    category: 'DECORATION',
    supplier: 'Mackays Preserves, Arbroath',
    storage: 'AMBIENT_RACK',
    targetTempC: 18.0,
    unit: 'kg',
    costPerKg: 4.80,
    allergens: [],
    stockQuantity: 1800,
    reorderPoint: 400,
    countryOfOrigin: 'United Kingdom (Scotland)',
    currentLots: [
      {
        lotNumber: 'LOT-J-51203',
        ingredientId: 'ING-JAM-01',
        receivedDate: '2026-09-10',
        expiryDate: '2027-09-10',
        initialWeightKg: 1200,
        remainingWeightKg: 850,
        moisturePercent: 35.0,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-MK-51203.pdf'
      }
    ]
  },
  {
    id: 'ING-CREAM-01',
    name: 'Cornish Clotted Cream 55% Milkfat',
    category: 'FAT',
    supplier: 'Rodda\'s Creamery, Scorrier, Cornwall',
    storage: 'CHILLED',
    targetTempC: 3.8,
    unit: 'kg',
    costPerKg: 6.90,
    allergens: ['MILK'],
    stockQuantity: 950,
    reorderPoint: 250,
    countryOfOrigin: 'United Kingdom',
    currentLots: [
      {
        lotNumber: 'LOT-C-33821',
        ingredientId: 'ING-CREAM-01',
        receivedDate: '2026-09-19',
        expiryDate: '2026-10-18',
        initialWeightKg: 800,
        remainingWeightKg: 520,
        moisturePercent: 38.0,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-RD-33821.pdf'
      }
    ]
  },
  {
    id: 'ING-CHOC-01',
    name: 'Belgian 70.5% Dark Chocolate Callets',
    category: 'DECORATION',
    supplier: 'Callebaut Barry, Banbury',
    storage: 'AMBIENT_RACK',
    targetTempC: 18.0,
    unit: 'kg',
    costPerKg: 8.40,
    allergens: ['SOYA', 'MILK'],
    stockQuantity: 2800,
    reorderPoint: 600,
    countryOfOrigin: 'Belgium',
    currentLots: [
      {
        lotNumber: 'LOT-CH-11940',
        ingredientId: 'ING-CHOC-01',
        receivedDate: '2026-08-25',
        expiryDate: '2027-08-25',
        initialWeightKg: 2000,
        remainingWeightKg: 1400,
        moisturePercent: 0.8,
        qcStatus: 'APPROVED',
        supplierCertUrl: 'COA-CAL-11940.pdf'
      }
    ]
  }
];

export const RECIPES_CATALOG: Recipe[] = [
  {
    id: 'REC-VS-001',
    name: 'The Northshire Heritage Victoria Sponge',
    category: 'CAKES',
    version: 14,
    recipeCode: 'VS-001',
    status: 'APPROVED',
    author: 'Chef Alistair Sterling / Lead Food Technologist',
    approvedBy: 'Head of Quality: Dr. Eleanor Vance & Master Baker: George Campbell',
    approvalDate: '12/08/2026',
    imageUrl: '/assets/images/victoria_sponge_spec_1791368023892.jpg',
    description: 'The quintessential British two-layer golden sponge sandwich filled with seedless Scottish Glen raspberry compote and Cornish clotted cream buttercream, decorated with 12 piped rosettes and light caster dusting.',
    targetBatchYieldCount: 500,
    unitWeightGrams: 450,
    shelfLifeDays: 7,
    dimensionsMm: {
      diameterOrLength: 200,
      height: 110,
      layers: 2
    },
    ingredients: [
      { ingredientId: 'ING-FLOUR-01', name: 'Shipton Mill Cake Flour', bakersPercentage: 100.0, batchWeightKg: 56.25, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 },
      { ingredientId: 'ING-SUGAR-01', name: 'Fine Caster Sugar', bakersPercentage: 100.0, batchWeightKg: 56.25, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 },
      { ingredientId: 'ING-BUTTER-01', name: 'West Country Butter 82%', bakersPercentage: 100.0, batchWeightKg: 56.25, dosingMethod: 'MANUAL_PRECISION_SCALE', toleranceKg: 0.02, targetTempC: 17.5 },
      { ingredientId: 'ING-EGG-01', name: 'Liquid Whole Free-Range Egg', bakersPercentage: 100.0, batchWeightKg: 56.25, dosingMethod: 'AUTOMATED_LIQUID', toleranceKg: 0.04, targetTempC: 12.0 },
      { ingredientId: 'ING-VANILLA-01', name: 'Bourbon Pure Vanilla Extract', bakersPercentage: 1.5, batchWeightKg: 0.85, dosingMethod: 'MANUAL_PRECISION_SCALE', toleranceKg: 0.005 },
      { ingredientId: 'ING-JAM-01', name: 'Scottish Raspberry Compote', bakersPercentage: 35.0, batchWeightKg: 19.70, dosingMethod: 'AUTOMATED_LIQUID', toleranceKg: 0.03 },
      { ingredientId: 'ING-CREAM-01', name: 'Cornish Clotted Cream Buttercream', bakersPercentage: 45.0, batchWeightKg: 25.30, dosingMethod: 'MANUAL_PRECISION_SCALE', toleranceKg: 0.03 }
    ],
    mixingProgramme: {
      totalDurationSec: 405, // 06:45
      targetHydrationPercent: 78.5,
      steps: [
        {
          stepNumber: 1,
          name: 'Stage 1: High-Aeration Creaming',
          tool: 'PADDLE',
          speedRpm: 184,
          durationSeconds: 150,
          targetTempC: 19.2,
          description: 'Cream tempered butter and caster sugar to achieve micro-air cell entrapment and pale emulsion.',
          ingredientsAdded: ['West Country Butter 82%', 'Fine Caster Sugar']
        },
        {
          stepNumber: 2,
          name: 'Stage 2: Emulsified Egg Addition',
          tool: 'WHISK',
          speedRpm: 120,
          durationSeconds: 180,
          targetTempC: 19.8,
          description: 'Slow metered addition of free-range liquid egg in 4 timed pulses with vanilla to prevent curdling.',
          ingredientsAdded: ['Liquid Whole Free-Range Egg', 'Bourbon Pure Vanilla Extract']
        },
        {
          stepNumber: 3,
          name: 'Stage 3: Gentle Flour Fold',
          tool: 'PADDLE',
          speedRpm: 55,
          durationSeconds: 75,
          targetTempC: 20.4,
          description: 'Low-shear folding of sifted cake flour to develop zero gluten tension while retaining bulk volume.',
          ingredientsAdded: ['Shipton Mill Cake Flour']
        }
      ]
    },
    depositingProgramme: {
      nozzleType: 'Multi-Piston 4-Head Depositor D-02',
      depositWeightGrams: 225, // per tier
      depositToleranceGrams: 3,
      cycleTimeSec: 2.2
    },
    bakingProgramme: {
      ovenType: 'TUNNEL',
      preheatTempC: 182,
      bakeTimeMinutes: 22,
      steamInjectionSeconds: 0,
      targetCoreTempC: 94.0,
      zones: [
        { zoneIndex: 1, name: 'Zone 1: Heat Rise & Expansion', targetTempC: 182, fanSpeedPercent: 60, topHeatPercent: 70, bottomHeatPercent: 80 },
        { zoneIndex: 2, name: 'Zone 2: Crumb Set & Gelatinisation', targetTempC: 176, fanSpeedPercent: 50, topHeatPercent: 65, bottomHeatPercent: 65 },
        { zoneIndex: 3, name: 'Zone 3: Golden Crusting & Drying', targetTempC: 165, fanSpeedPercent: 40, topHeatPercent: 60, bottomHeatPercent: 50 }
      ]
    },
    coolingProgramme: {
      targetTunnelExitTempC: 19.5,
      dwellTimeMinutes: 38,
      airVelocityMs: 1.8
    },
    decoratingProgramme: {
      icingThicknessMm: 2.5,
      icingToleranceMm: 0.2,
      requiresVisionClosedLoop: true,
      roboticPatterns: [
        { patternType: 'SPIRAL', pointsCount: 36, nozzleSizeMm: 6, depositionPressureBar: 1.8, heightMm: 4, colorHex: '#991B1B', icingMaterial: 'RASPBERRY_COMPOTE' },
        { patternType: 'BORDER_WAVE', pointsCount: 48, nozzleSizeMm: 8, depositionPressureBar: 2.2, heightMm: 8, colorHex: '#FEF3C7', icingMaterial: 'VANILLA_BUTTERCREAM' },
        { patternType: 'ROSETTE', pointsCount: 12, nozzleSizeMm: 10, depositionPressureBar: 2.5, heightMm: 16, colorHex: '#FEF3C7', icingMaterial: 'VANILLA_BUTTERCREAM' },
        { patternType: 'PLAQUE_CENTRE', pointsCount: 1, nozzleSizeMm: 0, depositionPressureBar: 0, heightMm: 2, colorHex: '#78350F', icingMaterial: 'CHOCOLATE_GANACHE' }
      ]
    },
    packagingProgramme: {
      primaryPackType: 'INDIVIDUAL_CARTON',
      cartonsPerCase: 6,
      modifiedAtmosphereGas: 'N2 98.5% / CO2 1.5%',
      targetNetWeightGrams: 450,
      labelFormatId: 'LBL-UK-VS-450G-V2'
    },
    costing: {
      ingredientCostGbp: 3.82,
      labourCostGbp: 2.40,
      energyCostGbp: 1.60,
      packagingCostGbp: 1.80,
      wasteAllowanceGbp: 1.40,
      totalUnitCostGbp: 11.02,
      targetRetailGbp: 18.50
    },
    allergens: ['WHEAT_GLUTEN', 'EGG', 'MILK'],
    qualityTolerances: {
      weightMinG: 435,
      weightMaxG: 465,
      heightMinMm: 106,
      heightMaxMm: 114,
      diameterMinMm: 198,
      diameterMaxMm: 202,
      browningDeltaEMax: 1.2,
      decorationAlignmentMinPercent: 97.5
    }
  },
  {
    id: 'REC-BC-002',
    name: 'Belgian Dark Chocolate Fudge Layer Cake',
    category: 'CAKES',
    version: 8,
    recipeCode: 'BC-002',
    status: 'APPROVED',
    author: 'Chef Jean-Luc Monet / Senior Chocolatier',
    approvedBy: 'Head of Quality: Dr. Eleanor Vance',
    approvalDate: '04/09/2026',
    imageUrl: '/assets/images/belgian_chocolate_cake_1791368036880.jpg',
    description: 'Three tiers of rich cocoa sponge saturated with 70.5% dark Belgian chocolate fudge ganache, finished with mirror glaze and hand-tempered chocolate curls.',
    targetBatchYieldCount: 400,
    unitWeightGrams: 620,
    shelfLifeDays: 9,
    dimensionsMm: { diameterOrLength: 200, height: 125, layers: 3 },
    ingredients: [
      { ingredientId: 'ING-FLOUR-01', name: 'Shipton Mill Cake Flour', bakersPercentage: 85.0, batchWeightKg: 42.5, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 },
      { ingredientId: 'ING-CHOC-01', name: 'Belgian 70.5% Callets', bakersPercentage: 55.0, batchWeightKg: 27.5, dosingMethod: 'MANUAL_PRECISION_SCALE', toleranceKg: 0.02 },
      { ingredientId: 'ING-SUGAR-01', name: 'Fine Caster Sugar', bakersPercentage: 110.0, batchWeightKg: 55.0, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 },
      { ingredientId: 'ING-BUTTER-01', name: 'West Country Butter 82%', bakersPercentage: 90.0, batchWeightKg: 45.0, dosingMethod: 'MANUAL_PRECISION_SCALE', toleranceKg: 0.02 },
      { ingredientId: 'ING-EGG-01', name: 'Liquid Whole Free-Range Egg', bakersPercentage: 80.0, batchWeightKg: 40.0, dosingMethod: 'AUTOMATED_LIQUID', toleranceKg: 0.04 }
    ],
    mixingProgramme: {
      totalDurationSec: 480,
      targetHydrationPercent: 72.0,
      steps: [
        { stepNumber: 1, name: 'Chocolate & Butter Melt Emulsification', tool: 'PADDLE', speedRpm: 90, durationSeconds: 180, targetTempC: 38.5, description: 'Low shear melt blending at 40°C jacket temperature.', ingredientsAdded: ['Belgian 70.5% Callets', 'West Country Butter 82%'] },
        { stepNumber: 2, name: 'Egg & Sugar Ribboning', tool: 'WHISK', speedRpm: 190, durationSeconds: 200, targetTempC: 22.0, description: 'High speed ribbon aeration.', ingredientsAdded: ['Liquid Whole Free-Range Egg', 'Fine Caster Sugar'] },
        { stepNumber: 3, name: 'Final Batter Incorporation', tool: 'PADDLE', speedRpm: 60, durationSeconds: 100, targetTempC: 24.5, description: 'Fold flour and cocoa.', ingredientsAdded: ['Shipton Mill Cake Flour'] }
      ]
    },
    depositingProgramme: { nozzleType: 'Heavy Viscosity 3-Head D-02', depositWeightGrams: 205, depositToleranceGrams: 4, cycleTimeSec: 2.8 },
    bakingProgramme: {
      ovenType: 'TUNNEL',
      preheatTempC: 175,
      bakeTimeMinutes: 26,
      steamInjectionSeconds: 0,
      targetCoreTempC: 92.5,
      zones: [
        { zoneIndex: 1, name: 'Zone 1: Core Warming', targetTempC: 175, fanSpeedPercent: 50, topHeatPercent: 60, bottomHeatPercent: 70 },
        { zoneIndex: 2, name: 'Zone 2: Fudge Setting', targetTempC: 170, fanSpeedPercent: 45, topHeatPercent: 60, bottomHeatPercent: 60 },
        { zoneIndex: 3, name: 'Zone 3: Moisture Retention', targetTempC: 160, fanSpeedPercent: 35, topHeatPercent: 55, bottomHeatPercent: 50 }
      ]
    },
    coolingProgramme: { targetTunnelExitTempC: 18.0, dwellTimeMinutes: 45, airVelocityMs: 1.5 },
    decoratingProgramme: {
      icingThicknessMm: 3.2,
      icingToleranceMm: 0.3,
      requiresVisionClosedLoop: true,
      roboticPatterns: [
        { patternType: 'DRIP', pointsCount: 24, nozzleSizeMm: 4, depositionPressureBar: 1.5, heightMm: 25, colorHex: '#29140C', icingMaterial: 'CHOCOLATE_GANACHE' }
      ]
    },
    packagingProgramme: { primaryPackType: 'INDIVIDUAL_CARTON', cartonsPerCase: 4, modifiedAtmosphereGas: 'N2 99%', targetNetWeightGrams: 620, labelFormatId: 'LBL-UK-BC-620G' },
    costing: { ingredientCostGbp: 5.60, labourCostGbp: 2.80, energyCostGbp: 1.90, packagingCostGbp: 2.10, wasteAllowanceGbp: 1.70, totalUnitCostGbp: 14.10, targetRetailGbp: 22.00 },
    allergens: ['WHEAT_GLUTEN', 'EGG', 'MILK', 'SOYA'],
    qualityTolerances: { weightMinG: 600, weightMaxG: 640, heightMinMm: 120, heightMaxMm: 130, diameterMinMm: 198, diameterMaxMm: 202, browningDeltaEMax: 1.5, decorationAlignmentMinPercent: 96.0 }
  },
  {
    id: 'REC-SD-003',
    name: 'Heritage Stoneground Artisan Sourdough',
    category: 'BREAD',
    version: 22,
    recipeCode: 'SD-003',
    status: 'APPROVED',
    author: 'Master Baker George Campbell',
    approvedBy: 'Head of Quality: Dr. Eleanor Vance',
    approvalDate: '28/07/2026',
    imageUrl: '/assets/images/artisan_sourdough_loaf_1791368050249.jpg',
    description: 'Wild yeast sourdough fermented for 24 hours, baked in heavy stone hearth with saturated steam injection for blistered crackling ear and custard-like open crumb.',
    targetBatchYieldCount: 600,
    unitWeightGrams: 800,
    shelfLifeDays: 5,
    dimensionsMm: { diameterOrLength: 260, width: 140, height: 115, layers: 1 },
    ingredients: [
      { ingredientId: 'ING-FLOUR-01', name: 'Shipton Mill Strong White Flour', bakersPercentage: 80.0, batchWeightKg: 192.0, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.1 },
      { ingredientId: 'ING-FLOUR-01', name: 'Stoneground Wholemeal Rye Flour', bakersPercentage: 20.0, batchWeightKg: 48.0, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 }
    ],
    mixingProgramme: {
      totalDurationSec: 720,
      targetHydrationPercent: 74.5,
      steps: [
        { stepNumber: 1, name: 'Autolyse Rest', tool: 'SPIRAL', speedRpm: 30, durationSeconds: 240, targetTempC: 22.0, description: 'Flour and water slow combine followed by rest.', ingredientsAdded: ['Flour', 'Water'] },
        { stepNumber: 2, name: 'Levain & Salt Incorporation', tool: 'SPIRAL', speedRpm: 60, durationSeconds: 300, targetTempC: 24.0, description: 'Develop gluten matrix.', ingredientsAdded: ['Sourdough Starter', 'Sea Salt'] },
        { stepNumber: 3, name: 'High Speed Gluten Window Test', tool: 'SPIRAL', speedRpm: 140, durationSeconds: 180, targetTempC: 25.5, description: 'Windowpane elastic development.', ingredientsAdded: [] }
      ]
    },
    depositingProgramme: { nozzleType: 'Hydraulic Volumetric Divider V-01', depositWeightGrams: 890, depositToleranceGrams: 8, cycleTimeSec: 1.5 },
    bakingProgramme: {
      ovenType: 'DECK',
      preheatTempC: 245,
      bakeTimeMinutes: 34,
      steamInjectionSeconds: 14,
      targetCoreTempC: 98.0,
      zones: [
        { zoneIndex: 1, name: 'Hearth Steam Chamber', targetTempC: 245, fanSpeedPercent: 0, topHeatPercent: 85, bottomHeatPercent: 95 }
      ]
    },
    coolingProgramme: { targetTunnelExitTempC: 24.0, dwellTimeMinutes: 60, airVelocityMs: 0.8 },
    decoratingProgramme: { icingThicknessMm: 0, icingToleranceMm: 0, requiresVisionClosedLoop: false, roboticPatterns: [] },
    packagingProgramme: { primaryPackType: 'FLOW_WRAP', cartonsPerCase: 8, modifiedAtmosphereGas: 'Ambient Micro-perforated', targetNetWeightGrams: 800, labelFormatId: 'LBL-UK-SD-800G' },
    costing: { ingredientCostGbp: 0.98, labourCostGbp: 1.45, energyCostGbp: 0.82, packagingCostGbp: 0.40, wasteAllowanceGbp: 0.25, totalUnitCostGbp: 3.90, targetRetailGbp: 5.75 },
    allergens: ['WHEAT_GLUTEN'],
    qualityTolerances: { weightMinG: 780, weightMaxG: 820, heightMinMm: 105, heightMaxMm: 125, diameterMinMm: 250, diameterMaxMm: 270, browningDeltaEMax: 2.0, decorationAlignmentMinPercent: 100 }
  },
  {
    id: 'REC-LD-004',
    name: 'Yorkshire Candied Lemon Drizzle Loaf',
    category: 'CAKES',
    version: 11,
    recipeCode: 'LD-004',
    status: 'APPROVED',
    author: 'Chef Alistair Sterling',
    approvedBy: 'Head of Quality: Dr. Eleanor Vance',
    approvalDate: '15/07/2026',
    imageUrl: '/assets/images/yorkshire_lemon_drizzle_1791368060944.jpg',
    description: 'Traditional Yorkshire loaf infused with fresh Sicilian lemon zest, injected with warm lemon syrup upon exiting the oven, and finished with crystalline sugar crackle glaze.',
    targetBatchYieldCount: 450,
    unitWeightGrams: 420,
    shelfLifeDays: 8,
    dimensionsMm: { diameterOrLength: 220, width: 105, height: 85, layers: 1 },
    ingredients: [
      { ingredientId: 'ING-FLOUR-01', name: 'Shipton Mill Cake Flour', bakersPercentage: 100.0, batchWeightKg: 45.0, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 },
      { ingredientId: 'ING-SUGAR-01', name: 'Fine Caster Sugar', bakersPercentage: 100.0, batchWeightKg: 45.0, dosingMethod: 'AUTOMATED_SILO', toleranceKg: 0.05 },
      { ingredientId: 'ING-BUTTER-01', name: 'West Country Butter 82%', bakersPercentage: 100.0, batchWeightKg: 45.0, dosingMethod: 'MANUAL_PRECISION_SCALE', toleranceKg: 0.02 },
      { ingredientId: 'ING-EGG-01', name: 'Liquid Whole Free-Range Egg', bakersPercentage: 100.0, batchWeightKg: 45.0, dosingMethod: 'AUTOMATED_LIQUID', toleranceKg: 0.04 }
    ],
    mixingProgramme: {
      totalDurationSec: 360,
      targetHydrationPercent: 76.0,
      steps: [
        { stepNumber: 1, name: 'Zest & Sugar Rub Creaming', tool: 'PADDLE', speedRpm: 175, durationSeconds: 150, targetTempC: 19.0, description: 'Release citrus oils.', ingredientsAdded: ['Fine Caster Sugar', 'West Country Butter 82%'] },
        { stepNumber: 2, name: 'Egg Addition', tool: 'WHISK', speedRpm: 130, durationSeconds: 150, targetTempC: 19.5, description: 'Smooth emulsification.', ingredientsAdded: ['Liquid Whole Free-Range Egg'] },
        { stepNumber: 3, name: 'Flour Fold', tool: 'PADDLE', speedRpm: 50, durationSeconds: 60, targetTempC: 20.0, description: 'Low shear incorporate.', ingredientsAdded: ['Shipton Mill Cake Flour'] }
      ]
    },
    depositingProgramme: { nozzleType: 'Loaf Tin Depositor D-02', depositWeightGrams: 410, depositToleranceGrams: 4, cycleTimeSec: 2.0 },
    bakingProgramme: {
      ovenType: 'TUNNEL',
      preheatTempC: 178,
      bakeTimeMinutes: 28,
      steamInjectionSeconds: 0,
      targetCoreTempC: 93.5,
      zones: [
        { zoneIndex: 1, name: 'Rise Zone', targetTempC: 178, fanSpeedPercent: 55, topHeatPercent: 70, bottomHeatPercent: 75 },
        { zoneIndex: 2, name: 'Set Zone', targetTempC: 172, fanSpeedPercent: 50, topHeatPercent: 65, bottomHeatPercent: 65 },
        { zoneIndex: 3, name: 'Crust Zone', targetTempC: 160, fanSpeedPercent: 40, topHeatPercent: 55, bottomHeatPercent: 50 }
      ]
    },
    coolingProgramme: { targetTunnelExitTempC: 22.0, dwellTimeMinutes: 35, airVelocityMs: 1.4 },
    decoratingProgramme: {
      icingThicknessMm: 1.5,
      icingToleranceMm: 0.2,
      requiresVisionClosedLoop: false,
      roboticPatterns: [
        { patternType: 'BORDER_WAVE', pointsCount: 20, nozzleSizeMm: 3, depositionPressureBar: 1.2, heightMm: 2, colorHex: '#FEF08A', icingMaterial: 'LEMON_FONDANT' }
      ]
    },
    packagingProgramme: { primaryPackType: 'TRAY_AND_SLEEVE', cartonsPerCase: 6, modifiedAtmosphereGas: 'N2 98%', targetNetWeightGrams: 420, labelFormatId: 'LBL-UK-LD-420G' },
    costing: { ingredientCostGbp: 2.65, labourCostGbp: 1.80, energyCostGbp: 1.20, packagingCostGbp: 1.40, wasteAllowanceGbp: 0.90, totalUnitCostGbp: 7.95, targetRetailGbp: 12.50 },
    allergens: ['WHEAT_GLUTEN', 'EGG', 'MILK'],
    qualityTolerances: { weightMinG: 410, weightMaxG: 430, heightMinMm: 80, heightMaxMm: 90, diameterMinMm: 215, diameterMaxMm: 225, browningDeltaEMax: 1.3, decorationAlignmentMinPercent: 98.0 }
  }
];

export const INITIAL_MACHINES: Machine[] = [
  {
    id: 'MACH-M04',
    name: 'Industrial Planetary Mixer M-04',
    code: 'M-04',
    department: 'MIXING',
    type: 'MIXER_PLANETARY',
    status: 'RUNNING',
    hygieneStatus: 'IN_PRODUCTION',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 184,
    speedTarget: 184,
    temperatureC: 19.4,
    loadPercent: 61,
    vibrationMmS: 0.84,
    powerKw: 14.8,
    runningHoursTotal: 1420,
    hoursUntilMaintenance: 80,
    oee: { availability: 96.2, performance: 92.8, quality: 98.7, overall: 88.3 },
    alarms: []
  },
  {
    id: 'MACH-D02',
    name: 'Volumetric Piston Depositor D-02',
    code: 'D-02',
    department: 'FORMING',
    type: 'DEPOSITOR',
    status: 'RUNNING',
    hygieneStatus: 'IN_PRODUCTION',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 28, // deposits/min
    speedTarget: 30,
    temperatureC: 20.2,
    loadPercent: 48,
    vibrationMmS: 0.42,
    powerKw: 6.2,
    runningHoursTotal: 980,
    hoursUntilMaintenance: 140,
    oee: { availability: 98.0, performance: 93.3, quality: 99.1, overall: 90.6 },
    alarms: []
  },
  {
    id: 'MACH-O07',
    name: 'Convection 3-Zone Tunnel Oven O-07',
    code: 'O-07',
    department: 'BAKING',
    type: 'TUNNEL_OVEN',
    status: 'RUNNING',
    hygieneStatus: 'IN_PRODUCTION',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 1.2, // m/min
    speedTarget: 1.2,
    temperatureC: 180.5,
    loadPercent: 88,
    vibrationMmS: 0.28,
    powerKw: 118.0,
    runningHoursTotal: 4680,
    hoursUntilMaintenance: 120,
    oee: { availability: 97.4, performance: 96.0, quality: 99.4, overall: 92.9 },
    alarms: []
  },
  {
    id: 'MACH-C02',
    name: 'Dynamic Air Cooling Tunnel C-02',
    code: 'C-02',
    department: 'COOLING',
    type: 'COOLING_TUNNEL',
    status: 'RUNNING',
    hygieneStatus: 'IN_PRODUCTION',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 0.9,
    speedTarget: 0.9,
    temperatureC: 12.8,
    loadPercent: 54,
    vibrationMmS: 0.35,
    powerKw: 24.5,
    runningHoursTotal: 2150,
    hoursUntilMaintenance: 220,
    oee: { availability: 99.2, performance: 98.1, quality: 99.8, overall: 97.1 },
    alarms: []
  },
  {
    id: 'MACH-R07',
    name: 'Precision 6-Axis Robotic Decorator R-07',
    code: 'R-07',
    department: 'DECORATING',
    type: 'ROBOTIC_DECORATOR',
    status: 'RUNNING',
    hygieneStatus: 'IN_PRODUCTION',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 120, // mm/s
    speedTarget: 120,
    temperatureC: 18.2,
    loadPercent: 66,
    vibrationMmS: 0.18,
    powerKw: 8.4,
    runningHoursTotal: 840,
    hoursUntilMaintenance: 160,
    oee: { availability: 95.0, performance: 94.2, quality: 98.9, overall: 88.5 },
    alarms: []
  },
  {
    id: 'MACH-V01',
    name: 'Dual-Camera High-Speed Vision QC Inspector V-01',
    code: 'V-01',
    department: 'DECORATING',
    type: 'VISION_QC',
    status: 'RUNNING',
    hygieneStatus: 'READY',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 45, // items/min
    speedTarget: 45,
    temperatureC: 21.0,
    loadPercent: 42,
    vibrationMmS: 0.08,
    powerKw: 3.2,
    runningHoursTotal: 1100,
    hoursUntilMaintenance: 300,
    oee: { availability: 99.8, performance: 99.2, quality: 99.9, overall: 98.9 },
    alarms: []
  },
  {
    id: 'MACH-P11',
    name: 'Automated Cartoner & Case Packer P-11',
    code: 'P-11',
    department: 'PACKAGING',
    type: 'CASE_PACKER',
    status: 'RUNNING',
    hygieneStatus: 'IN_PRODUCTION',
    safetyInterlockOk: true,
    currentRecipeId: 'REC-VS-001',
    currentBatchId: 'BATCH-82041',
    speedActual: 38, // packs/min
    speedTarget: 40,
    temperatureC: 22.4,
    loadPercent: 72,
    vibrationMmS: 0.52,
    powerKw: 18.6,
    runningHoursTotal: 3400,
    hoursUntilMaintenance: 90,
    oee: { availability: 94.8, performance: 95.0, quality: 99.2, overall: 89.3 },
    alarms: []
  }
];

export const INITIAL_BATCHES: ProductionBatch[] = [
  {
    id: 'BATCH-82041',
    orderId: 'ORD-820481',
    customerName: 'Waitrose & Partners / Marks & Spencer',
    recipeId: 'REC-VS-001',
    recipeCode: 'VS-001',
    recipeVersion: 14,
    productName: 'The Northshire Heritage Victoria Sponge',
    targetQuantity: 500,
    actualProducedQuantity: 342,
    rejectedQuantity: 3,
    stage: 'ROBOTIC_DECORATION',
    startTime: '07:30',
    scheduledEndTime: '10:45',
    progressPercent: 68.4,
    assignedMachines: {
      weighScale: 'SCALE-W01',
      mixer: 'M-04',
      depositor: 'D-02',
      oven: 'O-07',
      coolingTunnel: 'C-02',
      decorator: 'R-07',
      qcStation: 'V-01',
      packer: 'P-11'
    },
    allocatedLots: [
      { ingredientName: 'Shipton Mill Cake Flour', lotNumber: 'LOT-F-28471', allocatedWeightKg: 56.25, dispensedWeightKg: 56.24, withinTolerance: true },
      { ingredientName: 'Fine Caster Sugar', lotNumber: 'LOT-S-99120', allocatedWeightKg: 56.25, dispensedWeightKg: 56.26, withinTolerance: true },
      { ingredientName: 'West Country Butter 82%', lotNumber: 'LOT-B-77401', allocatedWeightKg: 56.25, dispensedWeightKg: 56.25, withinTolerance: true },
      { ingredientName: 'Liquid Whole Free-Range Egg', lotNumber: 'LOT-E-63029', allocatedWeightKg: 56.25, dispensedWeightKg: 56.23, withinTolerance: true },
      { ingredientName: 'Bourbon Pure Vanilla Extract', lotNumber: 'LOT-V-40192', allocatedWeightKg: 0.85, dispensedWeightKg: 0.851, withinTolerance: true },
      { ingredientName: 'Scottish Raspberry Compote', lotNumber: 'LOT-J-51203', allocatedWeightKg: 19.70, dispensedWeightKg: 19.71, withinTolerance: true },
      { ingredientName: 'Cornish Clotted Cream Buttercream', lotNumber: 'LOT-C-33821', allocatedWeightKg: 25.30, dispensedWeightKg: 25.29, withinTolerance: true }
    ],
    processTelemetry: {
      currentMixSpeedRpm: 184,
      currentMixTorqueNm: 84.2,
      mixElapsedTimeSec: 405,
      ovenChamberTempC: 180.5,
      productCoreTempC: 94.2,
      coolingTempC: 19.4,
      icingDepositThicknessMm: 2.48,
      visionPassRatePercent: 99.1
    },
    events: [
      { timestamp: '07:30:12', stage: 'QUEUED', description: 'Batch 82041 instantiated from Order ORD-820481 (500 units)', operator: 'Scheduler: M. Davies' },
      { timestamp: '07:35:40', stage: 'INGREDIENT_DISPENSE', description: 'Flour LOT-F-28471 & Sugar LOT-S-99120 dosed via Silo 03', operator: 'Auto-Dosing D-Sys' },
      { timestamp: '07:42:15', stage: 'INGREDIENT_DISPENSE', description: 'Butter LOT-B-77401 verified at Scale W-01 (56.25kg within ±0.02kg)', operator: 'Op: T. Higgins' },
      { timestamp: '07:48:00', stage: 'MIXING', description: 'Planetary Mixer M-04 started Recipe VS-14 mixing programme (3 stages)', operator: 'Op: T. Higgins' },
      { timestamp: '07:54:45', stage: 'MIXING', description: 'Mixing completed nominal. Batter temperature 20.4°C, bulk density 0.82 g/cm³', operator: 'Auto-Telemetry' },
      { timestamp: '07:58:20', stage: 'DEPOSITING', description: 'Transferred to Depositor D-02 hopper. Continuous deposit into 200mm sandwich tins', operator: 'Op: S. Wright' },
      { timestamp: '08:02:10', stage: 'BAKING', description: 'Tunnel Oven O-07 entrance. 3 heat zones (182°C / 176°C / 165°C)', operator: 'Auto-Oven' },
      { timestamp: '08:24:10', stage: 'COOLING', description: 'Exit oven. Core temperature 94.2°C. Entered Cooling Tunnel C-02', operator: 'CCP-02 Verified' },
      { timestamp: '09:02:10', stage: 'FILLING_ICING', description: 'Cakes cooled to 19.4°C. Sandwich split, raspberry compote spiral & buttercream injected', operator: 'Line 1 Form' },
      { timestamp: '09:12:00', stage: 'ROBOTIC_DECORATION', description: '6-Axis Robot R-07 executing 12-rosette top decoration with vision correction', operator: 'R-07 Controller' }
    ]
  },
  {
    id: 'BATCH-82042',
    orderId: 'ORD-820482',
    customerName: 'Sainsbury\'s Taste the Difference',
    recipeId: 'REC-BC-002',
    recipeCode: 'BC-002',
    recipeVersion: 8,
    productName: 'Belgian Dark Chocolate Fudge Layer Cake',
    targetQuantity: 400,
    actualProducedQuantity: 180,
    rejectedQuantity: 1,
    stage: 'BAKING',
    startTime: '08:15',
    scheduledEndTime: '11:30',
    progressPercent: 45.0,
    assignedMachines: {
      weighScale: 'SCALE-W02',
      mixer: 'M-02',
      depositor: 'D-01',
      oven: 'O-07',
      coolingTunnel: 'C-02',
      decorator: 'R-05',
      qcStation: 'V-01',
      packer: 'P-11'
    },
    allocatedLots: [],
    processTelemetry: {
      currentMixSpeedRpm: 0,
      currentMixTorqueNm: 0,
      mixElapsedTimeSec: 480,
      ovenChamberTempC: 175.0,
      productCoreTempC: 86.4,
      coolingTempC: 0,
      icingDepositThicknessMm: 0,
      visionPassRatePercent: 99.4
    },
    events: [
      { timestamp: '08:15:00', stage: 'QUEUED', description: 'Batch 82042 started for 400 Belgian Chocolate Cakes', operator: 'Scheduler' },
      { timestamp: '08:45:00', stage: 'BAKING', description: 'Baking in Zone 2 of Tunnel Oven', operator: 'Oven O-07' }
    ]
  },
  {
    id: 'BATCH-82043',
    orderId: 'ORD-820483',
    customerName: 'Fortnum & Mason Piccadilly',
    recipeId: 'REC-LD-004',
    recipeCode: 'LD-004',
    recipeVersion: 11,
    productName: 'Yorkshire Candied Lemon Drizzle Loaf',
    targetQuantity: 300,
    actualProducedQuantity: 0,
    rejectedQuantity: 0,
    stage: 'INGREDIENT_DISPENSE',
    startTime: '09:00',
    scheduledEndTime: '12:00',
    progressPercent: 12.0,
    assignedMachines: {
      weighScale: 'SCALE-W01',
      mixer: 'M-04',
      depositor: 'D-02',
      oven: 'O-07',
      coolingTunnel: 'C-02',
      decorator: 'R-07',
      qcStation: 'V-01',
      packer: 'P-11'
    },
    allocatedLots: [],
    processTelemetry: {
      currentMixSpeedRpm: 0,
      currentMixTorqueNm: 0,
      mixElapsedTimeSec: 0,
      ovenChamberTempC: 178,
      productCoreTempC: 0,
      coolingTempC: 0,
      icingDepositThicknessMm: 0,
      visionPassRatePercent: 100
    },
    events: [
      { timestamp: '09:00:00', stage: 'INGREDIENT_DISPENSE', description: 'Weighing station allocation in progress', operator: 'Op: T. Higgins' }
    ]
  }
];

export const INITIAL_ORDERS: ProductionOrder[] = [
  { id: 'ORD-820481', customer: 'Waitrose & Partners / Marks & Spencer', productName: 'The Northshire Heritage Victoria Sponge (500 units)', recipeId: 'REC-VS-001', quantity: 500, orderDate: '2026-09-20', deliveryDate: '2026-09-22', status: 'IN_PRODUCTION', priority: 'CRITICAL', batchId: 'BATCH-82041' },
  { id: 'ORD-820482', customer: 'Sainsbury\'s Taste the Difference', productName: 'Belgian Dark Chocolate Fudge Layer Cake (400 units)', recipeId: 'REC-BC-002', quantity: 400, orderDate: '2026-09-20', deliveryDate: '2026-09-22', status: 'IN_PRODUCTION', priority: 'HIGH', batchId: 'BATCH-82042' },
  { id: 'ORD-820483', customer: 'Fortnum & Mason Piccadilly', productName: 'Yorkshire Candied Lemon Drizzle Loaf (300 units)', recipeId: 'REC-LD-004', quantity: 300, orderDate: '2026-09-21', deliveryDate: '2026-09-23', status: 'IN_PRODUCTION', priority: 'HIGH', batchId: 'BATCH-82043' },
  { id: 'ORD-820484', customer: 'Harrods Food Hall Knightsbridge', productName: 'Heritage Stoneground Artisan Sourdough (600 units)', recipeId: 'REC-SD-003', quantity: 600, orderDate: '2026-09-21', deliveryDate: '2026-09-23', status: 'SCHEDULED', priority: 'NORMAL' },
  { id: 'ORD-820485', customer: 'Booths Supermarkets Northern England', productName: 'The Northshire Heritage Victoria Sponge (350 units)', recipeId: 'REC-VS-001', quantity: 350, orderDate: '2026-09-21', deliveryDate: '2026-09-24', status: 'PENDING', priority: 'NORMAL' }
];

export const INITIAL_CCPS: CCPMonitor[] = [
  {
    ccpNumber: 'CCP-01',
    name: 'Raw Flour & Sugar In-Line Sieve & Rare-Earth Magnet',
    hazardType: 'PHYSICAL',
    criticalLimit: '0.8mm mesh integrity, no metallic fragments > 0.5mm Fe / 0.8mm Non-Fe',
    currentValue: '100% Sieve Integrity OK / 0 Foreign Objects Detected',
    status: 'COMPLIANT',
    monitoringFrequency: 'Continuous with hourly verification',
    lastVerified: '08:00',
    verifierName: 'Quality Lead: J. Thorne'
  },
  {
    ccpNumber: 'CCP-02',
    name: 'Oven Core Thermal Kill Step (Sponge & Bread)',
    hazardType: 'MICROBIOLOGICAL',
    criticalLimit: 'Product Core Temperature ≥ 92.0°C for at least 120 seconds',
    currentValue: '94.2°C (Logged 08:24)',
    status: 'COMPLIANT',
    monitoringFrequency: 'Every baked batch (In-line optical IR & probe)',
    lastVerified: '08:24',
    verifierName: 'Automated Datalogger Logger-O7'
  },
  {
    ccpNumber: 'CCP-03',
    name: 'Post-Bake Rapid Cooling Dwell Zone',
    hazardType: 'MICROBIOLOGICAL',
    criticalLimit: 'Cool core from 94°C to < 20°C in ≤ 45 minutes to prevent spore germination',
    currentValue: '38 mins dwell → 19.4°C Exit',
    status: 'COMPLIANT',
    monitoringFrequency: 'Continuous tunnel telemetry',
    lastVerified: '09:02',
    verifierName: 'Sensor C02-TC4'
  },
  {
    ccpNumber: 'CCP-04',
    name: 'Allergen Changeover Line Washout & ATP Swab Validation',
    hazardType: 'ALLERGENIC',
    criticalLimit: 'ATP bioluminescence < 10 RLU; zero protein cross-contact residual',
    currentValue: '4 RLU (Pass) after Nut/Soya wash',
    status: 'COMPLIANT',
    monitoringFrequency: 'Every allergen switchover',
    lastVerified: '07:15',
    verifierName: 'Hygiene Supervisor: K. Patel'
  }
];

export const INITIAL_SPC_METRICS: SPCMetricSeries[] = [
  {
    parameterName: 'Victoria Sponge Unit Net Weight',
    unit: 'g',
    target: 450.0,
    ucl: 458.5,
    lcl: 441.5,
    usl: 465.0,
    lsl: 435.0,
    cpk: 1.64,
    readings: [
      { timestamp: '08:45', value: 449.2, batchId: 'BATCH-82041' },
      { timestamp: '08:50', value: 451.4, batchId: 'BATCH-82041' },
      { timestamp: '08:55', value: 450.1, batchId: 'BATCH-82041' },
      { timestamp: '09:00', value: 448.6, batchId: 'BATCH-82041' },
      { timestamp: '09:05', value: 452.0, batchId: 'BATCH-82041' },
      { timestamp: '09:10', value: 450.8, batchId: 'BATCH-82041' },
      { timestamp: '09:15', value: 449.9, batchId: 'BATCH-82041' },
      { timestamp: '09:20', value: 451.1, batchId: 'BATCH-82041' },
      { timestamp: '09:25', value: 450.4, batchId: 'BATCH-82041' }
    ]
  },
  {
    parameterName: 'Oven Core Exit Temperature',
    unit: '°C',
    target: 94.0,
    ucl: 96.0,
    lcl: 92.5,
    usl: 98.0,
    lsl: 92.0,
    cpk: 1.52,
    readings: [
      { timestamp: '08:45', value: 94.1, batchId: 'BATCH-82041' },
      { timestamp: '08:50', value: 94.4, batchId: 'BATCH-82041' },
      { timestamp: '08:55', value: 93.9, batchId: 'BATCH-82041' },
      { timestamp: '09:00', value: 94.3, batchId: 'BATCH-82041' },
      { timestamp: '09:05', value: 94.7, batchId: 'BATCH-82041' },
      { timestamp: '09:10', value: 94.2, batchId: 'BATCH-82041' },
      { timestamp: '09:15', value: 94.0, batchId: 'BATCH-82041' },
      { timestamp: '09:20', value: 94.5, batchId: 'BATCH-82041' }
    ]
  },
  {
    parameterName: 'Robotic Icing Layer Thickness',
    unit: 'mm',
    target: 2.50,
    ucl: 2.65,
    lcl: 2.35,
    usl: 2.70,
    lsl: 2.30,
    cpk: 1.78,
    readings: [
      { timestamp: '08:45', value: 2.48, batchId: 'BATCH-82041' },
      { timestamp: '08:50', value: 2.52, batchId: 'BATCH-82041' },
      { timestamp: '08:55', value: 2.49, batchId: 'BATCH-82041' },
      { timestamp: '09:00', value: 2.51, batchId: 'BATCH-82041' },
      { timestamp: '09:05', value: 2.53, batchId: 'BATCH-82041' },
      { timestamp: '09:10', value: 2.47, batchId: 'BATCH-82041' },
      { timestamp: '09:15', value: 2.50, batchId: 'BATCH-82041' },
      { timestamp: '09:20', value: 2.52, batchId: 'BATCH-82041' }
    ]
  }
];
