// Architectural Colour Mathematics & Lighting Physics Engine

export interface DaylightState {
  timeHours: number; // 6.0 to 21.0
  orientation: 'North Light' | 'South Light' | 'East Light' | 'West Light' | 'Artificial Warm' | 'Artificial Cool';
  brightness: number; // 0.2 to 1.3
  colorTemperatureK: number; // 2200K to 8000K
  tintFilter: string; // CSS color overlay
  shadowIntensity: number; // 0 to 1
  label: string;
}

export function calculateDaylight(time: number, orientation: string): DaylightState {
  // time from 6.0 (dawn) to 21.0 (night)
  const clampedTime = Math.max(6, Math.min(21, time));
  let label = 'Midday Daylight';
  let temp = 5500;
  let brightness = 1.0;
  let shadow = 0.3;
  let tint = 'rgba(255, 255, 255, 0)';

  if (clampedTime <= 7.5) {
    label = 'Dawn & Early Light';
    temp = 3200;
    brightness = 0.65;
    shadow = 0.6;
    tint = 'rgba(255, 210, 160, 0.18)';
  } else if (clampedTime <= 10.5) {
    label = 'Morning Sun';
    temp = 4800;
    brightness = 0.95;
    shadow = 0.4;
    tint = 'rgba(255, 240, 210, 0.08)';
  } else if (clampedTime <= 14.5) {
    label = 'Midday Overhead Light';
    temp = 6000;
    brightness = 1.1;
    shadow = 0.2;
    tint = 'rgba(235, 245, 255, 0.05)';
  } else if (clampedTime <= 17.5) {
    label = 'Afternoon Daylight';
    temp = 5200;
    brightness = 0.98;
    shadow = 0.35;
    tint = 'rgba(255, 245, 225, 0.06)';
  } else if (clampedTime <= 19.5) {
    label = 'Golden Hour';
    temp = 2800;
    brightness = 0.85;
    shadow = 0.75;
    tint = 'rgba(255, 175, 90, 0.24)';
  } else if (clampedTime <= 20.5) {
    label = 'Blue Hour Twilight';
    temp = 7500;
    brightness = 0.55;
    shadow = 0.85;
    tint = 'rgba(40, 80, 150, 0.28)';
  } else {
    label = 'Night & Interior Illumination';
    temp = 2600;
    brightness = 0.45;
    shadow = 0.9;
    tint = 'rgba(20, 25, 35, 0.42)';
  }

  // Apply orientation modifier
  if (orientation === 'North Light') {
    brightness *= 0.88;
    temp += 800; // cooler
    tint = 'rgba(160, 195, 230, 0.12)';
  } else if (orientation === 'South Light') {
    brightness *= 1.12;
    temp -= 300; // warmer direct
    tint = 'rgba(255, 240, 200, 0.12)';
  } else if (orientation === 'East Light') {
    if (clampedTime < 12) brightness *= 1.15;
    else brightness *= 0.85;
  } else if (orientation === 'West Light') {
    if (clampedTime >= 15) brightness *= 1.2;
    else brightness *= 0.85;
  } else if (orientation === 'Artificial Warm') {
    temp = 2700;
    brightness = 0.95;
    tint = 'rgba(255, 205, 130, 0.22)';
  } else if (orientation === 'Artificial Cool') {
    temp = 4000;
    brightness = 1.0;
    tint = 'rgba(210, 235, 255, 0.12)';
  }

  return {
    timeHours: clampedTime,
    orientation: orientation as any,
    brightness,
    colorTemperatureK: temp,
    tintFilter: tint,
    shadowIntensity: shadow,
    label
  };
}

// Adjust Hex Color based on light state
export function simulateColorUnderLight(hex: string, daylight: DaylightState, finish: string = 'Matt'): string {
  // Parse hex
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);

  if (isNaN(r) || isNaN(g) || isNaN(b)) return hex;

  // Temperature shift
  const tempRatio = daylight.colorTemperatureK / 5500;
  let rShift = r * (tempRatio < 1 ? 1 + (1 - tempRatio) * 0.4 : 1 - (tempRatio - 1) * 0.15);
  let gShift = g * (tempRatio < 1 ? 1 + (1 - tempRatio) * 0.1 : 1);
  let bShift = b * (tempRatio > 1 ? 1 + (tempRatio - 1) * 0.45 : 1 - (1 - tempRatio) * 0.35);

  // Brightness factor
  rShift *= daylight.brightness;
  gShift *= daylight.brightness;
  bShift *= daylight.brightness;

  // Finish reflectance
  if (finish === 'Gloss') {
    rShift *= 1.08;
    gShift *= 1.08;
    bShift *= 1.08;
  } else if (finish === 'Satin') {
    rShift *= 1.04;
    gShift *= 1.04;
    bShift *= 1.04;
  }

  const finalR = Math.max(0, Math.min(255, Math.round(rShift)));
  const finalG = Math.max(0, Math.min(255, Math.round(gShift)));
  const finalB = Math.max(0, Math.min(255, Math.round(bShift)));

  return `#${((1 << 24) + (finalR << 16) + (finalG << 8) + finalB).toString(16).slice(1).toUpperCase()}`;
}

// Paint Calculator Engine
export interface PaintCalculationInput {
  roomWidthM: number;
  roomLengthM: number;
  wallHeightM: number;
  doorsCount: number;
  windowsCount: number;
  ceilingIncluded: boolean;
  coats: number;
  coverageM2PerLitre: number; // default 12 m2/L
  wasteMarginPercent: number; // default 10%
  pricePer2_5L: number; // e.g., 68.00
}

export interface PaintCalculationResult {
  wallGrossAreaSqM: number;
  openingsDeductionSqM: number;
  wallNetAreaSqM: number;
  ceilingAreaSqM: number;
  totalAreaSqM: number;
  litresRaw: number;
  litresWithWaste: number;
  recommendedTins: {
    size: '20L' | '10L' | '5L' | '2.5L' | '1L';
    count: number;
    volumeTotal: number;
  }[];
  totalLitresDelivered: number;
  estimatedCostGbp: number;
}

export function calculatePaintRequirement(input: PaintCalculationInput): PaintCalculationResult {
  const perimeter = 2 * (input.roomWidthM + input.roomLengthM);
  const wallGrossArea = perimeter * input.wallHeightM;
  const doorsArea = input.doorsCount * 1.9; // standard 0.85m x 2.1m ~ 1.9m2
  const windowsArea = input.windowsCount * 1.8; // standard 1.2m x 1.5m ~ 1.8m2
  const openingsDeduction = doorsArea + windowsArea;
  const wallNetArea = Math.max(0, wallGrossArea - openingsDeduction);
  const ceilingArea = input.ceilingIncluded ? input.roomWidthM * input.roomLengthM : 0;
  const totalArea = (wallNetArea + ceilingArea) * input.coats;

  const litresRaw = totalArea / input.coverageM2PerLitre;
  const litresWithWaste = litresRaw * (1 + input.wasteMarginPercent / 100);

  // Calculate optimal container breakdown (20L, 10L, 5L, 2.5L, 1L)
  let remainingLitres = litresWithWaste;
  const tins: { size: '20L' | '10L' | '5L' | '2.5L' | '1L'; count: number; volumeTotal: number }[] = [];

  if (remainingLitres >= 18) {
    const count20 = Math.floor(remainingLitres / 20);
    if (count20 > 0) {
      tins.push({ size: '20L', count: count20, volumeTotal: count20 * 20 });
      remainingLitres -= count20 * 20;
    }
  }

  if (remainingLitres >= 8) {
    const count10 = Math.floor(remainingLitres / 10);
    if (count10 > 0) {
      tins.push({ size: '10L', count: count10, volumeTotal: count10 * 10 });
      remainingLitres -= count10 * 10;
    }
  }

  if (remainingLitres >= 4) {
    const count5 = Math.floor(remainingLitres / 5);
    if (count5 > 0) {
      tins.push({ size: '5L', count: count5, volumeTotal: count5 * 5 });
      remainingLitres -= count5 * 5;
    }
  }

  if (remainingLitres >= 2) {
    const count2_5 = Math.ceil(remainingLitres / 2.5);
    tins.push({ size: '2.5L', count: count2_5, volumeTotal: count2_5 * 2.5 });
    remainingLitres = 0;
  } else if (remainingLitres > 0) {
    const count1 = Math.ceil(remainingLitres / 1);
    tins.push({ size: '1L', count: count1, volumeTotal: count1 * 1 });
    remainingLitres = 0;
  }

  const totalLitresDelivered = tins.reduce((sum, t) => sum + t.volumeTotal, 0);
  const costPerLitreApprox = input.pricePer2_5L / 2.5;
  const estimatedCostGbp = Math.round(totalLitresDelivered * costPerLitreApprox);

  return {
    wallGrossAreaSqM: Math.round(wallGrossArea * 10) / 10,
    openingsDeductionSqM: Math.round(openingsDeduction * 10) / 10,
    wallNetAreaSqM: Math.round(wallNetArea * 10) / 10,
    ceilingAreaSqM: Math.round(ceilingArea * 10) / 10,
    totalAreaSqM: Math.round(totalArea * 10) / 10,
    litresRaw: Math.round(litresRaw * 10) / 10,
    litresWithWaste: Math.round(litresWithWaste * 10) / 10,
    recommendedTins: tins,
    totalLitresDelivered,
    estimatedCostGbp
  };
}
