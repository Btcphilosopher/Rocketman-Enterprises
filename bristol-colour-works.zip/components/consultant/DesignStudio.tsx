'use client';

import React, { useState } from 'react';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { MessageSquare, Camera, Sparkles, Sliders, Calendar, ArrowRight, Check, RefreshCw, Send, User } from 'lucide-react';

export function DesignStudio() {
  const { setCurrentTab, setSelectedColour, setAccentColour } = useApp();

  const [activeTab, setActiveTab] = useState<'questionnaire' | 'consultant' | 'photo' | 'booking'>('questionnaire');

  // Questionnaire State
  const [qStep, setQStep] = useState<number>(1);
  const [qAnswers, setQAnswers] = useState({
    room: 'Drawing Room / Living',
    lightAmount: 'Moderate / Overcast Diffused',
    direction: 'North-East Aspect',
    materials: 'Limestone Fireplace & Dark Oak',
    atmosphere: 'Architectural & Enveloping'
  });

  // AI Consultant State
  const [userQuery, setUserQuery] = useState<string>('I have a north-facing Georgian drawing room with walnut furniture and a limestone fireplace. What would you specify?');
  const [isConsultantLoading, setIsConsultantLoading] = useState<boolean>(false);
  const [consultantResponse, setConsultantResponse] = useState<string | null>(
    'For a north-facing Georgian room with walnut and limestone, cool northern light will drain cold synthetic greys. We specify BR-001 Clifton Honey Limestone on walls to amplify warmth, paired with BR-061 Bristol Cream on the ceiling to eliminate demarcation shadows. To celebrate the walnut grain, finish joinery and bookcases in BR-041 Harbourside Blue (Architectural Eggshell 15%). We recommend ordering 100ml sample pots to observe the morning and evening light transition.'
  );

  // Photo Analysis State
  const [isPhotoLoading, setIsPhotoLoading] = useState<boolean>(false);
  const [photoAnalysisResult, setPhotoAnalysisResult] = useState<any>(null);

  // Booking Form State
  const [bookingType, setBookingType] = useState<string>('60-Minute Architectural Colour Study');
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const handleConsultantSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userQuery.trim()) return;

    setIsConsultantLoading(true);
    try {
      const res = await fetch('/api/consultant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userQuery, roomContext: qAnswers })
      });
      const data = await res.json();
      setConsultantResponse(data.advice || 'Architectural recommendations processed.');
    } catch (err) {
      setConsultantResponse('For your specified space, we recommend pairing BR-001 Clifton Honey Limestone with BR-061 Bristol Cream and BR-041 Harbourside Blue for joinery accents.');
    } finally {
      setIsConsultantLoading(false);
    }
  };

  const handleSimulatePhotoUpload = () => {
    setIsPhotoLoading(true);
    setTimeout(() => {
      setPhotoAnalysisResult({
        detectedElements: ['Georgian Lime Plaster Wall', '12-Pane Sash Window', 'Aged Oak Floorboards', 'Cast Iron Grate'],
        paletteProposal: [
          { code: 'BR-001', name: 'Clifton Honey Limestone', role: 'Main Walls' },
          { code: 'BR-061', name: 'Bristol Cream', role: 'Ceiling' },
          { code: 'BR-041', name: 'Harbourside Blue', role: 'Window Reveals & Joinery' },
          { code: 'BR-072', name: 'Temple Meads Iron', role: 'Fireplace Surround & Skirting' }
        ],
        insight: 'The photograph exhibits balanced morning eastern light. Warm mineral ochres will harmonize with the oak timber while deep charcoal joinery stabilizes the visual scale.'
      });
      setIsPhotoLoading(false);
    }, 1200);
  };

  const getColour = (code: string) => ALL_COLOURS.find((c) => c.code === code) || ALL_COLOURS[0];

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
              Colour Design Studio
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
              Architectural Colour Consultation
            </h1>
            <p className="text-xs sm:text-sm text-[#69706D] max-w-xl">
              Professional colour planning, questionnaire-led design directions, AI consultant inquiries, and bespoke studio consultations.
            </p>
          </div>

          {/* Studio Navigation Tabs */}
          <div className="flex gap-1.5 bg-[#E6E4DD] p-1 rounded border border-[#202426]/10 text-xs font-mono-tech">
            {[
              { id: 'questionnaire', label: 'Find My Colour' },
              { id: 'consultant', label: 'AI Colour Consultant' },
              { id: 'photo', label: 'Photo Analysis' },
              { id: 'booking', label: 'Book Consultation' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
                  activeTab === tab.id
                    ? 'bg-[#202426] text-white shadow-xs'
                    : 'text-[#202426] hover:bg-white/50'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab 1: "Find My Colour" 5-Step Questionnaire (Section 44) */}
        {activeTab === 'questionnaire' && (
          <div className="bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-10 space-y-8 shadow-xs">
            
            <div className="flex items-center justify-between border-b border-[#202426]/10 pb-4">
              <div>
                <span className="text-xs font-mono-tech text-[#274F61] uppercase tracking-wider block">
                  Intelligent Specification Questionnaire
                </span>
                <h3 className="text-2xl font-serif-luxury font-semibold text-[#181B1C]">
                  Step {qStep} of 5: {qStep === 1 ? 'Room Typology' : (qStep === 2 ? 'Natural Light Levels' : (qStep === 3 ? 'Window Orientation' : (qStep === 4 ? 'Key Materials & Stone' : 'Desired Atmosphere')))}
                </h3>
              </div>
              <span className="text-xs font-mono-tech text-[#69706D]">
                Step {qStep}/5
              </span>
            </div>

            {/* Step 1: Room Typology */}
            {qStep === 1 && (
              <div className="space-y-4 font-mono-tech text-xs">
                <p className="text-[#69706D]">What room are you specifying?</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {['Drawing Room / Living', 'Formal Dining Room', 'Master Bedroom', 'Kitchen & Breakfast Room', 'Study / Library', 'Hallway & Staircase'].map((rm) => (
                    <button
                      key={rm}
                      onClick={() => {
                        setQAnswers({ ...qAnswers, room: rm });
                        setQStep(2);
                      }}
                      className={`p-4 rounded border text-left transition-all cursor-pointer ${
                        qAnswers.room === rm ? 'bg-[#202426] text-white border-[#202426]' : 'bg-[#F2EEE5]/60 hover:bg-[#E6E4DD]'
                      }`}
                    >
                      <span className="font-semibold block">{rm}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Natural Light */}
            {qStep === 2 && (
              <div className="space-y-4 font-mono-tech text-xs">
                <p className="text-[#69706D]">How much natural daylight does the space receive?</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {['Bright / Unobstructed All Day', 'Moderate / Overcast Diffused', 'Low / Shaded / Basement Level'].map((lt) => (
                    <button
                      key={lt}
                      onClick={() => {
                        setQAnswers({ ...qAnswers, lightAmount: lt });
                        setQStep(3);
                      }}
                      className={`p-4 rounded border text-left transition-all cursor-pointer ${
                        qAnswers.lightAmount === lt ? 'bg-[#202426] text-white border-[#202426]' : 'bg-[#F2EEE5]/60 hover:bg-[#E6E4DD]'
                      }`}
                    >
                      <span className="font-semibold block">{lt}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 3: Direction */}
            {qStep === 3 && (
              <div className="space-y-4 font-mono-tech text-xs">
                <p className="text-[#69706D]">Which direction do the main windows face?</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {['North / North-East', 'South / South-West', 'East (Morning Sun)', 'West (Afternoon Sun)'].map((dir) => (
                    <button
                      key={dir}
                      onClick={() => {
                        setQAnswers({ ...qAnswers, direction: dir });
                        setQStep(4);
                      }}
                      className={`p-4 rounded border text-left transition-all cursor-pointer ${
                        qAnswers.direction === dir ? 'bg-[#202426] text-white border-[#202426]' : 'bg-[#F2EEE5]/60 hover:bg-[#E6E4DD]'
                      }`}
                    >
                      <span className="font-semibold block">{dir}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 4: Materials */}
            {qStep === 4 && (
              <div className="space-y-4 font-mono-tech text-xs">
                <p className="text-[#69706D]">What key architectural materials are present in the room?</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {['Limestone Fireplace & Dark Oak', 'Pennant Stone & Brass', 'Red Brick & Cast Iron', 'White Ash & Polished Concrete', 'Linen Textiles & Bleached Timber'].map((mat) => (
                    <button
                      key={mat}
                      onClick={() => {
                        setQAnswers({ ...qAnswers, materials: mat });
                        setQStep(5);
                      }}
                      className={`p-4 rounded border text-left transition-all cursor-pointer ${
                        qAnswers.materials === mat ? 'bg-[#202426] text-white border-[#202426]' : 'bg-[#F2EEE5]/60 hover:bg-[#E6E4DD]'
                      }`}
                    >
                      <span className="font-semibold block">{mat}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 5: Desired Atmosphere & 3 Curated Design Directions */}
            {qStep === 5 && (
              <div className="space-y-6 font-mono-tech text-xs">
                <div className="space-y-2">
                  <p className="text-[#69706D]">Select desired atmosphere:</p>
                  <div className="flex flex-wrap gap-2">
                    {['Classic & Balanced', 'Quiet & Mineral', 'Architectural & Enveloping', 'Warm & Radiant'].map((atm) => (
                      <button
                        key={atm}
                        onClick={() => setQAnswers({ ...qAnswers, atmosphere: atm })}
                        className={`px-3 py-1.5 rounded border cursor-pointer ${
                          qAnswers.atmosphere === atm ? 'bg-[#202426] text-white' : 'bg-[#F2EEE5]'
                        }`}
                      >
                        {atm}
                      </button>
                    ))}
                  </div>
                </div>

                {/* 3 Resulting Design Directions */}
                <div className="space-y-4 pt-4 border-t border-[#202426]/10">
                  <h4 className="text-sm font-bold uppercase text-[#202426]">
                    3 Recommended Design Directions for Your Space
                  </h4>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    
                    {/* Direction 1: The Clifton Mineral Harmony */}
                    <div className="bg-[#F2EEE5] p-4 rounded-lg border border-[#202426]/15 space-y-3">
                      <span className="text-[10px] uppercase text-[#274F61] font-bold block">Direction 01</span>
                      <h5 className="text-base font-serif-luxury font-semibold text-[#181B1C]">The Clifton Mineral Balance</h5>
                      <p className="text-[11px] text-[#69706D]">Warm honey walls and cream ceilings to maximize light reflection without glare.</p>
                      <div className="flex items-center gap-1.5 pt-1">
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#D7C4A5' }} title="BR-001" />
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#F2EEE5' }} title="BR-061" />
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#7E9181' }} title="BR-032" />
                        <span className="text-[10px] text-[#202426]">BR-001 · BR-061 · BR-032</span>
                      </div>
                      <button
                        onClick={() => setCurrentTab('designer')}
                        className="w-full py-2 bg-[#202426] text-white rounded text-[10px] uppercase font-semibold hover:bg-[#274F61]"
                      >
                        Try Direction in Room Designer
                      </button>
                    </div>

                    {/* Direction 2: The Deep Maritime Enclosure */}
                    <div className="bg-[#F2EEE5] p-4 rounded-lg border border-[#202426]/15 space-y-3">
                      <span className="text-[10px] uppercase text-[#274F61] font-bold block">Direction 02</span>
                      <h5 className="text-base font-serif-luxury font-semibold text-[#181B1C]">Deep Harbourside Enclosure</h5>
                      <p className="text-[11px] text-[#69706D]">Enveloping deep blue walls with limestone fireplace contrast and bronze accents.</p>
                      <div className="flex items-center gap-1.5 pt-1">
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#274F61' }} title="BR-041" />
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#E6E4DD' }} title="BR-062" />
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#D5AA6D' }} title="BR-057" />
                        <span className="text-[10px] text-[#202426]">BR-041 · BR-062 · BR-057</span>
                      </div>
                      <button
                        onClick={() => setCurrentTab('designer')}
                        className="w-full py-2 bg-[#202426] text-white rounded text-[10px] uppercase font-semibold hover:bg-[#274F61]"
                      >
                        Try Direction in Room Designer
                      </button>
                    </div>

                    {/* Direction 3: The Cotham Walled Garden */}
                    <div className="bg-[#F2EEE5] p-4 rounded-lg border border-[#202426]/15 space-y-3">
                      <span className="text-[10px] uppercase text-[#274F61] font-bold block">Direction 03</span>
                      <h5 className="text-base font-serif-luxury font-semibold text-[#181B1C]">Cotham Walled Sanctuary</h5>
                      <p className="text-[11px] text-[#69706D]">Serene olive tones paired with warm quarry grey woodwork and soft linen.</p>
                      <div className="flex items-center gap-1.5 pt-1">
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#6B755E' }} title="BR-035" />
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#C0B7A6' }} title="BR-008" />
                        <div className="w-5 h-5 rounded-xs" style={{ backgroundColor: '#F2EEE5' }} title="BR-061" />
                        <span className="text-[10px] text-[#202426]">BR-035 · BR-008 · BR-061</span>
                      </div>
                      <button
                        onClick={() => setCurrentTab('designer')}
                        className="w-full py-2 bg-[#202426] text-white rounded text-[10px] uppercase font-semibold hover:bg-[#274F61]"
                      >
                        Try Direction in Room Designer
                      </button>
                    </div>

                  </div>
                </div>

                <div className="pt-2">
                  <button
                    onClick={() => setQStep(1)}
                    className="text-[#274F61] hover:underline cursor-pointer flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Restart Questionnaire</span>
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* Tab 2: AI Architectural Consultant (Section 45) */}
        {activeTab === 'consultant' && (
          <div className="bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-8 space-y-6 shadow-xs font-mono-tech">
            
            <div className="border-b border-[#202426]/10 pb-4 space-y-1">
              <span className="text-xs uppercase text-[#274F61] font-bold">
                Bristol Studio Colour Intelligence
              </span>
              <h3 className="text-2xl font-serif-luxury font-semibold text-[#181B1C]">
                Digital Colour Consultant
              </h3>
              <p className="text-xs text-[#69706D] font-sans">
                Describe your room aspect, materials, ceiling height, and lighting challenges for an architectural recommendation grounded in our 96-colour formulation library.
              </p>
            </div>

            {/* Consultant Chat Console */}
            <form onSubmit={handleConsultantSubmit} className="space-y-3">
              <div className="space-y-1">
                <label className="text-[11px] text-[#69706D] uppercase block">
                  Describe Your Room & Architectural Conditions
                </label>
                <textarea
                  rows={3}
                  value={userQuery}
                  onChange={(e) => setUserQuery(e.target.value)}
                  placeholder="e.g. 'I have a north-facing Georgian drawing room with walnut furniture, limestone fireplace, and 3.2m ceilings. What would you specify?'"
                  className="w-full p-3 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none focus:border-[#202426]"
                />
              </div>

              <button
                type="submit"
                disabled={isConsultantLoading}
                className="px-5 py-2.5 bg-[#202426] hover:bg-[#274F61] disabled:bg-gray-400 text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors flex items-center gap-2 cursor-pointer"
              >
                {isConsultantLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                <span>{isConsultantLoading ? 'Consulting Laboratory Archives...' : 'Request Architectural Specification'}</span>
              </button>
            </form>

            {/* Consultant Output */}
            {consultantResponse && (
              <div className="p-5 bg-[#F2EEE5] rounded-lg border border-[#202426]/20 space-y-3 animate-in fade-in duration-300">
                <div className="flex items-center gap-2 border-b border-[#202426]/15 pb-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-600" />
                  <span className="text-xs font-bold text-[#181B1C] uppercase">
                    Bristol Colour Works Specification Rationale
                  </span>
                </div>
                <p className="text-xs text-[#202426]/90 leading-relaxed font-sans whitespace-pre-line">
                  {consultantResponse}
                </p>
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() => setCurrentTab('designer')}
                    className="px-3 py-1.5 bg-[#202426] text-white text-[11px] rounded hover:bg-[#274F61] cursor-pointer"
                  >
                    Load in Room Designer
                  </button>
                  <button
                    onClick={() => setCurrentTab('explorer')}
                    className="px-3 py-1.5 bg-white text-[#202426] border border-[#202426]/20 text-[11px] rounded hover:bg-[#E6E4DD] cursor-pointer"
                  >
                    View Swatches
                  </button>
                </div>
              </div>
            )}

          </div>
        )}

        {/* Tab 3: Photo Analysis (Section 46) */}
        {activeTab === 'photo' && (
          <div className="bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-8 space-y-6 shadow-xs font-mono-tech">
            
            <div className="border-b border-[#202426]/10 pb-4 space-y-1">
              <span className="text-xs uppercase text-[#274F61] font-bold">
                Image-Based Room Analysis
              </span>
              <h3 className="text-2xl font-serif-luxury font-semibold text-[#181B1C]">
                Upload Interior Photo
              </h3>
              <p className="text-xs text-[#69706D] font-sans">
                Our vision engine identifies walls, timber floorboards, stone hearths, and natural light vectors to propose compatible paint formulas.
              </p>
            </div>

            {/* Photo Upload Box */}
            <div className="border-2 border-dashed border-[#202426]/20 p-8 rounded-lg text-center space-y-4 bg-[#F2EEE5]/40">
              <Camera className="w-8 h-8 mx-auto text-[#69706D]" />
              <div className="space-y-1">
                <p className="text-xs font-semibold text-[#181B1C]">Upload a high-resolution room photograph</p>
                <p className="text-[10px] text-[#69706D]">JPEG or PNG up to 10MB · Natural daytime illumination recommended</p>
              </div>

              <button
                onClick={handleSimulatePhotoUpload}
                disabled={isPhotoLoading}
                className="px-4 py-2 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors cursor-pointer"
              >
                {isPhotoLoading ? 'Analyzing Structural Light...' : 'Analyze Sample Georgian Room Photo'}
              </button>
            </div>

            {/* Analysis Result */}
            {photoAnalysisResult && (
              <div className="p-5 bg-[#F2EEE5] rounded-lg border border-[#202426]/20 space-y-4 animate-in fade-in duration-300">
                <div className="flex items-center justify-between border-b border-[#202426]/15 pb-2">
                  <span className="text-xs font-bold text-[#181B1C] uppercase">
                    Detected Architectural Elements
                  </span>
                  <span className="text-[10px] text-[#274F61]">Digital Design Assistance</span>
                </div>

                <div className="flex flex-wrap gap-1.5">
                  {photoAnalysisResult.detectedElements.map((el: string) => (
                    <span key={el} className="px-2.5 py-1 bg-white border border-[#202426]/10 text-xs rounded text-[#181B1C]">
                      {el}
                    </span>
                  ))}
                </div>

                <div className="space-y-2 pt-2">
                  <span className="text-[11px] uppercase text-[#69706D] block">
                    Proposed Architectural Palette:
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                    {photoAnalysisResult.paletteProposal.map((prop: any) => {
                      const c = getColour(prop.code);
                      return (
                        <div key={prop.code} className="p-3 bg-white rounded border border-[#202426]/10 space-y-1.5">
                          <div className="w-full h-12 rounded-xs border border-black/10" style={{ backgroundColor: c.hex }} />
                          <span className="font-bold text-xs text-[#181B1C] block">{prop.code}</span>
                          <span className="text-[10px] text-[#69706D] block">{prop.role}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <p className="text-xs text-[#202426]/90 leading-relaxed font-sans pt-1">
                  {photoAnalysisResult.insight}
                </p>
              </div>
            )}

          </div>
        )}

        {/* Tab 4: Studio Consultation Booking (Section 83) */}
        {activeTab === 'booking' && (
          <div className="bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-10 space-y-6 shadow-xs font-mono-tech">
            
            <div className="border-b border-[#202426]/10 pb-4 space-y-1">
              <span className="text-xs uppercase text-[#274F61] font-bold">
                Bespoke Design Service
              </span>
              <h3 className="text-2xl font-serif-luxury font-semibold text-[#181B1C]">
                Book an Architectural Colour Consultation
              </h3>
              <p className="text-xs text-[#69706D] font-sans">
                Meet with our senior colour consultants at our Underfall Yard Studio or via remote video link.
              </p>
            </div>

            {bookingSuccess ? (
              <div className="text-center py-10 space-y-3">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-bold text-[#181B1C]">Consultation Request Received</h4>
                <p className="text-xs text-[#69706D]">A member of our design practice will contact you within 24 hours to confirm date and room plans.</p>
              </div>
            ) : (
              <form onSubmit={(e) => { e.preventDefault(); setBookingSuccess(true); }} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {[
                    { title: '30-Minute Single Room Study', price: '£75' },
                    { title: '60-Minute Architectural Colour Study', price: '£150' },
                    { title: 'Full House / Historic Interior', price: '£350' }
                  ].map((svc) => (
                    <button
                      key={svc.title}
                      type="button"
                      onClick={() => setBookingType(svc.title)}
                      className={`p-3 rounded border text-left transition-colors cursor-pointer ${
                        bookingType === svc.title ? 'bg-[#202426] text-white border-[#202426]' : 'bg-[#F2EEE5]/60 hover:bg-[#E6E4DD]'
                      }`}
                    >
                      <span className="font-semibold block">{svc.title}</span>
                      <span className="block text-[10px] opacity-80 pt-1">{svc.price} fee redeemable against paint orders</span>
                    </button>
                  ))}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="space-y-1">
                    <label className="text-[10px] text-[#69706D] uppercase">Full Name</label>
                    <input type="text" required placeholder="e.g. Eleanor Croft" className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-[#69706D] uppercase">Email Address</label>
                    <input type="email" required placeholder="eleanor@domain.co.uk" className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded" />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-[#69706D] uppercase">Property Details & Objectives</label>
                  <textarea rows={3} placeholder="Describe building period, location, room dimensions, and desired feel..." className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded" />
                </div>

                <button
                  type="submit"
                  className="px-6 py-3 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors cursor-pointer"
                >
                  Confirm Consultation Request
                </button>
              </form>
            )}

          </div>
        )}

      </div>
    </section>
  );
}
