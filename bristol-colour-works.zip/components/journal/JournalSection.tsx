'use client';

import React, { useState } from 'react';
import { JOURNAL_ARTICLES, JournalArticle } from '@/data/journal';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { BookOpen, Clock, ArrowRight, ArrowLeft, User } from 'lucide-react';

export function JournalSection() {
  const { setCurrentTab, setSelectedColour } = useApp();
  const [selectedArticle, setSelectedArticle] = useState<JournalArticle | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Light & Atmosphere', 'Materiality', 'Architectural Theory', 'Case Study'];

  const filteredArticles = JOURNAL_ARTICLES.filter(
    (a) => activeCategory === 'All' || a.category === activeCategory
  );

  const getColour = (code: string) => ALL_COLOURS.find((c) => c.code === code) || ALL_COLOURS[0];

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Article Reader View */}
        {selectedArticle ? (
          <div className="max-w-4xl mx-auto bg-white rounded-xl border border-[#202426]/15 p-6 sm:p-12 space-y-8 shadow-sm">
            <button
              onClick={() => setSelectedArticle(null)}
              className="flex items-center gap-2 text-xs font-mono-tech text-[#69706D] hover:text-[#181B1C] transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Journal Index</span>
            </button>

            <div className="space-y-3 border-b border-[#202426]/10 pb-6">
              <div className="flex items-center gap-3 text-xs font-mono-tech text-[#69706D]">
                <span>{selectedArticle.category}</span>
                <span>·</span>
                <span>{selectedArticle.readTime}</span>
                <span>·</span>
                <span>Published {selectedArticle.publishDate}</span>
              </div>

              <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C] leading-tight">
                {selectedArticle.title}
              </h1>

              <p className="text-base sm:text-lg text-[#69706D] font-serif italic">
                {selectedArticle.subtitle}
              </p>

              <div className="pt-2 text-xs font-mono-tech text-[#274F61] flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />
                <span>By {selectedArticle.author} · {selectedArticle.authorRole}</span>
              </div>
            </div>

            {/* Article Content */}
            <div className="space-y-6 text-sm sm:text-base text-[#202426]/90 leading-relaxed font-serif">
              {selectedArticle.content.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            {/* Related Colours */}
            <div className="pt-8 border-t border-[#202426]/10 space-y-3">
              <h4 className="text-xs font-mono-tech font-bold uppercase text-[#202426]">
                Related Formulations in This Essay:
              </h4>
              <div className="flex flex-wrap gap-3">
                {selectedArticle.relatedColours.map((code) => {
                  const c = getColour(code);
                  return (
                    <div
                      key={code}
                      onClick={() => {
                        setSelectedColour(c);
                        setCurrentTab('explorer');
                      }}
                      className="p-2.5 bg-[#F2EEE5] rounded border border-[#202426]/15 flex items-center gap-2.5 hover:border-[#202426] transition-colors cursor-pointer"
                    >
                      <div className="w-5 h-5 rounded-xs border border-black/15 shadow-xs" style={{ backgroundColor: c.hex }} />
                      <div className="text-xs font-mono-tech">
                        <span className="font-bold text-[#181B1C] block">{c.code}</span>
                        <span className="text-[#69706D] text-[10px]">{c.name}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="border-b border-[#202426]/10 pb-6 space-y-2">
              <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
                Architectural Editorial
              </span>
              <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
                The Bristol Colour Journal
              </h1>
              <p className="text-xs sm:text-sm text-[#69706D] max-w-2xl leading-relaxed">
                Essays on British daylight physics, oolitic limestone chemistry, Brunel’s engineering palettes, and the architecture of colour.
              </p>
            </div>

            {/* Categories */}
            <div className="flex flex-wrap gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3 py-1.5 rounded text-xs font-mono-tech transition-colors cursor-pointer ${
                    activeCategory === cat
                      ? 'bg-[#202426] text-white'
                      : 'bg-white text-[#202426] border border-[#202426]/15 hover:border-[#202426]'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Articles Grid (12 Articles) */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredArticles.map((article) => (
                <article
                  key={article.id}
                  onClick={() => setSelectedArticle(article)}
                  className="bg-white rounded-lg border border-[#202426]/15 overflow-hidden flex flex-col justify-between hover:shadow-lg transition-all cursor-pointer group"
                >
                  <div className="p-6 space-y-3">
                    <div className="flex items-center justify-between text-[11px] font-mono-tech text-[#69706D]">
                      <span>{article.category}</span>
                      <span>{article.readTime}</span>
                    </div>

                    <h3 className="text-xl font-serif-luxury font-semibold text-[#181B1C] group-hover:text-[#274F61] transition-colors leading-snug">
                      {article.title}
                    </h3>

                    <p className="text-xs text-[#202426]/75 leading-relaxed font-sans line-clamp-3">
                      {article.excerpt}
                    </p>
                  </div>

                  <div className="p-6 pt-0 border-t border-[#202426]/10 flex items-center justify-between text-xs font-mono-tech text-[#274F61]">
                    <span>By {article.author}</span>
                    <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                      Read Essay <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </article>
              ))}
            </div>
          </>
        )}

      </div>
    </section>
  );
}
