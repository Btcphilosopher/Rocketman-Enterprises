'use client';

import React, { useState, useMemo } from 'react';
import { ALL_COLOURS, Colour } from '@/data/colours';
import { MATERIALS } from '@/data/materials';
import { useApp } from '@/context/AppContext';
import { calculateDaylight, simulateColorUnderLight } from '@/lib/colour-math';
import { Sun, Moon, Clock, Sliders, Save, ShoppingBag, Layers, Compass, Check, Sparkles, RefreshCw } from 'lucide-react';

export function RoomDesigner() {
  const { addToCart, saveRoom, isTradeMode, setAccentColour } = useApp();

  // Room Configuration State
  const [roomType, setRoomType] = useState<string>('Living Room');
  const [wallCode, setWallCode] = useState<string>('BR-041'); // Harbourside Blue
  const [ceilingCode, setCeilingCode] = useState<string>('BR-061'); // Bristol Cream
  const [joineryCode, setJoineryCode] = useState<string>('BR-001'); // Honey Limestone
  const [doorCode, setDoorCode] = useState<string>('BR-072'); // Temple Meads Iron
  const [trimCode, setTrimCode] = useState<string>('BR-057'); // Cornice Gold
  const [floorMaterialName, setFloorMaterialName] = useState<string>('English Brown Oak');
  const [furnitureMaterialName, setFurnitureMaterialName] = useState<string>('European Walnut');
  const [wallFinish, setWallFinish] = useState<'Matt' | 'Eggshell' | 'Satin' | 'Gloss'>('Matt');

  // Lighting & Orientation State
  const [timeOfDay, setTimeOfDay] = useState<number>(16.5); // 16:30 (Late afternoon)
  const [orientation, setOrientation] = useState<'North Light' | 'South Light' | 'East Light' | 'West Light' | 'Artificial Warm' | 'Artificial Cool'>('South Light');
  const [isDaylightPlaying, setIsDaylightPlaying] = useState<boolean>(false);
  const [activeLayerTab, setActiveLayerTab] = useState<'walls' | 'ceiling' | 'joinery' | 'doors' | 'trim' | 'materials'>('walls');

  const [savedSuccess, setSavedSuccess] = useState(false);
  const [bundleAdded, setBundleAdded] = useState(false);

  // Retrieve Colour Objects
  const wallColour = ALL_COLOURS.find((c) => c.code === wallCode) || ALL_COLOURS[0];
  const ceilingColour = ALL_COLOURS.find((c) => c.code === ceilingCode) || ALL_COLOURS[2];
  const joineryColour = ALL_COLOURS.find((c) => c.code === joineryCode) || ALL_COLOURS[1];
  const doorColour = ALL_COLOURS.find((c) => c.code === doorCode) || ALL_COLOURS[11];
  const trimColour = ALL_COLOURS.find((c) => c.code === trimCode) || ALL_COLOURS[4];

  // Calculate simulated daylight condition
  const daylight = useMemo(() => {
    return calculateDaylight(timeOfDay, orientation);
  }, [timeOfDay, orientation]);

  // Simulated colors under current light
  const simWallHex = simulateColorUnderLight(wallColour.hex, daylight, wallFinish);
  const simCeilingHex = simulateColorUnderLight(ceilingColour.hex, daylight, 'Matt');
  const simJoineryHex = simulateColorUnderLight(joineryColour.hex, daylight, 'Eggshell');
  const simDoorHex = simulateColorUnderLight(doorColour.hex, daylight, 'Gloss');
  const simTrimHex = simulateColorUnderLight(trimColour.hex, daylight, 'Satin');

  // Time daylight animation loop
  React.useEffect(() => {
    let interval: any;
    if (isDaylightPlaying) {
      interval = setInterval(() => {
        setTimeOfDay((prev) => {
          if (prev >= 21) return 6;
          return Math.round((prev + 0.25) * 100) / 100;
        });
      }, 250);
    }
    return () => clearInterval(interval);
  }, [isDaylightPlaying]);

  const handleSaveRoom = () => {
    saveRoom({
      id: `room-${Date.now()}`,
      title: `${roomType} · ${wallColour.name}`,
      roomType,
      wallColour: wallColour.code,
      ceilingColour: ceilingColour.code,
      joineryColour: joineryColour.code,
      doorsColour: doorColour.code,
      trimColour: trimColour.code,
      floorMaterial: floorMaterialName,
      lightingTime: timeOfDay,
      orientation,
      savedAt: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleAddEntirePaletteToCart = () => {
    // Add 2.5L Wall tin + 2.5L Ceiling tin + Sample pots
    addToCart({
      id: `tin-${wallColour.code}-${wallFinish}-2.5L-${Date.now()}`,
      type: 'paint_tin',
      colourId: wallColour.id,
      colourCode: wallColour.code,
      colourName: wallColour.name,
      hex: wallColour.hex,
      finish: wallFinish === 'Matt' ? 'Architectural Matt' : 'Architectural Eggshell',
      size: '2.5L',
      quantity: 2,
      unitPrice: isTradeMode ? 54.40 : 68.00
    });

    addToCart({
      id: `sample-${joineryColour.code}-100ml-${Date.now()}`,
      type: 'sample_pot',
      colourId: joineryColour.id,
      colourCode: joineryColour.code,
      colourName: joineryColour.name,
      hex: joineryColour.hex,
      finish: 'Architectural Eggshell',
      size: '100ml Pot',
      quantity: 1,
      unitPrice: isTradeMode ? 4.40 : 5.50
    });

    setBundleAdded(true);
    setTimeout(() => setBundleAdded(false), 3000);
  };

  // Format time display (e.g., 16.5 -> "16:30")
  const formatTime = (t: number) => {
    const hours = Math.floor(t);
    const minutes = Math.round((t - hours) * 60);
    return `${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}`;
  };

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#202426]/10 pb-6">
          <div>
            <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
              Digital Colour Design
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
              Architectural Room Designer
            </h1>
            <p className="text-xs sm:text-sm text-[#69706D] max-w-xl">
              Simulate daylight angles, material harmonies, and finish reflectance across 10 architectural room typologies.
            </p>
          </div>

          {/* Quick Room Typology Selector */}
          <div className="flex flex-wrap gap-1.5 bg-[#E6E4DD] p-1.5 rounded border border-[#202426]/10">
            {['Living Room', 'Dining Room', 'Kitchen', 'Bedroom', 'Study', 'Hallway', 'Bathroom', 'Library', 'Commercial'].map((t) => (
              <button
                key={t}
                onClick={() => setRoomType(t)}
                className={`px-2.5 py-1 text-xs font-mono-tech rounded transition-colors cursor-pointer ${
                  roomType === t ? 'bg-[#202426] text-white shadow-xs' : 'text-[#202426] hover:bg-white/60'
                }`}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Main 2-Column Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Interactive Architectural Elevation Canvas (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            
            {/* Architectural Canvas Box */}
            <div className="relative aspect-4/3 w-full rounded-lg border border-[#202426]/20 bg-[#181B1C] shadow-xl overflow-hidden flex flex-col justify-between">
              
              {/* Dynamic SVG Room Elevation Scene */}
              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 600" preserveAspectRatio="none">
                <defs>
                  {/* Floor Material Patterns */}
                  <linearGradient id="floorGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" stopColor="#2A241E" />
                    <stop offset="100%" stopColor="#1B1713" />
                  </linearGradient>

                  {/* Window Light Cone Gradient */}
                  <linearGradient id="windowLightBeam" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={daylight.colorTemperatureK < 3500 ? '#FFDE9E' : '#EAF4FF'} stopOpacity="0.35" />
                    <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* 1. Ceiling Plane */}
                <polygon points="0,0 800,0 720,90 80,90" fill={simCeilingHex} />
                <line x1="80" y1="90" x2="720" y2="90" stroke={simTrimHex} strokeWidth="3" />

                {/* 2. Left Wall Perspective */}
                <polygon points="0,0 80,90 80,480 0,600" fill={simWallHex} opacity="0.9" />

                {/* 3. Main Rear Elevation Wall */}
                <rect x="80" y="90" width="640" height="390" fill={simWallHex} />

                {/* 4. Right Wall Perspective */}
                <polygon points="800,0 720,90 720,480 800,600" fill={simWallHex} opacity="0.82" />

                {/* 5. Floor Plane */}
                <polygon points="0,600 80,480 720,480 800,600" fill="url(#floorGrad)" />
                {/* Floorboards lines */}
                <line x1="80" y1="480" x2="0" y2="600" stroke="#000" strokeWidth="1" strokeOpacity="0.4" />
                <line x1="200" y1="480" x2="160" y2="600" stroke="#000" strokeWidth="1" strokeOpacity="0.3" />
                <line x1="320" y1="480" x2="310" y2="600" stroke="#000" strokeWidth="1" strokeOpacity="0.3" />
                <line x1="480" y1="480" x2="490" y2="600" stroke="#000" strokeWidth="1" strokeOpacity="0.3" />
                <line x1="600" y1="480" x2="640" y2="600" stroke="#000" strokeWidth="1" strokeOpacity="0.3" />
                <line x1="720" y1="480" x2="800" y2="600" stroke="#000" strokeWidth="1" strokeOpacity="0.4" />

                {/* 6. Skirting & Joinery Trim */}
                <rect x="80" y="470" width="640" height="10" fill={simJoineryHex} />

                {/* 7. Tall Georgian Window on Left Rear */}
                <g>
                  {/* Window reveal frame */}
                  <rect x="130" y="130" width="160" height="290" fill="#E6E4DD" stroke={simJoineryHex} strokeWidth="6" />
                  {/* Sky glass view */}
                  <rect x="136" y="136" width="148" height="278" fill={daylight.colorTemperatureK < 3500 ? '#FDBA74' : (daylight.colorTemperatureK > 6500 ? '#38BDF8' : '#BAE6FD')} />
                  {/* Sash glazing bars */}
                  <line x1="210" y1="136" x2="210" y2="414" stroke={simJoineryHex} strokeWidth="3" />
                  <line x1="136" y1="200" x2="284" y2="200" stroke={simJoineryHex} strokeWidth="2.5" />
                  <line x1="136" y1="270" x2="284" y2="270" stroke={simJoineryHex} strokeWidth="3" />
                  <line x1="136" y1="340" x2="284" y2="340" stroke={simJoineryHex} strokeWidth="2.5" />

                  {/* Window Light cast beam */}
                  <polygon points="130,130 290,130 450,480 180,480" fill="url(#windowLightBeam)" />
                </g>

                {/* 8. Architectural Fireplace & Chimneypiece (Center Right) */}
                <g>
                  {/* Mantle shelf */}
                  <rect x="360" y="240" width="220" height="14" fill="#D7C4A5" />
                  {/* Surrounding ashlar */}
                  <rect x="380" y="254" width="180" height="216" fill="#C8B493" stroke="#202426" strokeWidth="0.5" strokeOpacity="0.4" />
                  {/* Hearth opening */}
                  <rect x="410" y="300" width="120" height="170" fill="#181B1C" />
                  {/* Fireplace firebox depth */}
                  <polygon points="410,300 430,320 430,470 410,470" fill="#0C0D0E" />
                  <polygon points="530,300 510,320 510,470 530,470" fill="#121314" />
                </g>

                {/* 9. Architectural Door (Far Right) */}
                <g>
                  <rect x="620" y="160" width="80" height="310" fill={simDoorHex} stroke={simJoineryHex} strokeWidth="5" />
                  {/* Door Panels */}
                  <rect x="630" y="180" width="60" height="100" fill={simDoorHex} stroke="#000" strokeWidth="1" strokeOpacity="0.2" />
                  <rect x="630" y="300" width="60" height="150" fill={simDoorHex} stroke="#000" strokeWidth="1" strokeOpacity="0.2" />
                  {/* Brass Knob */}
                  <circle cx="636" cy="315" r="3.5" fill="#EAB308" />
                </g>

                {/* 10. Ambient Daylight Wash Filter Overlay */}
                <rect x="0" y="0" width="800" height="600" fill={daylight.tintFilter} pointerEvents="none" />
              </svg>

              {/* Technical Canvas Overlay Badges */}
              <div className="relative z-10 p-4 flex items-start justify-between">
                <div className="bg-[#202426]/90 backdrop-blur-sm text-white px-3 py-1.5 rounded border border-white/10 text-[11px] font-mono-tech space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: daylight.colorTemperatureK < 3500 ? '#F97316' : '#38BDF8' }} />
                    <span className="font-semibold">{daylight.label}</span>
                    <span className="text-white/60">({formatTime(timeOfDay)})</span>
                  </div>
                  <div className="text-[9px] text-white/70">
                    {orientation} · {daylight.colorTemperatureK}K Spectral Temp
                  </div>
                </div>

                <div className="bg-white/90 text-[#202426] px-3 py-1.5 rounded shadow-sm text-right text-[11px] font-mono-tech">
                  <span className="block text-[9px] uppercase text-[#69706D]">Primary Wall Spec</span>
                  <span className="font-bold">{wallColour.code} {wallColour.name}</span>
                </div>
              </div>

              {/* Bottom Canvas Control Readout */}
              <div className="relative z-10 p-4 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex items-center justify-between text-[11px] font-mono-tech text-white">
                <div className="flex items-center gap-3">
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 rounded-xs border border-white/30" style={{ backgroundColor: wallColour.hex }} />
                    Wall: {wallColour.code}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 rounded-xs border border-white/30" style={{ backgroundColor: ceilingColour.hex }} />
                    Ceiling: {ceilingColour.code}
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-3 h-3 rounded-xs border border-white/30" style={{ backgroundColor: joineryColour.hex }} />
                    Joinery: {joineryColour.code}
                  </span>
                </div>

                <span className="text-white/70 text-[10px]">
                  Finish: {wallFinish} 2%
                </span>
              </div>

            </div>

            {/* Daylight Animation & Light Slider Box (Section 22) */}
            <div className="bg-white p-5 rounded-lg border border-[#202426]/15 space-y-4 shadow-xs">
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sun className="w-4 h-4 text-[#C28A38]" />
                  <span className="text-xs font-mono-tech font-semibold text-[#202426] uppercase">
                    Daylight & Solar Cycle (06:00 → 21:00)
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsDaylightPlaying(!isDaylightPlaying)}
                    className="px-2.5 py-1 bg-[#F2EEE5] hover:bg-[#202426] hover:text-white rounded text-[11px] font-mono-tech transition-colors cursor-pointer"
                  >
                    {isDaylightPlaying ? 'Pause Cycle' : 'Play 24hr Cycle'}
                  </button>
                  <span className="text-xs font-mono-tech font-bold text-[#181B1C] bg-[#EAE6DC] px-2 py-0.5 rounded">
                    {formatTime(timeOfDay)}
                  </span>
                </div>
              </div>

              {/* Time Slider */}
              <div className="space-y-1">
                <input
                  type="range"
                  min="6"
                  max="21"
                  step="0.25"
                  value={timeOfDay}
                  onChange={(e) => setTimeOfDay(Number(e.target.value))}
                  className="w-full h-2 bg-[#E6E4DD] rounded-lg appearance-none cursor-pointer accent-[#202426]"
                />
                <div className="flex justify-between text-[10px] font-mono-tech text-[#69706D] pt-1">
                  <span>06:00 Dawn</span>
                  <span>09:00 Morning</span>
                  <span>13:00 Midday</span>
                  <span>17:00 Afternoon</span>
                  <span>19:30 Golden Hour</span>
                  <span>21:00 Night</span>
                </div>
              </div>

              {/* Orientation & Artificial Light Buttons */}
              <div className="pt-2 border-t border-[#202426]/10">
                <label className="text-[10px] font-mono-tech text-[#69706D] uppercase block mb-1.5">
                  Fenestration Aspect & Ambient Light Source
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'North Light', label: 'North Light (Cool / Diffused)' },
                    { id: 'South Light', label: 'South Light (Direct / Golden)' },
                    { id: 'East Light', label: 'East Light (Morning Rays)' },
                    { id: 'West Light', label: 'West Light (Warm Evening)' },
                    { id: 'Artificial Warm', label: 'Domestic 2700K Lamplight' },
                    { id: 'Artificial Cool', label: 'Studio 4000K Illumination' }
                  ].map((o) => (
                    <button
                      key={o.id}
                      onClick={() => setOrientation(o.id as any)}
                      className={`p-2 text-left rounded text-[11px] font-mono-tech border transition-colors cursor-pointer ${
                        orientation === o.id
                          ? 'bg-[#202426] text-white border-[#202426]'
                          : 'bg-[#F2EEE5]/60 text-[#202426] border-[#202426]/15 hover:border-[#202426]'
                      }`}
                    >
                      {o.label}
                    </button>
                  ))}
                </div>
              </div>

            </div>

          </div>

          {/* Right Column: Layer Customiser & Paint Specifications (5 Cols) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Layer Selector Tabs */}
            <div className="bg-white p-5 rounded-lg border border-[#202426]/15 space-y-4 shadow-xs">
              
              <div className="flex items-center justify-between border-b border-[#202426]/10 pb-3">
                <h3 className="text-xs font-mono-tech font-bold text-[#202426] uppercase flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-[#274F61]" />
                  <span>Room Surface Specifications</span>
                </h3>
                <span className="text-[10px] font-mono-tech text-[#69706D]">
                  5 Layers Active
                </span>
              </div>

              {/* Layer Selection Chips */}
              <div className="grid grid-cols-5 gap-1 text-[11px] font-mono-tech text-center">
                {[
                  { id: 'walls', label: 'Walls', code: wallCode, hex: wallColour.hex },
                  { id: 'ceiling', label: 'Ceiling', code: ceilingCode, hex: ceilingColour.hex },
                  { id: 'joinery', label: 'Joinery', code: joineryCode, hex: joineryColour.hex },
                  { id: 'doors', label: 'Doors', code: doorCode, hex: doorColour.hex },
                  { id: 'trim', label: 'Trim', code: trimCode, hex: trimColour.hex }
                ].map((layer) => (
                  <button
                    key={layer.id}
                    onClick={() => setActiveLayerTab(layer.id as any)}
                    className={`p-1.5 rounded border transition-all cursor-pointer flex flex-col items-center gap-1 ${
                      activeLayerTab === layer.id
                        ? 'bg-[#202426] text-white border-[#202426]'
                        : 'bg-[#F2EEE5]/70 text-[#202426] border-[#202426]/15'
                    }`}
                  >
                    <div className="w-3.5 h-3.5 rounded-xs border border-black/20" style={{ backgroundColor: layer.hex }} />
                    <span className="font-semibold text-[10px]">{layer.label}</span>
                    <span className="text-[8px] opacity-80">{layer.code}</span>
                  </button>
                ))}
              </div>

              {/* Active Layer Palette Selector */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between text-xs font-mono-tech">
                  <span className="text-[#69706D]">
                    Choosing for <strong className="text-[#181B1C] uppercase">{activeLayerTab}</strong>:
                  </span>
                  <span className="font-bold text-[#274F61]">
                    {activeLayerTab === 'walls' ? wallColour.name : (activeLayerTab === 'ceiling' ? ceilingColour.name : joineryColour.name)}
                  </span>
                </div>

                {/* 16 Quick Curated Architectural Recommendations */}
                <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 max-h-48 overflow-y-auto p-1 bg-[#F2EEE5]/40 rounded border border-[#202426]/10">
                  {ALL_COLOURS.slice(0, 32).map((c) => {
                    const isSelected =
                      (activeLayerTab === 'walls' && wallCode === c.code) ||
                      (activeLayerTab === 'ceiling' && ceilingCode === c.code) ||
                      (activeLayerTab === 'joinery' && joineryCode === c.code) ||
                      (activeLayerTab === 'doors' && doorCode === c.code) ||
                      (activeLayerTab === 'trim' && trimCode === c.code);

                    return (
                      <button
                        key={c.code}
                        onClick={() => {
                          if (activeLayerTab === 'walls') setWallCode(c.code);
                          else if (activeLayerTab === 'ceiling') setCeilingCode(c.code);
                          else if (activeLayerTab === 'joinery') setJoineryCode(c.code);
                          else if (activeLayerTab === 'doors') setDoorCode(c.code);
                          else if (activeLayerTab === 'trim') setTrimCode(c.code);
                          setAccentColour(c.hex);
                        }}
                        className={`group p-1 rounded transition-all cursor-pointer flex flex-col items-center gap-1 ${
                          isSelected ? 'ring-2 ring-[#202426] bg-white' : 'hover:bg-white/80'
                        }`}
                        title={`${c.code} ${c.name}`}
                      >
                        <div className="w-full aspect-square rounded-xs border border-black/15 shadow-xs" style={{ backgroundColor: c.hex }} />
                        <span className="text-[8px] font-mono-tech truncate w-full text-center">{c.code}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Finish Selector for Walls */}
              <div className="pt-2 border-t border-[#202426]/10 space-y-1.5">
                <label className="text-[10px] font-mono-tech text-[#69706D] uppercase block">
                  Wall Sheen Level
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {(['Matt', 'Eggshell', 'Satin', 'Gloss'] as const).map((fn) => (
                    <button
                      key={fn}
                      onClick={() => setWallFinish(fn)}
                      className={`py-1.5 text-xs font-mono-tech rounded border transition-colors cursor-pointer text-center ${
                        wallFinish === fn
                          ? 'bg-[#202426] text-white border-[#202426]'
                          : 'bg-[#F2EEE5] text-[#202426] border-[#202426]/20'
                      }`}
                    >
                      {fn}
                    </button>
                  ))}
                </div>
              </div>

            </div>

            {/* Room Specification Actions & Palette Export */}
            <div className="bg-white p-5 rounded-lg border border-[#202426]/15 space-y-4 shadow-xs">
              
              <div className="flex items-center justify-between border-b border-[#202426]/10 pb-2">
                <span className="text-xs font-mono-tech font-bold uppercase text-[#202426]">
                  Room Specification Summary
                </span>
                <span className="text-xs font-mono-tech font-bold text-[#181B1C]">
                  {isTradeMode ? '£115.60 (Trade)' : '£141.50'}
                </span>
              </div>

              <div className="space-y-1 text-xs font-mono-tech text-[#202426]/80">
                <div className="flex justify-between">
                  <span>Wall Paint (2.5L × 2):</span>
                  <span>{wallColour.code} {wallColour.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Ceiling Paint (2.5L):</span>
                  <span>{ceilingColour.code} {ceilingColour.name}</span>
                </div>
                <div className="flex justify-between">
                  <span>Joinery Trim (100ml Pot):</span>
                  <span>{joineryColour.code} {joineryColour.name}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleAddEntirePaletteToCart}
                  className="w-full py-3 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  {bundleAdded ? <Check className="w-4 h-4 text-emerald-400" /> : <ShoppingBag className="w-4 h-4" />}
                  <span>{bundleAdded ? 'Room Bundle Added to Bag' : 'Order Complete Room Palette'}</span>
                </button>

                <button
                  onClick={handleSaveRoom}
                  className="w-full py-2.5 bg-[#F2EEE5] hover:bg-[#E6E4DD] text-[#202426] border border-[#202426]/25 text-xs font-mono-tech tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {savedSuccess ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Save className="w-3.5 h-3.5" />}
                  <span>{savedSuccess ? 'Room Saved to My Archive' : 'Save Room to My Archive'}</span>
                </button>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
