'use client';

import React, { useState } from 'react';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { ShoppingBag, Box, Check, Sparkles, Sliders, ShieldCheck } from 'lucide-react';

export function ProductCatalog() {
  const { addToCart, isTradeMode, setCurrentTab, setSelectedColour } = useApp();
  const [activeCategory, setActiveCategory] = useState<'all' | 'tins' | 'samples' | 'box'>('all');
  const [boxAdded, setBoxAdded] = useState(false);

  const handleAddColourBox = () => {
    addToCart({
      id: `colour-box-${Date.now()}`,
      type: 'colour_box',
      colourCode: 'BCW-BOX-96',
      colourName: 'The Bristol Colour Box (96 Swatches & Material Manual)',
      hex: '#274F61',
      size: 'Box Set',
      quantity: 1,
      unitPrice: isTradeMode ? 144.00 : 180.00
    });
    setBoxAdded(true);
    setTimeout(() => setBoxAdded(false), 2500);
  };

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-10">
        
        {/* Header */}
        <div className="border-b border-[#202426]/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
              Physical Products & Sample Systems
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
              Architectural Paint & Materials Store
            </h1>
            <p className="text-xs sm:text-sm text-[#69706D] max-w-xl">
              Precision tins, 100ml wet sample pots, A5 hand-painted cards, and the signature 96-colour boxed library.
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex gap-1.5 bg-[#E6E4DD] p-1 rounded border border-[#202426]/10 text-xs font-mono-tech">
            {[
              { id: 'all', label: 'All Products' },
              { id: 'box', label: 'The Colour Box' },
              { id: 'samples', label: 'Sample Systems' },
              { id: 'tins', label: 'Paint Tins (1L–20L)' }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-[#202426] text-white shadow-xs'
                    : 'text-[#202426] hover:bg-white/50'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Featured Showcase: The Bristol Colour Box (Section 29) */}
        {(activeCategory === 'all' || activeCategory === 'box') && (
          <div className="bg-[#202426] text-white rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 shadow-xl border border-black/40">
            <div className="lg:col-span-5 relative min-h-[280px] lg:min-h-[360px]">
              <img
                src="/images/paint_tin_architectural.jpg"
                alt="The Bristol Colour Box on Pennant Stone"
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#202426] via-transparent to-transparent lg:hidden" />
            </div>

            <div className="lg:col-span-7 p-6 sm:p-10 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono-tech tracking-widest text-[#D7C4A5] uppercase font-semibold">
                    The Signature Physical Tool
                  </span>
                  <span className="text-xs font-mono-tech bg-white/10 px-2.5 py-1 rounded text-[#E6E4DD]">
                    Architectural Edition
                  </span>
                </div>

                <h2 className="text-3xl sm:text-4xl font-serif-luxury font-normal text-white">
                  The Bristol Colour Box
                </h2>

                <p className="text-sm text-[#E6E4DD]/80 leading-relaxed font-sans">
                  The physical bridge between digital specification and real space. A handcrafted cloth-bound library containing all 96 hand-painted A6 swatch cards, 14 material reference slabs, architectural lighting guide, and specification handbook.
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs font-mono-tech text-[#E6E4DD]/80">
                  <div className="p-2.5 bg-white/5 rounded border border-white/10">
                    <span className="block text-[9px] text-[#D7C4A5] uppercase">Contents</span>
                    <span className="font-semibold text-white">96 Hand-Painted Cards</span>
                  </div>
                  <div className="p-2.5 bg-white/5 rounded border border-white/10">
                    <span className="block text-[9px] text-[#D7C4A5] uppercase">Finishes</span>
                    <span className="font-semibold text-white">Matt & Eggshell Samples</span>
                  </div>
                  <div className="p-2.5 bg-white/5 rounded border border-white/10">
                    <span className="block text-[9px] text-[#D7C4A5] uppercase">Material Book</span>
                    <span className="font-semibold text-white">Limestone & Oak Manual</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <span className="text-2xl font-bold font-mono-tech text-white">
                    £{isTradeMode ? '144.00' : '180.00'}
                  </span>
                  {isTradeMode && (
                    <span className="block text-[10px] font-mono-tech text-emerald-400">
                      Trade Architect Pricing Applied (-20%)
                    </span>
                  )}
                </div>

                <button
                  onClick={handleAddColourBox}
                  className="w-full sm:w-auto px-6 py-3 bg-[#D7C4A5] hover:bg-white text-[#202426] text-xs font-semibold tracking-widest uppercase rounded transition-all flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  {boxAdded ? <Check className="w-4 h-4 text-emerald-800" /> : <ShoppingBag className="w-4 h-4" />}
                  <span>{boxAdded ? 'Added to Order Bag' : 'Order The Bristol Colour Box'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Product Grid: Featured Paint Tins and Sample Cards */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-serif-luxury font-semibold text-[#181B1C]">
              Architectural Formulations & Sample Pots
            </h3>
            <span className="text-xs font-mono-tech text-[#69706D]">
              Showing curated selection · Free delivery on orders over £100
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {ALL_COLOURS.slice(0, 8).map((colour) => (
              <div
                key={colour.id}
                className="bg-white rounded-lg border border-[#202426]/15 overflow-hidden flex flex-col justify-between hover:shadow-lg transition-all"
              >
                <div>
                  {/* Swatch Image */}
                  <div
                    onClick={() => {
                      setSelectedColour(colour);
                      setCurrentTab('explorer');
                    }}
                    className="h-36 p-3 flex flex-col justify-between cursor-pointer relative"
                    style={{ backgroundColor: colour.hex }}
                  >
                    <span className="text-[10px] font-mono-tech bg-black/40 text-white px-2 py-0.5 rounded-xs w-fit">
                      {colour.code}
                    </span>
                    <span className="text-[10px] font-mono-tech bg-white/90 text-[#202426] px-2 py-0.5 rounded-xs w-fit font-bold">
                      LRV {colour.lrv}%
                    </span>
                  </div>

                  {/* Card Content */}
                  <div className="p-4 space-y-2">
                    <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">
                      {colour.collection} Collection
                    </span>
                    <h4 className="text-base font-serif-luxury font-semibold text-[#181B1C] leading-tight">
                      {colour.name}
                    </h4>
                    <p className="text-xs text-[#202426]/70 line-clamp-2">
                      {colour.description}
                    </p>
                  </div>
                </div>

                {/* Purchasing Options */}
                <div className="p-4 pt-0 space-y-2">
                  <div className="flex justify-between items-center text-xs font-mono-tech border-t border-[#202426]/10 pt-2">
                    <span className="text-[#69706D]">2.5L Arch. Matt:</span>
                    <span className="font-bold text-[#181B1C]">£{isTradeMode ? '54.40' : '68.00'}</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        addToCart({
                          id: `sample-${colour.code}-100ml-${Date.now()}`,
                          type: 'sample_pot',
                          colourId: colour.id,
                          colourCode: colour.code,
                          colourName: colour.name,
                          hex: colour.hex,
                          finish: 'Architectural Matt',
                          size: '100ml Pot',
                          quantity: 1,
                          unitPrice: isTradeMode ? 4.40 : 5.50
                        });
                      }}
                      className="py-2 text-[11px] font-mono-tech bg-[#F2EEE5] hover:bg-[#202426] hover:text-white text-[#202426] rounded transition-colors text-center cursor-pointer"
                    >
                      + Pot £{isTradeMode ? '4.40' : '5.50'}
                    </button>

                    <button
                      onClick={() => {
                        addToCart({
                          id: `tin-${colour.code}-Matt-2.5L-${Date.now()}`,
                          type: 'paint_tin',
                          colourId: colour.id,
                          colourCode: colour.code,
                          colourName: colour.name,
                          hex: colour.hex,
                          finish: 'Architectural Matt',
                          size: '2.5L',
                          quantity: 1,
                          unitPrice: isTradeMode ? 54.40 : 68.00
                        });
                      }}
                      className="py-2 text-[11px] font-mono-tech bg-[#202426] hover:bg-[#274F61] text-white rounded transition-colors text-center cursor-pointer"
                    >
                      + 2.5L Tin
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
