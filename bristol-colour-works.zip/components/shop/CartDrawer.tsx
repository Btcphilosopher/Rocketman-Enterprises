'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { X, Trash2, Plus, Minus, ShoppingBag, ShieldCheck, Check, ArrowRight } from 'lucide-react';

export function CartDrawer() {
  const { cart, removeFromCart, updateCartQuantity, clearCart, isCartOpen, setIsCartOpen, isTradeMode } = useApp();
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'confirmed'>('cart');
  const [confirmedOrderId, setConfirmedOrderId] = useState<string>('BCW-9418');
  const [shippingDetails, setShippingDetails] = useState({
    name: 'Marcus Vance, Architect',
    company: 'Vance & Partners Architecture',
    email: 'marcus@vance-arch.co.uk',
    address: '4 Royal York Crescent',
    city: 'Bristol',
    postcode: 'BS8 4JZ'
  });

  if (!isCartOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const delivery = subtotal > 100 || isTradeMode ? 0 : 7.50;
  const grandTotal = subtotal + delivery;

  const handleCompleteOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setConfirmedOrderId(`BCW-${Math.floor(1000 + Math.random() * 9000)}`);
    setCheckoutStep('confirmed');
  };

  const handleClose = () => {
    setIsCartOpen(false);
    if (checkoutStep === 'confirmed') {
      clearCart();
      setCheckoutStep('cart');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-[#F2EEE5] h-full shadow-2xl flex flex-col justify-between border-l border-[#202426]/20 font-sans"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-5 bg-white border-b border-[#202426]/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#274F61]" />
            <h3 className="text-sm font-semibold tracking-wider uppercase text-[#181B1C] font-mono-tech">
              {checkoutStep === 'cart' ? 'Architectural Order Bag' : (checkoutStep === 'shipping' ? 'Project Delivery' : 'Order Confirmed')}
            </h3>
          </div>
          <button
            onClick={handleClose}
            className="p-1 text-[#69706D] hover:text-[#181B1C] rounded cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          
          {checkoutStep === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="text-center py-16 space-y-3 font-mono-tech">
                  <div className="w-12 h-12 mx-auto rounded-full bg-[#E6E4DD] flex items-center justify-center text-[#69706D]">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <p className="text-sm text-[#202426]">Your specification bag is currently empty.</p>
                  <p className="text-xs text-[#69706D]">Explore colours, room palettes, or order sample pots.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {cart.map((item) => (
                    <div
                      key={item.id}
                      className="bg-white p-3.5 rounded-lg border border-[#202426]/15 flex items-center justify-between gap-3 shadow-2xs font-mono-tech"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className="w-10 h-10 rounded-xs border border-black/15 shadow-xs shrink-0"
                          style={{ backgroundColor: item.hex || '#274F61' }}
                        />
                        <div className="space-y-0.5 text-xs">
                          <span className="font-bold text-[#181B1C] block">
                            {item.colourCode ? `${item.colourCode} · ` : ''}{item.colourName || 'The Bristol Colour Box'}
                          </span>
                          <span className="text-[10px] text-[#69706D] block">
                            {item.size || 'Kit'} · {item.finish || 'Standard'}
                          </span>
                          <span className="text-xs font-semibold text-[#274F61]">
                            £{item.unitPrice.toFixed(2)} each
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Stepper */}
                        <div className="flex items-center border border-[#202426]/20 rounded bg-[#F2EEE5]">
                          <button
                            onClick={() => updateCartQuantity(item.id, -1)}
                            className="p-1 hover:bg-[#E6E4DD] rounded-l text-[#202426] cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-bold text-[#181B1C]">{item.quantity}</span>
                          <button
                            onClick={() => updateCartQuantity(item.id, 1)}
                            className="p-1 hover:bg-[#E6E4DD] rounded-r text-[#202426] cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.id)}
                          className="p-1 text-rose-700 hover:bg-rose-50 rounded cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {checkoutStep === 'shipping' && (
            <form id="checkout-form" onSubmit={handleCompleteOrder} className="space-y-3 font-mono-tech text-xs">
              <div className="space-y-1">
                <label className="text-[10px] text-[#69706D] uppercase">Specifier / Architect Name</label>
                <input
                  type="text"
                  required
                  value={shippingDetails.name}
                  onChange={(e) => setShippingDetails({ ...shippingDetails, name: e.target.value })}
                  className="w-full p-2 bg-white border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#69706D] uppercase">Practice / Project Reference</label>
                <input
                  type="text"
                  value={shippingDetails.company}
                  onChange={(e) => setShippingDetails({ ...shippingDetails, company: e.target.value })}
                  className="w-full p-2 bg-white border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#69706D] uppercase">Email For Tracking & Invoices</label>
                <input
                  type="email"
                  required
                  value={shippingDetails.email}
                  onChange={(e) => setShippingDetails({ ...shippingDetails, email: e.target.value })}
                  className="w-full p-2 bg-white border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-[#69706D] uppercase">Site / Delivery Street Address</label>
                <input
                  type="text"
                  required
                  value={shippingDetails.address}
                  onChange={(e) => setShippingDetails({ ...shippingDetails, address: e.target.value })}
                  className="w-full p-2 bg-white border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[10px] text-[#69706D] uppercase">City</label>
                  <input
                    type="text"
                    required
                    value={shippingDetails.city}
                    onChange={(e) => setShippingDetails({ ...shippingDetails, city: e.target.value })}
                    className="w-full p-2 bg-white border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-[#69706D] uppercase">Postal Code</label>
                  <input
                    type="text"
                    required
                    value={shippingDetails.postcode}
                    onChange={(e) => setShippingDetails({ ...shippingDetails, postcode: e.target.value })}
                    className="w-full p-2 bg-white border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                  />
                </div>
              </div>
            </form>
          )}

          {checkoutStep === 'confirmed' && (
            <div className="text-center py-8 space-y-4 font-mono-tech">
              <div className="w-14 h-14 mx-auto rounded-full bg-emerald-100 border border-emerald-300 text-emerald-800 flex items-center justify-center">
                <Check className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-lg font-bold text-[#181B1C]">
                  Order #{confirmedOrderId} Confirmed
                </h4>
                <p className="text-xs text-[#69706D]">
                  Preparing formulation and priority dispatch from our Bristol laboratory.
                </p>
              </div>

              <div className="bg-white p-4 rounded border border-[#202426]/10 text-left text-xs space-y-1.5">
                <div className="flex justify-between font-bold border-b border-[#202426]/10 pb-1">
                  <span>Delivery Target:</span>
                  <span>{shippingDetails.name}</span>
                </div>
                <p className="text-[#69706D]">{shippingDetails.address}, {shippingDetails.city}, {shippingDetails.postcode}</p>
                <div className="flex justify-between pt-1">
                  <span>Total Paid:</span>
                  <span className="font-bold text-[#274F61]">£{grandTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Drawer Footer Summary & Action */}
        <div className="p-5 bg-white border-t border-[#202426]/10 space-y-3 font-mono-tech">
          
          {checkoutStep !== 'confirmed' && (
            <>
              <div className="space-y-1 text-xs text-[#69706D]">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span className="font-bold text-[#181B1C]">£{subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Standard Carbon-Neutral Delivery:</span>
                  <span>{delivery === 0 ? 'FREE' : `£${delivery.toFixed(2)}`}</span>
                </div>
                {isTradeMode && (
                  <div className="flex justify-between text-emerald-700">
                    <span>Trade Account Discount:</span>
                    <span>20% Applied</span>
                  </div>
                )}
                <div className="flex justify-between text-sm font-bold text-[#181B1C] pt-1 border-t border-[#202426]/10">
                  <span>Total:</span>
                  <span>£{grandTotal.toFixed(2)}</span>
                </div>
              </div>

              {checkoutStep === 'cart' ? (
                <button
                  disabled={cart.length === 0}
                  onClick={() => setCheckoutStep('shipping')}
                  className="w-full py-3 bg-[#202426] hover:bg-[#274F61] disabled:bg-gray-400 text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Proceed to Delivery Details</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="submit"
                  form="checkout-form"
                  className="w-full py-3 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Place Architectural Order · £{grandTotal.toFixed(2)}</span>
                </button>
              )}
            </>
          )}

          {checkoutStep === 'confirmed' && (
            <button
              onClick={handleClose}
              className="w-full py-3 bg-[#202426] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors"
            >
              Close & Return to Studio
            </button>
          )}

        </div>

      </div>
    </div>
  );
}
