'use client';

import React, { useState, useMemo } from 'react';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { calculatePaintRequirement } from '@/lib/colour-math';
import { Calculator, ShoppingBag, Check, SlidersHorizontal, Info } from 'lucide-react';

export function PaintCalculator() {
  const { addToCart, isTradeMode } = useApp();

  const [roomWidth, setRoomWidth] = useState<number>(4.5);
  const [roomLength, setRoomLength] = useState<number>(5.8);
  const [wallHeight, setWallHeight] = useState<number>(3.2); // Tall Georgian default
  const [doors, setDoors] = useState<number>(2);
  const [windows, setWindows] = useState<number>(2);
  const [includeCeiling, setIncludeCeiling] = useState<boolean>(true);
  const [coats, setCoats] = useState<number>(2);
  const [selectedColourCode, setSelectedColourCode] = useState<string>('BR-041');
  const [selectedFinish, setSelectedFinish] = useState<'Architectural Matt' | 'Architectural Eggshell'>('Architectural Matt');
  const [addedSuccess, setAddedSuccess] = useState(false);

  const selectedColour = ALL_COLOURS.find((c) => c.code === selectedColourCode) || ALL_COLOURS[0];

  const calculation = useMemo(() => {
    return calculatePaintRequirement({
      roomWidthM: roomWidth,
      roomLengthM: roomLength,
      wallHeightM: wallHeight,
      doorsCount: doors,
      windowsCount: windows,
      ceilingIncluded: includeCeiling,
      coats,
      coverageM2PerLitre: 12,
      wasteMarginPercent: 10,
      pricePer2_5L: isTradeMode ? 54.40 : 68.00
    });
  }, [roomWidth, roomLength, wallHeight, doors, windows, includeCeiling, coats, isTradeMode]);

  const handleAddCalculatedTinsToCart = () => {
    calculation.recommendedTins.forEach((t) => {
      addToCart({
        id: `calc-tin-${selectedColour.code}-${t.size}-${Date.now()}`,
        type: 'paint_tin',
        colourId: selectedColour.id,
        colourCode: selectedColour.code,
        colourName: selectedColour.name,
        hex: selectedColour.hex,
        finish: selectedFinish,
        size: t.size as any,
        quantity: t.count,
        unitPrice: isTradeMode
          ? Math.round((t.size === '20L' ? 420 : (t.size === '10L' ? 230 : (t.size === '5L' ? 124 : (t.size === '2.5L' ? 68 : 34)))) * 0.8)
          : (t.size === '20L' ? 420 : (t.size === '10L' ? 230 : (t.size === '5L' ? 124 : (t.size === '2.5L' ? 68 : 34))))
      });
    });
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2500);
  };

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/10 pb-6 space-y-2">
          <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold flex items-center gap-1.5">
            <Calculator className="w-4 h-4" /> Architectural Estimation Engine
          </span>
          <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
            How Much Paint Do You Need?
          </h1>
          <p className="text-xs sm:text-sm text-[#69706D] max-w-xl">
            Input architectural dimensions and fenestration deductions to calculate exact volume, optimal container configuration, and estimated material cost.
          </p>
        </div>

        {/* 2-Column Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Dimension Inputs (6 Cols) */}
          <div className="lg:col-span-6 bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-8 space-y-6 shadow-xs font-mono-tech">
            
            <h3 className="text-xs font-bold text-[#202426] uppercase border-b border-[#202426]/10 pb-3">
              Room Dimensions & Substrate
            </h3>

            {/* Room Dimensions Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <label className="text-[11px] text-[#69706D] uppercase block">Width (metres)</label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  value={roomWidth}
                  onChange={(e) => setRoomWidth(Math.max(1, Number(e.target.value)))}
                  className="w-full p-2.5 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none focus:border-[#202426]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] text-[#69706D] uppercase block">Length (metres)</label>
                <input
                  type="number"
                  step="0.1"
                  min="1"
                  value={roomLength}
                  onChange={(e) => setRoomLength(Math.max(1, Number(e.target.value)))}
                  className="w-full p-2.5 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none focus:border-[#202426]"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] text-[#69706D] uppercase block">Height (metres)</label>
                <input
                  type="number"
                  step="0.1"
                  min="1.5"
                  value={wallHeight}
                  onChange={(e) => setWallHeight(Math.max(1.5, Number(e.target.value)))}
                  className="w-full p-2.5 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none focus:border-[#202426]"
                />
              </div>
            </div>

            {/* Deductions: Doors & Windows */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#202426]/10">
              <div className="space-y-1.5">
                <label className="text-[11px] text-[#69706D] uppercase block">Number of Doors (-1.9m² each)</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={doors}
                  onChange={(e) => setDoors(Math.max(0, Number(e.target.value)))}
                  className="w-full p-2.5 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] text-[#69706D] uppercase block">Number of Windows (-1.8m² each)</label>
                <input
                  type="number"
                  min="0"
                  max="10"
                  value={windows}
                  onChange={(e) => setWindows(Math.max(0, Number(e.target.value)))}
                  className="w-full p-2.5 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                />
              </div>
            </div>

            {/* Ceiling & Coats Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-[#202426]/10">
              <div className="flex items-center gap-3 p-3 bg-[#F2EEE5]/50 rounded border border-[#202426]/10 cursor-pointer" onClick={() => setIncludeCeiling(!includeCeiling)}>
                <input
                  type="checkbox"
                  checked={includeCeiling}
                  onChange={(e) => setIncludeCeiling(e.target.checked)}
                  className="accent-[#202426] w-4 h-4 cursor-pointer"
                />
                <span className="text-xs text-[#202426]">Include Ceiling Surface ({Math.round(roomWidth * roomLength)}m²)</span>
              </div>

              <div className="space-y-1.5">
                <label className="text-[11px] text-[#69706D] uppercase block">Number of Coats</label>
                <select
                  value={coats}
                  onChange={(e) => setCoats(Number(e.target.value))}
                  className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                >
                  <option value={1}>1 Coat (Touch-up / Primer)</option>
                  <option value={2}>2 Coats (Standard Architectural)</option>
                  <option value={3}>3 Coats (Deep Pigment Saturation)</option>
                </select>
              </div>
            </div>

            {/* Paint Choice Selector */}
            <div className="pt-2 border-t border-[#202426]/10 space-y-2">
              <label className="text-[11px] text-[#69706D] uppercase block">
                Assign Formulation for Calculation
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <select
                  value={selectedColourCode}
                  onChange={(e) => setSelectedColourCode(e.target.value)}
                  className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                >
                  {ALL_COLOURS.slice(0, 48).map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.code} · {c.name}
                    </option>
                  ))}
                </select>

                <select
                  value={selectedFinish}
                  onChange={(e) => setSelectedFinish(e.target.value as any)}
                  className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
                >
                  <option value="Architectural Matt">Architectural Matt (2% Sheen)</option>
                  <option value="Architectural Eggshell">Architectural Eggshell (15% Sheen)</option>
                </select>
              </div>
            </div>

          </div>

          {/* Right Column: Architectural Calculation Breakdown (6 Cols) */}
          <div className="lg:col-span-6 space-y-6">
            
            <div className="bg-[#E6E4DD] rounded-lg border border-[#202426]/25 p-6 sm:p-8 space-y-6 shadow-sm font-mono-tech">
              
              <div className="border-b border-[#202426]/15 pb-3 flex justify-between items-start">
                <div>
                  <span className="text-[10px] text-[#202426]/70 uppercase tracking-wider block">
                    Volumetric Schedule
                  </span>
                  <h3 className="text-xl font-bold uppercase text-[#181B1C] pt-0.5">
                    Paint Requirement Estimate
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold text-[#181B1C]">
                    ~{calculation.litresWithWaste} L
                  </span>
                  <span className="block text-[10px] text-[#69706D]">(incl. 10% margin)</span>
                </div>
              </div>

              {/* Surface Area Breakdown Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 bg-white rounded border border-[#202426]/10">
                  <span className="text-[10px] text-[#69706D] uppercase block">Gross Walls</span>
                  <span className="font-bold text-[#181B1C]">{calculation.wallGrossAreaSqM} m²</span>
                </div>
                <div className="p-3 bg-white rounded border border-[#202426]/10">
                  <span className="text-[10px] text-[#69706D] uppercase block">Openings Deducted</span>
                  <span className="font-bold text-rose-800">-{calculation.openingsDeductionSqM} m²</span>
                </div>
                <div className="p-3 bg-white rounded border border-[#202426]/10">
                  <span className="text-[10px] text-[#69706D] uppercase block">Net Wall Area</span>
                  <span className="font-bold text-[#181B1C]">{calculation.wallNetAreaSqM} m²</span>
                </div>
              </div>

              {/* Recommended Tin Configuration */}
              <div className="space-y-3 pt-2 border-t border-[#202426]/15">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase text-[#202426]">
                    Optimal Container Packaging
                  </span>
                  <span className="text-xs font-bold text-[#274F61]">
                    {calculation.totalLitresDelivered} L Total Delivered
                  </span>
                </div>

                <div className="space-y-2">
                  {calculation.recommendedTins.map((t, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-white rounded border border-[#202426]/10 text-xs">
                      <div className="flex items-center gap-3">
                        <div className="w-6 h-8 bg-[#F2EEE5] border border-[#202426]/30 rounded-xs flex items-center justify-center text-[9px] font-bold">
                          {t.size}
                        </div>
                        <div>
                          <span className="font-bold text-[#181B1C]">{t.count} × {t.size} Architectural Can</span>
                          <span className="block text-[10px] text-[#69706D]">{selectedColour.code} {selectedColour.name}</span>
                        </div>
                      </div>
                      <span className="font-semibold text-[#181B1C]">{t.volumeTotal} Litres</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Total Estimated Cost */}
              <div className="pt-2 border-t border-[#202426]/15 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold uppercase text-[#202426] block">Estimated Material Cost</span>
                  <span className="text-[10px] text-[#69706D]">Coverage: 12 m²/L @ 2 coats</span>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold text-[#181B1C]">
                    £{calculation.estimatedCostGbp.toFixed(2)}
                  </span>
                  {isTradeMode && (
                    <span className="block text-[10px] text-emerald-700 font-semibold">
                      Trade 20% Discount Applied
                    </span>
                  )}
                </div>
              </div>

              {/* Add to Basket Action */}
              <button
                onClick={handleAddCalculatedTinsToCart}
                className="w-full py-3.5 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
              >
                {addedSuccess ? <Check className="w-4 h-4 text-emerald-400" /> : <ShoppingBag className="w-4 h-4" />}
                <span>{addedSuccess ? 'Containers Added to Order Bag' : `Add ${calculation.totalLitresDelivered}L to Order Bag`}</span>
              </button>

              <div className="flex items-center gap-1.5 text-[10px] text-[#69706D] italic">
                <Info className="w-3.5 h-3.5 shrink-0" />
                <span>Estimates based on standard porosity. Porous unsealed lime plaster may require a priming mist coat.</span>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
