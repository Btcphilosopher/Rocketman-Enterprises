'use client';

import React, { useState } from 'react';
import { SIGNATURE_PROJECTS, SignatureProject, RoomScheduleItem } from '@/data/projects';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { ShieldCheck, FileText, Printer, Download, Plus, Check, Sliders, Building2, Landmark, Clock } from 'lucide-react';

export function ArchitectPortal() {
  const { activeProjectDemo, setActiveProjectDemo, isTradeMode, setIsTradeMode, addToCart } = useApp();
  const [selectedProject, setSelectedProject] = useState<SignatureProject>(
    SIGNATURE_PROJECTS.find((p) => p.id === activeProjectDemo) || SIGNATURE_PROJECTS[0]
  );
  const [historicMode, setHistoricMode] = useState<boolean>(true);
  const [listedGrade, setListedGrade] = useState<'Grade I' | 'Grade II*' | 'Grade II' | 'Conservation Area'>('Grade II*');
  const [substrateType, setSubstrateType] = useState<string>('Historic Lime Plaster (Breathable)');
  const [isExporting, setIsExporting] = useState(false);

  const handleSelectProject = (proj: SignatureProject) => {
    setSelectedProject(proj);
    setActiveProjectDemo(proj.id);
  };

  const handlePrintSchedule = () => {
    setIsExporting(true);
    setTimeout(() => {
      window.print();
      setIsExporting(false);
    }, 400);
  };

  const getColour = (code: string) => ALL_COLOURS.find((c) => c.code === code) || ALL_COLOURS[0];

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8 print:bg-white print:p-0">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header (Hidden when printing) */}
        <div className="border-b border-[#202426]/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4 print:hidden">
          <div className="space-y-2">
            <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold flex items-center gap-1.5">
              <Building2 className="w-4 h-4" /> B2B Architectural Specification Platform
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
              Architect Portal & Paint Schedules
            </h1>
            <p className="text-xs sm:text-sm text-[#69706D] max-w-2xl leading-relaxed">
              Generate NBS-ready paint schedules, manage multi-room commercial deliverables, and enforce heritage breathable coating compliance for listed buildings.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handlePrintSchedule}
              className="px-4 py-2.5 bg-white border border-[#202426]/20 hover:border-[#202426] text-xs font-mono-tech text-[#202426] rounded transition-colors flex items-center gap-2 cursor-pointer shadow-2xs"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Export PDF / Print Schedule</span>
            </button>

            <button
              onClick={() => setIsTradeMode(!isTradeMode)}
              className={`px-4 py-2.5 rounded text-xs font-mono-tech border transition-all cursor-pointer flex items-center gap-1.5 ${
                isTradeMode
                  ? 'bg-[#202426] text-white border-[#202426]'
                  : 'bg-white text-[#202426] border-[#202426]/20 hover:border-[#202426]'
              }`}
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{isTradeMode ? 'Trade Mode Active (-20%)' : 'Apply Trade Pricing'}</span>
            </button>
          </div>
        </div>

        {/* 4 Signature Demo Project Selector Tabs (Print Hidden) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 print:hidden">
          {SIGNATURE_PROJECTS.map((proj) => {
            const isSelected = selectedProject.id === proj.id;
            return (
              <button
                key={proj.id}
                onClick={() => handleSelectProject(proj)}
                className={`p-4 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                  isSelected
                    ? 'bg-[#202426] text-white border-[#202426] shadow-md ring-2 ring-[#202426]'
                    : 'bg-white text-[#202426] border-[#202426]/15 hover:border-[#202426]'
                }`}
              >
                <div>
                  <span className={`block text-[10px] font-mono-tech uppercase ${isSelected ? 'text-[#D7C4A5]' : 'text-[#274F61]'}`}>
                    {proj.typology}
                  </span>
                  <h3 className="text-base font-serif-luxury font-semibold leading-tight pt-1">
                    {proj.name}
                  </h3>
                  <p className={`text-xs pt-1 line-clamp-2 ${isSelected ? 'text-white/70' : 'text-[#69706D]'}`}>
                    {proj.location}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-current/10 text-[10px] font-mono-tech">
                  <span>{proj.rooms.length} Rooms Specified</span>
                  <span className="font-bold">{proj.totalLitres} L Total</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Historic Building Compliance Mode (Section 35) */}
        <div className="bg-white rounded-lg border border-[#202426]/15 p-6 space-y-4 shadow-xs print:hidden font-mono-tech">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#202426]/10 pb-3">
            <div className="flex items-center gap-2">
              <Landmark className="w-4 h-4 text-[#274F61]" />
              <h3 className="text-xs font-bold uppercase text-[#202426]">
                Historic Building Mode & Conservation Guidelines
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-xs text-[#69706D]">Status:</label>
              <select
                value={listedGrade}
                onChange={(e) => setListedGrade(e.target.value as any)}
                className="p-1.5 bg-[#F2EEE5] border border-[#202426]/20 rounded text-xs text-[#181B1C] focus:outline-none"
              >
                <option value="Grade I">Grade I Listed</option>
                <option value="Grade II*">Grade II* Listed</option>
                <option value="Grade II">Grade II Listed</option>
                <option value="Conservation Area">Conservation Area</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-3 bg-[#F2EEE5]/60 rounded border border-[#202426]/10 space-y-1">
              <span className="text-[10px] text-[#69706D] uppercase block">Substrate Vapor Permeability</span>
              <p className="font-medium text-[#181B1C]">SD Value &lt; 0.05m (Class I High Breathability)</p>
            </div>
            <div className="p-3 bg-[#F2EEE5]/60 rounded border border-[#202426]/10 space-y-1">
              <span className="text-[10px] text-[#69706D] uppercase block">Binder Chemistry</span>
              <p className="font-medium text-[#181B1C]">Potassium Waterglass Silicate / Natural Calcite</p>
            </div>
            <div className="p-3 bg-[#F2EEE5]/60 rounded border border-[#202426]/10 space-y-1">
              <span className="text-[10px] text-[#69706D] uppercase block">Heritage Officer Sign-off</span>
              <p className="font-medium text-[#181B1C]">Full Mineral Recipe Certification Provided</p>
            </div>
          </div>
        </div>

        {/* Printable Architectural Paint Schedule (Section 33) */}
        <div className="bg-white rounded-lg border border-[#202426]/25 p-6 sm:p-10 space-y-8 shadow-sm print:border-none print:shadow-none font-mono-tech">
          
          {/* Schedule Header */}
          <div className="border-b-2 border-[#202426] pb-6 flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold tracking-widest uppercase text-[#181B1C]">
                  Bristol Colour Works
                </span>
                <span className="text-xs text-[#69706D]">· Project Specification Document</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif-luxury font-bold text-[#181B1C] pt-1">
                {selectedProject.name}
              </h2>
              <p className="text-xs text-[#69706D]">
                Location: {selectedProject.location} · Client: {selectedProject.client}
              </p>
            </div>

            <div className="text-right text-xs space-y-0.5">
              <span className="block font-bold text-[#181B1C]">Doc Ref: BCW-SCH-{selectedProject.id.toUpperCase()}-2026</span>
              <span className="block text-[#69706D]">Date: 25 September 2026</span>
              <span className="block text-[#274F61] font-semibold">Specification Status: {selectedProject.status}</span>
            </div>
          </div>

          {/* Project Summary Description */}
          <div className="text-xs text-[#202426]/80 leading-relaxed font-sans bg-[#F2EEE5]/50 p-4 rounded border border-[#202426]/10">
            <p><strong>Architectural Rationale:</strong> {selectedProject.description}</p>
          </div>

          {/* Room-by-Room Schedule Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#202426] text-white uppercase text-[10px] tracking-wider">
                <tr>
                  <th className="p-3">Room / Space</th>
                  <th className="p-3">Wall Formula</th>
                  <th className="p-3">Ceiling</th>
                  <th className="p-3">Joinery / Trim</th>
                  <th className="p-3">Doors</th>
                  <th className="p-3">Finish</th>
                  <th className="p-3">Coats</th>
                  <th className="p-3">Net Area</th>
                  <th className="p-3 text-right">Volume</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#202426]/15">
                {selectedProject.rooms.map((rm, idx) => {
                  const wallC = getColour(rm.wallColour);
                  const ceilingC = getColour(rm.ceilingColour);
                  const joineryC = getColour(rm.joineryColour);
                  const doorC = getColour(rm.doorsColour);

                  return (
                    <tr key={idx} className="hover:bg-[#F2EEE5]/40 transition-colors">
                      <td className="p-3 font-semibold text-[#181B1C]">
                        {rm.room}
                        <span className="block text-[9px] font-normal text-[#69706D] uppercase">{rm.type}</span>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <div className="w-3 h-3 rounded-xs border border-black/20" style={{ backgroundColor: wallC.hex }} />
                          <span className="font-bold">{rm.wallColour}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <div className="w-3 h-3 rounded-xs border border-black/20" style={{ backgroundColor: ceilingC.hex }} />
                          <span>{rm.ceilingColour}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <div className="w-3 h-3 rounded-xs border border-black/20" style={{ backgroundColor: joineryC.hex }} />
                          <span>{rm.joineryColour}</span>
                        </div>
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-1.5">
                          <div className="w-3 h-3 rounded-xs border border-black/20" style={{ backgroundColor: doorC.hex }} />
                          <span>{rm.doorsColour}</span>
                        </div>
                      </td>
                      <td className="p-3 text-[#274F61]">{rm.finish}</td>
                      <td className="p-3">{rm.coats}</td>
                      <td className="p-3">{rm.areaSqM} m²</td>
                      <td className="p-3 text-right font-bold text-[#181B1C]">{rm.litresRequired} L</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-[#E6E4DD] font-bold border-t-2 border-[#202426]">
                <tr>
                  <td colSpan={7} className="p-3 text-right uppercase text-[10px]">Total Specified Project Volume:</td>
                  <td className="p-3">{selectedProject.rooms.reduce((s, r) => s + r.areaSqM, 0)} m²</td>
                  <td className="p-3 text-right text-sm text-[#181B1C]">{selectedProject.totalLitres} Litres</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Sign-off & Laboratory Authorization Bar */}
          <div className="pt-6 border-t border-[#202426]/20 grid grid-cols-1 sm:grid-cols-3 gap-6 text-xs text-[#69706D]">
            <div className="space-y-1">
              <span className="block uppercase text-[9px]">Specifying Architect / Practice</span>
              <p className="font-semibold text-[#181B1C] border-b border-[#202426]/20 pb-2">Marcus Croft, RIBA</p>
            </div>
            <div className="space-y-1">
              <span className="block uppercase text-[9px]">Bristol Colour Works Lead Chemist</span>
              <p className="font-semibold text-[#181B1C] border-b border-[#202426]/20 pb-2">Dr. Aris Thorne, CChem</p>
            </div>
            <div className="space-y-1">
              <span className="block uppercase text-[9px]">Production Batch Authorization</span>
              <p className="font-semibold text-emerald-800 border-b border-[#202426]/20 pb-2">Verified & Sealed for Delivery</p>
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
