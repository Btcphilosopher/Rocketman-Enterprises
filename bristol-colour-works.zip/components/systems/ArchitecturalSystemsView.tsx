'use client';

import React, { useState } from 'react';
import { ARCHITECTURAL_SYSTEMS, ArchitecturalSystem } from '@/data/systems';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { Layers, ArrowRight, Sliders, Sparkles, Compass } from 'lucide-react';

export function ArchitecturalSystemsView() {
  const { setCurrentTab, setSelectedColour, setAccentColour } = useApp();
  const [selectedSystem, setSelectedSystem] = useState<ArchitecturalSystem>(ARCHITECTURAL_SYSTEMS[0]);
  const [filterLight, setFilterLight] = useState<string>('All');

  const lightFilters = ['All', 'North Light', 'South Light', 'East Light', 'West Light', 'All-Day Diffused'];

  const filteredSystems = ARCHITECTURAL_SYSTEMS.filter(
    (s) => filterLight === 'All' || s.primaryLight === filterLight
  );

  const getColour = (code: string) => ALL_COLOURS.find((c) => c.code === code) || ALL_COLOURS[0];

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/10 pb-6 space-y-2">
          <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
            Architectural Colour Systems
          </span>
          <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
            24 Engineered Room Specifications
          </h1>
          <p className="text-xs sm:text-sm text-[#69706D] max-w-2xl leading-relaxed">
            Cohesive tripartite systems combining wall, ceiling, joinery, trim, and accent specifications calibrated to architectural periods and orientation.
          </p>
        </div>

        {/* Orientation Filter */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-mono-tech text-[#69706D] uppercase flex items-center gap-1 mr-2">
            <Compass className="w-3.5 h-3.5" /> Light Orientation:
          </span>
          {lightFilters.map((flt) => (
            <button
              key={flt}
              onClick={() => setFilterLight(flt)}
              className={`px-3 py-1.5 rounded text-xs font-mono-tech transition-colors cursor-pointer ${
                filterLight === flt
                  ? 'bg-[#202426] text-white'
                  : 'bg-white text-[#202426] border border-[#202426]/15 hover:border-[#202426]'
              }`}
            >
              {flt}
            </button>
          ))}
        </div>

        {/* 2-Column System Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Systems Index (5 Cols) */}
          <div className="lg:col-span-5 space-y-3 max-h-[750px] overflow-y-auto pr-2">
            {filteredSystems.map((sys) => {
              const isSelected = selectedSystem.id === sys.id;
              const wallC = getColour(sys.wallColour);
              const joineryC = getColour(sys.joineryColour);
              const ceilingC = getColour(sys.ceilingColour);

              return (
                <div
                  key={sys.id}
                  onClick={() => {
                    setSelectedSystem(sys);
                    setAccentColour(wallC.hex);
                  }}
                  className={`p-4 rounded-lg border text-left transition-all cursor-pointer space-y-2.5 ${
                    isSelected
                      ? 'bg-white border-[#202426] shadow-md ring-2 ring-[#202426]'
                      : 'bg-white/80 border-[#202426]/15 hover:bg-white hover:border-[#202426]'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-mono-tech text-[#274F61] uppercase font-semibold">
                      {sys.period}
                    </span>
                    <span className="text-[10px] font-mono-tech text-[#69706D] bg-[#F2EEE5] px-2 py-0.5 rounded">
                      {sys.primaryLight}
                    </span>
                  </div>

                  <h3 className="text-base font-serif-luxury font-semibold text-[#181B1C]">
                    {sys.name}
                  </h3>

                  {/* Triad Swatches Preview */}
                  <div className="flex items-center gap-2 pt-1">
                    <div className="flex items-center -space-x-1.5">
                      <div className="w-6 h-6 rounded-full border border-white shadow-xs" style={{ backgroundColor: wallC.hex }} title={`Wall: ${wallC.code}`} />
                      <div className="w-6 h-6 rounded-full border border-white shadow-xs" style={{ backgroundColor: ceilingC.hex }} title={`Ceiling: ${ceilingC.code}`} />
                      <div className="w-6 h-6 rounded-full border border-white shadow-xs" style={{ backgroundColor: joineryC.hex }} title={`Joinery: ${joineryC.code}`} />
                    </div>
                    <span className="text-[11px] font-mono-tech text-[#69706D]">
                      {sys.wallColour} · {sys.ceilingColour} · {sys.joineryColour}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right Column: Detailed System Plan & Room Elevation (7 Cols) */}
          <div className="lg:col-span-7 bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-8 space-y-6 shadow-xs">
            
            <div className="space-y-2 border-b border-[#202426]/10 pb-4">
              <div className="flex justify-between items-start">
                <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
                  Specification #{selectedSystem.id.toUpperCase()}
                </span>
                <span className="text-xs font-mono-tech text-[#69706D]">
                  {selectedSystem.primaryLight}
                </span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif-luxury font-semibold text-[#181B1C]">
                {selectedSystem.name}
              </h2>
              <p className="text-xs font-mono-tech text-[#69706D]">
                Architectural Typology: {selectedSystem.period}
              </p>
              <p className="text-sm text-[#202426]/80 leading-relaxed pt-1">
                {selectedSystem.description}
              </p>
            </div>

            {/* Visual Tripartite Elevation Swatches */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono-tech font-bold text-[#202426] uppercase">
                Tripartite Envelope Breakdown
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                
                {/* Wall Element */}
                {(() => {
                  const c = getColour(selectedSystem.wallColour);
                  return (
                    <div 
                      onClick={() => setSelectedColour(c)}
                      className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/15 space-y-2 hover:border-[#202426] transition-colors cursor-pointer"
                    >
                      <span className="text-[10px] font-mono-tech uppercase text-[#69706D] block">1. Wall Plane</span>
                      <div className="w-full h-16 rounded-xs border border-black/15 shadow-xs" style={{ backgroundColor: c.hex }} />
                      <div className="text-xs font-mono-tech">
                        <span className="font-bold text-[#181B1C] block">{c.code}</span>
                        <span className="text-[#202426] truncate block">{c.name}</span>
                        <span className="text-[10px] text-[#274F61]">{selectedSystem.recommendedFinishes.wall}</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Ceiling Element */}
                {(() => {
                  const c = getColour(selectedSystem.ceilingColour);
                  return (
                    <div 
                      onClick={() => setSelectedColour(c)}
                      className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/15 space-y-2 hover:border-[#202426] transition-colors cursor-pointer"
                    >
                      <span className="text-[10px] font-mono-tech uppercase text-[#69706D] block">2. Ceiling Plane</span>
                      <div className="w-full h-16 rounded-xs border border-black/15 shadow-xs" style={{ backgroundColor: c.hex }} />
                      <div className="text-xs font-mono-tech">
                        <span className="font-bold text-[#181B1C] block">{c.code}</span>
                        <span className="text-[#202426] truncate block">{c.name}</span>
                        <span className="text-[10px] text-[#274F61]">{selectedSystem.recommendedFinishes.ceiling}</span>
                      </div>
                    </div>
                  );
                })()}

                {/* Joinery / Trim Element */}
                {(() => {
                  const c = getColour(selectedSystem.joineryColour);
                  return (
                    <div 
                      onClick={() => setSelectedColour(c)}
                      className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/15 space-y-2 hover:border-[#202426] transition-colors cursor-pointer"
                    >
                      <span className="text-[10px] font-mono-tech uppercase text-[#69706D] block">3. Joinery & Woodwork</span>
                      <div className="w-full h-16 rounded-xs border border-black/15 shadow-xs" style={{ backgroundColor: c.hex }} />
                      <div className="text-xs font-mono-tech">
                        <span className="font-bold text-[#181B1C] block">{c.code}</span>
                        <span className="text-[#202426] truncate block">{c.name}</span>
                        <span className="text-[10px] text-[#274F61]">{selectedSystem.recommendedFinishes.joinery}</span>
                      </div>
                    </div>
                  );
                })()}

              </div>
            </div>

            {/* Material Partners */}
            <div className="space-y-2 pt-2 border-t border-[#202426]/10">
              <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">
                Recommended Architectural Material Partners
              </span>
              <div className="flex flex-wrap gap-2">
                {selectedSystem.materialPartners.map((mat) => (
                  <span key={mat} className="px-3 py-1 bg-[#F2EEE5] text-[#202426] rounded text-xs font-medium">
                    {mat}
                  </span>
                ))}
              </div>
            </div>

            {/* Launch In Room Designer CTA */}
            <div className="pt-4 border-t border-[#202426]/10 flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs font-mono-tech text-[#69706D]">
                Experience this system with dynamic daylight angles:
              </span>
              <button
                onClick={() => setCurrentTab('designer')}
                className="px-5 py-2.5 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Simulate in Room Designer</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
