'use client';

import React, { useState } from 'react';
import { COLLECTIONS, Collection } from '@/data/collections';
import { ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { ChevronLeft, ChevronRight, BookOpen, Sliders, Sparkles } from 'lucide-react';

export function ColourIndexBook() {
  const { setCurrentTab, setSelectedColour, setAccentColour } = useApp();
  const [currentPageIndex, setCurrentPageIndex] = useState<number>(0);

  const totalPages = COLLECTIONS.length;
  const currentCollection = COLLECTIONS[currentPageIndex];

  const collectionColours = ALL_COLOURS.filter((c) => c.collection === currentCollection.name);

  const nextPage = () => {
    if (currentPageIndex < totalPages - 1) {
      setCurrentPageIndex(currentPageIndex + 1);
    }
  };

  const prevPage = () => {
    if (currentPageIndex > 0) {
      setCurrentPageIndex(currentPageIndex - 1);
    }
  };

  return (
    <section className="min-h-screen bg-[#EAE6DC] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/15 pb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#274F61]" />
            <span className="text-xs font-mono-tech tracking-widest text-[#202426] uppercase font-bold">
              The Bristol Colour Index · Volume I
            </span>
          </div>
          <div className="flex items-center gap-3 text-xs font-mono-tech">
            <span className="text-[#69706D]">
              Collection {currentPageIndex + 1} of {totalPages}
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={prevPage}
                disabled={currentPageIndex === 0}
                className="p-1.5 rounded bg-white disabled:opacity-40 border border-[#202426]/20 hover:bg-[#F2EEE5] cursor-pointer"
                aria-label="Previous page"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextPage}
                disabled={currentPageIndex === totalPages - 1}
                className="p-1.5 rounded bg-white disabled:opacity-40 border border-[#202426]/20 hover:bg-[#F2EEE5] cursor-pointer"
                aria-label="Next page"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* The Open Architectural Book Layout (Spread View) */}
        <div className="bg-[#F2EEE5] rounded-xl shadow-2xl border border-[#202426]/20 overflow-hidden grid grid-cols-1 lg:grid-cols-2 relative">
          
          {/* Subtle Book Spine Gutter Divider */}
          <div className="hidden lg:block absolute inset-y-0 left-1/2 w-8 -translate-x-1/2 bg-gradient-to-r from-black/10 via-black/20 to-black/10 pointer-events-none z-10" />

          {/* Left Page (Spread Left) */}
          <div className="p-8 sm:p-12 space-y-6 border-b lg:border-b-0 lg:border-r border-[#202426]/15 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex justify-between items-center text-[10px] font-mono-tech uppercase text-[#69706D] border-b border-[#202426]/10 pb-2">
                <span>Bristol Architectural Archive</span>
                <span>Plate {currentPageIndex + 1 < 10 ? '0' + (currentPageIndex + 1) : currentPageIndex + 1}</span>
              </div>

              <div className="space-y-1">
                <span className="text-xs font-mono-tech text-[#274F61] uppercase tracking-widest font-semibold block">
                  Collection #{currentPageIndex + 1}
                </span>
                <h2 className="text-3xl sm:text-4xl font-serif-luxury font-normal text-[#181B1C]">
                  {currentCollection.name}
                </h2>
                <p className="text-xs font-mono-tech text-[#69706D] italic">
                  {currentCollection.subtitle}
                </p>
              </div>

              <p className="text-sm text-[#202426]/90 leading-relaxed font-serif">
                {currentCollection.description}
              </p>

              <div className="space-y-2 pt-3 border-t border-[#202426]/10 text-xs font-mono-tech">
                <span className="text-[10px] text-[#69706D] uppercase block">Architectural Context:</span>
                <p className="text-[#202426]/80">{currentCollection.architecturalContext}</p>
              </div>

              <div className="space-y-1.5 pt-1">
                <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">
                  Dominant Geological & Built Materials:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {currentCollection.dominantMaterials.map((mat) => (
                    <span key={mat} className="px-2 py-0.5 bg-white border border-[#202426]/10 text-xs rounded text-[#202426]">
                      {mat}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-6 border-t border-[#202426]/10 text-[10px] font-mono-tech text-[#69706D] flex justify-between">
              <span>Bristol Colour Works Ltd · 2026 Edition</span>
              <span>Page {currentPageIndex * 2 + 1}</span>
            </div>
          </div>

          {/* Right Page (Spread Right): Curated Colour Plates & Swatches */}
          <div className="p-8 sm:p-12 space-y-6 flex flex-col justify-between bg-white/60">
            <div className="space-y-4">
              <div className="flex justify-between items-center text-[10px] font-mono-tech uppercase text-[#69706D] border-b border-[#202426]/10 pb-2">
                <span>Pigment Index & Spectral Swatches</span>
                <span>Page {currentPageIndex * 2 + 2}</span>
              </div>

              {/* Grid of Key Colours in Collection */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {collectionColours.map((colour) => (
                  <div
                    key={colour.id}
                    onClick={() => {
                      setSelectedColour(colour);
                      setAccentColour(colour.hex);
                      setCurrentTab('explorer');
                    }}
                    className="p-3 bg-white rounded border border-[#202426]/15 space-y-2 hover:border-[#202426] hover:shadow-md transition-all cursor-pointer group"
                  >
                    <div 
                      className="w-full h-16 rounded-xs border border-black/10 shadow-inner group-hover:scale-[1.02] transition-transform"
                      style={{ backgroundColor: colour.hex }}
                    />
                    <div className="text-[11px] font-mono-tech space-y-0.5">
                      <span className="font-bold text-[#181B1C] block">{colour.code}</span>
                      <span className="text-[#202426] truncate block leading-tight">{colour.name}</span>
                      <span className="text-[9px] text-[#69706D] block">LRV {colour.lrv}% · {colour.undertone}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Spread Navigation */}
            <div className="pt-6 border-t border-[#202426]/10 flex items-center justify-between">
              <button
                onClick={() => setCurrentTab('explorer')}
                className="text-xs font-mono-tech text-[#274F61] hover:underline cursor-pointer"
              >
                Inspect All Formulations in Explorer →
              </button>

              <div className="flex gap-2">
                <button
                  onClick={prevPage}
                  disabled={currentPageIndex === 0}
                  className="px-3 py-1 bg-white border border-[#202426]/20 rounded text-xs font-mono-tech disabled:opacity-40 hover:bg-[#F2EEE5] cursor-pointer"
                >
                  Turn Back
                </button>
                <button
                  onClick={nextPage}
                  disabled={currentPageIndex === totalPages - 1}
                  className="px-3 py-1 bg-[#202426] text-white rounded text-xs font-mono-tech disabled:opacity-40 hover:bg-[#274F61] cursor-pointer"
                >
                  Turn Forward
                </button>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
