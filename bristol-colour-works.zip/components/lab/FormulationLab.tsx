'use client';

import React, { useState, useMemo } from 'react';
import { PIGMENTS, Pigment } from '@/data/pigments';
import { useApp } from '@/context/AppContext';
import { Sparkles, Sliders, RefreshCw, Save, ShoppingBag, ShieldCheck, Check, Beaker } from 'lucide-react';

export function FormulationLab() {
  const { addToCart, savePalette, isTradeMode, setAccentColour } = useApp();

  // Pigment percentage sliders
  const [pigmentWeights, setPigmentWeights] = useState<Record<string, number>>({
    'pig-01': 45, // Titanium White
    'pig-02': 25, // Yellow Ochre
    'pig-03': 0,  // Iron Oxide Red
    'pig-04': 15, // Ultramarine Blue
    'pig-05': 10, // Carbon Black
    'pig-06': 5,  // Chromium Oxide Green
    'pig-07': 0,  // Raw Umber
    'pig-08': 0   // Phthalo Green
  });

  const [customName, setCustomName] = useState<string>('Avon Gorge Mineral Formula');
  const [selectedBase, setSelectedBase] = useState<'Architectural Matt 2%' | 'Eggshell 15%' | 'Satin 30%' | 'Silicate Exterior'>('Architectural Matt 2%');
  const [formulaId] = useState<string>(`F-${Math.floor(100 + Math.random() * 900)}-26`);
  const [batchSaved, setBatchSaved] = useState(false);
  const [sampleOrdered, setSampleOrdered] = useState(false);

  // Normalize and calculate resulting color
  const calculatedColour = useMemo(() => {
    const totalWeight = Object.values(pigmentWeights).reduce((sum, w) => sum + w, 0) || 1;

    // Base color components in RGB weighted sum
    const rgbMap: Record<string, [number, number, number]> = {
      'pig-01': [248, 248, 246], // White
      'pig-02': [208, 158, 90],  // Ochre
      'pig-03': [147, 70, 55],   // Iron Red
      'pig-04': [30, 63, 102],   // Ultramarine
      'pig-05': [24, 27, 28],    // Carbon Black
      'pig-06': [70, 89, 78],    // Chromium Green
      'pig-07': [94, 72, 58],    // Raw Umber
      'pig-08': [28, 91, 82]     // Phthalo Green
    };

    let rSum = 0, gSum = 0, bSum = 0;
    Object.entries(pigmentWeights).forEach(([id, weight]) => {
      const rgb = rgbMap[id] || [200, 200, 200];
      const normWeight = weight / totalWeight;
      rSum += rgb[0] * normWeight;
      gSum += rgb[1] * normWeight;
      bSum += rgb[2] * normWeight;
    });

    const r = Math.max(0, Math.min(255, Math.round(rSum)));
    const g = Math.max(0, Math.min(255, Math.round(gSum)));
    const b = Math.max(0, Math.min(255, Math.round(bSum)));
    const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase()}`;
    const lrv = Math.round(((r * 0.2126 + g * 0.7152 + b * 0.0722) / 255) * 100);

    return { r, g, b, hex, lrv, totalWeight };
  }, [pigmentWeights]);

  const handleWeightChange = (id: string, val: number) => {
    setPigmentWeights((prev) => ({
      ...prev,
      [id]: Math.max(0, Math.min(100, val))
    }));
  };

  const handleOrderLabSample = () => {
    addToCart({
      id: `lab-sample-${Date.now()}`,
      type: 'sample_pot',
      colourCode: formulaId,
      colourName: customName,
      hex: calculatedColour.hex,
      finish: 'Architectural Matt',
      size: '100ml Pot',
      quantity: 1,
      unitPrice: isTradeMode ? 6.40 : 8.00 // custom formulation small batch
    });
    setSampleOrdered(true);
    setTimeout(() => setSampleOrdered(false), 2500);
  };

  const handleSaveToPalettes = () => {
    savePalette({
      id: `pal-custom-${Date.now()}`,
      title: customName,
      colours: [formulaId, 'BR-001', 'BR-061', 'BR-072'],
      createdAt: 'Custom Formulation Lab'
    });
    setBatchSaved(true);
    setTimeout(() => setBatchSaved(false), 2500);
  };

  const resetRecipe = () => {
    setPigmentWeights({
      'pig-01': 60,
      'pig-02': 20,
      'pig-03': 0,
      'pig-04': 10,
      'pig-05': 10,
      'pig-06': 0,
      'pig-07': 0,
      'pig-08': 0
    });
  };

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-2">
            <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold flex items-center gap-1.5">
              <Beaker className="w-4 h-4" /> Architectural Paint Laboratory
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
              Pigment Formulation Lab
            </h1>
            <p className="text-xs sm:text-sm text-[#69706D] max-w-xl">
              Combine authentic mineral and inorganic pigments in real time to produce custom architectural batches and certified laboratory formula cards.
            </p>
          </div>

          <button
            onClick={resetRecipe}
            className="px-3 py-1.5 bg-white border border-[#202426]/20 hover:border-[#202426] text-xs font-mono-tech text-[#202426] rounded transition-colors cursor-pointer flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Reset Proportions</span>
          </button>
        </div>

        {/* 2-Column Interface */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Pigment Mixing Console (7 Cols) */}
          <div className="lg:col-span-7 bg-white rounded-lg border border-[#202426]/15 p-6 space-y-6 shadow-xs">
            
            <div className="flex items-center justify-between border-b border-[#202426]/10 pb-3">
              <div>
                <h3 className="text-xs font-mono-tech font-bold uppercase text-[#202426]">
                  Active Pigment Sliders (0 – 100 Parts)
                </h3>
                <span className="text-[10px] font-mono-tech text-[#69706D]">
                  Mineral loading automatically normalised to 100% volumetric base
                </span>
              </div>
            </div>

            {/* Sliders Grid */}
            <div className="space-y-4">
              {PIGMENTS.map((pig) => {
                const currentWeight = pigmentWeights[pig.id] || 0;
                return (
                  <div key={pig.id} className="space-y-1 bg-[#F2EEE5]/40 p-3 rounded border border-[#202426]/10">
                    <div className="flex items-center justify-between text-xs font-mono-tech">
                      <div className="flex items-center gap-2">
                        <div className="w-3.5 h-3.5 rounded-xs border border-black/20" style={{ backgroundColor: pig.hexPreview }} />
                        <span className="font-semibold text-[#181B1C]">{pig.name}</span>
                        <span className="text-[10px] text-[#69706D]">({pig.colourIndex})</span>
                      </div>
                      <span className="font-bold text-[#202426]">{currentWeight} pts</span>
                    </div>

                    <div className="flex items-center gap-3">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={currentWeight}
                        onChange={(e) => handleWeightChange(pig.id, Number(e.target.value))}
                        className="w-full h-2 bg-[#E6E4DD] rounded-lg appearance-none cursor-pointer accent-[#202426]"
                      />
                    </div>
                    <span className="text-[9px] font-mono-tech text-[#69706D] block">
                      {pig.contribution}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Base Selection */}
            <div className="pt-2 border-t border-[#202426]/10 space-y-2">
              <label className="text-xs font-semibold font-mono-tech text-[#202426] uppercase block">
                Select Base Chemistry
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {['Architectural Matt 2%', 'Eggshell 15%', 'Satin 30%', 'Silicate Exterior'].map((b) => (
                  <button
                    key={b}
                    onClick={() => setSelectedBase(b as any)}
                    className={`p-2 text-xs font-mono-tech rounded border transition-colors cursor-pointer text-center ${
                      selectedBase === b
                        ? 'bg-[#202426] text-white border-[#202426]'
                        : 'bg-[#F2EEE5] text-[#202426] border-[#202426]/20'
                    }`}
                  >
                    {b}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Architectural Formula Card (Section 50) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* The Signature Formula Card */}
            <div className="bg-[#E6E4DD] rounded-lg border border-[#202426]/30 p-6 sm:p-8 space-y-6 shadow-md font-mono-tech">
              
              {/* Header Lockup */}
              <div className="border-b border-[#202426]/20 pb-4 space-y-1">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] uppercase tracking-widest text-[#202426]/70">
                    Bristol Colour Works Laboratory
                  </span>
                  <span className="text-[10px] text-[#202426] font-bold">
                    BS 4800 / ISO 9001
                  </span>
                </div>
                <h3 className="text-xl font-bold tracking-wider text-[#181B1C] uppercase pt-1">
                  Formula Certificate
                </h3>
              </div>

              {/* Large Digital Swatch Box */}
              <div 
                className="w-full aspect-16/9 rounded-xs border border-[#202426]/40 p-4 flex flex-col justify-between shadow-inner transition-colors duration-300 relative"
                style={{ backgroundColor: calculatedColour.hex }}
              >
                <div className="flex justify-between items-start">
                  <span className="text-xs bg-black/50 backdrop-blur-sm text-white px-2 py-0.5 rounded-xs">
                    {formulaId}
                  </span>
                  <span className="text-xs bg-white/90 text-[#202426] px-2 py-0.5 rounded-xs font-bold">
                    LRV {calculatedColour.lrv}%
                  </span>
                </div>

                <div className="bg-black/40 backdrop-blur-xs p-2 rounded-xs text-white">
                  <span className="text-[9px] uppercase tracking-wider block">Custom Mix</span>
                  <span className="text-sm font-semibold">{customName}</span>
                </div>
              </div>

              {/* Formula Technical Specification Breakdown */}
              <div className="space-y-2 text-xs border-y border-[#202426]/20 py-4">
                <div className="flex justify-between">
                  <span className="text-[#69706D] uppercase">Formula Code:</span>
                  <span className="font-bold text-[#181B1C]">{formulaId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#69706D] uppercase">Selected Base:</span>
                  <span className="text-[#181B1C]">{selectedBase}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#69706D] uppercase">Spectral Reflectance (LRV):</span>
                  <span className="font-bold text-[#181B1C]">{calculatedColour.lrv}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#69706D] uppercase">Hexadecimal:</span>
                  <span className="text-[#181B1C]">{calculatedColour.hex}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#69706D] uppercase">RGB Coordinates:</span>
                  <span className="text-[#181B1C]">
                    {calculatedColour.r}, {calculatedColour.g}, {calculatedColour.b}
                  </span>
                </div>
              </div>

              {/* Name Editor */}
              <div className="space-y-1">
                <label className="text-[10px] text-[#69706D] uppercase block">
                  Project / Formula Name
                </label>
                <input
                  type="text"
                  value={customName}
                  onChange={(e) => setCustomName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#202426]/30 rounded text-xs text-[#181B1C] focus:outline-none font-mono-tech"
                />
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleOrderLabSample}
                  className="w-full py-3 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  {sampleOrdered ? <Check className="w-4 h-4 text-emerald-400" /> : <ShoppingBag className="w-4 h-4" />}
                  <span>{sampleOrdered ? 'Lab Sample Pot In Bag' : `Order Wet Lab Sample (100ml) · £${isTradeMode ? '6.40' : '8.00'}`}</span>
                </button>

                <button
                  onClick={handleSaveToPalettes}
                  className="w-full py-2.5 bg-white hover:bg-[#F2EEE5] text-[#202426] border border-[#202426]/30 text-xs font-mono-tech tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {batchSaved ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : <Save className="w-3.5 h-3.5" />}
                  <span>{batchSaved ? 'Saved to Custom Archive' : 'Save Formula to Archive'}</span>
                </button>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
