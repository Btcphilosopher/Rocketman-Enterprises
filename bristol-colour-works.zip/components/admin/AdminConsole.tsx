'use client';

import React, { useState } from 'react';
import { ALL_COLOURS } from '@/data/colours';
import { COLLECTIONS } from '@/data/collections';
import { PIGMENTS } from '@/data/pigments';
import { MATERIALS } from '@/data/materials';
import { SIGNATURE_PROJECTS } from '@/data/projects';
import { BarChart3, Users, Package, ShieldCheck, Database, Layers, CheckCircle2 } from 'lucide-react';

export function AdminConsole() {
  const [activeAdminTab, setActiveAdminTab] = useState<'analytics' | 'colours' | 'trade' | 'orders'>('analytics');

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8 font-mono-tech">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/15 pb-4 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <span className="text-xs uppercase text-[#274F61] font-bold tracking-widest block">
              Internal Design & Operations System
            </span>
            <h1 className="text-2xl sm:text-4xl font-serif-luxury font-normal text-[#181B1C]">
              Bristol Studio Console & Analytics
            </h1>
          </div>

          <div className="flex gap-1.5 bg-[#E6E4DD] p-1 rounded text-xs">
            {[
              { id: 'analytics', label: 'Analytics' },
              { id: 'colours', label: '96 Colours Registry' },
              { id: 'trade', label: 'Trade Accounts' },
              { id: 'orders', label: 'Orders & Production' }
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveAdminTab(t.id as any)}
                className={`px-3 py-1.5 rounded transition-colors cursor-pointer ${
                  activeAdminTab === t.id ? 'bg-[#202426] text-white' : 'text-[#202426] hover:bg-white/50'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab 1: Analytics & Metrics (Section 71 & 72) */}
        {activeAdminTab === 'analytics' && (
          <div className="space-y-6">
            
            {/* KPI Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg border border-[#202426]/10 space-y-1">
                <span className="text-[10px] text-[#69706D] uppercase">Active Formulations</span>
                <span className="text-2xl font-bold text-[#181B1C] block">96 Colours</span>
                <span className="text-[10px] text-emerald-700">12 Bristol Collections</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-[#202426]/10 space-y-1">
                <span className="text-[10px] text-[#69706D] uppercase">Verified Trade Accounts</span>
                <span className="text-2xl font-bold text-[#181B1C] block">148 Practices</span>
                <span className="text-[10px] text-emerald-700">RIBA / BIID Members</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-[#202426]/10 space-y-1">
                <span className="text-[10px] text-[#69706D] uppercase">Monthly Specified Volume</span>
                <span className="text-2xl font-bold text-[#181B1C] block">4,280 Litres</span>
                <span className="text-[10px] text-[#274F61]">Avg 2.5L / 10L Can Mix</span>
              </div>
              <div className="bg-white p-4 rounded-lg border border-[#202426]/10 space-y-1">
                <span className="text-[10px] text-[#69706D] uppercase">Sample Pot Conversion</span>
                <span className="text-2xl font-bold text-[#181B1C] block">68.4%</span>
                <span className="text-[10px] text-emerald-700">+12% vs Industry Standard</span>
              </div>
            </div>

            {/* Most Specified Colours & Finishes Breakdown */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              <div className="bg-white p-6 rounded-lg border border-[#202426]/10 space-y-4">
                <h3 className="text-xs font-bold uppercase text-[#202426] border-b border-[#202426]/10 pb-2">
                  Top 5 Most Specified Architectural Formulations
                </h3>
                <div className="space-y-2.5 text-xs">
                  {[
                    { code: 'BR-041', name: 'Harbourside Blue', share: '24%', volume: '1,027 L', hex: '#274F61' },
                    { code: 'BR-001', name: 'Clifton Honey Limestone', share: '19%', volume: '813 L', hex: '#D7C4A5' },
                    { code: 'BR-061', name: 'Bristol Cream', share: '16%', volume: '684 L', hex: '#F2EEE5' },
                    { code: 'BR-072', name: 'Temple Meads Iron', share: '14%', volume: '599 L', hex: '#4A5053' },
                    { code: 'BR-032', name: 'Clifton Promenade Sage', share: '11%', volume: '470 L', hex: '#7E9181' }
                  ].map((c) => (
                    <div key={c.code} className="flex items-center justify-between p-2 bg-[#F2EEE5]/50 rounded border border-[#202426]/10">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-xs border border-black/15" style={{ backgroundColor: c.hex }} />
                        <span className="font-bold text-[#181B1C]">{c.code}</span>
                        <span className="text-[#69706D] truncate max-w-[140px]">{c.name}</span>
                      </div>
                      <div className="text-right">
                        <span className="font-bold text-[#181B1C]">{c.volume}</span>
                        <span className="text-[10px] text-[#69706D] block">({c.share})</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white p-6 rounded-lg border border-[#202426]/10 space-y-4">
                <h3 className="text-xs font-bold uppercase text-[#202426] border-b border-[#202426]/10 pb-2">
                  Finish Distribution & Substrate Match
                </h3>
                <div className="space-y-3 text-xs">
                  {[
                    { name: 'Architectural Matt 2%', pct: 58, desc: 'Breathable lime plaster & wall surfaces' },
                    { name: 'Architectural Eggshell 15%', pct: 26, desc: 'Joinery, kitchens, doors & architraves' },
                    { name: 'Exterior Masonry Silicate', pct: 9, desc: 'Ashlar facades & boundary brickwork' },
                    { name: 'Satin & Gloss', pct: 7, desc: 'Wrought iron balconies & front doors' }
                  ].map((f) => (
                    <div key={f.name} className="space-y-1">
                      <div className="flex justify-between">
                        <span className="font-semibold text-[#181B1C]">{f.name}</span>
                        <span className="font-bold">{f.pct}%</span>
                      </div>
                      <div className="w-full h-1.5 bg-[#E6E4DD] rounded-full overflow-hidden">
                        <div className="h-full bg-[#274F61]" style={{ width: `${f.pct}%` }} />
                      </div>
                      <span className="text-[10px] text-[#69706D] block">{f.desc}</span>
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Tab 2: Colours Registry */}
        {activeAdminTab === 'colours' && (
          <div className="bg-white rounded-lg border border-[#202426]/10 p-6 space-y-4">
            <div className="flex justify-between items-center border-b border-[#202426]/10 pb-3">
              <h3 className="text-xs font-bold uppercase text-[#202426]">
                Architectural Master Registry (96 Formulations)
              </h3>
              <span className="text-[10px] text-[#69706D]">Status: All Batch Formulas Active</span>
            </div>

            <div className="max-h-[500px] overflow-y-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#E6E4DD] text-[#202426] uppercase text-[10px]">
                  <tr>
                    <th className="p-2.5">Code</th>
                    <th className="p-2.5">Swatch</th>
                    <th className="p-2.5">Name</th>
                    <th className="p-2.5">Collection</th>
                    <th className="p-2.5">Formula ID</th>
                    <th className="p-2.5">LRV</th>
                    <th className="p-2.5">Hex</th>
                    <th className="p-2.5 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#202426]/10">
                  {ALL_COLOURS.map((c) => (
                    <tr key={c.code} className="hover:bg-[#F2EEE5]/40">
                      <td className="p-2.5 font-bold text-[#181B1C]">{c.code}</td>
                      <td className="p-2.5">
                        <div className="w-8 h-4 rounded-xs border border-black/15" style={{ backgroundColor: c.hex }} />
                      </td>
                      <td className="p-2.5 font-medium">{c.name}</td>
                      <td className="p-2.5 text-[#69706D]">{c.collection}</td>
                      <td className="p-2.5 text-[#274F61]">{c.formulaId}</td>
                      <td className="p-2.5 font-bold">{c.lrv}%</td>
                      <td className="p-2.5 text-[#69706D]">{c.hex}</td>
                      <td className="p-2.5 text-right text-emerald-700 text-[10px]">Certified Active</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Trade Accounts */}
        {activeAdminTab === 'trade' && (
          <div className="bg-white rounded-lg border border-[#202426]/10 p-6 space-y-4 text-xs">
            <h3 className="text-xs font-bold uppercase text-[#202426] border-b border-[#202426]/10 pb-3">
              Approved Architect & Trade Partners
            </h3>
            <div className="space-y-3">
              {[
                { name: 'Vance & Partners Architects', type: 'Architecture Practice', location: 'Clifton, Bristol', projects: 8, tier: '20% Trade' },
                { name: 'Redcliffe Interior Design Studio', type: 'Commercial Hospitality', location: 'Redcliffe, Bristol', projects: 12, tier: '20% Trade' },
                { name: 'West Country Heritage Restorations', type: 'Historic Listed Buildings', location: 'Bath / Bristol', projects: 15, tier: '25% Volume' },
                { name: 'Brunel Wharf Developments Ltd', type: 'Residential Developer', location: 'Harbourside, Bristol', projects: 6, tier: '20% Trade' }
              ].map((acc, idx) => (
                <div key={idx} className="p-3 bg-[#F2EEE5]/50 rounded border border-[#202426]/10 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-[#181B1C] block">{acc.name}</span>
                    <span className="text-[10px] text-[#69706D]">{acc.type} · {acc.location}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[10px]">
                      {acc.tier} Active
                    </span>
                    <span className="text-[10px] text-[#69706D] block pt-0.5">{acc.projects} Active Schedules</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Orders & Production */}
        {activeAdminTab === 'orders' && (
          <div className="bg-white rounded-lg border border-[#202426]/10 p-6 space-y-4 text-xs">
            <h3 className="text-xs font-bold uppercase text-[#202426] border-b border-[#202426]/10 pb-3">
              Active Production Batches & Delivery Queue
            </h3>
            <div className="space-y-2.5">
              {[
                { orderId: 'BCW-9402', project: 'Clifton House Drawing Room', litres: '48.0 L', items: '2.5L Arch. Matt (BR-041)', status: 'Mixed & Sealed' },
                { orderId: 'BCW-9403', project: 'Harbourside Boutique Hotel', litres: '240.0 L', items: '10L Arch. Eggshell (BR-073)', status: 'In Production' },
                { orderId: 'BCW-9404', project: 'Brunel Workshop Mezzanine', litres: '74.0 L', items: '5L Arch. Matt (BR-085)', status: 'Ready for Dispatch' }
              ].map((ord) => (
                <div key={ord.orderId} className="p-3 bg-[#F2EEE5]/50 rounded border border-[#202426]/10 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-[#181B1C] block">{ord.orderId} · {ord.project}</span>
                    <span className="text-[10px] text-[#69706D]">{ord.items}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-[#181B1C]">{ord.litres}</span>
                    <span className="text-[10px] text-[#274F61] block font-semibold">{ord.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </section>
  );
}
