'use client';

import React, { useState, useEffect } from 'react';
import { useApp } from '@/context/AppContext';
import { ArrowRight, Sliders, Layers, Sparkles, RefreshCw, Eye } from 'lucide-react';

export function HeroBristolRoom() {
  const { setCurrentTab, setAccentColour } = useApp();
  const [animationStep, setAnimationStep] = useState<number>(0);
  const [heroMode, setHeroMode] = useState<'elevation' | 'brush'>('elevation');
  const [activeAnnotation, setActiveAnnotation] = useState<boolean>(true);

  // Staged architectural reveal animation
  useEffect(() => {
    const timer1 = setTimeout(() => setAnimationStep(1), 800);  // lines drawing
    const timer2 = setTimeout(() => setAnimationStep(2), 2200); // stone wash
    const timer3 = setTimeout(() => setAnimationStep(3), 3600); // deep blue
    const timer4 = setTimeout(() => setAnimationStep(4), 5000); // full photograph
    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
    };
  }, [heroMode]);

  const restartHero = () => {
    setAnimationStep(0);
  };

  return (
    <section className="relative min-h-[90vh] bg-[#F2EEE5] border-b border-[#202426]/10 flex flex-col justify-between overflow-hidden">
      
      {/* Background Architectural Canvas / Image Reveal */}
      <div className="absolute inset-0 z-0">
        
        {/* Layer 0: Pure Chalk Canvas */}
        <div className="absolute inset-0 bg-[#F2EEE5]"></div>

        {/* Layer 1: Architectural SVG Elevation Grid */}
        <div 
          className={`absolute inset-0 transition-opacity duration-1000 ${
            animationStep >= 1 ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <svg className="w-full h-full" viewBox="0 0 1440 900" fill="none" preserveAspectRatio="xMidYMid slice">
            {/* Architectural Grid Lines */}
            <line x1="120" y1="0" x2="120" y2="900" stroke="#202426" strokeWidth="0.5" strokeDasharray="4 4" strokeOpacity="0.25" />
            <line x1="720" y1="0" x2="720" y2="900" stroke="#202426" strokeWidth="0.5" strokeDasharray="4 4" strokeOpacity="0.25" />
            <line x1="1320" y1="0" x2="1320" y2="900" stroke="#202426" strokeWidth="0.5" strokeDasharray="4 4" strokeOpacity="0.25" />
            <line x1="0" y1="240" x2="1440" y2="240" stroke="#202426" strokeWidth="0.5" strokeDasharray="4 4" strokeOpacity="0.25" />
            <line x1="0" y1="680" x2="1440" y2="680" stroke="#202426" strokeWidth="0.5" strokeDasharray="4 4" strokeOpacity="0.25" />

            {/* Room Elevation Contours */}
            <rect x="200" y="160" width="1040" height="580" stroke="#202426" strokeWidth="1.5" strokeOpacity="0.6" className="animate-elevation" />
            {/* Tall Georgian Sash Windows */}
            <rect x="280" y="220" width="220" height="420" stroke="#202426" strokeWidth="1" strokeOpacity="0.5" />
            <line x1="390" y1="220" x2="390" y2="640" stroke="#202426" strokeWidth="0.75" strokeOpacity="0.4" />
            <line x1="280" y1="360" x2="500" y2="360" stroke="#202426" strokeWidth="0.75" strokeOpacity="0.4" />
            <line x1="280" y1="500" x2="500" y2="500" stroke="#202426" strokeWidth="0.75" strokeOpacity="0.4" />

            {/* Adjacent Wall Section */}
            <rect x="620" y="200" width="560" height="480" stroke="#202426" strokeWidth="1" strokeOpacity="0.5" />
            {/* Limestone Fireplace outline */}
            <rect x="800" y="440" width="200" height="240" stroke="#202426" strokeWidth="1.2" strokeOpacity="0.6" />
            <rect x="840" y="500" width="120" height="180" stroke="#202426" strokeWidth="0.75" strokeOpacity="0.4" />
          </svg>
        </div>

        {/* Layer 2: Intermediate Colour Washes */}
        <div 
          className={`absolute inset-0 bg-[#D7C4A5]/30 mix-blend-multiply transition-opacity duration-1000 pointer-events-none ${
            animationStep >= 2 && animationStep < 4 ? 'opacity-100' : 'opacity-0'
          }`}
        />
        <div 
          className={`absolute right-0 top-0 bottom-0 w-1/2 bg-[#274F61]/40 mix-blend-multiply transition-opacity duration-1000 pointer-events-none ${
            animationStep >= 3 && animationStep < 4 ? 'opacity-100' : 'opacity-0'
          }`}
        />

        {/* Layer 3: High-Fidelity Photographic Room Rendering */}
        <div 
          className={`absolute inset-0 transition-opacity duration-1400 ease-out pointer-events-none ${
            animationStep >= 4 ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <img
            src="/images/hero_bristol_room.jpg"
            alt="The Bristol Room: Tall Georgian proportions with deep Avon blue and Clifton limestone walls"
            className="w-full h-full object-cover object-center brightness-95 contrast-105"
            referrerPolicy="no-referrer"
          />
          {/* Subtle architectural gradient overlay for text readability */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#F2EEE5]/95 via-[#F2EEE5]/75 to-transparent sm:w-2/3 lg:w-1/2" />
        </div>
      </div>

      {/* Hero Header Marker */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pt-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-[11px] font-mono-tech tracking-[0.25em] text-[#202426] uppercase">
              Bristol / England
            </span>
            <span className="text-[#202426]/30">·</span>
            <span className="text-[11px] font-mono-tech text-[#69706D] uppercase">
              Material Lab & Architectural Studio
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={restartHero}
              className="p-1.5 rounded border border-[#202426]/20 bg-[#F2EEE5]/80 hover:bg-white text-[#202426] text-xs transition-colors flex items-center gap-1 cursor-pointer font-mono-tech"
              title="Replay Line to Space sequence"
            >
              <RefreshCw className="w-3 h-3" />
              <span className="hidden sm:inline">Sequence</span>
            </button>
            <button
              onClick={() => setActiveAnnotation(!activeAnnotation)}
              className="p-1.5 rounded border border-[#202426]/20 bg-[#F2EEE5]/80 hover:bg-white text-[#202426] text-xs transition-colors flex items-center gap-1 cursor-pointer font-mono-tech"
              title="Toggle architectural notes"
            >
              <Eye className="w-3 h-3" />
              <span className="hidden sm:inline">Notes</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="max-w-2xl space-y-6">
          
          <div className="space-y-2">
            <span className="inline-block text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
              The Science of a Beautiful Room
            </span>
            <h1 className="text-4xl sm:text-6xl font-normal tracking-tight text-[#181B1C] font-serif-luxury leading-[1.08] text-balance">
              Colour is architecture in liquid form.
            </h1>
          </div>

          <p className="text-base sm:text-lg text-[#202426]/80 leading-relaxed font-sans max-w-xl">
            Bristol Colour Works engineers premium architectural paint, room palettes, and colour specifications calibrated to British daylight, limestone, timber, and proportion.
          </p>

          <div className="pt-4 flex flex-wrap items-center gap-4">
            <button
              onClick={() => {
                setCurrentTab('explorer');
                setAccentColour('#274F61');
              }}
              className="px-6 py-3.5 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-widest uppercase transition-all rounded shadow-sm flex items-center gap-2 group cursor-pointer"
            >
              <span>Explore Colour</span>
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <button
              onClick={() => setCurrentTab('designer')}
              className="px-6 py-3.5 bg-white/90 hover:bg-white text-[#202426] border border-[#202426]/25 hover:border-[#202426] text-xs font-semibold tracking-widest uppercase transition-all rounded shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Sliders className="w-4 h-4" />
              <span>Design A Room</span>
            </button>

            <button
              onClick={() => setCurrentTab('systems')}
              className="px-4 py-3.5 text-xs font-mono-tech text-[#202426] hover:text-[#274F61] transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>24 Architectural Systems</span>
            </button>
          </div>

          {/* Quick Colour Swatch Bar */}
          <div className="pt-6 border-t border-[#202426]/15 flex items-center gap-4">
            <span className="text-xs font-mono-tech text-[#69706D] uppercase">
              The Bristol Room Trio:
            </span>
            <div className="flex items-center gap-3">
              <div
                onClick={() => {
                  setAccentColour('#274F61');
                  setCurrentTab('explorer');
                }}
                className="flex items-center gap-2 p-1.5 bg-white/80 border border-[#202426]/15 rounded hover:border-[#202426] transition-all cursor-pointer group"
              >
                <div className="w-4 h-4 rounded-xs bg-[#274F61] shadow-xs" />
                <span className="text-[11px] font-mono-tech text-[#202426] group-hover:font-semibold">BR-041 Blue</span>
              </div>

              <div
                onClick={() => {
                  setAccentColour('#D7C4A5');
                  setCurrentTab('explorer');
                }}
                className="flex items-center gap-2 p-1.5 bg-white/80 border border-[#202426]/15 rounded hover:border-[#202426] transition-all cursor-pointer group"
              >
                <div className="w-4 h-4 rounded-xs bg-[#D7C4A5] shadow-xs" />
                <span className="text-[11px] font-mono-tech text-[#202426] group-hover:font-semibold">BR-001 Stone</span>
              </div>

              <div
                onClick={() => {
                  setAccentColour('#F2EEE5');
                  setCurrentTab('explorer');
                }}
                className="flex items-center gap-2 p-1.5 bg-white/80 border border-[#202426]/15 rounded hover:border-[#202426] transition-all cursor-pointer group"
              >
                <div className="w-4 h-4 rounded-xs bg-[#F2EEE5] border border-black/15 shadow-xs" />
                <span className="text-[11px] font-mono-tech text-[#202426] group-hover:font-semibold">BR-061 Cream</span>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Architectural Notebook Annotations (Section 13) */}
      {activeAnnotation && (
        <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pb-8">
          <div className="bg-[#202426]/90 text-[#F2EEE5] backdrop-blur-md p-4 rounded border border-[#F2EEE5]/20 max-w-xl sm:ml-auto space-y-2 animate-in fade-in slide-in-from-bottom-3 duration-500">
            <div className="flex items-center justify-between border-b border-[#F2EEE5]/15 pb-1.5">
              <span className="text-[10px] font-mono-tech uppercase tracking-widest text-[#D7C4A5]">
                Specification Note · Field Elevation #041
              </span>
              <span className="text-[10px] font-mono-tech text-[#F2EEE5]/60">
                Clifton South-West Aspect
              </span>
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px] font-mono-tech">
              <div>
                <span className="block text-[#F2EEE5]/50 text-[9px] uppercase">Light Condition</span>
                <span className="font-semibold text-white">South-West / 16:30</span>
              </div>
              <div>
                <span className="block text-[#F2EEE5]/50 text-[9px] uppercase">Substrate</span>
                <span className="font-semibold text-white">Lime Plaster</span>
              </div>
              <div>
                <span className="block text-[#F2EEE5]/50 text-[9px] uppercase">Formula</span>
                <span className="font-semibold text-[#D7C4A5]">BR-041 (LRV 8)</span>
              </div>
              <div>
                <span className="block text-[#F2EEE5]/50 text-[9px] uppercase">Finish</span>
                <span className="font-semibold text-white">Arch. Matt 2%</span>
              </div>
            </div>
          </div>
        </div>
      )}

    </section>
  );
}
