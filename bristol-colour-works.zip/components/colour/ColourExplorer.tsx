'use client';

import React, { useState, useMemo } from 'react';
import { Colour, ALL_COLOURS } from '@/data/colours';
import { COLLECTIONS } from '@/data/collections';
import { useApp } from '@/context/AppContext';
import { ColourDetailModal } from './ColourDetailModal';
import { Search, Filter, Grid, List, Sparkles, Layers, SlidersHorizontal, ArrowUpDown } from 'lucide-react';

export function ColourExplorer() {
  const { selectedColour, setSelectedColour, setAccentColour, quickAddSample } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFamily, setSelectedFamily] = useState<string>('All');
  const [selectedCollection, setSelectedCollection] = useState<string>('All');
  const [selectedUndertone, setSelectedUndertone] = useState<string>('All');
  const [minLrv, setMinLrv] = useState<number>(0);
  const [maxLrv, setMaxLrv] = useState<number>(100);
  const [viewMode, setViewMode] = useState<'grid' | 'list' | 'atlas'>('atlas');
  const [modalOpen, setModalOpen] = useState(false);
  const [inspectedColour, setInspectedColour] = useState<Colour | null>(null);

  const families = ['All', 'Stone', 'Earth', 'Blue', 'Green', 'Red', 'Yellow', 'White', 'Grey', 'Dark', 'Architectural Neutrals'];
  const undertones = ['All', 'Warm', 'Cool', 'Neutral', 'Mineral', 'Earthy', 'Oxide'];

  const filteredColours = useMemo(() => {
    return ALL_COLOURS.filter((c) => {
      // Search
      const q = searchQuery.toLowerCase().trim();
      const matchSearch =
        !q ||
        c.name.toLowerCase().includes(q) ||
        c.code.toLowerCase().includes(q) ||
        c.family.toLowerCase().includes(q) ||
        c.collection.toLowerCase().includes(q) ||
        c.undertone.toLowerCase().includes(q) ||
        c.description.toLowerCase().includes(q) ||
        c.recommendedRooms.some((r) => r.toLowerCase().includes(q)) ||
        c.compatibleMaterials.some((m) => m.toLowerCase().includes(q));

      // Family
      const matchFamily = selectedFamily === 'All' || c.family === selectedFamily;

      // Collection
      const matchCollection = selectedCollection === 'All' || c.collection === selectedCollection;

      // Undertone
      const matchUndertone = selectedUndertone === 'All' || c.undertone === selectedUndertone;

      // LRV
      const matchLrv = c.lrv >= minLrv && c.lrv <= maxLrv;

      return matchSearch && matchFamily && matchCollection && matchUndertone && matchLrv;
    });
  }, [searchQuery, selectedFamily, selectedCollection, selectedUndertone, minLrv, maxLrv]);

  const handleOpenDetail = (c: Colour) => {
    setInspectedColour(c);
    setSelectedColour(c);
    setAccentColour(c.hex);
    setModalOpen(true);
  };

  const handleCardHover = (c: Colour) => {
    // Subtle live UI adaptation
    setAccentColour(c.hex);
  };

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Section */}
        <div className="border-b border-[#202426]/10 pb-6 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
              The Colour Engine
            </span>
            <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
              The 96-Colour Architectural Atlas
            </h1>
            <p className="text-xs sm:text-sm text-[#69706D] max-w-xl">
              Engineered with natural pigments, calibrated for British light conditions, and categorized across 12 Bristol architectural collections.
            </p>
          </div>

          {/* View Mode Controls */}
          <div className="flex items-center gap-1 bg-[#E6E4DD] p-1 rounded border border-[#202426]/10">
            <button
              onClick={() => setViewMode('atlas')}
              className={`px-3 py-1.5 rounded text-xs font-mono-tech transition-colors cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'atlas' ? 'bg-[#202426] text-white shadow-xs' : 'text-[#202426] hover:bg-white/50'
              }`}
            >
              <Grid className="w-3.5 h-3.5" />
              <span>Atlas Grid</span>
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`px-3 py-1.5 rounded text-xs font-mono-tech transition-colors cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'grid' ? 'bg-[#202426] text-white shadow-xs' : 'text-[#202426] hover:bg-white/50'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Cards</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`px-3 py-1.5 rounded text-xs font-mono-tech transition-colors cursor-pointer flex items-center gap-1.5 ${
                viewMode === 'list' ? 'bg-[#202426] text-white shadow-xs' : 'text-[#202426] hover:bg-white/50'
              }`}
            >
              <List className="w-3.5 h-3.5" />
              <span>Data Sheet</span>
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="bg-white p-4 sm:p-5 rounded-lg border border-[#202426]/15 space-y-4 shadow-xs">
          
          {/* Top Search Input */}
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#69706D]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by code (BR-041), name, collection, material ('Limestone'), or atmosphere ('Warm blue')..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#181B1C] placeholder:text-[#69706D]/70 focus:outline-none focus:border-[#202426] font-sans"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono-tech text-[#69706D] hover:text-[#202426]"
              >
                Clear
              </button>
            )}
          </div>

          {/* Family Filter Chips */}
          <div className="space-y-1.5">
            <span className="text-[10px] font-mono-tech uppercase tracking-wider text-[#69706D]">
              Colour Families:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {families.map((f) => (
                <button
                  key={f}
                  onClick={() => setSelectedFamily(f)}
                  className={`px-2.5 py-1 text-xs font-mono-tech rounded transition-colors cursor-pointer ${
                    selectedFamily === f
                      ? 'bg-[#202426] text-white'
                      : 'bg-[#F2EEE5] text-[#202426] hover:bg-[#E6E4DD]'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Secondary Filters: Collections, Undertones & LRV Slider */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-[#202426]/10 text-xs font-mono-tech">
            
            {/* Collections Dropdown */}
            <div>
              <label className="block text-[10px] text-[#69706D] uppercase mb-1">Bristol Collection</label>
              <select
                value={selectedCollection}
                onChange={(e) => setSelectedCollection(e.target.value)}
                className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#202426] focus:outline-none"
              >
                <option value="All">All 12 Bristol Collections</option>
                {COLLECTIONS.map((col) => (
                  <option key={col.id} value={col.name}>{col.name}</option>
                ))}
              </select>
            </div>

            {/* Undertone Dropdown */}
            <div>
              <label className="block text-[10px] text-[#69706D] uppercase mb-1">Undertone / Resonance</label>
              <select
                value={selectedUndertone}
                onChange={(e) => setSelectedUndertone(e.target.value)}
                className="w-full p-2 bg-[#F2EEE5]/60 border border-[#202426]/20 rounded text-xs text-[#202426] focus:outline-none"
              >
                {undertones.map((u) => (
                  <option key={u} value={u}>{u === 'All' ? 'All Undertones' : `${u} Undertone`}</option>
                ))}
              </select>
            </div>

            {/* LRV Slider */}
            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-[10px] text-[#69706D] uppercase">Light Reflectance (LRV)</label>
                <span className="text-[10px] font-bold text-[#202426]">{minLrv}% – {maxLrv}%</span>
              </div>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={minLrv}
                  onChange={(e) => setMinLrv(Number(e.target.value))}
                  className="w-full accent-[#202426]"
                />
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={maxLrv}
                  onChange={(e) => setMaxLrv(Number(e.target.value))}
                  className="w-full accent-[#202426]"
                />
              </div>
            </div>

          </div>

          {/* Results Counter */}
          <div className="flex items-center justify-between pt-2 text-[11px] font-mono-tech text-[#69706D]">
            <span>Displaying {filteredColours.length} of 96 Architectural Formulations</span>
            {(selectedFamily !== 'All' || selectedCollection !== 'All' || selectedUndertone !== 'All' || searchQuery || minLrv > 0 || maxLrv < 100) && (
              <button
                onClick={() => {
                  setSelectedFamily('All');
                  setSelectedCollection('All');
                  setSelectedUndertone('All');
                  setSearchQuery('');
                  setMinLrv(0);
                  setMaxLrv(100);
                }}
                className="text-[#274F61] hover:underline cursor-pointer"
              >
                Reset all filters
              </button>
            )}
          </div>

        </div>

        {/* View 1: Atlas Grid (Spectacular 96-tile architectural matrix) */}
        {viewMode === 'atlas' && (
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3">
            {filteredColours.map((colour) => (
              <div
                key={colour.id}
                onClick={() => handleOpenDetail(colour)}
                onMouseEnter={() => handleCardHover(colour)}
                className="group relative aspect-square rounded bg-white p-2.5 border border-[#202426]/15 hover:border-[#202426] hover:shadow-lg transition-all duration-300 cursor-pointer flex flex-col justify-between"
              >
                {/* Large Colour Field Box */}
                <div 
                  className="w-full h-2/3 rounded-xs border border-black/10 transition-transform duration-300 group-hover:scale-[1.02] shadow-xs relative"
                  style={{ backgroundColor: colour.hex }}
                >
                  <span className="absolute top-1 right-1 text-[8px] font-mono-tech px-1 py-0.5 bg-black/40 text-white rounded-xs opacity-0 group-hover:opacity-100 transition-opacity">
                    LRV {colour.lrv}
                  </span>
                </div>

                {/* Metadata */}
                <div className="space-y-0.5 pt-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono-tech font-bold text-[#181B1C]">
                      {colour.code}
                    </span>
                    <span className="text-[8px] font-mono-tech text-[#69706D] truncate max-w-[50%]">
                      {colour.family}
                    </span>
                  </div>
                  <h4 className="text-[11px] font-medium text-[#202426] truncate group-hover:text-[#274F61] transition-colors leading-tight">
                    {colour.name}
                  </h4>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* View 2: Detailed Cards Grid */}
        {viewMode === 'grid' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredColours.map((colour) => (
              <div
                key={colour.id}
                onMouseEnter={() => handleCardHover(colour)}
                className="bg-white rounded-lg border border-[#202426]/15 overflow-hidden hover:shadow-xl transition-all duration-300 flex flex-col justify-between"
              >
                <div>
                  {/* Swatch Header */}
                  <div
                    onClick={() => handleOpenDetail(colour)}
                    className="h-44 p-4 flex flex-col justify-between cursor-pointer relative"
                    style={{ backgroundColor: colour.hex }}
                  >
                    <div className="flex justify-between items-start">
                      <span className="text-xs font-mono-tech bg-black/40 text-white px-2 py-0.5 rounded-xs">
                        {colour.code}
                      </span>
                      <span className="text-xs font-mono-tech bg-white/90 text-[#202426] px-2 py-0.5 rounded-xs font-semibold">
                        LRV {colour.lrv}%
                      </span>
                    </div>

                    <div className="bg-black/30 backdrop-blur-xs p-2 rounded-xs">
                      <span className="text-[10px] font-mono-tech text-white/80 uppercase block">
                        {colour.collection} Collection · {colour.undertone}
                      </span>
                      <h3 className="text-lg font-serif-luxury text-white font-medium">
                        {colour.name}
                      </h3>
                    </div>
                  </div>

                  {/* Card Body */}
                  <div className="p-4 space-y-3">
                    <p className="text-xs text-[#202426]/80 leading-relaxed line-clamp-2">
                      {colour.description}
                    </p>

                    <div className="text-[11px] font-mono-tech text-[#69706D] flex flex-wrap gap-2 pt-1 border-t border-[#202426]/10">
                      <span>Hex: <strong className="text-[#202426]">{colour.hex}</strong></span>
                      <span>·</span>
                      <span>Formula: {colour.formulaId}</span>
                    </div>

                    {/* Compatible Materials Chips */}
                    <div className="flex flex-wrap gap-1 pt-1">
                      {colour.compatibleMaterials.slice(0, 3).map((mat) => (
                        <span key={mat} className="text-[10px] px-2 py-0.5 bg-[#F2EEE5] text-[#202426] rounded">
                          {mat}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="p-4 pt-0 grid grid-cols-2 gap-2">
                  <button
                    onClick={() => handleOpenDetail(colour)}
                    className="py-2 text-xs font-mono-tech bg-[#F2EEE5] hover:bg-[#202426] hover:text-white text-[#202426] rounded transition-colors text-center cursor-pointer"
                  >
                    Inspect Details
                  </button>
                  <button
                    onClick={() => quickAddSample(colour)}
                    className="py-2 text-xs font-mono-tech bg-[#202426] hover:bg-[#274F61] text-white rounded transition-colors text-center cursor-pointer"
                  >
                    + Sample £5.50
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* View 3: Technical Data Sheet Table */}
        {viewMode === 'list' && (
          <div className="bg-white rounded-lg border border-[#202426]/15 overflow-x-auto shadow-xs">
            <table className="w-full text-left text-xs font-mono-tech">
              <thead className="bg-[#E6E4DD] text-[#202426] uppercase text-[10px] tracking-wider border-b border-[#202426]/15">
                <tr>
                  <th className="p-3">Code</th>
                  <th className="p-3">Colour Swatch</th>
                  <th className="p-3">Architectural Name</th>
                  <th className="p-3">Family</th>
                  <th className="p-3">Collection</th>
                  <th className="p-3">LRV</th>
                  <th className="p-3">Hex</th>
                  <th className="p-3">Undertone</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#202426]/10">
                {filteredColours.map((colour) => (
                  <tr
                    key={colour.id}
                    onClick={() => handleOpenDetail(colour)}
                    onMouseEnter={() => handleCardHover(colour)}
                    className="hover:bg-[#F2EEE5]/70 transition-colors cursor-pointer"
                  >
                    <td className="p-3 font-bold text-[#181B1C]">{colour.code}</td>
                    <td className="p-3">
                      <div className="w-10 h-6 rounded-xs border border-black/20" style={{ backgroundColor: colour.hex }} />
                    </td>
                    <td className="p-3 font-medium text-[#181B1C]">{colour.name}</td>
                    <td className="p-3 text-[#69706D]">{colour.family}</td>
                    <td className="p-3 text-[#69706D]">{colour.collection}</td>
                    <td className="p-3 font-bold text-[#202426]">{colour.lrv}%</td>
                    <td className="p-3 text-[#69706D]">{colour.hex}</td>
                    <td className="p-3 text-[#69706D]">{colour.undertone}</td>
                    <td className="p-3 text-right space-x-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenDetail(colour);
                        }}
                        className="px-2 py-1 bg-[#F2EEE5] hover:bg-[#202426] hover:text-white rounded text-[11px]"
                      >
                        Inspect
                      </button>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          quickAddSample(colour);
                        }}
                        className="px-2 py-1 bg-[#202426] text-white hover:bg-[#274F61] rounded text-[11px]"
                      >
                        + Sample
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      </div>

      {/* Modal View */}
      {modalOpen && inspectedColour && (
        <ColourDetailModal
          colour={inspectedColour}
          onClose={() => setModalOpen(false)}
        />
      )}
    </section>
  );
}
