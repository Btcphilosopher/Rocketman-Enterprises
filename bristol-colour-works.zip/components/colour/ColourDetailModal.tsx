'use client';

import React, { useState } from 'react';
import { Colour, ALL_COLOURS } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { X, ShoppingBag, Sliders, Check, Sparkles, Layers, Share2, ArrowRight } from 'lucide-react';

interface ColourDetailModalProps {
  colour: Colour | null;
  onClose: () => void;
}

export function ColourDetailModal({ colour, onClose }: ColourDetailModalProps) {
  const { addToCart, isTradeMode, setCurrentTab, setAccentColour } = useApp();
  const [selectedFinish, setSelectedFinish] = useState<'Architectural Matt' | 'Architectural Eggshell' | 'Satin' | 'Gloss' | 'Exterior Masonry'>('Architectural Matt');
  const [selectedSize, setSelectedSize] = useState<'1L' | '2.5L' | '5L' | '10L' | '20L'>('2.5L');
  const [tinAdded, setTinAdded] = useState(false);
  const [sampleAdded, setSampleAdded] = useState(false);

  if (!colour) return null;

  const tinPrices: Record<string, number> = {
    '1L': 34.00,
    '2.5L': 68.00,
    '5L': 124.00,
    '10L': 230.00,
    '20L': 420.00
  };

  const currentTinPrice = isTradeMode
    ? Math.round(tinPrices[selectedSize] * 0.8)
    : tinPrices[selectedSize];

  const handleAddTin = () => {
    const timestamp = new Date().getTime();
    addToCart({
      id: `tin-${colour.code}-${selectedFinish}-${selectedSize}-${timestamp}`,
      type: 'paint_tin',
      colourId: colour.id,
      colourCode: colour.code,
      colourName: colour.name,
      hex: colour.hex,
      finish: selectedFinish,
      size: selectedSize,
      quantity: 1,
      unitPrice: currentTinPrice
    });
    setTinAdded(true);
    setTimeout(() => setTinAdded(false), 2500);
  };

  const handleAddSample = (type: '100ml Pot' | 'A5 Card') => {
    const timestamp = new Date().getTime();
    const price = type === '100ml Pot' ? (isTradeMode ? 4.40 : 5.50) : (isTradeMode ? 1.60 : 2.00);
    addToCart({
      id: `sample-${colour.code}-${type}-${timestamp}`,
      type: type === '100ml Pot' ? 'sample_pot' : 'sample_card',
      colourId: colour.id,
      colourCode: colour.code,
      colourName: colour.name,
      hex: colour.hex,
      finish: 'Architectural Matt',
      size: type,
      quantity: 1,
      unitPrice: price
    });
    setSampleAdded(true);
    setTimeout(() => setSampleAdded(false), 2500);
  };

  const getColourByCode = (code: string) => ALL_COLOURS.find(c => c.code === code);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 lg:p-8 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-[#F2EEE5] w-full max-w-5xl max-h-[92vh] rounded-lg shadow-2xl border border-[#202426]/20 overflow-y-auto flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="sticky top-0 z-20 bg-[#F2EEE5]/95 backdrop-blur-md px-6 py-4 border-b border-[#202426]/10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-xs font-mono-tech tracking-widest text-[#69706D] uppercase">
              {colour.collection} Collection
            </span>
            <span className="text-[#202426]/30">·</span>
            <span className="text-xs font-mono-tech text-[#202426] font-semibold">
              {colour.code}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setAccentColour(colour.hex);
              }}
              className="px-2.5 py-1 bg-white border border-[#202426]/20 hover:border-[#202426] text-xs font-mono-tech text-[#202426] rounded flex items-center gap-1 cursor-pointer"
              title="Adopt this colour as the platform interface accent"
            >
              <Sparkles className="w-3 h-3" />
              <span>Set as Interface Accent</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-[#202426] hover:bg-[#E6E4DD] rounded transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 sm:p-8">
          
          {/* Left Column: Large Colour Field & 3D Paint Tin Visual */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Primary Colour Field Swatch */}
            <div 
              className="w-full aspect-4/3 rounded shadow-inner border border-black/10 flex flex-col justify-between p-6 transition-all duration-700 relative overflow-hidden"
              style={{ backgroundColor: colour.hex }}
            >
              <div className="flex justify-between items-start">
                <span className="text-xs font-mono-tech tracking-widest bg-black/40 backdrop-blur-sm text-white px-2.5 py-1 rounded-xs">
                  {colour.code}
                </span>
                <span className="text-xs font-mono-tech bg-white/90 text-[#202426] px-2 py-0.5 rounded-xs font-semibold">
                  LRV {colour.lrv}
                </span>
              </div>

              <div>
                <h3 className="text-2xl font-serif-luxury font-medium text-white drop-shadow-md">
                  {colour.name}
                </h3>
                <span className="text-[11px] font-mono-tech text-white/80 uppercase">
                  Undertone: {colour.undertone}
                </span>
              </div>
            </div>

            {/* Architectural Paint Tin Object Mockup */}
            <div className="bg-[#E6E4DD] p-5 rounded border border-[#202426]/15 space-y-3">
              <div className="flex items-center justify-between text-xs font-mono-tech text-[#69706D] uppercase">
                <span>Architectural Vessel</span>
                <span>BS 4800 Verified</span>
              </div>

              <div className="flex items-center gap-4">
                {/* Minimalist Paint Tin Graphic */}
                <div className="w-20 h-24 bg-[#F2EEE5] border border-[#202426]/30 rounded-xs shadow-md flex flex-col justify-between p-2 shrink-0">
                  <div className="w-full h-1 bg-[#202426]/30 rounded-full" />
                  <div className="space-y-0.5 text-center">
                    <span className="text-[7px] font-mono-tech block tracking-widest text-[#202426]/80 uppercase">BCW</span>
                    <div className="w-6 h-3 mx-auto rounded-xs border border-black/20" style={{ backgroundColor: colour.hex }} />
                    <span className="text-[7px] font-mono-tech block font-bold text-[#181B1C]">{colour.code}</span>
                  </div>
                  <div className="text-[6px] font-mono-tech text-center text-[#69706D] uppercase">{selectedSize}</div>
                </div>

                <div className="space-y-1 text-xs">
                  <p className="font-semibold text-[#181B1C]">Architectural Heavy-Gauge Can</p>
                  <p className="text-[#69706D] text-[11px]">Recyclable tinplate packaging with airtight friction lid and laboratory batch stamp.</p>
                  <p className="text-[11px] font-mono-tech text-[#274F61]">Formula ID: {colour.formulaId}</p>
                </div>
              </div>
            </div>

            {/* Pigment Chemistry Table */}
            <div className="bg-white p-4 rounded border border-[#202426]/15 space-y-2">
              <h4 className="text-xs font-semibold font-mono-tech text-[#202426] uppercase">
                Pigment Formulation Profile
              </h4>
              <div className="space-y-1.5 pt-1">
                {colour.pigments.map((p, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs font-mono-tech">
                    <span className="text-[#69706D]">{p.name}</span>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-1.5 bg-[#E6E4DD] rounded-full overflow-hidden">
                        <div className="h-full bg-[#202426]" style={{ width: `${p.percentage}%` }} />
                      </div>
                      <span className="w-8 text-right font-semibold text-[#202426]">{p.percentage}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Technical Specification & Purchasing */}
          <div className="lg:col-span-7 space-y-6">
            
            <div className="space-y-2">
              <div className="flex items-baseline justify-between">
                <h2 className="text-3xl font-serif-luxury font-medium text-[#181B1C]">
                  {colour.name}
                </h2>
                <span className="text-xs font-mono-tech text-[#69706D]">
                  {colour.family} Family
                </span>
              </div>
              <p className="text-sm text-[#202426]/80 leading-relaxed">
                {colour.description}
              </p>
              {colour.historicalNote && (
                <div className="p-3 bg-[#EAE6DC] rounded text-xs text-[#202426]/90 border-l-2 border-[#274F61] italic font-serif">
                  {colour.historicalNote}
                </div>
              )}
            </div>

            {/* Color Metrics Grid (LAB, LCH, RGB, HEX, LRV) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-2.5 bg-white border border-[#202426]/10 rounded text-center">
                <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">LRV Reflectance</span>
                <span className="text-sm font-semibold font-mono-tech text-[#181B1C]">{colour.lrv}%</span>
              </div>
              <div className="p-2.5 bg-white border border-[#202426]/10 rounded text-center">
                <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">Hex Value</span>
                <span className="text-sm font-semibold font-mono-tech text-[#181B1C]">{colour.hex}</span>
              </div>
              <div className="p-2.5 bg-white border border-[#202426]/10 rounded text-center">
                <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">RGB Coordinates</span>
                <span className="text-xs font-semibold font-mono-tech text-[#181B1C]">{colour.rgb.r}, {colour.rgb.g}, {colour.rgb.b}</span>
              </div>
              <div className="p-2.5 bg-white border border-[#202426]/10 rounded text-center">
                <span className="text-[10px] font-mono-tech text-[#69706D] uppercase block">L*A*B Matrix</span>
                <span className="text-xs font-semibold font-mono-tech text-[#181B1C]">{colour.lab.l}, {colour.lab.a}, {colour.lab.b}</span>
              </div>
            </div>

            {/* Finish Selection */}
            <div className="space-y-2">
              <label className="text-xs font-semibold font-mono-tech text-[#202426] uppercase block">
                Select Architectural Finish
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { name: 'Architectural Matt', sheen: '2% Sheen · Breathable Chalky Depth' },
                  { name: 'Architectural Eggshell', sheen: '15% Sheen · Durable Joinery & Kitchens' },
                  { name: 'Satin', sheen: '30% Sheen · Subtle Light Lustre' },
                  { name: 'Gloss', sheen: '75% Sheen · High Reflection Classic' },
                  { name: 'Exterior Masonry', sheen: 'Silicate Breathable Exterior' }
                ].map((f) => (
                  <button
                    key={f.name}
                    onClick={() => setSelectedFinish(f.name as any)}
                    className={`p-2.5 text-left border rounded transition-all cursor-pointer ${
                      selectedFinish === f.name
                        ? 'bg-[#202426] text-white border-[#202426] shadow-xs'
                        : 'bg-white text-[#202426] border-[#202426]/15 hover:border-[#202426]'
                    }`}
                  >
                    <span className="block text-xs font-semibold">{f.name}</span>
                    <span className={`block text-[10px] ${selectedFinish === f.name ? 'text-white/70' : 'text-[#69706D]'}`}>
                      {f.sheen}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Pack Size & Purchase Controls */}
            <div className="space-y-3 pt-2 border-t border-[#202426]/10">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold font-mono-tech text-[#202426] uppercase">
                  Volume & Container
                </label>
                <div className="text-right">
                  <span className="text-lg font-bold font-mono-tech text-[#181B1C]">
                    £{currentTinPrice.toFixed(2)}
                  </span>
                  {isTradeMode && (
                    <span className="block text-[10px] font-mono-tech text-emerald-700">
                      Trade Discount Applied (-20%)
                    </span>
                  )}
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {(['1L', '2.5L', '5L', '10L', '20L'] as const).map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`px-4 py-2 text-xs font-mono-tech font-semibold rounded border transition-colors cursor-pointer ${
                      selectedSize === sz
                        ? 'bg-[#202426] text-white border-[#202426]'
                        : 'bg-white text-[#202426] border-[#202426]/20 hover:border-[#202426]'
                    }`}
                  >
                    {sz} · £{isTradeMode ? Math.round(tinPrices[sz] * 0.8) : tinPrices[sz]}
                  </button>
                ))}
              </div>

              {/* Action Buttons: Add Tin vs Samples */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <button
                  onClick={handleAddTin}
                  className="sm:col-span-2 py-3 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  {tinAdded ? <Check className="w-4 h-4 text-emerald-400" /> : <ShoppingBag className="w-4 h-4" />}
                  <span>{tinAdded ? 'Added to Order Bag' : `Order ${selectedSize} Tin · £${currentTinPrice.toFixed(2)}`}</span>
                </button>

                <button
                  onClick={() => handleAddSample('100ml Pot')}
                  className="py-3 bg-white hover:bg-[#E6E4DD] text-[#202426] border border-[#202426]/30 text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {sampleAdded ? <Check className="w-3.5 h-3.5 text-emerald-700" /> : null}
                  <span>Sample Pot £{isTradeMode ? '4.40' : '5.50'}</span>
                </button>
              </div>
            </div>

            {/* Architectural Colour Relationships */}
            <div className="space-y-4 pt-4 border-t border-[#202426]/10">
              <h4 className="text-xs font-semibold font-mono-tech text-[#202426] uppercase">
                Engineered Colour Relationships
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Pairs Well With */}
                <div className="p-3 bg-white rounded border border-[#202426]/10 space-y-2">
                  <span className="text-[11px] font-mono-tech text-[#69706D] uppercase block">
                    Harmonic Pairs
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {colour.pairsWellWith.map((code) => {
                      const pair = getColourByCode(code);
                      if (!pair) return null;
                      return (
                        <div key={code} className="flex items-center gap-1.5 p-1 bg-[#F2EEE5] rounded border border-[#202426]/10 text-xs">
                          <div className="w-3.5 h-3.5 rounded-xs" style={{ backgroundColor: pair.hex }} />
                          <span className="font-mono-tech text-[11px]">{pair.code}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Contrast & Warm Companion */}
                <div className="p-3 bg-white rounded border border-[#202426]/10 space-y-2">
                  <span className="text-[11px] font-mono-tech text-[#69706D] uppercase block">
                    Architectural Contrast & Companion
                  </span>
                  <div className="flex flex-wrap gap-2">
                    {colour.contrast.map((code) => {
                      const c = getColourByCode(code);
                      if (!c) return null;
                      return (
                        <div key={code} className="flex items-center gap-1.5 p-1 bg-[#F2EEE5] rounded border border-[#202426]/10 text-xs">
                          <div className="w-3.5 h-3.5 rounded-xs" style={{ backgroundColor: c.hex }} />
                          <span className="font-mono-tech text-[11px]">Contrast: {c.code}</span>
                        </div>
                      );
                    })}
                    {colour.warmCompanion && (
                      <div className="flex items-center gap-1.5 p-1 bg-[#F2EEE5] rounded border border-[#202426]/10 text-xs">
                        <div className="w-3.5 h-3.5 rounded-xs" style={{ backgroundColor: getColourByCode(colour.warmCompanion)?.hex || '#D5AA6D' }} />
                        <span className="font-mono-tech text-[11px]">Warm: {colour.warmCompanion}</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Compatible Materials */}
              <div className="space-y-1.5">
                <span className="text-[11px] font-mono-tech text-[#69706D] uppercase block">
                  Material Relationships
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {colour.compatibleMaterials.map((mat) => (
                    <span
                      key={mat}
                      className="px-2.5 py-1 bg-[#EAE6DC] text-[#202426] rounded text-xs font-medium"
                    >
                      {mat}
                    </span>
                  ))}
                </div>
              </div>

              {/* Quick Room Designer Launcher with this Colour */}
              <div className="pt-2">
                <button
                  onClick={() => {
                    onClose();
                    setCurrentTab('designer');
                  }}
                  className="w-full py-2.5 bg-[#E6E4DD] hover:bg-[#202426] hover:text-white text-[#202426] text-xs font-mono-tech tracking-wider uppercase rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Launch Room Designer with {colour.code}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
