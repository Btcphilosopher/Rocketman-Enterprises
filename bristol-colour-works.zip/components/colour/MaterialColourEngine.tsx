'use client';

import React, { useState } from 'react';
import { MATERIALS, Material } from '@/data/materials';
import { ALL_COLOURS, Colour } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { Layers, ArrowRight, Sparkles, Sliders } from 'lucide-react';

export function MaterialColourEngine() {
  const { setCurrentTab, setSelectedColour, setAccentColour } = useApp();
  const [selectedMaterial, setSelectedMaterial] = useState<Material>(MATERIALS[0]);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Stone & Masonry', 'Metals', 'Timbers', 'Minerals & Concrete', 'Textiles'];

  const filteredMaterials = MATERIALS.filter(
    (m) => activeCategory === 'All' || m.category === activeCategory
  );

  const recommendedColours = ALL_COLOURS.filter((c) =>
    selectedMaterial.recommendedPaintColours.includes(c.code)
  );

  return (
    <section className="min-h-screen bg-[#F2EEE5] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="border-b border-[#202426]/10 pb-6 space-y-2">
          <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold">
            Materiality & Architectural Chemistry
          </span>
          <h1 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C]">
            The Material + Colour Engine
          </h1>
          <p className="text-xs sm:text-sm text-[#69706D] max-w-2xl leading-relaxed">
            Paint does not exist in isolation; it lives against stone, timber, metal, and plaster. Select an architectural material to discover mathematically engineered colour relationships.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded text-xs font-mono-tech transition-colors cursor-pointer ${
                activeCategory === cat
                  ? 'bg-[#202426] text-white'
                  : 'bg-white text-[#202426] border border-[#202426]/15 hover:border-[#202426]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Material Selection Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
          {filteredMaterials.map((mat) => {
            const isSelected = selectedMaterial.id === mat.id;
            return (
              <button
                key={mat.id}
                onClick={() => setSelectedMaterial(mat)}
                className={`p-3 rounded-lg border text-left transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                  isSelected
                    ? 'bg-[#202426] text-white border-[#202426] shadow-md ring-2 ring-[#202426]'
                    : 'bg-white text-[#202426] border-[#202426]/15 hover:border-[#202426]'
                }`}
              >
                <div
                  className="w-full h-12 rounded-xs border border-black/15 shadow-inner"
                  style={{ backgroundColor: mat.hexApprox }}
                />
                <div>
                  <span className={`block text-[9px] font-mono-tech uppercase ${isSelected ? 'text-white/60' : 'text-[#69706D]'}`}>
                    {mat.category}
                  </span>
                  <span className="block text-xs font-semibold leading-tight pt-0.5">
                    {mat.name}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Deep Relationship Breakdown for Selected Material */}
        <div className="bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-8 space-y-8 shadow-xs">
          
          {/* Top Material Profile */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start border-b border-[#202426]/10 pb-6">
            <div className="md:col-span-4 space-y-3">
              <div 
                className="w-full aspect-16/10 rounded border border-black/15 p-4 flex flex-col justify-end shadow-inner"
                style={{ backgroundColor: selectedMaterial.hexApprox }}
              >
                <span className="text-xs font-mono-tech font-bold uppercase tracking-wider bg-black/40 text-white px-2 py-1 rounded-xs inline-block w-fit">
                  {selectedMaterial.name}
                </span>
              </div>
            </div>

            <div className="md:col-span-8 space-y-3">
              <div className="flex items-baseline justify-between">
                <h3 className="text-2xl font-serif-luxury font-semibold text-[#181B1C]">
                  {selectedMaterial.name}
                </h3>
                <span className="text-xs font-mono-tech text-[#274F61]">
                  Origin: {selectedMaterial.origin}
                </span>
              </div>

              <p className="text-sm text-[#202426]/80 leading-relaxed">
                {selectedMaterial.description}
              </p>

              <div className="grid grid-cols-2 gap-4 pt-2 text-xs font-mono-tech">
                <div className="p-2.5 bg-[#F2EEE5] rounded border border-[#202426]/10">
                  <span className="block text-[10px] text-[#69706D] uppercase">Tactile Surface Texture</span>
                  <span className="font-medium text-[#181B1C]">{selectedMaterial.tactileTexture}</span>
                </div>
                <div className="p-2.5 bg-[#F2EEE5] rounded border border-[#202426]/10">
                  <span className="block text-[10px] text-[#69706D] uppercase">Reflectance Behaviour</span>
                  <span className="font-medium text-[#181B1C]">{selectedMaterial.reflectance}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Recommended Paint Colours for this Material */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-mono-tech font-bold text-[#202426] uppercase">
                  Engineered Paint Formulations for {selectedMaterial.name}
                </h4>
                <p className="text-xs text-[#69706D]">
                  Calibrated to balance contrast, warmth, and natural mineral light absorption.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              {recommendedColours.map((colour) => (
                <div
                  key={colour.id}
                  onClick={() => {
                    setSelectedColour(colour);
                    setAccentColour(colour.hex);
                    setCurrentTab('explorer');
                  }}
                  className="group bg-[#F2EEE5] rounded-lg border border-[#202426]/15 p-3 space-y-2 hover:border-[#202426] hover:shadow-md transition-all cursor-pointer"
                >
                  <div 
                    className="w-full h-24 rounded-xs border border-black/15 shadow-xs transition-transform group-hover:scale-[1.02]"
                    style={{ backgroundColor: colour.hex }}
                  />
                  <div>
                    <div className="flex justify-between items-center text-[10px] font-mono-tech">
                      <span className="font-bold text-[#181B1C]">{colour.code}</span>
                      <span className="text-[#69706D]">LRV {colour.lrv}%</span>
                    </div>
                    <h5 className="text-xs font-medium text-[#202426] truncate pt-0.5">
                      {colour.name}
                    </h5>
                    <span className="text-[10px] font-mono-tech text-[#274F61] block pt-1">
                      {colour.undertone} undertone
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
