'use client';

import React, { useState, useMemo } from 'react';
import { ALL_COLOURS, Colour } from '@/data/colours';
import { useApp } from '@/context/AppContext';
import { Sparkles, SlidersHorizontal, ArrowRight } from 'lucide-react';

export function ColourWheelInteractive() {
  const { setSelectedColour, setAccentColour, setCurrentTab } = useApp();
  const [selectedHarmony, setSelectedHarmony] = useState<'Complementary' | 'Monochromatic' | 'Analogous' | 'Split Complementary' | 'Triadic' | 'Tonal'>('Complementary');
  const [baseColour, setBaseColour] = useState<Colour>(ALL_COLOURS[10]); // BR-041 Harbourside Blue

  // Calculate harmonies
  const getHarmonies = () => {
    const baseIndex = ALL_COLOURS.findIndex((c) => c.code === baseColour.code);
    if (selectedHarmony === 'Complementary') {
      return [
        baseColour,
        ALL_COLOURS[(baseIndex + 48) % ALL_COLOURS.length]
      ];
    } else if (selectedHarmony === 'Triadic') {
      return [
        baseColour,
        ALL_COLOURS[(baseIndex + 32) % ALL_COLOURS.length],
        ALL_COLOURS[(baseIndex + 64) % ALL_COLOURS.length]
      ];
    } else if (selectedHarmony === 'Analogous') {
      return [
        ALL_COLOURS[(baseIndex - 3 + ALL_COLOURS.length) % ALL_COLOURS.length],
        baseColour,
        ALL_COLOURS[(baseIndex + 3) % ALL_COLOURS.length]
      ];
    } else if (selectedHarmony === 'Split Complementary') {
      return [
        baseColour,
        ALL_COLOURS[(baseIndex + 44) % ALL_COLOURS.length],
        ALL_COLOURS[(baseIndex + 52) % ALL_COLOURS.length]
      ];
    } else if (selectedHarmony === 'Monochromatic' || selectedHarmony === 'Tonal') {
      return ALL_COLOURS.filter((c) => c.family === baseColour.family).slice(0, 4);
    }
    return [baseColour];
  };

  const harmonyColours = getHarmonies();

  // Pre-calculated deterministic rounded arc paths for 24 segments
  const wheelSegments = useMemo(() => {
    return Array.from({ length: 24 }).map((_, i) => {
      const angle = (i / 24) * 2 * Math.PI;
      const nextAngle = ((i + 1) / 24) * 2 * Math.PI;
      const r1 = 110, r2 = 140;
      const x1 = (150 + r1 * Math.cos(angle)).toFixed(2);
      const y1 = (150 + r1 * Math.sin(angle)).toFixed(2);
      const x2 = (150 + r2 * Math.cos(angle)).toFixed(2);
      const y2 = (150 + r2 * Math.sin(angle)).toFixed(2);
      const x3 = (150 + r2 * Math.cos(nextAngle)).toFixed(2);
      const y3 = (150 + r2 * Math.sin(nextAngle)).toFixed(2);
      const x4 = (150 + r1 * Math.cos(nextAngle)).toFixed(2);
      const y4 = (150 + r1 * Math.sin(nextAngle)).toFixed(2);

      const col = ALL_COLOURS[(i * 4) % ALL_COLOURS.length];
      const d = `M ${x1} ${y1} L ${x2} ${y2} A ${r2} ${r2} 0 0 1 ${x3} ${y3} L ${x4} ${y4} A ${r1} ${r1} 0 0 0 ${x1} ${y1} Z`;

      return {
        d,
        col,
        index: i
      };
    });
  }, []);

  return (
    <div className="bg-white rounded-lg border border-[#202426]/15 p-6 sm:p-8 space-y-6 shadow-xs font-mono-tech">
      
      <div className="border-b border-[#202426]/10 pb-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <span className="text-[10px] text-[#274F61] uppercase font-bold tracking-widest block">
            Harmonic Chromatic Engine
          </span>
          <h3 className="text-xl font-serif-luxury font-semibold text-[#181B1C]">
            Architectural Colour Wheel & Geometry
          </h3>
        </div>

        {/* Harmony Mode Selector */}
        <div className="flex flex-wrap gap-1 bg-[#F2EEE5] p-1 rounded border border-[#202426]/10 text-xs">
          {['Complementary', 'Analogous', 'Split Complementary', 'Triadic', 'Tonal', 'Monochromatic'].map((h) => (
            <button
              key={h}
              onClick={() => setSelectedHarmony(h as any)}
              className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                selectedHarmony === h ? 'bg-[#202426] text-white' : 'text-[#202426] hover:bg-white/60'
              }`}
            >
              {h}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Circular Wheel Display & Swatches */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        
        {/* SVG Spectral Ring (5 Cols) */}
        <div className="md:col-span-5 relative aspect-square flex items-center justify-center p-4">
          <svg className="w-full h-full max-w-[280px]" viewBox="0 0 300 300" suppressHydrationWarning>
            {/* Outer Spectral Segments */}
            {wheelSegments.map(({ d, col, index }) => {
              const isBase = col.code === baseColour.code;

              return (
                <path
                  key={index}
                  d={d}
                  fill={col.hex}
                  stroke={isBase ? '#181B1C' : '#FFFFFF'}
                  strokeWidth={isBase ? 2.5 : 0.75}
                  className="cursor-pointer transition-transform hover:scale-105"
                  onClick={() => {
                    setBaseColour(col);
                    setAccentColour(col.hex);
                  }}
                />
              );
            })}

            {/* Inner Center Hub */}
            <circle cx="150" cy="150" r="85" fill="#F2EEE5" stroke="#202426" strokeWidth="1" />
            <text x="150" y="140" textAnchor="middle" fontSize="9" fill="#69706D" fontFamily="monospace" className="uppercase">
              Selected Base
            </text>
            <text x="150" y="160" textAnchor="middle" fontSize="13" fontWeight="bold" fill="#181B1C" fontFamily="monospace">
              {baseColour.code}
            </text>
            <text x="150" y="176" textAnchor="middle" fontSize="9" fill="#274F61" fontFamily="sans-serif">
              {baseColour.name}
            </text>
          </svg>
        </div>

        {/* Harmonies Cards (7 Cols) */}
        <div className="md:col-span-7 space-y-4">
          <div className="flex justify-between items-center text-xs">
            <span className="text-[#69706D] uppercase">
              {selectedHarmony} Architectural Chord ({harmonyColours.length} Colours)
            </span>
            <span className="text-[#202426] font-bold">Delta-E Harmonic Balanced</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {harmonyColours.map((c, idx) => (
              <div
                key={c.code + idx}
                onClick={() => {
                  setSelectedColour(c);
                  setAccentColour(c.hex);
                  setCurrentTab('explorer');
                }}
                className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/15 flex items-center justify-between gap-3 hover:border-[#202426] transition-all cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xs border border-black/15 shadow-xs shrink-0" style={{ backgroundColor: c.hex }} />
                  <div className="text-xs space-y-0.5">
                    <span className="font-bold text-[#181B1C] block">{c.code}</span>
                    <span className="text-[#202426] truncate block max-w-[130px]">{c.name}</span>
                  </div>
                </div>
                <span className="text-[10px] text-[#69706D] font-mono-tech">LRV {c.lrv}%</span>
              </div>
            ))}
          </div>

          <div className="pt-2">
            <button
              onClick={() => setCurrentTab('designer')}
              className="w-full py-2.5 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold uppercase tracking-wider rounded transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Test This Harmony in Room Designer</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
}
