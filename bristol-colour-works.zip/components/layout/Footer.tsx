'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ShieldCheck, ArrowRight, Check } from 'lucide-react';

export function Footer() {
  const { setCurrentTab, accentColour } = useApp();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setTimeout(() => setSubscribed(false), 4000);
      setEmail('');
    }
  };

  return (
    <footer className="bg-[#202426] text-[#E6E4DD] border-t border-[#181B1C] pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#E6E4DD]/10">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 grid grid-cols-2 grid-rows-2 gap-0.5 border border-[#E6E4DD]/40">
                <div className="bg-[#D7C4A5]"></div>
                <div className="bg-[#274F61]"></div>
                <div className="bg-[#934637]"></div>
                <div className="bg-[#69706D]"></div>
              </div>
              <span className="text-sm tracking-widest uppercase font-semibold text-white">
                Bristol Colour Works
              </span>
            </div>
            <p className="text-xs text-[#E6E4DD]/70 max-w-sm leading-relaxed">
              Premium British architectural paint, colour systems, and room specifications engineered for British architecture, light, and materiality.
            </p>
            <div className="pt-2 text-[11px] font-mono-tech text-[#E6E4DD]/50 space-y-1">
              <p>Studio & Laboratory: Underfall Yard, Cumberland Rd, Bristol BS1 6XG</p>
              <p>Manufacturing: St Philips Marsh & Avonmouth Works</p>
            </div>
          </div>

          {/* Navigation Col 1 */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold tracking-wider uppercase text-white font-mono-tech">
              Platform
            </h4>
            <ul className="space-y-2 text-xs text-[#E6E4DD]/70">
              <li>
                <button onClick={() => setCurrentTab('explorer')} className="hover:text-white transition-colors cursor-pointer">
                  The Colour Engine
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('designer')} className="hover:text-white transition-colors cursor-pointer">
                  Design A Room
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('systems')} className="hover:text-white transition-colors cursor-pointer">
                  Architectural Systems
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('materials')} className="hover:text-white transition-colors cursor-pointer">
                  Material Library
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('lab')} className="hover:text-white transition-colors cursor-pointer">
                  Formulation Lab
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('index-book')} className="hover:text-white transition-colors cursor-pointer">
                  The Bristol Colour Index
                </button>
              </li>
            </ul>
          </div>

          {/* Navigation Col 2 */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold tracking-wider uppercase text-white font-mono-tech">
              Specification & Trade
            </h4>
            <ul className="space-y-2 text-xs text-[#E6E4DD]/70">
              <li>
                <button onClick={() => setCurrentTab('architect')} className="hover:text-white transition-colors cursor-pointer">
                  Architect Portal
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('architect')} className="hover:text-white transition-colors cursor-pointer">
                  Paint Schedules & PDF
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('consultant')} className="hover:text-white transition-colors cursor-pointer">
                  Colour Consultation
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('journal')} className="hover:text-white transition-colors cursor-pointer">
                  Architectural Journal
                </button>
              </li>
              <li>
                <button onClick={() => setCurrentTab('admin')} className="hover:text-white transition-colors cursor-pointer text-[#E6E4DD]/40 hover:text-white">
                  Studio Admin Console
                </button>
              </li>
            </ul>
          </div>

          {/* Newsletter Col */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold tracking-wider uppercase text-white font-mono-tech">
              Colour Bulletins
            </h4>
            <p className="text-xs text-[#E6E4DD]/70 leading-relaxed">
              Quarterly essays on architectural colour theory, light science, and heritage restoration.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-2 pt-1">
              <div className="flex">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="architect@practice.co.uk"
                  required
                  className="w-full bg-[#181B1C] border border-[#E6E4DD]/20 text-xs px-3 py-2 text-white placeholder:text-[#E6E4DD]/40 focus:outline-none focus:border-[#D7C4A5] rounded-l"
                />
                <button
                  type="submit"
                  className="px-3 bg-[#D7C4A5] text-[#202426] hover:bg-white transition-colors rounded-r flex items-center justify-center cursor-pointer"
                  aria-label="Subscribe"
                >
                  {subscribed ? <Check className="w-4 h-4 text-emerald-800" /> : <ArrowRight className="w-4 h-4" />}
                </button>
              </div>
              {subscribed && (
                <p className="text-[11px] text-emerald-400 font-mono-tech">
                  Subscribed to the quarterly architectural index.
                </p>
              )}
            </form>
          </div>

        </div>

        {/* Technical Specification Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] font-mono-tech text-[#E6E4DD]/60">
          <div className="flex flex-wrap items-center gap-4 sm:gap-6">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D7C4A5]" />
              VOC Class A+ Ultra-Low Emissive
            </span>
            <span>·</span>
            <span>Lime Plaster Breathable Grade</span>
            <span>·</span>
            <span>BS 4800 / ISO 9001 Calibrated</span>
          </div>
          <div>
            <span>© 2026 Bristol Colour Works Ltd. All rights reserved.</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
