'use client';

import React, { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { ShoppingBag, Menu, X, Sliders, ShieldCheck, Sparkles } from 'lucide-react';

export function Navbar() {
  const { currentTab, setCurrentTab, cart, setIsCartOpen, isTradeMode, setIsTradeMode, accentColour } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'explorer', label: 'Colour' },
    { id: 'designer', label: 'Rooms' },
    { id: 'systems', label: 'Systems' },
    { id: 'materials', label: 'Materials' },
    { id: 'lab', label: 'Laboratory' },
    { id: 'architect', label: 'Projects & Trade' },
    { id: 'consultant', label: 'Design Studio' },
    { id: 'journal', label: 'Journal' },
    { id: 'index-book', label: 'Index Book' }
  ];

  const cartItemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="sticky top-0 z-40 bg-[#F2EEE5]/95 backdrop-blur-md border-b border-[#202426]/10 transition-colors duration-500">
      {/* Top Bar Contract: 3 Zones */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setCurrentTab('home')}
            className="text-left group cursor-pointer focus:outline-none"
          >
            <div className="flex items-center gap-2">
              <div 
                className="w-5 h-5 grid grid-cols-2 grid-rows-2 gap-0.5 border border-[#202426]/30 transition-transform group-hover:scale-105"
                style={{ borderColor: accentColour }}
              >
                <div className="bg-[#D7C4A5]"></div>
                <div className="bg-[#274F61]"></div>
                <div className="bg-[#934637]"></div>
                <div className="bg-[#69706D]"></div>
              </div>
              <span className="text-base sm:text-lg font-semibold tracking-wider text-[#181B1C] uppercase font-sans">
                Bristol Colour Works
              </span>
            </div>
            <span className="block text-[10px] tracking-[0.2em] text-[#69706D] font-mono-tech uppercase">
              Bristol / England
            </span>
          </button>
        </div>

        {/* Zone 2: Navigation Links (Single Line) */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-xs tracking-wider uppercase font-medium text-[#202426]/80">
          {navLinks.map((link) => {
            const isActive = currentTab === link.id;
            return (
              <button
                key={link.id}
                onClick={() => setCurrentTab(link.id)}
                className={`relative py-1 transition-colors hover:text-[#181B1C] cursor-pointer whitespace-nowrap ${
                  isActive ? 'text-[#181B1C] font-semibold' : ''
                }`}
              >
                {link.label}
                {isActive && (
                  <span
                    className="absolute bottom-0 left-0 right-0 h-0.5"
                    style={{ backgroundColor: accentColour }}
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-3 sm:gap-4">
          {/* Trade Mode Toggle */}
          <button
            onClick={() => setIsTradeMode(!isTradeMode)}
            className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded text-[11px] font-mono-tech tracking-wide border transition-all cursor-pointer ${
              isTradeMode
                ? 'bg-[#202426] text-[#F2EEE5] border-[#202426]'
                : 'bg-transparent text-[#69706D] border-[#202426]/20 hover:border-[#202426]'
            }`}
            title="Toggle B2B Trade & Architect Pricing (-20%)"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{isTradeMode ? 'TRADE -20%' : 'TRADE'}</span>
          </button>

          {/* Design A Room CTA */}
          <button
            onClick={() => setCurrentTab('designer')}
            className="hidden md:inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold tracking-wider uppercase text-white bg-[#202426] hover:bg-[#274F61] transition-colors rounded shadow-xs cursor-pointer whitespace-nowrap"
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Design Room</span>
          </button>

          {/* Shop / Cart Button */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative p-2 text-[#202426] hover:text-[#274F61] transition-colors cursor-pointer"
            aria-label="Open Cart"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartItemCount > 0 && (
              <span
                className="absolute -top-1 -right-1 w-4.5 h-4.5 text-[10px] font-bold text-white rounded-full flex items-center justify-center tabular-nums shadow-xs"
                style={{ backgroundColor: accentColour }}
              >
                {cartItemCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#202426] focus:outline-none cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#F2EEE5] border-b border-[#202426]/15 px-6 py-6 space-y-4 animate-in fade-in duration-200">
          <div className="grid grid-cols-2 gap-3 text-xs tracking-wider uppercase font-medium">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  setCurrentTab(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`text-left p-2.5 rounded border border-[#202426]/10 hover:bg-[#E6E4DD] transition-colors ${
                  currentTab === link.id ? 'bg-[#E6E4DD] font-semibold text-[#181B1C]' : 'text-[#202426]/80'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-[#202426]/10 flex flex-col gap-3">
            <button
              onClick={() => {
                setCurrentTab('designer');
                setMobileMenuOpen(false);
              }}
              className="w-full py-3 bg-[#202426] text-white text-xs font-semibold tracking-wider uppercase rounded text-center"
            >
              Design A Room
            </button>
            <button
              onClick={() => {
                setIsTradeMode(!isTradeMode);
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 border border-[#202426]/30 text-xs font-mono-tech tracking-wider uppercase rounded text-center text-[#202426]"
            >
              {isTradeMode ? 'Trade Mode Enabled (-20%)' : 'Switch to Trade Account'}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
