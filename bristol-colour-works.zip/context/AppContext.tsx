'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Colour, ALL_COLOURS } from '@/data/colours';

export interface CartItem {
  id: string;
  type: 'paint_tin' | 'sample_pot' | 'sample_card' | 'colour_box' | 'sample_set';
  colourId?: string;
  colourCode?: string;
  colourName?: string;
  hex?: string;
  finish?: 'Architectural Matt' | 'Architectural Eggshell' | 'Satin' | 'Gloss' | 'Exterior Masonry';
  size?: '1L' | '2.5L' | '5L' | '10L' | '20L' | '100ml Pot' | 'A5 Card' | 'Box Set';
  quantity: number;
  unitPrice: number;
}

export interface SavedRoom {
  id: string;
  title: string;
  roomType: string;
  wallColour: string;
  ceilingColour: string;
  joineryColour: string;
  doorsColour: string;
  trimColour: string;
  floorMaterial: string;
  lightingTime: number;
  orientation: string;
  savedAt: string;
}

export interface SavedPalette {
  id: string;
  title: string;
  colours: string[]; // Codes
  createdAt: string;
}

interface AppContextType {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  selectedColour: Colour | null;
  setSelectedColour: (colour: Colour | null) => void;
  accentColour: string;
  setAccentColour: (hex: string) => void;
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: string) => void;
  updateCartQuantity: (id: string, delta: number) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  savedRooms: SavedRoom[];
  saveRoom: (room: SavedRoom) => void;
  deleteSavedRoom: (id: string) => void;
  savedPalettes: SavedPalette[];
  savePalette: (palette: SavedPalette) => void;
  deleteSavedPalette: (id: string) => void;
  isTradeMode: boolean;
  setIsTradeMode: (enabled: boolean) => void;
  activeProjectDemo: string;
  setActiveProjectDemo: (projectId: string) => void;
  quickAddSample: (colour: Colour) => void;
  quickAddTin: (colour: Colour, finish?: string, size?: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedColour, setSelectedColour] = useState<Colour | null>(ALL_COLOURS[0]);
  const [accentColour, setAccentColour] = useState<string>('#274F61');
  const [cart, setCart] = useState<CartItem[]>([
    {
      id: 'initial-sample-01',
      type: 'sample_pot',
      colourId: 'br-001',
      colourCode: 'BR-001',
      colourName: 'Clifton Honey Limestone',
      hex: '#D7C4A5',
      size: '100ml Pot',
      finish: 'Architectural Matt',
      quantity: 2,
      unitPrice: 5.50
    },
    {
      id: 'initial-sample-02',
      type: 'sample_pot',
      colourId: 'br-041',
      colourCode: 'BR-041',
      colourName: 'Harbourside Blue',
      hex: '#274F61',
      size: '100ml Pot',
      finish: 'Architectural Matt',
      quantity: 1,
      unitPrice: 5.50
    }
  ]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [savedRooms, setSavedRooms] = useState<SavedRoom[]>([
    {
      id: 'room-default-1',
      title: 'Clifton Georgian Drawing Room',
      roomType: 'Living Room',
      wallColour: 'BR-041',
      ceilingColour: 'BR-061',
      joineryColour: 'BR-001',
      doorsColour: 'BR-072',
      trimColour: 'BR-057',
      floorMaterial: 'European Walnut',
      lightingTime: 16.5,
      orientation: 'South Light',
      savedAt: '25 Sep 2026'
    }
  ]);
  const [savedPalettes, setSavedPalettes] = useState<SavedPalette[]>([
    {
      id: 'pal-default-1',
      title: 'Avon Gorge Natural Mineral Triad',
      colours: ['BR-001', 'BR-041', 'BR-061', 'BR-072'],
      createdAt: '25 Sep 2026'
    }
  ]);
  const [isTradeMode, setIsTradeMode] = useState<boolean>(false);
  const [activeProjectDemo, setActiveProjectDemo] = useState<string>('clifton-townhouse');

  const addToCart = (item: CartItem) => {
    setCart(prev => {
      const existing = prev.find(
        i => i.colourCode === item.colourCode && i.type === item.type && i.size === item.size && i.finish === item.finish
      );
      if (existing) {
        return prev.map(i => i === existing ? { ...i, quantity: i.quantity + item.quantity } : i);
      }
      return [...prev, item];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(i => i.id !== id));
  };

  const updateCartQuantity = (id: string, delta: number) => {
    setCart(prev =>
      prev
        .map(item => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const quickAddSample = (colour: Colour) => {
    addToCart({
      id: `sample-${colour.code}-${Date.now()}`,
      type: 'sample_pot',
      colourId: colour.id,
      colourCode: colour.code,
      colourName: colour.name,
      hex: colour.hex,
      size: '100ml Pot',
      finish: 'Architectural Matt',
      quantity: 1,
      unitPrice: isTradeMode ? 4.40 : 5.50
    });
  };

  const quickAddTin = (colour: Colour, finish: string = 'Architectural Matt', size: string = '2.5L') => {
    const prices: Record<string, number> = {
      '1L': 34.00,
      '2.5L': 68.00,
      '5L': 124.00,
      '10L': 230.00,
      '20L': 420.00
    };
    const basePrice = prices[size] || 68.00;
    addToCart({
      id: `tin-${colour.code}-${finish}-${size}-${Date.now()}`,
      type: 'paint_tin',
      colourId: colour.id,
      colourCode: colour.code,
      colourName: colour.name,
      hex: colour.hex,
      finish: finish as any,
      size: size as any,
      quantity: 1,
      unitPrice: isTradeMode ? Math.round(basePrice * 0.8) : basePrice
    });
  };

  const saveRoom = (room: SavedRoom) => {
    setSavedRooms(prev => [room, ...prev.filter(r => r.id !== room.id)]);
  };

  const deleteSavedRoom = (id: string) => {
    setSavedRooms(prev => prev.filter(r => r.id !== id));
  };

  const savePalette = (palette: SavedPalette) => {
    setSavedPalettes(prev => [palette, ...prev.filter(p => p.id !== palette.id)]);
  };

  const deleteSavedPalette = (id: string) => {
    setSavedPalettes(prev => prev.filter(p => p.id !== id));
  };

  return (
    <AppContext.Provider
      value={{
        currentTab,
        setCurrentTab,
        selectedColour,
        setSelectedColour,
        accentColour,
        setAccentColour,
        cart,
        addToCart,
        removeFromCart,
        updateCartQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        savedRooms,
        saveRoom,
        deleteSavedRoom,
        savedPalettes,
        savePalette,
        deleteSavedPalette,
        isTradeMode,
        setIsTradeMode,
        activeProjectDemo,
        setActiveProjectDemo,
        quickAddSample,
        quickAddTin
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
