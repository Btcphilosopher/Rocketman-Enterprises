import type { Metadata } from 'next';
import './globals.css';
import { AppProvider } from '@/context/AppContext';

export const metadata: Metadata = {
  title: 'Bristol Colour Works | Architectural Paint & Colour Design',
  description: 'Bristol Colour Works engineers premium British architectural paint, room palettes, and colour specifications rooted in Bristol architecture and material science.',
  openGraph: {
    title: 'Bristol Colour Works | Architectural Paint & Colour Design',
    description: 'Colour is architecture in liquid form. Premium British paint engineered for light, proportion, and materiality.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bristol Colour Works | Architectural Paint & Colour Design',
    description: 'Colour is architecture in liquid form. Premium British paint engineered for light, proportion, and materiality.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=JetBrains+Mono:wght@400;500&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body suppressHydrationWarning className="bg-[#F2EEE5] text-[#181B1C] selection:bg-[#274F61] selection:text-white">
        <AppProvider>
          {children}
        </AppProvider>
      </body>
    </html>
  );
}
