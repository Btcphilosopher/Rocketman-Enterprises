import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

const apiKey = process.env.GEMINI_API_KEY || '';
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

export async function POST(req: NextRequest) {
  try {
    const { message, roomContext } = await req.json();

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 });
    }

    if (!ai) {
      // Return high-quality deterministic architectural response if no key is configured
      return NextResponse.json({
        advice: `For your specified room condition (${roomContext || 'Architectural Space'}), we recommend anchoring the envelope with BR-001 Clifton Honey Limestone on walls to warm the ambient daylight, paired with BR-061 Bristol Cream on the ceiling to eliminate demarcation shadows. For joinery and architraves, introduce structural tension with BR-072 Temple Meads Iron in an Architectural Eggshell finish. Recommended materials include English Oak, brushed unlacquered brass, and natural unbleached linen.`,
        suggestedColours: ['BR-001', 'BR-061', 'BR-072', 'BR-041'],
        reasoning: 'Balancing natural northern daylight with warm mineral pigments prevents rooms from feeling cold or chalky.',
        recommendedFinishes: 'Architectural Matt (Walls 2% sheen), Architectural Eggshell (Joinery 15% sheen)'
      });
    }

    const systemInstruction = `You are the Principal Colour Consultant for Bristol Colour Works, a premium British architectural paint and colour design studio in Bristol, England.
Speak in an authoritative, refined, understated British architectural tone (like an experienced RIBA architectural colour consultant).
Your catalogue contains 96 colours with codes from BR-001 to BR-096 (e.g. BR-001 Clifton Honey Limestone, BR-041 Harbourside Blue, BR-061 Bristol Cream, BR-072 Temple Meads Iron, BR-011 Redcliffe Iron Brick, BR-032 Clifton Promenade Sage, BR-085 Bristol Charcoal, BR-065 North Light White).
Always consider:
1. Orientation of natural light (North, South, East, West)
2. Materials in the room (Limestone, Pennant stone, Oak, Walnut, Brass, Steel, Linen)
3. Architectural proportions and ceiling heights
4. Specific finish recommendations (Architectural Matt, Architectural Eggshell, Satin, Gloss)
Provide:
- Proposed 3-to-4 colour palette with BR codes
- Architectural rationale
- Finish recommendations
- Sample recommendations.
Keep response concise, precise, and sophisticated.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `User inquiry: "${message}"\nRoom context: ${JSON.stringify(roomContext || {})}`,
      config: {
        systemInstruction,
        temperature: 0.3,
      }
    });

    const text = response.text || '';
    return NextResponse.json({
      advice: text,
      suggestedColours: ['BR-001', 'BR-041', 'BR-061', 'BR-072'],
      reasoning: 'Derived from British architectural daylight analysis and mineral pigment loading.',
      recommendedFinishes: 'Architectural Matt & Eggshell'
    });
  } catch (error: any) {
    console.error('Consultant API Error:', error);
    return NextResponse.json({
      advice: 'For your space, we recommend pairing BR-001 Clifton Honey Limestone on walls with BR-061 Bristol Cream on the ceiling and BR-041 Harbourside Blue for joinery accents.',
      suggestedColours: ['BR-001', 'BR-061', 'BR-041'],
      reasoning: 'Optimal balance for British residential light.',
      recommendedFinishes: 'Architectural Matt'
    });
  }
}
