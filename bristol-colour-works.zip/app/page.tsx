'use client';

import React from 'react';
import { useApp } from '@/context/AppContext';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';
import { HeroBristolRoom } from '@/components/hero/HeroBristolRoom';
import { ColourExplorer } from '@/components/colour/ColourExplorer';
import { RoomDesigner } from '@/components/room/RoomDesigner';
import { ArchitecturalSystemsView } from '@/components/systems/ArchitecturalSystemsView';
import { MaterialColourEngine } from '@/components/colour/MaterialColourEngine';
import { FormulationLab } from '@/components/lab/FormulationLab';
import { PaintCalculator } from '@/components/calculator/PaintCalculator';
import { ProductCatalog } from '@/components/shop/ProductCatalog';
import { CartDrawer } from '@/components/shop/CartDrawer';
import { ArchitectPortal } from '@/components/architect/ArchitectPortal';
import { DesignStudio } from '@/components/consultant/DesignStudio';
import { ColourIndexBook } from '@/components/index-book/ColourIndexBook';
import { JournalSection } from '@/components/journal/JournalSection';
import { AdminConsole } from '@/components/admin/AdminConsole';
import { ColourWheelInteractive } from '@/components/colour/ColourWheelInteractive';
import { COLLECTIONS } from '@/data/collections';
import { ALL_COLOURS } from '@/data/colours';
import { ArrowRight, Sliders, Layers, Sparkles, Building2, BookOpen, Compass, ShieldCheck } from 'lucide-react';

export default function HomePage() {
  const { currentTab, setCurrentTab, setSelectedColour, setAccentColour } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#F2EEE5] text-[#181B1C] selection:bg-[#274F61] selection:text-white">
      {/* Universal Top Bar */}
      <Navbar />

      {/* Main Viewport Router */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <div className="space-y-16 sm:space-y-24">
            
            {/* Signature Hero Elevation */}
            <HeroBristolRoom />

            {/* Section 1: The Core Architectural Philosophy */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="bg-white rounded-xl border border-[#202426]/15 p-8 sm:p-14 shadow-xs grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
                <div className="lg:col-span-7 space-y-4">
                  <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold block">
                    The Central Principle
                  </span>
                  <h2 className="text-3xl sm:text-5xl font-serif-luxury font-normal text-[#181B1C] leading-[1.12]">
                    A wall is not merely a wall. Colour changes scale, depth, and light.
                  </h2>
                  <p className="text-sm sm:text-base text-[#202426]/80 leading-relaxed font-sans pt-1">
                    Bristol Colour Works was founded on a singular architectural conviction: you are not choosing a tin of paint; you are configuring the light reflectance, acoustic depth, and spatial atmosphere of a room.
                  </p>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 text-xs font-mono-tech text-[#202426]">
                    <div className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/10">
                      <span className="block font-bold text-[#181B1C]">96 Formulations</span>
                      <span className="text-[10px] text-[#69706D]">Mineral Pigment Loaded</span>
                    </div>
                    <div className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/10">
                      <span className="block font-bold text-[#181B1C]">24 Systems</span>
                      <span className="text-[10px] text-[#69706D]">Tripartite Specifications</span>
                    </div>
                    <div className="p-3 bg-[#F2EEE5] rounded border border-[#202426]/10">
                      <span className="block font-bold text-[#181B1C]">12 Collections</span>
                      <span className="text-[10px] text-[#69706D]">Rooted in Bristol Fabric</span>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-5 relative aspect-4/3 rounded-lg overflow-hidden border border-[#202426]/20 shadow-md">
                  <img
                    src="/images/clifton_townhouse_interior.jpg"
                    alt="Clifton Georgian Townhouse Interior"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-3 left-3 bg-[#202426]/90 backdrop-blur-sm text-white px-3 py-1 rounded text-[10px] font-mono-tech">
                    Clifton Townhouse · Drawing Room Elevation
                  </div>
                </div>
              </div>
            </section>

            {/* Section 2: 12 Bristol Architectural Collections Spotlight */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#202426]/10 pb-4">
                <div>
                  <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-semibold block">
                    City Fabric & Geology
                  </span>
                  <h2 className="text-3xl sm:text-4xl font-serif-luxury font-normal text-[#181B1C]">
                    The 12 Bristol Collections
                  </h2>
                </div>

                <button
                  onClick={() => setCurrentTab('index-book')}
                  className="text-xs font-mono-tech text-[#274F61] hover:text-[#181B1C] transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Open The Bristol Colour Index →</span>
                </button>
              </div>

              {/* 6 Featured Collection Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {COLLECTIONS.slice(0, 6).map((col) => (
                  <div
                    key={col.id}
                    onClick={() => {
                      setCurrentTab('explorer');
                    }}
                    className="group bg-white rounded-lg border border-[#202426]/15 overflow-hidden flex flex-col justify-between hover:shadow-lg transition-all cursor-pointer"
                  >
                    <div className="p-6 space-y-4">
                      {/* Swatch Band */}
                      <div className="flex h-6 rounded-xs overflow-hidden border border-black/10">
                        {col.hexPalette.map((hex, i) => (
                          <div key={i} className="flex-1 h-full" style={{ backgroundColor: hex }} />
                        ))}
                      </div>

                      <div className="space-y-1">
                        <span className="text-[10px] font-mono-tech text-[#274F61] uppercase font-semibold">
                          Architectural Collection
                        </span>
                        <h3 className="text-xl font-serif-luxury font-semibold text-[#181B1C] group-hover:text-[#274F61] transition-colors">
                          {col.name}
                        </h3>
                        <p className="text-xs font-mono-tech text-[#69706D] italic">
                          {col.subtitle}
                        </p>
                      </div>

                      <p className="text-xs text-[#202426]/75 leading-relaxed font-sans line-clamp-3">
                        {col.description}
                      </p>
                    </div>

                    <div className="p-6 pt-0 border-t border-[#202426]/10 flex items-center justify-between text-xs font-mono-tech text-[#274F61]">
                      <span>{col.keyColours.length} Core Formulations</span>
                      <span className="flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        Explore Collection <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Section 3: Interactive Harmonic Wheel Spotlight */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <ColourWheelInteractive />
            </section>

            {/* Section 4: Signature Demo Project Spotlight (Section 73) */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="bg-[#202426] text-white rounded-xl overflow-hidden grid grid-cols-1 lg:grid-cols-12 shadow-2xl">
                <div className="lg:col-span-6 relative min-h-[320px] lg:min-h-[440px]">
                  <img
                    src="/images/bristol_harbourside_hotel.jpg"
                    alt="Bristol Harbourside Hotel Suite Specification"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-between space-y-6">
                  <div className="space-y-3">
                    <span className="text-xs font-mono-tech tracking-widest text-[#D7C4A5] uppercase font-semibold">
                      Architectural Case Study · Spec #BCW-HTL-2026
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-serif-luxury font-normal text-white">
                      Bristol Harbourside Hotel & Bonded Warehouses
                    </h2>
                    <p className="text-sm text-[#E6E4DD]/80 leading-relaxed font-sans">
                      A 42-room destination hotel and restaurant converting a 19th-century bonded warehouse. Specified in Tidal Navy, Wet Slate, Raw Brass, and Kiln Red with 100% breathable scrubbable finishes.
                    </p>
                  </div>

                  <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4">
                    <div className="text-xs font-mono-tech text-[#D7C4A5]">
                      <span>480 Litres Delivered · Full NBS Paint Schedule</span>
                    </div>

                    <button
                      onClick={() => setCurrentTab('architect')}
                      className="px-5 py-2.5 bg-[#D7C4A5] hover:bg-white text-[#202426] text-xs font-semibold tracking-wider uppercase rounded transition-colors flex items-center gap-2 cursor-pointer"
                    >
                      <Building2 className="w-4 h-4" />
                      <span>Inspect Project Schedule</span>
                    </button>
                  </div>
                </div>
              </div>
            </section>

            {/* Section 5: Final Brand Philosophy (Section 85 & 86) */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
              <div className="bg-[#E6E4DD] rounded-xl border border-[#202426]/20 p-8 sm:p-16 text-center space-y-6">
                <span className="text-xs font-mono-tech tracking-widest text-[#274F61] uppercase font-bold block">
                  Designed in Bristol · Made for Architecture
                </span>
                
                <h2 className="text-4xl sm:text-6xl font-serif-luxury font-normal text-[#181B1C] max-w-3xl mx-auto leading-tight text-balance">
                  Colour changes space.
                </h2>

                <p className="text-sm sm:text-lg text-[#202426]/80 max-w-2xl mx-auto leading-relaxed font-sans">
                  Bristol Colour Works creates premium architectural paint and colour systems for homes, buildings, and rooms with something to say.
                </p>

                <div className="pt-4 flex flex-wrap items-center justify-center gap-4">
                  <button
                    onClick={() => {
                      setCurrentTab('explorer');
                      setAccentColour('#274F61');
                    }}
                    className="px-8 py-3.5 bg-[#202426] hover:bg-[#274F61] text-white text-xs font-semibold tracking-widest uppercase transition-colors rounded shadow-sm cursor-pointer"
                  >
                    Explore Colour Atlas
                  </button>
                  <button
                    onClick={() => setCurrentTab('designer')}
                    className="px-8 py-3.5 bg-white hover:bg-[#F2EEE5] text-[#202426] border border-[#202426]/30 text-xs font-semibold tracking-widest uppercase transition-colors rounded shadow-xs cursor-pointer"
                  >
                    Launch Room Designer
                  </button>
                </div>
              </div>
            </section>

          </div>
        )}

        {/* View Router for Dedicated Sections */}
        {currentTab === 'explorer' && <ColourExplorer />}
        {currentTab === 'designer' && <RoomDesigner />}
        {currentTab === 'systems' && <ArchitecturalSystemsView />}
        {currentTab === 'materials' && <MaterialColourEngine />}
        {currentTab === 'lab' && <FormulationLab />}
        {currentTab === 'calculator' && <PaintCalculator />}
        {currentTab === 'shop' && <ProductCatalog />}
        {currentTab === 'architect' && <ArchitectPortal />}
        {currentTab === 'consultant' && <DesignStudio />}
        {currentTab === 'index-book' && <ColourIndexBook />}
        {currentTab === 'journal' && <JournalSection />}
        {currentTab === 'admin' && <AdminConsole />}
      </main>

      {/* Global Slide-Out Order & Checkout Drawer */}
      <CartDrawer />

      {/* Universal Architectural Footer */}
      <Footer />
    </div>
  );
}
