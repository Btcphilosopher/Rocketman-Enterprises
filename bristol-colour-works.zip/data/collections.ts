export interface Collection {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  architecturalContext: string;
  dominantMaterials: string[];
  keyColours: string[]; // Codes
  hexPalette: string[];
  image: string;
}

export const COLLECTIONS: Collection[] = [
  {
    id: 'clifton',
    name: 'Clifton',
    subtitle: 'Georgian ashlar, lime wash & balanced proportion',
    description: 'Warm honey limestone, chalk, stone, sage, deep green, soft blue, and luminous warm white. Calibrated to the grand window proportions and soft daylight of Royal York Crescent and Sion Hill.',
    architecturalContext: 'Georgian and Regency terraces constructed from local oolitic limestone with delicate wrought-iron balconies overlooking the Avon Gorge.',
    dominantMaterials: ['Clifton Limestone', 'Wrought Iron', 'Natural Lime Plaster', 'Aged Oak'],
    keyColours: ['BR-001', 'BR-009', 'BR-032', 'BR-041', 'BR-061', 'BR-057'],
    hexPalette: ['#D7C4A5', '#EBE5D8', '#7E9181', '#274F61', '#F2EEE5', '#D5AA6D'],
    image: '/images/clifton_townhouse_interior.jpg'
  },
  {
    id: 'harbourside',
    name: 'Harbourside',
    subtitle: 'Tidal salt, deep cobalt, iron quays & marine atmosphere',
    description: 'Deep marine blues, salt grey, wet concrete, industrial red, marine green, and tar black. Reflecting the changing tidal waters of the Floating Harbour and Underfall Yard.',
    architecturalContext: 'Victorian dockland infrastructure, bonded transit sheds, slipways, and industrial maritime engineering dating from the 1809 floating harbour scheme.',
    dominantMaterials: ['Pennant Flagstones', 'Wet Concrete', 'Tidal Timber', 'Oxidized Brass'],
    keyColours: ['BR-041', 'BR-042', 'BR-073', 'BR-011', 'BR-037', 'BR-086'],
    hexPalette: ['#274F61', '#7A9AA8', '#9DA2A1', '#934637', '#2B4A3D', '#181B1C'],
    image: '/images/bristol_harbourside_hotel.jpg'
  },
  {
    id: 'redcliffe',
    name: 'Redcliffe',
    subtitle: 'Kiln-fired brick, glass cones, iron & aged Dundry stone',
    description: 'Brick, terracotta, iron, warm white, aged stone, and deep brown. Rooted in the medieval cave foundations, historic glasshouses, and soaring Dundry stone vaults.',
    architecturalContext: 'Gothic ecclesiastical masonry alongside 18th-century kiln glass cones and sandstone cliff cellars.',
    dominantMaterials: ['Red Kiln Brick', 'Dundry Freestone', 'Cobalt Glass', 'Aged Iron'],
    keyColours: ['BR-011', 'BR-007', 'BR-044', 'BR-061', 'BR-020', 'BR-085'],
    hexPalette: ['#934637', '#D9CEBD', '#1D3B58', '#F2EEE5', '#5E483A', '#202426'],
    image: '/images/hero_bristol_room.jpg'
  },
  {
    id: 'temple',
    name: 'Temple',
    subtitle: 'Structural steel, train sheds, ink & railway amber',
    description: 'Industrial grey, steel, ink, oxide, concrete, and deep blue. An uncompromising architectural palette born from Brunel’s Gothic-revival railway terminus and heavy iron engineering.',
    architecturalContext: 'Massive hammerbeam timber spans, cast-iron columns, and railway engineering infrastructure.',
    dominantMaterials: ['Cast Iron', 'Structural Steel', 'Engineered Concrete', 'Signal Glass'],
    keyColours: ['BR-072', 'BR-085', 'BR-051', 'BR-013', 'BR-073', 'BR-045'],
    hexPalette: ['#4A5053', '#202426', '#C28A38', '#7A3225', '#9DA2A1', '#314E6E'],
    image: '/images/brunel_workshop_space.jpg'
  },
  {
    id: 'hotwells',
    name: 'Hotwells',
    subtitle: 'Mineral spa springs, green-grey Pennant & river reflections',
    description: 'Limestone, cream, green-grey, river blue, and muted charcoal. Soft, mineral-rich tones recalling the historical Georgian spa colonnades below St Vincent’s Rock.',
    architecturalContext: 'Steep river terraces stepping down towards the tidal riverway with Pennant stone retaining walls.',
    dominantMaterials: ['Pennant Sandstone', 'Mineral Limewash', 'River Reed Plaster', 'Slate'],
    keyColours: ['BR-003', 'BR-005', 'BR-061', 'BR-042', 'BR-071', 'BR-085'],
    hexPalette: ['#969B94', '#B8B3A2', '#F2EEE5', '#7A9AA8', '#69706D', '#202426'],
    image: '/images/paint_tin_architectural.jpg'
  },
  {
    id: 'cotham',
    name: 'Cotham',
    subtitle: 'Walled garden olive, stone villas & quiet northern light',
    description: 'Warm grey, olive, stone, soft blue, and deep green. Designed for leafy Victorian hillside villas, quiet study libraries, and domestic interiors.',
    architecturalContext: 'Substantial Victorian stone villas with generous mature gardens and limestone dressings.',
    dominantMaterials: ['Rubble Stone', 'Milled Ashlar', 'Garden Timber', 'Linen'],
    keyColours: ['BR-008', 'BR-035', 'BR-031', 'BR-046', 'BR-058', 'BR-061'],
    hexPalette: ['#C0B7A6', '#6B755E', '#3A4F3D', '#4A6274', '#DEBF8E', '#F2EEE5'],
    image: '/images/clifton_townhouse_interior.jpg'
  },
  {
    id: 'st-pauls',
    name: 'St Pauls',
    subtitle: 'Vibrant civic ochre, brick red, deep green & crisp cream',
    description: 'Brick red, charcoal, cream, deep green, and burnt orange. Celebrating the vibrant cultural layering, classical Portland Square proportion, and rich streetscape energy.',
    architecturalContext: 'Classical Georgian squares combined with lively residential artisan quarters and creative spaces.',
    dominantMaterials: ['Clay Brick', 'Painted Joinery', 'Limestone Ashlar', 'Wrought Iron'],
    keyColours: ['BR-018', 'BR-011', 'BR-004', 'BR-031', 'BR-052', 'BR-085'],
    hexPalette: ['#D09E5A', '#934637', '#E2DAC8', '#3A4F3D', '#BA8841', '#202426'],
    image: '/images/hero_bristol_room.jpg'
  },
  {
    id: 'bedminster',
    name: 'Bedminster',
    subtitle: 'Industrial red, foundry brown, steel & slate blue',
    description: 'Industrial red, brown, steel, cream, and blue-grey. Honoring the smelting foundries, tobacco factories, and sturdy Victorian worker cottages of South Bristol.',
    architecturalContext: 'High-density Victorian red brick street grids with heavy stone kerbing and corrugated industrial canopies.',
    dominantMaterials: ['Hard Red Brick', 'Cast Steel', 'Roofing Slate', 'Foundry Timber'],
    keyColours: ['BR-012', 'BR-015', 'BR-074', 'BR-061', 'BR-072', 'BR-048'],
    hexPalette: ['#B26247', '#C98C51', '#5A6266', '#F2EEE5', '#4A5053', '#3E5866'],
    image: '/images/brunel_workshop_space.jpg'
  },
  {
    id: 'avon',
    name: 'Avon',
    subtitle: 'Estuary mist, limestone strata, woodland canopy & water blue',
    description: 'Water blue, stone, green, mist, and charcoal. Capturing the dramatic transition where the Avon Gorge cuts through ancient limestone down to the Severn Sea.',
    architecturalContext: 'Natural limestone cliff topography meeting civil engineering structures.',
    dominantMaterials: ['Gorge Limestone', 'Ancient Oak', 'Tidal Water', 'Suspension Steel'],
    keyColours: ['BR-010', 'BR-016', 'BR-031', 'BR-043', 'BR-047', 'BR-085'],
    hexPalette: ['#8A8C7F', '#7A6E5E', '#3A4F3D', '#285A5D', '#B2C4CE', '#202426'],
    image: '/images/hero_bristol_room.jpg'
  },
  {
    id: 'brunel',
    name: 'Brunel',
    subtitle: 'Riveted iron, marine copper, boiler oxide & precision black',
    description: 'Iron, black, copper, oxide red, steel, and cream. Direct architectural homage to Isambard Kingdom Brunel’s monumental structures: SS Great Britain and Clifton Suspension Bridge.',
    architecturalContext: 'Pioneering 19th-century maritime dry docks, riveted wrought-iron plates, and heroic civil engineering.',
    dominantMaterials: ['Riveted Wrought Iron', 'Sheet Copper', 'Oxide Enamel', 'Hard Oak'],
    keyColours: ['BR-085', 'BR-086', 'BR-013', 'BR-019', 'BR-045', 'BR-061'],
    hexPalette: ['#202426', '#181B1C', '#7A3225', '#A76448', '#314E6E', '#F2EEE5'],
    image: '/images/brunel_workshop_space.jpg'
  },
  {
    id: 'bristol-byzantine',
    name: 'Bristol Byzantine',
    subtitle: 'Polychromatic terracotta, Moorish arches & smoky blue',
    description: 'Deep terracotta, brick, olive, cream, dark green, and smoky blue. Inspired by the distinctive Venetian-Gothic and Moorish industrial warehouses of Victorian Bristol.',
    architecturalContext: 'Intricate polychromatic brickwork, rounded arches, and decorative ceramic roundels on industrial warehouses.',
    dominantMaterials: ['Polychrome Brick', 'Moulded Terracotta', 'Glazed Tile', 'Dark Walnut'],
    keyColours: ['BR-017', 'BR-038', 'BR-046', 'BR-061', 'BR-011', 'BR-085'],
    hexPalette: ['#8E4535', '#545C44', '#4A6274', '#F2EEE5', '#934637', '#202426'],
    image: '/images/bristol_harbourside_hotel.jpg'
  },
  {
    id: 'west-country-modern',
    name: 'West Country Modern',
    subtitle: 'Luminous chalk, raw concrete, pale sage & honest timber',
    description: 'Warm white, concrete, pale green, blue-grey, timber, and charcoal. A contemporary British architectural approach pairing local materials with crisp daylight calibration.',
    architecturalContext: 'Contemporary residential renovations, open-plan extensions, and sustainable West Country architecture.',
    dominantMaterials: ['Board-Marked Concrete', 'White Ash', 'Lime Plaster', 'Zinc'],
    keyColours: ['BR-061', 'BR-065', 'BR-066', 'BR-034', 'BR-073', 'BR-085'],
    hexPalette: ['#F2EEE5', '#EDE8DF', '#E3DFD5', '#A3B39E', '#9DA2A1', '#202426'],
    image: '/images/clifton_townhouse_interior.jpg'
  }
];
