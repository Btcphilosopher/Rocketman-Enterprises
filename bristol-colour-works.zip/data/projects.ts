export interface RoomScheduleItem {
  room: string;
  type: string;
  wallColour: string;
  ceilingColour: string;
  joineryColour: string;
  doorsColour: string;
  trimColour: string;
  finish: 'Architectural Matt' | 'Architectural Eggshell' | 'Satin' | 'Gloss' | 'Exterior Masonry';
  materials: string[];
  coats: number;
  areaSqM: number;
  litresRequired: number;
  status: 'Specified' | 'Approved' | 'In Production' | 'Delivered';
}

export interface SignatureProject {
  id: string;
  name: string;
  location: string;
  typology: 'Residential Heritage' | 'Hospitality Commercial' | 'Workplace & Industrial' | 'Contemporary Heritage';
  client: string;
  year: string;
  description: string;
  heroImage: string;
  rooms: RoomScheduleItem[];
  paletteOverview: string[]; // Codes
  totalLitres: number;
  status: string;
}

export const SIGNATURE_PROJECTS: SignatureProject[] = [
  {
    id: 'clifton-townhouse',
    name: 'Clifton Townhouse',
    location: 'Royal York Crescent, Clifton, Bristol BS8',
    typology: 'Residential Heritage',
    client: 'Private Residence (Listed Grade II*)',
    year: '2025',
    description: 'Complete interior architectural colour restoration for a 5-storey Georgian townhouse overlooking the Avon Gorge. The scheme uses breathable lime-compatible paint specifications to honor historic plaster and monumental window proportions.',
    heroImage: '/images/clifton_townhouse_interior.jpg',
    paletteOverview: ['BR-001', 'BR-032', 'BR-041', 'BR-061', 'BR-072', 'BR-057'],
    totalLitres: 142.5,
    status: 'Completed Specification',
    rooms: [
      {
        room: 'Entrance Hall & Staircase',
        type: 'Circulation',
        wallColour: 'BR-001',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-072',
        doorsColour: 'BR-085',
        trimColour: 'BR-061',
        finish: 'Architectural Matt',
        materials: ['Clifton Limestone', 'Wrought Iron', 'Pennant Stone'],
        coats: 2,
        areaSqM: 68,
        litresRequired: 19.5,
        status: 'Delivered'
      },
      {
        room: 'First Floor Drawing Room',
        type: 'Living',
        wallColour: 'BR-041',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-001',
        doorsColour: 'BR-072',
        trimColour: 'BR-057',
        finish: 'Architectural Matt',
        materials: ['Walnut', 'French Polish', 'Limestone Fireplace', 'Silk-Linen'],
        coats: 2,
        areaSqM: 85,
        litresRequired: 24.0,
        status: 'Delivered'
      },
      {
        room: 'Formal Dining Room',
        type: 'Dining',
        wallColour: 'BR-032',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-072',
        doorsColour: 'BR-085',
        trimColour: 'BR-001',
        finish: 'Architectural Matt',
        materials: ['English Oak', 'Brass Chandeliers', 'Linen'],
        coats: 2,
        areaSqM: 54,
        litresRequired: 15.5,
        status: 'Delivered'
      },
      {
        room: 'Lower Ground Kitchen & Snug',
        type: 'Kitchen',
        wallColour: 'BR-001',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-033',
        doorsColour: 'BR-072',
        trimColour: 'BR-004',
        finish: 'Architectural Eggshell',
        materials: ['Pennant Flagstones', 'Honied Ashlar', 'Solid Ash'],
        coats: 2,
        areaSqM: 72,
        litresRequired: 21.0,
        status: 'Delivered'
      },
      {
        room: 'Library & Private Study',
        type: 'Study',
        wallColour: 'BR-085',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-085',
        doorsColour: 'BR-085',
        trimColour: 'BR-085',
        finish: 'Architectural Matt',
        materials: ['Dark European Walnut', 'Saddle Leather', 'Cast Iron'],
        coats: 2,
        areaSqM: 42,
        litresRequired: 12.0,
        status: 'Delivered'
      },
      {
        room: 'Principal Bedroom Suite',
        type: 'Bedroom',
        wallColour: 'BR-004',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-009',
        doorsColour: 'BR-001',
        trimColour: 'BR-061',
        finish: 'Architectural Matt',
        materials: ['Natural Linen', 'Bleached Oak', 'Wool'],
        coats: 2,
        areaSqM: 58,
        litresRequired: 16.5,
        status: 'Delivered'
      },
      {
        room: 'Principal Bathroom',
        type: 'Bathroom',
        wallColour: 'BR-042',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-073',
        doorsColour: 'BR-072',
        trimColour: 'BR-042',
        finish: 'Architectural Eggshell',
        materials: ['Carrara Marble', 'Pennant Stone', 'Unlacquered Brass'],
        coats: 2,
        areaSqM: 34,
        litresRequired: 10.0,
        status: 'Delivered'
      }
    ]
  },
  {
    id: 'bristol-harbourside-hotel',
    name: 'Bristol Harbourside Hotel',
    location: 'Wapping Wharf / Welsh Back, Bristol BS1',
    typology: 'Hospitality Commercial',
    client: 'Harbourside Hotel Holdings Ltd',
    year: '2026',
    description: 'Comprehensive 42-room boutique hotel and destination restaurant within a converted 19th-century bonded tobacco warehouse. The colour schedule provides robust, scrubbable finishes with dramatic tonal depth.',
    heroImage: '/images/bristol_harbourside_hotel.jpg',
    paletteOverview: ['BR-041', 'BR-073', 'BR-085', 'BR-019', 'BR-062', 'BR-011'],
    totalLitres: 480.0,
    status: 'In Production',
    rooms: [
      {
        room: 'Main Arrival Lobby & Reception',
        type: 'Public / Commercial',
        wallColour: 'BR-041',
        ceilingColour: 'BR-062',
        joineryColour: 'BR-085',
        doorsColour: 'BR-085',
        trimColour: 'BR-073',
        finish: 'Architectural Eggshell',
        materials: ['Wet Concrete', 'Pennant Stone', 'Raw Brass', 'Walnut'],
        coats: 2,
        areaSqM: 180,
        litresRequired: 52.0,
        status: 'Approved'
      },
      {
        room: 'Dockside Restaurant & Raw Bar',
        type: 'Dining',
        wallColour: 'BR-011',
        ceilingColour: 'BR-062',
        joineryColour: 'BR-085',
        doorsColour: 'BR-072',
        trimColour: 'BR-019',
        finish: 'Architectural Eggshell',
        materials: ['Kiln Brick', 'Cast Iron', 'Aged Oak', 'Sheet Copper'],
        coats: 2,
        areaSqM: 220,
        litresRequired: 63.0,
        status: 'In Production'
      },
      {
        room: 'Estuary Cocktail Lounge',
        type: 'Bar',
        wallColour: 'BR-043',
        ceilingColour: 'BR-085',
        joineryColour: 'BR-085',
        doorsColour: 'BR-085',
        trimColour: 'BR-051',
        finish: 'Architectural Matt',
        materials: ['Velvet', 'Oxidized Brass', 'Smoked Mirror'],
        coats: 2,
        areaSqM: 95,
        litresRequired: 27.5,
        status: 'Approved'
      },
      {
        room: '40 Harbour Guest Suites (Aggregate)',
        type: 'Guest Rooms',
        wallColour: 'BR-042',
        ceilingColour: 'BR-062',
        joineryColour: 'BR-041',
        doorsColour: 'BR-085',
        trimColour: 'BR-073',
        finish: 'Architectural Eggshell',
        materials: ['White Ash', 'Linen Textures', 'Matte Black Steel'],
        coats: 2,
        areaSqM: 880,
        litresRequired: 255.0,
        status: 'In Production'
      },
      {
        room: '12 Guest Corridors & Lift Lobbies',
        type: 'Circulation',
        wallColour: 'BR-073',
        ceilingColour: 'BR-062',
        joineryColour: 'BR-085',
        doorsColour: 'BR-041',
        trimColour: 'BR-073',
        finish: 'Architectural Eggshell',
        materials: ['Concrete', 'Recessed Warm LED', 'Acoustic Felt'],
        coats: 2,
        areaSqM: 290,
        litresRequired: 82.5,
        status: 'Approved'
      }
    ]
  },
  {
    id: 'brunel-workshop',
    name: 'Brunel Workshop',
    location: 'Great Western Dockyard, Bristol BS1',
    typology: 'Workplace & Industrial',
    client: 'Design & Architecture Practice Hub',
    year: '2025',
    description: 'Contemporary architectural design studio located in a former Victorian boiler making hall. Celebrating heavy engineering heritage through oxide red, dockyard black, and precision engineering blue.',
    heroImage: '/images/brunel_workshop_space.jpg',
    paletteOverview: ['BR-085', 'BR-013', 'BR-045', 'BR-072', 'BR-019', 'BR-061'],
    totalLitres: 195.0,
    status: 'Completed Specification',
    rooms: [
      {
        room: 'Main Design Mezzanine',
        type: 'Open Workspace',
        wallColour: 'BR-062',
        ceilingColour: 'BR-062',
        joineryColour: 'BR-085',
        doorsColour: 'BR-013',
        trimColour: 'BR-072',
        finish: 'Architectural Matt',
        materials: ['Structural Steel', 'Riveted Iron', 'Plywood', 'Concrete'],
        coats: 2,
        areaSqM: 260,
        litresRequired: 74.0,
        status: 'Delivered'
      },
      {
        room: 'Material & Model Making Lab',
        type: 'Workshop',
        wallColour: 'BR-073',
        ceilingColour: 'BR-062',
        joineryColour: 'BR-033',
        doorsColour: 'BR-085',
        trimColour: 'BR-073',
        finish: 'Architectural Eggshell',
        materials: ['Cast Iron', 'Sheet Zinc', 'Solid Oak Benches'],
        coats: 2,
        areaSqM: 140,
        litresRequired: 40.0,
        status: 'Delivered'
      },
      {
        room: 'Client Review & Boardroom',
        type: 'Meeting',
        wallColour: 'BR-013',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-085',
        doorsColour: 'BR-085',
        trimColour: 'BR-019',
        finish: 'Architectural Matt',
        materials: ['Fumed Oak', 'Aged Copper', 'Brushed Aluminium'],
        coats: 2,
        areaSqM: 65,
        litresRequired: 18.5,
        status: 'Delivered'
      },
      {
        room: 'Coffee Hub & Breakout Lounge',
        type: 'Amenity',
        wallColour: 'BR-045',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-085',
        doorsColour: 'BR-051',
        trimColour: 'BR-072',
        finish: 'Architectural Eggshell',
        materials: ['Terrazzo', 'Steel Framing', 'Leather'],
        coats: 2,
        areaSqM: 80,
        litresRequired: 23.0,
        status: 'Delivered'
      }
    ]
  },
  {
    id: 'bristol-byzantine-house',
    name: 'Bristol Byzantine House',
    location: 'Victoria Street / Redcliffe, Bristol BS1',
    typology: 'Contemporary Heritage',
    client: 'Architect Private Residence',
    year: '2026',
    description: 'An innovative adaptive reuse of a Victorian commercial warehouse featuring polychromatic brickwork, segmental arches, and Moorish architectural motifs transformed into a dramatic contemporary home.',
    heroImage: '/images/hero_bristol_room.jpg',
    paletteOverview: ['BR-017', 'BR-038', 'BR-046', 'BR-061', 'BR-011', 'BR-085'],
    totalLitres: 120.0,
    status: 'Completed Specification',
    rooms: [
      {
        room: 'Triple-Height Atrium Living Space',
        type: 'Living',
        wallColour: 'BR-061',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-017',
        doorsColour: 'BR-038',
        trimColour: 'BR-046',
        finish: 'Architectural Matt',
        materials: ['Exposed Byzantine Brick', 'Limestone Floor', 'Raw Walnut'],
        coats: 2,
        areaSqM: 190,
        litresRequired: 55.0,
        status: 'Delivered'
      },
      {
        room: 'Vaulted Dining Arcade',
        type: 'Dining',
        wallColour: 'BR-017',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-038',
        doorsColour: 'BR-085',
        trimColour: 'BR-001',
        finish: 'Architectural Matt',
        materials: ['Terracotta Tile', 'Aged Brass', 'Dundry Stone'],
        coats: 2,
        areaSqM: 70,
        litresRequired: 20.0,
        status: 'Delivered'
      },
      {
        room: 'Master Gallery Suite',
        type: 'Bedroom',
        wallColour: 'BR-046',
        ceilingColour: 'BR-061',
        joineryColour: 'BR-001',
        doorsColour: 'BR-017',
        trimColour: 'BR-046',
        finish: 'Architectural Matt',
        materials: ['Linen Drapes', 'Smoky Blue Glaze', 'Dark Ash'],
        coats: 2,
        areaSqM: 65,
        litresRequired: 18.5,
        status: 'Delivered'
      }
    ]
  }
];
