export interface Pigment {
  id: string;
  name: string;
  chemicalName: string;
  colourIndex: string;
  family: 'Inorganic Earth' | 'Synthetic Mineral' | 'Carbon' | 'Synthetic Organic';
  opacity: 'Opaque' | 'Semi-Opaque' | 'Transparent';
  lightfastness: 'Class I (Permanent)' | 'Class II (Very Good)';
  contribution: string;
  undertone: string;
  hexPreview: string;
  historicalContext: string;
}

export const PIGMENTS: Pigment[] = [
  {
    id: 'pig-01',
    name: 'Titanium White (Rutile)',
    chemicalName: 'Titanium Dioxide (TiO2)',
    colourIndex: 'PW6',
    family: 'Synthetic Mineral',
    opacity: 'Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Maximum opacity, luminous base reflectance, and clean light dispersion.',
    undertone: 'Neutral',
    hexPreview: '#FBFBFA',
    historicalContext: 'Modern architectural paint base standard since the mid-20th century.'
  },
  {
    id: 'pig-02',
    name: 'Yellow Ochre',
    chemicalName: 'Natural Hydrated Iron Oxide (FeO(OH))',
    colourIndex: 'PY43',
    family: 'Inorganic Earth',
    opacity: 'Semi-Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Provides the iconic warm honey and golden limestone undertones of Clifton ashlar.',
    undertone: 'Warm Golden',
    hexPreview: '#D09E5A',
    historicalContext: 'Extracted naturally from mineral deposits across the West of England since antiquity.'
  },
  {
    id: 'pig-03',
    name: 'Synthetic Iron Oxide Red',
    chemicalName: 'Ferric Oxide (Fe2O3)',
    colourIndex: 'PR101',
    family: 'Synthetic Mineral',
    opacity: 'Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Deep rust, brick, and boiler oxide red with exceptional exterior weather resistance.',
    undertone: 'Warm Oxide',
    hexPreview: '#934637',
    historicalContext: 'Used historically for protective coatings on Brunel’s marine and rail structures.'
  },
  {
    id: 'pig-04',
    name: 'French Ultramarine Blue',
    chemicalName: 'Complex Sodium Aluminum Sulfosilicate',
    colourIndex: 'PB29',
    family: 'Synthetic Mineral',
    opacity: 'Semi-Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Pure, radiant deep blue with delicate reddish-violet undertones.',
    undertone: 'Cool Deep Violet-Blue',
    hexPreview: '#1E3F66',
    historicalContext: 'Synthesized in the 1820s to replace precious lapis lazuli in British architectural decoration.'
  },
  {
    id: 'pig-05',
    name: 'Lamp / Carbon Black',
    chemicalName: 'Amorphous Carbon (C)',
    colourIndex: 'PBk7',
    family: 'Carbon',
    opacity: 'Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Dense neutral light absorption, slate grey tinting, and architectural charcoal depth.',
    undertone: 'Cool Blue-Grey tint',
    hexPreview: '#181B1C',
    historicalContext: 'Produced from combustion soot and coal tar across Victorian dockyards.'
  },
  {
    id: 'pig-06',
    name: 'Chromium Oxide Green',
    chemicalName: 'Anhydrous Chromium Sesquioxide (Cr2O3)',
    colourIndex: 'PG17',
    family: 'Synthetic Mineral',
    opacity: 'Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Muted, permanent olive and sage greens impervious to harsh sunlight and lime alkali.',
    undertone: 'Neutral Olive Green',
    hexPreview: '#46594E',
    historicalContext: 'Crucial for limewashes and breathable lime plaster paint formulas.'
  },
  {
    id: 'pig-07',
    name: 'Raw Umber',
    chemicalName: 'Natural Iron and Manganese Hydroxide',
    colourIndex: 'PBr7',
    family: 'Inorganic Earth',
    opacity: 'Semi-Opaque',
    lightfastness: 'Class I (Permanent)',
    contribution: 'Cool, greenish-brown mineral pigment ideal for desaturating bright hues and balancing shadows.',
    undertone: 'Cool Mineral Brown',
    hexPreview: '#5E483A',
    historicalContext: 'The fundamental pigment used by British masters to soften and balance natural daylight.'
  },
  {
    id: 'pig-08',
    name: 'Phthalo Green (Blue Shade)',
    chemicalName: 'Chlorinated Copper Phthalocyanine',
    colourIndex: 'PG7',
    family: 'Synthetic Organic',
    opacity: 'Transparent',
    lightfastness: 'Class I (Permanent)',
    contribution: 'High-tinting marine teal, estuary water, and deep emerald architectural notes.',
    undertone: 'Cool Intense Emerald',
    hexPreview: '#1C5B52',
    historicalContext: 'Introduced in the 1930s with unmatched tinting strength and clean colour dispersion.'
  }
];
