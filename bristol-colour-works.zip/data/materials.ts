export interface Material {
  id: string;
  name: string;
  category: 'Stone & Masonry' | 'Metals' | 'Timbers' | 'Minerals & Concrete' | 'Textiles';
  origin: string;
  tactileTexture: string;
  reflectance: string;
  description: string;
  recommendedPaintColours: string[]; // Codes
  hexApprox: string;
}

export const MATERIALS: Material[] = [
  {
    id: 'mat-01',
    name: 'Clifton Limestone',
    category: 'Stone & Masonry',
    origin: 'Avon Gorge Quarries, Bristol',
    tactileTexture: 'Fine-grained, porous oolitic ashlar with subtle fossil fragments',
    reflectance: 'Diffused matte (LRV ~52)',
    description: 'The golden-honey stone defining Clifton terraces, Royal York Crescent, and Georgian villas.',
    recommendedPaintColours: ['BR-041', 'BR-031', 'BR-061', 'BR-085', 'BR-057'],
    hexApprox: '#D7C4A5'
  },
  {
    id: 'mat-02',
    name: 'Pennant Sandstone',
    category: 'Stone & Masonry',
    origin: 'Bristol Coalfield Strata',
    tactileTexture: 'Hard, fine-grit greenish-grey carboniferous sandstone',
    reflectance: 'Low specular, high texture absorption (LRV ~30)',
    description: 'The ubiquitous green-grey flagstones of Bristol pavements, harbour quays, and retaining rubble walls.',
    recommendedPaintColours: ['BR-001', 'BR-011', 'BR-041', 'BR-061', 'BR-071'],
    hexApprox: '#69706D'
  },
  {
    id: 'mat-03',
    name: 'Redcliffe Kiln Brick',
    category: 'Stone & Masonry',
    origin: 'Redcliffe & St Philips Claybeds',
    tactileTexture: 'Rough wirecut terracotta with iron slag flashing and coal kiln char',
    reflectance: 'Matte, directional light scattering',
    description: 'Rich red and rust bricks traditional to Victorian industrial warehouses, potteries, and docks.',
    recommendedPaintColours: ['BR-001', 'BR-041', 'BR-073', 'BR-085', 'BR-035'],
    hexApprox: '#934637'
  },
  {
    id: 'mat-04',
    name: 'Dundry & Bath Freestone',
    category: 'Stone & Masonry',
    origin: 'Dundry Hill & Combe Down',
    tactileTexture: 'Soft, creamy calcite freestone easily carved for ecclesiastical tracery',
    reflectance: 'Luminous warm scatter (LRV ~60)',
    description: 'The pale, velvety stone of St Mary Redcliffe Cathedral and Regency porticos.',
    recommendedPaintColours: ['BR-044', 'BR-011', 'BR-032', 'BR-061', 'BR-085'],
    hexApprox: '#D9CEBD'
  },
  {
    id: 'mat-05',
    name: 'Welsh Roofing Slate',
    category: 'Stone & Masonry',
    origin: 'North Wales (Imported via Bristol Docks)',
    tactileTexture: 'Smooth cleavage plane with subtle purple-grey mineral sheen',
    reflectance: 'Low-to-medium directional sheen when wet',
    description: 'Standard roofing material of Georgian and Victorian Bristol terraces.',
    recommendedPaintColours: ['BR-061', 'BR-001', 'BR-015', 'BR-047'],
    hexApprox: '#5A6266'
  },
  {
    id: 'mat-06',
    name: 'Cast & Wrought Iron',
    category: 'Metals',
    origin: 'Bristol Coalbrookdale Foundries & Great Western Works',
    tactileTexture: 'Sand-cast granular surface or hand-hammered fibrous wrought iron',
    reflectance: 'Semi-matte dark graphite',
    description: 'Balconies, railings, suspension bridge chains, and Temple Meads structural pillars.',
    recommendedPaintColours: ['BR-001', 'BR-061', 'BR-013', 'BR-041', 'BR-051'],
    hexApprox: '#202426'
  },
  {
    id: 'mat-07',
    name: 'Engineered Structural Steel',
    category: 'Metals',
    origin: 'Modern British Fabricators',
    tactileTexture: 'Smooth milled or shot-blasted industrial steel with sharp edges',
    reflectance: 'Clean architectural specular reflection',
    description: 'Contemporary extensions, crittall doors, and warehouse mezzanine frames.',
    recommendedPaintColours: ['BR-061', 'BR-073', 'BR-013', 'BR-041', 'BR-085'],
    hexApprox: '#4A5053'
  },
  {
    id: 'mat-08',
    name: 'Dockyard Sheet Copper',
    category: 'Metals',
    origin: 'Avonmouth & South Wales Smelters',
    tactileTexture: 'Hand-beaten or patinated verdigris copper with rich warm tone',
    reflectance: 'Warm metallic glow turning to chalky pale green over time',
    description: 'Ship bottom sheathing, brewery kettles, and architectural cladding.',
    recommendedPaintColours: ['BR-041', 'BR-085', 'BR-003', 'BR-061', 'BR-033'],
    hexApprox: '#A76448'
  },
  {
    id: 'mat-09',
    name: 'English Brown Oak',
    category: 'Timbers',
    origin: 'Ashton Court & Somerset Woodlands',
    tactileTexture: 'Open grain, prominent medullary rays, fumed or wire-brushed',
    reflectance: 'Warm golden-amber diffusion',
    description: 'Georgian floorboards, library panelling, and solid structural timber beams.',
    recommendedPaintColours: ['BR-041', 'BR-031', 'BR-001', 'BR-061', 'BR-085'],
    hexApprox: '#825C3C'
  },
  {
    id: 'mat-10',
    name: 'European Walnut',
    category: 'Timbers',
    origin: 'Traditional British Cabinetmakers',
    tactileTexture: 'Silky, dense grain with dramatic dark chocolate and grey streaks',
    reflectance: 'Deep, rich lustre',
    description: 'Fine bespoke joinery, mid-century furniture, and high-status architectural doors.',
    recommendedPaintColours: ['BR-001', 'BR-041', 'BR-061', 'BR-057', 'BR-011'],
    hexApprox: '#4A3528'
  },
  {
    id: 'mat-11',
    name: 'Board-Marked Concrete',
    category: 'Minerals & Concrete',
    origin: 'Contemporary West Country Architecture',
    tactileTexture: 'Rough timber grain embossed into structural hydraulic cement',
    reflectance: 'Cool diffused grey',
    description: 'Modern extensions, gallery floors, and cantilevered harbour structures.',
    recommendedPaintColours: ['BR-041', 'BR-061', 'BR-011', 'BR-085', 'BR-034'],
    hexApprox: '#9DA2A1'
  },
  {
    id: 'mat-12',
    name: 'Polished Brass & Bronze',
    category: 'Metals',
    origin: 'Traditional Bristol Metalworkers',
    tactileTexture: 'Heavy, precision-machined unlacquered brass aging to warm bronze',
    reflectance: 'High specular warmth with golden flare',
    description: 'Door ironmongery, architectural switches, and bespoke lighting fixtures.',
    recommendedPaintColours: ['BR-041', 'BR-031', 'BR-085', 'BR-001', 'BR-011'],
    hexApprox: '#C8A251'
  },
  {
    id: 'mat-13',
    name: 'Natural Unbleached Linen',
    category: 'Textiles',
    origin: 'Traditional Weavers',
    tactileTexture: 'Tactile slub yarn, crisp drape with organic fiber irregularities',
    reflectance: 'Soft daylight filtering (LRV ~70)',
    description: 'Curtains, upholstery, and wall coverings in Georgian and contemporary rooms.',
    recommendedPaintColours: ['BR-001', 'BR-041', 'BR-032', 'BR-061', 'BR-008'],
    hexApprox: '#E2DAC8'
  },
  {
    id: 'mat-14',
    name: 'Saddle Leather',
    category: 'Textiles',
    origin: 'West Country Tanneries',
    tactileTexture: 'Vegetable-tanned full grain with natural pull-up patina',
    reflectance: 'Rich satin sheen',
    description: 'Club chairs, desk tops, and architectural bespoke handles.',
    recommendedPaintColours: ['BR-041', 'BR-001', 'BR-035', 'BR-061', 'BR-085'],
    hexApprox: '#8D5638'
  }
];
