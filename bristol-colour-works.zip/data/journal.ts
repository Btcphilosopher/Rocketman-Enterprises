export interface JournalArticle {
  id: string;
  slug: string;
  title: string;
  subtitle: string;
  author: string;
  authorRole: string;
  readTime: string;
  category: 'Light & Atmosphere' | 'Materiality' | 'Architectural Theory' | 'Case Study';
  publishDate: string;
  featuredImage: string;
  excerpt: string;
  content: string[];
  relatedColours: string[]; // Codes
  relatedMaterials: string[];
}

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'art-01',
    slug: 'why-bristol-light-matters',
    title: 'Why Bristol Light Matters',
    subtitle: 'The maritime atmosphere, Atlantic cloud cover, and spectral refraction of the West Country.',
    author: 'Eleanor Vance',
    authorRole: 'Head of Colour Science, Bristol Colour Works',
    readTime: '6 min read',
    category: 'Light & Atmosphere',
    publishDate: 'Autumn 2025',
    featuredImage: '/images/hero_bristol_room.jpg',
    excerpt: 'Natural light in the British West Country differs measurably from Continental Europe. High moisture content in Atlantic weather fronts scatters shorter blue wavelengths, demanding paints with mineral resonance.',
    content: [
      'Natural light in Bristol is shaped by geography: the funnel of the Severn Estuary, the maritime moisture drifting from the Atlantic, and the sudden microclimatic shifts created by the Avon Gorge.',
      'Under an overcast British sky, standard high-chroma synthetic paints appear aggressive and detached from their architectural envelope. They lack the mineral damping required to settle into aged lime plaster or limestone masonry.',
      'Bristol Colour Works formulates every tone with multi-pigment recipes—using natural ochres, umbers, and calcites—so that as the weather shifts from rain to soft break-through sunlight, the painted wall breathes in harmony with the building.'
    ],
    relatedColours: ['BR-061', 'BR-065', 'BR-001', 'BR-041'],
    relatedMaterials: ['Clifton Limestone', 'Natural Lime Plaster']
  },
  {
    id: 'art-02',
    slug: 'colour-and-limestone',
    title: 'Colour and Limestone: The Geology of Clifton',
    subtitle: 'Harmonising interior planes with oolitic ashlar and lime mortar.',
    author: 'Marcus Croft, RIBA',
    authorRole: 'Architectural Historian',
    readTime: '8 min read',
    category: 'Materiality',
    publishDate: 'Winter 2025',
    featuredImage: '/images/clifton_townhouse_interior.jpg',
    excerpt: 'The warm honey ashlar of Clifton and Bath freestone possesses a distinct warmth (LRV ~52-58). Introducing paint without understanding this mineral partner leads to discordant interior relationships.',
    content: [
      'When John Wood the Elder and later Georgian architects laid out the crescents of Clifton, they worked with the golden oolite of the West Country. This stone is not inert grey; it holds iron oxide traces that glow under late afternoon sun.',
      'To choose paint for a room with limestone window reveals or fireplaces, one must either extend the mineral warmth using tonal companions like BR-001 or introduce deliberate architectural tension with deep absorbing blues like BR-041.',
      'Our Clifton Collection was developed by spectrally analysing quarried ashlar samples under twelve distinct daylight phases.'
    ],
    relatedColours: ['BR-001', 'BR-004', 'BR-041', 'BR-057'],
    relatedMaterials: ['Clifton Limestone', 'Bath Freestone']
  },
  {
    id: 'art-03',
    slug: 'the-architecture-of-blue',
    title: 'The Architecture of Blue: From Smalt Glass to Maritime Quays',
    subtitle: 'How Bristol became Britain’s historical capital of architectural cobalt.',
    author: 'Eleanor Vance',
    authorRole: 'Head of Colour Science',
    readTime: '5 min read',
    category: 'Architectural Theory',
    publishDate: 'Winter 2025',
    featuredImage: '/images/bristol_harbourside_hotel.jpg',
    excerpt: 'In 1780, Bristol was internationally renowned for its cobalt blue glassware manufactured in the giant glass cones of Redcliffe. Today, blue remains the city’s profoundest architectural hue.',
    content: [
      'Blue in architectural interiors is frequently misunderstood as cold. Yet true maritime blues, anchored by black and green undertones rather than pure cyan, create a feeling of infinite spatial depth.',
      'When applied to large vertical planes in Georgian drawing rooms, BR-041 Harbourside Blue allows walls to recede visually, making ceiling heights and natural daylight appear magnified.',
      'It acts as an architectural canvas against which natural timber, unlacquered brass, and linen textiles radiate with warmth.'
    ],
    relatedColours: ['BR-041', 'BR-044', 'BR-042', 'BR-043'],
    relatedMaterials: ['European Walnut', 'Polished Brass', 'Pennant Stone']
  },
  {
    id: 'art-04',
    slug: 'how-paint-changes-a-room',
    title: 'How Paint Changes a Room: Proportion, Weight & Light',
    subtitle: 'A structural guide to altering perceived scale without moving a wall.',
    author: 'James Sterling',
    authorRole: 'Principal Colour Consultant',
    readTime: '7 min read',
    category: 'Architectural Theory',
    publishDate: 'Spring 2026',
    featuredImage: '/images/hero_bristol_room.jpg',
    excerpt: 'Paint is not a decorative veneer applied at the end of a project. It is architecture in liquid form that alters acoustic feel, light refraction, and room geometry.',
    content: [
      'A room is a volumetric vessel of daylight. By adjusting the reflectance value (LRV) across walls, ceilings, and woodwork, you can visually expand a narrow corridor or ground a cavernous loft.',
      'Painting skirting boards and doors in a darker tone than the walls (e.g. BR-072 joinery with BR-001 walls) grounds the room, creating an architectural plinth that stabilizes the eye.',
      'Conversely, enveloping all surfaces in a single unified finish eliminates distracting hard shadows, creating an atmosphere of profound serenity.'
    ],
    relatedColours: ['BR-001', 'BR-072', 'BR-061', 'BR-085'],
    relatedMaterials: ['Natural Lime Plaster', 'English Oak']
  },
  {
    id: 'art-05',
    slug: 'inside-the-colour-laboratory',
    title: 'Inside the Colour Laboratory: The Physics of Matt Finishes',
    subtitle: 'Balancing microscopic mineral fillers, breathable binders, and pigment loading.',
    author: 'Dr. Aris Thorne',
    authorRole: 'Chief Materials Chemist',
    readTime: '9 min read',
    category: 'Materiality',
    publishDate: 'Spring 2026',
    featuredImage: '/images/paint_tin_architectural.jpg',
    excerpt: 'True architectural matt paint must not look chalky or flat; it must possess velvety depth that diffuses light evenly across irregular lime plaster surfaces.',
    content: [
      'In conventional commercial paints, flat finishes are achieved through chemical matting agents that scatter light superficially. At Bristol Colour Works, we achieve our signature 2% sheen through ultra-dense pigment loading and micronized natural calcites.',
      'This mineral structure allows water vapour to pass freely through historic substrates, making our paint safe for Grade I and II* listed buildings where synthetic vinyl emulsions cause catastrophic damp trapping.',
      'Every batch undergoes spectro-photometric verification against our 1926 reference archive.'
    ],
    relatedColours: ['BR-061', 'BR-085', 'BR-003', 'BR-011'],
    relatedMaterials: ['Natural Lime Plaster', 'Dundry Stone']
  },
  {
    id: 'art-06',
    slug: 'clifton-stone-light-proportion',
    title: 'Clifton: Stone, Light and Proportion',
    subtitle: 'Lessons from 18th-century master builders on scale and window reveals.',
    author: 'Marcus Croft, RIBA',
    authorRole: 'Architectural Historian',
    readTime: '6 min read',
    category: 'Case Study',
    publishDate: 'Spring 2026',
    featuredImage: '/images/clifton_townhouse_interior.jpg',
    excerpt: 'Why Georgian drawing rooms feel innately balanced: the mathematical harmony between 12-pane sash windows, timber architraves, and lime washes.',
    content: [
      'The genius of Clifton terrace design lies in the depth of window reveals. Deep wooden shutters angled at 45 degrees bounce morning daylight across the floorboards.',
      'When these reveals are painted in warm architectural whites like BR-063 or BR-061, the harsh contrast between exterior brightness and interior shade is softened into a continuous gradient.',
      'This spatial clarity is what we seek to protect and amplify in every heritage specification.'
    ],
    relatedColours: ['BR-001', 'BR-063', 'BR-032', 'BR-072'],
    relatedMaterials: ['Clifton Limestone', 'Aged Oak']
  },
  {
    id: 'art-07',
    slug: 'the-industrial-palette',
    title: 'The Industrial Palette: Iron, Oxide and Steam',
    subtitle: 'Translating Victorian civil engineering into contemporary living spaces.',
    author: 'James Sterling',
    authorRole: 'Principal Colour Consultant',
    readTime: '5 min read',
    category: 'Architectural Theory',
    publishDate: 'Summer 2026',
    featuredImage: '/images/brunel_workshop_space.jpg',
    excerpt: 'Industrial colour is not bleak; it is saturated with iron oxide reds, boiler enamels, coal tar blacks, and riveted steel greys of exceptional integrity.',
    content: [
      'Too often, contemporary industrial design defaults to monotonous light grey. The actual historical palette of Bristol’s docklands was intense, physical, and protective.',
      'Brunel Oxide Red (BR-013) was formulated to defend iron hull plates against Atlantic brine; in a domestic library or dining room, it provides warmth and timeless gravitas.',
      'Paired with Temple Meads Iron (BR-072) and natural linen drapes, it turns former warehouse spaces into spaces of enduring dignity.'
    ],
    relatedColours: ['BR-013', 'BR-072', 'BR-085', 'BR-051'],
    relatedMaterials: ['Cast Iron', 'Structural Steel', 'Aged Copper']
  },
  {
    id: 'art-08',
    slug: 'colour-for-georgian-rooms',
    title: 'Colour for Georgian Rooms: Moving Beyond False Heritage',
    subtitle: 'Why the 18th century was bolder, richer, and more architectural than pastel myth suggests.',
    author: 'Eleanor Vance',
    authorRole: 'Head of Colour Science',
    readTime: '7 min read',
    category: 'Architectural Theory',
    publishDate: 'Summer 2026',
    featuredImage: '/images/clifton_townhouse_interior.jpg',
    excerpt: 'Scraping historic paint layers reveals that Georgian drawing rooms were not timid beige; they were painted in deep Prussian blues, full-bodied ochres, and dramatic stone washes.',
    content: [
      'The 20th-century myth of the polite pastel Georgian interior was an invention of modern reproduction decorators. In reality, 18th-century architects used strong mineral pigments to define hierarchy.',
      'Ground floor entrance halls were stone-coloured and robust; first-floor piano nobile drawing rooms were rich in expensive blues or greens; private study rooms were enveloping and dark.',
      'Our Georgian colour systems respect this authentic architectural hierarchy.'
    ],
    relatedColours: ['BR-001', 'BR-041', 'BR-032', 'BR-011'],
    relatedMaterials: ['Limestone', 'Gilt Brass', 'French Walnut']
  },
  {
    id: 'art-09',
    slug: 'why-ceilings-should-not-always-be-white',
    title: 'Why Ceilings Should Not Always Be White',
    subtitle: 'The tyranny of brilliant white ceiling emulsion and how to cure it.',
    author: 'James Sterling',
    authorRole: 'Principal Colour Consultant',
    readTime: '6 min read',
    category: 'Architectural Theory',
    publishDate: 'Autumn 2026',
    featuredImage: '/images/hero_bristol_room.jpg',
    excerpt: 'Slapping harsh, blue-tinted titanium white across a ceiling destroys the atmosphere of a room. Here is the architectural alternative.',
    content: [
      'In nature, the sky is rarely a flat stark white plane; it is a luminous dome of filtered light. When you paint a ceiling in harsh synthetic brilliant white, it creates a severe line of demarcation with the walls that lowers perceived height.',
      'By carrying a tinted architectural neutral like BR-061 Bristol Cream or a soft stone like BR-004 over the ceiling, the boundary dissolves, and light spreads seamlessly without glare.',
      'In dining rooms and snug studies, painting the ceiling in a darker tone than the walls can create an intimate, sheltering canopy.'
    ],
    relatedColours: ['BR-061', 'BR-004', 'BR-009', 'BR-065'],
    relatedMaterials: ['Natural Lime Plaster', 'Cornicing']
  },
  {
    id: 'art-10',
    slug: 'paint-as-material',
    title: 'Paint as Material: Viscosity, Opacity and Light Depth',
    subtitle: 'Why liquid architectural coatings behave like stone and timber, not digital pixels.',
    author: 'Dr. Aris Thorne',
    authorRole: 'Chief Materials Chemist',
    readTime: '8 min read',
    category: 'Materiality',
    publishDate: 'Autumn 2026',
    featuredImage: '/images/paint_tin_architectural.jpg',
    excerpt: 'On a computer screen, colour is projected RGB light. On a wall, colour is subtractive mineral absorption that interacts with the physical grain of plaster and brush strokes.',
    content: [
      'Understanding colour requires respecting its physical nature. A coat of paint is a 120-micron layer of mineral crystals suspended in a binder.',
      'When daylight strikes the wall, it does not bounce off the surface; it penetrates through pigment particles, refracting off calcites and returning to the eye with organic depth.',
      'This is why digital swatches can only ever be an index: the real magic happens when the tin is opened and liquid transforms into space.'
    ],
    relatedColours: ['BR-041', 'BR-001', 'BR-085', 'BR-071'],
    relatedMaterials: ['All Materials']
  },
  {
    id: 'art-11',
    slug: 'designing-with-pennant-stone',
    title: 'Designing with Pennant Stone: The Green-Grey Foundation',
    subtitle: 'How Bristol’s hardest carboniferous sandstone dictates exterior and interior palettes.',
    author: 'Marcus Croft, RIBA',
    authorRole: 'Architectural Historian',
    readTime: '5 min read',
    category: 'Materiality',
    publishDate: 'Winter 2026',
    featuredImage: '/images/brunel_workshop_space.jpg',
    excerpt: 'From Brandon Hill to the Floating Harbour quays, Pennant stone is the quiet backbone of Bristol’s physical fabric.',
    content: [
      'Unlike warm limestone, Pennant sandstone is cool, rugged, and flecked with green mineral veins. It absorbs water during West Country rainstorms, turning from dry dusty grey to rich dark slate.',
      'Pairing Pennant stone flagstones with warm terracotta (BR-012) or clean industrial green (BR-033) produces an unmistakably authentic British atmosphere.',
      'We formulated BR-003 Pennant Flagstone specifically to match this timeless stone tone.'
    ],
    relatedColours: ['BR-003', 'BR-071', 'BR-012', 'BR-033'],
    relatedMaterials: ['Pennant Sandstone', 'Cast Iron']
  },
  {
    id: 'art-12',
    slug: 'the-bristol-harbour-palette',
    title: 'The Bristol Harbour Palette: 200 Years of Water, Salt and Tar',
    subtitle: 'From Brunel’s SS Great Britain to contemporary dockland culture.',
    author: 'James Sterling',
    authorRole: 'Principal Colour Consultant',
    readTime: '6 min read',
    category: 'Case Study',
    publishDate: 'Winter 2026',
    featuredImage: '/images/bristol_harbourside_hotel.jpg',
    excerpt: 'The Floating Harbour is not just water; it is a vast amphitheatre of iron cranes, bonded brick warehouses, and changing reflections.',
    content: [
      'Completed in 1809 by William Jessop, Bristol’s Floating Harbour transformed a muddy tidal river into a permanent 70-acre body of deep water.',
      'The colours around the harbour are extraordinary: salt white, tarred timber, deep tidal blue, and wet concrete.',
      'Our Harbourside Collection distils this living maritime heritage into colours engineered for contemporary architecture.'
    ],
    relatedColours: ['BR-041', 'BR-042', 'BR-073', 'BR-086'],
    relatedMaterials: ['Pennant Flagstones', 'Wet Concrete', 'Dockyard Sheet Copper']
  }
];
