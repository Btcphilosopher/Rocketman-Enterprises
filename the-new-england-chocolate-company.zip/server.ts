import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { PRODUCTS, FACTORY_LINES, JOURNAL_ARTICLES } from "./src/data/mockData.js";
import { Product } from "./src/types/index.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // In-memory state for CMS simulation
  let liveProducts: Product[] = [...PRODUCTS];

  // API Routes
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", server: "The New England Chocolate Co. API Server", timestamp: new Date().toISOString() });
  });

  // Get products catalog
  app.get("/api/products", (req, res) => {
    res.json({ products: liveProducts });
  });

  // CMS update / add product
  app.post("/api/products", (req, res) => {
    const updatedProduct: Product = req.body;
    if (!updatedProduct || !updatedProduct.id) {
      return res.status(400).json({ error: "Invalid product data" });
    }
    const idx = liveProducts.findIndex((p) => p.id === updatedProduct.id);
    if (idx >= 0) {
      liveProducts[idx] = updatedProduct;
    } else {
      liveProducts.unshift(updatedProduct);
    }
    res.json({ success: true, product: updatedProduct, count: liveProducts.length });
  });

  // Simulated Factory Telemetry Stream
  app.get("/api/factory/telemetry", (req, res) => {
    const jitter = (base: number, maxDelta: number) => {
      const delta = (Math.random() - 0.5) * 2 * maxDelta;
      return Number((base + delta).toFixed(2));
    };

    const telemetry = FACTORY_LINES.map((line) => ({
      ...line,
      throughputBarsPerDay: Math.round(jitter(line.throughputBarsPerDay, 250)),
      currentTemperatureC: jitter(line.currentTemperatureC, 0.4),
      conchePressureBar: jitter(line.conchePressureBar, 0.05),
      temperCrystallizationIndex: jitter(line.temperCrystallizationIndex, 0.1),
      humidityPercent: jitter(line.humidityPercent, 0.5),
      lastUpdated: new Date().toISOString()
    }));

    res.json({
      factoryStatus: "OPERATIONAL",
      facility: "Boston Central Waterfront Mill - Line 01 through 04",
      totalDailyThroughput: telemetry.reduce((sum, l) => sum + l.throughputBarsPerDay, 0),
      overallEfficiency: 97.3,
      lines: telemetry
    });
  });

  // AI Taste & Selection Assistant using Gemini API
  app.post("/api/ai/recommend", async (req, res) => {
    const { preferences, note, userFlavorProfile } = req.body;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      // Fallback recommendation logic if API key is not yet set
      const recommended = liveProducts.slice(0, 3);
      return res.json({
        recommendationTitle: "The Master Chocolatier's Selected Flight",
        curatedProducts: recommended,
        aiAnalysis: "Based on your preference for complex dark cacao profiles and rich finishing notes, our Boston tasting director recommends starting with House 74 followed by Revolution 85 and our Maine Coast Salt edition.",
        pairingSuggestions: "Single-malt Islay whisky, dark roast Ethiopian Yirgacheffe, or aged Demerara rum.",
        technicalInsight: "Particle size controlled at 18.2 microns ensures immediate flavor dispersal upon contact with the palate."
      });
    }

    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `
You are the Chief Master Chocolatier and Director of Flavor Physics at The New England Chocolate Company (founded 1887 in Boston, MA).
A distinguished guest is seeking chocolate recommendations based on their flavor preferences:

User Preferences / Desired Profile: ${JSON.stringify(preferences || {})}
User Personal Notes: "${note || "Seeking a sophisticated dark chocolate experience"}"
User Flavor Ratings (1-10): ${JSON.stringify(userFlavorProfile || {})}

Available Products in our House Vault:
${JSON.stringify(
  liveProducts.map((p) => ({
    code: p.code,
    name: p.name,
    cacao: p.cacaoPercentage + "%",
    origin: p.origin,
    flavourNotes: p.flavourNotes,
    description: p.description
  }))
)}

Provide a highly sophisticated, editorial recommendation response in valid JSON format matching this schema:
{
  "recommendationTitle": "string (e.g., The Boston Merchant Private Selection)",
  "recommendedProductCodes": ["string product code 1", "string product code 2"],
  "aiAnalysis": "string (2-3 sentences of elevated, technical, architectural taste commentary in the voice of a Boston chocolatier)",
  "pairingSuggestions": "string (beverage and spirit pairings)",
  "technicalInsight": "string (1-2 sentences on roasting, conching, or particle size physics)"
}
`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt
      });

      const responseText = response.text || "";
      let parsed;
      try {
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        parsed = jsonMatch ? JSON.parse(jsonMatch[0]) : null;
      } catch (err) {
        parsed = null;
      }

      if (!parsed) {
        parsed = {
          recommendationTitle: "The Custom New England Cacao Selection",
          recommendedProductCodes: ["HOUSE 74", "REVOLUTION 85"],
          aiAnalysis: "Your preference demonstrates a refined appreciation for structured dark chocolate with pronounced tannic elegance and deep cacao depth.",
          pairingSuggestions: "Aged American Rye Whiskey, Port, or single-origin espresso.",
          technicalInsight: "High-density conching preserves volatile aromatic esters while mitigating astringency."
        };
      }

      // Match products from code
      const matchedProducts = liveProducts.filter((p) =>
        parsed.recommendedProductCodes.includes(p.code)
      );
      const finalProducts = matchedProducts.length > 0 ? matchedProducts : liveProducts.slice(0, 2);

      res.json({
        recommendationTitle: parsed.recommendationTitle,
        curatedProducts: finalProducts,
        aiAnalysis: parsed.aiAnalysis,
        pairingSuggestions: parsed.pairingSuggestions,
        technicalInsight: parsed.technicalInsight
      });
    } catch (error) {
      console.error("Gemini API error:", error);
      res.json({
        recommendationTitle: "The New England Merchant Cacao Flight",
        curatedProducts: liveProducts.slice(0, 2),
        aiAnalysis: "Our Boston laboratory has curated this balanced selection featuring our House 74 benchmark and Maine Coast Atlantic Salt edition.",
        pairingSuggestions: "Dark roast coffee, Cabernet Sauvignon, or peated scotch.",
        technicalInsight: "72-hour rotary conching guarantees zero chalkiness and optimal crystalline temper."
      });
    }
  });

  // Order submission endpoint
  app.post("/api/orders", (req, res) => {
    const { items, customerName, email, shippingAddress, shippingTier } = req.body;
    const certId = `CERT-NECC-${Math.floor(100000 + Math.random() * 900000)}-${new Date().getFullYear()}`;
    const trackingNo = `NECC-RAIL-${Math.floor(10000000 + Math.random() * 90000000)}`;

    const subtotal = items.reduce((acc: number, item: any) => acc + (item.product.priceUSD * item.quantity), 0);
    const shippingFee = shippingTier === 'TEMP_CONTROLLED_VAULT' ? 35 : shippingTier === 'EXPRESS_RAIL' ? 20 : 10;

    res.json({
      success: true,
      order: {
        id: `ORD-${Date.now()}`,
        createdAt: new Date().toISOString(),
        customerName: customerName || "Valued Client",
        email: email || "client@necc.com",
        shippingAddress: shippingAddress || "Boston, MA",
        shippingTier: shippingTier || "TEMP_CONTROLLED_VAULT",
        items,
        subtotal,
        shippingFee,
        total: subtotal + shippingFee,
        status: "VAULT_DISPATCHED",
        provenanceCertificateId: certId,
        trackingNumber: trackingNo
      }
    });
  });

  // Serve Journal
  app.get("/api/journal", (req, res) => {
    res.json({ articles: JOURNAL_ARTICLES });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
