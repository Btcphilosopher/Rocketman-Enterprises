import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CmsModal } from './components/CmsModal';
import { ProductDetailModal } from './components/views/ProductDetailModal';

// All Application View Components
import { HeroSection } from './components/views/HeroSection';
import { TheHouseView } from './components/views/TheHouseView';
import { ProductCatalogView } from './components/views/ProductCatalogView';
import { CocoaOriginsView } from './components/views/CocoaOriginsView';
import { FactoryView } from './components/views/FactoryView';
import { FactoryDigitalTwinView } from './components/views/FactoryDigitalTwinView';
import { NewEnglandMapView } from './components/views/NewEnglandMapView';
import { AtlanticCommerceView } from './components/views/AtlanticCommerceView';
import { ChocolateEngineeringView } from './components/views/ChocolateEngineeringView';
import { TastingSystemView } from './components/views/TastingSystemView';
import { ChocolateFinderView } from './components/views/ChocolateFinderView';
import { CellarView } from './components/views/CellarView';
import { PrivateReserveView } from './components/views/PrivateReserveView';
import { GiftingView } from './components/views/GiftingView';
import { AtlanticCircleView } from './components/views/AtlanticCircleView';
import { JournalView } from './components/views/JournalView';
import { ChocolateQuarterlyView } from './components/views/ChocolateQuarterlyView';
import { BostonHeadquartersView } from './components/views/BostonHeadquartersView';

// Data and Types
import { PRODUCTS } from './data/mockData';
import { Product, CartItem } from './types';

export function App() {
  const [activeView, setActiveView] = useState<string>('hero');
  const [products, setProducts] = useState<Product[]>(PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      product: PRODUCTS[0],
      quantity: 2,
      customEngraving: 'BOSTON - 1887'
    }
  ]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isCmsOpen, setIsCmsOpen] = useState<boolean>(false);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(true);
  const [memberTier, setMemberTier] = useState<string>('Merchant');
  const [orderSuccessNotice, setOrderSuccessNotice] = useState<string | null>(null);

  // Fetch live products from backend Express server on mount
  const refreshProducts = async () => {
    try {
      const res = await fetch('/api/products');
      if (res.ok) {
        const data = await res.json();
        if (data.products && Array.isArray(data.products)) {
          setProducts(data.products);
        }
      }
    } catch (err) {
      console.log('Using local mock data for products catalogue.');
    }
  };

  useEffect(() => {
    refreshProducts();
  }, []);

  // Web Audio API ambient hum synth when sound is enabled
  useEffect(() => {
    if (isAudioMuted) return;
    try {
      const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContext) return;
      const ctx = new AudioContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(55, ctx.currentTime); // Low warm 55Hz industrial hum
      gain.gain.setValueAtTime(0.015, ctx.currentTime);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();

      return () => {
        try {
          osc.stop();
          ctx.close();
        } catch (e) {}
      };
    } catch (e) {}
  }, [isAudioMuted]);

  // Cart operations
  const handleAddToCart = (
    product: Product,
    quantity = 1,
    customEngraving?: string,
    giftBoxStyle?: string
  ) => {
    setCartItems((prev) => {
      const existingIdx = prev.findIndex((item) => item.product.id === product.id);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        if (customEngraving) updated[existingIdx].customEngraving = customEngraving;
        if (giftBoxStyle) updated[existingIdx].giftBoxStyle = giftBoxStyle;
        return updated;
      }
      return [
        ...prev,
        {
          product,
          quantity,
          customEngraving,
          giftBoxStyle
        }
      ];
    });
  };

  const handleUpdateQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCartItems((prev) => {
      const updated = [...prev];
      updated[index].quantity = newQty;
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  };

  const handleProceedToCheckout = async () => {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cartItems,
          customerName: 'Alexander Vance',
          email: 'a.vance@bostonmerchant.com',
          shippingTier: 'TEMP_CONTROLLED_VAULT'
        })
      });

      if (res.ok) {
        const data = await res.json();
        setCartItems([]);
        setIsCartOpen(false);
        setOrderSuccessNotice(
          `ORDER DISPATCH CONFIRMED: Tracking #${data.order.trackingNumber} | Certificate ${data.order.provenanceCertificateId}`
        );
        setTimeout(() => setOrderSuccessNotice(null), 8000);
      } else {
        alert('Order submitted to Boston Central Vault.');
        setCartItems([]);
        setIsCartOpen(false);
      }
    } catch (e) {
      alert('Order dispatched directly to Boston Harbor Vault.');
      setCartItems([]);
      setIsCartOpen(false);
    }
  };

  const handleProductUpdated = (updatedProduct: Product) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === updatedProduct.id ? updatedProduct : p))
    );
  };

  // Render view based on activeView state
  const renderActiveView = () => {
    switch (activeView) {
      case 'hero':
        return <HeroSection setActiveView={setActiveView} />;
      case 'house':
        return <TheHouseView setActiveView={setActiveView} />;
      case 'chocolate':
        return (
          <ProductCatalogView
            products={products}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
            setActiveView={setActiveView}
          />
        );
      case 'cocoa':
        return <CocoaOriginsView />;
      case 'factory':
        return <FactoryView />;
      case 'telemetry':
        return <FactoryDigitalTwinView />;
      case 'map':
        return <NewEnglandMapView />;
      case 'atlantic':
        return <AtlanticCommerceView />;
      case 'science':
        return <ChocolateEngineeringView />;
      case 'tasting':
        return <TastingSystemView />;
      case 'finder':
        return (
          <ChocolateFinderView
            products={products}
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
          />
        );
      case 'cellar':
        return <CellarView />;
      case 'reserve':
        return <PrivateReserveView onAddToCart={handleAddToCart} />;
      case 'gifts':
        return <GiftingView onAddToCart={handleAddToCart} />;
      case 'circle':
        return (
          <AtlanticCircleView
            memberTier={memberTier}
            setMemberTier={setMemberTier}
          />
        );
      case 'journal':
        return <JournalView />;
      case 'quarterly':
        return <ChocolateQuarterlyView />;
      case 'hq':
        return <BostonHeadquartersView />;
      default:
        return <HeroSection setActiveView={setActiveView} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#08090c] text-[#f2f0e9] font-sans antialiased flex flex-col justify-between selection:bg-[#d4af37] selection:text-[#0c0d10]">
      {/* Global Order Success Notification Banner */}
      {orderSuccessNotice && (
        <div className="bg-[#d4af37] text-[#0c0d10] font-mono text-xs font-bold py-2.5 px-4 text-center shadow-md animate-fade-in flex items-center justify-center gap-2">
          <span>{orderSuccessNotice}</span>
        </div>
      )}

      {/* Global Header */}
      <Header
        activeView={activeView}
        setActiveView={setActiveView}
        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
        setIsCartOpen={setIsCartOpen}
        isAudioMuted={isAudioMuted}
        setIsAudioMuted={setIsAudioMuted}
        setIsCmsOpen={setIsCmsOpen}
        memberTier={memberTier}
      />

      {/* Active View Container */}
      <main className="flex-grow">{renderActiveView()}</main>

      {/* Global Footer */}
      <Footer setActiveView={setActiveView} setIsCmsOpen={setIsCmsOpen} />

      {/* Cart Drawer Modal */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onProceedToCheckout={handleProceedToCheckout}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Institutional CMS Modal */}
      <CmsModal
        isOpen={isCmsOpen}
        onClose={() => setIsCmsOpen(false)}
        products={products}
        onProductUpdated={handleProductUpdated}
        onRefreshProducts={refreshProducts}
      />
    </div>
  );
}

export default App;
