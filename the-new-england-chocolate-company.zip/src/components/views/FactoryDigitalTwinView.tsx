import React, { useState, useEffect } from 'react';
import { Cpu, Activity, Zap, ShieldAlert, Gauge, RefreshCw, BarChart2, CheckCircle } from 'lucide-react';
import { FACTORY_LINES } from '../../data/mockData';

export const FactoryDigitalTwinView: React.FC = () => {
  const [lines, setLines] = useState(FACTORY_LINES);
  const [totalBars, setTotalBars] = useState(111200);
  const [lastRefreshed, setLastRefreshed] = useState(new Date());
  const [selectedLineId, setSelectedLineId] = useState('line-04');

  useEffect(() => {
    // Poll real-time API server telemetry
    const fetchTelemetry = async () => {
      try {
        const res = await fetch('/api/factory/telemetry');
        if (res.ok) {
          const data = await res.json();
          if (data.lines) {
            setLines(data.lines);
            setTotalBars(data.totalDailyThroughput);
            setLastRefreshed(new Date());
          }
        }
      } catch (err) {
        // Jitter local state fallback if server call misses
        setLines(prev => prev.map(l => ({
          ...l,
          currentTemperatureC: Number((l.currentTemperatureC + (Math.random() - 0.5) * 0.2).toFixed(2))
        })));
      }
    };

    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 3000);
    return () => clearInterval(interval);
  }, []);

  const selectedLine = lines.find((l) => l.id === selectedLineId) || lines[0];

  return (
    <div className="bg-[#060709] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-mono text-xs min-h-screen">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Header Ribbon */}
        <div className="bg-[#0e1017] border border-[#222736] p-6 rounded flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              <span className="w-2.5 h-2.5 rounded-full bg-[#22c55e] animate-ping" />
              <span className="text-[#22c55e] font-bold tracking-widest text-sm">
                BOSTON CENTRAL DIGITAL TWIN • LIVE INDUSTRIAL CONTROL
              </span>
            </div>
            <h2 className="text-2xl font-serif font-bold text-[#f2f0e9]">
              REAL-TIME MANUFACTURING TELEMETRY
            </h2>
            <p className="text-[#8a96a8] text-[11px]">
              Aerospace-grade sensor array monitoring thermal gradients, viscosity, and Form V crystal nucleation.
            </p>
          </div>

          <div className="flex items-center space-x-6 text-right">
            <div>
              <div className="text-[#657182] text-[10px] uppercase">Combined Daily Output</div>
              <div className="text-2xl font-bold text-[#d4af37]">{totalBars.toLocaleString()} BARS/DAY</div>
            </div>
            <div>
              <div className="text-[#657182] text-[10px] uppercase">Last Sync</div>
              <div className="text-xs text-[#22c55e] font-bold">{lastRefreshed.toLocaleTimeString()}</div>
            </div>
          </div>
        </div>

        {/* 4 Line Status Cards Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {lines.map((line) => (
            <div
              key={line.id}
              onClick={() => setSelectedLineId(line.id)}
              className={`p-5 rounded border cursor-pointer transition-all ${
                selectedLineId === line.id
                  ? 'bg-[#121622] border-[#d4af37] shadow-lg shadow-[#d4af37]/5'
                  : 'bg-[#0b0c10] border-[#1f232f] hover:border-[#353c4f]'
              }`}
            >
              <div className="flex items-center justify-between pb-3 border-b border-[#202533]">
                <span className="text-[#d4af37] font-bold tracking-widest text-[11px]">{line.code.split(' - ')[0]}</span>
                <span className="px-2 py-0.5 bg-[#182015] text-[#22c55e] rounded text-[10px] font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e]"></span>
                  {line.status}
                </span>
              </div>

              <div className="pt-4 space-y-3">
                <div className="text-sm font-bold text-[#f2f0e9] truncate">{line.name}</div>
                
                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div>
                    <span className="text-[#657182] text-[10px] block">OUTPUT</span>
                    <span className="font-bold text-[#f2f0e9]">{line.throughputBarsPerDay.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[#657182] text-[10px] block">EFFICIENCY</span>
                    <span className="font-bold text-[#22c55e]">{line.efficiencyPercent}%</span>
                  </div>
                  <div>
                    <span className="text-[#657182] text-[10px] block">TEMP</span>
                    <span className="font-bold text-[#f2f0e9]">{line.currentTemperatureC}°C</span>
                  </div>
                  <div>
                    <span className="text-[#657182] text-[10px] block">QUALITY YIELD</span>
                    <span className="font-bold text-[#d4af37]">{line.qualityYieldPercent}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Selected Line In-Depth Control Dashboard */}
        <div className="bg-[#0b0d12] border border-[#222736] p-6 sm:p-8 rounded space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-[#1f232f] gap-4">
            <div>
              <span className="text-[#d4af37] font-bold text-xs tracking-widest block uppercase">
                SENSOR TELEMETRY DETAIL • {selectedLine.code}
              </span>
              <h3 className="text-2xl font-serif font-bold text-[#f2f0e9] mt-1">{selectedLine.name}</h3>
              <p className="text-[#8a96a8] text-xs mt-0.5">CURRENT BATCH: {selectedLine.currentBatch}</p>
            </div>

            <div className="flex items-center space-x-3 bg-[#131724] px-4 py-2 rounded border border-[#2b3142]">
              <Activity className="w-4 h-4 text-[#22c55e] animate-spin" />
              <span className="text-[#22c55e] font-bold">100% SENSOR FEED ACTIVE</span>
            </div>
          </div>

          {/* Metric Gauges */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-[#10131d] p-5 rounded border border-[#222736] space-y-2">
              <span className="text-[#657182] text-[10px] uppercase block">Thermal Zone Temperature</span>
              <div className="text-3xl font-bold text-[#f2f0e9]">{selectedLine.currentTemperatureC}°C</div>
              <div className="w-full bg-[#1b202e] h-2 rounded-full overflow-hidden mt-2">
                <div
                  className="bg-[#d4af37] h-full"
                  style={{ width: `${Math.min(100, (selectedLine.currentTemperatureC / 150) * 100)}%` }}
                />
              </div>
            </div>

            <div className="bg-[#10131d] p-5 rounded border border-[#222736] space-y-2">
              <span className="text-[#657182] text-[10px] uppercase block">Conching Vessel Pressure</span>
              <div className="text-3xl font-bold text-[#f2f0e9]">{selectedLine.conchePressureBar} Bar</div>
              <div className="w-full bg-[#1b202e] h-2 rounded-full overflow-hidden mt-2">
                <div
                  className="bg-[#22c55e] h-full"
                  style={{ width: `${Math.min(100, (selectedLine.conchePressureBar / 5) * 100)}%` }}
                />
              </div>
            </div>

            <div className="bg-[#10131d] p-5 rounded border border-[#222736] space-y-2">
              <span className="text-[#657182] text-[10px] uppercase block">Crystallization Index</span>
              <div className="text-3xl font-bold text-[#d4af37]">{selectedLine.temperCrystallizationIndex}</div>
              <div className="text-[10px] text-[#22c55e]">Target Form V Beta-2 Stable</div>
            </div>

            <div className="bg-[#10131d] p-5 rounded border border-[#222736] space-y-2">
              <span className="text-[#657182] text-[10px] uppercase block">Energy Consumption</span>
              <div className="text-3xl font-bold text-[#f2f0e9]">{selectedLine.energyKwhPerKg} kWh/kg</div>
              <div className="text-[10px] text-[#8a96a8]">Hydroelectric New England Grid</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
