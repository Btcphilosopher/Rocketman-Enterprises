import React, { useState } from 'react';
import { Sparkles, ArrowRight, ShieldCheck, Cpu, ShoppingBag, Check } from 'lucide-react';
import { Product } from '../../types';

interface ChocolateFinderViewProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
}

export const ChocolateFinderView: React.FC<ChocolateFinderViewProps> = ({
  products,
  onSelectProduct,
  onAddToCart
}) => {
  const flavorTags = [
    'Bold',
    'Dark',
    'Elegant',
    'Fruity',
    'Nutty',
    'Smoky',
    'Floral',
    'Rich',
    'Bright',
    'Complex'
  ];

  const [selectedTags, setSelectedTags] = useState<string[]>(['Bold', 'Dark', 'Complex']);
  const [personalNote, setPersonalNote] = useState<string>('Looking for a deeply structured bar with long oak finish for late evening tasting.');
  const [loading, setLoading] = useState<boolean>(false);
  const [recommendationResult, setRecommendationResult] = useState<any>(null);

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(selectedTags.filter((t) => t !== tag));
    } else {
      setSelectedTags([...selectedTags, tag]);
    }
  };

  const handleAnalyze = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          preferences: selectedTags,
          note: personalNote,
          userFlavorProfile: { cacaoIntensity: 8, aroma: 9, oakRoast: 8 }
        })
      });

      if (res.ok) {
        const data = await res.json();
        setRecommendationResult(data);
      }
    } catch (err) {
      console.error('Finder error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-5xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#151924] border border-[#2a3040] text-xs font-mono text-[#d4af37] rounded">
            <Sparkles className="w-4 h-4 text-[#d4af37]" />
            AI-POWERED FLAVOR ASSISTANT • BOSTON LAB
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            WHAT KIND OF CHOCOLATE DO YOU WANT?
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-xl mx-auto leading-relaxed">
            Select your desired sensory characteristics. Our AI Master Chocolatier will evaluate our active production runs and curate your personal flight.
          </p>
        </div>

        {/* Tag Selector Grid */}
        <div className="bg-[#0f1118] border border-[#232838] p-6 sm:p-8 rounded space-y-8 font-mono text-xs">
          <div className="space-y-3">
            <span className="text-[#d4af37] font-bold block uppercase">1. SELECT DESIRED SENSORY PROFILE ATTRIBUTES:</span>
            <div className="flex flex-wrap gap-3">
              {flavorTags.map((tag) => {
                const active = selectedTags.includes(tag);
                return (
                  <button
                    key={tag}
                    onClick={() => toggleTag(tag)}
                    className={`px-5 py-2.5 rounded text-xs font-bold transition-all border ${
                      active
                        ? 'bg-[#d4af37] text-[#0c0d10] border-[#d4af37]'
                        : 'bg-[#141822] text-[#8a96a8] border-[#252a38] hover:border-[#383e4d] hover:text-[#f2f0e9]'
                    }`}
                  >
                    {tag.toUpperCase()}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Personal Note Area */}
          <div className="space-y-2">
            <span className="text-[#d4af37] font-bold block uppercase">2. SPECIFY OCCASION OR BEVERAGE PAIRING NOTES:</span>
            <textarea
              rows={3}
              value={personalNote}
              onChange={(e) => setPersonalNote(e.target.value)}
              placeholder="e.g., 'Pairing with a peated Islay single malt whisky after dinner...'"
              className="w-full bg-[#141822] border border-[#252a38] p-3 text-xs font-mono text-[#f2f0e9] rounded focus:outline-none focus:border-[#d4af37]"
            />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={loading}
            className="w-full py-4 bg-[#d4af37] text-[#0c0d10] font-mono text-xs font-bold rounded hover:bg-[#e0be4d] transition-colors flex items-center justify-center space-x-2"
          >
            {loading ? (
              <>
                <Cpu className="w-4 h-4 animate-spin text-[#0c0d10]" />
                <span>EVALUATING CACAO MATRIX IN BOSTON LAB...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>CURATE MY CHOCOLATE FLIGHT</span>
              </>
            )}
          </button>
        </div>

        {/* AI Recommendation Result Card */}
        {recommendationResult && (
          <div className="bg-[#0f1118] border border-[#d4af37] p-6 sm:p-8 rounded space-y-8 font-sans">
            <div className="border-b border-[#232838] pb-4 space-y-2 font-mono">
              <span className="text-xs text-[#d4af37] font-bold tracking-widest uppercase">
                MASTER CHOCOLATIER CURATION
              </span>
              <h3 className="text-2xl font-serif font-bold text-[#f2f0e9]">
                {recommendationResult.recommendationTitle}
              </h3>
            </div>

            <div className="space-y-3 font-sans text-xs text-[#a3b1c6] leading-relaxed">
              <p className="bg-[#141822] p-4 rounded border border-[#222736] font-mono text-xs text-[#f2f0e9]">
                "{recommendationResult.aiAnalysis}"
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs pt-2">
                <div className="bg-[#141822] p-3 rounded border border-[#222736]">
                  <span className="text-[#657182] block text-[10px] uppercase">BEVERAGE PAIRING</span>
                  <span className="text-[#d4af37] font-bold">{recommendationResult.pairingSuggestions}</span>
                </div>
                <div className="bg-[#141822] p-3 rounded border border-[#222736]">
                  <span className="text-[#657182] block text-[10px] uppercase">TECHNICAL INSIGHT</span>
                  <span className="text-[#22c55e] font-bold">{recommendationResult.technicalInsight}</span>
                </div>
              </div>
            </div>

            {/* Curated Products Grid */}
            <div className="space-y-4 font-mono text-xs">
              <span className="text-xs font-bold text-[#d4af37] uppercase">RECOMMENDED SELECTIONS:</span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {recommendationResult.curatedProducts.map((p: Product) => (
                  <div key={p.id} className="bg-[#141822] p-5 rounded border border-[#252a38] space-y-4 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center justify-between text-[#d4af37] font-bold">
                        <span>{p.code}</span>
                        <span>{p.cacaoPercentage}% CACAO</span>
                      </div>
                      <h4 className="text-base font-serif font-bold text-[#f2f0e9] mt-1">{p.name}</h4>
                      <p className="text-xs text-[#8a96a8] font-mono mt-1">{p.tagline}</p>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-[#1f2330]">
                      <span className="text-base font-bold text-[#d4af37]">${p.priceUSD}</span>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => onSelectProduct(p)}
                          className="px-3 py-1.5 bg-[#1e2330] text-[#a3b1c6] rounded hover:text-[#ffffff]"
                        >
                          SPECS
                        </button>
                        <button
                          onClick={() => onAddToCart(p, 1)}
                          className="px-4 py-1.5 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e0be4d]"
                        >
                          ADD TO CART
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
