import React from 'react';
import { ArrowRight, ChevronDown, Compass, Cpu, Layers, Sparkles, ShieldCheck } from 'lucide-react';
import { heroBoxImage } from '../../data/mockData';

interface HeroSectionProps {
  setActiveView: (view: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ setActiveView }) => {
  return (
    <div className="relative min-h-[92vh] flex flex-col justify-between bg-[#08090c] text-[#f2f0e9] overflow-hidden">
      {/* Background Hero Image with Architectural Grid and Dark Vignette */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroBoxImage}
          alt="The New England Chocolate Company Luxury Presentation Box"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-40 mix-blend-luminosity scale-105 transform transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#08090c] via-[#08090c]/70 to-[#08090c]/40" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#08090c_90%)]" />
        
        {/* Subtle Architectural Blueprint Grid Overlay */}
        <div 
          className="absolute inset-0 opacity-[0.03] pointer-events-none"
          style={{
            backgroundImage: `linear-gradient(#d4af37 1px, transparent 1px), linear-gradient(90deg, #d4af37 1px, transparent 1px)`,
            backgroundSize: '80px 80px'
          }}
        />
      </div>

      {/* Top Telemetry Ribbon */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pt-8">
        <div className="inline-flex items-center gap-3 px-4 py-2 rounded bg-[#101217]/90 border border-[#2a2f3d] backdrop-blur-md text-xs font-mono tracking-widest text-[#a3b1c6]">
          <span className="w-2 h-2 rounded-full bg-[#d4af37] animate-ping" />
          <span className="text-[#d4af37] font-bold">ATLANTIC COMMERCE DISPATCH:</span>
          <span className="hidden sm:inline">WEST AFRICA & ECUADOR HARVEST BATCHES ARRIVING BOSTON HARBOR</span>
          <span className="text-[#8a92a3]">| BATCH #048-A TEMPERED AT 31.2°C</span>
        </div>
      </div>

      {/* Main Hero Content */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-16 my-auto">
        <div className="max-w-3xl space-y-8">
          {/* Institutional Badge */}
          <div className="space-y-2">
            <div className="text-xs font-mono tracking-[0.4em] text-[#d4af37] uppercase font-semibold flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
              ESTABLISHED 1887 • BOSTON, MASSACHUSETTS
            </div>
            <h1 className="text-4xl sm:text-6xl md:text-7xl font-serif font-extrabold tracking-tight text-[#f2f0e9] leading-[1.05]">
              THE NEW ENGLAND <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#f2f0e9] via-[#e5d5a1] to-[#b8860b]">
                CHOCOLATE COMPANY
              </span>
            </h1>
          </div>

          {/* Subheading */}
          <p className="text-lg sm:text-2xl font-mono tracking-wider text-[#c2c9d6] border-l-2 border-[#d4af37] pl-4 py-1">
            AMERICAN CHOCOLATE. <br className="sm:hidden" />
            <span className="text-[#d4af37] font-bold">ENGINEERED FOR THE FUTURE.</span>
          </p>

          <p className="text-sm sm:text-base font-sans text-[#a3b1c6] max-w-2xl leading-relaxed">
            Where 19th-century Atlantic merchant culture meets sub-20 micron precision milling, 72-hour rotary conching, and 21st-century food physics. Manufactured at our historic Boston waterfront facility.
          </p>

          {/* Primary & Secondary Action Button Groups */}
          <div className="pt-4 flex flex-col sm:flex-row flex-wrap gap-4 font-mono text-xs tracking-widest">
            {/* Primary Buttons */}
            <button
              onClick={() => setActiveView('chocolate')}
              className="px-8 py-4 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e6c254] transition-all flex items-center justify-center space-x-3 shadow-lg shadow-[#d4af37]/10 group"
            >
              <span>SHOP CHOCOLATE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => setActiveView('house')}
              className="px-8 py-4 bg-[#141720]/90 text-[#f2f0e9] font-bold rounded border border-[#383e4d] hover:border-[#d4af37] transition-all flex items-center justify-center space-x-2 backdrop-blur-md"
            >
              <Compass className="w-4 h-4 text-[#d4af37]" />
              <span>ENTER THE HOUSE</span>
            </button>

            {/* Secondary Buttons */}
            <button
              onClick={() => setActiveView('cocoa')}
              className="px-6 py-4 bg-transparent text-[#a3b1c6] hover:text-[#f2f0e9] font-medium border border-[#2a2f3d] hover:border-[#3d4559] rounded transition-all flex items-center justify-center space-x-2"
            >
              <span>DISCOVER THE COCOA</span>
            </button>

            <button
              onClick={() => setActiveView('factory')}
              className="px-6 py-4 bg-transparent text-[#a3b1c6] hover:text-[#f2f0e9] font-medium border border-[#2a2f3d] hover:border-[#3d4559] rounded transition-all flex items-center justify-center space-x-2"
            >
              <Cpu className="w-4 h-4 text-[#22c55e]" />
              <span>VISIT THE FACTORY</span>
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Technical Specifications Ribbon */}
      <div className="relative z-10 bg-[#060709]/95 border-t border-[#1f232d] py-6 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 font-mono text-xs">
          <div className="border-l border-[#2a2f3d] pl-4">
            <div className="text-[#727d91] text-[10px] uppercase">Mean Particle Size</div>
            <div className="text-base font-bold text-[#f2f0e9] mt-0.5">18.2 MICRONS</div>
            <div className="text-[10px] text-[#d4af37]">Sub-Palate Tactile Limit</div>
          </div>

          <div className="border-l border-[#2a2f3d] pl-4">
            <div className="text-[#727d91] text-[10px] uppercase">Rotary Conching</div>
            <div className="text-base font-bold text-[#f2f0e9] mt-0.5">72 HOURS</div>
            <div className="text-[10px] text-[#22c55e]">Zero-Astringency Extract</div>
          </div>

          <div className="border-l border-[#2a2f3d] pl-4">
            <div className="text-[#727d91] text-[10px] uppercase">Crystallization Index</div>
            <div className="text-base font-bold text-[#f2f0e9] mt-0.5">FORM V BETA-2</div>
            <div className="text-[10px] text-[#d4af37]">78 dB Acoustic Snap</div>
          </div>

          <div className="border-l border-[#2a2f3d] pl-4">
            <div className="text-[#727d91] text-[10px] uppercase">Atlantic Sourcing</div>
            <div className="text-base font-bold text-[#f2f0e9] mt-0.5">5 GLOBAL ESTATES</div>
            <div className="text-[10px] text-[#a3b1c6]">Ecuador • Ghana • Peru</div>
          </div>
        </div>
      </div>
    </div>
  );
};
