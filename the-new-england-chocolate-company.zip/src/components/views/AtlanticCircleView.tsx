import React, { useState } from 'react';
import { ShieldCheck, Award, Check, Compass, Star } from 'lucide-react';

interface AtlanticCircleViewProps {
  memberTier: string;
  setMemberTier: (tier: string) => void;
}

export const AtlanticCircleView: React.FC<AtlanticCircleViewProps> = ({ memberTier, setMemberTier }) => {
  const tiers = [
    {
      name: 'MEMBER',
      annual: '$120 / year',
      perks: ['Quarterly House Flight', 'Access to Cellar Journal', 'Standard Allocation Rights'],
      accessLevel: 'Tier 1 Access'
    },
    {
      name: 'MERCHANT',
      annual: '$350 / year',
      perks: ['Quarterly Grand Cru Flight', '2-Week Early Private Reserve Drops', 'Boston Harbor Tasting Salon Entry'],
      accessLevel: 'Tier 2 Access'
    },
    {
      name: 'FELLOW',
      annual: '$850 / year',
      perks: ['Quarterly Custom Batch', 'Private Factory Tour Access', 'Guaranteed Private Reserve Allocations'],
      accessLevel: 'Tier 3 Access'
    },
    {
      name: 'ATLANTIC PATRON',
      annual: '$2,500 / year',
      perks: ['Personal Master Chocolatier Commission', 'Full Private Reserve Priority', 'Annual Newport Mansion Gala Entry'],
      accessLevel: 'Tier 4 Executive'
    }
  ];

  return (
    <div className="bg-[#0c0d10] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
            PRIVATE MEMBERSHIP ARCHITECTURE • EST. 1887
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE ATLANTIC CIRCLE
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Inspired by historic New England merchant houses, private university clubs, and transatlantic hospitality.
          </p>
        </div>

        {/* Digital Membership Card Preview */}
        <div className="bg-[#0f1118] border border-[#d4af37]/60 p-6 sm:p-8 rounded max-w-xl mx-auto shadow-2xl relative overflow-hidden font-mono text-xs space-y-6">
          <div className="flex items-center justify-between border-b border-[#222736] pb-4">
            <span className="text-[#d4af37] font-bold tracking-widest text-sm">ATLANTIC CIRCLE MEMBER CARD</span>
            <span className="text-[#22c55e] font-bold">{memberTier.toUpperCase()}</span>
          </div>

          <div className="space-y-1 font-serif">
            <div className="text-2xl font-bold text-[#f2f0e9]">THOMAS A. BRADFORD</div>
            <div className="text-xs font-mono text-[#8a96a8]">CLIENT NO: NECC-AC-2026-9840</div>
          </div>

          <div className="flex justify-between items-end border-t border-[#222736] pt-4 text-[10px] text-[#8a96a8]">
            <div>ISSUED: BOSTON HARBOR</div>
            <div>STATUS: ACTIVE & VALID</div>
          </div>
        </div>

        {/* Tier Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-mono text-xs">
          {tiers.map((t) => (
            <div
              key={t.name}
              className={`p-6 rounded border flex flex-col justify-between space-y-6 ${
                memberTier.toLowerCase() === t.name.toLowerCase()
                  ? 'bg-[#141822] border-[#d4af37]'
                  : 'bg-[#0f1118] border-[#222632]'
              }`}
            >
              <div className="space-y-4">
                <div className="text-xs font-bold text-[#d4af37] tracking-widest">{t.name}</div>
                <div className="text-xl font-bold text-[#f2f0e9]">{t.annual}</div>
                <div className="text-[10px] text-[#657182] uppercase">{t.accessLevel}</div>

                <ul className="space-y-2 pt-2 border-t border-[#1f2330] font-sans text-xs text-[#a3b1c6]">
                  {t.perks.map((p) => (
                    <li key={p} className="flex items-start gap-2">
                      <Check className="w-3.5 h-3.5 text-[#22c55e] shrink-0 mt-0.5" />
                      <span>{p}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <button
                onClick={() => setMemberTier(t.name.toLowerCase())}
                className={`w-full py-2.5 rounded font-bold transition-colors ${
                  memberTier.toLowerCase() === t.name.toLowerCase()
                    ? 'bg-[#22c55e] text-[#0c0d10]'
                    : 'bg-[#d4af37] text-[#0c0d10] hover:bg-[#e0be4d]'
                }`}
              >
                {memberTier.toLowerCase() === t.name.toLowerCase() ? 'ACTIVE TIER' : `SELECT ${t.name}`}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
