import React, { useState } from 'react';
import { Product, GiftBoxOption } from '../../types';
import { GIFT_BOX_OPTIONS } from '../../data/mockData';
import { X, ShoppingBag, ShieldCheck, Cpu, Sliders, Check, Award, Gift, Sparkles } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, customEngraving?: string, giftBoxStyle?: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart
}) => {
  if (!product) return null;

  const [quantity, setQuantity] = useState<number>(1);
  const [customEngraving, setCustomEngraving] = useState<string>('');
  const [selectedGiftBox, setSelectedGiftBox] = useState<string>('none');
  const [activeTab, setActiveTab] = useState<'OVERVIEW' | 'TECHNICAL' | 'FLAVOUR' | 'PACKAGING'>('OVERVIEW');
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  const handleAdd = () => {
    onAddToCart(product, quantity, customEngraving.trim() || undefined, selectedGiftBox !== 'none' ? selectedGiftBox : undefined);
    setAddedSuccess(true);
    setTimeout(() => {
      setAddedSuccess(false);
      onClose();
    }, 1200);
  };

  const flavorProfileItems = [
    { label: 'Cacao Intensity', value: product.flavorProfile.cacaoIntensity },
    { label: 'Aroma Depth', value: product.flavorProfile.aroma },
    { label: 'Acidity', value: product.flavorProfile.acidity },
    { label: 'Bitterness', value: product.flavorProfile.bitterness },
    { label: 'Sweetness', value: product.flavorProfile.sweetness },
    { label: 'Body Density', value: product.flavorProfile.body },
    { label: 'Texture Smoothness', value: product.flavorProfile.texture },
    { label: 'Oak & Roast', value: product.flavorProfile.oakRoast },
    { label: 'Finish Length', value: product.flavorProfile.finishLength },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-[#000000]/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto font-sans">
      <div className="bg-[#0d0f14] border border-[#2a2f3d] text-[#f2f0e9] w-full max-w-5xl rounded-lg shadow-2xl overflow-hidden my-auto relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-[#171b24] hover:bg-[#252a38] text-[#a3b1c6] hover:text-[#ffffff] rounded-full border border-[#2d3345] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 max-h-[90vh] overflow-y-auto">
          {/* Left Column: Enormous Editorial Imagery */}
          <div className="lg:col-span-5 bg-[#07080a] p-6 lg:p-8 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#1f232d]">
            <div className="space-y-4">
              <div className="text-[10px] font-mono tracking-widest text-[#d4af37] uppercase flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" /> SPECIFICATION SHEET • {product.code}
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#f2f0e9]">{product.name}</h2>
              <p className="text-xs font-mono text-[#8a96a8]">{product.tagline}</p>
            </div>

            <div className="my-6 relative rounded overflow-hidden border border-[#2a2f3d] bg-[#0c0d10] group">
              <img
                src={product.image}
                alt={product.name}
                referrerPolicy="no-referrer"
                className="w-full h-72 sm:h-80 object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0d0f14] via-transparent to-transparent opacity-60" />
              <div className="absolute bottom-3 left-3 bg-[#0c0d10]/90 px-3 py-1 rounded border border-[#2a2f3d] text-xs font-mono text-[#d4af37]">
                {product.cacaoPercentage}% CACAO • {product.origin.toUpperCase()}
              </div>
            </div>

            {/* Quick Spec Highlights */}
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-[#11141c] p-3 rounded border border-[#1f232d]">
              <div>
                <span className="text-[#657182] block text-[10px] uppercase">Mean Particle Size</span>
                <span className="text-[#22c55e] font-bold">{product.technicalSpecs.particleMicrons} microns</span>
              </div>
              <div>
                <span className="text-[#657182] block text-[10px] uppercase">Conching Duration</span>
                <span className="text-[#f2f0e9] font-bold">{product.technicalSpecs.concheTimeHours} Hours</span>
              </div>
              <div>
                <span className="text-[#657182] block text-[10px] uppercase">Crystallization</span>
                <span className="text-[#d4af37] font-bold">Form V Beta-2</span>
              </div>
              <div>
                <span className="text-[#657182] block text-[10px] uppercase">Temper Index</span>
                <span className="text-[#f2f0e9] font-bold">{product.technicalSpecs.temperIndex}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Architectural Specification Tabs & Order Panel */}
          <div className="lg:col-span-7 p-6 lg:p-8 flex flex-col justify-between space-y-6">
            {/* Tabs Header */}
            <div className="flex border-b border-[#252a36] space-x-6 text-xs font-mono tracking-widest text-[#8a96a8]">
              {(['OVERVIEW', 'TECHNICAL', 'FLAVOUR', 'PACKAGING'] as const).map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-3 font-semibold transition-colors relative ${
                    activeTab === tab ? 'text-[#d4af37]' : 'hover:text-[#f2f0e9]'
                  }`}
                >
                  THE {tab}
                  {activeTab === tab && (
                    <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#d4af37]" />
                  )}
                </button>
              ))}
            </div>

            {/* Tab Contents */}
            <div className="space-y-4 font-sans text-xs text-[#a3b1c6] leading-relaxed min-h-[200px]">
              {activeTab === 'OVERVIEW' && (
                <div className="space-y-4">
                  <p>{product.description}</p>
                  
                  <div className="space-y-2">
                    <span className="text-xs font-mono text-[#d4af37] font-bold uppercase block">BLEND & TERROIR</span>
                    <p className="bg-[#12151c] p-3 rounded border border-[#222632] font-mono text-xs text-[#f2f0e9]">
                      {product.blendDetails}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <span className="text-xs font-mono text-[#d4af37] font-bold uppercase block">FINISH PROFILE</span>
                    <p className="font-serif text-sm italic text-[#f2f0e9]">"{product.finishDescription}"</p>
                  </div>
                </div>
              )}

              {activeTab === 'TECHNICAL' && (
                <div className="space-y-4 font-mono">
                  <div className="text-xs font-bold text-[#d4af37] uppercase">MANUFACTURING PHYSICS SPECIFICATIONS</div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-[#12151c] p-3 rounded border border-[#222632]">
                      <span className="text-[#6a7687] text-[10px] block">PARTICLE SIZE</span>
                      <span className="text-sm font-bold text-[#f2f0e9]">{product.technicalSpecs.particleMicrons} µm</span>
                      <p className="text-[10px] text-[#8a96a8] mt-1 font-sans">Below lingual tactile perception limit.</p>
                    </div>

                    <div className="bg-[#12151c] p-3 rounded border border-[#222632]">
                      <span className="text-[#6a7687] text-[10px] block">CONCHE CYCLE</span>
                      <span className="text-sm font-bold text-[#f2f0e9]">{product.technicalSpecs.concheTimeHours} Hours</span>
                      <p className="text-[10px] text-[#8a96a8] mt-1 font-sans">Rotary double-conche dry phase.</p>
                    </div>

                    <div className="bg-[#12151c] p-3 rounded border border-[#222632]">
                      <span className="text-[#6a7687] text-[10px] block">COCOA BUTTER RATIO</span>
                      <span className="text-sm font-bold text-[#f2f0e9]">{product.technicalSpecs.cocoaButterPercentage}%</span>
                      <p className="text-[10px] text-[#8a96a8] mt-1 font-sans">Natural non-deodorized press.</p>
                    </div>

                    <div className="bg-[#12151c] p-3 rounded border border-[#222632]">
                      <span className="text-[#6a7687] text-[10px] block">ROAST TEMPERATURE</span>
                      <span className="text-sm font-bold text-[#f2f0e9]">{product.technicalSpecs.roastTempCelsius}°C</span>
                      <p className="text-[10px] text-[#8a96a8] mt-1 font-sans">Precision thermal gradient profile.</p>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'FLAVOUR' && (
                <div className="space-y-4 font-mono">
                  <div className="text-xs font-bold text-[#d4af37] uppercase">9-AXIS SENSORY RADAR MAP</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {flavorProfileItems.map((item) => (
                      <div key={item.label} className="bg-[#12151c] p-2.5 rounded border border-[#222632]">
                        <div className="flex justify-between text-[11px] mb-1">
                          <span className="text-[#a3b1c6]">{item.label}</span>
                          <span className="text-[#d4af37] font-bold">{item.value} / 10</span>
                        </div>
                        <div className="w-full h-1.5 bg-[#1e2330] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#b8860b] to-[#d4af37]"
                            style={{ width: `${(item.value / 10) * 100}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'PACKAGING' && (
                <div className="space-y-4">
                  <p>{product.packagingDetails}</p>
                  <div className="bg-[#12151c] p-4 rounded border border-[#222632] space-y-2 font-mono text-xs">
                    <div className="text-[#d4af37] font-bold">INSTITUTIONAL PRESENTATION OPTIONS</div>
                    <p className="text-[#8a96a8]">
                      Includes official provenance certificate stamped with Boston Harbor batch number and Master Chocolatier signature.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Customization Controls: Engraving & Gift Box */}
            <div className="bg-[#12151c] p-4 rounded border border-[#252a36] space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between text-[#d4af37] font-bold">
                <span className="flex items-center gap-1.5">
                  <Gift className="w-4 h-4" />
                  OPTIONAL BRASS ENGRAVING & GIFT VAULT
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] text-[#8a96a8] uppercase block mb-1">Custom Engraved Brass Plate Text:</label>
                  <input
                    type="text"
                    maxLength={32}
                    placeholder="e.g., 'To Arthur - Boston 2026'"
                    value={customEngraving}
                    onChange={(e) => setCustomEngraving(e.target.value)}
                    className="w-full bg-[#181c26] border border-[#2d3345] px-2.5 py-1.5 rounded text-xs font-mono text-[#f2f0e9] focus:outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div>
                  <label className="text-[10px] text-[#8a96a8] uppercase block mb-1">Executive Presentation Box:</label>
                  <select
                    value={selectedGiftBox}
                    onChange={(e) => setSelectedGiftBox(e.target.value)}
                    className="w-full bg-[#181c26] border border-[#2d3345] px-2 py-1.5 rounded text-xs font-mono text-[#f2f0e9] focus:outline-none focus:border-[#d4af37]"
                  >
                    <option value="none">STANDARD PACKAGING (INCLUDED)</option>
                    {GIFT_BOX_OPTIONS.map((g) => (
                      <option key={g.id} value={g.name}>
                        {g.name.toUpperCase()} (+${g.priceAddonUSD})
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            {/* Bottom Order Bar */}
            <div className="pt-4 border-t border-[#222632] flex flex-col sm:flex-row items-center justify-between gap-4 font-mono">
              <div>
                <span className="text-[10px] text-[#8a96a8] uppercase block">Total Price:</span>
                <span className="text-2xl font-bold text-[#d4af37]">
                  ${product.priceUSD * quantity}
                </span>
                <span className="text-xs text-[#8a96a8] ml-2">({product.weightGrams * quantity}g)</span>
              </div>

              <div className="flex items-center space-x-3 w-full sm:w-auto">
                <div className="flex items-center border border-[#2d3345] rounded bg-[#181c26]">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-2 text-[#a3b1c6] hover:text-[#ffffff] text-sm"
                  >
                    -
                  </button>
                  <span className="px-3 py-2 text-xs font-bold text-[#f2f0e9]">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-2 text-[#a3b1c6] hover:text-[#ffffff] text-sm"
                  >
                    +
                  </button>
                </div>

                <button
                  onClick={handleAdd}
                  disabled={addedSuccess}
                  className="flex-1 sm:flex-none px-8 py-3 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e0be4d] transition-colors flex items-center justify-center space-x-2 text-xs"
                >
                  {addedSuccess ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>ADDED TO COLLECTION</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>ADD TO COLLECTION</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
