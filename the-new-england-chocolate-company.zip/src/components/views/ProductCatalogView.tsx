import React, { useState, useMemo } from 'react';
import { Product, ProductCategory, CocoaRegion } from '../../types';
import { SlidersHorizontal, Eye, ShoppingBag, ShieldCheck, Check, Sparkles } from 'lucide-react';

interface ProductCatalogViewProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, quantity?: number) => void;
  setActiveView: (view: string) => void;
}

export const ProductCatalogView: React.FC<ProductCatalogViewProps> = ({
  products,
  onSelectProduct,
  onAddToCart,
  setActiveView
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('ALL');
  const [selectedOrigin, setSelectedOrigin] = useState<string>('ALL');
  const [minCacao, setMinCacao] = useState<number>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [addedNoticeId, setAddedNoticeId] = useState<string | null>(null);

  const categories: ProductCategory[] = [
    'ALL',
    'DARK',
    'MILK',
    'SINGLE ORIGIN',
    'GRAND CRU',
    'AMERICAN EDITIONS',
    'LIMITED RELEASES',
    'SEASONAL',
    'GIFT COLLECTIONS'
  ];

  const origins = ['ALL', 'Ecuador', 'Ghana', 'Madagascar', 'Peru', 'Dominican Republic', 'Venezuela'];

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      if (selectedCategory !== 'ALL' && product.category !== selectedCategory) return false;
      if (selectedOrigin !== 'ALL' && product.origin !== selectedOrigin) return false;
      if (product.cacaoPercentage < minCacao) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matchName = product.name.toLowerCase().includes(q);
        const matchCode = product.code.toLowerCase().includes(q);
        const matchOrigin = product.origin.toLowerCase().includes(q);
        const matchNotes = product.flavourNotes.some(n => n.toLowerCase().includes(q));
        if (!matchName && !matchCode && !matchOrigin && !matchNotes) return false;
      }
      return true;
    });
  }, [products, selectedCategory, selectedOrigin, minCacao, searchQuery]);

  const handleQuickAdd = (p: Product) => {
    onAddToCart(p, 1);
    setAddedNoticeId(p.id);
    setTimeout(() => setAddedNoticeId(null), 2000);
  };

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-12 px-4 sm:px-6 lg:px-8 font-sans min-h-screen">
      <div className="max-w-7xl mx-auto space-y-10">
        {/* Header & Subtitle */}
        <div className="border-b border-[#222632] pb-8 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3">
            <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#d4af37]" />
              THE HOUSE COLLECTION • SPECIFICATION CATALOGUE
            </div>
            <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
              PRECISION CHOCOLATE
            </h2>
            <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl">
              Each bar is crafted like an industrial instrument. Micro-milled to sub-20 microns, long-conched, and tempered to Form V Beta-2 crystal perfection.
            </p>
          </div>

          <div className="flex items-center space-x-3 font-mono text-xs">
            <button
              onClick={() => setActiveView('finder')}
              className="px-4 py-2.5 bg-[#171b24] hover:bg-[#202533] text-[#d4af37] border border-[#d4af37]/40 rounded transition-colors flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>AI CHOCOLATE FINDER</span>
            </button>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex items-center overflow-x-auto space-x-2 pb-2 scrollbar-thin scrollbar-thumb-[#2a2f3d]">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded text-xs font-mono tracking-wider whitespace-nowrap transition-all border ${
                selectedCategory === cat
                  ? 'bg-[#d4af37] text-[#0c0d10] font-bold border-[#d4af37]'
                  : 'bg-[#101217] text-[#8a96a8] border-[#222632] hover:border-[#3d4559] hover:text-[#f2f0e9]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Filter Controls Row */}
        <div className="bg-[#101217] p-4 rounded border border-[#222632] grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
          {/* Origin Select */}
          <div className="flex items-center space-x-3">
            <span className="text-[#6c788a] uppercase text-[11px] whitespace-nowrap">Origin:</span>
            <select
              value={selectedOrigin}
              onChange={(e) => setSelectedOrigin(e.target.value)}
              className="w-full bg-[#181c26] border border-[#2d3345] text-[#f2f0e9] px-3 py-1.5 rounded focus:outline-none focus:border-[#d4af37]"
            >
              {origins.map((o) => (
                <option key={o} value={o}>
                  {o === 'ALL' ? 'ALL ORIGINS' : o.toUpperCase()}
                </option>
              ))}
            </select>
          </div>

          {/* Cacao Slider */}
          <div className="flex items-center space-x-3">
            <span className="text-[#6c788a] uppercase text-[11px] whitespace-nowrap">Min Cacao %:</span>
            <input
              type="range"
              min={0}
              max={90}
              step={5}
              value={minCacao}
              onChange={(e) => setMinCacao(Number(e.target.value))}
              className="w-full accent-[#d4af37]"
            />
            <span className="text-[#d4af37] font-bold min-w-[35px] text-right">{minCacao}%+</span>
          </div>

          {/* Search Input */}
          <div className="flex items-center space-x-2">
            <input
              type="text"
              placeholder="Filter by note, code, or name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#181c26] border border-[#2d3345] text-[#f2f0e9] px-3 py-1.5 rounded focus:outline-none focus:border-[#d4af37] placeholder-[#535d70]"
            />
          </div>
        </div>

        {/* Products Specification Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((p) => (
            <div
              key={p.id}
              className="bg-[#0d0f14] border border-[#222632] hover:border-[#d4af37]/60 rounded transition-all duration-300 flex flex-col justify-between overflow-hidden group shadow-lg"
            >
              <div>
                {/* Product Header Badge */}
                <div className="p-4 bg-[#12151c] border-b border-[#222632] flex items-center justify-between font-mono text-xs">
                  <span className="text-[#d4af37] font-bold tracking-widest">{p.code}</span>
                  <span className="px-2 py-0.5 bg-[#1e2330] text-[#a3b1c6] rounded text-[10px] font-semibold">
                    {p.category}
                  </span>
                </div>

                {/* Product Image Thumbnail */}
                <div 
                  onClick={() => onSelectProduct(p)}
                  className="relative h-56 bg-[#08090c] cursor-pointer overflow-hidden group"
                >
                  <img
                    src={p.image}
                    alt={p.name}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0d0f14] via-transparent to-transparent opacity-80" />

                  {/* Highlighting Tag */}
                  <div className="absolute top-3 left-3 bg-[#0c0d10]/90 backdrop-blur-md px-2.5 py-1 rounded border border-[#2b3142] text-[10px] font-mono text-[#d4af37]">
                    {p.cacaoPercentage}% CACAO
                  </div>

                  {p.privateReserveOnly && (
                    <div className="absolute top-3 right-3 bg-[#b8860b] text-[#0c0d10] font-bold px-2 py-0.5 rounded text-[10px] font-mono">
                      PRIVATE RESERVE
                    </div>
                  )}
                </div>

                {/* Specification Details */}
                <div className="p-6 space-y-4 font-sans">
                  <div>
                    <h3 
                      onClick={() => onSelectProduct(p)}
                      className="text-lg font-serif font-bold text-[#f2f0e9] group-hover:text-[#d4af37] transition-colors cursor-pointer"
                    >
                      {p.name}
                    </h3>
                    <p className="text-xs text-[#8a96a8] font-mono mt-1">{p.tagline}</p>
                  </div>

                  {/* Specification Table */}
                  <div className="grid grid-cols-2 gap-2 text-[11px] font-mono bg-[#12151c] p-3 rounded border border-[#1f232e]">
                    <div>
                      <span className="text-[#657182] block text-[10px] uppercase">Origin</span>
                      <span className="text-[#f2f0e9] font-medium">{p.origin}</span>
                    </div>
                    <div>
                      <span className="text-[#657182] block text-[10px] uppercase">Batch</span>
                      <span className="text-[#f2f0e9] font-medium">{p.batchNumber}</span>
                    </div>
                    <div>
                      <span className="text-[#657182] block text-[10px] uppercase">Particle Size</span>
                      <span className="text-[#22c55e] font-medium">{p.technicalSpecs.particleMicrons} µm</span>
                    </div>
                    <div>
                      <span className="text-[#657182] block text-[10px] uppercase">Conche Time</span>
                      <span className="text-[#f2f0e9] font-medium">{p.technicalSpecs.concheTimeHours}h</span>
                    </div>
                  </div>

                  {/* Flavor Notes Tags */}
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {p.flavourNotes.map((note) => (
                      <span
                        key={note}
                        className="px-2 py-0.5 bg-[#171b24] text-[#a3b1c6] border border-[#282e3d] text-[10px] font-mono rounded"
                      >
                        {note}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Card Footer & Order Controls */}
              <div className="p-6 pt-0 space-y-3 border-t border-[#1f232e] mt-4 font-mono">
                <div className="flex items-center justify-between pt-4">
                  <div>
                    <span className="text-xs text-[#6c788a] block text-[10px] uppercase">Weight / Price</span>
                    <span className="text-lg font-bold text-[#d4af37]">${p.priceUSD}</span>
                    <span className="text-xs text-[#8a96a8] ml-1">({p.weightGrams}g)</span>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onSelectProduct(p)}
                      className="p-2.5 bg-[#171b24] hover:bg-[#222836] text-[#a3b1c6] hover:text-[#f2f0e9] rounded border border-[#2a3040] transition-colors"
                      title="Inspect Technical Specifications"
                    >
                      <Eye className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => handleQuickAdd(p)}
                      className="px-4 py-2.5 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e0be4d] transition-colors flex items-center space-x-1.5 text-xs"
                    >
                      {addedNoticeId === p.id ? (
                        <>
                          <Check className="w-4 h-4" />
                          <span>ADDED</span>
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-4 h-4" />
                          <span>ADD TO CELLAR</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-20 bg-[#101217] rounded border border-[#222632] space-y-4 font-mono">
            <p className="text-sm text-[#8a96a8]">NO SPECIFICATIONS MATCH YOUR CURRENT FILTER PARAMETERS.</p>
            <button
              onClick={() => { setSelectedCategory('ALL'); setSelectedOrigin('ALL'); setMinCacao(0); setSearchQuery(''); }}
              className="px-4 py-2 bg-[#d4af37] text-[#0c0d10] font-bold text-xs rounded"
            >
              RESET ALL FILTERS
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
