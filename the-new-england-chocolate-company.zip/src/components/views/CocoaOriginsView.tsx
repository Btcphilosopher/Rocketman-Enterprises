import React, { useState } from 'react';
import { COCOA_ORIGINS } from '../../data/mockData';
import { Globe, Compass, ShieldCheck, MapPin, Layers, Sun, Thermometer, Wind } from 'lucide-react';

export const CocoaOriginsView: React.FC = () => {
  const [selectedOrigin, setSelectedOrigin] = useState(COCOA_ORIGINS[0]);

  return (
    <div className="bg-[#0c0d10] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Title */}
        <div className="border-b border-[#252a36] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Globe className="w-4 h-4 text-[#d4af37]" />
            GLOBAL COCOA PROVENANCE & ATLANTIC PIPELINE
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            GLOBAL TERROIR REGISTRY
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Every harvest imported into our Boston Harbor docks is cataloged by altitude, soil minerality, micro-climate, and fermentation protocol.
          </p>
        </div>

        {/* Global Map & Origin Selector Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Origin Buttons List */}
          <div className="lg:col-span-4 space-y-3 font-mono text-xs">
            <div className="text-xs font-bold text-[#d4af37] uppercase mb-2">ACTIVE SOURCING ESTATES</div>
            {COCOA_ORIGINS.map((origin) => (
              <button
                key={origin.id}
                onClick={() => setSelectedOrigin(origin)}
                className={`w-full text-left p-4 rounded border transition-all flex items-center justify-between ${
                  selectedOrigin.id === origin.id
                    ? 'bg-[#141822] border-[#d4af37] text-[#f2f0e9]'
                    : 'bg-[#0f1117] border-[#222632] text-[#8a96a8] hover:border-[#383e4d]'
                }`}
              >
                <div>
                  <div className="font-bold text-sm text-[#f2f0e9]">{origin.name}</div>
                  <div className="text-[10px] text-[#6c788a] mt-0.5">{origin.elevationMeters} • {origin.annualImportTons} Tons/Year</div>
                </div>
                <span className="text-[#d4af37] font-bold text-xs">{origin.countryCode}</span>
              </button>
            ))}
          </div>

          {/* Selected Origin Detailed Dossier Card */}
          <div className="lg:col-span-8 bg-[#0f1117] border border-[#252a36] rounded p-6 sm:p-8 space-y-8 font-sans">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-[#222632] gap-4">
              <div>
                <div className="text-xs font-mono text-[#d4af37] font-bold tracking-widest uppercase">
                  ESTATE DOSSIER • {selectedOrigin.countryCode}
                </div>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-[#f2f0e9] mt-1">
                  {selectedOrigin.name} Terroir
                </h3>
              </div>

              <div className="flex items-center space-x-3 font-mono text-xs bg-[#151924] px-4 py-2 rounded border border-[#2b3142]">
                <MapPin className="w-4 h-4 text-[#d4af37]" />
                <span>LAT: {selectedOrigin.coordinates.lat}° | LNG: {selectedOrigin.coordinates.lng}°</span>
              </div>
            </div>

            {/* Terroir Specifications Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 font-mono text-xs">
              <div className="bg-[#141822] p-4 rounded border border-[#222632]">
                <span className="text-[#6c788a] text-[10px] uppercase block">ELEVATION RANGE</span>
                <span className="text-sm font-bold text-[#f2f0e9] mt-0.5 block">{selectedOrigin.elevationMeters}</span>
              </div>

              <div className="bg-[#141822] p-4 rounded border border-[#222632]">
                <span className="text-[#6c788a] text-[10px] uppercase block">HARVEST CYCLE</span>
                <span className="text-sm font-bold text-[#22c55e] mt-0.5 block">{selectedOrigin.harvestMonths}</span>
              </div>

              <div className="bg-[#141822] p-4 rounded border border-[#222632]">
                <span className="text-[#6c788a] text-[10px] uppercase block">ACTIVE BATCHES</span>
                <span className="text-sm font-bold text-[#d4af37] mt-0.5 block">{selectedOrigin.activeBatches} Batches</span>
              </div>
            </div>

            {/* Detailed Description */}
            <div className="space-y-4">
              <h4 className="text-xs font-mono text-[#d4af37] font-bold uppercase">TERROIR & SOIL CHEMISTRY</h4>
              <p className="text-sm text-[#a3b1c6] leading-relaxed">
                {selectedOrigin.terroirDescription}
              </p>
            </div>

            <div className="space-y-4">
              <h4 className="text-xs font-mono text-[#d4af37] font-bold uppercase">FERMENTATION PROTOCOL</h4>
              <div className="bg-[#141822] p-4 rounded border border-[#222632] font-mono text-xs text-[#f2f0e9]">
                {selectedOrigin.fermentationMethod}
              </div>
            </div>

            {/* Key Flavor Profile Tags */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono text-[#d4af37] font-bold uppercase">SIGNATURE AROMATIC EXPRESSION</h4>
              <div className="flex flex-wrap gap-2 font-mono text-xs">
                {selectedOrigin.keyFlavourNotes.map((note) => (
                  <span
                    key={note}
                    className="px-3 py-1 bg-[#1a1f2c] border border-[#2e364a] text-[#d4af37] font-semibold rounded"
                  >
                    {note}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
