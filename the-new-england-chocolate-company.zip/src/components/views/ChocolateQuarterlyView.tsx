import React, { useState } from 'react';
import { ShieldCheck, Check, Package, Calendar } from 'lucide-react';

export const ChocolateQuarterlyView: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<string>('DARK');

  const subscriptionPlans = [
    {
      id: 'HOUSE',
      name: 'THE HOUSE FLIGHT',
      priceUSD: 65,
      frequency: 'Every 3 Months',
      description: '4 curated benchmark bars from House 74, Portland Sea Salt & Newport Milk editions.',
      barsPerShipment: 4
    },
    {
      id: 'DARK',
      name: 'THE DEEP CACAO SELECTION',
      priceUSD: 85,
      frequency: 'Every 3 Months',
      description: '4 high-cacao dark releases (74% to 85%), focused on sub-20 micron particle textures.',
      barsPerShipment: 4
    },
    {
      id: 'ORIGIN',
      name: 'THE GLOBAL TERROIR DISPATCH',
      priceUSD: 95,
      frequency: 'Every 3 Months',
      description: '4 single-estate origin releases (Ecuador, Ghana, Madagascar, Peru) with tasting maps.',
      barsPerShipment: 4
    },
    {
      id: 'GRAND CRU',
      name: 'THE PRESIDENTIAL VAULT SELECTION',
      priceUSD: 145,
      frequency: 'Every 3 Months',
      description: '6 rare vintage releases including 1 Private Reserve allocation in mahogany presentation box.',
      barsPerShipment: 6
    }
  ];

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Package className="w-4 h-4 text-[#d4af37]" />
            QUARTERLY CURATED SHIPMENTS • SUBSCRIPTION
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE CHOCOLATE QUARTERLY
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Delivered every four months directly from our Boston waterfront tempering lines in temperature-monitored insulation.
          </p>
        </div>

        {/* Subscription Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 font-mono text-xs">
          {subscriptionPlans.map((plan) => (
            <div
              key={plan.id}
              onClick={() => setSelectedPlan(plan.id)}
              className={`p-6 rounded border cursor-pointer transition-all flex flex-col justify-between space-y-6 ${
                selectedPlan === plan.id
                  ? 'bg-[#141822] border-[#d4af37]'
                  : 'bg-[#0f1118] border-[#222632] hover:border-[#383e4d]'
              }`}
            >
              <div className="space-y-4">
                <span className="text-xs font-bold text-[#d4af37] tracking-widest block">{plan.name}</span>
                <div className="text-2xl font-bold text-[#f2f0e9]">${plan.priceUSD} / QTR</div>
                <div className="text-[10px] text-[#657182] uppercase">{plan.frequency}</div>
                <p className="text-xs text-[#a3b1c6] font-sans pt-2">{plan.description}</p>
              </div>

              <button
                className={`w-full py-2.5 rounded font-bold transition-colors ${
                  selectedPlan === plan.id
                    ? 'bg-[#d4af37] text-[#0c0d10]'
                    : 'bg-[#1a1f2c] text-[#a3b1c6] hover:text-[#f2f0e9]'
                }`}
              >
                {selectedPlan === plan.id ? 'SELECTED SUBSCRIPTION' : 'SELECT PLAN'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
