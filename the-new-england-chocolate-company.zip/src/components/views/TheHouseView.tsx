import React from 'react';
import { Building2, Compass, Anchor, Cpu, History, Award, ShieldCheck, ArrowRight } from 'lucide-react';
import { bostonHqImage, factoryImage } from '../../data/mockData';

interface TheHouseViewProps {
  setActiveView: (view: string) => void;
}

export const TheHouseView: React.FC<TheHouseViewProps> = ({ setActiveView }) => {
  return (
    <div className="bg-[#0c0d10] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-16">
        {/* Header Title & Institutional Specs */}
        <div className="border-b border-[#2a2e38] pb-12 space-y-6">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#d4af37]" />
            INSTITUTIONAL PROFILE • EST. 1887
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE HOUSE OF NEW ENGLAND
          </h2>
          <p className="text-base sm:text-lg font-mono text-[#a3b1c6] max-w-3xl leading-relaxed">
            "FROM THE ATLANTIC TO THE AMERICAN FACTORY."
          </p>

          {/* Core Data Card Grid */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 font-mono text-xs pt-4">
            <div className="bg-[#12151c] p-4 rounded border border-[#252a36]">
              <div className="text-[#6c788a] uppercase text-[10px]">Founded</div>
              <div className="text-lg font-bold text-[#d4af37] mt-1">1887</div>
              <div className="text-[10px] text-[#8a96a8]">Boston, MA</div>
            </div>

            <div className="bg-[#12151c] p-4 rounded border border-[#252a36]">
              <div className="text-[#6c788a] uppercase text-[10px]">Origin</div>
              <div className="text-lg font-bold text-[#f2f0e9] mt-1">NEW ENGLAND</div>
              <div className="text-[10px] text-[#8a96a8]">United States</div>
            </div>

            <div className="bg-[#12151c] p-4 rounded border border-[#252a36]">
              <div className="text-[#6c788a] uppercase text-[10px]">Headquarters</div>
              <div className="text-lg font-bold text-[#f2f0e9] mt-1">BOSTON</div>
              <div className="text-[10px] text-[#8a96a8]">Waterfront Merchant House</div>
            </div>

            <div className="bg-[#12151c] p-4 rounded border border-[#252a36]">
              <div className="text-[#6c788a] uppercase text-[10px]">Manufacturing</div>
              <div className="text-lg font-bold text-[#f2f0e9] mt-1">NEW ENGLAND</div>
              <div className="text-[10px] text-[#8a96a8]">Boston & Providence</div>
            </div>

            <div className="bg-[#12151c] p-4 rounded border border-[#252a36]">
              <div className="text-[#6c788a] uppercase text-[10px]">Cocoa Pipeline</div>
              <div className="text-lg font-bold text-[#f2f0e9] mt-1">GLOBAL</div>
              <div className="text-[10px] text-[#8a96a8]">Atlantic Direct Import</div>
            </div>

            <div className="bg-[#12151c] p-4 rounded border border-[#252a36]">
              <div className="text-[#6c788a] uppercase text-[10px]">Technology</div>
              <div className="text-lg font-bold text-[#22c55e] mt-1">AMERICAN</div>
              <div className="text-[10px] text-[#8a96a8]">Sub-20µ Precision</div>
            </div>
          </div>
        </div>

        {/* Feature Split Image & Narrative */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h3 className="text-2xl font-serif font-bold text-[#f2f0e9]">
              An American Industrial House, Built on Maritime Heritage and Precision Engineering
            </h3>
            <p className="text-sm text-[#a3b1c6] leading-relaxed font-sans">
              Founded on India Wharf in 1887 by merchant captain Arthur Bradford and metallurgical engineer Silas Vance, The New England Chocolate Company was created to elevate chocolate making from a confectionery craft into a discipline of precision manufacturing.
            </p>
            <p className="text-sm text-[#a3b1c6] leading-relaxed font-sans">
              Rather than copying European alpine traditions, the founders drew inspiration from the mechanical rigor of New England steam mills, Connecticut firearms precision, and Boston maritime commerce. They engineered proprietary granite millstones and heavy iron conching tanks that harnessed river-driven water wheels.
            </p>
            <p className="text-sm text-[#a3b1c6] leading-relaxed font-sans">
              Today, our Boston waterfront facility fuses that 19th-century mercantile legacy with 21st-century food physics, ultrasonic particle classifiers, and automated climate-controlled rotary conches.
            </p>

            <div className="pt-4 flex items-center space-x-4 font-mono text-xs">
              <button
                onClick={() => setActiveView('factory')}
                className="px-6 py-3 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e6c254] transition-colors flex items-center gap-2"
              >
                <span>EXPLORE THE BOSTON FACTORY</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="relative rounded overflow-hidden border border-[#2a2e38]">
            <img
              src={bostonHqImage}
              alt="Boston Waterfront Headquarters of The New England Chocolate Company"
              referrerPolicy="no-referrer"
              className="w-full h-[450px] object-cover"
            />
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#0c0d10] via-[#0c0d10]/80 to-transparent p-6 font-mono text-xs">
              <div className="text-[#d4af37] font-bold">1887 BOSTON MERCHANTS HOUSE & LABORATORY</div>
              <div className="text-[#8a96a8] text-[11px] mt-1">India Wharf, Boston Harbor, Massachusetts</div>
            </div>
          </div>
        </div>

        {/* Historical Eras Timeline */}
        <div className="space-y-8 pt-8">
          <div className="flex items-center space-x-3 text-xs font-mono text-[#d4af37] tracking-widest uppercase">
            <History className="w-4 h-4" />
            THE CHRONICLES OF AMERICAN INDUSTRIAL CACAO
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-[#12151c] p-6 rounded border border-[#252a36] space-y-3">
              <div className="text-xs font-mono text-[#d4af37] font-bold">1887 – 1920: THE MERCHANT ERA</div>
              <h4 className="text-lg font-serif font-bold text-[#f2f0e9]">Atlantic Ships & Granite Mills</h4>
              <p className="text-xs text-[#a3b1c6] leading-relaxed font-sans">
                Direct sailing vessel trade brings wild fermented cacao from Ecuador and the West Indies straight to Boston Harbor. Heavy granite millstones crush beans under steam power.
              </p>
            </div>

            <div className="bg-[#12151c] p-6 rounded border border-[#252a36] space-y-3">
              <div className="text-xs font-mono text-[#d4af37] font-bold">1920 – 1980: INDUSTRIAL EXPANSION</div>
              <h4 className="text-lg font-serif font-bold text-[#f2f0e9]">The Providence Conching Mill</h4>
              <p className="text-xs text-[#a3b1c6] leading-relaxed font-sans">
                Expansion along New England railroad routes. Our ProvidenceSeekonk river mill pioneers continuous rotary conching and high-pressure steel roll refining.
              </p>
            </div>

            <div className="bg-[#12151c] p-6 rounded border border-[#252a36] space-y-3">
              <div className="text-xs font-mono text-[#22c55e] font-bold">1980 – PRESENT: ANGLO-FUTURISM</div>
              <h4 className="text-lg font-serif font-bold text-[#f2f0e9]">Sub-20 Micron Digital Twin</h4>
              <p className="text-xs text-[#a3b1c6] leading-relaxed font-sans">
                Integration of laser particle diffraction, live factory telemetry, and AI flavor profiling. Chocolate engineered with thermodynamic precision.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
