import React from 'react';
import { Building2, MapPin, Anchor, Compass, Clock } from 'lucide-react';
import { bostonHqImage } from '../../data/mockData';

export const BostonHeadquartersView: React.FC = () => {
  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#d4af37]" />
            SYMBOLIC CENTER & HEADQUARTERS • BOSTON HARBOR
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE HOUSE / BOSTON
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Located on India Wharf since 1887. Combining historic brick architecture, Atlantic deepwater access, and modern food physics research.
          </p>
        </div>

        {/* Hero Visual */}
        <div className="relative rounded overflow-hidden border border-[#2a2f3d]">
          <img
            src={bostonHqImage}
            alt="The New England Chocolate Company Boston Headquarters"
            referrerPolicy="no-referrer"
            className="w-full h-96 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#08090c] via-transparent to-transparent opacity-80" />
          <div className="absolute bottom-6 left-6 right-6 font-mono text-xs flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
            <div>
              <div className="text-[#d4af37] font-bold text-sm">INDIA WHARF HISTORIC MERCHANTS HOUSE</div>
              <div className="text-[#8a96a8]">42.3601° N, 71.0589° W • Boston Harbor, Massachusetts</div>
            </div>
            <div className="bg-[#12151c]/90 px-4 py-2 rounded border border-[#2b3142] text-[#22c55e]">
              PRIVATE TASTING SALON: OPEN FOR APPOINTMENTS
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
