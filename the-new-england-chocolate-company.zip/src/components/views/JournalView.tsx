import React, { useState } from 'react';
import { JOURNAL_ARTICLES } from '../../data/mockData';
import { JournalArticle } from '../../types';
import { BookOpen, Calendar, Clock, ArrowRight } from 'lucide-react';

export const JournalView: React.FC = () => {
  const [selectedArticle, setSelectedArticle] = useState<JournalArticle | null>(null);

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#d4af37]" />
            EDITORIAL PUBLICATION • JOURNAL OF CACAO & INDUSTRY
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE JOURNAL
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Essays on food physics, Atlantic trade history, crystallization mechanics, and New England industrial architecture.
          </p>
        </div>

        {/* Selected Reader Mode or Grid */}
        {selectedArticle ? (
          <div className="bg-[#0f1118] border border-[#232838] p-6 sm:p-10 rounded space-y-8 font-sans max-w-4xl mx-auto">
            <button
              onClick={() => setSelectedArticle(null)}
              className="text-xs font-mono text-[#d4af37] hover:underline"
            >
              ← BACK TO ALL JOURNAL ARTICLES
            </button>

            <div className="space-y-4 border-b border-[#222632] pb-6">
              <span className="text-xs font-mono text-[#d4af37] font-bold uppercase">{selectedArticle.category}</span>
              <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#f2f0e9]">{selectedArticle.title}</h1>
              <p className="text-base text-[#a3b1c6] font-serif italic">{selectedArticle.subtitle}</p>

              <div className="flex items-center space-x-6 font-mono text-xs text-[#657182] pt-2">
                <span>{selectedArticle.author} ({selectedArticle.authorTitle})</span>
                <span>•</span>
                <span>{selectedArticle.date}</span>
                <span>•</span>
                <span>{selectedArticle.readTime}</span>
              </div>
            </div>

            <div className="space-y-6 text-sm text-[#c2c9d6] leading-relaxed">
              {selectedArticle.content.map((p, idx) => (
                <p key={idx}>{p}</p>
              ))}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 font-sans">
            {JOURNAL_ARTICLES.map((art) => (
              <div
                key={art.id}
                onClick={() => setSelectedArticle(art)}
                className="bg-[#0f1118] border border-[#232838] hover:border-[#d4af37] rounded overflow-hidden cursor-pointer transition-all flex flex-col justify-between group"
              >
                <div>
                  <div className="h-48 overflow-hidden bg-[#07080a]">
                    <img
                      src={art.image}
                      alt={art.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                  </div>

                  <div className="p-6 space-y-3">
                    <span className="text-[10px] font-mono text-[#d4af37] font-bold uppercase tracking-widest">{art.category}</span>
                    <h3 className="text-lg font-serif font-bold text-[#f2f0e9] group-hover:text-[#d4af37] transition-colors">
                      {art.title}
                    </h3>
                    <p className="text-xs text-[#8a96a8] line-clamp-3">{art.excerpt}</p>
                  </div>
                </div>

                <div className="p-6 pt-0 font-mono text-xs text-[#657182] flex items-center justify-between border-t border-[#1f2330] mt-4">
                  <span>{art.readTime}</span>
                  <span className="text-[#d4af37] font-bold flex items-center gap-1">
                    READ ARTICLE <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
