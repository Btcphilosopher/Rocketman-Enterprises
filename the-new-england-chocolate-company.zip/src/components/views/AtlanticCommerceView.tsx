import React, { useState } from 'react';
import { Anchor, Compass, Globe, ArrowRight, ShieldCheck, Ship, Navigation } from 'lucide-react';

export const AtlanticCommerceView: React.FC = () => {
  const tradeRoutes = [
    {
      origin: 'WEST AFRICA (GHANA / CÔTE D’IVOIRE)',
      volume: '2,850 TONS/YR',
      transitDays: '14 DAYS',
      vessel: 'M/V ENDEAVOUR (BOSTON BOUND)',
      route: 'Ashanti Belt → Tema Port → Transatlantic → Boston Harbor'
    },
    {
      origin: 'SOUTH AMERICA (ECUADOR / PERU)',
      volume: '2,330 TONS/YR',
      transitDays: '10 DAYS',
      vessel: 'M/V BRADFORD (IN TRANSIT)',
      route: 'Guayaquil Port → Panama Canal → Atlantic Corridor → Boston Harbor'
    },
    {
      origin: 'CARIBBEAN (DOMINICAN REPUBLIC)',
      volume: '1,100 TONS/YR',
      transitDays: '6 DAYS',
      vessel: 'M/V NEW ENGLAND MERCHANT (DOCKED)',
      route: 'Santo Domingo → Atlantic Seaboard → Portland Maine Terminal'
    }
  ];

  return (
    <div className="bg-[#0a0c10] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Title */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Anchor className="w-4 h-4 text-[#d4af37]" />
            ATLANTIC COMMERCE & MARITIME TRADE MAP
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE TRANSATLANTIC PIPELINE
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Raw cocoa imported directly across the Atlantic ocean into Boston Harbor granite storehouses.
          </p>
        </div>

        {/* Trade Flow Diagram Card */}
        <div className="bg-[#0f121a] border border-[#232838] p-6 sm:p-10 rounded space-y-8 font-mono text-xs">
          <div className="text-center space-y-2">
            <span className="text-[#d4af37] font-bold tracking-widest text-sm">COMMODITY COMMERCE FLOW SCHEMATIC</span>
            <p className="text-[#8a96a8]">Direct estate procurement to American industrial transformation.</p>
          </div>

          {/* Flow Stepper */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center text-center">
            <div className="bg-[#151924] p-4 rounded border border-[#2b3142] space-y-2">
              <span className="text-[#d4af37] font-bold text-sm block">1. GLOBAL ESTATES</span>
              <span className="text-[10px] text-[#8a96a8] block">West Africa • Ecuador • Peru</span>
            </div>

            <div className="hidden md:flex justify-center text-[#d4af37]">
              <ArrowRight className="w-6 h-6 animate-pulse" />
            </div>

            <div className="bg-[#151924] p-4 rounded border border-[#2b3142] space-y-2">
              <span className="text-[#22c55e] font-bold text-sm block">2. ATLANTIC ROUTE</span>
              <span className="text-[10px] text-[#8a96a8] block">Climate-Controlled Vessels</span>
            </div>

            <div className="hidden md:flex justify-center text-[#d4af37]">
              <ArrowRight className="w-6 h-6 animate-pulse" />
            </div>

            <div className="bg-[#151924] p-4 rounded border border-[#2b3142] space-y-2">
              <span className="text-[#d4af37] font-bold text-sm block">3. BOSTON HARBOR</span>
              <span className="text-[10px] text-[#8a96a8] block">1887 Granite Merchant Docks</span>
            </div>
          </div>
        </div>

        {/* Live Cargo Route Cards */}
        <div className="space-y-4 font-mono text-xs">
          <div className="text-xs font-bold text-[#d4af37] uppercase">ACTIVE ATLANTIC VESSEL MANIFESTS</div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {tradeRoutes.map((route) => (
              <div key={route.origin} className="bg-[#0f121a] p-6 rounded border border-[#232838] space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-[#1f2330]">
                  <span className="text-[#d4af37] font-bold">{route.vessel}</span>
                  <span className="text-[#22c55e] font-bold">{route.transitDays}</span>
                </div>

                <div className="space-y-2 font-sans">
                  <h4 className="text-base font-serif font-bold text-[#f2f0e9]">{route.origin}</h4>
                  <p className="text-xs text-[#8a96a8] font-mono">{route.route}</p>
                </div>

                <div className="bg-[#151924] p-3 rounded border border-[#2b3142] flex justify-between">
                  <span className="text-[#657182] text-[10px]">ANNUAL VOLUME</span>
                  <span className="text-[#f2f0e9] font-bold">{route.volume}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
