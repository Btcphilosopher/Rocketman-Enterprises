import React, { useState } from 'react';
import { Cpu, Sliders, ShieldCheck, Flame, RotateCw, Sparkles, CheckCircle2 } from 'lucide-react';
import { factoryImage } from '../../data/mockData';

export const FactoryView: React.FC = () => {
  const [activeStageIndex, setActiveStageIndex] = useState<number>(6); // Default to conching

  const factoryStages = [
    {
      code: 'STAGE 01',
      title: 'BEAN RECEIVING & CLEANING',
      short: 'RECEIVING',
      facility: 'Portland & Boston Docks',
      details: 'Raw jute bags are unloaded from Atlantic vessels. Ultrasonic screeners remove ambient debris while optical color sorters isolate uniform beans.'
    },
    {
      code: 'STAGE 02',
      title: 'THERMAL GRADIENT ROASTING',
      short: 'ROASTING',
      facility: 'Rotary Roaster Line 01',
      details: 'Beans pass through radiant thermal coils at 120-135°C. Controlled Maillard kinetics maximize cocoa butter flavor precursors.'
    },
    {
      code: 'STAGE 03',
      title: 'MECHANICAL CRACKING',
      short: 'CRACKING',
      facility: 'Impact Breaker Mill',
      details: 'Precision impact rollers fracture roasted shells without crushing interior cocoa nib solids.'
    },
    {
      code: 'STAGE 04',
      title: 'AIR CYCLONE WINNOWING',
      short: 'WINNOWING',
      facility: 'Pneumatic Separation Column',
      details: 'Counter-current air currents lift away light husk fragments, yielding 99.8% pure cocoa nib nibs.'
    },
    {
      code: 'STAGE 05',
      title: 'PRIMARY NIB GRINDING',
      short: 'GRINDING',
      facility: 'Granite Stone Mill',
      details: 'Heavy rotating granite stones reduce nibs into liquid cocoa liquor at 45°C via friction heat.'
    },
    {
      code: 'STAGE 06',
      title: 'HIGH-PRESSURE STEEL REFINING',
      short: 'REFINING',
      facility: '5-Roll Steel Mill Line 02',
      details: 'Five chilled alloy steel rollers apply extreme shear force, milling cocoa solids down to 18.2 microns.'
    },
    {
      code: 'STAGE 07',
      title: '72-HOUR ROTARY LONG-CONCHE',
      short: 'CONCHING',
      facility: 'Providence Rotary Conche Vessel',
      details: 'Heated rotary agitators knead liquid chocolate for 72 hours. Removes unwanted volatile acids while enveloping sugar in cocoa butter.'
    },
    {
      code: 'STAGE 08',
      title: 'FORM V BETA CRYSTAL TEMPERING',
      short: 'TEMPERING',
      facility: 'Multi-Zone Temper Column',
      details: 'Liquid chocolate cools to 27°C then warms to 31.5°C under continuous shear to induce stable Form V Beta-2 crystals.'
    },
    {
      code: 'STAGE 09',
      title: 'PRECISION DEPOSITING & MOULDING',
      short: 'MOULDING',
      facility: 'Automated Moulding Tunnel',
      details: 'Pneumatic depositors inject exact bar weights into heated geometric moulds followed by ultrasonic bubble removal.'
    },
    {
      code: 'STAGE 10',
      title: 'HERMETIC FOIL & WOOD PACKAGING',
      short: 'PACKAGING',
      facility: 'Robotic Packaging Cell',
      details: 'Bars are wrapped in protective foil, sealed in cotton paper boxes, and stamped with unique brass serial batch numbers.'
    }
  ];

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#22c55e] uppercase flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[#22c55e]" />
            PRECISION MANUFACTURING FACILITY • BOSTON & PROVIDENCE
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE FACTORY SCHEMATIC
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Positioned between a historic 19th-century textile mill and a 2040s precision-manufacturing facility.
          </p>
        </div>

        {/* Hero Image & Factory Overview */}
        <div className="relative rounded overflow-hidden border border-[#2a2f3d]">
          <img
            src={factoryImage}
            alt="The New England Chocolate Factory Facility"
            referrerPolicy="no-referrer"
            className="w-full h-80 sm:h-96 object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#08090c] via-transparent to-transparent" />
          <div className="absolute bottom-6 left-6 right-6 flex flex-col md:flex-row items-start md:items-end justify-between gap-4 font-mono text-xs">
            <div>
              <div className="text-[#22c55e] font-bold text-sm">BOSTON WATERFRONT MANUFACTURING COMPLEX</div>
              <div className="text-[#8a96a8] mt-0.5">Blackened Steel • Chilled Granite • Copper Conching Tanks</div>
            </div>
            <div className="bg-[#12151c]/90 backdrop-blur-md px-4 py-2 rounded border border-[#2d3345] text-[#d4af37]">
              OPERATIONAL STATUS: 10/10 STAGES SYNCHRONIZED
            </div>
          </div>
        </div>

        {/* Interactive 10-Stage Horizontal Flow Tracker */}
        <div className="space-y-4 font-mono text-xs">
          <div className="text-xs font-bold text-[#d4af37] uppercase">MANUFACTURING PROCESS PIPELINE</div>
          <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
            {factoryStages.map((stage, idx) => (
              <button
                key={stage.code}
                onClick={() => setActiveStageIndex(idx)}
                className={`p-3 rounded border text-left transition-all ${
                  activeStageIndex === idx
                    ? 'bg-[#d4af37] text-[#0c0d10] font-bold border-[#d4af37]'
                    : 'bg-[#101217] text-[#8a96a8] border-[#222632] hover:border-[#3d4559]'
                }`}
              >
                <div className="text-[10px] opacity-80">{stage.code}</div>
                <div className="text-xs font-bold truncate mt-1">{stage.short}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Active Stage Detailed Breakdown Panel */}
        <div className="bg-[#101217] border border-[#252a36] p-6 sm:p-8 rounded space-y-6 font-sans">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-[#222632] gap-4 font-mono">
            <div>
              <span className="text-xs text-[#22c55e] font-bold tracking-widest">{factoryStages[activeStageIndex].code}</span>
              <h3 className="text-2xl font-serif font-bold text-[#f2f0e9] mt-1">
                {factoryStages[activeStageIndex].title}
              </h3>
            </div>
            <div className="text-xs text-[#8a96a8] bg-[#161a24] px-4 py-2 rounded border border-[#2a3040]">
              FACILITY: {factoryStages[activeStageIndex].facility.toUpperCase()}
            </div>
          </div>

          <p className="text-sm text-[#a3b1c6] leading-relaxed font-sans">
            {factoryStages[activeStageIndex].details}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 font-mono text-xs pt-2">
            <div className="bg-[#161a24] p-3 rounded border border-[#232938]">
              <span className="text-[#657182] text-[10px] block">CRITICAL CONTROL POINT</span>
              <span className="text-[#22c55e] font-bold">AUTOMATED CONTINUOUS FEED</span>
            </div>
            <div className="bg-[#161a24] p-3 rounded border border-[#232938]">
              <span className="text-[#657182] text-[10px] block">QUALITY CHECKS</span>
              <span className="text-[#d4af37] font-bold">LASER & ULTRASONIC SPECTRUM</span>
            </div>
            <div className="bg-[#161a24] p-3 rounded border border-[#232938]">
              <span className="text-[#657182] text-[10px] block">LINE SYNCHRONIZATION</span>
              <span className="text-[#f2f0e9] font-bold">99.8% EFFICIENCY YIELD</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
