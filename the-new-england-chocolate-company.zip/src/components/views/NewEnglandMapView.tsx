import React, { useState } from 'react';
import { NEW_ENGLAND_LOCATIONS } from '../../data/mockData';
import { MapPin, Compass, Building2, Anchor, Cpu, ArrowRight } from 'lucide-react';

export const NewEnglandMapView: React.FC = () => {
  const [selectedLoc, setSelectedLoc] = useState(NEW_ENGLAND_LOCATIONS[0]);

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Title */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Compass className="w-4 h-4 text-[#d4af37]" />
            REGIONAL INDUSTRIAL INFRASTRUCTURE • NEW ENGLAND
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE NEW ENGLAND NETWORK
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Spanning Boston waterfront headquarters, Rhode Island conching mills, Maine deepwater port terminals, and Connecticut food physics laboratories.
          </p>
        </div>

        {/* Map Visualizer & Location List Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Interactive Map Graphical Frame */}
          <div className="lg:col-span-7 bg-[#0f1117] border border-[#252a36] rounded p-6 space-y-6 relative overflow-hidden font-mono text-xs">
            <div className="flex items-center justify-between border-b border-[#222632] pb-4">
              <span className="text-[#d4af37] font-bold">NORTHEAST ATLANTIC CORRIDOR SCHEMATIC</span>
              <span className="text-[#6c788a] text-[10px]">SCALE: 1:500,000</span>
            </div>

            {/* Stylized Vector Map Box */}
            <div className="relative h-96 bg-[#08090c] rounded border border-[#1f232e] overflow-hidden p-4 flex flex-col justify-between">
              {/* Background Coastline Grid Overlay */}
              <div 
                className="absolute inset-0 opacity-10 pointer-events-none"
                style={{
                  backgroundImage: `radial-gradient(#d4af37 1px, transparent 1px)`,
                  backgroundSize: '24px 24px'
                }}
              />

              {/* Decorative Atlantic Coastline Vector */}
              <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-[#0d1421]/40 border-l border-[#1b2538] flex items-center justify-center">
                <span className="text-[10px] text-[#2b3a52] rotate-90 tracking-[0.5em] font-bold">ATLANTIC OCEAN</span>
              </div>

              {/* Location Pins overlay */}
              <div className="relative z-10 space-y-6">
                {NEW_ENGLAND_LOCATIONS.map((loc, idx) => (
                  <button
                    key={loc.id}
                    onClick={() => setSelectedLoc(loc)}
                    className={`flex items-center space-x-3 px-3 py-2 rounded border transition-all ${
                      selectedLoc.id === loc.id
                        ? 'bg-[#d4af37] text-[#0c0d10] font-bold border-[#d4af37] shadow-lg shadow-[#d4af37]/20 scale-105'
                        : 'bg-[#12151c]/90 text-[#a3b1c6] border-[#222632] hover:border-[#383e4d] hover:text-[#ffffff]'
                    }`}
                  >
                    <MapPin className="w-4 h-4 text-[#d4af37]" />
                    <span>{loc.city}, {loc.state} — {loc.name}</span>
                  </button>
                ))}
              </div>

              <div className="relative z-10 text-[10px] text-[#6c788a] flex justify-between pt-4 border-t border-[#1f232e]">
                <span>BOSTON HARBOR: LAT 42.3601° N</span>
                <span>STATE RAILWAY LINK: OPERATIONAL</span>
              </div>
            </div>
          </div>

          {/* Selected Location Profile Card */}
          <div className="lg:col-span-5 bg-[#0f1117] border border-[#252a36] rounded p-6 sm:p-8 space-y-6 font-sans">
            <div className="border-b border-[#222632] pb-4 space-y-2 font-mono">
              <span className="text-xs text-[#d4af37] font-bold tracking-widest uppercase">
                {selectedLoc.type} • EST. {selectedLoc.yearEstablished}
              </span>
              <h3 className="text-2xl font-serif font-bold text-[#f2f0e9]">{selectedLoc.name}</h3>
              <p className="text-xs text-[#22c55e] font-bold">{selectedLoc.status}</p>
            </div>

            <p className="text-sm text-[#a3b1c6] leading-relaxed">
              {selectedLoc.description}
            </p>

            <div className="space-y-3 font-mono text-xs pt-4 border-t border-[#222632]">
              <div className="bg-[#141822] p-3 rounded border border-[#222632]">
                <span className="text-[#6c788a] text-[10px] block uppercase">Coordinates</span>
                <span className="text-[#f2f0e9] font-bold">{selectedLoc.coordinates.lat}° N, {Math.abs(selectedLoc.coordinates.lng)}° W</span>
              </div>

              <div className="bg-[#141822] p-3 rounded border border-[#222632]">
                <span className="text-[#6c788a] text-[10px] block uppercase">Regional Function</span>
                <span className="text-[#d4af37] font-bold">{selectedLoc.type.replace('_', ' ')}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
