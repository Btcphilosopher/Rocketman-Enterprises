import React, { useState } from 'react';
import { Sliders, Cpu, ShieldCheck, Thermometer, Sparkles, Activity } from 'lucide-react';

export const ChocolateEngineeringView: React.FC = () => {
  const [particleSizeMicrons, setParticleSizeMicrons] = useState<number>(18.2);
  const [concheHours, setConcheHours] = useState<number>(72);
  const [temperCelsius, setTemperCelsius] = useState<number>(31.5);

  // Derived tactile & snap calculations
  const tactilePerception = particleSizeMicrons < 20.0 ? 'IMPERCEPTIBLE (SILK VELVET)' : 'GRITTY TACTILE DETECTED';
  const volatilityRemovalPercent = Math.min(99.9, Number((concheHours * 1.35).toFixed(1)));
  const crystalForm = temperCelsius >= 31.0 && temperCelsius <= 32.0 ? 'FORM V BETA-2 (STABLE SNAP)' : 'UNSTABLE FORM I-IV (BLOOM RISK)';

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#d4af37]" />
            THE SCIENCE OF CHOCOLATE • FOOD PHYSICS & RHEOLOGY
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            PHYSICS OF CACAO
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Manipulating crystalline polymorphs, shear stress, and particle micrometer distribution to achieve acoustic snap and immediate lingual melting.
          </p>
        </div>

        {/* Interactive Physics Simulator */}
        <div className="bg-[#0f1118] border border-[#252a38] p-6 sm:p-8 rounded space-y-8 font-mono text-xs">
          <div className="flex items-center justify-between pb-4 border-b border-[#202533]">
            <span className="text-[#d4af37] font-bold text-sm">INTERACTIVE RHEOLOGY SIMULATOR</span>
            <span className="text-[#22c55e]">MIT-ADJACENT RESEARCH SIMULATION</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Particle Microns Slider */}
            <div className="bg-[#141822] p-5 rounded border border-[#222736] space-y-3">
              <label className="text-[#a3b1c6] uppercase block font-bold">1. Particle Size (Microns)</label>
              <input
                type="range"
                min={10}
                max={40}
                step={0.5}
                value={particleSizeMicrons}
                onChange={(e) => setParticleSizeMicrons(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
              <div className="flex justify-between font-bold">
                <span className="text-[#657182]">VALUE:</span>
                <span className="text-[#d4af37] text-sm">{particleSizeMicrons} µm</span>
              </div>
              <div className="text-[10px] text-[#22c55e] border-t border-[#1f232e] pt-2">
                STATUS: {tactilePerception}
              </div>
            </div>

            {/* Conching Hours Slider */}
            <div className="bg-[#141822] p-5 rounded border border-[#222736] space-y-3">
              <label className="text-[#a3b1c6] uppercase block font-bold">2. Conching Duration (Hours)</label>
              <input
                type="range"
                min={12}
                max={96}
                step={6}
                value={concheHours}
                onChange={(e) => setConcheHours(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
              <div className="flex justify-between font-bold">
                <span className="text-[#657182]">VALUE:</span>
                <span className="text-[#f2f0e9] text-sm">{concheHours} Hours</span>
              </div>
              <div className="text-[10px] text-[#d4af37] border-t border-[#1f232e] pt-2">
                VOLATILE ACID REMOVAL: {volatilityRemovalPercent}%
              </div>
            </div>

            {/* Temper Temperature Slider */}
            <div className="bg-[#141822] p-5 rounded border border-[#222736] space-y-3">
              <label className="text-[#a3b1c6] uppercase block font-bold">3. Temper Zone Temperature (°C)</label>
              <input
                type="range"
                min={26.0}
                max={35.0}
                step={0.1}
                value={temperCelsius}
                onChange={(e) => setTemperCelsius(Number(e.target.value))}
                className="w-full accent-[#d4af37]"
              />
              <div className="flex justify-between font-bold">
                <span className="text-[#657182]">VALUE:</span>
                <span className="text-[#f2f0e9] text-sm">{temperCelsius}°C</span>
              </div>
              <div className="text-[10px] text-[#22c55e] border-t border-[#1f232e] pt-2">
                CRYSTAL: {crystalForm}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
