import React, { useState } from 'react';
import { Gift, ShieldCheck, Check, Sparkles } from 'lucide-react';
import { GIFT_BOX_OPTIONS, PRODUCTS } from '../../data/mockData';
import { Product } from '../../types';

interface GiftingViewProps {
  onAddToCart: (product: Product, quantity?: number, customEngraving?: string, giftBoxStyle?: string) => void;
}

export const GiftingView: React.FC = () => {
  const [selectedBoxId, setSelectedBoxId] = useState<string>(GIFT_BOX_OPTIONS[0].id);
  const [engravingText, setEngravingText] = useState<string>('FOR ALEXANDER - BOSTON 2026');
  const [giftNote, setGiftNote] = useState<string>('With highest institutional compliments from the New England Merchant House.');
  const [orderConfirmed, setOrderConfirmed] = useState<boolean>(false);

  const selectedBox = GIFT_BOX_OPTIONS.find((g) => g.id === selectedBoxId) || GIFT_BOX_OPTIONS[0];

  const handleCreateCommission = () => {
    setOrderConfirmed(true);
    setTimeout(() => setOrderConfirmed(false), 3000);
  };

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Gift className="w-4 h-4 text-[#d4af37]" />
            EXECUTIVE & PRIVATE COMMISSIONS • GIFTING
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            INSTITUTIONAL GIFTING
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Custom mahogany vaults, laser-engraved brass plates, and hand-stamped gold foil gift notes for corporate executives and private commissions.
          </p>
        </div>

        {/* Custom Box Builder Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Box Options */}
          <div className="lg:col-span-7 space-y-6 font-mono text-xs">
            <span className="text-xs font-bold text-[#d4af37] uppercase block">1. SELECT PRESENTATION VAULT:</span>
            <div className="space-y-4">
              {GIFT_BOX_OPTIONS.map((box) => (
                <div
                  key={box.id}
                  onClick={() => setSelectedBoxId(box.id)}
                  className={`p-5 rounded border cursor-pointer transition-all ${
                    selectedBoxId === box.id
                      ? 'bg-[#121622] border-[#d4af37]'
                      : 'bg-[#0f1118] border-[#222632] hover:border-[#383e4d]'
                  }`}
                >
                  <div className="flex items-center justify-between pb-2 border-b border-[#1f2330]">
                    <span className="font-bold text-sm text-[#f2f0e9]">{box.name}</span>
                    <span className="text-[#d4af37] font-bold">+${box.priceAddonUSD}</span>
                  </div>
                  <p className="text-xs text-[#8a96a8] font-sans mt-2">{box.description}</p>
                </div>
              ))}
            </div>

            <div className="space-y-4 pt-4">
              <span className="text-xs font-bold text-[#d4af37] uppercase block">2. ENGRAVING & COMPLIMENTS:</span>
              <div className="space-y-3 font-sans">
                <div>
                  <label className="text-xs font-mono text-[#8a96a8] block mb-1">Brass Plate Engraving (Max 36 Chars):</label>
                  <input
                    type="text"
                    maxLength={36}
                    value={engravingText}
                    onChange={(e) => setEngravingText(e.target.value)}
                    className="w-full bg-[#12151c] border border-[#232838] p-2.5 font-mono text-xs text-[#f2f0e9] rounded focus:outline-none focus:border-[#d4af37]"
                  />
                </div>

                <div>
                  <label className="text-xs font-mono text-[#8a96a8] block mb-1">Printed Parchment Message:</label>
                  <textarea
                    rows={3}
                    value={giftNote}
                    onChange={(e) => setGiftNote(e.target.value)}
                    className="w-full bg-[#12151c] border border-[#232838] p-2.5 font-mono text-xs text-[#f2f0e9] rounded focus:outline-none focus:border-[#d4af37]"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Real-time Box Preview */}
          <div className="lg:col-span-5 bg-[#0f1118] border border-[#252a36] rounded p-6 sm:p-8 space-y-6 font-mono text-xs">
            <div className="border-b border-[#222632] pb-3 text-[#d4af37] font-bold">LIVE GIFT COMMISSION PREVIEW</div>
            
            <div className="relative rounded overflow-hidden border border-[#222632] bg-[#07080a] h-60">
              <img
                src={selectedBox.image}
                alt={selectedBox.name}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-3 left-3 right-3 bg-[#0c0d10]/90 backdrop-blur-md p-3 rounded border border-[#2a3040] text-center">
                <span className="text-[10px] text-[#657182] block">BRASS ENGRAVING PREVIEW</span>
                <span className="text-xs font-serif italic text-[#d4af37] font-bold tracking-wider">
                  "{engravingText || 'YOUR TEXT HERE'}"
                </span>
              </div>
            </div>

            <div className="space-y-2 font-sans text-xs text-[#8a96a8]">
              <div className="text-[#f2f0e9] font-bold font-mono">SELECTED VAULT: {selectedBox.name}</div>
              <p>Includes official provenance certificate and temperature-controlled white-glove delivery.</p>
            </div>

            <button
              onClick={handleCreateCommission}
              className="w-full py-4 bg-[#d4af37] text-[#0c0d10] font-mono text-xs font-bold rounded hover:bg-[#e0be4d] transition-colors flex items-center justify-center space-x-2"
            >
              {orderConfirmed ? (
                <>
                  <Check className="w-4 h-4" />
                  <span>PRIVATE COMMISSION INITIATED</span>
                </>
              ) : (
                <span>SUBMIT PRIVATE COMMISSION REQUEST</span>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
