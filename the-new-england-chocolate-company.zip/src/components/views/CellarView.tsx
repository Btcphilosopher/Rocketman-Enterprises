import React, { useState } from 'react';
import { ShieldCheck, BookOpen, Layers, Award, Plus, Trash2, Edit3, Save } from 'lucide-react';
import { CellarItem, Product } from '../../types';
import { PRODUCTS } from '../../data/mockData';

export const CellarView: React.FC = () => {
  const [cellarItems, setCellarItems] = useState<CellarItem[]>([
    {
      id: 'cellar-01',
      productId: PRODUCTS[0].id,
      product: PRODUCTS[0],
      purchaseDate: '2026-07-14',
      batchNumber: 'BATCH 048-A',
      vintageYear: 2026,
      quantity: 4,
      userRating: 9,
      userNotes: 'Exceptional crisp snap. Deep black cherry notes pair brilliantly with 12-year Lagavulin.',
      storageVault: 'BOSTON HUMIDIFIED VAULT #04'
    },
    {
      id: 'cellar-02',
      productId: PRODUCTS[1].id,
      product: PRODUCTS[1],
      purchaseDate: '2026-06-28',
      batchNumber: 'BATCH 019-B',
      vintageYear: 2025,
      quantity: 2,
      userRating: 10,
      userNotes: 'Reserved for winter aging. High tannin structure.',
      storageVault: 'PRIVATE COLLECTION CABINET A'
    },
    {
      id: 'cellar-03',
      productId: PRODUCTS[6].id,
      product: PRODUCTS[6],
      purchaseDate: '2026-08-01',
      batchNumber: 'BATCH 014 / 300',
      vintageYear: 2026,
      quantity: 1,
      userRating: 10,
      userNotes: 'Rare wild heirloom Ecuador. Transcendent length.',
      storageVault: 'NEWPORT MANSION PRIVATE LOCKER'
    }
  ]);

  const [isEditingNoteId, setIsEditingNoteId] = useState<string | null>(null);
  const [tempNoteText, setTempNoteText] = useState<string>('');

  const totalBarsInCellar = cellarItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalValuation = cellarItems.reduce((sum, item) => sum + (item.product.priceUSD * item.quantity), 0);

  const startEditNote = (item: CellarItem) => {
    setIsEditingNoteId(item.id);
    setTempNoteText(item.userNotes || '');
  };

  const saveNote = (id: string) => {
    setCellarItems(cellarItems.map(item => item.id === id ? { ...item, userNotes: tempNoteText } : item));
    setIsEditingNoteId(null);
  };

  return (
    <div className="bg-[#08090c] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Title */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-[#d4af37]" />
            MY DIGITAL CELLAR & COLLECTION VAULT
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            THE PRIVATE CELLAR
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            A digital inventory of your stored allocations, vintage harvests, batch numbers, and personal sensory notes.
          </p>
        </div>

        {/* Cellar Summary Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
          <div className="bg-[#0f1118] p-5 rounded border border-[#222736]">
            <span className="text-[#657182] uppercase text-[10px] block">TOTAL STORED BARS</span>
            <span className="text-2xl font-bold text-[#d4af37] mt-1 block">{totalBarsInCellar} BARS</span>
          </div>

          <div className="bg-[#0f1118] p-5 rounded border border-[#222736]">
            <span className="text-[#657182] uppercase text-[10px] block">COLLECTION VALUATION</span>
            <span className="text-2xl font-bold text-[#22c55e] mt-1 block">${totalValuation} USD</span>
          </div>

          <div className="bg-[#0f1118] p-5 rounded border border-[#222736]">
            <span className="text-[#657182] uppercase text-[10px] block">ACTIVE BATCH VINTAGES</span>
            <span className="text-2xl font-bold text-[#f2f0e9] mt-1 block">2025 – 2026</span>
          </div>

          <div className="bg-[#0f1118] p-5 rounded border border-[#222736]">
            <span className="text-[#657182] uppercase text-[10px] block">VAULT STORAGE STATUS</span>
            <span className="text-2xl font-bold text-[#d4af37] mt-1 block">18°C • 55% RH</span>
          </div>
        </div>

        {/* Cellar Vault Inventory List */}
        <div className="space-y-6 font-mono text-xs">
          <div className="text-xs font-bold text-[#d4af37] uppercase">CELLAR LOG & JOURNAL</div>
          <div className="space-y-4">
            {cellarItems.map((item) => (
              <div
                key={item.id}
                className="bg-[#0f1118] border border-[#232838] p-6 rounded space-y-4 font-sans"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#1f2330] gap-2 font-mono">
                  <div>
                    <span className="text-[#d4af37] font-bold text-xs">{item.product.code}</span>
                    <h3 className="text-xl font-serif font-bold text-[#f2f0e9] mt-0.5">{item.product.name}</h3>
                  </div>

                  <div className="flex items-center space-x-4 text-xs">
                    <span className="bg-[#151924] px-3 py-1 rounded border border-[#282f42] text-[#d4af37]">
                      {item.batchNumber}
                    </span>
                    <span className="text-[#22c55e] font-bold">QTY: {item.quantity}</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
                  <div className="bg-[#141822] p-3 rounded border border-[#222632]">
                    <span className="text-[#657182] text-[10px] block">PURCHASE DATE</span>
                    <span className="text-[#f2f0e9] font-bold">{item.purchaseDate}</span>
                  </div>

                  <div className="bg-[#141822] p-3 rounded border border-[#222632]">
                    <span className="text-[#657182] text-[10px] block">STORAGE LOCATION</span>
                    <span className="text-[#d4af37] font-bold">{item.storageVault}</span>
                  </div>

                  <div className="bg-[#141822] p-3 rounded border border-[#222632]">
                    <span className="text-[#657182] text-[10px] block">SENSORY RATING</span>
                    <span className="text-[#22c55e] font-bold">{item.userRating} / 10 STARS</span>
                  </div>
                </div>

                {/* Personal Notes Section */}
                <div className="bg-[#141822] p-4 rounded border border-[#222632] space-y-2 font-mono">
                  <div className="flex items-center justify-between">
                    <span className="text-[#d4af37] font-bold text-xs">PRIVATE TASTING NOTES:</span>
                    {isEditingNoteId === item.id ? (
                      <button
                        onClick={() => saveNote(item.id)}
                        className="text-[#22c55e] hover:underline flex items-center gap-1 text-xs"
                      >
                        <Save className="w-3.5 h-3.5" /> SAVE NOTE
                      </button>
                    ) : (
                      <button
                        onClick={() => startEditNote(item)}
                        className="text-[#8a96a8] hover:text-[#d4af37] flex items-center gap-1 text-xs"
                      >
                        <Edit3 className="w-3.5 h-3.5" /> EDIT NOTE
                      </button>
                    )}
                  </div>

                  {isEditingNoteId === item.id ? (
                    <textarea
                      rows={2}
                      value={tempNoteText}
                      onChange={(e) => setTempNoteText(e.target.value)}
                      className="w-full bg-[#181c26] border border-[#2d3345] p-2 text-xs font-mono text-[#f2f0e9] rounded focus:outline-none"
                    />
                  ) : (
                    <p className="text-xs text-[#a3b1c6] font-serif italic">
                      "{item.userNotes || 'No sensory notes recorded yet.'}"
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
