import React, { useState } from 'react';
import { Sliders, Sparkles, Check, RefreshCw } from 'lucide-react';
import { PRODUCTS } from '../../data/mockData';

export const TastingSystemView: React.FC = () => {
  const [selectedProductId, setSelectedProductId] = useState<string>(PRODUCTS[0].id);

  const selectedProduct = PRODUCTS.find((p) => p.id === selectedProductId) || PRODUCTS[0];

  const flavorAxes = [
    { key: 'cacaoIntensity', label: 'Cacao Intensity', value: selectedProduct.flavorProfile.cacaoIntensity },
    { key: 'aroma', label: 'Aroma Complexity', value: selectedProduct.flavorProfile.aroma },
    { key: 'acidity', label: 'Fruit Acidity', value: selectedProduct.flavorProfile.acidity },
    { key: 'bitterness', label: 'Tannic Bitterness', value: selectedProduct.flavorProfile.bitterness },
    { key: 'sweetness', label: 'Natural Sweetness', value: selectedProduct.flavorProfile.sweetness },
    { key: 'body', label: 'Mouthfeel Density', value: selectedProduct.flavorProfile.body },
    { key: 'texture', label: 'Melt Smoothness', value: selectedProduct.flavorProfile.texture },
    { key: 'oakRoast', label: 'Oak & Roast Depth', value: selectedProduct.flavorProfile.oakRoast },
    { key: 'finishLength', label: 'Finish Persistence', value: selectedProduct.flavorProfile.finishLength },
  ];

  return (
    <div className="bg-[#0c0d10] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#d4af37]" />
            9-AXIS INDUSTRIAL SENSORY EVALUATION SYSTEM
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            TASTING RADAR & ANALYSIS
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Quantitative flavor mapping developed for our Boston tasting laboratory. Evaluates 9 physical dimensions of cacao expression.
          </p>
        </div>

        {/* Product Selector Bar */}
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 scrollbar-thin">
          {PRODUCTS.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedProductId(p.id)}
              className={`px-4 py-2 rounded font-mono text-xs whitespace-nowrap border transition-all ${
                selectedProductId === p.id
                  ? 'bg-[#d4af37] text-[#0c0d10] font-bold border-[#d4af37]'
                  : 'bg-[#10131c] text-[#8a96a8] border-[#202533] hover:text-[#f2f0e9]'
              }`}
            >
              {p.code} ({p.cacaoPercentage}%)
            </button>
          ))}
        </div>

        {/* Sensory Profile Display Grid */}
        <div className="bg-[#0f1118] border border-[#232838] p-6 sm:p-8 rounded space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-[#202533] gap-4">
            <div>
              <span className="text-xs font-mono text-[#d4af37] font-bold">{selectedProduct.code} EVALUATION SHEET</span>
              <h3 className="text-2xl font-serif font-bold text-[#f2f0e9]">{selectedProduct.name}</h3>
              <p className="text-xs font-mono text-[#8a96a8] mt-1">{selectedProduct.origin} • {selectedProduct.cacaoPercentage}% Cacao</p>
            </div>

            <div className="flex items-center space-x-2 font-mono text-xs">
              {selectedProduct.flavourNotes.map((n) => (
                <span key={n} className="px-3 py-1 bg-[#151924] border border-[#2a3040] text-[#d4af37] rounded">
                  {n}
                </span>
              ))}
            </div>
          </div>

          {/* 9 Axes Bars */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
            {flavorAxes.map((axis) => (
              <div key={axis.key} className="bg-[#141822] p-4 rounded border border-[#222736] space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#a3b1c6] font-bold">{axis.label}</span>
                  <span className="text-[#d4af37] font-bold">{axis.value} / 10</span>
                </div>
                <div className="w-full bg-[#1b202e] h-2 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#b8860b] to-[#d4af37]"
                    style={{ width: `${(axis.value / 10) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="bg-[#141822] p-4 rounded border border-[#222736] font-mono text-xs space-y-2">
            <span className="text-[#d4af37] font-bold block">FINISH NOTES:</span>
            <p className="text-[#a3b1c6] font-serif italic text-sm">"{selectedProduct.finishDescription}"</p>
          </div>
        </div>
      </div>
    </div>
  );
};
