import React, { useState } from 'react';
import { Lock, Unlock, ShieldCheck, Key, ShoppingBag, Check, Award } from 'lucide-react';
import { PRODUCTS } from '../../data/mockData';
import { Product } from '../../types';

interface PrivateReserveViewProps {
  onAddToCart: (product: Product, quantity?: number) => void;
}

export const PrivateReserveView: React.FC<PrivateReserveViewProps> = ({ onAddToCart }) => {
  const [passcode, setPasscode] = useState<string>('');
  const [isUnlocked, setIsUnlocked] = useState<boolean>(true); // Default accessible preview for seamless UX
  const [reservedIds, setReservedIds] = useState<string[]>([]);

  const privateProducts = PRODUCTS.filter((p) => p.privateReserveOnly || p.category === 'LIMITED RELEASES');

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcode.trim().toUpperCase() === 'BOSTON1887' || passcode.trim().length >= 4) {
      setIsUnlocked(true);
    } else {
      alert('Access Code Required: Try "BOSTON1887" or Atlantic Circle Member Key.');
    }
  };

  const handleReserve = (product: Product) => {
    onAddToCart(product, 1);
    setReservedIds([...reservedIds, product.id]);
  };

  return (
    <div className="bg-[#060709] text-[#f2f0e9] py-16 px-4 sm:px-6 lg:px-8 font-sans min-h-screen">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header */}
        <div className="border-b border-[#222632] pb-8 space-y-4">
          <div className="text-xs font-mono tracking-[0.3em] text-[#d4af37] uppercase flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#d4af37]" />
            RESTRICTED ALLOCATION • THE PRIVATE RESERVE VAULT
          </div>
          <h2 className="text-3xl sm:text-5xl font-serif font-bold text-[#f2f0e9] tracking-tight">
            INVITATION-ONLY ALLOCATIONS
          </h2>
          <p className="text-sm font-mono text-[#a3b1c6] max-w-2xl leading-relaxed">
            Rare wild harvests, experimental single-barrel micro-batches, and numbered collector releases produced in micro-quantities.
          </p>
        </div>

        {/* Passcode Unlock Bar if locked */}
        {!isUnlocked ? (
          <div className="bg-[#0f1118] border border-[#232838] p-8 rounded text-center max-w-md mx-auto space-y-4 font-mono text-xs">
            <Lock className="w-8 h-8 text-[#d4af37] mx-auto" />
            <div className="text-sm font-bold text-[#f2f0e9]">ENTER ATLANTIC CIRCLE ALLOCATION PASSCODE</div>
            <p className="text-[#8a96a8]">Member key required to unlock Private Reserve drops.</p>
            <form onSubmit={handleUnlock} className="space-y-3">
              <input
                type="password"
                placeholder="Passcode (Try 'BOSTON1887')"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                className="w-full bg-[#151924] border border-[#2b3142] px-3 py-2 text-center text-xs font-mono text-[#f2f0e9] rounded focus:outline-none focus:border-[#d4af37]"
              />
              <button
                type="submit"
                className="w-full py-2.5 bg-[#d4af37] text-[#0c0d10] font-bold rounded"
              >
                UNLOCK VAULT ALLOCATIONS
              </button>
            </form>
          </div>
        ) : (
          <div className="space-y-8">
            <div className="bg-[#121622] border border-[#d4af37]/40 p-4 rounded flex items-center justify-between font-mono text-xs text-[#d4af37]">
              <span className="flex items-center gap-2 font-bold">
                <Unlock className="w-4 h-4" /> ALLOCATION VAULT UNLOCKED • ATLANTIC PATRON KEY ACTIVE
              </span>
              <span>BOSTON VAULT #01</span>
            </div>

            {/* Reserved Products Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {privateProducts.map((p) => {
                const isReserved = reservedIds.includes(p.id);
                return (
                  <div
                    key={p.id}
                    className="bg-[#0f1118] border border-[#d4af37]/50 rounded p-6 sm:p-8 space-y-6 relative overflow-hidden"
                  >
                    <div className="flex items-center justify-between border-b border-[#222736] pb-4 font-mono text-xs">
                      <span className="text-[#d4af37] font-bold tracking-widest">{p.batchNumber}</span>
                      <span className="px-2.5 py-0.5 bg-[#261f0e] text-[#d4af37] border border-[#d4af37]/40 rounded text-[10px] font-bold">
                        {p.allocationRemaining || 18} BARS REMAINING
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-6">
                      <div className="sm:col-span-5 relative rounded overflow-hidden border border-[#222736] bg-[#08090c]">
                        <img
                          src={p.image}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="w-full h-48 sm:h-full object-cover"
                        />
                      </div>

                      <div className="sm:col-span-7 space-y-4">
                        <h3 className="text-xl font-serif font-bold text-[#f2f0e9]">{p.name}</h3>
                        <p className="text-xs text-[#a3b1c6] font-sans leading-relaxed">{p.description}</p>

                        <div className="bg-[#151924] p-3 rounded border border-[#222736] font-mono text-xs space-y-1">
                          <div className="text-[#657182] text-[10px]">HARVEST VINTAGE</div>
                          <div className="text-[#f2f0e9] font-bold">{p.vintageYear} • {p.origin} ({p.cacaoPercentage}%)</div>
                        </div>

                        <div className="flex items-center justify-between pt-2 font-mono">
                          <span className="text-xl font-bold text-[#d4af37]">${p.priceUSD}</span>
                          <button
                            onClick={() => handleReserve(p)}
                            disabled={isReserved}
                            className={`px-6 py-2.5 rounded font-bold text-xs transition-colors ${
                              isReserved
                                ? 'bg-[#22c55e] text-[#0c0d10]'
                                : 'bg-[#d4af37] text-[#0c0d10] hover:bg-[#e0be4d]'
                            }`}
                          >
                            {isReserved ? 'ALLOCATION CLAIMED' : 'CLAIM ALLOCATION'}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
