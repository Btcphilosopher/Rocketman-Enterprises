import React from 'react';
import { Compass, Anchor, Cpu, Building2, MapPin, Mail, ArrowUpRight } from 'lucide-react';

interface FooterProps {
  setActiveView: (view: string) => void;
  setIsCmsOpen: (open: boolean) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActiveView, setIsCmsOpen }) => {
  return (
    <footer className="bg-[#07080a] text-[#a3b1c6] border-t border-[#1f232d] pt-16 pb-12 font-mono text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Upper Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#1b1f28]">
          {/* Institutional Manifesto */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-2 text-[#d4af37]">
              <Building2 className="w-5 h-5" />
              <span className="text-sm font-serif font-bold tracking-wider text-[#f2f0e9]">
                THE NEW ENGLAND CHOCOLATE COMPANY
              </span>
            </div>
            <p className="text-xs text-[#8a96a8] leading-relaxed pr-6 font-sans">
              Founded during the American Industrial Age in 1887. Built on Atlantic maritime commerce, New England manufacturing precision, and sub-20 micron particle science. Engineered for the 21st century.
            </p>
            <div className="text-[11px] text-[#6b7687] pt-2 space-y-1">
              <div>FOUNDED: 1887 • BOSTON HARBOR, MASSACHUSETTS</div>
              <div>PATENTS: US-PRECISION-CACAO-TEMPER #94,820</div>
            </div>
          </div>

          {/* Divisions Navigation */}
          <div className="space-y-3">
            <h4 className="text-xs text-[#f2f0e9] font-bold tracking-widest uppercase border-b border-[#252a36] pb-1.5">
              DIVISIONS
            </h4>
            <ul className="space-y-2 text-[#8a96a8]">
              <li>
                <button onClick={() => setActiveView('house')} className="hover:text-[#d4af37] transition-colors">
                  The House & History
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('chocolate')} className="hover:text-[#d4af37] transition-colors">
                  House Chocolate Catalog
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('factory')} className="hover:text-[#d4af37] transition-colors">
                  Boston Factory Facilities
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('telemetry')} className="hover:text-[#d4af37] transition-colors">
                  Digital Twin Live Telemetry
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('science')} className="hover:text-[#d4af37] transition-colors">
                  The Science of Chocolate
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('reserve')} className="hover:text-[#d4af37] transition-colors">
                  Private Reserve Vault
                </button>
              </li>
            </ul>
          </div>

          {/* Regional Network */}
          <div className="space-y-3">
            <h4 className="text-xs text-[#f2f0e9] font-bold tracking-widest uppercase border-b border-[#252a36] pb-1.5">
              NEW ENGLAND NETWORK
            </h4>
            <ul className="space-y-2 text-[#8a96a8]">
              <li>
                <button onClick={() => setActiveView('map')} className="hover:text-[#d4af37] transition-colors flex items-center justify-between w-full">
                  <span>Boston Waterfront HQ</span>
                  <MapPin className="w-3 h-3 text-[#d4af37]" />
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('map')} className="hover:text-[#d4af37] transition-colors flex items-center justify-between w-full">
                  <span>Providence Conching Mill</span>
                  <MapPin className="w-3 h-3 text-[#8a96a8]" />
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('map')} className="hover:text-[#d4af37] transition-colors flex items-center justify-between w-full">
                  <span>Portland Atlantic Terminal</span>
                  <Anchor className="w-3 h-3 text-[#8a96a8]" />
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('map')} className="hover:text-[#d4af37] transition-colors flex items-center justify-between w-full">
                  <span>New Haven Rheology Lab</span>
                  <Compass className="w-3 h-3 text-[#8a96a8]" />
                </button>
              </li>
              <li>
                <button onClick={() => setActiveView('map')} className="hover:text-[#d4af37] transition-colors flex items-center justify-between w-full">
                  <span>Newport Flagship Salon</span>
                  <ArrowUpRight className="w-3 h-3 text-[#8a96a8]" />
                </button>
              </li>
            </ul>
          </div>

          {/* Atlantic Shipping Gazette Newsletter */}
          <div className="space-y-3">
            <h4 className="text-xs text-[#f2f0e9] font-bold tracking-widest uppercase border-b border-[#252a36] pb-1.5">
              ATLANTIC DISPATCH
            </h4>
            <p className="text-[11px] text-[#7a8699] font-sans">
              Subscribe to quarterly cocoa crop reports, private reserve allocations, and industrial dispatches.
            </p>
            <div className="flex flex-col space-y-2">
              <input
                type="email"
                placeholder="client@institution.com"
                className="bg-[#12151c] border border-[#2a2f3d] px-3 py-2 text-xs font-mono text-[#f2f0e9] rounded focus:outline-none focus:border-[#d4af37]"
              />
              <button 
                onClick={() => alert('Subscription confirmed to the Atlantic Dispatch.')}
                className="bg-[#d4af37] text-[#0c0d10] font-mono text-xs font-bold py-2 rounded hover:bg-[#e0be4d] transition-colors"
              >
                JOIN THE DISPATCH
              </button>
            </div>
          </div>
        </div>

        {/* Lower Banner & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between text-[11px] text-[#5e6978] space-y-4 md:space-y-0">
          <div>
            © 1887–2026 THE NEW ENGLAND CHOCOLATE COMPANY. ALL RIGHTS RESERVED.
          </div>

          <div className="flex items-center space-x-6">
            <button onClick={() => setIsCmsOpen(true)} className="hover:text-[#d4af37] flex items-center gap-1">
              <Cpu className="w-3 h-3 text-[#d4af37]" />
              CMS & TELEMETRY
            </button>
            <span>TERMS OF MERCHANDISE</span>
            <span>PRIVACY & SECURITY</span>
            <span>PROVENANCE CERTIFICATION</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
