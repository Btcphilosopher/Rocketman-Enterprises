import React, { useState } from 'react';
import { X, Cpu, Save, Plus, RefreshCw, Check, ShieldCheck, Database } from 'lucide-react';
import { Product } from '../types';

interface CmsModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onProductUpdated: (updatedProduct: Product) => void;
  onRefreshProducts: () => void;
}

export const CmsModal: React.FC<CmsModalProps> = ({
  isOpen,
  onClose,
  products,
  onProductUpdated,
  onRefreshProducts
}) => {
  if (!isOpen) return null;

  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [editingPrice, setEditingPrice] = useState<number>(products[0]?.priceUSD || 22);
  const [editingBatch, setEditingBatch] = useState<string>(products[0]?.batchNumber || 'BATCH 048-A');
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);
  const [isPosting, setIsPosting] = useState<boolean>(false);

  const selectedProduct = products.find((p) => p.id === selectedProductId) || products[0];

  const handleProductChange = (id: string) => {
    setSelectedProductId(id);
    const p = products.find((item) => item.id === id);
    if (p) {
      setEditingPrice(p.priceUSD);
      setEditingBatch(p.batchNumber);
    }
  };

  const handleSave = async () => {
    if (!selectedProduct) return;
    setIsPosting(true);
    const updated: Product = {
      ...selectedProduct,
      priceUSD: Number(editingPrice),
      batchNumber: editingBatch.trim() || selectedProduct.batchNumber
    };

    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });

      if (res.ok) {
        onProductUpdated(updated);
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 2000);
      }
    } catch (err) {
      console.error('Failed to update product via API', err);
      // Local fallback update
      onProductUpdated(updated);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 2000);
    } finally {
      setIsPosting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#000000]/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto font-sans">
      <div className="bg-[#0c0d10] border border-[#2a2f3d] text-[#f2f0e9] w-full max-w-3xl rounded-lg shadow-2xl p-6 relative space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 bg-[#171b24] hover:bg-[#252a38] text-[#a3b1c6] hover:text-[#ffffff] rounded-full border border-[#2d3345] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="border-b border-[#222632] pb-4 space-y-1">
          <div className="text-xs font-mono tracking-widest text-[#d4af37] uppercase flex items-center gap-2">
            <Cpu className="w-4 h-4 text-[#d4af37]" />
            BOSTON CENTRAL MANUFACTURING CMS & CATALOGUE CONSOLE
          </div>
          <h2 className="text-2xl font-serif font-bold text-[#f2f0e9]">INSTITUTIONAL PRODUCT MANAGEMENT</h2>
          <p className="text-xs font-mono text-[#8a96a8]">
            Direct database sync with the server API at <code className="text-[#22c55e]">/api/products</code>
          </p>
        </div>

        {/* CMS Controls Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
          {/* Select Product */}
          <div className="space-y-2">
            <label className="text-[#a3b1c6] uppercase block">Select Catalog Specification:</label>
            <select
              value={selectedProductId}
              onChange={(e) => handleProductChange(e.target.value)}
              className="w-full bg-[#141720] border border-[#2e3547] text-[#f2f0e9] px-3 py-2 rounded focus:outline-none focus:border-[#d4af37]"
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.code} - {p.name.toUpperCase()} (${p.priceUSD})
                </option>
              ))}
            </select>
          </div>

          {/* Edit Price */}
          <div className="space-y-2">
            <label className="text-[#a3b1c6] uppercase block">Wholesale / Retail Price (USD):</label>
            <input
              type="number"
              value={editingPrice}
              onChange={(e) => setEditingPrice(Number(e.target.value))}
              className="w-full bg-[#141720] border border-[#2e3547] text-[#d4af37] font-bold px-3 py-2 rounded focus:outline-none focus:border-[#d4af37]"
            />
          </div>

          {/* Edit Batch Number */}
          <div className="space-y-2 md:col-span-2">
            <label className="text-[#a3b1c6] uppercase block">Active Production Batch Tag:</label>
            <input
              type="text"
              value={editingBatch}
              onChange={(e) => setEditingBatch(e.target.value)}
              className="w-full bg-[#141720] border border-[#2e3547] text-[#f2f0e9] px-3 py-2 rounded focus:outline-none focus:border-[#d4af37]"
            />
          </div>
        </div>

        {/* Active Product Details Preview Card */}
        {selectedProduct && (
          <div className="bg-[#12151c] p-4 rounded border border-[#222632] space-y-3 font-mono text-xs">
            <div className="flex justify-between items-center text-[#d4af37] font-bold">
              <span>{selectedProduct.code} SPECIFICATION SUMMARY</span>
              <span>{selectedProduct.cacaoPercentage}% CACAO</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px] text-[#a3b1c6]">
              <div>Origin: <span className="text-[#f2f0e9] font-semibold">{selectedProduct.origin}</span></div>
              <div>Particle Size: <span className="text-[#22c55e] font-semibold">{selectedProduct.technicalSpecs.particleMicrons} µm</span></div>
              <div>Conching: <span className="text-[#f2f0e9] font-semibold">{selectedProduct.technicalSpecs.concheTimeHours}h</span></div>
              <div>Current Price: <span className="text-[#d4af37] font-semibold">${selectedProduct.priceUSD}</span></div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="pt-4 border-t border-[#222632] flex items-center justify-between font-mono text-xs">
          <button
            onClick={onRefreshProducts}
            className="px-4 py-2 bg-[#171b24] hover:bg-[#202533] text-[#a3b1c6] rounded border border-[#2e3547] flex items-center gap-2"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            SYNC API DATA
          </button>

          <button
            onClick={handleSave}
            disabled={isPosting}
            className="px-6 py-2.5 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e0be4d] transition-colors flex items-center gap-2"
          >
            {saveSuccess ? (
              <>
                <Check className="w-4 h-4" />
                <span>UPDATED & SYNCED</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>{isPosting ? 'POSTING...' : 'COMMIT SPECIFICATION CHANGE'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
