import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, Gift } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onProceedToCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout
}) => {
  if (!isOpen) return null;

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.priceUSD * item.quantity, 0);

  return (
    <div className="fixed inset-0 z-50 bg-[#000000]/80 backdrop-blur-sm flex justify-end font-sans">
      <div className="bg-[#0c0d10] border-l border-[#2a2e38] text-[#f2f0e9] w-full max-w-md h-full flex flex-col justify-between p-6 shadow-2xl relative">
        {/* Drawer Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#222632]">
          <div className="flex items-center space-x-2 font-mono text-xs">
            <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
            <span className="text-[#f2f0e9] font-bold tracking-wider">YOUR CACAO COLLECTION ({cartItems.length})</span>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-[#8a96a8] hover:text-[#ffffff] rounded border border-[#222632]"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Items List */}
        <div className="flex-1 overflow-y-auto py-6 space-y-4">
          {cartItems.length === 0 ? (
            <div className="text-center py-20 space-y-3 font-mono text-xs text-[#8a96a8]">
              <p>YOUR CELLAR BASKET IS EMPTY.</p>
              <p className="text-[10px]">Select chocolate bars from the specification catalogue.</p>
            </div>
          ) : (
            cartItems.map((item, idx) => (
              <div key={idx} className="bg-[#12151c] p-4 rounded border border-[#222632] space-y-3 font-mono text-xs">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-[#d4af37] font-bold text-[10px]">{item.product.code}</span>
                    <h4 className="font-bold text-sm text-[#f2f0e9] font-serif">{item.product.name}</h4>
                  </div>
                  <button
                    onClick={() => onRemoveItem(idx)}
                    className="text-[#8a96a8] hover:text-[#ef4444] p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {item.customEngraving && (
                  <div className="text-[10px] text-[#d4af37] bg-[#1a1e2b] p-2 rounded border border-[#2b3142]">
                    ENGRAVING: "{item.customEngraving}"
                  </div>
                )}

                {item.giftBoxStyle && (
                  <div className="text-[10px] text-[#22c55e] flex items-center gap-1">
                    <Gift className="w-3 h-3" /> VAULT: {item.giftBoxStyle}
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-[#1f2330]">
                  <div className="flex items-center border border-[#2d3345] rounded bg-[#181c26]">
                    <button
                      onClick={() => onUpdateQuantity(idx, Math.max(1, item.quantity - 1))}
                      className="px-2 py-0.5 text-[#a3b1c6]"
                    >
                      -
                    </button>
                    <span className="px-2 py-0.5 text-xs font-bold text-[#f2f0e9]">{item.quantity}</span>
                    <button
                      onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                      className="px-2 py-0.5 text-[#a3b1c6]"
                    >
                      +
                    </button>
                  </div>

                  <span className="font-bold text-sm text-[#d4af37]">
                    ${item.product.priceUSD * item.quantity}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Drawer Footer */}
        {cartItems.length > 0 && (
          <div className="pt-4 border-t border-[#222632] space-y-4 font-mono text-xs">
            <div className="flex justify-between text-sm font-bold">
              <span className="text-[#a3b1c6]">SUBTOTAL:</span>
              <span className="text-[#d4af37]">${subtotal} USD</span>
            </div>

            <button
              onClick={() => {
                onClose();
                onProceedToCheckout();
              }}
              className="w-full py-4 bg-[#d4af37] text-[#0c0d10] font-bold rounded hover:bg-[#e0be4d] transition-colors flex items-center justify-center space-x-2"
            >
              <span>PROCEED TO INSTITUTIONAL CHECKOUT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
