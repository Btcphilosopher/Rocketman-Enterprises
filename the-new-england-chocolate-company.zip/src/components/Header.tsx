import React, { useState } from 'react';
import { ShoppingBag, Search, ShieldCheck, Compass, Sliders, Volume2, VolumeX, Menu, X, Cpu } from 'lucide-react';

interface HeaderProps {
  activeView: string;
  setActiveView: (view: string) => void;
  cartCount: number;
  setIsCartOpen: (open: boolean) => void;
  isAudioMuted: boolean;
  setIsAudioMuted: (muted: boolean) => void;
  setIsCmsOpen: (open: boolean) => void;
  memberTier: string;
}

export const Header: React.FC<HeaderProps> = ({
  activeView,
  setActiveView,
  cartCount,
  setIsCartOpen,
  isAudioMuted,
  setIsAudioMuted,
  setIsCmsOpen,
  memberTier
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const mainNavItems = [
    { id: 'house', label: 'THE HOUSE' },
    { id: 'chocolate', label: 'CHOCOLATE' },
    { id: 'cocoa', label: 'COCOA ORIGINS' },
    { id: 'factory', label: 'THE FACTORY' },
    { id: 'telemetry', label: 'DIGITAL TWIN' },
    { id: 'finder', label: 'CHOCOLATE FINDER' },
    { id: 'journal', label: 'THE JOURNAL' },
    { id: 'reserve', label: 'PRIVATE RESERVE' },
    { id: 'cellar', label: 'MY CELLAR' },
    { id: 'circle', label: 'ATLANTIC CIRCLE' },
    { id: 'gifts', label: 'GIFTS' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-[#0c0d10]/95 backdrop-blur-md border-b border-[#2a2e38] text-[#f2f0e9]">
      {/* Top Telemetry / Status Bar */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1.5 bg-[#060709] text-[11px] font-mono tracking-widest text-[#8a92a3] border-b border-[#1f222b]">
        <div className="flex items-center space-x-6">
          <span className="flex items-center gap-1.5 text-[#22c55e]">
            <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e] animate-pulse"></span>
            BOSTON HARBOR FACILITY: OPERATIONAL
          </span>
          <span>LAT: 42.3601° N, LON: 71.0589° W</span>
          <span>ATLANTIC VESSEL: M/V ENDEAVOUR (EN ROUTE)</span>
        </div>
        <div className="flex items-center space-x-6">
          <button 
            onClick={() => setIsCmsOpen(true)}
            className="hover:text-[#d4af37] flex items-center gap-1 text-[#a3b1c6] transition-colors"
            title="Open Manufacturing & Catalog CMS"
          >
            <Cpu className="w-3 h-3 text-[#d4af37]" />
            INSTITUTIONAL CMS
          </button>
          <span>TEMP: 18.5°C | HUMIDITY: 40%</span>
          <span className="text-[#d4af37] font-semibold">{memberTier.toUpperCase()} MEMBER</span>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Identity / Logo */}
        <button 
          onClick={() => { setActiveView('hero'); setIsMobileMenuOpen(false); }}
          className="text-left group flex flex-col justify-center focus:outline-none"
        >
          <span className="text-xs font-mono tracking-[0.3em] text-[#b8860b] uppercase font-bold group-hover:text-[#d4af37] transition-colors">
            Est. 1887 • Boston, Mass.
          </span>
          <h1 className="text-lg sm:text-xl md:text-2xl font-serif font-bold tracking-tight text-[#f2f0e9] group-hover:text-[#ffffff] transition-colors">
            THE NEW ENGLAND CHOCOLATE CO.
          </h1>
        </button>

        {/* Desktop Primary Nav Links */}
        <nav className="hidden xl:flex items-center space-x-5 text-xs font-mono tracking-widest text-[#a3b1c6]">
          {mainNavItems.slice(0, 8).map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`hover:text-[#d4af37] transition-colors py-2 relative uppercase font-medium ${
                activeView === item.id ? 'text-[#d4af37] font-bold' : ''
              }`}
            >
              {item.label}
              {activeView === item.id && (
                <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#d4af37]" />
              )}
            </button>
          ))}
        </nav>

        {/* Action Controls */}
        <div className="flex items-center space-x-3 sm:space-x-4">
          {/* Audio Ambience Toggle */}
          <button
            onClick={() => setIsAudioMuted(!isAudioMuted)}
            className="p-2 text-[#8a92a3] hover:text-[#d4af37] transition-colors rounded border border-[#2a2e38] hover:border-[#d4af37]/50"
            title={isAudioMuted ? "Enable Industrial Ambient Atmosphere" : "Mute Sound"}
          >
            {isAudioMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-[#d4af37]" />}
          </button>

          {/* Search Button */}
          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className="p-2 text-[#8a92a3] hover:text-[#d4af37] transition-colors rounded border border-[#2a2e38] hover:border-[#d4af37]/50"
            title="Search Chocolate & Technical Archives"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Cart Trigger */}
          <button
            onClick={() => setIsCartOpen(true)}
            className="relative px-3.5 py-2 bg-[#1a1d24] hover:bg-[#252933] border border-[#383e4d] hover:border-[#d4af37] text-xs font-mono tracking-wider text-[#f2f0e9] flex items-center space-x-2 rounded transition-all shadow-sm"
          >
            <ShoppingBag className="w-4 h-4 text-[#d4af37]" />
            <span className="hidden sm:inline">COLLECTION</span>
            {cartCount > 0 && (
              <span className="bg-[#d4af37] text-[#0c0d10] font-bold rounded-full w-5 h-5 flex items-center justify-center text-[10px] ml-1">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Trigger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="xl:hidden p-2 text-[#a3b1c6] hover:text-[#ffffff]"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Expanded Quick Nav Ribbon for Secondary Views */}
      <div className="hidden lg:flex items-center justify-center space-x-8 px-6 py-2 bg-[#101217] text-[11px] font-mono tracking-widest text-[#8a92a3] border-t border-[#1f222b]">
        <button 
          onClick={() => setActiveView('map')}
          className={`hover:text-[#d4af37] transition-colors flex items-center gap-1.5 ${activeView === 'map' ? 'text-[#d4af37]' : ''}`}
        >
          <Compass className="w-3.5 h-3.5" /> NEW ENGLAND MAP
        </button>
        <button 
          onClick={() => setActiveView('atlantic')}
          className={`hover:text-[#d4af37] transition-colors flex items-center gap-1.5 ${activeView === 'atlantic' ? 'text-[#d4af37]' : ''}`}
        >
          <Compass className="w-3.5 h-3.5" /> ATLANTIC COMMERCE
        </button>
        <button 
          onClick={() => setActiveView('science')}
          className={`hover:text-[#d4af37] transition-colors flex items-center gap-1.5 ${activeView === 'science' ? 'text-[#d4af37]' : ''}`}
        >
          <Sliders className="w-3.5 h-3.5" /> SCIENCE & TEMPERING
        </button>
        <button 
          onClick={() => setActiveView('tasting')}
          className={`hover:text-[#d4af37] transition-colors flex items-center gap-1.5 ${activeView === 'tasting' ? 'text-[#d4af37]' : ''}`}
        >
          <Sliders className="w-3.5 h-3.5" /> 9-AXIS TASTING SYSTEM
        </button>
        <button 
          onClick={() => setActiveView('quarterly')}
          className={`hover:text-[#d4af37] transition-colors flex items-center gap-1.5 ${activeView === 'quarterly' ? 'text-[#d4af37]' : ''}`}
        >
          <ShieldCheck className="w-3.5 h-3.5" /> CHOCOLATE QUARTERLY
        </button>
      </div>

      {/* Search Bar Overlay */}
      {isSearchOpen && (
        <div className="bg-[#14171f] border-t border-[#2a2e38] p-4 px-6">
          <div className="max-w-3xl mx-auto flex items-center space-x-3">
            <Search className="w-5 h-5 text-[#d4af37]" />
            <input
              type="text"
              placeholder="Search by cocoa percentage, origin (Ecuador, Ghana...), flavor note (espresso, cherry), or batch..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  setActiveView('chocolate');
                  setIsSearchOpen(false);
                }
              }}
              className="w-full bg-transparent border-none text-sm font-mono text-[#f2f0e9] focus:outline-none placeholder-[#5b6375]"
              autoFocus
            />
            <button 
              onClick={() => { setActiveView('chocolate'); setIsSearchOpen(false); }}
              className="px-4 py-1.5 bg-[#d4af37] text-[#0c0d10] font-mono text-xs font-bold rounded"
            >
              SEARCH
            </button>
          </div>
        </div>
      )}

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="xl:hidden bg-[#0c0d10] border-t border-[#2a2e38] p-6 space-y-4 font-mono text-sm">
          <div className="grid grid-cols-2 gap-3 text-xs tracking-wider">
            {mainNavItems.map((item) => (
              <button
                key={item.id}
                onClick={() => { setActiveView(item.id); setIsMobileMenuOpen(false); }}
                className={`text-left p-3 rounded border border-[#2a2e38] ${
                  activeView === item.id ? 'bg-[#d4af37]/10 border-[#d4af37] text-[#d4af37]' : 'text-[#a3b1c6]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
          <div className="pt-4 border-t border-[#1f222b] flex items-center justify-between text-xs text-[#8a92a3]">
            <button
              onClick={() => { setIsCmsOpen(true); setIsMobileMenuOpen(false); }}
              className="text-[#d4af37] underline"
            >
              OPEN CMS CONSOLE
            </button>
            <span>BOSTON HQ: OPERATIONAL</span>
          </div>
        </div>
      )}
    </header>
  );
};
