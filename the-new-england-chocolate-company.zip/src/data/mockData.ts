import { Product, CocoaOrigin, FactoryLine, JournalArticle, NewEnglandLocation, GiftBoxOption } from '../types';

const heroBoxImage = '/images/hero_chocolate_box_1786700763879.jpg';
const factoryImage = '/images/factory_machinery_1786700778482.jpg';
const darkBarImage = '/images/chocolate_bar_dark_1786700793005.jpg';
const bostonHqImage = '/images/boston_headquarters_1786700804279.jpg';

export { heroBoxImage, factoryImage, darkBarImage, bostonHqImage };

export const PRODUCTS: Product[] = [
  {
    id: 'prod-01',
    code: 'HOUSE 74',
    name: 'House Signature 74% Dark',
    tagline: 'The foundational benchmark of New England precision chocolate manufacturing.',
    cacaoPercentage: 74,
    category: 'DARK',
    origin: 'Ecuador',
    blendDetails: 'Single-estate Ecuador Arriba Nacional with Ghanaian Forestero roasted blend',
    batchNumber: 'BATCH 048-A',
    vintageYear: 2026,
    flavourNotes: ['Black Cherry', 'Walnut', 'Espresso', 'Brown Spice'],
    finishDescription: 'Dry, long, structured with a clean cocoa butter persistence.',
    weightGrams: 85,
    priceUSD: 24,
    flavorProfile: {
      aroma: 9,
      acidity: 5,
      bitterness: 7,
      sweetness: 4,
      body: 8,
      texture: 9,
      cacaoIntensity: 8,
      oakRoast: 7,
      finishLength: 9
    },
    technicalSpecs: {
      particleMicrons: 18.2,
      concheTimeHours: 72,
      temperIndex: 5.9,
      cocoaButterPercentage: 38.2,
      roastTempCelsius: 126
    },
    description: 'Engineered at our Boston waterfront facility, House 74 expresses the core ethos of our manufacturer. Roasted with precise thermal gradient control to preserve delicate volatile terpenes while caramelizing deep cacao solids.',
    packagingDetails: 'Pressed black cotton paper, gold leaf foil stamping, individually numbered brass serial tag.',
    image: darkBarImage,
    inStock: true,
    featured: true
  },
  {
    id: 'prod-02',
    code: 'REVOLUTION 85',
    name: 'Revolution 85% Cacao Reserve',
    tagline: 'High-density cacao intensity balanced by extended micro-conching.',
    cacaoPercentage: 85,
    category: 'GRAND CRU',
    origin: 'Ghana',
    blendDetails: '100% Single Origin Ashanti Region heritage trees',
    batchNumber: 'BATCH 019-B',
    vintageYear: 2025,
    flavourNotes: ['Black Truffle', 'Smoked Cedar', 'Molasses', 'Cacao Nibs'],
    finishDescription: 'Monumental, resinous finish with hints of pipe tobacco and dark oak.',
    weightGrams: 85,
    priceUSD: 32,
    flavorProfile: {
      aroma: 10,
      acidity: 3,
      bitterness: 9,
      sweetness: 2,
      body: 10,
      texture: 9,
      cacaoIntensity: 10,
      oakRoast: 9,
      finishLength: 10
    },
    technicalSpecs: {
      particleMicrons: 16.8,
      concheTimeHours: 96,
      temperIndex: 6.2,
      cocoaButterPercentage: 42.0,
      roastTempCelsius: 132
    },
    description: 'A tribute to American industrial boldness. Revolution 85 undergoes 96 hours of dry conching to eliminate harsh volatility, leaving an opulent, velvety dark structure.',
    packagingDetails: 'Brushed aluminum foil lining inside charcoal rigid cardboard with wax seal.',
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?q=80&w=800&auto=format&fit=crop',
    inStock: true,
    featured: true
  },
  {
    id: 'prod-03',
    code: 'PORTLAND SEA SALT',
    name: 'Maine Coast Atlantic Sea Salt 68%',
    tagline: 'Pure Maine coast solar-evaporated sea salt crystals over dark cacao.',
    cacaoPercentage: 68,
    category: 'AMERICAN EDITIONS',
    origin: 'Dominican Republic',
    blendDetails: 'Hispananiola Trinitario cacao paired with Portland, ME hand-harvested sea salt',
    batchNumber: 'BATCH 062-C',
    vintageYear: 2026,
    flavourNotes: ['Brine', 'Toasted Hazelnut', 'Caramelized Fig', 'Vanilla Bean'],
    finishDescription: 'Rhythmic interplay of mineral salt bursts and smooth cocoa sweetness.',
    weightGrams: 85,
    priceUSD: 26,
    flavorProfile: {
      aroma: 8,
      acidity: 6,
      bitterness: 5,
      sweetness: 5,
      body: 7,
      texture: 10,
      cacaoIntensity: 7,
      oakRoast: 5,
      finishLength: 8
    },
    technicalSpecs: {
      particleMicrons: 19.0,
      concheTimeHours: 64,
      temperIndex: 5.7,
      cocoaButterPercentage: 36.8,
      roastTempCelsius: 122
    },
    description: 'Sourced directly from the rocky shores of Portland, Maine. Large mineral salt flakes are layered on top of hot tempered dark chocolate, delivering crisp texture and salinity.',
    packagingDetails: 'Deep ocean navy textured box with embossed sea chart grid lines.',
    image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?q=80&w=800&auto=format&fit=crop',
    inStock: true,
    featured: true
  },
  {
    id: 'prod-04',
    code: 'NEWPORT MILK 48',
    name: 'Newport Guild Dark Milk 48%',
    tagline: 'High-cacao milk chocolate crafted with New England Jersey cream.',
    cacaoPercentage: 48,
    category: 'MILK',
    origin: 'Peru',
    blendDetails: 'San Martin Peruvian Criollo cacao with Vermont grass-fed Jersey milk solids',
    batchNumber: 'BATCH 033-D',
    vintageYear: 2026,
    flavourNotes: ['Browned Butter', 'Malted Barley', 'Honeycomb', 'Ripe Plum'],
    finishDescription: 'Rich, creamy, luxurious melt with a lingering malty fruit finish.',
    weightGrams: 85,
    priceUSD: 22,
    flavorProfile: {
      aroma: 7,
      acidity: 4,
      bitterness: 3,
      sweetness: 7,
      body: 9,
      texture: 10,
      cacaoIntensity: 5,
      oakRoast: 4,
      finishLength: 7
    },
    technicalSpecs: {
      particleMicrons: 15.5,
      concheTimeHours: 60,
      temperIndex: 5.4,
      cocoaButterPercentage: 34.5,
      roastTempCelsius: 118
    },
    description: 'Rethinking traditional milk chocolate. Sourced from high-altitude Peruvian valleys and combined with condensed Jersey cream from Vermont family farms.',
    packagingDetails: 'Ivory linen paper with copper foil geometric monogram.',
    image: 'https://images.unsplash.com/photo-1548907040-4ba422245913?q=80&w=800&auto=format&fit=crop',
    inStock: true
  },
  {
    id: 'prod-05',
    code: 'MADAGASCAR 72',
    name: 'Sambirano Valley Single Origin 72%',
    tagline: 'Bright red berry acidity and citrus brightness from Madagascar.',
    cacaoPercentage: 72,
    category: 'SINGLE ORIGIN',
    origin: 'Madagascar',
    blendDetails: '100% Organic Sambirano Estate Heirloom Criollo',
    batchNumber: 'BATCH 011-E',
    vintageYear: 2026,
    flavourNotes: ['Raspberry', 'Blood Orange', 'Cedar', 'Pink Peppercorn'],
    finishDescription: 'Vibrant, refreshing acidity giving way to a warm woody finish.',
    weightGrams: 85,
    priceUSD: 28,
    flavorProfile: {
      aroma: 9,
      acidity: 9,
      bitterness: 5,
      sweetness: 5,
      body: 6,
      texture: 8,
      cacaoIntensity: 7,
      oakRoast: 4,
      finishLength: 8
    },
    technicalSpecs: {
      particleMicrons: 17.8,
      concheTimeHours: 54,
      temperIndex: 5.8,
      cocoaButterPercentage: 37.0,
      roastTempCelsius: 120
    },
    description: 'Grown in the alluvial volcanic soil of northern Madagascar. Naturally high in fruit acids, this bar undergoes gentle low-temperature roasting to preserve its extraordinary citrus and berry notes.',
    packagingDetails: 'Crimson red card stock with laser-etched topographical map of the Sambirano river valley.',
    image: 'https://images.unsplash.com/photo-1606312619070-d48b4c652a52?q=80&w=800&auto=format&fit=crop',
    inStock: true
  },
  {
    id: 'prod-06',
    code: 'MAPLE BOURBON 70',
    name: 'Vermont Maple & Oak Bourbon Cacao 70%',
    tagline: 'Aged in charred American oak bourbon barrels with Vermont grade-A maple syrup.',
    cacaoPercentage: 70,
    category: 'SEASONAL',
    origin: 'Venezuela',
    blendDetails: 'Ocumare Venezuelan beans aged 60 days in Hudson Valley bourbon casks',
    batchNumber: 'BATCH 007-S',
    vintageYear: 2026,
    flavourNotes: ['Vanilla Oak', 'Maple Sugar', 'Charred Cacao', 'Dried Apricot'],
    finishDescription: 'Warming bourbon warmth coupled with deep maple wood sweetness.',
    weightGrams: 85,
    priceUSD: 30,
    flavorProfile: {
      aroma: 10,
      acidity: 4,
      bitterness: 6,
      sweetness: 6,
      body: 9,
      texture: 9,
      cacaoIntensity: 7,
      oakRoast: 10,
      finishLength: 9
    },
    technicalSpecs: {
      particleMicrons: 18.0,
      concheTimeHours: 68,
      temperIndex: 5.9,
      cocoaButterPercentage: 38.0,
      roastTempCelsius: 125
    },
    description: 'Unfermented unroasted green cocoa nibs rest inside newly emptied charred bourbon barrels for two months before roasting, absorbing complex oak vanillin and amber notes.',
    packagingDetails: 'Rich oak-grain patterned box with hand-stamped copper wax emblem.',
    image: 'https://images.unsplash.com/photo-1582293041079-7814c2f12063?q=80&w=800&auto=format&fit=crop',
    inStock: true
  },
  {
    id: 'prod-07',
    code: 'PRIVATE RESERVE 81',
    name: 'Private Allocation Batch 014 - Ecuador 81%',
    tagline: 'Invitation-only micro-batch harvested from 120-year-old wild heirloom cacao trees.',
    cacaoPercentage: 81,
    category: 'LIMITED RELEASES',
    origin: 'Ecuador',
    blendDetails: '100% Wild Amazonian Piedra de Plata Criollo',
    batchNumber: 'BATCH 014 / 300 BARS',
    vintageYear: 2026,
    flavourNotes: ['Black Jasmine', 'Damp Forest Floor', 'Cocoa Nectar', 'Cured Leather'],
    finishDescription: 'Transcendent length exceeding 15 minutes on the palate.',
    weightGrams: 90,
    priceUSD: 65,
    flavorProfile: {
      aroma: 10,
      acidity: 4,
      bitterness: 8,
      sweetness: 2,
      body: 10,
      texture: 10,
      cacaoIntensity: 10,
      oakRoast: 8,
      finishLength: 10
    },
    technicalSpecs: {
      particleMicrons: 14.2,
      concheTimeHours: 120,
      temperIndex: 6.5,
      cocoaButterPercentage: 44.5,
      roastTempCelsius: 115
    },
    description: 'Only 300 bars produced annually. Harvested by hand in remote Ecuadorian canopy forests, transported via wooden canoe to our Atlantic shipping depot, and crafted under Master Roaster supervision.',
    packagingDetails: 'Hand-carved New England white oak presentation box with brass latch and certificate signed by Master Chocolatier.',
    image: heroBoxImage,
    inStock: true,
    privateReserveOnly: true,
    allocationRemaining: 18,
    featured: true
  },
  {
    id: 'prod-08',
    code: 'ATLANTIC CHEST',
    name: 'The Merchant House Presidential Collection',
    tagline: '12 curated bars in a heavy brass-bound mahogany executive vault.',
    cacaoPercentage: 74,
    category: 'GIFT COLLECTIONS',
    origin: 'Ecuador',
    blendDetails: 'Full spectrum representation of House 74, Revolution 85, Portland Sea Salt & Single Origins',
    batchNumber: 'VAULT EDITION 2026',
    vintageYear: 2026,
    flavourNotes: ['Full Spectrum Tasting Journey'],
    finishDescription: 'Comprehensive industrial tasting experience.',
    weightGrams: 1020,
    priceUSD: 245,
    flavorProfile: {
      aroma: 10,
      acidity: 7,
      bitterness: 7,
      sweetness: 5,
      body: 9,
      texture: 9,
      cacaoIntensity: 8,
      oakRoast: 8,
      finishLength: 10
    },
    technicalSpecs: {
      particleMicrons: 17.5,
      concheTimeHours: 72,
      temperIndex: 6.0,
      cocoaButterPercentage: 38.0,
      roastTempCelsius: 125
    },
    description: 'Designed for corporate executives, institutional gifting, and serious collectors. Includes a custom tasting guidebook, brass tasting calipers, and a personalized engraved brass plate.',
    packagingDetails: 'Solid New England mahogany chest with brushed brass hinges and lock.',
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?q=80&w=800&auto=format&fit=crop',
    inStock: true,
    featured: true
  }
];

export const COCOA_ORIGINS: CocoaOrigin[] = [
  {
    id: 'origin-ecuador',
    name: 'Ecuador',
    countryCode: 'EC',
    coordinates: { lat: -1.8312, lng: -78.1834 },
    elevationMeters: '300 - 1,200m',
    terroirDescription: 'Volcanic Andean soil enriched by Amazonian basin humidity and coastal morning mists.',
    harvestMonths: 'May - December',
    fermentationMethod: '5-Day Wooden Box Fermentation with Banana Leaf Covering',
    keyFlavourNotes: ['Black Cherry', 'Jasmine', 'Cured Tobacco', 'Walnut'],
    annualImportTons: 1420,
    activeBatches: 12
  },
  {
    id: 'origin-ghana',
    name: 'Ghana',
    countryCode: 'GH',
    coordinates: { lat: 7.9465, lng: -1.0232 },
    elevationMeters: '150 - 450m',
    terroirDescription: 'Ashanti rainforest belt with deep laterite clay and rich tropical shade canopy.',
    harvestMonths: 'October - February',
    fermentationMethod: '6-Day Earth Heap Fermentation under Plantain Leaves',
    keyFlavourNotes: ['Fudge Cacao', 'Smoked Oak', 'Molasses', 'Leather'],
    annualImportTons: 2850,
    activeBatches: 24
  },
  {
    id: 'origin-madagascar',
    name: 'Madagascar',
    countryCode: 'MG',
    coordinates: { lat: -18.7669, lng: 46.8691 },
    elevationMeters: '50 - 300m',
    terroirDescription: 'Sambirano river valley with tropical monsoon soil and high mineral density.',
    harvestMonths: 'May - November',
    fermentationMethod: '4-Day Tiered Cascade Boxes',
    keyFlavourNotes: ['Red Raspberry', 'Citrus Peel', 'Pink Pepper', 'Cedar'],
    annualImportTons: 640,
    activeBatches: 8
  },
  {
    id: 'origin-peru',
    name: 'Peru',
    countryCode: 'PE',
    coordinates: { lat: -9.19, lng: -75.0152 },
    elevationMeters: '400 - 1,400m',
    terroirDescription: 'High-altitude Amazonian headwaters in San Martin with pure mountain glacial melt.',
    harvestMonths: 'April - August',
    fermentationMethod: '6-Day Cedar Box Fermentation',
    keyFlavourNotes: ['Floral Honey', 'Malted Barley', 'Dried Fig', 'Cream'],
    annualImportTons: 910,
    activeBatches: 10
  },
  {
    id: 'origin-domrep',
    name: 'Dominican Republic',
    countryCode: 'DO',
    coordinates: { lat: 18.7357, lng: -70.1627 },
    elevationMeters: '200 - 800m',
    terroirDescription: 'Cibao Valley marine sea breeze soil with organic shade agriculture.',
    harvestMonths: 'March - July',
    fermentationMethod: '5-Day Aerated Box System',
    keyFlavourNotes: ['Toasted Almond', 'Earthy Cocoa', 'Subtle Citrus', 'Spiced Oak'],
    annualImportTons: 1100,
    activeBatches: 14
  }
];

export const FACTORY_LINES: FactoryLine[] = [
  {
    id: 'line-01',
    code: 'LINE 01 - BEAN ROASTING & WINNOWING',
    name: 'Thermal Roasting Engine & Winnowing Cyclone',
    status: 'OPERATIONAL',
    throughputBarsPerDay: 32400,
    efficiencyPercent: 98.4,
    energyKwhPerKg: 1.42,
    qualityYieldPercent: 99.8,
    currentBatch: 'BATCH 048-A (HOUSE 74)',
    currentTemperatureC: 126.4,
    conchePressureBar: 1.05,
    temperCrystallizationIndex: 5.9,
    humidityPercent: 42.1
  },
  {
    id: 'line-02',
    code: 'LINE 02 - MICRO-GRINDING & REFINING',
    name: '5-Roll Steel Mill & Ultrasonic Particle Classifier',
    status: 'OPERATIONAL',
    throughputBarsPerDay: 28900,
    efficiencyPercent: 96.2,
    energyKwhPerKg: 1.68,
    qualityYieldPercent: 99.4,
    currentBatch: 'BATCH 019-B (REVOLUTION 85)',
    currentTemperatureC: 48.2,
    conchePressureBar: 2.10,
    temperCrystallizationIndex: 6.1,
    humidityPercent: 38.5
  },
  {
    id: 'line-03',
    code: 'LINE 03 - ROTARY LONG-CONCHE',
    name: '72-Hour Rotary Double-Conche Vessel',
    status: 'OPTIMIZING',
    throughputBarsPerDay: 21500,
    efficiencyPercent: 94.8,
    energyKwhPerKg: 2.05,
    qualityYieldPercent: 99.9,
    currentBatch: 'BATCH 014-X (PRIVATE RESERVE)',
    currentTemperatureC: 62.1,
    conchePressureBar: 3.45,
    temperCrystallizationIndex: 6.5,
    humidityPercent: 35.0
  },
  {
    id: 'line-04',
    code: 'LINE 04 - PRECISION TEMPERING & MOULDING',
    name: 'Polymorphic Crystal Tempering Column & Robotic Pack',
    status: 'OPERATIONAL',
    throughputBarsPerDay: 38000,
    efficiencyPercent: 97.9,
    energyKwhPerKg: 1.15,
    qualityYieldPercent: 99.7,
    currentBatch: 'BATCH 062-C (PORTLAND SALT)',
    currentTemperatureC: 31.2,
    conchePressureBar: 1.20,
    temperCrystallizationIndex: 5.8,
    humidityPercent: 40.0
  }
];

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'art-01',
    title: 'The Industrial Geometry of 18-Micron Particle Refining',
    subtitle: 'Why human lingual papillae perceive smoothness at sub-20 micron thresholds and how American steel mills enabled it.',
    category: 'THE FACTORY',
    author: 'Dr. Thaddeus Vance',
    authorTitle: 'Chief Director of Food Physics, Boston Innovation Laboratory',
    date: 'August 2, 2026',
    readTime: '8 MIN READ',
    excerpt: 'The transition from gritty 19th-century cocoa paste to modern silken chocolate is fundamentally a mechanical engineering achievement governed by friction, shear stress, and particle geometry.',
    content: [
      'In traditional confectionery literature, smoothness is often described through vague sensory adjectives. At the New England Chocolate Company, we analyze texture as a quantifiable physical dimension governed by rheology and particle size distribution.',
      'Human lingual tactile receptors can discriminate discrete solid particles down to approximately 20 microns (0.02 millimeters). Anything larger produces a subtle gritty friction on the palate. By utilizing precision hardened steel five-roll mills operating with micrometer gap tolerances, our Boston facility reduces cocoa solids and crystalline sugar to a mean particle size of 18.2 microns.',
      'This mechanical particle reduction increases surface area exponentially, exposing more cocoa butter matrix to light and heat, resulting in instantaneous thermal breakdown upon entering the mouth at 36.5°C.'
    ],
    image: factoryImage,
    tags: ['PHYSICS', 'REFINING', 'BOSTON FACTORY', 'RHEOLOGY']
  },
  {
    id: 'art-02',
    title: 'Atlantic Shipping Routes & The Boston Merchant Tradition',
    subtitle: 'How 19th-century maritime commerce created America’s premier cocoa import gateway.',
    category: 'THE ATLANTIC',
    author: 'Eleanor Bradford',
    authorTitle: 'Senior Curator of Maritime Commerce & Industrial History',
    date: 'July 18, 2026',
    readTime: '12 MIN READ',
    excerpt: 'Before Boston became a center of technological innovation, its harbor was the beating heart of transatlantic trade. Raw cocoa arrived on wooden clipper ships alongside sugar, mahogany, and spices.',
    content: [
      'The history of American chocolate is inseparable from the deepwater ports of New England. In the late 1880s, Boston merchant vessels sailed directly from the Caribbean and West Africa, docking at India Wharf to unload raw fermented cacao beans into granite storehouses.',
      'Unlike European chocolate makers who relied on overland alpine trade, New England manufacturers established immediate access to raw transatlantic commodity shipments. This direct maritime pipeline allowed our founders to select the finest harvests before they reached secondary markets.',
      'Today, that merchant tradition lives on through our automated Atlantic tracking system, which monitors climate-controlled cargo vessels carrying raw cacao across the ocean directly to our Boston facility.'
    ],
    image: bostonHqImage,
    tags: ['ATLANTIC TRADE', 'BOSTON HARBOR', 'MARITIME', 'HISTORY']
  },
  {
    id: 'art-03',
    title: 'Polymorphic Crystallization: Controlling the Form V Beta Crystal',
    subtitle: 'A thermodynamic breakdown of chocolate tempering and snap mechanics.',
    category: 'THE COCOA',
    author: 'Prof. Harrison Sterling',
    authorTitle: 'Senior Fellow in Crystallography & Material Science',
    date: 'June 29, 2026',
    readTime: '10 MIN READ',
    excerpt: 'Cocoa butter is one of the most complex fats in nature, capable of crystallizing into six distinct polymorphs. Only Form V provides the signature gloss, clean snap, and thermal stability of luxury chocolate.',
    content: [
      'When molten chocolate cools uncontrolled, cocoa butter molecules align in unstable Form I through IV crystal matrices. The result is soft, dull chocolate that blooms easily under ambient temperature fluctuations.',
      'To achieve the prized Form V (Beta-2) crystal, our tempering columns subject the liquid cocoa butter to a precise thermal cycle: cooling to 27°C to initiate crystallization, then re-heating to 31.5°C to melt away inferior Form I-IV crystals while preserving stable Form V nuclei.',
      'This exact thermal cadence ensures that every bar manufactured in our New England facility produces a crisp acoustic snap exceeding 78 decibels when fractured.'
    ],
    image: darkBarImage,
    tags: ['CRYSTALLOGRAPHY', 'TEMPERING', 'CHEMISTRY', 'PRECISION']
  }
];

export const NEW_ENGLAND_LOCATIONS: NewEnglandLocation[] = [
  {
    id: 'loc-01',
    name: 'Boston Central Waterfront Headquarters',
    city: 'Boston',
    state: 'MA',
    type: 'HEADQUARTERS',
    coordinates: { lat: 42.3601, lng: -71.0589 },
    description: '1887 granite merchant house overlooking Boston Harbor, now housing executive offices, central innovation laboratories, and private tasting salons.',
    yearEstablished: 1887,
    status: 'ACTIVE - HEADQUARTERS'
  },
  {
    id: 'loc-02',
    name: 'Providence Precision Mill & Conching Line',
    city: 'Providence',
    state: 'RI',
    type: 'MILL_FACTORY',
    coordinates: { lat: 41.8240, lng: -71.4128 },
    description: 'Converted historic textile mill on the Seekonk River housing our high-volume rotary conching vessels and automated packaging lines.',
    yearEstablished: 1912,
    status: 'OPERATIONAL - 24/7'
  },
  {
    id: 'loc-03',
    name: 'Portland Maritime Vault & Cold Storage',
    city: 'Portland',
    state: 'ME',
    type: 'PORT_TERMINAL',
    coordinates: { lat: 43.6591, lng: -70.2568 },
    description: 'Deepwater port terminal and temperature-monitored granite vault for receiving raw cocoa shipments from West Africa and South America.',
    yearEstablished: 1934,
    status: 'ACTIVE - RECEIVING'
  },
  {
    id: 'loc-04',
    name: 'New Haven Rheology & Flavor Research Center',
    city: 'New Haven',
    state: 'CT',
    type: 'RESEARCH_LAB',
    coordinates: { lat: 41.3083, lng: -72.9279 },
    description: 'Yale-adjacent advanced food science research unit focused on cocoa polyphenol extraction, fermentation biochemistry, and sensor development.',
    yearEstablished: 1978,
    status: 'ACTIVE - RESEARCH'
  },
  {
    id: 'loc-05',
    name: 'Newport Mansion Flagship Salon',
    city: 'Newport',
    state: 'RI',
    type: 'FLAGSHIP_BOUTIQUE',
    coordinates: { lat: 41.4901, lng: -71.3128 },
    description: 'Gilded Age mansion converted into a private chocolate tasting room and Atlantic Circle member club.',
    yearEstablished: 1998,
    status: 'OPEN FOR MEMBERS & APPOINTMENTS'
  }
];

export const GIFT_BOX_OPTIONS: GiftBoxOption[] = [
  {
    id: 'box-mahogany',
    name: 'The Merchant Mahogany Vault',
    description: 'Solid New England mahogany wood box with hand-carved joinery, brass hinges, and deep green felt lining.',
    material: 'New England Mahogany & Brushed Brass',
    priceAddonUSD: 45,
    image: 'https://images.unsplash.com/photo-1549007994-cb92caebd54b?q=80&w=800&auto=format&fit=crop'
  },
  {
    id: 'box-brass',
    name: 'The Industrial Steel & Inlaid Brass Chest',
    description: 'Precision-machined blackened steel casing with inlaid copper trim and laser-engraved serial plate.',
    material: 'Blackened Steel, Copper & Obsidian Velvet',
    priceAddonUSD: 60,
    image: heroBoxImage
  },
  {
    id: 'box-presidential',
    name: 'The Oxford Ivory & Gold Foil Box',
    description: 'Heavyweight rigid cotton paperboard wrapped in oxford navy cloth with 24k gold leaf foil hot stamping.',
    material: 'Oxford Cloth Paper & Gold Leaf',
    priceAddonUSD: 25,
    image: 'https://images.unsplash.com/photo-1511381939415-e44015466834?q=80&w=800&auto=format&fit=crop'
  }
];
