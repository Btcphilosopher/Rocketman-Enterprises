export type ProductCategory = 
  | 'ALL'
  | 'DARK'
  | 'MILK'
  | 'SINGLE ORIGIN'
  | 'GRAND CRU'
  | 'AMERICAN EDITIONS'
  | 'LIMITED RELEASES'
  | 'SEASONAL'
  | 'GIFT COLLECTIONS';

export type CocoaRegion = 
  | 'Ecuador'
  | 'Ghana'
  | "Côte d'Ivoire"
  | 'Dominican Republic'
  | 'Peru'
  | 'Madagascar'
  | 'Venezuela'
  | 'Tanzania'
  | 'Mexico';

export interface FlavorProfile {
  aroma: number;        // 1 - 10
  acidity: number;      // 1 - 10
  bitterness: number;   // 1 - 10
  sweetness: number;    // 1 - 10
  body: number;         // 1 - 10
  texture: number;      // 1 - 10
  cacaoIntensity: number; // 1 - 10
  oakRoast: number;     // 1 - 10
  finishLength: number; // 1 - 10
}

export interface ProductTechnicalSpecs {
  particleMicrons: number;     // e.g. 18.5
  concheTimeHours: number;     // e.g. 72
  temperIndex: number;          // e.g. 5.8
  cocoaButterPercentage: number; // e.g. 38.5
  roastTempCelsius: number;     // e.g. 128
}

export interface Product {
  id: string;
  code: string;                 // e.g. 'HOUSE 74'
  name: string;
  tagline: string;
  cacaoPercentage: number;
  category: ProductCategory;
  origin: CocoaRegion;
  blendDetails: string;
  batchNumber: string;
  vintageYear: number;
  flavourNotes: string[];
  finishDescription: string;
  weightGrams: number;
  priceUSD: number;
  flavorProfile: FlavorProfile;
  technicalSpecs: ProductTechnicalSpecs;
  description: string;
  packagingDetails: string;
  image: string;
  inStock: boolean;
  privateReserveOnly?: boolean;
  allocationRemaining?: number;
  featured?: boolean;
}

export interface CocoaOrigin {
  id: string;
  name: CocoaRegion;
  countryCode: string;
  coordinates: { lat: number; lng: number };
  elevationMeters: string;
  terroirDescription: string;
  harvestMonths: string;
  fermentationMethod: string;
  keyFlavourNotes: string[];
  annualImportTons: number;
  activeBatches: number;
}

export interface FactoryLine {
  id: string;
  code: string;               // e.g., 'LINE 01 - CONCHING & REFINING'
  name: string;
  status: 'OPERATIONAL' | 'CALIBRATING' | 'MAINTENANCE' | 'OPTIMIZING';
  throughputBarsPerDay: number;
  efficiencyPercent: number;
  energyKwhPerKg: number;
  qualityYieldPercent: number;
  currentBatch: string;
  currentTemperatureC: number;
  conchePressureBar: number;
  temperCrystallizationIndex: number;
  humidityPercent: number;
}

export interface JournalArticle {
  id: string;
  title: string;
  subtitle: string;
  category: 'THE COCOA' | 'THE FACTORY' | 'THE ATLANTIC' | 'THE TABLE' | 'THE CITY' | 'THE FUTURE' | 'THE HOUSE';
  author: string;
  authorTitle: string;
  date: string;
  readTime: string;
  excerpt: string;
  content: string[];
  image: string;
  tags: string[];
}

export interface CellarItem {
  id: string;
  productId: string;
  product: Product;
  purchaseDate: string;
  batchNumber: string;
  vintageYear: number;
  quantity: number;
  userRating?: number;
  userNotes?: string;
  storageVault: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  customEngraving?: string;
  giftBoxStyle?: string;
}

export interface NewEnglandLocation {
  id: string;
  name: string;
  city: string;
  state: string;
  type: 'HEADQUARTERS' | 'MILL_FACTORY' | 'PORT_TERMINAL' | 'RESEARCH_LAB' | 'FLAGSHIP_BOUTIQUE' | 'RAIL_DEPOT';
  coordinates: { lat: number; lng: number };
  description: string;
  yearEstablished: number;
  status: string;
}

export interface GiftBoxOption {
  id: string;
  name: string;
  description: string;
  material: string;
  priceAddonUSD: number;
  image: string;
}

export interface AtlanticCircleTier {
  tierName: 'MEMBER' | 'MERCHANT' | 'FELLOW' | 'ATLANTIC PATRON';
  annualAllocationUSD: number;
  perks: string[];
  accessLevel: string;
}

export interface OrderDetails {
  id: string;
  createdAt: string;
  customerName: string;
  email: string;
  shippingAddress: string;
  shippingTier: 'STANDARD_ATLANTIC' | 'EXPRESS_RAIL' | 'TEMP_CONTROLLED_VAULT';
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  total: number;
  status: 'PENDING' | 'VAULT_DISPATCHED' | 'IN_TRANSIT' | 'DELIVERED';
  provenanceCertificateId: string;
  trackingNumber: string;
}
