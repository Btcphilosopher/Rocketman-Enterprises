"use client";

import React, { useState } from "react";
import { Sliders, Sparkles, Award, CheckCircle, BarChart2, Layers } from "lucide-react";
import FlavourRadarChart from "./FlavourRadarChart";

interface MasterBlenderProps {
  onOptimiseBlend: (target: Record<string, number>) => Promise<any>;
}

export default function MasterBlenderView({ onOptimiseBlend }: MasterBlenderProps) {
  const [targetVector, setTargetVector] = useState<Record<string, number>>({
    vanilla: 80,
    caramel: 75,
    oak: 65,
    fruit: 70,
    rye_spice: 60,
    body: 80,
    finish: 85
  });

  const [loading, setLoading] = useState(false);
  const [blendResult, setBlendResult] = useState<any>(null);

  const handleSliderChange = (key: string, val: number) => {
    setTargetVector((prev) => ({ ...prev, [key]: val }));
  };

  const handleRunOptimization = async () => {
    setLoading(true);
    try {
      const res = await onOptimiseBlend(targetVector);
      setBlendResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const currentBlendedVector = blendResult?.blended_flavour_vector ?? {
    sweetness: 68,
    vanilla: 78,
    caramel: 74,
    oak: 64,
    fruit: 68,
    rye_spice: 58,
    body: 78,
    finish: 84
  };

  return (
    <div className="space-y-6">
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-2">
        <h2 className="text-lg font-bold text-stone-100 flex items-center gap-2">
          <Award className="w-5 h-5 text-amber-500" /> Master Blender Decision Support Engine
        </h2>
        <p className="text-xs text-stone-400">
          Solves constrained optimization across mature barrel inventory to reproduce target brand flavour signatures with minimal distance metric variance.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Target Profile Sliders */}
        <div className="lg:col-span-5 bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-stone-800 pb-3">
            <h3 className="font-semibold text-stone-200 flex items-center gap-2 text-sm">
              <Sliders className="w-4 h-4 text-amber-500" /> Target Brand Profile Signature
            </h3>
            <button
              onClick={handleRunOptimization}
              disabled={loading}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              {loading ? "Optimizing..." : "Solve Blend Recipe"}
            </button>
          </div>

          <div className="space-y-3">
            {Object.keys(targetVector).map((key) => (
              <div key={key}>
                <div className="flex justify-between text-xs text-stone-300 mb-1">
                  <span className="capitalize">{key.replace("_", " ")}</span>
                  <span className="font-mono text-amber-400 font-bold">{targetVector[key]} / 100</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={targetVector[key]}
                  onChange={(e) => handleSliderChange(key, parseInt(e.target.value))}
                  className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg appearance-none cursor-pointer"
                />
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-stone-800 text-xs text-stone-400 space-y-1">
            <div className="font-medium text-stone-300">Constrained Optimisation Parameters:</div>
            <ul className="list-disc list-inside text-[11px] text-stone-500 space-y-0.5">
              <li>Max single barrel contribution: &le; 45% weight</li>
              <li>Batch volume requirement: 2,500 Litres @ 90 Proof</li>
              <li>Target Flavour Distance Metric: Weighted Euclidean</li>
            </ul>
          </div>
        </div>

        {/* Right Column: Blend Results & Proportions */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-stone-200 flex items-center gap-2 text-sm">
                <Sparkles className="w-4 h-4 text-amber-500" /> Target vs Blended Master Match
              </h3>
              <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-full font-medium">
                {blendResult ? `${blendResult.target_match_pct}% Flavour Match` : "96.4% Flavour Match"}
              </span>
            </div>

            <FlavourRadarChart
              currentVector={currentBlendedVector}
              targetVector={targetVector}
            />
          </div>

          {/* Recommended Barrel Mixture Table */}
          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-3">
            <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-500" /> Recommended Barrel Mixture
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-stone-300">
                <thead className="bg-stone-950 text-stone-400 uppercase text-[10px] tracking-wider border-b border-stone-800">
                  <tr>
                    <th className="p-2.5">Barrel ID</th>
                    <th className="p-2.5">Warehouse</th>
                    <th className="p-2.5">Floor</th>
                    <th className="p-2.5">Age</th>
                    <th className="p-2.5">Volume</th>
                    <th className="p-2.5 text-right">Blend Weight %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-800">
                  {(blendResult?.barrel_proportions ?? [
                    { barrel_id: "BRL-RIC-F4-0012", warehouse_id: "RICKHOUSE_A", floor: 4, age_months: 72, volume: 165, weight_pct: 38.5 },
                    { barrel_id: "BRL-RIC-F5-0045", warehouse_id: "RICKHOUSE_B", floor: 5, age_months: 84, volume: 152, weight_pct: 34.0 },
                    { barrel_id: "BRL-RIC-F3-0089", warehouse_id: "RICKHOUSE_A", floor: 3, age_months: 60, volume: 178, weight_pct: 27.5 },
                  ]).map((item: any, idx: number) => (
                    <tr key={idx} className="hover:bg-stone-800/40">
                      <td className="p-2.5 font-mono text-amber-400 font-medium">{item.barrel_id}</td>
                      <td className="p-2.5 text-stone-400">{item.warehouse_id}</td>
                      <td className="p-2.5 font-mono">Floor {item.floor}</td>
                      <td className="p-2.5 font-mono">{item.age_months}m</td>
                      <td className="p-2.5 font-mono">{item.volume ?? 160}L</td>
                      <td className="p-2.5 text-right font-bold text-emerald-400 font-mono">{item.weight_pct}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
