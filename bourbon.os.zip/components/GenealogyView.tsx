"use client";

import React, { useState } from "react";
import { GitCommit, Layers, Wheat, Flame, Wine, Clock, PackageCheck, ArrowRight } from "lucide-react";

interface GenealogyProps {
  genealogyData: any;
}

export default function GenealogyView({ genealogyData }: GenealogyProps) {
  const [selectedBottle, setSelectedBottle] = useState("BOTTLE-BATCH-2026-001");

  const gen = genealogyData ?? {
    bottle_id: selectedBottle,
    blend: {
      blend_id: "BLEND-HERITAGE-SELECT-01",
      barrels: [
        { barrel_id: "BRL-RIC-F4-0012", weight_pct: 40.0, age_months: 72.0 },
        { barrel_id: "BRL-RIC-F5-0045", weight_pct: 35.0, age_months: 84.0 },
        { barrel_id: "BRL-RIC-F3-0089", weight_pct: 25.0, age_months: 60.0 }
      ]
    },
    distillation_batch: "DST-BATCH-2020-03-A",
    fermentation_batch: "FRM-BATCH-2020-03-A",
    mash_batch: "MSH-BATCH-2020-03-A",
    grain_lots: [
      { grain_type: "CORN", lot_id: "LOT-COR-0102", supplier: "Midwest Grains", origin: "Kentucky, USA" },
      { grain_type: "RYE", lot_id: "LOT-RYE-0145", supplier: "AgriCrop Co", origin: "Ohio, USA" },
      { grain_type: "MALTED_BARLEY", lot_id: "LOT-MAL-0201", supplier: "Bluegrass Malting", origin: "Indiana, USA" }
    ]
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-2">
        <h2 className="text-lg font-bold text-stone-100 flex items-center gap-2">
          <GitCommit className="w-5 h-5 text-amber-500" /> Full Genealogy & Batch Traceability Graph
        </h2>
        <p className="text-xs text-stone-400">
          Trace any bottle back through its exact blend recipe, individual mature barrels, distillation run, fermentation wash, mashing batch, and agricultural grain lot origins.
        </p>
      </div>

      {/* Traceability Flow Tree */}
      <div className="space-y-4">
        {/* Node 1: Bottled Product */}
        <div className="bg-stone-900/80 border border-amber-500/40 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 rounded-lg text-amber-400 border border-amber-500/20">
              <PackageCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="text-xs uppercase text-amber-500 font-semibold tracking-wider">Final Bottle Product</div>
              <div className="text-base font-bold text-stone-100 font-mono">{gen.bottle_id}</div>
              <div className="text-xs text-stone-400">Bottled @ 90 Proof | 750ml | TTB COLA #26090001</div>
            </div>
          </div>
          <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full font-bold">
            100% Traceable
          </span>
        </div>

        <div className="flex justify-center"><ArrowRight className="w-5 h-5 text-stone-600 rotate-90" /></div>

        {/* Node 2: Blend & Component Barrels */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center gap-2 text-stone-200 text-sm font-semibold">
            <Layers className="w-4 h-4 text-amber-500" /> Master Blend: <span className="font-mono text-amber-400">{gen.blend?.blend_id}</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            {gen.blend?.barrels?.map((b: any, idx: number) => (
              <div key={idx} className="bg-stone-950 p-3 rounded-lg border border-stone-800 space-y-1">
                <div className="font-mono text-amber-400 font-bold">{b.barrel_id}</div>
                <div className="text-stone-300">Blend Contribution: <span className="font-bold text-emerald-400">{b.weight_pct}%</span></div>
                <div className="text-stone-500 text-[11px]">Maturation: {b.age_months} Months</div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-center"><ArrowRight className="w-5 h-5 text-stone-600 rotate-90" /></div>

        {/* Node 3: Distillation & Fermentation Batches */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-stone-200 font-semibold text-sm">
              <Flame className="w-4 h-4 text-amber-500" /> Distillation Run
            </div>
            <div className="font-mono text-amber-400 font-bold text-sm">{gen.distillation_batch}</div>
            <div className="text-stone-400">Continuous Column Still + Doubler | Hearts Cut: 135 Proof</div>
          </div>

          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-stone-200 font-semibold text-sm">
              <Wine className="w-4 h-4 text-amber-500" /> Fermentation Wash
            </div>
            <div className="font-mono text-amber-400 font-bold text-sm">{gen.fermentation_batch}</div>
            <div className="text-stone-400">72 Hours Fermentation | Pitch Temp: 22.0&deg;C | Final ABV: 9.2%</div>
          </div>
        </div>

        <div className="flex justify-center"><ArrowRight className="w-5 h-5 text-stone-600 rotate-90" /></div>

        {/* Node 4: Agricultural Grain Lots */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-4 space-y-3 text-xs">
          <div className="flex items-center gap-2 text-stone-200 font-semibold text-sm">
            <Wheat className="w-4 h-4 text-amber-500" /> Grain Lot Origins & Certificates of Analysis (CoA)
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {gen.grain_lots?.map((gl: any, idx: number) => (
              <div key={idx} className="bg-stone-950 p-3 rounded-lg border border-stone-800 space-y-1">
                <div className="font-bold text-stone-200">{gl.grain_type}</div>
                <div className="font-mono text-amber-400 font-medium">{gl.lot_id}</div>
                <div className="text-stone-400 text-[11px]">{gl.supplier} ({gl.origin})</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
