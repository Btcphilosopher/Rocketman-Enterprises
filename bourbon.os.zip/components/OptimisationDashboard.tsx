"use client";

import React, { useState } from "react";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from "recharts";
import { TrendingUp, Target, ShieldCheck, Zap, Award, Sparkles, RefreshCw } from "lucide-react";

interface OptimisationProps {
  paretoData: any;
  monteCarloData: any;
  sensitivityData: any;
  bayesianData: any;
  onRunMonteCarlo: () => void;
}

export default function OptimisationDashboard({
  paretoData,
  monteCarloData,
  sensitivityData,
  bayesianData,
  onRunMonteCarlo
}: OptimisationProps) {
  const paretoPoints = paretoData?.pareto_frontier ?? [
    { tier: "Standard Batch", cost_per_bottle: 9.80, bqi_quality: 79.5 },
    { tier: "Reserve Batch", cost_per_bottle: 14.50, bqi_quality: 85.2 },
    { tier: "Small Batch Choice", cost_per_bottle: 19.80, bqi_quality: 89.8 },
    { tier: "Single Barrel Select", cost_per_bottle: 32.00, bqi_quality: 94.1 },
    { tier: "Master Distiller Reserve", cost_per_bottle: 52.00, bqi_quality: 96.8 },
  ];

  const mcHist = monteCarloData?.distribution_histogram ?? [];
  const sensVars = sensitivityData?.ranked_variables ?? [];
  const recExp = bayesianData?.recommended_experiment ?? {};

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-2">
        <h2 className="text-lg font-bold text-stone-100 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-amber-500" /> Process Optimisation & Uncertainty Propagation Engine
        </h2>
        <p className="text-xs text-stone-400">
          Evaluates trade-offs across Quality (BQI), Raw Material & Storage Cost, Yield, and stochastic operational uncertainties.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pareto Frontier Chart */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
              <Target className="w-4 h-4 text-amber-500" /> Multi-Objective Pareto Frontier (Quality vs Cost)
            </h3>
            <span className="text-[11px] text-amber-400 font-medium">Optimal: Small Batch Choice</span>
          </div>

          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={paretoPoints}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="cost_per_bottle" stroke="#94a3b8" fontSize={11} unit="$" />
                <YAxis domain={[70, 100]} stroke="#94a3b8" fontSize={11} unit=" BQI" />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e293b", borderColor: "#475569", color: "#f8fafc", borderRadius: "8px" }}
                />
                <Line
                  type="monotone"
                  dataKey="bqi_quality"
                  name="BQI Quality"
                  stroke="#f59e0b"
                  strokeWidth={3}
                  dot={{ r: 6, fill: "#f59e0b" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-stone-400">
            {paretoData?.sweet_spot_recommendation ?? "6-Year Small Batch Choice provides optimal marginal return before holding cost curves steepen."}
          </p>
        </div>

        {/* Monte Carlo Uncertainty Distribution */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" /> Monte Carlo Quality Distribution (250 Trials)
            </h3>
            <button
              onClick={onRunMonteCarlo}
              className="px-3 py-1 bg-stone-800 hover:bg-stone-700 text-stone-200 rounded text-xs flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw className="w-3 h-3" /> Re-run Simulation
            </button>
          </div>

          <div className="w-full h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={mcHist}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis dataKey="score" stroke="#94a3b8" fontSize={11} />
                <YAxis stroke="#94a3b8" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#1e293b", borderColor: "#475569", color: "#f8fafc", borderRadius: "8px" }}
                />
                <Bar dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-between text-xs text-stone-400 font-mono">
            <span>Mean BQI: {monteCarloData?.mean_bqi ?? 88.4}</span>
            <span>95% CI: [{monteCarloData?.worst_case_p5 ?? 83.2} - {monteCarloData?.best_case_p95 ?? 93.6}]</span>
          </div>
        </div>
      </div>

      {/* Sensitivity Analysis & Bayesian DOE */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sensitivity Ranking Table */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-3">
          <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-500" /> Quality Sensitivity Analysis (Sobol Indices)
          </h3>

          <div className="space-y-2.5">
            {sensVars.map((v: any, idx: number) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="text-stone-300 font-medium">{v.variable}</span>
                  <span className="text-amber-400 font-mono">{(v.importance_score * 100).toFixed(0)}% Sobol Index</span>
                </div>
                <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                  <div
                    className="bg-amber-500 h-full rounded-full transition-all"
                    style={{ width: `${v.importance_score * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bayesian Optimal Experiment Design */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" /> Next Optimal Pilot Batch Experiment
            </h3>
            <span className="text-xs bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2.5 py-0.5 rounded-full font-mono">
              Acquisition Fn: 0.92
            </span>
          </div>

          <div className="bg-stone-950/80 border border-stone-800 rounded-lg p-4 space-y-3 text-xs">
            <div className="font-bold text-amber-400 text-sm">{recExp.title ?? "Extended Fermentation vs High Rye Interaction"}</div>
            <p className="text-stone-400 leading-relaxed">{recExp.hypothesis ?? "Increasing fermentation time from 72h to 88h at 22C pitch temp will boost fruity ester production without increasing fusels."}</p>

            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-stone-800 font-mono text-stone-300">
              <div>Expected Gain: <span className="text-emerald-400 font-bold">{recExp.expected_quality_gain ?? "+2.8 BQI Points"}</span></div>
              <div>Info Gain Score: <span className="text-amber-400 font-bold">{recExp.information_gain_score ?? "0.88"}</span></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
