"use client";

import React from "react";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
  Legend,
  Tooltip
} from "recharts";

interface FlavourRadarProps {
  currentVector: Record<string, number>;
  targetVector?: Record<string, number>;
  blendVector?: Record<string, number>;
}

export default function FlavourRadarChart({
  currentVector,
  targetVector,
  blendVector
}: FlavourRadarProps) {
  const keys = Object.keys(currentVector);
  const data = keys.map((key) => ({
    subject: key.replace("_", " ").toUpperCase(),
    Current: currentVector[key] ?? 50,
    ...(targetVector ? { Target: targetVector[key] ?? 50 } : {}),
    ...(blendVector ? { Blended: blendVector[key] ?? 50 } : {})
  }));

  return (
    <div className="w-full h-80 bg-stone-900/50 rounded-xl p-4 border border-stone-800">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart cx="50%" cy="50%" outerRadius="75%" data={data}>
          <PolarGrid stroke="#44403c" />
          <PolarAngleAxis dataKey="subject" tick={{ fill: "#a8a29e", fontSize: 10 }} />
          <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#78716c" fontSize={9} />
          <Radar
            name="Current Batch"
            dataKey="Current"
            stroke="#d97706"
            fill="#d97706"
            fillOpacity={0.4}
          />
          {targetVector && (
            <Radar
              name="Target Profile"
              dataKey="Target"
              stroke="#0284c7"
              fill="#0284c7"
              fillOpacity={0.25}
            />
          )}
          {blendVector && (
            <Radar
              name="Blended Master"
              dataKey="Blended"
              stroke="#10b981"
              fill="#10b981"
              fillOpacity={0.3}
            />
          )}
          <Tooltip
            contentStyle={{ backgroundColor: "#1c1917", borderColor: "#44403c", color: "#f5f5f4", borderRadius: "8px" }}
          />
          <Legend wrapperStyle={{ fontSize: "12px", paddingTop: "8px" }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
