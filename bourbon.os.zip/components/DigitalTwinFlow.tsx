"use client";

import React, { useState } from "react";
import {
  Wheat,
  Flame,
  Factory,
  Wine,
  Sparkles,
  ShieldCheck,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2,
  Clock,
  DollarSign,
  BarChart3,
  Thermometer,
  Layers
} from "lucide-react";
import FlavourRadarChart from "./FlavourRadarChart";

interface DigitalTwinFlowProps {
  simulationData: any;
  onRunSimulation: (params: any) => void;
  loading: boolean;
}

export default function DigitalTwinFlow({
  simulationData,
  onRunSimulation,
  loading
}: DigitalTwinFlowProps) {
  const [cornPct, setCornPct] = useState(70);
  const [ryePct, setRyePct] = useState(20);
  const [wheatPct, setWheatPct] = useState(0);
  const [barleyPct, setBarleyPct] = useState(10);
  const [targetAgeMonths, setTargetAgeMonths] = useState(72);
  const [simulateStall, setSimulateStall] = useState(false);
  const [activeStage, setActiveStage] = useState<string>("SUMMARY");

  const handleGrainChange = (type: string, val: number) => {
    let c = cornPct;
    let r = ryePct;
    let w = wheatPct;
    let b = barleyPct;

    if (type === "corn") c = val;
    if (type === "rye") r = val;
    if (type === "wheat") w = val;
    if (type === "barley") b = val;

    const remaining = 100 - c;
    if (type === "corn") {
      // Scale others proportionately
      const otherSum = r + w + b || 1;
      r = Math.round((r / otherSum) * remaining);
      w = Math.round((w / otherSum) * remaining);
      b = 100 - c - r - w;
    }

    setCornPct(c);
    setRyePct(Math.max(0, r));
    setWheatPct(Math.max(0, w));
    setBarleyPct(Math.max(0, b));
  };

  const handleRun = () => {
    onRunSimulation({
      corn_pct: cornPct,
      rye_pct: ryePct,
      wheat_pct: wheatPct,
      barley_pct: barleyPct,
      target_age_months: targetAgeMonths,
      simulate_stall: simulateStall
    });
  };

  const stages = [
    { id: "GRAIN", label: "Grain Lot", icon: Wheat },
    { id: "MILLING", label: "Milling", icon: Factory },
    { id: "MASH", label: "Mash Cook", icon: Flame },
    { id: "FERMENTATION", label: "Fermentation", icon: Wine },
    { id: "DISTILLATION", label: "Distillation", icon: Layers },
    { id: "SPIRIT", label: "White Spirit", icon: Sparkles },
    { id: "BARREL", label: "Barrel Entry", icon: Layers },
    { id: "MATURATION", label: "Maturation", icon: Clock },
    { id: "PROOFING", label: "Proofing", icon: Wine },
    { id: "BOTTLING", label: "Bottling", icon: CheckCircle2 },
  ];

  const bqi = simulationData?.bqi_result?.bqi ?? 88.5;
  const costPerBottle = simulationData?.cost_result?.cost_per_750ml_bottle ?? 14.80;
  const yieldLitres = simulationData?.yield_litres_proof ?? 235.0;
  const flavour = simulationData?.flavour_vector ?? {
    sweetness: 65, vanilla: 75, caramel: 78, oak: 62, fruit: 55, rye_spice: 68, heat: 42, body: 78, finish: 82
  };
  const offNotes = simulationData?.bqi_result?.off_notes ?? [];

  return (
    <div className="space-y-6">
      {/* Top Banner Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-stone-900/80 border border-amber-900/40 rounded-xl p-4 flex items-center justify-between shadow-lg">
          <div>
            <div className="text-xs uppercase text-amber-500 font-semibold tracking-wider">Bourbon Quality Index</div>
            <div className="text-3xl font-extrabold text-amber-400 mt-1">{bqi} <span className="text-sm font-normal text-amber-500/80">/ 100</span></div>
            <div className="text-xs text-stone-400 mt-0.5">95% CI: [{simulationData?.bqi_result?.bqi_ci_lower ?? 85.2} - {simulationData?.bqi_result?.bqi_ci_upper ?? 91.8}]</div>
          </div>
          <div className="p-3 bg-amber-500/10 rounded-full border border-amber-500/20 text-amber-400">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase text-stone-400 font-semibold tracking-wider">Cost / 750ml Bottle</div>
            <div className="text-3xl font-extrabold text-stone-100 mt-1">${costPerBottle}</div>
            <div className="text-xs text-stone-400 mt-0.5">Proof Spirit Cost: ${simulationData?.cost_result?.cost_per_litre_proof_spirit ?? 18.50}/L</div>
          </div>
          <div className="p-3 bg-emerald-500/10 rounded-full border border-emerald-500/20 text-emerald-400">
            <DollarSign className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase text-stone-400 font-semibold tracking-wider">Proof Spirit Yield</div>
            <div className="text-3xl font-extrabold text-stone-100 mt-1">{yieldLitres} <span className="text-sm font-normal text-stone-400">L</span></div>
            <div className="text-xs text-stone-400 mt-0.5">~313 Bottles @ 90 Proof</div>
          </div>
          <div className="p-3 bg-blue-500/10 rounded-full border border-blue-500/20 text-blue-400">
            <BarChart3 className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-stone-900/80 border border-stone-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <div className="text-xs uppercase text-stone-400 font-semibold tracking-wider">TTB Regulatory Status</div>
            <div className="text-xl font-bold text-emerald-400 mt-1 flex items-center gap-1.5">
              <ShieldCheck className="w-5 h-5" /> Straight Bourbon
            </div>
            <div className="text-xs text-stone-400 mt-0.5">27 CFR § 5.143 Compliant</div>
          </div>
        </div>
      </div>

      {/* Production Lifecycle Pipeline Map */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm uppercase tracking-wider font-semibold text-stone-300 flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-500" /> End-to-End Production Digital Twin Pipeline
          </h3>
          <span className="text-xs text-stone-400">Click any stage to inspect detailed physics & chemistry</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 lg:grid-cols-10 gap-2">
          {stages.map((st, idx) => {
            const Icon = st.icon;
            const isSelected = activeStage === st.id;
            return (
              <button
                key={st.id}
                onClick={() => setActiveStage(st.id)}
                className={`flex flex-col items-center p-3 rounded-lg border text-center transition-all ${
                  isSelected
                    ? "bg-amber-500/20 border-amber-500/60 text-amber-300 shadow-lg shadow-amber-500/10"
                    : "bg-stone-950/60 border-stone-800 text-stone-400 hover:border-stone-700 hover:text-stone-200"
                }`}
              >
                <Icon className="w-5 h-5 mb-1.5" />
                <span className="text-xs font-medium">{st.label}</span>
                <span className="text-[10px] text-stone-500 mt-0.5">Stage {idx + 1}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Controls & Radar Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Process Parameters */}
        <div className="lg:col-span-5 bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-5">
          <div className="flex items-center justify-between border-b border-stone-800 pb-3">
            <h3 className="font-semibold text-stone-200 flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-500" /> Process Simulator Controls
            </h3>
            <button
              onClick={handleRun}
              disabled={loading}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
            >
              {loading ? <RotateCcw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              {loading ? "Simulating..." : "Run Digital Twin"}
            </button>
          </div>

          {/* Grain Bill Sliders */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-stone-300 flex items-center gap-1.5">
                <Wheat className="w-3.5 h-3.5 text-amber-500" /> Grain Bill Composition
              </label>
              <span className="text-xs text-amber-400 font-mono">
                {cornPct}% Corn | {ryePct}% Rye | {wheatPct}% Wheat | {barleyPct}% Barley
              </span>
            </div>

            <div>
              <div className="flex justify-between text-xs text-stone-400 mb-1">
                <span>Corn (Min 51% legal requirement):</span>
                <span className="font-semibold text-stone-200">{cornPct}%</span>
              </div>
              <input
                type="range"
                min="51"
                max="85"
                value={cornPct}
                onChange={(e) => handleGrainChange("corn", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-stone-400 mb-1">
                <span>Rye (Flavor & Spice):</span>
                <span className="font-semibold text-stone-200">{ryePct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={ryePct}
                onChange={(e) => handleGrainChange("rye", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-stone-400 mb-1">
                <span>Wheat (Mellowness & Floral):</span>
                <span className="font-semibold text-stone-200">{wheatPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                value={wheatPct}
                onChange={(e) => handleGrainChange("wheat", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs text-stone-400 mb-1">
                <span>Malted Barley (Diastatic Enzymes):</span>
                <span className="font-semibold text-stone-200">{barleyPct}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="20"
                value={barleyPct}
                onChange={(e) => handleGrainChange("barley", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>

          {/* Maturation Age Slider */}
          <div className="space-y-2 pt-2 border-t border-stone-800">
            <div className="flex justify-between text-xs text-stone-300">
              <span className="flex items-center gap-1.5 font-medium">
                <Clock className="w-3.5 h-3.5 text-amber-500" /> Maturation Age:
              </span>
              <span className="font-mono text-amber-400 font-bold">
                {targetAgeMonths} Months ({(targetAgeMonths / 12).toFixed(1)} Years)
              </span>
            </div>
            <input
              type="range"
              min="12"
              max="144"
              step="6"
              value={targetAgeMonths}
              onChange={(e) => setTargetAgeMonths(parseInt(e.target.value))}
              className="w-full accent-amber-500 bg-stone-800 h-1.5 rounded-lg appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-stone-500">
              <span>1 Yr (Early)</span>
              <span>4 Yrs (Straight)</span>
              <span>6 Yrs (Peak)</span>
              <span>12 Yrs (Over-oak risk)</span>
            </div>
          </div>

          {/* Anomaly Testing Switch */}
          <div className="pt-2 border-t border-stone-800 flex items-center justify-between">
            <div className="text-xs">
              <div className="font-medium text-stone-300">Simulate Fermentation Stall Anomaly</div>
              <div className="text-stone-500 text-[11px]">Injects yeast stress to test off-note diagnostics</div>
            </div>
            <button
              onClick={() => setSimulateStall(!simulateStall)}
              className={`w-11 h-6 rounded-full transition-colors p-1 ${
                simulateStall ? "bg-red-600" : "bg-stone-800"
              }`}
            >
              <div className={`w-4 h-4 bg-white rounded-full transition-transform ${simulateStall ? "translate-x-5" : ""}`} />
            </button>
          </div>
        </div>

        {/* Right Column: Flavour Radar & Off-Note Diagnostics */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-stone-200 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-500" /> 18-Dimensional Flavour Vector Radar
              </h3>
              <span className="text-xs text-amber-400/80 font-mono">BQI Score: {bqi}</span>
            </div>
            <FlavourRadarChart currentVector={flavour} />
          </div>

          {/* Off-note Diagnostic Cards */}
          {offNotes.length > 0 && (
            <div className="bg-red-950/20 border border-red-900/40 rounded-xl p-4 space-y-2">
              <div className="text-xs uppercase font-semibold text-red-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4" /> Off-Note Diagnostics Detected
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {offNotes.map((off: any, idx: number) => (
                  <div key={idx} className="bg-stone-950/80 border border-red-900/30 rounded-lg p-3 text-xs space-y-1">
                    <div className="font-semibold text-red-300 flex justify-between">
                      <span>{off.off_note_type}</span>
                      <span className="text-stone-400">Severity: {off.severity}/10</span>
                    </div>
                    <div className="text-stone-400">Probability: {(off.probability * 100).toFixed(0)}%</div>
                    <div className="text-stone-500 text-[11px]">
                      Root cause: {off.contributing_variables?.join(", ")}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
