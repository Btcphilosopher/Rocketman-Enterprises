"use client";

import React, { useState } from "react";
import { Database, FileCheck, Shield, UploadCloud, Cpu, AlertCircle, CheckCircle } from "lucide-react";

interface LabProps {
  modelsData: any[];
  complianceData: any;
}

export default function LabAndGovernanceView({ modelsData, complianceData }: LabProps) {
  const [csvText, setCsvText] = useState("");
  const [uploadSuccess, setUploadSuccess] = useState(false);

  const handleSimulateUpload = () => {
    if (!csvText.trim()) return;
    setUploadSuccess(true);
    setTimeout(() => setUploadSuccess(false), 4000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-2">
        <h2 className="text-lg font-bold text-stone-100 flex items-center gap-2">
          <Database className="w-5 h-5 text-amber-500" /> Laboratory Data Calibration, ML Governance & Compliance
        </h2>
        <p className="text-xs text-stone-400">
          Calibrates surrogate digital twin models against real laboratory GC-MS congener assays and taster panel scores while maintaining strict TTB regulatory compliance.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* ML Model Registry Table */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-3">
          <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-500" /> ML Model Governance & Registry
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-stone-300">
              <thead className="bg-stone-950 text-stone-400 uppercase text-[10px] tracking-wider border-b border-stone-800">
                <tr>
                  <th className="p-2.5">Model ID</th>
                  <th className="p-2.5">Type</th>
                  <th className="p-2.5">MAE</th>
                  <th className="p-2.5">RMSE</th>
                  <th className="p-2.5">R&sup2; Score</th>
                  <th className="p-2.5">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-800 font-mono">
                {(modelsData?.length ? modelsData : [
                  { model_id: "BBN-RF-BQI-v1.4", model_type: "Random Forest", mae: 1.42, rmse: 1.88, r2_score: 0.932, status: "PRODUCTION" },
                  { model_id: "BBN-GPR-FLAVOUR-v2.1", model_type: "Gaussian Process", mae: 1.15, rmse: 1.52, r2_score: 0.954, status: "PRODUCTION" },
                  { model_id: "BBN-XGB-YIELD-v1.0", model_type: "Gradient Boost", mae: 2.10, rmse: 2.85, r2_score: 0.910, status: "CHALLENGER" }
                ]).map((m: any, idx: number) => (
                  <tr key={idx} className="hover:bg-stone-800/40">
                    <td className="p-2.5 text-amber-400 font-bold">{m.model_id}</td>
                    <td className="p-2.5 text-stone-300 font-sans">{m.model_type}</td>
                    <td className="p-2.5 text-stone-300">{m.mae}</td>
                    <td className="p-2.5 text-stone-300">{m.rmse}</td>
                    <td className="p-2.5 text-emerald-400 font-bold">{m.r2_score}</td>
                    <td className="p-2.5 font-sans">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        m.status === "PRODUCTION" ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30" : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      }`}>
                        {m.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* TTB Regulatory Compliance Verification */}
        <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-amber-500" /> TTB 27 CFR Part 5 Compliance Verification
            </h3>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
              Fully Compliant
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="p-3 bg-stone-950 rounded-lg border border-stone-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-stone-200">Grain Bill Corn % (&ge; 51.0%)</div>
                <div className="text-stone-500 text-[11px]">Current value: 70.0% Corn</div>
              </div>
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            </div>

            <div className="p-3 bg-stone-950 rounded-lg border border-stone-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-stone-200">Max Distillation Proof (&le; 160 Proof)</div>
                <div className="text-stone-500 text-[11px]">Current hearts proof: 135.0 Proof</div>
              </div>
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            </div>

            <div className="p-3 bg-stone-950 rounded-lg border border-stone-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-stone-200">Max Barrel Entry Proof (&le; 125 Proof)</div>
                <div className="text-stone-500 text-[11px]">Current entry proof: 120.0 Proof</div>
              </div>
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            </div>

            <div className="p-3 bg-stone-950 rounded-lg border border-stone-800 flex items-center justify-between">
              <div>
                <div className="font-semibold text-stone-200">Oak Container Requirement</div>
                <div className="text-stone-500 text-[11px]">Charred New American White Oak</div>
              </div>
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            </div>
          </div>
        </div>
      </div>

      {/* CSV / Lab Data Calibration Section */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-4">
        <h3 className="font-semibold text-stone-200 text-sm flex items-center gap-2">
          <UploadCloud className="w-4 h-4 text-amber-500" /> Laboratory Assays & Sensory Score Upload
        </h3>

        <div className="space-y-3">
          <textarea
            rows={4}
            value={csvText}
            onChange={(e) => setCsvText(e.target.value)}
            placeholder="Paste GC-MS lab assay CSV data (batch_id, abv, esters_ppm, fusels_ppm, sensory_score)...&#10;e.g. BATCH-001,45.2,120.4,310.2,88.5"
            className="w-full bg-stone-950 border border-stone-800 rounded-lg p-3 text-xs text-stone-200 font-mono focus:outline-none focus:border-amber-500"
          />

          <div className="flex items-center justify-between">
            <button
              onClick={handleSimulateUpload}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-lg text-xs font-semibold flex items-center gap-2 transition-colors"
            >
              <UploadCloud className="w-4 h-4" /> Import & Calibrate Surrogate Model
            </button>

            {uploadSuccess && (
              <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" /> Lab dataset successfully ingested & model recalibrated!
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
