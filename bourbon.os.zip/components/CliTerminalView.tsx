"use client";

import React, { useState, useRef, useEffect } from "react";
import { Terminal, Play, CornerDownLeft, Sparkles, HelpCircle } from "lucide-react";

export default function CliTerminalView() {
  const [inputCommand, setInputCommand] = useState("bourbon report");
  const [history, setHistory] = useState<Array<{ command: string; output: string; exitCode: number }>>([
    {
      command: "bourbon simulate --corn 70 --rye 20 --barley 10",
      output: `=== BOURBON.OS DIGITAL TWIN SIMULATION COMPLETE ===
Batch ID: SIM-BATCH-LIVE
Recipe: Kentucky Classic Bourbon
BQI Score: 88.5 / 100
Proof Yield: 235.0 Proof Litres
Cost / 750ml Bottle: $14.80
TTB Regulatory Status: 27 CFR § 5.143 COMPLIANT`,
      exitCode: 0
    }
  ]);

  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  const handleRunCommand = async (cmdToRun?: string) => {
    const cmd = cmdToRun || inputCommand;
    if (!cmd.trim()) return;

    setLoading(true);
    try {
      const res = await fetch("/api/cli", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command: cmd })
      });
      const data = await res.json();

      setHistory((prev) => [
        ...prev,
        {
          command: cmd,
          output: data.stdout || data.stderr || "Command executed with no output.",
          exitCode: data.exitCode ?? 0
        }
      ]);
    } catch (err: any) {
      setHistory((prev) => [
        ...prev,
        {
          command: cmd,
          output: err?.message || "Failed to execute command.",
          exitCode: 1
        }
      ]);
    } finally {
      setLoading(false);
      if (!cmdToRun) setInputCommand("");
    }
  };

  const sampleCommands = [
    "bourbon report",
    "bourbon simulate --corn 75 --rye 15 --barley 10",
    "bourbon optimise --profile HIGH_RYE",
    "bourbon barrel --limit 10",
    "bourbon blend",
    "bourbon seed"
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-2">
        <h2 className="text-lg font-bold text-stone-100 flex items-center gap-2">
          <Terminal className="w-5 h-5 text-amber-500" /> BOURBON.OS Interactive Command Line Console
        </h2>
        <p className="text-xs text-stone-400">
          Run Python CLI commands directly against the digital twin simulation and optimization engine.
        </p>
      </div>

      {/* Quick Example Buttons */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs text-stone-400 flex items-center gap-1 font-medium">
          <HelpCircle className="w-3.5 h-3.5" /> Quick Run:
        </span>
        {sampleCommands.map((sc, idx) => (
          <button
            key={idx}
            onClick={() => handleRunCommand(sc)}
            className="px-2.5 py-1 bg-stone-900 hover:bg-stone-800 border border-stone-800 text-amber-400 text-xs font-mono rounded-lg transition-colors"
          >
            {sc}
          </button>
        ))}
      </div>

      {/* Terminal Display */}
      <div className="bg-stone-950 border border-stone-800 rounded-xl overflow-hidden font-mono text-xs shadow-2xl">
        {/* Terminal Header Bar */}
        <div className="bg-stone-900 px-4 py-2 border-b border-stone-800 flex items-center justify-between text-stone-400">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="ml-2 text-[11px] text-stone-300 font-semibold">bourbon_os@digital-twin:~</span>
          </div>
          <span className="text-[10px] text-stone-500">Python 3.12 | CLI v1.0</span>
        </div>

        {/* Terminal Output Body */}
        <div className="p-4 space-y-4 max-h-[420px] overflow-y-auto">
          {history.map((item, idx) => (
            <div key={idx} className="space-y-1.5">
              <div className="flex items-center gap-2 text-amber-400">
                <span className="text-stone-500">$</span>
                <span className="font-bold">{item.command}</span>
              </div>
              <pre className="text-stone-300 bg-stone-900/40 p-3 rounded-lg border border-stone-800/60 whitespace-pre-wrap leading-relaxed text-[11px]">
                {item.output}
              </pre>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Command Input Bar */}
        <div className="p-3 bg-stone-900/80 border-t border-stone-800 flex items-center gap-2">
          <span className="text-amber-500 font-bold">$</span>
          <input
            type="text"
            value={inputCommand}
            onChange={(e) => setInputCommand(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleRunCommand()}
            placeholder="Type command e.g. bourbon simulate..."
            className="flex-1 bg-transparent text-stone-100 placeholder-stone-600 focus:outline-none"
          />
          <button
            onClick={() => handleRunCommand()}
            disabled={loading}
            className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Play className="w-3 h-3 fill-current" /> Run
          </button>
        </div>
      </div>
    </div>
  );
}
