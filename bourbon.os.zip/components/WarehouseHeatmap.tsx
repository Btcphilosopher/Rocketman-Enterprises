"use client";

import React, { useState } from "react";
import { Warehouse, Thermometer, Droplets, Layers, Search, Filter } from "lucide-react";

interface WarehouseProps {
  barrels: any[];
}

export default function WarehouseHeatmap({ barrels }: WarehouseProps) {
  const [selectedWarehouse, setSelectedWarehouse] = useState<string>("RICKHOUSE_A");
  const [selectedFloor, setSelectedFloor] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>("");

  const filteredBarrels = barrels.filter((b) => {
    const matchWh = b.warehouse_id === selectedWarehouse;
    const matchFl = selectedFloor === null || b.floor === selectedFloor;
    const matchSearch = !searchTerm || b.barrel_id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchWh && matchFl && matchSearch;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "PEAK_MATURITY":
        return "bg-emerald-500/20 text-emerald-300 border-emerald-500/40";
      case "APPROACHING_PEAK":
        return "bg-amber-500/20 text-amber-300 border-amber-500/40";
      case "OVER_OAK_RISK":
        return "bg-red-500/20 text-red-300 border-red-500/40";
      default:
        return "bg-stone-800 text-stone-300 border-stone-700";
    }
  };

  return (
    <div className="space-y-6">
      {/* Rickhouse Warehouse Selector & Microclimate Metrics */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Warehouse className="w-5 h-5 text-amber-500" />
            <h2 className="text-lg font-bold text-stone-100">Rickhouse Warehouse Spatial Digital Twin</h2>
          </div>

          {/* Warehouse Tabs */}
          <div className="flex gap-2">
            {["RICKHOUSE_A", "RICKHOUSE_B", "RICKHOUSE_C"].map((wh) => (
              <button
                key={wh}
                onClick={() => setSelectedWarehouse(wh)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                  selectedWarehouse === wh
                    ? "bg-amber-500/20 border-amber-500/60 text-amber-300"
                    : "bg-stone-950 border-stone-800 text-stone-400 hover:text-stone-200"
                }`}
              >
                {wh.replace("_", " ")}
              </button>
            ))}
          </div>
        </div>

        {/* Spatial Microclimate Profile Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 pt-2 border-t border-stone-800 text-xs">
          {[1, 2, 3, 4, 5, 6].map((fl) => {
            const temp = 18 + fl * 2.2;
            const rh = 72 - fl * 3.5;
            const isSel = selectedFloor === fl;
            return (
              <button
                key={fl}
                onClick={() => setSelectedFloor(isSel ? null : fl)}
                className={`p-2.5 rounded-lg border text-left space-y-1 transition-all ${
                  isSel
                    ? "bg-amber-500/20 border-amber-500/60 text-amber-300"
                    : "bg-stone-950/80 border-stone-800 text-stone-300 hover:border-stone-700"
                }`}
              >
                <div className="font-bold flex justify-between">
                  <span>Floor {fl}</span>
                  <span className="text-[10px] text-stone-500">{fl > 4 ? "Hot/Dry" : "Cool/Humid"}</span>
                </div>
                <div className="flex items-center gap-2 text-[11px] text-stone-400">
                  <span className="flex items-center gap-0.5"><Thermometer className="w-3 h-3 text-red-400" /> {temp.toFixed(1)}&deg;C</span>
                  <span className="flex items-center gap-0.5"><Droplets className="w-3 h-3 text-blue-400" /> {rh.toFixed(0)}%</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search & Filter Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-500" />
          <input
            type="text"
            placeholder="Search Barrel ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-stone-900 border border-stone-800 rounded-lg pl-9 pr-3 py-2 text-xs text-stone-200 focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="text-xs text-stone-400">
          Showing <span className="font-mono font-bold text-amber-400">{filteredBarrels.length}</span> barrels in {selectedWarehouse}
        </div>
      </div>

      {/* Barrel Rank & Inventory Table */}
      <div className="bg-stone-900/60 border border-stone-800 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-stone-300">
            <thead className="bg-stone-950 text-stone-400 uppercase text-[10px] tracking-wider border-b border-stone-800">
              <tr>
                <th className="p-3">Barrel ID</th>
                <th className="p-3">Location</th>
                <th className="p-3">Char Level</th>
                <th className="p-3">Age</th>
                <th className="p-3">Current Proof</th>
                <th className="p-3">Volume</th>
                <th className="p-3">Est. BQI</th>
                <th className="p-3">Maturity Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-800">
              {filteredBarrels.slice(0, 30).map((b, idx) => (
                <tr key={idx} className="hover:bg-stone-800/40 transition-colors">
                  <td className="p-3 font-mono font-bold text-amber-400">{b.barrel_id}</td>
                  <td className="p-3 text-stone-400 font-mono">
                    Floor {b.floor} | R{b.rack}-R{b.row}
                  </td>
                  <td className="p-3 font-mono">Char #{b.char_level ?? 4}</td>
                  <td className="p-3 font-mono font-semibold text-stone-200">{b.age_months} months</td>
                  <td className="p-3 font-mono">{b.current_proof} Proof</td>
                  <td className="p-3 font-mono">{b.current_volume_l} L</td>
                  <td className="p-3 font-mono font-bold text-amber-400">{b.estimated_bqi}</td>
                  <td className="p-3">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold border ${getStatusColor(b.maturity_status)}`}>
                      {b.maturity_status.replace("_", " ")}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
