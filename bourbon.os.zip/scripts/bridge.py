"""
BOURBON.OS — Next.js Node API Bridge Script
Accepts JSON commands from standard input and invokes BOURBON.OS Python services.
"""

import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import json
from bourbon_os.api.services import (
    api_run_digital_twin_simulation,
    api_optimise_blend,
    api_rank_barrels,
    api_seed_database,
    api_get_genealogy
)
from bourbon_os.optimisation.recipe_opt import optimize_recipe
from bourbon_os.optimisation.monte_carlo import run_monte_carlo_simulation
from bourbon_os.optimisation.sensitivity import run_sensitivity_analysis
from bourbon_os.optimisation.pareto_opt import calculate_pareto_frontier
from bourbon_os.optimisation.bayesian_opt import run_bayesian_experiment_design
from bourbon_os.machine_learning.governance import get_model_registry
from bourbon_os.compliance.regulatory import RegulatoryComplianceChecker
from bourbon_os.core.models import GrainBill


def main():
    try:
        raw_input = sys.stdin.read()
        req = json.loads(raw_input) if raw_input.strip() else {}
        action = req.get("action", "simulate")
        params = req.get("params", {})

        if action == "seed":
            res = api_seed_database()
        elif action == "simulate":
            res = api_run_digital_twin_simulation(
                corn_pct=params.get("corn_pct", 70.0),
                rye_pct=params.get("rye_pct", 20.0),
                wheat_pct=params.get("wheat_pct", 0.0),
                barley_pct=params.get("barley_pct", 10.0),
                target_age_months=params.get("target_age_months", 72.0),
                simulate_stall=params.get("simulate_stall", False)
            )
        elif action == "optimise_recipe":
            res = optimize_recipe(target_profile_name=params.get("profile", "HIGH_RYE"))
        elif action == "optimise_blend":
            target_dict = params.get("target_flavour", {
                "vanilla": 80.0, "caramel": 75.0, "oak": 65.0, "fruit": 70.0, "rye_spice": 60.0, "body": 80.0, "finish": 85.0
            })
            res = api_optimise_blend(target_flavour_dict=target_dict)
        elif action == "rank_barrels":
            res = api_rank_barrels(limit=params.get("limit", 50))
        elif action == "monte_carlo":
            gb = GrainBill(
                corn_pct=params.get("corn_pct", 70.0),
                rye_pct=params.get("rye_pct", 20.0),
                wheat_pct=params.get("wheat_pct", 0.0),
                malted_barley_pct=params.get("barley_pct", 10.0)
            )
            res = run_monte_carlo_simulation(num_trials=params.get("num_trials", 200), grain_bill=gb)
        elif action == "sensitivity":
            res = run_sensitivity_analysis()
        elif action == "pareto":
            res = calculate_pareto_frontier()
        elif action == "bayesian":
            res = run_bayesian_experiment_design()
        elif action == "ml_governance":
            res = get_model_registry()
        elif action == "compliance":
            checker = RegulatoryComplianceChecker()
            gb = GrainBill(
                corn_pct=params.get("corn_pct", 70.0),
                rye_pct=params.get("rye_pct", 20.0),
                wheat_pct=params.get("wheat_pct", 0.0),
                malted_barley_pct=params.get("barley_pct", 10.0)
            )
            res = checker.check_bourbon_compliance(
                grain_bill=gb,
                distillation_hearts_proof=params.get("distillation_proof", 135.0),
                barrel_entry_proof=params.get("barrel_entry_proof", 120.0),
                bottling_proof=params.get("bottling_proof", 90.0),
                maturation_age_years=params.get("maturation_age_years", 6.0),
                wood_type=params.get("wood_type", "Charred New American White Oak")
            )
        elif action == "genealogy":
            res = api_get_genealogy(bottle_id=params.get("bottle_id", "BOTTLE-BATCH-2026-001"))
        else:
            res = {"status": "ERROR", "message": f"Unknown action: {action}"}

        print(json.dumps(res))
    except Exception as e:
        print(json.dumps({"status": "ERROR", "message": str(e)}))


if __name__ == "__main__":
    main()
