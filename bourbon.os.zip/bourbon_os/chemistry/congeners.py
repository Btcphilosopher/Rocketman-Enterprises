"""
BOURBON.OS — Chemical Congener Dynamics & Volatile Compounds
"""

from typing import Dict


def calculate_fermentation_congeners(
    yeast_ester_tendency: float,
    yeast_fusel_tendency: float,
    yeast_acid_tendency: float,
    pitch_temp_c: float,
    fermentation_hours: float,
    gravity_sg: float
) -> Dict[str, float]:
    """
    Predicts congener concentrations in fermented wash (ppm / mg/L).
    """
    temp_factor = 1.0 + (pitch_temp_c - 25.0) * 0.04  # Higher temp increases esters & fusels

    # Esters (Ethyl acetate, isoamyl acetate)
    esters_ppm = 80.0 * (yeast_ester_tendency / 5.0) * temp_factor * (fermentation_hours / 72.0)**0.8

    # Higher Alcohols / Fusels (Isoamyl alcohol, isobutanol, propanol)
    fusel_ppm = 250.0 * (yeast_fusel_tendency / 5.0) * temp_factor * (gravity_sg - 1.0) / 0.06

    # Acetaldehyde / Aldehydes
    aldehydes_ppm = 35.0 * (fermentation_hours / 72.0)**0.5

    # Organic Acids (Acetic acid, isovaleric acid)
    acids_ppm = 40.0 * (yeast_acid_tendency / 5.0) * (fermentation_hours / 72.0)

    # Phenolics (grain-derived)
    phenols_ppm = 12.0

    return {
        "esters": round(max(10.0, esters_ppm), 1),
        "higher_alcohols": round(max(50.0, fusel_ppm), 1),
        "aldehydes": round(max(5.0, aldehydes_ppm), 1),
        "organic_acids": round(max(10.0, acids_ppm), 1),
        "phenolics": round(max(2.0, phenols_ppm), 1),
        "oak_compounds": 0.0  # Zero prior to barrel entry
    }


def calculate_distillation_carryover(
    wash_congeners: Dict[str, float],
    hearts_pct: float,
    heads_pct: float,
    tails_pct: float,
    reflux_ratio: float
) -> Dict[str, float]:
    """
    Calculates fraction separation and congener distribution in hearts distillate (low wines/high wines).
    - Heads take low boiling point compounds (acetaldehyde, ethyl acetate).
    - Hearts retain balanced ester & moderate fusel levels.
    - Tails take high boiling point organic acids, furfural, heavy fusel oils.
    """
    reflux_factor = 1.0 / (1.0 + reflux_ratio * 0.2)

    # Carryover efficiency factors into hearts fraction
    distillate_congeners = {
        "esters": round(wash_congeners.get("esters", 80.0) * (hearts_pct / 100.0) * 1.1 * reflux_factor, 1),
        "higher_alcohols": round(wash_congeners.get("higher_alcohols", 250.0) * (hearts_pct / 100.0) * 0.95, 1),
        "aldehydes": round(wash_congeners.get("aldehydes", 35.0) * (heads_pct / 100.0) * 0.3, 1), # Mostly cut in heads
        "organic_acids": round(wash_congeners.get("organic_acids", 40.0) * (1.0 - tails_pct / 100.0) * 0.4, 1), # Mostly cut in tails
        "phenolics": round(wash_congeners.get("phenolics", 12.0) * 0.85, 1),
        "oak_compounds": 0.0
    }

    return distillate_congeners
