"""
BOURBON.OS — Oak Extraction, Maturation Kinetics & Evaporation (Angel's Share)
"""

import math
from typing import Dict, Tuple


def calculate_oak_extraction(
    age_months: float,
    char_level: int,
    fill_proof: float,
    temp_c: float
) -> Dict[str, float]:
    """
    Simulates oak extractive extraction kinetics (mg/L / ppm) over age.
    Char #1-#4: Higher char increases wood sugars/caramelization and charcoal filtration,
    while moderate char/toast preserves vanillin, lactones, and eugenol.
    """
    time_years = age_months / 12.0
    
    # Saturation kinetic curve: C(t) = C_max * (1 - exp(-k * t))
    k_extraction = 0.35 + (temp_c - 20.0) * 0.015
    proof_solubility = (fill_proof / 100.0)**1.2  # Higher proof dissolves more ethanol-soluble lactones

    char_multipliers = {
        1: {"vanillin": 1.4, "lactones": 1.5, "caramel": 0.8, "tannins": 1.3},
        2: {"vanillin": 1.3, "lactones": 1.3, "caramel": 1.0, "tannins": 1.1},
        3: {"vanillin": 1.1, "lactones": 1.1, "caramel": 1.3, "tannins": 0.9},
        4: {"vanillin": 0.9, "lactones": 0.8, "caramel": 1.5, "tannins": 0.7} # Heavy alligator char
    }

    m = char_multipliers.get(char_level, char_multipliers[3])
    extraction_factor = (1.0 - math.exp(-k_extraction * time_years)) * proof_solubility

    vanillin_ppm = 8.5 * m["vanillin"] * extraction_factor
    oak_lactones_ppm = 12.0 * m["lactones"] * extraction_factor
    caramel_pyrolysis_ppm = 18.0 * m["caramel"] * extraction_factor
    eugenol_spice_ppm = 4.2 * extraction_factor
    tannins_ppm = 45.0 * m["tannins"] * extraction_factor

    return {
        "vanillin": round(vanillin_ppm, 2),
        "oak_lactones": round(oak_lactones_ppm, 2),
        "caramel_compounds": round(caramel_pyrolysis_ppm, 2),
        "eugenol": round(eugenol_spice_ppm, 2),
        "tannins": round(tannins_ppm, 2),
        "total_extractives": round(vanillin_ppm + oak_lactones_ppm + caramel_pyrolysis_ppm + eugenol_spice_ppm + tannins_ppm, 2)
    }


def calculate_angels_share_and_proof(
    initial_vol_l: float,
    initial_proof: float,
    age_months: float,
    avg_temp_c: float,
    avg_humidity_pct: float,
    warehouse_floor: int
) -> Tuple[float, float, float, float]:
    """
    Models Angel's Share evaporation rate and proof dynamics.
    - Top floors (higher floor #) = hotter, lower humidity -> higher volume loss (4-7%/yr), PROOF RISES.
    - Bottom floors = cooler, higher humidity -> moderate volume loss (2-4%/yr), PROOF DROPS or stays flat.
    Returns:
        (current_volume_l, current_proof, total_volume_lost_l, color_lovibond)
    """
    time_years = age_months / 12.0
    
    # Floor height effect: Floor 1 is ground level (cool/humid), Floor 6+ is top rack (hot/dry)
    floor_temp_boost = (warehouse_floor - 1) * 1.8  # Deg C increase per floor
    floor_humidity_drop = (warehouse_floor - 1) * 3.5 # % RH drop per floor

    effective_temp = avg_temp_c + floor_temp_boost
    effective_humidity = max(25.0, avg_humidity_pct - floor_humidity_drop)

    # Annual volume loss %
    base_annual_evap_pct = 3.5 + (effective_temp - 20.0) * 0.25 + (70.0 - effective_humidity) * 0.08
    base_annual_evap_pct = max(1.5, min(8.0, base_annual_evap_pct))

    # Total volume remaining: Vol(t) = Vol_0 * (1 - rate)^t
    remaining_vol_l = initial_vol_l * ((1.0 - (base_annual_evap_pct / 100.0)) ** time_years)
    volume_lost_l = initial_vol_l - remaining_vol_l

    # Proof shift:
    # If RH < 65%, water evaporates faster than ethanol -> Proof INCREASES.
    # If RH > 65%, ethanol evaporates faster than water -> Proof DECREASES.
    annual_proof_change = (65.0 - effective_humidity) * 0.12
    current_proof = initial_proof + (annual_proof_change * time_years)
    current_proof = max(80.0, min(140.0, current_proof))

    # Color development (Degrees Lovibond)
    # Deep amber is ~15-20 deg Lovibond
    color_lovibond = min(25.0, 1.5 + (time_years * 2.8) * (effective_temp / 20.0))

    return (
        round(remaining_vol_l, 2),
        round(current_proof, 1),
        round(volume_lost_l, 2),
        round(color_lovibond, 1)
    )
