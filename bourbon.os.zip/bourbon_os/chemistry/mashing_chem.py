"""
BOURBON.OS — Mashing & Enzymatic Starch Hydrolysis Chemistry
"""

import math
from typing import Dict, Tuple


def calculate_mashing_kinetics(
    corn_kg: float,
    rye_kg: float,
    wheat_kg: float,
    barley_kg: float,
    water_l: float,
    temp_c: float,
    duration_min: float,
    water_ph: float,
    calcium_ppm: float
) -> Tuple[float, float, float, float]:
    """
    Simulates enzymatic starch hydrolysis into fermentable sugars (glucose, maltose, maltotriose)
    and unfermentable dextrins.
    Returns:
        (starch_converted_kg, fermentable_sugars_kg, dextrins_kg, mash_gravity_sg)
    """
    # Starch contents per grain type (average dry weight basis)
    starch_content = {
        "corn": 0.68,
        "rye": 0.60,
        "wheat": 0.64,
        "barley": 0.58
    }

    total_grain = corn_kg + rye_kg + wheat_kg + barley_kg
    if total_grain <= 0:
        return (0.0, 0.0, 0.0, 1.000)

    total_starch = (
        corn_kg * starch_content["corn"] +
        rye_kg * starch_content["rye"] +
        wheat_kg * starch_content["wheat"] +
        barley_kg * starch_content["barley"]
    )

    # Diastatic Power (Enzymes come primarily from malted barley; wheat/rye may contribute minor)
    # Lintner degree contribution: Malted barley ~120-140 deg Lintner
    lintner_barley = 130.0
    total_diastatic_power = (barley_kg * lintner_barley) / total_grain  # deg Lintner per kg mash

    # Calcium stabilizes alpha-amylase at higher temperatures
    ca_factor = min(1.2, 0.8 + (calcium_ppm / 200.0))

    # Temperature kinetics optimums:
    # Beta-amylase optimum 62-65C (produces maltose)
    # Alpha-amylase optimum 70-75C (cleaves internal 1,4-bonds)
    if temp_c < 50.0:
        temp_efficiency = 0.3
    elif 50.0 <= temp_c <= 68.0:
        # High beta-amylase activity -> high fermentability
        temp_efficiency = 0.85 + 0.15 * math.sin((temp_c - 50.0) / 18.0 * math.pi)
    elif 68.0 < temp_c <= 78.0:
        # High alpha-amylase, lower beta -> moderate fermentability
        temp_efficiency = 0.90
    else:
        # Enzyme denaturation above 80C
        temp_efficiency = max(0.1, 1.0 - (temp_c - 78.0) * 0.1)

    # Duration effect (exponential saturation)
    duration_factor = 1.0 - math.exp(-duration_min / 45.0)

    # Overall starch conversion efficiency (0.0 - 0.98)
    conversion_efficiency = min(0.98, (total_diastatic_power / 30.0) * temp_efficiency * ca_factor * duration_factor)
    conversion_efficiency = max(0.1, conversion_efficiency)

    starch_converted_kg = total_starch * conversion_efficiency

    # Fermentable vs dextrin ratio depends on temperature mashing profile
    if temp_c <= 66.0:
        fermentable_ratio = 0.82  # High maltose yield
    elif temp_c <= 72.0:
        fermentable_ratio = 0.75
    else:
        fermentable_ratio = 0.65  # Higher dextrins

    fermentable_sugars_kg = starch_converted_kg * fermentable_ratio
    dextrins_kg = starch_converted_kg * (1.0 - fermentable_ratio)

    # Specific gravity calculation (Plato / SG estimation)
    # 1 kg dissolved sugar in water adds ~0.004 SG per L
    dissolved_solids_kg = fermentable_sugars_kg + dextrins_kg
    sg = 1.000 + (dissolved_solids_kg / water_l) * 0.385

    return (
        round(starch_converted_kg, 2),
        round(fermentable_sugars_kg, 2),
        round(dextrins_kg, 2),
        round(sg, 4)
    )
