"""
BOURBON.OS — 18-Dimensional Flavour Vector Mathematics & Distance Metrics
"""

import math
from typing import Dict, List, Tuple
from bourbon_os.core.models import FlavourVector
from bourbon_os.core.constants import FLAVOUR_DIMENSIONS


def calculate_flavour_distance(
    fv1: FlavourVector,
    fv2: FlavourVector,
    metric: str = "EUCLIDEAN"
) -> float:
    """
    Calculates distance between two 18-dimensional flavour vectors.
    """
    dict1 = fv1.to_dict()
    dict2 = fv2.to_dict()

    if metric == "COSINE":
        dot = sum(dict1[dim] * dict2[dim] for dim in FLAVOUR_DIMENSIONS)
        mag1 = math.sqrt(sum(dict1[dim]**2 for dim in FLAVOUR_DIMENSIONS))
        mag2 = math.sqrt(sum(dict2[dim]**2 for dim in FLAVOUR_DIMENSIONS))
        if mag1 * mag2 == 0:
            return 1.0
        return round(1.0 - (dot / (mag1 * mag2)), 4)
    else:  # EUCLIDEAN
        sq_diff = sum((dict1[dim] - dict2[dim])**2 for dim in FLAVOUR_DIMENSIONS)
        return round(math.sqrt(sq_diff), 2)


def blend_flavour_vectors(
    vectors_with_weights: List[Tuple[FlavourVector, float]]
) -> FlavourVector:
    """
    Calculates weighted linear combination of multiple barrel flavour vectors.
    """
    total_w = sum(w for _, w in vectors_with_weights)
    if total_w <= 0:
        return FlavourVector()

    norm_weights = [(fv, w / total_w) for fv, w in vectors_with_weights]
    blended_dict = {dim: 0.0 for dim in FLAVOUR_DIMENSIONS}

    for fv, w in norm_weights:
        d = fv.to_dict()
        for dim in FLAVOUR_DIMENSIONS:
            blended_dict[dim] += d[dim] * w

    return FlavourVector.from_dict({k: round(v, 1) for k, v in blended_dict.items()})


from typing import Tuple
