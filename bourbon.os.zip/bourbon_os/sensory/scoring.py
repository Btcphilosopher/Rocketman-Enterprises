"""
BOURBON.OS — Sensory Science & Multi-Taster Scoring Engine
"""

from typing import List, Dict, Any
import statistics


def calculate_sensory_panel_scores(panel_scores: List[Dict[str, float]]) -> Dict[str, Any]:
    """
    Aggregates sensory panel evaluations across 8 dimensions (Nose, Palate, Finish, Balance, Complexity, Mouthfeel, Aroma Intensity, Flavour Intensity).
    Calculates mean, median, standard deviation, and inter-rater agreement.
    """
    if not panel_scores:
        return {}

    categories = ["nose", "palate", "finish", "balance", "complexity", "mouthfeel", "aroma_intensity", "flavour_intensity"]
    aggregated = {}

    for cat in categories:
        vals = [s.get(cat, 80.0) for s in panel_scores]
        mean_v = statistics.mean(vals)
        median_v = statistics.median(vals)
        stdev_v = statistics.stdev(vals) if len(vals) > 1 else 0.0
        aggregated[cat] = {
            "mean": round(mean_v, 1),
            "median": round(median_v, 1),
            "stdev": round(stdev_v, 2)
        }

    # Overall panel mean
    overall_vals = [s.get("overall", 82.0) for s in panel_scores]
    panel_mean = statistics.mean(overall_vals)
    panel_stdev = statistics.stdev(overall_vals) if len(overall_vals) > 1 else 0.0

    # Inter-rater agreement index (Cronbach's Alpha proxy)
    agreement = max(0.0, min(100.0, 100.0 - (panel_stdev * 8.0)))

    return {
        "panel_count": len(panel_scores),
        "category_scores": aggregated,
        "overall_mean": round(panel_mean, 1),
        "overall_stdev": round(panel_stdev, 2),
        "inter_rater_agreement_pct": round(agreement, 1)
    }
