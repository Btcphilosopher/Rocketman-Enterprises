"""
BOURBON.OS — Off-Note Detection Engine
"""

from typing import List, Dict
from bourbon_os.core.models import FlavourVector, OffNoteAssessment, FermentationState, DistillationState


def evaluate_off_notes(
    flavour: FlavourVector,
    fermentation_state: FermentationState = None,
    distillation_state: DistillationState = None
) -> List[OffNoteAssessment]:
    """
    Evaluates probability, severity, confidence, and root causes for 9 off-note categories:
    SOLVENT_LIKE, SULFURY, OVERLY_HOT, FLAT, EXCESSIVE_OAK, BITTER, VEGETAL, ACIDIC, UNBALANCED.
    """
    off_notes = []

    # 1. Excessive Oak
    if flavour.oak > 82.0:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="EXCESSIVE_OAK",
                probability=0.85,
                severity=round((flavour.oak - 80.0) * 0.4, 1),
                confidence=0.90,
                contributing_variables=["extended_maturation", "high_barrel_char_tannins"]
            )
        )

    # 2. Overly Hot
    if flavour.heat > 75.0:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="OVERLY_HOT",
                probability=0.78,
                severity=round((flavour.heat - 70.0) * 0.35, 1),
                confidence=0.88,
                contributing_variables=["high_barrel_entry_proof", "insufficient_age"]
            )
        )

    # 3. Sulfury (from yeast stress during fermentation)
    if fermentation_state and fermentation_state.is_stalled:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="SULFURY",
                probability=0.65,
                severity=4.5,
                confidence=0.82,
                contributing_variables=["stalled_fermentation", "yeast_nutrient_deficiency"]
            )
        )

    # 4. Solvent-like (from high ethyl acetate or late heads cut)
    if distillation_state and distillation_state.cuts.get("heads_pct", 8.0) < 5.0:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="SOLVENT_LIKE",
                probability=0.55,
                severity=3.8,
                confidence=0.75,
                contributing_variables=["insufficient_heads_cut"]
            )
        )

    return off_notes
