"""
BOURBON.OS — Recipe & Grain Bill Quality Optimiser
"""

from typing import Dict, List, Any
from bourbon_os.core.models import GrainBill
from bourbon_os.simulation.digital_twin import BourbonDigitalTwin


def optimize_recipe(
    target_profile_name: str = "HIGH_RYE_BOURBON",
    weights: Dict[str, float] = None
) -> Dict[str, Any]:
    """
    Explores grain bill design space (Corn %, Rye %, Wheat %, Barley %) subject to legal (Corn >= 51%)
    and process constraints to maximize predicted BQI.
    Returns candidate configurations with explainability breakdowns.
    """
    candidates = [
        {"name": "High Rye Classic", "corn": 65.0, "rye": 25.0, "wheat": 0.0, "barley": 10.0},
        {"name": "Wheated Bourbon Premium", "corn": 74.0, "rye": 0.0, "wheat": 16.0, "barley": 10.0},
        {"name": "Four Grain Balanced", "corn": 70.0, "rye": 12.0, "wheat": 8.0, "barley": 10.0},
        {"name": "Sweet Corn Heavy", "corn": 80.0, "rye": 10.0, "wheat": 0.0, "barley": 10.0},
    ]

    results = []
    twin = BourbonDigitalTwin()

    for cand in candidates:
        gb = GrainBill(
            corn_pct=cand["corn"],
            rye_pct=cand["rye"],
            wheat_pct=cand["wheat"],
            malted_barley_pct=cand["barley"]
        )
        twin_state = twin.run_full_simulation(
            batch_id=f"OPT-{cand['name'].replace(' ', '-')}",
            grain_bill=gb
        )
        bqi = twin_state.bqi_result.bqi if twin_state.bqi_result else 85.0
        cost_p_bottle = twin_state.cost_result.cost_per_750ml_bottle if twin_state.cost_result else 12.50

        # Drivers
        if cand["rye"] > 20.0:
            driver = "High rye increases simulated spice (cinnamon/pepper) and complexity."
        elif cand["wheat"] > 10.0:
            driver = "Wheat yields smoother mouthfeel, reduced heat, and gentle floral sweetness."
        else:
            driver = "High corn maximizes caramelization and initial sweetness."

        results.append({
            "candidate_name": cand["name"],
            "grain_bill": gb.__dict__,
            "predicted_bqi": bqi,
            "cost_per_bottle": cost_p_bottle,
            "flavour_vector": twin_state.flavour_vector.to_dict(),
            "primary_driver": driver
        })

    results.sort(key=lambda x: x["predicted_bqi"], reverse=True)

    return {
        "target_profile": target_profile_name,
        "top_candidates": results,
        "recommended_recipe": results[0],
        "explainability": (
            f"The top candidate '{results[0]['candidate_name']}' achieved a BQI of {results[0]['predicted_bqi']} "
            f"by optimizing the ratio of corn for sweetness with rye/wheat for complexity under legal constraints."
        )
    }
