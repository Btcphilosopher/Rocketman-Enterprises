"""
BOURBON.OS — Distillation Simulation, Fraction Separation & Spirit Character
"""

from typing import Dict, List, Tuple
from bourbon_os.core.models import FermentationState, DistillationState, SpiritCharacter, OffNoteAssessment, FlavourVector
from bourbon_os.chemistry.congeners import calculate_distillation_carryover


def simulate_distillation(
    batch_id: str,
    fermentation_state: FermentationState,
    equipment_type: str = "COLUMN_STILL_DOUBLER",
    reflux_ratio: float = 1.2,
    hearts_cut_start_proof: float = 152.0,
    hearts_cut_end_proof: float = 118.0,
    target_hearts_proof: float = 135.0  # Must be <= 160.0 proof legally
) -> Tuple[DistillationState, SpiritCharacter, FlavourVector, List[OffNoteAssessment]]:
    """
    Simulates distillation separation and calculates unaged distillate spirit character & initial flavour vector.
    Enforces LEGAL constraint: hearts_proof <= 160 proof.
    """
    if target_hearts_proof > 160.0:
        target_hearts_proof = 160.0  # Cap at legal maximum

    # Standard volume distribution based on cuts
    hearts_pct = 70.0
    heads_pct = 8.0
    tails_pct = 20.0
    foreshots_pct = 2.0

    total_wash_volume_l = 5000.0
    total_pure_ethanol_l = total_wash_volume_l * (fermentation_state.final_abv_pct / 100.0)

    hearts_ethanol_l = total_pure_ethanol_l * (hearts_pct / 100.0)
    hearts_volume_l = hearts_ethanol_l / (target_hearts_proof / 200.0)

    heads_volume_l = (total_pure_ethanol_l * (heads_pct / 100.0)) / (155.0 / 200.0)
    tails_volume_l = (total_pure_ethanol_l * (tails_pct / 100.0)) / (80.0 / 200.0)

    distillate_congeners = calculate_distillation_carryover(
        wash_congeners=fermentation_state.congeners_ppm,
        hearts_pct=hearts_pct,
        heads_pct=heads_pct,
        tails_pct=tails_pct,
        reflux_ratio=reflux_ratio
    )

    # Derive 12 Spirit Character Dimensions (0-100)
    esters = distillate_congeners.get("esters", 80.0)
    fusels = distillate_congeners.get("higher_alcohols", 250.0)
    aldehydes = distillate_congeners.get("aldehydes", 15.0)

    spirit = SpiritCharacter(
        fruit=min(100.0, max(0.0, esters * 0.65)),
        spice=min(100.0, max(0.0, 45.0 + (target_hearts_proof - 120.0) * 0.2)),
        grain=min(100.0, max(0.0, 75.0 - (target_hearts_proof - 120.0) * 0.4)), # Lower proof retains more grain/oil
        sweetness=min(100.0, max(0.0, 40.0 + esters * 0.2)),
        oak_potential=65.0,
        floral=min(100.0, max(0.0, esters * 0.35)),
        herbal=25.0,
        roasted=30.0,
        earthy=20.0,
        heat=min(100.0, max(0.0, (target_hearts_proof - 100.0) * 1.1)), # Higher proof = higher initial heat
        body=min(100.0, max(0.0, 85.0 - (target_hearts_proof - 120.0) * 0.5)),
        complexity=min(100.0, max(0.0, 50.0 + (fusels / 10.0)))
    )

    # Initial Unaged White Spirit Flavour Vector
    init_fv = FlavourVector(
        sweetness=round(spirit.sweetness, 1),
        vanilla=10.0,      # Unaged spirit has minimal vanilla prior to oak
        caramel=15.0,      # Minimal caramel prior to oak char pyrolysis
        oak=0.0,           # Zero oak
        fruit=round(spirit.fruit, 1),
        rye_spice=round(spirit.spice, 1),
        pepper=30.0,
        cinnamon=25.0,
        toast=10.0,
        smoke=5.0,
        floral=round(spirit.floral, 1),
        nutty=20.0,
        dried_fruit=15.0,
        tobacco=0.0,
        leather=0.0,
        heat=round(spirit.heat, 1),
        body=round(spirit.body, 1),
        finish=45.0
    )

    # Off-Note Evaluation
    off_notes: List[OffNoteAssessment] = []
    if target_hearts_proof > 152.0:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="OVERLY_HOT",
                probability=0.75,
                severity=5.5,
                confidence=0.85,
                contributing_variables=["high_hearts_proof (>152)"]
            )
        )
    if aldehydes > 25.0:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="SOLVENT_LIKE",
                probability=0.60,
                severity=4.0,
                confidence=0.80,
                contributing_variables=["heads_cut_too_late", "high_acetaldehyde"]
            )
        )

    distillate_state = DistillationState(
        batch_id=batch_id,
        fermentation_batch_id=fermentation_state.batch_id,
        equipment_type=equipment_type,
        reflux_ratio=reflux_ratio,
        cuts={"foreshots_pct": foreshots_pct, "heads_pct": heads_pct, "hearts_pct": hearts_pct, "tails_pct": tails_pct},
        hearts_proof=round(target_hearts_proof, 1),
        hearts_volume_l=round(hearts_volume_l, 1),
        heads_volume_l=round(heads_volume_l, 1),
        tails_volume_l=round(tails_volume_l, 1),
        distillate_congeners=distillate_congeners
    )

    return distillate_state, spirit, init_fv, off_notes
