"""
BOURBON.OS — Warehouse Spatial Digital Twin & Microclimate Simulation
"""

from typing import Dict, List, Any
import random
from bourbon_os.core.models import WarehouseLocation, BarrelSpec


class WarehouseDigitalTwin:
    """
    Simulates rickhouse microclimates (Floor 1-7, Rack 1-12, Row 1-20).
    Top floors experience higher heat and lower humidity (accelerated evaporation, rising proof).
    Bottom floors experience lower heat and higher humidity (slow maturation, falling proof).
    """

    def __init__(self, warehouse_id: str = "RICKHOUSE_A", total_floors: int = 6):
        self.warehouse_id = warehouse_id
        self.total_floors = total_floors

    def get_microclimate(self, floor: int, ambient_temp_c: float = 20.0, ambient_rh_pct: float = 65.0) -> Dict[str, float]:
        temp = ambient_temp_c + (floor - 1) * 1.8
        rh = max(25.0, ambient_rh_pct - (floor - 1) * 4.0)
        return {
            "temperature_c": round(temp, 1),
            "humidity_pct": round(rh, 1),
            "evaporation_rate_annual_pct": round(3.0 + (floor - 1) * 0.7, 2)
        }

    def generate_warehouse_grid(self, barrels_per_floor: int = 100) -> List[Dict[str, Any]]:
        grid = []
        for floor in range(1, self.total_floors + 1):
            climate = self.get_microclimate(floor)
            for b in range(1, barrels_per_floor + 1):
                rack = ((b - 1) // 10) + 1
                row = ((b - 1) % 10) + 1
                grid.append({
                    "warehouse_id": self.warehouse_id,
                    "floor": floor,
                    "rack": rack,
                    "row": row,
                    "temperature_c": climate["temperature_c"],
                    "humidity_pct": climate["humidity_pct"],
                    "evaporation_rate": climate["evaporation_rate_annual_pct"]
                })
        return grid
