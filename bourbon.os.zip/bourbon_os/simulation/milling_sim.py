"""
BOURBON.OS — Milling & Particle Size Distribution Model
"""

from bourbon_os.core.models import GrainBill, MillingState


def simulate_milling(
    grain_bill: GrainBill,
    mill_type: str = "ROLLER_MILL",
    gap_setting_mm: float = 1.2
) -> MillingState:
    """
    Simulates particle size distribution (grist profile), surface area, and accessibility.
    Roller mill produces uniform grist with low flour; Hammer mill produces finer grist with high surface area.
    """
    if mill_type == "HAMMER_MILL":
        fine_pct = min(45.0, 30.0 + (1.5 - gap_setting_mm) * 15.0)
        medium_pct = 50.0
        coarse_pct = max(5.0, 100.0 - fine_pct - medium_pct)
        surface_area = 2.45  # m2/kg
        efficiency = 0.94
        throughput = 1200.0  # kg/hr
        accessibility = 0.95
    else:  # ROLLER_MILL
        fine_pct = min(25.0, 15.0 + (1.5 - gap_setting_mm) * 10.0)
        medium_pct = 65.0
        coarse_pct = max(10.0, 100.0 - fine_pct - medium_pct)
        surface_area = 1.85  # m2/kg
        efficiency = 0.91
        throughput = 1800.0  # kg/hr
        accessibility = 0.89

    return MillingState(
        grain_bill=grain_bill,
        grist_fine_pct=round(fine_pct, 1),
        grist_medium_pct=round(medium_pct, 1),
        grist_coarse_pct=round(coarse_pct, 1),
        surface_area_m2_kg=round(surface_area, 2),
        milling_efficiency=round(efficiency, 3),
        throughput_kg_hr=round(throughput, 1),
        accessibility_factor=round(accessibility, 3)
    )
