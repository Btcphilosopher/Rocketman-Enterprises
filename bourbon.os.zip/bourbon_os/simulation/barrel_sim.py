"""
BOURBON.OS — Barrel Digital Twin & Maturation Trajectory Simulator
"""

from typing import List, Tuple, Dict
from bourbon_os.core.models import BarrelSpec, MaturationPoint, MaturationTrajectory, FlavourVector, OffNoteAssessment, BQIResult, SpiritCharacter
from bourbon_os.chemistry.maturation_chem import calculate_oak_extraction, calculate_angels_share_and_proof
from bourbon_os.core.bqi import BQIEngine


def simulate_barrel_maturation(
    barrel_spec: BarrelSpec,
    initial_flavour: FlavourVector,
    spirit_character: SpiritCharacter,
    target_age_months: float = 72.0, # 6 Years default
    avg_temp_c: float = 22.0,
    avg_humidity_pct: float = 62.0
) -> Tuple[MaturationTrajectory, MaturationPoint, FlavourVector, List[OffNoteAssessment], BQIResult]:
    """
    Simulates maturation timeline month by month for a barrel digital twin.
    Calculates oak extraction, Angel's share, proof evolution, flavour vector trajectory, optimal bottling window.
    """
    points: List[MaturationPoint] = []
    
    current_vol = barrel_spec.initial_volume_l
    current_proof = barrel_spec.fill_proof

    bqi_engine = BQIEngine()

    best_quality = 0.0
    peak_age = 48.0
    over_oak_age = 120.0

    # Step through maturation timeline in 6-month steps
    steps = int(target_age_months / 6.0)
    final_fv = FlavourVector(**initial_flavour.to_dict())

    for step in range(1, steps + 1):
        age = step * 6.0
        
        # Oak extractives
        oak_dict = calculate_oak_extraction(
            age_months=age,
            char_level=barrel_spec.char_level,
            fill_proof=barrel_spec.fill_proof,
            temp_c=avg_temp_c
        )

        # Evaporation & Proof
        vol, proof, lost_l, lovibond = calculate_angels_share_and_proof(
            initial_vol_l=barrel_spec.initial_volume_l,
            initial_proof=barrel_spec.fill_proof,
            age_months=age,
            avg_temp_c=avg_temp_c,
            avg_humidity_pct=avg_humidity_pct,
            warehouse_floor=barrel_spec.floor
        )

        # Evolve Flavour Vector based on Oak + Oxidation + Age
        vanilla_score = min(100.0, initial_flavour.vanilla + oak_dict["vanillin"] * 4.2)
        caramel_score = min(100.0, initial_flavour.caramel + oak_dict["caramel_compounds"] * 2.8)
        oak_score = min(100.0, oak_dict["total_extractives"] * 0.95)
        
        # Spice integration
        rye_spice = max(20.0, initial_flavour.rye_spice * math.exp(-age / 180.0) + oak_dict["eugenol"] * 3.0)
        
        # Heat softens over time due to ethanol-water esterification & oxidation
        softened_heat = max(20.0, initial_flavour.heat * math.exp(-age / 48.0))
        
        # Body & Finish increase with age
        matured_body = min(98.0, initial_flavour.body + (age / 12.0) * 3.5)
        matured_finish = min(98.0, initial_flavour.finish + (age / 12.0) * 4.0)

        step_fv = FlavourVector(
            sweetness=round(min(100.0, initial_flavour.sweetness + caramel_score * 0.2), 1),
            vanilla=round(vanilla_score, 1),
            caramel=round(caramel_score, 1),
            oak=round(oak_score, 1),
            fruit=round(max(10.0, initial_flavour.fruit * math.exp(-age / 96.0) + 15.0), 1),
            rye_spice=round(rye_spice, 1),
            pepper=round(max(15.0, initial_flavour.pepper * 0.8), 1),
            cinnamon=round(min(90.0, initial_flavour.cinnamon + oak_dict["eugenol"] * 2.5), 1),
            toast=round(min(90.0, initial_flavour.toast + (barrel_spec.char_level * 8.0)), 1),
            smoke=round(min(80.0, 5.0 + (barrel_spec.char_level * 7.5)), 1),
            floral=round(max(5.0, initial_flavour.floral * 0.7), 1),
            nutty=round(min(85.0, 20.0 + oak_dict["vanillin"] * 2.0), 1),
            dried_fruit=round(min(90.0, 15.0 + (age / 12.0) * 3.5), 1),
            tobacco=round(min(85.0, max(0.0, (age - 36.0) * 0.8)), 1),
            leather=round(min(85.0, max(0.0, (age - 48.0) * 0.9)), 1),
            heat=round(softened_heat, 1),
            body=round(matured_body, 1),
            finish=round(matured_finish, 1)
        )

        pt = MaturationPoint(
            age_months=age,
            temperature_c=avg_temp_c,
            humidity_pct=avg_humidity_pct,
            current_volume_l=vol,
            current_proof=proof,
            angels_share_loss_l=lost_l,
            oak_extractives_ppm=oak_dict["total_extractives"],
            color_lovibond=lovibond,
            flavour_vector=step_fv.to_dict()
        )
        points.append(pt)

        # Track quality peak
        step_bqi = bqi_engine.calculate_bqi(
            flavour=step_fv,
            spirit=spirit_character,
            maturation=pt,
            off_notes=[]
        )
        if step_bqi.bqi > best_quality:
            best_quality = step_bqi.bqi
            peak_age = age

        if age >= target_age_months:
            final_fv = step_fv

    # Off-Note Evaluation for Barrel
    off_notes: List[OffNoteAssessment] = []
    if final_fv.oak > 85.0:
        off_notes.append(
            OffNoteAssessment(
                off_note_type="EXCESSIVE_OAK",
                probability=0.85,
                severity=6.0,
                confidence=0.90,
                contributing_variables=["over_age (>8_years)", "high_extractives_ppm"]
            )
        )

    final_maturation = points[-1]
    final_bqi = bqi_engine.calculate_bqi(
        flavour=final_fv,
        spirit=spirit_character,
        maturation=final_maturation,
        off_notes=off_notes
    )

    trajectory = MaturationTrajectory(
        barrel_id=barrel_spec.barrel_id,
        points=points,
        peak_quality_age_months=peak_age,
        over_oak_risk_age_months=peak_age + 48.0,
        optimal_window_start_months=max(24.0, peak_age - 12.0),
        optimal_window_end_months=peak_age + 24.0
    )

    return trajectory, final_maturation, final_fv, off_notes, final_bqi
