"""
BOURBON.OS — Fermentation Engine & Digital Twin Time-Series Simulator
"""

import math
from typing import List, Tuple
from bourbon_os.core.models import MashState, YeastProfile, FermentationState, FermentationTimeSeriesPoint
from bourbon_os.chemistry.congeners import calculate_fermentation_congeners


def simulate_fermentation(
    batch_id: str,
    mash_state: MashState,
    yeast_profile: YeastProfile,
    pitch_temp_c: float = 24.0,
    duration_hours: float = 72.0,
    simulate_stall: bool = False
) -> FermentationState:
    """
    Simulates time-series fermentation kinetics (sugar consumption -> ethanol + CO2 + congeners).
    Returns FermentationState with full time-series curve and anomaly detection flags.
    """
    initial_sg = mash_state.gravity_sg
    initial_sugar_g_l = (initial_sg - 1.0) / 0.00385  # ~140-160 g/L fermentable sugars
    
    time_points: List[FermentationTimeSeriesPoint] = []
    
    current_sg = initial_sg
    current_sugar = initial_sugar_g_l
    current_ph = mash_state.ph
    current_abv = 0.0

    steps = int(duration_hours / 4.0)
    for i in range(steps + 1):
        t = i * 4.0
        
        # Fermentation curve kinetics (logistic kinetic rate)
        k = yeast_profile.fermentation_rate_k * (1.0 + (pitch_temp_c - 24.0) * 0.02)
        if simulate_stall and t > 36.0:
            k *= 0.1  # Severe rate drop simulating yeast exhaustion / nutrient lack / temperature spike

        # Temperature rises due to exothermic fermentation reaction
        exotherm = 4.0 * math.sin(min(math.pi, (t / 48.0) * math.pi)) if t <= 48.0 else 2.0
        temp_t = pitch_temp_c + exotherm

        # Sugar consumption & ethanol production
        consumed_sugar_pct = 1.0 / (1.0 + math.exp(-k * (t - 24.0))) if t > 0 else 0.0
        current_sugar = max(2.0, initial_sugar_g_l * (1.0 - (consumed_sugar_pct * (yeast_profile.attenuation_pct / 100.0))))
        
        # Specific gravity drops
        sugar_consumed_g_l = initial_sugar_g_l - current_sugar
        current_abv = (sugar_consumed_g_l * 0.51) / 7.89 # Ethanol yield ~0.51 g ethanol / g sugar
        current_sg = max(0.992, initial_sg - (current_abv * 0.00135))

        # pH drops due to organic acid production
        current_ph = max(3.8, mash_state.ph - (0.8 * (sugar_consumed_g_l / initial_sugar_g_l)))

        rate = (sugar_consumed_g_l / (t + 1e-5)) if t > 0 else 0.0

        time_points.append(
            FermentationTimeSeriesPoint(
                time_hours=t,
                temperature_c=round(temp_t, 1),
                specific_gravity=round(current_sg, 4),
                ph=round(current_ph, 2),
                estimated_abv_pct=round(current_abv, 2),
                fermentation_rate=round(rate, 2),
                sugars_g_l=round(current_sugar, 1)
            )
        )

    # Anomaly Detection
    is_stalled = False
    anomaly_msg = None

    if simulate_stall or (current_abv < (initial_sg - 1.0) * 1000.0 * 0.06):
        is_stalled = True
        anomaly_msg = "WARNING: Fermentation trajectory stalled before target attenuation (high residual sugar)."

    # Calculate final congeners
    congeners = calculate_fermentation_congeners(
        yeast_ester_tendency=yeast_profile.ester_tendency,
        yeast_fusel_tendency=yeast_profile.higher_alcohol_tendency,
        yeast_acid_tendency=yeast_profile.acid_tendency,
        pitch_temp_c=pitch_temp_c,
        fermentation_hours=duration_hours,
        gravity_sg=initial_sg
    )

    return FermentationState(
        batch_id=batch_id,
        mash_batch_id=mash_state.batch_id,
        yeast_profile=yeast_profile,
        pitch_temp_c=pitch_temp_c,
        duration_hours=duration_hours,
        time_series=time_points,
        final_abv_pct=round(current_abv, 2),
        final_gravity=round(current_sg, 4),
        residual_sugar_g_l=round(current_sugar, 1),
        congeners_ppm=congeners,
        is_stalled=is_stalled,
        anomaly_flag=anomaly_msg
    )
