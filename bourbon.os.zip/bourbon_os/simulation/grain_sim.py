"""
BOURBON.OS — Grain Lot & Raw Material Variability Simulation
"""

import random
from typing import List
from bourbon_os.core.models import GrainLot, GrainBill


def generate_synthetic_grain_lots(count: int = 100, seed: int = 42) -> List[GrainLot]:
    """
    Generates a realistic synthetic database of grain lots with natural agricultural variability.
    """
    random.seed(seed)
    grain_types = ["CORN", "RYE", "WHEAT", "MALTED_BARLEY"]
    origins = ["Kentucky, USA", "Indiana, USA", "Illinois, USA", "Ohio, USA", "Ontario, Canada"]
    suppliers = ["AgriCrop Co", "Highland Grist", "Midwest Grains", "Bluegrass Malting"]

    lots = []
    for i in range(count):
        gtype = random.choice(grain_types)
        if gtype == "CORN":
            starch = random.gauss(68.0, 1.5)
            protein = random.gauss(8.5, 0.6)
            moisture = random.gauss(13.0, 0.8)
            diastatic = 0.0
            cost = random.gauss(0.28, 0.02)
        elif gtype == "RYE":
            starch = random.gauss(60.0, 1.8)
            protein = random.gauss(11.0, 0.8)
            moisture = random.gauss(12.5, 0.7)
            diastatic = 15.0
            cost = random.gauss(0.42, 0.03)
        elif gtype == "WHEAT":
            starch = random.gauss(64.0, 1.6)
            protein = random.gauss(10.5, 0.7)
            moisture = random.gauss(12.0, 0.6)
            diastatic = 10.0
            cost = random.gauss(0.38, 0.025)
        else: # MALTED_BARLEY
            starch = random.gauss(58.0, 2.0)
            protein = random.gauss(11.5, 0.9)
            moisture = random.gauss(10.5, 0.5)
            diastatic = random.gauss(135.0, 10.0)
            cost = random.gauss(0.65, 0.05)

        lot = GrainLot(
            lot_id=f"LOT-{gtype[:3]}-{i+101:04d}",
            grain_type=gtype,
            supplier=random.choice(suppliers),
            origin=random.choice(origins),
            moisture_pct=round(max(8.0, min(16.0, moisture)), 2),
            protein_pct=round(max(6.0, min(15.0, protein)), 2),
            starch_potential_pct=round(max(50.0, min(75.0, starch)), 2),
            diastatic_power_lintner=round(max(0.0, diastatic), 1),
            batch_variability=round(random.uniform(0.02, 0.06), 3),
            cost_per_kg=round(max(0.1, cost), 3),
            inventory_kg=round(random.uniform(5000.0, 25000.0), 1)
        )
        lots.append(lot)
    return lots
