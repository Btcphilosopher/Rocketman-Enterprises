"""
BOURBON.OS — Master Unified Digital Twin Simulator
Connecting GRAIN -> MASH -> FERMENTATION -> DISTILLATION -> SPIRIT -> BARREL -> MATURATION -> PROOFING -> BQI
"""

from typing import Dict, Any, Optional, Tuple
from bourbon_os.core.models import (
    GrainBill, WaterProfile, YeastProfile, BarrelSpec, DigitalTwinState,
    MillingState, MashState, FermentationState, DistillationState, SpiritCharacter,
    FlavourVector, BQIResult, CostModelResult
)
from bourbon_os.simulation.milling_sim import simulate_milling
from bourbon_os.simulation.mash_sim import simulate_mash
from bourbon_os.simulation.fermentation_sim import simulate_fermentation
from bourbon_os.simulation.distillation_sim import simulate_distillation
from bourbon_os.simulation.barrel_sim import simulate_barrel_maturation
from bourbon_os.simulation.proofing_sim import simulate_proofing


class BourbonDigitalTwin:
    """
    Unified Production Digital Twin Simulator orchestrating the entire lifecycle.
    """

    def __init__(self, recipe_id: str = "RECIPE-CLASSIC-01", recipe_name: str = "Kentucky Classic Bourbon"):
        self.recipe_id = recipe_id
        self.recipe_name = recipe_name

    def run_full_simulation(
        self,
        batch_id: str = "BATCH-2026-001",
        grain_bill: GrainBill = None,
        yeast_profile: YeastProfile = None,
        barrel_spec: BarrelSpec = None,
        target_age_months: float = 72.0,
        target_proofing_proof: float = 90.0,
        simulate_stall: bool = False
    ) -> DigitalTwinState:
        
        if grain_bill is None:
            grain_bill = GrainBill(corn_pct=72.0, rye_pct=18.0, wheat_pct=0.0, malted_barley_pct=10.0)

        if yeast_profile is None:
            yeast_profile = YeastProfile(
                yeast_id="Y-BBN-01",
                name="Heritage Bourbon Yeast A",
                attenuation_pct=83.0,
                optimal_temp_c=26.0,
                fermentation_rate_k=0.12,
                ester_tendency=7.2,
                higher_alcohol_tendency=6.0,
                acid_tendency=4.5,
                flavor_note="Rich stone fruit, vanilla precursor"
            )

        if barrel_spec is None:
            barrel_spec = BarrelSpec(
                barrel_id=f"BRL-{batch_id}-01",
                wood_type="American White Oak (Quercus alba)",
                toast_level="Medium Plus",
                char_level=4,
                volume_capacity_l=200.0,
                fill_proof=120.0,
                warehouse_id="RICKHOUSE_A",
                floor=4,
                rack=5,
                row=8,
                fill_date="2026-09-09",
                initial_volume_l=200.0
            )

        # 1. Milling
        milling_state = simulate_milling(grain_bill=grain_bill, mill_type="ROLLER_MILL")

        # 2. Mash
        mash_state = simulate_mash(
            batch_id=f"MSH-{batch_id}",
            grain_bill=grain_bill,
            total_grain_kg=1000.0,
            milling_state=milling_state
        )

        # 3. Fermentation
        ferm_state = simulate_fermentation(
            batch_id=f"FRM-{batch_id}",
            mash_state=mash_state,
            yeast_profile=yeast_profile,
            duration_hours=72.0,
            simulate_stall=simulate_stall
        )

        # 4. Distillation
        dist_state, spirit_char, init_fv, dist_off_notes = simulate_distillation(
            batch_id=f"DST-{batch_id}",
            fermentation_state=ferm_state,
            target_hearts_proof=135.0
        )

        # 5. Barrel Entry & Maturation
        mat_trajectory, final_mat_point, final_fv, barrel_off_notes, bqi_result = simulate_barrel_maturation(
            barrel_spec=barrel_spec,
            initial_flavour=init_fv,
            spirit_character=spirit_char,
            target_age_months=target_age_months
        )

        # 6. Proofing & Bottling
        final_vol, final_proof, water_added, mass_bal, reg_note = simulate_proofing(
            cask_volume_l=final_mat_point.current_volume_l,
            cask_proof=final_mat_point.current_proof,
            target_proof=target_proofing_proof
        )

        # 7. Cost Calculation
        grain_cost = 1000.0 * 0.35
        barrel_cost = 280.0
        warehouse_cost = (target_age_months / 12.0) * 15.0
        energy_labor = 450.0
        total_cost = grain_cost + barrel_cost + warehouse_cost + energy_labor
        cost_per_litre = total_cost / (final_vol * (final_proof / 200.0))
        cost_per_bottle = total_cost / mass_bal["bottles_750ml"]

        cost_res = CostModelResult(
            grain_cost=round(grain_cost, 2),
            water_energy_cost=150.0,
            yeast_cost=45.0,
            labor_cost=300.0,
            barrel_cost=barrel_cost,
            warehouse_storage_cost=round(warehouse_cost, 2),
            bottling_cost=120.0,
            total_batch_cost=round(total_cost, 2),
            cost_per_litre_proof_spirit=round(cost_per_litre, 2),
            cost_per_750ml_bottle=round(cost_per_bottle, 2)
        )

        return DigitalTwinState(
            batch_id=batch_id,
            recipe_id=self.recipe_id,
            recipe_name=self.recipe_name,
            current_stage="BOTTLING",
            grain_bill=grain_bill,
            mash_state=mash_state,
            fermentation_state=ferm_state,
            distillation_state=dist_state,
            spirit_character=spirit_char,
            barrel_spec=barrel_spec,
            maturation_state=final_mat_point,
            flavour_vector=final_fv,
            bqi_result=bqi_result,
            cost_result=cost_res,
            yield_litres_proof=round(final_vol * (final_proof / 200.0), 1),
            uncertainty_pct=4.2
        )
