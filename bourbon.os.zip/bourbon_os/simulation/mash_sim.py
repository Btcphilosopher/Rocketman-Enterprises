"""
BOURBON.OS — Mashing Simulation
"""

from bourbon_os.core.models import GrainBill, WaterProfile, MillingState, MashState
from bourbon_os.chemistry.mashing_chem import calculate_mashing_kinetics


def simulate_mash(
    batch_id: str,
    grain_bill: GrainBill,
    total_grain_kg: float = 1000.0,
    water_to_grain_ratio: float = 3.8,
    water_profile: WaterProfile = None,
    milling_state: MillingState = None,
    mash_temp_c: float = 65.0,
    duration_minutes: float = 90.0
) -> MashState:
    """
    Simulates mashing stage and returns a detailed MashState.
    """
    if water_profile is None:
        water_profile = WaterProfile()

    corn_kg = total_grain_kg * (grain_bill.corn_pct / 100.0)
    rye_kg = total_grain_kg * (grain_bill.rye_pct / 100.0)
    wheat_kg = total_grain_kg * (grain_bill.wheat_pct / 100.0)
    barley_kg = total_grain_kg * (grain_bill.malted_barley_pct / 100.0)

    total_water_l = total_grain_kg * water_to_grain_ratio

    starch_converted, fermentable_sugars, dextrins, sg = calculate_mashing_kinetics(
        corn_kg=corn_kg,
        rye_kg=rye_kg,
        wheat_kg=wheat_kg,
        barley_kg=barley_kg,
        water_l=total_water_l,
        temp_c=mash_temp_c,
        duration_min=duration_minutes,
        water_ph=water_profile.ph,
        calcium_ppm=water_profile.calcium_ppm
    )

    alpha_act = 85.0 if mash_temp_c >= 68.0 else 60.0
    beta_act = 90.0 if mash_temp_c <= 66.0 else 40.0

    return MashState(
        batch_id=batch_id,
        milling_state=milling_state if milling_state else MillingState(grain_bill, 20.0, 60.0, 20.0, 2.0, 0.92, 1500.0, 0.90),
        water_profile=water_profile,
        water_to_grain_ratio=water_to_grain_ratio,
        total_grain_kg=total_grain_kg,
        total_water_l=total_water_l,
        temp_profile_c=[mash_temp_c],
        duration_minutes=duration_minutes,
        alpha_amylase_activity=alpha_act,
        beta_amylase_activity=beta_act,
        starch_conversion_pct=round((starch_converted / (total_grain_kg * 0.65)) * 100.0, 1),
        fermentable_extract_kg=fermentable_sugars,
        gravity_sg=sg,
        ph=round(max(5.0, min(5.8, water_profile.ph - 0.2)), 2)
    )
