"""
BOURBON.OS — Controlled Proofing Engine & Water Quality Dilution Model
"""

from typing import Dict, Tuple
from bourbon_os.core.models import WaterProfile


def simulate_proofing(
    cask_volume_l: float,
    cask_proof: float,
    target_proof: float = 90.0, # e.g. 90 proof / 45% ABV
    proofing_water: WaterProfile = None
) -> Tuple[float, float, float, Dict[str, float], str]:
    """
    Calculates water addition, volume expansion/contraction, final ABV, and mass balance.
    Distinguishes model calculations from regulatory lab hydrometer / densitometer verification.
    """
    if proofing_water is None:
        proofing_water = WaterProfile(ph=6.8, calcium_ppm=10.0, tds_ppm=35.0) # RO purified water

    if target_proof > cask_proof:
        target_proof = cask_proof  # Cannot increase proof with water addition

    # Proof = 2 * ABV%
    initial_abv = cask_proof / 2.0
    target_abv = target_proof / 2.0

    # Pure ethanol volume (L)
    pure_ethanol_l = cask_volume_l * (initial_abv / 100.0)

    # Theoretical volume = pure_ethanol / target_abv
    theoretical_final_vol_l = pure_ethanol_l / (target_abv / 100.0)
    water_addition_l = theoretical_final_vol_l - cask_volume_l

    # Ethanol-water volumetric contraction (typically ~0.2% - 0.5% volume loss on dilution)
    contraction_factor = 0.9975
    actual_final_vol_l = theoretical_final_vol_l * contraction_factor
    actual_final_proof = (pure_ethanol_l / actual_final_vol_l) * 200.0

    # Number of standard 750ml bottles produced
    bottles_750ml = math.floor(actual_final_vol_l / 0.75)

    mass_balance = {
        "initial_cask_vol_l": round(cask_volume_l, 2),
        "water_added_l": round(water_addition_l, 2),
        "contraction_loss_l": round(theoretical_final_vol_l - actual_final_vol_l, 2),
        "final_volume_l": round(actual_final_vol_l, 2),
        "bottles_750ml": bottles_750ml,
        "pure_ethanol_l": round(pure_ethanol_l, 2)
    }

    regulatory_note = (
        "CALCULATION NOTICE: Proofing values are model estimates. "
        "TTB regulations require official proof determination via density meter (e.g. Anton Paar DMA) "
        "or calibrated hydrometer at 60 deg F prior to bottling taxation."
    )

    return (
        round(actual_final_vol_l, 2),
        round(actual_final_proof, 1),
        round(water_addition_l, 2),
        mass_balance,
        regulatory_note
    )


import math
