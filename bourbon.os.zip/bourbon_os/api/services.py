"""
BOURBON.OS — Service API Layer
Unified High-Level Interface for Simulation, Optimisation, Analytics & Digital Twin Management
"""

from typing import Dict, List, Any, Optional
import json
from bourbon_os.core.models import GrainBill, WaterProfile, YeastProfile, BarrelSpec, FlavourVector
from bourbon_os.simulation.digital_twin import BourbonDigitalTwin
from bourbon_os.optimisation.recipe_opt import optimize_recipe
from bourbon_os.optimisation.blend_opt import optimize_blend
from bourbon_os.optimisation.monte_carlo import run_monte_carlo_simulation
from bourbon_os.optimisation.sensitivity import run_sensitivity_analysis
from bourbon_os.optimisation.pareto_opt import calculate_pareto_frontier
from bourbon_os.optimisation.bayesian_opt import run_bayesian_experiment_design
from bourbon_os.machine_learning.surrogate_models import BourbonQualityMLPredictor
from bourbon_os.database.db import get_connection, init_db, log_audit_event
from bourbon_os.database.seed_data import seed_database
from bourbon_os.compliance.regulatory import RegulatoryComplianceChecker


def api_seed_database() -> Dict[str, Any]:
    seed_database()
    log_audit_event("SYSTEM", "SEED_DATABASE", "DATABASE", "BOURBON_OS_DB", {"status": "SUCCESS"})
    return {"status": "SUCCESS", "message": "Database seeded with 120 grain lots, 4 recipes, and 500 barrels."}


def api_run_digital_twin_simulation(
    corn_pct: float = 70.0,
    rye_pct: float = 20.0,
    wheat_pct: float = 0.0,
    barley_pct: float = 10.0,
    target_age_months: float = 72.0,
    simulate_stall: bool = False
) -> Dict[str, Any]:
    gb = GrainBill(corn_pct=corn_pct, rye_pct=rye_pct, wheat_pct=wheat_pct, malted_barley_pct=barley_pct)
    validation_errs = gb.validate()
    if validation_errs:
        return {"status": "ERROR", "errors": validation_errs}

    twin = BourbonDigitalTwin()
    state = twin.run_full_simulation(
        batch_id="SIM-BATCH-LIVE",
        grain_bill=gb,
        target_age_months=target_age_months,
        simulate_stall=simulate_stall
    )

    log_audit_event("OPERATOR", "RUN_SIMULATION", "BATCH", state.batch_id, {"bqi": state.bqi_result.bqi if state.bqi_result else None})

    return {
        "status": "SUCCESS",
        "batch_id": state.batch_id,
        "recipe_name": state.recipe_name,
        "grain_bill": state.grain_bill.__dict__,
        "mash_state": {
            "gravity_sg": state.mash_state.gravity_sg,
            "fermentable_extract_kg": state.mash_state.fermentable_extract_kg,
            "starch_conversion_pct": state.mash_state.starch_conversion_pct
        } if state.mash_state else None,
        "fermentation_state": {
            "final_abv_pct": state.fermentation_state.final_abv_pct,
            "final_gravity": state.fermentation_state.final_gravity,
            "is_stalled": state.fermentation_state.is_stalled,
            "anomaly_flag": state.fermentation_state.anomaly_flag,
            "time_series": [t.__dict__ for t in state.fermentation_state.time_series]
        } if state.fermentation_state else None,
        "distillation_state": {
            "hearts_proof": state.distillation_state.hearts_proof,
            "hearts_volume_l": state.distillation_state.hearts_volume_l,
            "congeners": state.distillation_state.distillate_congeners
        } if state.distillation_state else None,
        "maturation_state": {
            "age_months": state.maturation_state.age_months,
            "current_volume_l": state.maturation_state.current_volume_l,
            "current_proof": state.maturation_state.current_proof,
            "color_lovibond": state.maturation_state.color_lovibond
        } if state.maturation_state else None,
        "flavour_vector": state.flavour_vector.to_dict(),
        "bqi_result": state.bqi_result.__dict__ if state.bqi_result else None,
        "cost_result": state.cost_result.__dict__ if state.cost_result else None,
        "yield_litres_proof": state.yield_litres_proof
    }


def api_optimise_blend(
    target_flavour_dict: Dict[str, float]
) -> Dict[str, Any]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM barrels WHERE status = 'MATURING' ORDER BY current_age_months DESC LIMIT 25")
    rows = cursor.fetchall()
    conn.close()

    available_barrels = []
    for r in rows:
        # Generate synthetic flavour vector for barrel based on age
        age_m = r["current_age_months"]
        fv = FlavourVector(
            sweetness=round(min(90.0, 45.0 + age_m * 0.3), 1),
            vanilla=round(min(95.0, age_m * 0.75), 1),
            caramel=round(min(95.0, age_m * 0.70), 1),
            oak=round(min(95.0, age_m * 0.80), 1),
            rye_spice=round(55.0, 1),
            body=round(min(95.0, 50.0 + age_m * 0.4), 1),
            finish=round(min(95.0, 50.0 + age_m * 0.45), 1)
        )
        available_barrels.append({
            "barrel_id": r["barrel_id"],
            "warehouse_id": r["warehouse_id"],
            "floor": r["floor"],
            "age_months": r["current_age_months"],
            "current_volume_l": r["current_volume_l"],
            "flavour_vector": fv.to_dict()
        })

    target_fv = FlavourVector.from_dict(target_flavour_dict)
    res = optimize_blend(target_flavour=target_fv, available_barrels=available_barrels)
    return res


def api_rank_barrels(limit: int = 50) -> List[Dict[str, Any]]:
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM barrels ORDER BY current_age_months DESC LIMIT ?", (limit,))
    rows = cursor.fetchall()
    conn.close()

    barrels = []
    for r in rows:
        age_m = r["current_age_months"]
        bqi_estimate = min(96.0, 72.0 + (age_m / 12.0) * 3.5)
        if age_m > 108.0:
            bqi_estimate -= (age_m - 108.0) * 0.2
        
        status = "PEAK_MATURITY" if 60 <= age_m <= 96 else ("APPROACHING_PEAK" if age_m < 60 else "OVER_OAK_RISK")

        barrels.append({
            "barrel_id": r["barrel_id"],
            "warehouse_id": r["warehouse_id"],
            "floor": r["floor"],
            "rack": r["rack"],
            "row": r["row"],
            "char_level": r["char_level"],
            "age_months": age_m,
            "current_volume_l": r["current_volume_l"],
            "current_proof": r["current_proof"],
            "estimated_bqi": round(bqi_estimate, 1),
            "maturity_status": status
        })
    return barrels


def api_get_genealogy(bottle_id: str = "BOTTLE-BATCH-2026-001") -> Dict[str, Any]:
    return {
        "bottle_id": bottle_id,
        "blend": {
            "blend_id": "BLEND-HERITAGE-SELECT-01",
            "barrels": [
                {"barrel_id": "BRL-RIC-F4-0012", "weight_pct": 40.0, "age_months": 72.0},
                {"barrel_id": "BRL-RIC-F5-0045", "weight_pct": 35.0, "age_months": 84.0},
                {"barrel_id": "BRL-RIC-F3-0089", "weight_pct": 25.0, "age_months": 60.0}
            ]
        },
        "distillation_batch": "DST-BATCH-2020-03-A",
        "fermentation_batch": "FRM-BATCH-2020-03-A",
        "mash_batch": "MSH-BATCH-2020-03-A",
        "grain_lots": [
            {"grain_type": "CORN", "lot_id": "LOT-COR-0102", "supplier": "Midwest Grains", "origin": "Kentucky, USA"},
            {"grain_type": "RYE", "lot_id": "LOT-RYE-0145", "supplier": "AgriCrop Co", "origin": "Ohio, USA"},
            {"grain_type": "MALTED_BARLEY", "lot_id": "LOT-MAL-0201", "supplier": "Bluegrass Malting", "origin": "Indiana, USA"}
        ]
    }
