"""
BOURBON.OS — Configurable TTB Regulatory Compliance Engine (27 CFR Part 5)
Flags compliance warnings for human operator verification.
"""

from typing import Dict, List, Any
from bourbon_os.core.models import GrainBill, DistillationState, BarrelSpec


class RegulatoryComplianceChecker:
    """
    Checks parameters against US Federal Standards of Identity for Bourbon Whiskey (27 CFR § 5.143).
    """

    def check_bourbon_compliance(
        self,
        grain_bill: GrainBill,
        distillation_hearts_proof: float,
        barrel_entry_proof: float,
        bottling_proof: float,
        maturation_age_years: float,
        wood_type: str,
        has_added_flavoring_or_coloring: bool = False
    ) -> Dict[str, Any]:
        flags: List[Dict[str, str]] = []
        is_compliant = True

        # 1. Grain bill: Must be at least 51% corn
        if grain_bill.corn_pct < 51.0:
            is_compliant = False
            flags.append({
                "rule": "GRAIN_BILL_CORN_MINIMUM",
                "severity": "CRITICAL_NON_COMPLIANT",
                "message": f"Corn percentage is {grain_bill.corn_pct:.1f}%. Legal minimum for Bourbon is 51.0%."
            })

        # 2. Distillation proof: Maximum 160 proof (80% ABV)
        if distillation_hearts_proof > 160.0:
            is_compliant = False
            flags.append({
                "rule": "DISTILLATION_PROOF_MAXIMUM",
                "severity": "CRITICAL_NON_COMPLIANT",
                "message": f"Distillation proof is {distillation_hearts_proof:.1f}. Legal maximum for Bourbon is 160.0 proof."
            })

        # 3. Barrel entry proof: Maximum 125 proof (62.5% ABV)
        if barrel_entry_proof > 125.0:
            is_compliant = False
            flags.append({
                "rule": "BARREL_ENTRY_PROOF_MAXIMUM",
                "severity": "CRITICAL_NON_COMPLIANT",
                "message": f"Barrel entry proof is {barrel_entry_proof:.1f}. Legal maximum for Bourbon is 125.0 proof."
            })

        # 4. Container type: Must be charred new oak containers
        if "new" not in wood_type.lower() or "char" not in wood_type.lower():
            flags.append({
                "rule": "CONTAINER_CHARRED_NEW_OAK",
                "severity": "WARNING_REVIEW_REQUIRED",
                "message": "Container must be charred new oak. Verify barrel specification certification."
            })

        # 5. Bottling proof: Minimum 80 proof (40% ABV)
        if bottling_proof < 80.0:
            is_compliant = False
            flags.append({
                "rule": "BOTTLING_PROOF_MINIMUM",
                "severity": "CRITICAL_NON_COMPLIANT",
                "message": f"Bottling proof is {bottling_proof:.1f}. Legal minimum for Bourbon is 80.0 proof."
            })

        # 6. Coloring/Flavoring: No added color or flavor allowed in Bourbon
        if has_added_flavoring_or_coloring:
            is_compliant = False
            flags.append({
                "rule": "NO_ADDED_COLOR_OR_FLAVOR",
                "severity": "CRITICAL_NON_COMPLIANT",
                "message": "Bourbon whiskey cannot contain added coloring, flavoring, or blending materials."
            })

        # Classification badges
        classifications = ["BOURBON_WHISKEY"]
        if maturation_age_years >= 2.0 and is_compliant:
            classifications.append("STRAIGHT_BOURBON_WHISKEY")
        if maturation_age_years >= 4.0 and bottling_proof == 100.0 and is_compliant:
            classifications.append("BOTTLED_IN_BOND")

        return {
            "is_compliant": is_compliant,
            "classifications_eligible": classifications,
            "compliance_flags": flags,
            "human_verification_notice": "Disclaimer: Software checks are decision-support recommendations. Regulatory compliance requires official laboratory proof verification and COLA TTB label approval."
        }
