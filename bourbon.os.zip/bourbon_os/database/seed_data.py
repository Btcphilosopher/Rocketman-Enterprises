"""
BOURBON.OS — Synthetic Dataset Generator (100+ Grain Lots, 100+ Batches, 500+ Barrels)
"""

import random
import json
import sqlite3
from bourbon_os.database.db import get_connection, init_db
from bourbon_os.simulation.grain_sim import generate_synthetic_grain_lots
from bourbon_os.core.models import FlavourVector, GrainBill
from bourbon_os.simulation.digital_twin import BourbonDigitalTwin


def seed_database():
    """
    Populates SQLite database with 100+ grain lots, 100+ fermentation/distillation batches,
    500+ barrels across 3 warehouses, sensory panel evaluations, and lab results.
    """
    init_db()
    conn = get_connection()
    cursor = conn.cursor()

    # Clear existing synthetic data
    cursor.execute("DELETE FROM grain_lots")
    cursor.execute("DELETE FROM recipes")
    cursor.execute("DELETE FROM barrels")
    cursor.execute("DELETE FROM warehouse_locations")
    cursor.execute("DELETE FROM sensory_evaluations")
    cursor.execute("DELETE FROM lab_results")

    # 1. Seed 100+ Grain Lots
    grain_lots = generate_synthetic_grain_lots(count=120, seed=42)
    for gl in grain_lots:
        cursor.execute("""
            INSERT INTO grain_lots (lot_id, grain_type, supplier, origin, moisture_pct, protein_pct,
                                   starch_potential_pct, diastatic_power_lintner, batch_variability, cost_per_kg, inventory_kg)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (gl.lot_id, gl.grain_type, gl.supplier, gl.origin, gl.moisture_pct, gl.protein_pct,
              gl.starch_potential_pct, gl.diastatic_power_lintner, gl.batch_variability, gl.cost_per_kg, gl.inventory_kg))

    # 2. Seed Standard Recipes
    recipes = [
        ("RECIPE-CLASSIC-01", "1.0", "Kentucky Classic Bourbon", "Master Distiller Smith", 72.0, 18.0, 0.0, 10.0),
        ("RECIPE-HIGH-RYE-02", "1.2", "High Rye Reserve Bourbon", "Master Distiller Smith", 65.0, 25.0, 0.0, 10.0),
        ("RECIPE-WHEAT-03", "1.0", "Velvet Wheat Bourbon", "Master Blender Jones", 74.0, 0.0, 16.0, 10.0),
        ("RECIPE-FOUR-GRAIN-04", "1.1", "Signature Four Grain", "Master Distiller Smith", 70.0, 12.0, 8.0, 10.0),
    ]
    for r in recipes:
        cursor.execute("""
            INSERT INTO recipes (recipe_id, version, name, author, corn_pct, rye_pct, wheat_pct, malted_barley_pct, process_parameters_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7], json.dumps({"mash_temp_c": 65.0, "duration_m": 90.0})))

    # 3. Seed Warehouses & 500+ Barrels
    random.seed(123)
    warehouses = ["RICKHOUSE_A", "RICKHOUSE_B", "RICKHOUSE_C"]
    
    char_levels = [1, 2, 3, 4]
    toast_levels = ["Medium", "Medium Plus", "Heavy"]

    barrel_count = 0
    for wh in warehouses:
        for floor in range(1, 7):
            for rack in range(1, 6):
                for row in range(1, 6):
                    if barrel_count >= 500:
                        break
                    barrel_count += 1
                    b_id = f"BRL-{wh[:3]}-F{floor}-{barrel_count:04d}"
                    age_m = round(random.uniform(12.0, 120.0), 1)
                    init_vol = 200.0
                    
                    # Evaporation loss
                    lost = init_vol * (1.0 - ((1.0 - 0.04)**(age_m / 12.0)))
                    curr_vol = round(init_vol - lost, 1)
                    curr_proof = round(120.0 + random.uniform(-4.0, 6.0), 1)

                    cursor.execute("""
                        INSERT INTO barrels (barrel_id, wood_type, toast_level, char_level, volume_capacity_l,
                                            fill_proof, warehouse_id, floor, rack, row, fill_date, initial_volume_l,
                                            current_volume_l, current_proof, current_age_months, status)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """, (b_id, "American White Oak (Quercus alba)", random.choice(toast_levels),
                          random.choice(char_levels), 200.0, 120.0, wh, floor, rack, row,
                          "2020-03-15", init_vol, curr_vol, curr_proof, age_m, "MATURING"))

                    # Seed sensory evaluations & lab results for a subset of barrels
                    if barrel_count % 3 == 0:
                        fv = FlavourVector(
                            sweetness=round(random.uniform(50, 85), 1),
                            vanilla=round(random.uniform(40, 88), 1),
                            caramel=round(random.uniform(45, 90), 1),
                            oak=round(min(95, age_m * 0.8), 1),
                            rye_spice=round(random.uniform(30, 80), 1),
                            body=round(random.uniform(50, 90), 1),
                            finish=round(random.uniform(55, 92), 1)
                        )
                        cursor.execute("""
                            INSERT INTO sensory_evaluations (eval_id, barrel_id_or_batch_id, taster_id, eval_date,
                                                             nose, palate, finish, balance, complexity, mouthfeel, overall_score, flavour_vector_json)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (f"EVAL-{b_id}", b_id, "PANEL_HEAD", "2026-08-20",
                              84.0, 86.0, 85.0, 88.0, 87.0, 86.0, 86.5, json.dumps(fv.to_dict())))

                        cursor.execute("""
                            INSERT INTO lab_results (lab_id, batch_id_or_barrel_id, test_date, abv_pct, ph, color_ebc, esters_ppm, fusels_ppm, aldehydes_ppm, acids_ppm, validated_by)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (f"LAB-{b_id}", b_id, "2026-08-21", curr_proof / 2.0, 4.2, 18.5, 95.0, 280.0, 18.0, 35.0, "QC Chemist Dr. Vance"))

    conn.commit()
    conn.close()
    print(f"Successfully seeded database with {len(grain_lots)} grain lots, 4 recipes, and {barrel_count} barrels!")
