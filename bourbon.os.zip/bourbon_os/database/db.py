"""
BOURBON.OS — Relational Database Schema & Data Persistence Layer
Tables: grain_lots, recipes, mash_batches, fermentation_batches, distillation_batches,
barrels, warehouse_locations, samples, sensory_evaluations, lab_results, blends,
bottling_batches, experiments, models, predictions, audit_events.
"""

import sqlite3
import os
import json
from typing import List, Dict, Any, Optional

DB_FILE = os.path.join(os.path.dirname(__file__), "bourbon_os.db")


def get_connection():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    # Create Core 16 Relational Tables
    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS grain_lots (
        lot_id TEXT PRIMARY KEY,
        grain_type TEXT NOT NULL,
        supplier TEXT,
        origin TEXT,
        moisture_pct REAL,
        protein_pct REAL,
        starch_potential_pct REAL,
        diastatic_power_lintner REAL,
        batch_variability REAL,
        cost_per_kg REAL,
        inventory_kg REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS recipes (
        recipe_id TEXT PRIMARY KEY,
        version TEXT NOT NULL,
        name TEXT NOT NULL,
        author TEXT,
        corn_pct REAL,
        rye_pct REAL,
        wheat_pct REAL,
        malted_barley_pct REAL,
        process_parameters_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS mash_batches (
        batch_id TEXT PRIMARY KEY,
        recipe_id TEXT,
        grain_lot_ids_json TEXT,
        total_grain_kg REAL,
        water_l REAL,
        mash_temp_c REAL,
        conversion_pct REAL,
        gravity_sg REAL,
        ph REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS fermentation_batches (
        batch_id TEXT PRIMARY KEY,
        mash_batch_id TEXT,
        yeast_id TEXT,
        pitch_temp_c REAL,
        duration_hours REAL,
        final_abv_pct REAL,
        final_sg REAL,
        congeners_json TEXT,
        is_stalled INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS distillation_batches (
        batch_id TEXT PRIMARY KEY,
        fermentation_batch_id TEXT,
        equipment_type TEXT,
        hearts_proof REAL,
        hearts_volume_l REAL,
        heads_volume_l REAL,
        tails_volume_l REAL,
        congeners_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS warehouse_locations (
        location_id TEXT PRIMARY KEY,
        warehouse_id TEXT NOT NULL,
        floor INTEGER NOT NULL,
        rack INTEGER NOT NULL,
        row INTEGER NOT NULL,
        avg_temp_c REAL,
        avg_rh_pct REAL
    );

    CREATE TABLE IF NOT EXISTS barrels (
        barrel_id TEXT PRIMARY KEY,
        wood_type TEXT,
        toast_level TEXT,
        char_level INTEGER,
        volume_capacity_l REAL,
        fill_proof REAL,
        warehouse_id TEXT,
        floor INTEGER,
        rack INTEGER,
        row INTEGER,
        fill_date TEXT,
        initial_volume_l REAL,
        current_volume_l REAL,
        current_proof REAL,
        current_age_months REAL,
        status TEXT DEFAULT 'MATURING'
    );

    CREATE TABLE IF NOT EXISTS samples (
        sample_id TEXT PRIMARY KEY,
        barrel_id TEXT NOT NULL,
        sample_date TEXT,
        age_months REAL,
        proof REAL,
        color_lovibond REAL,
        sensory_score REAL,
        notes TEXT
    );

    CREATE TABLE IF NOT EXISTS sensory_evaluations (
        eval_id TEXT PRIMARY KEY,
        barrel_id_or_batch_id TEXT NOT NULL,
        taster_id TEXT NOT NULL,
        eval_date TEXT,
        nose REAL,
        palate REAL,
        finish REAL,
        balance REAL,
        complexity REAL,
        mouthfeel REAL,
        overall_score REAL,
        flavour_vector_json TEXT
    );

    CREATE TABLE IF NOT EXISTS lab_results (
        lab_id TEXT PRIMARY KEY,
        batch_id_or_barrel_id TEXT NOT NULL,
        test_date TEXT,
        abv_pct REAL,
        ph REAL,
        color_ebc REAL,
        esters_ppm REAL,
        fusels_ppm REAL,
        aldehydes_ppm REAL,
        acids_ppm REAL,
        validated_by TEXT
    );

    CREATE TABLE IF NOT EXISTS blends (
        blend_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        target_profile_name TEXT,
        barrels_json TEXT,
        predicted_bqi REAL,
        flavour_vector_json TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS bottling_batches (
        bottling_id TEXT PRIMARY KEY,
        blend_id TEXT,
        barrel_ids_json TEXT,
        final_proof REAL,
        total_volume_l REAL,
        total_bottles_750ml INTEGER,
        bqi_score REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS experiments (
        experiment_id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        hypothesis TEXT,
        variables_json TEXT,
        status TEXT DEFAULT 'PROPOSED',
        results_json TEXT,
        conclusion TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS models (
        model_id TEXT PRIMARY KEY,
        version TEXT NOT NULL,
        model_type TEXT,
        training_dataset TEXT,
        mae REAL,
        rmse REAL,
        r2_score REAL,
        status TEXT
    );

    CREATE TABLE IF NOT EXISTS predictions (
        prediction_id TEXT PRIMARY KEY,
        model_id TEXT,
        input_params_json TEXT,
        predicted_bqi REAL,
        predicted_flavour_json TEXT,
        confidence REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS audit_events (
        event_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        actor TEXT,
        action TEXT,
        entity_type TEXT,
        entity_id TEXT,
        details_json TEXT
    );
    """)

    conn.commit()
    conn.close()


def log_audit_event(actor: str, action: str, entity_type: str, entity_id: str, details: Dict[str, Any] = None):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO audit_events (actor, action, entity_type, entity_id, details_json) VALUES (?, ?, ?, ?, ?)",
        (actor, action, entity_type, entity_id, json.dumps(details or {}))
    )
    conn.commit()
    conn.close()
