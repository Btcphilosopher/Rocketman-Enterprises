"""
BOURBON.OS — Physical Constants and Regulatory Definitions
"""

# Regulatory Constants (27 CFR Part 5)
LEGAL_MIN_CORN_PERCENT = 51.0
LEGAL_MAX_DISTILLATION_PROOF = 160.0  # 80% ABV
LEGAL_MAX_BARREL_ENTRY_PROOF = 125.0  # 62.5% ABV
LEGAL_MIN_BOTTLING_PROOF = 80.0       # 40.0% ABV
LEGAL_STRAIGHT_MIN_AGE_YEARS = 2.0
LEGAL_BONDED_PROOF = 100.0            # 50.0% ABV
LEGAL_BONDED_MIN_AGE_YEARS = 4.0

# Standard Barrel Specs (53 Gallon / ~200 Litres American Oak Barrel)
BARREL_STANDARD_CAPACITY_LITRES = 200.0
BARREL_STANDARD_CAPACITY_GALLONS = 53.0
WATER_DENSITY_KG_PER_L = 1.0
ETHANOL_DENSITY_KG_PER_L = 0.7893

# Flavour Dimensions (18 Standard Axes)
FLAVOUR_DIMENSIONS = [
    "sweetness",
    "vanilla",
    "caramel",
    "oak",
    "fruit",
    "rye_spice",
    "pepper",
    "cinnamon",
    "toast",
    "smoke",
    "floral",
    "nutty",
    "dried_fruit",
    "tobacco",
    "leather",
    "heat",
    "body",
    "finish"
]

# Off-Note Categories
OFF_NOTE_CATEGORIES = [
    "SOLVENT_LIKE",
    "SULFURY",
    "OVERLY_HOT",
    "FLAT",
    "EXCESSIVE_OAK",
    "BITTER",
    "VEGETAL",
    "ACIDIC",
    "UNBALANCED"
]
