"""
BOURBON.OS — Process State Domain Models & Type Definitions
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any
from datetime import datetime
import json


@dataclass
class GrainLot:
    lot_id: str
    grain_type: str  # CORN, RYE, WHEAT, MALTED_BARLEY, OTHER
    supplier: str
    origin: str
    moisture_pct: float          # e.g., 12.5%
    protein_pct: float           # e.g., 9.0%
    starch_potential_pct: float  # e.g., 68.0%
    diastatic_power_lintner: float # Enzyme potential
    batch_variability: float     # Std dev relative uncertainty
    cost_per_kg: float
    inventory_kg: float


@dataclass
class GrainBill:
    corn_pct: float
    rye_pct: float
    wheat_pct: float
    malted_barley_pct: float
    other_pct: float = 0.0

    def validate(self) -> List[str]:
        errors = []
        total = self.corn_pct + self.rye_pct + self.wheat_pct + self.malted_barley_pct + self.other_pct
        if abs(total - 100.0) > 0.01:
            errors.append(f"Grain bill percentages must sum to 100%, got {total:.2f}%")
        if self.corn_pct < 51.0:
            errors.append(f"Bourbon legal requirement: Corn % must be >= 51.0%, got {self.corn_pct:.1f}%")
        return errors


@dataclass
class WaterProfile:
    ph: float = 5.6
    calcium_ppm: float = 75.0
    magnesium_ppm: float = 20.0
    bicarbonate_ppm: float = 120.0
    sulfate_ppm: float = 60.0
    chloride_ppm: float = 40.0
    tds_ppm: float = 250.0


@dataclass
class MillingState:
    grain_bill: GrainBill
    grist_fine_pct: float      # % through <1mm
    grist_medium_pct: float    # % through 1-2mm
    grist_coarse_pct: float    # % >2mm
    surface_area_m2_kg: float  # Specific surface area
    milling_efficiency: float  # 0.0 - 1.0
    throughput_kg_hr: float
    accessibility_factor: float


@dataclass
class MashState:
    batch_id: str
    milling_state: MillingState
    water_profile: WaterProfile
    water_to_grain_ratio: float # L/kg, e.g. 3.8
    total_grain_kg: float
    total_water_l: float
    temp_profile_c: List[float]  # e.g. [65.0, 78.0, 85.0]
    duration_minutes: float
    alpha_amylase_activity: float
    beta_amylase_activity: float
    starch_conversion_pct: float
    fermentable_extract_kg: float
    gravity_sg: float
    ph: float


@dataclass
class YeastProfile:
    yeast_id: str
    name: str
    attenuation_pct: float       # e.g. 82.0%
    optimal_temp_c: float        # e.g. 28.0C
    fermentation_rate_k: float   # Kinetic constant
    ester_tendency: float        # 0-10 scale
    higher_alcohol_tendency: float # 0-10 scale
    acid_tendency: float          # 0-10 scale
    flavor_note: str


@dataclass
class FermentationTimeSeriesPoint:
    time_hours: float
    temperature_c: float
    specific_gravity: float
    ph: float
    estimated_abv_pct: float
    fermentation_rate: float
    sugars_g_l: float


@dataclass
class FermentationState:
    batch_id: str
    mash_batch_id: str
    yeast_profile: YeastProfile
    pitch_temp_c: float
    duration_hours: float
    time_series: List[FermentationTimeSeriesPoint]
    final_abv_pct: float
    final_gravity: float
    residual_sugar_g_l: float
    congeners_ppm: Dict[str, float] # e.g. {'esters': 120.0, 'fusel': 350.0, 'acids': 45.0}
    is_stalled: bool = False
    anomaly_flag: Optional[str] = None


@dataclass
class DistillationState:
    batch_id: str
    fermentation_batch_id: str
    equipment_type: str         # 'COLUMN_STILL_DOUBLER' or 'POT_STILL'
    reflux_ratio: float
    cuts: Dict[str, float]      # {'foreshots_pct': 1.5, 'heads_pct': 8.0, 'hearts_pct': 70.0, 'tails_pct': 20.5}
    hearts_proof: float         # Distillate proof (<=160)
    hearts_volume_l: float
    heads_volume_l: float
    tails_volume_l: float
    distillate_congeners: Dict[str, float]


@dataclass
class SpiritCharacter:
    fruit: float
    spice: float
    grain: float
    sweetness: float
    oak_potential: float
    floral: float
    herbal: float
    roasted: float
    earthy: float
    heat: float
    body: float
    complexity: float

    def to_dict(self) -> Dict[str, float]:
        return asdict(self)


@dataclass
class BarrelSpec:
    barrel_id: str
    wood_type: str          # American White Oak (Quercus alba)
    toast_level: str        # Light, Medium, Heavy, Medium Plus
    char_level: int         # Char #1 (15s), #2 (30s), #3 (45s), #4 Alligator (55s)
    volume_capacity_l: float # 200.0 L
    fill_proof: float       # <=125 proof
    warehouse_id: str
    floor: int
    rack: int
    row: int
    fill_date: str
    initial_volume_l: float


@dataclass
class MaturationPoint:
    age_months: float
    temperature_c: float
    humidity_pct: float
    current_volume_l: float
    current_proof: float
    angels_share_loss_l: float
    oak_extractives_ppm: float
    color_lovibond: float
    flavour_vector: Dict[str, float]


@dataclass
class MaturationTrajectory:
    barrel_id: str
    points: List[MaturationPoint]
    peak_quality_age_months: float
    over_oak_risk_age_months: float
    optimal_window_start_months: float
    optimal_window_end_months: float


@dataclass
class FlavourVector:
    sweetness: float = 50.0
    vanilla: float = 50.0
    caramel: float = 50.0
    oak: float = 50.0
    fruit: float = 50.0
    rye_spice: float = 50.0
    pepper: float = 50.0
    cinnamon: float = 50.0
    toast: float = 50.0
    smoke: float = 50.0
    floral: float = 50.0
    nutty: float = 50.0
    dried_fruit: float = 50.0
    tobacco: float = 50.0
    leather: float = 50.0
    heat: float = 50.0
    body: float = 50.0
    finish: float = 50.0

    def to_dict(self) -> Dict[str, float]:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: Dict[str, float]) -> 'FlavourVector':
        valid_keys = {f for f in cls.__dataclass_fields__}
        filtered = {k: v for k, v in d.items() if k in valid_keys}
        return cls(**filtered)


@dataclass
class OffNoteAssessment:
    off_note_type: str
    probability: float   # 0.0 to 1.0
    severity: float      # 0.0 to 10.0
    confidence: float    # 0.0 to 1.0
    contributing_variables: List[str]


@dataclass
class BQIResult:
    bqi: float                           # Overall score 0-100
    bqi_ci_lower: float                  # Confidence interval lower
    bqi_ci_upper: float                  # Confidence interval upper
    aroma_score: float                   # 0-100
    flavour_score: float                 # 0-100
    body_score: float                    # 0-100
    balance_score: float                 # 0-100
    complexity_score: float              # 0-100
    finish_score: float                  # 0-100
    colour_score: float                  # 0-100
    consistency_score: float             # 0-100
    process_stability_score: float       # 0-100
    weakest_dimension: str
    strongest_dimension: str
    off_notes: List[OffNoteAssessment]


@dataclass
class CostModelResult:
    grain_cost: float
    water_energy_cost: float
    yeast_cost: float
    labor_cost: float
    barrel_cost: float
    warehouse_storage_cost: float
    bottling_cost: float
    total_batch_cost: float
    cost_per_litre_proof_spirit: float
    cost_per_750ml_bottle: float


@dataclass
class DigitalTwinState:
    batch_id: str
    recipe_id: str
    recipe_name: str
    current_stage: str       # GRAIN, MASH, FERMENTATION, DISTILLATION, BARREL, MATURATION, BLEND, BOTTLING
    grain_bill: GrainBill
    mash_state: Optional[MashState] = None
    fermentation_state: Optional[FermentationState] = None
    distillation_state: Optional[DistillationState] = None
    spirit_character: Optional[SpiritCharacter] = None
    barrel_spec: Optional[BarrelSpec] = None
    maturation_state: Optional[MaturationPoint] = None
    flavour_vector: FlavourVector = field(default_factory=FlavourVector)
    bqi_result: Optional[BQIResult] = None
    cost_result: Optional[CostModelResult] = None
    yield_litres_proof: float = 0.0
    uncertainty_pct: float = 5.0
