"""
BOURBON.OS — Bourbon Quality Index (BQI) & Objective Function Engine
"""

from typing import Dict, List, Tuple
from bourbon_os.core.models import FlavourVector, BQIResult, OffNoteAssessment, SpiritCharacter, MaturationPoint


class BQIEngine:
    """
    Computes the Bourbon Quality Index (BQI) 0-100 based on sensory metrics,
    flavour vector balance, complexity, off-note penalties, and process stability.
    """

    def __init__(self, weights: Dict[str, float] = None):
        # Configurable objective function weights
        default_weights = {
            "aroma": 0.15,
            "flavour": 0.20,
            "body": 0.10,
            "balance": 0.15,
            "complexity": 0.15,
            "finish": 0.10,
            "colour": 0.05,
            "consistency": 0.05,
            "process_stability": 0.05,
        }
        self.weights = weights if weights is not None else default_weights
        # Normalize weights to sum to 1.0
        total = sum(self.weights.values())
        if total > 0:
            self.weights = {k: v / total for k, v in self.weights.items()}

    def calculate_bqi(
        self,
        flavour: FlavourVector,
        spirit: SpiritCharacter,
        maturation: MaturationPoint,
        off_notes: List[OffNoteAssessment],
        consistency_score: float = 85.0,
        process_stability_score: float = 90.0
    ) -> BQIResult:
        # 1. Aroma score derived from floral, fruit, spice, vanilla, oak aroma elements
        aroma = min(100.0, max(0.0, (flavour.vanilla * 0.25 + flavour.fruit * 0.25 + flavour.rye_spice * 0.2 + flavour.floral * 0.15 + flavour.caramel * 0.15)))
        
        # 2. Flavour score derived from core bourbon profile balance
        flavour_score = min(100.0, max(0.0, (flavour.caramel * 0.25 + flavour.vanilla * 0.25 + flavour.oak * 0.20 + flavour.rye_spice * 0.15 + flavour.toast * 0.15)))
        
        # 3. Body score
        body = flavour.body
        
        # 4. Finish score
        finish = flavour.finish
        
        # 5. Complexity score (spread/richness across multiple positive flavor dimensions)
        positive_dims = [flavour.vanilla, flavour.caramel, flavour.oak, flavour.fruit, flavour.rye_spice, flavour.cinnamon, flavour.toast, flavour.nutty, flavour.dried_fruit]
        mean_val = sum(positive_dims) / len(positive_dims)
        # Higher diversity above threshold = higher complexity
        richness_bonus = sum(1.5 for d in positive_dims if d >= 50.0)
        complexity = min(100.0, max(0.0, mean_val + richness_bonus))
        
        # 6. Balance score (penalty for extreme outliers or high harsh heat / bitterness)
        heat_penalty = max(0.0, (flavour.heat - 65.0) * 0.8)
        oak_excess_penalty = max(0.0, (flavour.oak - 80.0) * 1.2)
        balance = min(100.0, max(0.0, 90.0 - heat_penalty - oak_excess_penalty))
        
        # 7. Colour score derived from Lovibond / amber development
        if maturation:
            lovibond = maturation.color_lovibond
            colour = min(100.0, max(0.0, lovibond * 5.0)) # ~15-20 Lovibond is deep amber
            if lovibond > 22.0: # Overly dark/charred
                colour = max(60.0, 100.0 - (lovibond - 22.0) * 3.0)
        else:
            colour = 80.0

        scores = {
            "aroma": aroma,
            "flavour": flavour_score,
            "body": body,
            "balance": balance,
            "complexity": complexity,
            "finish": finish,
            "colour": colour,
            "consistency": consistency_score,
            "process_stability": process_stability_score,
        }

        # Weighted raw BQI
        raw_bqi = sum(scores[k] * self.weights.get(k, 0.0) for k in scores)

        # Off-note deductions
        total_off_note_penalty = sum(o.severity * o.probability * 2.0 for o in off_notes)
        final_bqi = max(0.0, min(100.0, raw_bqi - total_off_note_penalty))

        # Identify weakest and strongest dimensions
        sorted_dims = sorted(scores.items(), key=lambda x: x[1])
        weakest = sorted_dims[0][0]
        strongest = sorted_dims[-1][0]

        # Uncertainty range (+/- 3.5 points baseline)
        ci_spread = 2.5 + (total_off_note_penalty * 0.2)

        return BQIResult(
            bqi=round(final_bqi, 2),
            bqi_ci_lower=round(max(0.0, final_bqi - ci_spread), 2),
            bqi_ci_upper=round(min(100.0, final_bqi + ci_spread), 2),
            aroma_score=round(aroma, 1),
            flavour_score=round(flavour_score, 1),
            body_score=round(body, 1),
            balance_score=round(balance, 1),
            complexity_score=round(complexity, 1),
            finish_score=round(finish, 1),
            colour_score=round(colour, 1),
            consistency_score=round(consistency_score, 1),
            process_stability_score=round(process_stability_score, 1),
            weakest_dimension=weakest.upper(),
            strongest_dimension=strongest.upper(),
            off_notes=off_notes
        )
