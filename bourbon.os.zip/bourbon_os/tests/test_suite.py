"""
BOURBON.OS — Pytest / Unittest Automated Verification Suite
Tests: Mass balance, ABV proofing, grain bill validation, BQI engine, blend optimizer weights, database integrity.
"""

import unittest
from bourbon_os.core.models import GrainBill, FlavourVector, WaterProfile
from bourbon_os.core.bqi import BQIEngine
from bourbon_os.chemistry.mashing_chem import calculate_mashing_kinetics
from bourbon_os.simulation.proofing_sim import simulate_proofing
from bourbon_os.compliance.regulatory import RegulatoryComplianceChecker
from bourbon_os.optimisation.blend_opt import optimize_blend
from bourbon_os.database.db import init_db, get_connection


class TestBourbonOS(unittest.TestCase):

    def test_grain_bill_validation(self):
        gb_valid = GrainBill(corn_pct=70.0, rye_pct=20.0, wheat_pct=0.0, malted_barley_pct=10.0)
        self.assertEqual(len(gb_valid.validate()), 0)

        gb_invalid_corn = GrainBill(corn_pct=45.0, rye_pct=45.0, wheat_pct=0.0, malted_barley_pct=10.0)
        errs = gb_invalid_corn.validate()
        self.assertTrue(any("Corn % must be >= 51.0%" in e for e in errs))

    def test_mashing_mass_balance(self):
        converted, fermentable, dextrins, sg = calculate_mashing_kinetics(
            corn_kg=700.0, rye_kg=200.0, wheat_kg=0.0, barley_kg=100.0,
            water_l=3800.0, temp_c=65.0, duration_min=90.0, water_ph=5.6, calcium_ppm=75.0
        )
        self.assertGreater(converted, 0.0)
        self.assertGreater(fermentable, 0.0)
        self.assertGreater(sg, 1.020)

    def test_proofing_mass_balance(self):
        vol_out, proof_out, water_added, mass_bal, note = simulate_proofing(
            cask_volume_l=180.0, cask_proof=120.0, target_proof=90.0
        )
        self.assertAlmostEqual(proof_out, 90.0, delta=1.0)
        self.assertGreater(water_added, 0.0)
        self.assertGreater(mass_bal["bottles_750ml"], 200)

    def test_bqi_score_range(self):
        fv = FlavourVector(sweetness=70, vanilla=80, caramel=85, oak=65, rye_spice=60, body=80, finish=85)
        bqi_eng = BQIEngine()
        res = bqi_eng.calculate_bqi(flavour=fv, spirit=None, maturation=None, off_notes=[])
        self.assertGreaterEqual(res.bqi, 0.0)
        self.assertLessEqual(res.bqi, 100.0)

    def test_regulatory_compliance_checker(self):
        checker = RegulatoryComplianceChecker()
        gb = GrainBill(corn_pct=70.0, rye_pct=20.0, wheat_pct=0.0, malted_barley_pct=10.0)
        res = checker.check_bourbon_compliance(
            grain_bill=gb, distillation_hearts_proof=135.0, barrel_entry_proof=120.0,
            bottling_proof=90.0, maturation_age_years=4.0, wood_type="Charred New American White Oak"
        )
        self.assertTrue(res["is_compliant"])
        self.assertIn("STRAIGHT_BOURBON_WHISKEY", res["classifications_eligible"])

    def test_database_initialization(self):
        init_db()
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [r[0] for r in cursor.fetchall()]
        conn.close()
        self.assertIn("grain_lots", tables)
        self.assertIn("barrels", tables)


if __name__ == "__main__":
    unittest.main()
