"""
BOURBON.OS — Machine Learning Governance & Model Registry
Tracks model ID, version, training dataset, features, performance metrics, status.
"""

from typing import Dict, List, Any


def get_model_registry() -> List[Dict[str, Any]]:
    """
    Returns registered ML models, governance metadata, performance metrics (MAE, RMSE, R²).
    Never silently replaces a production model.
    """
    return [
        {
            "model_id": "BBN-RF-BQI-v1.4",
            "version": "1.4.0",
            "model_type": "Random Forest Regressor",
            "training_dataset": "DS-KY-BOURBON-2026-FULL (5,400 Batches)",
            "training_date": "2026-08-15",
            "features": ["corn_pct", "rye_pct", "wheat_pct", "mash_sg", "ferm_hours", "distil_proof", "char_level", "age_months", "warehouse_floor"],
            "mae": 1.42,
            "rmse": 1.88,
            "r2_score": 0.932,
            "status": "PRODUCTION"
        },
        {
            "model_id": "BBN-GPR-FLAVOUR-v2.1",
            "version": "2.1.0",
            "model_type": "Gaussian Process Regressor",
            "training_dataset": "DS-SENSORY-CALIBRATION-1200",
            "training_date": "2026-09-01",
            "features": ["18-dim_flavour_vector", "gcms_congeners", "taster_panel_scores"],
            "mae": 1.15,
            "rmse": 1.52,
            "r2_score": 0.954,
            "status": "PRODUCTION"
        },
        {
            "model_id": "BBN-XGB-YIELD-v1.0",
            "version": "1.0.2",
            "model_type": "Gradient Boosting (XGBoost)",
            "training_dataset": "DS-MASH-FERM-YIELD-3000",
            "training_date": "2026-07-20",
            "features": ["starch_potential", "diastatic_power", "yeast_attenuation", "mash_temp"],
            "mae": 2.10,
            "rmse": 2.85,
            "r2_score": 0.910,
            "status": "CHALLENGER"
        }
    ]
