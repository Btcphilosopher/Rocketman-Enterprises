"""
BOURBON.OS — Command Line Interface
Usage:
  bourbon simulate --corn 70 --rye 20 --barley 10
  bourbon optimise --profile HIGH_RYE
  bourbon barrel --id BRL-001
  bourbon blend --target profile.json
  bourbon quality --batch BATCH-001
  bourbon experiment --run EXP-004
  bourbon calibrate --lab data.csv
  bourbon report --batch BATCH-001
  bourbon seed
"""

import sys
import argparse
import json
from bourbon_os.api.services import (
    api_run_digital_twin_simulation,
    api_optimise_blend,
    api_rank_barrels,
    api_seed_database
)
from bourbon_os.optimisation.recipe_opt import optimize_recipe
from bourbon_os.optimisation.monte_carlo import run_monte_carlo_simulation
from bourbon_os.optimisation.sensitivity import run_sensitivity_analysis


def main():
    parser = argparse.ArgumentParser(description="BOURBON.OS — Bourbon Distillery Digital Twin & Quality Engine")
    subparsers = parser.add_subparsers(dest="command")

    # bourbon seed
    subparsers.add_parser("seed", help="Populate database with synthetic demonstration dataset")

    # bourbon simulate
    sim_p = subparsers.add_parser("simulate", help="Run full Digital Twin simulation")
    sim_p.add_argument("--corn", type=float, default=70.0)
    sim_p.add_argument("--rye", type=float, default=20.0)
    sim_p.add_argument("--wheat", type=float, default=0.0)
    sim_p.add_argument("--barley", type=float, default=10.0)
    sim_p.add_argument("--age", type=float, default=72.0)

    # bourbon optimise
    opt_p = subparsers.add_parser("optimise", help="Optimise recipe or process parameters")
    opt_p.add_argument("--profile", type=str, default="HIGH_RYE")

    # bourbon barrel
    bar_p = subparsers.add_parser("barrel", help="Rank and view barrel digital twins")
    bar_p.add_argument("--limit", type=int, default=10)

    # bourbon blend
    blend_p = subparsers.add_parser("blend", help="Master Blender blend optimization")

    # bourbon quality
    qual_p = subparsers.add_parser("quality", help="Calculate BQI and uncertainty")

    # bourbon report
    rep_p = subparsers.add_parser("report", help="Generate production report")

    args = parser.parse_args()

    if args.command == "seed":
        res = api_seed_database()
        print(json.dumps(res, indent=2))
    elif args.command == "simulate":
        res = api_run_digital_twin_simulation(
            corn_pct=args.corn,
            rye_pct=args.rye,
            wheat_pct=args.wheat,
            barley_pct=args.barley,
            target_age_months=args.age
        )
        print(json.dumps(res, indent=2))
    elif args.command == "optimise":
        res = optimize_recipe(target_profile_name=args.profile)
        print(json.dumps(res, indent=2))
    elif args.command == "barrel":
        res = api_rank_barrels(limit=args.limit)
        print(json.dumps(res, indent=2))
    elif args.command == "blend":
        target = {"vanilla": 80, "caramel": 75, "oak": 65, "fruit": 70, "rye_spice": 60, "body": 80, "finish": 85}
        res = api_optimise_blend(target_flavour_dict=target)
        print(json.dumps(res, indent=2))
    elif args.command == "report" or args.command == "quality":
        res = api_run_digital_twin_simulation()
        print("=== BOURBON.OS PRODUCTION QUALITY REPORT ===")
        print(f"Batch ID: {res.get('batch_id')}")
        print(f"BQI Score: {res.get('bqi_result', {}).get('bqi')}")
        print(f"Strongest Dim: {res.get('bqi_result', {}).get('strongest_dimension')}")
        print(f"Weakest Dim: {res.get('bqi_result', {}).get('weakest_dimension')}")
        print(f"Proof Yield: {res.get('yield_litres_proof')} Proof Litres")
        print(f"Cost per bottle: ${res.get('cost_result', {}).get('cost_per_750ml_bottle')}")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
