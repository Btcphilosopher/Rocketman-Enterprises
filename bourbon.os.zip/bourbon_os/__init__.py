"""
BOURBON.OS — Python Bourbon Distillery Digital Twin & Quality Optimisation Engine
"""

__version__ = "1.0.0"
