import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'BOURBON.OS — Distillery Digital Twin & Quality Engine',
  description: 'Computational digital twin and quality optimisation platform for American bourbon whiskey production.',
  openGraph: {
    title: 'BOURBON.OS — Distillery Digital Twin & Quality Engine',
    description: 'Computational digital twin and quality optimisation platform for American bourbon whiskey production.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BOURBON.OS — Distillery Digital Twin & Quality Engine',
    description: 'Computational digital twin and quality optimisation platform for American bourbon whiskey production.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
