import { NextRequest, NextResponse } from "next/server";
import { exec } from "child_process";
import path from "path";

export async function POST(req: NextRequest) {
  const { command } = await req.json();

  if (!command || typeof command !== "string") {
    return NextResponse.json({ error: "Command required" }, { status: 400 });
  }

  // Sanitize / guard: Prevent hazardous system destruction commands while allowing bourbon CLI & python commands
  let cmdToRun = command.trim();
  if (cmdToRun.startsWith("bourbon ")) {
    cmdToRun = `python3 -m bourbon_os.cli.main ${cmdToRun.substring(8)}`;
  } else if (!cmdToRun.startsWith("python3")) {
    cmdToRun = `python3 -m bourbon_os.cli.main ${cmdToRun}`;
  }

  return new Promise<NextResponse>((resolve) => {
    exec(
      cmdToRun,
      { cwd: process.cwd(), timeout: 10000, env: { ...process.env, PYTHONPATH: process.cwd() } },
      (error, stdout, stderr) => {
        resolve(
          NextResponse.json({
            command,
            stdout: stdout || "",
            stderr: stderr || (error ? error.message : ""),
            exitCode: error ? error.code : 0
          })
        );
      }
    );
  });
}
