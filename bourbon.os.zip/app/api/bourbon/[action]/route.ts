import { NextRequest, NextResponse } from "next/server";
import { spawn } from "child_process";
import path from "path";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ action: string }> }
) {
  const { action } = await params;
  let body = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  return new Promise<NextResponse>((resolve) => {
    const bridgePath = path.join(process.cwd(), "scripts", "bridge.py");
    const py = spawn("python3", [bridgePath]);

    let stdout = "";
    let stderr = "";

    py.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    py.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    py.on("close", (code) => {
      if (code !== 0 && !stdout.trim()) {
        resolve(
          NextResponse.json(
            { status: "ERROR", message: stderr || `Python exited with code ${code}` },
            { status: 500 }
          )
        );
        return;
      }

      try {
        // Extract JSON line from output (in case print statements preceded it)
        const lines = stdout.trim().split("\n");
        const jsonLine = lines[lines.length - 1];
        const parsed = JSON.parse(jsonLine);
        resolve(NextResponse.json(parsed));
      } catch (err) {
        resolve(
          NextResponse.json({
            status: "SUCCESS",
            raw_output: stdout,
            stderr
          })
        );
      }
    });

    py.stdin.write(JSON.stringify({ action, params: body }));
    py.stdin.end();
  });
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ action: string }> }
) {
  const { action } = await params;
  return new Promise<NextResponse>((resolve) => {
    const bridgePath = path.join(process.cwd(), "scripts", "bridge.py");
    const py = spawn("python3", [bridgePath]);

    let stdout = "";

    py.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    py.on("close", () => {
      try {
        const lines = stdout.trim().split("\n");
        const parsed = JSON.parse(lines[lines.length - 1]);
        resolve(NextResponse.json(parsed));
      } catch {
        resolve(NextResponse.json({ status: "SUCCESS", raw_output: stdout }));
      }
    });

    py.stdin.write(JSON.stringify({ action, params: {} }));
    py.stdin.end();
  });
}
