"use client";

import React, { useState, useEffect } from "react";
import {
  Wheat,
  Sliders,
  Warehouse,
  TrendingUp,
  Database,
  Terminal,
  GitCommit,
  Sparkles,
  ShieldCheck,
  RotateCcw,
  Layers,
  Award
} from "lucide-react";

import DigitalTwinFlow from "@/components/DigitalTwinFlow";
import MasterBlenderView from "@/components/MasterBlenderView";
import WarehouseHeatmap from "@/components/WarehouseHeatmap";
import OptimisationDashboard from "@/components/OptimisationDashboard";
import LabAndGovernanceView from "@/components/LabAndGovernanceView";
import CliTerminalView from "@/components/CliTerminalView";
import GenealogyView from "@/components/GenealogyView";

export default function BourbonOSApp() {
  const [activeTab, setActiveTab] = useState<
    | "DIGITAL_TWIN"
    | "MASTER_BLENDER"
    | "WAREHOUSE_HEATMAP"
    | "OPTIMISATION"
    | "LAB_GOVERNANCE"
    | "CLI_TERMINAL"
    | "GENEALOGY"
  >("DIGITAL_TWIN");

  const [simLoading, setSimLoading] = useState(false);
  const [simulationData, setSimulationData] = useState<any>(null);
  const [barrelsData, setBarrelsData] = useState<any[]>([]);
  const [paretoData, setParetoData] = useState<any>(null);
  const [monteCarloData, setMonteCarloData] = useState<any>(null);
  const [sensitivityData, setSensitivityData] = useState<any>(null);
  const [bayesianData, setBayesianData] = useState<any>(null);
  const [modelsData, setModelsData] = useState<any[]>([]);
  const [genealogyData, setGenealogyData] = useState<any>(null);

  // Initialize DB and fetch baseline simulation & barrel inventory
  useEffect(() => {
    async function initPlatform() {
      setSimLoading(true);
      try {
        // Seed DB if first run
        await fetch("/api/bourbon/seed", { method: "POST" });

        // Run baseline simulation
        const simRes = await fetch("/api/bourbon/simulate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ corn_pct: 70, rye_pct: 20, wheat_pct: 0, barley_pct: 10, target_age_months: 72 })
        });
        const simJson = await simRes.json();
        setSimulationData(simJson);

        // Fetch barrels
        const barRes = await fetch("/api/bourbon/rank_barrels", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ limit: 100 })
        });
        const barJson = await barRes.json();
        if (Array.isArray(barJson)) setBarrelsData(barJson);

        // Fetch Pareto
        const parRes = await fetch("/api/bourbon/pareto", { method: "POST" });
        setParetoData(await parRes.json());

        // Fetch Monte Carlo
        const mcRes = await fetch("/api/bourbon/monte_carlo", { method: "POST" });
        setMonteCarloData(await mcRes.json());

        // Fetch Sensitivity
        const sensRes = await fetch("/api/bourbon/sensitivity", { method: "POST" });
        setSensitivityData(await sensRes.json());

        // Fetch Bayesian DOE
        const bayRes = await fetch("/api/bourbon/bayesian", { method: "POST" });
        setBayesianData(await bayRes.json());

        // Fetch ML Governance
        const mlRes = await fetch("/api/bourbon/ml_governance", { method: "POST" });
        setModelsData(await mlRes.json());

        // Fetch Genealogy
        const genRes = await fetch("/api/bourbon/genealogy", { method: "POST" });
        setGenealogyData(await genRes.json());
      } catch (err) {
        console.error("Platform initialization error:", err);
      } finally {
        setSimLoading(false);
      }
    }

    initPlatform();
  }, []);

  const handleRunSimulation = async (params: any) => {
    setSimLoading(true);
    try {
      const res = await fetch("/api/bourbon/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(params)
      });
      const data = await res.json();
      setSimulationData(data);
    } catch (err) {
      console.error("Simulation error:", err);
    } finally {
      setSimLoading(false);
    }
  };

  const handleOptimiseBlend = async (targetFlavour: Record<string, number>) => {
    const res = await fetch("/api/bourbon/optimise_blend", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target_flavour: targetFlavour })
    });
    return await res.json();
  };

  const handleRunMonteCarlo = async () => {
    const res = await fetch("/api/bourbon/monte_carlo", { method: "POST" });
    setMonteCarloData(await res.json());
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 font-sans antialiased selection:bg-amber-500 selection:text-stone-950">
      {/* Platform Navigation Header */}
      <header className="sticky top-0 z-50 bg-stone-950/90 backdrop-blur-md border-b border-stone-800/80 px-4 sm:px-8 py-3.5">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-amber-500 to-amber-700 rounded-xl text-stone-950 font-black shadow-lg shadow-amber-500/20">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black tracking-wider text-amber-500 font-mono">BOURBON.OS</h1>
                <span className="text-[10px] bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded font-mono font-semibold">
                  v1.0.0
                </span>
              </div>
              <p className="text-[11px] text-stone-400">
                Bourbon Distillery Digital Twin & Quality Optimisation Engine
              </p>
            </div>
          </div>

          {/* Quick Platform Status Pills */}
          <div className="hidden lg:flex items-center gap-3 text-xs">
            <div className="px-3 py-1 bg-stone-900 rounded-full border border-stone-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-stone-400">Database:</span>
              <span className="font-mono text-amber-400 font-semibold">500+ Barrels</span>
            </div>

            <div className="px-3 py-1 bg-stone-900 rounded-full border border-stone-800 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span className="text-stone-400">Compliance:</span>
              <span className="font-semibold text-emerald-300">TTB 27 CFR Part 5</span>
            </div>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="max-w-7xl mx-auto mt-3 pt-2 border-t border-stone-900 overflow-x-auto no-scrollbar flex items-center gap-1 text-xs">
          {[
            { id: "DIGITAL_TWIN", label: "Lifecycle Digital Twin", icon: Layers },
            { id: "MASTER_BLENDER", label: "Master Blender", icon: Award },
            { id: "WAREHOUSE_HEATMAP", label: "Rickhouse Spatial Twin", icon: Warehouse },
            { id: "OPTIMISATION", label: "Optimisation & Uncertainty", icon: TrendingUp },
            { id: "LAB_GOVERNANCE", label: "Lab & ML Governance", icon: Database },
            { id: "CLI_TERMINAL", label: "Interactive CLI", icon: Terminal },
            { id: "GENEALOGY", label: "Genealogy Graph", icon: GitCommit },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-lg font-medium flex items-center gap-2 whitespace-nowrap transition-all ${
                  active
                    ? "bg-amber-500 text-stone-950 font-semibold shadow-md shadow-amber-500/10"
                    : "text-stone-400 hover:text-stone-200 hover:bg-stone-900"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main Content Workspace */}
      <main className="max-w-7xl mx-auto px-4 sm:px-8 py-8">
        {activeTab === "DIGITAL_TWIN" && (
          <DigitalTwinFlow
            simulationData={simulationData}
            onRunSimulation={handleRunSimulation}
            loading={simLoading}
          />
        )}

        {activeTab === "MASTER_BLENDER" && (
          <MasterBlenderView onOptimiseBlend={handleOptimiseBlend} />
        )}

        {activeTab === "WAREHOUSE_HEATMAP" && (
          <WarehouseHeatmap barrels={barrelsData} />
        )}

        {activeTab === "OPTIMISATION" && (
          <OptimisationDashboard
            paretoData={paretoData}
            monteCarloData={monteCarloData}
            sensitivityData={sensitivityData}
            bayesianData={bayesianData}
            onRunMonteCarlo={handleRunMonteCarlo}
          />
        )}

        {activeTab === "LAB_GOVERNANCE" && (
          <LabAndGovernanceView
            modelsData={modelsData}
            complianceData={simulationData?.compliance}
          />
        )}

        {activeTab === "CLI_TERMINAL" && <CliTerminalView />}

        {activeTab === "GENEALOGY" && (
          <GenealogyView genealogyData={genealogyData} />
        )}
      </main>
    </div>
  );
}
