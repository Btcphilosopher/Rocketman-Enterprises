import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";
import { PRODUCT_CATALOGUE } from "./src/productsData.js";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Set payload limits for image uploads (OCR feature)
  app.use(express.json({ limit: "15mb" }));
  app.use(express.urlencoded({ limit: "15mb", extended: true }));

  // Shared Gemini client utility (Lazy initialization to prevent crashes on startup if key is missing)
  let aiClient: GoogleGenAI | null = null;
  function getGemini(): GoogleGenAI {
    if (!aiClient) {
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        console.warn("GEMINI_API_KEY environment variable is not defined. Running in high-fidelity mock simulation mode.");
      }
      aiClient = new GoogleGenAI({
        apiKey: key || "DUMMY_KEY_SAFE_FALLBACK",
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
    return aiClient;
  }

  // --- API Routes FIRST ---

  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      timestamp: new Date().toISOString(),
      service: "FORGE INDUSTRIAL Engineering Hub"
    });
  });

  app.get("/api/products", (req, res) => {
    res.json(PRODUCT_CATALOGUE);
  });

  // API 1: AI Chat with Lead Technical Engineer (Sheffield/Birmingham)
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        res.status(400).json({ error: "Invalid parameters. 'messages' array required." });
        return;
      }

      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        const lastUserMsg = messages[messages.length - 1]?.content || "Help me select a part";
        res.json({
          text: `[FORGE ENGINEER - DEMO MODE]\n\nThank you for contacting Forge Industrial Technical Support. I'm simulating a response because your 'GEMINI_API_KEY' is currently unset in your platform Secrets. Under real API operations, I will evaluate: "${lastUserMsg}".\n\nFor general precision engineering, we recommend our **${PRODUCT_CATALOGUE[0].name}** (SKU: **${PRODUCT_CATALOGUE[0].sku}**), designed and manufactured here in Sheffield to **${PRODUCT_CATALOGUE[0].tolerances}** standards. It offers unmatched structural integrity.\n\nHow else can I assist with your CAD downloads or tolerance parameters?`
        });
        return;
      }

      const ai = getGemini();
      const formattedContents = messages.map(msg => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: formattedContents,
        config: {
          systemInstruction: "You are the Lead Technical Engineering Specialist at FORGE INDUSTRIAL (Engineering Britain's Future). You speak with technical elegance, immense pride in British engineering (Sheffield precision, Birmingham manufacturing, BAE Systems, Formula One, aerospace, Foster + Partners style), and complete mathematical rigor. Guide users to specific product codes in our catalogue where applicable (e.g., FI-MECH-BRG-7204-M, FI-MECH-SFT-M20-400, FI-HYDR-VLV-SS12). Provide absolute tolerances, steel grades, standards (BS EN, ISO, DIN), and mathematical calculations if they ask about loading, velocity, or pressures. Keep your tone Swiss-editorial clean, authoritative, yet warm, helpful, and deeply confident."
        }
      });

      res.json({ text: response.text });
    } catch (err: any) {
      console.error("Chat error:", err);
      res.status(500).json({ error: err.message || "Failed to process chat" });
    }
  });

  // API 2: AI-Assisted Component Matching / Intelligent Search
  app.post("/api/gemini/match", async (req, res) => {
    try {
      const { description, category } = req.body;
      if (!description) {
        res.status(400).json({ error: "Missing 'description' parameter." });
        return;
      }

      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        // Return simulated match from our high-fidelity database
        const term = description.toLowerCase();
        const matched = PRODUCT_CATALOGUE.find(p => 
          p.name.toLowerCase().includes(term) ||
          p.category.toLowerCase().includes(term) ||
          p.description.toLowerCase().includes(term) ||
          p.sku.toLowerCase().includes(term)
        ) || PRODUCT_CATALOGUE[0];

        res.json({
          success: true,
          match: {
            sku: matched.sku,
            name: matched.name,
            confidence: 0.96,
            technicalReasoning: `Local Engineering Database matched key terms to Sheffield/Cotswold specs. Ideal for your criteria: ${matched.materials} with dynamic tolerance limits specified to ${matched.tolerances}.`
          }
        });
        return;
      }

      const ai = getGemini();
      const prompt = `Match the following user industrial inquiry to one of our catalog products:
Inquiry: "${description}"
${category ? `Category Constraint: "${category}"` : ""}

Our catalogue:
${JSON.stringify(PRODUCT_CATALOGUE.map(p => ({ sku: p.sku, name: p.name, category: p.category, description: p.description, materials: p.materials, tolerances: p.tolerances })))}

Respond strictly in valid JSON format only, matching the specified schema.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              success: { type: Type.BOOLEAN },
              match: {
                type: Type.OBJECT,
                properties: {
                  sku: { type: Type.STRING, description: "The exact matching SKU from the catalogue, or 'UNKNOWN' if no suitable match exists." },
                  name: { type: Type.STRING, description: "The catalog product name." },
                  confidence: { type: Type.NUMBER, description: "Matching confidence coefficient between 0.0 and 1.0." },
                  technicalReasoning: { type: Type.STRING, description: "A clean, highly technical explanation of why this product fits the requirement based on material grade, standard specifications, or sizing compatibility." }
                },
                required: ["sku", "name", "confidence", "technicalReasoning"]
              }
            },
            required: ["success", "match"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      res.json(parsed);
    } catch (err: any) {
      console.error("Match error:", err);
      res.status(500).json({ error: err.message || "Failed to process matching engine" });
    }
  });

  // API 3: AI OCR / Parts Photograph Recognition
  app.post("/api/gemini/ocr", async (req, res) => {
    try {
      const { image } = req.body;
      if (!image) {
        res.status(400).json({ error: "Missing 'image' parameter with Base64 payload." });
        return;
      }

      const cleanBase64 = image.replace(/^data:image\/\w+;base64,/, "");
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        // High fidelity simulated OCR response
        res.json({
          detectedPartNumber: "7204-B-XL-TVP",
          detectedBrand: "FORGE Equivalent / SKF OEM",
          materialsDetected: "En31 Machined Chrome-Alloy Steel",
          matchedSku: "FI-MECH-BRG-7204-M",
          confidence: 0.91,
          analysisReport: "Image analyzed successfully via Simulated OCR. Angular Contact bearing configuration detected with solid-brass cage geometry (40° angle). Our metallurgical assessment matches carbon-chromium high wear-resistance alloy. Direct catalog equivalent is: FI-MECH-BRG-7204-M, fabricated at the Sheffield Forge facility."
        });
        return;
      }

      const ai = getGemini();
      const imagePart = {
        inlineData: {
          mimeType: "image/png", // We'll feed it as PNG/JPEG base64
          data: cleanBase64,
        },
      };

      const prompt = `Analyze this engineering part photograph. Extract any visible SKU, serial numbers, part numbers, stamping codes, material markings, brand/manufacturer name, and physical/geometric dimensions. Match this to the closest product SKU in the FORGE INDUSTRIAL catalog:
Catalogue:
${JSON.stringify(PRODUCT_CATALOGUE.map(p => ({ sku: p.sku, name: p.name, partNumber: p.partNumber, manufacturer: p.manufacturer })))}

Respond in valid JSON format matching the schema provided. Make sure to suggest a valid matchedSku from our catalog.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.6-flash",
        contents: [imagePart, prompt],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              detectedPartNumber: { type: Type.STRING },
              detectedBrand: { type: Type.STRING },
              materialsDetected: { type: Type.STRING },
              matchedSku: { type: Type.STRING },
              confidence: { type: Type.NUMBER },
              analysisReport: { type: Type.STRING, description: "A detailed physical analysis report of the wear patterns, shape characteristics, and compatibility recommendation." }
            },
            required: ["detectedPartNumber", "detectedBrand", "materialsDetected", "matchedSku", "confidence", "analysisReport"]
          }
        }
      });

      const parsed = JSON.parse(response.text || "{}");
      res.json(parsed);
    } catch (err: any) {
      console.error("OCR analysis error:", err);
      res.status(500).json({ error: err.message || "Failed to process image OCR" });
    }
  });

  // --- Serve Client Front-end ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`FORGE INDUSTRIAL server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
