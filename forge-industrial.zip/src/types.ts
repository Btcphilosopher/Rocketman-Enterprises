import { Product } from './productsData';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface QuoteRequest {
  id: string;
  companyName: string;
  contactName: string;
  email: string;
  items: {
    product: Product;
    quantity: number;
    targetPrice?: number;
  }[];
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  poNumber?: string;
  totalAmount: number;
  date: string;
}

export interface SavedList {
  id: string;
  name: string;
  itemsCount: number;
  description: string;
}

export interface SpendDataPoint {
  month: string;
  "Mechanical Parts": number;
  "Hydraulics": number;
  "Pneumatics": number;
  "Electrical & Automation": number;
}

export interface ProcurementConfig {
  companyName: string;
  taxRegistrationNumber: string;
  approvalLimit: number;
  requirePO: boolean;
  budgetCap: number;
  spentThisMonth: number;
  users: { name: string; role: 'Admin' | 'Buyer' | 'Approver'; email: string }[];
}
