export interface Product {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  sku: string;
  partNumber: string;
  manufacturer: string;
  price: number;
  materials: string;
  dimensions: {
    [key: string]: string;
  };
  tolerances: string;
  certifications: string[];
  stock: number;
  warehouse: string;
  leadTime: string;
  description: string;
  sustainability: {
    co2: string;
    recycledContent: string;
    origin: string;
  };
  cadData: {
    shape: 'bearing' | 'gear' | 'shaft' | 'valve' | 'flange' | 'motor';
    diameter?: number;
    length?: number;
    teeth?: number;
    bores?: number;
  };
  compatibleParts: string[];
}

export const PRODUCT_CATALOGUE: Product[] = [
  {
    id: "brg-7204-m",
    name: "High-Precision Angular Contact Ball Bearing",
    category: "Mechanical",
    subcategory: "Bearings",
    sku: "FI-MECH-BRG-7204-M",
    partNumber: "7204-B-XL-TVP",
    manufacturer: "Sheffield Precision Bearings",
    price: 184.50,
    materials: "En31 High-Carbon Chromium Steel, machined solid brass cage",
    dimensions: {
      "Bore Diameter": "20.000 mm",
      "Outer Diameter": "47.000 mm",
      "Width": "14.000 mm",
      "Contact Angle": "40°"
    },
    tolerances: "ISO Class P5 (exceeds ABEC-5), radial runout < 4.0 µm",
    certifications: ["BS EN 10204 3.1", "UKCA Approved", "ISO 9001:2015"],
    stock: 142,
    warehouse: "Birmingham Central Depot",
    leadTime: "Next Working Day (UK Standard)",
    description: "Designed for high-speed, high-rigidity applications in aerospace turbines and machine tool spindles. Machined brass cage provides exceptional guidance and thermal stability at high rotational speeds up to 18,000 RPM.",
    sustainability: {
      co2: "0.85 kg CO2e per unit",
      recycledContent: "72% high-grade steel scrap",
      origin: "Sheffield, United Kingdom"
    },
    cadData: {
      shape: "bearing",
      diameter: 47,
      length: 14
    },
    compatibleParts: ["sft-m20-400", "cpl-sd25-20"]
  },
  {
    id: "ger-mod2-36",
    name: "Spur Gear - Module 2.0 (36 Teeth)",
    category: "Mechanical",
    subcategory: "Gears",
    sku: "FI-MECH-GER-M2-36",
    partNumber: "SG-M2.0-36T-SH",
    manufacturer: "Midlands Precision Gears",
    price: 112.20,
    materials: "817M40 (EN24) Nickel-Chromium-Molybdenum Steel, induction hardened teeth",
    dimensions: {
      "Module": "2.0",
      "Number of Teeth": "36",
      "Pitch Diameter": "72.000 mm",
      "Face Width": "20.000 mm",
      "Bore Diameter": "15.000 mm with 5mm keyway"
    },
    tolerances: "AGMA Class 11, tooth profile error < 0.008 mm",
    certifications: ["BS EN 10204 3.1", "DIN 3962", "CE Standard"],
    stock: 85,
    warehouse: "Sheffield Distribution Centre",
    leadTime: "2-3 Working Days",
    description: "Induction-hardened teeth to 58-62 HRC. Ideal for severe-duty industrial drivetrains requiring reliable torque transfer and low noise signatures under shock loads.",
    sustainability: {
      co2: "1.20 kg CO2e per unit",
      recycledContent: "55% electric arc furnace steel",
      origin: "Rotherham, United Kingdom"
    },
    cadData: {
      shape: "gear",
      teeth: 36,
      diameter: 72
    },
    compatibleParts: ["sft-m20-400"]
  },
  {
    id: "sft-m20-400",
    name: "Precision Ground Linear Shaft",
    category: "Mechanical",
    subcategory: "Shafts",
    sku: "FI-MECH-SFT-M20-400",
    partNumber: "LS-M20-H6-400",
    manufacturer: "Sheffield Precision Bearings",
    price: 64.80,
    materials: "Cf53 High-Carbon Steel, induction hardened to 60-64 HRC",
    dimensions: {
      "Diameter": "20.000 mm",
      "Length": "400.000 mm",
      "Straightness": "0.1 mm/m",
      "Hardness Depth": "1.5 mm - 2.2 mm"
    },
    tolerances: "ISO h6 precision grind, surface roughness Ra 0.20 µm",
    certifications: ["BS EN 10204 3.1", "UKCA Approved"],
    stock: 210,
    warehouse: "Birmingham Central Depot",
    leadTime: "Next Working Day (UK Standard)",
    description: "Induction hardened and precision ground shafting optimized for linear ball bush bearings. Features highly consistent hardness profiles to ensure uniform wear resistance.",
    sustainability: {
      co2: "0.58 kg CO2e per unit",
      recycledContent: "80% recycled railway steel",
      origin: "Sheffield, United Kingdom"
    },
    cadData: {
      shape: "shaft",
      diameter: 20,
      length: 400
    },
    compatibleParts: ["brg-7204-m", "cpl-sd25-20"]
  },
  {
    id: "hyd-vlv-ss12",
    name: "High-Pressure Hydraulic Solenoid Valve",
    category: "Hydraulics",
    subcategory: "Valves",
    sku: "FI-HYDR-VLV-SS12",
    partNumber: "HSV-34-SS12-24V",
    manufacturer: "Cotswold Hydraulics & Controls",
    price: 495.00,
    materials: "316L Marine Grade Stainless Steel body, Fluorocarbon seals",
    dimensions: {
      "Port Size": "1/2\" BSPP",
      "Max Pressure": "350 Bar",
      "Flow Rate": "80 L/min",
      "Solenoid Voltage": "24V DC"
    },
    tolerances: "Spool clearance 0.003 mm, zero leakage design",
    certifications: ["BS EN 10204 3.1", "ATEX Zone 1/21 Rated", "IP67 Protection"],
    stock: 34,
    warehouse: "Gloucester Logistics Hub",
    leadTime: "3-5 Working Days",
    description: "Proportional pilot-operated control valve engineered for harsh offshore environments. Stainless steel body offers unparalleled resistance to marine corrosion and high-pressure fluid erosion.",
    sustainability: {
      co2: "3.40 kg CO2e per unit",
      recycledContent: "40% certified clean scrap",
      origin: "Stroud, United Kingdom"
    },
    cadData: {
      shape: "valve",
      diameter: 60,
      length: 120
    },
    compatibleParts: ["hyd-con-m20"]
  },
  {
    id: "hyd-con-m20",
    name: "Heavy-Duty Hydraulic Hose Connector",
    category: "Hydraulics",
    subcategory: "Connectors",
    sku: "FI-HYDR-CON-M20",
    partNumber: "HC-M20-BSPP38",
    manufacturer: "Cotswold Hydraulics & Controls",
    price: 18.50,
    materials: "Carbon Steel, Zinc-Nickel plating (exceeds 1000hr salt spray test)",
    dimensions: {
      "Thread 1": "M20 x 1.5 Male Metric",
      "Thread 2": "3/8\" BSPP Female Swivel",
      "Hex Size": "22 mm"
    },
    tolerances: "BS 5200 Standard, seating angle tolerance ±0.5°",
    certifications: ["ISO 12151-2", "UKCA Approved"],
    stock: 1250,
    warehouse: "Gloucester Logistics Hub",
    leadTime: "Next Working Day (UK Standard)",
    description: "Premium hydraulic hose adapter for reliable dynamic high-pressure piping. Features cold-formed threads for enhanced fatigue resistance in severe pulsating pressure systems.",
    sustainability: {
      co2: "0.08 kg CO2e per unit",
      recycledContent: "95% scrap zinc & steel",
      origin: "Stroud, United Kingdom"
    },
    cadData: {
      shape: "flange",
      diameter: 28,
      length: 45
    },
    compatibleParts: ["hyd-vlv-ss12"]
  },
  {
    id: "pne-cmp-v30",
    name: "Whisper-Quiet Rotary Screw Compressor",
    category: "Pneumatics",
    subcategory: "Compressors",
    sku: "FI-PNEU-CMP-V30",
    partNumber: "RSC-V30-A1",
    manufacturer: "Birmingham Pneumatic Systems",
    price: 3450.00,
    materials: "Acoustic canopy steel, synthetic fluid lubricants, integrated dryer",
    dimensions: {
      "Motor Power": "7.5 kW (10 HP)",
      "Free Air Delivery": "1.15 m³/min @ 8 Bar",
      "Noise Level": "62 dB(A)",
      "Air Receiver": "270 Litres"
    },
    tolerances: "Rotary clearance ±0.0015 mm",
    certifications: ["BS EN 286-1", "CE Marked", "UKCA Approved"],
    stock: 12,
    warehouse: "Birmingham Central Depot",
    leadTime: "5-7 Working Days",
    description: "Highly efficient variable-speed rotary screw compressor. The integrated dryer removes moisture to prevent downstream actuator corrosion. Extremely quiet acoustic housing allows direct installation in workshops.",
    sustainability: {
      co2: "45.00 kg CO2e (Offset program included)",
      recycledContent: "35% eco-cast steel",
      origin: "Birmingham, United Kingdom"
    },
    cadData: {
      shape: "motor",
      diameter: 180,
      length: 260
    },
    compatibleParts: ["pne-act-r25"]
  },
  {
    id: "pne-act-r25",
    name: "ISO 15552 Pneumatic Cylinder",
    category: "Pneumatics",
    subcategory: "Actuators",
    sku: "FI-PNEU-ACT-R25",
    partNumber: "PC-ISO-50-200-PPV",
    manufacturer: "Birmingham Pneumatic Systems",
    price: 154.00,
    materials: "Anodised Aluminium barrel, Chrome-plated high tensile steel rod",
    dimensions: {
      "Bore Size": "50 mm",
      "Stroke Length": "200 mm",
      "Cushioning": "Adjustable pneumatic both ends",
      "Operating Temp": "-20°C to +80°C"
    },
    tolerances: "Piston concentricity h9, stroke tolerance +1.5/-0 mm",
    certifications: ["ISO 15552", "ATEX Rated Optional"],
    stock: 94,
    warehouse: "Birmingham Central Depot",
    leadTime: "Next Working Day (UK Standard)",
    description: "Classic robust ISO double-acting cylinder with adjustable end position cushioning. High-performance low-friction polyurethane seals ensure long service life exceeding 10,000 kilometres.",
    sustainability: {
      co2: "1.10 kg CO2e per unit",
      recycledContent: "85% aluminium casing scrap",
      origin: "Birmingham, United Kingdom"
    },
    cadData: {
      shape: "shaft",
      diameter: 50,
      length: 200
    },
    compatibleParts: ["pne-cmp-v30"]
  },
  {
    id: "ele-mot-ie4",
    name: "IE4 Super-Premium Efficiency 3-Phase Motor",
    category: "Electrical",
    subcategory: "Motors",
    sku: "FI-ELEC-MOT-IE4",
    partNumber: "M3BP-132SMC4-IE4",
    manufacturer: "West Midlands Heavy Industries",
    price: 890.00,
    materials: "Cast iron frame, Class H insulated copper stator, Neodymium magnets",
    dimensions: {
      "Output Power": "5.5 kW (7.5 HP)",
      "Sync Speed": "1500 RPM (4 Pole)",
      "Frame Size": "132S",
      "Efficiency": "91.9% at full load"
    },
    tolerances: "Shaft concentricity IEC 60072-1 h6",
    certifications: ["BS EN 60034-30-1", "UKCA Approved", "IP55 Rating"],
    stock: 22,
    warehouse: "Birmingham Central Depot",
    leadTime: "2-3 Working Days",
    description: "Super-Premium IE4 efficiency synchronous reluctance motor. Engineered to significantly reduce industrial energy costs and carbon footprint in continuous operation pumping, HVAC, and conveyor environments.",
    sustainability: {
      co2: "8.90 kg CO2e (Calculated for manufacturing)",
      recycledContent: "60% recycled copper stator winding",
      origin: "Wolverhampton, United Kingdom"
    },
    cadData: {
      shape: "motor",
      diameter: 150,
      length: 310
    },
    compatibleParts: ["brg-7204-m", "cpl-sd25-20"]
  },
  {
    id: "cpl-sd25-20",
    name: "Flexible Spider Coupling - Shaft 20mm/15mm",
    category: "Mechanical",
    subcategory: "Couplings",
    sku: "FI-MECH-CPL-SD25-20",
    partNumber: "SC-D30-L40-20-15",
    manufacturer: "Sheffield Precision Bearings",
    price: 42.10,
    materials: "Aluminium 6082-T6 hubs, polyurethane spider insert (92 Shore A)",
    dimensions: {
      "Outside Diameter": "30.000 mm",
      "Total Length": "40.000 mm",
      "Bore 1": "20.000 mm",
      "Bore 2": "15.000 mm"
    },
    tolerances: "Bore ISO H7 fit, angular misalignment capacity 1.0°",
    certifications: ["RoHS Compliant", "CE Standard"],
    stock: 145,
    warehouse: "Sheffield Distribution Centre",
    leadTime: "Next Working Day (UK Standard)",
    description: "High-integrity torsional coupling for servo and positioning applications. Polyurethane elastic element dampens torsional vibrations and accommodates parallel and angular shaft misalignments.",
    sustainability: {
      co2: "0.15 kg CO2e",
      recycledContent: "90% green-smelted aluminium",
      origin: "Sheffield, United Kingdom"
    },
    cadData: {
      shape: "bearing",
      diameter: 30,
      length: 40
    },
    compatibleParts: ["sft-m20-400", "ele-mot-ie4"]
  },
  {
    id: "aut-rob-cob",
    name: "Forgebot-6 Six-Axis Collaborative Robot Arm",
    category: "Industrial Automation",
    subcategory: "Robotics",
    sku: "FI-AUTO-ROB-COB",
    partNumber: "FB-6-COB-R2",
    manufacturer: "Coventry Advanced Robotics",
    price: 18450.00,
    materials: "Aerospace carbon fibre composite, titanium pivots, absolute encoders",
    dimensions: {
      "Payload": "6.00 kg",
      "Reach Radius": "900.00 mm",
      "Repeatability": "±0.03 mm",
      "Weight": "21.5 kg"
    },
    tolerances: "Kinematic error envelope < 0.05 mm",
    certifications: ["ISO 10218-1", "ISO/TS 15066 (Collaborative safety)", "CE Marked", "UKCA Approved"],
    stock: 4,
    warehouse: "Coventry Automation Lab",
    leadTime: "10-14 Working Days",
    description: "Advanced British-designed collaborative robot featuring integrated torque sensors in each joint. Simple touch-to-teach programming interfaces allow deployment on assembly, CNC machine tending, and inspection tasks in under an hour without extensive safety guarding.",
    sustainability: {
      co2: "32.00 kg CO2e per unit",
      recycledContent: "25% recycled carbon composite",
      origin: "Coventry, United Kingdom"
    },
    cadData: {
      shape: "motor",
      diameter: 120,
      length: 450
    },
    compatibleParts: ["aut-vis-cam"]
  },
  {
    id: "aut-vis-cam",
    name: "Industrial Smart Vision Camera System",
    category: "Industrial Automation",
    subcategory: "Vision systems",
    sku: "FI-AUTO-VIS-CAM",
    partNumber: "IVC-5M-GL1",
    manufacturer: "Coventry Advanced Robotics",
    price: 1250.00,
    materials: "Anodised machined aluminium housing, sapphire glass aperture protection",
    dimensions: {
      "Resolution": "5.0 Megapixels",
      "Frame Rate": "60 FPS",
      "Processor": "Quad-core Embedded AI TPU",
      "Lens Mount": "C-Mount"
    },
    tolerances: "Focal drift < 0.002 mm over 10,000 hrs",
    certifications: ["CE", "UKCA", "IP67 Rating", "UL Listed"],
    stock: 18,
    warehouse: "Coventry Automation Lab",
    leadTime: "2-3 Working Days",
    description: "High-speed AI inspection camera designed for sub-millimetre defect detection. Features on-board deep learning execution for real-time sorting, label checking, and automated robot coordinate feedback via Modbus/EtherNet/IP.",
    sustainability: {
      co2: "0.95 kg CO2e",
      recycledContent: "45% recycled electronics packaging",
      origin: "Coventry, United Kingdom"
    },
    cadData: {
      shape: "valve",
      diameter: 50,
      length: 80
    },
    compatibleParts: ["aut-rob-cob"]
  },
  {
    id: "eng-wnd-bld",
    name: "Micro-Grid Turbine Generator Hub Connector",
    category: "Energy",
    subcategory: "Wind turbine components",
    sku: "FI-ENER-WND-BLD",
    partNumber: "MGTH-250-KW",
    manufacturer: "Cotswold Hydraulics & Controls",
    price: 1850.00,
    materials: "Superalloy Inconel 718, vacuum cast & shot peened",
    dimensions: {
      "Nominal Rating": "250 kW",
      "Bore Angle": "12.00° pitch pre-set",
      "Weight": "45.0 kg"
    },
    tolerances: "Geometric positioning tolerance ±0.010 mm",
    certifications: ["BS EN 61400-1", "Lloyds Register Certified", "UKCA Approved"],
    stock: 8,
    warehouse: "Gloucester Logistics Hub",
    leadTime: "5-7 Working Days",
    description: "High-strength structural connection hub for renewable micro-grid wind turbine blades. Manufactured using state-of-the-art additive sintering and shot-peening to ensure high fatigue threshold in extreme North Sea gusting conditions.",
    sustainability: {
      co2: "18.50 kg CO2e",
      recycledContent: "50% Aerospace titanium/nickel scrap",
      origin: "Gloucester, United Kingdom"
    },
    cadData: {
      shape: "flange",
      diameter: 250,
      length: 120
    },
    compatibleParts: ["brg-7204-m", "ele-mot-ie4"]
  }
];
