import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { PRODUCT_CATALOGUE, Product } from './productsData';
import CADViewer from './components/CADViewer';
import EngineeringCalculator from './components/EngineeringCalculator';
import ProcurementDashboard from './components/ProcurementDashboard';
import ManufacturerPortal from './components/ManufacturerPortal';
import AIChatSupport from './components/AIChatSupport';
import AIComponentFinder from './components/AIComponentFinder';
import { 
  ShoppingBag, Cpu, HelpCircle, HardHat, ShieldCheck, 
  Settings, Layers, Compass, TrendingUp, Building, Search, 
  ChevronRight, ArrowRight, Star, Truck, RefreshCw, FileText, 
  Check, Info, Sparkles, Mail, Phone, Landmark, MapPin, Trash2
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'catalog' | 'ai-center' | 'calculators' | 'procurement' | 'supplier'>('home');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(PRODUCT_CATALOGUE[0]);
  
  // Catalog Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  
  // B2B Cart / RFQ State
  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isQuoteCompiled, setIsQuoteCompiled] = useState(false);

  // SCADA Sensor Simulations State
  const [scadaSensors, setScadaSensors] = useState({
    sheffieldFurnaceTemp: 1642,
    birminghamCompressorPressure: 7.2,
    coventryRoboticRepeatability: 0.024,
    northSeaTurbineOutput: 242.4
  });

  // Cycle SCADA values to simulate live automation telemetry
  useEffect(() => {
    const interval = setInterval(() => {
      setScadaSensors({
        sheffieldFurnaceTemp: Math.floor(1640 + Math.random() * 8),
        birminghamCompressorPressure: Number((7.1 + Math.random() * 0.2).toFixed(2)),
        coventryRoboticRepeatability: Number((0.021 + Math.random() * 0.006).toFixed(3)),
        northSeaTurbineOutput: Number((240 + Math.random() * 5).toFixed(1))
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const addToCart = (product: Product, quantity: number) => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item);
      }
      return [...prev, { product, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const compileB2BRequisition = () => {
    setIsQuoteCompiled(true);
    setTimeout(() => {
      setIsQuoteCompiled(false);
      setCart([]);
      setIsCartOpen(false);
      // Navigate to procurement tab to show compiled quotes
      setActiveTab('procurement');
    }, 1800);
  };

  const filteredProducts = PRODUCT_CATALOGUE.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.sku.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.partNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.materials.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const cartTotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);

  return (
    <div className="min-h-screen bg-brand-cream text-brand-dark font-sans antialiased selection:bg-brand-green selection:text-white">
      
      {/* 1. TOP INDUSTRIAL BANNER */}
      <div className="bg-brand-dark border-b border-brand-green/20 text-brand-cream py-1.5 px-6 flex justify-between items-center text-[10px] font-mono tracking-widest uppercase">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1"><Landmark className="w-3.5 h-3.5 text-brand-copper" /> SHEFFIELD FORGE COV-LIMIT: 1642°C</span>
          <span className="hidden md:flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-brand-green" /> WEST MIDLANDS HUB ACTIVE</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="hidden md:block">ISO 9001:2015 REGISTERED</span>
          <span className="text-brand-copper font-bold">BUILT TO LAST • ENGAGED</span>
        </div>
      </div>

      {/* 2. MAIN HEADER */}
      <header className="sticky top-0 z-40 bg-brand-cream/95 backdrop-blur border-b-2 border-brand-dark px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('home')}>
          <div className="p-2 bg-brand-dark text-brand-cream">
            <span className="font-mono font-black text-lg tracking-tighter">F•I</span>
          </div>
          <div>
            <h1 className="text-sm font-serif font-bold tracking-tight uppercase leading-none">FORGE INDUSTRIAL</h1>
            <p className="text-[9px] font-mono text-brand-copper tracking-widest font-semibold uppercase mt-0.5">ENGINEERING BRITAIN'S FUTURE</p>
          </div>
        </div>

        {/* Global Navigation Controls */}
        <nav className="hidden lg:flex items-center gap-1 font-mono text-[11px] font-bold">
          <button onClick={() => { setActiveTab('home'); setSelectedProduct(PRODUCT_CATALOGUE[0]); }}
                  className={`px-3 py-1.5 transition-all duration-200 ${activeTab === 'home' ? 'bg-brand-dark text-brand-cream' : 'hover:bg-brand-dark/5 text-brand-dark'}`}>
            01. HOME
          </button>
          <button onClick={() => setActiveTab('catalog')}
                  className={`px-3 py-1.5 transition-all duration-200 ${activeTab === 'catalog' ? 'bg-brand-dark text-brand-cream' : 'hover:bg-brand-dark/5 text-brand-dark'}`}>
            02. SHOP COMPONENTS
          </button>
          <button onClick={() => setActiveTab('ai-center')}
                  className={`px-3 py-1.5 transition-all duration-200 ${activeTab === 'ai-center' ? 'bg-brand-dark text-brand-cream' : 'hover:bg-brand-dark/5 text-brand-dark'}`}>
            03. AI COMMAND CENTER
          </button>
          <button onClick={() => setActiveTab('calculators')}
                  className={`px-3 py-1.5 transition-all duration-200 ${activeTab === 'calculators' ? 'bg-brand-dark text-brand-cream' : 'hover:bg-brand-dark/5 text-brand-dark'}`}>
            04. CALCULATORS
          </button>
          <button onClick={() => setActiveTab('procurement')}
                  className={`px-3 py-1.5 transition-all duration-200 ${activeTab === 'procurement' ? 'bg-brand-dark text-brand-cream' : 'hover:bg-brand-dark/5 text-brand-dark'}`}>
            05. ENTERPRISE PROCUREMENT
          </button>
          <button onClick={() => setActiveTab('supplier')}
                  className={`px-3 py-1.5 transition-all duration-200 ${activeTab === 'supplier' ? 'bg-brand-dark text-brand-cream' : 'hover:bg-brand-dark/5 text-brand-dark'}`}>
            06. MANUFACTURER LEDGER
          </button>
        </nav>

        {/* Action icons / Cart */}
        <div className="flex items-center gap-3">
          <button onClick={() => setIsCartOpen(!isCartOpen)}
                  className="relative p-2.5 border-2 border-brand-dark hover:border-brand-green transition-all bg-white flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-brand-dark" />
            <span className="text-[11px] font-mono font-bold">{cart.length}</span>
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-brand-copper rounded-full animate-ping"></span>
            )}
          </button>

          {/* Quick Support chat bubble shortcut */}
          <button onClick={() => setActiveTab('ai-center')}
                  className="px-4 py-2 bg-brand-green hover:bg-brand-dark text-brand-cream text-xs font-mono font-bold tracking-widest uppercase transition-all flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-brand-copper" />
            AI DESK
          </button>
        </div>
      </header>

      {/* 3. B2B CART SLIDE OUT */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden">
            <div className="absolute inset-0 bg-brand-dark/40 backdrop-blur-sm" onClick={() => setIsCartOpen(false)} />
            <div className="absolute inset-y-0 right-0 max-w-full flex">
              <motion.div initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }} transition={{ type: 'spring', damping: 25 }}
                          className="w-screen max-w-md bg-white border-l-2 border-brand-dark shadow-2xl flex flex-col justify-between">
                
                <div className="p-6 overflow-y-auto space-y-6">
                  <div className="flex justify-between items-center border-b-2 border-brand-dark pb-3">
                    <h3 className="text-sm font-bold font-mono tracking-widest uppercase text-brand-dark">B2B REQUISITION COMPILER</h3>
                    <button onClick={() => setIsCartOpen(false)} className="text-xs font-mono text-brand-dark/60 hover:text-brand-dark font-bold">CLOSE</button>
                  </div>

                  {cart.length === 0 ? (
                    <div className="py-12 text-center text-brand-dark/50 font-mono text-xs space-y-3">
                      <ShoppingBag className="w-8 h-8 mx-auto text-brand-dark/30" />
                      <p className="tracking-wider">COMPILER CONTAINS NO ITEMS</p>
                      <button onClick={() => { setIsCartOpen(false); setActiveTab('catalog'); }}
                              className="text-brand-green font-bold hover:underline">
                        BROWSE HIGH-PRECISION PARTS
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {cart.map((item) => (
                        <div key={item.product.id} className="p-4 bg-brand-cream border border-brand-dark/20 space-y-2">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="text-xs font-bold text-brand-dark uppercase font-serif">{item.product.name}</h4>
                              <p className="text-[10px] text-brand-dark/60 font-mono">SKU: {item.product.sku}</p>
                            </div>
                            <button onClick={() => removeFromCart(item.product.id)} className="text-brand-dark/40 hover:text-red-600 transition-colors">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>

                          <div className="flex justify-between items-center text-xs font-mono pt-2 border-t border-brand-dark/10">
                            <span className="text-brand-dark/70">Quantity: <strong className="text-brand-dark">{item.quantity} units</strong></span>
                            <span className="font-bold text-brand-green">£{(item.product.price * item.quantity).toLocaleString()} GBP</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {cart.length > 0 && (
                  <div className="p-6 bg-brand-cream border-t-2 border-brand-dark space-y-4">
                    <div className="flex justify-between text-xs font-mono text-brand-dark/80">
                      <span className="uppercase">NET SUB-TOTAL:</span>
                      <span className="font-bold text-brand-dark">£{(cartTotal / 1.2).toLocaleString()} GBP</span>
                    </div>
                    <div className="flex justify-between text-xs font-mono text-brand-dark/80 border-b border-brand-dark/10 pb-2">
                      <span className="uppercase">VAT REGULATED (20%):</span>
                      <span className="font-bold text-brand-dark">£{(cartTotal * 0.2 / 1.2).toLocaleString()} GBP</span>
                    </div>
                    <div className="flex justify-between text-sm font-mono font-bold text-brand-green">
                      <span>TOTAL OUTLAY VALUE:</span>
                      <span>£{cartTotal.toLocaleString()} GBP</span>
                    </div>

                    <button onClick={compileB2BRequisition}
                            disabled={isQuoteCompiled}
                            className="w-full py-3.5 bg-brand-dark text-brand-cream text-xs font-mono font-bold tracking-widest uppercase hover:bg-brand-green transition-all flex items-center justify-center gap-2">
                      {isQuoteCompiled ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" /> COMPILING B2B RFQ...
                        </>
                      ) : (
                        <>
                          COMPILE FORMAL REQUISITION
                        </>
                      )}
                    </button>
                    <p className="text-[9px] font-mono text-center text-brand-dark/50">Compiling generates an active RFQ in the Corporate Dashboard.</p>
                  </div>
                )}

              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* 4. TAB CONTENTS */}
      <main className="pb-16">

         {/* TAB A: HOME */}
         {activeTab === 'home' && (
          <div className="space-y-16">
            
            {/* CINEMATIC HERO */}
            <section className="relative min-h-[580px] bg-brand-dark text-brand-cream flex items-center justify-center overflow-hidden border-b-4 border-brand-dark">
              
              {/* High-Tech Grid Overlays */}
              <div className="absolute inset-0 opacity-10" 
                   style={{ 
                     backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px), linear-gradient(to right, #3c3c3c 1px, transparent 1px), linear-gradient(to bottom, #3c3c3c 1px, transparent 1px)', 
                     backgroundSize: '36px 36px, 180px 180px, 180px 180px' 
                   }}></div>
              
              {/* Floating Blueprint graphics for automated manufacturing */}
              <div className="absolute right-10 top-20 opacity-15 pointer-events-none hidden lg:block">
                <svg className="w-[450px] h-[450px] text-brand-copper stroke-current" fill="none" strokeWidth="1.5" viewBox="0 0 100 100">
                  <circle cx="50" cy="50" r="40" strokeDasharray="3 3" />
                  <circle cx="50" cy="50" r="25" />
                  <path d="M10 50 L90 50 M50 10 L50 90" strokeDasharray="5 5" />
                  <polygon points="50,15 55,25 45,25" />
                  <text x="55" y="48" fontSize="3.5" fontFamily="monospace" fill="currentColor">AXIS X-01 ROTATOR</text>
                </svg>
              </div>

              {/* Central Copy block in Swiss Typography */}
              <div className="relative max-w-4xl px-8 text-center space-y-6">
                <span className="text-xs font-mono text-brand-copper uppercase tracking-widest font-bold block flex items-center justify-center gap-2">
                  <HardHat className="w-4 h-4 text-brand-green" /> ANGLO-FUTURIST SUPERMODERN COMMERCE
                </span>
                
                <h2 className="text-5xl md:text-7xl font-serif font-bold tracking-tight text-white leading-none uppercase">
                  BUILT TO <span className="text-brand-copper italic font-semibold">LAST</span>.<br />
                  ENGINEERED FOR TOMORROW.
                </h2>

                <p className="max-w-xl mx-auto text-sm md:text-base text-brand-cream/80 leading-relaxed font-sans font-light">
                  Britain's premium industrial marketplace for advanced aerospace, marine division shipyards, automated logistics warehouses, and renewable energy grids.
                </p>

                {/* Primary actions from prompt */}
                <div className="pt-4 flex flex-wrap justify-center gap-3 font-mono text-xs">
                  <button onClick={() => setActiveTab('catalog')}
                          className="px-6 py-3.5 bg-brand-green hover:bg-brand-copper hover:text-brand-dark text-brand-cream font-sans font-bold tracking-widest uppercase transition-all flex items-center gap-1.5">
                    SHOP COMPONENTS <ChevronRight className="w-4 h-4" />
                  </button>
                  <button onClick={() => setActiveTab('ai-center')}
                          className="px-6 py-3.5 bg-brand-dark border-2 border-brand-cream/30 hover:border-brand-copper hover:text-brand-copper text-brand-cream font-sans font-bold tracking-widest uppercase transition-all flex items-center gap-1.5">
                    BROWSE INDUSTRIES
                  </button>
                  <button onClick={() => setActiveTab('procurement')}
                          className="px-6 py-3.5 bg-brand-dark border-2 border-brand-cream/30 hover:border-brand-copper hover:text-brand-copper text-brand-cream font-sans font-bold tracking-widest uppercase transition-all flex items-center gap-1.5">
                    REQUEST A QUOTE
                  </button>
                  <button onClick={() => setActiveTab('ai-center')}
                          className="px-6 py-3.5 bg-brand-copper hover:bg-brand-green text-brand-cream font-sans font-bold tracking-widest uppercase transition-all flex items-center gap-1.5">
                    TECHNICAL SUPPORT
                  </button>
                </div>
              </div>

              {/* Lower telemetry overlay bar representing the "industry 4.0 digital twins" */}
              <div className="absolute bottom-0 inset-x-0 bg-brand-dark/95 border-t border-brand-green/20 py-3.5 px-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center font-mono text-[10px]">
                <div>
                  <span className="text-brand-cream/50 uppercase block">SHEFFIELD FORGE TEMP:</span>
                  <span className="font-bold text-brand-copper">{scadaSensors.sheffieldFurnaceTemp} °C</span>
                </div>
                <div>
                  <span className="text-brand-cream/50 uppercase block">BIRMINGHAM SYSTEM BAR:</span>
                  <span className="font-bold text-white">{scadaSensors.birminghamCompressorPressure} bar</span>
                </div>
                <div>
                  <span className="text-brand-cream/50 uppercase block">COVENTRY COBOT DEVIATION:</span>
                  <span className="font-bold text-brand-green">±{scadaSensors.coventryRoboticRepeatability} mm</span>
                </div>
                <div>
                  <span className="text-brand-cream/50 uppercase block">NORTH SEA TURBINE ACTIVE:</span>
                  <span className="font-bold text-white">{scadaSensors.northSeaTurbineOutput} MWh</span>
                </div>
              </div>
            </section>

            {/* HIGH-END FEATURE CARDS GRID (Swiss-editorial representation of industrial heritage) */}
            <section className="max-w-7xl mx-auto px-6 space-y-6">
              <div className="border-b-2 border-brand-dark pb-3 flex justify-between items-end">
                <div>
                  <span className="text-[10px] font-mono text-brand-copper uppercase font-bold tracking-widest">ENGINEERED CAPITAL SECTORS</span>
                  <h3 className="text-2xl font-serif font-bold uppercase tracking-tight text-brand-dark mt-1">SUPERMODERN INFRASTRUCTURE</h3>
                </div>
                <p className="text-xs text-brand-dark/70 hidden md:block max-w-sm font-sans font-light">
                  We supply precision mechanical castings, heavy hydraulic spool valves, and automated collaborative assemblies to support key national engineering vectors.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-sans text-sm">
                
                <div className="bg-white border-2 border-brand-dark p-6 space-y-4 hover:border-brand-copper transition-all duration-300 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="w-12 h-12 bg-brand-dark text-brand-cream flex items-center justify-center font-serif font-bold text-lg">
                      01
                    </div>
                    <h4 className="text-base font-serif font-bold text-brand-dark uppercase">AEROSPACE & ASSEMBLY</h4>
                    <p className="text-brand-dark/80 font-light leading-relaxed">
                      Designed for maximum fatigue threshold in high rotational environments. Certified under BS EN standardizations for immediate flight logistics incorporation.
                    </p>
                  </div>
                  <p className="text-brand-green font-mono font-bold text-[10px] uppercase tracking-wider flex items-center gap-1 mt-4">
                    SHEFFIELD STEEL AND ISO P5 SPECS ACTIVE <ChevronRight className="w-3.5 h-3.5 text-brand-copper" />
                  </p>
                </div>

                <div className="bg-white border-2 border-brand-dark p-6 space-y-4 hover:border-brand-copper transition-all duration-300 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="w-12 h-12 bg-brand-dark text-brand-cream flex items-center justify-center font-serif font-bold text-lg">
                      02
                    </div>
                    <h4 className="text-base font-serif font-bold text-brand-dark uppercase">FORMULA ONE PRECISION</h4>
                    <p className="text-brand-dark/80 font-light leading-relaxed">
                      Extreme machining tolerance of sub-micron precision. Lightweight high-density alloy castings designed to survive high-vibration shock loads and temperature sweeps.
                    </p>
                  </div>
                  <p className="text-brand-green font-mono font-bold text-[10px] uppercase tracking-wider flex items-center gap-1 mt-4">
                    INDIVIDUAL LAB ROTATIONAL REPORTS ATTACHED <ChevronRight className="w-3.5 h-3.5 text-brand-copper" />
                  </p>
                </div>

                <div className="bg-white border-2 border-brand-dark p-6 space-y-4 hover:border-brand-copper transition-all duration-300 flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="w-12 h-12 bg-brand-dark text-brand-cream flex items-center justify-center font-serif font-bold text-lg">
                      03
                    </div>
                    <h4 className="text-base font-serif font-bold text-brand-dark uppercase">NORTH SEA ENERGY GRIDS</h4>
                    <p className="text-brand-dark/80 font-light leading-relaxed">
                      Superalloy vacuum castings and zinc-nickel weather seals (1000hr salt-spray rating) certified for extreme marine gusting or subsea pressures.
                    </p>
                  </div>
                  <p className="text-brand-green font-mono font-bold text-[10px] uppercase tracking-wider flex items-center gap-1 mt-4">
                    LLOYDS REGISTER STAMPS FULLY DEPLOYED <ChevronRight className="w-3.5 h-3.5 text-brand-copper" />
                  </p>
                </div>

              </div>
            </section>

            {/* INTRODUCING THE AI COMMAND CENTER - CALL TO ACTION */}
            <section className="bg-brand-dark text-brand-cream py-16 px-6 border-y-4 border-brand-dark">
              <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <span className="text-[10px] font-mono text-brand-copper uppercase font-bold tracking-widest flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 bg-brand-green rounded-full animate-pulse"></span>
                    INDUSTRY 4.0 ACTIVE INTEGRATION
                  </span>
                  <h3 className="text-3xl font-serif font-bold uppercase tracking-tight text-white leading-tight">AI COMMAND TERMINAL</h3>
                  <p className="text-sm text-brand-cream/80 font-sans font-light leading-relaxed">
                    Ditch traditional clunky procurement catalogs. Experience our advanced B2B natural language matcher, live chat with technical experts, and image-based computer vision OCR. Upload a picture of a field component and let the model determine tolerances and recommend perfect Sheffield-engineered replacements.
                  </p>
                  <button onClick={() => setActiveTab('ai-center')}
                          className="px-6 py-3.5 bg-brand-green hover:bg-brand-copper hover:text-brand-dark text-brand-cream font-sans font-bold text-xs tracking-widest uppercase transition-all inline-flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-brand-copper" /> LAUNCH AI DESK
                  </button>
                </div>

                <div className="p-6 bg-brand-dark border-2 border-brand-cream/10 rounded-none space-y-4 font-mono text-xs">
                  <span className="text-brand-copper font-bold uppercase tracking-wider">SYSTEM LOGS - SECURE CORRIDORS:</span>
                  <div className="space-y-1.5 text-brand-cream/70">
                    <p className="text-brand-green">• [STATUS OK] Connected to Sheffield Mainframe (Applet 11c76edd)</p>
                    <p>• [SPECS ENGAGED] ISO/DIS 15552, AGMA Class 11 Spur pinion, EN24 Steel</p>
                    <p>• [INTELLIGENT OCR] Waiting photo Base64 vector input stream...</p>
                  </div>
                  <div className="p-3 bg-black/40 border border-brand-cream/10 rounded-none text-center text-[10px] text-brand-cream/40 uppercase tracking-widest">
                    "Britain builds the future - digitally verified."
                  </div>
                </div>
              </div>
            </section>

          </div>
        )}

        {/* TAB B: SHOP CATALOG */}
        {activeTab === 'catalog' && (
          <div className="max-w-7xl mx-auto px-6 pt-8 space-y-8">
            
            {/* Catalog Layout Header */}
            <div className="border-b-2 border-brand-dark pb-4 flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
              <div>
                <span className="text-[10px] font-mono text-brand-copper uppercase tracking-widest font-bold block">FORGE INDUSTRIAL CATALOGUE</span>
                <h2 className="text-3xl font-serif font-bold uppercase tracking-tight text-brand-dark mt-1">SHOP COMPONENTS</h2>
              </div>

              {/* Dynamic search bar */}
              <div className="w-full md:w-auto flex flex-col md:flex-row gap-2 font-mono text-xs">
                <div className="relative">
                  <input type="text" placeholder="Search SKU, part number, alloy..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                         className="px-4 py-3 bg-white border-2 border-brand-dark text-brand-dark w-full md:w-72 focus:outline-none focus:border-brand-green" />
                  <Search className="w-4 h-4 absolute right-3 top-3.5 text-brand-dark/40" />
                </div>
              </div>
            </div>

            {/* Category Selectors */}
            <div className="flex flex-wrap gap-1 border-b border-brand-dark/10 pb-4 font-sans text-xs font-bold tracking-wider">
              {['All', 'Mechanical', 'Hydraulics', 'Pneumatics', 'Electrical', 'Industrial Automation', 'Energy'].map((cat) => (
                <button key={cat} onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-2 border-2 border-brand-dark font-sans font-bold uppercase transition-all duration-200 ${selectedCategory === cat ? 'bg-brand-green text-white border-brand-green' : 'bg-white text-brand-dark hover:bg-brand-cream'}`}>
                  {cat.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Split layout: Grid on left (2/3), Specs/CAD page on right (1/3) */}
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              
              {/* Product Grid listing */}
              <div className="xl:col-span-2 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {filteredProducts.map((p) => (
                    <div key={p.id} onClick={() => setSelectedProduct(p)}
                         className={`p-6 bg-white border-2 cursor-pointer transition-all flex flex-col justify-between h-[230px] hover:shadow-md ${selectedProduct?.id === p.id ? 'border-brand-green bg-brand-green/[0.02]' : 'border-brand-dark/20 hover:border-brand-dark'}`}>
                      <div className="space-y-2">
                        <div className="flex justify-between items-start text-[10px] font-mono">
                          <span className="text-brand-copper uppercase font-bold">{p.category} • {p.subcategory}</span>
                          <span className="text-brand-dark/40 font-bold">{p.sku}</span>
                        </div>
                        <h3 className="text-base font-serif font-bold uppercase text-brand-dark leading-tight line-clamp-2">{p.name}</h3>
                        <p className="text-xs text-brand-dark/70 font-sans line-clamp-2">{p.description}</p>
                      </div>

                      <div className="border-t border-brand-dark/10 pt-3 flex justify-between items-end font-mono">
                        <div>
                          <p className="text-[9px] text-brand-dark/40 uppercase">Est. Lead Time</p>
                          <p className="text-[10px] text-brand-dark font-bold">{p.leadTime}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[9px] text-brand-dark/40 uppercase">UnitPrice (GBP)</p>
                          <p className="text-sm font-bold text-brand-green">£{p.price.toFixed(2)}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                {filteredProducts.length === 0 && (
                  <div className="p-12 text-center border-2 border-dashed border-brand-dark/20 text-brand-dark/50 font-mono text-xs">
                    No components found matching "{searchQuery}" under {selectedCategory}.
                  </div>
                )}
              </div>

              {/* Specs & Interactive CAD view on click */}
              <div className="xl:col-span-1">
                {selectedProduct ? (
                  <div className="sticky top-24 bg-white border-2 border-brand-dark p-6 space-y-6">
                    <div>
                      <span className="text-[9px] font-mono text-brand-copper uppercase font-bold tracking-widest">{selectedProduct.category} • {selectedProduct.subcategory}</span>
                      <h3 className="text-lg font-serif font-bold text-brand-dark uppercase leading-tight mt-1">{selectedProduct.name}</h3>
                      <p className="text-xs font-mono text-brand-dark/50 mt-1">SKU: {selectedProduct.sku} | Part No: {selectedProduct.partNumber}</p>
                    </div>

                    {/* Stock level indicators */}
                    <div className="p-4 bg-brand-cream border border-brand-dark/20 flex justify-between items-center text-xs font-mono">
                      <div>
                        <span className="text-brand-dark/50 block uppercase text-[9px] tracking-wider">PHYSICAL INVENTORY</span>
                        <span className="font-bold text-brand-green flex items-center gap-1.5 mt-0.5">
                          <Check className="w-4 h-4 text-brand-green" /> {selectedProduct.stock} Units Stocked
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-brand-dark/50 block uppercase text-[9px] tracking-wider">DEPOT HUB</span>
                        <span className="font-bold text-brand-dark text-[10px]">{selectedProduct.warehouse}</span>
                      </div>
                    </div>

                    {/* Technical details list */}
                    <div className="space-y-3 font-mono text-xs">
                      <span className="text-brand-dark/40 uppercase block text-[9px] border-b border-brand-dark/10 pb-1">METROLOGICAL CHARACTERISTICS</span>
                      <div className="grid grid-cols-2 gap-y-2 gap-x-4">
                        <div>
                          <p className="text-[10px] text-brand-dark/50">MATERIAL SELECTION</p>
                          <p className="font-bold text-brand-dark truncate" title={selectedProduct.materials}>{selectedProduct.materials}</p>
                        </div>
                        <div>
                          <p className="text-[10px] text-brand-dark/50">TOLERANCE SPEC</p>
                          <p className="font-bold text-brand-dark">{selectedProduct.tolerances}</p>
                        </div>
                        {Object.entries(selectedProduct.dimensions).slice(0, 4).map(([key, value]) => (
                          <div key={key}>
                            <p className="text-[10px] text-brand-dark/50 uppercase">{key}</p>
                            <p className="font-bold text-brand-dark">{value}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Sustainability Badge */}
                    <div className="p-4 bg-brand-green/5 border border-brand-green/20 text-brand-green text-xs font-mono space-y-1">
                      <p className="font-bold flex items-center gap-1.5 text-brand-green">
                        <ShieldCheck className="w-4 h-4" /> CARBON-COMPLIANCE RECORD:
                      </p>
                      <p className="text-[10px]">Alloy Carbon Footprint: <strong className="text-brand-dark">{selectedProduct.sustainability.co2}</strong></p>
                      <p className="text-[10px]">Recycled Component Index: <strong className="text-brand-dark">{selectedProduct.sustainability.recycledContent}</strong></p>
                      <p className="text-[10px]">Manufactured Origin: <strong className="text-brand-dark">{selectedProduct.sustainability.origin}</strong></p>
                    </div>

                    {/* Action form */}
                    <div className="space-y-2 pt-2 border-t border-brand-dark/10">
                      <div className="flex justify-between items-center text-xs font-mono font-bold text-brand-dark">
                        <span>UNIT QUOTATION VALUE:</span>
                        <span className="text-lg text-brand-copper">£{selectedProduct.price.toFixed(2)} GBP</span>
                      </div>
                      
                      <div className="flex gap-2">
                        <button onClick={() => addToCart(selectedProduct, 1)}
                                className="flex-1 py-3.5 bg-brand-green hover:bg-brand-copper text-white hover:text-brand-dark transition-all text-xs font-sans font-bold tracking-widest uppercase">
                          ADD TO REQUISITION
                        </button>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="sticky top-24 border-2 border-dashed border-brand-dark/20 p-12 text-center text-brand-dark/50 font-mono text-xs">
                    Select a component from our list to configure variables, download 3D models, or generate quotes.
                  </div>
                )}
              </div>

            </div>

            {/* RENDER CAD VIEW OF SELECTED PRODUCT */}
            {selectedProduct && (
              <section className="space-y-4 pt-12 border-t-2 border-brand-dark">
                <div className="border-b border-brand-dark/10 pb-2">
                  <h3 className="text-base font-serif font-bold tracking-wider uppercase text-brand-dark">INTERACTIVE CAD DRAWING ENGINE</h3>
                  <p className="text-xs text-brand-dark/60 font-sans">Configure physical parameters and inspect alignment tolerances before bulk B2B ordering.</p>
                </div>
                <CADViewer product={selectedProduct} />
              </section>
            )}

          </div>
        )}

        {/* TAB C: AI COMMAND CENTER */}
        {activeTab === 'ai-center' && (
          <div className="max-w-7xl mx-auto px-6 pt-8 space-y-12 animate-fadeIn">
            <div>
              <span className="text-[10px] font-mono text-[#ea580c] uppercase tracking-widest font-bold block">INTELLIGENT REQUISITIONS ASSISTANT</span>
              <h2 className="text-3xl font-black font-mono uppercase tracking-tight text-[#121212]">AI COMMAND CENTER</h2>
              <p className="text-xs text-[#64748b] mt-1 max-w-xl font-mono">Use deep generative models to assist with parts search and technical alignment on shipping specs.</p>
            </div>

            {/* AI Finder/OCR Section */}
            <section className="space-y-4">
              <div className="border-b border-[#cbd5e1] pb-2">
                <h3 className="text-sm font-bold font-mono tracking-wider uppercase">SPECS MATCHER & COMPUTER VISION OCR</h3>
              </div>
              <AIComponentFinder onSelectProduct={(sku) => {
                const found = PRODUCT_CATALOGUE.find(p => p.sku === sku);
                if (found) {
                  setSelectedProduct(found);
                  setActiveTab('catalog');
                }
              }} products={PRODUCT_CATALOGUE} />
            </section>

            {/* AI Live Chat Section */}
            <section className="space-y-4">
              <div className="border-b border-[#cbd5e1] pb-2">
                <h3 className="text-sm font-bold font-mono tracking-wider uppercase">LIVE ENGINEERING DESK CHAT</h3>
              </div>
              <AIChatSupport />
            </section>
          </div>
        )}

        {/* TAB D: ENGINEERING CALCULATORS */}
        {activeTab === 'calculators' && (
          <div className="max-w-7xl mx-auto px-6 pt-8 space-y-8 animate-fadeIn">
            <div>
              <span className="text-[10px] font-mono text-[#ea580c] uppercase tracking-widest font-bold block">MATHEMATICAL VERIFICATION SUITE</span>
              <h2 className="text-3xl font-black font-mono uppercase tracking-tight text-[#121212]">ENGINEERING CALCULATORS</h2>
              <p className="text-xs text-[#64748b] mt-1 max-w-xl font-mono">Formulate structural fatigue tolerances, hydraulic forces, and air compressor requirements with strict ISO formulas.</p>
            </div>

            <EngineeringCalculator />
          </div>
        )}

        {/* TAB E: ENTERPRISE PROCUREMENT */}
        {activeTab === 'procurement' && (
          <div className="max-w-7xl mx-auto px-6 pt-8 space-y-8 animate-fadeIn">
            <div>
              <span className="text-[10px] font-mono text-[#ea580c] uppercase tracking-widest font-bold block">B2B COV-LIMIT CONTROLS</span>
              <h2 className="text-3xl font-black font-mono uppercase tracking-tight text-[#121212]">ENTERPRISE PROCUREMENT</h2>
              <p className="text-xs text-[#64748b] mt-1 max-w-xl font-mono font-bold">Manage approval workflows, purchase order limits, and analyze monthly expenditure vectors.</p>
            </div>

            <ProcurementDashboard />
          </div>
        )}

        {/* TAB F: MANUFACTURER LEDGER */}
        {activeTab === 'supplier' && (
          <div className="max-w-7xl mx-auto px-6 pt-8 space-y-8 animate-fadeIn">
            <div>
              <span className="text-[10px] font-mono text-[#ea580c] uppercase tracking-widest font-bold block">INDUSTRY 4.0 INTEGRATOR APIS</span>
              <h2 className="text-3xl font-black font-mono uppercase tracking-tight text-[#121212]">MANUFACTURER PORTAL</h2>
              <p className="text-xs text-[#64748b] mt-1 max-w-xl font-mono">Allows certified suppliers to update stocked quantities, alter unit pricing structures, and accept incoming RFQs.</p>
            </div>

            <ManufacturerPortal />
          </div>
        )}

      </main>

      {/* 5. METICULOUS SWISS FOOTER */}
      <footer className="bg-[#121212] text-white border-t border-zinc-800 pt-16 pb-8 px-6 font-mono text-xs">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 border-b border-zinc-800 pb-12 mb-8">
          
          <div className="space-y-4">
            <h4 className="font-bold text-[#ea580c] uppercase tracking-wider text-sm">FORGE INDUSTRIAL</h4>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              "Britain builds the future." Fusing Sheffield's manufacturing heritage, Coventry's collaborative robotics, and modern digital logistics into one cohesive B2B digital ecosystem.
            </p>
          </div>

          <div className="space-y-3">
            <p className="font-bold uppercase text-[#ea580c]">DEPOT LOCATION CORRIDORS</p>
            <ul className="text-slate-400 space-y-1.5 text-[11px]">
              <li>• Central Hub: Birmingham Logistics, B1 1AA</li>
              <li>• Forge Division: Sheffield Metallurgy, S1 1EE</li>
              <li>• Fluid Dynamics: Stroud Hydraulics, GL5 1DD</li>
              <li>• Robotics Lab: Coventry Automation, CV1 1EE</li>
            </ul>
          </div>

          <div className="space-y-3">
            <p className="font-bold uppercase text-[#ea580c]">SYSTEM ACCREDITATIONS</p>
            <ul className="text-slate-400 space-y-1.5 text-[11px]">
              <li>• ISO 9001:2015 Quality Systems</li>
              <li>• BS EN 10204 Metallurgical Assay</li>
              <li>• ATEX Hazard Zones Certification</li>
              <li>• UKCA / CE Machinery Safety</li>
            </ul>
          </div>

          <div className="space-y-3">
            <p className="font-bold uppercase text-[#ea580c]">COMMUNICATION LINES</p>
            <p className="text-slate-400 text-[11px]">Direct B2B Hotline: <br /> <strong className="text-white">+44 (0) 114 9020 7204</strong></p>
            <p className="text-slate-400 text-[11px] mt-2">Mainframe Hub: <br /> <strong className="text-white">tom@ahyx.org</strong></p>
          </div>

        </div>

        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center text-slate-500 text-[10px] gap-4">
          <p>© 2026 FORGE INDUSTRIAL LTD. ALL REGISTERED RIGHTS TO METALLURGICAL LOGS PRESERVED IN ACCORDANCE WITH BS MACHINERY CODES.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white">UK SPEC COMPLIANCE</a>
            <a href="#" className="hover:text-white">BIM INTELLECTUAL STANDARD</a>
            <a href="#" className="hover:text-white">TERMS OF SALE</a>
          </div>
        </div>
      </footer>

    </div>
  );
}
