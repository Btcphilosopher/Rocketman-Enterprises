import React, { useState } from 'react';
import { Search, Camera, FileText, AlertCircle, RefreshCw, Sparkles } from 'lucide-react';
import { Product } from '../productsData';

interface AIComponentFinderProps {
  onSelectProduct: (productSku: string) => void;
  products: Product[];
}

// Low-weight, high-fidelity inline SVGs to act as high-tech Base64 simulated engineering photos
const MOCK_PHOTOS = {
  bearing: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200' style='background:%23F5F5F0;'><circle cx='100' cy='100' r='80' stroke='%231A1A1A' stroke-width='4' fill='none'/><circle cx='100' cy='100' r='55' stroke='%23B87333' stroke-dasharray='5,5' stroke-width='2' fill='none'/><circle cx='100' cy='100' r='30' stroke='%231A1A1A' stroke-width='3' fill='none'/><circle cx='100' cy='62' r='10' fill='%23B87333'/><circle cx='100' cy='138' r='10' fill='%23B87333'/><circle cx='62' cy='100' r='10' fill='%23B87333'/><circle cx='138' cy='100' r='10' fill='%23B87333'/><text x='15' y='185' fill='%231A1A1A' font-family='monospace' font-size='8' font-weight='bold'>METROLOGY SPEC 7204-XL</text></svg>",
  valve: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200' style='background:%23F5F5F0;'><rect x='40' y='50' width='120' height='100' rx='0' stroke='%231A1A1A' stroke-width='4' fill='none'/><circle cx='100' cy='100' r='30' stroke='%23B87333' stroke-width='2' fill='none'/><path d='M70 100 L130 100 M100 70 L100 130' stroke='%231A1A1A' stroke-width='2'/><text x='15' y='185' fill='%231A1A1A' font-family='monospace' font-size='8' font-weight='bold'>COTSWOLD FLUID-DYNAMICS</text></svg>",
  gear: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='200' viewBox='0 0 200 200' style='background:%23F5F5F0;'><circle cx='100' cy='100' r='60' stroke='%231A1A1A' stroke-width='3' stroke-dasharray='10,4' fill='none'/><circle cx='100' cy='100' r='30' stroke='%23B87333' stroke-width='3' fill='none'/><path d='M100 15 L100 35 M100 165 L100 185 M15 100 L35 100 M165 100 L185 100' stroke='%231A1A1A' stroke-width='4'/><text x='15' y='185' fill='%231A1A1A' font-family='monospace' font-size='8' font-weight='bold'>SPUR GEAR PINION M2.0</text></svg>"
};

export default function AIComponentFinder({ onSelectProduct, products }: AIComponentFinderProps) {
  const [activeMode, setActiveMode] = useState<'text' | 'photo'>('text');

  // Text matcher states
  const [descriptionInput, setDescriptionInput] = useState('');
  const [matchingCategory, setMatchingCategory] = useState('');
  const [matcherResult, setMatcherResult] = useState<any | null>(null);
  const [isMatching, setIsMatching] = useState(false);

  // Photo OCR states
  const [selectedPhotoBase64, setSelectedPhotoBase64] = useState<string | null>(null);
  const [photoAnalysisResult, setPhotoAnalysisResult] = useState<any | null>(null);
  const [isAnalyzingPhoto, setIsAnalyzingPhoto] = useState(false);
  const [selectedSample, setSelectedSample] = useState<string | null>(null);

  // Text Matching Submission
  const handleTextMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!descriptionInput.trim() || isMatching) return;

    setIsMatching(true);
    setMatcherResult(null);

    try {
      const response = await fetch('/api/gemini/match', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: descriptionInput,
          category: matchingCategory || undefined
        })
      });

      if (!response.ok) {
        throw new Error("Failed matching.");
      }

      const data = await response.json();
      setMatcherResult(data);
    } catch (err) {
      console.error(err);
      // Fallback
      setMatcherResult({
        success: true,
        match: {
          sku: "FI-MECH-BRG-7204-M",
          name: "High-Precision Angular Contact Ball Bearing",
          confidence: 0.85,
          technicalReasoning: "Fallback match applied (Verify Gemini Mainframe status in panel Secrets)."
        }
      });
    } finally {
      setIsMatching(false);
    }
  };

  // Run OCR analysis on photo
  const runOCR = async (base64Payload: string) => {
    setIsAnalyzingPhoto(true);
    setPhotoAnalysisResult(null);

    try {
      const response = await fetch('/api/gemini/ocr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ image: base64Payload })
      });

      if (!response.ok) {
        throw new Error("OCR failure.");
      }

      const data = await response.json();
      setPhotoAnalysisResult(data);
    } catch (err) {
      console.error(err);
      // Fallback
      setPhotoAnalysisResult({
        detectedPartNumber: "7204-B-XL",
        detectedBrand: "SKF OEM equivalent",
        materialsDetected: "Case-hardened Chrome steel",
        matchedSku: "FI-MECH-BRG-7204-M",
        confidence: 0.88,
        analysisReport: "Mock analysis triggered due to API key absence. Shape matches ball contact bearings."
      });
    } finally {
      setIsAnalyzingPhoto(false);
    }
  };

  // Photo upload trigger
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedSample(null);
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setSelectedPhotoBase64(base64);
      runOCR(base64);
    };
    reader.readAsDataURL(file);
  };

  // Handle sample photo select
  const handleSelectSample = (key: 'bearing' | 'valve' | 'gear') => {
    setSelectedSample(key);
    const mockBase64 = MOCK_PHOTOS[key];
    setSelectedPhotoBase64(mockBase64);
    runOCR(mockBase64);
  };

  return (
    <div id="ai-component-finder-container" className="bg-white border-2 border-brand-dark shadow-sm">
      {/* Search Type Tabs */}
      <div className="flex border-b-2 border-brand-dark bg-brand-cream text-xs font-sans font-bold tracking-widest">
        <button onClick={() => setActiveMode('text')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 uppercase border-r-2 border-brand-dark transition-all duration-200 ${activeMode === 'text' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Search className="w-4 h-4 align-text-bottom" />
          NATURAL LANGUAGE COMPONENT MATCHING
        </button>
        <button onClick={() => setActiveMode('photo')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 uppercase transition-all duration-200 ${activeMode === 'photo' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Camera className="w-4 h-4 align-text-bottom" />
          PARTS OCR PHOTOGRAPHIC ANALYSER
        </button>
      </div>

      <div className="p-6">
        {/* MODE A: NATURAL LANGUAGE MATCHING */}
        {activeMode === 'text' && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Input Inquiry Form */}
            <div className="lg:col-span-2 space-y-4">
              <div>
                <h3 className="text-base font-serif font-bold text-brand-dark uppercase">Describe your requirement</h3>
                <p className="text-xs text-brand-dark/70 mt-1 leading-relaxed font-sans">Our AI component finder matches physical parameters, load tolerances, and design envelopes to our registered B2B catalog.</p>
              </div>

              <form onSubmit={handleTextMatch} className="space-y-4 font-mono text-xs">
                <div className="flex flex-col space-y-1.5">
                  <label className="text-brand-dark/50 font-sans font-bold text-[9px] tracking-wider uppercase">DETAILED SPECIFICATION ENVELOPE:</label>
                  <textarea value={descriptionInput} onChange={(e) => setDescriptionInput(e.target.value)}
                            required rows={4}
                            placeholder="e.g. I need a ball bearing suitable for an angular contact shaft of diameter 20mm with premium tolerances of ABEC-5 or similar for high spindle velocities..."
                            className="px-3 py-2.5 bg-white border-2 border-brand-dark text-brand-dark font-mono text-xs focus:outline-none focus:border-brand-copper" />
                </div>

                <div className="flex flex-col space-y-1.5">
                  <label className="text-brand-dark/50 font-sans font-bold text-[9px] tracking-wider uppercase">CATEGORY FILTER (OPTIONAL):</label>
                  <select value={matchingCategory} onChange={(e) => setMatchingCategory(e.target.value)}
                          className="px-3 py-2.5 bg-white border-2 border-brand-dark text-brand-dark font-mono text-xs focus:outline-none focus:border-brand-copper">
                    <option value="">No Filter (Search Entire B2B Stock)</option>
                    <option value="Mechanical">Mechanical (Bearings, Gears, Shafts)</option>
                    <option value="Hydraulics">Hydraulics (Valves, Pumps, Connectors)</option>
                    <option value="Pneumatics">Pneumatics (Compressors, Actuators)</option>
                    <option value="Electrical">Electrical (IE4 Motors, PLCs)</option>
                    <option value="Industrial Automation">Industrial Automation (Robotics, AI Cameras)</option>
                  </select>
                </div>

                <button type="submit" disabled={isMatching}
                        className="w-full py-4 bg-brand-green hover:bg-brand-copper text-white hover:text-brand-dark font-sans font-bold tracking-widest uppercase border-2 border-brand-green hover:border-brand-copper transition-all duration-200 flex items-center justify-center gap-2">
                  <Sparkles className="w-4 h-4 text-white hover:text-brand-dark" />
                  {isMatching ? 'MATCHING SPECS...' : 'EXECUTE AI MATCHING'}
                </button>
              </form>
            </div>

            {/* Matcher Results Block */}
            <div className="lg:col-span-3 bg-brand-cream/40 border-2 border-brand-dark p-6 flex flex-col justify-between">
              {matcherResult ? (
                <div className="space-y-6 animate-fadeIn font-mono text-xs">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-brand-green border-2 border-brand-green px-3 py-1 bg-white uppercase tracking-wider">AI ALIGNMENT RESOLVED</span>
                    <h4 className="text-base font-serif font-bold text-brand-dark uppercase mt-3">CATALOG MATCH DETECTED:</h4>
                  </div>

                  {matcherResult.match && matcherResult.match.sku !== 'UNKNOWN' ? (
                    <div className="border-2 border-brand-dark bg-white p-5 space-y-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">BEST MATCH SKU</p>
                          <p className="text-sm font-bold text-brand-copper">{matcherResult.match.sku}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">CONFIDENCE RATING</p>
                          <p className="text-sm font-bold text-brand-green">{(matcherResult.match.confidence * 100).toFixed(1)}%</p>
                        </div>
                      </div>

                      <div className="border-t border-brand-dark/10 pt-3">
                        <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">Product Name:</p>
                        <p className="font-bold text-brand-dark mt-0.5 text-xs font-serif">{matcherResult.match.name}</p>
                      </div>

                      <div className="bg-brand-cream p-4 border border-brand-dark/10 text-[11px] leading-relaxed text-brand-dark/80">
                        <p className="font-bold text-brand-dark flex items-center gap-1.5 mb-1.5 font-sans uppercase tracking-wide text-[10px]">
                          <FileText className="w-4 h-4 text-brand-copper" /> METALLURGICAL LOGIC:
                        </p>
                        {matcherResult.match.technicalReasoning}
                      </div>

                      <button onClick={() => onSelectProduct(matcherResult.match.sku)}
                              className="w-full py-3.5 bg-brand-dark hover:bg-brand-copper text-white hover:text-brand-dark font-sans font-bold uppercase border-2 border-brand-dark hover:border-brand-copper transition-all duration-200 tracking-widest text-[10px]">
                        GO TO DETAILED SPECIFICATIONS & CAD DOWNLOADS
                      </button>
                    </div>
                  ) : (
                    <div className="p-4 bg-red-50 border-2 border-red-200 text-red-700 flex gap-2">
                      <AlertCircle className="w-5 h-5 flex-shrink-0" />
                      <div>
                        <p className="font-bold font-sans">No High-Confidence Catalog Match Found</p>
                        <p className="text-[11px] mt-0.5">Please adjust your dimensional filters, steel grades, or categories to align with our Sheffield/Midlands manufacture range.</p>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-brand-dark/50">
                  {isMatching ? (
                    <div className="space-y-3">
                      <RefreshCw className="w-8 h-8 text-brand-copper animate-spin mx-auto" />
                      <p className="font-mono text-xs uppercase tracking-widest text-brand-copper font-bold">GEMINI INFERENCE ACTIVE...</p>
                      <p className="text-[10px] text-brand-dark/40 font-mono">Cross-checking metallurgical grain, tolerances, and DIN specifications.</p>
                    </div>
                  ) : (
                    <div className="space-y-3 font-mono">
                      <Sparkles className="w-8 h-8 text-brand-dark/20 mx-auto" />
                      <p className="text-xs uppercase font-sans font-bold tracking-widest text-brand-dark">Awaiting technical specifications</p>
                      <p className="text-[11px] text-brand-dark/60 font-sans max-w-sm mx-auto mt-1 leading-relaxed">Input a physical description of the bearing, gear, motor, or valve envelope to resolve alignment.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        {/* MODE B: PHOTOGRAPH OCR ANALYSER */}
        {activeMode === 'photo' && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Left Col: Upload and Sample selection */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h3 className="text-base font-serif font-bold text-brand-dark uppercase">SELECT COMPONENT CAPTURE OR CHOOSE TEMPLATE</h3>
                <p className="text-xs text-brand-dark/70 mt-1 leading-relaxed font-sans">Simulate a high-speed camera capture on a manufacturing line or upload a physical component marking stamp.</p>
              </div>

              {/* Sample Photo Cards */}
              <div className="space-y-3 font-mono text-xs">
                <span className="text-brand-dark/50 font-sans font-bold uppercase block text-[9px] tracking-wider">TAP A RECENT FIELD CAPTURE TEMPLATE:</span>
                <div className="grid grid-cols-3 gap-2">
                  <button onClick={() => handleSelectSample('bearing')}
                          className={`p-2 border-2 text-center transition-all flex flex-col justify-between h-28 bg-[#FAF9F6] hover:border-brand-copper ${selectedSample === 'bearing' ? 'border-brand-copper ring-1 ring-brand-copper bg-white' : 'border-brand-dark/20'}`}>
                    <img src={MOCK_PHOTOS.bearing} className="w-full h-14 object-contain opacity-90" referrerPolicy="no-referrer" />
                    <span className="text-[9px] text-brand-dark uppercase font-bold tracking-tight">BEARING STAMP</span>
                  </button>
                  <button onClick={() => handleSelectSample('valve')}
                          className={`p-2 border-2 text-center transition-all flex flex-col justify-between h-28 bg-[#FAF9F6] hover:border-brand-copper ${selectedSample === 'valve' ? 'border-brand-copper ring-1 ring-brand-copper bg-white' : 'border-brand-dark/20'}`}>
                    <img src={MOCK_PHOTOS.valve} className="w-full h-14 object-contain opacity-90" referrerPolicy="no-referrer" />
                    <span className="text-[9px] text-brand-dark uppercase font-bold tracking-tight">FLOW VALVE</span>
                  </button>
                  <button onClick={() => handleSelectSample('gear')}
                          className={`p-2 border-2 text-center transition-all flex flex-col justify-between h-28 bg-[#FAF9F6] hover:border-brand-copper ${selectedSample === 'gear' ? 'border-brand-copper ring-1 ring-brand-copper bg-white' : 'border-brand-dark/20'}`}>
                    <img src={MOCK_PHOTOS.gear} className="w-full h-14 object-contain opacity-90" referrerPolicy="no-referrer" />
                    <span className="text-[9px] text-brand-dark uppercase font-bold tracking-tight">PINION GEAR</span>
                  </button>
                </div>
              </div>

              {/* Real file upload option */}
              <div className="border-2 border-dashed border-brand-dark/30 p-6 text-center font-sans text-xs bg-brand-cream/40">
                <Camera className="w-6 h-6 mx-auto text-brand-copper mb-2" />
                <label className="block text-brand-dark font-bold mb-1 uppercase tracking-wider text-[10px]">UPLOAD FIELD MARKING PHOTOGRAPH</label>
                <p className="text-[10px] text-brand-dark/40 mb-4">Accepts PNG, JPG (Max 5MB)</p>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" id="part-photo-upload" />
                <label htmlFor="part-photo-upload" className="px-6 py-2.5 bg-brand-dark hover:bg-brand-copper text-white hover:text-brand-dark text-[10px] font-sans font-bold tracking-widest uppercase transition-all duration-200 cursor-pointer border-2 border-brand-dark hover:border-brand-copper">
                  SELECT IMAGE FILE
                </label>
              </div>
            </div>

            {/* Right Col: OCR Analysis details */}
            <div className="lg:col-span-3 bg-brand-cream/40 border-2 border-brand-dark p-6 flex flex-col justify-between">
              {photoAnalysisResult ? (
                <div className="space-y-6 animate-fadeIn font-mono text-xs">
                  <div>
                    <span className="text-[10px] font-mono font-bold text-brand-green border-2 border-brand-green px-3 py-1 bg-white uppercase tracking-wider">COMPUTER VISION RESOLVED</span>
                    <h4 className="text-base font-serif font-bold text-brand-dark uppercase mt-3">OCR STAMP METALLURGICAL REPORT</h4>
                  </div>

                  <div className="border-2 border-brand-dark bg-white p-5 space-y-4">
                    <div className="grid grid-cols-2 gap-4 border-b border-brand-dark/10 pb-3">
                      <div>
                        <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">DETECTED ENG-CODE / SN</p>
                        <p className="font-bold text-brand-dark text-sm">{photoAnalysisResult.detectedPartNumber}</p>
                      </div>
                      <div>
                        <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">BRAND STAMP INFERENCE</p>
                        <p className="font-bold text-brand-copper text-sm">{photoAnalysisResult.detectedBrand}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 border-b border-brand-dark/10 pb-3">
                      <div>
                        <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">ALLOY COMPOSITION</p>
                        <p className="font-bold text-brand-dark/80">{photoAnalysisResult.materialsDetected}</p>
                      </div>
                      <div>
                        <p className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider font-sans">CATALOG INTERSECTION SKU</p>
                        <p className="font-bold text-brand-copper">{photoAnalysisResult.matchedSku}</p>
                      </div>
                    </div>

                    <div className="bg-brand-cream p-4 border border-brand-dark/10 text-[11px] leading-relaxed text-brand-dark/80">
                      <p className="font-bold text-brand-dark flex items-center gap-1.5 mb-1.5 font-sans uppercase tracking-wide text-[10px]">
                        <FileText className="w-4 h-4 text-brand-copper" /> STRUCTURAL WEAR & FIT ASSESSMENT:
                      </p>
                      {photoAnalysisResult.analysisReport}
                    </div>

                    <button onClick={() => onSelectProduct(photoAnalysisResult.matchedSku)}
                            className="w-full py-3.5 bg-brand-dark hover:bg-brand-copper text-white hover:text-brand-dark font-sans font-bold uppercase border-2 border-brand-dark hover:border-brand-copper transition-all duration-200 tracking-widest text-[10px]">
                      OPEN COMPATIBLE CATALOG SPECIFICATION & CAD SHEET
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-brand-dark/50">
                  {isAnalyzingPhoto ? (
                    <div className="space-y-3">
                      <RefreshCw className="w-8 h-8 text-brand-copper animate-spin mx-auto" />
                      <p className="font-mono text-xs uppercase tracking-widest text-brand-copper font-bold">ANALYSER RUNNING RECOGNITION...</p>
                      <p className="text-[10px] text-brand-dark/40 font-mono">Running neural pixel comparison against alloy stamp profiles.</p>
                    </div>
                  ) : (
                    <div className="space-y-3 font-mono">
                      <Camera className="w-8 h-8 text-brand-dark/20 mx-auto" />
                      <p className="text-xs uppercase font-sans font-bold tracking-widest text-brand-dark">Awaiting field photograph</p>
                      <p className="text-[11px] text-brand-dark/60 font-sans max-w-sm mx-auto mt-1 leading-relaxed">Select one of our templates or upload a photo containing physical engravings/wear markers to analyze.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
