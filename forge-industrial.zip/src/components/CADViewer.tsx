import React, { useState } from 'react';
import { Product } from '../productsData';
import { Settings, Download, Compass, HardHat, FileText, Activity } from 'lucide-react';

interface CADViewerProps {
  product: Product;
}

export default function CADViewer({ product }: CADViewerProps) {
  // Configurable dimensions in CAD
  const [scale, setScale] = useState<number>(1.2);
  const [boreSize, setBoreSize] = useState<number>(product.cadData.diameter ? Math.round(product.cadData.diameter * 0.45) : 20);
  const [outerDiameter, setOuterDiameter] = useState<number>(product.cadData.diameter || 60);
  const [length, setLength] = useState<number>(product.cadData.length || 150);
  const [teeth, setTeeth] = useState<number>(product.cadData.teeth || 36);
  const [isRotating, setIsRotating] = useState<boolean>(false);
  const [cadFormat, setCadFormat] = useState<string>('STEP (.stp)');
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  // Trigger simulated CAD download
  const handleDownload = () => {
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      // Trigger actual download of a fake STEP text file representing our exact model
      const mockStepContent = `ISO-10303-21;
HEADER;
FILE_DESCRIPTION(('FORGE INDUSTRIAL CAD ASSEMBLY','2;1'),'21');
FILE_NAME('${product.sku}_REV_1.stp','${new Date().toISOString()}',('FORGE INDUSTRIAL CAx TEAM'),('SHEFFIELD ENGINEERING DIVISION'),'STEP AP242','FORGE-CAD-ENGINE','');
FILE_SCHEMA(('AP242_MANAGED_MODEL_BASED_3D_ENGINEERING_MIM_LF_GR_V1.4.38'));
ENDSEC;
DATA;
#1=ORGANIZATION('FORGE INDUSTRIAL LTD','UK-NORTHERN-HUB','');
#2=PRODUCT('${product.sku}','${product.name}','',(#1));
#3=PRODUCT_DEFINITION_FORMATION('1','FIRST RELEASE',#2);
#4=SHAPE_REPRESENTATION('${product.name} SOLID',(#5),#6);
/* BORE: ${boreSize}mm, OD: ${outerDiameter}mm, WIDTH: ${length}mm */
/* GEOMETRIC SYMMETRY STABILITY OK */
ENDSEC;
END-ISO-10303-21;`;
      const blob = new Blob([mockStepContent], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${product.sku}_CAD_MODEL.stp`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }, 1200);
  };

  const resetCAD = () => {
    setBoreSize(product.cadData.diameter ? Math.round(product.cadData.diameter * 0.45) : 20);
    setOuterDiameter(product.cadData.diameter || 60);
    setLength(product.cadData.length || 150);
    setTeeth(product.cadData.teeth || 36);
  };

  return (
    <div id="cad-viewer-container" className="grid grid-cols-1 lg:grid-cols-3 gap-6 bg-white border-2 border-brand-dark p-6 shadow-sm">
      {/* CAD Canvas & Technical Layout */}
      <div id="cad-canvas-section" className="lg:col-span-2 relative bg-[#18181b] border-2 border-brand-dark h-[380px] flex items-center justify-center overflow-hidden">
        {/* Blueprint Grid Lines */}
        <div className="absolute inset-0 opacity-15 pointer-events-none" 
             style={{ 
               backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px), linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)', 
               backgroundSize: '24px 24px, 120px 120px, 120px 120px' 
             }}></div>

        {/* CAD Target Crosshairs */}
        <div className="absolute w-8 h-8 border-t border-b border-l border-r border-brand-copper opacity-50 pointer-events-none"></div>
        <div className="absolute w-[90%] h-[1px] border-t border-dashed border-white/20 opacity-20 pointer-events-none"></div>
        <div className="absolute h-[85%] w-[1px] border-l border-dashed border-white/20 opacity-20 pointer-events-none"></div>

        {/* Interactive Drawing Container */}
        <div className="relative w-full h-full flex items-center justify-center transition-transform duration-500" 
             style={{ transform: `scale(${scale})` }}>
          
          <svg className={`w-80 h-80 overflow-visible text-[#e2e8f0] fill-none stroke-current stroke-1.5 ${isRotating ? 'animate-spin' : ''}`}
               style={{ animationDuration: '12s' }}
               viewBox="-100 -100 200 200">
            
            {/* 1. Bearing Shape */}
            {product.cadData.shape === 'bearing' && (
              <g>
                {/* Outer Ring */}
                <circle cx="0" cy="0" r={outerDiameter} className="stroke-slate-400" />
                <circle cx="0" cy="0" r={outerDiameter - 8} className="stroke-slate-500 stroke-dasharray-[2_2]" />
                
                {/* Inner Ring */}
                <circle cx="0" cy="0" r={boreSize} className="stroke-slate-400" />
                <circle cx="0" cy="0" r={boreSize + 6} className="stroke-slate-500" />

                {/* Roller Balls */}
                {[0, 45, 90, 135, 180, 225, 270, 315].map((angle) => {
                  const rad = (angle * Math.PI) / 180;
                  const ballR = (outerDiameter - 8 - (boreSize + 6)) / 2;
                  const ballDist = boreSize + 6 + ballR;
                  const cx = ballDist * Math.cos(rad);
                  const cy = ballDist * Math.sin(rad);
                  return (
                    <circle key={angle} cx={cx} cy={cy} r={ballR - 1} className="stroke-brand-copper fill-[#18181b]" />
                  );
                })}

                {/* Technical dimension overlay markings */}
                <line x1="-120" y1="0" x2="-50" y2="0" className="stroke-slate-500 stroke-dasharray-[2_2]" />
                <line x1="50" y1="0" x2="120" y2="0" className="stroke-slate-500 stroke-dasharray-[2_2]" />
                <text x="5" y="-12" className="fill-slate-400 text-[8px] font-mono">Bore: Ø{boreSize}.000 mm h6</text>
                <text x="5" y="-115" className="fill-brand-copper text-[8px] font-mono">OD: Ø{outerDiameter * 2}.000 mm H7</text>
              </g>
            )}

            {/* 2. Gear Shape */}
            {product.cadData.shape === 'gear' && (
              <g>
                {/* Outer Pitch Diameter */}
                <circle cx="0" cy="0" r={outerDiameter} className="stroke-slate-500 stroke-dasharray-[4_4]" />
                {/* Root circle */}
                <circle cx="0" cy="0" r={outerDiameter - 12} className="stroke-slate-600" />
                {/* Bore */}
                <circle cx="0" cy="0" r={boreSize} className="stroke-slate-400" />
                {/* Keyway */}
                <rect x={boreSize - 2} y={-boreSize - 4} width="4" height="8" className="stroke-slate-400 fill-[#18181b]" />

                {/* Teeth Generator */}
                {Array.from({ length: Math.min(teeth, 72) }).map((_, i) => {
                  const angle = (i * 360) / teeth;
                  const rad = (angle * Math.PI) / 180;
                  const rOut = outerDiameter + 6;
                  const rIn = outerDiameter - 12;
                  const x1 = rIn * Math.cos(rad - 0.04);
                  const y1 = rIn * Math.sin(rad - 0.04);
                  const x2 = rOut * Math.cos(rad - 0.02);
                  const y2 = rOut * Math.sin(rad - 0.02);
                  const x3 = rOut * Math.cos(rad + 0.02);
                  const y3 = rOut * Math.sin(rad + 0.02);
                  const x4 = rIn * Math.cos(rad + 0.04);
                  const y4 = rIn * Math.sin(rad + 0.04);
                  return (
                    <polygon key={i} points={`${x1},${y1} ${x2},${y2} ${x3},${y3} ${x4},${y4}`} className="stroke-slate-400 fill-[#18181b]" />
                  );
                })}
                
                <text x="5" y="-12" className="fill-slate-400 text-[8px] font-mono">Bore: Ø{boreSize}.000</text>
                <text x="5" y="-95" className="fill-brand-copper text-[8px] font-mono">{teeth} Teeth | Mod 2.0</text>
              </g>
            )}

            {/* 3. Shaft Shape */}
            {product.cadData.shape === 'shaft' && (
              <g transform="rotate(-15)">
                {/* Main Shaft Cylinder */}
                <rect x={-length/2} y={-boreSize} width={length} height={boreSize * 2} className="stroke-slate-400 fill-[#18181b]" />
                {/* Keyway or chamfer */}
                <line x1={-length/2} y1={-boreSize} x2={-length/2 + 5} y2={-boreSize + 5} className="stroke-slate-400" />
                <line x1={length/2} y1={-boreSize} x2={length/2 - 5} y2={-boreSize + 5} className="stroke-slate-400" />
                {/* Surface finish symbols */}
                <text x="-30" y={boreSize + 15} className="fill-slate-400 text-[8px] font-mono">Ra 0.20 µm GROUND</text>
                <text x="-30" y={-boreSize - 10} className="fill-brand-copper text-[8px] font-mono">L = {length}.000 mm ±0.05</text>
              </g>
            )}

            {/* 4. Hydraulic Valve / Flange / Motor */}
            {(product.cadData.shape === 'valve' || product.cadData.shape === 'flange' || product.cadData.shape === 'motor') && (
              <g>
                {/* Enclosing body */}
                <rect x="-60" y="-45" width="120" height="90" rx="0" className="stroke-slate-500 fill-[#18181b]" />
                <circle cx="0" cy="0" r="30" className="stroke-slate-400" />
                <line x1="-80" y1="0" x2="80" y2="0" className="stroke-brand-copper" />
                <line x1="0" y1="-60" x2="0" y2="60" className="stroke-brand-copper stroke-dasharray-[2_2]" />
                
                {/* Core flow arrow / coils */}
                {product.cadData.shape === 'valve' && (
                  <path d="M -20 -15 L 20 15 M 20 -15 L -20 15 M -20 0 L 20 0" className="stroke-slate-400" />
                )}
                {product.cadData.shape === 'motor' && (
                  <text x="-12" y="6" className="fill-brand-copper text-[18px] font-mono font-bold">M 3~</text>
                )}
                {product.cadData.shape === 'flange' && (
                  <g>
                    <circle cx="-40" cy="0" r="4" className="stroke-slate-400" />
                    <circle cx="40" cy="0" r="4" className="stroke-slate-400" />
                  </g>
                )}
                
                <text x="-50" y="-55" className="fill-slate-400 text-[8px] font-mono">SPEC: BS EN 10204 3.1</text>
                <text x="-50" y="58" className="fill-brand-copper text-[8px] font-mono">Pressure Peak: 350 Bar Max</text>
              </g>
            )}

          </svg>
        </div>

        {/* CAD Canvas Overlays / Info */}
        <div className="absolute top-4 left-4 bg-black/85 px-3 py-2 border-2 border-brand-dark/20">
          <p className="text-[10px] font-mono text-brand-copper uppercase tracking-wider flex items-center gap-1.5 font-bold">
            <Activity className="w-3.5 h-3.5 animate-pulse" />
            LIVE CAD GENERATION ENGINE
          </p>
          <p className="text-xs text-white font-mono mt-0.5">{product.sku}</p>
        </div>

        <div className="absolute bottom-4 right-4 flex gap-2">
          <button onClick={() => setIsRotating(!isRotating)}
                  className={`px-3 py-1.5 text-[10px] font-mono border-2 transition-all font-bold ${isRotating ? 'bg-brand-copper text-brand-dark border-brand-copper' : 'bg-black/85 text-white border-white/20 hover:border-white'}`}>
            {isRotating ? 'PAUSE ROTATION' : 'ROTATE AXIS'}
          </button>
          <button onClick={resetCAD}
                  className="px-3 py-1.5 text-[10px] font-mono bg-black/85 text-white border-2 border-white/20 hover:border-white font-bold">
            RESET VIEW
          </button>
        </div>
      </div>

      {/* CAD Variables & Download Control Panel */}
      <div id="cad-control-panel" className="flex flex-col justify-between space-y-6">
        <div className="space-y-4">
          <div className="border-b-2 border-brand-dark pb-2">
            <h4 className="text-xs font-sans font-bold tracking-widest text-brand-dark uppercase flex items-center gap-2">
              <Settings className="w-4 h-4 text-brand-copper" />
              DIMENSIONAL MODIFICATION
            </h4>
            <p className="text-xs text-brand-dark/60 font-sans mt-0.5">Alter vector specs in real time to test engineering fit.</p>
          </div>

          {/* Sliders for customization */}
          {product.cadData.diameter && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-brand-dark font-bold">Bore Inner Diameter (Ø):</span>
                <span className="text-brand-copper font-bold">{boreSize} mm</span>
              </div>
              <input type="range" min="10" max={outerDiameter - 15} value={boreSize} 
                     onChange={(e) => setBoreSize(Number(e.target.value))}
                     className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
            </div>
          )}

          {product.cadData.diameter && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-brand-dark font-bold">Outside Radius / Shell (Ø):</span>
                <span className="text-brand-copper font-bold">{outerDiameter} mm</span>
              </div>
              <input type="range" min={boreSize + 15} max="120" value={outerDiameter} 
                     onChange={(e) => setOuterDiameter(Number(e.target.value))}
                     className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
            </div>
          )}

          {product.cadData.length && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-brand-dark font-bold">Physical Assembly Width/Length:</span>
                <span className="text-brand-copper font-bold">{length} mm</span>
              </div>
              <input type="range" min="30" max="450" value={length} 
                     onChange={(e) => setLength(Number(e.target.value))}
                     className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
            </div>
          )}

          {product.cadData.teeth && (
            <div className="space-y-1">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-brand-dark font-bold">Pinion Teeth Frequency (N):</span>
                <span className="text-brand-copper font-bold">{teeth} Teeth</span>
              </div>
              <input type="range" min="12" max="64" value={teeth} 
                     onChange={(e) => setTeeth(Number(e.target.value))}
                     className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
            </div>
          )}

          {/* Static Engineering Tolerances Info */}
          <div className="p-4 bg-brand-cream border-2 border-brand-dark rounded-none space-y-2">
            <h5 className="text-[11px] font-sans font-bold uppercase tracking-widest text-brand-dark flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-brand-copper" />
              METROLOGICAL COMPLIANCE
            </h5>
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-brand-dark/70">
              <div>
                <p className="text-brand-dark/40 uppercase font-bold text-[9px] tracking-wider">TOLERANCE CLASS</p>
                <p className="font-bold text-brand-dark">{product.tolerances}</p>
              </div>
              <div>
                <p className="text-brand-dark/40 uppercase font-bold text-[9px] tracking-wider">MATERIAL SPEC</p>
                <p className="font-bold text-brand-dark truncate" title={product.materials}>{product.materials}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Export / CAD Download Section */}
        <div className="space-y-3 pt-4 border-t-2 border-brand-dark">
          <div className="flex flex-col space-y-1.5">
            <label className="text-[10px] font-mono text-brand-dark/50 font-bold uppercase tracking-wider">CHOOSE CAD/BIM FILE FORMAT:</label>
            <select value={cadFormat} 
                    onChange={(e) => setCadFormat(e.target.value)}
                    className="w-full px-4 py-3 text-xs font-mono bg-white border-2 border-brand-dark text-brand-dark focus:outline-none">
              <option>STEP (.stp) - Recommended for SolidWorks/CATIA</option>
              <option>IGES (.igs) - Legacy CAD Interchange</option>
              <option>BIM Revit Family (.rfa) - Architecture/Grid Integration</option>
              <option>Parasolid (.x_t) - High-end Kernel Modeling</option>
              <option>DXF Vector (.dxf) - CNC Profile / Laser Cut</option>
            </select>
          </div>

          <button onClick={handleDownload}
                  disabled={isDownloading}
                  className="w-full flex items-center justify-center gap-2 px-4 py-4 bg-brand-green hover:bg-brand-copper text-white hover:text-brand-dark text-xs font-sans font-bold tracking-widest uppercase border-2 border-brand-green hover:border-brand-copper transition-all duration-200 disabled:bg-slate-400">
            <Download className="w-4 h-4" />
            {isDownloading ? 'EXPORTING ASSEMBLY...' : 'DOWNLOAD CAD MODEL (FREE)'}
          </button>
          
          <div className="flex justify-between text-[10px] text-brand-dark/40 font-mono">
            <span className="flex items-center gap-1 font-bold uppercase text-[9px]"><HardHat className="w-3.5 h-3.5 text-brand-copper" /> Fully engineered</span>
            <span className="flex items-center gap-1 font-bold uppercase text-[9px]"><FileText className="w-3.5 h-3.5 text-brand-copper" /> AP242 Certified</span>
          </div>
        </div>
      </div>
    </div>
  );
}
