import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { Send, User, Bot, HelpCircle, Landmark, ShieldCheck, Cpu } from 'lucide-react';

export default function AIChatSupport() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "init",
      role: "assistant",
      content: "Welcome to the FORGE INDUSTRIAL Technical Support Hub. I am the Lead Engineering Officer for our Sheffield Forge and Birmingham Hydraulics divisions. \n\nHow can I assist you with component specifications, ISO tolerances, CAD geometric files, or bulk B2B procurement contract terms today?",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of conversation
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      content: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMsg].map(m => ({ role: m.role, content: m.content }))
        })
      });

      if (!response.ok) {
        throw new Error("Engineering line communications interrupted.");
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now()}-reply`,
        role: "assistant",
        content: data.text || "I was unable to compile a response. Please check your data logs.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      setMessages(prev => [
        ...prev,
        {
          id: `msg-err`,
          role: "assistant",
          content: "[SYSTEM TELEMETRY FAULT] Communication with the Sheffield mainframe was interrupted. Please ensure your GEMINI_API_KEY is registered in the Secrets panel, or proceed in local mode.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div id="ai-chat-container" className="grid grid-cols-1 lg:grid-cols-4 gap-6 bg-white border-2 border-brand-dark p-6 shadow-sm">
      {/* Sidebar Engineering Meta */}
      <div className="lg:col-span-1 bg-brand-cream border-2 border-brand-dark p-5 flex flex-col justify-between rounded-none">
        <div className="space-y-4">
          <div>
            <span className="text-[9px] font-mono font-bold text-brand-copper uppercase tracking-widest block">SUPPORT CORE TELEMETRY</span>
            <h3 className="text-sm font-bold text-brand-dark uppercase font-serif mt-1">Lead Specialist</h3>
            <p className="text-xs text-brand-dark/70 mt-1 leading-relaxed">Assigned to: Sheffield Forge Lab & Birmingham Hub.</p>
          </div>

          <div className="border-t-2 border-brand-dark pt-3 space-y-2.5 font-mono text-[10px] text-brand-dark">
            <p className="flex items-center gap-1.5 font-bold text-brand-dark">
              <Cpu className="w-3.5 h-3.5 text-brand-copper" /> ENGINE CONFIG:
            </p>
            <p className="pl-5 text-brand-dark/60 font-sans">Gemini 2.5 Flash (Real-time active)</p>

            <p className="flex items-center gap-1.5 font-bold text-brand-dark">
              <ShieldCheck className="w-3.5 h-3.5 text-brand-green" /> ACCREDITATION:
            </p>
            <p className="pl-5 text-brand-dark/60 font-sans">MSc Precision Engineering, Birmingham Research Council</p>

            <p className="flex items-center gap-1.5 font-bold text-brand-dark">
              <Landmark className="w-3.5 h-3.5 text-brand-copper" /> HEADQUARTERS:
            </p>
            <p className="pl-5 text-brand-dark/60 font-sans">Industry 4.0 Sheffield HQ</p>
          </div>
        </div>

        <div className="mt-6 p-4 bg-white border border-brand-dark/20 rounded-none space-y-1.5">
          <p className="text-[10px] font-sans text-brand-copper font-bold flex items-center gap-1 uppercase tracking-wider">
            <HelpCircle className="w-3.5 h-3.5" /> Sample Queries:
          </p>
          <ul className="text-[10px] text-brand-dark/70 font-mono list-disc list-inside space-y-1">
            <li className="hover:text-brand-copper hover:underline cursor-pointer" onClick={() => setInput("What bearing fits a 20mm ground linear shaft?")}>Shaft & bearing matching</li>
            <li className="hover:text-brand-copper hover:underline cursor-pointer" onClick={() => setInput("Tell me the difference between ABEC-5 and ISO P5 tolerances.")}>ISO tolerance standards</li>
            <li className="hover:text-brand-copper hover:underline cursor-pointer" onClick={() => setInput("What are the BS EN 10204 3.1 certification guidelines?")}>Metallurgical certification</li>
          </ul>
        </div>
      </div>

      {/* Chat Conversational Pane */}
      <div className="lg:col-span-3 flex flex-col justify-between border-2 border-brand-dark h-[440px] bg-brand-cream/10 overflow-hidden rounded-none">
        {/* Messages list */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.map((m) => (
            <div key={m.id} className={`flex gap-3 max-w-[85%] ${m.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}>
              <div className={`p-2 h-8 w-8 flex items-center justify-center border-2 ${m.role === 'user' ? 'bg-brand-copper text-brand-dark border-brand-dark' : 'bg-brand-dark text-white border-brand-dark'}`}>
                {m.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4 text-brand-copper" />}
              </div>
              <div className={`p-4 font-mono text-xs leading-relaxed space-y-1.5 border-2 border-brand-dark ${m.role === 'user' ? 'bg-brand-copper text-brand-dark' : 'bg-white text-brand-dark'}`}>
                <div className="flex justify-between items-center gap-8 border-b border-brand-dark/10 pb-1 mb-1 text-[9px] opacity-75 font-sans font-bold">
                  <span className="uppercase tracking-wider">{m.role === 'user' ? 'REQUISITION OFFICER' : 'FORGE TECHNICAL CHIEF'}</span>
                  <span>{m.timestamp}</span>
                </div>
                <p className="whitespace-pre-line leading-relaxed">{m.content}</p>
              </div>
            </div>
          ))}

          {isLoading && (
            <div className="flex gap-3 max-w-[80%]">
              <div className="p-2 h-8 w-8 flex items-center justify-center bg-brand-dark text-white border-2 border-brand-dark">
                <Bot className="w-4 h-4 text-brand-copper animate-bounce" />
              </div>
              <div className="p-4 bg-white border-2 border-brand-dark text-brand-dark font-mono text-[11px] animate-pulse">
                ENGINEERING CORE COMPILING MATHEMATICAL DATA...
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Chat bar */}
        <form onSubmit={handleSubmit} className="p-3 bg-brand-cream border-t-2 border-brand-dark flex gap-2">
          <input type="text" value={input} onChange={(e) => setInput(e.target.value)}
                 placeholder="Formulate technical or procurement query..."
                 className="flex-1 px-4 py-3 bg-white border-2 border-brand-dark text-brand-dark font-mono text-xs focus:outline-none focus:border-brand-copper" />
          <button type="submit" disabled={isLoading}
                  className="px-6 bg-brand-dark text-white hover:bg-brand-green transition-all flex items-center justify-center border-2 border-brand-dark hover:border-brand-green font-sans font-bold uppercase tracking-widest text-xs">
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
