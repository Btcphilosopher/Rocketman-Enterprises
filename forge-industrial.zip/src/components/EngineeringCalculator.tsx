import React, { useState } from 'react';
import { Compass, Hammer, Wind, Activity } from 'lucide-react';

export default function EngineeringCalculator() {
  const [activeTab, setActiveTab] = useState<'bearing' | 'hydraulic' | 'pneumatic'>('bearing');

  // Bearing calculator state
  const [cr, setCr] = useState<number>(12.8); // Dynamic load rating Cr in kN
  const [pr, setPr] = useState<number>(3.2);  // Actual radial load Pr in kN
  const [rpm, setRpm] = useState<number>(3000); // Speed in RPM
  const [bearingType, setBearingType] = useState<'ball' | 'roller'>('ball');

  // Hydraulic calculator state
  const [pressureBar, setPressureBar] = useState<number>(160); // Pressure in bar
  const [boreMm, setBoreMm] = useState<number>(50); // Piston bore size in mm
  const [rodMm, setRodMm] = useState<number>(28);   // Rod diameter in mm

  // Pneumatic calculator state
  const [pneuBore, setPneuBore] = useState<number>(40); // mm
  const [pneuStroke, setPneuStroke] = useState<number>(200); // mm
  const [pneuPressure, setPneuPressure] = useState<number>(6); // bar
  const [pneuCycles, setPneuCycles] = useState<number>(30); // cycles per min

  // Calculation Results
  const calculateBearingLife = () => {
    const p = bearingType === 'ball' ? 3.0 : 10 / 3;
    if (pr <= 0) return 0;
    const l10MillionRevolutions = Math.pow(cr / pr, p);
    const l10Hours = (l10MillionRevolutions * 1000000) / (60 * rpm);
    return Math.round(l10Hours);
  };

  const calculateHydraulicForce = () => {
    // Area in cm^2
    const pistonArea = Math.PI * Math.pow(boreMm / 10, 2) / 4;
    const rodArea = Math.PI * Math.pow(rodMm / 10, 2) / 4;
    const annularArea = pistonArea - rodArea;

    // Force = Pressure (bar = 10 N/cm^2) * Area (cm^2) * 10
    const pushForceN = pressureBar * pistonArea * 10;
    const pullForceN = pressureBar * annularArea * 10;

    return {
      pushN: Math.round(pushForceN),
      pushTons: (pushForceN / 9806.65).toFixed(2), // kgf/9.806 -> metric tons
      pullN: Math.round(pullForceN),
      pullTons: (pullForceN / 9806.65).toFixed(2)
    };
  };

  const calculatePneumaticConsumption = () => {
    const compressionRatio = (pneuPressure + 1.013) / 1.013;
    const volumeLitres = (Math.PI * Math.pow(pneuBore / 10, 2) / 4) * (pneuStroke / 10) / 1000;
    
    const cycleVolumeStandardLitres = volumeLitres * 1.95 * compressionRatio;
    const totalConsumptionPerMin = cycleVolumeStandardLitres * pneuCycles;

    return {
      volumePerCycle: cycleVolumeStandardLitres.toFixed(3),
      consumptionPerMin: totalConsumptionPerMin.toFixed(1)
    };
  };

  return (
    <div id="engineering-calculator-container" className="bg-white border-2 border-brand-dark shadow-sm">
      {/* Tab Navigation */}
      <div className="flex border-b-2 border-brand-dark bg-brand-cream text-xs font-sans font-bold tracking-widest">
        <button onClick={() => setActiveTab('bearing')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 uppercase border-r-2 border-brand-dark transition-all duration-200 ${activeTab === 'bearing' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Compass className="w-4 h-4 align-text-bottom" />
          BEARING LIFE (L10)
        </button>
        <button onClick={() => setActiveTab('hydraulic')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 uppercase border-r-2 border-brand-dark transition-all duration-200 ${activeTab === 'hydraulic' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Hammer className="w-4 h-4 align-text-bottom" />
          HYDRAULIC FORCE
        </button>
        <button onClick={() => setActiveTab('pneumatic')}
                className={`flex-1 flex items-center justify-center gap-2 py-4 uppercase transition-all duration-200 ${activeTab === 'pneumatic' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Wind className="w-4 h-4 align-text-bottom" />
          PNEUMATIC FLOW
        </button>
      </div>

      <div className="p-6">
        {/* 1. Bearing Life Calculator */}
        {activeTab === 'bearing' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-base font-serif font-bold tracking-tight text-brand-dark uppercase flex items-center gap-2">
                <Activity className="w-4 h-4 text-brand-copper" />
                L10 FATIGUE LIFE PARAMETERS
              </h3>
              
              <div className="space-y-4 font-mono text-xs text-brand-dark">
                <div className="flex flex-col space-y-1">
                  <label className="text-brand-dark/40 font-bold uppercase text-[9px] tracking-wider mb-1">BEARING FAMILY GEOMETRY:</label>
                  <div className="flex gap-2">
                    <button onClick={() => setBearingType('ball')}
                            className={`flex-1 py-3 border-2 text-center font-sans font-bold transition-all ${bearingType === 'ball' ? 'bg-brand-green text-white border-brand-green' : 'border-brand-dark/30 hover:border-brand-dark text-brand-dark'}`}>
                      BALL (p=3.0)
                    </button>
                    <button onClick={() => setBearingType('roller')}
                            className={`flex-1 py-3 border-2 text-center font-sans font-bold transition-all ${bearingType === 'roller' ? 'bg-brand-green text-white border-brand-green' : 'border-brand-dark/30 hover:border-brand-dark text-brand-dark'}`}>
                      ROLLER (p=3.33)
                    </button>
                  </div>
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">DYNAMIC CAPACITY (Cr):</label>
                    <span className="font-bold text-brand-copper">{cr} kN</span>
                  </div>
                  <input type="range" min="1" max="150" step="0.5" value={cr} 
                         onChange={(e) => setCr(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                  <p className="text-[10px] text-brand-dark/50 font-sans mt-0.5">Manufactured rating from technical datasheets.</p>
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">ACTUAL RADIAL LOAD (Pr):</label>
                    <span className="font-bold text-brand-copper">{pr} kN</span>
                  </div>
                  <input type="range" min="0.1" max="50" step="0.1" value={pr} 
                         onChange={(e) => setPr(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                  <p className="text-[10px] text-brand-dark/50 font-sans mt-0.5">Total radial combined vector load in service.</p>
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">ROTATIONAL VELOCITY:</label>
                    <span className="font-bold text-brand-copper">{rpm} RPM</span>
                  </div>
                  <input type="range" min="100" max="18000" step="100" value={rpm} 
                         onChange={(e) => setRpm(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                </div>
              </div>
            </div>

            {/* Results Block */}
            <div className="flex flex-col justify-between bg-brand-dark text-white p-6 border-2 border-brand-dark">
              <div className="space-y-4">
                <span className="text-[9px] font-mono text-brand-copper uppercase tracking-widest font-bold block">CALCULATION OUTPUT (ISO 281:2007)</span>
                <h4 className="text-xs font-mono text-white/50">CALCULATED FATIGUE LIFE (L10h):</h4>
                
                <div className="space-y-1.5">
                  <p className="text-4xl md:text-5xl font-mono font-bold text-white tracking-tight">
                    {calculateBearingLife().toLocaleString()}
                  </p>
                  <p className="text-xs text-brand-copper font-mono font-bold tracking-wider">OPERATIONAL HOURS BEFORE FATIGUE</p>
                </div>

                <div className="text-[11px] font-mono text-white/70 border-t border-white/10 pt-4 space-y-2">
                  <p>• Assumes 90% reliability under strict ISO compliance.</p>
                  <p>• Highly recommended lubricated viscosity index: &gt;1.2</p>
                  <p>• Cross-compatible steel: <strong className="text-white">En31 High Carbon Steel</strong></p>
                </div>
              </div>

              <div className="text-[9px] font-mono text-white/30 border-t border-white/10 pt-4 mt-6">
                FORMULA: L10h = ((Cr/Pr)^p) * (10^6 / (60 * RPM))
              </div>
            </div>
          </div>
        )}

        {/* 2. Hydraulic Cylinder Force Calculator */}
        {activeTab === 'hydraulic' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-base font-serif font-bold tracking-tight text-brand-dark uppercase flex items-center gap-2">
                <Activity className="w-4 h-4 text-brand-copper" />
                CYLINDER PRESSURE & AREA PARAMETERS
              </h3>
              
              <div className="space-y-4 font-mono text-xs text-brand-dark">
                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">SYSTEM FLUID PRESSURE:</label>
                    <span className="font-bold text-brand-copper">{pressureBar} Bar</span>
                  </div>
                  <input type="range" min="10" max="450" step="5" value={pressureBar} 
                         onChange={(e) => setPressureBar(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                  <p className="text-[10px] text-brand-dark/50 font-sans mt-0.5">Typical industrial hydraulic lines range 100 - 350 Bar.</p>
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">PISTON BORE DIAMETER (Ø):</label>
                    <span className="font-bold text-brand-copper">{boreMm} mm</span>
                  </div>
                  <input type="range" min="20" max="250" step="2" value={boreMm} 
                         onChange={(e) => setBoreMm(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">ROD DIAMETER (Ø):</label>
                    <span className="font-bold text-brand-copper">{rodMm} mm</span>
                  </div>
                  <input type="range" min="10" max={boreMm - 5} step="1" value={rodMm} 
                         onChange={(e) => setRodMm(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                  <p className="text-[10px] text-brand-dark/50 font-sans mt-0.5">Annular area reduces the cylinder pull force during retraction.</p>
                </div>
              </div>
            </div>

            {/* Results Block */}
            <div className="flex flex-col justify-between bg-brand-dark text-white p-6 border-2 border-brand-dark">
              <div className="space-y-6">
                <span className="text-[9px] font-mono text-brand-copper uppercase tracking-widest font-bold block">THEORETICAL FORCE CALCULATIONS</span>
                
                <div className="grid grid-cols-2 gap-4 border-b border-white/10 pb-4">
                  <div>
                    <h4 className="text-[10px] font-mono text-white/50 uppercase">EXTENSION FORCE (PUSH)</h4>
                    <p className="text-2xl font-mono font-bold text-white mt-1">
                      {calculateHydraulicForce().pushN.toLocaleString()} N
                    </p>
                    <p className="text-xs text-brand-copper font-mono font-bold mt-1">
                      ({calculateHydraulicForce().pushTons} METRIC TONS)
                    </p>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-mono text-white/50 uppercase">RETRACTION FORCE (PULL)</h4>
                    <p className="text-2xl font-mono font-bold text-white mt-1">
                      {calculateHydraulicForce().pullN.toLocaleString()} N
                    </p>
                    <p className="text-xs text-brand-copper font-mono font-bold mt-1">
                      ({calculateHydraulicForce().pullTons} METRIC TONS)
                    </p>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-white/70 space-y-2">
                  <p>• Assumes 95% volumetric/mechanical efficiency.</p>
                  <p>• High-pressure hose specification: <strong className="text-white">BS ISO 1436 Premium</strong></p>
                  <p>• Minimum cylinder safety coefficient: <strong className="text-white">3.5 : 1</strong></p>
                </div>
              </div>

              <div className="text-[9px] font-mono text-white/30 border-t border-white/10 pt-4 mt-6">
                FORCE PUSH = Pressure * Piston Area | FORCE PULL = Pressure * Annular Area
              </div>
            </div>
          </div>
        )}

        {/* 3. Pneumatic Flow Calculator */}
        {activeTab === 'pneumatic' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h3 className="text-base font-serif font-bold tracking-tight text-brand-dark uppercase flex items-center gap-2">
                <Activity className="w-4 h-4 text-brand-copper" />
                ACTUATOR AIR LINE FLOW PARAMETERS
              </h3>
              
              <div className="space-y-4 font-mono text-xs text-brand-dark">
                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">CYLINDER BORE (Ø):</label>
                    <span className="font-bold text-brand-copper">{pneuBore} mm</span>
                  </div>
                  <input type="range" min="12" max="125" step="1" value={pneuBore} 
                         onChange={(e) => setPneuBore(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">CYLINDER STROKE LENGTH:</label>
                    <span className="font-bold text-brand-copper">{pneuStroke} mm</span>
                  </div>
                  <input type="range" min="10" max="1000" step="10" value={pneuStroke} 
                         onChange={(e) => setPneuStroke(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">OPERATING PRESSURE:</label>
                    <span className="font-bold text-brand-copper">{pneuPressure} Bar</span>
                  </div>
                  <input type="range" min="2" max="12" step="0.5" value={pneuPressure} 
                         onChange={(e) => setPneuPressure(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                </div>

                <div className="flex flex-col space-y-1">
                  <div className="flex justify-between">
                    <label className="text-brand-dark/50 font-bold uppercase text-[9px] tracking-wider">CYCLE REPETITIONS RATE:</label>
                    <span className="font-bold text-brand-copper">{pneuCycles} Cycles/min</span>
                  </div>
                  <input type="range" min="5" max="120" step="5" value={pneuCycles} 
                         onChange={(e) => setPneuCycles(Number(e.target.value))}
                         className="w-full h-1 bg-brand-cream rounded-none appearance-none cursor-pointer accent-brand-copper" />
                </div>
              </div>
            </div>

            {/* Results Block */}
            <div className="flex flex-col justify-between bg-brand-dark text-white p-6 border-2 border-brand-dark">
              <div className="space-y-6">
                <span className="text-[9px] font-mono text-brand-copper uppercase tracking-widest font-bold block">VOLUMETRIC AIR FLOW OUTCOME</span>
                
                <div className="border-b border-white/10 pb-4 space-y-4">
                  <div>
                    <h4 className="text-[10px] font-mono text-white/50 uppercase">STANDARD AIR PER COMPLETE CYCLE</h4>
                    <p className="text-2xl font-mono font-bold text-white mt-1">
                      {calculatePneumaticConsumption().volumePerCycle} NL
                    </p>
                    <p className="text-xs text-white/40 font-mono mt-0.5">Normal Litres (free compressed air)</p>
                  </div>
                  <div>
                    <h4 className="text-[10px] font-mono text-white/50 uppercase">CONTINUOUS FLOW REQUISITION</h4>
                    <p className="text-3xl font-mono font-bold text-brand-copper mt-1">
                      {calculatePneumaticConsumption().consumptionPerMin} NL/min
                    </p>
                    <p className="text-xs text-white/40 font-mono mt-0.5">Minimum compressor intake capability required</p>
                  </div>
                </div>

                <div className="text-[11px] font-mono text-white/70 space-y-1">
                  <p>• Calculated for a double-acting pneumatic configuration.</p>
                  <p>• Compressor recommendation: <strong className="text-white">Birmingham RSC-V30 Rotary Screw</strong></p>
                </div>
              </div>

              <div className="text-[9px] font-mono text-white/30 border-t border-white/10 pt-4 mt-6">
                COMPRESSION RATIO (CR) = (Pressure_Bar + 1.013) / 1.013
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
