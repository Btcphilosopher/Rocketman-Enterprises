import React, { useState } from 'react';
import { PRODUCT_CATALOGUE, Product } from '../productsData';
import { 
  Building, Edit3, Save, CheckCircle2, AlertTriangle, 
  Upload, Sparkles, RefreshCw, Layers 
} from 'lucide-react';

export default function ManufacturerPortal() {
  const [selectedSupplier, setSelectedSupplier] = useState<string>("Sheffield Precision Bearings");
  const [products, setProducts] = useState<Product[]>(PRODUCT_CATALOGUE);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);
  
  // RFQs for this supplier
  const [rfqs, setRfqs] = useState([
    { id: "RFQ-2026-X10", part: "7204-B-XL-TVP", qty: 100, targetPrice: 150.00, buyer: "Rolls-Royce Derby Plant", status: "PENDING" },
    { id: "RFQ-2026-X12", part: "SG-M2.0-36T-SH", qty: 250, targetPrice: 90.00, buyer: "Birmingham Automated Assembly Hub", status: "PENDING" }
  ]);

  const supplierProducts = products.filter(p => p.manufacturer === selectedSupplier);

  const startEdit = (p: Product) => {
    setEditingId(p.id);
    setEditPrice(p.price);
    setEditStock(p.stock);
  };

  const saveEdit = (id: string) => {
    const updated = products.map(p => {
      if (p.id === id) {
        return { ...p, price: editPrice, stock: editStock };
      }
      return p;
    });
    setProducts(updated);
    setEditingId(null);
  };

  const handleRfqAction = (rfqId: string, action: 'ACCEPT' | 'REJECT' | 'COUNTER', counterPrice?: number) => {
    const updated = rfqs.map(r => {
      if (r.id === rfqId) {
        return { 
          ...r, 
          status: action === 'ACCEPT' ? 'ACCEPTED' : action === 'REJECT' ? 'REJECTED' : 'COUNTER_PROPOSED',
          targetPrice: counterPrice || r.targetPrice 
        };
      }
      return r;
    });
    setRfqs(updated);
  };

  return (
    <div id="manufacturer-portal" className="bg-white border-2 border-brand-dark shadow-sm">
      {/* Manufacturer Select Header */}
      <div className="bg-brand-dark p-6 text-white flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-brand-copper text-brand-dark">
            <Building className="w-6 h-6" />
          </div>
          <div>
            <span className="text-[10px] font-mono text-brand-copper uppercase tracking-widest block font-bold">MANUFACTURER CREDENTIALS DELEGATION</span>
            <select value={selectedSupplier} onChange={(e) => setSelectedSupplier(e.target.value)}
                    className="bg-brand-dark text-white font-mono font-bold text-sm border-b-2 border-brand-copper pb-1 pr-6 focus:outline-none cursor-pointer mt-1">
              <option value="Sheffield Precision Bearings" className="bg-brand-dark text-white">Sheffield Precision Bearings (Code: SP-SHEFFIELD)</option>
              <option value="Cotswold Hydraulics & Controls" className="bg-brand-dark text-white">Cotswold Hydraulics & Controls (Code: CH-GLOUCESTER)</option>
              <option value="Birmingham Pneumatic Systems" className="bg-brand-dark text-white">Birmingham Pneumatic Systems (Code: BP-BIRMINGHAM)</option>
              <option value="Coventry Advanced Robotics" className="bg-brand-dark text-white">Coventry Advanced Robotics (Code: CR-COVENTRY)</option>
            </select>
          </div>
        </div>

        <div className="text-left md:text-right font-mono text-xs">
          <p className="text-white/60 uppercase tracking-wider text-[9px] font-bold">QUALITY AUDIT STATUS:</p>
          <p className="text-brand-green font-bold bg-brand-cream px-3 py-1.5 mt-1.5 inline-block border-2 border-brand-green uppercase tracking-widest text-[10px]">CLASS A BS EN ISO 9001:2015</p>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Supplier Inventory Listing */}
        <div className="lg:col-span-2 space-y-4">
          <div className="border-b-2 border-brand-dark pb-2 flex justify-between items-center">
            <h3 className="text-base font-serif font-bold text-brand-dark uppercase">MANAGED STOCK & PRICE CATALOGUE</h3>
            <span className="text-xs font-mono text-brand-dark/50">{supplierProducts.length} items registered</span>
          </div>

          <div className="border-2 border-brand-dark divide-y-2 divide-brand-dark overflow-hidden">
            {supplierProducts.map((p) => (
              <div key={p.id} className="p-4 bg-white hover:bg-brand-cream/10 transition-all space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-sm font-bold text-brand-dark uppercase font-serif">{p.name}</h4>
                    <p className="text-[10px] text-brand-dark/50 font-mono mt-0.5">SKU: {p.sku} | Part No: {p.partNumber}</p>
                  </div>
                  <div className="text-right font-mono">
                    <p className="text-[9px] text-brand-dark/40 uppercase font-bold">Current Price</p>
                    <p className="text-sm font-bold text-brand-green">£{p.price.toFixed(2)} GBP</p>
                  </div>
                </div>

                {/* Inline edit container */}
                {editingId === p.id ? (
                  <div className="p-4 bg-brand-cream border border-brand-dark/20 rounded-none grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-brand-dark/60 uppercase tracking-wider">UNIT PRICE (£):</label>
                      <input type="number" step="0.01" value={editPrice} onChange={(e) => setEditPrice(Number(e.target.value))}
                             className="w-full px-3 py-2 text-xs font-mono bg-white border-2 border-brand-dark text-brand-dark focus:outline-none" />
                    </div>
                    <div>
                      <label className="block text-[9px] font-mono font-bold text-brand-dark/60 uppercase tracking-wider">STOCK LEVEL:</label>
                      <input type="number" value={editStock} onChange={(e) => setEditStock(Number(e.target.value))}
                             className="w-full px-3 py-2 text-xs font-mono bg-white border-2 border-brand-dark text-brand-dark focus:outline-none" />
                    </div>
                    <div className="flex gap-1 pt-3">
                      <button onClick={() => saveEdit(p.id)}
                              className="flex-1 py-2.5 bg-brand-green hover:bg-brand-copper text-white hover:text-brand-dark text-[10px] font-sans font-bold tracking-widest uppercase border border-brand-green transition-all duration-200">
                        <Save className="w-3.5 h-3.5 inline mr-1 align-middle" /> SAVE
                      </button>
                      <button onClick={() => setEditingId(null)}
                              className="flex-1 py-2.5 bg-white text-brand-dark hover:bg-brand-cream text-[10px] font-sans font-bold tracking-widest uppercase border border-brand-dark transition-all duration-200">
                        CANCEL
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="flex justify-between items-center text-[11px] font-mono text-brand-dark bg-brand-cream/50 p-3 border border-brand-dark/10 rounded-none">
                    <span>Stock: <strong className="text-brand-dark">{p.stock} units</strong> ({p.warehouse})</span>
                    <button onClick={() => startEdit(p)}
                            className="text-[10px] font-mono text-brand-copper font-bold hover:underline flex items-center gap-1">
                      <Edit3 className="w-3.5 h-3.5" /> ADJUST OFFERS
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* RFQ & Compliance Hub */}
        <div className="space-y-6">
          {/* Supplier RFQs */}
          <div className="p-5 bg-brand-cream border-2 border-brand-dark space-y-4">
            <h4 className="text-xs font-sans font-bold tracking-widest text-brand-dark uppercase flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-brand-copper" />
              OUTSTANDING B2B RFQs
            </h4>

            <div className="space-y-4">
              {rfqs.map((r, i) => (
                <div key={i} className="p-4 bg-white border-2 border-brand-dark space-y-2.5 font-mono text-xs">
                  <div className="flex justify-between items-start border-b border-brand-dark/10 pb-2">
                    <div>
                      <span className="text-[9px] text-brand-dark/40 font-bold uppercase tracking-wider">REQ ID:</span>
                      <p className="font-bold text-brand-dark">{r.id}</p>
                    </div>
                    <span className={`px-2.5 py-0.5 text-[9px] font-bold border ${
                      r.status === 'ACCEPTED' ? 'bg-brand-green/5 text-brand-green border-brand-green' :
                      r.status === 'REJECTED' ? 'bg-red-50 text-red-700 border-red-300' :
                      r.status === 'COUNTER_PROPOSED' ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                      'bg-brand-copper/10 text-brand-copper border-brand-copper animate-pulse'
                    }`}>
                      {r.status}
                    </span>
                  </div>

                  <div className="space-y-1 text-[11px] text-brand-dark/80">
                    <p>Buyer: <strong className="text-brand-dark">{r.buyer}</strong></p>
                    <p>Part: <strong className="text-brand-dark">{r.part}</strong> (Qty: {r.qty})</p>
                    <p>Target Bid: <strong className="text-brand-copper">£{r.targetPrice.toFixed(2)} / unit</strong></p>
                  </div>

                  {r.status === 'PENDING' && (
                    <div className="flex gap-1.5 pt-2 border-t border-brand-dark/10">
                      <button onClick={() => handleRfqAction(r.id, 'ACCEPT')}
                              className="flex-1 py-1.5 bg-brand-green text-white text-[9px] font-bold uppercase hover:bg-brand-copper hover:text-brand-dark transition-all duration-200">
                        BID MATCH
                      </button>
                      <button onClick={() => handleRfqAction(r.id, 'COUNTER', r.targetPrice * 1.1)}
                              className="flex-1 py-1.5 bg-brand-dark text-white text-[9px] font-bold uppercase hover:bg-brand-copper hover:text-brand-dark transition-all duration-200">
                        COUNTER (+10%)
                      </button>
                      <button onClick={() => handleRfqAction(r.id, 'REJECT')}
                              className="px-2.5 py-1.5 bg-brand-cream text-brand-dark text-[9px] font-bold uppercase hover:bg-brand-dark hover:text-white transition-all duration-200">
                        DECLINE
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Compliance Locker */}
          <div className="p-5 bg-brand-cream border-2 border-brand-dark space-y-4">
            <h4 className="text-xs font-sans font-bold tracking-widest text-brand-dark uppercase flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-brand-copper" />
              METALLURGICAL LOGS & CERTIFICATIONS
            </h4>
            
            <div className="space-y-3 font-mono text-xs">
              <div className="p-4 bg-white border-2 border-brand-dark space-y-1">
                <div className="flex justify-between font-bold">
                  <span className="text-brand-dark">BS EN 10204 3.1 Cert</span>
                  <span className="text-brand-green font-bold">VERIFIED</span>
                </div>
                <p className="text-[10px] text-brand-dark/50">Chemical composition & tensile testing audit. Signed July 2026.</p>
              </div>

              <div className="p-4 bg-white border-2 border-brand-dark space-y-1">
                <div className="flex justify-between font-bold">
                  <span className="text-brand-dark">UKCA Engineering Stamp</span>
                  <span className="text-brand-green font-bold">VERIFIED</span>
                </div>
                <p className="text-[10px] text-brand-dark/50">Conforming to machinery safety regulations 2008.</p>
              </div>

              <button className="w-full py-3.5 border-2 border-dashed border-brand-dark/30 text-brand-dark/60 text-[10px] font-sans font-bold tracking-widest uppercase hover:border-brand-copper hover:text-brand-copper transition-all duration-200 flex items-center justify-center gap-2 bg-white">
                <Upload className="w-4 h-4 text-brand-copper" /> UPLOAD METALLURGICAL ASSAY
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
