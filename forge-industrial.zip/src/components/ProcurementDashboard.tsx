import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { PRODUCT_CATALOGUE } from '../productsData';
import { SpendDataPoint, ProcurementConfig, QuoteRequest } from '../types';
import { 
  Briefcase, Plus, Users, ShieldAlert, CheckCircle, 
  Clock, FileDown, TrendingUp, AlertCircle, RefreshCw 
} from 'lucide-react';

const INITIAL_SPEND_DATA: SpendDataPoint[] = [
  { month: 'Feb 26', "Mechanical Parts": 4500, "Hydraulics": 3200, "Pneumatics": 1800, "Electrical & Automation": 9200 },
  { month: 'Mar 26', "Mechanical Parts": 6200, "Hydraulics": 4100, "Pneumatics": 2400, "Electrical & Automation": 11500 },
  { month: 'Apr 26', "Mechanical Parts": 8900, "Hydraulics": 5800, "Pneumatics": 4100, "Electrical & Automation": 14000 },
  { month: 'May 26', "Mechanical Parts": 7400, "Hydraulics": 6200, "Pneumatics": 3800, "Electrical & Automation": 12800 },
  { month: 'Jun 26', "Mechanical Parts": 11200, "Hydraulics": 8900, "Pneumatics": 5200, "Electrical & Automation": 18500 },
  { month: 'Jul 26', "Mechanical Parts": 14500, "Hydraulics": 12400, "Pneumatics": 7800, "Electrical & Automation": 22400 },
];

const INITIAL_CONFIG: ProcurementConfig = {
  companyName: "BAE Systems Marine Division",
  taxRegistrationNumber: "GB 982 7431 12",
  approvalLimit: 1500.00,
  requirePO: true,
  budgetCap: 120000.00,
  spentThisMonth: 57100.00,
  users: [
    { name: "Sir Marcus Pendelton", role: "Approver", email: "m.pendelton@baesystems.co.uk" },
    { name: "Alistair Thorne", role: "Admin", email: "a.thorne@baesystems.co.uk" },
    { name: "Siobhan Clegg", role: "Buyer", email: "s.clegg@baesystems.co.uk" }
  ]
};

const INITIAL_QUOTES: QuoteRequest[] = [
  {
    id: "RFQ-2026-904",
    companyName: "BAE Systems Marine Division",
    contactName: "Siobhan Clegg",
    email: "s.clegg@baesystems.co.uk",
    items: [
      { product: PRODUCT_CATALOGUE[0], quantity: 20 }, // bearings
      { product: PRODUCT_CATALOGUE[2], quantity: 15 }, // shafts
    ],
    status: "APPROVED",
    poNumber: "PO-MARINE-9824A",
    totalAmount: 4662.00,
    date: "2026-07-22"
  },
  {
    id: "RFQ-2026-915",
    companyName: "BAE Systems Marine Division",
    contactName: "Siobhan Clegg",
    email: "s.clegg@baesystems.co.uk",
    items: [
      { product: PRODUCT_CATALOGUE[3], quantity: 2 }, // solenoid valve
    ],
    status: "PENDING",
    totalAmount: 990.00,
    date: "2026-07-25"
  }
];

export default function ProcurementDashboard() {
  const [config, setConfig] = useState<ProcurementConfig>(INITIAL_CONFIG);
  const [quotes, setQuotes] = useState<QuoteRequest[]>(INITIAL_QUOTES);
  const [activeTab, setActiveTab] = useState<'analytics' | 'workflows' | 'history'>('analytics');
  
  // States for adding user
  const [newUserName, setNewUserName] = useState('');
  const [newUserRole, setNewUserRole] = useState<'Admin' | 'Buyer' | 'Approver'>('Buyer');
  const [newUserEmail, setNewUserEmail] = useState('');

  // States for edit budget
  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [editedCap, setEditedCap] = useState(config.budgetCap);
  const [editedLimit, setEditedLimit] = useState(config.approvalLimit);

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName || !newUserEmail) return;
    const updatedUsers = [...config.users, { name: newUserName, role: newUserRole, email: newUserEmail }];
    setConfig({ ...config, users: updatedUsers });
    setNewUserName('');
    setNewUserEmail('');
  };

  const handleSaveConfig = () => {
    setConfig({
      ...config,
      budgetCap: editedCap,
      approvalLimit: editedLimit
    });
    setIsEditingBudget(false);
  };

  const triggerQuoteDownload = (quote: QuoteRequest) => {
    const content = `========================================================================
                      FORGE INDUSTRIAL LTD
          - Engineering Britain's Future • Sheffield Forge Division -
========================================================================
QUOTE ID: ${quote.id}
DATE: ${quote.date}
COMPANY: ${quote.companyName}
TAX ID: ${config.taxRegistrationNumber}
BUYER REQ: ${quote.contactName} (${quote.email})
STATUS: ${quote.status}
PO NUMBER: ${quote.poNumber || "N/A - ENTERPRISE WORKFLOW ATTACHED"}
------------------------------------------------------------------------
LINE ITEMS:
${quote.items.map((it, idx) => {
  const linePrice = it.product.price * it.quantity;
  return `${idx + 1}. SKU: ${it.product.sku} | PART: ${it.product.partNumber}
    DESC: ${it.product.name}
    QTY: ${it.quantity} x £${it.product.price.toFixed(2)} GBP = £${linePrice.toFixed(2)} GBP`;
}).join('\n')}
------------------------------------------------------------------------
NET SUB-TOTAL:  £${(quote.totalAmount / 1.2).toFixed(2)} GBP
VAT REG (20%):  £${(quote.totalAmount * 0.2 / 1.2).toFixed(2)} GBP
TOTAL REQUISITION AMOUNT: £${quote.status === 'APPROVED' ? quote.totalAmount.toFixed(2) : (quote.totalAmount * 0.9).toFixed(2)} GBP (Contract Tier pricing applied)
========================================================================
BS EN 10204 / UKCA Compliance standard documents are auto-compiled.
Delivery Depot: Birmingham Logistics Central. Lead time: 24-48 Hours.
========================================================================`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `FORGE_INDUSTRIAL_${quote.id}_QUOTATION.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div id="procurement-dashboard-container" className="bg-white border-2 border-brand-dark shadow-sm">
      {/* Corporate Metadata Header */}
      <div className="bg-brand-cream border-b-2 border-brand-dark p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <span className="text-[10px] font-mono text-brand-copper uppercase tracking-wider block font-bold flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-brand-green"></span>
            B2B ENTERPRISE PROFILE ACTIVE
          </span>
          <h2 className="text-2xl font-serif font-bold text-brand-dark mt-1">{config.companyName}</h2>
          <p className="text-xs text-brand-dark/60 font-mono mt-1">VAT ID: {config.taxRegistrationNumber} | Sector: Aerospace & Shipbuilding</p>
        </div>

        <div className="flex gap-2">
          <button onClick={() => setIsEditingBudget(!isEditingBudget)}
                  className="px-5 py-3 bg-brand-dark text-white hover:bg-brand-copper hover:text-brand-dark text-xs font-sans font-bold tracking-widest uppercase border-2 border-brand-dark transition-all duration-200">
            {isEditingBudget ? "CLOSE SETTINGS" : "EDIT COV-LIMITS"}
          </button>
        </div>
      </div>

      {/* Editing Modal/Section if toggled */}
      {isEditingBudget && (
        <div className="bg-brand-cream border-b-2 border-brand-dark p-6 grid grid-cols-1 md:grid-cols-3 gap-6 animate-fadeIn">
          <div>
            <label className="block text-xs font-mono font-bold text-brand-dark mb-2 uppercase">ANNUAL BUDGET CAP (£):</label>
            <input type="number" value={editedCap} onChange={(e) => setEditedCap(Number(e.target.value))}
                   className="w-full px-4 py-2.5 text-xs font-mono bg-white border-2 border-brand-dark text-brand-dark focus:outline-none" />
          </div>
          <div>
            <label className="block text-xs font-mono font-bold text-brand-dark mb-2 uppercase">SINGLE-PURCHASE APPROVAL BAR (£):</label>
            <input type="number" value={editedLimit} onChange={(e) => setEditedLimit(Number(e.target.value))}
                   className="w-full px-4 py-2.5 text-xs font-mono bg-white border-2 border-brand-dark text-brand-dark focus:outline-none" />
          </div>
          <div className="flex items-end">
            <button onClick={handleSaveConfig}
                    className="w-full py-3 bg-brand-green hover:bg-brand-copper hover:text-brand-dark text-white text-xs font-sans font-bold tracking-widest uppercase border-2 border-brand-green hover:border-brand-copper transition-all duration-200">
              SAVE CHANGES
            </button>
          </div>
        </div>
      )}

      {/* Rhythmic Spacing Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 border-b-2 border-brand-dark bg-white divide-y md:divide-y-0 md:divide-x divide-brand-dark">
        <div className="p-6">
          <p className="text-[10px] font-mono text-brand-dark/50 uppercase tracking-widest font-bold">ANNUAL SPEND BUDGET</p>
          <p className="text-2xl font-serif font-bold text-brand-dark mt-2">£{config.budgetCap.toLocaleString()}</p>
          <div className="w-full bg-brand-cream border border-brand-dark/25 h-3 mt-4 overflow-hidden">
            <div className="bg-brand-green h-full" style={{ width: `${(config.spentThisMonth / config.budgetCap) * 100}%` }}></div>
          </div>
        </div>
        <div className="p-6">
          <p className="text-[10px] font-mono text-brand-dark/50 uppercase tracking-widest font-bold">SPENT THIS CALENDAR MONTH</p>
          <p className="text-2xl font-serif font-bold text-brand-green mt-2">£{config.spentThisMonth.toLocaleString()}</p>
          <p className="text-[10px] text-brand-dark/55 font-mono mt-1">Remaining: £{(config.budgetCap - config.spentThisMonth).toLocaleString()}</p>
        </div>
        <div className="p-6">
          <p className="text-[10px] font-mono text-brand-dark/50 uppercase tracking-widest font-bold">SIGN-OFF THRESHOLD</p>
          <p className="text-2xl font-serif font-bold text-brand-copper mt-2">£{config.approvalLimit.toLocaleString()}</p>
          <p className="text-[10px] text-brand-dark/55 font-mono mt-1">Orders above require Approver PO</p>
        </div>
        <div className="p-6">
          <p className="text-[10px] font-mono text-brand-dark/50 uppercase tracking-widest font-bold">MANDATORY PO CODES</p>
          <p className="text-2xl font-serif font-bold text-brand-dark mt-2">{config.requirePO ? "ENFORCED" : "BYPASSED"}</p>
          <p className="text-[10px] text-brand-dark/55 font-mono mt-1">Required for automated invoicing</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b-2 border-brand-dark bg-brand-cream text-xs font-sans font-bold tracking-widest">
        <button onClick={() => setActiveTab('analytics')}
                className={`px-6 py-4 flex-1 md:flex-none uppercase border-r-2 border-brand-dark transition-all duration-200 ${activeTab === 'analytics' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <TrendingUp className="w-4 h-4 inline mr-2 align-text-bottom" />
          ANALYTICS
        </button>
        <button onClick={() => setActiveTab('workflows')}
                className={`px-6 py-4 flex-1 md:flex-none uppercase border-r-2 border-brand-dark transition-all duration-200 ${activeTab === 'workflows' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Users className="w-4 h-4 inline mr-2 align-text-bottom" />
          PERMISSIONS
        </button>
        <button onClick={() => setActiveTab('history')}
                className={`px-6 py-4 flex-1 md:flex-none uppercase transition-all duration-200 ${activeTab === 'history' ? 'bg-brand-dark text-white' : 'text-brand-dark hover:bg-white'}`}>
          <Clock className="w-4 h-4 inline mr-2 align-text-bottom" />
          QUOTATIONS ({quotes.length})
        </button>
      </div>

      <div className="p-6">
        {/* 1. Spend Analytics */}
        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-base font-serif font-bold text-brand-dark uppercase">H1 2026 CATEGORICAL PROCUREMENT OUTLAYS</h3>
                <p className="text-xs text-brand-dark/60 font-sans mt-0.5">A Swiss-editorial representation of outlays mapped across key engineering categories.</p>
              </div>
            </div>

            <div className="h-[280px] w-full font-mono text-[10px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={INITIAL_SPEND_DATA} margin={{ top: 20, right: 10, left: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E2D9" />
                  <XAxis dataKey="month" stroke="#1A1A1A" />
                  <YAxis stroke="#1A1A1A" />
                  <Tooltip cursor={{ fill: 'rgba(0,66,37,0.03)' }} contentStyle={{ fontFamily: 'monospace', fontSize: '11px', backgroundColor: '#F5F5F0', border: '2px solid #1A1A1A', borderRadius: '0' }} />
                  <Legend iconType="rect" />
                  <Bar dataKey="Mechanical Parts" stackId="a" fill="#1A1A1A" name="Mechanical" />
                  <Bar dataKey="Hydraulics" stackId="a" fill="#B87333" name="Hydraulics" />
                  <Bar dataKey="Pneumatics" stackId="a" fill="#004225" name="Pneumatics" />
                  <Bar dataKey="Electrical & Automation" stackId="a" fill="#6B7280" name="Electrical" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* 2. Workflows & Permissions */}
        {activeTab === 'workflows' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-4">
              <h3 className="text-base font-serif font-bold text-brand-dark uppercase">AUTHORIZED TEAM MEMBERS</h3>
              
              <div className="border-2 border-brand-dark divide-y-2 divide-brand-dark">
                {config.users.map((u, i) => (
                  <div key={i} className="p-4 flex justify-between items-center bg-white hover:bg-brand-cream/40 transition-all">
                    <div>
                      <p className="text-sm font-bold text-brand-dark font-sans">{u.name}</p>
                      <p className="text-xs text-brand-dark/50 font-mono">{u.email}</p>
                    </div>
                    <div>
                      <span className={`px-3 py-1 text-[9px] font-mono font-bold tracking-widest uppercase border-2 ${
                        u.role === 'Approver' ? 'bg-brand-cream text-brand-copper border-brand-copper' :
                        u.role === 'Admin' ? 'bg-brand-dark text-white border-brand-dark' :
                        'bg-white text-brand-green border-brand-green'
                      }`}>
                        {u.role}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Add Team Member form */}
            <div className="p-6 bg-brand-cream border-2 border-brand-dark space-y-4">
              <h4 className="text-xs font-sans font-bold tracking-widest text-brand-dark uppercase flex items-center gap-1.5">
                <Plus className="w-4 h-4 text-brand-copper" />
                AUTHORIZE PROCUREMENT USER
              </h4>
              <form onSubmit={handleAddUser} className="space-y-4 font-sans text-xs">
                <div className="flex flex-col space-y-1">
                  <label className="text-brand-dark font-mono font-bold text-[10px]">FULL NAME:</label>
                  <input type="text" required value={newUserName} onChange={(e) => setNewUserName(e.target.value)}
                         placeholder="e.g. Lt. Cmdr. Sterling"
                         className="px-4 py-2.5 bg-white border-2 border-brand-dark text-brand-dark focus:outline-none" />
                </div>
                <div className="flex flex-col space-y-1">
                  <label className="text-brand-dark font-mono font-bold text-[10px]">CORPORATE EMAIL:</label>
                  <input type="email" required value={newUserEmail} onChange={(e) => setNewUserEmail(e.target.value)}
                         placeholder="user@baesystems.co.uk"
                         className="px-4 py-2.5 bg-white border-2 border-brand-dark text-brand-dark focus:outline-none" />
                </div>
                <div className="flex flex-col space-y-1">
                  <label className="text-brand-dark font-mono font-bold text-[10px]">DESIGNATED ASSIGNED ROLE:</label>
                  <select value={newUserRole} onChange={(e) => setNewUserRole(e.target.value as any)}
                          className="px-4 py-2.5 bg-white border-2 border-brand-dark text-brand-dark focus:outline-none">
                    <option value="Buyer">Buyer (Limit: Up to Approval Bar)</option>
                    <option value="Approver">Approver (Unrestricted Signature)</option>
                    <option value="Admin">Administrator (Adjust System Caps)</option>
                  </select>
                </div>
                <button type="submit"
                        className="w-full py-3 bg-brand-dark text-white hover:bg-brand-copper hover:text-brand-dark text-xs font-sans font-bold tracking-widest uppercase border-2 border-brand-dark transition-all duration-200">
                  AUTHORIZE SIGNATURE
                </button>
              </form>
            </div>
          </div>
        )}

        {/* 3. Requisitions History */}
        {activeTab === 'history' && (
          <div className="space-y-4">
            <h3 className="text-base font-serif font-bold text-brand-dark uppercase">REQUISITIONS & VERIFIED QUOTES</h3>
            
            <div className="space-y-6">
              {quotes.map((q) => (
                <div key={q.id} className="border-2 border-brand-dark bg-white p-6 space-y-4 hover:border-brand-green transition-all duration-200">
                  <div className="flex justify-between items-start md:items-center flex-col md:flex-row gap-2 border-b border-brand-dark/10 pb-3">
                    <div>
                      <p className="text-[10px] font-mono text-brand-dark/40 uppercase tracking-widest font-bold">Requisition Identifier</p>
                      <p className="text-base font-bold font-mono text-brand-dark">{q.id}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`px-2.5 py-0.5 text-[9px] font-mono font-bold tracking-widest uppercase border-2 ${
                        q.status === 'APPROVED' ? 'bg-brand-green/5 text-brand-green border-brand-green' :
                        'bg-brand-copper/10 text-brand-copper border-brand-copper animate-pulse'
                      }`}>
                        {q.status}
                      </span>
                      <span className="text-xs font-mono text-brand-dark/40">{q.date}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs font-sans">
                    <div>
                      <h4 className="text-[10px] font-mono text-brand-dark/50 uppercase tracking-widest font-bold">LINE PARTS LISTING:</h4>
                      <ul className="mt-2.5 space-y-1.5">
                        {q.items.map((it, idx) => (
                          <li key={idx} className="text-brand-dark/80 list-disc list-inside">
                            {it.product.name} (x{it.quantity}) - <span className="font-bold text-brand-dark">£{(it.product.price * it.quantity).toLocaleString()}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="bg-brand-cream p-4 border-2 border-brand-dark flex flex-col justify-between">
                      <div>
                        <p className="text-[10px] font-mono text-brand-dark/50 uppercase tracking-widest font-bold">TIER 1 PRICING COMPROMISE TOTAL:</p>
                        <p className="text-xl font-bold text-brand-dark mt-1">£{q.totalAmount.toLocaleString()}</p>
                      </div>
                      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mt-4 pt-3 border-t border-brand-dark/10 gap-2">
                        <span className="text-[9px] text-brand-dark/60 font-mono font-bold">PO: {q.poNumber || "PO-MARINE-PENDING"}</span>
                        <button onClick={() => triggerQuoteDownload(q)}
                                className="text-[10px] font-mono text-brand-green hover:text-brand-copper font-bold uppercase flex items-center gap-1">
                          <FileDown className="w-4 h-4" /> DOWNLOAD OFFICIAL COMPLIANCE QUOTE
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
