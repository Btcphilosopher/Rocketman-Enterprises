import { useState, useEffect } from 'react';
import { CartItem, Beer, Product } from './types';
import Header from './components/Header';
import HomeHero from './components/HomeHero';
import HomeFeatured from './components/HomeFeatured';
import BeerCatalogue from './components/BeerCatalogue';
import TaproomPage from './components/TaproomPage';
import ShopPage from './components/ShopPage';
import EventsPage from './components/EventsPage';
import JournalPage from './components/JournalPage';
import StoryPage from './components/StoryPage';
import Footer from './components/Footer';

import { Compass, User, Clock, MapPin, Check, LogOut, Award, RefreshCw, ShoppingBag, X, Minus, Plus, Trash2 } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(true);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isAccountOpen, setIsAccountOpen] = useState<boolean>(false);

  // Exact image URLs generated from the tools
  const breweryHeroUrl = '/src/assets/images/brewery_hero_1785675377789.jpg';
  const lighthouseUrl = '/src/assets/images/coastal_lighthouse_1785675396642.jpg';

  // Apply dark/light body classes on change
  useEffect(() => {
    const body = document.body;
    if (isDarkMode) {
      body.classList.add('dark');
      body.style.backgroundColor = '#0d161f';
      body.style.color = '#faf8f5';
    } else {
      body.classList.remove('dark');
      body.style.backgroundColor = '#FAF8F5';
      body.style.color = '#0d161f';
    }
  }, [isDarkMode]);

  // Add standard 4-pack directly from catalog
  const handleAddBeerToCart = (beer: Beer) => {
    const existing = cartItems.find(item => item.product.id === beer.id && !item.isSubscription);
    if (existing) {
      setCartItems(cartItems.map(item =>
        item.product.id === beer.id && !item.isSubscription
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCartItems([...cartItems, { id: beer.id, product: beer, quantity: 1 }]);
    }
    setIsCartOpen(true);
  };

  // Add custom product (merch/crates) to cart
  const handleAddCartItem = (newItem: CartItem) => {
    const existing = cartItems.find(item => item.id === newItem.id);
    if (existing) {
      setCartItems(cartItems.map(item =>
        item.id === newItem.id
          ? { ...item, quantity: item.quantity + newItem.quantity }
          : item
      ));
    } else {
      setCartItems([...cartItems, newItem]);
    }
    setIsCartOpen(true);
  };

  const handleRemoveFromCart = (itemId: string) => {
    setCartItems(cartItems.filter(item => item.id !== itemId));
  };

  const handleUpdateCartQty = (itemId: string, qty: number) => {
    if (qty <= 0) {
      handleRemoveFromCart(itemId);
    } else {
      setCartItems(cartItems.map(item =>
        item.id === itemId ? { ...item, quantity: qty } : item
      ));
    }
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleNavigate = (viewId: string) => {
    if (viewId === 'sustainability') {
      setCurrentView('story');
      // Scroll to sustainability section after delay
      setTimeout(() => {
        const el = document.getElementById('ingredients-map-block');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 300);
    } else if (viewId === 'find-us') {
      setCurrentView('taproom');
      setTimeout(() => {
        const el = document.getElementById('taproom-booking');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 300);
    } else {
      setCurrentView(viewId);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <div className={`min-h-screen flex flex-col justify-between overflow-x-hidden ${isDarkMode ? 'bg-navy-950 text-cream-100' : 'bg-cream-100 text-navy-900'}`}>
      
      {/* Sticky Premium Navigation */}
      <Header
        currentView={currentView}
        setCurrentView={handleNavigate}
        onOpenCart={() => setIsCartOpen(true)}
        cartItemsCount={totalCartCount}
        onOpenAccount={() => setIsAccountOpen(true)}
        isDarkMode={isDarkMode}
        toggleDarkMode={() => setIsDarkMode(!isDarkMode)}
      />

      {/* Main Dynamic Viewport */}
      <main className="flex-grow">
        {currentView === 'home' && (
          <div className="animate-fadeIn">
            <HomeHero onNavigate={handleNavigate} isDarkMode={isDarkMode} breweryHeroUrl={breweryHeroUrl} />
            <HomeFeatured onNavigate={handleNavigate} isDarkMode={isDarkMode} lighthouseUrl={lighthouseUrl} />
          </div>
        )}

        {currentView === 'beer' && (
          <BeerCatalogue onAddToCart={handleAddBeerToCart} isDarkMode={isDarkMode} />
        )}

        {currentView === 'taproom' && (
          <TaproomPage isDarkMode={isDarkMode} />
        )}

        {currentView === 'story' && (
          <StoryPage isDarkMode={isDarkMode} />
        )}

        {currentView === 'events' && (
          <EventsPage isDarkMode={isDarkMode} />
        )}

        {currentView === 'shop' && (
          <ShopPage
            onAddToCartItem={handleAddCartItem}
            cartItems={cartItems}
            onRemoveFromCart={handleRemoveFromCart}
            onUpdateCartQty={handleUpdateCartQty}
            onClearCart={handleClearCart}
            isDarkMode={isDarkMode}
          />
        )}

        {currentView === 'journal' && (
          <JournalPage isDarkMode={isDarkMode} />
        )}
      </main>

      {/* Global Brand Footer */}
      <Footer onNavigate={handleNavigate} isDarkMode={isDarkMode} />

      {/* 1. Global Sliding Cart Drawer */}
      {isCartOpen && (
        <div id="sidebar-cart-drawer" className="fixed inset-0 z-50 flex justify-end">
          {/* Backdrop */}
          <div className="fixed inset-0 bg-navy-950/80 backdrop-blur-sm" onClick={() => setIsCartOpen(false)}></div>
          
          {/* Drawer content */}
          <div className={`relative w-full max-w-md h-full flex flex-col justify-between shadow-2xl p-6 sm:p-8 border-l ${
            isDarkMode ? 'bg-navy-900 border-gold/15 text-cream-100' : 'bg-cream-50 border-navy-900/10 text-navy-900'
          }`}>
            <button
              id="close-cart-drawer"
              onClick={() => setIsCartOpen(false)}
              className="absolute top-4 right-4 text-slate-gray hover:text-gold"
            >
              ✕
            </button>

            <div className="space-y-6">
              <div className="flex items-center gap-3 border-b border-navy-900/5 dark:border-gold/10 pb-4">
                <ShoppingBag className="w-6 h-6 text-gold" />
                <h3 className="font-serif text-2xl font-bold">Your Provisions Crate</h3>
              </div>

              {cartItems.length === 0 ? (
                <div className="text-center py-16 space-y-4">
                  <Compass className="w-12 h-12 text-gold/20 mx-auto animate-spin-slow" />
                  <p className="font-sans text-xs text-slate-gray">Your crate is currently empty.</p>
                  <button
                    onClick={() => { setIsCartOpen(false); handleNavigate('shop'); }}
                    className="font-sans text-[10px] tracking-widest font-extrabold text-gold hover:underline"
                  >
                    GO TO RETAIL STORE
                  </button>
                </div>
              ) : (
                <div className="space-y-4 max-h-[55vh] overflow-y-auto pr-2">
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex gap-4 items-center border-b border-navy-900/5 dark:border-gold/5 pb-4 text-xs">
                      <img
                        src={item.product.imageUrl}
                        alt={item.product.name}
                        className="w-16 h-12 object-cover rounded border border-gold/10"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex-1 space-y-0.5">
                        <h4 className="font-sans font-bold leading-tight truncate">{item.product.name}</h4>
                        <p className="font-sans text-[10px] text-gold font-bold">
                          ${item.product.price.toFixed(2)} {item.isSubscription ? `(${item.frequency})` : ''}
                        </p>
                        {item.selectedSize && <p className="font-sans text-[9px] text-slate-gray">Size: {item.selectedSize}</p>}
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleUpdateCartQty(item.id, item.quantity - 1)}
                          className="p-1 hover:text-gold"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="font-sans font-extrabold text-gold text-center w-4">{item.quantity}</span>
                        <button
                          onClick={() => handleUpdateCartQty(item.id, item.quantity + 1)}
                          className="p-1 hover:text-gold"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleRemoveFromCart(item.id)}
                          className="p-1 hover:text-red-500 ml-1 text-slate-gray"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cartItems.length > 0 && (
              <div className="border-t border-navy-900/10 dark:border-gold/10 pt-5 space-y-4">
                <div className="flex justify-between items-center text-xs font-sans">
                  <span className="text-slate-gray font-semibold">SUBTOTAL PROVISIONS:</span>
                  <span className="font-serif text-lg font-bold text-gold">
                    ${cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0).toFixed(2)}
                  </span>
                </div>
                
                <p className="font-sans text-[10px] text-slate-gray text-center leading-normal">
                  *Unpasteurized beers are packed with cold gel insulation. Standard shipping takes 3-5 days.
                </p>

                <div className="flex gap-2">
                  <button
                    onClick={() => { setIsCartOpen(false); handleNavigate('shop'); }}
                    className="flex-1 text-center font-sans text-[10px] tracking-widest font-extrabold border border-gold/30 text-gold py-3 hover:bg-gold/5"
                  >
                    CONTINUE SHOPPING
                  </button>
                  <button
                    onClick={() => { setIsCartOpen(false); handleNavigate('shop'); }}
                    className="flex-1 text-center font-sans text-[10px] tracking-widest font-extrabold bg-gold text-navy-950 py-3 hover:bg-cream-100"
                  >
                    CHECKOUT NOW
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* 2. Customer Account Portal overlay */}
      {isAccountOpen && (
        <div id="customer-account-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-navy-950/80 backdrop-blur-sm" onClick={() => setIsAccountOpen(false)}></div>
          
          <div className={`relative max-w-lg w-full rounded-xl overflow-hidden shadow-2xl border p-6 sm:p-8 space-y-6 ${
            isDarkMode ? 'bg-navy-900 border-gold/15 text-cream-100' : 'bg-cream-50 border-navy-900/10 text-navy-900'
          }`}>
            <button
              onClick={() => setIsAccountOpen(false)}
              className="absolute top-4 right-4 text-slate-gray hover:text-gold"
            >
              ✕
            </button>

            <div className="flex justify-between items-start border-b border-navy-900/5 dark:border-gold/10 pb-4">
              <div className="flex gap-3 items-center">
                <div className="w-12 h-12 bg-gold/10 rounded-full border border-gold flex items-center justify-center">
                  <User className="w-6 h-6 text-gold" />
                </div>
                <div>
                  <h3 className="font-serif text-xl font-bold">Mariner Customer Portal</h3>
                  <span className="font-sans text-[9px] tracking-[0.2em] font-extrabold text-gold uppercase flex items-center gap-1">
                    <Award className="w-3.5 h-3.5 text-gold" />
                    ANCHOR ELITE STATUS • 420 PTS
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/5 dark:border-gold/10 rounded space-y-1">
                  <span className="text-[8px] text-slate-gray font-bold tracking-widest block uppercase">ACTIVE MEMBER</span>
                  <p className="font-sans font-extrabold text-gold">Captain Thomas</p>
                  <p className="text-[10px] text-slate-gray font-sans font-medium">Joined Dec 2024</p>
                </div>
                <div className="p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/5 dark:border-gold/10 rounded space-y-1">
                  <span className="text-[8px] text-slate-gray font-bold tracking-widest block uppercase">DEFAULT HARBOR PORT</span>
                  <p className="font-sans font-extrabold text-gold">Essex Basin Marina</p>
                  <p className="text-[10px] text-slate-gray font-sans font-medium">Slip #14 Authorization</p>
                </div>
              </div>

              {/* Rolling subscriptions lists */}
              <div className="space-y-2">
                <h4 className="font-sans text-[9px] tracking-widest text-gold font-extrabold uppercase block">ACTIVE REPEATING CRATES</h4>
                <div className="p-3 bg-navy-950/20 border border-gold/10 rounded flex justify-between items-center">
                  <div className="space-y-0.5">
                    <p className="font-bold">The Hop-Head Hazies Subscription</p>
                    <p className="text-[10px] text-slate-gray">12 Cans • Dispatched every 4 Weeks</p>
                  </div>
                  <div className="text-right">
                    <span className="font-sans text-[9px] text-emerald-500 font-extrabold bg-emerald-500/10 px-2 py-0.5 rounded">
                      ACTIVE DISPATCH
                    </span>
                    <p className="text-[9px] text-slate-gray mt-1">Next: Aug 18, 2026</p>
                  </div>
                </div>
              </div>

              {/* Historical receipts */}
              <div className="space-y-2">
                <h4 className="font-sans text-[9px] tracking-widest text-gold font-extrabold uppercase block">PAST PROVISIONS HISTORY</h4>
                <div className="space-y-1.5 font-sans font-medium">
                  <div className="flex justify-between items-center text-[10px] border-b border-navy-900/5 dark:border-gold/5 pb-1">
                    <span>#NHB-8420 - 4-Pack Harbor IPA, 1x Mariner Cap</span>
                    <span className="text-gold font-bold">$48.00 • Delivered</span>
                  </div>
                  <div className="flex justify-between items-center text-[10px]">
                    <span>#NHB-5103 - Signature Embossed Glass Growler</span>
                    <span className="text-gold font-bold">$28.00 • Delivered</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="border-t border-navy-900/5 dark:border-gold/10 pt-4 flex gap-3">
              <button
                onClick={() => setIsAccountOpen(false)}
                className="flex-1 font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-3 hover:bg-cream-100 border border-gold"
              >
                RETURN TO BREWHOUSE
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
