import { Beer, Product, JournalPost, TaproomEvent, Review } from './types';

export const BEERS: Beer[] = [
  {
    id: 'harbor-ipa',
    name: 'Harbor IPA',
    style: 'IPA',
    tagline: 'Bold tropical hop profile with a smooth coastal finish',
    description: 'Our flagship India Pale Ale, brewed to capture the bold and adventurous spirit of the Maine coast. Double dry-hopped with Citra, Mosaic, and Simcoe, it delivers intense aromas of grapefruit, passionfruit, and resinous pine, backed by a clean, balanced malt backbone.',
    abv: '6.7%',
    ibu: 65,
    tastingNotes: ['Grapefruit', 'Passionfruit', 'Resinous Pine', 'Bright Citrus'],
    foodPairings: ['Sharp New England Cheddar', 'Spicy Lobster Roll', 'Grilled Fish Tacos'],
    availability: 'Year-Round',
    awards: ['Gold Medal - Great American Beer Festival 2024', 'Best East Coast IPA - New England Brewers Cup'],
    brewTechnique: 'Double Dry-Hopping (DDH) at cold temperatures to maximize aromatic volatile oils without adding harsh bitterness.',
    ingredients: {
      malts: ['2-Row Pale Malt', 'Flaked Oats', 'Carapils'],
      hops: ['Citra', 'Mosaic', 'Simcoe', 'Amarillo'],
      yeast: 'House New England Ale Yeast',
      water: 'Filtered Pure Coastal Spring Water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1584225065152-4a1454aa3d4e?auto=format&fit=crop&w=600&q=80',
    price: 16.00,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#E5A93C]'
  },
  {
    id: 'coastal-kolsch',
    name: 'Coastal Kölsch',
    style: 'Kölsch',
    tagline: 'Exceptionally crisp, clean, and refreshing',
    description: 'Brewed strictly according to traditional Cologne methods but with an added kiss of local New England hops. Crisp, subtle, and beautifully clear, with delicate pear and floral notes, culminating in a dry, refreshing snap. Perfect for long afternoons on the dock.',
    abv: '4.8%',
    ibu: 20,
    tastingNotes: ['Crisp Pear', 'Noble Hops', 'Crackery Malt', 'White Flower'],
    foodPairings: ['Fresh Maine Oysters', 'Steamed Clams', 'Light Summer Salads'],
    availability: 'Year-Round',
    awards: ['First Place - Massachusetts Craft Beer Showcase 2025'],
    brewTechnique: 'Long cold lagering for four weeks to achieve pristine clarity and an ultra-clean fermentation profile.',
    ingredients: {
      malts: ['German Pilsner Malt', 'Vienna Malt', 'Wheat Malt'],
      hops: ['Hallertau Mittelfrüh', 'Tettnanger', 'Saphir'],
      yeast: 'Classic Kölsch Ale Yeast (Cold fermented)',
      water: 'Softened Spring Water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1608270586620-248524c67de9?auto=format&fit=crop&w=600&q=80',
    price: 14.50,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#F5E1A4]'
  },
  {
    id: 'pine-point',
    name: 'Pine Point Pale Ale',
    style: 'Pale Ale',
    tagline: 'Resinous pine needles meets zesty citrus peel',
    description: 'Inspired by the rugged pine forests of New Hampshire and Maine meeting the Atlantic shoreline. This Pale Ale balances the aromatic woody resins of Chinook and Cascade hops with a slightly toasted caramel malt sweetness. Balanced, comforting, and deeply satisfying.',
    abv: '5.6%',
    ibu: 40,
    tastingNotes: ['Pine Resin', 'Grapefruit Peel', 'Toasted Caramel', 'Earthy Cedar'],
    foodPairings: ['Wood-fired Pizza', 'Smoked Brisket', 'Maple Glazed Salmon'],
    availability: 'Year-Round',
    awards: ['Sustained Excellence Award - Northeast Beer Guild'],
    brewTechnique: 'Late kettle hop additions coupled with active whirlpool hop infusions to preserve organic pine terpenes.',
    ingredients: {
      malts: ['Maris Otter Pale Malt', 'Munich Malt', 'Crystal 40L'],
      hops: ['Chinook', 'Cascade', 'Centennial'],
      yeast: 'American West Coast Ale Yeast',
      water: 'High-calcium Hardwood Spring Water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1566633806327-68e152aaf26d?auto=format&fit=crop&w=600&q=80',
    price: 15.00,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#D28C38]'
  },
  {
    id: 'dorys-dark-ale',
    name: "Dory's Dark Ale",
    style: 'Amber Ale',
    tagline: 'Toasted biscuit, rich caramel, and subtle dark fruit',
    description: "An elegant New England Amber Ale named after the classic maritime dory boats. Pouring a beautiful deep copper, it leads with aromas of warm biscuit, molasses, and toasted hazelnut, transitioning to a balanced bitterness that keeps the malt richness in perfect check.",
    abv: '5.5%',
    ibu: 28,
    tastingNotes: ['Warm Biscuit', 'Toasted Hazelnut', 'Molasses', 'Muted Plum'],
    foodPairings: ['Roasted Turkey', 'Clam Chowder', 'Warm Apple Crisp'],
    availability: 'Year-Round',
    awards: ['Best in Class Amber - Rhode Island Craft Brewer Fest'],
    brewTechnique: 'Precision mash temperature profiling to create complex unfermentable sugars for a luxurious, full-bodied mouthfeel.',
    ingredients: {
      malts: ['Golden Promise', 'Amber Malt', 'Chocolate Malt', 'Special B'],
      hops: ['Willamette', 'East Kent Goldings'],
      yeast: 'English Ale Strain',
      water: 'Iron-filtered Forest Spring Water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1571613316887-6f8d5cbf7ef7?auto=format&fit=crop&w=600&q=80',
    price: 15.00,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#984E2A]'
  },
  {
    id: 'summer-screen',
    name: 'Summer Screen Wheat',
    style: 'Wheat Beer',
    tagline: 'Sun-kissed wheat with coriander and sweet orange peel',
    description: 'A classic Belgian-style Witbier with a coastal New England touch. Soft, hazy, and pillow-light, brewed with organic raw wheat, rolled oats, ground coriander, and dried Curaçao orange peel. Exceptionally refreshing with a delicate, spicy yeast complexity.',
    abv: '4.9%',
    ibu: 15,
    tastingNotes: ['Sweet Orange', 'Ground Coriander', 'Pillow Malt', 'Delicate Clove'],
    foodPairings: ['Lemon Herb Grilled Chicken', 'Lobster Salad', 'Fresh Goat Cheese'],
    availability: 'Seasonal Releases',
    brewTechnique: 'Unfiltered presentation utilizing an authentic open-fermentation style to encourage natural spicy ester development.',
    ingredients: {
      malts: ['Pilsner Malt', 'Flaked Wheat', 'Raw Wheat', 'Oats'],
      hops: ['Saaz', 'Hallertau Hersbrucker'],
      yeast: 'Belgian Witbier Strain',
      water: 'Soft, mineral-balanced water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1532634922-8fe0b757fb13?auto=format&fit=crop&w=600&q=80',
    price: 14.50,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#F2EDC2]'
  },
  {
    id: 'penobscot-porter',
    name: 'Penobscot Porter',
    style: 'Porter',
    tagline: 'Dark roasted espresso beans and bittersweet chocolate',
    description: 'Pouring jet black with a thick tan head, this traditional porter is named after the historic and stormy Penobscot Bay. Expect rich flavors of dark roasted espresso, premium dark cocoa, and a hint of smoky campfire, balanced by a smooth, silky finish.',
    abv: '6.0%',
    ibu: 35,
    tastingNotes: ['Dark Espresso', 'Bittersweet Cocoa', 'Smoky Oak', 'Toffee'],
    foodPairings: ['Raw Blue Point Oysters', 'Charred Ribeye Steak', 'Chocolate Lava Cake'],
    availability: 'Seasonal Releases',
    awards: ['Gold Medal - Vermont Beer Cup 2023'],
    brewTechnique: 'Infusion of premium cold-brew coffee concentrate directly post-fermentation to preserve bright berry notes.',
    ingredients: {
      malts: ['Maris Otter', 'Brown Malt', 'Chocolate Malt', 'Black Barley'],
      hops: ['Fuggles', 'Goldings'],
      yeast: 'House London Ale Yeast',
      water: 'High-carbonate deep well water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1600788886242-5c96aabe3757?auto=format&fit=crop&w=600&q=80',
    price: 16.50,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#2E1E1C]'
  },
  {
    id: 'monhegan-sour',
    name: 'Monhegan Wild Sour',
    style: 'Sour',
    tagline: 'Tart coastal blackberries and wild lactobacillus kettle sour',
    description: 'A vibrant, ruby-red kettle sour fermented with hundreds of pounds of wild blackberries harvested from New England islands. Brightly acidic, sparkling, and bursting with fresh berry tartness, supported by a faint, dry biscuit malt layer.',
    abv: '5.0%',
    ibu: 8,
    tastingNotes: ['Wild Blackberry', 'Zesty Lemon Tart', 'Sourdough', 'Clean Acid'],
    foodPairings: ['Plum Tart', 'Creamy Brie Cheese', 'Cranberry Duck Breast'],
    availability: 'Limited Release',
    brewTechnique: 'Kettle-souring technique using a selected strain of Lactobacillus plantarum, followed by heavy berry maceration.',
    ingredients: {
      malts: ['Pilsner Malt', 'White Wheat Malt'],
      hops: ['Aged Saaz Hops (very low alpha)'],
      yeast: 'American Neutral Yeast + Lactobacillus',
      water: 'Pure mountain spring water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1575444758702-4a6b9222336e?auto=format&fit=crop&w=600&q=80',
    price: 18.00,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#B43A66]'
  },
  {
    id: 'vermont-maple-stout',
    name: 'Vermont Maple Stout',
    style: 'Stout',
    tagline: 'Imperial stout aged with Grade A Vermont maple syrup',
    description: 'A luxurious, warm, high-gravity imperial stout that serves as the ultimate winter companion. Rich, viscous, and decadent, brewed with dark specialty malts and generous amounts of authentic, wood-fired Grade A Vermont maple syrup. Notes of vanilla bean, roasted oak, and dark syrup.',
    abv: '9.5%',
    ibu: 50,
    tastingNotes: ['Maple Molasses', 'Vanilla Bean', 'Roasted Bourbon Oak', 'Toasted Pecan'],
    foodPairings: ['Pecan Pie', 'Aged Blue Cheese', 'Maple Smoked Bacon'],
    availability: 'Limited Release',
    awards: ['Best Barrel-Aged Stout - Northeast Brewers Guild 2024'],
    brewTechnique: 'Long 3-hour kettle boil for heavy caramelization, combined with oak-aging for added wood tannins.',
    ingredients: {
      malts: ['Maris Otter', 'Roasted Barley', 'Caramunich', 'Oat Malt'],
      hops: ['Magnum', 'Fuggles'],
      yeast: 'Irish Stout Yeast Strain',
      water: 'Soft spring water'
    },
    imageUrl: 'https://images.unsplash.com/photo-1518099074172-2e47ee7cfdf0?auto=format&fit=crop&w=600&q=80',
    price: 22.00,
    volume: '4-Pack / 16oz Cans',
    color: 'bg-[#18100E]'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'propellers-mixed-case',
    name: 'The Harbor Crew Mixed Case',
    category: 'mixed',
    description: 'A hand-selected 24-can showcase of our finest New England crafts. Contains 6 cans of Harbor IPA, 6 of Coastal Kölsch, 6 of Pine Point Pale, and 6 of our rotating seasonal release.',
    price: 88.00,
    imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 142,
    details: ['24 Cans of 16oz fresh beer', 'Sturdy wooden crate packaging option available', 'Ships cold in insulated, eco-friendly shippers', 'Includes premium tasting cards'],
    stock: 45,
    isSubscriptionAvailable: true
  },
  {
    id: 'amber-glass-growler',
    name: 'Signature Embossed Glass Growler',
    category: 'glassware',
    description: 'An elegant, 64oz heavy-duty amber glass growler featuring our compass rose emblem in deep relief. Includes a spring-wire porcelain flip-top closure to lock in absolute freshness.',
    price: 28.00,
    imageUrl: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&w=600&q=80',
    rating: 4.8,
    reviewsCount: 56,
    details: ['Heavy-gauge amber glass shielding UV light', 'Porcelain flip-top with high-density silicone gaskets', 'Holds 64 fluid oz (4 pints)', 'Dishwasher safe and fully reusable'],
    stock: 120
  },
  {
    id: 'heritage-brewer-hoodie',
    name: 'Heritage Weathered Cedar Hoodie',
    category: 'apparel',
    description: 'An exceptionally soft, heavy-gauge French Terry cotton pullover dyed in weathered cedar. Features a detailed hand-stitched leather patch of the North Harbor compass on the chest.',
    price: 68.00,
    imageUrl: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 88,
    details: ['100% Organic Cotton French Terry (400 GSM)', 'Double-lined hood with genuine leather-tipped drawstring', 'Ethically manufactured in Massachusetts', 'Pre-shrunk and garment-washed for a vintage feel'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    stock: 35
  },
  {
    id: 'coastline-apparel-cap',
    name: 'Waxed Canvas Mariner Cap',
    category: 'apparel',
    description: 'A weather-resistant structured cap constructed of genuine waxed cotton canvas. Developed to withstand heavy saltwater spray, ocean fog, and sudden squalls.',
    price: 32.00,
    imageUrl: 'https://images.unsplash.com/photo-1588850561407-ed78c282e89b?auto=format&fit=crop&w=600&q=80',
    rating: 4.7,
    reviewsCount: 74,
    details: ['Genuine dry-waxed cotton canvas shell', 'Solid antique brass slide strap adjustment', 'Embroidered tone-on-tone compass rose emblem', 'Moisture-wicking internal sweatband'],
    stock: 80
  },
  {
    id: 'tasting-room-glass-set',
    name: 'Distillery-Grade Craft Tasting Glasses',
    category: 'glassware',
    description: 'A set of four custom-molded 13.5oz tulip tasting glasses, scientifically designed to concentrate and funnel dense hop and ester aromas directly to your nose.',
    price: 38.00,
    imageUrl: 'https://images.unsplash.com/photo-1574030110002-4d9af3ed2109?auto=format&fit=crop&w=600&q=80',
    rating: 4.9,
    reviewsCount: 65,
    details: ['Set of 4 elegant tulip glasses', 'Optically clear lead-free crystalline glass', 'Flared rim maximizes aroma concentration', 'Reinforced heavy-foot base with signature laser-engraved compass'],
    stock: 50
  },
  {
    id: 'wood-gift-crate',
    name: 'Coastal Gathering Gift Crate',
    category: 'gifts',
    description: 'The ultimate coastal New England hospitality gift. Packaged in a hand-crafted pine wood crate made in Vermont, stuffed with natural wood excelsior, fine beer, and specialty pairings.',
    price: 115.00,
    imageUrl: 'https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=600&q=80',
    rating: 5.0,
    reviewsCount: 29,
    details: ['Hand-made Vermont pine crate', 'Includes 4 premium beers (Harbor IPA, Coastal Kölsch, Pine Point, Dory\'s Dark)', '2 Signature Tasting Glasses', 'Artisanal Maine sea-salt crackers and Vermont sharp cheddar cheese wheel', 'Includes personalized handwritten copper card'],
    stock: 15
  }
];

export const JOURNAL_POSTS: JournalPost[] = [
  {
    id: 'science-of-decoction',
    title: 'The Alchemy of Cedar & Hops: Wood-Aged Brewing Science',
    summary: 'A deep dive into how wooden vessels and local coastal woods modify hop bitterness, flavor stability, and organic compound extraction.',
    content: 'At North Harbor, we have spent years experimenting with wood-aging, not just in traditional bourbon oak barrels, but with native New England woods like weathered white cedar, spruce, and maple. In this technical feature, our head brewer discusses the delicate chemical interaction between wood resins, alpha acids, and the slow micro-oxygenation that transforms a heavy imperial stout or a wild sour into a masterpiece. We look at the hemicellulose breakdown and how toast levels dictate the release of vanillin and toasted furfurals.',
    category: 'Science',
    author: 'Erich Vance',
    role: 'Master Brewer & Director of Science',
    date: 'July 18, 2026',
    readTime: '8 min read',
    imageUrl: 'https://images.unsplash.com/photo-1584225065152-4a1454aa3d4e?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'maine-coast-guide',
    title: "The Mariner's Compass: A Craft Beer Lover's Coastal Guide",
    summary: 'Charting a route from Cape Cod to the rugged cliffs of Acadia, highlighting historic lighthouses, maritime pubs, and beautiful ocean trails.',
    content: 'There is something fundamentally magical about pairing a fresh, crisp Kölsch with a cool Atlantic breeze. Our coastal guide charts an immersive three-day exploration across the classic harbours, quiet beach docks, and historic brick shipyards of New England. From the historic brick walls of Essex and Gloucester to the sleepy summer houses of Rhode Island, we share our favorite secret sunset views, local oyster beds, and hiking paths where a chilled can of North Harbor fits perfectly.',
    category: 'Guides',
    author: 'Clara Alden',
    role: 'Editor, Journal of Maritime Hospitality',
    date: 'June 29, 2026',
    readTime: '12 min read',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'sea-salt-cheddar-pairing',
    title: 'New England Pairings: Oyster Mignonette & Fresh Kölsch',
    summary: 'Explore the culinary synergy between the crisp salinity of cold-water oysters and the subtle, sparkling snap of our traditional Coastal Kölsch.',
    content: 'Why does our Coastal Kölsch elevate a fresh-shucked oyster? It comes down to clean chemical interactions. The delicate crackery malts of the Kölsch slice beautifully through the rich oyster creaminess, while its bright carbonation and light, fruity pear esters cleanse the palate, highlighting the ocean mineral brine. We outline three seasonal mignonette recipes, including a custom Harbor IPA hops-infused shallot reduction that will stun your next dinner gathering.',
    category: 'Recipes',
    author: 'Chef Thomas Cabot',
    role: 'Culinary Director, The North Harbor Taproom',
    date: 'May 14, 2026',
    readTime: '6 min read',
    imageUrl: 'https://images.unsplash.com/photo-1534080391025-a77d018f26e5?auto=format&fit=crop&w=600&q=80'
  }
];

export const EVENTS: TaproomEvent[] = [
  {
    id: 'harbor-sessions-1',
    title: 'The Harbor Sessions: Live Coastal Folk & Blues',
    subtitle: 'Featuring the Boston Maritime Acoustic Trio',
    date: 'Saturday, Aug 8, 2026',
    day: '08',
    month: 'AUG',
    time: '6:00 PM – 9:00 PM',
    description: 'Join us on our spacious timber deck overlooking the harbor as we host live, acoustic sea-folk and warm blues. Pull up an adirondack chair, gather around our outdoor stone fire pits, and enjoy fresh wood-fired lobster pizza and pints under the stars.',
    category: 'live-music',
    price: 'Free Admission',
    ticketsAvailable: true
  },
  {
    id: 'oyster-pairing-fest',
    title: 'Annual Shuck & Sip: Coastal Oyster & Beer Festival',
    subtitle: 'A gathering of 8 New England Oyster Farms',
    date: 'Sunday, Aug 16, 2026',
    day: '16',
    month: 'AUG',
    time: '12:00 PM – 6:00 PM',
    description: 'Our highly anticipated annual festival! Pair pristine, cold-water oysters shucked live on our lawn by local farmers with our crisp Coastal Kölsch, Monhegan Sour, and limited-edition experimental dry-hopped lagers. Ticket includes custom glassware and first 6 oysters.',
    category: 'festival',
    price: '$45.00',
    ticketsAvailable: true
  },
  {
    id: 'brewhouse-tour-experience',
    title: 'Master Class: Brewhouse Tour & Barrel Room Tasting',
    subtitle: 'Led by Master Brewer Erich Vance',
    date: 'Friday, Aug 21, 2026',
    day: '21',
    month: 'AUG',
    time: '4:00 PM – 5:30 PM',
    description: 'An intimate, behind-the-scenes journey through our state-of-the-art 30-barrel brewing system. Enter our private climate-controlled barrel cellar and taste premium imperial maple stouts and wild sours directly from our white oak and white cedar aging casks.',
    category: 'tour',
    price: '$30.00',
    ticketsAvailable: true
  },
  {
    id: 'cheese-beer-pairing',
    title: 'Artisanal Cheese & Beer Pairing Workshop',
    subtitle: 'In partnership with Jasper Hill Farm (Vermont)',
    date: 'Thursday, Sep 3, 2026',
    day: '03',
    month: 'SEP',
    time: '7:00 PM – 8:30 PM',
    description: 'Discover the incredible synergy of fine cheese and craft beer. Our cicerone and Jasper Hill\'s cheesemonger walk you through five decadent pairings, pairing award-winning blues, washed-rinds, and sharp cheddars with our flagships and sours.',
    category: 'tasting',
    price: '$40.00',
    ticketsAvailable: true
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Sarah Jenkins',
    rating: 5,
    date: 'July 14, 2026',
    comment: 'Harbor IPA is simply the best balanced IPA in New England. It has that incredible tropical punch without the chalky, overly sweet finish of some other hazies. Crisp, clean, absolutely magnificent.',
    verified: true,
    productName: 'Harbor IPA'
  },
  {
    id: 'rev-2',
    author: 'Benjamin S.',
    rating: 5,
    date: 'June 28, 2026',
    comment: 'The waxed canvas cap has gone on every sailing trip with me this summer. Exceptionally sturdy and beads off sea spray like a dream. Highly recommend!',
    verified: true,
    productName: 'Waxed Canvas Mariner Cap'
  },
  {
    id: 'rev-3',
    author: 'Mark O\'Donnell',
    rating: 5,
    date: 'July 2, 2026',
    comment: 'Visited the taproom in Essex last weekend. Outstanding design, huge timber framing, and beautiful harbor views. Coastal Kölsch on draft is a spiritual experience. Cleanest beer on the coast!',
    verified: true,
    productName: 'Coastal Kölsch'
  }
];
