import { useState } from 'react';
import { TaproomEvent } from '../types';
import { EVENTS } from '../data';
import { Calendar, Compass, Sparkles, MapPin, Clock, Check, Ticket, Award } from 'lucide-react';

interface EventsPageProps {
  isDarkMode: boolean;
}

export default function EventsPage({ isDarkMode }: EventsPageProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [bookedEventId, setBookedEventId] = useState<string | null>(null);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState<boolean>(false);
  const [activeEvent, setActiveEvent] = useState<TaproomEvent | null>(null);

  const categories = [
    { id: 'all', label: 'ALL EVENTS' },
    { id: 'live-music', label: 'LIVE MUSIC' },
    { id: 'festival', label: 'FESTIVALS' },
    { id: 'tour', label: 'BREWERY TOURS' },
    { id: 'tasting', label: 'PAIRINGS & WORKSHOPS' }
  ];

  const filteredEvents = EVENTS.filter(evt => {
    if (selectedCategory === 'all') return true;
    return evt.category === selectedCategory;
  });

  const handleBookTicket = (event: TaproomEvent) => {
    setActiveEvent(event);
    setBookedEventId(event.id);
    setIsSuccessModalOpen(true);
  };

  const handleCloseSuccess = () => {
    setIsSuccessModalOpen(false);
    setBookedEventId(null);
    setActiveEvent(null);
  };

  return (
    <div id="events-page-view" className={`pt-28 pb-20 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950 text-cream-100 paper-texture-dark' : 'bg-cream-100 text-navy-900 paper-texture'}`}>
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold">
            <Calendar className="w-3.5 h-3.5" />
            LIVE HARBOR SEASONS & COMMUNITY GATHERINGS
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
            The Live Calendar
          </h1>
          <p className={`font-sans text-xs sm:text-sm font-light leading-relaxed ${isDarkMode ? 'text-cream-300/70' : 'text-slate-gray'}`}>
            Join us on our spacious timber decks, around the central hearth, or in our private cellars. Filter our upcoming gatherings to book tickets, reserve custom tastings, or plan private celebrations.
          </p>
        </div>

        {/* Dynamic Event Filters */}
        <div id="events-filters" className="flex flex-wrap items-center justify-center gap-2 border-b border-navy-900/10 dark:border-gold/10 pb-6 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`font-sans text-[9px] tracking-[0.18em] font-extrabold px-5 py-2.5 transition-colors border ${
                selectedCategory === cat.id
                  ? 'bg-gold text-navy-950 border-gold'
                  : isDarkMode
                  ? 'border-gold/15 text-cream-200 hover:border-gold hover:text-gold bg-navy-900'
                  : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold bg-cream-50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Calendar Lists Stack */}
        <div id="events-list-container" className="space-y-6 max-w-5xl mx-auto">
          {filteredEvents.map((evt) => (
            <div
              key={evt.id}
              className={`border rounded-xl p-6 flex flex-col md:flex-row gap-6 items-stretch justify-between transition-all duration-300 hover:border-gold/30 ${
                isDarkMode ? 'bg-navy-900 border-gold/10 shadow-lg' : 'bg-cream-50 border-navy-900/5 shadow-md'
              }`}
            >
              {/* Left Column: Premium date seal */}
              <div className="flex md:flex-col justify-center items-center text-center p-4 bg-navy-950 text-cream-50 border border-gold/10 rounded-lg min-w-[100px] shrink-0">
                <span className="font-sans text-[10px] tracking-widest text-gold font-extrabold uppercase block">{evt.month}</span>
                <span className="font-serif text-4xl font-extrabold leading-none my-1 block">{evt.day}</span>
                <span className="font-sans text-[9px] tracking-wider text-cream-300/60 block">2026</span>
              </div>

              {/* Center Column: Event details */}
              <div className="flex-1 flex flex-col justify-between space-y-4 py-2">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-sans text-[8px] tracking-[0.2em] font-black uppercase text-navy-950 bg-gold px-2.5 py-0.5 rounded">
                      {evt.category.replace('-', ' ')}
                    </span>
                    <span className="font-sans text-[9px] text-slate-gray font-bold uppercase">{evt.price}</span>
                  </div>
                  <h3 className="font-serif text-xl sm:text-2xl font-bold tracking-wide">{evt.title}</h3>
                  {evt.subtitle && <p className="font-sans text-xs text-gold/80 italic font-semibold">{evt.subtitle}</p>}
                  <p className="font-sans text-xs text-slate-gray leading-relaxed font-light">{evt.description}</p>
                </div>

                {/* Sub utility parameters */}
                <div className="flex flex-wrap gap-4 text-xs font-sans text-slate-gray font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-gold" />
                    {evt.time}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-gold" />
                    Essex River Basin Lawn & Hearth
                  </span>
                </div>
              </div>

              {/* Right Column: Ticket triggers */}
              <div className="border-t md:border-t-0 md:border-l border-navy-900/5 dark:border-gold/10 pt-4 md:pt-0 md:pl-6 flex flex-col justify-center items-center md:items-end space-y-3 min-w-[160px]">
                <div className="text-center md:text-right">
                  <span className="font-sans text-[8px] text-slate-gray tracking-wider uppercase block font-bold">TICKET COST</span>
                  <span className="font-serif text-lg font-bold text-gold">{evt.price === 'Free Admission' ? 'FREE' : evt.price}</span>
                </div>

                <button
                  id={`book-ticket-${evt.id}`}
                  onClick={() => handleBookTicket(evt)}
                  className="w-full md:w-auto font-sans text-[10px] tracking-widest font-extrabold bg-gold text-navy-950 py-3 px-6 hover:bg-cream-100 border border-gold transition-colors flex items-center justify-center gap-1.5"
                >
                  <Ticket className="w-3.5 h-3.5" />
                  ACQUIRE ACCESS
                </button>
              </div>

            </div>
          ))}

          {/* Empty state */}
          {filteredEvents.length === 0 && (
            <div className="text-center py-16 space-y-3">
              <Compass className="w-12 h-12 text-gold/30 mx-auto animate-spin-slow" />
              <h3 className="font-serif text-xl font-bold">No vessels found on this horizon</h3>
              <p className="font-sans text-xs text-slate-gray">Select another event category filter above.</p>
            </div>
          )}
        </div>

      </div>

      {/* Booking success overlay */}
      {isSuccessModalOpen && activeEvent && (
        <div id="events-ticket-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-navy-950/80 backdrop-blur-md" onClick={handleCloseSuccess}></div>
          
          <div className="relative max-w-md w-full bg-navy-900 border border-gold/15 text-cream-100 p-6 sm:p-8 rounded-xl shadow-2xl space-y-6">
            <button
              id="close-ticket-success"
              onClick={handleCloseSuccess}
              className="absolute top-4 right-4 text-cream-300 hover:text-gold"
            >
              ✕
            </button>

            <div className="text-center space-y-4 flex flex-col items-center justify-center">
              <div className="w-16 h-16 bg-gold/10 rounded-full border border-gold flex items-center justify-center animate-bounce">
                <Ticket className="w-8 h-8 text-gold" />
              </div>
              <div className="space-y-1">
                <span className="font-sans text-[8px] tracking-[0.2em] font-extrabold text-gold uppercase block">TICKET DISPATCH COMPLETE</span>
                <h3 className="font-serif text-2xl font-bold text-gold">Access Voucher Secured</h3>
                <p className="font-sans text-xs text-slate-gray uppercase font-semibold">TICKET ID: NHB-EV-{Math.floor(400000 + Math.random() * 599999)}</p>
              </div>

              <div className="bg-navy-950 p-4 rounded text-left w-full space-y-2.5 text-xs border border-gold/15">
                <p className="font-bold text-cream-50 font-serif border-b border-gold/15 pb-2 truncate">
                  {activeEvent.title}
                </p>
                <p>• Date: <span className="font-bold text-gold">{activeEvent.date}</span></p>
                <p>• Time: <span className="font-bold text-gold">{activeEvent.time}</span></p>
                <p>• Admission Type: <span className="font-bold text-gold">1x General Admission Verified</span></p>
                <p>• Direct slip parking authorization verified</p>
              </div>

              <p className="font-sans text-[11px] text-slate-gray leading-relaxed max-w-xs">
                An electronic verification pass and harbor navigation details have been dispatched to your mariner customer email.
              </p>

              <button
                onClick={handleCloseSuccess}
                className="w-full font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-3.5 hover:bg-cream-100 border border-gold"
              >
                RETURN TO CALENDAR
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
