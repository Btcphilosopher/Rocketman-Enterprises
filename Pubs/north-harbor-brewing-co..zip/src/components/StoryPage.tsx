import { useState } from 'react';
import { Compass, ShieldCheck, Heart, Leaf, HelpCircle, ArrowRight, Sparkles, MapPin } from 'lucide-react';

interface StoryPageProps {
  isDarkMode: boolean;
}

export default function StoryPage({ isDarkMode }: StoryPageProps) {
  const [activeIngredient, setActiveIngredient] = useState<string>('all');

  const team = [
    {
      name: 'Erich Vance',
      role: 'Founder & Master Brewer',
      bio: 'Erich spent 15 years studying traditional lagering in Cologne and Bamberg before returning home to the Essex shoreline to establish our wood-aging cellar.',
      img: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Clara Alden',
      role: 'Cellar Operator & Fermentation Lead',
      bio: 'Clara handles our complex wild lactobacillus cultures and coordinates our local coastal berry foraging expeditions across Maine islands.',
      img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80'
    },
    {
      name: 'Chef Thomas Cabot',
      role: 'Culinary Director & Certified Cicerone',
      bio: 'Thomas curates our wood-fired taproom menu, ensuring each local oyster mignonette recipe pairs seamlessly with our seasonal drafts.',
      img: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=400&q=80'
    }
  ];

  const ingredients = [
    {
      id: 'spruce',
      name: 'Maine Coastal Spruce',
      origin: 'Penobscot Bay, ME',
      desc: 'Freshly harvested wild spruce needles added directly to the whirlpool, releasing crisp notes of citrus peel and coastal pine resins.',
      coord: 'top-[15%] right-[25%]'
    },
    {
      id: 'barley',
      name: 'Massachusetts Winter Barley',
      origin: 'Pioneer Valley, MA',
      desc: 'Organically grown winter barley crafted on a family-owned floor-malting house, imparting rich biscuit and toasted breadcrumbs notes.',
      coord: 'bottom-[35%] left-[20%]'
    },
    {
      id: 'maple',
      name: 'Grade-A Maple Syrup',
      origin: 'Mount Mansfield, VT',
      desc: 'Pure, wood-fired maple syrup caramelized over open flames, adding complex molasses and caramel sugars to our imperial stout boil.',
      coord: 'top-[30%] left-[35%]'
    },
    {
      id: 'water',
      name: 'Glacial Hardwood Water',
      origin: 'White Mountains, NH',
      desc: 'Mineral-pure water filtered naturally through ancient granite aquifers, giving our crisp lagers and pale ales their iconic clean finish.',
      coord: 'top-[45%] left-[55%]'
    }
  ];

  const milestones = [
    { year: '2014', title: 'The Anchor is Cast', desc: 'Founder Erich Vance salvages historic shipyard timber structures to erect our first 15-barrel brewhouse in Essex, MA.' },
    { year: '2017', title: 'The GABF Accolade', desc: 'Our flagship Harbor IPA receives its first Gold Medal at the Great American Beer Festival, cementing our hop-craft standards.' },
    { year: '2021', title: 'Cellar Expansion', desc: 'We establish our climate-controlled white cedar aging program, releasing our first wood-matured wild sours.' },
    { year: '2024', title: 'Carbon Neutral Standard', desc: 'We complete 100% solar array panels installation on our roof, executing an eco-sustainable closed-loop brewing standard.' }
  ];

  return (
    <div id="story-page-view" className={`pt-28 pb-20 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950 text-cream-100 paper-texture-dark' : 'bg-cream-100 text-navy-900 paper-texture'}`}>
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Header Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold uppercase">
            <Compass className="w-3.5 h-3.5 animate-spin-slow" />
            TIMELINES, CRAFTSMANSHIP & ECO-VALUES
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
            Our Brewing Heritage
          </h1>
          <p className={`font-sans text-xs sm:text-sm font-light leading-relaxed ${isDarkMode ? 'text-cream-300/70' : 'text-slate-gray'}`}>
            For over a decade, North Harbor Brewing Co. has operated with a deep respect for natural materials, New England communities, and traditional brewing science.
          </p>
        </div>

        {/* 1. Brewing Philosophy & Timelines Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <span className="font-sans text-[10px] tracking-[0.25em] font-extrabold text-gold uppercase block">BREWING INTENT</span>
            <h2 className="font-serif text-3xl font-extrabold tracking-tight">Respecting Time, Respecting Grain</h2>
            <div className={`space-y-4 font-sans text-sm font-light ${isDarkMode ? 'text-cream-300/80' : 'text-slate-gray'} leading-relaxed`}>
              <p>
                Our philosophy is simple: we do not cut corners. We refuse to use chemical enzymes, artificial clarify agents, or accelerated pressurized fermentation vessels. Our lagers cold-mature for weeks; our sours sit peacefully in wood casks for years.
              </p>
              <p>
                By respecting historic European brewing methodologies—like double-decoction mashing—while embracing the adventurous hop-forward signatures of the East Coast, we produce beers of extraordinary character and drinkability.
              </p>
            </div>
            
            <div className="grid grid-cols-2 gap-4 border-t border-navy-900/5 dark:border-gold/10 pt-6 text-xs">
              <div className="space-y-1">
                <h4 className="font-sans font-extrabold text-gold tracking-widest uppercase">100% SOLAR POWERED</h4>
                <p className="text-slate-gray leading-relaxed font-medium">Our Essex brewhouse roof is equipped with heavy solar panels, offsetting 100% of our daily production electricity.</p>
              </div>
              <div className="space-y-1">
                <h4 className="font-sans font-extrabold text-gold tracking-widest uppercase">ZERO WASTE SPENT GRAINS</h4>
                <p className="text-slate-gray leading-relaxed font-medium">100% of our spent brewing grains are dispatched to family-owned cattle farms in Essex and Ipswich for organic cattle feed.</p>
              </div>
            </div>
          </div>

          {/* Interactive Timeline column */}
          <div className={`lg:col-span-5 border rounded-xl p-6 sm:p-8 space-y-6 ${isDarkMode ? 'bg-navy-900 border-gold/15 shadow-xl' : 'bg-cream-50 border-navy-900/5 shadow-lg'}`}>
            <h3 className="font-serif text-xl font-bold border-b border-navy-900/5 dark:border-gold/10 pb-3">The Vessels of Progress</h3>
            
            <div className="space-y-6 relative border-l border-gold/20 pl-4 text-xs">
              {milestones.map((mil, idx) => (
                <div key={idx} className="relative space-y-1">
                  {/* Timeline bullet */}
                  <div className="absolute -left-[21px] top-1 w-2.5 h-2.5 bg-gold rounded-full border border-navy-900 animate-pulse"></div>
                  <span className="font-sans font-black text-gold text-[10px] tracking-wider block">{mil.year} — {mil.title}</span>
                  <p className="font-sans text-slate-gray font-light leading-relaxed">{mil.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 2. Interactive Ingredient Map Showcase */}
        <div id="ingredients-map-block" className={`border rounded-xl p-6 sm:p-10 ${isDarkMode ? 'bg-navy-900 border-gold/15' : 'bg-cream-50 border-navy-900/10'}`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-5 space-y-4">
              <span className="font-sans text-[9px] tracking-[0.25em] font-extrabold text-gold uppercase block">REGIONAL GEOGRAPHY</span>
              <h2 className="font-serif text-2xl sm:text-3xl font-extrabold tracking-tight">The New England Pantry</h2>
              <p className="font-sans text-xs sm:text-sm text-slate-gray leading-relaxed font-light">
                We believe exceptional beer must reflect the ecology of its home. We harvest, source, and forage our primary ingredients directly from agricultural families across the states of Massachusetts, Maine, Vermont, and New Hampshire.
              </p>

              {/* Dynamic Interactive Detail cards */}
              <div className="space-y-2 pt-2">
                {ingredients.map((ing) => (
                  <button
                    key={ing.id}
                    onClick={() => setActiveIngredient(ing.id)}
                    className={`w-full text-left p-3 border rounded text-xs transition-all flex justify-between items-center ${
                      activeIngredient === ing.id
                        ? 'border-gold bg-gold/5 text-gold font-bold'
                        : 'border-navy-900/10 dark:border-gold/10 hover:border-gold/40'
                    }`}
                  >
                    <span>{ing.name}</span>
                    <span className="font-sans text-[10px] text-slate-gray tracking-wider uppercase font-semibold">{ing.origin}</span>
                  </button>
                ))}
                {activeIngredient !== 'all' && (
                  <button
                    onClick={() => setActiveIngredient('all')}
                    className="font-sans text-[9px] tracking-widest font-extrabold text-gold mt-2 block hover:underline"
                  >
                    RESET DISCOVERY VIEW
                  </button>
                )}
              </div>
            </div>

            {/* Simulated Sourcing Map with dynamic detail tooltip overlays */}
            <div className="lg:col-span-7 relative h-[360px] bg-navy-950 border border-gold/15 rounded-xl overflow-hidden p-6 flex flex-col justify-between text-cream-100">
              
              <div className="absolute top-4 right-4 text-right">
                <span className="font-sans text-[8px] tracking-widest text-gold font-extrabold block uppercase">CRAFT MAP MODEL</span>
                <span className="font-serif text-xs italic opacity-70">Northeastern Coastline</span>
              </div>

              {/* Contour Map backgrounds */}
              <div className="absolute inset-0 opacity-10 pointer-events-none flex items-center justify-center">
                <Compass className="w-56 h-56 text-cream-100 animate-spin-slow" />
              </div>

              {/* Simulated Map Shoreline overlay */}
              <div className="absolute inset-0 pointer-events-none">
                <svg className="w-full h-full stroke-gold/10 fill-transparent stroke-2" viewBox="0 0 400 300">
                  <path d="M 50,20 Q 150,50 180,120 T 350,180 T 390,280" />
                  <path d="M 120,20 Q 180,70 210,150 T 380,210" className="opacity-40" />
                </svg>
              </div>

              {/* Map pin nodes */}
              {ingredients.map((ing) => (
                <button
                  key={ing.id}
                  onClick={() => setActiveIngredient(ing.id)}
                  className={`absolute ${ing.coord} group z-10`}
                >
                  <div className={`relative flex items-center justify-center w-6 h-6 border rounded-full transition-all duration-300 ${
                    activeIngredient === ing.id ? 'bg-gold border-gold scale-110' : 'bg-navy-900 border-gold/40 hover:border-gold hover:scale-105'
                  }`}>
                    <MapPin className={`w-3.5 h-3.5 ${activeIngredient === ing.id ? 'text-navy-950' : 'text-gold'}`} />
                    <span className="absolute left-7 bg-navy-950/90 text-gold font-sans text-[9px] font-extrabold py-0.5 px-2 border border-gold/20 rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                      {ing.name}
                    </span>
                  </div>
                </button>
              ))}

              {/* Floating detail overlay card */}
              <div className="relative z-20 bg-navy-950/90 border border-gold/20 p-4 rounded shadow-xl mt-auto max-w-sm">
                {activeIngredient === 'all' ? (
                  <div className="space-y-1">
                    <span className="font-sans text-[8px] tracking-widest text-gold block uppercase font-extrabold">DISCOVERY MODE ACTIVATED</span>
                    <p className="font-serif text-sm font-semibold">Explore Sourcing Locations</p>
                    <p className="font-sans text-[10px] text-cream-300/60 leading-normal">Click any yellow location pin on the coastal map coordinate layer to inspect local ingredient details, harvesting methods, and farm profiles.</p>
                  </div>
                ) : (
                  <div className="space-y-1.5 animate-fadeIn">
                    <span className="font-sans text-[8px] tracking-widest text-gold block uppercase font-extrabold">INGREDIENT DISPATCH FOUND</span>
                    <p className="font-serif text-base font-bold text-cream-100">{ingredients.find(i => i.id === activeIngredient)?.name}</p>
                    <p className="font-sans text-[9px] font-extrabold text-gold uppercase">{ingredients.find(i => i.id === activeIngredient)?.origin}</p>
                    <p className="font-sans text-[11px] text-cream-300/80 leading-relaxed pt-1 border-t border-gold/10">
                      {ingredients.find(i => i.id === activeIngredient)?.desc}
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>
        </div>

        {/* 3. The Team Showcase Grid */}
        <div className="space-y-8">
          <div className="text-center max-w-xl mx-auto space-y-1">
            <span className="font-sans text-[9px] tracking-[0.25em] font-extrabold text-gold block uppercase">THE MARINER GUILD</span>
            <h3 className="font-serif text-3xl font-bold">The Craft Artisans</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {team.map((member, i) => (
              <div
                key={i}
                className={`border rounded-lg overflow-hidden flex flex-col justify-between transition-all duration-300 hover:border-gold/30 ${
                  isDarkMode ? 'bg-navy-900 border-gold/10' : 'bg-cream-50 border-navy-900/5'
                }`}
              >
                <div className="aspect-[4/5] bg-navy-950 relative overflow-hidden">
                  <img
                    src={member.img}
                    alt={member.name}
                    className="w-full h-full object-cover grayscale brightness-90 hover:grayscale-0 transition-all duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent"></div>
                </div>

                <div className="p-5 flex-1 flex flex-col justify-between space-y-3">
                  <div className="space-y-1">
                    <h4 className="font-serif text-lg font-bold tracking-wide">{member.name}</h4>
                    <span className="font-sans text-[9px] text-gold tracking-widest font-extrabold uppercase block">{member.role}</span>
                  </div>
                  <p className="font-sans text-xs text-slate-gray leading-relaxed font-light">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
