import React, { useState } from 'react';
import { Compass, Mail, Clock, MapPin, Check, Heart, HelpCircle, Briefcase, FileText, ArrowRight } from 'lucide-react';

interface FooterProps {
  onNavigate: (viewId: string) => void;
  isDarkMode: boolean;
}

export default function Footer({ onNavigate, isDarkMode }: FooterProps) {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  // Forms states
  const [showCareers, setShowCareers] = useState(false);
  const [showWholesale, setShowWholesale] = useState(false);
  const [showPress, setShowPress] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  const faqs = [
    {
      q: 'Do you ship beer directly to my house?',
      a: 'Yes, we ship fresh cold-packaged cans, mixed cases, and custom subscriptions directly to addresses across MA, NH, VT, ME, and RI. All beers are shipped in insulated boxes with cold gel packs to preserve absolute draft freshness. An adult signature (21+) is required upon delivery.'
    },
    {
      q: 'Can I arrive at the Essex Taproom by boat?',
      a: 'Absolutely. We sit directly on the Essex River basin. Public docking slips 12 through 16 are available for draft room patrons on a first-come, first-served basis. We ask boaters to respect local speed constraints and tie off securely.'
    },
    {
      q: 'Are your brewery tours wheelchair accessible?',
      a: 'Yes. Our entire Salem-timber facility is fully ADA-compliant. This includes step-free access to our main brewhouse floor, the fermentation cellar, public rest areas, and accessible tables on our ocean deck.'
    },
    {
      q: 'How long does unpasteurized craft beer stay fresh?',
      a: 'We do not pasteurize our beers to preserve delicate hop oils and aromatic yeast esters. We recommend keeping all cans refrigerated at 38–42°F and consuming them within 90 days of canning (stamped on the can bottom) for optimal taste.'
    }
  ];

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setIsSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setIsSubscribed(false);
    }, 4000);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setShowCareers(false);
      setShowWholesale(false);
      setShowPress(false);
    }, 3000);
  };

  return (
    <footer id="main-footer" className="bg-navy-950 text-cream-100 border-t border-gold/15 relative z-10">
      
      {/* 1. Newsletter Signup block */}
      <div id="newsletter-signup" className="border-b border-gold/10 py-12 px-4 sm:px-6 lg:px-8 bg-navy-900">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center lg:text-left">
            <h4 className="font-serif text-lg font-bold text-gold">Subscribe to the Maritime Dispatch</h4>
            <p className="font-sans text-xs text-cream-300/60 leading-relaxed font-light">Quarterly reports about limited wild sours, upcoming harbor sessions, and exclusive barrel program allocations.</p>
          </div>

          {!isSubscribed ? (
            <form onSubmit={handleSubscribe} className="flex w-full lg:w-auto max-w-md gap-2">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="mariner@beacon.com"
                className="flex-1 p-3 bg-navy-950 border border-gold/15 focus:border-gold outline-none rounded font-sans text-xs text-cream-100 placeholder-cream-300/40"
              />
              <button
                type="submit"
                className="font-sans text-[10px] tracking-widest font-extrabold bg-gold text-navy-950 px-6 py-3 hover:bg-cream-100 border border-gold transition-colors shrink-0"
              >
                JOIN DISPATCH
              </button>
            </form>
          ) : (
            <div className="flex items-center gap-2 text-gold font-sans text-xs font-bold bg-gold/5 border border-gold/20 p-3 rounded">
              <Check className="w-4 h-4" />
              COORDINATES SECURED! CHECK YOUR INBOX SHORTLY.
            </div>
          )}
        </div>
      </div>

      {/* 2. FAQs Section (WCAG compliant collapsible) */}
      <div id="footer-faqs" className="py-12 border-b border-gold/10 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto space-y-6">
        <div className="text-center space-y-1">
          <span className="font-sans text-[8px] tracking-[0.2em] font-extrabold text-gold uppercase block">HAVE QUESTIONS?</span>
          <h4 className="font-serif text-xl font-bold">Frequently Asked Inquiries</h4>
        </div>

        <div className="space-y-3 text-xs">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="border border-gold/10 rounded-lg overflow-hidden bg-navy-900/40"
            >
              <button
                onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                className="w-full text-left p-4 font-sans font-bold flex justify-between items-center text-cream-100 hover:text-gold transition-colors"
              >
                <span>{faq.q}</span>
                <span className="text-gold font-bold">{activeFaq === idx ? '−' : '+'}</span>
              </button>
              {activeFaq === idx && (
                <div className="p-4 border-t border-gold/10 font-sans text-cream-300/70 leading-relaxed font-light bg-navy-950/40 animate-fadeIn">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* 3. Central Footer Links Columns */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 text-xs">
        
        {/* Brand details */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Compass className="w-8 h-8 text-gold animate-spin-slow" />
            <div className="flex flex-col">
              <span className="font-serif text-base tracking-widest font-bold text-gold leading-none">NORTH HARBOR</span>
              <span className="font-sans text-[8px] tracking-[0.2em] font-medium leading-none text-cream-300/60">BREWING CO.</span>
            </div>
          </div>
          <p className="font-sans text-[11px] text-cream-300/50 leading-relaxed font-light">
            Crafting unpasteurized New England beers of deep character, inspired by sea salt air, coastal timber yards, and good company.
          </p>
          <p className="font-sans text-[10px] text-gold font-semibold">
            © 2026 North Harbor Brewing Co. • All rights reserved.
          </p>
        </div>

        {/* Navigation lists */}
        <div className="space-y-3">
          <h5 className="font-serif text-sm font-bold text-gold tracking-wide">Provisions Hub</h5>
          <ul className="space-y-2 font-sans font-semibold text-cream-200/60">
            <li><button onClick={() => onNavigate('beer')} className="hover:text-gold">Tasting Menu Catalog</button></li>
            <li><button onClick={() => onNavigate('taproom')} className="hover:text-gold">Table & Tour Reservations</button></li>
            <li><button onClick={() => onNavigate('shop')} className="hover:text-gold">Online Can Delivery</button></li>
            <li><button onClick={() => onNavigate('events')} className="hover:text-gold">Gatherings Calendar</button></li>
          </ul>
        </div>

        {/* Corporate / Utilities */}
        <div className="space-y-3">
          <h5 className="font-serif text-sm font-bold text-gold tracking-wide">General Portals</h5>
          <ul className="space-y-2 font-sans font-semibold text-cream-200/60">
            <li><button onClick={() => setShowWholesale(true)} className="hover:text-gold">Wholesale Distribution</button></li>
            <li><button onClick={() => setShowCareers(true)} className="hover:text-gold">Careers & Apprenticeships</button></li>
            <li><button onClick={() => setShowPress(true)} className="hover:text-gold">Press Kits & Asset Packs</button></li>
            <li><button onClick={() => onNavigate('story')} className="hover:text-gold">Sourcing Philosophy</button></li>
          </ul>
        </div>

        {/* Contacts */}
        <div className="space-y-3">
          <h5 className="font-serif text-sm font-bold text-gold tracking-wide">Coastal Lodgings</h5>
          <div className="space-y-2 font-sans text-cream-200/60 leading-normal">
            <div className="flex gap-2">
              <MapPin className="w-4 h-4 text-gold shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-cream-100">The Essex Brewhouse</p>
                <p className="text-[10px]">15 Harbor Way, Essex, MA 01929</p>
              </div>
            </div>
            <div className="flex gap-2 pt-1 border-t border-gold/5">
              <Clock className="w-4 h-4 text-gold shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-cream-100">Draft Room Hours</p>
                <p className="text-[10px]">Wed-Thu: 4PM-9PM • Fri-Sat: 12PM-10PM • Sun: 12PM-6PM</p>
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* Dynamic Pop-up Modals for Wholesale, Careers, Press */}
      {(showCareers || showWholesale || showPress) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-navy-950/80 backdrop-blur-md" onClick={() => { setShowCareers(false); setShowWholesale(false); setShowPress(false); }}></div>
          
          <div className="relative max-w-md w-full bg-navy-900 border border-gold/15 text-cream-100 p-6 sm:p-8 rounded-xl shadow-2xl space-y-5">
            <button
              onClick={() => { setShowCareers(false); setShowWholesale(false); setShowPress(false); }}
              className="absolute top-4 right-4 text-cream-300 hover:text-gold"
            >
              ✕
            </button>

            {!formSubmitted ? (
              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div className="space-y-1">
                  <span className="font-sans text-[8px] tracking-[0.25em] font-extrabold text-gold uppercase block">MARITIME REGISTRY</span>
                  <h3 className="font-serif text-xl font-bold">
                    {showCareers ? 'Apply for Apprenticeship' : showWholesale ? 'Wholesale Distribution Form' : 'Press Kit Download'}
                  </h3>
                  <p className="font-sans text-[11px] text-slate-gray">
                    {showCareers 
                      ? 'Submit details for lead brewer, cellar operator, or customer hospitality roles.' 
                      : showWholesale 
                      ? 'Inquire about regional distribution, draft keg supply, or restaurant partnerships.'
                      : 'Download our vector logos, photography reels, and editorial sheets.'
                    }
                  </p>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="space-y-1">
                    <label className="font-sans font-bold text-slate-gray block">Full Representative Name</label>
                    <input type="text" required placeholder="John Winthrop" className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded font-sans text-cream-100" />
                  </div>
                  <div className="space-y-1">
                    <label className="font-sans font-bold text-slate-gray block">Contact Email</label>
                    <input type="email" required placeholder="john@mariner.com" className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded font-sans text-cream-100" />
                  </div>
                  {showPress ? null : (
                    <div className="space-y-1">
                      <label className="font-sans font-bold text-slate-gray block">{showCareers ? 'Resume Summary / Notes' : 'Business Location & Volume Details'}</label>
                      <textarea required rows={2} placeholder="Type message here..." className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded font-sans text-cream-100" />
                    </div>
                  )}
                </div>

                <button type="submit" className="w-full font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-3.5 hover:bg-cream-100 transition-colors border border-gold">
                  {showPress ? 'DOWNLOAD ZIP ASSET PACK' : 'SUBMIT REQUISITION'}
                </button>
              </form>
            ) : (
              <div className="text-center py-6 space-y-4 flex flex-col items-center justify-center">
                <div className="w-12 h-12 bg-gold/10 rounded-full border border-gold flex items-center justify-center animate-bounce">
                  <Check className="w-6 h-6 text-gold" />
                </div>
                <div className="space-y-1">
                  <p className="font-serif text-lg font-bold text-gold">Transmission Secured</p>
                  <p className="font-sans text-[11px] text-slate-gray leading-relaxed max-w-xs">
                    Your request has been successfully registered. Our team will contact you back in 1-2 business days. Thank you.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

    </footer>
  );
}
