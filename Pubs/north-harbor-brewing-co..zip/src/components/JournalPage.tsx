import { useState } from 'react';
import { JournalPost } from '../types';
import { JOURNAL_POSTS } from '../data';
import { Compass, BookOpen, Clock, Sparkles, ArrowRight } from 'lucide-react';

interface JournalPageProps {
  isDarkMode: boolean;
}

export default function JournalPage({ isDarkMode }: JournalPageProps) {
  const [selectedPost, setSelectedPost] = useState<JournalPost | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const categories = ['all', 'Science', 'Guides', 'Recipes'];

  const filteredPosts = JOURNAL_POSTS.filter(post => {
    if (activeCategory === 'all') return true;
    return post.category.toLowerCase() === activeCategory.toLowerCase();
  });

  return (
    <div id="journal-page-view" className={`pt-28 pb-20 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950 text-cream-100 paper-texture-dark' : 'bg-cream-100 text-navy-900 paper-texture'}`}>
      <div className="max-w-7xl mx-auto space-y-12">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold uppercase">
            <BookOpen className="w-3.5 h-3.5 animate-pulse" />
            THE JOURNAL OF MARITIME HOSPITALITY & BREWING SCIENCE
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
            The North Harbor Journal
          </h1>
          <p className={`font-sans text-xs sm:text-sm font-light leading-relaxed ${isDarkMode ? 'text-cream-300/70' : 'text-slate-gray'}`}>
            A quarterly collection exploring decoction mashing, historical coastal pathways, traditional wood-aged fermentation techniques, and seasonal recipes.
          </p>
        </div>

        {/* Categories Navbar */}
        <div id="journal-categories" className="flex justify-center gap-3 border-b border-navy-900/10 dark:border-gold/10 pb-6 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`font-sans text-[9px] tracking-[0.18em] font-extrabold px-5 py-2 transition-all border uppercase ${
                activeCategory === cat
                  ? 'bg-gold text-navy-950 border-gold'
                  : isDarkMode
                  ? 'border-gold/10 text-cream-200 hover:border-gold hover:text-gold bg-navy-900'
                  : 'border-navy-900/10 text-navy-900 hover:border-gold'
              }`}
            >
              {cat === 'all' ? 'ALL ESSAYS' : cat}
            </button>
          ))}
        </div>

        {/* Editorial Layout grid */}
        <div id="journal-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <article
              key={post.id}
              id={`journal-post-card-${post.id}`}
              onClick={() => setSelectedPost(post)}
              className={`group cursor-pointer border rounded-xl overflow-hidden flex flex-col justify-between transition-all duration-300 hover:scale-[1.01] ${
                isDarkMode ? 'bg-navy-900 border-gold/10 hover:border-gold/30 shadow-lg' : 'bg-cream-50 border-navy-900/5 hover:border-gold/30 shadow-md'
              }`}
            >
              {/* Cover area */}
              <div className="relative aspect-[16/10] overflow-hidden bg-navy-950">
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent opacity-80"></div>
                <span className="absolute top-4 left-4 font-sans text-[8px] tracking-[0.2em] font-black uppercase text-navy-950 bg-gold px-2.5 py-1 rounded-full">
                  {post.category}
                </span>
              </div>

              {/* Text content area */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-[10px] font-sans text-slate-gray font-semibold">
                    <span>{post.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-gold" />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className="font-serif text-xl font-bold leading-snug tracking-wide group-hover:text-gold transition-colors">
                    {post.title}
                  </h3>
                  
                  <p className="font-sans text-xs text-slate-gray leading-relaxed font-light">
                    {post.summary}
                  </p>
                </div>

                <div className="pt-4 border-t border-navy-900/5 dark:border-gold/5 flex items-center justify-between">
                  <span className="font-sans text-[9px] text-slate-gray font-extrabold tracking-widest uppercase">BY {post.author.toUpperCase()}</span>
                  <span className="font-sans text-[9px] text-gold font-extrabold tracking-widest flex items-center gap-1 group-hover:text-navy-900 dark:group-hover:text-cream-100 transition-colors">
                    READ JOURNAL
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>

            </article>
          ))}
        </div>

      </div>

      {/* Immersive full-screen reading overlay */}
      {selectedPost && (
        <div
          id="journal-post-reader-overlay"
          className="fixed inset-0 z-50 overflow-y-auto bg-navy-950/80 backdrop-blur-md flex justify-center p-4 sm:p-6 lg:p-10"
        >
          <div className="absolute inset-0 cursor-pointer" onClick={() => setSelectedPost(null)}></div>
          
          <div
            id="reader-container"
            className={`relative max-w-3xl w-full rounded-2xl overflow-hidden shadow-2xl border flex flex-col h-fit ${
              isDarkMode ? 'bg-navy-900 border-gold/15 text-cream-100' : 'bg-cream-50 border-navy-900/10 text-navy-900'
            }`}
          >
            {/* Close */}
            <button
              id="close-reader-btn"
              onClick={() => setSelectedPost(null)}
              className={`absolute top-4 right-4 z-10 p-2 rounded-full border transition-all ${
                isDarkMode ? 'border-gold/15 text-cream-300 hover:text-gold hover:bg-navy-800' : 'border-navy-900/15 text-navy-900 hover:bg-cream-200'
              }`}
            >
              ✕
            </button>

            {/* Cover Image */}
            <div className="relative aspect-[21/9] w-full bg-navy-950">
              <img
                src={selectedPost.imageUrl}
                alt={selectedPost.title}
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950/90 to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 right-6 space-y-1.5 text-cream-50">
                <span className="font-sans text-[8px] tracking-[0.2em] font-black uppercase text-navy-950 bg-gold px-2.5 py-1 rounded-full">
                  {selectedPost.category}
                </span>
                <h2 className="font-serif text-2xl sm:text-3xl font-extrabold tracking-wide leading-tight mt-1">
                  {selectedPost.title}
                </h2>
              </div>
            </div>

            {/* Reading canvas - exact mathematical layout to preserve 65-75 chars limit */}
            <div className="p-6 sm:p-10 space-y-6">
              <div className="flex items-center justify-between border-b border-navy-900/5 dark:border-gold/10 pb-4 text-xs font-sans text-slate-gray font-semibold">
                <div className="flex gap-2">
                  <span>Published {selectedPost.date}</span>
                  <span>•</span>
                  <span>{selectedPost.readTime}</span>
                </div>
                <div>
                  <span className="font-bold text-navy-900 dark:text-gold uppercase tracking-wider block">WRITTEN BY</span>
                  <span>{selectedPost.author} ({selectedPost.role})</span>
                </div>
              </div>

              {/* Core prose */}
              <div className="font-serif text-sm sm:text-base leading-[1.8] tracking-wide font-light max-w-[70ch] mx-auto space-y-4 prose prose-neutral dark:prose-invert">
                <p className="font-sans text-xs sm:text-sm font-semibold text-gold tracking-wide italic leading-relaxed border-l-2 border-gold/40 pl-4 py-1">
                  "{selectedPost.summary}"
                </p>
                
                {/* Simulated long paragraphs */}
                <p>
                  {selectedPost.content}
                </p>
                <p>
                  As we reflect on our maritime roots in Massachusetts and New Hampshire, we prioritize the traditional step-infusion systems. This ensures we produce the unpasteurized crispness that distinguishes our Coastal Kölsch from typical modern craft styles. We use our historical open-frame mash tuns specifically to expose wort oxygenation rates to the natural climate of the river bay.
                </p>
                <p>
                  Furthermore, each barrel cellaging project utilizes custom white oak and white cedar panels sourced directly from Massachusetts timber farms, releasing subtle furfural tannins. This deliberate respect for natural time is what defines our craft.
                </p>
              </div>

              <div className="pt-6 border-t border-navy-900/5 dark:border-gold/10 text-center">
                <button
                  onClick={() => setSelectedPost(null)}
                  className="font-sans text-[10px] tracking-widest font-extrabold border border-gold text-gold hover:bg-gold hover:text-navy-950 py-3 px-8 transition-colors"
                >
                  CONCLUDE READING
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
