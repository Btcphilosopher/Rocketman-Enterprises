import React, { useState } from 'react';
import { Beer } from '../types';
import { BEERS } from '../data';
import { Compass, Sparkles, Award, Utensils, Droplet, HelpCircle, ShoppingBag, Check } from 'lucide-react';

interface BeerCatalogueProps {
  onAddToCart: (beer: Beer) => void;
  isDarkMode: boolean;
}

export default function BeerCatalogue({ onAddToCart, isDarkMode }: BeerCatalogueProps) {
  const [selectedStyle, setSelectedStyle] = useState<string>('All');
  const [selectedBeer, setSelectedBeer] = useState<Beer | null>(null);
  const [addedBeerId, setAddedBeerId] = useState<string | null>(null);

  const styles = [
    'All',
    'IPA',
    'Kölsch',
    'Stout',
    'Porter',
    'Pale Ale',
    'Sour',
    'Wheat Beer',
    'Seasonal Releases',
  ];

  const filteredBeers = BEERS.filter((beer) => {
    if (selectedStyle === 'All') return true;
    if (selectedStyle === 'Seasonal Releases') {
      return beer.availability.toLowerCase().includes('seasonal') || beer.availability.toLowerCase().includes('limited');
    }
    return beer.style.toLowerCase() === selectedStyle.toLowerCase();
  });

  const handleAddToCartClick = (beer: Beer, e: React.MouseEvent) => {
    e.stopPropagation(); // Avoid opening details
    onAddToCart(beer);
    setAddedBeerId(beer.id);
    setTimeout(() => setAddedBeerId(null), 1500);
  };

  return (
    <div id="beer-catalogue-view" className={`pt-28 pb-20 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950 text-cream-100 paper-texture-dark' : 'bg-cream-100 text-navy-900 paper-texture'}`}>
      <div className="max-w-7xl mx-auto">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold">
            <Sparkles className="w-3.5 h-3.5" />
            THE ART OF GRAIN, HOPS & TIME
          </span>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight">
            Our Maritime Catalog
          </h1>
          <p className={`font-sans text-xs sm:text-sm font-light leading-relaxed ${isDarkMode ? 'text-cream-300/70' : 'text-slate-gray'}`}>
            Explore our meticulous selection of New England brews. Filter by style to view ingredients, custom wood-aging profiles, GABF awards, and curated local culinary pairings.
          </p>
        </div>

        {/* Dynamic Filters Nav Bar */}
        <div id="beer-filters" className="flex flex-wrap items-center justify-center gap-2 border-b border-navy-900/10 dark:border-gold/10 pb-6 mb-12">
          {styles.map((style) => (
            <button
              key={style}
              id={`filter-btn-${style.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setSelectedStyle(style)}
              className={`font-sans text-[11px] tracking-[0.18em] font-extrabold px-5 py-2.5 transition-all duration-300 border ${
                selectedStyle === style
                  ? 'bg-gold text-navy-950 border-gold'
                  : isDarkMode
                  ? 'border-gold/15 text-cream-200 hover:border-gold hover:text-gold bg-navy-900'
                  : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold bg-cream-50'
              }`}
            >
              {style.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Beer Catalog Grid */}
        <div id="beers-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredBeers.map((beer) => (
            <div
              key={beer.id}
              id={`beer-card-${beer.id}`}
              onClick={() => setSelectedBeer(beer)}
              className={`group cursor-pointer border rounded-lg overflow-hidden flex flex-col justify-between transition-all duration-500 hover:scale-[1.02] ${
                isDarkMode
                  ? 'bg-navy-900 border-gold/15 hover:border-gold/40 shadow-xl shadow-navy-950/40'
                  : 'bg-cream-50 border-navy-900/10 hover:border-gold/40 shadow-lg'
              }`}
            >
              {/* Product Visual Area */}
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-navy-950">
                <img
                  src={beer.imageUrl}
                  alt={beer.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual Overlays & Badges */}
                <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent"></div>
                <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                  <span className={`font-sans text-[8px] tracking-[0.2em] font-black uppercase text-navy-950 px-2.5 py-1 ${beer.color} rounded-full`}>
                    {beer.style}
                  </span>
                  <span className="font-sans text-[8px] tracking-[0.15em] font-black uppercase text-cream-50 bg-navy-900/80 backdrop-blur border border-gold/15 px-2.5 py-1 rounded-full">
                    {beer.availability}
                  </span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                  <div className="space-y-0.5 text-cream-50">
                    <h3 className="font-serif text-lg font-bold leading-tight tracking-wide group-hover:text-gold transition-colors">
                      {beer.name}
                    </h3>
                    <p className="font-sans text-[10px] text-cream-300/70 italic leading-none truncate w-52">
                      {beer.tagline}
                    </p>
                  </div>
                </div>
              </div>

              {/* Beer Specifications Area */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div className="grid grid-cols-2 gap-y-2 gap-x-3 border-b border-navy-900/5 dark:border-gold/5 pb-4 text-xs">
                  <div>
                    <span className="font-sans text-[9px] text-slate-gray font-bold tracking-widest block uppercase">ABV LEVEL</span>
                    <span className="font-sans font-extrabold text-gold">{beer.abv}</span>
                  </div>
                  <div>
                    <span className="font-sans text-[9px] text-slate-gray font-bold tracking-widest block uppercase">IBU INDEX</span>
                    <span className="font-sans font-extrabold text-gold">{beer.ibu}</span>
                  </div>
                  <div className="col-span-2 mt-1">
                    <span className="font-sans text-[9px] text-slate-gray font-bold tracking-widest block uppercase">TASTING HIGHLIGHTS</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {beer.tastingNotes.slice(0, 3).map((note, i) => (
                        <span key={i} className="font-sans text-[9px] font-semibold bg-navy-900/5 dark:bg-gold/5 px-2 py-0.5 rounded text-slate-gray dark:text-cream-300">
                          {note}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card CTA Actions */}
                <div className="flex items-center justify-between pt-1">
                  <span className="font-sans text-xs font-extrabold text-gold">
                    ${beer.price.toFixed(2)} <span className="font-medium text-slate-gray font-sans text-[10px] block">{beer.volume}</span>
                  </span>
                  
                  <div className="flex items-center gap-2">
                    <button
                      id={`add-to-cart-beer-${beer.id}`}
                      onClick={(e) => handleAddToCartClick(beer, e)}
                      className={`font-sans text-[9px] tracking-widest font-extrabold py-2.5 px-3 border flex items-center gap-1 transition-all ${
                        addedBeerId === beer.id
                          ? 'bg-emerald-600 text-cream-50 border-emerald-600'
                          : 'border-gold/30 text-gold hover:bg-gold hover:text-navy-950'
                      }`}
                    >
                      {addedBeerId === beer.id ? (
                        <>
                          <Check className="w-3 h-3" />
                          ADDED
                        </>
                      ) : (
                        <>
                          <ShoppingBag className="w-3 h-3" />
                          ADD 4-PACK
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Empty Catalog State */}
        {filteredBeers.length === 0 && (
          <div className="text-center py-16 space-y-3">
            <Compass className="w-12 h-12 text-gold/30 mx-auto animate-spin-slow" />
            <h3 className="font-serif text-xl font-bold">No vessels found matching style</h3>
            <p className="font-sans text-xs text-slate-gray">Please select another craft style filter above.</p>
          </div>
        )}

      </div>

      {/* Immersive Tasting Booklet Modal (Details Drawer) */}
      {selectedBeer && (
        <div
          id="beer-detail-modal"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto"
        >
          {/* Modal Backdrop overlay */}
          <div
            id="modal-backdrop"
            className="fixed inset-0 bg-navy-950/80 backdrop-blur-md"
            onClick={() => setSelectedBeer(null)}
          ></div>
          
          {/* Modal Booklet container */}
          <div
            id="modal-container"
            className={`relative max-w-3xl w-full rounded-xl overflow-hidden shadow-2xl border flex flex-col md:flex-row max-h-[90vh] md:max-h-auto overflow-y-auto ${
              isDarkMode ? 'bg-navy-900 border-gold/15 text-cream-100' : 'bg-cream-50 border-navy-900/10 text-navy-900'
            }`}
          >
            {/* Left side: Premium Beer Label Portrait */}
            <div className="relative w-full md:w-5/12 aspect-[4/5] md:aspect-auto min-h-[250px] md:min-h-[480px]">
              <img
                src={selectedBeer.imageUrl}
                alt={selectedBeer.name}
                className="absolute inset-0 w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-navy-950/40 to-transparent"></div>
              
              <div className="absolute bottom-6 left-6 right-6 space-y-2 text-cream-50">
                <span className={`font-sans text-[8px] tracking-[0.25em] font-black uppercase text-navy-950 px-2.5 py-1 ${selectedBeer.color} rounded-full`}>
                  {selectedBeer.style}
                </span>
                <h2 className="font-serif text-3xl font-extrabold tracking-wide leading-tight">
                  {selectedBeer.name}
                </h2>
                <p className="font-sans text-xs text-cream-200/80 italic leading-snug">
                  "{selectedBeer.tagline}"
                </p>
              </div>
            </div>

            {/* Right side: In-depth Cicerone Tasting Card */}
            <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between overflow-y-auto space-y-6">
              <button
                id="close-modal-btn"
                onClick={() => setSelectedBeer(null)}
                className={`absolute top-4 right-4 p-1.5 rounded-full border transition-colors ${
                  isDarkMode ? 'border-gold/10 text-cream-300 hover:text-gold hover:bg-navy-800' : 'border-navy-900/10 text-navy-900 hover:bg-cream-200'
                }`}
              >
                ✕
              </button>

              <div className="space-y-5">
                <div>
                  <h4 className="font-sans text-[9px] tracking-[0.2em] font-extrabold text-gold uppercase block mb-1">THE SENSORY CHARACTER</h4>
                  <p className={`font-sans text-xs sm:text-sm font-light leading-relaxed ${isDarkMode ? 'text-cream-200/80' : 'text-slate-gray'}`}>
                    {selectedBeer.description}
                  </p>
                </div>

                {/* Analytical stats */}
                <div className="grid grid-cols-2 gap-4 border-y border-navy-900/5 dark:border-gold/5 py-4">
                  <div className="space-y-0.5">
                    <span className="font-sans text-[8px] text-slate-gray tracking-widest block uppercase font-bold">ABV INDEX</span>
                    <p className="font-serif text-lg font-bold text-gold">{selectedBeer.abv}</p>
                  </div>
                  <div className="space-y-0.5">
                    <span className="font-sans text-[8px] text-slate-gray tracking-widest block uppercase font-bold">BITTERNESS INDEX</span>
                    <p className="font-serif text-lg font-bold text-gold">{selectedBeer.ibu} IBU</p>
                  </div>
                </div>

                {/* Ingredients & Source Sourcing */}
                <div className="space-y-2.5">
                  <h4 className="font-sans text-[9px] tracking-[0.2em] font-extrabold text-gold uppercase block">INGREDIENT SOURCING</h4>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
                    <div>
                      <p className="font-sans font-extrabold text-slate-gray block uppercase text-[8px]">Craft Malts</p>
                      <p className="font-sans font-medium">{selectedBeer.ingredients.malts.join(', ')}</p>
                    </div>
                    <div>
                      <p className="font-sans font-extrabold text-slate-gray block uppercase text-[8px]">Noble Hops</p>
                      <p className="font-sans font-medium">{selectedBeer.ingredients.hops.join(', ')}</p>
                    </div>
                    <div className="col-span-2 border-t border-navy-900/5 dark:border-gold/5 pt-2">
                      <p className="font-sans font-extrabold text-slate-gray block uppercase text-[8px]">Yeast Fermentation</p>
                      <p className="font-sans font-medium">{selectedBeer.ingredients.yeast}</p>
                    </div>
                  </div>
                </div>

                {/* Tasting pairings */}
                {selectedBeer.foodPairings.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-sans text-[9px] tracking-[0.2em] font-extrabold text-gold uppercase flex items-center gap-1.5 font-bold">
                      <Utensils className="w-3.5 h-3.5" />
                      RECOMMENDED HOSPITALITY PAIRINGS
                    </h4>
                    <div className="flex flex-wrap gap-1.5">
                      {selectedBeer.foodPairings.map((food, idx) => (
                        <span key={idx} className="font-sans text-[10px] font-semibold bg-gold/5 border border-gold/10 text-gold px-2.5 py-1 rounded">
                          {food}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Awards if any */}
                {selectedBeer.awards && selectedBeer.awards.length > 0 && (
                  <div className="bg-navy-950/10 dark:bg-navy-950/40 border border-gold/10 p-3 rounded">
                    <div className="flex gap-2 items-start">
                      <Award className="w-4.5 h-4.5 text-gold shrink-0 mt-0.5" />
                      <div className="space-y-0.5">
                        <span className="font-sans text-[8px] text-gold tracking-wider font-extrabold">NE GUILD ACCOLADES</span>
                        {selectedBeer.awards.map((award, idx) => (
                          <p key={idx} className="font-sans text-[10px] text-slate-gray dark:text-cream-200/80 font-medium">
                            • {award}
                          </p>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Purchase Footer inside Modal */}
              <div className="border-t border-navy-900/10 dark:border-gold/10 pt-4 flex items-center justify-between mt-auto">
                <div className="flex flex-col">
                  <span className="font-sans text-[9px] text-slate-gray tracking-wider uppercase">FOUR-PACK PRICE</span>
                  <span className="font-sans text-lg font-extrabold text-gold">${selectedBeer.price.toFixed(2)}</span>
                </div>
                
                <div className="flex gap-3">
                  <button
                    id="modal-add-to-cart"
                    onClick={(e) => handleAddToCartClick(selectedBeer, e)}
                    className="font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 px-6 py-3 border border-gold hover:bg-cream-100 hover:border-cream-100 transition-colors"
                  >
                    ADD TO CART
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
