import React, { useState } from 'react';
import { Booking } from '../types';
import { Clock, MapPin, Compass, ShieldCheck, Heart, ArrowRight, Check, Sparkles } from 'lucide-react';

interface TaproomPageProps {
  isDarkMode: boolean;
}

export default function TaproomPage({ isDarkMode }: TaproomPageProps) {
  // Booking Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [guests, setGuests] = useState(2);
  const [date, setDate] = useState('2026-08-15');
  const [time, setTime] = useState('18:00');
  const [bookingType, setBookingType] = useState<'table' | 'tour'>('table');
  const [notes, setNotes] = useState('');
  const [isBooked, setIsBooked] = useState(false);
  const [activeMenuTab, setActiveMenuTab] = useState<'food' | 'draft'>('food');

  const foodMenu = [
    {
      name: 'North Harbor Lobster Roll',
      desc: 'Fresh Maine lobster meat lightly tossed in brown butter, stuffed in a toasted artisan split-top brioche bun with chives.',
      price: '$28.00',
      pairing: 'Coastal Kölsch'
    },
    {
      name: 'Wood-Fired Hops Clam Pizza',
      desc: 'White clam pizza with garlic cream sauce, fresh whole belly clams, smoked pancetta, mozzarella, and oil infused with Cascade hops.',
      price: '$21.00',
      pairing: 'Harbor IPA'
    },
    {
      name: 'Essex Clam Chowder Bread Bowl',
      desc: 'Award-winning thick cream chowder loaded with sweet sea clams and potatoes, served inside a fresh sourdough boule.',
      price: '$14.00',
      pairing: "Dory's Dark Ale"
    },
    {
      name: 'Smoked Maple Pork Belly Sliders',
      desc: 'Slow-smoked local pork belly glazed with Grade A Vermont maple syrup, pickled red cabbage, served on sweet potato rolls.',
      price: '$16.00',
      pairing: 'Vermont Maple Stout'
    }
  ];

  const draftMenu = [
    { name: 'Coastal Kölsch', style: 'Crisp German Style Ale', abv: '4.8%', price: '$7.00 / 16oz Pint' },
    { name: 'Pine Point Pale Ale', style: 'Resinous American Pale Ale', abv: '5.6%', price: '$7.50 / 16oz Pint' },
    { name: 'Harbor IPA', style: 'Tropical Double Dry-Hopped IPA', abv: '6.7%', price: '$8.00 / 16oz Pint' },
    { name: "Dory's Dark Ale", style: 'Toasted Biscuit Amber Ale', abv: '5.5%', price: '$7.50 / 16oz Pint' },
    { name: 'Summer Screen Wheat', style: 'Belgian Witbier with orange peel', abv: '4.9%', price: '$7.00 / 16oz Pint' },
    { name: 'Penobscot Porter', style: 'Dark Espresso Roasted Porter', abv: '6.0%', price: '$8.00 / 16oz Pint' },
    { name: 'Monhegan Wild Sour', style: 'Tart Blackberry Kettle Sour', abv: '5.0%', price: '$9.00 / 12oz Stem' },
    { name: 'Vermont Maple Stout', style: 'Imperial Maple Wood-Aged Stout', abv: '9.5%', price: '$10.00 / 10oz Snifter' }
  ];

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;
    setIsBooked(true);
  };

  const handleResetBooking = () => {
    setName('');
    setEmail('');
    setGuests(2);
    setNotes('');
    setIsBooked(false);
  };

  return (
    <div id="taproom-page-view" className={`pt-28 pb-20 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950 text-cream-100 paper-texture-dark' : 'bg-cream-100 text-navy-900 paper-texture'}`}>
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Head Intro */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6">
            <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold uppercase">
              <Compass className="w-3.5 h-3.5 animate-spin-slow" />
              OUR HEARTH BY THE WATER
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-extrabold tracking-tight leading-none">
              The Essex Taproom & Brewhouse
            </h1>
            <p className={`font-sans text-sm sm:text-base font-light leading-relaxed ${isDarkMode ? 'text-cream-300/70' : 'text-slate-gray'}`}>
              Housed in a meticulously restored 19th-century ship timber yard, our Essex taproom sits directly on the salt marshes overlooking the harbor. Enjoy high-timber wooden architecture, an open-concept brewing observation floor, deep stone fire pits, and ocean docks where you can arrive by land or water.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 text-xs">
              <div className="space-y-2 border-l border-gold/20 pl-4">
                <p className="font-sans font-extrabold tracking-widest text-gold uppercase">TAPROOM HOURS</p>
                <div className="space-y-1 font-medium">
                  <p>Wednesday – Thursday: 4:00 PM – 9:00 PM</p>
                  <p>Friday – Saturday: 12:00 PM – 10:00 PM</p>
                  <p>Sunday: 12:00 PM – 6:00 PM</p>
                  <p className="text-slate-gray italic">(Closed Mondays & Tuesdays for brewing)</p>
                </div>
              </div>
              <div className="space-y-2 border-l border-gold/20 pl-4">
                <p className="font-sans font-extrabold tracking-widest text-gold uppercase">OUR LOCATION</p>
                <div className="space-y-1 font-medium">
                  <p className="font-bold">15 Harbor Way, Essex, MA 01929</p>
                  <p>Phone: (978) 555-0144</p>
                  <p>Email: taproom@northharborbrewing.com</p>
                  <p className="text-slate-gray">Arrive by boat? Public slips 12-16 are available.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5 relative aspect-[4/3] rounded-xl overflow-hidden shadow-2xl border border-gold/10">
            <img
              src="https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80"
              alt="Inside North Harbor Taproom"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-transparent"></div>
            <div className="absolute bottom-4 left-4 right-4 bg-navy-950/80 backdrop-blur border border-gold/15 p-4 rounded text-cream-50">
              <span className="font-sans text-[9px] tracking-[0.2em] font-extrabold text-gold block">ARCHITECTURE HIGHLIGHTS</span>
              <p className="font-serif text-sm font-semibold mt-1">Authentic Heavy Timber Construction</p>
              <p className="font-sans text-[10px] text-cream-300/70 mt-0.5">Built using reclaimed white cedar and oak framing salvaged from historic Salem shipyard docks.</p>
            </div>
          </div>
        </div>

        {/* Interactive Reservation Form Grid */}
        <div id="taproom-booking" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch pt-8">
          {/* Reservation Card */}
          <div className={`lg:col-span-7 border rounded-xl p-6 sm:p-8 flex flex-col justify-between ${isDarkMode ? 'bg-navy-900 border-gold/15 shadow-xl shadow-navy-950/40' : 'bg-cream-50 border-navy-900/10 shadow-lg'}`}>
            {!isBooked ? (
              <form id="booking-form" onSubmit={handleBookingSubmit} className="space-y-6">
                <div className="space-y-1">
                  <span className="font-sans text-[9px] tracking-[0.25em] font-extrabold text-gold uppercase block">HOSPITALITY REGISTER</span>
                  <h3 className="font-serif text-2xl font-bold">Secure Your Table or Guided Tour</h3>
                  <p className="font-sans text-xs text-slate-gray">We hold 50% of our draft room tables for walk-ins, but reserve the remaining tables and all Master Class brewing tours here.</p>
                </div>

                <div className="flex gap-4 border-b border-navy-900/5 dark:border-gold/5 pb-4">
                  <button
                    type="button"
                    onClick={() => setBookingType('table')}
                    className={`flex-1 py-3 text-center font-sans text-xs tracking-widest font-extrabold border transition-all ${
                      bookingType === 'table'
                        ? 'bg-gold text-navy-950 border-gold'
                        : isDarkMode
                        ? 'border-gold/10 text-cream-300 hover:border-gold hover:text-gold'
                        : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold'
                    }`}
                  >
                    DRAFT ROOM TABLE
                  </button>
                  <button
                    type="button"
                    onClick={() => setBookingType('tour')}
                    className={`flex-1 py-3 text-center font-sans text-xs tracking-widest font-extrabold border transition-all ${
                      bookingType === 'tour'
                        ? 'bg-gold text-navy-950 border-gold'
                        : isDarkMode
                        ? 'border-gold/10 text-cream-300 hover:border-gold hover:text-gold'
                        : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold'
                    }`}
                  >
                    BREWHOUSE TOUR ($30)
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-1">
                    <label className="font-sans font-extrabold text-slate-gray tracking-wider uppercase block">Full Name</label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="e.g. Samuel Adams"
                      className="w-full p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/10 dark:border-gold/10 focus:border-gold outline-none rounded font-sans"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-sans font-extrabold text-slate-gray tracking-wider uppercase block">Email Address</label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="e.g. sam@mariner.com"
                      className="w-full p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/10 dark:border-gold/10 focus:border-gold outline-none rounded font-sans"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-sans font-extrabold text-slate-gray tracking-wider uppercase block">Number of Guests</label>
                    <select
                      value={guests}
                      onChange={(e) => setGuests(Number(e.target.value))}
                      className="w-full p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/10 dark:border-gold/10 focus:border-gold outline-none rounded font-sans"
                    >
                      <option value="1">1 Guest</option>
                      <option value="2">2 Guests</option>
                      <option value="4">4 Guests</option>
                      <option value="6">6 Guests</option>
                      <option value="8">8+ Guests (Call Brewhouse)</option>
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="font-sans font-extrabold text-slate-gray tracking-wider uppercase block">Preferred Date</label>
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/10 dark:border-gold/10 focus:border-gold outline-none rounded font-sans text-navy-900 dark:text-cream-100"
                    />
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <label className="font-sans font-extrabold text-slate-gray tracking-wider uppercase block">Arrival Time Slot</label>
                    <select
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/10 dark:border-gold/10 focus:border-gold outline-none rounded font-sans"
                    >
                      <option value="12:00">12:00 PM (Lawn open)</option>
                      <option value="14:00">2:00 PM</option>
                      <option value="16:00">4:00 PM (Tours begin)</option>
                      <option value="18:00">6:00 PM (Highly popular)</option>
                      <option value="20:00">8:00 PM (Late hearth sessions)</option>
                    </select>
                  </div>
                  <div className="space-y-1 sm:col-span-2">
                    <label className="font-sans font-extrabold text-slate-gray tracking-wider uppercase block">Special Accommodations / Dietary Notes</label>
                    <textarea
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Ramp requirements, gluten-free requests, high chair needed..."
                      className="w-full p-3 bg-navy-950/5 dark:bg-navy-950/40 border border-navy-900/10 dark:border-gold/10 focus:border-gold outline-none rounded font-sans"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-4 hover:bg-cream-100 hover:text-navy-950 transition-colors border border-gold"
                >
                  {bookingType === 'table' ? 'CONFIRM TABLE BOOKING' : 'BOOK TOUR ACCESS'}
                </button>
              </form>
            ) : (
              <div id="booking-success" className="text-center py-12 px-4 space-y-6 max-w-md mx-auto flex flex-col items-center justify-center">
                <div className="w-16 h-16 bg-gold/10 rounded-full border border-gold flex items-center justify-center animate-bounce">
                  <Sparkles className="w-8 h-8 text-gold" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-serif text-2xl font-bold text-gold">Booking Authenticated</h3>
                  <p className="font-sans text-xs font-semibold uppercase tracking-widest text-slate-gray">
                    REFERENCE ID: NHB-{Math.floor(100000 + Math.random() * 900000)}
                  </p>
                  <p className="font-sans text-sm font-light leading-relaxed">
                    Thank you, <span className="font-bold text-gold">{name}</span>. Your {bookingType === 'table' ? 'Draft Room Table' : 'Master guided brewhouse tour'} for <span className="font-bold">{guests} guests</span> is provisionally confirmed for <span className="font-bold">{date}</span> at <span className="font-bold">{time}</span>.
                  </p>
                </div>

                <div className="bg-navy-950/15 p-4 rounded text-left text-xs border border-gold/15 w-full space-y-2">
                  <p className="font-bold">✓ Direct Harbor Access slips included</p>
                  <p className="font-bold">✓ Wheelchair ramp accessible seating allocated</p>
                  <p className="font-bold">✓ Confirming digital ticket dispatched to <span className="text-gold italic">{email}</span></p>
                </div>

                <button
                  onClick={handleResetBooking}
                  className="font-sans text-[10px] tracking-widest font-extrabold border border-gold text-gold hover:bg-gold hover:text-navy-950 py-3 px-6 transition-all"
                >
                  BOOK ANOTHER SELECTION
                </button>
              </div>
            )}
          </div>

          {/* Maps / Accessibility Panel */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
            {/* Visual Map representational Card */}
            <div className={`border rounded-xl p-5 ${isDarkMode ? 'bg-navy-900 border-gold/15' : 'bg-cream-50 border-navy-900/10'}`}>
              <span className="font-sans text-[8px] tracking-[0.2em] font-extrabold text-gold uppercase block mb-1">MARITIME COMPASS</span>
              <h4 className="font-serif text-base font-bold mb-3">Geographic Grounding</h4>
              
              {/* Fake aesthetic vector map representation */}
              <div className="aspect-[16/9] bg-cream-300 rounded border border-navy-900/10 relative overflow-hidden p-3 flex items-center justify-center">
                {/* Simulated contour shoreline lines */}
                <div className="absolute inset-0 bg-blue-100/10 opacity-70"></div>
                <div className="absolute top-1/4 right-0 w-44 h-24 border-t-2 border-l border-blue-400/20 rounded-tl-[80px] transform rotate-12"></div>
                <div className="absolute bottom-0 left-10 w-24 h-20 border-r-2 border-b border-blue-400/20 rounded-tr-[50px] transform -rotate-12"></div>
                
                {/* Compass graphic */}
                <div className="absolute top-4 right-4 opacity-15">
                  <Compass className="w-16 h-16 text-navy-900" />
                </div>

                {/* Road overlays */}
                <div className="absolute inset-x-0 top-1/2 h-1 bg-neutral-400/10 transform rotate-6"></div>
                <div className="absolute inset-y-0 left-1/3 w-0.5 bg-neutral-400/10 transform -rotate-12"></div>

                {/* Harbor Water badge label */}
                <span className="absolute bottom-2 right-4 font-serif text-[9px] tracking-wider italic text-blue-800/60 font-bold">Essex River Basin</span>

                {/* The Pin */}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="bg-navy-950 text-gold text-[8px] font-sans font-extrabold py-1 px-2 border border-gold rounded shadow-md flex items-center gap-1">
                    <Compass className="w-2.5 h-2.5 animate-spin-slow" />
                    NORTH HARBOR CO.
                  </div>
                  <div className="w-1.5 h-3 bg-gold transform rotate-45 -mt-0.5 shadow-lg"></div>
                </div>
              </div>

              <p className="font-sans text-[10px] text-slate-gray mt-3 leading-relaxed">
                *Essex is approximately 45 minutes north of Boston. Public marina docking is directly adjacent to the taproom shoreline patio.
              </p>
            </div>

            {/* Accessibility Details */}
            <div className={`border rounded-xl p-5 flex-1 ${isDarkMode ? 'bg-navy-900 border-gold/15' : 'bg-cream-50 border-navy-900/10'}`}>
              <span className="font-sans text-[8px] tracking-[0.2em] font-extrabold text-gold uppercase block mb-1">ADA HOSPITALITY COMPLIANCE</span>
              <h4 className="font-serif text-base font-bold mb-3">Accessibility & Comfort</h4>
              
              <div className="space-y-3 font-sans text-xs leading-relaxed text-slate-gray dark:text-cream-300/80 font-medium">
                <div className="flex gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                  <p><span className="font-bold text-navy-900 dark:text-gold">Ramp & Ingress:</span> Full step-free ramp entry to both main brewhouse draft floor, lower lawn deck, and custom accessible restroom facilities.</p>
                </div>
                <div className="flex gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                  <p><span className="font-bold text-navy-900 dark:text-gold">Allergens & GF:</span> Full listing of ingredients. GF gluten-reduced beer alternative and vegan food pairing swaps clearly marked.</p>
                </div>
                <div className="flex gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-gold shrink-0 mt-0.5" />
                  <p><span className="font-bold text-navy-900 dark:text-gold">Sensory Details:</span> Guide dogs are fully welcomed. Our outdoor seating provides acoustic spacing away from central audio speakers for sensory safety.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Taproom Culinary & Beer Menu Cards */}
        <div id="taproom-culinary-menu" className="pt-8">
          <div className="text-center max-w-xl mx-auto mb-10 space-y-2">
            <span className="font-sans text-[9px] tracking-[0.25em] font-extrabold text-gold block uppercase">CURED & COOKED LOCALLY</span>
            <h3 className="font-serif text-3xl font-bold">The Taproom Wood-Fired Menu</h3>
            
            {/* Toggle tabs for Food and Draft */}
            <div className="flex justify-center gap-4 pt-4 text-xs font-sans">
              <button
                onClick={() => setActiveMenuTab('food')}
                className={`px-5 py-2 font-extrabold border tracking-wider transition-colors ${
                  activeMenuTab === 'food'
                    ? 'bg-gold text-navy-950 border-gold'
                    : isDarkMode
                    ? 'border-gold/10 text-cream-200 hover:border-gold hover:text-gold'
                    : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold'
                }`}
              >
                WOOD-FIRED KITCHEN
              </button>
              <button
                onClick={() => setActiveMenuTab('draft')}
                className={`px-5 py-2 font-extrabold border tracking-wider transition-colors ${
                  activeMenuTab === 'draft'
                    ? 'bg-gold text-navy-950 border-gold'
                    : isDarkMode
                    ? 'border-gold/10 text-cream-200 hover:border-gold hover:text-gold'
                    : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold'
                }`}
              >
                DRAFT ROOM BOARD
              </button>
            </div>
          </div>

          {/* Dynamic Menu grids */}
          {activeMenuTab === 'food' ? (
            <div id="food-menu-grid" className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
              {foodMenu.map((dish, i) => (
                <div
                  key={i}
                  className={`border rounded-lg p-5 flex flex-col justify-between space-y-3 hover:border-gold/30 transition-all duration-300 ${
                    isDarkMode ? 'bg-navy-900 border-gold/10' : 'bg-cream-50 border-navy-900/5'
                  }`}
                >
                  <div className="flex justify-between items-start gap-4">
                    <h4 className="font-serif text-lg font-bold tracking-wide">{dish.name}</h4>
                    <span className="font-sans text-xs font-extrabold text-gold text-right shrink-0">{dish.price}</span>
                  </div>
                  <p className="font-sans text-xs text-slate-gray leading-relaxed font-light">{dish.desc}</p>
                  <div className="pt-2 border-t border-navy-900/5 dark:border-gold/5 flex items-center justify-between text-[10px]">
                    <span className="font-sans text-slate-gray font-bold tracking-widest uppercase">CICERONE PAIRING:</span>
                    <span className="font-sans font-extrabold text-gold tracking-wider flex items-center gap-1">
                      <Compass className="w-3 h-3 text-gold" />
                      {dish.pairing}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div id="draft-menu-grid" className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-5xl mx-auto">
              {draftMenu.map((draft, i) => (
                <div
                  key={i}
                  className={`border rounded-lg p-4 flex justify-between items-center hover:border-gold/30 transition-all ${
                    isDarkMode ? 'bg-navy-900 border-gold/10' : 'bg-cream-50 border-navy-900/5'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-sans text-xs font-extrabold">{draft.name}</span>
                      <span className="font-sans text-[8px] tracking-wider font-extrabold text-gold bg-gold/10 px-1.5 py-0.5 rounded">
                        {draft.abv}
                      </span>
                    </div>
                    <p className="font-sans text-[10px] text-slate-gray">{draft.style}</p>
                  </div>
                  <span className="font-sans text-xs font-extrabold text-gold">{draft.price}</span>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
