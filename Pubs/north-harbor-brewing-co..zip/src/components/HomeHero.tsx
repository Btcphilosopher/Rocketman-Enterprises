import { Compass, MapPin, Calendar, Clock, ArrowRight } from 'lucide-react';

interface HomeHeroProps {
  onNavigate: (viewId: string) => void;
  isDarkMode: boolean;
  breweryHeroUrl: string;
}

export default function HomeHero({ onNavigate, isDarkMode, breweryHeroUrl }: HomeHeroProps) {
  const onTapBeers = [
    { name: 'COASTAL KÖLSCH', abv: '4.8%' },
    { name: 'PINE POINT PALE ALE', abv: '5.6%' },
    { name: 'HARBOR IPA', abv: '6.7%' },
    { name: "DORY'S DARK ALE", abv: '5.5%' },
    { name: 'SUMMER SCREEN WHEAT', abv: '4.9%' },
  ];

  const upcomingEvents = [
    {
      date: 'SAT, AUG 8',
      title: 'LIVE MUSIC: THE HARBOR SESSIONS',
      time: '6:00PM – 9:00PM',
    },
    {
      date: 'SUN, AUG 16',
      title: "SHUCK & SIP: COASTAL OYSTER FESTIVAL",
      time: '12:00PM – 6:00PM',
    },
    {
      date: 'FRI, AUG 21',
      title: 'MASTER CLASS: BREWHOUSE TOUR',
      time: '4:00PM – 5:30PM',
    },
  ];

  return (
    <section id="homepage-hero" className="relative min-h-screen pt-16 flex flex-col lg:flex-row bg-navy-950 overflow-hidden">
      {/* Left Column: Cinematic Banner overlayed with elegant typography */}
      <div className="relative flex-1 flex flex-col justify-center px-6 sm:px-12 lg:px-16 py-16 lg:py-24 xl:py-32">
        {/* Background image with dual layers for premium editorial feel and high contrast WCAG standards */}
        <div className="absolute inset-0 z-0">
          <img
            src={breweryHeroUrl}
            alt="North Harbor coastal brewery at sunset"
            className="w-full h-full object-cover object-center opacity-85 hover:scale-105 transition-transform duration-10000"
            referrerPolicy="no-referrer"
          />
          {/* Linear gradient overlays for optimal text legibility */}
          <div className="absolute inset-0 bg-gradient-to-r from-navy-950 via-navy-950/75 to-transparent"></div>
          <div className="absolute inset-0 bg-gradient-to-t from-navy-950 via-transparent to-navy-950/20"></div>
        </div>

        {/* Content Overlay */}
        <div className="relative z-10 max-w-2xl space-y-6 sm:space-y-8">
          <div className="space-y-2">
            <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold">
              <Compass className="w-3.5 h-3.5 animate-spin-slow" />
              ESTABLISHED 2014
            </span>
            <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-[5.5rem] font-bold tracking-tight leading-[1.05] text-cream-50">
              ROOTED IN <br className="hidden sm:inline" />
              NEW ENGLAND.<br />
              <span className="font-serif italic text-gold font-normal">BREWED FOR</span> <br className="sm:hidden" />
              GOOD COMPANY.
            </h1>
          </div>

          <p className="font-sans text-base sm:text-lg text-cream-200/80 max-w-lg leading-relaxed font-light">
            Independent craft beer brewed with unwavering integrity on the rugged Massachusetts coastline. Inspired by salty air, historic timber yards, and good friends.
          </p>

          <div className="flex flex-wrap gap-4 pt-2">
            <button
              id="hero-explore-beer-btn"
              onClick={() => onNavigate('beer')}
              className="group inline-flex items-center gap-3 font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 px-8 py-4 hover:bg-cream-100 hover:border-cream-100 transition-all duration-500 border border-gold"
            >
              EXPLORE OUR BEER
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform duration-300" />
            </button>
            <button
              id="hero-visit-taproom-btn"
              onClick={() => onNavigate('taproom')}
              className="inline-flex items-center gap-2 font-sans text-xs tracking-widest font-extrabold border border-cream-100/30 text-cream-100 px-8 py-4 hover:bg-cream-100/10 hover:border-cream-100 transition-all duration-500 bg-transparent"
            >
              VISIT THE TAPROOM
            </button>
          </div>
        </div>
      </div>

      {/* Right Column: Premium Stationery-style Sidebar Board */}
      <div id="hero-sidebar" className="w-full lg:w-[380px] xl:w-[440px] flex flex-col shrink-0 border-t lg:border-t-0 lg:border-l border-gold/15 bg-cream-200 z-10">
        {/* Section 1: On Tap Now */}
        <div id="sidebar-on-tap" className="p-6 xl:p-8 border-b border-navy-900/10 paper-texture text-navy-900 flex-1 flex flex-col justify-center">
          <div className="flex items-center gap-2 mb-4">
            <Compass className="w-4.5 h-4.5 text-gold stroke-[2.5]" />
            <h3 className="font-serif text-lg tracking-[0.15em] font-extrabold text-navy-900">
              ON TAP NOW
            </h3>
          </div>
          <div className="space-y-3.5 my-3">
            {onTapBeers.map((beer, index) => (
              <div
                key={index}
                className="flex items-center justify-between border-b border-navy-900/5 pb-2 hover:translate-x-1 transition-transform duration-300 cursor-pointer"
                onClick={() => onNavigate('beer')}
              >
                <span className="font-sans text-xs sm:text-sm tracking-wider font-extrabold text-navy-900">
                  {beer.name}
                </span>
                <span className="font-sans text-xs font-semibold text-slate-gray">
                  {beer.abv}
                </span>
              </div>
            ))}
          </div>
          <button
            id="sidebar-menu-link"
            onClick={() => onNavigate('beer')}
            className="group self-start inline-flex items-center gap-2 font-sans text-xs tracking-widest font-extrabold text-gold hover:text-navy-900 mt-2 transition-colors duration-300"
          >
            VIEW FULL MENU
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Section 2: Upcoming Events */}
        <div id="sidebar-upcoming-events" className="p-6 xl:p-8 border-b border-navy-900/10 bg-navy-900 text-cream-50 flex-1 flex flex-col justify-center">
          <div className="flex items-center gap-2 mb-4">
            <Calendar className="w-4.5 h-4.5 text-gold" />
            <h3 className="font-serif text-lg tracking-[0.15em] font-extrabold text-gold">
              UPCOMING EVENTS
            </h3>
          </div>
          <div className="space-y-4 my-2">
            {upcomingEvents.map((event, index) => (
              <div
                key={index}
                className="space-y-1 border-b border-gold/10 pb-3 hover:bg-navy-800/20 p-1.5 rounded transition-all cursor-pointer"
                onClick={() => onNavigate('events')}
              >
                <span className="font-sans text-[10px] tracking-widest font-extrabold text-gold block">
                  {event.date}
                </span>
                <span className="font-sans text-xs tracking-wide font-extrabold text-cream-100 block truncate">
                  {event.title}
                </span>
                <span className="font-sans text-[10px] text-cream-300/60 block">
                  {event.time}
                </span>
              </div>
            ))}
          </div>
          <button
            id="sidebar-events-link"
            onClick={() => onNavigate('events')}
            className="group self-start inline-flex items-center gap-2 font-sans text-xs tracking-widest font-extrabold text-gold hover:text-cream-50 mt-2 transition-colors duration-300"
          >
            VIEW ALL EVENTS
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Section 3: Visit Our Taproom */}
        <div id="sidebar-visit-taproom" className="p-6 xl:p-8 bg-cream-200 text-navy-900 flex-1 flex flex-col justify-center relative overflow-hidden">
          <div className="flex items-center gap-2 mb-3">
            <MapPin className="w-4.5 h-4.5 text-gold" />
            <h3 className="font-serif text-lg tracking-[0.15em] font-extrabold text-navy-900">
              VISIT OUR TAPROOM
            </h3>
          </div>
          
          <div className="space-y-3 mb-4">
            <div className="space-y-0.5">
              <p className="font-sans text-xs font-bold text-navy-900">15 HARBOR WAY</p>
              <p className="font-sans text-xs text-slate-gray font-medium">ESSEX, MASSACHUSETTS 01929</p>
            </div>
            
            <div className="grid grid-cols-2 gap-x-4 gap-y-1 border-t border-navy-900/10 pt-2 text-[11px]">
              <div>
                <p className="font-sans font-extrabold text-navy-900">WED – THU</p>
                <p className="font-sans font-medium text-slate-gray">4:00 PM – 9:00 PM</p>
              </div>
              <div>
                <p className="font-sans font-extrabold text-navy-900">FRI – SAT</p>
                <p className="font-sans font-medium text-slate-gray">12:00 PM – 10:00 PM</p>
              </div>
              <div className="col-span-2 pt-1">
                <p className="font-sans font-extrabold text-navy-900">SUN</p>
                <p className="font-sans font-medium text-slate-gray">12:00 PM – 6:00 PM</p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between border-t border-navy-900/10 pt-3 mt-auto">
            <button
              id="sidebar-taproom-link"
              onClick={() => onNavigate('taproom')}
              className="group inline-flex items-center gap-2 font-sans text-xs tracking-widest font-extrabold text-gold hover:text-navy-900 transition-colors duration-300"
            >
              GET DIRECTIONS
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            {/* Minimal stylized map crop representation */}
            <div className="w-16 h-12 bg-cream-300 rounded border border-navy-900/10 relative overflow-hidden flex items-center justify-center cursor-pointer hover:border-gold transition-colors" onClick={() => onNavigate('taproom')}>
              <div className="absolute top-1/2 left-1/3 w-8 h-1 bg-navy-900/10 transform rotate-12"></div>
              <div className="absolute top-1/4 left-1/2 w-1 h-8 bg-navy-900/10 transform -rotate-45"></div>
              <div className="absolute top-1/3 right-1/4 w-3 h-3 bg-blue-300/30 rounded-full border border-blue-400/20"></div>
              <MapPin className="w-4 h-4 text-gold absolute z-10 animate-bounce" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
