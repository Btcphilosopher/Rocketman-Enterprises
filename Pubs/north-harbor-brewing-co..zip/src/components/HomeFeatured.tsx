import { Compass, ShieldCheck, Heart, Leaf, HelpCircle, ArrowRight } from 'lucide-react';

interface HomeFeaturedProps {
  onNavigate: (viewId: string) => void;
  isDarkMode: boolean;
  lighthouseUrl: string;
}

export default function HomeFeatured({ onNavigate, isDarkMode, lighthouseUrl }: HomeFeaturedProps) {
  // Hardcoded premium values to match the mockup bottom bar
  const values = [
    {
      icon: <Compass className="w-6 h-6 text-gold" />,
      title: 'QUALITY INGREDIENTS',
      desc: 'Sourced with care from New England farms.',
    },
    {
      icon: <ShieldCheck className="w-6 h-6 text-gold" />,
      title: 'SMALL BATCH BREWED',
      desc: 'Never rushed. Patiently aged and matured.',
    },
    {
      icon: <Heart className="w-6 h-6 text-gold" />,
      title: 'COMMUNITY DRIVEN',
      desc: 'Beer brings us together around the hearth.',
    },
    {
      icon: <Leaf className="w-6 h-6 text-gold" />,
      title: 'SUSTAINABLE PRACTICES',
      desc: 'For our coast, forests, and future generations.',
    },
  ];

  // Cans from the mockup with precise color schemes
  const featuredCans = [
    {
      name: 'HARBOR IPA',
      style: 'INDIA PALE ALE',
      abv: '6.7% ALC./VOL.',
      bg: 'from-amber-600 to-navy-900',
      textColor: 'text-amber-500',
      canBg: 'bg-gradient-to-b from-navy-800 via-navy-900 to-amber-950',
      accentColor: 'border-amber-500/30',
      labelBg: 'bg-navy-900/90',
      badge: 'FLAGSHIP'
    },
    {
      name: 'COASTAL KÖLSCH',
      style: 'KÖLSCH STYLE ALE',
      abv: '4.8% ALC./VOL.',
      bg: 'from-cream-200 to-stone-400',
      textColor: 'text-stone-800',
      canBg: 'bg-gradient-to-b from-cream-100 via-cream-200 to-stone-300',
      accentColor: 'border-stone-400/30',
      labelBg: 'bg-cream-50/90',
      badge: 'CRISP'
    },
    {
      name: 'PINE POINT PALE ALE',
      style: 'AMERICAN PALE ALE',
      abv: '5.6% ALC./VOL.',
      bg: 'from-emerald-700 to-emerald-950',
      textColor: 'text-emerald-500',
      canBg: 'bg-gradient-to-b from-emerald-800 via-emerald-950 to-navy-950',
      accentColor: 'border-emerald-500/30',
      labelBg: 'bg-emerald-950/90',
      badge: 'RESINOUS'
    },
    {
      name: "DORY'S DARK ALE",
      style: 'AMBER ALE',
      abv: '5.5% ALC./VOL.',
      bg: 'from-amber-850 to-amber-950',
      textColor: 'text-orange-500',
      canBg: 'bg-gradient-to-b from-amber-900 via-stone-900 to-stone-950',
      accentColor: 'border-orange-500/30',
      labelBg: 'bg-stone-950/90',
      badge: 'TOASTED'
    }
  ];

  return (
    <div id="home-featured-section" className="relative">
      {/* 4 Core Beliefs Banner Bar (Dark & Premium Accent) */}
      <div id="core-values-banner" className="bg-navy-900 border-y border-gold/15 py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((val, idx) => (
            <div key={idx} className="flex items-start gap-4 hover:translate-y-[-2px] transition-all duration-300">
              <div className="p-2.5 bg-navy-800 rounded border border-gold/10 shrink-0">
                {val.icon}
              </div>
              <div>
                <h4 className="font-sans text-[11px] tracking-[0.2em] font-extrabold text-gold">
                  {val.title}
                </h4>
                <p className="font-sans text-xs text-cream-200/60 mt-1 font-medium leading-relaxed">
                  {val.desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Main Bottom Section: Cans display + Story + Lighthouse Layout */}
      <div className={`py-16 sm:py-24 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950' : 'bg-cream-100'}`}>
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 xl:gap-12 items-stretch">
          
          {/* 1. Left Column (Cols 1-5): The 4 premium cans side-by-side */}
          <div id="featured-beers-row" className="lg:col-span-5 flex flex-col justify-between">
            <div>
              <span className="font-sans text-[10px] tracking-[0.3em] font-extrabold text-gold block mb-2">
                OUR CORE ROTATION
              </span>
              <h2 className={`font-serif text-3xl sm:text-4xl font-extrabold tracking-tight ${isDarkMode ? 'text-cream-50' : 'text-navy-900'} mb-8`}>
                Signature New England Cans
              </h2>
            </div>

            {/* Cans Grid on a wooden-inspired horizontal dock shelf */}
            <div className="relative pt-6 pb-2 px-2 rounded-xl bg-navy-900/5 dark:bg-navy-900/30 border border-navy-900/5 dark:border-gold/5">
              <div className="grid grid-cols-4 gap-2 sm:gap-4 relative z-10 items-end">
                {featuredCans.map((can, idx) => (
                  <div
                    key={idx}
                    className="group cursor-pointer flex flex-col items-center text-center hover:scale-105 transition-all duration-300"
                    onClick={() => onNavigate('beer')}
                  >
                    {/* Can Cylinder design using pure modern CSS */}
                    <div className={`relative w-12 sm:w-16 h-28 sm:h-36 rounded-t-xl rounded-b-xl ${can.canBg} border border-gold/10 shadow-lg flex flex-col items-center justify-between p-1 sm:p-2 overflow-hidden`}>
                      {/* Metal can lip top */}
                      <div className="absolute top-0 w-full h-1.5 bg-gradient-to-r from-stone-400 via-stone-200 to-stone-400 rounded-t-xl"></div>
                      
                      {/* Logo and Brand on can */}
                      <div className="flex flex-col items-center mt-2 scale-75 sm:scale-100">
                        <Compass className="w-2.5 h-2.5 text-gold animate-pulse" />
                        <span className="font-serif text-[4.5px] tracking-widest font-bold text-cream-50 mt-0.5">NORTH HARBOR</span>
                      </div>

                      {/* Can central graphic element representing the style */}
                      <div className={`w-full py-1 ${can.labelBg} border-y ${can.accentColor} flex flex-col items-center`}>
                        <span className="font-serif text-[6px] sm:text-[8px] font-bold text-gold text-center leading-none">
                          {can.name.split(' ')[0]}
                        </span>
                        <span className="font-sans text-[4px] sm:text-[5px] text-cream-100/70 tracking-widest text-center mt-0.5 leading-none">
                          {can.style.split(' ')[0]}
                        </span>
                      </div>

                      {/* Alcohol badge bottom */}
                      <span className="font-sans text-[4.5px] sm:text-[6px] text-cream-200/50 mb-2 tracking-wider">
                        {can.abv.split(' ')[0]}
                      </span>

                      {/* Metal bottom ring */}
                      <div className="absolute bottom-0 w-full h-1.5 bg-gradient-to-r from-stone-400 via-stone-200 to-stone-400 rounded-b-xl"></div>
                    </div>

                    {/* Can Label Text Description beneath the dock */}
                    <div className="mt-3 space-y-0.5">
                      <p className={`font-sans text-[9px] sm:text-[10px] font-extrabold ${isDarkMode ? 'text-cream-100' : 'text-navy-900'} truncate w-14 sm:w-20`}>
                        {can.name}
                      </p>
                      <p className="font-sans text-[8px] text-slate-gray font-semibold">
                        {can.abv}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Wooden dock shelf base matching the image */}
              <div className="w-full h-2.5 bg-gradient-to-b from-amber-800 to-amber-950 rounded-full mt-2 border-b border-gold/20 shadow-md"></div>
            </div>

            <button
              id="row-catalogue-btn"
              onClick={() => onNavigate('beer')}
              className="mt-6 font-sans text-xs tracking-widest font-extrabold text-gold hover:text-navy-900 dark:hover:text-cream-100 self-start inline-flex items-center gap-2 group"
            >
              EXPLORE TASTING NOTES
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* 2. Center Column (Cols 6-9): Our Story / Brewed on Purpose */}
          <div id="story-block" className="lg:col-span-4 flex flex-col justify-center py-6 border-t lg:border-t-0 lg:border-x border-navy-900/10 dark:border-gold/10 lg:px-8">
            <span className="font-sans text-[10px] tracking-[0.3em] font-extrabold text-gold block mb-2">
              OUR STORY
            </span>
            <h2 className={`font-serif text-3xl sm:text-4xl font-extrabold tracking-tight ${isDarkMode ? 'text-cream-50' : 'text-navy-900'} leading-tight mb-6`}>
              Brewed on Purpose
            </h2>
            
            <div className={`space-y-4 font-sans text-xs sm:text-sm font-light ${isDarkMode ? 'text-cream-200/70' : 'text-slate-gray'} leading-relaxed`}>
              <p>
                North Harbor Brewing Co. was founded in 2014 in Essex, Massachusetts with a singular maritime dream: to craft pristine, high-character beers that celebrate the character, weather, and heritage of coastal New England.
              </p>
              <p>
                From the organic barley harvested in Vermont farms to the local spruce needles gathered from Maine forests, we brew each small batch deliberately. We do not rush. We respect time, wood-aging, and the company of neighbors.
              </p>
            </div>

            {/* Head Brewer's signature styling */}
            <div className="mt-8 pt-6 border-t border-navy-900/5 dark:border-gold/5 flex flex-col gap-1">
              {/* Stylized Signature using cursive fonts or vector-like script aesthetic */}
              <span className="font-serif italic text-2xl text-gold/80 tracking-wide font-normal">
                Erich Vance
              </span>
              <span className={`font-sans text-[10px] tracking-[0.25em] font-extrabold ${isDarkMode ? 'text-cream-300/40' : 'text-navy-900/40'}`}>
                FOUNDER & HEAD BREWER
              </span>
            </div>

            <button
              id="story-link"
              onClick={() => onNavigate('story')}
              className="group inline-flex items-center gap-2 font-sans text-xs tracking-widest font-extrabold text-gold hover:text-navy-900 dark:hover:text-cream-100 mt-6 transition-colors duration-300 self-start"
            >
              MEET THE TEAM
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>

          {/* 3. Right Column (Cols 10-12): Beautiful Tall Black-and-white Lighthouse */}
          <div id="lighthouse-photo-column" className="lg:col-span-3 flex flex-col justify-center relative min-h-[350px] lg:min-h-auto rounded-lg overflow-hidden border border-gold/10">
            <img
              src={lighthouseUrl}
              alt="Rugged Cape Elizabeth Lighthouse in Maine"
              className="absolute inset-0 w-full h-full object-cover grayscale brightness-90 hover:grayscale-0 transition-all duration-1000"
              referrerPolicy="no-referrer"
            />
            {/* Visual Frame overlay and subtle border lines */}
            <div className="absolute inset-4 border border-cream-100/10 pointer-events-none"></div>
            <div className="absolute bottom-4 left-4 right-4 bg-navy-950/80 backdrop-blur-md p-4 border border-gold/15 relative z-10">
              <span className="font-sans text-[9px] tracking-[0.2em] font-extrabold text-gold block">
                COASTAL HERITAGE
              </span>
              <p className="font-serif text-sm font-semibold text-cream-50 leading-snug mt-1">
                Cape Elizabeth, Maine
              </p>
              <p className="font-sans text-[10px] text-cream-300/60 mt-0.5 leading-normal">
                Inspiring our maritime wood-aging and barrel barrel-cellar programs.
              </p>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
