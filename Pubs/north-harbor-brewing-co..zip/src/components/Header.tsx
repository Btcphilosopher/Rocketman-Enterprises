import { useState, useEffect } from 'react';
import { Compass, ShoppingBag, User, Menu, X, Sun, Moon } from 'lucide-react';

interface HeaderProps {
  currentView: string;
  setCurrentView: (view: string) => void;
  onOpenCart: () => void;
  cartItemsCount: number;
  onOpenAccount: () => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

export default function Header({
  currentView,
  setCurrentView,
  onOpenCart,
  cartItemsCount,
  onOpenAccount,
  isDarkMode,
  toggleDarkMode,
}: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'beer', label: 'BEER' },
    { id: 'taproom', label: 'VISIT' },
    { id: 'story', label: 'OUR STORY' },
    { id: 'events', label: 'EVENTS' },
    { id: 'shop', label: 'SHOP' },
    { id: 'journal', label: 'JOURNAL' },
    { id: 'sustainability', label: 'SUSTAINABILITY' },
    { id: 'find-us', label: 'FIND US' },
  ];

  const handleNavClick = (viewId: string) => {
    setCurrentView(viewId);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <header
        id="main-header"
        className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
          isScrolled
            ? isDarkMode
              ? 'bg-navy-950/95 border-b border-gold/15 shadow-xl py-3'
              : 'bg-cream-100/95 border-b border-navy-900/10 shadow-lg py-3'
            : isDarkMode
            ? 'bg-gradient-to-b from-navy-950/80 to-transparent py-5'
            : 'bg-gradient-to-b from-cream-100/40 to-transparent py-5'
        } backdrop-blur-md`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo / Brand Name */}
            <div
              id="brand-logo"
              className="flex items-center gap-3 cursor-pointer group"
              onClick={() => handleNavClick('home')}
            >
              <div className="relative flex items-center justify-center w-10 h-10 border border-gold/30 rounded-full bg-navy-900/40 p-1 group-hover:border-gold transition-colors duration-500">
                <Compass className="w-6 h-6 text-gold animate-spin-slow group-hover:text-gold" />
                <div className="absolute inset-0 border border-transparent rounded-full group-hover:border-gold/20 group-hover:scale-110 transition-transform duration-500"></div>
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-lg tracking-widest font-bold leading-none text-gold group-hover:text-cream-300 transition-colors">
                  NORTH HARBOR
                </span>
                <span className={`font-sans text-[9px] tracking-[0.25em] font-medium leading-none ${isDarkMode ? 'text-cream-300/60' : 'text-navy-900/60'}`}>
                  BREWING CO.
                </span>
              </div>
            </div>

            {/* Desktop Navigation Links */}
            <nav id="desktop-nav" className="hidden lg:flex items-center space-x-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`relative font-sans text-xs tracking-[0.2em] font-semibold transition-all duration-300 py-2 hover:text-gold ${
                    currentView === item.id
                      ? 'text-gold'
                      : isDarkMode
                      ? 'text-cream-100'
                      : 'text-navy-900'
                  }`}
                >
                  {item.label}
                  {currentView === item.id && (
                    <span className="absolute bottom-0 left-1/4 right-1/4 h-[1.5px] bg-gold rounded-full"></span>
                  )}
                </button>
              ))}
            </nav>

            {/* Utility Actions */}
            <div id="header-utilities" className="flex items-center space-x-2 sm:space-x-4">
              {/* Theme Toggle */}
              <button
                id="theme-toggle-btn"
                onClick={toggleDarkMode}
                className={`p-2 rounded-full transition-all duration-300 hover:scale-105 ${
                  isDarkMode ? 'text-gold hover:bg-navy-800' : 'text-navy-900 hover:bg-cream-200'
                }`}
                title={isDarkMode ? 'Switch to Fog Mode' : 'Switch to Sea Mode'}
              >
                {isDarkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>

              {/* Account button */}
              <button
                id="account-btn"
                onClick={onOpenAccount}
                className={`p-2 rounded-full transition-all duration-300 hover:scale-105 ${
                  isDarkMode ? 'text-cream-100 hover:bg-navy-800' : 'text-navy-900 hover:bg-cream-200'
                }`}
                title="Customer Account"
              >
                <User className="w-4.5 h-4.5" />
              </button>

              {/* Shopping Cart Trigger */}
              <button
                id="cart-trigger-btn"
                onClick={onOpenCart}
                className={`relative p-2 rounded-full transition-all duration-300 hover:scale-105 ${
                  isDarkMode ? 'text-cream-100 hover:bg-navy-800' : 'text-navy-900 hover:bg-cream-200'
                }`}
              >
                <ShoppingBag className="w-4.5 h-4.5" />
                {cartItemsCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-gold text-navy-950 font-sans text-[10px] font-extrabold rounded-full flex items-center justify-center animate-pulse border border-navy-900">
                    {cartItemsCount}
                  </span>
                )}
              </button>

              {/* Call-to-action button (Desktop) */}
              <button
                id="header-cta-order"
                onClick={() => handleNavClick('shop')}
                className="hidden md:inline-flex items-center font-sans text-xs tracking-widest font-extrabold border border-gold px-5 py-2 hover:bg-gold hover:text-navy-950 transition-all duration-500 bg-transparent text-gold"
              >
                ORDER BEER
              </button>

              {/* Hamburger Button (Mobile) */}
              <button
                id="mobile-menu-toggle"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={`lg:hidden p-2 rounded-full transition-all ${
                  isDarkMode ? 'text-cream-100 hover:bg-navy-800' : 'text-navy-900 hover:bg-cream-200'
                }`}
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      <div
        id="mobile-nav-drawer"
        className={`fixed inset-0 z-40 lg:hidden transition-all duration-500 ease-in-out ${
          isMobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div
          id="mobile-drawer-backdrop"
          className="absolute inset-0 bg-navy-950/80 backdrop-blur-sm"
          onClick={() => setIsMobileMenuOpen(false)}
        ></div>
        <div
          id="mobile-drawer-content"
          className={`absolute right-0 top-0 h-full w-[280px] sm:w-[320px] shadow-2xl transition-transform duration-500 ${
            isMobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          } ${isDarkMode ? 'bg-navy-900 text-cream-100 border-l border-gold/15' : 'bg-cream-50 text-navy-900 border-l border-navy-900/10'} p-6 flex flex-col justify-between`}
        >
          <div>
            <div className="flex items-center justify-between border-b border-gold/10 pb-5 mb-6">
              <span className="font-serif text-sm tracking-widest font-bold text-gold">
                NORTH HARBOR
              </span>
              <button
                id="mobile-drawer-close"
                onClick={() => setIsMobileMenuOpen(false)}
                className={`p-1 rounded-full ${isDarkMode ? 'text-cream-100/60 hover:text-cream-100' : 'text-navy-900/60'}`}
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav id="mobile-nav-links" className="flex flex-col space-y-4">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  id={`mobile-nav-link-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`w-full text-left font-sans text-sm tracking-[0.18em] font-semibold py-2.5 px-3 border-l-2 hover:bg-gold/5 hover:text-gold transition-all ${
                    currentView === item.id
                      ? 'border-gold text-gold bg-gold/5'
                      : 'border-transparent'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="border-t border-gold/10 pt-5 space-y-4">
            <button
              id="mobile-drawer-cta-order"
              onClick={() => handleNavClick('shop')}
              className="w-full text-center font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-3 hover:bg-cream-100 transition-colors border border-gold"
            >
              ORDER BEER ONLINE
            </button>
            <p className={`font-sans text-[10px] text-center tracking-wider ${isDarkMode ? 'text-cream-300/40' : 'text-navy-900/40'}`}>
              Essex, Massachusetts • Estd 2014
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
