import React, { useState } from 'react';
import { Product, Beer, CartItem } from '../types';
import { PRODUCTS, BEERS } from '../data';
import { Compass, ShoppingBag, Plus, Minus, Trash2, Check, Sparkles, CreditCard, Shield, User, ArrowRight, Heart } from 'lucide-react';

interface ShopPageProps {
  onAddToCartItem: (item: CartItem) => void;
  cartItems: CartItem[];
  onRemoveFromCart: (itemId: string) => void;
  onUpdateCartQty: (itemId: string, qty: number) => void;
  onClearCart: () => void;
  isDarkMode: boolean;
}

export default function ShopPage({
  onAddToCartItem,
  cartItems,
  onRemoveFromCart,
  onUpdateCartQty,
  onClearCart,
  isDarkMode
}: ShopPageProps) {
  // Category filter state
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedSize, setSelectedSize] = useState<string>('M');
  
  // Custom Subscription Builder State
  const [subStep, setSubStep] = useState<number>(1);
  const [subType, setSubType] = useState<'mixed' | 'hazies' | 'crisp'>('mixed');
  const [subQty, setSubQty] = useState<number>(12); // 12 or 24 cans
  const [subFreq, setSubFreq] = useState<string>('4weeks');
  const [subAdded, setSubAdded] = useState<boolean>(false);

  // Checkout Multi-Step Wizard State
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [checkoutStep, setCheckoutStep] = useState<number>(1);
  const [fullName, setFullName] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [cardNo, setCardNo] = useState<string>('');
  const [isPaid, setIsPaid] = useState<boolean>(false);

  // Active Customer Portal state
  const [isAccountOpen, setIsAccountOpen] = useState<boolean>(false);

  const categories = [
    { id: 'all', label: 'ALL PRODUCTS' },
    { id: 'cans', label: 'CANS' },
    { id: 'mixed', label: 'MIXED CASES' },
    { id: 'gifts', label: 'GIFT BOXES' },
    { id: 'glassware', label: 'GLASSWARE' },
    { id: 'apparel', label: 'APPAREL' }
  ];

  // Map BEERS into products format to enable buying cans directly
  const BEER_PRODUCTS: Product[] = BEERS.map(beer => ({
    id: beer.id,
    name: beer.name,
    category: 'cans',
    description: beer.tagline,
    price: beer.price,
    imageUrl: beer.imageUrl,
    rating: 4.8,
    reviewsCount: 30,
    details: ['16oz 4-Pack cans', 'Unpasteurized fresh draft quality', 'Keep cold, pour gently'],
    stock: 50
  }));

  const allProducts = [...BEER_PRODUCTS, ...PRODUCTS];

  const filteredProducts = allProducts.filter(p => {
    if (selectedCategory === 'all') return true;
    return p.category === selectedCategory;
  });

  const handleAddToCart = (product: Product) => {
    // Determine size if apparel
    const itemSize = product.category === 'apparel' ? selectedSize : undefined;
    const itemId = itemSize ? `${product.id}-${itemSize}` : product.id;

    onAddToCartItem({
      id: itemId,
      product: product,
      quantity: 1,
      selectedSize: itemSize
    });
  };

  const handleBuildSubscription = () => {
    // Generate custom sub product name
    const title = `The Mariner's ${subType.charAt(0).toUpperCase() + subType.slice(1)} Box Subscription (${subQty} Cans)`;
    const price = subQty === 12 ? 45.00 : 80.00;

    const subItem: CartItem = {
      id: `sub-${subType}-${subQty}-${subFreq}`,
      product: {
        id: `sub-${subType}-${subQty}`,
        name: title,
        category: 'mixed',
        description: `Repeating fresh brew box delivered every ${subFreq === '2weeks' ? '2 weeks' : subFreq === '4weeks' ? '4 weeks' : '6 weeks'}.`,
        price: price,
        imageUrl: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=600&q=80',
        rating: 5.0,
        reviewsCount: 12,
        details: [`${subQty} cans of seasonal brews`, 'Ships cold', 'Cancel anytime'],
        stock: 999
      },
      quantity: 1,
      isSubscription: true,
      frequency: subFreq
    };

    onAddToCartItem(subItem);
    setSubAdded(true);
    setTimeout(() => {
      setSubAdded(false);
      setSubStep(1);
    }, 2000);
  };

  const calculateTotal = () => {
    return cartItems.reduce((acc, item) => acc + (item.product.price * item.quantity), 0);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (checkoutStep === 1) {
      setCheckoutStep(2);
    } else {
      setIsPaid(true);
    }
  };

  const handleCompletePayment = () => {
    onClearCart();
    setIsCheckoutOpen(false);
    setCheckoutStep(1);
    setIsPaid(false);
  };

  return (
    <div id="shop-page-view" className={`pt-28 pb-20 px-4 sm:px-6 lg:px-8 ${isDarkMode ? 'bg-navy-950 text-cream-100 paper-texture-dark' : 'bg-cream-100 text-navy-900 paper-texture'}`}>
      <div className="max-w-7xl mx-auto space-y-16">
        
        {/* Upper Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-navy-900 text-cream-50 rounded-2xl border border-gold/15 p-6 sm:p-10 relative overflow-hidden">
          <div className="lg:col-span-7 space-y-6 z-10">
            <span className="inline-flex items-center gap-2 font-sans text-xs tracking-[0.3em] font-extrabold text-gold uppercase">
              <Sparkles className="w-3.5 h-3.5" />
              NORTH HARBOR MERCHANDISE & COLD CAN DISPATCH
            </span>
            <h1 className="font-serif text-3xl sm:text-5xl font-extrabold tracking-tight leading-none">
              The Maritime Retail House
            </h1>
            <p className="font-sans text-sm font-light text-cream-200/85 leading-relaxed">
              Order cold fresh cans, hand-made gift boxes, waxed canvas caps, or custom tulip tasting glasses shipped directly to your porch. Freshness is protected with double-insulated craft cells and cool gel dispatch.
            </p>

            <div className="flex gap-4">
              <a href="#shop-grid" className="font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 px-6 py-3.5 border border-gold hover:bg-cream-100 hover:border-cream-100 transition-colors">
                EXPLORE RETAIL GRID
              </a>
              <a href="#sub-builder" className="font-sans text-xs tracking-widest font-extrabold border border-cream-100/30 text-cream-100 px-6 py-3.5 hover:bg-cream-100/10 transition-colors">
                BUILD A SUBSCRIPTION
              </a>
            </div>
          </div>

          <div className="lg:col-span-5 relative aspect-[16/10] sm:aspect-[16/9] lg:aspect-auto h-full min-h-[220px] rounded-xl overflow-hidden border border-gold/10">
            <img
              src="https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=800&q=80"
              alt="North Harbor Gift Box Collection"
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-950/80 via-transparent to-transparent"></div>
          </div>
        </div>

        {/* 1. INTERACTIVE BEER SUBSCRIPTION BUILDER SECTION */}
        <div id="sub-builder" className={`border rounded-xl p-6 sm:p-10 ${isDarkMode ? 'bg-navy-900 border-gold/15' : 'bg-cream-50 border-navy-900/10'}`}>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            <div className="lg:col-span-5 space-y-4">
              <span className="font-sans text-[9px] tracking-[0.25em] font-extrabold text-gold uppercase block">NEVER RUN DRY</span>
              <h2 className="font-serif text-2xl sm:text-3xl font-extrabold tracking-tight">
                The Mariner's Craft Box Subscription
              </h2>
              <p className="font-sans text-xs sm:text-sm text-slate-gray leading-relaxed font-light">
                Configure a customized rolling delivery of fresh New England craft beers. Hand-selected seasonal releases, exclusive double dry-hopped IPAs, and wood-aged wild sours dispatched on your terms. 
              </p>
              
              <div className="space-y-2 text-xs font-sans font-medium text-slate-gray dark:text-cream-300">
                <p>✓ 15% discount on standard can prices</p>
                <p>✓ Exclusive subscriber-only experimental releases</p>
                <p>✓ Free delivery on 24-can dispatches</p>
                <p>✓ Pause, update, or cancel instantly from portal</p>
              </div>
            </div>

            {/* Customizer steps wizard */}
            <div className="lg:col-span-7 bg-navy-950 border border-gold/15 p-6 rounded-xl text-cream-100 space-y-6">
              <div className="flex justify-between items-center border-b border-gold/10 pb-3">
                <span className="font-sans text-[10px] tracking-widest font-extrabold text-gold">STEP {subStep} OF 3</span>
                <span className="font-sans text-[10px] text-cream-300">
                  {subStep === 1 ? 'SELECT BEER CATEGORY' : subStep === 2 ? 'CHOOSE SIZE' : 'DELIVERY INTERVAL'}
                </span>
              </div>

              {subStep === 1 && (
                <div className="space-y-4">
                  <p className="font-sans text-xs font-extrabold text-cream-200 uppercase">1. What styles float your vessel?</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <button
                      onClick={() => setSubType('mixed')}
                      className={`p-4 text-left border rounded transition-all flex flex-col justify-between h-28 ${
                        subType === 'mixed' ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <span className="font-bold">The Crew Mixed Box</span>
                      <span className="text-[10px] opacity-70">A perfect balance of crisp lagers, IPAs, and dark stouts.</span>
                    </button>
                    <button
                      onClick={() => setSubType('hazies')}
                      className={`p-4 text-left border rounded transition-all flex flex-col justify-between h-28 ${
                        subType === 'hazies' ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <span className="font-bold">Hop-Heads Hazies</span>
                      <span className="text-[10px] opacity-70">Double dry-hopped IPAs, pale ales, and hop-burst hazies.</span>
                    </button>
                    <button
                      onClick={() => setSubType('crisp')}
                      className={`p-4 text-left border rounded transition-all flex flex-col justify-between h-28 ${
                        subType === 'crisp' ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <span className="font-bold">Pristine Crisp</span>
                      <span className="text-[10px] opacity-70">Refreshing Kölsch, pilsners, wheat ales, and clean lagers.</span>
                    </button>
                  </div>
                </div>
              )}

              {subStep === 2 && (
                <div className="space-y-4">
                  <p className="font-sans text-xs font-extrabold text-cream-200 uppercase">2. Select Can Volume Dispatch</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <button
                      onClick={() => setSubQty(12)}
                      className={`p-4 text-left border rounded transition-all flex flex-col justify-between h-24 ${
                        subQty === 12 ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <span className="font-bold">12 Cans (Three 4-Packs)</span>
                      <span className="text-[10px] text-gold font-extrabold">$45.00 / Delivery</span>
                    </button>
                    <button
                      onClick={() => setSubQty(24)}
                      className={`p-4 text-left border rounded transition-all flex flex-col justify-between h-24 ${
                        subQty === 24 ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <span className="font-bold">24 Cans (Six 4-Packs - Free Delivery)</span>
                      <span className="text-[10px] text-gold font-extrabold">$80.00 / Delivery</span>
                    </button>
                  </div>
                </div>
              )}

              {subStep === 3 && (
                <div className="space-y-4">
                  <p className="font-sans text-xs font-extrabold text-cream-200 uppercase">3. Choose Shipping Frequency</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <button
                      onClick={() => setSubFreq('2weeks')}
                      className={`p-4 text-center border rounded transition-all ${
                        subFreq === '2weeks' ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <p className="font-bold">Every 2 Weeks</p>
                    </button>
                    <button
                      onClick={() => setSubFreq('4weeks')}
                      className={`p-4 text-center border rounded transition-all ${
                        subFreq === '4weeks' ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <p className="font-bold">Every 4 Weeks</p>
                    </button>
                    <button
                      onClick={() => setSubFreq('6weeks')}
                      className={`p-4 text-center border rounded transition-all ${
                        subFreq === '6weeks' ? 'border-gold bg-gold/5 text-gold' : 'border-gold/10 hover:border-gold/40'
                      }`}
                    >
                      <p className="font-bold">Every 6 Weeks</p>
                    </button>
                  </div>
                </div>
              )}

              {/* Wizard navigation */}
              <div className="flex justify-between pt-4 border-t border-gold/10">
                <button
                  disabled={subStep === 1}
                  onClick={() => setSubStep(subStep - 1)}
                  className="font-sans text-[10px] tracking-widest font-extrabold disabled:opacity-30 border border-gold/20 text-cream-200 px-4 py-2 hover:bg-gold/5 rounded"
                >
                  PREVIOUS
                </button>

                {subStep < 3 ? (
                  <button
                    onClick={() => setSubStep(subStep + 1)}
                    className="font-sans text-[10px] tracking-widest font-extrabold bg-gold text-navy-950 px-5 py-2 hover:bg-cream-100 transition-colors"
                  >
                    CONTINUE NEXT
                  </button>
                ) : (
                  <button
                    onClick={handleBuildSubscription}
                    disabled={subAdded}
                    className="font-sans text-[10px] tracking-widest font-extrabold bg-gold text-navy-950 px-6 py-2.5 hover:bg-cream-100 transition-colors flex items-center gap-2"
                  >
                    {subAdded ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        ADDED TO BASKET!
                      </>
                    ) : (
                      <>
                        <Compass className="w-3.5 h-3.5 animate-spin-slow" />
                        SUBSCRIBE & START DISPATCH
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

          </div>
        </div>

        {/* 2. PRODUCT RETAL GRID SECTION */}
        <div id="shop-grid" className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-navy-900/10 dark:border-gold/10 pb-6">
            <div className="space-y-1">
              <span className="font-sans text-[9px] tracking-[0.25em] font-extrabold text-gold uppercase block">THE DRY SHED</span>
              <h3 className="font-serif text-3xl font-bold">The General Provisions</h3>
            </div>
            
            {/* Category selection */}
            <div className="flex flex-wrap gap-2 text-xs">
              {categories.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`font-sans text-[9px] tracking-[0.15em] font-extrabold px-4 py-2 transition-colors border ${
                    selectedCategory === cat.id
                      ? 'bg-gold text-navy-950 border-gold'
                      : isDarkMode
                      ? 'border-gold/15 text-cream-200 hover:border-gold hover:text-gold'
                      : 'border-navy-900/10 text-navy-900 hover:border-gold hover:text-gold'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8">
            {filteredProducts.map((prod) => (
              <div
                key={prod.id}
                className={`border rounded-lg overflow-hidden flex flex-col justify-between transition-all duration-300 hover:scale-[1.01] ${
                  isDarkMode ? 'bg-navy-900 border-gold/10 hover:border-gold/30' : 'bg-cream-50 border-navy-900/5 hover:border-gold/30'
                }`}
              >
                {/* Visual */}
                <div className="relative aspect-[4/3] bg-navy-950">
                  <img
                    src={prod.imageUrl}
                    alt={prod.name}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  {prod.isSubscriptionAvailable && (
                    <span className="absolute top-3 left-3 font-sans text-[8px] tracking-[0.15em] font-black uppercase text-navy-950 bg-gold px-2.5 py-1 rounded">
                      SUBSCRIPTION OPTION
                    </span>
                  )}
                  {prod.stock < 20 && (
                    <span className="absolute top-3 right-3 font-sans text-[8px] tracking-[0.15em] font-black uppercase text-cream-50 bg-red-600/95 px-2.5 py-1 rounded">
                      ONLY {prod.stock} LEFT
                    </span>
                  )}
                </div>

                {/* Info & purchasing */}
                <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-sans text-[8px] tracking-widest text-gold font-extrabold uppercase">{prod.category}</span>
                      <span className="font-sans text-[10px] text-slate-gray font-semibold">★ {prod.rating} ({prod.reviewsCount} reviews)</span>
                    </div>
                    <h4 className="font-serif text-lg font-bold tracking-wide">{prod.name}</h4>
                    <p className="font-sans text-xs text-slate-gray leading-relaxed font-light">{prod.description}</p>
                    
                    {prod.category === 'apparel' && (
                      <div className="flex items-center gap-2 pt-2 text-xs">
                        <span className="font-sans text-[8px] tracking-wider text-slate-gray font-bold uppercase">SELECT SIZE:</span>
                        {['S', 'M', 'L', 'XL', 'XXL'].map((sz) => (
                          <button
                            key={sz}
                            onClick={() => setSelectedSize(sz)}
                            className={`w-7 h-7 rounded border font-sans text-[10px] font-bold transition-all ${
                              selectedSize === sz
                                ? 'bg-gold text-navy-950 border-gold'
                                : isDarkMode
                                ? 'border-gold/15 text-cream-300 hover:border-gold'
                                : 'border-navy-900/10 text-navy-900 hover:border-gold'
                            }`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-navy-900/5 dark:border-gold/5">
                    <span className="font-sans text-base font-extrabold text-gold">${prod.price.toFixed(2)}</span>
                    <button
                      id={`add-provision-btn-${prod.id}`}
                      onClick={() => handleAddToCart(prod)}
                      className="font-sans text-[9px] tracking-widest font-extrabold border border-gold/40 text-gold px-4 py-2.5 hover:bg-gold hover:text-navy-950 transition-colors"
                    >
                      ADD TO BASKET
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Cart Slider Drawer Overlay */}
      {cartItems.length > 0 && (
        <div id="cart-drawer-overlay" className="fixed bottom-6 right-6 z-40 bg-navy-950/95 border border-gold/20 text-cream-100 p-5 rounded-xl shadow-2xl max-w-sm w-full space-y-4 animate-bounce-slow">
          <div className="flex justify-between items-center border-b border-gold/15 pb-2">
            <div className="flex items-center gap-2 text-gold">
              <ShoppingBag className="w-5 h-5" />
              <span className="font-serif text-sm font-bold">Your Provisions Crate</span>
            </div>
            <span className="font-sans text-[10px] font-extrabold bg-gold/10 text-gold px-2 py-0.5 rounded">
              {cartItems.reduce((acc, item) => acc + item.quantity, 0)} ITEMS
            </span>
          </div>

          <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
            {cartItems.map((item) => (
              <div key={item.id} className="flex justify-between items-center text-xs border-b border-gold/5 pb-2">
                <div className="truncate w-44">
                  <p className="font-bold truncate">{item.product.name}</p>
                  <p className="text-[10px] text-slate-gray font-sans">
                    {item.selectedSize ? `Size: ${item.selectedSize} • ` : ''}
                    ${item.product.price.toFixed(2)} each
                  </p>
                </div>
                
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => onUpdateCartQty(item.id, item.quantity - 1)}
                    className="p-1 hover:text-gold"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="font-bold text-gold w-3 text-center">{item.quantity}</span>
                  <button
                    onClick={() => onUpdateCartQty(item.id, item.quantity + 1)}
                    className="p-1 hover:text-gold"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                  
                  <button
                    onClick={() => onRemoveFromCart(item.id)}
                    className="p-1 hover:text-red-500 ml-1 text-slate-gray"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="border-t border-gold/15 pt-3 flex justify-between items-center text-xs font-sans">
            <span className="font-bold">SUBTOTAL VALUE</span>
            <span className="font-serif text-base font-bold text-gold">${calculateTotal().toFixed(2)}</span>
          </div>

          <button
            onClick={() => setIsCheckoutOpen(true)}
            className="w-full text-center font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-3 hover:bg-cream-100 transition-colors border border-gold"
          >
            PROCEED TO SECURE CHECKOUT
          </button>
        </div>
      )}

      {/* Checkout Multistep Wizard Dialog */}
      {isCheckoutOpen && (
        <div id="checkout-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-navy-950/80 backdrop-blur-md" onClick={() => setIsCheckoutOpen(false)}></div>
          
          <div className="relative max-w-md w-full bg-navy-900 border border-gold/15 text-cream-100 p-6 sm:p-8 rounded-xl shadow-2xl space-y-6 max-h-[90vh] overflow-y-auto">
            <button
              id="close-checkout"
              onClick={() => setIsCheckoutOpen(false)}
              className="absolute top-4 right-4 text-cream-300 hover:text-gold"
            >
              ✕
            </button>

            {!isPaid ? (
              <form onSubmit={handleCheckoutSubmit} className="space-y-5">
                <div className="space-y-1">
                  <span className="font-sans text-[8px] tracking-[0.25em] font-extrabold text-gold uppercase block">SECURE DISPATCH PROTOCOL</span>
                  <h3 className="font-serif text-xl font-bold">Secure Checkout Process</h3>
                  <p className="font-sans text-[11px] text-slate-gray">Verify your shipping provisions. Securely encrypted and processed.</p>
                </div>

                {checkoutStep === 1 ? (
                  <div className="space-y-4 text-xs">
                    <p className="font-sans text-[10px] tracking-wider font-extrabold text-gold uppercase border-b border-gold/10 pb-1">1. SHIPPING ADDRESS</p>
                    <div className="space-y-1">
                      <label className="font-sans font-bold text-slate-gray">Mariner Full Name</label>
                      <input
                        type="text"
                        required
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        placeholder="John Winthrop"
                        className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded text-cream-100 font-sans"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="font-sans font-bold text-slate-gray">Street Address (Continental US)</label>
                      <input
                        type="text"
                        required
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder="12 Beacon Hill Road, Boston, MA 02108"
                        className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded text-cream-100 font-sans"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 text-xs">
                    <p className="font-sans text-[10px] tracking-wider font-extrabold text-gold uppercase border-b border-gold/10 pb-1">2. SECURE PAYMENT GATEWAY</p>
                    <div className="bg-navy-950 p-3 rounded border border-gold/10 space-y-2 mb-2">
                      <div className="flex items-center gap-1 text-[10px] text-gold font-sans font-extrabold">
                        <Shield className="w-3.5 h-3.5" />
                        SSL ENCRYPTED SIMULATION
                      </div>
                      <p className="text-[10px] text-slate-gray">For verification, any test billing credentials will execute successfully. Do not input real secrets.</p>
                    </div>

                    <div className="space-y-1">
                      <label className="font-sans font-bold text-slate-gray">Credit Card Number</label>
                      <input
                        type="text"
                        required
                        value={cardNo}
                        onChange={(e) => setCardNo(e.target.value)}
                        placeholder="4111 2222 3333 4444"
                        className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded text-cream-100 font-sans"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1">
                        <label className="font-sans font-bold text-slate-gray">Expiry Date</label>
                        <input
                          type="text"
                          required
                          placeholder="12 / 29"
                          className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded text-cream-100 font-sans"
                        />
                      </div>
                      <div className="space-y-1">
                        <label className="font-sans font-bold text-slate-gray">Security Code (CVV)</label>
                        <input
                          type="text"
                          required
                          placeholder="382"
                          className="w-full p-3 bg-navy-950/50 border border-gold/15 focus:border-gold outline-none rounded text-cream-100 font-sans"
                        />
                      </div>
                    </div>
                  </div>
                )}

                <div className="border-t border-gold/10 pt-4 space-y-3">
                  <div className="flex justify-between text-xs font-sans">
                    <span className="text-slate-gray">Cart Value:</span>
                    <span>${calculateTotal().toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-xs font-sans">
                    <span className="text-slate-gray">Cold Pack Dispatch Fee:</span>
                    <span className="text-gold font-bold">FREE</span>
                  </div>
                  <div className="flex justify-between text-sm font-sans font-extrabold">
                    <span>SECURE TOTAL:</span>
                    <span className="text-gold font-serif">${calculateTotal().toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex gap-3">
                  {checkoutStep === 2 && (
                    <button
                      type="button"
                      onClick={() => setCheckoutStep(1)}
                      className="font-sans text-[10px] tracking-widest font-extrabold border border-gold/20 text-cream-200 px-4 py-3 hover:bg-gold/5 rounded"
                    >
                      BACK
                    </button>
                  )}
                  <button
                    type="submit"
                    className="flex-1 font-sans text-xs tracking-widest font-extrabold bg-gold text-navy-950 py-3.5 hover:bg-cream-100 transition-colors border border-gold"
                  >
                    {checkoutStep === 1 ? 'PROCEED TO PAYMENT' : 'AUTHORIZE DISPATCH'}
                  </button>
                </div>
              </form>
            ) : (
              <div id="checkout-success" className="text-center py-6 space-y-6 flex flex-col items-center justify-center">
                <div className="w-16 h-16 bg-gold/10 rounded-full border border-gold flex items-center justify-center animate-bounce">
                  <Check className="w-8 h-8 text-gold" />
                </div>
                <div className="space-y-2">
                  <h3 className="font-serif text-2xl font-bold text-gold">Order Dispatched Successfully</h3>
                  <p className="font-sans text-xs font-semibold uppercase tracking-widest text-slate-gray">
                    DISPATCH BILL: NHB-{Math.floor(200000 + Math.random() * 899999)}
                  </p>
                  <p className="font-sans text-xs font-light leading-relaxed">
                    Thank you, <span className="font-bold text-gold">{fullName || 'Mariner'}</span>. Your maritime supplies have been securely packed and allocated.
                  </p>
                </div>

                <div className="bg-navy-950/40 border border-gold/10 p-4 rounded text-left text-xs w-full space-y-2">
                  <p className="font-bold">✓ Insulated Cold Cell Packing Verified</p>
                  <p className="font-bold">✓ Estimated Porter Delivery: <span className="text-gold">3-5 Business Days</span></p>
                  <p className="font-bold">✓ Tracked delivery updates sent to your mariner inbox</p>
                </div>

                <button
                  onClick={handleCompletePayment}
                  className="font-sans text-[10px] tracking-widest font-extrabold bg-gold text-navy-950 py-3 px-8 hover:bg-cream-100 border border-gold"
                >
                  RETURN TO DRY SHED
                </button>
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
}
