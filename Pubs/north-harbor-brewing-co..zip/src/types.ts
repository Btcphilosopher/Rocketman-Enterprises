export interface Beer {
  id: string;
  name: string;
  style: string;
  tagline: string;
  description: string;
  abv: string;
  ibu: number;
  tastingNotes: string[];
  foodPairings: string[];
  availability: string; // e.g. "Year-Round", "Seasonal - Autumn", "Limited Release"
  awards?: string[];
  brewTechnique?: string;
  ingredients: {
    malts: string[];
    hops: string[];
    yeast: string;
    water?: string;
  };
  imageUrl: string;
  price: number;
  volume: string;
  color: string; // Hex or tailwind class for beer color badge
}

export interface Product {
  id: string;
  name: string;
  category: 'cans' | 'bottles' | 'mixed' | 'gifts' | 'glassware' | 'apparel' | 'merch';
  description: string;
  price: number;
  imageUrl: string;
  rating: number;
  reviewsCount: number;
  details: string[];
  sizes?: string[]; // For apparel
  stock: number;
  isSubscriptionAvailable?: boolean;
}

export interface CartItem {
  id: string; // Can be product ID + size to distinguish sizes
  product: Product | Beer;
  quantity: number;
  selectedSize?: string;
  isSubscription?: boolean;
  frequency?: string; // "2weeks" | "4weeks" | "6weeks"
}

export interface JournalPost {
  id: string;
  title: string;
  summary: string;
  content: string;
  category: 'Science' | 'Heritage' | 'Recipes' | 'Guides' | 'Interviews';
  author: string;
  role: string;
  date: string;
  readTime: string;
  imageUrl: string;
}

export interface TaproomEvent {
  id: string;
  title: string;
  subtitle?: string;
  date: string;
  day: string;
  month: string;
  time: string;
  description: string;
  category: 'live-music' | 'tasting' | 'festival' | 'celebration' | 'tour';
  price?: string; // e.g. "Free" or "$25"
  ticketsAvailable?: boolean;
}

export interface Review {
  id: string;
  author: string;
  rating: number;
  date: string;
  comment: string;
  verified: boolean;
  productName: string;
}

export interface Booking {
  id: string;
  name: string;
  email: string;
  guests: number;
  date: string;
  time: string;
  type: 'table' | 'tour';
  specialRequests?: string;
  status: 'pending' | 'confirmed';
}
