export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: string;
  category: 'breakfast' | 'lunch' | 'dinner' | 'late-night' | 'sunday-roast' | 'desserts' | 'cocktails' | 'beers' | 'wines' | 'spirits';
  tags?: string[];
  isSignature?: boolean;
}

export interface EventItem {
  id: string;
  date: string; // e.g. '2026-08-04'
  dayOfWeek: string; // e.g. 'Tuesday'
  title: string;
  description: string;
  time: string; // e.g. '8:00 PM - 11:00 PM'
  category: 'Jazz' | 'Acoustic' | 'Piano Evening' | 'British Rock' | 'DJ Set' | 'Sport';
}

export interface GalleryItem {
  id: string;
  url: string;
  category: 'interiors' | 'food' | 'drinks' | 'events';
  caption: string;
}

export interface ReviewItem {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
  avatar?: string;
}

export interface CareerJob {
  id: string;
  title: string;
  department: string;
  type: string; // e.g. 'Full-time'
  salary: string;
  description: string;
  requirements: string[];
}

export interface JournalPost {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  content: string;
  date: string;
  readTime: string;
  imageUrl: string;
}

export type ViewState = 
  | 'home' 
  | 'about' 
  | 'menus' 
  | 'drinks' 
  | 'live' 
  | 'private' 
  | 'gallery' 
  | 'reservations' 
  | 'journal' 
  | 'giftcards' 
  | 'careers' 
  | 'contact';
