import React from 'react';
import { IMAGES } from '../data';
import { ViewState } from '../types';

interface AboutSectionProps {
  setView: (view: ViewState) => void;
}

export default function AboutSection({ setView }: AboutSectionProps) {
  return (
    <section 
      id="welcome-section"
      className="relative bg-[#101010] py-20 lg:py-28 overflow-hidden crest-watermark"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-stretch">
          
          {/* Left Side: Luxurious Photography Zoom Container */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            <div className="img-zoom-container relative h-[450px] lg:h-[550px] w-full border border-[#B68C45]/30">
              <img
                src={IMAGES.pubInterior}
                alt="The Albion & Liberty Dark Walnut Cozy Snug"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#101010]/80 via-transparent to-transparent" />
              
              {/* Subtle Badge */}
              <div className="absolute bottom-6 left-6 border border-[#B68C45]/30 bg-[#101010]/95 backdrop-blur-sm p-5">
                <p className="font-serif text-sm tracking-widest text-[#B68C45] uppercase" style={{ fontFamily: 'Georgia, serif' }}>
                  The Snug Fireplace Room
                </p>
                <p className="font-sans text-[10px] tracking-widest text-[#E8E1D5]/60 mt-1">
                  Private bookings available daily
                </p>
              </div>
            </div>
          </div>

          {/* Right Side: Editorial Ivory/Cream Panel */}
          <div className="lg:col-span-6 flex items-center">
            <div className="relative bg-[#F6F3ED] text-[#101010] p-8 sm:p-12 lg:p-16 border border-[#B68C45]/20 w-full flex flex-col justify-between">
              
              {/* Corner brass-style ornament */}
              <div className="absolute top-4 right-4 text-[#B68C45]/20 font-serif text-6xl select-none">
                AL
              </div>

              <div>
                <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
                  WELCOME TO
                </p>
                <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light text-[#101010] leading-tight mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                  THE ALBION & LIBERTY
                </h2>
                
                {/* Refined Gold Accent Divider */}
                <div className="w-16 h-[1.5px] bg-[#B68C45] mb-8" />
                
                <p className="font-sans text-sm sm:text-base text-[#4B3527] leading-relaxed mb-6 font-light">
                  Where the refined heritage of British public house culture meets the electric, tireless energy of Manhattan, New York. Situated on a iconic corner building, we are a true 24-hour sanctuary for culinary enthusiasts, cocktail aficionados, and lovers of classic hospitality.
                </p>
                <p className="font-sans text-sm sm:text-base text-[#4B3527] leading-relaxed mb-8 font-light">
                  Our pub is designed as a home away from home. Whether you seek a pristine Full English Breakfast at dawn, a leisurely Sunday Roast with towering Yorkies, an exquisite tableside smoked Manhattan, or a lively conversation over a cask stout at 4:00 AM—our doors are forever open, and our hearth is forever warm.
                </p>
              </div>

              <div>
                <button
                  onClick={() => {
                    setView('about');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-10 py-4 border border-[#B68C45] text-[#101010] hover:bg-[#B68C45] hover:text-[#F6F3ED] uppercase tracking-[0.2em] text-[11px] font-bold transition-all duration-300 cursor-pointer"
                >
                  Our Full Story
                </button>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
