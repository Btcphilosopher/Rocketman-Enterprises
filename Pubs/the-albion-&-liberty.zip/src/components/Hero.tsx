import React from 'react';
import { ArrowRight, ChevronDown } from 'lucide-react';
import { IMAGES } from '../data';
import { ViewState } from '../types';

interface HeroProps {
  setView: (view: ViewState) => void;
}

export default function Hero({ setView }: HeroProps) {
  const handleScrollToWelcome = () => {
    const welcomeSec = document.getElementById('welcome-section');
    if (welcomeSec) {
      welcomeSec.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero-section"
      className="relative h-screen flex items-center justify-center overflow-hidden bg-[#101010]"
    >
      {/* Background Image Container */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.pubExterior}
          alt="The Albion & Liberty Exterior at Dusk"
          className="w-full h-full object-cover object-center filter brightness-[0.35] scale-105 animate-[zoomOut_10s_ease-out_forwards]"
          referrerPolicy="no-referrer"
        />
        {/* Cinematic atmospheric overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#101010] via-transparent to-[#101010]/70" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#101010]/80 via-transparent to-[#101010]/80" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 text-center mt-12 flex flex-col items-center">
        {/* Editorial Eyebrow */}
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="h-[1px] w-12 bg-[#B68C45]"></div>
          <span className="text-[#B68C45] text-xs uppercase tracking-[0.4em] font-semibold">
            EST. 2026 • MANHATTAN, NY
          </span>
          <div className="h-[1px] w-12 bg-[#B68C45]"></div>
        </div>

        {/* Headline */}
        <h1 
          id="hero-headline"
          className="font-serif text-5xl md:text-8xl text-[#F6F3ED] leading-[0.9] tracking-tight mb-8"
        >
          A British Tradition.<br />
          <span className="italic opacity-80 text-[#E8E1D5]">An American Spirit.</span>
        </h1>

        {/* Subtitle */}
        <p 
          id="hero-subheading"
          className="font-sans text-base md:text-lg text-[#E8E1D5]/80 max-w-2xl mx-auto leading-relaxed mb-10 font-light"
        >
          The Albion & Liberty is New York's premier 24-hour British-American gastro pub, serving elevated dining, craft cocktails, and warm hospitality around the clock.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
          <button
            onClick={() => setView('reservations')}
            className="px-10 py-4 bg-[#B68C45] text-[#101010] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#E8E1D5] transition-all cursor-pointer"
          >
            Reserve a Table
          </button>
          
          <button
            onClick={() => setView('menus')}
            className="px-10 py-4 border border-[#B68C45] text-[#B68C45] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#B68C45] hover:text-[#101010] transition-all cursor-pointer"
          >
            Explore Menus
          </button>
        </div>
      </div>

      {/* Subtle Scroll Indicator */}
      <div 
        onClick={handleScrollToWelcome}
        className="absolute bottom-8 flex flex-col items-center opacity-40 cursor-pointer group"
      >
        <span className="font-sans text-[9px] uppercase tracking-[0.3em] mb-2 text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors">
          Scroll
        </span>
        <div className="h-12 w-[1px] bg-gradient-to-b from-[#F6F3ED] to-transparent"></div>
      </div>
    </section>
  );
}
