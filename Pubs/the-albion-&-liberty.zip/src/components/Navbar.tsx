import React, { useState, useEffect } from 'react';
import { Menu, X, Crown, Calendar } from 'lucide-react';
import { ViewState } from '../types';

interface NavbarProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
}

export default function Navbar({ currentView, setView }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'HOME', view: 'home' as ViewState },
    { label: 'ABOUT', view: 'about' as ViewState },
    { label: 'MENUS', view: 'menus' as ViewState },
    { label: 'DRINKS', view: 'drinks' as ViewState },
    { label: 'LIVE', view: 'live' as ViewState },
    { label: 'PRIVATE EVENTS', view: 'private' as ViewState },
    { label: 'GALLERY', view: 'gallery' as ViewState },
    { label: 'FIND US', view: 'contact' as ViewState }, // Contact page displays map & info
  ];

  const handleNavClick = (view: ViewState) => {
    setView(view);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-[#101010]/95 backdrop-blur-md border-b border-[#F6F3ED]/10 py-4 shadow-xl' 
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          
          {/* Logo */}
          <div 
            id="nav-logo"
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => handleNavClick('home')}
          >
            <div className="text-[#B68C45] transition-transform duration-500 group-hover:rotate-12">
              <Crown className="w-8 h-8 stroke-[1.2]" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-2xl tracking-[0.2em] uppercase text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300" style={{ fontFamily: 'Georgia, serif' }}>
                The Albion
              </span>
              <span className="text-[10px] tracking-[0.4em] uppercase opacity-60 mt-[-4px] text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300">
                & Liberty
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.view)}
                className={`font-sans text-xs tracking-[0.2em] transition-all duration-300 relative py-1 cursor-pointer ${
                  currentView === item.view
                    ? 'text-[#B68C45] font-semibold'
                    : 'text-[#E8E1D5] hover:text-[#B68C45]'
                }`}
              >
                {item.label}
                {currentView === item.view && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1px] bg-[#B68C45]" />
                )}
              </button>
            ))}
          </nav>

          {/* Reserve CTA */}
          <div className="hidden lg:block">
            <button
              id="desktop-reserve-btn"
              onClick={() => handleNavClick('reservations')}
              className="px-8 py-3 bg-[#B68C45] text-[#101010] text-[11px] uppercase tracking-[0.2em] font-bold hover:bg-[#E8E1D5] transition-all cursor-pointer"
            >
              Reserve
            </button>
          </div>

          {/* Mobile Menu Trigger */}
          <div className="flex items-center space-x-4 lg:hidden">
            {/* Minimal Mobile Reserve Button next to menu */}
            <button
              onClick={() => handleNavClick('reservations')}
              className="bg-[#B68C45] text-[#101010] p-2 rounded-full cursor-pointer hover:bg-[#e5bd73] transition-colors duration-300"
              title="Reserve"
            >
              <Calendar className="w-4 h-4" />
            </button>
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-[#F6F3ED] hover:text-[#B68C45] focus:outline-none cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Drawer */}
      <div
        id="mobile-nav-drawer"
        className={`fixed inset-0 top-[73px] bg-[#101010]/98 z-40 lg:hidden border-t border-[#B68C45]/20 transition-all duration-500 ease-in-out transform ${
          mobileMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'
        }`}
      >
        <div className="px-6 py-8 flex flex-col space-y-6 h-full justify-between">
          <div className="flex flex-col space-y-5">
            {navItems.map((item, index) => (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.view)}
                style={{ transitionDelay: `${index * 50}ms` }}
                className={`text-left font-serif text-2xl tracking-wider py-2 transition-all duration-300 ${
                  currentView === item.view ? 'text-[#B68C45] translate-x-2' : 'text-[#E8E1D5]'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pb-12">
            <button
              onClick={() => handleNavClick('reservations')}
              className="w-full text-center bg-[#B68C45] text-[#101010] font-sans text-sm font-semibold tracking-widest py-4 border border-[#B68C45] uppercase transition-all duration-300"
            >
              Reserve a Table
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
