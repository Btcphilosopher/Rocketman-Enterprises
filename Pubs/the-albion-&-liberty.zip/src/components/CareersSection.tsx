import React, { useState } from 'react';
import { CAREER_JOBS } from '../data';
import { Briefcase, MapPin, DollarSign, Clock, ChevronDown, ChevronUp, Upload, Check } from 'lucide-react';

export default function CareersSection() {
  const [expandedJobId, setExpandedJobId] = useState<string | null>(null);
  const [submittedApp, setSubmittedApp] = useState(false);
  const [fileName, setFileName] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    coverLetter: '',
  });

  const handleToggleExpand = (id: string) => {
    setExpandedJobId(expandedJobId === id ? null : id);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileName(e.target.files[0].name);
    }
  };

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone || !fileName) {
      return;
    }
    setSubmittedApp(true);
  };

  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200"
            alt="Careers Banner"
            className="w-full h-full object-cover filter brightness-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            JOIN THE HOSPITALITY LEGEND
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            CAREERS
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        {/* Intro */}
        <div className="text-center max-w-xl mx-auto mb-16">
          <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed font-light">
            We are always seeking passionate, refined hospitality professionals to represent our brand around the clock. If you possess a rigorous commitment to culinary craft and warm hospitality, explore our open suites.
          </p>
        </div>

        {/* Jobs list */}
        <div className="space-y-6">
          {CAREER_JOBS.map((job) => {
            const isExpanded = expandedJobId === job.id;

            return (
              <div
                key={job.id}
                className="border border-[#B68C45]/15 bg-[#101010] rounded-none shadow-xl overflow-hidden transition-all duration-300"
              >
                
                {/* Header click bar */}
                <div
                  onClick={() => handleToggleExpand(job.id)}
                  className="p-6 cursor-pointer flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 hover:bg-[#183A2B]/10 transition-colors"
                >
                  <div className="space-y-2">
                    <div className="flex items-center space-x-3">
                      <span className="text-[9px] font-sans tracking-widest text-[#B68C45] uppercase border border-[#B68C45]/35 px-2.5 py-1 rounded-none">
                        {job.department}
                      </span>
                      <span className="text-[10px] font-sans text-[#E8E1D5]/60 flex items-center">
                        <Clock className="w-3.5 h-3.5 mr-1" />
                        {job.type}
                      </span>
                    </div>

                    <h3 className="font-serif text-xl sm:text-2xl text-[#F6F3ED] tracking-wide font-medium" style={{ fontFamily: 'Georgia, serif' }}>
                      {job.title}
                    </h3>

                    {/* Meta specifics */}
                    <div className="flex flex-wrap gap-4 text-xs font-sans text-[#E8E1D5]/70">
                      <span className="flex items-center">
                        <MapPin className="w-4 h-4 text-[#B68C45] mr-1" />
                        Manhattan, NY
                      </span>
                      <span className="flex items-center">
                        <DollarSign className="w-4 h-4 text-[#B68C45] mr-0.5" />
                        {job.salary}
                      </span>
                    </div>
                  </div>

                  <button className="text-[#B68C45] p-2 hover:text-[#E8E1D5] focus:outline-none shrink-0 self-end sm:self-center">
                    {isExpanded ? <ChevronUp className="w-6 h-6" /> : <ChevronDown className="w-6 h-6" />}
                  </button>
                </div>

                {/* Expanded Details section */}
                {isExpanded && (
                  <div className="p-6 sm:p-8 bg-[#101010]/80 border-t border-[#B68C45]/15 space-y-8 animate-[fadeIn_0.4s_ease]">
                    
                    <div className="space-y-2">
                      <h4 className="font-serif text-lg text-[#B68C45] uppercase tracking-wider" style={{ fontFamily: 'Georgia, serif' }}>
                        ROLE DESCRIPTION
                      </h4>
                      <p className="font-sans text-xs sm:text-sm text-[#E8E1D5]/90 leading-relaxed font-light">
                        {job.description}
                      </p>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-serif text-lg text-[#B68C45] uppercase tracking-wider" style={{ fontFamily: 'Georgia, serif' }}>
                        QUALIFICATIONS & REQUIREMENTS
                      </h4>
                      <ul className="space-y-2 font-sans text-xs sm:text-sm text-[#E8E1D5]/80 font-light list-disc pl-5">
                        {job.requirements.map((req, idx) => (
                          <li key={idx} className="leading-relaxed">
                            {req}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Quick application Form inside expanded container */}
                    <div className="pt-8 border-t border-[#B68C45]/10 space-y-6">
                      <div className="flex items-center space-x-3">
                        <Briefcase className="w-5 h-5 text-[#B68C45]" />
                        <h4 className="font-serif text-lg text-[#F6F3ED] uppercase tracking-wider" style={{ fontFamily: 'Georgia, serif' }}>
                          APPLY FOR THIS ROLE
                        </h4>
                      </div>

                      {submittedApp ? (
                        <div className="text-center py-8 space-y-4">
                          <span className="w-10 h-10 rounded-none border border-[#B68C45] flex items-center justify-center text-[#B68C45] mx-auto bg-[#B68C45]/10">✓</span>
                          <h5 className="font-serif text-xl text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>Application Dispatched</h5>
                          <p className="font-sans text-xs text-[#E8E1D5]/85 max-w-xs mx-auto">
                            Thank you. Our Talent Director has received your application and CV file. If a match is verified, we will reach out within 48 hours for an interview slot.
                          </p>
                          <button
                            onClick={() => {
                              setSubmittedApp(false);
                              setFileName('');
                            }}
                            className="cursor-pointer border border-[#B68C45] text-[#B68C45] hover:bg-[#B68C45] hover:text-[#101010] px-4 py-1.5 font-sans text-[10px] uppercase transition-colors rounded-none"
                          >
                            Close Form
                          </button>
                        </div>
                      ) : (
                        <form onSubmit={handleApplySubmit} className="space-y-4 max-w-2xl">
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div>
                              <input
                                type="text"
                                required
                                placeholder="Your Name"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-xs text-[#F6F3ED] outline-none"
                              />
                            </div>
                            <div>
                              <input
                                type="email"
                                required
                                placeholder="Email Address"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-xs text-[#F6F3ED] outline-none"
                              />
                            </div>
                            <div>
                              <input
                                type="tel"
                                required
                                placeholder="Phone Number"
                                value={formData.phone}
                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                                className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-xs text-[#F6F3ED] outline-none"
                              />
                            </div>
                          </div>

                          <div>
                            <textarea
                              rows={2}
                              placeholder="Describe your hospitality background shortly..."
                              value={formData.coverLetter}
                              onChange={(e) => setFormData({ ...formData, coverLetter: e.target.value })}
                              className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-xs text-[#F6F3ED] outline-none"
                            />
                          </div>

                          {/* Interactive File Upload Container */}
                          <div className="border border-dashed border-[#B68C45]/30 hover:border-[#B68C45] bg-[#101010]/90 rounded-none p-5 text-center cursor-pointer transition-all relative">
                            <input
                              type="file"
                              accept=".pdf,.doc,.docx"
                              required
                              onChange={handleFileUpload}
                              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                            />
                            {fileName ? (
                              <div className="flex items-center justify-center space-x-2 text-[#B68C45]">
                                <Check className="w-4 h-4" />
                                <span className="font-sans text-xs truncate max-w-xs">{fileName} Uploaded</span>
                              </div>
                            ) : (
                              <div className="space-y-1">
                                <Upload className="w-6 h-6 text-[#B68C45] mx-auto mb-1" />
                                <p className="font-sans text-xs text-[#E8E1D5]">
                                  Click or drag your CV / Resume here (PDF, DOCX) *
                                </p>
                                <p className="font-sans text-[10px] text-[#E8E1D5]/40 uppercase tracking-widest">
                                  maximum file size: 5MB
                                </p>
                              </div>
                            )}
                          </div>

                          <button
                            type="submit"
                            className="w-full bg-[#B68C45] text-[#101010] hover:bg-[#e5bd73] font-sans text-xs font-semibold tracking-widest py-3 uppercase transition-colors cursor-pointer rounded-none"
                          >
                            Submit Career Application
                          </button>
                        </form>
                      )}

                    </div>

                  </div>
                )}

              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
}
