import React, { useState } from 'react';
import { JOURNAL_POSTS } from '../data';
import { JournalPost } from '../types';
import { BookOpen, Calendar, ArrowLeft, ArrowRight } from 'lucide-react';

export default function JournalSection() {
  const [selectedPost, setSelectedPost] = useState<JournalPost | null>(null);

  const handleOpenPost = (post: JournalPost) => {
    setSelectedPost(post);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleClosePost = () => {
    setSelectedPost(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (selectedPost) {
    // 1. Reading view for a selected post
    return (
      <div className="pt-28 bg-[#101010] min-h-screen pb-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6">
          
          <button
            onClick={handleClosePost}
            className="group cursor-pointer mb-8 inline-flex items-center space-x-2 text-xs font-semibold tracking-widest text-[#B68C45] hover:text-[#E8E1D5] uppercase transition-colors"
          >
            <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1 transition-transform" />
            <span>Back to Journal</span>
          </button>

          <article className="space-y-6">
            <div className="space-y-3">
              <span className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase border border-[#B68C45]/20 bg-[#183A2B]/10 px-3 py-1 rounded-none">
                {selectedPost.category}
              </span>
              <h1 className="font-serif text-3xl sm:text-5xl text-[#F6F3ED] leading-tight pt-2 uppercase" style={{ fontFamily: 'Georgia, serif' }}>
                {selectedPost.title}
              </h1>
              <div className="flex items-center space-x-4 text-xs font-sans text-[#E8E1D5]/60">
                <span className="flex items-center">
                  <Calendar className="w-3.5 h-3.5 mr-1.5 text-[#B68C45]" />
                  {selectedPost.date}
                </span>
                <span>•</span>
                <span>{selectedPost.readTime}</span>
              </div>
            </div>

            <div className="h-[350px] sm:h-[450px] w-full rounded-none overflow-hidden border border-[#B68C45]/20 shadow-2xl">
              <img
                src={selectedPost.imageUrl}
                alt={selectedPost.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            <div className="prose prose-invert prose-gold max-w-none pt-6">
              <p className="font-serif text-lg text-[#E8E1D5] leading-relaxed italic mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                {selectedPost.excerpt}
              </p>
              
              <div className="w-full h-[1px] bg-gradient-to-r from-[#B68C45]/30 to-transparent my-6" />

              <p className="font-sans text-sm sm:text-base text-[#E8E1D5]/90 leading-relaxed font-light whitespace-pre-line">
                {selectedPost.content}
              </p>
              
              <p className="font-sans text-sm sm:text-base text-[#E8E1D5]/90 leading-relaxed font-light mt-4">
                Our Gastronomy team works weekly with local artisans to update dishes in accordance with seasonal micro-seasons. We believe food should tell a beautiful story of place, geography, and heritage. We invite you to sit at our tables, listen to live acoustics, and taste our classical pub recipes today.
              </p>
            </div>

            {/* Quote block inside article */}
            <div className="bg-[#183A2B]/10 border-l-4 border-[#B68C45] p-6 rounded-none my-10">
              <p className="font-serif text-base text-[#F6F3ED] italic leading-relaxed" style={{ fontFamily: 'Georgia, serif' }}>
                "We do not cut corners, and we do not compromise on time. Our stout conditioning requires a full 14 days of cellar resting before it ever reaches our taps. This is our promise."
              </p>
              <span className="font-sans text-[10px] text-[#B68C45] uppercase tracking-wider font-semibold mt-2 block">
                — Cellar Master, The Albion & Liberty
              </span>
            </div>

          </article>

        </div>
      </div>
    );
  }

  // 2. Default Magazine Grid View
  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=1200"
            alt="Journal Banner"
            className="w-full h-full object-cover filter brightness-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            THE ALBION CHRONICLES
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            GASTRONOMY JOURNAL
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        {/* Magazine Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {JOURNAL_POSTS.map((post) => (
            <div
              key={post.id}
              className="group flex flex-col bg-[#101010] border border-[#B68C45]/20 hover:border-[#B68C45]/50 transition-all duration-400 rounded-none overflow-hidden shadow-xl"
            >
              {/* Image with hover zoom */}
              <div className="img-zoom-container h-56 relative border-b border-[#B68C45]/10">
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4">
                  <span className="text-[9px] font-sans tracking-widest text-[#B68C45] uppercase bg-[#101010] px-3 py-1.5 rounded-none border border-[#B68C45]/35 font-bold">
                    {post.category}
                  </span>
                </div>
              </div>

              {/* Text Area */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center text-[10px] font-sans text-[#E8E1D5]/60 mb-2">
                    <span>{post.date}</span>
                    <span className="mx-2">•</span>
                    <span>{post.readTime}</span>
                  </div>

                  <h3 className="font-serif text-xl sm:text-2xl text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300 uppercase leading-tight mb-3" style={{ fontFamily: 'Georgia, serif' }}>
                    {post.title}
                  </h3>

                  <p className="font-sans text-xs text-[#E8E1D5]/75 leading-relaxed font-light mb-6">
                    {post.excerpt}
                  </p>
                </div>

                <button
                  onClick={() => handleOpenPost(post)}
                  className="group/btn cursor-pointer font-sans text-[10px] tracking-widest text-[#B68C45] hover:text-[#E8E1D5] uppercase font-bold text-left flex items-center space-x-1 border-t border-[#B68C45]/10 pt-4"
                >
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Footer info sign */}
        <div className="mt-20 border-t border-[#B68C45]/20 pt-10 text-center max-w-md mx-auto">
          <BookOpen className="w-8 h-8 text-[#B68C45] mx-auto mb-3" />
          <h4 className="font-serif text-lg text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>The Gastronomy Press</h4>
          <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed mt-2 font-light">
            We regularly publish insights into cellar conditioning, recipe curation, and private events. Follow our updates and sign up for our newsletter to receive print-copies in mail.
          </p>
        </div>

      </div>

    </div>
  );
}
