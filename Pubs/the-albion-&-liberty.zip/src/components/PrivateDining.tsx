import React, { useState } from 'react';
import { IMAGES } from '../data';
import { ViewState } from '../types';
import { Users, Shield, Award, Calendar, ChevronRight } from 'lucide-react';

interface PrivateDiningProps {
  setView: (view: ViewState) => void;
  isFullPage?: boolean;
}

export default function PrivateDining({ setView, isFullPage = false }: PrivateDiningProps) {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    suite: 'wellington',
    guests: '12',
    eventType: 'corporate',
    notes: '',
  });

  const suites = [
    {
      id: 'wellington',
      name: 'THE WELLINGTON SUITE',
      capacity: 'Up to 18 Seated • 30 Reception',
      theme: 'Traditional British Mahogany & Open Fireplace',
      desc: 'Our flagship private room features gorgeous dark mahogany wood paneling, an authentic hand-carved brick fireplace, tufted leather chairs, and a private copper bar with a dedicated bartender.',
      image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=600',
    },
    {
      id: 'roosevelt',
      name: 'THE ROOSEVELT ROOM',
      capacity: 'Up to 12 Seated • 15 Reception',
      theme: 'Manhattan Marble & Modern AV Media',
      desc: 'Combining sleek New York sophistication with business readiness. Features a majestic solid Calacatta marble conference dining table, leather executive chairs, a hidden 4K presentation screen, and soundproofing.',
      image: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&q=80&w=600',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.phone || !formData.date) {
      return;
    }
    setSubmitted(true);
  };

  if (!isFullPage) {
    // Landing Page Callout Card
    return (
      <section
        id="landing-private-dining"
        className="relative bg-[#101010] py-20 lg:py-24 border-b border-[#F6F3ED]/10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#101010] border border-[#B68C45]/20 rounded-none overflow-hidden shadow-2xl">
            <div className="grid grid-cols-1 lg:grid-cols-12">
              
              {/* Image side */}
              <div className="lg:col-span-6 relative h-[300px] lg:h-auto min-h-[350px]">
                <img
                  src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200"
                  alt="Wellington Private Suite"
                  className="w-full h-full object-cover animate-[zoomOut_10s_ease-out_forwards]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-transparent to-[#101010]/90 hidden lg:block" />
                <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent lg:hidden" />
              </div>

              {/* Text side */}
              <div className="lg:col-span-6 p-8 sm:p-12 lg:p-16 flex flex-col justify-center">
                <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
                  EXCLUSIVE ROOMS
                </p>
                <h2 className="font-serif text-3xl sm:text-4xl text-[#F6F3ED] uppercase tracking-wider mb-4" style={{ fontFamily: 'Georgia, serif' }}>
                  PRIVATE DINING & CELEBRATIONS
                </h2>
                <p className="font-sans text-xs text-[#B68C45] tracking-widest uppercase mb-6">
                  Classic Spaces • Bespoke Banquet curation
                </p>
                <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed mb-8 font-light">
                  Host your next corporate dinner, milestone birthday, or warm family gathering in our highly exclusive private suites. Complete with custom-poured tastings, premium tasting menus, and impeccable white-glove pub service.
                </p>

                <div className="flex space-x-6">
                  <button
                    onClick={() => {
                      setView('private');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="px-10 py-4 border border-[#B68C45] text-[#B68C45] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#B68C45] hover:text-[#101010] transition-all cursor-pointer"
                  >
                    Explore Suites
                  </button>
                </div>
              </div>

            </div>
          </div>
        </div>
      </section>
    );
  }

  // Full Page sub-view
  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200"
            alt="Private Dining Banner"
            className="w-full h-full object-cover filter brightness-[0.25]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            BESPOKE BESPONSIBILITIES
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            PRIVATE SUITES
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        {/* Sub-header grid intro */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed font-light">
            Our private dining spaces combine quiet, exclusive isolation with the bustling hospitality of our main pub. We handle details meticulously, tailoring dining packages, pairings, and floral decor to your unique specifications.
          </p>
        </div>

        {/* Suites list */}
        <div className="space-y-16 mb-24">
          {suites.map((suite, index) => (
            <div
              key={suite.id}
              className={`grid grid-cols-1 lg:grid-cols-12 gap-10 items-center p-8 border border-[#B68C45]/20 bg-[#101010] rounded-none shadow-xl ${
                index % 2 === 1 ? 'lg:flex-row-reverse' : ''
              }`}
            >
              {/* Photo */}
              <div className={`lg:col-span-6 relative h-[350px] overflow-hidden rounded-none border border-[#B68C45]/20 ${
                index % 2 === 1 ? 'lg:order-last' : ''
              }`}>
                <img
                  src={suite.image}
                  alt={suite.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Specifications and Description */}
              <div className="lg:col-span-6 space-y-4">
                <span className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase border border-[#B68C45]/30 px-3 py-1 rounded-none bg-[#183A2B]/10">
                  {suite.capacity}
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#F6F3ED] tracking-wide mt-2 uppercase" style={{ fontFamily: 'Georgia, serif' }}>
                  {suite.name}
                </h3>
                <p className="font-sans text-xs italic text-[#B68C45]">
                  {suite.theme}
                </p>
                <div className="w-12 h-[1px] bg-[#B68C45] my-2" />
                <p className="font-sans text-sm text-[#E8E1D5]/95 leading-relaxed font-light">
                  {suite.desc}
                </p>
                
                <div className="grid grid-cols-3 gap-4 pt-4 text-center">
                  <div className="p-3 bg-[#101010] border border-[#B68C45]/20 rounded-none">
                    <Users className="w-4 h-4 text-[#B68C45] mx-auto mb-1" />
                    <span className="font-sans text-[10px] text-[#E8E1D5] block uppercase">Bespoke Menu</span>
                  </div>
                  <div className="p-3 bg-[#101010] border border-[#B68C45]/20 rounded-none">
                    <Shield className="w-4 h-4 text-[#B68C45] mx-auto mb-1" />
                    <span className="font-sans text-[10px] text-[#E8E1D5] block uppercase">Private Bar</span>
                  </div>
                  <div className="p-3 bg-[#101010] border border-[#B68C45]/20 rounded-none">
                    <Award className="w-4 h-4 text-[#B68C45] mx-auto mb-1" />
                    <span className="font-sans text-[10px] text-[#E8E1D5] block uppercase">Dedicated AV</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Split Section: Private Event Reservation Inquiry Form */}
        <div className="border border-[#B68C45]/20 bg-[#101010] rounded-none overflow-hidden shadow-2xl max-w-4xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-12">
            
            <div className="md:col-span-5 bg-[#183A2B]/10 p-8 sm:p-12 flex flex-col justify-between border-r border-[#B68C45]/20">
              <div>
                <span className="font-sans text-[10px] tracking-widest text-[#B68C45] uppercase font-bold">
                  PLAN YOUR SOIRÉE
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl text-[#F6F3ED] mt-3 uppercase leading-tight" style={{ fontFamily: 'Georgia, serif' }}>
                  INQUIRE ABOUT A PRIVATE EVENT
                </h3>
                <div className="w-12 h-[1px] bg-[#B68C45] my-6" />
                <p className="font-sans text-xs text-[#E8E1D5]/80 leading-relaxed mb-6 font-light">
                  Simply fill out this inquiry form, and our Director of Events will contact you within 12 hours with room availabilities, plating proposals, and customized drink pricing.
                </p>
              </div>

              <div className="text-[#B68C45] text-xs font-sans tracking-widest flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>RESPONSE GUARANTEE</span>
              </div>
            </div>

            <div className="md:col-span-7 p-8 sm:p-12">
              {submitted ? (
                <div className="text-center py-12 space-y-4">
                  <div className="w-12 h-12 rounded-full border border-[#B68C45] flex items-center justify-center mx-auto text-[#B68C45]">
                    ✓
                  </div>
                  <h4 className="font-serif text-2xl text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>Inquiry Received</h4>
                  <p className="font-sans text-xs text-[#E8E1D5]/80 max-w-xs mx-auto">
                    Thank you. Our Events Director is preparing options for you. A brochure has been dispatched to {formData.email}.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="px-6 py-2.5 border border-[#B68C45] text-[#B68C45] hover:bg-[#B68C45] hover:text-[#101010] font-sans text-[10px] font-semibold tracking-widest transition-all duration-300 uppercase mt-4 cursor-pointer rounded-none"
                  >
                    Submit Another Inquiry
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Your Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none transition-colors"
                        placeholder="e.g. Sterling Archer"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none transition-colors"
                        placeholder="sterling@agency.com"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none transition-colors"
                        placeholder="(212) 555-0199"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Preferred Date *
                      </label>
                      <input
                        type="date"
                        required
                        value={formData.date}
                        onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none transition-colors"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Select Suite
                      </label>
                      <select
                        value={formData.suite}
                        onChange={(e) => setFormData({ ...formData, suite: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-xs text-[#F6F3ED] outline-none"
                      >
                        <option value="wellington">Wellington Suite</option>
                        <option value="roosevelt">Roosevelt Room</option>
                        <option value="all">Full Venue Takeover</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Guest Count
                      </label>
                      <input
                        type="number"
                        min="5"
                        max="150"
                        value={formData.guests}
                        onChange={(e) => setFormData({ ...formData, guests: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                        Event Type
                      </label>
                      <select
                        value={formData.eventType}
                        onChange={(e) => setFormData({ ...formData, eventType: e.target.value })}
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-xs text-[#F6F3ED] outline-none"
                      >
                        <option value="corporate">Corporate Gala</option>
                        <option value="birthday">Milestone Celebration</option>
                        <option value="tasting">Private Wine/Spirit Tasting</option>
                        <option value="wedding">Micro-Wedding / Dinner</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                      Bespoke Requests or Notes
                    </label>
                    <textarea
                      rows={3}
                      value={formData.notes}
                      onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none transition-colors"
                      placeholder="e.g. Dietary preferences, whiskey tastings, custom decorations..."
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full px-10 py-4 bg-[#B68C45] text-[#101010] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#E8E1D5] transition-all cursor-pointer rounded-none"
                  >
                    Submit Event Proposal Inquiry
                  </button>
                </form>
              )}
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
