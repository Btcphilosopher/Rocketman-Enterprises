import React, { useState } from 'react';
import { Gift, Sparkles, CreditCard, Mail, Info } from 'lucide-react';

export default function GiftCardsSection() {
  const [amount, setAmount] = useState('100');
  const [customAmount, setCustomAmount] = useState('');
  const [senderName, setSenderName] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [recipientEmail, setRecipientEmail] = useState('');
  const [message, setMessage] = useState('');
  const [design, setDesign] = useState<'classic' | 'luxury-gold' | 'midnight'>('luxury-gold');
  const [submitted, setSubmitted] = useState(false);

  const predefinedAmounts = ['50', '100', '200', '500'];

  const handlePurchase = (e: React.FormEvent) => {
    e.preventDefault();
    if (!senderName || !recipientName || !recipientEmail) {
      return;
    }
    setSubmitted(true);
  };

  const currentAmount = amount === 'custom' ? (customAmount || '0') : amount;
  const serialCode = `GC-AL-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;

  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1200"
            alt="Gift Cards Banner"
            className="w-full h-full object-cover filter brightness-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            GIFT OF LUXURY HOSPITALITY
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            GIFT CARDS
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        {/* Intro */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed font-light">
            Gift an exceptional dining experience. Our customizable digital and physical gift vouchers are accepted for all gastronomy menus, fine wines, rare reserve spirits, and event bookings.
          </p>
        </div>

        {/* Dynamic Split Layout: Form on Left, Live interactive preview on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start max-w-5xl mx-auto">
          
          {/* Form Side (lg:col-span-6) */}
          <div className="lg:col-span-6 border border-[#B68C45]/20 bg-[#101010] p-6 sm:p-8 rounded-none shadow-2xl">
            {submitted ? (
              <div className="text-center py-10 space-y-6">
                <div className="w-12 h-12 rounded-none border border-[#B68C45] flex items-center justify-center text-[#B68C45] mx-auto bg-[#B68C45]/10">
                  ✓
                </div>
                <h3 className="font-serif text-2xl text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>Voucher Dispatched!</h3>
                <p className="font-sans text-xs text-[#E8E1D5]/80 max-w-xs mx-auto">
                  Success. An elegant digital voucher containing your message, worth <strong>${currentAmount}</strong>, has been sent to <strong>{recipientEmail}</strong>.
                </p>
                
                <div className="border border-[#B68C45]/20 bg-[#101010] p-4 rounded-none text-left font-sans text-xs text-[#E8E1D5] space-y-1">
                  <p><strong>Receipt Number:</strong> {serialCode}</p>
                  <p><strong>From:</strong> {senderName}</p>
                  <p><strong>To:</strong> {recipientName}</p>
                  <p><strong>Amount:</strong> ${currentAmount}.00</p>
                </div>

                <button
                  onClick={() => {
                    setSubmitted(false);
                    setSenderName('');
                    setRecipientName('');
                    setRecipientEmail('');
                    setMessage('');
                  }}
                  className="px-6 py-3 border border-[#B68C45] text-[#B68C45] hover:bg-[#B68C45] hover:text-[#101010] font-sans text-[11px] tracking-widest uppercase transition-colors font-bold cursor-pointer rounded-none"
                >
                  Buy Another Card
                </button>
              </div>
            ) : (
              <form onSubmit={handlePurchase} className="space-y-6">
                
                {/* Select Amount */}
                <div className="space-y-3">
                  <span className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold">
                    Select Amount
                  </span>
                  <div className="grid grid-cols-5 gap-2">
                    {predefinedAmounts.map((amt) => (
                      <button
                        type="button"
                        key={amt}
                        onClick={() => {
                          setAmount(amt);
                          setCustomAmount('');
                        }}
                        className={`py-2 rounded-none font-sans text-xs font-semibold cursor-pointer border transition-colors ${
                          amount === amt
                            ? 'bg-[#B68C45] text-[#101010] border-[#B68C45]'
                            : 'bg-[#101010] text-[#E8E1D5] border-[#B68C45]/15 hover:border-[#B68C45]/40'
                        }`}
                      >
                        ${amt}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setAmount('custom')}
                      className={`py-2 rounded-none font-sans text-xs font-semibold cursor-pointer border transition-colors ${
                        amount === 'custom'
                          ? 'bg-[#B68C45] text-[#101010] border-[#B68C45]'
                          : 'bg-[#101010] text-[#E8E1D5] border-[#B68C45]/15 hover:border-[#B68C45]/40'
                      }`}
                    >
                      Other
                    </button>
                  </div>

                  {amount === 'custom' && (
                    <input
                      type="number"
                      required
                      min="10"
                      max="2000"
                      placeholder="Enter custom USD amount (e.g. 150)"
                      value={customAmount}
                      onChange={(e) => setCustomAmount(e.target.value)}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  )}
                </div>

                {/* Theme Selector */}
                <div className="space-y-3">
                  <span className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold">
                    Design Theme Preferred
                  </span>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { id: 'luxury-gold', label: 'Warm Brass' },
                      { id: 'midnight', label: 'Charcoal Black' },
                      { id: 'classic', label: 'British Green' },
                    ].map((d) => (
                      <button
                        type="button"
                        key={d.id}
                        onClick={() => setDesign(d.id as any)}
                        className={`py-2 text-[10px] tracking-widest uppercase rounded-none cursor-pointer border transition-all duration-300 ${
                          design === d.id
                            ? 'border-[#B68C45] bg-[#B68C45]/10 text-[#B68C45]'
                            : 'border-[#B68C45]/10 bg-[#101010] text-[#E8E1D5]/70'
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sender Recipient Names */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="From..."
                      value={senderName}
                      onChange={(e) => setSenderName(e.target.value)}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                      Recipient Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="For..."
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                    Recipient Email *
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="Where to dispatch voucher..."
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                    className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1.5 font-semibold">
                    Personal Greeting Notes
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Write a custom, elegant message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full px-10 py-4 bg-[#B68C45] text-[#101010] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#E8E1D5] transition-all cursor-pointer rounded-none"
                >
                  Confirm Card Purchase
                </button>

              </form>
            )}
          </div>

          {/* Interactive Preview Side (lg:col-span-6) */}
          <div className="lg:col-span-6 flex flex-col justify-center sticky top-[150px]">
            <span className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-bold mb-4 block text-center lg:text-left">
              LIVE GIFT VOUCHER PREVIEW
            </span>
            
            {/* Elegant physical card styled layout */}
            <div 
              className={`w-full h-64 rounded-none border p-8 flex flex-col justify-between shadow-2xl transition-all duration-500 relative overflow-hidden ${
                design === 'luxury-gold' 
                  ? 'bg-gradient-to-br from-[#4B3527] to-[#101010] border-[#B68C45]/50'
                  : design === 'midnight'
                    ? 'bg-[#101010] border-white/10'
                    : 'bg-gradient-to-br from-[#183A2B] to-[#101010] border-[#B68C45]/40'
              }`}
            >
              
              {/* Gold watermark crest background */}
              <div className="absolute -bottom-16 -right-16 w-48 h-48 border border-[#B68C45]/10 rounded-none flex items-center justify-center select-none pointer-events-none">
                <div className="w-32 h-32 border border-[#B68C45]/5 rounded-none" />
              </div>

              {/* Card Header */}
              <div className="flex justify-between items-start relative z-10">
                <div className="flex items-center space-x-2.5">
                  <div className="text-[#B68C45]">
                    <Gift className="w-6 h-6 stroke-[1.5]" />
                  </div>
                  <div className="flex flex-col">
                    <span className="font-serif text-[11px] tracking-[0.2em] text-[#F6F3ED] uppercase font-bold" style={{ fontFamily: 'Georgia, serif' }}>
                      THE ALBION & LIBERTY
                    </span>
                    <span className="font-sans text-[7px] tracking-widest text-[#B68C45] uppercase">
                      MANHATTAN, NY
                    </span>
                  </div>
                </div>

                <div className="text-[#B68C45] font-serif text-3xl font-light" style={{ fontFamily: 'Georgia, serif' }}>
                  ${currentAmount}
                </div>
              </div>

              {/* Card Body Message area */}
              <div className="relative z-10 space-y-1 my-4">
                {message ? (
                  <p className="font-sans text-[11px] text-[#E8E1D5]/90 italic leading-relaxed line-clamp-2">
                    "{message}"
                  </p>
                ) : (
                  <p className="font-sans text-[11px] text-[#E8E1D5]/40 italic leading-relaxed">
                    Write an elegant message to display here...
                  </p>
                )}
              </div>

              {/* Card Footer details */}
              <div className="flex justify-between items-end relative z-10 border-t border-[#B68C45]/10 pt-4 text-[10px] font-sans">
                <div>
                  <span className="text-[#B68C45] uppercase text-[7px] tracking-widest block mb-0.5">FOR</span>
                  <span className="text-[#F6F3ED] font-semibold">{recipientName || 'Recipient Name'}</span>
                </div>
                <div>
                  <span className="text-[#B68C45] uppercase text-[7px] tracking-widest block mb-0.5">FROM</span>
                  <span className="text-[#F6F3ED] font-semibold">{senderName || 'Sender Name'}</span>
                </div>
                <div className="text-right">
                  <span className="text-[#B68C45] uppercase text-[7px] tracking-widest block mb-0.5">CODE</span>
                  <span className="text-[#E8E1D5]/60 text-[8px] font-mono">{serialCode}</span>
                </div>
              </div>

            </div>

            <div className="mt-6 flex items-start space-x-3 text-left max-w-sm mx-auto lg:mx-0">
              <Info className="w-4 h-4 text-[#B68C45] shrink-0 mt-0.5" />
              <p className="font-sans text-[10px] text-[#E8E1D5]/60 leading-relaxed">
                Gift vouchers do not expire. They are delivered instantly to the recipient's inbox and can be added directly to standard Apple/Google Wallet apps.
              </p>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
}
