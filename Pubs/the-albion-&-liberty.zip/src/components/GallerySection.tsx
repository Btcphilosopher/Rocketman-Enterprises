import React, { useState } from 'react';
import { GALLERY_ITEMS } from '../data';
import { ViewState } from '../types';
import { ChevronLeft, ChevronRight, X, ZoomIn } from 'lucide-react';

interface GallerySectionProps {
  setView: (view: ViewState) => void;
  isFullPage?: boolean;
}

export default function GallerySection({ setView, isFullPage = false }: GallerySectionProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | 'interiors' | 'food' | 'drinks' | 'events'>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filteredItems = activeFilter === 'all'
    ? GALLERY_ITEMS
    : GALLERY_ITEMS.filter(item => item.category === activeFilter);

  const handleOpenLightbox = (index: number) => {
    setLightboxIndex(index);
  };

  const handleCloseLightbox = () => {
    setLightboxIndex(null);
  };

  const handlePrevImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (lightboxIndex === null) return;
    const nextIdx = lightboxIndex === 0 ? filteredItems.length - 1 : lightboxIndex - 1;
    setLightboxIndex(nextIdx);
  };

  const handleNextImage = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (lightboxIndex === null) return;
    const nextIdx = lightboxIndex === filteredItems.length - 1 ? 0 : lightboxIndex + 1;
    setLightboxIndex(nextIdx);
  };

  if (!isFullPage) {
    // 1. Landing Page Section (Step Inside)
    const previewItems = GALLERY_ITEMS.slice(0, 3);

    return (
      <section 
        id="landing-gallery-section"
        className="relative bg-[#101010] py-20 lg:py-24 border-b border-[#F6F3ED]/10 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-16">
            <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
              VISUAL INDULGENCE
            </p>
            <h2 className="font-serif text-3xl sm:text-5xl font-light text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
              STEP INSIDE
            </h2>
            <div className="w-16 h-[1.5px] bg-[#B68C45] mx-auto mt-4" />
          </div>

          {/* 3 Large Photos Horizontal Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {previewItems.map((item, index) => (
              <div
                key={item.id}
                onClick={() => {
                  setView('gallery');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="img-zoom-container cursor-pointer group relative h-80 rounded-none overflow-hidden border border-[#B68C45]/15 hover:border-[#B68C45]/50 shadow-2xl transition-all duration-500"
              >
                <img
                  src={item.url}
                  alt={item.caption}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                
                {/* Overlay on hover */}
                <div className="absolute inset-0 bg-[#101010]/80 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col items-center justify-center p-6 text-center">
                  <ZoomIn className="w-8 h-8 text-[#B68C45] mb-4 transform scale-75 group-hover:scale-100 transition-transform duration-500" />
                  <span className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase mb-1">
                    {item.category}
                  </span>
                  <p className="font-serif text-lg text-[#F6F3ED] tracking-wide max-w-xs" style={{ fontFamily: 'Georgia, serif' }}>
                    {item.caption}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={() => {
                setView('gallery');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-10 py-4 border border-[#B68C45] text-[#B68C45] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#B68C45] hover:text-[#101010] transition-all cursor-pointer inline-block"
            >
              View Full Gallery
            </button>
          </div>

        </div>
      </section>
    );
  }

  // 2. Full Page Detailed View Mode
  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=1200"
            alt="Gallery Banner"
            className="w-full h-full object-cover filter brightness-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            IMMERSIVE IMAGERY
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            BRAND GALLERY
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        {/* Filter categories */}
        <div className="flex flex-wrap gap-2 justify-center mb-16">
          {[
            { id: 'all', name: 'ALL IMAGES' },
            { id: 'interiors', name: 'LUXURY INTERIORS' },
            { id: 'food', name: 'ELEVATED PLATES' },
            { id: 'drinks', name: 'MOODY COCKTAILS' },
            { id: 'events', name: 'LIVE ATMOSPHERE' },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveFilter(item.id as any)}
              className={`font-sans text-[10px] tracking-widest px-5 py-2 border transition-all duration-300 cursor-pointer rounded-none ${
                activeFilter === item.id
                  ? 'bg-[#B68C45] text-[#101010] border-[#B68C45] font-semibold'
                  : 'text-[#E8E1D5] border-[#B68C45]/20 hover:border-[#B68C45] hover:text-[#B68C45]'
              }`}
            >
              {item.name}
            </button>
          ))}
        </div>

        {/* Masonry-style Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 [column-fill:_balance] box-border">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              onClick={() => handleOpenLightbox(index)}
              className="break-inside-avoid img-zoom-container relative mb-6 rounded-none overflow-hidden border border-[#B68C45]/15 hover:border-[#B68C45]/60 shadow-xl cursor-pointer group"
            >
              <img
                src={item.url}
                alt={item.caption}
                className="w-full object-cover"
                referrerPolicy="no-referrer"
              />
              
              {/* Fade-in overlay */}
              <div className="absolute inset-0 bg-[#101010]/80 opacity-0 group-hover:opacity-100 transition-opacity duration-400 flex flex-col justify-end p-6">
                <span className="text-[9px] font-sans tracking-widest text-[#B68C45] uppercase mb-1">
                  {item.category}
                </span>
                <p className="font-serif text-lg text-[#F6F3ED] leading-tight font-light" style={{ fontFamily: 'Georgia, serif' }}>
                  {item.caption}
                </p>
                <div className="mt-3 text-[#B68C45] text-xs font-sans tracking-widest flex items-center space-x-1">
                  <ZoomIn className="w-3.5 h-3.5" />
                  <span>EXPAND IMAGE</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {lightboxIndex !== null && (
        <div
          id="lightbox-modal"
          onClick={handleCloseLightbox}
          className="fixed inset-0 bg-black/95 z-[100] flex flex-col justify-center items-center p-4 cursor-zoom-out animate-[fadeIn_0.3s_ease]"
        >
          {/* Close Trigger */}
          <button
            onClick={handleCloseLightbox}
            className="absolute top-6 right-6 text-[#E8E1D5] hover:text-[#B68C45] cursor-pointer focus:outline-none"
          >
            <X className="w-8 h-8" />
          </button>

          {/* Left Arrow */}
          <button
            onClick={handlePrevImage}
            className="absolute left-6 text-[#E8E1D5] hover:text-[#B68C45] cursor-pointer focus:outline-none p-3 bg-black/40 rounded-none border border-white/10"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          {/* Right Arrow */}
          <button
            onClick={handleNextImage}
            className="absolute right-6 text-[#E8E1D5] hover:text-[#B68C45] cursor-pointer focus:outline-none p-3 bg-black/40 rounded-none border border-white/10"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

          {/* Image & Caption Box */}
          <div 
            onClick={(e) => e.stopPropagation()} 
            className="max-w-4xl max-h-[80vh] flex flex-col items-center bg-[#101010] border border-[#B68C45]/20 p-2 rounded-none shadow-2xl"
          >
            <img
              src={filteredItems[lightboxIndex].url}
              alt={filteredItems[lightboxIndex].caption}
              className="max-w-full max-h-[70vh] object-contain rounded-none"
              referrerPolicy="no-referrer"
            />
            <div className="py-4 text-center max-w-xl">
              <span className="text-[9px] font-sans tracking-[0.25em] text-[#B68C45] uppercase block mb-1">
                {filteredItems[lightboxIndex].category}
              </span>
              <p className="font-serif text-lg text-[#F6F3ED] font-light" style={{ fontFamily: 'Georgia, serif' }}>
                {filteredItems[lightboxIndex].caption}
              </p>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
