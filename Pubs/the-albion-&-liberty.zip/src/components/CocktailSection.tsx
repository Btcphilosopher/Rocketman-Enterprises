import React, { useState } from 'react';
import { IMAGES, DRINKS_MENU } from '../data';
import { ViewState } from '../types';
import { Award, Star, ShieldAlert } from 'lucide-react';

interface CocktailSectionProps {
  setView: (view: ViewState) => void;
  isFullPage?: boolean;
}

export default function CocktailSection({ setView, isFullPage = false }: CocktailSectionProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'cocktails' | 'beers' | 'wines' | 'spirits'>('all');

  const drinkHighlights = [
    {
      title: 'CRAFT COCKTAILS',
      desc: 'Tableside smoked cloches, custom botanicals, and hand-cut clear ice.',
      tag: 'Smoked & Shaken',
    },
    {
      title: 'BRITISH CASK ALES',
      desc: 'Traditional conditioned stouts and imported bitters weekly.',
      tag: 'Nitro & Handpump',
    },
    {
      title: 'WHISKEY CELLAR',
      desc: 'A collection of rare Speyside single malts and small-batch Kentucky bourbons.',
      tag: 'Reserve Collection',
    },
  ];

  const filteredDrinks = activeTab === 'all'
    ? DRINKS_MENU
    : DRINKS_MENU.filter(d => d.category === activeTab);

  if (!isFullPage) {
    // Landing Page Mode
    return (
      <section 
        id="landing-cocktails-section"
        className="relative bg-[#101010] py-20 lg:py-24 border-b border-[#F6F3ED]/10 overflow-hidden"
      >
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-[#B68C45]/3 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-[#183A2B]/5 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left Column: Copywriting & Actions */}
            <div className="lg:col-span-5">
              <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
                THE CELLAR & BAR
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light text-[#F6F3ED] uppercase tracking-wide leading-tight mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                MOODY SPIRITS & <br />
                <span className="italic opacity-80 text-[#E8E1D5]">CRAFT MIXOLOGY</span>
              </h2>
              <div className="w-16 h-[1.5px] bg-[#B68C45] mb-8" />
              
              <p className="font-sans text-sm sm:text-base text-[#E8E1D5]/80 leading-relaxed mb-8 font-light">
                Step inside our dimly lit cellar sanctuary. Handcrafted in dark marble, leather and warm brass, our bar pays homage to traditional London member clubs while introducing contemporary mixology that flares the senses. 
              </p>

              {/* Stack of features */}
              <div className="space-y-6 mb-10">
                {drinkHighlights.map((hl, idx) => (
                  <div key={idx} className="flex space-x-4 border-l-2 border-[#B68C45]/40 pl-4 py-1">
                    <div>
                      <h4 className="font-serif text-lg text-[#F6F3ED] tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>{hl.title}</h4>
                      <p className="font-sans text-xs text-[#E8E1D5]/70 mt-0.5">{hl.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  setView('drinks');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-10 py-4 border border-[#B68C45] text-[#B68C45] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#B68C45] hover:text-[#101010] transition-all cursor-pointer"
              >
                View Drinks Menu
              </button>
            </div>

            {/* Right Column: Visual Floating Cards */}
            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-6 relative">
              <div className="flex flex-col space-y-6">
                <div className="img-zoom-container relative h-80 rounded-none overflow-hidden shadow-2xl border border-[#B68C45]/20">
                  <img
                    src={IMAGES.pintOfAle}
                    alt="Pint of London Ale"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101010] via-transparent to-transparent opacity-80" />
                  <div className="absolute bottom-4 left-4">
                    <span className="text-[9px] font-sans tracking-widest bg-[#183A2B] text-[#F6F3ED] px-3 py-1 rounded-none uppercase">
                      nitro poured stouts
                    </span>
                  </div>
                </div>

                <div className="bg-[#101010] border border-[#B68C45]/20 p-8 rounded-none">
                  <h3 className="font-serif text-xl text-[#B68C45] mb-2 uppercase" style={{ fontFamily: 'Georgia, serif' }}>The Whiskey Vault</h3>
                  <p className="font-sans text-xs text-[#E8E1D5]/80 leading-relaxed">
                    Over 150 selected single malts, rare Japanese small batches, and hard-to-find pre-prohibition style Kentucky straight bourbons curated for the true connoisseur.
                  </p>
                </div>
              </div>

              <div className="flex flex-col space-y-6 sm:mt-12">
                <div className="bg-[#183A2B]/10 border border-[#B68C45]/20 p-8 rounded-none">
                  <h3 className="font-serif text-xl text-[#B68C45] mb-2 uppercase" style={{ fontFamily: 'Georgia, serif' }}>Tableside Smoke</h3>
                  <p className="font-sans text-xs text-[#E8E1D5]/80 leading-relaxed">
                    Enjoy classic Old Fashioneds and Manhattans smoked under elegant glass cloches using locally sourced cherry-wood and dried orange peels right at your booth.
                  </p>
                </div>

                <div className="img-zoom-container relative h-80 rounded-none overflow-hidden shadow-2xl border border-[#B68C45]/20">
                  <img
                    src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=600"
                    alt="Bartender Shaking Cocktail"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101010] via-transparent to-transparent opacity-80" />
                  <div className="absolute bottom-4 left-4">
                    <span className="text-[9px] font-sans tracking-widest bg-[#B68C45] text-[#101010] px-3 py-1 rounded-none uppercase font-bold">
                      Bespoke Mixology
                    </span>
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      </section>
    );
  }

  // Full Page Sub-View Mode
  return (
    <div className="pt-28 bg-[#101010] min-h-screen">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1200"
            alt="Drinks Banner"
            className="w-full h-full object-cover filter brightness-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            THE FINEST DRINKS PROGRAM
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            CELLAR & COCKTAILS
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      {/* Tabs Menu Selection */}
      <div className="border-b border-[#F6F3ED]/10 bg-[#101010]/95 sticky top-[73px] z-30 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 overflow-x-auto whitespace-nowrap scrollbar-none py-4 flex justify-center space-x-6">
          {[
            { id: 'all', name: 'ALL BEVERAGES' },
            { id: 'cocktails', name: 'SIGNATURE COCKTAILS' },
            { id: 'beers', name: 'CASK & DRAFT BEERS' },
            { id: 'wines', name: 'FINE WINES' },
            { id: 'spirits', name: 'RESERVE WHISKEYS & SPIRITS' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveTab(cat.id as any)}
              className={`font-sans text-xs tracking-widest px-4 py-2 border transition-all duration-300 cursor-pointer rounded-none ${
                activeTab === cat.id
                  ? 'bg-[#B68C45] text-[#101010] border-[#B68C45] font-semibold'
                  : 'text-[#E8E1D5] border-transparent hover:border-[#B68C45]/40 hover:text-[#B68C45]'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Drinks Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        
        {/* Specific Warnings / Highlights */}
        <div className="mb-12 border border-[#B68C45]/30 bg-[#183A2B]/10 p-6 rounded-none flex items-center space-x-4 max-w-2xl mx-auto">
          <Star className="w-6 h-6 text-[#B68C45] shrink-0" />
          <p className="font-sans text-xs text-[#E8E1D5]/90 leading-relaxed">
            Many of our rare spirits and fine wines are sourced directly from exclusive private auctions in London and Edinburgh. Ask our sommelier for our physical vault list featuring vintage cognacs and single-barrel rums.
          </p>
        </div>

        {/* Display List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
          {filteredDrinks.map((item) => (
            <div
              key={item.id}
              className="group flex flex-col justify-between p-4 border-b border-[#F6F3ED]/10 hover:bg-[#F6F3ED]/5 transition-all duration-400"
            >
              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <h3 className="font-serif text-xl sm:text-2xl text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300 tracking-wide flex items-center" style={{ fontFamily: 'Georgia, serif' }}>
                    {item.name}
                    {item.isSignature && (
                      <span className="ml-2.5 bg-[#B68C45]/20 text-[#B68C45] text-[9px] font-sans tracking-widest font-semibold px-2 py-0.5 rounded-none uppercase flex items-center">
                        <Award className="w-2.5 h-2.5 mr-1" />
                        Signature Poured
                      </span>
                    )}
                  </h3>
                  <span className="font-serif text-lg font-light text-[#B68C45]">
                    {item.price}
                  </span>
                </div>

                <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed font-light mb-4">
                  {item.description}
                </p>
              </div>

              {item.tags && item.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {item.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[9px] font-sans tracking-widest text-[#B68C45]/80 uppercase"
                    >
                      • {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Bottom Bar Info */}
        <div className="mt-20 border-t border-[#F6F3ED]/10 pt-10 text-center max-w-xl mx-auto">
          <div className="flex justify-center space-x-2 text-[#B68C45]/60 mb-4">
            <Star className="w-4 h-4" />
            <span className="font-sans text-[10px] tracking-widest uppercase">
              Responsible Service of Alcohol
            </span>
          </div>
          <p className="font-sans text-xs text-[#E8E1D5]/60 leading-relaxed">
            We operate strict age verification systems. Intoxicated persons will not be served under any circumstances. Thank you for maintaining our pleasant members-club atmosphere.
          </p>
        </div>

      </div>

    </div>
  );
}
