import React, { useState } from 'react';
import { MapPin, Clock, Phone, Mail, Navigation, Car, Train, Landmark, Compass, MessageSquare } from 'lucide-react';

export default function FindUs() {
  const [submittedMessage, setSubmittedMessage] = useState(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    message: '',
  });

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      return;
    }
    setSubmittedMessage(true);
  };

  const landmarks = [
    { name: 'Empire State Building', dist: '5 min walk (East)' },
    { name: 'Times Square', dist: '8 min walk (North)' },
    { name: 'Penn Station', dist: '4 min walk (West)' },
    { name: 'Herald Square Metro', dist: '3 min walk (South)' },
  ];

  return (
    <section 
      id="find-us-section"
      className="relative bg-[#101010] py-20 lg:py-24 border-b border-[#F6F3ED]/10"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
            VISIT & CONNECT
          </p>
          <h2 className="font-serif text-3xl sm:text-5xl font-light text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
            FIND US IN MANHATTAN
          </h2>
          <div className="w-16 h-[1.5px] bg-[#B68C45] mx-auto mt-4" />
        </div>

        {/* Main Grid Content */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Column 1: Address, Hours, Transport Info (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-8 flex flex-col justify-between">
            
            {/* Direct Coordinates */}
            <div className="border border-[#B68C45]/20 bg-[#101010] p-6 rounded-none space-y-4 shadow-xl">
              <div className="flex items-center space-x-3 text-[#B68C45]">
                <MapPin className="w-6 h-6 shrink-0" />
                <h3 className="font-serif text-xl text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>LOCATION</h3>
              </div>
              <p className="font-sans text-sm text-[#E8E1D5] leading-relaxed pl-9 font-light">
                <strong>123 Liberty Avenue</strong><br />
                New York, NY 10018<br />
                <span className="text-[#B68C45] text-xs font-semibold uppercase tracking-wider mt-1 block">
                  (Corner of 36th Street)
                </span>
              </p>
              
              <div className="pl-9 pt-2">
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-2 text-xs font-semibold tracking-widest text-[#B68C45] hover:text-[#E8E1D5] uppercase transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Get Driving Directions</span>
                </a>
              </div>
            </div>

            {/* Timings */}
            <div className="border border-[#B68C45]/20 bg-[#101010] p-6 rounded-none space-y-4 shadow-xl">
              <div className="flex items-center space-x-3 text-[#B68C45]">
                <Clock className="w-6 h-6 shrink-0" />
                <h3 className="font-serif text-xl text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>HOURS OF SERVICE</h3>
              </div>
              <p className="font-sans text-sm text-[#E8E1D5] leading-relaxed pl-9 font-light">
                <strong>We are open 24 Hours a Day • 7 Days a Week</strong>
              </p>
              <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed pl-9 italic font-light">
                * Note: Full Dining Menu runs from 6:00 AM to Midnight daily. Late-Night Exclusive Comfort Menu runs from Midnight to 6:00 AM.
              </p>
            </div>

            {/* Transport details */}
            <div className="border border-[#B68C45]/20 bg-[#101010] p-6 rounded-none space-y-4 shadow-xl flex-1">
              <div className="flex items-center space-x-3 text-[#B68C45]">
                <Compass className="w-6 h-6 shrink-0" />
                <h3 className="font-serif text-xl text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>GETTING HERE</h3>
              </div>

              <div className="space-y-4 pl-9 pt-2">
                
                {/* Subway */}
                <div className="flex items-start space-x-3">
                  <Train className="w-4 h-4 text-[#B68C45] shrink-0 mt-0.5" />
                  <p className="font-sans text-xs text-[#E8E1D5]/90">
                    <strong>By Subway:</strong> Take the <strong>N, Q, R, W, B, D, F, M</strong> to 34th St - Herald Sq (3 min walk) or <strong>A, C, E, 1, 2, 3</strong> to Penn Station (4 min walk).
                  </p>
                </div>

                {/* Parking */}
                <div className="flex items-start space-x-3">
                  <Car className="w-4 h-4 text-[#B68C45] shrink-0 mt-0.5" />
                  <p className="font-sans text-xs text-[#E8E1D5]/90">
                    <strong>Parking:</strong> Valet parking is available daily from 5:00 PM to Midnight. Alternative public garages are located directly adjacent on 36th Street.
                  </p>
                </div>

                {/* Landmarks */}
                <div className="flex items-start space-x-3">
                  <Landmark className="w-4 h-4 text-[#B68C45] shrink-0 mt-0.5" />
                  <div className="font-sans text-xs text-[#E8E1D5]/90 space-y-1">
                    <strong>Nearby Landmarks:</strong>
                    <div className="grid grid-cols-2 gap-2 text-[11px] text-[#E8E1D5]/70 pt-1">
                      {landmarks.map((lm, idx) => (
                        <span key={idx}>• {lm.name} ({lm.dist})</span>
                      ))}
                    </div>
                  </div>
                </div>

              </div>
            </div>

          </div>

          {/* Column 2: Elegant Google Maps Interactive Representation & Direct Contact Form (lg:col-span-7) */}
          <div className="lg:col-span-7 flex flex-col space-y-8">
            
            {/* Simulated Interactive Map */}
            <div className="relative h-[280px] w-full rounded-none overflow-hidden border border-[#B68C45]/20 shadow-2xl bg-[#101010]">
              <div className="absolute inset-0 bg-[#101010] bg-opacity-70 flex flex-col items-center justify-center p-6 text-center z-10">
                <div className="w-12 h-12 rounded-none border border-[#B68C45]/50 bg-[#101010]/90 text-[#B68C45] flex items-center justify-center mb-3">
                  <MapPin className="w-6 h-6 animate-bounce" />
                </div>
                <h4 className="font-serif text-lg text-[#F6F3ED] uppercase mb-1" style={{ fontFamily: 'Georgia, serif' }}>Interactive Google Map</h4>
                <p className="font-sans text-xs text-[#E8E1D5]/80 max-w-sm mb-4 leading-relaxed">
                  Our premises sit precisely on 123 Liberty Ave at 36th Street, in close range to Chelsea, Midtown South, and Herald Sq.
                </p>
                <a
                  href="https://maps.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="cursor-pointer bg-[#B68C45] text-[#101010] font-sans text-[10px] font-bold tracking-widest px-6 py-2.5 uppercase hover:bg-transparent hover:text-[#B68C45] border border-[#B68C45] transition-colors rounded-none"
                >
                  Open in Google Maps
                </a>
              </div>

              {/* Styled stylized street grid lines background representation */}
              <div className="absolute inset-0 opacity-15 select-none pointer-events-none grid grid-cols-12 grid-rows-6">
                {Array.from({ length: 72 }).map((_, i) => (
                  <div key={i} className="border border-[#B68C45]/20" />
                ))}
              </div>
            </div>

            {/* Quick Contact Form */}
            <div className="border border-[#B68C45]/20 bg-[#101010] p-8 rounded-none shadow-xl">
              <div className="flex items-center space-x-3 text-[#B68C45] mb-6">
                <MessageSquare className="w-6 h-6 shrink-0" />
                <h3 className="font-serif text-xl text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>SEND A MESSAGE</h3>
              </div>

              {submittedMessage ? (
                <div className="text-center py-6 space-y-4">
                  <span className="w-10 h-10 rounded-none border border-[#B68C45] flex items-center justify-center text-[#B68C45] mx-auto text-sm">✓</span>
                  <h4 className="font-serif text-xl text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>Message Dispatched</h4>
                  <p className="font-sans text-xs text-[#E8E1D5]/80 max-w-xs mx-auto">
                    Thank you. A guest relationship team member will respond to your query via email at {contactForm.email} shortly.
                  </p>
                  <button
                    onClick={() => setSubmittedMessage(false)}
                    className="cursor-pointer border border-[#B68C45] text-[#B68C45] hover:bg-[#B68C45] hover:text-[#101010] px-5 py-2 font-sans text-[10px] tracking-widest uppercase transition-colors rounded-none"
                  >
                    Send Another
                  </button>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <input
                        type="text"
                        required
                        value={contactForm.name}
                        onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                        placeholder="Your Name"
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                      />
                    </div>
                    <div>
                      <input
                        type="email"
                        required
                        value={contactForm.email}
                        onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                        placeholder="Email Address"
                        className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <textarea
                      rows={3}
                      required
                      value={contactForm.message}
                      onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                      placeholder="How may our concierge help you?"
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-[#B68C45] text-[#101010] font-sans text-xs font-semibold tracking-widest py-3.5 uppercase hover:bg-[#e5bd73] transition-colors cursor-pointer rounded-none"
                  >
                    Submit message
                  </button>
                </form>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
