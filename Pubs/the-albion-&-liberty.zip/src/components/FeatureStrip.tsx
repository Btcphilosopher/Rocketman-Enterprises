import React from 'react';

export default function FeatureStrip() {
  const features = [
    {
      symbol: '24',
      title: 'Always Open',
      desc: 'Complete kitchen service around the clock, 365 days a year.',
    },
    {
      symbol: 'B/A',
      title: 'Cuisine',
      desc: 'Modern British gastronomy paired with Manhattan classics.',
    },
    {
      symbol: '♫',
      title: 'Live Music',
      desc: 'Fireplace jazz, piano lounges, and late-night vinyl sets.',
    },
    {
      symbol: 'W',
      title: 'Collections',
      desc: 'Imported cask ales, aged whiskeys, and cellar reserves.',
    },
  ];

  return (
    <section 
      id="features-strip"
      className="relative z-20 bg-[#183A2B] border-y border-[#B68C45]/20 py-8 lg:py-10"
    >
      <div className="max-w-7xl mx-auto px-6 sm:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-4 items-center justify-between">
          {features.map((feat, idx) => (
            <React.Fragment key={idx}>
              <div className="flex items-center space-x-5 px-2">
                <div className="w-12 h-12 border border-[#B68C45]/30 bg-[#101010]/20 flex items-center justify-center flex-shrink-0 rounded-sm">
                  <span className="text-[#B68C45] text-lg font-serif italic font-normal select-none">
                    {feat.symbol}
                  </span>
                </div>
                <div>
                  <h4 className="text-xs uppercase tracking-[0.2em] text-[#B68C45] mb-1 font-bold">
                    {feat.title}
                  </h4>
                  <p className="text-[10px] text-[#F6F3ED]/75 font-sans leading-normal max-w-[200px] font-light">
                    {feat.desc}
                  </p>
                </div>
              </div>
              {idx < features.length - 1 && (
                <div className="hidden lg:block h-12 w-[1px] bg-[#B68C45]/20" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </section>
  );
}

