import React, { useState } from 'react';
import { Calendar, Clock, Users, Gift, Sparkles, MessageSquare, Phone, Info } from 'lucide-react';
import { ViewState } from '../types';

interface ReservationsSectionProps {
  setView: (view: ViewState) => void;
  isFullPage?: boolean;
}

export default function ReservationsSection({ setView, isFullPage = false }: ReservationsSectionProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [partySize, setPartySize] = useState('2');
  const [date, setDate] = useState('2026-08-05');
  const [time, setTime] = useState('19:30');
  const [seatingArea, setSeatingArea] = useState('main');
  const [notes, setNotes] = useState('');
  const [dietary, setDietary] = useState<string[]>([]);

  // Personal details
  const [personalDetails, setPersonalDetails] = useState({
    name: '',
    email: '',
    phone: '',
  });

  const seatingOptions = [
    { id: 'main', name: 'Main Dining Hall', desc: 'Bustling luxury pub atmosphere with tufted leather booths.', premium: false },
    { id: 'snug', name: 'The Fireplace Snug', desc: 'Intimate, warm, next to the open roaring fire. Ideal for dates.', premium: true },
    { id: 'bar', name: 'The Black Marble Bar', desc: 'High stools directly in front of the mixologists and draft Nitro taps.', premium: false },
    { id: 'private', name: 'Wellington Suite (Premium)', desc: 'Our premier private board room seating. Requires confirmation.', premium: true },
  ];

  const timesList = [
    '06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00', '22:00', '23:30', '01:00', '03:00'
  ];

  const dietaryOptions = [
    'Vegetarian', 'Vegan', 'Gluten-Free', 'Nut Allergy', 'Dairy-Free'
  ];

  const handleToggleDietary = (opt: string) => {
    if (dietary.includes(opt)) {
      setDietary(dietary.filter(d => d !== opt));
    } else {
      setDietary([...dietary, opt]);
    }
  };

  const handlePersonalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPersonalDetails({
      ...personalDetails,
      [name]: value,
    });
  };

  const handleNextStep = (e: React.FormEvent) => {
    e.preventDefault();
    if (!personalDetails.name || !personalDetails.email || !personalDetails.phone) {
      return;
    }
    setStep(2);
  };

  const handleBackStep = () => {
    setStep(1);
  };

  // Generate mock booking code
  const bookingCode = `AL-2026-${Math.random().toString(36).substring(2, 6).toUpperCase()}`;

  return (
    <section 
      id="reservations-section"
      className={`relative bg-[#101010] py-20 lg:py-24 overflow-hidden crest-watermark ${
        isFullPage ? 'pt-28' : ''
      }`}
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
            SECURE YOUR BOOTH
          </p>
          <h2 className="font-serif text-3xl sm:text-5xl font-light text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
            RESERVE A TABLE
          </h2>
          <div className="w-16 h-[1.5px] bg-[#B68C45] mx-auto mt-4" />
        </div>

        {/* Outer Form Container */}
        <div className="border border-[#B68C45]/20 bg-[#101010] rounded-none shadow-2xl p-6 sm:p-10 lg:p-12">
          
          {step === 1 ? (
            /* Step 1: Input Form */
            <form onSubmit={handleNextStep} className="space-y-8">
              
              {/* Top Quick Configurations Row */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                
                {/* Party Size */}
                <div className="space-y-2">
                  <label className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold flex items-center">
                    <Users className="w-3.5 h-3.5 mr-2" />
                    Guests *
                  </label>
                  <select
                    value={partySize}
                    onChange={(e) => setPartySize(e.target.value)}
                    className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 text-sm text-[#F6F3ED] rounded-none outline-none cursor-pointer"
                  >
                    {[1, 2, 3, 4, 5, 6, 8, 10, 12, 16].map((num) => (
                      <option key={num} value={num}>
                        {num} {num === 1 ? 'Guest' : 'Guests'}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date Selection */}
                <div className="space-y-2">
                  <label className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold flex items-center">
                    <Calendar className="w-3.5 h-3.5 mr-2" />
                    Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 text-sm text-[#F6F3ED] rounded-none outline-none"
                  />
                </div>

                {/* Time Selection */}
                <div className="space-y-2">
                  <label className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold flex items-center">
                    <Clock className="w-3.5 h-3.5 mr-2" />
                    Hour *
                  </label>
                  <select
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 text-sm text-[#F6F3ED] rounded-none outline-none cursor-pointer"
                  >
                    {timesList.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              {/* Dynamic Seating Area Selection Map (Grid) */}
              <div className="space-y-3">
                <label className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold mb-2">
                  Select Seating Area Preferred
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {seatingOptions.map((opt) => (
                    <div
                      key={opt.id}
                      onClick={() => setSeatingArea(opt.id)}
                      className={`p-4 border rounded-none cursor-pointer transition-all duration-300 flex flex-col justify-between ${
                        seatingArea === opt.id
                          ? 'border-[#B68C45] bg-[#B68C45]/10 shadow-lg shadow-[#B68C45]/5'
                          : 'border-[#B68C45]/10 bg-[#101010]/60 hover:border-[#B68C45]/40'
                      }`}
                    >
                      <div>
                        <div className="flex justify-between items-center mb-1">
                          <h4 className="font-serif text-base text-[#F6F3ED] font-medium tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
                            {opt.name}
                          </h4>
                          {opt.premium && (
                            <span className="text-[8px] font-sans tracking-widest text-[#B68C45] uppercase border border-[#B68C45]/40 px-2 py-0.5 rounded-none bg-[#183A2B]/20">
                              COZY SNUG
                            </span>
                          )}
                        </div>
                        <p className="font-sans text-[11px] text-[#E8E1D5]/70 leading-relaxed font-light">
                          {opt.desc}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Personal Details Panel */}
              <div className="space-y-4 pt-4 border-t border-[#F6F3ED]/10">
                <h3 className="font-serif text-lg tracking-wide text-[#F6F3ED]" style={{ fontFamily: 'Georgia, serif' }}>
                  PERSONAL DETAILS
                </h3>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <input
                      type="text"
                      name="name"
                      required
                      placeholder="Your Full Name"
                      value={personalDetails.name}
                      onChange={handlePersonalChange}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="email"
                      name="email"
                      required
                      placeholder="Email Address"
                      value={personalDetails.email}
                      onChange={handlePersonalChange}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  </div>
                  <div>
                    <input
                      type="tel"
                      name="phone"
                      required
                      placeholder="Phone Number"
                      value={personalDetails.phone}
                      onChange={handlePersonalChange}
                      className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 rounded-none text-sm text-[#F6F3ED] outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Dietary Requirements Checklist */}
              <div className="space-y-3 pt-2">
                <span className="block text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold">
                  Dietary Requirements (Optional)
                </span>
                <div className="flex flex-wrap gap-2">
                  {dietaryOptions.map((opt) => (
                    <button
                      type="button"
                      key={opt}
                      onClick={() => handleToggleDietary(opt)}
                      className={`px-4 py-1.5 rounded-none font-sans text-[10px] tracking-widest uppercase transition-all duration-300 border cursor-pointer ${
                        dietary.includes(opt)
                          ? 'bg-[#B68C45]/20 text-[#B68C45] border-[#B68C45]'
                          : 'bg-[#101010] text-[#E8E1D5]/70 border-[#B68C45]/15 hover:border-[#B68C45]/40'
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Special Requests Notes */}
              <div className="space-y-2">
                <label className="text-[10px] font-sans tracking-widest text-[#B68C45] uppercase font-semibold flex items-center">
                  <MessageSquare className="w-3.5 h-3.5 mr-2" />
                  Special Occasion or Notes
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 text-sm text-[#F6F3ED] rounded-none outline-none"
                  placeholder="e.g. Celebrating an anniversary, need a quiet corner table, high chairs for kids, etc..."
                />
              </div>

              {/* Dynamic Warning for late hours */}
              <div className="p-4 bg-[#183A2B]/10 border border-[#B68C45]/20 rounded-none flex items-center space-x-3 text-[#E8E1D5]/80">
                <Info className="w-4 h-4 text-[#B68C45] shrink-0" />
                <span className="font-sans text-[11px]">
                  We hold reservations for a grace period of 15 minutes. If running late, please call our main host at (212) 555-ALBION directly to preserve your seating.
                </span>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full px-10 py-4 bg-[#B68C45] text-[#101010] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#E8E1D5] transition-all cursor-pointer rounded-none"
              >
                Confirm Reservation Details
              </button>

            </form>
          ) : (
            /* Step 2: Confirmation Screen */
            <div className="text-center py-12 space-y-8 max-w-lg mx-auto">
              
              {/* Gold Crest Success Sparkle */}
              <div className="w-16 h-16 rounded-none border border-[#B68C45] flex items-center justify-center mx-auto bg-[#B68C45]/10 text-[#B68C45]">
                <Sparkles className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <span className="font-sans text-[10px] tracking-[0.3em] text-[#B68C45] uppercase font-bold">
                  RESERVATION COMPLETED
                </span>
                <h3 className="font-serif text-3xl sm:text-4xl text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>
                  See You Soon
                </h3>
                <div className="w-12 h-[1px] bg-[#B68C45] mx-auto mt-3" />
              </div>

              {/* PDF Ticket Style Receipt Card */}
              <div className="border border-[#B68C45]/20 bg-[#101010] rounded-none p-6 text-left shadow-2xl space-y-4 font-sans relative overflow-hidden">
                
                {/* Visual stamp background */}
                <div className="absolute -top-10 -right-10 text-[#B68C45]/5 font-serif text-8xl select-none uppercase font-bold tracking-[0.2em] transform rotate-12">
                  AL
                </div>

                <div className="flex justify-between items-start border-b border-[#B68C45]/10 pb-3">
                  <div>
                    <span className="text-[10px] text-[#B68C45] uppercase tracking-widest block">
                      Booking Guest
                    </span>
                    <span className="text-base text-[#F6F3ED] font-semibold">
                      {personalDetails.name}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-[#B68C45] uppercase tracking-widest block">
                      Booking Reference
                    </span>
                    <span className="text-sm font-serif text-[#B68C45] font-semibold">
                      {bookingCode}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pb-3 border-b border-[#B68C45]/10">
                  <div>
                    <span className="text-[10px] text-[#E8E1D5]/60 uppercase tracking-widest block">
                      Date & Hour
                    </span>
                    <span className="text-sm text-[#F6F3ED]">
                      {date} @ {time}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#E8E1D5]/60 uppercase tracking-widest block">
                      Party Size
                    </span>
                    <span className="text-sm text-[#F6F3ED]">
                      {partySize} Seated
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pb-3">
                  <div>
                    <span className="text-[10px] text-[#E8E1D5]/60 uppercase tracking-widest block">
                      Seating Room
                    </span>
                    <span className="text-sm text-[#F6F3ED]">
                      {seatingOptions.find(o => o.id === seatingArea)?.name || 'Main Hall'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-[#E8E1D5]/60 uppercase tracking-widest block">
                      Dietary Tags
                    </span>
                    <span className="text-xs text-[#B68C45]">
                      {dietary.length > 0 ? dietary.join(', ') : 'None requested'}
                    </span>
                  </div>
                </div>

                {notes && (
                  <div className="bg-[#183A2B]/10 p-3 rounded-none border border-[#B68C45]/10">
                    <span className="text-[9px] text-[#E8E1D5]/60 uppercase tracking-widest block">
                      Special requests details:
                    </span>
                    <p className="text-xs text-[#E8E1D5]/90 italic mt-1 leading-relaxed">
                      "{notes}"
                    </p>
                  </div>
                )}
              </div>

              <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed max-w-sm mx-auto">
                A confirmation voucher and calendar invitation have been dispatched to <strong>{personalDetails.email}</strong>. We look forward to offering you impeccable British-American hospitality!
              </p>

              <div className="flex justify-center space-x-4">
                <button
                  onClick={handleBackStep}
                  className="px-6 py-3 border border-[#B68C45] text-[#B68C45] hover:bg-[#B68C45] hover:text-[#101010] font-sans text-[10px] font-semibold tracking-widest uppercase transition-all duration-300 cursor-pointer rounded-none"
                >
                  Modify Reservation
                </button>
                <button
                  onClick={() => handleNavClickHome()}
                  className="px-6 py-3 bg-[#B68C45] text-[#101010] hover:bg-transparent hover:text-[#B68C45] border border-[#B68C45] font-sans text-[10px] font-semibold tracking-widest uppercase transition-all duration-300 cursor-pointer rounded-none"
                >
                  Back to Homepage
                </button>
              </div>

            </div>
          )}

        </div>

      </div>
    </section>
  );

  function handleNavClickHome() {
    setView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    setStep(1);
  }
}
