import React, { useState } from 'react';
import { Crown, Instagram, Facebook, Phone, MapPin, Mail, ArrowRight } from 'lucide-react';
import { ViewState } from '../types';

interface FooterProps {
  setView: (view: ViewState) => void;
}

export default function Footer({ setView }: FooterProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail('');
  };

  const quickLinks = [
    { label: 'About', view: 'about' as ViewState },
    { label: 'Menus', view: 'menus' as ViewState },
    { label: 'Private Events', view: 'private' as ViewState },
    { label: 'Gallery', view: 'gallery' as ViewState },
    { label: 'Live Music', view: 'live' as ViewState },
    { label: 'Find Us', view: 'contact' as ViewState },
    { label: 'Careers', view: 'careers' as ViewState },
    { label: 'Journal', view: 'journal' as ViewState },
    { label: 'Gift Cards', view: 'giftcards' as ViewState },
  ];

  const handleLinkClick = (view: ViewState) => {
    setView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer 
      id="main-footer"
      className="relative bg-[#101010] border-t border-[#B68C45]/20 pt-16 pb-8 overflow-hidden"
    >
      
      {/* 1. Newsletter Form Section (Top part of Footer) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12 border-b border-[#B68C45]/10 mb-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          
          <div className="lg:col-span-5 flex items-center space-x-4">
            <div className="text-[#B68C45]">
              <Crown className="w-10 h-10 stroke-[1.2]" />
            </div>
            <div>
              <h3 className="font-serif text-xl sm:text-2xl text-[#F6F3ED] uppercase tracking-wider" style={{ fontFamily: 'Georgia, serif' }}>
                BE PART OF THE FAMILY
              </h3>
              <p className="font-sans text-xs text-[#E8E1D5]/70 mt-1">
                Sign up for news, secret menus, tastings and private event alerts.
              </p>
            </div>
          </div>

          <div className="lg:col-span-7">
            {subscribed ? (
              <div className="text-[#B68C45] font-serif text-sm italic tracking-wide text-left sm:text-right py-2" style={{ fontFamily: 'Georgia, serif' }}>
                Welcome to the inner circle. Expect our letters soon.
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  required
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="flex-1 bg-[#101010] border border-[#B68C45]/20 focus:border-[#B68C45] px-4 py-3 text-sm text-[#F6F3ED] rounded-none outline-none transition-colors"
                />
                <button
                  type="submit"
                  className="cursor-pointer bg-[#B68C45] hover:bg-[#e5bd73] text-[#101010] font-sans text-xs font-semibold tracking-widest px-8 py-3.5 uppercase transition-colors shrink-0 rounded-none"
                >
                  SIGN UP
                </button>
              </form>
            )}
          </div>

        </div>
      </div>

      {/* 2. Main Grid: Info columns & Skyline Illustration */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 items-start mb-16">
          
          {/* Column A: Logo, description, social (lg:col-span-4) */}
          <div className="lg:col-span-4 space-y-6">
            <div 
              className="flex items-center space-x-3 cursor-pointer group"
              onClick={() => handleLinkClick('home')}
            >
              <Crown className="w-8 h-8 text-[#B68C45] stroke-[1.5]" />
              <div className="flex flex-col">
                <span className="font-serif text-base tracking-[0.15em] text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>
                  THE ALBION & LIBERTY
                </span>
                <span className="font-sans text-[9px] tracking-[0.3em] text-[#B68C45] uppercase">
                  24 Hour Gastro Pub
                </span>
              </div>
            </div>

            <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed max-w-sm font-light">
              New York's finest 24-hour British-American gastro sanctuary. Located in the heart of Manhattan, we elevate historic gastropub tradition with Manhattan ambition and luxury detail.
            </p>

            <div className="flex space-x-4">
              <a 
                href="https://instagram.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-8 h-8 rounded-none border border-[#B68C45]/20 hover:border-[#B68C45] flex items-center justify-center text-[#E8E1D5] hover:text-[#B68C45] transition-colors"
                title="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a 
                href="https://facebook.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-8 h-8 rounded-none border border-[#B68C45]/20 hover:border-[#B68C45] flex items-center justify-center text-[#E8E1D5] hover:text-[#B68C45] transition-colors"
                title="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a 
                href="tel:2125552524" 
                className="w-8 h-8 rounded-none border border-[#B68C45]/20 hover:border-[#B68C45] flex items-center justify-center text-[#E8E1D5] hover:text-[#B68C45] transition-colors"
                title="Phone"
              >
                <Phone className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Column B: Quick Links (lg:col-span-3) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-serif text-sm text-[#B68C45] tracking-[0.2em] uppercase font-semibold" style={{ fontFamily: 'Georgia, serif' }}>
              QUICK LINKS
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {quickLinks.map((link) => (
                <button
                  key={link.label}
                  onClick={() => handleLinkClick(link.view)}
                  className="text-left font-sans text-xs text-[#E8E1D5]/80 hover:text-[#B68C45] transition-colors cursor-pointer py-1 block"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>

          {/* Column C: Operating times & Reservation direct (lg:col-span-3) */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="font-serif text-sm text-[#B68C45] tracking-[0.2em] uppercase font-semibold" style={{ fontFamily: 'Georgia, serif' }}>
              OPEN 24 HOURS
            </h4>
            <p className="font-sans text-xs text-[#E8E1D5]/80 leading-relaxed font-light">
              Always Open • Always Welcoming<br />
              123 Liberty Avenue, Manhattan, NY
            </p>

            <h4 className="font-serif text-sm text-[#B68C45] tracking-[0.2em] uppercase font-semibold pt-2" style={{ fontFamily: 'Georgia, serif' }}>
              RESERVATIONS
            </h4>
            <a 
              href="tel:2125552524"
              className="font-serif text-lg text-[#F6F3ED] hover:text-[#B68C45] transition-colors tracking-wide block"
              style={{ fontFamily: 'Georgia, serif' }}
            >
              (212) 555-ALBION
            </a>
          </div>

          {/* Column D: Beautiful wireframe skyline SVG (lg:col-span-2) */}
          <div className="lg:col-span-2 flex justify-end">
            {/* Inline SVG Skyline Illustration */}
            <svg 
              className="w-full max-w-[150px] opacity-25 text-[#B68C45]" 
              viewBox="0 0 100 100" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="0.75"
            >
              {/* Empire State Building wire */}
              <path d="M50 10 L50 20 M47 20 L53 20 M45 25 L55 25 M40 35 L60 35 M40 35 L40 100 M60 35 L60 100" />
              <path d="M42 45 L58 45 M42 55 L58 55 M42 65 L58 65 M42 75 L58 75 M42 85 L58 85" />
              {/* Chrysler-style arches */}
              <path d="M15 45 L15 100 M30 45 L30 100 M15 45 Q22 30 30 45" />
              <path d="M22 30 L22 10 M18 40 L26 40" />
              {/* Boxy Manhattan residential lines */}
              <path d="M70 50 L70 100 M90 50 L90 100 M70 50 L90 50 M70 60 L90 60 M70 70 L90 70 M70 80 L90 80 M70 90 L90 90" />
              {/* Bridge arcs */}
              <path d="M5 90 L95 90 M5 95 L95 95 M10 90 L10 100 M90 90 L90 100" />
            </svg>
          </div>

        </div>

        {/* 3. Privacy, Copyright bottom bar */}
        <div className="border-t border-[#B68C45]/10 pt-8 flex flex-col sm:flex-row justify-between items-center text-[10px] font-sans text-[#E8E1D5]/50 tracking-wider">
          <p>© 2026 The Albion & Liberty. All Rights Reserved.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <button 
              onClick={() => handleLinkClick('contact')}
              className="hover:text-[#B68C45] transition-colors cursor-pointer uppercase"
            >
              Privacy Policy
            </button>
            <button 
              onClick={() => handleLinkClick('contact')}
              className="hover:text-[#B68C45] transition-colors cursor-pointer uppercase"
            >
              Terms & Conditions
            </button>
          </div>
        </div>

      </div>

    </footer>
  );
}
