import React, { useState } from 'react';
import { EVENTS_LIST } from '../data';
import { ViewState, EventItem } from '../types';
import { Calendar, Music, Sparkles, Trophy, ArrowRight, Hourglass } from 'lucide-react';

interface LiveMusicProps {
  setView: (view: ViewState) => void;
  isFullPage?: boolean;
}

export default function LiveMusic({ setView, isFullPage = false }: LiveMusicProps) {
  const [filter, setFilter] = useState<'all' | 'Jazz' | 'Acoustic' | 'British Rock' | 'DJ Set' | 'Sport'>('all');

  const filteredEvents = filter === 'all'
    ? EVENTS_LIST
    : EVENTS_LIST.filter(evt => evt.category === filter);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Jazz':
        return <Music className="w-5 h-5 text-[#B68C45]" />;
      case 'Acoustic':
        return <Sparkles className="w-5 h-5 text-[#B68C45]" />;
      case 'Sport':
        return <Trophy className="w-5 h-5 text-[#B68C45]" />;
      case 'DJ Set':
        return <Hourglass className="w-5 h-5 text-[#B68C45]" />;
      default:
        return <Music className="w-5 h-5 text-[#B68C45]" />;
    }
  };

  if (!isFullPage) {
    // 1. Landing Page Split Block (Live & Unmissable)
    return (
      <section
        id="landing-music-section"
        className="relative bg-[#101010] py-20 lg:py-24 border-b border-[#F6F3ED]/10 overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Left: Singer/Acoustic Photo with text overlay */}
            <div className="lg:col-span-6 relative h-[450px] rounded-none overflow-hidden border border-[#B68C45]/20 shadow-2xl group">
              <img
                src="https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&q=80&w=1200"
                alt="Musician playing live at pub snug"
                className="w-full h-full object-cover filter brightness-[0.35] group-hover:scale-105 transition-transform duration-1000"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#101010] via-transparent to-transparent opacity-90" />
              
              {/* Overlay text */}
              <div className="absolute bottom-10 left-10 right-10">
                <span className="font-sans text-[9px] tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-2 block">
                  EVERY WEEKEND
                </span>
                <h3 className="font-serif text-3xl text-[#F6F3ED] uppercase tracking-wide leading-tight mb-4" style={{ fontFamily: 'Georgia, serif' }}>
                  THE FIREPLACE JAZZ SNUG
                </h3>
                <p className="font-sans text-xs text-[#E8E1D5]/80 leading-relaxed max-w-sm">
                  Let classical bass and double sax sweep your night away. Hand-poured Scotch and cozy lounge sofas at your disposal.
                </p>
              </div>
            </div>

            {/* Right: Copywriting and Next Events listing */}
            <div className="lg:col-span-6 flex flex-col justify-center">
              <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
                LIVE & UNMISSABLE
              </p>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-light text-[#F6F3ED] uppercase tracking-wide mb-6" style={{ fontFamily: 'Georgia, serif' }}>
                SOUNDS OF THE ALBION
              </h2>
              <div className="w-16 h-[1.5px] bg-[#B68C45] mb-8" />
              
              <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed mb-8 font-light">
                From cozy midnight fireplace acoustics to high-profile Premier League screenings and late-night vinyl club DJs—there is always a reason to gather at The Albion & Liberty.
              </p>

              {/* Top 3 upcoming events */}
              <div className="space-y-4 mb-10">
                {EVENTS_LIST.slice(0, 3).map((evt) => (
                  <div
                    key={evt.id}
                    className="flex justify-between items-center p-4 border border-[#B68C45]/20 bg-[#101010] rounded-none hover:border-[#B68C45]/60 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="bg-[#101010] p-2.5 rounded-none border border-[#B68C45]/20">
                        {getCategoryIcon(evt.category)}
                      </div>
                      <div>
                        <h4 className="font-serif text-base text-[#F6F3ED] tracking-wide font-medium" style={{ fontFamily: 'Georgia, serif' }}>{evt.title}</h4>
                        <p className="font-sans text-[10px] text-[#B68C45] uppercase tracking-wider">{evt.dayOfWeek} • {evt.time}</p>
                      </div>
                    </div>
                    <span className="text-[9px] font-sans tracking-widest text-[#E8E1D5]/50 uppercase hidden sm:block">
                      {evt.category}
                    </span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => {
                  setView('live');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="px-10 py-4 border border-[#B68C45] text-[#B68C45] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#B68C45] hover:text-[#101010] transition-all cursor-pointer max-w-sm flex items-center justify-center space-x-2"
              >
                <span>Full Events Calendar</span>
                <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
              </button>

            </div>

          </div>
        </div>
      </section>
    );
  }

  // 2. Full Page sub-view
  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&q=80&w=1200"
            alt="Live Music Banner"
            className="w-full h-full object-cover filter brightness-[0.2]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            SOUND & ENTERTAINMENT
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            LIVE CALENDAR
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        
        {/* Intro */}
        <div className="text-center max-w-xl mx-auto mb-12">
          <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed font-light">
            We host intimate gatherings, master instrumental sets, and classic broadcasts to entertain Manhattan around the clock. Filter the calendar below to check what is scheduled for your visit.
          </p>
        </div>

        {/* Calendar Filters */}
        <div className="flex flex-wrap gap-2 justify-center mb-12">
          {['all', 'Jazz', 'Acoustic', 'British Rock', 'DJ Set', 'Sport'].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilter(cat as any)}
              className={`font-sans text-[10px] tracking-widest px-4 py-2 border transition-all duration-300 cursor-pointer rounded-none ${
                filter === cat
                  ? 'bg-[#B68C45] text-[#101010] border-[#B68C45] font-semibold'
                  : 'text-[#E8E1D5] border-[#B68C45]/20 hover:border-[#B68C45] hover:text-[#B68C45]'
              }`}
            >
              {cat.toUpperCase()}
            </button>
          ))}
        </div>

        {/* Calendar Row Items */}
        <div className="space-y-6">
          {filteredEvents.length > 0 ? (
            filteredEvents.map((evt) => (
              <div
                key={evt.id}
                className="group grid grid-cols-1 md:grid-cols-12 gap-6 p-6 border border-[#B68C45]/20 bg-[#101010] rounded-none hover:border-[#B68C45] transition-all duration-400 items-center relative overflow-hidden"
              >
                {/* Visual left element */}
                <div className="md:col-span-3 flex md:flex-col justify-between md:justify-center md:items-center text-center border-b md:border-b-0 md:border-r border-[#B68C45]/20 pb-4 md:pb-0 md:pr-6 shrink-0">
                  <div className="flex items-center md:flex-col">
                    <Calendar className="w-5 h-5 text-[#B68C45] mb-2 md:block hidden" />
                    <span className="font-serif text-2xl text-[#F6F3ED] uppercase font-bold tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
                      {evt.dayOfWeek}
                    </span>
                  </div>
                  <span className="font-sans text-[10px] tracking-widest text-[#B68C45] uppercase mt-1">
                    {evt.date}
                  </span>
                </div>

                {/* Center Copy details */}
                <div className="md:col-span-6 space-y-2">
                  <span className="text-[9px] font-sans tracking-widest text-[#B68C45] uppercase bg-[#B68C45]/10 px-2.5 py-1 rounded-none">
                    {evt.category}
                  </span>
                  <h3 className="font-serif text-xl sm:text-2xl text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300 pt-1" style={{ fontFamily: 'Georgia, serif' }}>
                    {evt.title}
                  </h3>
                  <p className="font-sans text-xs text-[#E8E1D5]/80 leading-relaxed font-light">
                    {evt.description}
                  </p>
                </div>

                {/* Right Call-To-Action Booking */}
                <div className="md:col-span-3 flex flex-col justify-center items-stretch md:pl-6">
                  <div className="text-center md:text-right mb-4">
                    <span className="font-sans text-[10px] tracking-wider text-[#B68C45] uppercase font-bold block">
                      SCHEDULED TIME
                    </span>
                    <span className="font-sans text-xs text-[#E8E1D5]">{evt.time}</span>
                  </div>

                  <button
                    onClick={() => {
                      setView('reservations');
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="cursor-pointer bg-[#B68C45] text-[#101010] hover:bg-transparent hover:text-[#B68C45] border border-[#B68C45] font-sans text-[10px] font-bold tracking-widest py-3 text-center uppercase transition-all duration-300 rounded-none"
                  >
                    Reserve Table
                  </button>
                </div>

              </div>
            ))
          ) : (
            <div className="text-center py-20 border border-[#B68C45]/15 bg-[#172231]/10 rounded-none">
              <span className="font-sans text-xs text-[#E8E1D5]/60 italic">
                No events scheduled under this category. Please check another tab or return later.
              </span>
            </div>
          )}
        </div>

        {/* Note at Bottom */}
        <div className="mt-16 bg-[#183A2B]/10 border border-[#B68C45]/20 p-6 rounded-none text-center max-w-xl mx-auto">
          <p className="font-sans text-xs text-[#E8E1D5]/85">
            <strong>Table Bookings:</strong> Live music events are extremely popular. To guarantee a prime seat in front of the band, we suggest booking your reservation at least 48 hours in advance and adding "Live Music Area" in special requests.
          </p>
        </div>

      </div>

    </div>
  );
}
