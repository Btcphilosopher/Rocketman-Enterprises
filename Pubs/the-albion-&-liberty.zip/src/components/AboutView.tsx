import React from 'react';
import { IMAGES } from '../data';
import { Shield, Sparkles, Award } from 'lucide-react';

export default function AboutView() {
  const coreValues = [
    {
      icon: <Shield className="w-6 h-6 text-[#B68C45]" />,
      title: 'HISTORICAL FIDELITY',
      desc: 'We conditioned cask ales strictly in London limestone equivalents, with high-end nitrogenated lines and classical, hand-pumped draft beer engines.',
    },
    {
      icon: <Award className="w-6 h-6 text-[#B68C45]" />,
      title: 'ELEVATED INGREDIENTS',
      desc: 'Dry-aging Pat LaFrieda ribeyes for 35 days, hand-carving custom West Country butter blends, and sourcing organic Hudson Valley farm potatoes.',
    },
    {
      icon: <Sparkles className="w-6 h-6 text-[#B68C45]" />,
      title: 'UNCEASING WELCOME',
      desc: 'Open 24 hours a day, 365 days a year. We honor all shifts and guests equally—whether they are midnight theatergoers or early sunrise workers.',
    },
  ];

  return (
    <div className="pt-28 bg-[#101010] min-h-screen pb-20">
      
      {/* Banner */}
      <div className="relative h-[300px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={IMAGES.pubInterior}
            alt="About Banner"
            className="w-full h-full object-cover filter brightness-[0.25]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            ESTABLISHED IN MANHATTAN
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            OUR STORY & HERITAGE
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 space-y-16">
        
        {/* Story Section 1 */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-7 space-y-4">
            <span className="font-sans text-xs tracking-[0.2em] text-[#B68C45] uppercase font-bold">
              THE BRIDGING OF TWO EMPIRES
            </span>
            <h2 className="font-serif text-3xl text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
              A British Tradition. An American Spirit.
            </h2>
            <div className="w-12 h-[1px] bg-[#B68C45] my-2" />
            
            <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed font-light">
              Founded in 2026 by a collective of passionate English publicans and New York culinary designers, The Albion & Liberty was born out of a simple, beautiful desire: to craft an uncompromised, world-class British public house inside the towering landscape of Manhattan.
            </p>
            <p className="font-sans text-sm text-[#E8E1D5]/80 leading-relaxed font-light">
              We took cues from London's traditional members clubs—with their dark timber, plush tufted leather, and cozy private snugs—and fused it with New York's sophisticated, fast-paced culinary ambition. The result is a premium, welcoming 24-hour gastro sanctuary.
            </p>
          </div>

          <div className="md:col-span-5 h-[320px] rounded-none border border-[#B68C45]/20 overflow-hidden shadow-xl img-zoom-container">
            <img
              src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600"
              alt="Culinary Ingredients"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Story Section 2 (Centered callout) */}
        <div className="bg-[#101010] border border-[#B68C45]/25 rounded-none p-8 sm:p-12 text-center max-w-3xl mx-auto space-y-4 shadow-2xl relative">
          <div className="absolute top-4 left-4 text-[#B68C45]/10 font-serif text-6xl">“</div>
          <p className="font-serif text-xl sm:text-2xl text-[#F6F3ED] italic leading-relaxed" style={{ fontFamily: 'Georgia, serif' }}>
            "To build a sanctuary that honors classical brewing and traditional Sunday roasts, but is fueled by the ambition, energy, and meticulous standards of Manhattan culinary craft."
          </p>
          <p className="font-sans text-xs tracking-widest text-[#B68C45] uppercase font-semibold">
            — THE ALBION FOUNDING MANIFESTO
          </p>
        </div>

        {/* Value Cards Section */}
        <div className="space-y-6 pt-6">
          <div className="text-center">
            <p className="font-sans text-xs tracking-[0.25em] text-[#B68C45] uppercase font-semibold mb-2">
              OUR SERVICE VALUES
            </p>
            <h3 className="font-serif text-2xl text-[#F6F3ED] uppercase tracking-wider" style={{ fontFamily: 'Georgia, serif' }}>
              WHAT WE STAND FOR
            </h3>
            <div className="w-12 h-[1px] bg-[#B68C45] mx-auto mt-3" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6">
            {coreValues.map((val, idx) => (
              <div 
                key={idx}
                className="p-6 border border-[#B68C45]/20 bg-[#101010] rounded-none hover:border-[#B68C45]/40 transition-colors text-center space-y-3"
              >
                <div className="w-12 h-12 rounded-none border border-[#B68C45]/30 bg-[#183A2B]/10 flex items-center justify-center mx-auto">
                  {val.icon}
                </div>
                <h4 className="font-serif text-lg text-[#F6F3ED] tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>{val.title}</h4>
                <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed font-light">
                  {val.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
