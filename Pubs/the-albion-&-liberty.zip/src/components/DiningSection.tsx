import React, { useState } from 'react';
import { IMAGES, FOOD_MENU } from '../data';
import { ViewState } from '../types';
import { Check, Flame, Award, Clock } from 'lucide-react';

interface DiningSectionProps {
  setView: (view: ViewState) => void;
  isFullPage?: boolean;
}

export default function DiningSection({ setView, isFullPage = false }: DiningSectionProps) {
  const [activeTab, setActiveTab] = useState<'all' | 'breakfast' | 'lunch' | 'dinner' | 'late-night' | 'sunday-roast' | 'desserts'>('all');

  // Highlights on the main home landing page - Raised Pub Classics
  const raisedClassics = [
    {
      title: 'FOOD MENU',
      description: 'British classics, elevated. Seasonal, local, exceptional.',
      image: IMAGES.fishAndChips,
      btnText: 'VIEW MENU',
      action: () => handleViewCategory('lunch'),
    },
    {
      title: 'DRINKS MENU',
      description: 'From British cask ales to signature cocktails.',
      image: IMAGES.pintOfAle,
      btnText: 'VIEW DRINKS',
      action: () => {
        setView('drinks');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      },
    },
    {
      title: 'ALL-DAY MENU',
      description: 'Breakfast, lunch, dinner and everything in between.',
      image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=600',
      btnText: 'VIEW ALL-DAY',
      action: () => handleViewCategory('all'),
    },
    {
      title: 'LATE NIGHT MENU',
      description: 'Thoughtful dishes, served through the night.',
      image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=600',
      btnText: 'VIEW LATE NIGHT',
      action: () => handleViewCategory('late-night'),
    },
    {
      title: 'DESSERTS',
      description: 'Indulgent, classic, unforgettable.',
      image: IMAGES.stickyToffee,
      btnText: 'VIEW DESSERTS',
      action: () => handleViewCategory('desserts'),
    },
  ];

  const handleViewCategory = (category: typeof activeTab) => {
    setView('menus');
    setActiveTab(category);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredMenu = activeTab === 'all' 
    ? FOOD_MENU 
    : FOOD_MENU.filter(item => item.category === activeTab);

  const categoriesList = [
    { id: 'all', name: 'ALL-DAY SELECTION' },
    { id: 'breakfast', name: 'BREAKFAST (6AM-11AM)' },
    { id: 'lunch', name: 'ELEVATED LUNCH (11AM-4PM)' },
    { id: 'dinner', name: 'LUXURY DINNER (4PM-MIDNIGHT)' },
    { id: 'late-night', name: 'MIDNIGHT TO DAWN (MIDNIGHT-6AM)' },
    { id: 'sunday-roast', name: 'SUNDAY ROAST (SUNDAYS ONLY)' },
    { id: 'desserts', name: 'DESSERTS & CHEESE' },
  ];

  if (!isFullPage) {
    // 1. Landing Page Horizontal Grid - Raised Pub Classics
    return (
      <section 
        id="landing-dining-section"
        className="relative bg-[#101010] py-20 lg:py-24 border-b border-[#F6F3ED]/10"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center mb-16">
            <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-bold mb-3">
              ESTEEMED CULINARY SELECTION
            </p>
            <h2 className="font-serif text-3xl sm:text-5xl font-light text-[#F6F3ED] uppercase tracking-wide" style={{ fontFamily: 'Georgia, serif' }}>
              RAISED PUB CLASSICS
            </h2>
            <div className="w-16 h-[1.5px] bg-[#B68C45] mx-auto mt-4" />
          </div>

          {/* Grid of the 5 main luxury cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {raisedClassics.map((classic, index) => (
              <div
                key={index}
                className="group flex flex-col bg-[#101010] border border-[#B68C45]/20 hover:border-[#B68C45] transition-all duration-500 rounded-none overflow-hidden shadow-xl"
              >
                {/* Image Container with zoom */}
                <div className="img-zoom-container relative h-48 w-full border-b border-[#B68C45]/20">
                  <img
                    src={classic.image}
                    alt={classic.title}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#101010]/90 to-transparent opacity-60 group-hover:opacity-45 transition-opacity" />
                </div>

                {/* Card Info */}
                <div className="p-5 flex-1 flex flex-col justify-between text-center bg-[#101010]/95">
                  <div>
                    <h3 className="font-serif text-lg tracking-widest text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300 uppercase mb-2" style={{ fontFamily: 'Georgia, serif' }}>
                      {classic.title}
                    </h3>
                    <p className="font-sans text-xs text-[#E8E1D5]/75 leading-relaxed mb-6 h-12 overflow-hidden">
                      {classic.description}
                    </p>
                  </div>

                  <div>
                    <button
                      onClick={classic.action}
                      className="px-4 py-2 border border-[#B68C45]/30 text-[#B68C45] text-[10px] uppercase tracking-[0.15em] font-bold hover:bg-[#B68C45] hover:text-[#101010] transition-all duration-300 w-full block cursor-pointer"
                    >
                      {classic.btnText}
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>

        </div>
      </section>
    );
  }

  // 2. Full Page sub-view with category navigation, lists, recipes & details
  return (
    <div className="pt-28 bg-[#101010]">
      {/* Banner */}
      <div className="relative h-[250px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={IMAGES.pubInterior}
            alt="Dining Banner"
            className="w-full h-full object-cover filter brightness-[0.25]"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#101010] to-transparent" />
        </div>
        <div className="relative z-10 text-center">
          <p className="font-sans text-xs tracking-[0.3em] text-[#B68C45] uppercase font-semibold mb-3">
            TASTE OF EXCELLENCE
          </p>
          <h1 className="font-serif text-4xl sm:text-6xl text-[#F6F3ED] tracking-wider uppercase" style={{ fontFamily: 'Georgia, serif' }}>
            GASTRONOMY MENUS
          </h1>
          <div className="w-16 h-[1px] bg-[#B68C45] mx-auto mt-4" />
        </div>
      </div>

      {/* Tabs Menu Selection */}
      <div className="border-b border-[#F6F3ED]/10 bg-[#101010]/95 sticky top-[73px] z-30 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 overflow-x-auto whitespace-nowrap scrollbar-none py-4 flex justify-center space-x-6">
          {categoriesList.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveTab(cat.id as any)}
              className={`font-sans text-xs tracking-widest px-4 py-2 border transition-all duration-300 cursor-pointer rounded-none ${
                activeTab === cat.id
                  ? 'bg-[#B68C45] text-[#101010] border-[#B68C45] font-semibold'
                  : 'text-[#E8E1D5] border-transparent hover:border-[#B68C45]/40 hover:text-[#B68C45]'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </div>

      {/* Full Menu Layout Container */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        
        {/* Dynamic Warning or Highlight Box for Sunday Roast */}
        {activeTab === 'sunday-roast' && (
          <div className="mb-12 border border-[#B68C45]/30 bg-[#183A2B]/10 p-6 rounded-none text-center flex flex-col items-center">
            <Award className="w-8 h-8 text-[#B68C45] mb-2" />
            <h3 className="font-serif text-lg tracking-wider text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>
              The Sunday roast Legend
            </h3>
            <p className="font-sans text-xs text-[#E8E1D5]/90 mt-1 max-w-xl">
              Available exclusively on Sundays from 12:00 PM until sold out. Hand-carved and served family-style in our dining hall. Booking highly recommended.
            </p>
          </div>
        )}

        {/* Dynamic Warning or Highlight Box for Late Night */}
        {activeTab === 'late-night' && (
          <div className="mb-12 border border-[#B68C45]/30 bg-[#101010] p-6 rounded-none text-center flex flex-col items-center">
            <Clock className="w-8 h-8 text-[#B68C45] mb-2 animate-pulse" />
            <h3 className="font-serif text-lg tracking-wider text-[#F6F3ED] uppercase" style={{ fontFamily: 'Georgia, serif' }}>
              24-Hour Midnight Culinary Craft
            </h3>
            <p className="font-sans text-xs text-[#E8E1D5]/90 mt-1 max-w-xl">
              Served from midnight until dawn. Sourced with the same elevated standard for Manhattan's late-night gourmands and off-duty culinary chefs.
            </p>
          </div>
        )}

        {/* Menu Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-16">
          {filteredMenu.map((item) => (
            <div 
              key={item.id}
              className="group flex flex-col justify-between p-4 border-b border-[#F6F3ED]/10 hover:bg-[#F6F3ED]/5 transition-all duration-400"
            >
              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <h3 className="font-serif text-xl sm:text-2xl text-[#F6F3ED] group-hover:text-[#B68C45] transition-colors duration-300 tracking-wide flex items-center" style={{ fontFamily: 'Georgia, serif' }}>
                    {item.name}
                    {item.isSignature && (
                      <span className="ml-2.5 bg-[#B68C45]/20 text-[#B68C45] text-[9px] font-sans tracking-widest font-semibold px-2 py-0.5 rounded-none uppercase flex items-center">
                        <Award className="w-2.5 h-2.5 mr-1" />
                        Signature
                      </span>
                    )}
                  </h3>
                  <span className="font-serif text-lg font-light text-[#B68C45]">
                    {item.price}
                  </span>
                </div>

                <p className="font-sans text-xs text-[#E8E1D5]/70 leading-relaxed font-light mb-4">
                  {item.description}
                </p>
              </div>

              {item.tags && item.tags.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {item.tags.map((tag, idx) => (
                    <span 
                      key={idx}
                      className="text-[9px] font-sans tracking-widest text-[#B68C45]/80 uppercase"
                    >
                      • {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Note at Bottom */}
        <div className="mt-20 text-center max-w-lg mx-auto border-t border-[#F6F3ED]/10 pt-10">
          <p className="font-sans text-xs text-[#E8E1D5]/60 leading-relaxed italic">
            Consuming raw or undercooked meats, poultry, seafood, shellfish, or eggs may increase your risk of foodborne illness. Please notify your server of any food allergies or dietary restrictions prior to ordering.
          </p>
          <button
            onClick={() => {
              setView('reservations');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-10 py-4 bg-[#B68C45] text-[#101010] uppercase tracking-[0.2em] text-[11px] font-bold hover:bg-[#E8E1D5] transition-all cursor-pointer mt-8 inline-block"
          >
            Book a Table to dine
          </button>
        </div>

      </div>
    </div>
  );
}
