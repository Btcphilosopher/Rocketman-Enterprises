import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import FeatureStrip from './components/FeatureStrip';
import AboutSection from './components/AboutSection';
import DiningSection from './components/DiningSection';
import CocktailSection from './components/CocktailSection';
import PrivateDining from './components/PrivateDining';
import LiveMusic from './components/LiveMusic';
import GallerySection from './components/GallerySection';
import ReservationsSection from './components/ReservationsSection';
import FindUs from './components/FindUs';
import Footer from './components/Footer';

// Extra Sub-views
import AboutView from './components/AboutView';
import JournalSection from './components/JournalSection';
import GiftCardsSection from './components/GiftCardsSection';
import CareersSection from './components/CareersSection';

import { ViewState } from './types';
import { Crown, Calendar, Sparkles } from 'lucide-react';

export default function App() {
  const [currentView, setView] = useState<ViewState>('home');
  const [loading, setLoading] = useState(true);
  const [showStickyMobile, setShowStickyMobile] = useState(false);
  const [cursorPos, setCursorPos] = useState({ x: -100, y: -100 });
  const [isHovering, setIsHovering] = useState(false);

  // 1. Loading screen timer
  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);
    return () => clearTimeout(timer);
  }, []);

  // 2. Mobile sticky reserve button trigger on scroll
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowStickyMobile(true);
      } else {
        setShowStickyMobile(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 3. Custom cursor position tracker
  useEffect(() => {
    const updateCursor = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
    };

    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target.tagName === 'BUTTON' || 
        target.tagName === 'A' || 
        target.onclick ||
        target.closest('button') ||
        target.closest('a') ||
        target.classList.contains('cursor-pointer')
      ) {
        setIsHovering(true);
      } else {
        setIsHovering(false);
      }
    };

    window.addEventListener('mousemove', updateCursor);
    window.addEventListener('mouseover', handleMouseOver);

    return () => {
      window.removeEventListener('mousemove', updateCursor);
      window.removeEventListener('mouseover', handleMouseOver);
    };
  }, []);

  const handleSetView = (view: ViewState) => {
    setView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // 4. Render current main content panel
  const renderContent = () => {
    switch (currentView) {
      case 'home':
        return (
          <>
            <Hero setView={handleSetView} />
            <FeatureStrip />
            <AboutSection setView={handleSetView} />
            <DiningSection setView={handleSetView} isFullPage={false} />
            <CocktailSection setView={handleSetView} isFullPage={false} />
            <PrivateDining setView={handleSetView} isFullPage={false} />
            <LiveMusic setView={handleSetView} isFullPage={false} />
            <GallerySection setView={handleSetView} isFullPage={false} />
            <ReservationsSection setView={handleSetView} isFullPage={false} />
            <FindUs />
          </>
        );
      case 'about':
        return <AboutView />;
      case 'menus':
        return <DiningSection setView={handleSetView} isFullPage={true} />;
      case 'drinks':
        return <CocktailSection setView={handleSetView} isFullPage={true} />;
      case 'live':
        return <LiveMusic setView={handleSetView} isFullPage={true} />;
      case 'private':
        return <PrivateDining setView={handleSetView} isFullPage={true} />;
      case 'gallery':
        return <GallerySection setView={handleSetView} isFullPage={true} />;
      case 'reservations':
        return <ReservationsSection setView={handleSetView} isFullPage={true} />;
      case 'journal':
        return <JournalSection />;
      case 'giftcards':
        return <GiftCardsSection />;
      case 'careers':
        return <CareersSection />;
      case 'contact':
        return (
          <div className="pt-28 bg-[#101010]">
            <FindUs />
          </div>
        );
      default:
        return <Hero setView={handleSetView} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#101010] text-[#F6F3ED] selection:bg-[#B68C45] selection:text-[#101010] relative">
      
      {/* Dynamic Ambient Luxury Lighting Backgrounds */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden opacity-30">
        <div className="absolute top-1/4 left-[-10%] w-[500px] h-[500px] rounded-full bg-[#183A2B]/20 blur-[130px]" />
        <div className="absolute bottom-1/4 right-[-10%] w-[600px] h-[600px] rounded-full bg-[#172231]/15 blur-[150px]" />
      </div>

      {/* Elegant Loading Screen */}
      {loading && (
        <div 
          id="loading-screen"
          className="fixed inset-0 bg-[#101010] z-[1000] flex flex-col items-center justify-center space-y-4 transition-opacity duration-1000 ease-in-out"
        >
          <div className="text-[#B68C45] animate-[spin_4s_linear_infinite]">
            <Crown className="w-16 h-16 stroke-[1]" />
          </div>
          <div className="flex flex-col items-center text-center space-y-1">
            <h2 className="font-serif text-2xl tracking-[0.2em] text-[#F6F3ED] uppercase font-light animate-pulse">
              THE ALBION & LIBERTY
            </h2>
            <span className="font-sans text-[9px] tracking-[0.4em] text-[#B68C45] uppercase font-semibold">
              EST. 2026 • MANHATTAN
            </span>
          </div>
          {/* Subtle gold line bar */}
          <div className="w-32 h-[1px] bg-[#B68C45]/20 relative overflow-hidden mt-6">
            <div className="absolute inset-y-0 left-0 bg-[#B68C45] w-12 animate-[loadingBar_1.5s_infinite_ease-in-out]" />
          </div>
        </div>
      )}

      {/* Custom Mouse Cursor on Desktop */}
      <div
        id="custom-cursor"
        style={{
          transform: `translate3d(${cursorPos.x - 10}px, ${cursorPos.y - 10}px, 0)`,
          opacity: cursorPos.x === -100 ? 0 : 1,
        }}
        className={`hidden lg:block fixed top-0 left-0 w-5 h-5 rounded-full border border-[#B68C45] pointer-events-none z-[9999] transition-all duration-75 ease-out ${
          isHovering 
            ? 'bg-[#B68C45]/20 scale-150 border-transparent shadow-[0_0_15px_3px_rgba(182,140,69,0.4)]' 
            : 'bg-transparent scale-100'
        }`}
      />

      {/* Sticky Reservation Button on Mobile */}
      {showStickyMobile && (
        <div 
          id="mobile-sticky-bar"
          className="lg:hidden fixed bottom-6 left-1/2 transform -translate-x-1/2 z-40 w-[90%] max-w-sm animate-[fadeIn_0.5s_ease]"
        >
          <button
            onClick={() => handleSetView('reservations')}
            className="w-full bg-[#B68C45] text-[#101010] font-sans text-xs font-bold tracking-widest py-4 rounded-full shadow-2xl uppercase flex items-center justify-center space-x-2 border border-[#B68C45] hover:bg-[#101010] hover:text-[#B68C45] transition-all duration-300"
          >
            <Calendar className="w-4 h-4" />
            <span>RESERVE A TABLE</span>
          </button>
        </div>
      )}

      {/* Navigation Bar */}
      <Navbar currentView={currentView} setView={handleSetView} />

      {/* Main View Area */}
      <main className="relative z-10">
        {renderContent()}
      </main>

      {/* Footer Area */}
      <Footer setView={handleSetView} />

    </div>
  );
}
