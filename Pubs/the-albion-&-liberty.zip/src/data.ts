import pubExterior from './assets/images/pub_exterior_1785680632147.jpg';
import pubInterior from './assets/images/pub_interior_1785680649652.jpg';
import fishAndChipsImg from './assets/images/fish_and_chips_1785680668441.jpg';
import pintOfAleImg from './assets/images/pint_of_ale_1785680684512.jpg';
import stickyToffeeImg from './assets/images/sticky_toffee_1785680702793.jpg';

import { MenuItem, EventItem, GalleryItem, ReviewItem, CareerJob, JournalPost } from './types';

// Export imported image paths for easy consumption elsewhere
export const IMAGES = {
  pubExterior,
  pubInterior,
  fishAndChips: fishAndChipsImg,
  pintOfAle: pintOfAleImg,
  stickyToffee: stickyToffeeImg,
};

export const FOOD_MENU: MenuItem[] = [
  // Breakfast (6 AM - 11 AM)
  {
    id: 'b1',
    name: 'The Great British Breakfast',
    description: 'Two organic eggs, Cumberland sausage, thick-cut smoked back bacon, black pudding, roasted field mushroom, grilled plum tomato, Heinz baked beans, and buttered sourdough toast.',
    price: '$28.00',
    category: 'breakfast',
    tags: ['Traditional', 'Guest Favorite'],
    isSignature: true,
  },
  {
    id: 'b2',
    name: 'Manhattan Eggs Royale',
    description: 'Perfectly poached organic eggs, house-cured Scottish smoked salmon, buttered English muffin, wild ramp hollandaise, served with a side of micro-herb salad.',
    price: '$24.00',
    category: 'breakfast',
    tags: ['Fresh', 'Signature'],
  },
  {
    id: 'b3',
    name: 'Liberty Avocado Sourdough',
    description: 'Smashed Haas avocado, crumbled Cotswold cheese, heirloom cherry tomatoes, pumpkin seeds, and hot honey drizzle on toasted rye bread.',
    price: '$19.00',
    category: 'breakfast',
    tags: ['Vegetarian', 'Healthy'],
  },

  // Lunch (11 AM - 4 PM)
  {
    id: 'l1',
    name: 'Traditional British Fish & Chips',
    description: 'Line-caught Atlantic cod in a golden crispy beer batter made with Samuel Smith stout, served with triple-cooked chips, minty mushy peas, and house-made caper tartar sauce.',
    price: '$29.00',
    category: 'lunch',
    tags: ['Award Winning', 'Cask Batter'],
    isSignature: true,
  },
  {
    id: 'l2',
    name: 'The Albion Burger',
    description: 'Dry-aged Pat LaFrieda beef blend, mature West Country English Cheddar, Guinness-caramelized onions, bone marrow aioli, on a toasted brioche bun, served with hand-cut fries.',
    price: '$28.00',
    category: 'lunch',
    tags: ['Dry-Aged', 'Prime'],
    isSignature: true,
  },
  {
    id: 'l3',
    name: 'Smoked Salmon Club',
    description: 'Triple-decker toasted brioche, Scottish smoked salmon, crisp pancetta, butter lettuce, heirloom tomato, and dill cream cheese.',
    price: '$22.00',
    category: 'lunch',
    tags: ['New York Style'],
  },

  // Dinner (4 PM - Midnight)
  {
    id: 'd1',
    name: 'Braised Cask Ale Beef Pie',
    description: 'Slow-braised British beef shin in a rich Samuel Smith oatmeal stout gravy, encased in a buttery, flaky hand-crimped pastry, served with Jersey Royal pomme purée and buttered heirloom carrots.',
    price: '$34.00',
    category: 'dinner',
    tags: ['House Classic', 'Slow-Cooked'],
    isSignature: true,
  },
  {
    id: 'd2',
    name: 'Pan-Roasted Atlantic Halibut',
    description: 'Wild Atlantic halibut fillet, cockle and samphire chowder, saffron potatoes, and chive oil.',
    price: '$45.00',
    category: 'dinner',
    tags: ['Gluten-Free', 'Seafood'],
  },
  {
    id: 'd3',
    name: 'Galloways 14oz Ribeye Steak',
    description: '35-day dry-aged ribeye, charred spring onions, bone marrow butter, triple-cooked chips, and a choice of peppercorn or Stilton blue cheese sauce.',
    price: '$58.00',
    category: 'dinner',
    tags: ['Dry-Aged', 'Premium Steak'],
  },

  // Late Night (Midnight - 6 AM)
  {
    id: 'n1',
    name: 'Midnight Scotch Egg',
    description: 'Soft-boiled farm egg encased in savory Cumberland sausage and panko crumbs, fried golden, served with warm English mustard.',
    price: '$14.00',
    category: 'late-night',
    tags: ['Comfort Food', 'Late Night Exclusive'],
  },
  {
    id: 'n2',
    name: 'The 4 AM Welsh Rarebit',
    description: 'Thick-cut sourdough drenched in a rich sauce of mature English cheddar, Guinness, Worcester sauce, and mustard, grilled until bubbling.',
    price: '$16.00',
    category: 'late-night',
    tags: ['Vegetarian', 'Classic Pub'],
  },
  {
    id: 'n3',
    name: 'Liberty Beef Sliders',
    description: 'Three mini prime beef patties, pub relish, melted Stilton cheese, on toasted mini brioche buns.',
    price: '$19.00',
    category: 'late-night',
    tags: ['Midnight Feast'],
  },

  // Sunday Roast (Sunday Only, All Day)
  {
    id: 'r1',
    name: 'Roast Prime Rib of Beef',
    description: 'Dry-aged Galloway beef sirloin, served with duck-fat roasted potatoes, a towering Yorkshire pudding, honey-glazed parsnips, carrot purée, creamed spinach, and 48-hour bone marrow gravy.',
    price: '$42.00',
    category: 'sunday-roast',
    tags: ['Sunday Legend', 'Traditional'],
    isSignature: true,
  },
  {
    id: 'r2',
    name: 'Roast Orchard Pork Belly',
    description: 'Slow-rolled crispy pork belly, spiced apple purée, crackling, duck-fat potatoes, Yorkshire pudding, and cider gravy.',
    price: '$36.00',
    category: 'sunday-roast',
    tags: ['Slow Roast'],
  },
  {
    id: 'r3',
    name: 'Nut & Wild Mushroom Roast',
    description: 'Savory chestnut, walnut and wild mushroom loaf, roasted potatoes (vegetarian-prep), vegetarian Yorkshire pudding, glazed parsnips, and red wine gravy.',
    price: '$32.00',
    category: 'sunday-roast',
    tags: ['Vegetarian', 'Comfort'],
  },

  // Desserts
  {
    id: 'ds1',
    name: 'The Albion Sticky Toffee Pudding',
    description: 'A dark, moist date sponge drenched in a warm, rich butterscotch sauce, topped with a scoop of double vanilla bean clotted cream ice cream.',
    price: '$15.00',
    category: 'desserts',
    tags: ['Legendary', 'Must Try'],
    isSignature: true,
  },
  {
    id: 'ds2',
    name: 'London Gin & Lemon Posset',
    description: 'Silky, chilled lemon cream infused with botanical London dry gin, served with homemade lavender shortbread biscuits.',
    price: '$14.00',
    category: 'desserts',
    tags: ['Light & Refreshing'],
  },
  {
    id: 'ds3',
    name: 'British Cheese Board',
    description: 'A selection of fine artisanal cheeses: Colston Bassett Stilton, Keen’s Extra Mature Cheddar, and West Country Brie, served with quince paste, oatcakes, and grapes.',
    price: '$24.00',
    category: 'desserts',
    tags: ['Artisanal', 'Whiskey Pairing'],
  },
];

export const DRINKS_MENU: MenuItem[] = [
  // Cocktails
  {
    id: 'c1',
    name: 'The Liberty Manhattan',
    description: 'Michter’s US*1 Rye Whiskey, Carpano Antica sweet vermouth, Angostura bitters, presented in a cherry-wood smoked cloche tableside.',
    price: '$22.00',
    category: 'cocktails',
    tags: ['Tableside Smoke', 'Signature'],
    isSignature: true,
  },
  {
    id: 'c2',
    name: 'The Chelsea Florist',
    description: 'No.3 London Dry Gin, St-Germain Elderflower, cucumber water, fresh lemon, completed with edible gold leaf spray.',
    price: '$19.00',
    category: 'cocktails',
    tags: ['Elegant', 'Floral'],
  },
  {
    id: 'c3',
    name: 'Black Velvet 1897',
    description: 'Guinness Draught floated meticulously over Bollinger Brut Special Cuvée Champagne. A historic members-club classic.',
    price: '$24.00',
    category: 'cocktails',
    tags: ['Royal', 'Historic'],
  },

  // Beers
  {
    id: 'be1',
    name: 'The Albion Cask Stout',
    description: 'Our proprietary stout brewed in collaboration with Yorkshire. Smooth, dark chocolate and roasted barley notes, poured on nitro.',
    price: '$10.00',
    category: 'beers',
    tags: ['Proprietary Stout', 'Nitro Poured'],
    isSignature: true,
  },
  {
    id: 'be2',
    name: 'London Pride Premium Bitter',
    description: 'The quintessential English pale ale. Medium-bodied, superb malty balance, with a grassy hop finish, imported weekly.',
    price: '$11.00',
    category: 'beers',
    tags: ['Imported Cask'],
  },
  {
    id: 'be3',
    name: 'Brooklyn Lager',
    description: 'A New York staple. Dry-hopped amber lager with floral hops and sweet caramel malt notes.',
    price: '$9.00',
    category: 'beers',
    tags: ['New York Craft'],
  },

  // Wines
  {
    id: 'w1',
    name: 'Bollinger Special Cuvée Brut',
    description: 'Champagne, France. A golden-colored, rich and structured Champagne with aromas of roasted apples and peaches.',
    price: '$32.00 / $160.00',
    category: 'wines',
    tags: ['Premium Sparkling'],
  },
  {
    id: 'w2',
    name: 'Ridge Lytton Springs Zinfandel 2021',
    description: 'Dry Creek Valley, California. Elegant and robust red wine with dark plum, pepper, and cedarwood notes.',
    price: '$28.00 / $135.00',
    category: 'wines',
    tags: ['Bold Red'],
  },
  {
    id: 'w3',
    name: 'Cloudy Bay Sauvignon Blanc 2023',
    description: 'Marlborough, New Zealand. Vibrant white wine with intense grapefruit, lime, and passionfruit aromas.',
    price: '$21.00 / $98.00',
    category: 'wines',
    tags: ['Crisp White'],
  },

  // Spirits (Whiskey focus)
  {
    id: 'sp1',
    name: 'The Macallan 18 Year Sherry Oak',
    description: 'Speyside Single Malt Scotch. Robust flavor with dried fruits, warm spices, orange and wood smoke.',
    price: '$45.00',
    category: 'spirits',
    tags: ['Sherry Oak Cask', 'Elite Pour'],
  },
  {
    id: 'sp2',
    name: 'Pappy Van Winkle Family Reserve 15 Year',
    description: 'Kentucky Straight Bourbon. Highly sought-after. Beautiful copper color, sweet vanilla, wood, and spice notes.',
    price: '$95.00',
    category: 'spirits',
    tags: ['Rare Collection'],
  },
  {
    id: 'sp3',
    name: 'Redbreast 12 Year Single Pot Still',
    description: 'Irish Whiskey. Complex spicy, fruity, toasted oak aroma with a rich creamy texture.',
    price: '$18.00',
    category: 'spirits',
    tags: ['Pot Still'],
  },
];

export const EVENTS_LIST: EventItem[] = [
  {
    id: 'e1',
    date: '2026-08-03',
    dayOfWeek: 'Monday',
    title: 'The Jazz Snug Sessions',
    description: 'Cozy up in our fireplace room and listen to the Manhattan Swing Trio. Authentic classic New York jazz.',
    time: '8:00 PM - 11:30 PM',
    category: 'Jazz',
  },
  {
    id: 'e2',
    date: '2026-08-04',
    dayOfWeek: 'Tuesday',
    title: 'Acoustic Heritage Evening',
    description: 'British folk and acoustic blues classics played by world-class local musicians under intimate lights.',
    time: '7:30 PM - 10:30 PM',
    category: 'Acoustic',
  },
  {
    id: 'e3',
    date: '2026-08-05',
    dayOfWeek: 'Wednesday',
    title: 'Premier League Live Broadcast',
    description: 'Catch the big match in our back pub screen with British draft ales and breakfast sandwiches ready.',
    time: '3:00 PM - 5:30 PM',
    category: 'Sport',
  },
  {
    id: 'e4',
    date: '2026-08-06',
    dayOfWeek: 'Thursday',
    title: 'Piano & Port Lounge',
    description: 'Request classic tunes and enjoy selected rare British port flights accompanied by live piano play.',
    time: '8:30 PM - Midnight',
    category: 'Piano Evening',
  },
  {
    id: 'e5',
    date: '2026-08-07',
    dayOfWeek: 'Friday',
    title: 'London Calling: Late-Night DJ',
    description: 'Vinyl DJ set blending British Rock, 80s synth-pop, and upbeat Manhattan indie-dance to keep you going.',
    time: '11:00 PM - 3:30 AM',
    category: 'DJ Set',
  },
  {
    id: 'e6',
    date: '2026-08-08',
    dayOfWeek: 'Saturday',
    title: 'Live British Rock Revival',
    description: 'A live band performing the greatest British rock anthems from Oasis, Queen, Led Zeppelin and The Rolling Stones.',
    time: '9:30 PM - 1:00 AM',
    category: 'British Rock',
  },
];

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'g1',
    url: pubExterior,
    category: 'interiors',
    caption: 'The majestic exterior at dusk on Manhattan streets.',
  },
  {
    id: 'g2',
    url: pubInterior,
    category: 'interiors',
    caption: 'Cozy dark walnut panels and warm spherical glowing snugs.',
  },
  {
    id: 'g3',
    url: fishAndChipsImg,
    category: 'food',
    caption: 'Our award-winning beer-battered cod and triple-cooked chips.',
  },
  {
    id: 'g4',
    url: pintOfAleImg,
    category: 'drinks',
    caption: 'A beautifully poured pint of our signature cask stout on the marble bar.',
  },
  {
    id: 'g5',
    url: stickyToffeeImg,
    category: 'food',
    caption: 'Warm, sticky date sponge with rich dripping butterscotch.',
  },
  // Add some other premium visual-placeholder image URLs for diversity
  {
    id: 'g6',
    url: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=800',
    category: 'drinks',
    caption: 'Crafting signature cocktails at the black marble bar top.',
  },
  {
    id: 'g7',
    url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800',
    category: 'food',
    caption: 'Juicy 35-day dry-aged ribeye steak sizzling on dark slate.',
  },
  {
    id: 'g8',
    url: 'https://images.unsplash.com/photo-1511192336575-5a79af67a629?auto=format&fit=crop&q=80&w=800',
    category: 'events',
    caption: 'Intimate jazz sessions under golden spotlights in the snug.',
  },
];

export const GOOGLE_REVIEWS: ReviewItem[] = [
  {
    id: 'rev1',
    name: 'Charles Sterling',
    rating: 5,
    text: 'Visiting from London and shocked to find a roast in NY that rivaled the best Soho clubs. The Yorkshire pudding was absolutely towering and the cask stout poured on nitro is perfection. Feels like home but with New York electricity.',
    date: '3 days ago',
  },
  {
    id: 'rev2',
    name: 'Madeline Vance',
    rating: 5,
    text: 'A absolute gem. It is open 24 hours but does not feel like a typical late-night diner—it is an ultra-luxurious Gastro Pub. We came in at 3:00 AM for Scotch Eggs and Welsh Rarebit. Impeccable service, incredible leather booth seating.',
    date: '1 week ago',
  },
  {
    id: 'rev3',
    name: 'Richard Henderson',
    rating: 5,
    text: 'The Macallan collection is secondary to none. They smoked my Manhattan tableside and the ambience is pure dark elegance. Perfect spot to host corporate clients or enjoy a warm fireplace after a chilly night.',
    date: '2 weeks ago',
  },
];

export const CAREER_JOBS: CareerJob[] = [
  {
    id: 'j1',
    title: 'Lead Gastronomy Chef',
    department: 'Kitchen',
    type: 'Full-time',
    salary: '$85,000 - $100,000 / year',
    description: 'We are seeking an innovative, passionate Lead Chef to curate and elevate our traditional British-American Gastro Pub menu. You will oversee daily operations, source from NY farms and British importers, and maintain our high culinary standard.',
    requirements: [
      '5+ years experience in a high-end Michelin-starred or premium pub kitchen.',
      'Extensive expertise in classical British roasts, pastries, and baking techniques.',
      'Strong leadership skills with the ability to manage a high-volume, 24-hour kitchen staff.',
      'Rigorous food safety, ordering, and margin control standards.'
    ],
  },
  {
    id: 'j2',
    title: 'Master Mixologist / Bar Manager',
    department: 'Bar & Spirits',
    type: 'Full-time',
    salary: '$65,000 - $75,000 + tips',
    description: 'We are seeking an exceptional Bar Manager and Mixologist to curate our luxury whiskey cellar, draft programs, and premium cocktails. You will design seasonal drink lists and manage our prestigious back-bar program.',
    requirements: [
      'Deep knowledge of classic cocktails, premium whiskeys (Bourbon, Scotch, Irish), and British cask conditioning.',
      'Creative mixology approach with an eye for dramatic luxury tableside presentations.',
      'Experience managing busy Manhattan luxury cocktail bars or exclusive members clubs.',
      'Warm hospitality style with an exceptional memory for regulars.'
    ],
  },
  {
    id: 'j3',
    title: 'Floor Supervisor & Host / Hostess',
    department: 'Hospitality',
    type: 'Full-time / Part-time',
    salary: '$24.00 - $28.00 / hour',
    description: 'Be the welcoming face of The Albion & Liberty. You will coordinate reservation flows, manage our premium seating snugs, and lead servers to deliver a bespoke dining experience.',
    requirements: [
      'Polished appearance, eloquent speech, and warm welcoming demeanor.',
      'Experience with premium Reservation engines (OpenTable, Resy) and VIP seating.',
      'Calm under pressure in high-profile, fast-paced dining rooms.',
      'Passionate about food, wine, and British-American hospitality culture.'
    ],
  },
];

export const JOURNAL_POSTS: JournalPost[] = [
  {
    id: 'post1',
    title: 'The Art of Cask Ale: From London Cellars to Manhattan Bars',
    category: 'Brewing',
    excerpt: 'Conditioned in real oak casks, our beer cellar requires specific temperatures, patience, and direct importing weekly. Explore the rich heritage of live cask ales.',
    content: 'At The Albion & Liberty, we believe a pint is not just poured—it is nurtured. Classical cask ale undergoes a secondary fermentation in the cellar, creating delicate natural carbonation, rich malty aromas, and a smooth mouthfeel. Our cellar is equipped with high-precision temperature controls mimicking historic English limestone cellars, and we import premium bitters and stouts weekly. Here is how our Cellar Master manages this traditional, living brew around the clock...',
    date: 'July 28, 2026',
    readTime: '5 min read',
    imageUrl: 'https://images.unsplash.com/photo-1571613316887-6f8d5cbf7ef7?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'post2',
    title: 'Sourcing the Best of New York State Farms',
    category: 'Culinary Craft',
    excerpt: 'Elevating a Sunday Roast means acquiring the finest dry-aged beef. Here is how we partner with Hudson Valley farms to bring fresh, local produce to your table.',
    content: 'While our culinary soul is British, our heart beat is pure New York. Every vegetable, ribeye, and cheese is hand-selected. We work closely with family-owned Hudson Valley farms to supply premium dry-aged beef and organic poultry. Sourcing locally ensures peak ripeness, low environmental impact, and supports our New York agricultural neighbors, which we mix with West Country British dairy imports for the absolute best pastry consistency...',
    date: 'July 15, 2026',
    readTime: '4 min read',
    imageUrl: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 'post3',
    title: 'Designing the Perfect Late-Night Gastro Menu',
    category: 'Gastronomy',
    excerpt: 'What makes a midnight steak or a Welsh Rarebit at 4:00 AM feel luxurious? Dive into our late-night menu design process.',
    content: 'A true 24-hour venue must respect all hours equally. Feeding late-night theatergoers, off-shift hospitality legends, and night owls is a serious craft. Our culinary team designed specific midnight comfort plates that feel satisfying but elegant. We explore how we balance high-end ingredients, like Stilton and bone marrow, in quick-fired dishes designed to soothe, ground, and elevate your spirit in the quiet, magical Manhattan morning hours...',
    date: 'June 30, 2026',
    readTime: '6 min read',
    imageUrl: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&q=80&w=800',
  },
];
