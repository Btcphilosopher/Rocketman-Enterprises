'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Search, X, Filter, ArrowRight, Sparkles } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { PRODUCTS } from '@/data/products';
import { Product } from '@/types/ecommerce';
import { ProductCanGraphic } from '../product/ProductCanGraphic';

export const SearchDrawer: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, searchQuery, setSearchQuery } = useShop();

  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [zeroProofOnly, setZeroProofOnly] = useState<boolean>(false);
  const [maxPrice, setMaxPrice] = useState<number>(100);
  const [results, setResults] = useState<Product[]>([]);

  useEffect(() => {
    let filtered = [...PRODUCTS];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.style?.toLowerCase().includes(q) ||
          p.tagline.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.ingredients.some((i) => i.toLowerCase().includes(q)) ||
          p.tastingProfile.primaryNotes.some((n) => n.toLowerCase().includes(q))
      );
    }

    if (categoryFilter !== 'ALL') {
      filtered = filtered.filter((p) => p.category === categoryFilter);
    }

    if (zeroProofOnly) {
      filtered = filtered.filter((p) => p.isZeroProof || p.abv === 0);
    }

    filtered = filtered.filter((p) => p.variants[0]?.unitPrice <= maxPrice);

    setResults(filtered);
  }, [searchQuery, categoryFilter, zeroProofOnly, maxPrice]);

  if (!isSearchOpen) return null;

  const SUGGESTIONS = ['NODE ZERO', 'DARKNET', 'NEIPA', '0.0%', 'CITRUS', 'HOODIE', 'FLASK'];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-[#08090a]/95 backdrop-blur-xl p-4 sm:p-8 overflow-y-auto">
      <div className="max-w-4xl mx-auto w-full space-y-6">
        {/* Header bar */}
        <div className="flex items-center justify-between pb-4 border-b border-[#262930]">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-[#00ff66]" />
            <span className="font-display font-bold text-xl text-white">SEARCH THE OPEN NETWORK</span>
          </div>

          <button
            onClick={() => setIsSearchOpen(false)}
            className="p-2 text-neutral-400 hover:text-white rounded hover:bg-neutral-800"
            aria-label="Close search"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Search Input Bar */}
        <div className="relative">
          <input
            type="text"
            placeholder="Search by beer name, style, hop type (Citra, Simcoe), or note (Citrus, Espresso)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            autoFocus
            className="w-full bg-[#121417] border-2 border-[#262930] focus:border-[#00ff66] rounded-lg px-4 py-3.5 pl-12 font-mono text-sm sm:text-base text-white placeholder-neutral-500 focus:outline-none transition-all shadow-xl"
          />
          <Search className="absolute left-4 top-4 w-5 h-5 text-neutral-500" />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-4 top-4 text-neutral-500 hover:text-white font-mono text-xs"
            >
              CLEAR
            </button>
          )}
        </div>

        {/* Quick Suggestion Chips */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-xs text-neutral-500">QUICK SIGNALS:</span>
          {SUGGESTIONS.map((term) => (
            <button
              key={term}
              onClick={() => setSearchQuery(term)}
              className="px-2.5 py-1 bg-neutral-900 border border-neutral-800 hover:border-[#00ff66] text-neutral-300 hover:text-[#00ff66] font-mono text-xs rounded transition-colors"
            >
              {term}
            </button>
          ))}
        </div>

        {/* Filters Controls */}
        <div className="p-4 bg-[#111317] border border-[#22252b] rounded-lg flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-neutral-400 font-bold flex items-center gap-1">
              <Filter className="w-3.5 h-3.5 text-[#00ff66]" /> CATEGORY:
            </span>
            {['ALL', 'BEER', 'ZERO-PROOF', 'MERCH', 'ACCESSORIES'].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategoryFilter(cat)}
                className={`px-2.5 py-1 rounded transition-colors ${
                  categoryFilter === cat
                    ? 'bg-[#00ff66] text-black font-bold'
                    : 'bg-neutral-900 text-neutral-300 border border-neutral-800 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
              <input
                type="checkbox"
                checked={zeroProofOnly}
                onChange={(e) => setZeroProofOnly(e.target.checked)}
                className="accent-[#00ff66] w-4 h-4"
              />
              <span>0.0% ONLY</span>
            </label>
          </div>
        </div>

        {/* Search Results Display */}
        <div className="pt-2">
          <div className="flex items-center justify-between pb-3 text-xs font-mono text-neutral-400">
            <span>FOUND {results.length} MATCHING SIGNALS</span>
          </div>

          {results.length === 0 ? (
            <div className="py-12 text-center space-y-3 bg-[#111317] border border-[#22252b] rounded-lg p-6">
              <p className="font-display font-bold text-lg text-white">NO SIGNAL MATCHED "{searchQuery}"</p>
              <p className="font-mono text-xs text-neutral-400">
                Try searching for 'pale ale', 'stout', 'citra', or '0.0%'.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {results.map((product) => (
                <Link
                  key={product.id}
                  href={`/product/${product.slug}`}
                  onClick={() => setIsSearchOpen(false)}
                  className="p-3 bg-[#111317] border border-[#22252b] hover:border-[#00ff66] rounded-lg flex gap-3 transition-all group"
                >
                  <div className="w-14 h-18 bg-neutral-900 rounded flex items-center justify-center shrink-0">
                    <ProductCanGraphic product={product} size="sm" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="font-mono text-[9px] text-[#00ff66] uppercase">
                      {product.category}
                    </span>
                    <h4 className="font-display font-bold text-sm text-white group-hover:text-[#00ff66] transition-colors uppercase truncate">
                      {product.name}
                    </h4>
                    <p className="font-mono text-[10px] text-neutral-400 truncate">
                      {product.tagline}
                    </p>
                    <p className="font-mono font-bold text-xs text-white pt-1">
                      £{product.variants[0]?.unitPrice.toFixed(2)}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
