'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { X, Trash2, Plus, Minus, ArrowRight, ShieldCheck, ShieldAlert, Tag, Check, Sparkles } from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { ProductCanGraphic } from '../product/ProductCanGraphic';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateQuantity,
    clearCart,
    cartSubtotal,
    discountAmount,
    estimatedShipping,
    cartTotal,
    totalItemCount,
    ageVerified,
    setIsAgeModalOpen,
    activePromo,
    promoCodeInput,
    setPromoCodeInput,
    applyPromoCode,
    removePromoCode,
  } = useShop();

  const [promoMessage, setPromoMessage] = useState<{ text: string; isError: boolean } | null>(null);
  const [isCheckingOutDemo, setIsCheckingOutDemo] = useState(false);
  const [demoOrderSuccess, setDemoOrderSuccess] = useState<any | null>(null);

  if (!isCartOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoCodeInput) return;
    const res = applyPromoCode(promoCodeInput);
    setPromoMessage({ text: res.message, isError: !res.success });
  };

  const handleTriggerCheckout = async () => {
    if (!ageVerified && cart.some((i) => i.product.isAgeRestricted)) {
      setIsAgeModalOpen(true);
      return;
    }

    setIsCheckingOutDemo(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          items: cart,
          customerEmail: 'operator@openbeer.net',
          ageVerifiedConfirmed: true,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setDemoOrderSuccess(data.order);
        clearCart();
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsCheckingOutDemo(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={() => setIsCartOpen(false)}
        aria-hidden="true"
      />

      {/* Cart Panel */}
      <div className="relative w-full max-w-md bg-[#0a0c0f] border-l border-[#262930] h-full flex flex-col z-10 shadow-2xl">
        {/* Header */}
        <div className="p-5 border-b border-[#22252b] flex items-center justify-between bg-[#111317]">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-xl text-white tracking-wide">
              DISPATCH CART
            </span>
            <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2 py-0.5 rounded border border-[#00ff66]/20">
              {totalItemCount} ITEMS
            </span>
          </div>

          <button
            onClick={() => setIsCartOpen(false)}
            className="p-1.5 text-neutral-400 hover:text-white rounded hover:bg-neutral-800"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Age Verification Banner */}
        <div className="px-5 py-2.5 bg-neutral-900 border-b border-neutral-800 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2">
            {ageVerified ? (
              <ShieldCheck className="w-4 h-4 text-[#00ff66]" />
            ) : (
              <ShieldAlert className="w-4 h-4 text-amber-400" />
            )}
            <span className={ageVerified ? 'text-neutral-300' : 'text-amber-400'}>
              {ageVerified ? 'Age verified 18+ for alcohol dispatch' : 'Age verification required'}
            </span>
          </div>
          {!ageVerified && (
            <button
              onClick={() => setIsAgeModalOpen(true)}
              className="text-[10px] text-[#00ff66] underline hover:text-white font-bold"
            >
              Verify
            </button>
          )}
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {demoOrderSuccess ? (
            /* Demo Order Completed Screen */
            <div className="py-8 text-center space-y-4 bg-emerald-950/20 border border-emerald-500/30 p-6 rounded">
              <Sparkles className="w-10 h-10 text-[#00ff66] mx-auto animate-bounce" />
              <h3 className="font-display font-bold text-2xl text-white">ORDER DISPATCHED</h3>
              <p className="font-mono text-xs text-neutral-300">
                Order reference: <span className="text-[#00ff66] font-bold">{demoOrderSuccess.id}</span>
              </p>
              <p className="font-mono text-xs text-neutral-400 leading-relaxed">
                Thank you for testing the BrewDog Open Beer Network prototype slice!
              </p>

              <div className="p-3 bg-neutral-900/80 rounded border border-neutral-800 font-mono text-[11px] text-neutral-400 text-left space-y-1">
                <div>Total: £{demoOrderSuccess.totalAmount.toFixed(2)}</div>
                <div>Status: DEMO DISPATCH CONFIRMED</div>
                <div>Dispatch target: UK EXPRESS NETWORK</div>
              </div>

              <button
                onClick={() => setDemoOrderSuccess(null)}
                className="w-full py-2.5 bg-[#00ff66] text-black font-mono font-bold text-xs uppercase rounded"
              >
                RETURN TO NETWORK SHOP
              </button>
            </div>
          ) : cart.length === 0 ? (
            /* Empty Cart State */
            <div className="py-16 text-center space-y-4">
              <div className="w-16 h-16 bg-neutral-900 border border-neutral-800 rounded-full flex items-center justify-center mx-auto text-neutral-500">
                <X className="w-8 h-8" />
              </div>
              <h3 className="font-display font-bold text-xl text-white">YOUR CART IS EMPTY</h3>
              <p className="font-mono text-xs text-neutral-400 max-w-xs mx-auto">
                No signal detected in your dispatch manifest. Explore our fresh drops or build a custom mixed pack.
              </p>
              <div className="pt-2 flex flex-col gap-2">
                <Link
                  href="/shop"
                  onClick={() => setIsCartOpen(false)}
                  className="inline-block py-3 px-6 bg-[#00ff66] text-black font-mono font-bold text-xs uppercase tracking-wider rounded"
                >
                  EXPLORE BEER RANGE
                </Link>
                <Link
                  href="/mixed-packs"
                  onClick={() => setIsCartOpen(false)}
                  className="inline-block py-2.5 px-6 bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white font-mono text-xs uppercase tracking-wider rounded"
                >
                  BUILD MIXED PACK
                </Link>
              </div>
            </div>
          ) : (
            /* Cart Items List */
            cart.map((item) => (
              <div
                key={item.id}
                className="bg-[#121417] border border-[#22252b] rounded p-3.5 flex gap-3 relative group"
              >
                <div className="w-16 h-20 bg-neutral-900 rounded flex items-center justify-center shrink-0">
                  <ProductCanGraphic product={item.product} size="sm" />
                </div>

                <div className="flex-1 space-y-1">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-display font-bold text-sm text-white uppercase line-clamp-1">
                      {item.product.name}
                    </h4>
                    <button
                      onClick={() => removeFromCart(item.id)}
                      className="text-neutral-500 hover:text-red-400 p-1"
                      aria-label="Remove item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="font-mono text-[10px] text-[#00ff66] uppercase">
                    {item.variant.packSize > 1 ? `${item.variant.packSize}-CAN PACK` : 'SINGLE ITEM'}
                  </p>

                  <div className="pt-2 flex items-center justify-between">
                    {/* Quantity controls */}
                    <div className="flex items-center border border-neutral-800 rounded bg-neutral-900 font-mono text-xs">
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        className="px-2 py-1 text-neutral-400 hover:text-white"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 text-white font-bold">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="px-2 py-1 text-neutral-400 hover:text-white"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="font-mono font-bold text-sm text-white">
                      £{(item.variant.unitPrice * item.quantity).toFixed(2)}
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout */}
        {cart.length > 0 && !demoOrderSuccess && (
          <div className="p-5 bg-[#111317] border-t border-[#22252b] space-y-3">
            {/* Promo code field */}
            <form onSubmit={handleApplyPromo} className="flex gap-2">
              <input
                type="text"
                placeholder="PROMO SIGNAL CODE (e.g. NETWORK10)"
                value={promoCodeInput}
                onChange={(e) => setPromoCodeInput(e.target.value)}
                className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-3 py-1.5 font-mono text-xs text-white placeholder-neutral-600 focus:outline-none focus:border-[#00ff66]"
              />
              <button
                type="submit"
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-mono text-xs font-bold rounded"
              >
                APPLY
              </button>
            </form>

            {promoMessage && (
              <p
                className={`text-[10px] font-mono ${
                  promoMessage.isError ? 'text-red-400' : 'text-[#00ff66]'
                }`}
              >
                {promoMessage.text}
              </p>
            )}

            {/* Calculations Breakdown */}
            <div className="space-y-1.5 font-mono text-xs text-neutral-400 pt-2 border-t border-neutral-800">
              <div className="flex justify-between">
                <span>SUBTOTAL</span>
                <span className="text-white">£{cartSubtotal.toFixed(2)}</span>
              </div>

              {discountAmount > 0 && (
                <div className="flex justify-between text-[#00ff66]">
                  <span>DISCOUNT ({activePromo?.code})</span>
                  <span>-£{discountAmount.toFixed(2)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>ESTIMATED UK DISPATCH</span>
                <span className="text-white">
                  {estimatedShipping === 0 ? 'FREE' : `£${estimatedShipping.toFixed(2)}`}
                </span>
              </div>

              <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-neutral-800">
                <span>TOTAL DISPATCH</span>
                <span className="text-[#00ff66]">£{cartTotal.toFixed(2)}</span>
              </div>
            </div>

            {/* Demo Notice */}
            <p className="text-[10px] font-mono text-neutral-500 text-center">
              PROTOTYPE DEMO CHECKOUT — NO REAL PAYMENT REQUIRED
            </p>

            {/* Checkout Button */}
            <button
              onClick={handleTriggerCheckout}
              disabled={isCheckingOutDemo}
              className="w-full py-3.5 bg-[#00ff66] text-black font-mono font-bold text-sm tracking-wider uppercase hover:bg-[#39ff14] transition-all rounded shadow-lg flex items-center justify-center gap-2"
            >
              <span>{isCheckingOutDemo ? 'GENERATING DISPATCH...' : 'CONFIRM DEMO DISPATCH'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
