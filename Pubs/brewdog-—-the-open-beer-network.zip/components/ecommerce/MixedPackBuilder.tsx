'use client';

import React, { useState } from 'react';
import { Plus, Minus, Check, ShoppingBag, RotateCcw, Sparkles, Filter } from 'lucide-react';
import { PRODUCTS } from '@/data/products';
import { Product, MixedPack } from '@/types/ecommerce';
import { useShop } from '@/context/ShopContext';
import { ProductCanGraphic } from '../product/ProductCanGraphic';

export const MixedPackBuilder: React.FC = () => {
  const { addMixedPackToCart } = useShop();

  const [packSize, setPackSize] = useState<6 | 12 | 24>(12);
  const [zeroProofOnly, setZeroProofOnly] = useState<boolean>(false);
  const [flavourFilter, setFlavourFilter] = useState<string>('ALL');

  // Quantities per product ID
  const [selectedCounts, setSelectedCounts] = useState<{ [productId: string]: number }>({});
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  // Available beers filter
  const availableBeers = PRODUCTS.filter((p) => {
    if (p.category !== 'BEER' && p.category !== 'ZERO-PROOF') return false;
    if (zeroProofOnly && !p.isZeroProof && p.abv > 0) return false;
    if (flavourFilter !== 'ALL') {
      const matchFlavour = p.tastingProfile.primaryNotes.some((n) =>
        n.toLowerCase().includes(flavourFilter.toLowerCase())
      );
      if (!matchFlavour) return false;
    }
    return true;
  });

  const totalSelectedCans = Object.values(selectedCounts).reduce((a, b) => a + b, 0);
  const remainingSlots = packSize - totalSelectedCans;

  // Pricing calculation based on pack size and average unit discount
  const basePricePerCan = 2.10;
  const packDiscountFactor = packSize === 24 ? 0.8 : packSize === 12 ? 0.88 : 0.95;
  const totalPrice = Math.max(12, totalSelectedCans * basePricePerCan * packDiscountFactor);

  const handleUpdateCount = (productId: string, delta: number) => {
    const current = selectedCounts[productId] || 0;
    const next = current + delta;
    if (next < 0) return;
    if (delta > 0 && remainingSlots <= 0) return;

    setSelectedCounts((prev) => ({
      ...prev,
      [productId]: next,
    }));
  };

  const handleReset = () => {
    setSelectedCounts({});
  };

  const handleAddToCart = () => {
    if (remainingSlots > 0) return;

    const items = Object.entries(selectedCounts)
      .filter(([_, qty]) => qty > 0)
      .map(([id, qty]) => ({
        product: PRODUCTS.find((p) => p.id === id)!,
        quantity: qty,
      }));

    const pack: MixedPack = {
      id: `mix-${Date.now()}`,
      name: `${packSize}-CAN OPEN NETWORK MIXED PACK`,
      size: packSize,
      isZeroProofOnly: zeroProofOnly,
      items,
      totalCans: totalSelectedCans,
      totalPrice: parseFloat(totalPrice.toFixed(2)),
    };

    addMixedPackToCart(pack);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2000);
  };

  const FLAVOUR_FILTERS = ['ALL', 'Citrus', 'Bitter', 'Juicy', 'Dark', 'Crisp', 'Sour'];

  return (
    <div className="bg-[#0e1014] border border-[#22252b] rounded-xl p-5 sm:p-8 space-y-8 shadow-2xl relative overflow-hidden">
      {/* Tech Background Grid */}
      <div className="absolute inset-0 bg-tech-grid opacity-10 pointer-events-none" />

      {/* Title Header */}
      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-[#22252b]">
        <div>
          <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
            BUILDER ENGINE v2.4
          </span>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-white mt-2 uppercase tracking-wide">
            CUSTOM MIXED PACK BUILDER
          </h2>
          <p className="font-mono text-xs text-neutral-400 mt-1 max-w-xl">
            Curate your own custom flight. Mix pale ales, stouts, NEIPAs and 0.0% options to match your exact latency profile.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white font-mono text-xs rounded transition-colors self-start md:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>RESET BUILD</span>
        </button>
      </div>

      {/* Step 1 & 2 Controls: Pack Size & Alcohol Mode */}
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pack Size Selection */}
        <div className="space-y-2">
          <label className="font-mono text-xs text-neutral-400 font-bold uppercase">
            1. SELECT PACK CAPACITY:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {[6, 12, 24].map((size) => (
              <button
                key={size}
                onClick={() => {
                  setPackSize(size as 6 | 12 | 24);
                  setSelectedCounts({});
                }}
                className={`py-3 px-2 rounded font-mono text-xs sm:text-sm font-bold border transition-all ${
                  packSize === size
                    ? 'bg-[#00ff66] text-black border-[#00ff66] shadow-lg shadow-[#00ff66]/10'
                    : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                }`}
              >
                {size} CANS
                <span className="block text-[9px] font-normal opacity-80 mt-0.5">
                  {size === 24 ? 'SAVE 20%' : size === 12 ? 'SAVE 12%' : 'STANDARD'}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Mode & Flavour Filters */}
        <div className="space-y-2">
          <label className="font-mono text-xs text-neutral-400 font-bold uppercase">
            2. FLAVOUR & ALCOHOL PROFILE:
          </label>
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <button
              onClick={() => setZeroProofOnly(!zeroProofOnly)}
              className={`px-3 py-2 rounded font-mono text-xs font-bold border transition-all ${
                zeroProofOnly
                  ? 'bg-[#00ff66] text-black border-[#00ff66]'
                  : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:text-white'
              }`}
            >
              0.0% ZERO-PROOF ONLY
            </button>

            <div className="flex flex-wrap items-center gap-1">
              {FLAVOUR_FILTERS.map((f) => (
                <button
                  key={f}
                  onClick={() => setFlavourFilter(f)}
                  className={`px-2 py-1 rounded font-mono text-[10px] uppercase border transition-colors ${
                    flavourFilter === f
                      ? 'bg-amber-400 text-black font-bold border-amber-400'
                      : 'bg-neutral-900 text-neutral-400 border-neutral-800 hover:text-white'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Slot Capacity Progress Bar */}
      <div className="relative z-10 bg-[#12151a] border border-[#22252b] p-4 rounded-lg space-y-2">
        <div className="flex items-center justify-between font-mono text-xs">
          <span className="text-neutral-300 font-bold">
            PACK SLOTS: {totalSelectedCans} / {packSize} CANS FILLED
          </span>
          <span className={remainingSlots === 0 ? 'text-[#00ff66] font-bold' : 'text-amber-400'}>
            {remainingSlots === 0 ? 'PACK FULL — READY TO ADD' : `${remainingSlots} SLOTS REMAINING`}
          </span>
        </div>

        <div className="w-full bg-neutral-900 h-3 rounded-full overflow-hidden p-0.5 border border-neutral-800">
          <div
            className="bg-[#00ff66] h-full rounded-full transition-all duration-300"
            style={{ width: `${(totalSelectedCans / packSize) * 100}%` }}
          />
        </div>
      </div>

      {/* Product Selection Grid */}
      <div className="relative z-10 space-y-3">
        <h3 className="font-mono text-xs text-neutral-400 font-bold uppercase">
          3. ADD CANS TO YOUR FLIGHT:
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {availableBeers.map((beer) => {
            const count = selectedCounts[beer.id] || 0;
            return (
              <div
                key={beer.id}
                className={`p-3 bg-[#111317] border rounded-lg transition-all flex flex-col justify-between ${
                  count > 0 ? 'border-[#00ff66] bg-[#00ff66]/5' : 'border-[#22252b] hover:border-neutral-700'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-16 shrink-0">
                    <ProductCanGraphic product={beer} size="sm" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="font-mono text-[9px] text-[#00ff66] font-bold">
                      {beer.abv}% ABV
                    </span>
                    <h4 className="font-display font-bold text-sm text-white uppercase truncate">
                      {beer.name}
                    </h4>
                    <p className="font-mono text-[10px] text-neutral-400 truncate">
                      {beer.style}
                    </p>
                  </div>
                </div>

                {/* Counter buttons */}
                <div className="pt-3 flex items-center justify-between border-t border-[#22252b] mt-3">
                  <span className="font-mono text-xs font-bold text-neutral-300">
                    {count} IN PACK
                  </span>

                  <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded">
                    <button
                      onClick={() => handleUpdateCount(beer.id, -1)}
                      disabled={count === 0}
                      className="p-1.5 text-neutral-400 hover:text-white disabled:opacity-30"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="px-2 font-mono font-bold text-xs text-white">{count}</span>
                    <button
                      onClick={() => handleUpdateCount(beer.id, 1)}
                      disabled={remainingSlots <= 0}
                      className="p-1.5 text-neutral-400 hover:text-white disabled:opacity-30"
                    >
                      <Plus className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Add To Cart Action */}
      <div className="relative z-10 pt-4 border-t border-[#22252b] flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="font-mono text-xs text-neutral-400">ESTIMATED PACK PRICE:</div>
          <div className="font-mono font-bold text-2xl text-[#00ff66]">
            £{totalPrice.toFixed(2)}
          </div>
        </div>

        <button
          onClick={handleAddToCart}
          disabled={remainingSlots > 0}
          className={`w-full sm:w-auto py-3.5 px-8 font-mono font-bold text-sm tracking-wider uppercase rounded transition-all flex items-center justify-center gap-2 ${
            addedSuccess
              ? 'bg-emerald-500 text-black'
              : remainingSlots > 0
              ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
              : 'bg-[#00ff66] text-black hover:bg-[#39ff14] shadow-lg shadow-[#00ff66]/20'
          }`}
        >
          {addedSuccess ? (
            <>
              <Check className="w-4 h-4" />
              <span>PACK ADDED TO DISPATCH</span>
            </>
          ) : remainingSlots > 0 ? (
            <span>ADD {remainingSlots} MORE CANS TO COMPLETE</span>
          ) : (
            <>
              <ShoppingBag className="w-4 h-4" />
              <span>ADD {packSize}-PACK TO CART (£{totalPrice.toFixed(2)})</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
