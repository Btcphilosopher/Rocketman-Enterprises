'use client';

import React from 'react';
import { Product } from '@/types/ecommerce';

interface ProductCanGraphicProps {
  product: Product;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const ProductCanGraphic: React.FC<ProductCanGraphicProps> = ({
  product,
  size = 'md',
  className = '',
}) => {
  const dimensions = {
    sm: 'w-24 h-40',
    md: 'w-36 h-60',
    lg: 'w-48 h-80',
    xl: 'w-64 h-104',
  }[size];

  const primaryImage = product.images.find((img) => img.isPrimary) || product.images[0];
  const canColor = primaryImage?.canColorHex || '#181b20';
  const accentColor = primaryImage?.accentColorHex || '#00ff66';

  return (
    <div className={`relative flex items-center justify-center group ${dimensions} ${className}`}>
      {/* Shadow */}
      <div className="absolute -bottom-3 w-3/4 h-4 bg-black/80 blur-md rounded-full group-hover:scale-105 transition-transform duration-300" />

      {/* Main Can SVG Container */}
      <div className="relative w-full h-full transform transition-transform duration-300 group-hover:-translate-y-1 group-hover:rotate-1">
        <svg
          viewBox="0 0 200 340"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-full drop-shadow-2xl"
        >
          <defs>
            {/* Can Metallic Top Gradient */}
            <linearGradient id="lidGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#8c939e" />
              <stop offset="30%" stopColor="#d1d5db" />
              <stop offset="50%" stopColor="#f3f4f6" />
              <stop offset="70%" stopColor="#9ca3af" />
              <stop offset="100%" stopColor="#6b7280" />
            </linearGradient>

            {/* Can Body Cylindrical Shading */}
            <linearGradient id={`bodyGrad-${product.id}`} x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#000000" stopOpacity="0.75" />
              <stop offset="15%" stopColor={canColor} />
              <stop offset="50%" stopColor={canColor} />
              <stop offset="85%" stopColor={canColor} />
              <stop offset="100%" stopColor="#000000" stopOpacity="0.8" />
            </linearGradient>

            {/* Metallic Shine Overlay */}
            <linearGradient id="shineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#ffffff" stopOpacity="0" />
              <stop offset="25%" stopColor="#ffffff" stopOpacity="0.12" />
              <stop offset="30%" stopColor="#ffffff" stopOpacity="0.25" />
              <stop offset="35%" stopColor="#ffffff" stopOpacity="0.05" />
              <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
            </linearGradient>

            <clipPath id={`canClip-${product.id}`}>
              {/* Can Silhouette Body */}
              <path d="M 35 45 C 35 35 165 35 165 45 L 168 295 C 168 305 155 315 100 315 C 45 315 32 305 32 295 Z" />
            </clipPath>
          </defs>

          {/* Can Rim & Pull Tab Lid */}
          <path d="M 45 20 C 45 12 155 12 155 20 L 160 38 C 160 42 150 46 100 46 C 50 46 40 42 40 38 Z" fill="url(#lidGrad)" />
          {/* Inner Lid Rim */}
          <ellipse cx="100" cy="22" rx="48" ry="8" fill="#4b5563" stroke="#9ca3af" strokeWidth="1" />
          {/* Pull tab outline */}
          <ellipse cx="100" cy="22" rx="12" ry="4" fill="#d1d5db" />
          <circle cx="100" cy="22" r="3" fill="#374151" />

          {/* Can Neck Taper */}
          <path d="M 40 38 L 35 48 C 35 48 165 48 165 48 L 160 38 Z" fill="url(#lidGrad)" />

          {/* Can Main Body */}
          <path
            d="M 35 48 L 165 48 L 168 295 C 168 305 155 315 100 315 C 45 315 32 305 32 295 Z"
            fill={`url(#bodyGrad-${product.id})`}
          />

          {/* Clipped Label Graphics inside the Can Body */}
          <g clipPath={`url(#canClip-${product.id})`}>
            {/* Custom Brand Graphic depending on Product Code */}

            {/* NODE ZERO Vertical Stripe */}
            {product.code.includes('NZ') && (
              <rect x="90" y="48" width="20" height="260" fill={accentColor} />
            )}

            {/* PACKET LOSS Red Panel */}
            {product.code.includes('PL') && (
              <rect x="32" y="100" width="136" height="120" fill={accentColor} opacity="0.9" />
            )}

            {/* PROTOCOL PILS Cobalt Badge */}
            {product.code.includes('PP') && (
              <rect x="32" y="60" width="136" height="30" fill={accentColor} />
            )}

            {/* MESH NETWORK Mesh Lines */}
            {product.code.includes('MN') && (
              <g stroke="#000000" strokeWidth="1" opacity="0.3">
                <line x1="40" y1="80" x2="160" y2="200" />
                <line x1="160" y1="80" x2="40" y2="200" />
                <line x1="40" y1="140" x2="160" y2="140" />
                <circle cx="100" cy="140" r="35" fill="none" stroke="#00ff66" strokeWidth="2" />
              </g>
            )}

            {/* DARKNET Copper Stamp */}
            {product.code.includes('DS') && (
              <rect x="40" y="80" width="120" height="180" fill="none" stroke={accentColor} strokeWidth="2" strokeDasharray="6 4" />
            )}

            {/* ZERO PROOF Large 0.0% Badge */}
            {product.isZeroProof && (
              <g>
                <rect x="45" y="65" width="110" height="24" fill={accentColor} />
                <text x="100" y="82" fill="#000000" fontSize="14" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  0.0% ABV
                </text>
              </g>
            )}

            {/* Brand Logo Header: BREWDOG Dog Head silhouette */}
            <path
              d="M 92 88 L 100 78 L 108 88 L 105 102 L 95 102 Z"
              fill={product.isZeroProof ? '#000000' : '#ffffff'}
            />

            {/* BREWDOG Brand Typography */}
            <text
              x="100"
              y="125"
              fill={product.code.includes('PL') ? '#ffffff' : (product.code.includes('MN') ? '#000000' : '#ffffff')}
              fontSize="16"
              fontWeight="900"
              letterSpacing="2"
              textAnchor="middle"
              fontFamily="var(--font-display), sans-serif"
            >
              BREWDOG
            </text>

            <text
              x="100"
              y="140"
              fill={accentColor}
              fontSize="8"
              fontWeight="bold"
              letterSpacing="1.5"
              textAnchor="middle"
              fontFamily="var(--font-mono), monospace"
            >
              OPEN BEER NETWORK
            </text>

            {/* Product Name Big Typography */}
            <text
              x="100"
              y="175"
              fill={product.code.includes('MN') ? '#000000' : '#ffffff'}
              fontSize="20"
              fontWeight="900"
              letterSpacing="1"
              textAnchor="middle"
              fontFamily="var(--font-display), sans-serif"
            >
              {product.name}
            </text>

            {/* Style / ABV */}
            <text
              x="100"
              y="195"
              fill="#9ca3af"
              fontSize="9"
              letterSpacing="1"
              textAnchor="middle"
              fontFamily="var(--font-mono), monospace"
            >
              {product.style?.toUpperCase()} • {product.abv}% ABV
            </text>

            {/* Tagline microprint */}
            <text
              x="100"
              y="225"
              fill={accentColor}
              fontSize="7"
              fontWeight="bold"
              letterSpacing="1"
              textAnchor="middle"
              fontFamily="var(--font-mono), monospace"
            >
              {product.tagline}
            </text>

            {/* Code identifier badge at bottom of label */}
            <rect x="65" y="255" width="70" height="16" fill="#000000" opacity="0.6" rx="2" />
            <text
              x="100"
              y="266"
              fill="#ffffff"
              fontSize="8"
              fontWeight="bold"
              textAnchor="middle"
              fontFamily="var(--font-mono), monospace"
            >
              {product.code}
            </text>
          </g>

          {/* Shine Reflection Overlay */}
          <path
            d="M 35 48 L 165 48 L 168 295 C 168 305 155 315 100 315 C 45 315 32 305 32 295 Z"
            fill="url(#shineGrad)"
            pointerEvents="none"
          />

          {/* Bottom Chime Metallic Rim */}
          <path d="M 32 295 C 32 305 45 315 100 315 C 155 315 168 305 168 295 L 162 306 C 152 316 140 322 100 322 C 60 322 48 316 38 306 Z" fill="url(#lidGrad)" />
        </svg>
      </div>
    </div>
  );
};
