'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { Heart, ShoppingBag, Check, ShieldAlert, Sparkles, Star } from 'lucide-react';
import { Product, ProductVariant } from '@/types/ecommerce';
import { useShop } from '@/context/ShopContext';
import { ProductCanGraphic } from './ProductCanGraphic';

interface ProductCardProps {
  product: Product;
  compact?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, compact = false }) => {
  const { addToCart, wishlist, toggleWishlist, ageVerified, setIsAgeModalOpen } = useShop();

  // Selected variant state (default to middle/12-pack or first variant)
  const [selectedVariantIndex, setSelectedVariantIndex] = useState<number>(
    product.variants.length > 1 ? 1 : 0
  );
  const [addedSuccess, setAddedSuccess] = useState<boolean>(false);

  const isWishlisted = wishlist.includes(product.id);
  const currentVariant = product.variants[selectedVariantIndex] || product.variants[0];

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (product.isAgeRestricted && !ageVerified) {
      setIsAgeModalOpen(true);
      return;
    }

    addToCart(product, currentVariant, 1);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2000);
  };

  const handleToggleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product.id);
  };

  return (
    <div className="group relative bg-[#111317] border border-[#22252b] hover:border-[#00ff66]/50 rounded-lg p-4 sm:p-5 flex flex-col justify-between transition-all duration-300 hover:shadow-xl hover:shadow-[#00ff66]/5 overflow-hidden">
      {/* Background Subtle Tech Grid */}
      <div className="absolute inset-0 bg-tech-grid opacity-10 pointer-events-none" />

      {/* Top Badges */}
      <div className="relative z-10 flex items-start justify-between gap-2 mb-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {product.isZeroProof ? (
            <span className="px-2 py-0.5 bg-[#00ff66] text-black font-mono font-bold text-[10px] tracking-wider uppercase rounded">
              0.0% ABV
            </span>
          ) : (
            <span className="px-2 py-0.5 bg-neutral-800 text-neutral-300 border border-neutral-700 font-mono font-medium text-[10px] tracking-wider uppercase rounded">
              {product.abv}% ABV
            </span>
          )}

          {product.isLimitedRelease && (
            <span className="px-2 py-0.5 bg-amber-500/20 text-amber-400 border border-amber-500/40 font-mono text-[10px] tracking-wider uppercase rounded">
              LIMITED DROP
            </span>
          )}

          <span className="px-1.5 py-0.5 bg-neutral-900 text-neutral-400 font-mono text-[9px] uppercase border border-neutral-800 rounded">
            {product.code}
          </span>
        </div>

        {/* Wishlist Button */}
        <button
          onClick={handleToggleWishlist}
          className={`p-1.5 rounded-full transition-colors ${
            isWishlisted
              ? 'text-red-500 bg-red-500/10'
              : 'text-neutral-500 hover:text-white bg-neutral-900/80 hover:bg-neutral-800'
          }`}
          aria-label="Toggle wishlist"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Center Image / Can Render */}
      <Link href={`/product/${product.slug}`} className="relative z-10 my-2 flex justify-center items-center py-2">
        <ProductCanGraphic product={product} size={compact ? 'sm' : 'md'} />
      </Link>

      {/* Content Details */}
      <div className="relative z-10 mt-2 space-y-2">
        {/* Category / Style */}
        <div className="flex items-center justify-between text-[11px] font-mono text-neutral-400">
          <span>{product.style?.toUpperCase()}</span>
          {product.rating > 0 && (
            <div className="flex items-center gap-1 text-amber-400 text-[10px]">
              <Star className="w-3 h-3 fill-amber-400" />
              <span>{product.rating}</span>
            </div>
          )}
        </div>

        {/* Product Title */}
        <Link href={`/product/${product.slug}`} className="block">
          <h3 className="font-display font-bold text-lg sm:text-xl text-white group-hover:text-[#00ff66] transition-colors uppercase tracking-wide leading-snug">
            {product.name}
          </h3>
        </Link>

        {/* Tagline / Brand Language */}
        <p className="font-mono text-[11px] text-[#00ff66] font-semibold tracking-wider uppercase line-clamp-1">
          {product.tagline}
        </p>

        {/* Tasting Notes Chips */}
        <div className="flex flex-wrap gap-1 pt-1">
          {product.tastingProfile.primaryNotes.slice(0, 3).map((note, idx) => (
            <span
              key={idx}
              className="px-1.5 py-0.5 bg-neutral-900 text-neutral-300 font-mono text-[9px] rounded border border-neutral-800"
            >
              {note}
            </span>
          ))}
        </div>

        {/* Pack Size Selector */}
        {product.variants.length > 1 && (
          <div className="pt-2 flex items-center gap-1 font-mono text-[10px]">
            <span className="text-neutral-500 uppercase mr-1">PACK:</span>
            {product.variants.map((v, i) => (
              <button
                key={v.id}
                onClick={(e) => {
                  e.preventDefault();
                  setSelectedVariantIndex(i);
                }}
                className={`px-2 py-1 rounded transition-all ${
                  selectedVariantIndex === i
                    ? 'bg-[#00ff66]/20 border border-[#00ff66] text-[#00ff66] font-bold'
                    : 'bg-neutral-900 border border-neutral-800 text-neutral-400 hover:text-white'
                }`}
              >
                {v.packSize > 1 ? `${v.packSize} CAN` : '1 UNIT'}
              </button>
            ))}
          </div>
        )}

        {/* Price & Add to Cart Footer */}
        <div className="pt-3 flex items-center justify-between border-t border-[#22252b]">
          <div>
            <div className="font-mono font-bold text-lg text-white">
              £{currentVariant.unitPrice.toFixed(2)}
            </div>
            {currentVariant.compareAtPrice && (
              <span className="font-mono text-[10px] text-neutral-500 line-through">
                £{currentVariant.compareAtPrice.toFixed(2)}
              </span>
            )}
          </div>

          <button
            onClick={handleAddToCart}
            disabled={currentVariant.inventoryStatus === 'SOLD_OUT'}
            className={`px-3.5 py-2 rounded font-mono font-bold text-xs tracking-wider uppercase transition-all flex items-center gap-1.5 ${
              addedSuccess
                ? 'bg-emerald-500 text-black'
                : currentVariant.inventoryStatus === 'SOLD_OUT'
                ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                : 'bg-[#00ff66] text-black hover:bg-[#39ff14] active:scale-95'
            }`}
          >
            {addedSuccess ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>ADDED</span>
              </>
            ) : currentVariant.inventoryStatus === 'SOLD_OUT' ? (
              <span>SOLD OUT</span>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>ADD</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
