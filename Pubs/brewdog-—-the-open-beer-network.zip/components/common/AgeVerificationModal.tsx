'use client';

import React, { useState } from 'react';
import { ShieldAlert, ShieldCheck, Lock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useShop } from '@/context/ShopContext';

export const AgeVerificationModal: React.FC = () => {
  const { isAgeModalOpen, setIsAgeModalOpen, ageVerified, verifyAge } = useShop();
  const [denied, setDenied] = useState(false);

  if (!isAgeModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md transition-all">
      <div className="relative w-full max-w-md bg-[#0e1014] border border-[#262930] p-6 sm:p-8 rounded-lg shadow-2xl space-y-6">
        {/* Header Icon */}
        <div className="flex justify-center">
          <div className="w-14 h-14 bg-neutral-900 border border-[#00ff66]/40 rounded-full flex items-center justify-center text-[#00ff66]">
            <Lock className="w-7 h-7" />
          </div>
        </div>

        {/* Title */}
        <div className="text-center space-y-2">
          <span className="font-mono text-[10px] tracking-widest text-[#00ff66] uppercase bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20">
            NETWORK SIGNAL CHECK
          </span>
          <h2 className="font-display font-bold text-2xl text-white tracking-wide">
            AGE VERIFICATION REQUIRED
          </h2>
          <p className="text-xs font-mono text-neutral-400 leading-relaxed">
            The Open Beer Network contains alcohol-related products. You must be of legal drinking age in your region (18+ in the UK) to enter.
          </p>
        </div>

        {denied ? (
          <div className="p-4 bg-red-950/40 border border-red-500/40 rounded text-center space-y-3">
            <AlertTriangle className="w-6 h-6 text-red-400 mx-auto" />
            <p className="font-mono text-xs text-red-300">
              Access restricted to legal drinking age operators only.
            </p>
            <p className="text-[11px] text-neutral-400 font-mono">
              You may still browse our <a href="/zero-proof" onClick={() => setIsAgeModalOpen(false)} className="text-[#00ff66] underline font-bold">Zero-Proof 0.0% Collection</a>.
            </p>
            <button
              onClick={() => setDenied(false)}
              className="text-[10px] font-mono text-neutral-400 hover:text-white underline mt-2"
            >
              Retry verification
            </button>
          </div>
        ) : (
          /* Action buttons */
          <div className="space-y-3 pt-2">
            <button
              onClick={() => verifyAge(true)}
              className="w-full py-3.5 px-4 bg-[#00ff66] text-black font-mono font-bold text-sm tracking-wider uppercase hover:bg-[#39ff14] transition-all rounded shadow-lg flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>I AM 18 YEARS OR OLDER</span>
            </button>

            <button
              onClick={() => setDenied(true)}
              className="w-full py-3 px-4 bg-neutral-900 border border-neutral-700 text-neutral-300 font-mono text-xs tracking-wider uppercase hover:border-neutral-500 hover:text-white transition-all rounded"
            >
              I AM UNDER 18 YEARS OLD
            </button>
          </div>
        )}

        {/* Footer info */}
        <div className="pt-2 text-center border-t border-[#22252b]">
          <p className="text-[10px] font-mono text-neutral-500">
            Drink responsibly. Learn more at drinkaware.co.uk
          </p>
        </div>
      </div>
    </div>
  );
};
