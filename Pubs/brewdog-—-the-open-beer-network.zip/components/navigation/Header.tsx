'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Search,
  ShoppingBag,
  Heart,
  User,
  Globe,
  Menu,
  ShieldCheck,
  ShieldAlert,
  X,
  Sparkles,
} from 'lucide-react';
import { useShop } from '@/context/ShopContext';
import { MobileMenu } from './MobileMenu';

export const Header: React.FC = () => {
  const pathname = usePathname();
  const {
    totalItemCount,
    setIsCartOpen,
    setIsSearchOpen,
    wishlist,
    ageVerified,
    setIsAgeModalOpen,
    region,
    setRegion,
  } = useShop();

  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isRegionDropdownOpen, setIsRegionDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { href: '/shop', label: 'SHOP' },
    { href: '/beer', label: 'BEER' },
    { href: '/zero-proof', label: 'ZERO-PROOF', badge: '0.0%' },
    { href: '/drops', label: 'NETWORK DROPS', highlight: true },
    { href: '/mixed-packs', label: 'MIXED PACKS' },
    { href: '/merch', label: 'MERCH' },
    { href: '/accessories', label: 'ACCESSORIES' },
    { href: '/brew-lab', label: 'BREW LAB' },
    { href: '/our-story', label: 'OUR STORY' },
  ];

  const REGIONS = ['UK (£)', 'EU (€)', 'US ($)', 'GLOBAL (BTC/GBP)'];

  return (
    <>
      <header
        className={`sticky top-0 z-40 bg-[#08090a]/95 backdrop-blur-md border-b border-[#22252b] transition-all duration-300 ${
          isScrolled ? 'py-2.5 shadow-2xl' : 'py-4'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between gap-4">
            {/* Mobile menu button */}
            <div className="flex items-center gap-2 lg:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(true)}
                className="p-2 text-neutral-300 hover:text-[#00ff66] focus:outline-none focus:ring-1 focus:ring-[#00ff66]"
                aria-label="Open mobile menu"
              >
                <Menu className="w-6 h-6" />
              </button>
            </div>

            {/* Brand Logo & Dog Head */}
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2.5 group">
                {/* Dog Head Icon SVG */}
                <div className="w-8 h-8 sm:w-9 sm:h-9 bg-neutral-900 border border-neutral-700 rounded-sm flex items-center justify-center group-hover:border-[#00ff66] transition-colors p-1">
                  <svg viewBox="0 0 100 100" className="w-full h-full fill-white group-hover:fill-[#00ff66] transition-colors">
                    <path d="M 50 10 L 85 45 L 75 85 L 50 95 L 25 85 L 15 45 Z" />
                    <circle cx="35" cy="45" r="6" fill="#08090a" />
                    <circle cx="65" cy="45" r="6" fill="#08090a" />
                    <path d="M 42 65 L 50 72 L 58 65 Z" fill="#08090a" />
                  </svg>
                </div>

                <div className="flex flex-col">
                  <span className="font-display font-bold tracking-widest text-lg sm:text-xl text-white group-hover:text-[#00ff66] transition-colors uppercase leading-none">
                    BREWDOG
                  </span>
                  <span className="font-mono text-[9px] tracking-widest text-neutral-400 font-medium uppercase mt-0.5">
                    THE OPEN BEER NETWORK
                  </span>
                </div>
              </Link>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden xl:flex items-center gap-6" aria-label="Main navigation">
              {navLinks.map((link) => {
                const isActive = pathname === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={`font-mono text-xs tracking-wider uppercase transition-colors relative py-1 ${
                      isActive
                        ? 'text-[#00ff66] font-bold'
                        : link.highlight
                        ? 'text-amber-400 hover:text-amber-300 font-semibold'
                        : 'text-neutral-300 hover:text-[#00ff66]'
                    }`}
                  >
                    {link.label}
                    {link.badge && (
                      <span className="ml-1.5 px-1 py-0.5 bg-[#00ff66]/20 text-[#00ff66] text-[9px] rounded font-bold border border-[#00ff66]/30">
                        {link.badge}
                      </span>
                    )}
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#00ff66]" />
                    )}
                  </Link>
                );
              })}
            </nav>

            {/* Header Right Actions */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Region Selector */}
              <div className="relative hidden md:block">
                <button
                  onClick={() => setIsRegionDropdownOpen(!isRegionDropdownOpen)}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded bg-neutral-900 border border-neutral-800 text-xs font-mono text-neutral-300 hover:border-neutral-700 hover:text-white transition-all"
                  aria-label="Select Region"
                >
                  <Globe className="w-3.5 h-3.5 text-[#00ff66]" />
                  <span>{region}</span>
                </button>

                {isRegionDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-36 bg-[#121417] border border-[#262930] rounded shadow-2xl py-1 z-50">
                    {REGIONS.map((r) => (
                      <button
                        key={r}
                        onClick={() => {
                          setRegion(r);
                          setIsRegionDropdownOpen(false);
                        }}
                        className={`w-full text-left px-3 py-1.5 text-xs font-mono transition-colors ${
                          region === r
                            ? 'text-[#00ff66] bg-[#00ff66]/10 font-bold'
                            : 'text-neutral-300 hover:bg-neutral-800'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Age Verification Badge */}
              <button
                onClick={() => setIsAgeModalOpen(true)}
                className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded text-[10px] font-mono border transition-all ${
                  ageVerified
                    ? 'bg-[#00ff66]/10 border-[#00ff66]/30 text-[#00ff66]'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-400 animate-pulse'
                }`}
                title={ageVerified ? 'Age Verified 18+' : 'Age Verification Required'}
              >
                {ageVerified ? (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>VERIFIED 18+</span>
                  </>
                ) : (
                  <>
                    <ShieldAlert className="w-3.5 h-3.5" />
                    <span>VERIFY AGE</span>
                  </>
                )}
              </button>

              {/* Search Trigger */}
              <button
                onClick={() => setIsSearchOpen(true)}
                className="p-2 text-neutral-300 hover:text-[#00ff66] transition-colors rounded hover:bg-neutral-900"
                aria-label="Search catalog"
              >
                <Search className="w-5 h-5" />
              </button>

              {/* Wishlist */}
              <Link
                href="/account?tab=wishlist"
                className="relative p-2 text-neutral-300 hover:text-[#00ff66] transition-colors rounded hover:bg-neutral-900 hidden sm:block"
                aria-label="Wishlist"
              >
                <Heart className="w-5 h-5" />
                {wishlist.length > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-amber-500 text-black font-mono font-bold text-[10px] rounded-full flex items-center justify-center">
                    {wishlist.length}
                  </span>
                )}
              </Link>

              {/* Account */}
              <Link
                href="/account"
                className="p-2 text-neutral-300 hover:text-[#00ff66] transition-colors rounded hover:bg-neutral-900 hidden sm:block"
                aria-label="Customer Account"
              >
                <User className="w-5 h-5" />
              </Link>

              {/* Cart Drawer Trigger */}
              <button
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-[#00ff66] bg-[#00ff66]/10 border border-[#00ff66]/30 hover:bg-[#00ff66] hover:text-black transition-all rounded"
                aria-label={`Shopping Cart with ${totalItemCount} items`}
              >
                <ShoppingBag className="w-5 h-5" />
                {totalItemCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 min-w-5 h-5 px-1 bg-[#00ff66] text-black font-mono font-bold text-xs rounded-full flex items-center justify-center shadow-lg border border-black">
                    {totalItemCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
    </>
  );
};
