'use client';

import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Pause, Play, ShieldAlert } from 'lucide-react';

const MESSAGES = [
  'NETWORK DROP 001 NOW OPEN — GENESIS FLIGHT AVAILABLE',
  'FREE UK DELIVERY ABOVE £40 ORDER THRESHOLD',
  '0.0% BEER. FULL SIGNAL. NO PERMISSION REQUIRED.',
  'OPEN BEER NETWORK // NO DATA SELLING // DECENTRALIZED FLAVOUR',
];

export const AnnouncementBar: React.FC = () => {
  const [index, setIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % MESSAGES.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isPlaying]);

  return (
    <aside
      aria-label="Announcement bar"
      className="bg-[#0c0e11] border-b border-[#22252b] text-xs font-mono text-neutral-300 py-1.5 px-4 flex items-center justify-between select-none relative z-40"
    >
      <div className="flex items-center gap-2 text-[#00ff66]">
        <span className="inline-block w-2 h-2 rounded-full bg-[#00ff66] animate-pulse" />
        <span className="hidden sm:inline text-[10px] uppercase tracking-widest font-bold">
          STATUS: ONLINE
        </span>
      </div>

      <div className="flex-1 text-center px-4 overflow-hidden">
        <p className="inline-block tracking-wider text-neutral-200 uppercase text-[11px] sm:text-xs">
          {MESSAGES[index]}
        </p>
      </div>

      <div className="flex items-center gap-1.5 text-neutral-400">
        <button
          onClick={() => setIndex((prev) => (prev - 1 + MESSAGES.length) % MESSAGES.length)}
          className="p-1 hover:text-[#00ff66] transition-colors"
          aria-label="Previous announcement"
        >
          <ChevronLeft className="w-3.5 h-3.5" />
        </button>

        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-1 hover:text-[#00ff66] transition-colors"
          aria-label={isPlaying ? 'Pause announcements' : 'Play announcements'}
        >
          {isPlaying ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
        </button>

        <button
          onClick={() => setIndex((prev) => (prev + 1) % MESSAGES.length)}
          className="p-1 hover:text-[#00ff66] transition-colors"
          aria-label="Next announcement"
        >
          <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </aside>
  );
};
