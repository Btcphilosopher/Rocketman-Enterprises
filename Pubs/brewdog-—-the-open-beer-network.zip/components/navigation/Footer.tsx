'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ShieldCheck, Mail, ArrowRight, Lock, Check } from 'lucide-react';

export const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    try {
      await fetch('/api/newsletter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      setSubscribed(true);
      setEmail('');
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <footer className="bg-[#060708] border-t border-[#1e2128] text-neutral-400 font-mono text-xs relative z-10 pt-12 pb-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Top Newsletter & Open Network Join */}
        <div className="p-6 sm:p-8 bg-[#0c0e12] border border-[#22252b] rounded-xl flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 shadow-2xl relative overflow-hidden">
          <div className="space-y-2 max-w-xl">
            <span className="text-[10px] text-[#00ff66] uppercase tracking-widest bg-[#00ff66]/10 px-2 py-0.5 rounded border border-[#00ff66]/20 font-bold">
              NETWORK SUBSCRIPTION
            </span>
            <h3 className="font-display font-bold text-2xl text-white uppercase tracking-wide">
              JOIN THE OPEN BEER NETWORK
            </h3>
            <p className="text-neutral-400 leading-relaxed text-xs">
              Subscribe for early access to limited concept drops, release notes, and community brew lab logs. Zero marketing spam. No data selling.
            </p>
          </div>

          <div className="w-full lg:w-auto">
            {subscribed ? (
              <div className="flex items-center gap-2 p-3 bg-[#00ff66]/10 border border-[#00ff66] rounded text-[#00ff66] font-bold">
                <Check className="w-4 h-4" />
                <span>SIGNAL LOGGED. WELCOME TO THE NETWORK.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2 w-full max-w-md">
                <input
                  type="email"
                  placeholder="Enter email address..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="flex-1 bg-neutral-900 border border-neutral-800 rounded px-4 py-3 text-white placeholder-neutral-500 focus:outline-none focus:border-[#00ff66]"
                />
                <button
                  type="submit"
                  className="px-5 py-3 bg-[#00ff66] text-black font-bold uppercase rounded hover:bg-[#39ff14] transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>CONNECT</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>
            )}
          </div>
        </div>

        {/* Links Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8 pt-4">
          {/* Col 1 */}
          <div className="space-y-3">
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">
              SHOP RANGE
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li><Link href="/shop" className="hover:text-[#00ff66]">All Products</Link></li>
              <li><Link href="/beer" className="hover:text-[#00ff66]">Craft Beer Range</Link></li>
              <li><Link href="/zero-proof" className="hover:text-[#00ff66]">Zero-Proof (0.0%)</Link></li>
              <li><Link href="/drops" className="hover:text-[#00ff66]">Network Drops</Link></li>
              <li><Link href="/mixed-packs" className="hover:text-[#00ff66]">Mixed Pack Builder</Link></li>
            </ul>
          </div>

          {/* Col 2 */}
          <div className="space-y-3">
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">
              GEAR & MERCH
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li><Link href="/merch" className="hover:text-[#00ff66]">Technical Apparel</Link></li>
              <li><Link href="/accessories" className="hover:text-[#00ff66]">Hardware & Openers</Link></li>
              <li><Link href="/accessories" className="hover:text-[#00ff66]">Screen-Printed Glassware</Link></li>
              <li><Link href="/brew-lab" className="hover:text-[#00ff66]">Brew Lab Experiments</Link></li>
            </ul>
          </div>

          {/* Col 3 */}
          <div className="space-y-3">
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">
              PHILOSOPHY
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li><Link href="/our-story" className="hover:text-[#00ff66]">Our Story & Manifesto</Link></li>
              <li><Link href="/data-principles" className="hover:text-[#00ff66]">Personal Data Principles</Link></li>
              <li><Link href="/brew-lab" className="hover:text-[#00ff66]">Open Brewing Philosophy</Link></li>
              <li><Link href="/bars" className="hover:text-[#00ff66]">BrewDog Bar Locations</Link></li>
            </ul>
          </div>

          {/* Col 4 */}
          <div className="space-y-3">
            <h4 className="font-display font-bold text-sm text-white uppercase tracking-wider">
              CUSTOMER CARE
            </h4>
            <ul className="space-y-2 text-neutral-400">
              <li><Link href="/account" className="hover:text-[#00ff66]">Account & Order Status</Link></li>
              <li><Link href="/shipping" className="hover:text-[#00ff66]">UK Delivery Info</Link></li>
              <li><Link href="/faq" className="hover:text-[#00ff66]">Frequently Asked Questions</Link></li>
              <li><Link href="/contact" className="hover:text-[#00ff66]">Contact Support</Link></li>
            </ul>
          </div>

          {/* Col 5 Security & Verification */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1 space-y-3 p-4 bg-[#0a0c0f] border border-[#1e2128] rounded">
            <div className="flex items-center gap-1.5 text-[#00ff66]">
              <Lock className="w-4 h-4" />
              <span className="font-bold">DIGITAL SOVEREIGNTY</span>
            </div>
            <p className="text-[10px] text-neutral-400 leading-relaxed">
              This is a creative prototype application for BrewDog: The Open Beer Network. All orders are processed in demo mode.
            </p>
            <div className="pt-2 flex items-center gap-2 text-[10px] text-neutral-500">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00ff66]" />
              <span>AGE VERIFIED 18+ PROTOCOL</span>
            </div>
          </div>
        </div>

        {/* Bottom copyright & disclaimers */}
        <div className="pt-8 border-t border-[#1e2128] flex flex-col md:flex-row items-center justify-between gap-4 text-[11px] text-neutral-500">
          <div>
            © 2026 BREWDOG PLC — THE OPEN BEER NETWORK. ALL RIGHTS RESERVED.
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <Link href="/data-principles" className="hover:text-neutral-300">PRIVACY & DATA PRINCIPLES</Link>
            <Link href="/terms" className="hover:text-neutral-300">TERMS OF SERVICE</Link>
            <a href="https://www.drinkaware.co.uk" target="_blank" rel="noopener noreferrer" className="hover:text-neutral-300">DRINKAWARE.CO.UK</a>
          </div>
        </div>
      </div>
    </footer>
  );
};
