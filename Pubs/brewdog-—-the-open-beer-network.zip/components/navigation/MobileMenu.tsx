'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { X, Globe, ShieldCheck, ShieldAlert, ChevronRight, User, Heart } from 'lucide-react';
import { useShop } from '@/context/ShopContext';

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export const MobileMenu: React.FC<MobileMenuProps> = ({ isOpen, onClose }) => {
  const pathname = usePathname();
  const { ageVerified, setIsAgeModalOpen, region, setRegion, wishlist } = useShop();

  if (!isOpen) return null;

  const links = [
    { href: '/shop', label: 'SHOP ALL' },
    { href: '/beer', label: 'BEER RANGE' },
    { href: '/zero-proof', label: 'ZERO-PROOF (0.0%)' },
    { href: '/drops', label: 'NETWORK DROPS' },
    { href: '/mixed-packs', label: 'MIXED PACK BUILDER' },
    { href: '/merch', label: 'MERCHANDISE' },
    { href: '/accessories', label: 'ACCESSORIES & HARDWARE' },
    { href: '/brew-lab', label: 'BREW LAB EXPERIMENTS' },
    { href: '/bars', label: 'BREWDOG BARS' },
    { href: '/our-story', label: 'OUR STORY & MANIFESTO' },
  ];

  return (
    <div className="fixed inset-0 z-50 lg:hidden flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer */}
      <div className="relative w-full max-w-xs bg-[#0c0e11] border-r border-[#262930] h-full flex flex-col z-10 p-6 overflow-y-auto">
        <div className="flex items-center justify-between pb-6 border-b border-[#22252b]">
          <div className="flex items-center gap-2">
            <span className="font-display font-bold text-lg text-white">BREWDOG</span>
            <span className="font-mono text-[9px] text-[#00ff66] bg-[#00ff66]/10 px-1.5 py-0.5 rounded border border-[#00ff66]/20">
              NETWORK
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white"
            aria-label="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Verification Status Banner */}
        <div className="my-4">
          <button
            onClick={() => {
              onClose();
              setIsAgeModalOpen(true);
            }}
            className={`w-full flex items-center justify-between p-3 rounded text-xs font-mono border ${
              ageVerified
                ? 'bg-[#00ff66]/10 border-[#00ff66]/30 text-[#00ff66]'
                : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
            }`}
          >
            <div className="flex items-center gap-2">
              {ageVerified ? <ShieldCheck className="w-4 h-4" /> : <ShieldAlert className="w-4 h-4" />}
              <span>{ageVerified ? 'AGE VERIFIED (18+)' : 'AGE UNVERIFIED'}</span>
            </div>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Nav Links */}
        <nav className="flex-1 space-y-1">
          {links.map((link) => {
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={onClose}
                className={`flex items-center justify-between px-3 py-2.5 rounded font-mono text-sm tracking-wide transition-colors ${
                  isActive
                    ? 'bg-[#00ff66]/10 text-[#00ff66] font-bold border-l-2 border-[#00ff66]'
                    : 'text-neutral-300 hover:bg-neutral-800 hover:text-white'
                }`}
              >
                <span>{link.label}</span>
                <ChevronRight className="w-4 h-4 text-neutral-600" />
              </Link>
            );
          })}
        </nav>

        {/* Footer Actions */}
        <div className="pt-6 border-t border-[#22252b] space-y-3 font-mono text-xs text-neutral-400">
          <Link
            href="/account"
            onClick={onClose}
            className="flex items-center gap-2 p-2 hover:text-[#00ff66] transition-colors"
          >
            <User className="w-4 h-4" />
            <span>ACCOUNT & NETWORK TIER</span>
          </Link>

          <Link
            href="/account?tab=wishlist"
            onClick={onClose}
            className="flex items-center gap-2 p-2 hover:text-[#00ff66] transition-colors"
          >
            <Heart className="w-4 h-4" />
            <span>SAVED WISHLIST ({wishlist.length})</span>
          </Link>

          <div className="pt-2 flex items-center gap-2 text-[10px] text-neutral-500">
            <Globe className="w-3.5 h-3.5 text-[#00ff66]" />
            <span>REGION: {region}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
