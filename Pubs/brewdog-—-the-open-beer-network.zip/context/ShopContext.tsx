'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, ProductVariant, CartItem, MixedPack, Promotion } from '@/types/ecommerce';
import { PRODUCTS } from '@/data/products';

interface ShopContextType {
  ageVerified: boolean;
  verifyAge: (confirmed: boolean) => void;
  isAgeModalOpen: boolean;
  setIsAgeModalOpen: (open: boolean) => void;
  
  cart: CartItem[];
  addToCart: (product: Product, variant: ProductVariant, quantity?: number) => void;
  addMixedPackToCart: (mixedPack: MixedPack) => void;
  removeFromCart: (cartItemId: string) => void;
  updateQuantity: (cartItemId: string, quantity: number) => void;
  clearCart: () => void;
  
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  
  region: string;
  setRegion: (region: string) => void;
  
  activePromo: Promotion | null;
  promoCodeInput: string;
  setPromoCodeInput: (code: string) => void;
  applyPromoCode: (code: string) => { success: boolean; message: string };
  removePromoCode: () => void;
  
  cartSubtotal: number;
  discountAmount: number;
  estimatedShipping: number;
  cartTotal: number;
  totalItemCount: number;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

const DEMO_PROMOS: Promotion[] = [
  { code: 'NETWORK10', discountPercentage: 10, description: '10% off your network order' },
  { code: 'FREESHIP', freeShipping: true, minimumSpend: 30, description: 'Free UK delivery on orders over £30' },
  { code: 'OPENBEER', flatDiscountGbp: 5, minimumSpend: 25, description: '£5 off orders over £25' },
];

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [ageVerified, setAgeVerified] = useState<boolean>(false);
  const [isAgeModalOpen, setIsAgeModalOpen] = useState<boolean>(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [region, setRegion] = useState<string>('UK (£)');
  const [activePromo, setActivePromo] = useState<Promotion | null>(null);
  const [promoCodeInput, setPromoCodeInput] = useState<string>('');

  // Load initial state from localStorage on client mount
  useEffect(() => {
    try {
      const storedAge = localStorage.getItem('brewdog_age_verified');
      if (storedAge === 'true') {
        setAgeVerified(true);
      } else {
        // Show age verification prompt after short delay if not verified
        const timer = setTimeout(() => setIsAgeModalOpen(true), 800);
        return () => clearTimeout(timer);
      }

      const storedCart = localStorage.getItem('brewdog_cart');
      if (storedCart) {
        setCart(JSON.parse(storedCart));
      }

      const storedWishlist = localStorage.getItem('brewdog_wishlist');
      if (storedWishlist) {
        setWishlist(JSON.parse(storedWishlist));
      }
    } catch (e) {
      console.warn('Storage read failed', e);
    }
  }, []);

  // Save cart changes
  useEffect(() => {
    try {
      localStorage.setItem('brewdog_cart', JSON.stringify(cart));
    } catch (e) {
      console.warn('Cart storage save failed', e);
    }
  }, [cart]);

  // Save wishlist changes
  useEffect(() => {
    try {
      localStorage.setItem('brewdog_wishlist', JSON.stringify(wishlist));
    } catch (e) {
      console.warn('Wishlist storage save failed', e);
    }
  }, [wishlist]);

  const verifyAge = (confirmed: boolean) => {
    if (confirmed) {
      setAgeVerified(true);
      setIsAgeModalOpen(false);
      try {
        localStorage.setItem('brewdog_age_verified', 'true');
      } catch (e) {
        console.warn('Age storage failed', e);
      }
    } else {
      setAgeVerified(false);
      // Redirect or restrict access message
    }
  };

  const addToCart = (product: Product, variant: ProductVariant, quantity = 1) => {
    if (product.isAgeRestricted && !ageVerified) {
      setIsAgeModalOpen(true);
      return;
    }

    setCart((prevCart) => {
      const existingIndex = prevCart.findIndex(
        (item) => item.productId === product.id && item.variantId === variant.id && !item.isMixedPackItem
      );

      if (existingIndex > -1) {
        const updated = [...prevCart];
        updated[existingIndex].quantity += quantity;
        return updated;
      } else {
        const newItem: CartItem = {
          id: `cart-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
          productId: product.id,
          variantId: variant.id,
          product,
          variant,
          quantity,
        };
        return [...prevCart, newItem];
      }
    });

    setIsCartOpen(true);
  };

  const addMixedPackToCart = (mixedPack: MixedPack) => {
    if (!ageVerified && !mixedPack.isZeroProofOnly) {
      setIsAgeModalOpen(true);
      return;
    }

    // Treat as a custom bundle item
    const bundleProduct: Product = {
      id: `custom-pack-${mixedPack.id}`,
      code: `BD-MIX-${mixedPack.size}`,
      name: `CUSTOM ${mixedPack.size}-CAN MIXED PACK`,
      slug: `custom-pack-${mixedPack.id}`,
      category: 'MIXED PACKS',
      abv: 4.8,
      isZeroProof: mixedPack.isZeroProofOnly,
      tagline: `CUSTOM SELECTION (${mixedPack.totalCans} CANS)`,
      description: `Custom curated ${mixedPack.size}-pack containing: ${mixedPack.items.map(i => `${i.quantity}x ${i.product.name}`).join(', ')}`,
      tastingProfile: { primaryNotes: ['Custom Flight Selection'], bodyScore: 3, hoppinessScore: 4, maltinessScore: 3, aromaDescriptors: [] },
      ingredients: ['Various Hops, Barley, Oats, Yeast'],
      allergens: ['Contains Gluten'],
      servingRecs: 'Chill thoroughly before tasting flight.',
      packagingDetails: 'Heavy-duty recycled card grid transport box.',
      sustainabilityInfo: '100% plastic-free packaging.',
      variants: [
        {
          id: `var-mix-${mixedPack.id}`,
          sku: `BD-MIX-VAR-${mixedPack.size}`,
          packSize: mixedPack.size as 6 | 12 | 24,
          unitPrice: mixedPack.totalPrice,
          inventoryQuantity: 99,
          inventoryStatus: 'IN_STOCK',
        }
      ],
      images: [
        {
          id: `img-mix-${mixedPack.id}`,
          url: 'https://picsum.photos/seed/brewdog-mixedpack-custom/800/800',
          alt: `Custom ${mixedPack.size}-Can Pack`,
          isPrimary: true,
          packagingType: 'PACK',
        }
      ],
      featured: false,
      rating: 5.0,
      reviewCount: 1,
      relatedProductIds: [],
      isAgeRestricted: !mixedPack.isZeroProofOnly,
    };

    const variant = bundleProduct.variants[0];

    const newItem: CartItem = {
      id: `cart-pack-${Date.now()}`,
      productId: bundleProduct.id,
      variantId: variant.id,
      product: bundleProduct,
      variant,
      quantity: 1,
      isMixedPackItem: true,
      customMixedPack: mixedPack,
    };

    setCart((prev) => [...prev, newItem]);
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId: string) => {
    setCart((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const updateQuantity = (cartItemId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCart((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist((prev) =>
      prev.includes(productId) ? prev.filter((id) => id !== productId) : [...prev, productId]
    );
  };

  const applyPromoCode = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    const found = DEMO_PROMOS.find((p) => p.code === cleanCode);
    if (found) {
      setActivePromo(found);
      setPromoCodeInput(cleanCode);
      return { success: true, message: `Promo code ${cleanCode} applied!` };
    }
    return { success: false, message: 'Invalid signal promo code.' };
  };

  const removePromoCode = () => {
    setActivePromo(null);
    setPromoCodeInput('');
  };

  // Calculations
  const cartSubtotal = cart.reduce(
    (sum, item) => sum + item.variant.unitPrice * item.quantity,
    0
  );

  let discountAmount = 0;
  if (activePromo) {
    if (activePromo.discountPercentage) {
      discountAmount = (cartSubtotal * activePromo.discountPercentage) / 100;
    } else if (activePromo.flatDiscountGbp) {
      discountAmount = Math.min(cartSubtotal, activePromo.flatDiscountGbp);
    }
  }

  const freeShippingEligible = cartSubtotal >= 40 || (activePromo?.freeShipping && cartSubtotal >= (activePromo.minimumSpend || 0));
  const estimatedShipping = cartSubtotal > 0 ? (freeShippingEligible ? 0 : 4.50) : 0;
  const cartTotal = Math.max(0, cartSubtotal - discountAmount + estimatedShipping);

  const totalItemCount = cart.reduce((count, item) => count + item.quantity, 0);

  return (
    <ShopContext.Provider
      value={{
        ageVerified,
        verifyAge,
        isAgeModalOpen,
        setIsAgeModalOpen,
        cart,
        addToCart,
        addMixedPackToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        isSearchOpen,
        setIsSearchOpen,
        searchQuery,
        setSearchQuery,
        wishlist,
        toggleWishlist,
        region,
        setRegion,
        activePromo,
        promoCodeInput,
        setPromoCodeInput,
        applyPromoCode,
        removePromoCode,
        cartSubtotal,
        discountAmount,
        estimatedShipping,
        cartTotal,
        totalItemCount,
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
