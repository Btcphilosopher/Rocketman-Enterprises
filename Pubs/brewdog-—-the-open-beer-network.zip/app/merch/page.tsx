'use client';

import React from 'react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { PRODUCTS } from '@/data/products';

function MerchContent() {
  const merchProducts = PRODUCTS.filter((p) => p.category === 'MERCH');

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
            TECHNICAL APPAREL & WORKWEAR
          </span>
          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            BREWDOG MERCHANDISE RANGE
          </h1>
          <p className="font-mono text-xs sm:text-sm text-neutral-400 max-w-2xl">
            Heavyweight cotton tees, ripstop technical overshirts, and sub-frequency fleece hoodies designed as a collaboration between brewery engineering and independent streetwear.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {merchProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function MerchPage() {
  return (
    <ShopProvider>
      <MerchContent />
    </ShopProvider>
  );
}
