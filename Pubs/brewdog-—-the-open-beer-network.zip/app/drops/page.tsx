'use client';

import React from 'react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { RELEASE_DROPS, PRODUCTS } from '@/data/products';
import { Flame, Clock, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';

function DropsContent() {
  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-12">
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
            LIMITED CULTURAL RELEASES
          </span>
          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            NETWORK DROPS
          </h1>
          <p className="font-mono text-xs sm:text-sm text-neutral-400 max-w-2xl">
            Strictly limited batch releases, experimental pilot brews, and seasonal flight packages. Honest stock availability transparency.
          </p>
        </div>

        {/* Drops Stack */}
        <div className="space-y-12">
          {RELEASE_DROPS.map((drop) => {
            const dropProducts = PRODUCTS.filter((p) =>
              drop.featuredProductIds.includes(p.id)
            );

            return (
              <div
                key={drop.id}
                className="bg-[#0e1014] border border-[#262930] rounded-xl p-6 sm:p-8 space-y-6 shadow-2xl relative overflow-hidden"
              >
                {/* Header status bar */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#22252b]">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-lg text-black bg-[#00ff66] px-3 py-1 rounded uppercase tracking-wider">
                      {drop.dropCode}
                    </span>
                    <div>
                      <h2 className="font-display font-bold text-2xl text-white uppercase">
                        {drop.title}
                      </h2>
                      <p className="font-mono text-xs text-neutral-400">{drop.subtitle}</p>
                    </div>
                  </div>

                  <div className="font-mono text-xs text-left sm:text-right">
                    <span className="text-neutral-500 uppercase block">STOCK PROTOCOL</span>
                    <span className="font-bold text-white text-base">
                      {drop.unitsRemaining} / {drop.totalUnitsAvailable} UNITS AVAILABLE
                    </span>
                  </div>
                </div>

                {/* Drop Story & Flight notes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-[#13161c] p-4 rounded border border-neutral-800 font-mono text-xs">
                  <div>
                    <span className="text-[#00ff66] font-bold block mb-1">THE RELEASE STORY:</span>
                    <p className="text-neutral-300 leading-relaxed">{drop.storyText}</p>
                  </div>
                  <div>
                    <span className="text-amber-400 font-bold block mb-1">TASTING FLIGHT PROFILE:</span>
                    <p className="text-neutral-300 leading-relaxed">{drop.tastingFlightNotes}</p>
                  </div>
                </div>

                {/* Product Cards Grid in Drop */}
                <div className="space-y-3">
                  <h3 className="font-mono text-xs text-neutral-400 font-bold uppercase">
                    FEATURED CAN SIGNALS IN THIS DROP:
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {dropProducts.map((p) => (
                      <ProductCard key={p.id} product={p} />
                    ))}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function DropsPage() {
  return (
    <ShopProvider>
      <DropsContent />
    </ShopProvider>
  );
}
