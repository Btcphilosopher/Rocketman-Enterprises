'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { ShopProvider, useShop } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { PRODUCTS } from '@/data/products';
import { User, ShieldCheck, Heart, Package, Globe, Terminal, Sparkles } from 'lucide-react';

function AccountContent() {
  const { wishlist, ageVerified, region, setRegion, setIsAgeModalOpen } = useShop();
  const [activeTab, setActiveTab] = useState<'orders' | 'wishlist' | 'settings'>('orders');

  const wishlistedProducts = PRODUCTS.filter((p) => wishlist.includes(p.id));

  const mockOrders = [
    {
      id: 'ORD-2026-9081',
      date: '18 SEP 2026',
      status: 'DISPATCH CONFIRMED',
      total: '£36.00',
      items: [
        { name: 'NODE ZERO (12-CAN PACK)', qty: 1, price: '£26.00' },
        { name: 'BREWDOG OPEN NETWORK TEE', qty: 1, price: '£10.00' },
      ],
    },
    {
      id: 'ORD-2026-8812',
      date: '02 SEP 2026',
      status: 'DELIVERED',
      total: '£22.00',
      items: [{ name: 'ZERO NODE 0.0% (12-CAN PACK)', qty: 1, price: '£22.00' }],
    },
  ];

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        {/* Profile Banner */}
        <div className="bg-[#0e1014] border border-[#22252b] rounded-xl p-6 sm:p-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-neutral-900 border border-[#00ff66] rounded-full flex items-center justify-center text-[#00ff66]">
              <User className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2 py-0.5 rounded border border-[#00ff66]/20 font-bold uppercase">
                  OPERATOR TIER II
                </span>
                {ageVerified ? (
                  <span className="font-mono text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    AGE VERIFIED 18+
                  </span>
                ) : (
                  <button
                    onClick={() => setIsAgeModalOpen(true)}
                    className="font-mono text-[10px] text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20 underline"
                  >
                    VERIFY AGE NOW
                  </button>
                )}
              </div>
              <h1 className="font-display font-bold text-2xl text-white uppercase mt-1">
                OPERATOR_9081
              </h1>
              <p className="font-mono text-xs text-neutral-400">
                operator@openbeer.net — REGION: {region}
              </p>
            </div>
          </div>
        </div>

        {/* Tabs Bar */}
        <div className="flex items-center gap-2 border-b border-[#22252b] pb-2 font-mono text-xs">
          <button
            onClick={() => setActiveTab('orders')}
            className={`px-4 py-2 rounded font-bold uppercase transition-colors flex items-center gap-2 ${
              activeTab === 'orders'
                ? 'bg-[#00ff66] text-black'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>DISPATCH ORDERS ({mockOrders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('wishlist')}
            className={`px-4 py-2 rounded font-bold uppercase transition-colors flex items-center gap-2 ${
              activeTab === 'wishlist'
                ? 'bg-[#00ff66] text-black'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            <Heart className="w-4 h-4" />
            <span>SAVED WISHLIST ({wishlist.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-2 rounded font-bold uppercase transition-colors flex items-center gap-2 ${
              activeTab === 'settings'
                ? 'bg-[#00ff66] text-black'
                : 'bg-neutral-900 text-neutral-400 hover:text-white'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span>REGION PREFERENCES</span>
          </button>
        </div>

        {/* Tab Views */}
        {activeTab === 'orders' && (
          <div className="space-y-4 font-mono text-xs">
            <h2 className="font-display font-bold text-xl text-white uppercase">
              ORDER DISPATCH HISTORY
            </h2>

            {mockOrders.map((order) => (
              <div key={order.id} className="bg-[#0e1014] border border-[#22252b] rounded-lg p-5 space-y-3">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#22252b] gap-2">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-white text-sm">{order.id}</span>
                    <span className="text-neutral-500">{order.date}</span>
                  </div>
                  <span className="px-2.5 py-1 bg-[#00ff66]/10 border border-[#00ff66]/30 text-[#00ff66] font-bold rounded">
                    {order.status}
                  </span>
                </div>

                <div className="space-y-1 text-neutral-300">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between">
                      <span>{item.qty}x {item.name}</span>
                      <span>{item.price}</span>
                    </div>
                  ))}
                </div>

                <div className="pt-2 border-t border-[#22252b] flex justify-between font-bold text-white text-sm">
                  <span>TOTAL DISPATCHED</span>
                  <span>{order.total}</span>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'wishlist' && (
          <div className="space-y-4">
            <h2 className="font-display font-bold text-xl text-white uppercase">
              SAVED WISHLIST SIGNALS
            </h2>

            {wishlistedProducts.length === 0 ? (
              <div className="py-12 text-center space-y-3 bg-[#0e1014] border border-[#22252b] rounded-lg p-6 font-mono text-xs">
                <p className="text-neutral-400">YOUR WISHLIST IS CURRENTLY EMPTY.</p>
                <Link href="/shop" className="inline-block px-4 py-2 bg-[#00ff66] text-black font-bold uppercase rounded">
                  EXPLORE SHOP CATALOG
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {wishlistedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="bg-[#0e1014] border border-[#22252b] rounded-lg p-6 space-y-6 font-mono text-xs max-w-xl">
            <h2 className="font-display font-bold text-xl text-white uppercase">
              OPERATOR REGION & COMPLIANCE
            </h2>

            <div className="space-y-2">
              <label className="text-neutral-400 font-bold block">DISPATCH REGION:</label>
              <select
                value={region}
                onChange={(e) => setRegion(e.target.value)}
                className="w-full bg-neutral-900 border border-neutral-800 rounded p-3 text-white focus:outline-none focus:border-[#00ff66]"
              >
                <option value="UK">UNITED KINGDOM (EXPRESS DISPATCH)</option>
                <option value="EU">EUROPEAN UNION (INSPECTION MODE)</option>
                <option value="GLOBAL">GLOBAL OPEN NETWORK</option>
              </select>
            </div>

            <div className="pt-4 border-t border-[#22252b] space-y-2">
              <p className="text-neutral-400">AGE VERIFICATION PROTOCOL:</p>
              <div className="flex items-center justify-between p-3 bg-neutral-900 rounded border border-neutral-800">
                <span>STATUS: {ageVerified ? 'VERIFIED (18+)' : 'UNVERIFIED'}</span>
                <button
                  onClick={() => setIsAgeModalOpen(true)}
                  className="px-3 py-1 bg-[#00ff66] text-black font-bold rounded"
                >
                  RE-VERIFY
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function AccountPage() {
  return (
    <ShopProvider>
      <AccountContent />
    </ShopProvider>
  );
}
