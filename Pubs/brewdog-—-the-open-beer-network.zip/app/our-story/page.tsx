'use client';

import React from 'react';
import Link from 'next/link';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { Terminal, Shield, ArrowRight } from 'lucide-react';

function StoryContent() {
  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
            BRAND MANIFESTO v3.6
          </span>
          <h1 className="font-display font-black text-4xl sm:text-6xl text-white uppercase tracking-tight">
            OUR STORY & MANIFESTO
          </h1>
          <p className="font-mono text-sm text-[#00ff66] font-bold">
            GREAT BEER. OPEN NETWORKS. NO PERMISSION REQUIRED.
          </p>
        </div>

        <div className="space-y-6 font-mono text-xs sm:text-sm text-neutral-300 leading-relaxed">
          <div className="p-6 bg-[#0e1014] border border-[#22252b] rounded-xl space-y-4">
            <h2 className="font-display font-bold text-2xl text-white uppercase">
              1. THE CRAFT BEER REVOLUTION ENTERING A NEW ERA
            </h2>
            <p>
              BrewDog was born in Aberdeenshire with a single mission: to make people as passionate about great craft beer as we are. We tore down industrial lagering compromises with Punk IPA and proved that independent flavor could conquer global mass-market monotony.
            </p>
            <p>
              Now, we enter a new cultural and technological era: <strong>THE OPEN BEER NETWORK</strong>.
            </p>
          </div>

          <div className="p-6 bg-[#0e1014] border border-[#22252b] rounded-xl space-y-4">
            <h2 className="font-display font-bold text-2xl text-white uppercase">
              2. WHAT IS THE OPEN BEER NETWORK?
            </h2>
            <p>
              The Open Beer Network merges independent British craft beer culture with cypherpunk digital sovereignty. We believe in open standards, transparent recipes, zero predatory tracking, and direct-to-consumer delivery without middlemen.
            </p>
            <ul className="list-disc pl-5 space-y-2 text-neutral-300">
              <li><strong>Open Brewing Philosophy:</strong> Publish complete hop, malt, and yeast specs for every batch.</li>
              <li><strong>Zero-Proof Innovation:</strong> Treat 0.0% ABV alcohol-free beer as a primary craft discipline.</li>
              <li><strong>Privacy-Conscious E-commerce:</strong> Collect only the data needed to ship beer safely. No tracking, no data selling.</li>
              <li><strong>Network Drops:</strong> Limited cultural releases dropped directly to operators on the open network.</li>
            </ul>
          </div>

          <div className="p-6 bg-[#00ff66]/10 border border-[#00ff66]/30 rounded-xl space-y-4 text-left">
            <h2 className="font-display font-bold text-2xl text-[#00ff66] uppercase">
              READY TO CONNECT TO THE NETWORK?
            </h2>
            <p className="text-neutral-200">
              Explore our fresh releases, build a custom 12-can flight, or check out our technical gear.
            </p>

            <div className="pt-2 flex flex-wrap gap-4">
              <Link
                href="/shop"
                className="py-3 px-6 bg-[#00ff66] text-black font-bold uppercase rounded hover:bg-[#39ff14] transition-colors inline-flex items-center gap-2"
              >
                <span>EXPLORE CATALOGUE</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function OurStoryPage() {
  return (
    <ShopProvider>
      <StoryContent />
    </ShopProvider>
  );
}
