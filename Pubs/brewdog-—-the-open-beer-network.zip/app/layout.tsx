import type { Metadata } from 'next';
import { JetBrains_Mono, Oswald, Inter } from 'next/font/google';
import './globals.css';

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  display: 'swap',
});

const oswald = Oswald({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'BREWDOG — THE OPEN BEER NETWORK',
  description: 'Great beer. Open networks. No permission required. Future-facing craft beer e-commerce prototype.',
  openGraph: {
    title: 'BREWDOG — THE OPEN BEER NETWORK',
    description: 'Great beer. Open networks. No permission required.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BREWDOG — THE OPEN BEER NETWORK',
    description: 'Great beer. Open networks. No permission required.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${jetbrainsMono.variable} ${oswald.variable} ${inter.variable} dark`}>
      <body className="bg-[#08090a] text-[#f1f3f5] font-sans antialiased min-h-screen flex flex-col selection:bg-[#00ff66] selection:text-black" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}

