import { NextRequest, NextResponse } from 'next/server';
import { OrderDraft } from '@/types/ecommerce';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { items, customerEmail, shippingAddress, ageVerifiedConfirmed } = body;

    if (!items || items.length === 0) {
      return NextResponse.json(
        { error: 'Cart is empty. Cannot generate order draft.' },
        { status: 400 }
      );
    }

    if (!ageVerifiedConfirmed) {
      return NextResponse.json(
        { error: 'Age verification required for alcohol order dispatch.' },
        { status: 403 }
      );
    }

    const subtotal = items.reduce(
      (acc: number, item: any) => acc + item.variant.unitPrice * item.quantity,
      0
    );

    const shippingFee = subtotal >= 40 ? 0 : 4.50;
    const totalAmount = subtotal + shippingFee;

    const orderDraft: OrderDraft = {
      id: `ORD-BD-${Date.now().toString(36).toUpperCase()}`,
      items,
      subtotal,
      discountAmount: 0,
      shippingFee,
      totalAmount,
      customerEmail: customerEmail || 'operator@openbeer.net',
      shippingAddress,
      ageVerifiedConfirmed: true,
      status: 'PAID_DEMO',
      createdAtISO: new Date().toISOString(),
    };

    return NextResponse.json({
      success: true,
      order: orderDraft,
      demoMessage: 'This is a prototype order draft for demonstration purposes. No real payment was charged.',
    });
  } catch (err: any) {
    return NextResponse.json(
      { error: err.message || 'Server error processing checkout' },
      { status: 500 }
    );
  }
}
