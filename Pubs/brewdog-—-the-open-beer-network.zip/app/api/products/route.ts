import { NextRequest, NextResponse } from 'next/server';
import { PRODUCTS } from '@/data/products';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('q')?.toLowerCase();
  const category = searchParams.get('category');
  const zeroProofOnly = searchParams.get('zeroProof') === 'true';
  const abvMin = parseFloat(searchParams.get('abvMin') || '0');
  const abvMax = parseFloat(searchParams.get('abvMax') || '20');
  const style = searchParams.get('style');
  const limitedOnly = searchParams.get('limited') === 'true';
  const dropId = searchParams.get('dropId');
  const flavour = searchParams.get('flavour');

  let filtered = [...PRODUCTS];

  if (query) {
    filtered = filtered.filter(
      (p) =>
        p.name.toLowerCase().includes(query) ||
        p.style?.toLowerCase().includes(query) ||
        p.tagline.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.ingredients.some((ing) => ing.toLowerCase().includes(query)) ||
        p.tastingProfile.primaryNotes.some((note) => note.toLowerCase().includes(query))
    );
  }

  if (category) {
    filtered = filtered.filter(
      (p) => p.category.toLowerCase() === category.toLowerCase()
    );
  }

  if (zeroProofOnly) {
    filtered = filtered.filter((p) => p.isZeroProof || p.abv === 0);
  }

  if (style) {
    filtered = filtered.filter(
      (p) => p.style?.toLowerCase() === style.toLowerCase()
    );
  }

  if (limitedOnly) {
    filtered = filtered.filter((p) => p.isLimitedRelease);
  }

  if (dropId) {
    filtered = filtered.filter((p) => p.releaseDropId === dropId);
  }

  if (flavour) {
    filtered = filtered.filter((p) =>
      p.tastingProfile.primaryNotes.some((note) =>
        note.toLowerCase().includes(flavour.toLowerCase())
      )
    );
  }

  filtered = filtered.filter((p) => p.abv >= abvMin && p.abv <= abvMax);

  return NextResponse.json({
    total: filtered.length,
    products: filtered,
  });
}
