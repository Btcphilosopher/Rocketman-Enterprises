import { NextRequest, NextResponse } from 'next/server';
import { PRODUCTS } from '@/data/products';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const product = PRODUCTS.find((p) => p.slug === slug || p.id === slug);

  if (!product) {
    return NextResponse.json(
      { error: 'Product signal not found' },
      { status: 404 }
    );
  }

  const related = PRODUCTS.filter((p) =>
    product.relatedProductIds.includes(p.id)
  );

  return NextResponse.json({
    product,
    relatedProducts: related,
  });
}
