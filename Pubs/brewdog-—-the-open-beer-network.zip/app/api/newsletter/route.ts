import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const { email, preferences } = await request.json();

    if (!email || !email.includes('@')) {
      return NextResponse.json(
        { error: 'Valid email signal required.' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      message: `Signal logged for ${email}. You are now on The Open Network drop list.`,
      preferences: preferences || { newDrops: true, localEvents: false, brewLabNotes: true },
    });
  } catch (e: any) {
    return NextResponse.json({ error: 'Subscription request failed.' }, { status: 500 });
  }
}
