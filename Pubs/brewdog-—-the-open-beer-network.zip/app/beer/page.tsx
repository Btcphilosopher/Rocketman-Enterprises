'use client';

import React from 'react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { PRODUCTS } from '@/data/products';

function BeerContent() {
  const beerProducts = PRODUCTS.filter((p) => p.category === 'BEER');

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
            CRAFT BEER COLLECTION
          </span>
          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            FICTIONAL BEER RANGE
          </h1>
          <p className="font-mono text-xs sm:text-sm text-neutral-400 max-w-2xl">
            From the foundational dry-hopped Node Zero pale ale to the subterranean Darknet Stout and West Coast Packet Loss IPA.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {beerProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function BeerPage() {
  return (
    <ShopProvider>
      <BeerContent />
    </ShopProvider>
  );
}
