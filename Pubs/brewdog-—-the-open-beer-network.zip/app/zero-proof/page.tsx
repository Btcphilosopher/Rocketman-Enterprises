'use client';

import React from 'react';
import Link from 'next/link';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { PRODUCTS } from '@/data/products';
import { ShieldCheck, Sparkles, Zap, ArrowRight } from 'lucide-react';

function ZeroProofContent() {
  const zeroProducts = PRODUCTS.filter((p) => p.isZeroProof || p.abv === 0);

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-12">
        {/* Banner Header */}
        <div className="bg-[#0f1217] border border-[#22252b] rounded-xl p-6 sm:p-10 relative overflow-hidden space-y-4">
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#00ff66]/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
              0.0% ABV FULL SIGNAL
            </span>
            <span className="font-mono text-xs text-neutral-400 bg-neutral-900 px-2.5 py-1 rounded border border-neutral-800">
              NO PERMISSION REQUIRED
            </span>
          </div>

          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            ZERO-PROOF COLLECTION
          </h1>

          <p className="font-mono text-xs sm:text-sm text-neutral-300 max-w-2xl leading-relaxed">
            Crafted without alcohol, without compromise. Utilizing cold-vacuum distillation to preserve 100% of the hop essential oils and aroma compounds. High signal, zero impairment.
          </p>

          <div className="pt-2 flex flex-wrap gap-4">
            <Link
              href="/mixed-packs"
              className="py-3 px-6 bg-[#00ff66] text-black font-mono font-bold text-xs uppercase tracking-wider rounded hover:bg-[#39ff14] transition-colors flex items-center gap-2"
            >
              <span>BUILD 0.0% MIXED PACK</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Product Grid */}
        <div className="space-y-4">
          <h2 className="font-display font-bold text-2xl text-white uppercase">
            ALCOHOL-FREE LINEUP (0.0% ABV)
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {zeroProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>

        {/* Product Education & Technology Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 border-t border-[#22252b]">
          <div className="p-6 bg-[#111317] border border-[#22252b] rounded-lg space-y-2">
            <Zap className="w-6 h-6 text-[#00ff66]" />
            <h3 className="font-display font-bold text-lg text-white uppercase">
              VACUUM DISTILLATION
            </h3>
            <p className="font-mono text-xs text-neutral-400 leading-relaxed">
              By boiling off alcohol under low-pressure vacuum at just 28°C, delicate hop monoterpenes and ester aromas remain unheated and intact.
            </p>
          </div>

          <div className="p-6 bg-[#111317] border border-[#22252b] rounded-lg space-y-2">
            <ShieldCheck className="w-6 h-6 text-sky-400" />
            <h3 className="font-display font-bold text-lg text-white uppercase">
              LOW LATENCY FOCUS
            </h3>
            <p className="font-mono text-xs text-neutral-400 leading-relaxed">
              Under 45 calories per can with zero residual sugars. Sustained focus for coding, late-night creative sessions, or active training.
            </p>
          </div>

          <div className="p-6 bg-[#111317] border border-[#22252b] rounded-lg space-y-2">
            <Sparkles className="w-6 h-6 text-amber-400" />
            <h3 className="font-display font-bold text-lg text-white uppercase">
              FULL TASTING FLIGHT
            </h3>
            <p className="font-mono text-xs text-neutral-400 leading-relaxed">
              Experience the full gamut: Zero Node Pale, Clear Channel Lager, and Low Power Blood Orange Pale in our custom 12-can flight packs.
            </p>
          </div>
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function ZeroProofPage() {
  return (
    <ShopProvider>
      <ZeroProofContent />
    </ShopProvider>
  );
}
