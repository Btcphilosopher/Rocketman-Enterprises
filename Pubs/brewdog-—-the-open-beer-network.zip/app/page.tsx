'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowRight, ShieldCheck, Sparkles, Flame, Terminal, CheckCircle2, ChevronRight, Zap } from 'lucide-react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { MixedPackBuilder } from '@/components/ecommerce/MixedPackBuilder';
import { PRODUCTS, RELEASE_DROPS } from '@/data/products';
import { ProductCanGraphic } from '@/components/product/ProductCanGraphic';

function MainHomepageContent() {
  const featuredProducts = PRODUCTS.filter((p) => p.featured);
  const genesisDrop = RELEASE_DROPS[0];

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1">
        {/* HERO SECTION */}
        <section className="relative min-h-[85vh] flex items-center bg-[#090a0d] border-b border-[#22252b] overflow-hidden py-16 px-4 sm:px-6 lg:px-8">
          {/* Subtle Tech Grid Background */}
          <div className="absolute inset-0 bg-tech-grid opacity-15 pointer-events-none" />

          {/* Ambient Lighting Glows */}
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-[#00ff66]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-40 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
            {/* Left Column: Copy & Actions */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#00ff66]/10 border border-[#00ff66]/30 text-[#00ff66] font-mono text-xs font-bold uppercase tracking-widest rounded">
                <span className="w-2 h-2 rounded-full bg-[#00ff66] animate-ping" />
                <span>NETWORK DROP 001 NOW LIVE</span>
              </div>

              <h1 className="font-display font-black text-4xl sm:text-6xl lg:text-7xl text-white uppercase tracking-tight leading-[0.95]">
                THE NETWORK <br />
                <span className="text-[#00ff66] underline decoration-4 underline-offset-8">IS OPEN</span>
              </h1>

              <p className="font-mono text-sm sm:text-base text-neutral-300 max-w-xl leading-relaxed">
                Independent brewing for people who prefer their beer unfiltered, their culture decentralised, and their nights entirely their own.
              </p>

              {/* Primary Call to Action Buttons */}
              <div className="pt-4 flex flex-wrap items-center gap-4">
                <Link
                  href="/drops"
                  className="py-4 px-8 bg-[#00ff66] text-black font-mono font-bold text-sm tracking-wider uppercase rounded hover:bg-[#39ff14] transition-all shadow-xl shadow-[#00ff66]/20 flex items-center gap-2 group"
                >
                  <span>SHOP THE NEW DROP</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>

                <Link
                  href="/shop"
                  className="py-4 px-8 bg-neutral-900 border border-neutral-700 text-neutral-200 font-mono text-sm tracking-wider uppercase rounded hover:border-[#00ff66] hover:text-white transition-all"
                >
                  EXPLORE THE RANGE
                </Link>
              </div>

              {/* Technical Specifications Bar */}
              <div className="pt-6 grid grid-cols-3 gap-4 border-t border-[#22252b] font-mono text-xs text-neutral-400">
                <div>
                  <span className="text-neutral-500 block text-[10px]">CRAFT PROTOCOL</span>
                  <span className="text-white font-bold">UNFILTERED & COLD</span>
                </div>
                <div>
                  <span className="text-neutral-500 block text-[10px]">NETWORK NODES</span>
                  <span className="text-[#00ff66] font-bold">100% INDEPENDENT</span>
                </div>
                <div>
                  <span className="text-neutral-500 block text-[10px]">LATENCY</span>
                  <span className="text-white font-bold">EXPRESS UK DELIVERY</span>
                </div>
              </div>
            </div>

            {/* Right Column: Sculptural Can Art Composition */}
            <div className="lg:col-span-5 relative flex justify-center items-center">
              <div className="relative w-full max-w-md aspect-square bg-[#0f1115] border border-[#22252b] rounded-2xl p-6 flex items-center justify-center shadow-2xl overflow-hidden group">
                <div className="absolute inset-0 bg-dots-pattern opacity-20" />

                {/* Main Can Trio Arrangement */}
                <div className="relative z-10 flex items-center justify-center -space-x-8">
                  {/* Left Can: Protocol Pils */}
                  <div className="transform -rotate-6 scale-90 opacity-95 transition-transform duration-500 group-hover:-rotate-12">
                    <ProductCanGraphic product={PRODUCTS[2]} size="lg" />
                  </div>

                  {/* Center Hero Can: Node Zero */}
                  <div className="relative z-20 transform scale-110 shadow-2xl transition-transform duration-500 group-hover:scale-115">
                    <ProductCanGraphic product={PRODUCTS[0]} size="lg" />
                  </div>

                  {/* Right Can: Packet Loss IPA */}
                  <div className="transform rotate-6 scale-90 opacity-95 transition-transform duration-500 group-hover:rotate-12">
                    <ProductCanGraphic product={PRODUCTS[3]} size="lg" />
                  </div>
                </div>

                {/* Signal Badge */}
                <div className="absolute bottom-4 left-4 z-30 px-3 py-1.5 bg-black/80 backdrop-blur-md border border-[#00ff66]/40 rounded font-mono text-[10px] text-[#00ff66] font-bold uppercase">
                  BUILD 001 // THREE-CAN FLIGHT
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* FEATURED RELEASE DROP 001 BANNER */}
        <section className="py-12 bg-[#0c0e12] border-b border-[#22252b] px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto bg-[#12151b] border border-[#262930] rounded-xl p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center shadow-2xl relative overflow-hidden">
            <div className="lg:col-span-8 space-y-4">
              <div className="flex items-center gap-2 text-amber-400 font-mono text-xs font-bold">
                <Flame className="w-4 h-4" />
                <span>LIMITED CULTURAL RELEASE: {genesisDrop.dropCode}</span>
              </div>
              <h2 className="font-display font-bold text-3xl sm:text-4xl text-white uppercase tracking-wide">
                {genesisDrop.title} — {genesisDrop.subtitle}
              </h2>
              <p className="font-mono text-xs sm:text-sm text-neutral-300 leading-relaxed max-w-2xl">
                {genesisDrop.storyText}
              </p>
              <p className="font-mono text-xs text-[#00ff66] font-semibold">
                {genesisDrop.tastingFlightNotes}
              </p>
            </div>

            <div className="lg:col-span-4 flex flex-col items-start lg:items-end justify-between gap-4 border-t lg:border-t-0 lg:border-l border-[#262930] pt-4 lg:pt-0 lg:pl-8">
              <div className="font-mono text-left lg:text-right">
                <span className="text-[10px] text-neutral-500 uppercase block">STOCK REMAINING</span>
                <span className="font-bold text-2xl text-white">
                  {genesisDrop.unitsRemaining} / {genesisDrop.totalUnitsAvailable} UNITS
                </span>
              </div>

              <Link
                href="/drops"
                className="w-full sm:w-auto py-3 px-6 bg-[#00ff66] text-black font-mono font-bold text-xs uppercase tracking-wider rounded hover:bg-[#39ff14] transition-colors flex items-center justify-center gap-2"
              >
                <span>CLAIM DROP FLIGHT</span>
                <ChevronRight className="w-4 h-4" />
              </Link>
            </div>
          </div>
        </section>

        {/* FEATURED PRODUCTS CATALOG GRID */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 pb-4 border-b border-[#22252b]">
            <div>
              <span className="font-mono text-xs text-[#00ff66] font-bold uppercase tracking-widest">
                SIGNALS IN STOCK
              </span>
              <h2 className="font-display font-bold text-3xl text-white uppercase tracking-wide mt-1">
                FEATURED BEERS & ZERO-PROOF
              </h2>
            </div>

            <Link
              href="/shop"
              className="font-mono text-xs text-[#00ff66] hover:underline flex items-center gap-1 font-bold"
            >
              <span>VIEW FULL CATALOG (12 SIGNALS)</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* MIXED PACK BUILDER INTERACTIVE SECTION */}
        <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
          <MixedPackBuilder />
        </section>

        {/* OPEN BREWING PHILOSOPHY & CYPHERPUNK MANIFESTO */}
        <section className="py-16 bg-[#0a0c0f] border-t border-b border-[#22252b] px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="p-6 bg-[#111317] border border-[#22252b] rounded-lg space-y-3">
              <Terminal className="w-8 h-8 text-[#00ff66]" />
              <h3 className="font-display font-bold text-xl text-white uppercase">
                OPEN BREWING PHILOSOPHY
              </h3>
              <p className="font-mono text-xs text-neutral-400 leading-relaxed">
                Full transparency in every build. We publish complete hop ratios, malt profiles, and fermentation parameters for every brew batch. No permission required to inspect or recreate.
              </p>
            </div>

            <div className="p-6 bg-[#111317] border border-[#22252b] rounded-lg space-y-3">
              <ShieldCheck className="w-8 h-8 text-amber-400" />
              <h3 className="font-display font-bold text-xl text-white uppercase">
                ZERO TRACKING & DATA SOVEREIGNTY
              </h3>
              <p className="font-mono text-xs text-neutral-400 leading-relaxed">
                We believe your purchasing habits are your own business. We collect only what is strictly required to ship your beer safely. Zero data selling, zero predatory cookies.
              </p>
            </div>

            <div className="p-6 bg-[#111317] border border-[#22252b] rounded-lg space-y-3">
              <Zap className="w-8 h-8 text-sky-400" />
              <h3 className="font-display font-bold text-xl text-white uppercase">
                0.0% FULL SIGNAL ZERO-PROOF
              </h3>
              <p className="font-mono text-xs text-neutral-400 leading-relaxed">
                Zero-proof craft beer engineered as a primary focus, not an afterthought. Advanced cold-vacuum distillation for full hop essential oil retention with 0.0% ABV.
              </p>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      {/* Global Modals & Drawers */}
      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function HomePage() {
  return (
    <ShopProvider>
      <MainHomepageContent />
    </ShopProvider>
  );
}
