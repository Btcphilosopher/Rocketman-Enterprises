'use client';

import React, { useState, useMemo } from 'react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCard } from '@/components/product/ProductCard';
import { PRODUCTS } from '@/data/products';
import { ProductCategory } from '@/types/ecommerce';
import { Filter, RotateCcw, SlidersHorizontal } from 'lucide-react';

function ShopContent() {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedStyle, setSelectedStyle] = useState<string>('ALL');
  const [zeroProofOnly, setZeroProofOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');

  const categories = ['ALL', 'BEER', 'ZERO-PROOF', 'MERCH', 'ACCESSORIES'];

  const styles = useMemo(() => {
    const set = new Set<string>();
    PRODUCTS.forEach((p) => {
      if (p.style) set.add(p.style);
    });
    return ['ALL', ...Array.from(set)];
  }, []);

  const filteredProducts = useMemo(() => {
    let result = [...PRODUCTS];

    if (selectedCategory !== 'ALL') {
      result = result.filter((p) => p.category === selectedCategory);
    }

    if (selectedStyle !== 'ALL') {
      result = result.filter((p) => p.style === selectedStyle);
    }

    if (zeroProofOnly) {
      result = result.filter((p) => p.isZeroProof || p.abv === 0);
    }

    if (sortBy === 'price-asc') {
      result.sort((a, b) => (a.variants[0]?.unitPrice || 0) - (b.variants[0]?.unitPrice || 0));
    } else if (sortBy === 'price-desc') {
      result.sort((a, b) => (b.variants[0]?.unitPrice || 0) - (a.variants[0]?.unitPrice || 0));
    } else if (sortBy === 'rating') {
      result.sort((a, b) => b.rating - a.rating);
    }

    return result;
  }, [selectedCategory, selectedStyle, zeroProofOnly, sortBy]);

  const resetFilters = () => {
    setSelectedCategory('ALL');
    setSelectedStyle('ALL');
    setZeroProofOnly(false);
    setSortBy('featured');
  };

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        {/* Title Header */}
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
            FULL CATALOG PROTOCOL
          </span>
          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            THE OPEN NETWORK CATALOGUE
          </h1>
          <p className="font-mono text-xs sm:text-sm text-neutral-400 max-w-2xl">
            Explore our complete lineup of dry-hopped pale ales, imperial stouts, crisp pilsners, 0.0% zero-proof options, and technical apparel.
          </p>
        </div>

        {/* Filter Toolbar */}
        <div className="p-4 bg-[#111317] border border-[#22252b] rounded-lg space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
            {/* Category Filter Pills */}
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-neutral-400 font-bold flex items-center gap-1.5 mr-1">
                <Filter className="w-3.5 h-3.5 text-[#00ff66]" /> CATEGORY:
              </span>
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded transition-all font-bold ${
                    selectedCategory === cat
                      ? 'bg-[#00ff66] text-black shadow-md'
                      : 'bg-neutral-900 text-neutral-300 border border-neutral-800 hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Zero proof checkbox & Sort Selector */}
            <div className="flex flex-wrap items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer text-neutral-300">
                <input
                  type="checkbox"
                  checked={zeroProofOnly}
                  onChange={(e) => setZeroProofOnly(e.target.checked)}
                  className="accent-[#00ff66] w-4 h-4"
                />
                <span>0.0% ZERO-PROOF ONLY</span>
              </label>

              <div className="flex items-center gap-2">
                <span className="text-neutral-500">SORT:</span>
                <select
                  value={sortBy}
                  onChange={(e: any) => setSortBy(e.target.value)}
                  className="bg-neutral-900 border border-neutral-800 rounded px-3 py-1.5 text-white focus:outline-none focus:border-[#00ff66]"
                >
                  <option value="featured">FEATURED</option>
                  <option value="price-asc">PRICE: LOW TO HIGH</option>
                  <option value="price-desc">PRICE: HIGH TO LOW</option>
                  <option value="rating">HIGHEST RATED</option>
                </select>
              </div>

              {(selectedCategory !== 'ALL' || selectedStyle !== 'ALL' || zeroProofOnly || sortBy !== 'featured') && (
                <button
                  onClick={resetFilters}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-neutral-900 text-neutral-400 hover:text-white rounded border border-neutral-800"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>RESET</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Product Count & Grid */}
        <div className="space-y-4">
          <div className="font-mono text-xs text-neutral-400 flex items-center justify-between">
            <span>SHOWING {filteredProducts.length} PRODUCTS</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function ShopPage() {
  return (
    <ShopProvider>
      <ShopContent />
    </ShopProvider>
  );
}
