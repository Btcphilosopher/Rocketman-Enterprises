'use client';

import React, { useState } from 'react';
import { useParams, notFound } from 'next/navigation';
import Link from 'next/link';
import {
  ShoppingBag,
  Heart,
  Check,
  ShieldAlert,
  ShieldCheck,
  ChevronDown,
  Star,
  ArrowRight,
  Truck,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import { ShopProvider, useShop } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ProductCanGraphic } from '@/components/product/ProductCanGraphic';
import { ProductCard } from '@/components/product/ProductCard';
import { PRODUCTS } from '@/data/products';

function ProductDetailContent() {
  const params = useParams();
  const slug = params?.slug as string;

  const product = PRODUCTS.find((p) => p.slug === slug || p.id === slug);

  if (!product) {
    return (
      <div className="min-h-screen bg-[#08090a] text-white flex flex-col items-center justify-center p-4">
        <h1 className="font-display font-bold text-3xl uppercase">PRODUCT SIGNAL NOT FOUND</h1>
        <p className="font-mono text-xs text-neutral-400 mt-2">The requested beer node does not exist in the open network catalog.</p>
        <Link href="/shop" className="mt-4 px-6 py-3 bg-[#00ff66] text-black font-mono font-bold text-xs uppercase rounded">
          RETURN TO SHOP
        </Link>
      </div>
    );
  }

  const { addToCart, wishlist, toggleWishlist, ageVerified, setIsAgeModalOpen } = useShop();

  const [selectedVariantIndex, setSelectedVariantIndex] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [addedSuccess, setAddedSuccess] = useState(false);
  const [activeAccordion, setActiveAccordion] = useState<string | null>('THE PROFILE');

  const currentVariant = product.variants[selectedVariantIndex] || product.variants[0];
  const isWishlisted = wishlist.includes(product.id);

  const relatedProducts = PRODUCTS.filter((p) =>
    product.relatedProductIds.includes(p.id)
  );

  const handleAddToCart = () => {
    if (product.isAgeRestricted && !ageVerified) {
      setIsAgeModalOpen(true);
      return;
    }
    addToCart(product, currentVariant, quantity);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 2000);
  };

  const accordionSections = [
    {
      id: 'THE PROFILE',
      title: 'THE PROFILE & TASTING NOTES',
      content: (
        <div className="space-y-3 font-mono text-xs text-neutral-300">
          <p>{product.description}</p>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {product.tastingProfile.primaryNotes.map((note, idx) => (
              <span key={idx} className="px-2 py-1 bg-neutral-900 border border-neutral-800 text-[#00ff66] rounded font-bold">
                {note}
              </span>
            ))}
          </div>
          {product.tastingProfile.bitternessIbu && (
            <div className="pt-2 text-neutral-400">
              IBU BITTERNESS RATING: <span className="text-white font-bold">{product.tastingProfile.bitternessIbu} / 100</span>
            </div>
          )}
        </div>
      ),
    },
    {
      id: 'THE BREW',
      title: 'THE BREW & INGREDIENTS',
      content: (
        <div className="space-y-2 font-mono text-xs text-neutral-300">
          <div><span className="text-neutral-500">INGREDIENTS:</span> {product.ingredients.join(', ')}</div>
          <div><span className="text-neutral-500">SERVING RECOMMENDATION:</span> {product.servingRecs}</div>
          {product.buildReleaseNotes && (
            <div className="p-3 bg-neutral-900 rounded border border-neutral-800 mt-2">
              <div className="text-[#00ff66] font-bold">BUILD SPECS: {product.buildReleaseNotes.buildNumber}</div>
              <div>Hops: {product.buildReleaseNotes.hops.join(', ')}</div>
              <div>Fermentation: {product.buildReleaseNotes.fermentation}</div>
            </div>
          )}
        </div>
      ),
    },
    {
      id: 'THE PACKAGING',
      title: 'THE PACKAGING & SUSTAINABILITY',
      content: (
        <div className="space-y-2 font-mono text-xs text-neutral-300">
          <p>{product.packagingDetails}</p>
          <p className="text-emerald-400 font-semibold">{product.sustainabilityInfo}</p>
        </div>
      ),
    },
    {
      id: 'THE DETAILS',
      title: 'THE SPECIFICATIONS & CODE',
      content: (
        <div className="space-y-1 font-mono text-xs text-neutral-300">
          <div>SKU CODE: <span className="text-white font-bold">{currentVariant.sku}</span></div>
          <div>PRODUCT CODE: <span className="text-white font-bold">{product.code}</span></div>
          <div>ABV LEVEL: <span className="text-[#00ff66] font-bold">{product.abv}%</span></div>
          <div>STOCK STATUS: <span className="text-white font-bold">{currentVariant.inventoryStatus}</span></div>
        </div>
      ),
    },
    {
      id: 'SHIPPING',
      title: 'SHIPPING & DISPATCH',
      content: (
        <div className="space-y-2 font-mono text-xs text-neutral-300">
          <p>UK Express Delivery available on all orders. Free delivery over £40.</p>
          <p>Shipped in heavy-duty recyclable transit boxes with tamper-evident security seals.</p>
        </div>
      ),
    },
    {
      id: 'ALLERGENS',
      title: 'ALLERGEN INFORMATION',
      content: (
        <div className="font-mono text-xs text-neutral-300">
          {product.allergens.length > 0 ? (
            <span className="text-amber-400 font-bold">{product.allergens.join(', ')}</span>
          ) : (
            <span>No registered major gluten or dairy allergens.</span>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-12">
        {/* Breadcrumb */}
        <div className="font-mono text-xs text-neutral-500 flex items-center gap-2">
          <Link href="/shop" className="hover:text-white">SHOP</Link>
          <span>/</span>
          <Link href={`/${product.category.toLowerCase()}`} className="hover:text-white">{product.category}</Link>
          <span>/</span>
          <span className="text-[#00ff66] font-bold">{product.name}</span>
        </div>

        {/* Product Hero Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left: Product Can Render / Gallery */}
          <div className="lg:col-span-6 bg-[#0e1014] border border-[#22252b] rounded-xl p-8 sm:p-12 flex items-center justify-center relative shadow-2xl overflow-hidden group">
            <div className="absolute inset-0 bg-tech-grid opacity-15 pointer-events-none" />

            <div className="relative z-10 transform transition-transform duration-500 group-hover:scale-105">
              <ProductCanGraphic product={product} size="xl" />
            </div>

            {/* Code tag */}
            <div className="absolute top-4 left-4 px-2.5 py-1 bg-black/80 border border-neutral-700 font-mono text-[10px] text-neutral-300 rounded">
              SIGNAL: {product.code}
            </div>
          </div>

          {/* Right: Product Info & Actions */}
          <div className="lg:col-span-6 space-y-6">
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                {product.isZeroProof ? (
                  <span className="px-2.5 py-0.5 bg-[#00ff66] text-black font-mono font-bold text-xs uppercase rounded">
                    0.0% ABV ZERO-PROOF
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 bg-neutral-800 text-neutral-300 border border-neutral-700 font-mono font-bold text-xs uppercase rounded">
                    {product.abv}% ABV
                  </span>
                )}
                <span className="px-2.5 py-0.5 bg-neutral-900 text-neutral-400 font-mono text-xs uppercase rounded border border-neutral-800">
                  {product.style}
                </span>
              </div>

              <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
                {product.name}
              </h1>

              <p className="font-mono text-sm text-[#00ff66] font-bold tracking-wider uppercase">
                {product.tagline}
              </p>
            </div>

            {/* Price & Rating */}
            <div className="flex items-center justify-between pb-4 border-b border-[#22252b]">
              <div>
                <div className="font-mono font-bold text-3xl text-white">
                  £{currentVariant.unitPrice.toFixed(2)}
                </div>
                {currentVariant.compareAtPrice && (
                  <span className="font-mono text-xs text-neutral-500 line-through">
                    £{currentVariant.compareAtPrice.toFixed(2)}
                  </span>
                )}
              </div>

              {product.rating > 0 && (
                <div className="flex items-center gap-1.5 text-amber-400 font-mono text-xs">
                  <Star className="w-4 h-4 fill-amber-400" />
                  <span className="font-bold">{product.rating}</span>
                  <span className="text-neutral-500">({product.reviewCount} reviews)</span>
                </div>
              )}
            </div>

            {/* Pack Size Selection */}
            {product.variants.length > 1 && (
              <div className="space-y-2 font-mono text-xs">
                <label className="text-neutral-400 font-bold block">SELECT PACK SIZE:</label>
                <div className="grid grid-cols-3 gap-2">
                  {product.variants.map((v, i) => (
                    <button
                      key={v.id}
                      onClick={() => setSelectedVariantIndex(i)}
                      className={`py-3 px-3 rounded font-bold border transition-all text-center ${
                        selectedVariantIndex === i
                          ? 'bg-[#00ff66] text-black border-[#00ff66] shadow-lg'
                          : 'bg-neutral-900 text-neutral-300 border-neutral-800 hover:border-neutral-700'
                      }`}
                    >
                      <span className="block text-sm">{v.packSize} CANS</span>
                      <span className="block text-[10px] font-normal opacity-80">
                        £{(v.unitPrice / v.packSize).toFixed(2)} / CAN
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity and Add to Cart */}
            <div className="flex items-center gap-4 pt-2">
              <div className="flex items-center border border-neutral-800 rounded bg-neutral-900 font-mono text-sm py-3 px-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-2 text-neutral-400 hover:text-white"
                >
                  -
                </button>
                <span className="px-3 font-bold text-white">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-2 text-neutral-400 hover:text-white"
                >
                  +
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                disabled={currentVariant.inventoryStatus === 'SOLD_OUT'}
                className={`flex-1 py-4 px-6 font-mono font-bold text-sm tracking-wider uppercase rounded transition-all flex items-center justify-center gap-2 ${
                  addedSuccess
                    ? 'bg-emerald-500 text-black'
                    : 'bg-[#00ff66] text-black hover:bg-[#39ff14] shadow-xl shadow-[#00ff66]/20'
                }`}
              >
                {addedSuccess ? (
                  <>
                    <Check className="w-5 h-5" />
                    <span>ADDED TO DISPATCH CART</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-5 h-5" />
                    <span>ADD TO CART (£{(currentVariant.unitPrice * quantity).toFixed(2)})</span>
                  </>
                )}
              </button>

              <button
                onClick={() => toggleWishlist(product.id)}
                className={`p-4 rounded border transition-colors ${
                  isWishlisted
                    ? 'bg-red-500/10 border-red-500 text-red-500'
                    : 'bg-neutral-900 border-neutral-800 text-neutral-400 hover:text-white'
                }`}
                aria-label="Wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Quick Badges */}
            <div className="pt-4 grid grid-cols-2 gap-3 border-t border-[#22252b] font-mono text-xs text-neutral-400">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-[#00ff66]" />
                <span>EXPRESS UK SHIPPING</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#00ff66]" />
                <span>AGE VERIFIED COMPLIANCE</span>
              </div>
            </div>

            {/* Accordion Sections */}
            <div className="pt-6 border-t border-[#22252b] space-y-2">
              {accordionSections.map((sec) => {
                const isOpen = activeAccordion === sec.id;
                return (
                  <div key={sec.id} className="border border-[#22252b] bg-[#0d0f13] rounded overflow-hidden">
                    <button
                      onClick={() => setActiveAccordion(isOpen ? null : sec.id)}
                      className="w-full text-left px-4 py-3 font-mono font-bold text-xs text-white uppercase flex items-center justify-between hover:bg-neutral-900 transition-colors"
                    >
                      <span>{sec.title}</span>
                      <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180 text-[#00ff66]' : 'text-neutral-500'}`} />
                    </button>
                    {isOpen && <div className="px-4 pb-4">{sec.content}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="pt-12 border-t border-[#22252b] space-y-6">
            <h2 className="font-display font-bold text-2xl text-white uppercase">
              RELATED SIGNALS IN FLIGHT
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        )}
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function ProductDetailPage() {
  return (
    <ShopProvider>
      <ProductDetailContent />
    </ShopProvider>
  );
}
