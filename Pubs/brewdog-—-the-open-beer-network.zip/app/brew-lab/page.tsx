'use client';

import React from 'react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { PRODUCTS } from '@/data/products';
import { Terminal, Cpu, Sparkles, Check, ArrowRight } from 'lucide-react';
import { ProductCard } from '@/components/product/ProductCard';

function BrewLabContent() {
  const labProducts = PRODUCTS.filter((p) => p.buildReleaseNotes);

  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-10 space-y-12">
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-[#00ff66]" />
            <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
              EXPERIMENTAL BREW LAB & RELEASE NOTES
            </span>
          </div>
          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            BREW LAB // EXPERIMENTAL BUILDS
          </h1>
          <p className="font-mono text-xs sm:text-sm text-neutral-400 max-w-2xl">
            Where our master brewers test new hop varieties, wild fermentation cultures, and zero-proof vacuum extraction parameters. Full release logs provided.
          </p>
        </div>

        {/* Release Notes Inspector Stack */}
        <div className="space-y-6">
          <h2 className="font-display font-bold text-2xl text-white uppercase">
            ACTIVE BREW BUILD LOGS
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {labProducts.map((p) => (
              <div
                key={p.id}
                className="bg-[#0e1014] border border-[#22252b] hover:border-[#00ff66]/50 rounded-lg p-6 space-y-4 font-mono text-xs"
              >
                <div className="flex items-center justify-between pb-3 border-b border-[#22252b]">
                  <span className="text-[#00ff66] font-bold text-sm">{p.buildReleaseNotes?.buildNumber}</span>
                  <span className="px-2 py-0.5 bg-neutral-900 border border-neutral-700 text-neutral-300 text-[10px] uppercase rounded">
                    STATUS: {p.buildReleaseNotes?.status}
                  </span>
                </div>

                <div className="space-y-2">
                  <h3 className="font-display font-bold text-xl text-white uppercase">{p.name}</h3>
                  <p className="text-neutral-400 text-xs">{p.description}</p>
                </div>

                <div className="bg-[#12151b] p-3 rounded border border-neutral-800 space-y-1 text-[11px]">
                  <div><span className="text-neutral-500">HOPS:</span> <span className="text-white font-bold">{p.buildReleaseNotes?.hops.join(' / ')}</span></div>
                  <div><span className="text-neutral-500">FERMENTATION:</span> <span className="text-white font-bold">{p.buildReleaseNotes?.fermentation}</span></div>
                  {p.buildReleaseNotes?.waterProfile && (
                    <div><span className="text-neutral-500">WATER PROFILE:</span> <span className="text-white font-bold">{p.buildReleaseNotes?.waterProfile}</span></div>
                  )}
                  <div><span className="text-neutral-500">ABV LEVEL:</span> <span className="text-[#00ff66] font-bold">{p.abv}%</span></div>
                </div>

                <div className="pt-2 flex justify-end">
                  <a
                    href={`/product/${p.slug}`}
                    className="px-4 py-2 bg-[#00ff66] text-black font-bold uppercase text-[11px] rounded hover:bg-[#39ff14] transition-colors flex items-center gap-1"
                  >
                    <span>INSPECT BATCH</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function BrewLabPage() {
  return (
    <ShopProvider>
      <BrewLabContent />
    </ShopProvider>
  );
}
