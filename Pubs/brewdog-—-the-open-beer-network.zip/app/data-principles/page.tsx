'use client';

import React from 'react';
import { ShopProvider } from '@/context/ShopContext';
import { AnnouncementBar } from '@/components/navigation/AnnouncementBar';
import { Header } from '@/components/navigation/Header';
import { Footer } from '@/components/navigation/Footer';
import { AgeVerificationModal } from '@/components/common/AgeVerificationModal';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { SearchDrawer } from '@/components/search/SearchDrawer';
import { ShieldCheck, Lock, EyeOff, Trash2, CheckCircle2 } from 'lucide-react';

function DataPrinciplesContent() {
  return (
    <div className="min-h-screen bg-[#08090a] text-[#f1f3f5] font-sans flex flex-col">
      <AnnouncementBar />
      <Header />

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-12 space-y-10">
        <div className="border-b border-[#22252b] pb-6 space-y-2">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#00ff66]" />
            <span className="font-mono text-xs text-[#00ff66] bg-[#00ff66]/10 px-2.5 py-1 rounded border border-[#00ff66]/20 font-bold uppercase">
              CYPHERPUNK DATA PRIVACY POLICY
            </span>
          </div>
          <h1 className="font-display font-black text-3xl sm:text-5xl text-white uppercase tracking-tight">
            PERSONAL DATA PRINCIPLES
          </h1>
          <p className="font-mono text-xs sm:text-sm text-neutral-400 max-w-2xl">
            We believe digital sovereignty starts with respectful e-commerce. How we handle operator data on The Open Beer Network.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
          <div className="p-6 bg-[#0e1014] border border-[#22252b] rounded-lg space-y-3">
            <Lock className="w-6 h-6 text-[#00ff66]" />
            <h2 className="font-display font-bold text-lg text-white uppercase">
              1. MINIMAL NECESSARY DATA
            </h2>
            <p className="text-neutral-400 leading-relaxed">
              We collect only what is strictly required to ship physical craft beer to your address and verify age compliance under UK law.
            </p>
          </div>

          <div className="p-6 bg-[#0e1014] border border-[#22252b] rounded-lg space-y-3">
            <EyeOff className="w-6 h-6 text-amber-400" />
            <h2 className="font-display font-bold text-lg text-white uppercase">
              2. ZERO DATA SELLING
            </h2>
            <p className="text-neutral-400 leading-relaxed">
              We will never sell, lease, or monetize your contact information, order history, or browsing habits to third-party ad brokers or data aggregators.
            </p>
          </div>

          <div className="p-6 bg-[#0e1014] border border-[#22252b] rounded-lg space-y-3">
            <CheckCircle2 className="w-6 h-6 text-sky-400" />
            <h2 className="font-display font-bold text-lg text-white uppercase">
              3. TRANSPARENT CONSENT
            </h2>
            <p className="text-neutral-400 leading-relaxed">
              Age verification and newsletter subscriptions are strictly opt-in. You can clear local storage state or unsubscribe at any time in one click.
            </p>
          </div>

          <div className="p-6 bg-[#0e1014] border border-[#22252b] rounded-lg space-y-3">
            <Trash2 className="w-6 h-6 text-red-400" />
            <h2 className="font-display font-bold text-lg text-white uppercase">
              4. EASY DATA DELETION
            </h2>
            <p className="text-neutral-400 leading-relaxed">
              Operators can request complete purge of order history and account profiles with zero bureaucratic friction.
            </p>
          </div>
        </div>

        <div className="p-4 bg-neutral-900 border border-neutral-800 rounded font-mono text-[11px] text-neutral-400">
          <p className="font-bold text-neutral-300">PROTOTYPE NOTICE:</p>
          <p>
            These principles reflect the design philosophy of the BrewDog: The Open Beer Network prototype applet and do not assert BrewDog’s global corporate legal policies.
          </p>
        </div>
      </main>

      <Footer />

      <AgeVerificationModal />
      <CartDrawer />
      <SearchDrawer />
    </div>
  );
}

export default function DataPrinciplesPage() {
  return (
    <ShopProvider>
      <DataPrinciplesContent />
    </ShopProvider>
  );
}
