export type ProductCategory = 
  | 'BEER'
  | 'ZERO-PROOF'
  | 'NETWORK DROPS'
  | 'MIXED PACKS'
  | 'MERCH'
  | 'ACCESSORIES'
  | 'BREW LAB';

export type InventoryStatus = 'IN_STOCK' | 'LOW_STOCK' | 'PRE_ORDER' | 'SOLD_OUT' | 'LIMITED_DROP';

export interface TastingProfile {
  primaryNotes: string[];
  bitternessIbu?: number;
  bodyScore: number; // 1-5
  hoppinessScore: number; // 1-5
  maltinessScore: number; // 1-5
  aromaDescriptors: string[];
}

export interface ProductImage {
  id: string;
  url: string;
  alt: string;
  isPrimary?: boolean;
  canColorHex?: string;
  accentColorHex?: string;
  packagingType?: 'CAN' | 'BOTTLE' | 'APPAREL' | 'HARDWARE' | 'GLASSWARE' | 'PACK';
}

export interface ProductVariant {
  id: string;
  sku: string;
  packSize: 4 | 6 | 12 | 24 | 1; // 1 for merch/single items
  unitPrice: number; // price in GBP
  compareAtPrice?: number;
  inventoryQuantity: number;
  inventoryStatus: InventoryStatus;
  weightGrams?: number;
}

export interface Product {
  id: string;
  code: string; // e.g. "BD-NODE-000"
  name: string;
  slug: string;
  category: ProductCategory;
  subCategory?: string;
  style?: string;
  abv: number; // 0.0 to 12.0+
  isZeroProof: boolean;
  tagline: string; // Brand language e.g. "LOW LATENCY. HIGH FLAVOUR."
  description: string;
  tastingProfile: TastingProfile;
  ingredients: string[];
  allergens: string[];
  servingRecs: string;
  packagingDetails: string;
  sustainabilityInfo: string;
  variants: ProductVariant[];
  images: ProductImage[];
  isLimitedRelease?: boolean;
  releaseDropId?: string;
  buildReleaseNotes?: {
    buildNumber: string;
    hops: string[];
    fermentation: string;
    waterProfile?: string;
    status: string;
  };
  featured: boolean;
  rating: number; // e.g. 4.8
  reviewCount: number;
  relatedProductIds: string[];
  isAgeRestricted: boolean; // true for ABV > 0
}

export interface CartItem {
  id: string;
  productId: string;
  variantId: string;
  product: Product;
  variant: ProductVariant;
  quantity: number;
  isMixedPackItem?: boolean;
  customMixedPack?: MixedPack;
}

export interface MixedPackItem {
  product: Product;
  quantity: number;
}

export interface MixedPack {
  id: string;
  name: string;
  size: 6 | 12 | 24;
  isZeroProofOnly: boolean;
  flavourProfileFilter?: string;
  items: MixedPackItem[];
  totalCans: number;
  totalPrice: number;
}

export interface Address {
  fullName: string;
  line1: string;
  line2?: string;
  city: string;
  postcode: string;
  country: string;
  isDefault?: boolean;
}

export interface Customer {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  networkTier: 'OPERATOR' | 'NODE_ADMIN' | 'CYPHER_VIP';
  ageVerified: boolean;
  savedAddresses: Address[];
  orderHistory: string[]; // order IDs
  wishlistProductIds: string[];
}

export interface Promotion {
  code: string;
  discountPercentage?: number;
  flatDiscountGbp?: number;
  freeShipping?: boolean;
  minimumSpend?: number;
  description: string;
}

export interface ReleaseDrop {
  id: string;
  dropCode: string; // e.g. "DROP 001"
  title: string;
  subtitle: string;
  releaseDateISO: string; // ISO date
  status: 'NOW_OPEN' | 'UPCOMING' | 'ARCHIVED';
  featuredProductIds: string[];
  storyText: string;
  tastingFlightNotes: string;
  totalUnitsAvailable: number;
  unitsRemaining: number;
}

export interface OrderDraft {
  id: string;
  items: CartItem[];
  subtotal: number;
  discountAmount: number;
  shippingFee: number;
  totalAmount: number;
  promotionCode?: string;
  customerEmail: string;
  shippingAddress?: Address;
  ageVerifiedConfirmed: boolean;
  status: 'DRAFT' | 'PAID_DEMO' | 'CANCELLED';
  createdAtISO: string;
}

export interface NewsletterSubscription {
  email: string;
  subscribedAtISO: string;
  preferences: {
    newDrops: boolean;
    localEvents: boolean;
    brewLabNotes: boolean;
  };
}
