export interface Product {
  id: string;
  name: string;
  category: 'protein' | 'pre-workout' | 'vitamins' | 'apparel' | 'stacks';
  tagline: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewsCount: number;
  image: string;
  flavors?: string[];
  sizes?: string[];
  description: string;
  benefits: string[];
  specs: {
    label: string;
    value: string;
  }[];
  nutritionFacts?: {
    servingSize: string;
    servingsPerContainer: number;
    calories: number;
    protein?: string;
    carbs?: string;
    fat?: string;
    sodium?: string;
    activeIngredients?: { name: string; amount: string; dailyValue?: string }[];
  };
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedFlavor?: string;
  selectedSize?: string;
}

export interface CustomIngredient {
  id: string;
  name: string;
  category: 'energy' | 'pump' | 'focus' | 'recovery';
  amount: number; // in mg or g
  maxAmount: number;
  unit: string;
  description: string;
  color: string;
  pricePerUnit: number; // price per 1g/mg
}
