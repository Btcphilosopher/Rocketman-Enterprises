import { Product, CustomIngredient } from './types';

// Let's use the precise image paths generated earlier
export const PRODUCTS: Product[] = [
  {
    id: 'whey-protein',
    name: 'AUREOM WHEY PROTEIN',
    category: 'protein',
    tagline: 'BUILD & RECOVER',
    price: 39.99,
    originalPrice: 45.00,
    rating: 4.9,
    reviewsCount: 1420,
    image: '/src/assets/images/whey_protein_tub_1784888203566.jpg',
    flavors: ['CHOCOLATE RAVE', 'VANILLA STATIC', 'ACID LIME RIPPLE'],
    sizes: ['1.0KG', '2.0KG'],
    description: 'An advanced micro-filtered whey protein isolate engineered for rapid absorption, muscle repair, and absolute purity. Free from fillers, enriched with digestive enzymes, and optimized for elite physical output.',
    benefits: [
      '25g Pure Isolate Protein per scoop',
      '5.5g Branched Chain Amino Acids (BCAAs)',
      'Zero added sugars & extremely low carbs',
      'DigeZyme® complex for seamless digestion',
      'Engineered in Great Britain for premium standards'
    ],
    specs: [
      { label: 'Origin', value: 'United Kingdom' },
      { label: 'Servings', value: '30 per container' },
      { label: 'Form', value: 'Ultra-Fine Powder' },
      { label: 'Certificate', value: 'Informed-Sport Tested' }
    ],
    nutritionFacts: {
      servingSize: '1 Scoop (33g)',
      servingsPerContainer: 30,
      calories: 120,
      protein: '25g',
      carbs: '1.2g',
      fat: '0.8g',
      sodium: '95mg',
      activeIngredients: [
        { name: 'L-Leucine (BCAA)', amount: '2.6g' },
        { name: 'L-Isoleucine (BCAA)', amount: '1.4g' },
        { name: 'L-Valine (BCAA)', amount: '1.5g' },
        { name: 'DigeZyme® Multi-Enzyme', amount: '50mg' }
      ]
    }
  },
  {
    id: 'pre-workout',
    name: 'AUREOM PRE-WORKOUT',
    category: 'pre-workout',
    tagline: 'ENERGY & FOCUS',
    price: 34.99,
    rating: 4.8,
    reviewsCount: 894,
    image: '/src/assets/images/cat_preworkout_1784888214503.jpg',
    flavors: ['ACID LIME BLAST', 'ELECTRIC MELON', 'AMPHETAMINE BLUE'],
    sizes: ['300G'],
    description: 'A clinical-strength multi-stage pre-workout designed to supply razor-sharp cognitive focus, maximum muscular pump, and sustained explosive power. No crashes, no synthetic jitters—only pure, relentless drive.',
    benefits: [
      '8000mg L-Citrulline Malate for massive blood flow',
      '3200mg Beta-Alanine for lactic acid buffering',
      '350mg PurCaf® Organic Caffeine for clean energy',
      '200mg L-Theanine for hyper-focused tunnel vision',
      'Electrolyte matrix to support cell hydration'
    ],
    specs: [
      { label: 'Origin', value: 'United Kingdom' },
      { label: 'Servings', value: '30 per tub' },
      { label: 'Stimulant', value: 'High (350mg Caffeine)' },
      { label: 'Banned Sub.', value: '100% Free / WADA Compliant' }
    ],
    nutritionFacts: {
      servingSize: '1 Scoop (15g)',
      servingsPerContainer: 30,
      calories: 15,
      carbs: '2.0g',
      activeIngredients: [
        { name: 'L-Citrulline Malate 2:1', amount: '8000mg' },
        { name: 'Beta-Alanine', amount: '3200mg' },
        { name: 'Betaine Anhydrous', amount: '2500mg' },
        { name: 'Organic Caffeine', amount: '350mg' },
        { name: 'L-Theanine', amount: '200mg' },
        { name: 'Huperzine A 1%', amount: '200mcg' }
      ]
    }
  },
  {
    id: 'vitamins',
    name: 'AUREOM ESSENTIALS',
    category: 'vitamins',
    tagline: 'DAILY OPTIMISATION',
    price: 24.99,
    rating: 4.7,
    reviewsCount: 512,
    image: '/src/assets/images/cat_vitamins_1784888228407.jpg',
    flavors: ['UNFLAVOURED CAPSULES'],
    sizes: ['60 CAPSULES'],
    description: 'A high-potency daily micronutrient stack meticulously designed for active individuals. Supports bone density, hormone regulation, and metabolic rate, ensuring your body operates at Peak British Efficiency.',
    benefits: [
      'Optimal dosage of D3 & K2 for calcium absorption',
      'High-absorption Zinc Bisglycinate and Magnesium Oxide',
      'Enriched with adaptogenic Ashwagandha for cortisol control',
      'Coenzyme Q10 for advanced cellular energy synthesis',
      'Heavy metal and purity lab-tested'
    ],
    specs: [
      { label: 'Serving Size', value: '2 Capsules Daily' },
      { label: 'Supply', value: '30 Days' },
      { label: 'Capsule', value: '100% Vegan HPMC' },
      { label: 'Testing', value: 'Triple-Lab Verified' }
    ],
    nutritionFacts: {
      servingSize: '2 Capsules',
      servingsPerContainer: 30,
      calories: 0,
      activeIngredients: [
        { name: 'Vitamin D3 (Cholecalciferol)', amount: '5000 IU', dailyValue: '625%' },
        { name: 'Vitamin K2 (MK-7)', amount: '120mcg', dailyValue: '100%' },
        { name: 'Magnesium Bisglycinate', amount: '300mg', dailyValue: '75%' },
        { name: 'Zinc Bisglycinate', amount: '25mg', dailyValue: '227%' },
        { name: 'KSM-66® Ashwagandha', amount: '400mg', dailyValue: '*' }
      ]
    }
  },
  {
    id: 'apparel',
    name: 'AUREOM ARCHITECT TEE',
    category: 'apparel',
    tagline: 'TRAIN WITHOUT LIMITS',
    price: 45.00,
    rating: 4.9,
    reviewsCount: 318,
    image: '/src/assets/images/cat_apparel_1784888239107.jpg',
    flavors: ['MATTE BLACK', 'GRAPHITE GREY'],
    sizes: ['S', 'M', 'L', 'XL'],
    description: 'An ultra-light, double-weave technical athletic tee. Tailored to move with your physique, utilizing laser-cut ventilation, bonded seams, and premium sweat-wicking synthetic British fibers.',
    benefits: [
      'Advanced 4-way stretch poly-elastane fabric',
      'Laser-perforated heat zones along the spine',
      'Zero-chafe seamless construction',
      'Reflective neon-lime chest branding',
      'Built to survive brutal warehouse training conditions'
    ],
    specs: [
      { label: 'Material', value: '88% Polyester / 12% Elastane' },
      { label: 'Fit', value: 'Athletic / Sculpted Fit' },
      { label: 'Wash', value: 'Machine Cold / Hang Dry' },
      { label: 'Tech', value: 'Aero-Weave Breathability' }
    ]
  },
  {
    id: 'stacks',
    name: 'AUREOM COMPLETE SYSTEM',
    category: 'stacks',
    tagline: 'MAXIMUM RESULTS',
    price: 89.99,
    originalPrice: 109.97,
    rating: 4.95,
    reviewsCount: 742,
    image: '/src/assets/images/cat_stacks_1784888252887.jpg',
    flavors: ['DEFAULT COMBINATION', 'CUSTOM COMBINATION'],
    sizes: ['COMPLETE BUNDLE'],
    description: 'The ultimate performance stack. Combines our signature Whey Isolate (1.0kg), Pre-Workout (300g), and Essentials Vitamins. Engineered to synchronise recovery, mental focus, and everyday biochemical output.',
    benefits: [
      'Includes Aureom Whey, Aureom Pre, & Essentials',
      'Save over £20 compared to buying individually',
      'Fully customizable flavor selection',
      'Comes with a free matte black steel shaker cup',
      'Guaranteed next-day shipping in premium matte box'
    ],
    specs: [
      { label: 'Items', value: '3 Signature Formulas + Steel Shaker' },
      { label: 'Storage', value: 'Cool, dark place' },
      { label: 'Usage', value: 'Full training-cycle plan included' },
      { label: 'Box', value: 'Eco-Brutalist Recycled Cardboard' }
    ]
  }
];

export const CUSTOM_INGREDIENTS: CustomIngredient[] = [
  {
    id: 'citrulline',
    name: 'L-Citrulline Malate 2:1',
    category: 'pump',
    amount: 4000,
    maxAmount: 10000,
    unit: 'mg',
    description: 'Boosts nitric oxide production for dramatic muscle pumps and endurance.',
    color: '#D8FF00', // Acid Lime
    pricePerUnit: 0.0015 // per mg
  },
  {
    id: 'beta_alanine',
    name: 'Beta-Alanine',
    category: 'energy',
    amount: 1600,
    maxAmount: 4000,
    unit: 'mg',
    description: 'Buffers lactic acid to delay muscular fatigue and increase total training volume.',
    color: '#EAF000',
    pricePerUnit: 0.002
  },
  {
    id: 'organic_caffeine',
    name: 'Caffeine Anhydrous',
    category: 'energy',
    amount: 150,
    maxAmount: 400,
    unit: 'mg',
    description: 'Increases central nervous system arousal, reaction speed, and raw energy output.',
    color: '#FFFFFF',
    pricePerUnit: 0.015
  },
  {
    id: 'alpha_gpc',
    name: 'Alpha-GPC 50%',
    category: 'focus',
    amount: 300,
    maxAmount: 800,
    unit: 'mg',
    description: 'Crosses blood-brain barrier to raise acetylcholine for laser-sharp cognitive drive.',
    color: '#A8B890',
    pricePerUnit: 0.012
  },
  {
    id: 'creatine',
    name: 'Creatine Monohydrate',
    category: 'recovery',
    amount: 2500,
    maxAmount: 5000,
    unit: 'mg',
    description: 'Saturates intramuscular ATP stores for absolute power, cell volume, and strength.',
    color: '#00F3FF', // Cyan accent
    pricePerUnit: 0.001
  }
];
