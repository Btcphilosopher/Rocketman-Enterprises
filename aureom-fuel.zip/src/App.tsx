import React, { useState, useEffect } from 'react';
import { PRODUCTS } from './data';
import { Product, CartItem } from './types';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import StackBuilder from './components/StackBuilder';
import RavePulse from './components/RavePulse';
import CartDrawer from './components/CartDrawer';
import { 
  Truck, 
  FlaskConical, 
  TrendingUp, 
  Award, 
  ShieldAlert, 
  Dribbble, 
  Instagram, 
  Youtube, 
  ChevronRight,
  ArrowUpRight,
  CheckCircle,
  Sparkles
} from 'lucide-react';

export default function App() {
  // Cart state synchronized with LocalStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('aureom_cart');
    return saved ? JSON.parse(saved) : [];
  });

  // Selected product state for details modal
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');

  // Atmosphere engine states mapped from RavePulse to page pulse animations
  const [bassLevel, setBassLevel] = useState(65);
  const [laserIntensity, setLaserIntensity] = useState(80);
  const [hazeDensity, setHazeDensity] = useState(40);

  // Email state for movement sign-up
  const [email, setEmail] = useState('');
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);

  // Save cart to local storage whenever it changes
  useEffect(() => {
    localStorage.setItem('aureom_cart', JSON.stringify(cart));
  }, [cart]);

  // Handle adding standard products to cart
  const handleAddToCart = (product: Product, quantity: number, flavor?: string, size?: string) => {
    setCart(prevCart => {
      // Find matching item with exact same product ID, flavor, and size
      const existingIndex = prevCart.findIndex(item => 
        item.product.id === product.id && 
        item.selectedFlavor === flavor && 
        item.selectedSize === size
      );

      if (existingIndex > -1) {
        const newCart = [...prevCart];
        newCart[existingIndex].quantity += quantity;
        return newCart;
      } else {
        return [...prevCart, { product, quantity, selectedFlavor: flavor, selectedSize: size }];
      }
    });
    // Open cart drawer for quick feedback
    setIsCartOpen(true);
  };

  // Handle adding dynamically formulated custom stacks to cart
  const handleAddCustomStackToCart = (customProduct: Product) => {
    setCart(prevCart => {
      return [...prevCart, { product: customProduct, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, qty: number, flavor?: string, size?: string) => {
    setCart(prevCart => 
      prevCart.map(item => {
        if (item.product.id === productId && item.selectedFlavor === flavor && item.selectedSize === size) {
          return { ...item, quantity: qty };
        }
        return item;
      })
    );
  };

  const handleRemoveCartItem = (productId: string, flavor?: string, size?: string) => {
    setCart(prevCart => 
      prevCart.filter(item => 
        !(item.product.id === productId && item.selectedFlavor === flavor && item.selectedSize === size)
      )
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Navigation router / smooth scrolling helper
  const handleNavigateToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setNewsletterSuccess(true);
      setEmail('');
      setTimeout(() => setNewsletterSuccess(false), 3000);
    }
  };

  // Filtered product items
  const filteredProducts = activeCategoryFilter === 'all' 
    ? PRODUCTS 
    : PRODUCTS.filter(p => p.category === activeCategoryFilter);

  // Calculate simulated pulse beat frequency based on the active Bass slider
  const pulseScale = 1 + (bassLevel / 1200); // maps 20-100 bass level to subtle scale
  const pulseDuration = `${(140 / (135 + (bassLevel * 0.1))).toFixed(2)}s`; // map to music tempo

  return (
    <div 
      className="bg-[#050505] text-white min-h-screen relative font-sans overflow-x-hidden selection:bg-[#D8FF00] selection:text-black"
      style={{
        '--pulse-duration': pulseDuration,
        '--pulse-scale': pulseScale,
      } as React.CSSProperties}
    >
      
      {/* GLOBAL BACKGROUND PULSE EFFECT IN SYNC WITH BASS ENGINE */}
      <style>{`
        @keyframes subtlePulse {
          0%, 100% { transform: scale(1); filter: brightness(1); }
          50% { transform: scale(var(--pulse-scale)); filter: brightness(1.08); }
        }
        .rave-pulsing-element {
          animation: subtlePulse var(--pulse-duration) infinite ease-in-out;
        }
      `}</style>

      {/* Header Sticky Navigation */}
      <Navbar 
        cart={cart}
        onOpenCart={() => setIsCartOpen(true)}
        onNavigateToSection={handleNavigateToSection}
      />

      {/* Hero Intro Section */}
      <div id="hero">
        <Hero 
          onShopProtein={() => {
            setSelectedProduct(PRODUCTS[0]); // opens whey protein isolate modal
          }}
          onShopAll={() => handleNavigateToSection('shop')}
          onOpenDetails={(productId) => {
            const prod = PRODUCTS.find(p => p.id === productId);
            if (prod) setSelectedProduct(prod);
          }}
        />
      </div>

      {/* VALUE PROPOSITION STRIP UNDER HERO SECTION */}
      <div className="w-full bg-[#0a0a0a] border-y border-white/5 py-6 md:py-8 select-none">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-4 divide-y md:divide-y-0 md:divide-x divide-white/5">
          
          <div className="flex items-center gap-4 pl-0 md:pl-4 pt-4 md:pt-0">
            <div className="w-10 h-10 rounded-sm bg-black/40 border border-white/5 flex items-center justify-center text-[#D8FF00] shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <span className="block text-[11px] font-mono tracking-widest text-[#D8FF00] font-bold">NEXT DAY DELIVERY</span>
              <span className="block text-[10px] text-zinc-400 font-medium">ON ALL UK ORDERS OVER £50</span>
            </div>
          </div>

          <div className="flex items-center gap-4 pl-0 md:pl-6 pt-4 md:pt-0">
            <div className="w-10 h-10 rounded-sm bg-black/40 border border-white/5 flex items-center justify-center text-[#D8FF00] shrink-0">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div>
              <span className="block text-[11px] font-mono tracking-widest text-[#D8FF00] font-bold">PREMIUM INGREDIENTS</span>
              <span className="block text-[10px] text-zinc-400 font-medium">TRIPLE VERIFIED CLINICAL DOSAGES</span>
            </div>
          </div>

          <div className="flex items-center gap-4 pl-0 md:pl-6 pt-4 md:pt-0">
            <div className="w-10 h-10 rounded-sm bg-black/40 border border-white/5 flex items-center justify-center text-[#D8FF00] shrink-0">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <span className="block text-[11px] font-mono tracking-widest text-[#D8FF00] font-bold">PERFORMANCE FOCUSED</span>
              <span className="block text-[10px] text-zinc-400 font-medium">DESIGNED FOR MAXIMUM ENDURANCE</span>
            </div>
          </div>

          <div className="flex items-center gap-4 pl-0 md:pl-6 pt-4 md:pt-0">
            <div className="w-10 h-10 rounded-sm bg-black/40 border border-white/5 flex items-center justify-center text-[#D8FF00] shrink-0">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <span className="block text-[11px] font-mono tracking-widest text-[#D8FF00] font-bold">TRUSTED BY ATHLETES</span>
              <span className="block text-[10px] text-zinc-400 font-medium">USED BY UK ELITE WORKOUT TEAMS</span>
            </div>
          </div>

        </div>
      </div>

      {/* CORE PRODUCT SYSTEM SHOP SECTION */}
      <section id="shop" className="py-20 md:py-28 bg-[#050505] relative select-none">
        
        {/* Subtle grid lines background overlay */}
        <div className="absolute inset-x-0 top-0 h-40 bg-gradient-to-b from-zinc-950/20 to-transparent pointer-events-none"></div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.005)_1px,transparent_1px)] bg-[size:6rem_6rem] pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
          
          {/* Section Headers & Filter Controls */}
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 border-b border-white/5 pb-8">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono tracking-[0.2em] text-[#D8FF00] font-bold uppercase">SYSTEM INVENTORY</span>
              </div>
              <h2 className="text-3xl sm:text-5xl font-black tracking-tighter text-white">
                THE BIOCHEMICAL SUITE.
              </h2>
              <p className="text-xs md:text-sm text-zinc-400 font-medium max-w-md">
                Select your targeted active agents to fuel specific physical domains. Informed-Sport tested, clinical purity.
              </p>
            </div>

            {/* Category selection filters */}
            <div className="flex flex-wrap gap-1.5 md:gap-2">
              {['all', 'protein', 'pre-workout', 'vitamins', 'apparel', 'stacks'].map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveCategoryFilter(cat)}
                  className={`px-3.5 py-2 font-mono text-[10px] tracking-widest font-bold border rounded-none transition-all cursor-pointer ${
                    activeCategoryFilter === cat 
                      ? 'bg-[#D8FF00] border-black text-black' 
                      : 'bg-zinc-950 border-zinc-900 text-zinc-400 hover:border-zinc-800 hover:text-white'
                  }`}
                >
                  {cat.toUpperCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Product grid displaying custom items */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
            {filteredProducts.map((prod) => (
              <ProductCard 
                key={prod.id}
                product={prod}
                onOpenDetails={(id) => setSelectedProduct(prod)}
              />
            ))}
          </div>

        </div>
      </section>

      {/* DYNAMIC ATMOSPHERE DJ STATION */}
      <RavePulse 
        onAtmosphereChange={(b, l, h) => {
          setBassLevel(b);
          setLaserIntensity(l);
          setHazeDensity(h);
        }}
      />

      {/* DYNAMIC CUSTOM INGREDIENTS STACK BUILDER */}
      <StackBuilder 
        onAddCustomStackToCart={handleAddCustomStackToCart}
      />

      {/* SCIENTIFIC EXCELLENCE BANNER */}
      <section className="py-16 md:py-24 bg-[#0a0a0a] border-t border-white/5 relative overflow-hidden select-none">
        <div className="absolute inset-0 bg-radial-[circle_at_center,rgba(216,255,0,0.015)_0%,transparent_70%] pointer-events-none"></div>
        
        <div className="max-w-5xl mx-auto px-4 md:px-8 text-center space-y-8 relative z-10">
          <div className="flex justify-center">
            {/* Crown styled geometric British badge */}
            <div className="px-3.5 py-1.5 border border-[#D8FF00]/40 rounded-sm bg-black/60 font-mono text-[9px] text-[#D8FF00] tracking-widest font-black uppercase flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-red-600 inline-block animate-ping"></span>
              UK ANTI-DOPING WADA ACCREDITATION
            </div>
          </div>

          <h3 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            ENGINEERED TO PRESERVE PURE PHYSIOLOGY.
          </h3>

          <p className="max-w-2xl mx-auto text-xs md:text-sm text-zinc-400 font-medium leading-relaxed">
            Every batch of Aureom Fuel is processed in clean GMP-registered facilities in Great Britain. 
            We submit each production iteration for independent batch chemical assays to confirm 
            the absolute absence of WADA banned compounds, assuring elite world-class security.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto pt-4 font-mono text-[9px] md:text-xs text-zinc-500 font-bold tracking-widest uppercase">
            <div className="p-3 border border-white/5 bg-black/40">100% TRANSPARENT</div>
            <div className="p-3 border border-white/5 bg-black/40">INFORMED-SPORT</div>
            <div className="p-3 border border-white/5 bg-black/40">ZERO BIO-FILLERS</div>
            <div className="p-3 border border-white/5 bg-black/40">VEGAN CAPSULE SOURCING</div>
          </div>
        </div>
      </section>

      {/* NEWSLETTER MOVEMENT SIGN-UP */}
      <section className="py-12 md:py-16 bg-[#D8FF00] text-black font-mono select-none">
        <div className="max-w-7xl mx-auto px-4 md:px-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-1">
            <h3 className="text-lg md:text-xl font-black tracking-tight uppercase">
              JOIN THE MOVEMENT.
            </h3>
            <p className="text-[10px] md:text-xs font-bold text-zinc-800 tracking-wider">
              EXCLUSIVE DROPS. EARLY ACCESS. BUILT DIFFERENT.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleNewsletterSubmit} className="flex-grow max-w-md relative">
            <input 
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="ENTER YOUR SYSTEM EMAIL ADDRESS"
              className="w-full bg-black text-white font-mono font-bold text-xs tracking-wider border-none focus:outline-none px-4 py-4 pr-16"
            />
            <button 
              type="submit"
              className="absolute right-0 top-0 h-full w-14 bg-white hover:bg-zinc-100 flex items-center justify-center border-l border-zinc-800 text-black cursor-pointer"
            >
              <ArrowUpRight className="w-5 h-5 transition-transform hover:translate-x-0.5 hover:-translate-y-0.5" />
            </button>
          </form>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#050505] border-t border-white/5 py-12 md:py-16 text-zinc-500 font-mono text-[10px] select-none">
        <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          
          {/* Column 1: Logo & Statement */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 flex items-center justify-center bg-[#0a0a0a] border border-white/10 rounded-sm">
                <svg viewBox="0 0 100 100" className="w-5 h-5 fill-[#D8FF00]">
                  <path d="M50 15 L85 85 L65 85 L50 45 L35 85 L15 85 Z M50 35 L40 68 L60 68 Z" />
                </svg>
              </div>
              <span className="text-white font-extrabold tracking-widest text-xs">AUREOM FUEL</span>
            </div>
            <p className="text-zinc-600 leading-relaxed font-semibold">
              Engineered physical nutrition designed to conquer the next paradigm of athletic performance thresholds. Made in Britain.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div className="space-y-3">
            <span className="text-white font-extrabold tracking-widest uppercase">PRODUCT PARADIGMS</span>
            <ul className="space-y-1.5 font-bold text-zinc-600">
              <li><button onClick={() => handleNavigateToSection('shop')} className="hover:text-[#D8FF00] transition-colors cursor-pointer text-left">WHEY ISOLATES</button></li>
              <li><button onClick={() => handleNavigateToSection('shop')} className="hover:text-[#D8FF00] transition-colors cursor-pointer text-left">PRE-STAGE COGNITIVES</button></li>
              <li><button onClick={() => handleNavigateToSection('shop')} className="hover:text-[#D8FF00] transition-colors cursor-pointer text-left">ESSENTIAL RECOVERIES</button></li>
              <li><button onClick={() => handleNavigateToSection('builder')} className="hover:text-[#D8FF00] transition-colors cursor-pointer text-left">CUSTOM LABS</button></li>
            </ul>
          </div>

          {/* Column 3: Company */}
          <div className="space-y-3">
            <span className="text-white font-extrabold tracking-widest uppercase">LAB NETWORK</span>
            <ul className="space-y-1.5 font-bold text-zinc-600">
              <li><a href="#hero" className="hover:text-[#D8FF00] transition-colors">OUR ETHOLOGY</a></li>
              <li><a href="#rave-station" className="hover:text-[#D8FF00] transition-colors">RAVE SYSTEM</a></li>
              <li><a href="#builder" className="hover:text-[#D8FF00] transition-colors">ACCESS ASSAY DATA</a></li>
              <li><a href="#hero" className="hover:text-[#D8FF00] transition-colors">BRITISH INVENTORY</a></li>
            </ul>
          </div>

          {/* Column 4: Contact & Socials */}
          <div className="space-y-4">
            <span className="text-white font-extrabold tracking-widest uppercase block">CONNECT</span>
            <div className="flex gap-4">
              <a href="#" className="w-8 h-8 rounded-sm bg-[#0a0a0a] border border-white/5 hover:border-[#D8FF00] flex items-center justify-center text-zinc-400 hover:text-white transition-all">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded-sm bg-[#0a0a0a] border border-white/5 hover:border-[#D8FF00] flex items-center justify-center text-zinc-400 hover:text-white transition-all">
                <Youtube className="w-4 h-4" />
              </a>
              <a href="#" className="w-8 h-8 rounded-sm bg-[#0a0a0a] border border-white/5 hover:border-[#D8FF00] flex items-center justify-center text-zinc-400 hover:text-white transition-all">
                <Dribbble className="w-4 h-4" />
              </a>
            </div>
            <div className="text-zinc-600 leading-relaxed font-semibold">
              SUPPORT@AUREOM.CO.UK <br />
              +44 203 894 2035 <br />
              LONDON WAREHOUSE HQ
            </div>
          </div>

        </div>

        {/* Dynamic Legal and copyright row */}
        <div className="max-w-7xl mx-auto px-4 md:px-8 border-t border-white/5 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-zinc-600">
          <span>© 2026 AUREOM FUEL LTD. DESIGNED & ASSEMBLED IN GREAT BRITAIN. ALL RIGHTS RESERVED.</span>
          <div className="flex gap-4 font-bold">
            <a href="#" className="hover:underline">TERMS OF TRANSMISSION</a>
            <a href="#" className="hover:underline">PRIVACY SYSTEM</a>
            <a href="#" className="hover:underline">WADA COMPLIANCE SHEET</a>
          </div>
        </div>
      </footer>

      {/* Cart Drawer Slide-out container */}
      <CartDrawer 
        isOpen={isCartOpen}
        cart={cart}
        onClose={() => setIsCartOpen(false)}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* Detailed Product Specification Modal overlay */}
      {selectedProduct && (
        <ProductDetailModal 
          product={selectedProduct}
          isOpen={true}
          onClose={() => setSelectedProduct(null)}
          onAddToCart={handleAddToCart}
        />
      )}

      {/* Newsletter signup success notification */}
      {newsletterSuccess && (
        <div className="fixed bottom-6 left-6 z-[150] bg-black border border-[#D8FF00] px-5 py-3 shadow-2xl rounded-sm flex items-center gap-3 font-mono text-xs animate-slide-in">
          <CheckCircle className="w-4 h-4 text-[#D8FF00]" />
          <div>
            <span className="text-[#D8FF00] font-black uppercase block">TRANSMISSION REGISTERED</span>
            <span className="text-zinc-400 text-[10px] block">You have joined the Aureom British movement.</span>
          </div>
        </div>
      )}

    </div>
  );
}
