import React, { useState } from 'react';
import { X, Star, Shield, ArrowRight, Sparkles, Check, ChevronDown, ListPlus } from 'lucide-react';
import { Product } from '../types';

interface ProductDetailModalProps {
  product: Product;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, quantity: number, flavor?: string, size?: string) => void;
}

export default function ProductDetailModal({ product, isOpen, onClose, onAddToCart }: ProductDetailModalProps) {
  const [selectedFlavor, setSelectedFlavor] = useState<string>(
    product.flavors && product.flavors.length > 0 ? product.flavors[0] : ''
  );
  const [selectedSize, setSelectedSize] = useState<string>(
    product.sizes && product.sizes.length > 0 ? product.sizes[0] : ''
  );
  const [quantity, setQuantity] = useState<number>(1);
  const [tab, setTab] = useState<'benefits' | 'nutrition' | 'specs'>('benefits');
  const [addedAnimation, setAddedAnimation] = useState(false);

  if (!isOpen) return null;

  const handleAddToCart = () => {
    onAddToCart(product, quantity, selectedFlavor || undefined, selectedSize || undefined);
    setAddedAnimation(true);
    setTimeout(() => {
      setAddedAnimation(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-end select-none">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/85 backdrop-blur-sm transition-opacity"
      ></div>

      {/* Slide-out Panel */}
      <div className="relative w-full max-w-2xl h-full bg-[#0a0a0a] border-l border-white/5 overflow-y-auto flex flex-col justify-between z-10 shadow-2xl">
        
        {/* Modal Header */}
        <div className="sticky top-0 bg-[#050505]/95 backdrop-blur-md z-20 border-b border-white/5 p-4 md:p-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono tracking-widest text-[#D8FF00] font-bold">SYSTEM // SPECIFICATIONS</span>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 border border-white/5 hover:border-[#D8FF00] flex items-center justify-center text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 md:p-8 space-y-8 flex-grow">
          {/* Main Hero grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Visual display stage */}
            <div className="relative aspect-square bg-zinc-900/30 border border-zinc-900 rounded-sm flex items-center justify-center p-6 overflow-hidden">
              <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(216,255,0,0.01)_1px,transparent_1px),linear-gradient(to_bottom,rgba(216,255,0,0.01)_1px,transparent_1px)] bg-[size:2rem_2rem]"></div>
              <div className="absolute top-1/2 left-0 w-full h-[1px] bg-[#D8FF00]/10 transform rotate-12"></div>
              
              <img 
                src={product.image} 
                alt={product.name} 
                className="w-full h-full object-contain relative z-10 drop-shadow-[0_20px_40px_rgba(0,0,0,0.9)]"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Title & Selection options */}
            <div className="space-y-4">
              <div className="space-y-1">
                <span className="text-xs font-mono font-bold text-[#D8FF00] tracking-widest uppercase">{product.tagline}</span>
                <h2 className="text-xl md:text-2xl font-black tracking-tight text-white leading-tight">
                  {product.name}
                </h2>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-[#D8FF00] stroke-none" />
                    <span className="text-xs font-mono font-bold text-white">{product.rating}</span>
                  </div>
                  <span className="text-xs font-mono text-zinc-500">({product.reviewsCount} REVIEWS)</span>
                </div>
              </div>

              {/* Price Segment */}
              <div className="py-2 border-y border-zinc-900 flex items-baseline gap-3">
                <span className="text-2xl font-mono font-black text-[#D8FF00]">£{product.price.toFixed(2)}</span>
                {product.originalPrice && (
                  <span className="text-sm font-mono text-zinc-600 line-through">£{product.originalPrice.toFixed(2)}</span>
                )}
              </div>

              {/* Description summary */}
              <p className="text-xs md:text-sm text-zinc-400 font-medium leading-relaxed">
                {product.description}
              </p>
            </div>
          </div>

          {/* Form Options (Flavors, Sizes, Quantities) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 md:p-6 bg-zinc-950/80 border border-zinc-900/80 rounded-sm">
            {/* Flavor selection */}
            {product.flavors && product.flavors.length > 0 && (
              <div className="space-y-2">
                <label className="text-[10px] font-mono tracking-widest text-zinc-400 uppercase font-bold flex items-center gap-1.5">
                  <span>SELECT FORMULATION / FLAVOUR</span>
                </label>
                <div className="flex flex-col gap-2">
                  {product.flavors.map((flv) => (
                    <button
                      key={flv}
                      onClick={() => setSelectedFlavor(flv)}
                      className={`text-left text-xs font-mono px-3.5 py-2.5 border transition-all ${
                        selectedFlavor === flv 
                          ? 'bg-[#D8FF00] border-black text-black font-extrabold' 
                          : 'bg-zinc-900/40 border-zinc-800 text-zinc-300 hover:border-zinc-700 hover:text-white'
                      } cursor-pointer`}
                    >
                      {flv}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size selection */}
            <div className="space-y-4">
              {product.sizes && product.sizes.length > 0 && (
                <div className="space-y-2">
                  <label className="text-[10px] font-mono tracking-widest text-zinc-400 uppercase font-bold">
                    SELECT SIZE / VOLUME
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {product.sizes.map((sz) => (
                      <button
                        key={sz}
                        onClick={() => setSelectedSize(sz)}
                        className={`text-xs font-mono px-4 py-2.5 border transition-all ${
                          selectedSize === sz 
                            ? 'bg-white border-white text-black font-extrabold' 
                            : 'bg-zinc-900/40 border-zinc-800 text-zinc-400 hover:border-zinc-700 hover:text-white'
                        } cursor-pointer`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quantity */}
              <div className="space-y-2">
                <label className="text-[10px] font-mono tracking-widest text-zinc-400 uppercase font-bold">
                  QUANTITY
                </label>
                <div className="flex items-center gap-1 w-32 border border-zinc-800">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-900 font-bold transition-colors cursor-pointer"
                  >
                    -
                  </button>
                  <span className="flex-grow text-center font-mono text-xs font-bold text-white">{quantity}</span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-10 h-10 flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-900 font-bold transition-colors cursor-pointer"
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Scientific Tabs section (Benefits, Spec Sheets, Nutrition Panel) */}
          <div className="space-y-4">
            <div className="flex border-b border-zinc-900">
              <button
                onClick={() => setTab('benefits')}
                className={`px-4 py-3 font-mono text-[10px] tracking-widest font-bold border-b-2 transition-all ${
                  tab === 'benefits' ? 'border-[#D8FF00] text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'
                } cursor-pointer`}
              >
                BENEFITS
              </button>
              {product.nutritionFacts && (
                <button
                  onClick={() => setTab('nutrition')}
                  className={`px-4 py-3 font-mono text-[10px] tracking-widest font-bold border-b-2 transition-all ${
                    tab === 'nutrition' ? 'border-[#D8FF00] text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'
                  } cursor-pointer`}
                >
                  NUTRITION FACTS
                </button>
              )}
              <button
                onClick={() => setTab('specs')}
                className={`px-4 py-3 font-mono text-[10px] tracking-widest font-bold border-b-2 transition-all ${
                  tab === 'specs' ? 'border-[#D8FF00] text-white' : 'border-transparent text-zinc-500 hover:text-zinc-300'
                } cursor-pointer`}
              >
                SPECIFICATIONS
              </button>
            </div>

            {/* Tab: Benefits */}
            {tab === 'benefits' && (
              <ul className="space-y-2.5">
                {product.benefits.map((benefit, i) => (
                  <li key={i} className="flex items-start gap-3 text-xs md:text-sm text-zinc-300">
                    <span className="text-[#D8FF00] mt-0.5 font-bold">✓</span>
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            )}

            {/* Tab: Specs */}
            {tab === 'specs' && (
              <div className="grid grid-cols-2 gap-4">
                {product.specs.map((spec, i) => (
                  <div key={i} className="border border-zinc-900 p-3 bg-zinc-950/40 rounded-sm">
                    <span className="block text-[9px] font-mono text-zinc-500 uppercase tracking-widest">{spec.label}</span>
                    <span className="block text-xs font-bold text-white mt-1">{spec.value}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Tab: Nutrition facts (High-fidelity detailed layout) */}
            {tab === 'nutrition' && product.nutritionFacts && (
              <div className="border border-zinc-800 p-4 md:p-6 bg-black font-sans text-white max-w-sm mx-auto rounded-sm">
                <h3 className="text-xl font-extrabold tracking-tight border-b-4 border-white pb-1">Nutrition Facts</h3>
                <div className="text-xs font-medium py-1.5 border-b border-zinc-600 flex justify-between">
                  <span>Serving Size</span>
                  <span className="font-extrabold">{product.nutritionFacts.servingSize}</span>
                </div>
                <div className="text-xs font-medium py-1 border-b-4 border-white flex justify-between">
                  <span>Servings Per Container</span>
                  <span className="font-extrabold">{product.nutritionFacts.servingsPerContainer}</span>
                </div>

                <div className="font-extrabold text-sm py-2 border-b border-zinc-700 flex justify-between items-baseline">
                  <span>Amount Per Serving</span>
                </div>

                <div className="font-extrabold text-base py-1.5 border-b-2 border-white flex justify-between items-baseline">
                  <span>Calories</span>
                  <span>{product.nutritionFacts.calories}</span>
                </div>

                {product.nutritionFacts.protein && (
                  <div className="text-xs py-1.5 border-b border-zinc-600 flex justify-between font-bold">
                    <span>Protein</span>
                    <span>{product.nutritionFacts.protein}</span>
                  </div>
                )}
                {product.nutritionFacts.carbs && (
                  <div className="text-xs py-1.5 border-b border-zinc-600 flex justify-between">
                    <span>Total Carbohydrate</span>
                    <span className="font-bold">{product.nutritionFacts.carbs}</span>
                  </div>
                )}
                {product.nutritionFacts.fat && (
                  <div className="text-xs py-1.5 border-b border-zinc-600 flex justify-between">
                    <span>Total Fat</span>
                    <span className="font-bold">{product.nutritionFacts.fat}</span>
                  </div>
                )}
                {product.nutritionFacts.sodium && (
                  <div className="text-xs py-1.5 border-b border-zinc-600 flex justify-between">
                    <span>Sodium</span>
                    <span className="font-bold">{product.nutritionFacts.sodium}</span>
                  </div>
                )}

                {product.nutritionFacts.activeIngredients && (
                  <div className="mt-3">
                    <h4 className="text-[10px] font-mono tracking-widest text-zinc-500 uppercase font-bold border-b border-zinc-600 pb-1 mb-1.5">Active Formulation components</h4>
                    {product.nutritionFacts.activeIngredients.map((ing, i) => (
                      <div key={i} className="text-xs py-1 border-b border-zinc-900 flex justify-between text-zinc-300">
                        <span>{ing.name}</span>
                        <div className="flex gap-2">
                          <span className="font-bold text-white">{ing.amount}</span>
                          {ing.dailyValue && <span className="text-[10px] font-mono text-zinc-500">({ing.dailyValue})</span>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Modal Action footer */}
        <div className="sticky bottom-0 bg-zinc-950/95 backdrop-blur-md border-t border-zinc-900 p-6 flex flex-col sm:flex-row gap-4">
          <button 
            disabled={addedAnimation}
            onClick={handleAddToCart}
            className={`flex-grow group relative py-4 px-6 font-mono font-black text-xs md:text-sm tracking-[0.2em] uppercase flex items-center justify-center gap-3 transition-all duration-300 cursor-pointer ${
              addedAnimation 
                ? 'bg-zinc-900 text-[#D8FF00]' 
                : 'bg-[#D8FF00] hover:bg-white text-black'
            }`}
          >
            {addedAnimation ? (
              <>
                <Check className="w-4 h-4 text-[#D8FF00] animate-bounce" />
                INTEGRATED INTO SYSTEM!
              </>
            ) : (
              <>
                <ListPlus className="w-4 h-4" />
                ADD TO SYSTEM
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
