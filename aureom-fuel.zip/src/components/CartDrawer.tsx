import React, { useState } from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck, HelpCircle, Ticket, CheckCircle2 } from 'lucide-react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  cart: CartItem[];
  onClose: () => void;
  onUpdateQuantity: (productId: string, qty: number, flavor?: string, size?: string) => void;
  onRemoveItem: (productId: string, flavor?: string, size?: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  cart,
  onClose,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}: CartDrawerProps) {
  const [promoCode, setPromoCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(false);
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'shipping' | 'complete'>('cart');

  // Shipping form fields
  const [fullName, setFullName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [postcode, setPostcode] = useState('');
  const [emailAddress, setEmailAddress] = useState('');

  if (!isOpen) return null;

  const subtotal = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
  const discountMultiplier = discountApplied ? 0.85 : 1.0; // 15% discount
  const finalPrice = parseFloat((subtotal * discountMultiplier).toFixed(2));
  const shippingFee = subtotal > 50 || subtotal === 0 ? 0 : 4.99;
  const totalWithShipping = parseFloat((finalPrice + shippingFee).toFixed(2));

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (promoCode.toUpperCase() === 'RAVE15' || promoCode.toUpperCase() === 'FUTURE') {
      setDiscountApplied(true);
    }
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCheckoutStep('complete');
  };

  const handleResetCheckout = () => {
    onClearCart();
    setCheckoutStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-end select-none">
      {/* Backdrop */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-black/85 backdrop-blur-sm transition-opacity"
      ></div>

      {/* Cart Drawer Panel */}
      <div className="relative w-full max-w-md h-full bg-[#0a0a0a] border-l border-white/5 flex flex-col justify-between z-10 shadow-2xl">
        
        {/* Drawer Header */}
        <div className="bg-[#050505]/95 backdrop-blur-md border-b border-white/5 p-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4 text-[#D8FF00]" />
            <span className="text-xs font-mono font-bold tracking-widest text-white uppercase">AUREOM LABS CART</span>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 border border-white/5 hover:border-[#D8FF00] flex items-center justify-center text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Dynamic Step Panels */}
        <div className="flex-grow overflow-y-auto p-6 space-y-6">

          {/* STEP 1: CART LIST VIEW */}
          {checkoutStep === 'cart' && (
            <>
              {cart.length === 0 ? (
                <div className="h-96 flex flex-col items-center justify-center text-center space-y-4">
                  <div className="w-14 h-14 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-600 border border-zinc-800">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs font-mono font-bold tracking-widest text-zinc-500 uppercase block">SYSTEM STATUS: EMPTY</span>
                    <p className="text-xs text-zinc-400 font-semibold max-w-xs">
                      No active formulations loaded. Visit the product system or the custom lab to mix compounds.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex justify-between items-baseline border-b border-zinc-900 pb-2">
                    <span className="text-[10px] font-mono text-zinc-500 uppercase">Compounds currently loaded</span>
                    <button 
                      onClick={onClearCart}
                      className="text-[9px] font-mono text-red-500 hover:underline uppercase"
                    >
                      Purge Cart
                    </button>
                  </div>

                  {/* Cart Item Row List */}
                  {cart.map((item, i) => (
                    <div 
                      key={`${item.product.id}-${item.selectedFlavor || ''}-${item.selectedSize || ''}`} 
                      className="flex gap-4 p-4 border border-zinc-900 bg-zinc-950/40 relative"
                    >
                      {/* Product display thumbnail */}
                      <div className="w-16 h-16 bg-zinc-900 border border-zinc-900/60 p-1 shrink-0">
                        <img 
                          src={item.product.image} 
                          alt={item.product.name} 
                          className="w-full h-full object-contain"
                          referrerPolicy="no-referrer"
                        />
                      </div>

                      {/* Content block */}
                      <div className="flex-grow space-y-1">
                        <div className="flex justify-between items-start">
                          <h4 className="text-xs font-bold text-white tracking-tight uppercase line-clamp-1">{item.product.name}</h4>
                          <span className="text-xs font-mono font-bold text-[#D8FF00] ml-2 shrink-0">
                            £{(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>

                        {/* Options badge display */}
                        {(item.selectedFlavor || item.selectedSize) && (
                          <div className="flex flex-wrap gap-1.5 pt-0.5">
                            {item.selectedFlavor && (
                              <span className="text-[8px] font-mono tracking-wider bg-zinc-900 border border-zinc-800 text-zinc-400 px-1.5 py-0.5 uppercase">
                                FLV: {item.selectedFlavor}
                              </span>
                            )}
                            {item.selectedSize && (
                              <span className="text-[8px] font-mono tracking-wider bg-zinc-900 border border-zinc-800 text-zinc-400 px-1.5 py-0.5 uppercase">
                                SIZE: {item.selectedSize}
                              </span>
                            )}
                          </div>
                        )}

                        {/* Quantity and Delete control */}
                        <div className="flex items-center justify-between pt-2">
                          <div className="flex items-center gap-1 border border-zinc-900 w-24 bg-black">
                            <button 
                              onClick={() => onUpdateQuantity(item.product.id, Math.max(1, item.quantity - 1), item.selectedFlavor, item.selectedSize)}
                              className="w-6 h-6 flex items-center justify-center text-zinc-500 hover:text-white font-mono text-xs cursor-pointer"
                            >
                              -
                            </button>
                            <span className="flex-grow text-center font-mono text-[10px] text-zinc-300">{item.quantity}</span>
                            <button 
                              onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1, item.selectedFlavor, item.selectedSize)}
                              className="w-6 h-6 flex items-center justify-center text-zinc-500 hover:text-white font-mono text-xs cursor-pointer"
                            >
                              +
                            </button>
                          </div>

                          <button 
                            onClick={() => onRemoveItem(item.product.id, item.selectedFlavor, item.selectedSize)}
                            className="text-zinc-600 hover:text-red-500 transition-colors p-1"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Promo Input Area */}
                  <form onSubmit={handleApplyPromo} className="pt-4 border-t border-zinc-900 flex gap-2">
                    <input 
                      type="text"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                      placeholder="PROMO CODE (E.G. RAVE15)"
                      className="flex-grow bg-zinc-900/60 border border-zinc-900 focus:border-[#D8FF00] focus:outline-none px-3 py-2 font-mono text-xs tracking-widest text-white uppercase rounded-none"
                    />
                    <button 
                      type="submit"
                      className="bg-zinc-900 hover:bg-zinc-800 text-white border border-zinc-800 hover:border-zinc-700 px-4 py-2 font-mono text-[10px] font-bold tracking-widest uppercase cursor-pointer"
                    >
                      APPLY
                    </button>
                  </form>
                  {discountApplied && (
                    <div className="bg-[#D8FF00]/10 border border-[#D8FF00]/20 p-2.5 text-[10px] font-mono text-[#D8FF00] flex justify-between items-center">
                      <span>✓ 15% SYSTEM DISCHARGE APPLIED!</span>
                      <span>CODE: RAVE15</span>
                    </div>
                  )}
                </div>
              )}
            </>
          )}

          {/* STEP 2: SHIPPING DETAILS & BILLING */}
          {checkoutStep === 'shipping' && (
            <form onSubmit={handleCheckoutSubmit} className="space-y-4">
              <div className="border-b border-zinc-900 pb-2">
                <span className="text-[10px] font-mono text-zinc-500 uppercase">British Logistic Destination</span>
              </div>

              <div className="space-y-3">
                <div className="space-y-1">
                  <label className="text-[9px] font-mono text-zinc-400 font-bold uppercase">Consignee Name</label>
                  <input 
                    type="text" 
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="E.G. LIAM GALLAGHER"
                    className="w-full bg-zinc-900/40 text-white font-mono border border-zinc-800 focus:border-[#D8FF00] focus:outline-none p-3 text-xs tracking-wider rounded-none uppercase"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-mono text-zinc-400 font-bold uppercase">System Contact Email</label>
                  <input 
                    type="email" 
                    required
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    placeholder="E.G. LIAM@AUREOM.CO.UK"
                    className="w-full bg-zinc-900/40 text-white font-mono border border-zinc-800 focus:border-[#D8FF00] focus:outline-none p-3 text-xs tracking-wider rounded-none uppercase"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-mono text-zinc-400 font-bold uppercase">Delivery Address</label>
                  <input 
                    type="text" 
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="E.G. 42 WAREHOUSE BLVD"
                    className="w-full bg-zinc-900/40 text-white font-mono border border-zinc-800 focus:border-[#D8FF00] focus:outline-none p-3 text-xs tracking-wider rounded-none uppercase"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono text-zinc-400 font-bold uppercase">City</label>
                    <input 
                      type="text" 
                      required
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      placeholder="LONDON"
                      className="w-full bg-zinc-900/40 text-white font-mono border border-zinc-800 focus:border-[#D8FF00] focus:outline-none p-3 text-xs tracking-wider rounded-none uppercase"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-mono text-zinc-400 font-bold uppercase">Postcode</label>
                    <input 
                      type="text" 
                      required
                      value={postcode}
                      onChange={(e) => setPostcode(e.target.value)}
                      placeholder="E1 6AN"
                      className="w-full bg-zinc-900/40 text-white font-mono border border-zinc-800 focus:border-[#D8FF00] focus:outline-none p-3 text-xs tracking-wider rounded-none uppercase"
                    />
                  </div>
                </div>
              </div>

              {/* Standard Payment Simulated Banner */}
              <div className="bg-zinc-950 border border-zinc-900 p-4 space-y-2">
                <span className="text-[8px] font-mono tracking-widest text-zinc-500 uppercase block">AUTHENTICATING SECURE TRANSFER</span>
                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-zinc-400">CREDIT TERMINAL</span>
                  <span className="text-white font-bold">•••• •••• •••• 2035</span>
                </div>
                <p className="text-[8px] text-zinc-600 font-mono leading-relaxed uppercase">
                  Processed via Aureom Cryptographic Clearance System. Authorized in the United Kingdom.
                </p>
              </div>

              <button 
                type="submit"
                className="w-full bg-[#D8FF00] hover:bg-white text-black font-mono font-black text-xs tracking-[0.2em] py-4 uppercase flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
              >
                DISPATCH SYSTEM LOAD
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* STEP 3: ORDER SUCCESS STATE */}
          {checkoutStep === 'complete' && (
            <div className="h-full flex flex-col items-center justify-center text-center p-4 space-y-6">
              <div className="w-16 h-16 rounded-full bg-[#D8FF00]/10 border border-[#D8FF00]/40 flex items-center justify-center text-[#D8FF00] animate-bounce">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <span className="text-[10px] font-mono tracking-[0.25em] text-[#D8FF00] font-bold uppercase block">DISPATCH CHRONOLOGY SUCCESS</span>
                <h3 className="text-lg font-black tracking-tight text-white uppercase">LOAD CONFIRMED.</h3>
                <p className="text-xs text-zinc-400 font-medium leading-relaxed max-w-xs mx-auto">
                  Your performance compounds have been queued for next-day delivery. <br />
                  Our London warehouse team is mixing and packing your cargo right now.
                </p>
              </div>

              {/* Order specifics */}
              <div className="w-full bg-zinc-900/40 border border-zinc-900 p-4 font-mono text-left text-[10px] text-zinc-500 space-y-1.5">
                <div className="flex justify-between">
                  <span>ORDER IDENTIFIER:</span>
                  <span className="text-white font-bold">#AR-{Math.floor(Math.random() * 90000 + 10000)}</span>
                </div>
                <div className="flex justify-between">
                  <span>ESTIMATED DISPATCH:</span>
                  <span className="text-[#D8FF00] font-bold">TOMORROW (08:00 BST)</span>
                </div>
                <div className="flex justify-between border-t border-zinc-900 pt-1.5 mt-1.5 text-xs">
                  <span>TOTAL CLEARED:</span>
                  <span className="text-white font-bold">£{totalWithShipping.toFixed(2)}</span>
                </div>
              </div>

              <button 
                onClick={handleResetCheckout}
                className="w-full bg-white hover:bg-zinc-200 text-black font-mono font-black text-xs tracking-[0.2em] py-4 uppercase cursor-pointer"
              >
                RETURN TO SYSTEM HOME
              </button>
            </div>
          )}

        </div>

        {/* Drawer Sticky Billing Footer */}
        {cart.length > 0 && checkoutStep === 'cart' && (
          <div className="bg-zinc-950/95 border-t border-zinc-900 p-6 space-y-4">
            <div className="space-y-2 font-mono text-xs text-zinc-400">
              <div className="flex justify-between items-baseline">
                <span>SUBTOTAL</span>
                <span className="text-white font-bold">£{subtotal.toFixed(2)}</span>
              </div>
              {discountApplied && (
                <div className="flex justify-between items-baseline text-[#D8FF00]">
                  <span>DISCOUNT (15%)</span>
                  <span>-£{(subtotal * 0.15).toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between items-baseline">
                <span>BRITISH EXPRESS SHIPPING</span>
                <span className="text-white font-bold">
                  {shippingFee === 0 ? 'FREE' : `£${shippingFee.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between items-baseline border-t border-zinc-900 pt-3 text-sm font-black text-white">
                <span>TOTAL ESTIMATED</span>
                <span className="text-[#D8FF00]">£{totalWithShipping.toFixed(2)}</span>
              </div>
            </div>

            <button 
              onClick={() => setCheckoutStep('shipping')}
              className="w-full group bg-[#D8FF00] hover:bg-white text-black font-mono font-black text-xs tracking-[0.2em] py-4 uppercase flex items-center justify-center gap-3 transition-colors duration-300 cursor-pointer"
            >
              PROCEED TO LOGISTICS
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[9px] font-mono text-zinc-500">
              <ShieldCheck className="w-3.5 h-3.5 text-[#D8FF00]" />
              <span>INFORMED SPORT TESTED PRODUCTS • 100% SECURE CHECKOUT</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
