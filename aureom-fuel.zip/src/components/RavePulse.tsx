import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Disc, Volume2, Sparkles, Sliders, Radio, Music, Eye } from 'lucide-react';

interface Track {
  id: string;
  title: string;
  bpm: number;
  genre: string;
  duration: string;
}

const RAVE_TRACKS: Track[] = [
  { id: '1', title: 'HYDROGEN BRUTALIST // LAB-MIX', bpm: 135, genre: 'Industrial Techno', duration: '5:42' },
  { id: '2', title: 'SUB-BASS ISOLATE // MONO', bpm: 138, genre: 'Warehouse Dubstep', duration: '6:14' },
  { id: '3', title: 'ACID LIME 140BPM // OVERDRIVE', bpm: 140, genre: 'Acid Trance', duration: '4:55' },
  { id: '4', title: 'TECHNO GLUCOSE // SYNTH', bpm: 132, genre: 'Minimal Techno', duration: '5:08' }
];

interface RavePulseProps {
  onAtmosphereChange: (bass: number, lasers: number, haze: number) => void;
}

export default function RavePulse({ onAtmosphereChange }: RavePulseProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTrack, setActiveTrack] = useState<Track>(RAVE_TRACKS[0]);
  const [bass, setBass] = useState(65);
  const [lasers, setLasers] = useState(80);
  const [haze, setHaze] = useState(40);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);

  // Trigger atmosphere changes up to App state
  useEffect(() => {
    onAtmosphereChange(bass, lasers, haze);
  }, [bass, lasers, haze]);

  // Handle visualizer rendering on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      // Clear canvas with subtle transparency for trails
      ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const numBars = 45;
      const barWidth = canvas.width / numBars;
      phase += isPlaying ? (activeTrack.bpm / 240) : 0.01;

      for (let i = 0; i < numBars; i++) {
        // Calculate dynamic height based on sin wave, bass level, and play state
        const ampFactor = isPlaying ? (bass / 100) : 0.15;
        const noise = Math.sin(i * 0.18 + phase) * Math.cos(i * 0.08 - phase * 0.5);
        const randNoise = isPlaying ? Math.random() * 0.35 : 0.05;
        
        const rawHeight = (noise + 1) * 0.5 * (canvas.height * 0.7);
        const barHeight = Math.max(4, rawHeight * ampFactor + (isPlaying ? randNoise * 30 : 0));

        // Color mapping to acid lime (#D8FF00)
        const alpha = isPlaying ? 0.3 + (barHeight / canvas.height) * 0.7 : 0.2;
        ctx.fillStyle = `rgba(216, 255, 0, ${alpha})`;

        // Draw symmetrical audio wave bar
        const x = i * barWidth;
        const y = (canvas.height - barHeight) / 2;
        
        ctx.fillRect(x + 1, y, barWidth - 2, barHeight);

        // Draw tiny neon floating dots for laser atmosphere reflection
        if (isPlaying && Math.random() > 0.94) {
          ctx.fillStyle = 'rgba(216, 255, 0, 0.9)';
          ctx.beginPath();
          ctx.arc(
            x + barWidth / 2, 
            y - Math.random() * 20, 
            Math.random() * 2 + 1, 
            0, 
            Math.PI * 2
          );
          ctx.fill();
        }
      }

      animationRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isPlaying, activeTrack, bass]);

  return (
    <section id="rave-station" className="py-20 bg-[#050505] border-t border-b border-white/5 select-none overflow-hidden relative">
      {/* Background neon lime lines */}
      <div className="absolute top-0 right-1/4 w-[1px] h-full bg-[#D8FF00]/5 pointer-events-none"></div>
      <div className="absolute bottom-0 left-1/4 w-full h-[1px] bg-[#D8FF00]/5 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Module Title */}
        <div className="mb-12 space-y-3">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-[#D8FF00] animate-pulse" />
            <span className="text-[10px] font-mono tracking-[0.2em] text-[#D8FF00] font-bold uppercase">SYSTEM REVERB // DIGITAL ENGINE</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black tracking-tighter text-white">
            ATMOSPHERE ENGINE.
          </h2>
          <p className="max-w-xl text-xs md:text-sm text-zinc-400 font-medium">
            Fine-tune the underground warehouse audio-visual calibration of the Aureom interface. 
            Adjust bass frequencies, active laser refraction, and fog density to sync the system with your rhythm.
          </p>
        </div>

        {/* Studio Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
          
          {/* Track List Selector */}
          <div className="lg:col-span-4 bg-[#0a0a0a] border border-white/5 p-6 flex flex-col justify-between rounded-sm">
            <div className="space-y-4">
              <div className="flex items-center gap-2 border-b border-zinc-900 pb-3">
                <Music className="w-4 h-4 text-zinc-400" />
                <span className="text-xs font-mono font-bold tracking-widest text-white uppercase">SOUND DECK SYSTEM</span>
              </div>

              <div className="space-y-2">
                {RAVE_TRACKS.map((track) => (
                  <button
                    key={track.id}
                    onClick={() => {
                      setActiveTrack(track);
                      setIsPlaying(true);
                    }}
                    className={`w-full text-left p-3 border transition-all flex justify-between items-center group font-mono ${
                      activeTrack.id === track.id
                        ? 'bg-zinc-900/80 border-[#D8FF00] text-white'
                        : 'bg-zinc-950 border-zinc-900 text-zinc-500 hover:text-zinc-300 hover:border-zinc-800'
                    } cursor-pointer`}
                  >
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold tracking-wider flex items-center gap-2">
                        {activeTrack.id === track.id && isPlaying && (
                          <span className="w-1.5 h-1.5 rounded-full bg-[#D8FF00] animate-ping"></span>
                        )}
                        <span>{track.title}</span>
                      </div>
                      <span className="text-[9px] text-zinc-600 block uppercase">{track.genre} // {track.bpm} BPM</span>
                    </div>
                    <span className="text-[10px] text-zinc-600">{track.duration}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Simulated Play deck stats */}
            <div className="mt-8 pt-4 border-t border-zinc-900 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setIsPlaying(!isPlaying)}
                  className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all cursor-pointer ${
                    isPlaying 
                      ? 'bg-[#D8FF00] border-black text-black' 
                      : 'bg-black border-zinc-800 text-white hover:border-[#D8FF00] hover:text-[#D8FF00]'
                  }`}
                >
                  {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
                </button>

                <div>
                  <span className="text-[8px] font-mono text-zinc-600 uppercase block tracking-widest">NOW BROADCASTING</span>
                  <span className="text-xs font-mono font-bold text-white uppercase block tracking-wider line-clamp-1">
                    {activeTrack.title}
                  </span>
                </div>
              </div>

              {/* Rotating abstract disk indicator */}
              <div className="relative">
                <Disc className={`w-10 h-10 text-zinc-800 ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '3s' }} />
                <div className="absolute inset-0 m-auto w-2 h-2 rounded-full bg-[#D8FF00]"></div>
              </div>
            </div>
          </div>

          {/* Core Visualizer Deck */}
          <div className="lg:col-span-8 bg-[#0a0a0a] border border-white/5 p-6 md:p-8 flex flex-col justify-between rounded-sm relative overflow-hidden">
            {/* Corner Bracket decorations */}
            <div className="absolute top-0 right-0 w-3 h-[1px] bg-zinc-800"></div>
            <div className="absolute top-0 right-0 w-[1px] h-3 bg-zinc-800"></div>

            <div className="flex justify-between items-center border-b border-zinc-900 pb-4 mb-6 z-10">
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-[#D8FF00]" />
                <span className="text-xs font-mono font-bold tracking-widest text-white uppercase">FREQUENCY SPECTRUM</span>
              </div>
              <div className="flex items-center gap-1.5 font-mono text-[9px] text-zinc-500">
                <span>STATUS:</span>
                <span className={isPlaying ? 'text-[#D8FF00] font-bold' : 'text-zinc-600'}>
                  {isPlaying ? 'MODULATING LIVE' : 'STATION IDLE'}
                </span>
              </div>
            </div>

            {/* Visualizer Canvas area */}
            <div className="bg-[#050505]/60 border border-white/5 rounded-sm flex items-center justify-center relative p-2 h-44 mb-6">
              <canvas 
                ref={canvasRef} 
                width={500} 
                height={160} 
                className="w-full h-full block"
              />
              <div className="absolute top-3 left-3 bg-black/60 border border-zinc-900 px-2 py-1 flex items-center gap-1.5">
                <span className="w-1 h-1 rounded-full bg-[#D8FF00] animate-ping"></span>
                <span className="text-[8px] font-mono text-zinc-400 uppercase tracking-widest">FEED RECONSTRUCTION</span>
              </div>
            </div>

            {/* Atmosphere Sliders */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-zinc-900 z-10">
              {/* Slider 1: Bass decibels */}
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-mono font-bold uppercase">
                  <span className="text-zinc-400">BASS ISOLATE</span>
                  <span className="text-[#D8FF00]">{bass}dB</span>
                </div>
                <input 
                  type="range"
                  min="20"
                  max="100"
                  value={bass}
                  onChange={(e) => setBass(parseInt(e.target.value))}
                  className="w-full h-1 bg-zinc-900 appearance-none cursor-pointer accent-[#D8FF00]"
                />
                <span className="block text-[8px] text-zinc-600 font-mono uppercase">Sync page pulse rate</span>
              </div>

              {/* Slider 2: Laser frequency */}
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-mono font-bold uppercase">
                  <span className="text-zinc-400">LASER REFRAC</span>
                  <span className="text-[#D8FF00]">{lasers}Hz</span>
                </div>
                <input 
                  type="range"
                  min="10"
                  max="150"
                  value={lasers}
                  onChange={(e) => setLasers(parseInt(e.target.value))}
                  className="w-full h-1 bg-zinc-900 appearance-none cursor-pointer accent-[#D8FF00]"
                />
                <span className="block text-[8px] text-zinc-600 font-mono uppercase">Vibe opacity multipliers</span>
              </div>

              {/* Slider 3: Atmospheric haze */}
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] font-mono font-bold uppercase">
                  <span className="text-zinc-400">AMB. HAZE DENS</span>
                  <span className="text-[#D8FF00]">{haze}%</span>
                </div>
                <input 
                  type="range"
                  min="0"
                  max="100"
                  value={haze}
                  onChange={(e) => setHaze(parseInt(e.target.value))}
                  className="w-full h-1 bg-zinc-900 appearance-none cursor-pointer accent-[#D8FF00]"
                />
                <span className="block text-[8px] text-zinc-600 font-mono uppercase">Backdrop fog filters</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
