import React from 'react';
import { ArrowRight, Flame, ShieldAlert, Award, Compass } from 'lucide-react';

interface HeroProps {
  onShopProtein: () => void;
  onShopAll: () => void;
  onOpenDetails: (productId: string) => void;
}

export default function Hero({ onShopProtein, onShopAll, onOpenDetails }: HeroProps) {
  return (
    <section className="relative w-full min-h-screen pt-28 md:pt-36 pb-12 flex items-center justify-center overflow-hidden bg-[#050505] select-none">
      {/* Background Graphic with Laser beams overlay and polished concrete texture */}
      <div className="absolute inset-0 z-0">
        {/* Generated premium industrial gym background */}
        <img 
          src="/src/assets/images/gym_hero_bg_1784888191991.jpg" 
          alt="Brutalist Warehouse Gym Background" 
          className="w-full h-full object-cover opacity-30 filter brightness-90 grayscale-[25%]"
          referrerPolicy="no-referrer"
        />
        {/* Smoked Glass, Laser Line Gradients */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-[#050505]/90 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/45 to-[#050505]/85"></div>

        {/* Dynamic neon line laser beams simulation (absolute overlays) */}
        <div className="absolute top-1/4 left-0 w-full h-[1px] bg-[#D8FF00]/15 blur-[1px] transform -rotate-12"></div>
        <div className="absolute top-2/3 left-0 w-full h-[1.5px] bg-[#D8FF00]/30 blur-[2px] transform rotate-6"></div>
        <div className="absolute bottom-1/3 left-0 w-full h-[1px] bg-[#D8FF00]/15 blur-[0.5px] transform -rotate-12"></div>
        
        {/* Grid lines layout to emphasize "architectural engineering" */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.015)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.015)_1px,transparent_1px)] bg-[size:4rem_4rem]"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 w-full h-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        {/* Left Side Content */}
        <div className="lg:col-span-7 flex flex-col items-start justify-center space-y-6 md:space-y-8">
          {/* Hypermodern Badge */}
          <div className="px-3.5 py-1 border border-[#D8FF00]/40 inline-flex w-fit rounded-full bg-[#D8FF00]/5">
            <span className="text-[#D8FF00] text-[10px] font-mono font-bold tracking-widest uppercase">Hypermodern Performance</span>
          </div>

          {/* Headline Container */}
          <div className="space-y-2">
            <h1 className="text-5xl sm:text-7xl md:text-8xl lg:text-[100px] font-black tracking-tighter leading-[0.85] text-white">
              BUILT<br />DIFFERENT.<br /><span className="text-stroke-white text-transparent">FUELLED</span><br />FUTURE.
            </h1>
          </div>

          {/* Tagline / Brand Statement */}
          <div className="max-w-md border-l-2 border-[#D8FF00] pl-4 md:pl-6">
            <p className="text-sm md:text-base text-zinc-300 font-medium leading-relaxed">
              Premium performance nutrition. <br />
              <span className="text-white font-semibold">Engineered for strength. Designed for the future.</span>
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
            <button 
              onClick={onShopProtein}
              className="group relative bg-[#D8FF00] hover:bg-white text-black font-mono font-black text-xs md:text-sm tracking-[0.15em] py-4 px-8 uppercase flex items-center justify-center gap-3 transition-colors duration-300 rounded-none cursor-pointer"
            >
              SHOP PROTEIN
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
            <button 
              onClick={onShopAll}
              className="group relative bg-black hover:bg-zinc-950 text-white hover:text-[#D8FF00] font-mono font-bold text-xs md:text-sm tracking-[0.15em] py-4 px-8 uppercase border border-zinc-800 hover:border-[#D8FF00] flex items-center justify-center gap-3 transition-all duration-300 rounded-none cursor-pointer"
            >
              SHOP ALL
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          {/* British Engineering Badge */}
          <div className="flex items-center gap-3 bg-zinc-950/80 border border-zinc-900 px-4 py-3 select-none">
            {/* Custom stylized futuristic union jack badge matching mockup */}
            <div className="w-8 h-5 relative overflow-hidden bg-zinc-900 border border-zinc-800">
              <svg viewBox="0 0 100 60" className="w-full h-full opacity-80">
                {/* Custom yellow/lime styled Union Jack lines */}
                <path d="M0 0 L100 60 M100 0 L0 60" stroke="#D8FF00" strokeWidth="6" />
                <path d="M50 0 L50 60 M0 30 L100 30" stroke="#D8FF00" strokeWidth="12" />
                <path d="M50 0 L50 60 M0 30 L100 30" stroke="#000" strokeWidth="4" />
              </svg>
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-mono font-bold tracking-[0.15em] text-[#D8FF00]">ENGINEERED</span>
              <span className="text-[9px] font-mono text-zinc-400 tracking-[0.1em]">IN GREAT BRITAIN</span>
            </div>
          </div>
        </div>

        {/* Right Side Content - Massive Protein Tub & Stats Column */}
        <div className="lg:col-span-5 relative flex items-center justify-center lg:justify-end pt-8 lg:pt-0">
          
          {/* Background Glow behind product */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 bg-[#D8FF00]/10 rounded-full blur-[80px] z-0 pointer-events-none"></div>

          <div className="relative z-10 flex items-center gap-6 md:gap-8 max-w-md lg:max-w-none">
            
            {/* The Huge Matte Black Protein Tub */}
            <div 
              onClick={() => onOpenDetails('whey-protein')}
              className="relative cursor-pointer group flex flex-col items-center select-none"
              id="hero-product-tub"
            >
              {/* Image Frame with brutalist border decoration */}
              <div className="absolute -top-3 -left-3 w-6 h-6 border-t-2 border-l-2 border-zinc-800 group-hover:border-[#D8FF00] transition-colors"></div>
              <div className="absolute -bottom-3 -right-3 w-6 h-6 border-b-2 border-r-2 border-zinc-800 group-hover:border-[#D8FF00] transition-colors"></div>

              {/* Glowing Rim effect */}
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-[#D8FF00]/5 to-transparent rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

              {/* The high quality product image generated */}
              <img 
                src="/src/assets/images/whey_protein_tub_1784888203566.jpg" 
                alt="AUREOM WHEY PROTEIN" 
                className="w-64 sm:w-80 lg:w-[350px] h-auto object-contain drop-shadow-[0_25px_40px_rgba(0,0,0,0.9)] transition-transform duration-500 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />

              {/* Interactive Hover Tag */}
              <div className="absolute bottom-4 bg-black/80 backdrop-blur-md border border-zinc-800 px-4 py-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2">
                <span className="text-[10px] font-mono text-white tracking-[0.1em]">VEW COMPOSITION</span>
                <span className="text-[#D8FF00] text-xs">→</span>
              </div>
            </div>

            {/* Vertical Stack of Line Icons on the right of the tub */}
            <div className="flex flex-col space-y-6 md:space-y-8 border-l border-zinc-900/60 pl-4 md:pl-6 select-none shrink-0">
              
              <div className="flex flex-col items-center text-center group">
                <div className="w-10 h-10 rounded-sm bg-zinc-950/90 border border-zinc-900 flex items-center justify-center text-[#D8FF00] mb-2 group-hover:border-[#D8FF00] transition-colors">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
                    <path d="M4.5 3h15M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3M9 11h6M9 15h6" />
                  </svg>
                </div>
                <span className="text-[9px] font-mono text-zinc-500 tracking-[0.15em] uppercase">LAB</span>
                <span className="text-[10px] font-mono text-[#D8FF00] tracking-[0.1em] font-bold">TESTED</span>
              </div>

              <div className="flex flex-col items-center text-center group">
                <div className="w-10 h-10 rounded-sm bg-zinc-950/90 border border-zinc-900 flex items-center justify-center text-[#D8FF00] mb-2 group-hover:border-[#D8FF00] transition-colors">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
                    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
                  </svg>
                </div>
                <span className="text-[9px] font-mono text-zinc-500 tracking-[0.15em] uppercase">PERFORMANCE</span>
                <span className="text-[10px] font-mono text-white tracking-[0.1em] font-bold">DRIVEN</span>
              </div>

              <div className="flex flex-col items-center text-center group">
                <div className="w-10 h-10 rounded-sm bg-zinc-950/90 border border-zinc-900 flex items-center justify-center text-[#D8FF00] mb-2 group-hover:border-[#D8FF00] transition-colors">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-5 h-5">
                    <polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5" />
                    <circle cx="12" cy="12" r="3" />
                  </svg>
                </div>
                <span className="text-[9px] font-mono text-zinc-500 tracking-[0.15em] uppercase">PREMIUM</span>
                <span className="text-[10px] font-mono text-[#D8FF00] tracking-[0.1em] font-bold">QUALITY</span>
              </div>

              <div className="flex flex-col items-center text-center group">
                <div className="w-10 h-10 rounded-sm bg-zinc-950/90 border border-zinc-900 flex items-center justify-center text-[#D8FF00] mb-2 group-hover:border-[#D8FF00] transition-colors">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-5 h-5 opacity-90">
                    <path d="M12 2v20M2 12h20M2 2l20 20M22 2L2 20" />
                  </svg>
                </div>
                <span className="text-[9px] font-mono text-zinc-500 tracking-[0.15em] uppercase">BRITISH</span>
                <span className="text-[10px] font-mono text-white tracking-[0.1em] font-bold">ENGINEERED</span>
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  );
}
