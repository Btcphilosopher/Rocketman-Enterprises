import React from 'react';
import { Star, Shield, ArrowUpRight } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOpenDetails: (productId: string) => void;
  key?: string;
}

export default function ProductCard({ product, onOpenDetails }: ProductCardProps) {
  // Map category to formatted names
  const categoryLabels: Record<string, string> = {
    protein: 'PROTEIN',
    'pre-workout': 'PRE-WORKOUT',
    vitamins: 'VITAMINS',
    apparel: 'APPAREL',
    stacks: 'STACKS'
  };

  return (
    <div 
      id={`category-${product.id}`}
      onClick={() => onOpenDetails(product.id)}
      className="group relative bg-[#0a0a0a] border border-white/5 overflow-hidden cursor-pointer select-none flex flex-col justify-between h-full hover:border-[#D8FF00]/40 transition-all duration-500"
    >
      {/* Decorative corners to match brutalist / architectural theme */}
      <div className="absolute top-0 left-0 w-3 h-[1px] bg-zinc-800 group-hover:bg-[#D8FF00] transition-colors"></div>
      <div className="absolute top-0 left-0 w-[1px] h-3 bg-zinc-800 group-hover:bg-[#D8FF00] transition-colors"></div>
      <div className="absolute bottom-0 right-0 w-3 h-[1px] bg-zinc-800 group-hover:bg-[#D8FF00] transition-colors"></div>
      <div className="absolute bottom-0 right-0 w-[1px] h-3 bg-zinc-800 group-hover:bg-[#D8FF00] transition-colors"></div>

      {/* Subtle top lime light bar */}
      <div className="absolute top-0 inset-x-0 h-[2px] bg-[#D8FF00]/0 group-hover:bg-[#D8FF00] transition-all duration-500 z-10"></div>

      {/* Product Image Stage */}
      <div className="relative w-full aspect-[4/5] bg-gradient-to-b from-zinc-950/80 to-zinc-900/40 overflow-hidden flex items-center justify-center p-4">
        {/* Abstract Laser overlay behind product */}
        <div className="absolute inset-0 z-0 bg-radial-[circle_at_center,rgba(216,255,0,0.03)_0%,transparent_70%]"></div>
        <div className="absolute top-1/2 left-0 w-full h-[1px] bg-[#D8FF00]/5 group-hover:bg-[#D8FF00]/15 blur-[0.5px] transform rotate-12 transition-all duration-500"></div>

        {/* Product image with sleek scaling effect */}
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-contain relative z-10 drop-shadow-[0_16px_32px_rgba(0,0,0,0.85)] group-hover:drop-shadow-[0_20px_40px_rgba(216,255,0,0.15)] transition-transform duration-700 ease-out group-hover:scale-[1.04]"
          referrerPolicy="no-referrer"
        />

        {/* Premium Tagline Overlay */}
        <div className="absolute top-3 left-3 z-20 bg-zinc-950/90 border border-zinc-900 px-2.5 py-1 flex items-center gap-1.5 rounded-sm">
          <span className="w-1.5 h-1.5 rounded-full bg-[#D8FF00] animate-pulse"></span>
          <span className="text-[8px] font-mono tracking-widest text-zinc-400 font-bold uppercase">{product.tagline}</span>
        </div>

        {/* Price Tag Overlay */}
        <div className="absolute bottom-3 right-3 z-20 bg-black/90 border border-zinc-800 group-hover:border-[#D8FF00] px-3 py-1 font-mono transition-colors">
          <span className="text-white font-black text-xs md:text-sm">£{product.price.toFixed(2)}</span>
          {product.originalPrice && (
            <span className="text-zinc-600 text-[10px] line-through ml-1.5">£{product.originalPrice.toFixed(2)}</span>
          )}
        </div>
      </div>

      {/* Product Information */}
      <div className="p-4 md:p-6 bg-zinc-950/40 border-t border-zinc-900/60 flex-grow flex flex-col justify-between">
        <div className="space-y-1.5">
          {/* Category Eyebrow */}
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-mono font-bold tracking-[0.2em] text-[#D8FF00]">
              {categoryLabels[product.category]}
            </span>
            {/* Informational rating */}
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 fill-[#D8FF00] stroke-none" />
              <span className="text-[10px] font-mono font-bold text-white">{product.rating}</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 className="text-base md:text-lg font-black tracking-tight text-white group-hover:text-[#D8FF00] transition-colors leading-snug">
            {product.name}
          </h3>

          {/* Short dynamic descriptions */}
          <p className="text-xs text-zinc-400 font-medium line-clamp-2 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Interactive action footer */}
        <div className="mt-5 pt-3 border-t border-zinc-900/60 flex items-center justify-between">
          <span className="text-[9px] font-mono text-zinc-500 group-hover:text-zinc-300 transition-colors uppercase tracking-[0.15em] font-bold">
            EXPLORE COMPOSITION
          </span>
          <div className="w-6 h-6 rounded-sm bg-zinc-900 group-hover:bg-[#D8FF00] group-hover:text-black text-zinc-500 flex items-center justify-center transition-colors">
            <ArrowUpRight className="w-4 h-4" />
          </div>
        </div>
      </div>
    </div>
  );
}
