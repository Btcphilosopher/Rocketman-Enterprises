import React, { useState } from 'react';
import { CUSTOM_INGREDIENTS } from '../data';
import { CustomIngredient, Product } from '../types';
import { FlaskConical, Sliders, Play, Plus, Zap, HeartPulse, Sparkles, Check } from 'lucide-react';

interface StackBuilderProps {
  onAddCustomStackToCart: (customProduct: Product) => void;
}

export default function StackBuilder({ onAddCustomStackToCart }: StackBuilderProps) {
  const [ingredients, setIngredients] = useState<CustomIngredient[]>(CUSTOM_INGREDIENTS);
  const [formulaName, setFormulaName] = useState('AUREOM APEX-1');
  const [isFormulating, setIsFormulating] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSliderChange = (id: string, value: number) => {
    setIngredients(prev => prev.map(ing => {
      if (ing.id === id) {
        return { ...ing, amount: value };
      }
      return ing;
    }));
  };

  // Calculations
  const totalWeightMg = ingredients.reduce((sum, ing) => sum + ing.amount, 0);
  const totalWeightG = parseFloat((totalWeightMg / 1000).toFixed(2));
  
  // Calculate price based on raw ingredients and a premium container packaging fee
  const packagingFee = 8.50;
  const ingredientsPrice = ingredients.reduce((sum, ing) => sum + (ing.amount * ing.pricePerUnit), 0);
  const totalPrice = parseFloat((packagingFee + ingredientsPrice).toFixed(2));

  // Handle formulating and adding to cart
  const handleFormulate = () => {
    setIsFormulating(true);
    setTimeout(() => {
      // Build a unique Custom Product representation
      const customProduct: Product = {
        id: `custom-stack-${Date.now()}`,
        name: `CUSTOM FORMULA: ${formulaName.toUpperCase()}`,
        category: 'stacks',
        tagline: 'SCIENTIFIC DESIGN',
        price: totalPrice,
        rating: 5.0,
        reviewsCount: 1,
        image: '/src/assets/images/cat_stacks_1784888252887.jpg', // uses stack render
        description: `Individually formulated lab stack engineered for high athletic thresholds. Features ${ingredients.map(ing => `${ing.amount}${ing.unit} ${ing.name}`).join(', ')}.`,
        benefits: [
          `Custom weight profile: ${totalWeightG}g Active dosage`,
          'Zero redundant fillers or chemical binders',
          'Triple certified clinical ingredients',
          'Sourced and mixed directly in the UK'
        ],
        specs: [
          { label: 'Formulation ID', value: `LAB-${Math.floor(Math.random() * 900000 + 100000)}` },
          { label: 'Servings', value: '30 Single Doses' },
          { label: 'Weight / Tub', value: `${(totalWeightG * 30).toFixed(0)}g` },
          { label: 'Mixer Location', value: 'Aureom Lab London' }
        ],
        nutritionFacts: {
          servingSize: `1 Custom Scoop (${totalWeightG}g)`,
          servingsPerContainer: 30,
          calories: Math.round(totalWeightG * 1.5),
          activeIngredients: ingredients.map(ing => ({
            name: ing.name,
            amount: `${ing.amount}${ing.unit}`
          }))
        }
      };

      onAddCustomStackToCart(customProduct);
      setIsFormulating(false);
      setSuccess(true);
      setTimeout(() => setSuccess(false), 2000);
    }, 1500);
  };

  return (
    <section id="builder" className="py-20 md:py-28 bg-[#050505] relative select-none border-t border-white/5">
      {/* Decorative Grid and Ambient Lights */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,rgba(216,255,0,0.02)_0%,transparent_50%)] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-4 md:px-8 relative z-10">
        
        {/* Section Heading */}
        <div className="mb-12 md:mb-16 space-y-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#D8FF00] animate-ping"></span>
            <span className="text-[10px] font-mono tracking-[0.2em] text-[#D8FF00] font-bold uppercase">AUREOM COGNITIVE LABS</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-black tracking-tighter text-white">
            SCIENTIFIC STACK BUILDER.
          </h2>
          <p className="max-w-xl text-xs md:text-sm text-zinc-400 font-medium leading-relaxed">
            Architect your own high-performance pre-workout or recovery formulation. 
            Calibrate precise dosages of active raw compounds to match your physiological thresholds.
          </p>
        </div>

        {/* Content Panel Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          
          {/* Left Column: DOSAGE CALIBRATORS */}
          <div className="lg:col-span-7 space-y-6 md:space-y-8 bg-[#0a0a0a] border border-white/5 p-6 md:p-8 rounded-sm">
            <div className="flex items-center justify-between border-b border-white/5">
              <div className="flex items-center gap-2.5">
                <Sliders className="w-5 h-5 text-[#D8FF00]" />
                <span className="text-xs font-mono font-bold tracking-widest text-white uppercase">ACTIVE AGENT DOSAGES</span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500">CALIBRATION UNIT: MILLIGRAMS (mg)</span>
            </div>

            {/* Form Name Input */}
            <div className="space-y-2">
              <label className="text-[10px] font-mono tracking-widest text-zinc-400 font-bold uppercase block">
                FORMULA NOMENCLATURE / NAME
              </label>
              <input 
                type="text" 
                value={formulaName}
                onChange={(e) => setFormulaName(e.target.value.slice(0, 24))}
                placeholder="E.g. COGNITIVE CHARGE"
                className="w-full bg-zinc-900/40 text-white font-mono font-bold border border-zinc-800 focus:border-[#D8FF00] focus:outline-none px-4 py-3 rounded-none text-sm tracking-widest uppercase transition-colors"
              />
            </div>

            {/* Sliders Container */}
            <div className="space-y-6 md:space-y-8">
              {ingredients.map((ing) => {
                const percentage = Math.round((ing.amount / ing.maxAmount) * 100);
                return (
                  <div key={ing.id} className="space-y-2.5">
                    <div className="flex justify-between items-baseline">
                      <div className="space-y-0.5">
                        <span className="text-xs font-mono font-bold text-white flex items-center gap-2">
                          <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: ing.color }}></span>
                          {ing.name}
                        </span>
                        <span className="block text-[10px] text-zinc-500 max-w-sm font-medium leading-tight">
                          {ing.description}
                        </span>
                      </div>
                      <div className="text-right font-mono">
                        <span className="text-xs font-bold text-[#D8FF00]">{ing.amount}{ing.unit}</span>
                        <span className="text-[10px] text-zinc-600 block">MAX: {ing.maxAmount}{ing.unit}</span>
                      </div>
                    </div>

                    {/* Styled Range Slider */}
                    <div className="relative flex items-center">
                      <input 
                        type="range"
                        min="0"
                        max={ing.maxAmount}
                        step={ing.id === 'organic_caffeine' ? '10' : '100'}
                        value={ing.amount}
                        onChange={(e) => handleSliderChange(ing.id, parseInt(e.target.value))}
                        className="w-full h-1 bg-zinc-900 rounded-none appearance-none cursor-pointer accent-[#D8FF00] focus:outline-none"
                        style={{
                          background: `linear-gradient(to right, ${ing.color} 0%, ${ing.color} ${percentage}%, #18181b ${percentage}%, #18181b 100%)`
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: CUSTOM PACKAGING LABEL DISPLAY */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            
            {/* Matte Black Tub Visualization with dynamic details overlay */}
            <div className="relative bg-[#0a0a0a] border border-white/5 p-6 md:p-8 rounded-none overflow-hidden flex flex-col justify-between aspect-[3/4] shadow-2xl">
              {/* Corner brackets */}
              <div className="absolute top-0 left-0 w-4 h-[1px] bg-[#D8FF00]"></div>
              <div className="absolute top-0 left-0 w-[1px] h-4 bg-[#D8FF00]"></div>
              <div className="absolute bottom-0 right-0 w-4 h-[1px] bg-[#D8FF00]"></div>
              <div className="absolute bottom-0 right-0 w-[1px] h-4 bg-[#D8FF00]"></div>

              {/* Cybernetic Grid behind */}
              <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:1.5rem_1.5rem] opacity-30 pointer-events-none"></div>

              {/* Header Label */}
              <div className="flex justify-between items-start border-b border-zinc-900 pb-4 relative z-10">
                <div className="space-y-0.5">
                  <span className="text-[9px] font-mono tracking-[0.25em] text-[#D8FF00] font-bold block">SPEC SHEET SYSTEM</span>
                  <span className="text-xs font-mono font-black text-white tracking-widest uppercase">{formulaName || 'AUREOM SPEC-X'}</span>
                </div>
                <div className="text-right">
                  <span className="text-[8px] font-mono text-zinc-500 block">CONTAINER VOLUME</span>
                  <span className="text-xs font-mono font-bold text-white">450 GRAMS</span>
                </div>
              </div>

              {/* Graph Visualizer of formulation concentrations */}
              <div className="space-y-3 py-6 relative z-10 flex-grow flex flex-col justify-center">
                <span className="text-[8px] font-mono tracking-widest text-zinc-600 block uppercase font-bold">Active concentration graph</span>
                <div className="space-y-2.5">
                  {ingredients.map((ing) => {
                    const ratio = ing.amount / ing.maxAmount;
                    const widthPct = Math.max(4, ratio * 100);
                    return (
                      <div key={ing.id} className="space-y-1">
                        <div className="flex justify-between text-[9px] font-mono font-semibold text-zinc-400">
                          <span>{ing.name.split(' ')[0]}</span>
                          <span>{ing.amount}{ing.unit}</span>
                        </div>
                        <div className="w-full h-2 bg-zinc-900 rounded-none overflow-hidden border border-zinc-900">
                          <div 
                            className="h-full transition-all duration-300"
                            style={{ 
                              width: `${widthPct}%`,
                              backgroundColor: ing.color
                            }}
                          ></div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Totals & Dynamic Price Section */}
              <div className="border-t border-zinc-900 pt-5 space-y-4 relative z-10">
                <div className="grid grid-cols-2 gap-4 font-mono text-xs">
                  <div>
                    <span className="text-[9px] text-zinc-600 uppercase tracking-wider block">ACTIVE SERVING DOSAGE</span>
                    <span className="text-sm font-bold text-white">{totalWeightG}g</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-zinc-600 uppercase tracking-wider block">SERVINGS / UNIT</span>
                    <span className="text-sm font-bold text-white">30 SERVINGS</span>
                  </div>
                </div>

                <div className="flex justify-between items-center bg-black/40 border border-white/5 p-3">
                  <div className="flex items-center gap-1.5">
                    <FlaskConical className="w-4 h-4 text-[#D8FF00]" />
                    <span className="text-[10px] font-mono text-zinc-400 tracking-wider">UNIT FORMULATION PRICE</span>
                  </div>
                  <span className="text-lg font-mono font-black text-[#D8FF00]">£{totalPrice.toFixed(2)}</span>
                </div>

                {/* Submit button */}
                <button
                  disabled={totalWeightMg === 0 || isFormulating || success}
                  onClick={handleFormulate}
                  className={`w-full group font-mono font-black text-xs tracking-[0.2em] py-4 uppercase flex items-center justify-center gap-2.5 transition-colors cursor-pointer ${
                    success
                      ? 'bg-zinc-900 text-[#D8FF00]'
                      : totalWeightMg === 0
                        ? 'bg-zinc-900/40 border border-zinc-900 text-zinc-600 cursor-not-allowed'
                        : 'bg-[#D8FF00] hover:bg-white text-black'
                  }`}
                >
                  {isFormulating ? (
                    <>
                      <span className="w-2 h-2 rounded-full bg-black animate-ping"></span>
                      INTEGRATING COMPOUNDS...
                    </>
                  ) : success ? (
                    <>
                      <Check className="w-4 h-4 text-[#D8FF00]" />
                      FORMULATED & PACKAGED!
                    </>
                  ) : (
                    <>
                      <Plus className="w-4 h-4" />
                      COMPOSE & ADD TO CART
                    </>
                  )}
                </button>
              </div>

            </div>
          </div>

        </div>

      </div>
    </section>
  );
}
