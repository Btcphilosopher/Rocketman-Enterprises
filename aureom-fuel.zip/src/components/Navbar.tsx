import React, { useState } from 'react';
import { Search, User, ShoppingBag, Menu, X, ArrowRight } from 'lucide-react';
import { CartItem } from '../types';

interface NavbarProps {
  cart: CartItem[];
  onOpenCart: () => void;
  onNavigateToSection: (section: string) => void;
}

export default function Navbar({ cart, onOpenCart, onNavigateToSection }: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="w-full z-50 fixed top-0 left-0 bg-[#050505]/40 backdrop-blur-md border-b border-white/5 select-none">
      {/* Thin Neon Announcement Bar */}
      <div className="w-full bg-[#D8FF00] text-black py-1.5 px-4 text-[10px] md:text-xs font-mono font-bold tracking-[0.15em] overflow-hidden whitespace-nowrap border-b border-white/10">
        <div className="flex justify-between items-center max-w-7xl mx-auto">
          <div className="animate-pulse flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-red-600 inline-block animate-ping"></span>
            <span>NEXT DAY DELIVERY AVAILABLE IN UK</span>
          </div>
          <div className="hidden md:flex gap-8 items-center">
            <span>•  ENGINEERED IN BRITAIN  •</span>
            <span>FUEL THE FUTURE</span>
          </div>
          <div className="text-[10px] hover:underline cursor-pointer flex items-center gap-1">
            <span>ENGLAND / GBP (£)</span>
            <span className="text-[8px]">▼</span>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 md:h-20 flex items-center justify-between">
        {/* Brand Logo */}
        <div 
          onClick={() => onNavigateToSection('hero')} 
          className="flex items-center gap-2.5 cursor-pointer group"
          id="nav-logo"
        >
          {/* Futuristic geometric logo representing AUREOM (triangle styled A) */}
          <div className="relative w-8 h-8 md:w-10 md:h-10 flex items-center justify-center bg-black border border-zinc-800 rounded-sm overflow-hidden group-hover:border-[#D8FF00] transition-colors">
            <div className="absolute inset-0 bg-gradient-to-tr from-zinc-950 via-zinc-900 to-black"></div>
            {/* Triangular design mimicking the image logo */}
            <svg viewBox="0 0 100 100" className="w-6 h-6 md:w-8 md:h-8 fill-[#D8FF00] relative z-10 transition-transform group-hover:scale-110 duration-300">
              <path d="M50 15 L85 85 L65 85 L50 45 L35 85 L15 85 Z M50 35 L40 68 L60 68 Z" />
            </svg>
            <div className="absolute inset-x-0 bottom-0 h-[2px] bg-[#D8FF00] opacity-0 group-hover:opacity-100 transition-opacity"></div>
          </div>
          <div className="flex flex-col">
            <span className="text-white font-mono font-extrabold tracking-[0.2em] text-sm md:text-lg leading-none">AUREOM</span>
            <span className="text-[8px] md:text-[9px] text-zinc-500 font-bold tracking-[0.45em] leading-none mt-0.5 group-hover:text-[#D8FF00] transition-colors">FUEL</span>
          </div>
        </div>

        {/* Desktop Links */}
        <nav className="hidden lg:flex items-center gap-6 xl:gap-8">
          <button 
            onClick={() => onNavigateToSection('shop')} 
            className="text-xs font-mono font-bold tracking-widest text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            SHOP
          </button>
          <button 
            onClick={() => { onNavigateToSection('shop'); setTimeout(() => document.getElementById('category-protein')?.scrollIntoView({ behavior: 'smooth' }), 100); }} 
            className="text-xs font-mono font-bold tracking-widest text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            PROTEIN
          </button>
          <button 
            onClick={() => { onNavigateToSection('shop'); setTimeout(() => document.getElementById('category-pre-workout')?.scrollIntoView({ behavior: 'smooth' }), 100); }} 
            className="text-xs font-mono font-bold tracking-widest text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            PRE-WORKOUT
          </button>
          <button 
            onClick={() => { onNavigateToSection('shop'); setTimeout(() => document.getElementById('category-vitamins')?.scrollIntoView({ behavior: 'smooth' }), 100); }} 
            className="text-xs font-mono font-bold tracking-widest text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            VITAMINS
          </button>
          <button 
            onClick={() => { onNavigateToSection('shop'); setTimeout(() => document.getElementById('category-apparel')?.scrollIntoView({ behavior: 'smooth' }), 100); }} 
            className="text-xs font-mono font-bold tracking-widest text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            APPAREL
          </button>
          <button 
            onClick={() => onNavigateToSection('builder')} 
            className="text-xs font-mono font-bold tracking-widest text-[#D8FF00] hover:brightness-125 transition-all flex items-center gap-1 cursor-pointer bg-zinc-950/80 px-2.5 py-1 border border-zinc-900 rounded-sm hover:border-[#D8FF00]/40"
          >
            CUSTOM LAB
          </button>
          <button 
            onClick={() => onNavigateToSection('rave-station')} 
            className="text-xs font-mono font-bold tracking-widest text-zinc-400 hover:text-white transition-colors cursor-pointer"
          >
            RAVE STATION
          </button>
        </nav>

        {/* Right Side Utility Controls */}
        <div className="flex items-center gap-4 md:gap-6">
          <button className="text-zinc-400 hover:text-white transition-colors p-1 cursor-pointer relative group">
            <Search className="w-5 h-5" />
            <span className="absolute bottom-[-24px] right-0 bg-zinc-950 border border-zinc-800 text-[8px] font-mono text-zinc-400 px-1.5 py-0.5 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none uppercase tracking-wider">Search</span>
          </button>
          
          <button className="text-zinc-400 hover:text-white transition-colors p-1 cursor-pointer relative group">
            <User className="w-5 h-5" />
            <span className="absolute bottom-[-24px] right-0 bg-zinc-950 border border-zinc-800 text-[8px] font-mono text-zinc-400 px-1.5 py-0.5 rounded-sm opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none uppercase tracking-wider">Account</span>
          </button>

          {/* Cart Trigger Button */}
          <button 
            onClick={onOpenCart} 
            className="relative text-zinc-400 hover:text-white transition-colors p-1.5 border border-zinc-900 bg-zinc-950/40 hover:border-zinc-800 rounded-sm flex items-center gap-1.5 cursor-pointer"
            id="cart-trigger"
          >
            <ShoppingBag className="w-5 h-5 text-white" />
            <span className="hidden md:inline font-mono text-xs text-zinc-500 font-bold">CART</span>
            <div className="flex items-center justify-center bg-[#D8FF00] text-black w-5 h-5 rounded-full text-[10px] font-mono font-bold leading-none ml-0.5">
              {totalItems}
            </div>
          </button>

          {/* Mobile Menu Trigger */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="lg:hidden text-white hover:text-[#D8FF00] transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-[88px] bg-black/95 backdrop-blur-xl z-40 border-t border-zinc-900 flex flex-col p-6 space-y-6">
          <div className="flex flex-col space-y-4 font-mono">
            <button 
              onClick={() => { setMobileMenuOpen(false); onNavigateToSection('shop'); }} 
              className="text-left text-lg font-bold tracking-widest text-white border-b border-zinc-900 pb-2"
            >
              SHOP PRODUCTS
            </button>
            <button 
              onClick={() => { setMobileMenuOpen(false); onNavigateToSection('builder'); }} 
              className="text-left text-lg font-bold tracking-widest text-[#D8FF00] border-b border-zinc-900 pb-2 flex justify-between items-center"
            >
              <span>LAB: STACK BUILDER</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button 
              onClick={() => { setMobileMenuOpen(false); onNavigateToSection('rave-station'); }} 
              className="text-left text-lg font-bold tracking-widest text-white border-b border-zinc-900 pb-2"
            >
              RAVE SOUND STATION
            </button>
            <button 
              onClick={() => { setMobileMenuOpen(false); onNavigateToSection('hero'); }} 
              className="text-left text-zinc-400 text-sm tracking-widest"
            >
              HOME
            </button>
          </div>

          <div className="mt-auto border-t border-zinc-900 pt-6 flex flex-col gap-3 font-mono text-xs text-zinc-500">
            <p>DESIGNED & ENGINEERED IN BRITAIN</p>
            <p>© 2026 AUREOM FUEL LTD.</p>
          </div>
        </div>
      )}
    </header>
  );
}
