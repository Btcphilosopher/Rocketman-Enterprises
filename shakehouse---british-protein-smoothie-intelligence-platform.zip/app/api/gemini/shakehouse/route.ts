import { GoogleGenAI, Type } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';
import { calculateFormulation } from '@/lib/shakehouse/formulation-engine';
import { FormulationInput } from '@/lib/shakehouse/types';

export async function POST(req: NextRequest) {
  try {
    const { prompt } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are Gemini 3.7 Flash acting as the Senior British Food Scientist for SHAKEHOUSE - British Protein Smoothie Laboratory.
Your job is to translate natural language user requests (e.g., "I want something like a chocolate orange but not too sweet, high protein and thick") into a structured smoothie formulation.

Available Ingredient IDs to choose from:
- Liquids: "whole_milk", "oat_milk", "almond_milk"
- Bases: "greek_yoghurt", "skyr_yoghurt"
- Proteins: "whey_vanilla_isolate", "whey_chocolate_concentrate", "micellar_casein_unflavoured", "plant_pea_hemp_blend", "bovine_collagen_peptides", "egg_white_isolate"
- Fruits: "rhubarb_stewed", "strawberries_british", "blackcurrant_compote", "gooseberry_purée", "bramley_apple", "conference_pear", "banana_ripe"
- Flavours: "custard_cream_base", "lemon_curd", "orange_marmalade", "malt_extract", "earl_grey_infusion", "cocoa_powder_dutch"
- Biscuits: "digestive_biscuit"
- Strange/Adventurous: "stem_ginger_syrup", "sea_salt_flakes", "fresh_basil_leaves"

You MUST return a valid JSON object matching this schema:
{
  "shakeName": "String title, e.g. THE CHOCOLATE ORANGE BUILDER",
  "explanation": "Friendly British food science explanation of why these ingredients match their request",
  "formulationInput": {
    "baseId": "optional string ID",
    "liquidId": "string ID e.g. whole_milk",
    "liquid_amount_ml": 200,
    "proteinId": "string ID e.g. whey_chocolate_concentrate",
    "protein_scoops": 1,
    "fruitIds": [{"id": "fruit_id", "amount_g": 80}],
    "flavourIds": [{"id": "flavour_id", "amount_g": 20}],
    "biscuitId": "optional biscuit_id",
    "biscuit_amount_g": 15,
    "strangeIds": [{"id": "strange_id", "amount_g": 10}],
    "ice_cubes": 4
  }
}`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            shakeName: { type: Type.STRING },
            explanation: { type: Type.STRING },
            formulationInput: {
              type: Type.OBJECT,
              properties: {
                baseId: { type: Type.STRING },
                liquidId: { type: Type.STRING },
                liquid_amount_ml: { type: Type.NUMBER },
                proteinId: { type: Type.STRING },
                protein_scoops: { type: Type.NUMBER },
                fruitIds: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      amount_g: { type: Type.NUMBER }
                    }
                  }
                },
                flavourIds: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      amount_g: { type: Type.NUMBER }
                    }
                  }
                },
                biscuitId: { type: Type.STRING },
                biscuit_amount_g: { type: Type.NUMBER },
                strangeIds: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      amount_g: { type: Type.NUMBER }
                    }
                  }
                },
                ice_cubes: { type: Type.NUMBER }
              }
            }
          },
          required: ['shakeName', 'explanation', 'formulationInput']
        }
      }
    });

    const resultText = response.text || '{}';
    const parsed = JSON.parse(resultText);

    // Calculate the deterministic formulation using Python/TS engine
    const calculated = calculateFormulation(parsed.formulationInput as FormulationInput, parsed.shakeName);

    return NextResponse.json({
      success: true,
      shakeName: parsed.shakeName,
      explanation: parsed.explanation,
      formulationInput: parsed.formulationInput,
      calculated
    });
  } catch (error: any) {
    console.error('Gemini error:', error);
    return NextResponse.json({ error: error.message || 'AI Formulation failed' }, { status: 500 });
  }
}
