import { NextRequest, NextResponse } from 'next/server';
import { calculateFormulation } from '@/lib/shakehouse/formulation-engine';
import { generateBertieBottsExperiments } from '@/lib/shakehouse/flavour-compatibility';
import { substituteIngredientInFormulation, optimiseFormulationForGoal } from '@/lib/shakehouse/optimiser';
import { solveKitchenIngredients } from '@/lib/shakehouse/kitchen-solver';
import { INGREDIENT_DATABASE } from '@/lib/shakehouse/ingredients-db';
import { PROTEIN_DATABASE } from '@/lib/shakehouse/proteins-db';
import { SUPPLEMENT_DATABASE } from '@/lib/shakehouse/supplements-db';
import { RECIPE_CATALOGUE } from '@/lib/shakehouse/recipes-db';
import { shakehouseR } from '@/lib/shakehouse/shakehouseR';
import { getSyntheticDatasetSummary } from '@/lib/shakehouse/synthetic-data';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get('action');

  if (action === 'catalogues') {
    return NextResponse.json({
      ingredients: INGREDIENT_DATABASE,
      proteins: PROTEIN_DATABASE,
      supplements: SUPPLEMENT_DATABASE,
      recipes: RECIPE_CATALOGUE
    });
  }

  if (action === 'analytics') {
    return NextResponse.json({
      synthetic_stats: getSyntheticDatasetSummary(),
      r_recipe_analysis: shakehouseR.recipe_analysis(),
      r_flavour_analysis: shakehouseR.flavour_analysis(),
      r_nutrition_analysis: shakehouseR.nutrition_analysis(),
      r_ab_test_analysis: shakehouseR.ab_test_analysis()
    });
  }

  return NextResponse.json({
    status: 'SHAKEHOUSE Intelligence API Active',
    version: '1.0.0-British-Lab',
    capabilities: ['formulate', 'optimise', 'substitute', 'bertie-botts', 'kitchen-solver']
  });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action, input, title, substitutionType, goal, onHandIds } = body;

    if (action === 'formulate') {
      const calculated = calculateFormulation(input, title);
      return NextResponse.json({ success: true, calculated });
    }

    if (action === 'substitute') {
      const newInput = substituteIngredientInFormulation(input, substitutionType);
      const calculated = calculateFormulation(newInput, title);
      return NextResponse.json({ success: true, input: newInput, calculated });
    }

    if (action === 'optimise') {
      const res = optimiseFormulationForGoal(input, goal);
      return NextResponse.json({ success: true, input: res.input, calculated: res.calculated });
    }

    if (action === 'bertie_botts') {
      const experiments = generateBertieBottsExperiments(body.count || 6);
      return NextResponse.json({ success: true, experiments });
    }

    if (action === 'kitchen_solver') {
      const matches = solveKitchenIngredients(onHandIds || []);
      return NextResponse.json({ success: true, matches });
    }

    return NextResponse.json({ error: 'Invalid action provided' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Internal Server Error' }, { status: 500 });
  }
}
