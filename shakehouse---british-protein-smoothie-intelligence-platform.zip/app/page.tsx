'use client';

import React, { useState } from 'react';
import { HeaderNav } from '@/components/shakehouse/HeaderNav';
import { SignatureDemos } from '@/components/shakehouse/SignatureDemos';
import { ShakeBuilder } from '@/components/shakehouse/ShakeBuilder';
import { BertieBottsLab } from '@/components/shakehouse/BertieBottsLab';
import { MakeMeAShakeAI } from '@/components/shakehouse/MakeMeAShakeAI';
import { WhatsInMyKitchen } from '@/components/shakehouse/WhatsInMyKitchen';
import { RecipeBook } from '@/components/shakehouse/RecipeBook';
import { SupplementCabinet } from '@/components/shakehouse/SupplementCabinet';
import { FlavourProfileRadar } from '@/components/shakehouse/FlavourProfileRadar';
import { AdminLab } from '@/components/shakehouse/AdminLab';
import { BlenderSimulatorModal } from '@/components/shakehouse/BlenderSimulatorModal';
import { EmbedModal } from '@/components/shakehouse/EmbedModal';
import { FormulationInput } from '@/lib/shakehouse/types';
import { substituteIngredientInFormulation } from '@/lib/shakehouse/optimiser';

// Signature Demo 1: The Rhubarb Custard
const DEFAULT_RHUBARB_CUSTARD_INPUT: FormulationInput = {
  baseId: 'greek_yoghurt',
  liquidId: 'oat_milk',
  liquid_amount_ml: 200,
  proteinId: 'whey_vanilla_isolate',
  protein_scoops: 1,
  fruitIds: [{ id: 'rhubarb_stewed', amount_g: 80 }],
  flavourIds: [{ id: 'custard_cream_base', amount_g: 40 }],
  ice_cubes: 4
};

// Signature Demo 2: The Chocolate Digestive
const CHOCOLATE_DIGESTIVE_INPUT: FormulationInput = {
  baseId: 'greek_yoghurt',
  liquidId: 'whole_milk',
  liquid_amount_ml: 200,
  proteinId: 'whey_chocolate_concentrate',
  protein_scoops: 1,
  biscuitId: 'digestive_biscuit',
  biscuit_amount_g: 15,
  flavourIds: [{ id: 'cocoa_powder_dutch', amount_g: 8 }],
  strangeIds: [{ id: 'sea_salt_flakes', amount_g: 1 }],
  ice_cubes: 4
};

export default function ShakehousePage() {
  const [activeTab, setActiveTab] = useState<string>('builder');
  const [currentInput, setCurrentInput] = useState<FormulationInput>(DEFAULT_RHUBARB_CUSTARD_INPUT);
  const [customTitle, setCustomTitle] = useState<string>('THE RHUBARB CUSTARD');
  const [activeDemo, setActiveDemo] = useState<string>('rhubarb_custard');

  const [blendSpeed, setBlendSpeed] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
  const [isBlenderModalOpen, setIsBlenderModalOpen] = useState(false);
  const [isEmbedModalOpen, setIsEmbedModalOpen] = useState(false);

  // Demo selection handler
  const handleSelectDemo = (demoType: 'rhubarb_custard' | 'chocolate_digestive' | 'bertie_botts') => {
    setActiveDemo(demoType);
    if (demoType === 'rhubarb_custard') {
      setCurrentInput(DEFAULT_RHUBARB_CUSTARD_INPUT);
      setCustomTitle('THE RHUBARB CUSTARD');
      setActiveTab('builder');
    } else if (demoType === 'chocolate_digestive') {
      setCurrentInput(CHOCOLATE_DIGESTIVE_INPUT);
      setCustomTitle('THE CHOCOLATE DIGESTIVE');
      setActiveTab('builder');
    } else if (demoType === 'bertie_botts') {
      setActiveTab('bertie');
    }
  };

  // Quick Tweak Solver
  const handleTweak = (tweakType: 'PLANT_BASED' | 'HIGHER_PROTEIN' | 'LOWER_CALORIE' | 'CHEAPER' | 'LESS_SWEET' | 'THICKER') => {
    const tweaked = substituteIngredientInFormulation(currentInput, tweakType);
    setCurrentInput(tweaked);
    setCustomTitle(`THE ${tweakType.replace('_', ' ')} FORMULATION`);
    setActiveTab('builder');
  };

  // Load formulation from any sub-view into builder
  const handleLoadFormulation = (input: FormulationInput, title: string) => {
    setCurrentInput(input);
    setCustomTitle(title);
    setActiveTab('builder');
  };

  return (
    <div className="min-h-screen bg-[#F5EFE6] text-[#0E1B2E] flex flex-col font-sans selection:bg-[#0A3828] selection:text-white">
      {/* Header & Mode Switcher */}
      <HeaderNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onOpenEmbed={() => setIsEmbedModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {/* Signature Demonstration Suite Bar (Always accessible top hero) */}
        <SignatureDemos
          onSelectDemo={handleSelectDemo}
          onTweak={handleTweak}
          activeDemo={activeDemo}
        />

        {/* Tab Views */}
        {activeTab === 'builder' && (
          <ShakeBuilder
            currentInput={currentInput}
            customTitle={customTitle}
            onInputChange={setCurrentInput}
            onOpenBlenderModal={() => setIsBlenderModalOpen(true)}
            blendSpeed={blendSpeed}
          />
        )}

        {activeTab === 'bertie' && (
          <BertieBottsLab onLoadExperiment={handleLoadFormulation} />
        )}

        {activeTab === 'ai_nl' && (
          <MakeMeAShakeAI onLoadFormulation={handleLoadFormulation} />
        )}

        {activeTab === 'kitchen' && (
          <WhatsInMyKitchen onLoadFormulation={handleLoadFormulation} />
        )}

        {activeTab === 'recipes' && (
          <RecipeBook onLoadRecipe={handleLoadFormulation} />
        )}

        {activeTab === 'cabinet' && (
          <SupplementCabinet />
        )}

        {activeTab === 'profile' && (
          <FlavourProfileRadar onLoadFormulation={handleLoadFormulation} />
        )}

        {activeTab === 'admin' && (
          <AdminLab />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#0E1B2E] text-white border-t border-[#0A3828] py-8 mt-12 text-center text-xs font-mono">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-serif font-bold text-base text-[#FAF8F5]">
            SHAKEHOUSE • BRITISH PROTEIN SMOOTHIE LABORATORY
          </p>
          <p className="text-[#E6D7C3]">
            Formulation Engine • Flavour Vector Intelligence • Bertie Bott's Experimental Mode
          </p>
          <p className="text-[#F3D068] text-[10px] uppercase tracking-widest pt-2">
            © 2026 SHAKEHOUSE LABS. ALL FORMULATIONS CALCULATED DETERMINISTICALLY.
          </p>
        </div>
      </footer>

      {/* Modals */}
      <BlenderSimulatorModal
        isOpen={isBlenderModalOpen}
        onClose={() => setIsBlenderModalOpen(false)}
        shakeTitle={customTitle || 'THE SHAKEHOUSE FORMULATION'}
        onSpeedChange={setBlendSpeed}
        currentSpeed={blendSpeed}
      />

      <EmbedModal
        isOpen={isEmbedModalOpen}
        onClose={() => setIsEmbedModalOpen(false)}
      />
    </div>
  );
}
