import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'SHAKEHOUSE - British Protein Smoothie Laboratory',
  description: 'SHAKEHOUSE is a premium British protein smoothie intelligence platform combining formulation science, British flavours, Bertie Bott\'s experimental mode, and personalized nutrition.',
  openGraph: {
    title: 'SHAKEHOUSE - British Protein Smoothie Laboratory',
    description: 'SHAKEHOUSE is a premium British protein smoothie intelligence platform combining formulation science, British flavours, Bertie Bott\'s experimental mode, and personalized nutrition.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SHAKEHOUSE - British Protein Smoothie Laboratory',
    description: 'SHAKEHOUSE is a premium British protein smoothie intelligence platform combining formulation science, British flavours, Bertie Bott\'s experimental mode, and personalized nutrition.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
