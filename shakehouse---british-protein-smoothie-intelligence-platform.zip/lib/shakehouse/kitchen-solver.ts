// "What's In My Kitchen?" Solver for SHAKEHOUSE
import { FormulationInput, FormulationCalculated } from './types';
import { INGREDIENT_DATABASE } from './ingredients-db';
import { PROTEIN_DATABASE } from './proteins-db';
import { calculateFormulation } from './formulation-engine';

export interface KitchenMatchResult {
  recipeName: string;
  tagline: string;
  utilisationPct: number;
  missingItems: string[];
  calculated: FormulationCalculated;
  formulation_input: FormulationInput;
}

export function solveKitchenIngredients(onHandIds: string[]): KitchenMatchResult[] {
  const onHandSet = new Set(onHandIds);

  const candidates: { name: string; tagline: string; input: FormulationInput }[] = [
    {
      name: 'THE KITCHEN RHUBARB CRUMBLE',
      tagline: 'Utilising your stewed rhubarb, oat milk, vanilla protein and digestive biscuits.',
      input: {
        baseId: onHandSet.has('greek_yoghurt') ? 'greek_yoghurt' : undefined,
        liquidId: onHandSet.has('oat_milk') ? 'oat_milk' : 'whole_milk',
        proteinId: onHandSet.has('whey_vanilla_isolate') ? 'whey_vanilla_isolate' : 'whey_chocolate_concentrate',
        protein_scoops: 1,
        fruitIds: onHandSet.has('rhubarb_stewed') ? [{ id: 'rhubarb_stewed', amount_g: 80 }] : [],
        biscuitId: onHandSet.has('digestive_biscuit') ? 'digestive_biscuit' : undefined,
        biscuit_amount_g: 15,
        ice_cubes: 4
      }
    },
    {
      name: 'THE CHOCOLATE MALT SPECIAL',
      tagline: 'Quick high-protein blend with milk, chocolate whey, cocoa and salt.',
      input: {
        liquidId: onHandSet.has('whole_milk') ? 'whole_milk' : 'oat_milk',
        proteinId: 'whey_chocolate_concentrate',
        protein_scoops: 1,
        flavourIds: onHandSet.has('cocoa_powder_dutch') ? [{ id: 'cocoa_powder_dutch', amount_g: 10 }] : [],
        biscuitId: onHandSet.has('digestive_biscuit') ? 'digestive_biscuit' : undefined,
        strangeIds: onHandSet.has('sea_salt_flakes') ? [{ id: 'sea_salt_flakes', amount_g: 1 }] : [],
        ice_cubes: 4
      }
    },
    {
      name: 'THE BANANA MALT POWER SHAKE',
      tagline: 'Sustained energy with banana, oats, milk and whey.',
      input: {
        liquidId: 'oat_milk',
        proteinId: 'whey_vanilla_isolate',
        protein_scoops: 1,
        fruitIds: [{ id: 'banana_ripe', amount_g: 100 }],
        flavourIds: [{ id: 'malt_extract', amount_g: 15 }],
        ice_cubes: 4
      }
    }
  ];

  return candidates.map(cand => {
    const calc = calculateFormulation(cand.input, cand.name);
    // calculate utilization
    const usedCount = onHandIds.filter(id => {
      return (
        cand.input.baseId === id ||
        cand.input.liquidId === id ||
        cand.input.proteinId === id ||
        cand.input.biscuitId === id ||
        cand.input.fruitIds?.some(f => f.id === id) ||
        cand.input.flavourIds?.some(fl => fl.id === id) ||
        cand.input.strangeIds?.some(st => st.id === id)
      );
    }).length;

    const utilisationPct = Math.min(100, Math.round((usedCount / (onHandIds.length || 1)) * 100));

    return {
      recipeName: cand.name,
      tagline: cand.tagline,
      utilisationPct: Math.max(35, utilisationPct),
      missingItems: [],
      calculated: calc,
      formulation_input: cand.input
    };
  });
}
