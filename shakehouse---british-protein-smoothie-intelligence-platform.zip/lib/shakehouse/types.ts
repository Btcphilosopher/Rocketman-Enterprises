// SHAKEHOUSE Domain Model Types

export type IngredientCategory =
  | 'base'
  | 'liquid'
  | 'protein'
  | 'fruit'
  | 'flavour'
  | 'texture'
  | 'sweetener'
  | 'acid'
  | 'functional'
  | 'supplement'
  | 'ice'
  | 'biscuit'
  | 'exotic';

export type UKAllergen =
  | 'celery'
  | 'cereals_gluten'
  | 'crustaceans'
  | 'eggs'
  | 'fish'
  | 'lupin'
  | 'milk'
  | 'molluscs'
  | 'mustard'
  | 'tree_nuts'
  | 'peanuts'
  | 'sesame'
  | 'soybeans'
  | 'sulphites';

export type ProvenanceState =
  | 'VERIFIED'
  | 'SUPPLIER'
  | 'USER_ENTERED'
  | 'ESTIMATED'
  | 'SYNTHETIC'
  | 'ML_PREDICTED';

export type FlavourClassification =
  | 'SAFE BET'
  | 'INTERESTING'
  | 'ADVENTUROUS'
  | 'ODD'
  | 'EXPERIMENTAL';

export interface FlavourVector {
  sweet: number;      // 0 - 100
  acid: number;       // 0 - 100
  fruit: number;      // 0 - 100
  cream: number;      // 0 - 100
  citrus: number;     // 0 - 100
  chocolate: number;  // 0 - 100
  vanilla: number;    // 0 - 100
  spice: number;      // 0 - 100
  floral: number;     // 0 - 100
  roasted: number;    // 0 - 100
  nutty: number;      // 0 - 100
  malty: number;      // 0 - 100
}

export interface TextureProfile {
  viscosity: number;   // 0 - 100 (liquid vs thick paste)
  creaminess: number;  // 0 - 100
  thickness: number;   // 0 - 100
  smoothness: number;  // 0 - 100
  graininess: number;  // 0 - 100
  foaming: number;     // 0 - 100
}

export interface AllergenProfile {
  contains: UKAllergen[];
  may_contain: UKAllergen[];
  derived_from: string[];
  isIncomplete: boolean;
}

export interface Ingredient {
  id: string;
  name: string;
  display_name: string;
  category: IngredientCategory;
  description: string;
  origin?: string;
  brand?: string;
  supplier?: string;
  serving_size_g: number;
  calories_per_100g: number;
  protein_per_100g: number;
  carbs_per_100g: number;
  sugar_per_100g: number;
  fat_per_100g: number;
  sat_fat_per_100g: number;
  fibre_per_100g: number;
  salt_per_100g: number;
  water_content_pct: number;
  density_g_ml: number; // e.g. 1.03 for milk, 0.9 for yoghurt, 1.4 for honey
  cost_per_100g: number; // GBP (£)
  seasonality?: ('spring' | 'summer' | 'autumn' | 'winter')[];
  color_hex: string;
  flavour_profile: FlavourVector;
  allergens: AllergenProfile;
  provenance: ProvenanceState;
}

export interface ProteinProduct {
  id: string;
  name: string;
  brand: string;
  protein_source: 'whey_isolate' | 'whey_concentrate' | 'casein' | 'milk_protein' | 'pea' | 'soy' | 'rice' | 'hemp' | 'plant_blend' | 'collagen' | 'egg';
  protein_per_100g: number;
  serving_size_g: number;
  calories_per_100g: number;
  carbs_per_100g: number;
  fat_per_100g: number;
  sugar_per_100g: number;
  flavour: string;
  sweetener: string;
  solubility: number; // 0-100
  thickness: number;  // 0-100
  foaming: number;    // 0-100
  mixability: number; // 0-100
  price_per_serving: number; // GBP (£)
  color_hex: string;
  provenance: ProvenanceState;
  allergens: AllergenProfile;
}

export interface SupplementProduct {
  id: string;
  brand: string;
  product: string;
  category: 'creatine' | 'electrolytes' | 'fibre' | 'oats' | 'cocoa' | 'collagen' | 'vitamins' | 'flavour' | 'greens' | 'nut_butter' | 'seed_powder';
  serving_size_g: number;
  ingredients_list: string[];
  calories_per_serving: number;
  protein_per_serving: number;
  carbs_per_serving: number;
  fat_per_serving: number;
  fibre_per_serving: number;
  cost_per_serving: number; // GBP (£)
  flavour_note: string;
  format: 'powder' | 'liquid' | 'drops';
  warnings?: string;
  allergens: AllergenProfile;
  provenance: ProvenanceState;
}

export interface IngredientAmount {
  ingredientId: string;
  amount_g: number;
  notes?: string;
}

export interface SupplementAmount {
  supplementId: string;
  servings: number;
}

export interface FormulationInput {
  baseId?: string;
  liquidId?: string;
  liquid_amount_ml?: number;
  proteinId?: string;
  protein_scoops?: number; // 1 scoop = ~30g
  fruitIds?: { id: string; amount_g: number }[];
  flavourIds?: { id: string; amount_g: number }[];
  biscuitId?: string;
  biscuit_amount_g?: number;
  strangeIds?: { id: string; amount_g: number }[];
  sweetenerId?: string;
  sweetener_amount_g?: number;
  ice_cubes?: number; // 1 cube = ~20g
  supplements?: { supplementId: string; servings: number }[];
  blendSpeed?: 'LOW' | 'MEDIUM' | 'HIGH';
}

export interface FormulationCalculated {
  id: string;
  title: string;
  subtitle: string;
  total_mass_g: number;
  estimated_volume_ml: number;
  calories: number;
  protein_g: number;
  carbs_g: number;
  sugar_g: number;
  fat_g: number;
  sat_fat_g: number;
  fibre_g: number;
  salt_g: number;
  protein_density_g_per_100kcal: number;
  cost_gbp: number;
  sweetness_index: number;  // 0 - 100
  acidity_index: number;    // 0 - 100
  balance_score: number;    // 0 - 100
  texture: TextureProfile;
  flavour_vector: FlavourVector;
  allergens: AllergenProfile;
  supplements_summary: { name: string; amount: string; cost: number }[];
  visual_color_hex: string;
  flavour_classification: FlavourClassification;
  flavour_logic: string;
  provenance_summary: ProvenanceState;
}

export interface Recipe {
  id: string;
  name: string;
  category: 'BRITISH CLASSICS' | 'PROTEIN' | 'BREAKFAST' | 'DESSERT' | 'FRUIT' | 'CHOCOLATE' | 'TEA' | 'COFFEE' | 'EXPERIMENTAL' | 'SEASONAL' | 'PLANT';
  description: string;
  tagline: string;
  formulation_input: FormulationInput;
  method: string[];
  prep_time_mins: number;
  seasonal_best?: 'spring' | 'summer' | 'autumn' | 'winter';
  hero_image_url?: string;
  provenance: ProvenanceState;
}

export interface UserFlavourProfile {
  userId: string;
  preferred_flavours: FlavourVector;
  texture_preference: 'light' | 'creamy' | 'thick' | 'dessert' | 'icy';
  target_protein_g: number;
  target_calories: number;
  experimental_readiness: number; // 0-100
  dietary_restrictions: UKAllergen[];
  saved_recipe_ids: string[];
}

export interface GoalConstraint {
  target: 'HIGH_PROTEIN' | 'LOWER_CALORIE' | 'BREAKFAST' | 'POST_WORKOUT' | 'DESSERT' | 'FRUIT_HEAVY' | 'CREAMY' | 'LIGHT' | 'HIGH_FIBRE' | 'PLANT_BASED' | 'BUDGET';
  max_calories?: number;
  min_protein_g?: number;
  max_cost_gbp?: number;
  max_sugar_g?: number;
}
