// Flavour Compatibility & Bertie Bott's "EVERY SHAKE" Laboratory Engine
import { FlavourVector, FlavourClassification, FormulationInput } from './types';
import { INGREDIENT_DATABASE } from './ingredients-db';
import { PROTEIN_DATABASE } from './proteins-db';
import { calculateFormulation } from './formulation-engine';

export function calculateCosineSimilarity(vecA: FlavourVector, vecB: FlavourVector): number {
  const keys = Object.keys(vecA) as (keyof FlavourVector)[];
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  keys.forEach((k) => {
    const valA = vecA[k] || 0;
    const valB = vecB[k] || 0;
    dotProduct += valA * valB;
    normA += valA * valA;
    normB += valB * valB;
  });

  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

export interface BertieExperiment {
  id: string;
  name: string;
  tagline: string;
  classification: FlavourClassification;
  novelty_score: number; // 0-100
  compatibility_score: number; // 0-100
  flavour_explanation: string;
  formulation_input: FormulationInput;
}

export function generateBertieBottsExperiments(count = 6): BertieExperiment[] {
  const seeds: {
    name: string;
    tagline: string;
    explanation: string;
    input: FormulationInput;
  }[] = [
    {
      name: 'THE MARMALADE MONSTER',
      tagline: 'Seville orange marmalade, raw cocoa powder, Yorkshire chocolate whey & whole milk.',
      explanation: 'Bittersweet Dundee marmalade peel cuts through heavy cocoa fat, creating a classic British Jaffa Cake flavor profile.',
      input: {
        baseId: 'greek_yoghurt',
        liquidId: 'whole_milk',
        liquid_amount_ml: 200,
        proteinId: 'whey_chocolate_concentrate',
        protein_scoops: 1,
        flavourIds: [
          { id: 'orange_marmalade', amount_g: 25 },
          { id: 'cocoa_powder_dutch', amount_g: 8 }
        ],
        ice_cubes: 4
      }
    },
    {
      name: 'THE RASPBERRY TEA PARTY',
      tagline: 'Fresh raspberries, concentrated Earl Grey tea, vanilla whey isolate & oat milk.',
      explanation: 'Floral bergamot oil lifts tart red raspberry notes while vanilla whey rounds out black tea astringency.',
      input: {
        liquidId: 'oat_milk',
        liquid_amount_ml: 220,
        proteinId: 'whey_vanilla_isolate',
        protein_scoops: 1,
        fruitIds: [{ id: 'strawberries_british', amount_g: 80 }],
        flavourIds: [{ id: 'earl_grey_infusion', amount_g: 30 }],
        ice_cubes: 4
      }
    },
    {
      name: 'THE STRAWBERRY & BASIL LAB',
      tagline: 'Kent strawberries, fresh garden basil, Maldon sea salt & Madagascar vanilla whey.',
      explanation: 'Peppery essential oils in fresh basil bind to strawberry aroma compounds, yielding a surprising savory-sweet high-street twist.',
      input: {
        baseId: 'greek_yoghurt',
        liquidId: 'whole_milk',
        liquid_amount_ml: 180,
        proteinId: 'whey_vanilla_isolate',
        protein_scoops: 1,
        fruitIds: [{ id: 'strawberries_british', amount_g: 100 }],
        strangeIds: [
          { id: 'fresh_basil_leaves', amount_g: 3 },
          { id: 'sea_salt_flakes', amount_g: 1 }
        ],
        ice_cubes: 4
      }
    },
    {
      name: 'THE GINGERED PEAR & MALT',
      tagline: 'Conference pear, diced stem ginger syrup, malted barley extract & casein.',
      explanation: 'Fiery ginger root heat provides a sharp counterpoint to smooth pear juice and dark sticky malt loaf notes.',
      input: {
        baseId: 'greek_yoghurt',
        liquidId: 'oat_milk',
        liquid_amount_ml: 200,
        proteinId: 'micellar_casein_unflavoured',
        protein_scoops: 1,
        fruitIds: [{ id: 'conference_pear', amount_g: 90 }],
        flavourIds: [{ id: 'malt_extract', amount_g: 15 }],
        strangeIds: [{ id: 'stem_ginger_syrup', amount_g: 15 }],
        ice_cubes: 4
      }
    },
    {
      name: 'THE GOOSEBERRY ELDERFLOWER ENGINE',
      tagline: 'Tart green gooseberries, elderflower cordial, egg white protein & Skyr.',
      explanation: 'Vibrant green acidity harmonizes with floral elderflower terpenes for an ultra-refreshing high-protein tonic.',
      input: {
        baseId: 'skyr_yoghurt',
        liquidId: 'almond_milk',
        liquid_amount_ml: 200,
        proteinId: 'egg_white_isolate',
        protein_scoops: 1,
        fruitIds: [{ id: 'gooseberry_purée', amount_g: 70 }],
        ice_cubes: 4
      }
    },
    {
      name: 'THE CHOCOLATE & CHILLI DIGESTIVE',
      tagline: 'Yorkshire chocolate whey, crushed wholemeal digestive, cocoa & warming ginger.',
      explanation: 'A rich chocolate dessert shake infused with subtle warming spice and wholemeal biscuit texture.',
      input: {
        baseId: 'greek_yoghurt',
        liquidId: 'whole_milk',
        liquid_amount_ml: 200,
        proteinId: 'whey_chocolate_concentrate',
        protein_scoops: 1,
        biscuitId: 'digestive_biscuit',
        biscuit_amount_g: 15,
        strangeIds: [{ id: 'stem_ginger_syrup', amount_g: 12 }],
        ice_cubes: 4
      }
    }
  ];

  return seeds.slice(0, count).map((s, idx) => {
    const calc = calculateFormulation(s.input, s.name);
    return {
      id: `bertie_${idx}_${Date.now()}`,
      name: s.name,
      tagline: s.tagline,
      classification: calc.flavour_classification,
      novelty_score: Math.min(100, Math.max(40, 100 - calc.balance_score + 35)),
      compatibility_score: calc.balance_score,
      flavour_explanation: s.explanation,
      formulation_input: s.input
    };
  });
}
