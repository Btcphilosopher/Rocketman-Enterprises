// SHAKEHOUSE Formulation & Physics Engine
import {
  FormulationInput,
  FormulationCalculated,
  FlavourVector,
  TextureProfile,
  AllergenProfile,
  ProvenanceState,
  FlavourClassification,
  UKAllergen
} from './types';
import { getIngredientById } from './ingredients-db';
import { getProteinById } from './proteins-db';
import { getSupplementById } from './supplements-db';

export function calculateFormulation(input: FormulationInput, customTitle?: string): FormulationCalculated {
  let total_mass_g = 0;
  let raw_volume_ml = 0;

  let total_calories = 0;
  let total_protein_g = 0;
  let total_carbs_g = 0;
  let total_sugar_g = 0;
  let total_fat_g = 0;
  let total_sat_fat_g = 0;
  let total_fibre_g = 0;
  let total_salt_g = 0;

  let total_cost_gbp = 0;

  // Composite flavour vector accumulators
  const flavourAcc: Record<keyof FlavourVector, number> = {
    sweet: 0, acid: 0, fruit: 0, cream: 0, citrus: 0, chocolate: 0,
    vanilla: 0, spice: 0, floral: 0, roasted: 0, nutty: 0, malty: 0
  };

  // Allergen tracking
  const containsSet = new Set<UKAllergen>();
  const mayContainSet = new Set<UKAllergen>();
  const derivedFromList: string[] = [];
  let isIncompleteAllergen = false;

  // Track provenance
  const provenanceStates: ProvenanceState[] = [];

  // Helper to add ingredient contribution
  const processItem = (id: string, amount_g: number, categoryMultiplier = 1.0) => {
    if (amount_g <= 0) return;
    const ing = getIngredientById(id);
    if (!ing) return;

    total_mass_g += amount_g;
    const itemVol = amount_g / (ing.density_g_ml || 1.0);
    raw_volume_ml += itemVol;

    const factor = amount_g / 100;
    total_calories += ing.calories_per_100g * factor;
    total_protein_g += ing.protein_per_100g * factor;
    total_carbs_g += ing.carbs_per_100g * factor;
    total_sugar_g += ing.sugar_per_100g * factor;
    total_fat_g += ing.fat_per_100g * factor;
    total_sat_fat_g += ing.sat_fat_per_100g * factor;
    total_fibre_g += ing.fibre_per_100g * factor;
    total_salt_g += ing.salt_per_100g * factor;

    total_cost_gbp += (ing.cost_per_100g || 0) * factor;

    // Accumulate flavour weighted by mass and category intensity
    const weight = amount_g * categoryMultiplier;
    Object.keys(ing.flavour_profile).forEach((k) => {
      const key = k as keyof FlavourVector;
      flavourAcc[key] += (ing.flavour_profile[key] || 0) * weight;
    });

    // Allergens
    ing.allergens.contains.forEach(a => containsSet.add(a));
    ing.allergens.may_contain.forEach(a => mayContainSet.add(a));
    if (ing.allergens.derived_from) derivedFromList.push(...ing.allergens.derived_from);
    if (ing.allergens.isIncomplete) isIncompleteAllergen = true;

    provenanceStates.push(ing.provenance);
  };

  // 1. Process Base (e.g. Greek Yoghurt / Skyr)
  if (input.baseId) {
    processItem(input.baseId, 150, 1.2);
  }

  // 2. Process Liquid (e.g. Oat milk, Whole milk, Almond milk)
  const liquid_ml = input.liquid_amount_ml || 200;
  if (input.liquidId) {
    const ing = getIngredientById(input.liquidId);
    const mass = liquid_ml * (ing?.density_g_ml || 1.03);
    processItem(input.liquidId, mass, 0.8);
  }

  // 3. Process Protein Powder
  let proteinThicknessImpact = 0;
  let proteinFoamingImpact = 0;
  if (input.proteinId) {
    const prot = getProteinById(input.proteinId);
    if (prot) {
      const scoops = input.protein_scoops || 1;
      const mass = scoops * prot.serving_size_g;
      total_mass_g += mass;
      raw_volume_ml += mass / 1.35; // Protein powder density ~1.35

      const factor = mass / 100;
      total_calories += prot.calories_per_100g * factor;
      total_protein_g += prot.protein_per_100g * factor;
      total_carbs_g += prot.carbs_per_100g * factor;
      total_sugar_g += prot.sugar_per_100g * factor;
      total_fat_g += prot.fat_per_100g * factor;
      total_cost_gbp += prot.price_per_serving * scoops;

      proteinThicknessImpact = prot.thickness;
      proteinFoamingImpact = prot.foaming;

      // Flavour profile mapping based on protein powder flavour notes
      const weight = mass * 1.5;
      if (prot.flavour.toLowerCase().includes('vanilla')) {
        flavourAcc.vanilla += 85 * weight;
        flavourAcc.sweet += 60 * weight;
        flavourAcc.cream += 50 * weight;
      } else if (prot.flavour.toLowerCase().includes('cocoa') || prot.flavour.toLowerCase().includes('chocolate')) {
        flavourAcc.chocolate += 90 * weight;
        flavourAcc.sweet += 55 * weight;
        flavourAcc.roasted += 40 * weight;
      } else if (prot.flavour.toLowerCase().includes('oat') || prot.flavour.toLowerCase().includes('hazelnut')) {
        flavourAcc.nutty += 70 * weight;
        flavourAcc.malty += 60 * weight;
      }

      prot.allergens.contains.forEach(a => containsSet.add(a));
      prot.allergens.may_contain.forEach(a => mayContainSet.add(a));
      if (prot.allergens.derived_from) derivedFromList.push(...prot.allergens.derived_from);

      provenanceStates.push(prot.provenance);
    }
  }

  // 4. Process Fruits
  if (input.fruitIds && input.fruitIds.length > 0) {
    input.fruitIds.forEach(f => processItem(f.id, f.amount_g, 1.4));
  }

  // 5. Process Flavours (e.g. Custard, Lemon Curd, Marmalade)
  if (input.flavourIds && input.flavourIds.length > 0) {
    input.flavourIds.forEach(fl => processItem(fl.id, fl.amount_g, 1.8));
  }

  // 6. Process Biscuit Texture Addition
  if (input.biscuitId) {
    const mass = input.biscuit_amount_g || 15;
    processItem(input.biscuitId, mass, 1.6);
  }

  // 7. Process Strange / Adventurous Additions (e.g. Basil, Maldon Salt, Stem Ginger)
  if (input.strangeIds && input.strangeIds.length > 0) {
    input.strangeIds.forEach(st => processItem(st.id, st.amount_g, 2.5));
  }

  // 8. Process Sweetener
  if (input.sweetenerId) {
    const mass = input.sweetener_amount_g || 10;
    processItem(input.sweetenerId, mass, 2.0);
  }

  // 9. Process Ice Cubes
  const ice_cubes = input.ice_cubes !== undefined ? input.ice_cubes : 4;
  if (ice_cubes > 0) {
    processItem('ice_cubes', ice_cubes * 20, 0.1);
  }

  // 10. Process Supplements
  const supplements_summary: { name: string; amount: string; cost: number }[] = [];
  if (input.supplements && input.supplements.length > 0) {
    input.supplements.forEach(supItem => {
      const sup = getSupplementById(supItem.supplementId);
      if (sup) {
        const servings = supItem.servings || 1;
        const mass = servings * sup.serving_size_g;
        total_mass_g += mass;
        raw_volume_ml += mass / 1.2;

        total_calories += sup.calories_per_serving * servings;
        total_protein_g += sup.protein_per_serving * servings;
        total_carbs_g += sup.carbs_per_serving * servings;
        total_fat_g += sup.fat_per_serving * servings;
        total_fibre_g += sup.fibre_per_serving * servings;

        const itemCost = sup.cost_per_serving * servings;
        total_cost_gbp += itemCost;

        supplements_summary.push({
          name: sup.product,
          amount: `${servings * sup.serving_size_g}g (${servings} serving${servings > 1 ? 's' : ''})`,
          cost: Math.round(itemCost * 100) / 100
        });

        sup.allergens.contains.forEach(a => containsSet.add(a));
        sup.allergens.may_contain.forEach(a => mayContainSet.add(a));
        if (sup.allergens.derived_from) derivedFromList.push(...sup.allergens.derived_from);

        provenanceStates.push(sup.provenance);
      }
    });
  }

  // Calculate Aeration & Final Volume
  const blendSpeed = input.blendSpeed || 'MEDIUM';
  const speedMultiplier = blendSpeed === 'HIGH' ? 1.22 : blendSpeed === 'MEDIUM' ? 1.14 : 1.06;
  const foamingBoost = (proteinFoamingImpact / 100) * 0.10;
  const estimated_volume_ml = Math.round(raw_volume_ml * (speedMultiplier + foamingBoost));

  // Compute Mass-Normalized Composite Flavour Vector
  const compositeFlavour: FlavourVector = {
    sweet: 0, acid: 0, fruit: 0, cream: 0, citrus: 0, chocolate: 0,
    vanilla: 0, spice: 0, floral: 0, roasted: 0, nutty: 0, malty: 0
  };

  const totalFlavourWeight = total_mass_g || 1;
  (Object.keys(flavourAcc) as (keyof FlavourVector)[]).forEach((key) => {
    compositeFlavour[key] = Math.min(100, Math.round((flavourAcc[key] / totalFlavourWeight) * 1.5));
  });

  // Calculate Protein Density (g per 100 kcal)
  const protein_density_g_per_100kcal = total_calories > 0
    ? Math.round((total_protein_g / (total_calories / 100)) * 10) / 10
    : 0;

  // Relative Sweetness Index & Acidity Index
  const sweetness_index = Math.min(100, Math.max(0, compositeFlavour.sweet + Math.round(total_sugar_g * 0.8)));
  const acidity_index = Math.min(100, Math.max(0, compositeFlavour.acid));

  // Flavour Balance Score
  const acidRatio = acidity_index / (sweetness_index || 1);
  const idealRatioPenalty = Math.abs(acidRatio - 0.4) * 30; // standard sweet/tart balance
  const balance_score = Math.min(100, Math.max(20, Math.round(95 - idealRatioPenalty + (compositeFlavour.cream * 0.2))));

  // Texture Engine Calculations
  const isCasein = input.proteinId?.includes('casein');
  const isGreekOrSkyr = input.baseId === 'greek_yoghurt' || input.baseId === 'skyr_yoghurt';

  const viscosity = Math.min(100, Math.round(
    30 +
    (isGreekOrSkyr ? 35 : 10) +
    (isCasein ? 30 : proteinThicknessImpact * 0.3) +
    (input.biscuitId ? 12 : 0) +
    (input.fruitIds?.some(f => f.id === 'banana_ripe') ? 18 : 0)
  ));

  const creaminess = Math.min(100, Math.round(
    compositeFlavour.cream * 0.7 +
    (input.baseId ? 25 : 0) +
    (input.liquidId === 'whole_milk' ? 20 : input.liquidId === 'oat_milk' ? 15 : 5)
  ));

  const thickness = Math.min(100, Math.round((viscosity * 0.7) + (creaminess * 0.3)));
  const smoothness = Math.min(100, Math.max(20, Math.round(90 - (input.biscuitId ? 25 : 0) - (input.proteinId?.includes('plant') ? 15 : 0))));
  const graininess = 100 - smoothness;
  const foaming = Math.min(100, Math.round(proteinFoamingImpact * (blendSpeed === 'HIGH' ? 1.3 : 1.0)));

  const texture: TextureProfile = {
    viscosity,
    creaminess,
    thickness,
    smoothness,
    graininess,
    foaming
  };

  // Determine Flavour Classification (SAFE BET, INTERESTING, ADVENTUROUS, ODD, EXPERIMENTAL)
  let flavour_classification: FlavourClassification = 'SAFE BET';
  let flavour_logic = 'Familiar British classic profile with harmonious sweet and cream balance.';

  const hasStrange = !!(input.strangeIds && input.strangeIds.length > 0);
  const hasTeaOrSpice = compositeFlavour.floral > 30 || compositeFlavour.spice > 30;
  const highAcidContrast = acidity_index > 60 && compositeFlavour.cream > 50;

  if (hasStrange) {
    if (input.strangeIds?.some(s => s.id === 'fresh_basil_leaves' || s.id === 'sea_salt_flakes')) {
      flavour_classification = 'EXPERIMENTAL';
      flavour_logic = 'Pushes culinary boundaries with savory herbal notes and mineral salt highlights.';
    } else {
      flavour_classification = 'ADVENTUROUS';
      flavour_logic = 'Spicy stem ginger and zesty notes contrast nicely against creamy protein base.';
    }
  } else if (highAcidContrast && compositeFlavour.malty > 30) {
    flavour_classification = 'ODD';
    flavour_logic = 'Intense tart berry acidity combined with dark malted grain notes.';
  } else if (highAcidContrast || hasTeaOrSpice) {
    flavour_classification = 'INTERESTING';
    flavour_logic = 'Bright British fruit tartness cut with velvety custard or floral tea aroma.';
  }

  // Determine Dominant Color for Visualizer
  let visual_color_hex = '#FAF6EE';
  if (input.fruitIds && input.fruitIds.length > 0) {
    const topFruit = getIngredientById(input.fruitIds[0].id);
    if (topFruit) visual_color_hex = topFruit.color_hex;
  } else if (input.flavourIds && input.flavourIds.length > 0) {
    const topFlav = getIngredientById(input.flavourIds[0].id);
    if (topFlav) visual_color_hex = topFlav.color_hex;
  } else if (input.proteinId) {
    const prot = getProteinById(input.proteinId);
    if (prot) visual_color_hex = prot.color_hex;
  }

  // Provenance summary
  const isSynthetic = provenanceStates.some(p => p === 'SYNTHETIC');
  const isUserEntered = provenanceStates.some(p => p === 'USER_ENTERED');
  const provenance_summary: ProvenanceState = isSynthetic ? 'SYNTHETIC' : isUserEntered ? 'USER_ENTERED' : 'VERIFIED';

  // Title & Subtitle Generation
  const title = customTitle || generateDynamicTitle(input, compositeFlavour);
  const subtitle = generateDynamicSubtitle(total_protein_g, Math.round(total_calories), estimated_volume_ml, flavour_classification);

  return {
    id: `formulation_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    title,
    subtitle,
    total_mass_g: Math.round(total_mass_g),
    estimated_volume_ml,
    calories: Math.round(total_calories),
    protein_g: Math.round(total_protein_g * 10) / 10,
    carbs_g: Math.round(total_carbs_g * 10) / 10,
    sugar_g: Math.round(total_sugar_g * 10) / 10,
    fat_g: Math.round(total_fat_g * 10) / 10,
    sat_fat_g: Math.round(total_sat_fat_g * 10) / 10,
    fibre_g: Math.round(total_fibre_g * 10) / 10,
    salt_g: Math.round(total_salt_g * 100) / 100,
    protein_density_g_per_100kcal,
    cost_gbp: Math.round(total_cost_gbp * 100) / 100,
    sweetness_index,
    acidity_index,
    balance_score,
    texture,
    flavour_vector: compositeFlavour,
    allergens: {
      contains: Array.from(containsSet),
      may_contain: Array.from(mayContainSet),
      derived_from: Array.from(new Set(derivedFromList)),
      isIncomplete: isIncompleteAllergen
    },
    supplements_summary,
    visual_color_hex,
    flavour_classification,
    flavour_logic,
    provenance_summary
  };
}

function generateDynamicTitle(input: FormulationInput, f: FlavourVector): string {
  if (input.fruitIds?.some(x => x.id === 'rhubarb_stewed') && (input.flavourIds?.some(x => x.id === 'custard_cream_base') || f.vanilla > 40)) {
    return 'THE RHUBARB CUSTARD';
  }
  if (input.flavourIds?.some(x => x.id === 'orange_marmalade') && f.chocolate > 30) {
    return 'THE MARMALADE BUILDER';
  }
  if (input.biscuitId === 'digestive_biscuit' && f.chocolate > 30) {
    return 'THE CHOCOLATE DIGESTIVE';
  }
  if (input.flavourIds?.some(x => x.id === 'earl_grey_infusion')) {
    return 'THE EARL GREY PROTEIN';
  }
  if (input.fruitIds?.some(x => x.id === 'blackcurrant_compote')) {
    return 'THE BLACKCURRANT FOOL';
  }
  if (input.flavourIds?.some(x => x.id === 'lemon_curd')) {
    return 'THE LEMON CURD BUILDER';
  }
  if (input.fruitIds?.some(x => x.id === 'bramley_apple')) {
    return 'THE APPLE CRUMBLE';
  }
  if (f.chocolate > 60) return 'THE YORKSHIRE CHOCOLATE';
  if (f.fruit > 60) return 'THE KENT BERRY FOOL';
  if (f.malty > 50) return 'THE MALT LOAF BUILDER';

  return 'THE SHAKEHOUSE FORMULATION';
}

function generateDynamicSubtitle(protein: number, kcal: number, vol: number, classif: string): string {
  return `${protein}g Protein • ${kcal} kcal • ${vol}ml [${classif}]`;
}
