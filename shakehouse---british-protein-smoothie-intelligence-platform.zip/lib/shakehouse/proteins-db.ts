// Protein Lab Database for SHAKEHOUSE
import { ProteinProduct } from './types';

export const PROTEIN_DATABASE: ProteinProduct[] = [
  {
    id: 'whey_vanilla_isolate',
    name: 'Madagascar Vanilla Whey Isolate',
    brand: 'SHAKEHOUSE LABS',
    protein_source: 'whey_isolate',
    protein_per_100g: 88.0,
    serving_size_g: 30, // 26.4g protein
    calories_per_100g: 370,
    carbs_per_100g: 1.5,
    sugar_per_100g: 0.8,
    fat_per_100g: 0.9,
    flavour: 'Vanilla Custard',
    sweetener: 'Sucralose & Stevia',
    solubility: 95,
    thickness: 40,
    foaming: 25,
    mixability: 96,
    price_per_serving: 1.10,
    color_hex: '#FFFBEB',
    provenance: 'VERIFIED',
    allergens: { contains: ['milk'], may_contain: [], derived_from: ['bovine milk whey'], isIncomplete: false }
  },
  {
    id: 'whey_chocolate_concentrate',
    name: 'Yorkshire Chocolate Whey Concentrate',
    brand: 'SHAKEHOUSE LABS',
    protein_source: 'whey_concentrate',
    protein_per_100g: 78.0,
    serving_size_g: 30, // 23.4g protein
    calories_per_100g: 405,
    carbs_per_100g: 5.5,
    sugar_per_100g: 4.2,
    fat_per_100g: 6.8,
    flavour: 'Rich Cocoa & Biscuit',
    sweetener: 'Sucralose',
    solubility: 88,
    thickness: 65,
    foaming: 35,
    mixability: 90,
    price_per_serving: 0.85,
    color_hex: '#582F0E',
    provenance: 'VERIFIED',
    allergens: { contains: ['milk'], may_contain: ['soybeans'], derived_from: ['bovine milk whey'], isIncomplete: false }
  },
  {
    id: 'micellar_casein_unflavoured',
    name: 'Nighttime Micellar Casein',
    brand: 'SHAKEHOUSE LABS',
    protein_source: 'casein',
    protein_per_100g: 82.0,
    serving_size_g: 30, // 24.6g protein
    calories_per_100g: 360,
    carbs_per_100g: 3.0,
    sugar_per_100g: 1.2,
    fat_per_100g: 1.5,
    flavour: 'Neutral Milk',
    sweetener: 'None (Unsweetened)',
    solubility: 70,
    thickness: 95, // Ultra thick dessert texture
    foaming: 20,
    mixability: 82,
    price_per_serving: 1.05,
    color_hex: '#F8F9FA',
    provenance: 'VERIFIED',
    allergens: { contains: ['milk'], may_contain: [], derived_from: ['bovine milk casein'], isIncomplete: false }
  },
  {
    id: 'plant_pea_hemp_blend',
    name: 'British Hemp & Golden Pea Blend',
    brand: 'SHAKEHOUSE PLANT',
    protein_source: 'plant_blend',
    protein_per_100g: 76.0,
    serving_size_g: 32, // 24.3g protein
    calories_per_100g: 380,
    carbs_per_100g: 4.2,
    sugar_per_100g: 0.2,
    fat_per_100g: 6.5,
    flavour: 'Toasted Oat & Hazelnut',
    sweetener: 'Stevia Leaf',
    solubility: 78,
    thickness: 75,
    foaming: 40,
    mixability: 84,
    price_per_serving: 0.95,
    color_hex: '#DDA15E',
    provenance: 'VERIFIED',
    allergens: { contains: [], may_contain: ['tree_nuts'], derived_from: ['pea protein', 'hemp seed'], isIncomplete: false }
  },
  {
    id: 'bovine_collagen_peptides',
    name: 'Pure Bovine Collagen Peptides',
    brand: 'SHAKEHOUSE LABS',
    protein_source: 'collagen',
    protein_per_100g: 90.0,
    serving_size_g: 15, // 13.5g protein
    calories_per_100g: 360,
    carbs_per_100g: 0,
    sugar_per_100g: 0,
    fat_per_100g: 0,
    flavour: 'Unflavoured & Odourless',
    sweetener: 'None',
    solubility: 99,
    thickness: 10, // Zero thickness
    foaming: 5,
    mixability: 100,
    price_per_serving: 0.70,
    color_hex: '#FFFFFF',
    provenance: 'VERIFIED',
    allergens: { contains: [], may_contain: [], derived_from: ['bovine hide peptides'], isIncomplete: false }
  },
  {
    id: 'egg_white_isolate',
    name: 'Free Range Egg White Protein',
    brand: 'SHAKEHOUSE LABS',
    protein_source: 'egg',
    protein_per_100g: 84.0,
    serving_size_g: 30, // 25.2g protein
    calories_per_100g: 375,
    carbs_per_100g: 2.0,
    sugar_per_100g: 0.5,
    fat_per_100g: 0.2,
    flavour: 'Neutral Crisp',
    sweetener: 'None',
    solubility: 85,
    thickness: 30,
    foaming: 80, // High foaming potential
    mixability: 88,
    price_per_serving: 1.20,
    color_hex: '#FEF3C7',
    provenance: 'VERIFIED',
    allergens: { contains: ['eggs'], may_contain: [], derived_from: ['egg white albumen'], isIncomplete: false }
  }
];

export function getProteinById(id: string): ProteinProduct | undefined {
  return PROTEIN_DATABASE.find(p => p.id === id);
}
