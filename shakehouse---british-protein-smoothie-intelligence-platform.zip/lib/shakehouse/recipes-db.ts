// British Recipe Catalogue for SHAKEHOUSE
import { Recipe } from './types';

export const RECIPE_CATALOGUE: Recipe[] = [
  {
    id: 'rhubarb_custard',
    name: 'THE RHUBARB CUSTARD',
    category: 'BRITISH CLASSICS',
    tagline: 'Yorkshire forced rhubarb poached with Madagascar vanilla bean custard & creamy whey isolate.',
    description: 'A timeless British dessert reinvented into a high-protein laboratory formulation. Bright tart pink rhubarb cuts through rich velvet custard notes.',
    formulation_input: {
      baseId: 'greek_yoghurt',
      liquidId: 'oat_milk',
      liquid_amount_ml: 200,
      proteinId: 'whey_vanilla_isolate',
      protein_scoops: 1,
      fruitIds: [{ id: 'rhubarb_stewed', amount_g: 80 }],
      flavourIds: [{ id: 'custard_cream_base', amount_g: 40 }],
      ice_cubes: 4
    },
    method: [
      'Add 200ml cold British Oat Milk and 150g Greek Yoghurt to the blender vessel.',
      'Add 1 scoop (30g) Madagascar Vanilla Whey Isolate and 40g Vanilla Custard base.',
      'Spoon in 80g stewed Yorkshire Forced Rhubarb and 4 ice cubes.',
      'Blend on MEDIUM speed for 35 seconds to emulsify and aerate to smooth velvet texture.'
    ],
    prep_time_mins: 3,
    seasonal_best: 'spring',
    provenance: 'VERIFIED'
  },
  {
    id: 'chocolate_digestive',
    name: 'THE CHOCOLATE DIGESTIVE',
    category: 'CHOCOLATE',
    tagline: 'Yorkshire chocolate whey, wholemeal digestive crumbs, dark cocoa & Maldon sea salt.',
    description: 'Nostalgic British tea-time biscuit in liquid protein form. Rich roasted cocoa balanced with salty malt biscuit crunch.',
    formulation_input: {
      baseId: 'greek_yoghurt',
      liquidId: 'whole_milk',
      liquid_amount_ml: 200,
      proteinId: 'whey_chocolate_concentrate',
      protein_scoops: 1,
      biscuitId: 'digestive_biscuit',
      biscuit_amount_g: 15,
      flavourIds: [{ id: 'cocoa_powder_dutch', amount_g: 8 }],
      strangeIds: [{ id: 'sea_salt_flakes', amount_g: 1 }],
      ice_cubes: 4
    },
    method: [
      'Pour 200ml British Whole Milk and 150g Greek Yoghurt into blender container.',
      'Add 1 scoop Yorkshire Chocolate Whey Concentrate and 8g Organic Cocoa Powder.',
      'Crumble in 15g Wholemeal Digestive Biscuit and 1 pinch (1g) Maldon Sea Salt Flakes.',
      'Add 4 ice cubes and blend on HIGH speed for 30 seconds until rich, thick and malty.'
    ],
    prep_time_mins: 2,
    provenance: 'VERIFIED'
  },
  {
    id: 'blackcurrant_fool',
    name: 'THE BLACKCURRANT FOOL',
    category: 'BRITISH CLASSICS',
    tagline: 'Deep purple Herefordshire blackcurrant compote whipped with fat-free Skyr & vanilla.',
    description: 'Intense berry acidity softened by thick Icelandic-style Skyr. Delivering 38g of clean protein per glass.',
    formulation_input: {
      baseId: 'skyr_yoghurt',
      liquidId: 'whole_milk',
      liquid_amount_ml: 180,
      proteinId: 'whey_vanilla_isolate',
      protein_scoops: 1,
      fruitIds: [{ id: 'blackcurrant_compote', amount_g: 60 }],
      ice_cubes: 4
    },
    method: [
      'Combine Skyr, whole milk, vanilla whey isolate and blackcurrant compote.',
      'Blend for 25 seconds until vivid purple foam forms.',
      'Garnish with fresh blackcurrants or mint.'
    ],
    prep_time_mins: 2,
    seasonal_best: 'summer',
    provenance: 'VERIFIED'
  },
  {
    id: 'earl_grey_protein',
    name: 'THE EARL GREY PROTEIN',
    category: 'TEA',
    tagline: 'Cold-extracted Earl Grey tea, bergamot oil, vanilla whey & wholemeal oat biscuit.',
    description: 'An elegant afternoon tea experience. Floral citrus bergamot notes paired with soothing vanilla protein body.',
    formulation_input: {
      liquidId: 'oat_milk',
      liquid_amount_ml: 220,
      proteinId: 'whey_vanilla_isolate',
      protein_scoops: 1,
      flavourIds: [{ id: 'earl_grey_infusion', amount_g: 30 }],
      biscuitId: 'digestive_biscuit',
      biscuit_amount_g: 10,
      ice_cubes: 4
    },
    method: [
      'Pour oat milk and Earl Grey tea concentrate into blender.',
      'Add vanilla isolate and digestive biscuit crumbs.',
      'Blend on LOW speed for 20 seconds to preserve delicate bergamot aromatics.'
    ],
    prep_time_mins: 2,
    provenance: 'VERIFIED'
  },
  {
    id: 'lemon_curd_builder',
    name: 'THE LEMON CURD BUILDER',
    category: 'DESSERT',
    tagline: 'Highland lemon curd, zesty citrus, thick Greek yoghurt & vanilla isolate.',
    description: 'Sweet, tart, buttery lemon pie in a cup. High protein with an energizing lemon kick.',
    formulation_input: {
      baseId: 'greek_yoghurt',
      liquidId: 'almond_milk',
      liquid_amount_ml: 200,
      proteinId: 'whey_vanilla_isolate',
      protein_scoops: 1,
      flavourIds: [{ id: 'lemon_curd', amount_g: 25 }],
      ice_cubes: 4
    },
    method: [
      'Blend almond milk, Greek yoghurt, vanilla whey isolate and Highland lemon curd with ice.',
      'Blend on HIGH for 30 seconds for a silky mousse-like pour.'
    ],
    prep_time_mins: 2,
    provenance: 'VERIFIED'
  },
  {
    id: 'apple_crumble',
    name: 'THE APPLE CRUMBLE',
    category: 'SEASONAL',
    tagline: 'Spiced Bramley apple compote, digestive crumble, cinnamon & vanilla protein.',
    description: 'Autumnal comfort in a glass. Warming cinnamon and tart Bramley apple notes with biscuit crumble crunch.',
    formulation_input: {
      baseId: 'greek_yoghurt',
      liquidId: 'oat_milk',
      liquid_amount_ml: 200,
      proteinId: 'whey_vanilla_isolate',
      protein_scoops: 1,
      fruitIds: [{ id: 'bramley_apple', amount_g: 80 }],
      biscuitId: 'digestive_biscuit',
      biscuit_amount_g: 15,
      ice_cubes: 4
    },
    method: [
      'Add oat milk, Greek yoghurt, vanilla whey, Bramley apple puree and digestive biscuit.',
      'Blend on MEDIUM speed for 30 seconds.'
    ],
    prep_time_mins: 3,
    seasonal_best: 'autumn',
    provenance: 'VERIFIED'
  },
  {
    id: 'british_breakfast',
    name: 'THE BRITISH BREAKFAST',
    category: 'BREAKFAST',
    tagline: 'Scottish oats, plant protein blend, banana, malted barley extract & oat milk.',
    description: 'A complete slow-release breakfast fuel. Packed with complex carbs, fibre, malt and plant protein.',
    formulation_input: {
      liquidId: 'oat_milk',
      liquid_amount_ml: 250,
      proteinId: 'plant_pea_hemp_blend',
      protein_scoops: 1,
      fruitIds: [{ id: 'banana_ripe', amount_g: 100 }],
      flavourIds: [{ id: 'malt_extract', amount_g: 15 }],
      supplements: [{ supplementId: 'scottish_oat_powder', servings: 1 }],
      ice_cubes: 3
    },
    method: [
      'Combine oat milk, hemp & pea protein blend, ripe banana, malt extract and ultrafine oat powder.',
      'Blend on HIGH speed for 40 seconds until smooth and thick.'
    ],
    prep_time_mins: 3,
    provenance: 'VERIFIED'
  }
];

export function getRecipeById(id: string): Recipe | undefined {
  return RECIPE_CATALOGUE.find(r => r.id === id);
}
