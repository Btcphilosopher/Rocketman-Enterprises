// SHAKEHOUSE Optimisation Engine & Substitution Solver
import { FormulationInput, FormulationCalculated, GoalConstraint } from './types';
import { calculateFormulation } from './formulation-engine';

export function substituteIngredientInFormulation(
  currentInput: FormulationInput,
  substitutionType: 'PLANT_BASED' | 'LOWER_CALORIE' | 'HIGHER_PROTEIN' | 'CHEAPER' | 'LESS_SWEET' | 'THICKER'
): FormulationInput {
  const newInput: FormulationInput = JSON.parse(JSON.stringify(currentInput));

  switch (substitutionType) {
    case 'PLANT_BASED':
      // Swap milk to oat milk, whey to plant blend, greek yoghurt to skyr or omit
      newInput.liquidId = 'oat_milk';
      newInput.proteinId = 'plant_pea_hemp_blend';
      if (newInput.baseId === 'greek_yoghurt') {
        newInput.baseId = undefined; // plant based omit dairy base
      }
      break;

    case 'HIGHER_PROTEIN':
      // Increase protein scoops or swap to whey isolate / casein + add Greek Yoghurt
      newInput.protein_scoops = (newInput.protein_scoops || 1) + 0.5;
      if (!newInput.baseId) {
        newInput.baseId = 'skyr_yoghurt';
      }
      break;

    case 'LOWER_CALORIE':
      // Swap liquid to almond milk or water, reduce fruit/biscuit portions
      newInput.liquidId = 'almond_milk';
      newInput.baseId = 'skyr_yoghurt'; // high protein, 0% fat
      if (newInput.biscuitId) {
        newInput.biscuit_amount_g = 8; // halve biscuit
      }
      break;

    case 'CHEAPER':
      // Swap whey isolate to whey concentrate, use oat milk
      newInput.proteinId = 'whey_chocolate_concentrate';
      newInput.liquidId = 'oat_milk';
      break;

    case 'LESS_SWEET':
      // Remove sweetener, add Maldon sea salt or lemon
      newInput.sweetenerId = undefined;
      newInput.sweetener_amount_g = 0;
      newInput.strangeIds = newInput.strangeIds || [];
      if (!newInput.strangeIds.some(s => s.id === 'sea_salt_flakes')) {
        newInput.strangeIds.push({ id: 'sea_salt_flakes', amount_g: 1 });
      }
      break;

    case 'THICKER':
      // Swap protein to casein or add Greek Yoghurt + banana / oats
      newInput.proteinId = 'micellar_casein_unflavoured';
      newInput.baseId = 'greek_yoghurt';
      break;
  }

  return newInput;
}

export function optimiseFormulationForGoal(
  initialInput: FormulationInput,
  goal: GoalConstraint
): { input: FormulationInput; calculated: FormulationCalculated } {
  let modifiedInput: FormulationInput = JSON.parse(JSON.stringify(initialInput));

  if (goal.target === 'HIGH_PROTEIN') {
    modifiedInput = substituteIngredientInFormulation(modifiedInput, 'HIGHER_PROTEIN');
  } else if (goal.target === 'LOWER_CALORIE') {
    modifiedInput = substituteIngredientInFormulation(modifiedInput, 'LOWER_CALORIE');
  } else if (goal.target === 'PLANT_BASED') {
    modifiedInput = substituteIngredientInFormulation(modifiedInput, 'PLANT_BASED');
  } else if (goal.target === 'BUDGET') {
    modifiedInput = substituteIngredientInFormulation(modifiedInput, 'CHEAPER');
  }

  const calculated = calculateFormulation(modifiedInput);
  return { input: modifiedInput, calculated };
}
