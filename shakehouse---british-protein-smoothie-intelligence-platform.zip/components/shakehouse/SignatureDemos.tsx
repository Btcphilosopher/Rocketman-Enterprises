'use client';

import React from 'react';
import { Sparkles, Zap, Wand2, RefreshCw } from 'lucide-react';
import { FormulationInput } from '@/lib/shakehouse/types';

interface SignatureDemosProps {
  onSelectDemo: (demoType: 'rhubarb_custard' | 'chocolate_digestive' | 'bertie_botts') => void;
  onTweak: (tweakType: 'PLANT_BASED' | 'HIGHER_PROTEIN' | 'LOWER_CALORIE' | 'CHEAPER' | 'LESS_SWEET' | 'THICKER') => void;
  activeDemo: string;
}

export const SignatureDemos: React.FC<SignatureDemosProps> = ({
  onSelectDemo,
  onTweak,
  activeDemo
}) => {
  return (
    <div className="w-full bg-[#0A3828] text-white p-6 rounded-2xl shadow-lg border border-[#0E1B2E]">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 border-b border-[#0A3828]/60 pb-4">
        <div>
          <span className="text-[10px] font-mono text-[#F3D068] bg-[#07291D] px-2.5 py-1 rounded-full uppercase tracking-widest font-semibold border border-[#F3D068]/30">
            SIGNATURE DEMONSTRATION SUITE
          </span>
          <h2 className="text-xl md:text-2xl font-serif font-bold text-[#FAF8F5] mt-1 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#F3D068]" />
            LABORATORY SIGNATURE VERTICAL SLICES
          </h2>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-[#E6D7C3]">
          <span className="w-2 h-2 rounded-full bg-[#2A9D8F] animate-pulse"></span>
          REAL-TIME DETERMINISTIC ENGINE ACTIVE
        </div>
      </div>

      {/* Signature Demo Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Demo 1: The Rhubarb Custard */}
        <button
          onClick={() => onSelectDemo('rhubarb_custard')}
          className={`p-4 rounded-xl text-left border transition-all cursor-pointer ${
            activeDemo === 'rhubarb_custard'
              ? 'bg-[#FAF8F5] text-[#0E1B2E] border-[#F3D068] ring-2 ring-[#F3D068] shadow-md'
              : 'bg-[#07291D] text-white border-[#155A42] hover:border-[#F3D068]'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#D64550]">
              DEMO 1
            </span>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#581825] text-white">
              38g PROTEIN
            </span>
          </div>
          <h3 className="font-serif font-bold text-lg leading-snug">
            THE RHUBARB CUSTARD
          </h3>
          <p className="text-xs opacity-80 mt-1 font-sans">
            Yorkshire forced rhubarb, Madagascar vanilla whey isolate, Greek yoghurt & oat milk.
          </p>
        </button>

        {/* Demo 2: The Chocolate Digestive */}
        <button
          onClick={() => onSelectDemo('chocolate_digestive')}
          className={`p-4 rounded-xl text-left border transition-all cursor-pointer ${
            activeDemo === 'chocolate_digestive'
              ? 'bg-[#FAF8F5] text-[#0E1B2E] border-[#F3D068] ring-2 ring-[#F3D068] shadow-md'
              : 'bg-[#07291D] text-white border-[#155A42] hover:border-[#F3D068]'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#F3D068]">
              DEMO 2
            </span>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#3D2314] text-white">
              35g PROTEIN
            </span>
          </div>
          <h3 className="font-serif font-bold text-lg leading-snug">
            THE CHOCOLATE DIGESTIVE
          </h3>
          <p className="text-xs opacity-80 mt-1 font-sans">
            Yorkshire chocolate whey, wholemeal digestive crumbs, raw cocoa & Maldon sea salt.
          </p>
        </button>

        {/* Demo 3: Bertie Bott's Mode */}
        <button
          onClick={() => onSelectDemo('bertie_botts')}
          className={`p-4 rounded-xl text-left border transition-all cursor-pointer ${
            activeDemo === 'bertie_botts'
              ? 'bg-[#FAF8F5] text-[#0E1B2E] border-[#F3D068] ring-2 ring-[#F3D068] shadow-md'
              : 'bg-[#07291D] text-white border-[#155A42] hover:border-[#F3D068]'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] font-mono uppercase tracking-wider font-bold text-[#2A9D8F]">
              DEMO 3
            </span>
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-[#2A9D8F] text-white">
              EVERY SHAKE
            </span>
          </div>
          <h3 className="font-serif font-bold text-lg leading-snug">
            BERTIE BOTT'S MODE
          </h3>
          <p className="text-xs opacity-80 mt-1 font-sans">
            Playful British flavor lab generating strange-but-good experimental formulations.
          </p>
        </button>
      </div>

      {/* Quick Tweak Constraints Bar */}
      <div className="pt-2 border-t border-[#155A42] flex flex-wrap items-center gap-2">
        <span className="text-xs font-mono text-[#E6D7C3] mr-2 flex items-center gap-1 font-semibold">
          <Wand2 className="w-3.5 h-3.5 text-[#F3D068]" /> INSTANT RECALCULATION TWEAKS:
        </span>

        <button
          onClick={() => onTweak('PLANT_BASED')}
          className="px-3 py-1 bg-[#155A42] hover:bg-[#1C7355] text-white text-xs font-semibold rounded-lg border border-[#2A9D8F]/40 transition-colors cursor-pointer"
        >
          MAKE PLANT-BASED
        </button>

        <button
          onClick={() => onTweak('HIGHER_PROTEIN')}
          className="px-3 py-1 bg-[#155A42] hover:bg-[#1C7355] text-white text-xs font-semibold rounded-lg border border-[#2A9D8F]/40 transition-colors cursor-pointer"
        >
          MAKE HIGHER PROTEIN
        </button>

        <button
          onClick={() => onTweak('LOWER_CALORIE')}
          className="px-3 py-1 bg-[#155A42] hover:bg-[#1C7355] text-white text-xs font-semibold rounded-lg border border-[#2A9D8F]/40 transition-colors cursor-pointer"
        >
          MAKE LOWER CALORIE
        </button>

        <button
          onClick={() => onTweak('LESS_SWEET')}
          className="px-3 py-1 bg-[#155A42] hover:bg-[#1C7355] text-white text-xs font-semibold rounded-lg border border-[#2A9D8F]/40 transition-colors cursor-pointer"
        >
          LESS SWEET
        </button>

        <button
          onClick={() => onTweak('THICKER')}
          className="px-3 py-1 bg-[#155A42] hover:bg-[#1C7355] text-white text-xs font-semibold rounded-lg border border-[#2A9D8F]/40 transition-colors cursor-pointer"
        >
          MAKE THICKER
        </button>

        <button
          onClick={() => onTweak('CHEAPER')}
          className="px-3 py-1 bg-[#155A42] hover:bg-[#1C7355] text-white text-xs font-semibold rounded-lg border border-[#2A9D8F]/40 transition-colors cursor-pointer"
        >
          MAKE CHEAPER
        </button>
      </div>
    </div>
  );
};
