'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Plus, Minus, Info, Package, AlertCircle } from 'lucide-react';
import { SUPPLEMENT_DATABASE } from '@/lib/shakehouse/supplements-db';

export const SupplementCabinet: React.FC = () => {
  const [selectedServings, setSelectedServings] = useState<Record<string, number>>({
    creapure_creatine: 1,
    scottish_oat_powder: 1,
    electrolyte_hydration_citrus: 0,
    crunchy_peanut_butter: 1
  });

  const updateServings = (id: string, delta: number) => {
    setSelectedServings(prev => {
      const current = prev[id] || 0;
      const next = Math.max(0, current + delta);
      return { ...prev, [id]: next };
    });
  };

  // Stack totals
  let totalMass = 0;
  let totalCalories = 0;
  let totalProtein = 0;
  let totalCarbs = 0;
  let totalFat = 0;
  let totalFibre = 0;
  let totalCost = 0;

  SUPPLEMENT_DATABASE.forEach(sup => {
    const s = selectedServings[sup.id] || 0;
    if (s > 0) {
      totalMass += sup.serving_size_g * s;
      totalCalories += sup.calories_per_serving * s;
      totalProtein += sup.protein_per_serving * s;
      totalCarbs += sup.carbs_per_serving * s;
      totalFat += sup.fat_per_serving * s;
      totalFibre += sup.fibre_per_serving * s;
      totalCost += sup.cost_per_serving * s;
    }
  });

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 border-b border-[#E6D7C3] pb-4">
        <div>
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            PRODUCT CATALOGUE & STACK BUILDER
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#0E1B2E] mt-1">
            THE SUPPLEMENT CABINET ("MY STACK")
          </h2>
          <p className="text-xs text-[#0E1B2E]/70 mt-1 max-w-xl">
            Configure individual verified supplement products into your personal stack. Calculate exact mass, macros, fibre and serving cost.
          </p>
        </div>

        {/* Stack Summary Card */}
        <div className="bg-[#0E1B2E] text-white p-4 rounded-xl border border-[#0E1B2E] min-w-[280px]">
          <span className="text-[10px] font-mono text-[#F3D068] uppercase font-bold block mb-1">
            CURRENT STACK CALCULATED TOTALS
          </span>
          <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono my-2">
            <div>
              <span className="text-opacity-60 block text-[9px]">MASS</span>
              <span className="font-bold">{Math.round(totalMass)}g</span>
            </div>
            <div>
              <span className="text-opacity-60 block text-[9px]">PROTEIN</span>
              <span className="font-bold text-[#F3D068]">{Math.round(totalProtein * 10) / 10}g</span>
            </div>
            <div>
              <span className="text-opacity-60 block text-[9px]">CALORIES</span>
              <span className="font-bold">{Math.round(totalCalories)} kcal</span>
            </div>
          </div>
          <div className="pt-2 border-t border-white/20 flex justify-between items-center text-xs">
            <span className="text-opacity-80">STACK COST / SERVING:</span>
            <span className="font-bold font-mono text-[#F3D068]">£{Math.round(totalCost * 100) / 100}</span>
          </div>
        </div>
      </div>

      {/* Safety Notice */}
      <div className="mb-6 p-3 bg-[#EFE8DC] border border-[#D8CCB8] rounded-xl flex items-start gap-2.5 text-xs text-[#0E1B2E]">
        <Info className="w-4 h-4 text-[#0A3828] shrink-0 mt-0.5" />
        <div>
          <span className="font-bold font-mono block">SUPPLEMENT SAFETY ARCHITECTURE:</span>
          All supplement entries represent verified product specifications. SHAKEHOUSE is a formulation tool; no unsupported medical or performance claims are made.
        </div>
      </div>

      {/* Product List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {SUPPLEMENT_DATABASE.map((sup) => {
          const count = selectedServings[sup.id] || 0;
          return (
            <div
              key={sup.id}
              className={`p-4 rounded-xl border transition-all ${
                count > 0
                  ? 'bg-white border-[#0A3828] shadow-sm'
                  : 'bg-[#F5EFE6] border-[#E6D7C3] opacity-80'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <div>
                  <span className="text-[10px] font-mono text-[#0A3828] uppercase font-bold block">
                    {sup.brand}
                  </span>
                  <h4 className="font-serif font-bold text-sm text-[#0E1B2E]">
                    {sup.product}
                  </h4>
                </div>
                <span className="text-xs font-mono font-bold text-[#581825] bg-[#F5EFE6] px-2 py-0.5 rounded border border-[#E6D7C3]">
                  £{sup.cost_per_serving}/serv
                </span>
              </div>

              <p className="text-xs text-[#0E1B2E]/70 mb-3 italic">
                "{sup.flavour_note}"
              </p>

              {/* Macro breakdown per serving */}
              <div className="grid grid-cols-4 gap-1 text-center text-[10px] font-mono bg-[#FAF8F5] p-2 rounded-lg border border-[#E6D7C3] mb-3">
                <div>
                  <span className="text-opacity-60 block">SERVING</span>
                  <span className="font-bold text-[#0E1B2E]">{sup.serving_size_g}g</span>
                </div>
                <div>
                  <span className="text-opacity-60 block">PROT</span>
                  <span className="font-bold text-[#0A3828]">{sup.protein_per_serving}g</span>
                </div>
                <div>
                  <span className="text-opacity-60 block">KCAL</span>
                  <span className="font-bold text-[#0E1B2E]">{sup.calories_per_serving}</span>
                </div>
                <div>
                  <span className="text-opacity-60 block">FIBRE</span>
                  <span className="font-bold text-[#0E1B2E]">{sup.fibre_per_serving}g</span>
                </div>
              </div>

              {/* Servings Counter */}
              <div className="flex items-center justify-between border-t border-[#E6D7C3] pt-2">
                <span className="text-xs font-mono text-[#0E1B2E] font-semibold">
                  ADD TO STACK:
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => updateServings(sup.id, -1)}
                    disabled={count === 0}
                    className="w-7 h-7 rounded-lg bg-[#EFE8DC] hover:bg-[#E2D6C3] text-[#0E1B2E] flex items-center justify-center font-bold text-xs disabled:opacity-40 cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-6 text-center font-mono font-bold text-xs text-[#0E1B2E]">
                    {count}
                  </span>
                  <button
                    onClick={() => updateServings(sup.id, 1)}
                    className="w-7 h-7 rounded-lg bg-[#0A3828] hover:bg-[#07291D] text-white flex items-center justify-center font-bold text-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
