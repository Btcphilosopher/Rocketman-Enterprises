'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Send, Bot, ArrowRight, Loader2 } from 'lucide-react';
import { FormulationInput, FormulationCalculated } from '@/lib/shakehouse/types';

interface MakeMeAShakeAIProps {
  onLoadFormulation: (input: FormulationInput, title: string) => void;
}

const SAMPLE_PROMPTS = [
  'I want something like a chocolate orange but not too sweet, high protein and thick.',
  'Give me something extremely British, high-protein, creamy, not too sweet and slightly weird.',
  'An afternoon tea shake with Earl Grey, bergamot, vanilla protein and wholemeal biscuit.',
  'A refreshing summer berry shake with Scottish oats and fat-free Skyr.'
];

export const MakeMeAShakeAI: React.FC<MakeMeAShakeAIProps> = ({ onLoadFormulation }) => {
  const [prompt, setPrompt] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    shakeName: string;
    explanation: string;
    formulationInput: FormulationInput;
    calculated: FormulationCalculated;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (queryToUse?: string) => {
    const q = queryToUse || prompt;
    if (!q.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/gemini/shakehouse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: q })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'AI formulation request failed');
      }

      setResult(data);
    } catch (err: any) {
      setError(err.message || 'Something went wrong processing your request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2.5 bg-[#0E1B2E] text-[#F3D068] rounded-xl">
          <Bot className="w-6 h-6" />
        </div>
        <div>
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            NATURAL LANGUAGE FORMULATION ENGINE
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#0E1B2E]">
            "MAKE ME A SHAKE"
          </h2>
        </div>
      </div>

      <p className="text-xs text-[#0E1B2E]/80 mb-4 max-w-2xl">
        Describe your desired flavour, macro targets, texture or mood in plain English. Gemini AI will interpret your prompt and call our deterministic Python/TS formulation physics engine.
      </p>

      {/* Input Box */}
      <div className="relative mb-4">
        <textarea
          rows={3}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g., I want something like a chocolate orange but not too sweet, high protein and thick..."
          className="w-full bg-white border border-[#E6D7C3] rounded-xl p-4 pr-32 text-sm text-[#0E1B2E] placeholder-[#0E1B2E]/40 focus:outline-none focus:border-[#0A3828] shadow-inner"
        />

        <button
          onClick={() => handleGenerate()}
          disabled={loading || !prompt.trim()}
          className="absolute bottom-3 right-3 px-4 py-2.5 bg-[#0A3828] hover:bg-[#07291D] text-white text-xs font-bold rounded-lg shadow-md flex items-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-[#F3D068]" />
              <span>FORMULATING...</span>
            </>
          ) : (
            <>
              <Send className="w-3.5 h-3.5" />
              <span>FORMULATE</span>
            </>
          )}
        </button>
      </div>

      {/* Prompt Pills */}
      <div className="flex flex-wrap items-center gap-2 mb-6">
        <span className="text-xs font-mono text-[#0E1B2E]/60 font-semibold mr-1">
          SUGGESTED PROMPTS:
        </span>
        {SAMPLE_PROMPTS.map((p, idx) => (
          <button
            key={idx}
            onClick={() => {
              setPrompt(p);
              handleGenerate(p);
            }}
            className="text-xs bg-[#F5EFE6] hover:bg-[#EFE8DC] text-[#0E1B2E] px-3 py-1.5 rounded-lg border border-[#E6D7C3] transition-colors cursor-pointer text-left"
          >
            "{p}"
          </button>
        ))}
      </div>

      {/* Error Message */}
      {error && (
        <div className="mb-4 p-3 bg-[#581825]/10 border border-[#581825] text-[#581825] rounded-xl text-xs font-mono">
          {error}
        </div>
      )}

      {/* Generated Result Output */}
      {result && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white border-2 border-[#0A3828] rounded-xl p-5 shadow-md"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-[#E6D7C3] pb-3 mb-3">
            <div>
              <span className="text-[10px] font-mono text-[#2A9D8F] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase">
                FORMULATED BY GEMINI AI + SHAKEHOUSE ENGINE
              </span>
              <h3 className="text-xl font-serif font-bold text-[#0E1B2E] mt-1">
                {result.shakeName}
              </h3>
            </div>

            <button
              onClick={() => onLoadFormulation(result.formulationInput, result.shakeName)}
              className="px-4 py-2 bg-[#D64550] hover:bg-[#B8323C] text-white text-xs font-bold rounded-lg shadow-xs flex items-center gap-1.5 transition-all cursor-pointer self-start md:self-auto"
            >
              <span>LOAD INTO SHAKE BUILDER</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <p className="text-xs text-[#0E1B2E]/90 italic bg-[#FAF8F5] p-3 rounded-lg border border-[#E6D7C3] mb-4">
            "{result.explanation}"
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
            <div className="bg-[#F5EFE6] p-2.5 rounded-lg border border-[#E6D7C3]">
              <span className="text-[10px] font-mono text-[#0E1B2E]/60 block uppercase">PROTEIN</span>
              <span className="text-sm font-bold font-mono text-[#0A3828]">{result.calculated.protein_g}g</span>
            </div>
            <div className="bg-[#F5EFE6] p-2.5 rounded-lg border border-[#E6D7C3]">
              <span className="text-[10px] font-mono text-[#0E1B2E]/60 block uppercase">CALORIES</span>
              <span className="text-sm font-bold font-mono text-[#0E1B2E]">{result.calculated.calories} kcal</span>
            </div>
            <div className="bg-[#F5EFE6] p-2.5 rounded-lg border border-[#E6D7C3]">
              <span className="text-[10px] font-mono text-[#0E1B2E]/60 block uppercase">VOLUME</span>
              <span className="text-sm font-bold font-mono text-[#0E1B2E]">{result.calculated.estimated_volume_ml} ml</span>
            </div>
            <div className="bg-[#F5EFE6] p-2.5 rounded-lg border border-[#E6D7C3]">
              <span className="text-[10px] font-mono text-[#0E1B2E]/60 block uppercase">COST</span>
              <span className="text-sm font-bold font-mono text-[#581825]">£{result.calculated.cost_gbp}</span>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
