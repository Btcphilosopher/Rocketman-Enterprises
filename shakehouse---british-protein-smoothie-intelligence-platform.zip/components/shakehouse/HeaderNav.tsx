'use client';

import React from 'react';
import { motion } from 'motion/react';
import {
  FlaskConical,
  Dices,
  Bot,
  Utensils,
  BookOpen,
  Package,
  Sliders,
  Database,
  Code2,
  Sparkles
} from 'lucide-react';

interface HeaderNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onOpenEmbed: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  activeTab,
  onTabChange,
  onOpenEmbed
}) => {
  const tabs = [
    { id: 'builder', label: 'SHAKE BUILDER', icon: FlaskConical },
    { id: 'bertie', label: 'BERTIE BOTT\'S', icon: Dices },
    { id: 'ai_nl', label: 'MAKE ME A SHAKE', icon: Bot },
    { id: 'kitchen', label: 'MY KITCHEN', icon: Utensils },
    { id: 'recipes', label: 'RECIPE BOOK', icon: BookOpen },
    { id: 'cabinet', label: 'THE CABINET', icon: Package },
    { id: 'profile', label: 'SHAKE PROFILE', icon: Sliders },
    { id: 'admin', label: 'ADMIN & R LAB', icon: Database }
  ];

  return (
    <header className="w-full bg-[#0E1B2E] text-white border-b-4 border-[#0A3828] sticky top-0 z-40 shadow-md">
      {/* Top Brand Banner */}
      <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#FAF8F5] text-[#0E1B2E] rounded-xl border border-[#F3D068]">
            <FlaskConical className="w-6 h-6 text-[#0A3828]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-serif font-black text-2xl tracking-tight text-[#FAF8F5]">
                SHAKEHOUSE
              </h1>
              <span className="text-[10px] font-mono text-[#F3D068] bg-[#07291D] px-2 py-0.5 rounded uppercase font-bold border border-[#F3D068]/30">
                BRITISH LAB
              </span>
            </div>
            <p className="text-[11px] font-mono text-[#E6D7C3] tracking-wide">
              BRITISH PROTEIN. UNEXPECTED FLAVOURS. FORMULATION ENGINE.
            </p>
          </div>
        </div>

        {/* Top Right Action Tools */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenEmbed}
            className="px-3 py-1.5 bg-[#07291D] hover:bg-[#0A3828] text-[#F3D068] text-xs font-mono font-bold rounded-lg border border-[#F3D068]/40 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>EMBED CODE</span>
          </button>
        </div>
      </div>

      {/* Navigation Mode Tabs */}
      <div className="max-w-7xl mx-auto px-4 overflow-x-auto scrollbar-none flex gap-1 pb-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`px-3.5 py-2 rounded-t-xl text-xs font-bold font-mono tracking-wider transition-all flex items-center gap-2 whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-[#FAF8F5] text-[#0E1B2E] shadow-inner'
                  : 'text-[#E6D7C3] hover:text-white hover:bg-white/10'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#0A3828]' : ''}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
};
