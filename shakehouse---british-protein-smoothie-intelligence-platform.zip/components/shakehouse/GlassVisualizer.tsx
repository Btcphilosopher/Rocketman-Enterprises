'use client';

import React from 'react';
import { motion } from 'motion/react';
import { FormulationCalculated } from '@/lib/shakehouse/types';

interface GlassVisualizerProps {
  calculated: FormulationCalculated;
  isBlending?: boolean;
  blendSpeed?: 'LOW' | 'MEDIUM' | 'HIGH';
  onTriggerBlend?: () => void;
}

export const GlassVisualizer: React.FC<GlassVisualizerProps> = ({
  calculated,
  isBlending = false,
  blendSpeed = 'MEDIUM',
  onTriggerBlend
}) => {
  // Map volume (300ml - 600ml) to fill percentage (35% - 88%)
  const fillPct = Math.min(88, Math.max(35, Math.round(((calculated.estimated_volume_ml - 200) / 450) * 53 + 35)));
  const colorHex = calculated.visual_color_hex || '#E63946';

  // Foam height based on foaming texture
  const foamHeight = Math.min(24, Math.max(6, Math.round(calculated.texture.foaming * 0.25)));

  return (
    <div className="relative w-full flex flex-col items-center justify-center p-6 bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl shadow-sm">
      {/* Top Laboratory Tag */}
      <div className="absolute top-4 left-4 flex items-center gap-2 text-xs font-mono tracking-wider text-[#0A3828] bg-[#EFE8DC] px-2.5 py-1 rounded-full border border-[#D8CCB8]">
        <span className="w-2 h-2 rounded-full bg-[#0A3828] animate-pulse"></span>
        FLUID LAB GLASS • {calculated.estimated_volume_ml} ML
      </div>

      {/* Glass Rendering */}
      <div className="relative w-56 h-80 my-4 flex items-end justify-center">
        {/* Outer Glass Rim & Shadow */}
        <div className="absolute inset-0 border-4 border-[#0E1B2E]/20 border-t-2 rounded-b-3xl rounded-t-lg bg-white/40 backdrop-blur-xs shadow-xl overflow-hidden flex items-end justify-center">
          {/* Glass Specular Highlights */}
          <div className="absolute top-0 left-3 w-3 h-full bg-white/40 rounded-full z-20 pointer-events-none transform -skew-x-3"></div>
          <div className="absolute top-0 right-3 w-1.5 h-full bg-white/20 rounded-full z-20 pointer-events-none"></div>

          {/* Liquid Fill Level Container */}
          <motion.div
            className="relative w-full rounded-b-2xl overflow-hidden transition-all duration-700 ease-out"
            style={{ height: `${fillPct}%` }}
            animate={{
              scaleY: isBlending ? [1, 1.05, 0.98, 1] : 1,
            }}
            transition={{
              repeat: isBlending ? Infinity : 0,
              duration: blendSpeed === 'HIGH' ? 0.3 : 0.6
            }}
          >
            {/* Main Fluid Body Gradient */}
            <div
              className="absolute inset-0 w-full h-full transition-colors duration-500"
              style={{
                background: `linear-gradient(180deg, ${colorHex}DD 0%, ${colorHex} 70%, #0E1B2E33 100%)`
              }}
            ></div>

            {/* Blending Vortex Effect */}
            {isBlending && (
              <motion.div
                className="absolute inset-0 bg-white/20 backdrop-blur-xs"
                animate={{ rotate: [0, 360] }}
                transition={{ repeat: Infinity, duration: blendSpeed === 'HIGH' ? 0.4 : 0.8, ease: 'linear' }}
              >
                <div className="w-full h-full border-t-4 border-dashed border-white/60 rounded-full"></div>
              </motion.div>
            )}

            {/* Foaming Top Layer */}
            <div
              className="absolute top-0 left-0 right-0 bg-white/80 backdrop-blur-xs border-b border-white/50 transition-all duration-500 flex items-center justify-center overflow-hidden"
              style={{ height: `${foamHeight}px` }}
            >
              <div className="w-full h-full opacity-60 bg-[radial-gradient(#000_1px,transparent_1px)] [background-size:6px_6px]"></div>
            </div>

            {/* Floating Ice Cubes */}
            <motion.div
              className="absolute top-4 left-6 w-8 h-8 bg-white/40 border border-white/70 rounded-md backdrop-blur-xs shadow-xs"
              animate={{ y: isBlending ? [-4, 4, -4] : [-2, 2, -2], rotate: [0, 15, -15, 0] }}
              transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
            ></motion.div>
            <motion.div
              className="absolute top-6 right-8 w-7 h-7 bg-white/35 border border-white/60 rounded-md backdrop-blur-xs shadow-xs"
              animate={{ y: isBlending ? [3, -3, 3] : [2, -2, 2], rotate: [0, -20, 20, 0] }}
              transition={{ repeat: Infinity, duration: 2.5, ease: 'easeInOut', delay: 0.3 }}
            ></motion.div>

            {/* Biscuit particles / fruit flecks */}
            <div className="absolute bottom-4 left-10 w-2 h-2 rounded-full bg-[#3D2314]/40"></div>
            <div className="absolute bottom-8 right-12 w-1.5 h-1.5 rounded-full bg-[#3D2314]/30"></div>
            <div className="absolute bottom-12 left-16 w-2 h-2 rounded-full bg-white/50"></div>
          </motion.div>
        </div>

        {/* Straw */}
        <div className="absolute -top-12 right-12 w-3 h-96 bg-gradient-to-r from-[#D64550] via-[#FAF8F5] to-[#D64550] border border-[#581825]/30 rounded-full transform rotate-12 z-10 shadow-md"></div>
      </div>

      {/* Glass Base Label */}
      <div className="mt-2 text-center">
        <h4 className="text-sm font-bold font-serif tracking-wide text-[#0E1B2E]">
          {calculated.title}
        </h4>
        <p className="text-xs text-[#581825] font-mono mt-0.5">
          VISCOSITY: {calculated.texture.viscosity}/100 • CREAMINESS: {calculated.texture.creaminess}/100
        </p>
      </div>

      {/* Blend Trigger Button */}
      {onTriggerBlend && (
        <button
          onClick={onTriggerBlend}
          className="mt-3 px-4 py-1.5 bg-[#0A3828] hover:bg-[#07291D] text-white text-xs font-semibold rounded-lg shadow-xs flex items-center gap-2 transition-all cursor-pointer"
        >
          <span className="w-2 h-2 rounded-full bg-[#F3D068]"></span>
          {isBlending ? 'EMULSIFYING IN LAB...' : 'RUN BLENDER SIMULATION'}
        </button>
      )}
    </div>
  );
};
