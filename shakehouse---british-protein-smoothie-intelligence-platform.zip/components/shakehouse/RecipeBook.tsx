'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { BookOpen, Search, ArrowRight, ShieldAlert, Sparkles } from 'lucide-react';
import { RECIPE_CATALOGUE } from '@/lib/shakehouse/recipes-db';
import { calculateFormulation } from '@/lib/shakehouse/formulation-engine';
import { FormulationInput } from '@/lib/shakehouse/types';

interface RecipeBookProps {
  onLoadRecipe: (input: FormulationInput, title: string) => void;
}

const CATEGORIES = ['ALL', 'BRITISH CLASSICS', 'CHOCOLATE', 'TEA', 'DESSERT', 'BREAKFAST', 'SEASONAL'] as const;

export const RecipeBook: React.FC<RecipeBookProps> = ({ onLoadRecipe }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredRecipes = RECIPE_CATALOGUE.filter(recipe => {
    const matchesCat = selectedCategory === 'ALL' || recipe.category === selectedCategory;
    const matchesQuery = recipe.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         recipe.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 border-b border-[#E6D7C3] pb-4">
        <div>
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            BRITISH SMOOTHIE ARCHIVE
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#0E1B2E] mt-1">
            SHAKEHOUSE RECIPE BOOK
          </h2>
          <p className="text-xs text-[#0E1B2E]/70 mt-1 max-w-xl">
            Explore curated British formulations with transparent nutrition, UK traffic-light macro badges, and allergen metadata.
          </p>
        </div>

        {/* Search Input */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-[#0E1B2E]/40" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search British recipes..."
            className="w-full bg-white border border-[#E6D7C3] pl-9 pr-3 py-2 text-xs text-[#0E1B2E] rounded-xl focus:outline-none focus:border-[#0A3828]"
          />
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {CATEGORIES.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold font-mono transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-[#0E1B2E] text-white shadow-xs'
                : 'bg-[#F5EFE6] text-[#0E1B2E] hover:bg-[#EFE8DC] border border-[#E6D7C3]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid of Recipe Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRecipes.map((recipe) => {
          const calc = calculateFormulation(recipe.formulation_input, recipe.name);
          return (
            <div
              key={recipe.id}
              className="bg-white border-2 border-[#0E1B2E] rounded-2xl p-5 shadow-sm flex flex-col justify-between hover:shadow-md transition-all relative overflow-hidden"
            >
              {/* Product Card Top Header */}
              <div>
                <div className="flex items-center justify-between border-b border-[#0E1B2E]/10 pb-3 mb-3">
                  <span className="text-[10px] font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase">
                    {recipe.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-[#581825]">
                    £{calc.cost_gbp}
                  </span>
                </div>

                <h3 className="font-serif font-bold text-xl text-[#0E1B2E] leading-tight">
                  {recipe.name}
                </h3>

                <p className="text-xs text-[#581825] font-semibold mt-1 italic">
                  "{recipe.tagline}"
                </p>

                <p className="text-xs text-[#0E1B2E]/70 mt-2 line-clamp-2">
                  {recipe.description}
                </p>

                {/* Physical Product-Style Metric Grid */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs font-mono bg-[#FAF8F5] p-3 rounded-xl border border-[#E6D7C3] my-4">
                  <div className="bg-white p-1.5 rounded border border-[#E6D7C3]">
                    <span className="text-[9px] text-[#0E1B2E]/60 block">PROTEIN</span>
                    <span className="font-bold text-[#0A3828]">{calc.protein_g}g</span>
                  </div>
                  <div className="bg-white p-1.5 rounded border border-[#E6D7C3]">
                    <span className="text-[9px] text-[#0E1B2E]/60 block">ENERGY</span>
                    <span className="font-bold text-[#0E1B2E]">{calc.calories} kcal</span>
                  </div>
                  <div className="bg-white p-1.5 rounded border border-[#E6D7C3]">
                    <span className="text-[9px] text-[#0E1B2E]/60 block">VOLUME</span>
                    <span className="font-bold text-[#0E1B2E]">{calc.estimated_volume_ml}ml</span>
                  </div>
                </div>

                {/* Allergen Flag */}
                {calc.allergens.contains.length > 0 && (
                  <div className="text-[10px] font-mono text-[#581825] bg-[#581825]/10 p-2 rounded-lg border border-[#581825]/30 flex items-center gap-1.5 mb-4">
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                    <span>CONTAINS: {calc.allergens.contains.join(', ').toUpperCase()}</span>
                  </div>
                )}
              </div>

              {/* Action Button */}
              <button
                onClick={() => onLoadRecipe(recipe.formulation_input, recipe.name)}
                className="w-full py-2.5 bg-[#0A3828] hover:bg-[#07291D] text-white text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <span>MAKE THIS IN BUILDER</span>
                <ArrowRight className="w-4 h-4 text-[#F3D068]" />
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};
