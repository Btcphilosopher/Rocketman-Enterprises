'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Play, RotateCcw, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BlenderSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  shakeTitle: string;
  onSpeedChange: (speed: 'LOW' | 'MEDIUM' | 'HIGH') => void;
  currentSpeed: 'LOW' | 'MEDIUM' | 'HIGH';
}

const STAGES = [
  { id: 1, name: 'INGREDIENTS', desc: 'Loading raw liquids, protein powders, British berries & ice cubes into vessel.' },
  { id: 2, name: 'BLEND', desc: 'Engaging high-torque motor blades. Pulverising whole oats & fruit skins.' },
  { id: 3, name: 'EMULSIFY', desc: 'Homogenising dairy lipids and whey proteins to form smooth micellar matrix.' },
  { id: 4, name: 'AERATE', desc: 'Incorporating micro-bubbles for velvety British high-street foam texture.' },
  { id: 5, name: 'SERVE', desc: 'Formulation ready for immediate tasting!' }
];

export const BlenderSimulatorModal: React.FC<BlenderSimulatorModalProps> = ({
  isOpen,
  onClose,
  shakeTitle,
  onSpeedChange,
  currentSpeed
}) => {
  const [activeStageIndex, setActiveStageIndex] = useState(0);
  const [isSimulating, setIsSimulating] = useState(false);

  const startSimulation = () => {
    setIsSimulating(true);
    setActiveStageIndex(0);
  };

  useEffect(() => {
    if (!isSimulating) return;

    if (activeStageIndex < STAGES.length - 1) {
      const timer = setTimeout(() => {
        setActiveStageIndex(prev => prev + 1);
      }, 1200);
      return () => clearTimeout(timer);
    } else {
      setIsSimulating(false);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
    }
  }, [isSimulating, activeStageIndex]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0E1B2E]/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-lg bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl shadow-2xl overflow-hidden p-6"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#0E1B2E] hover:bg-[#EFE8DC] rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-4 border-b border-[#E6D7C3] pb-3">
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-1 rounded-full uppercase tracking-wider">
            BLENDER SIMULATION ENGINE
          </span>
          <h3 className="text-xl font-bold font-serif text-[#0E1B2E] mt-2">
            {shakeTitle}
          </h3>
        </div>

        {/* Speed Selection */}
        <div className="mb-6 bg-[#F5EFE6] p-3 rounded-xl border border-[#E6D7C3]">
          <label className="block text-xs font-mono text-[#0E1B2E] mb-2 uppercase font-semibold">
            Motor Speed Setting:
          </label>
          <div className="grid grid-cols-3 gap-2">
            {(['LOW', 'MEDIUM', 'HIGH'] as const).map((spd) => (
              <button
                key={spd}
                onClick={() => onSpeedChange(spd)}
                className={`py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                  currentSpeed === spd
                    ? 'bg-[#0A3828] text-white shadow-xs'
                    : 'bg-white text-[#0E1B2E] border border-[#E6D7C3] hover:bg-[#EFE8DC]'
                }`}
              >
                {spd} RPM
              </button>
            ))}
          </div>
        </div>

        {/* 5-Stage Stepper Display */}
        <div className="space-y-3 mb-6">
          {STAGES.map((stg, idx) => {
            const isDone = idx < activeStageIndex;
            const isCurrent = idx === activeStageIndex;
            return (
              <div
                key={stg.id}
                className={`p-3 rounded-xl border transition-all flex items-start gap-3 ${
                  isCurrent
                    ? 'bg-[#0A3828] text-white border-[#0A3828] shadow-sm'
                    : isDone
                    ? 'bg-[#EFE8DC] text-[#0E1B2E] border-[#D8CCB8]'
                    : 'bg-white text-[#0E1B2E]/60 border-[#E6D7C3]'
                }`}
              >
                <div className="mt-0.5">
                  {isDone ? (
                    <CheckCircle2 className="w-5 h-5 text-[#2A9D8F]" />
                  ) : isCurrent ? (
                    <span className="w-5 h-5 rounded-full border-2 border-[#F3D068] border-t-transparent animate-spin block"></span>
                  ) : (
                    <span className="w-5 h-5 rounded-full bg-[#E6D7C3] text-xs font-mono flex items-center justify-center font-bold text-[#0E1B2E]">
                      {stg.id}
                    </span>
                  )}
                </div>
                <div>
                  <h5 className={`text-xs font-bold font-mono tracking-wider ${isCurrent ? 'text-[#F3D068]' : ''}`}>
                    STAGE {stg.id}: {stg.name}
                  </h5>
                  <p className="text-xs opacity-90 mt-0.5">{stg.desc}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Action Controls */}
        <div className="flex gap-3">
          <button
            onClick={startSimulation}
            disabled={isSimulating}
            className="flex-1 py-2.5 bg-[#D64550] hover:bg-[#B8323C] text-white text-xs font-bold rounded-xl shadow-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
          >
            {isSimulating ? (
              <span>BLENDING ({STAGES[activeStageIndex].name})...</span>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>START BLENDER PROCESS</span>
              </>
            )}
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-[#EFE8DC] hover:bg-[#E2D6C3] text-[#0E1B2E] text-xs font-bold rounded-xl transition-all cursor-pointer"
          >
            CLOSE
          </button>
        </div>
      </motion.div>
    </div>
  );
};
