'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Utensils, Check, ArrowRight, Sparkles } from 'lucide-react';
import { INGREDIENT_DATABASE } from '@/lib/shakehouse/ingredients-db';
import { solveKitchenIngredients, KitchenMatchResult } from '@/lib/shakehouse/kitchen-solver';
import { FormulationInput } from '@/lib/shakehouse/types';

interface WhatsInMyKitchenProps {
  onLoadFormulation: (input: FormulationInput, title: string) => void;
}

const COMMON_KITCHEN_ITEMS = [
  { id: 'whole_milk', label: 'British Whole Milk' },
  { id: 'oat_milk', label: 'British Oat Milk' },
  { id: 'greek_yoghurt', label: 'Greek Yoghurt' },
  { id: 'whey_vanilla_isolate', label: 'Madagascar Vanilla Whey' },
  { id: 'whey_chocolate_concentrate', label: 'Yorkshire Chocolate Whey' },
  { id: 'rhubarb_stewed', label: 'Yorkshire Rhubarb' },
  { id: 'banana_ripe', label: 'Ripe Banana' },
  { id: 'digestive_biscuit', label: 'Digestive Biscuits' },
  { id: 'cocoa_powder_dutch', label: 'Cocoa Powder' },
  { id: 'sea_salt_flakes', label: 'Maldon Sea Salt' }
];

export const WhatsInMyKitchen: React.FC<WhatsInMyKitchenProps> = ({ onLoadFormulation }) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([
    'oat_milk',
    'whey_vanilla_isolate',
    'rhubarb_stewed',
    'digestive_biscuit'
  ]);

  const matches = solveKitchenIngredients(selectedIds);

  const toggleSelect = (id: string) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2.5 bg-[#0A3828] text-[#F3D068] rounded-xl">
          <Utensils className="w-6 h-6" />
        </div>
        <div>
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            INVENTORY SOLVER
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#0E1B2E]">
            "WHAT'S IN MY KITCHEN?"
          </h2>
        </div>
      </div>

      <p className="text-xs text-[#0E1B2E]/80 mb-4 max-w-2xl">
        Select the ingredients you currently have on hand. SHAKEHOUSE will generate candidate formulations ranked by ingredient utilisation, flavour match score and nutritional completeness.
      </p>

      {/* Ingredient Checkboxes */}
      <div className="flex flex-wrap gap-2 mb-6">
        {COMMON_KITCHEN_ITEMS.map((item) => {
          const isSelected = selectedIds.includes(item.id);
          return (
            <button
              key={item.id}
              onClick={() => toggleSelect(item.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold border transition-all flex items-center gap-2 cursor-pointer ${
                isSelected
                  ? 'bg-[#0A3828] text-white border-[#0A3828] shadow-xs'
                  : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
              }`}
            >
              <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                isSelected ? 'bg-[#F3D068] border-[#F3D068] text-[#0E1B2E]' : 'border-[#E6D7C3]'
              }`}>
                {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
              </div>
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Matched Formulations */}
      <div className="space-y-4">
        <h3 className="text-xs font-mono font-bold text-[#0E1B2E] uppercase tracking-wider">
          TOP FEASIBLE KITCHEN FORMULATIONS ({matches.length}):
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {matches.map((match, idx) => (
            <div
              key={idx}
              className="bg-white border border-[#E6D7C3] rounded-xl p-4 shadow-xs flex flex-col justify-between hover:border-[#0A3828] transition-all"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="text-[10px] font-mono text-[#0A3828] bg-[#EFE8DC] px-2 py-0.5 rounded font-bold">
                    UTILISATION: {match.utilisationPct}%
                  </span>
                  <span className="text-xs font-mono font-bold text-[#581825]">
                    {match.calculated.protein_g}g Protein
                  </span>
                </div>

                <h4 className="font-serif font-bold text-base text-[#0E1B2E]">
                  {match.recipeName}
                </h4>

                <p className="text-xs text-[#0E1B2E]/70 mt-1">
                  {match.tagline}
                </p>

                <div className="mt-3 flex gap-2 text-[10px] font-mono text-[#0E1B2E]/60 bg-[#FAF8F5] p-2 rounded border border-[#E6D7C3]">
                  <span>{match.calculated.calories} kcal</span>
                  <span>•</span>
                  <span>{match.calculated.estimated_volume_ml} ml</span>
                  <span>•</span>
                  <span>£{match.calculated.cost_gbp}</span>
                </div>
              </div>

              <button
                onClick={() => onLoadFormulation(match.formulation_input, match.recipeName)}
                className="mt-4 w-full py-2 bg-[#0A3828] hover:bg-[#07291D] text-white text-xs font-bold rounded-lg shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <span>MAKE THIS SHAKE</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
