'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Dices, TestTube, CheckCircle2, Bookmark } from 'lucide-react';
import { BertieExperiment, generateBertieBottsExperiments } from '@/lib/shakehouse/flavour-compatibility';
import { FormulationInput } from '@/lib/shakehouse/types';

interface BertieBottsLabProps {
  onLoadExperiment: (input: FormulationInput, title: string) => void;
}

export const BertieBottsLab: React.FC<BertieBottsLabProps> = ({ onLoadExperiment }) => {
  const [experiments, setExperiments] = useState<BertieExperiment[]>(() => generateBertieBottsExperiments(6));
  const [savedIds, setSavedIds] = useState<string[]>([]);

  const handleRollExperiments = () => {
    setExperiments(generateBertieBottsExperiments(6));
  };

  const toggleSave = (id: string) => {
    setSavedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const getBadgeColor = (classif: string) => {
    switch (classif) {
      case 'SAFE BET': return 'bg-[#2A9D8F] text-white';
      case 'INTERESTING': return 'bg-[#0E1B2E] text-white';
      case 'ADVENTUROUS': return 'bg-[#D64550] text-white';
      case 'ODD': return 'bg-[#581825] text-white';
      case 'EXPERIMENTAL': return 'bg-[#F3D068] text-[#0E1B2E] font-bold';
      default: return 'bg-[#0A3828] text-white';
    }
  };

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 bg-[#0E1B2E] text-white p-6 rounded-xl">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xs font-mono text-[#F3D068] bg-[#07291D] px-3 py-1 rounded-full uppercase tracking-widest font-bold border border-[#F3D068]/40">
              BERTIE BOTT'S MODE • EVERY SHAKE
            </span>
            <TestTube className="w-4 h-4 text-[#F3D068] animate-bounce" />
          </div>
          <h2 className="text-2xl md:text-3xl font-serif font-bold text-[#FAF8F5]">
            BRITAIN'S STRANGEST FLAVOUR LAB
          </h2>
          <p className="text-xs text-[#E6D7C3] mt-1 max-w-xl">
            Surprising British combinations evaluated by our flavour matrix. Every experiment receives a novelty score and transparent flavour logic.
          </p>
        </div>

        <button
          onClick={handleRollExperiments}
          className="px-5 py-3 bg-[#D64550] hover:bg-[#B8323C] text-white text-xs font-bold rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer shrink-0"
        >
          <Dices className="w-4 h-4" />
          <span>SURPRISE ME (ROLL NEW SHAKES)</span>
        </button>
      </div>

      {/* Grid of Experiments */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {experiments.map((exp) => {
          const isSaved = savedIds.includes(exp.id);
          return (
            <motion.div
              key={exp.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border border-[#E6D7C3] rounded-xl p-5 shadow-xs flex flex-col justify-between hover:border-[#0A3828] transition-all"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full uppercase ${getBadgeColor(exp.classification)}`}>
                    {exp.classification}
                  </span>
                  <span className="text-xs font-mono text-[#0E1B2E] bg-[#F5EFE6] px-2 py-0.5 rounded border border-[#E6D7C3]">
                    NOVELTY: {exp.novelty_score}/100
                  </span>
                </div>

                <h3 className="font-serif font-bold text-lg text-[#0E1B2E] mt-1 leading-snug">
                  {exp.name}
                </h3>

                <p className="text-xs font-semibold text-[#581825] mt-1 italic">
                  "{exp.tagline}"
                </p>

                {/* Flavour Logic Explanation */}
                <div className="mt-3 bg-[#FAF8F5] p-3 rounded-lg border border-[#E6D7C3] text-xs text-[#0E1B2E]/80 leading-relaxed font-sans">
                  <span className="font-mono font-bold text-[#0A3828] block mb-1">
                    FLAVOUR LOGIC ANALYSIS:
                  </span>
                  {exp.flavour_explanation}
                </div>
              </div>

              {/* Actions */}
              <div className="mt-4 pt-3 border-t border-[#E6D7C3] flex items-center gap-2">
                <button
                  onClick={() => onLoadExperiment(exp.formulation_input, exp.name)}
                  className="flex-1 py-2 bg-[#0A3828] hover:bg-[#07291D] text-white text-xs font-bold rounded-lg shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#F3D068]" />
                  <span>MAKE THIS IN BUILDER</span>
                </button>

                <button
                  onClick={() => toggleSave(exp.id)}
                  className={`p-2 rounded-lg border transition-all cursor-pointer ${
                    isSaved
                      ? 'bg-[#581825] text-white border-[#581825]'
                      : 'bg-[#F5EFE6] text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#EFE8DC]'
                  }`}
                  title={isSaved ? 'Saved to profile' : 'Save experiment'}
                >
                  <Bookmark className="w-4 h-4 fill-current" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
};
