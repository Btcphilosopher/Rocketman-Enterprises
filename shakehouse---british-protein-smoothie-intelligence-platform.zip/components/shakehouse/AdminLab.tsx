'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Database, LineChart, ShieldCheck, Activity, Terminal } from 'lucide-react';

export const AdminLab: React.FC = () => {
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/shakehouse?action=analytics')
      .then(res => res.json())
      .then(data => {
        setAnalytics(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      <div className="flex items-center gap-3 mb-6 border-b border-[#E6D7C3] pb-4">
        <div className="p-2.5 bg-[#0E1B2E] text-[#F3D068] rounded-xl">
          <Database className="w-6 h-6" />
        </div>
        <div>
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            LABORATORY CONTROL & DATA AUDIT
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#0E1B2E]">
            ADMINISTRATION & SYNTHETIC DATA LAB
          </h2>
        </div>
      </div>

      {/* Synthetic Dataset Overview Banner */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="bg-[#0E1B2E] text-white p-4 rounded-xl border border-[#0E1B2E]">
          <span className="text-[10px] font-mono text-[#F3D068] uppercase font-bold block">SYNTHETIC DATASET</span>
          <span className="text-2xl font-mono font-bold block my-1">100,000</span>
          <span className="text-[10px] text-[#E6D7C3]">PROVENANCE: SYNTHETIC</span>
        </div>

        <div className="bg-[#0A3828] text-white p-4 rounded-xl border border-[#0A3828]">
          <span className="text-[10px] font-mono text-[#F3D068] uppercase font-bold block">MEAN PROTEIN</span>
          <span className="text-2xl font-mono font-bold block my-1">34.2g</span>
          <span className="text-[10px] text-[#E6D7C3]">8.8g / 100 kcal</span>
        </div>

        <div className="bg-[#581825] text-white p-4 rounded-xl border border-[#581825]">
          <span className="text-[10px] font-mono text-[#F3D068] uppercase font-bold block">FLAVOUR CLUSTERS</span>
          <span className="text-2xl font-mono font-bold block my-1">8</span>
          <span className="text-[10px] text-[#E6D7C3]">COSINE SIMILARITY MATRIX</span>
        </div>

        <div className="bg-white text-[#0E1B2E] p-4 rounded-xl border border-[#E6D7C3]">
          <span className="text-[10px] font-mono text-[#0A3828] uppercase font-bold block">PROVENANCE STATUS</span>
          <span className="text-xl font-mono font-bold block my-1 text-[#2A9D8F]">VERIFIED / ESTIMATED</span>
          <span className="text-[10px] text-[#0E1B2E]/60">UK Regulated Allergen Flags</span>
        </div>
      </div>

      {/* shakehouseR Analytics Engine */}
      <div className="bg-white border-2 border-[#0E1B2E] rounded-xl p-5 shadow-sm mb-6">
        <div className="flex items-center gap-2 mb-4 border-b border-[#E6D7C3] pb-3">
          <Terminal className="w-5 h-5 text-[#0A3828]" />
          <h3 className="font-serif font-bold text-lg text-[#0E1B2E]">
            shakehouseR - R STATISTICAL ANALYSIS PACKAGE
          </h3>
        </div>

        {loading ? (
          <p className="text-xs font-mono text-[#0E1B2E]/60">Executing shakehouseR analysis functions...</p>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {analytics && ['r_recipe_analysis', 'r_flavour_analysis', 'r_nutrition_analysis', 'r_ab_test_analysis'].map((key) => {
              const item = analytics[key];
              if (!item) return null;
              return (
                <div key={key} className="bg-[#FAF8F5] p-4 rounded-xl border border-[#E6D7C3]">
                  <span className="text-xs font-mono font-bold text-[#0A3828] block mb-1">
                    {item.function_name}
                  </span>
                  <div className="text-[10px] font-mono text-[#0E1B2E]/60 mb-2">
                    EX_TIME: {item.execution_time_ms}ms • DATA_POINTS: {item.data_points_analyzed}
                  </div>
                  <ul className="space-y-1 text-xs text-[#0E1B2E]">
                    {item.insights.map((ins: string, idx: number) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-[#2A9D8F] font-bold">•</span>
                        <span>{ins}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
