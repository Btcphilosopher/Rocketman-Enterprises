'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Copy, Check, Code2 } from 'lucide-react';

interface EmbedModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EmbedModal: React.FC<EmbedModalProps> = ({ isOpen, onClose }) => {
  const [embedType, setEmbedType] = useState<'builder' | 'recipe' | 'mini' | 'recommender' | 'supplements'>('builder');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const snippets: Record<string, string> = {
    builder: `<div id="shakehouse-builder"></div>\n<script src="https://shakehouse.uk/embed/shakehouse.js"></script>\n<script>\n  SHAKEHOUSE.init('#shakehouse-builder', { mode: 'full-builder' });\n</script>`,
    recipe: `<div id="shakehouse-recipe"></div>\n<script src="https://shakehouse.uk/embed/shakehouse.js"></script>\n<script>\n  SHAKEHOUSE.init('#shakehouse-recipe', { mode: 'recipe-card', recipeId: 'rhubarb-custard' });\n</script>`,
    mini: `<div id="shakehouse-mini"></div>\n<script src="https://shakehouse.uk/embed/shakehouse.js"></script>\n<script>\n  SHAKEHOUSE.init('#shakehouse-mini', { mode: 'mini-builder' });\n</script>`,
    recommender: `<div id="shakehouse-recommender"></div>\n<script src="https://shakehouse.uk/embed/shakehouse.js"></script>\n<script>\n  SHAKEHOUSE.init('#shakehouse-recommender', { mode: 'personal-recommender' });\n</script>`,
    supplements: `<div id="shakehouse-supplements"></div>\n<script src="https://shakehouse.uk/embed/shakehouse.js"></script>\n<script>\n  SHAKEHOUSE.init('#shakehouse-supplements', { mode: 'supplement-stack' });\n</script>`
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(snippets[embedType]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0E1B2E]/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="relative w-full max-w-xl bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-2xl"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-[#0E1B2E] hover:bg-[#EFE8DC] rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <Code2 className="w-5 h-5 text-[#0A3828]" />
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase">
            WEBSITE EMBEDDABLE COMPONENTS
          </span>
        </div>

        <h3 className="text-xl font-serif font-bold text-[#0E1B2E] mb-2">
          EMBED SHAKEHOUSE ON YOUR WEBSITE
        </h3>

        <p className="text-xs text-[#0E1B2E]/70 mb-4">
          Integrate the complete formulation lab, recipe card, mini builder or supplement stack onto any host website with a simple script tag.
        </p>

        {/* Embed Mode Tabs */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2 mb-4">
          {[
            { id: 'builder', label: 'FULL BUILDER' },
            { id: 'recipe', label: 'RECIPE CARD' },
            { id: 'mini', label: 'MINI BUILDER' },
            { id: 'recommender', label: 'RECOMMENDER' },
            { id: 'supplements', label: 'SUPPLEMENT CABINET' }
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setEmbedType(item.id as any)}
              className={`py-2 px-3 text-xs font-mono font-bold rounded-lg border transition-all cursor-pointer ${
                embedType === item.id
                  ? 'bg-[#0A3828] text-white border-[#0A3828]'
                  : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* Code Box */}
        <div className="relative bg-[#0E1B2E] text-[#F3D068] p-4 rounded-xl font-mono text-xs overflow-x-auto mb-4 border border-[#0E1B2E]">
          <pre>{snippets[embedType]}</pre>
          <button
            onClick={handleCopy}
            className="absolute top-3 right-3 px-3 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-lg text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-[#2A9D8F]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'COPIED!' : 'COPY CODE'}</span>
          </button>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-[#EFE8DC] hover:bg-[#E2D6C3] text-[#0E1B2E] text-xs font-bold rounded-xl transition-all cursor-pointer"
        >
          DONE
        </button>
      </motion.div>
    </div>
  );
};
