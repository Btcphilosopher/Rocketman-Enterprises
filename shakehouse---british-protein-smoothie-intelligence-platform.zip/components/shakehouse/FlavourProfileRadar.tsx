'use client';

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sliders, Sparkles, Heart, Star, Check } from 'lucide-react';
import { RECIPE_CATALOGUE } from '@/lib/shakehouse/recipes-db';
import { FormulationInput } from '@/lib/shakehouse/types';

interface FlavourProfileRadarProps {
  onLoadFormulation: (input: FormulationInput, title: string) => void;
}

export const FlavourProfileRadar: React.FC<FlavourProfileRadarProps> = ({ onLoadFormulation }) => {
  const [prefs, setPrefs] = useState({
    sweetness: 65,
    creaminess: 80,
    fruitiness: 70,
    chocolate: 40,
    experimental: 75
  });

  const [ratings, setRatings] = useState<Record<string, number>>({
    rhubarb_custard: 5,
    chocolate_digestive: 4
  });

  const setRating = (id: string, score: number) => {
    setRatings(prev => ({ ...prev, [id]: score }));
  };

  return (
    <div className="w-full bg-[#FAF8F5] border border-[#E6D7C3] rounded-2xl p-6 shadow-sm">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 border-b border-[#E6D7C3] pb-4">
        <div>
          <span className="text-xs font-mono text-[#0A3828] bg-[#EFE8DC] px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            PERSONALIZATION & ML PREFERENCE MATRIX
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#0E1B2E] mt-1">
            YOUR SHAKE PROFILE
          </h2>
          <p className="text-xs text-[#0E1B2E]/70 mt-1 max-w-xl">
            Inferred culinary profile from your recipe saves, ratings and flavour slider preferences.
          </p>
        </div>

        <div className="bg-[#0E1B2E] text-[#F3D068] p-3 rounded-xl text-xs font-mono flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-[#F3D068]" />
          <span>EXPERIMENTAL READINESS: {prefs.experimental}%</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Preference Sliders */}
        <div className="bg-white p-5 rounded-xl border border-[#E6D7C3]">
          <h3 className="font-serif font-bold text-base text-[#0E1B2E] mb-4 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#0A3828]" />
            CULINARY PREFERENCE TARGETS
          </h3>

          <div className="space-y-4">
            {[
              { key: 'sweetness', label: 'PREFERRED SWEETNESS' },
              { key: 'creaminess', label: 'CREAMINESS & BODY' },
              { key: 'fruitiness', label: 'TART FRUITINESS' },
              { key: 'chocolate', label: 'DARK CHOCOLATE INTENSITY' },
              { key: 'experimental', label: 'EXPERIMENTAL READINESS' }
            ].map((item) => {
              const k = item.key as keyof typeof prefs;
              return (
                <div key={k}>
                  <div className="flex justify-between text-xs font-mono text-[#0E1B2E] mb-1">
                    <span>{item.label}</span>
                    <span className="font-bold text-[#0A3828]">{prefs[k]}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={prefs[k]}
                    onChange={(e) => setPrefs(prev => ({ ...prev, [k]: parseInt(e.target.value) }))}
                    className="w-full accent-[#0A3828] cursor-pointer"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {/* Saved Recipe Ratings */}
        <div className="bg-white p-5 rounded-xl border border-[#E6D7C3]">
          <h3 className="font-serif font-bold text-base text-[#0E1B2E] mb-4 flex items-center gap-2">
            <Star className="w-4 h-4 text-[#F3D068] fill-current" />
            YOUR RECIPE RATINGS & FEEDBACK
          </h3>

          <div className="space-y-3">
            {RECIPE_CATALOGUE.slice(0, 3).map((rec) => {
              const currentScore = ratings[rec.id] || 0;
              return (
                <div key={rec.id} className="p-3 bg-[#FAF8F5] rounded-lg border border-[#E6D7C3] flex items-center justify-between">
                  <div>
                    <h4 className="font-serif font-bold text-xs text-[#0E1B2E]">{rec.name}</h4>
                    <span className="text-[10px] font-mono text-[#0E1B2E]/60">{rec.category}</span>
                  </div>

                  <div className="flex items-center gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(rec.id, star)}
                        className="p-1 cursor-pointer transition-transform hover:scale-110"
                      >
                        <Star className={`w-4 h-4 ${star <= currentScore ? 'text-[#F3D068] fill-current' : 'text-[#E6D7C3]'}`} />
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
