'use client';

import React, { useState, useMemo } from 'react';
import { motion } from 'motion/react';
import {
  Sparkles,
  Plus,
  Minus,
  Check,
  ShieldAlert,
  Flame,
  Scale,
  PoundSterling,
  RotateCcw,
  Play,
  Heart,
  Bookmark
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { FormulationInput, FormulationCalculated } from '@/lib/shakehouse/types';
import { INGREDIENT_DATABASE } from '@/lib/shakehouse/ingredients-db';
import { PROTEIN_DATABASE } from '@/lib/shakehouse/proteins-db';
import { SUPPLEMENT_DATABASE } from '@/lib/shakehouse/supplements-db';
import { calculateFormulation } from '@/lib/shakehouse/formulation-engine';
import { GlassVisualizer } from './GlassVisualizer';

interface ShakeBuilderProps {
  currentInput: FormulationInput;
  customTitle?: string;
  onInputChange: (newInput: FormulationInput) => void;
  onOpenBlenderModal: () => void;
  blendSpeed: 'LOW' | 'MEDIUM' | 'HIGH';
}

export const ShakeBuilder: React.FC<ShakeBuilderProps> = ({
  currentInput,
  customTitle,
  onInputChange,
  onOpenBlenderModal,
  blendSpeed
}) => {
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Calculate live formulation on every change (<100ms)
  const calculated: FormulationCalculated = useMemo(() => {
    return calculateFormulation({ ...currentInput, blendSpeed }, customTitle);
  }, [currentInput, blendSpeed, customTitle]);

  const handleSelectBase = (id?: string) => {
    onInputChange({ ...currentInput, baseId: currentInput.baseId === id ? undefined : id });
  };

  const handleSelectLiquid = (id: string) => {
    onInputChange({ ...currentInput, liquidId: id });
  };

  const handleSelectProtein = (id: string) => {
    onInputChange({ ...currentInput, proteinId: id });
  };

  const handleToggleFruit = (id: string) => {
    const existing = currentInput.fruitIds || [];
    const exists = existing.some(f => f.id === id);
    let updated;
    if (exists) {
      updated = existing.filter(f => f.id !== id);
    } else {
      updated = [...existing, { id, amount_g: id === 'rhubarb_stewed' || id === 'bramley_apple' ? 80 : 100 }];
    }
    onInputChange({ ...currentInput, fruitIds: updated });
  };

  const handleToggleFlavour = (id: string) => {
    const existing = currentInput.flavourIds || [];
    const exists = existing.some(f => f.id === id);
    let updated;
    if (exists) {
      updated = existing.filter(f => f.id !== id);
    } else {
      updated = [...existing, { id, amount_g: id === 'custard_cream_base' ? 40 : 20 }];
    }
    onInputChange({ ...currentInput, flavourIds: updated });
  };

  const handleToggleBiscuit = (id: string) => {
    if (currentInput.biscuitId === id) {
      onInputChange({ ...currentInput, biscuitId: undefined, biscuit_amount_g: 0 });
    } else {
      onInputChange({ ...currentInput, biscuitId: id, biscuit_amount_g: 15 });
    }
  };

  const handleToggleStrange = (id: string) => {
    const existing = currentInput.strangeIds || [];
    const exists = existing.some(s => s.id === id);
    let updated;
    if (exists) {
      updated = existing.filter(s => s.id !== id);
    } else {
      updated = [...existing, { id, amount_g: id === 'sea_salt_flakes' || id === 'fresh_basil_leaves' ? 2 : 12 }];
    }
    onInputChange({ ...currentInput, strangeIds: updated });
  };

  const handleSaveRecipe = () => {
    confetti({ particleCount: 70, spread: 70, origin: { y: 0.6 } });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* Left Column: 6-Step Selection Interface */}
      <div className="lg:col-span-7 space-y-6">
        {/* Step 1: Base & Liquid */}
        <div className="bg-[#FAF8F5] border border-[#E6D7C3] p-5 rounded-2xl shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-[#0A3828] text-white text-xs font-mono font-bold flex items-center justify-center">
              1
            </span>
            <h3 className="font-serif font-bold text-lg text-[#0E1B2E]">
              CHOOSE YOUR LIQUID & BASE
            </h3>
          </div>

          {/* Liquid Selection */}
          <div className="mb-4">
            <label className="text-xs font-mono text-[#0E1B2E]/70 font-semibold block mb-2 uppercase">
              Liquid Base (200ml):
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { id: 'oat_milk', name: 'British Oat Milk' },
                { id: 'whole_milk', name: 'British Whole Milk' },
                { id: 'almond_milk', name: 'Almond Milk' }
              ].map(liq => (
                <button
                  key={liq.id}
                  onClick={() => handleSelectLiquid(liq.id)}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-left cursor-pointer ${
                    currentInput.liquidId === liq.id
                      ? 'bg-[#0A3828] text-white border-[#0A3828] shadow-xs'
                      : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
                  }`}
                >
                  {liq.name}
                </button>
              ))}
            </div>
          </div>

          {/* Cultured Base Selection */}
          <div>
            <label className="text-xs font-mono text-[#0E1B2E]/70 font-semibold block mb-2 uppercase">
              Cultured Yoghurt Base (Optional 150g):
            </label>
            <div className="grid grid-cols-2 gap-2">
              {[
                { id: 'greek_yoghurt', name: 'Strained Greek Yoghurt (Creamy)' },
                { id: 'skyr_yoghurt', name: 'Fat-Free Icelandic Skyr (High Protein)' }
              ].map(b => (
                <button
                  key={b.id}
                  onClick={() => handleSelectBase(b.id)}
                  className={`p-2.5 rounded-xl text-xs font-bold border transition-all text-left cursor-pointer ${
                    currentInput.baseId === b.id
                      ? 'bg-[#0E1B2E] text-[#F3D068] border-[#0E1B2E] shadow-xs'
                      : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
                  }`}
                >
                  {b.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Step 2: Protein Selection */}
        <div className="bg-[#FAF8F5] border border-[#E6D7C3] p-5 rounded-2xl shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-[#0A3828] text-white text-xs font-mono font-bold flex items-center justify-center">
              2
            </span>
            <h3 className="font-serif font-bold text-lg text-[#0E1B2E]">
              CHOOSE YOUR PROTEIN SPECIFICATION
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {PROTEIN_DATABASE.map(prot => {
              const isSelected = currentInput.proteinId === prot.id;
              return (
                <button
                  key={prot.id}
                  onClick={() => handleSelectProtein(prot.id)}
                  className={`p-3 rounded-xl text-left border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#0A3828] text-white border-[#0A3828] shadow-sm'
                      : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <span className="text-[10px] font-mono font-bold uppercase opacity-80">
                      {prot.protein_source.replace('_', ' ')}
                    </span>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${isSelected ? 'bg-[#F3D068] text-[#0E1B2E]' : 'bg-[#EFE8DC]'}`}>
                      {prot.protein_per_100g}g Prot/100g
                    </span>
                  </div>
                  <h4 className="font-serif font-bold text-xs mt-1 leading-snug">
                    {prot.name}
                  </h4>
                  <p className="text-[10px] opacity-75 mt-0.5 italic">
                    Flavour: {prot.flavour}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 3: British Fruits & Specialty Flavours */}
        <div className="bg-[#FAF8F5] border border-[#E6D7C3] p-5 rounded-2xl shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-[#0A3828] text-white text-xs font-mono font-bold flex items-center justify-center">
              3
            </span>
            <h3 className="font-serif font-bold text-lg text-[#0E1B2E]">
              BRITISH FRUITS & SPECIALTY FLAVOURS
            </h3>
          </div>

          {/* Fruits */}
          <div className="mb-4">
            <label className="text-xs font-mono text-[#0E1B2E]/70 font-semibold block mb-2 uppercase">
              British Fruit Additions:
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'rhubarb_stewed', name: 'Yorkshire Rhubarb' },
                { id: 'strawberries_british', name: 'Kent Strawberries' },
                { id: 'blackcurrant_compote', name: 'Blackcurrant Compote' },
                { id: 'gooseberry_purée', name: 'Gooseberry Elderflower' },
                { id: 'bramley_apple', name: 'Bramley Apple & Cinnamon' },
                { id: 'conference_pear', name: 'Conference Pear' },
                { id: 'banana_ripe', name: 'Ripe Banana' }
              ].map(f => {
                const isSelected = currentInput.fruitIds?.some(x => x.id === f.id);
                return (
                  <button
                    key={f.id}
                    onClick={() => handleToggleFruit(f.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#D64550] text-white border-[#D64550] shadow-xs'
                        : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
                    }`}
                  >
                    {f.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Specialty Flavours */}
          <div>
            <label className="text-xs font-mono text-[#0E1B2E]/70 font-semibold block mb-2 uppercase">
              Specialty British Confectionery & Tea Flavours:
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'custard_cream_base', name: 'Vanilla Custard' },
                { id: 'lemon_curd', name: 'Highland Lemon Curd' },
                { id: 'orange_marmalade', name: 'Dundee Orange Marmalade' },
                { id: 'malt_extract', name: 'Malted Barley Extract' },
                { id: 'earl_grey_infusion', name: 'Earl Grey & Bergamot' },
                { id: 'cocoa_powder_dutch', name: 'Raw Cocoa Powder' }
              ].map(fl => {
                const isSelected = currentInput.flavourIds?.some(x => x.id === fl.id);
                return (
                  <button
                    key={fl.id}
                    onClick={() => handleToggleFlavour(fl.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#581825] text-white border-[#581825] shadow-xs'
                        : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
                    }`}
                  >
                    {fl.name}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Step 4 & 5: Biscuit & Strange Additions */}
        <div className="bg-[#FAF8F5] border border-[#E6D7C3] p-5 rounded-2xl shadow-xs">
          <div className="flex items-center gap-2 mb-3">
            <span className="w-6 h-6 rounded-full bg-[#0A3828] text-white text-xs font-mono font-bold flex items-center justify-center">
              4 & 5
            </span>
            <h3 className="font-serif font-bold text-lg text-[#0E1B2E]">
              TEXTURE & BERTIE BOTT'S STRANGE ADDITIONS
            </h3>
          </div>

          {/* Biscuit */}
          <div className="mb-4">
            <label className="text-xs font-mono text-[#0E1B2E]/70 font-semibold block mb-2 uppercase">
              British Biscuit Texture Crumble:
            </label>
            <button
              onClick={() => handleToggleBiscuit('digestive_biscuit')}
              className={`px-3 py-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                currentInput.biscuitId === 'digestive_biscuit'
                  ? 'bg-[#3D2314] text-white border-[#3D2314]'
                  : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
              }`}
            >
              Crushed Wholemeal Digestive Biscuit (15g)
            </button>
          </div>

          {/* Strange Additions */}
          <div>
            <label className="text-xs font-mono text-[#0E1B2E]/70 font-semibold block mb-2 uppercase">
              Add Something Strange (Bertie Bott's Experiments):
            </label>
            <div className="flex flex-wrap gap-2">
              {[
                { id: 'stem_ginger_syrup', name: 'Diced Stem Ginger & Syrup' },
                { id: 'sea_salt_flakes', name: 'Maldon Sea Salt Flakes' },
                { id: 'fresh_basil_leaves', name: 'Fresh Garden Basil' }
              ].map(st => {
                const isSelected = currentInput.strangeIds?.some(x => x.id === st.id);
                return (
                  <button
                    key={st.id}
                    onClick={() => handleToggleStrange(st.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#0E1B2E] text-[#F3D068] border-[#0E1B2E] shadow-xs'
                        : 'bg-white text-[#0E1B2E] border-[#E6D7C3] hover:bg-[#F5EFE6]'
                    }`}
                  >
                    {st.name}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Right Column: Live Glass Visualizer & Real-Time Macro Facts */}
      <div className="lg:col-span-5 space-y-6">
        {/* Dynamic Glass Visualization */}
        <GlassVisualizer
          calculated={calculated}
          blendSpeed={blendSpeed}
          onTriggerBlend={onOpenBlenderModal}
        />

        {/* Live Nutrition Facts Panel (UK Traffic Light Style) */}
        <div className="bg-white border-2 border-[#0E1B2E] p-5 rounded-2xl shadow-md">
          <div className="flex items-center justify-between border-b-2 border-[#0E1B2E] pb-3 mb-4">
            <div>
              <span className="text-[10px] font-mono font-bold text-[#0A3828] bg-[#EFE8DC] px-2 py-0.5 rounded uppercase">
                UK REGULATED NUTRITION PANEL
              </span>
              <h3 className="font-serif font-black text-xl text-[#0E1B2E] mt-0.5">
                FORMULATION FACTS
              </h3>
            </div>
            <span className="text-xs font-mono font-bold text-[#581825] bg-[#FAF8F5] px-2.5 py-1 rounded border border-[#E6D7C3]">
              £{calculated.cost_gbp} / SHAKE
            </span>
          </div>

          {/* Main Macro Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center font-mono mb-4">
            <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6D7C3]">
              <span className="text-[9px] text-[#0E1B2E]/60 block uppercase font-bold">PROTEIN</span>
              <span className="text-base font-black text-[#0A3828]">{calculated.protein_g}g</span>
            </div>

            <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6D7C3]">
              <span className="text-[9px] text-[#0E1B2E]/60 block uppercase font-bold">CALORIES</span>
              <span className="text-base font-black text-[#0E1B2E]">{calculated.calories}</span>
            </div>

            <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6D7C3]">
              <span className="text-[9px] text-[#0E1B2E]/60 block uppercase font-bold">VOLUME</span>
              <span className="text-base font-black text-[#0E1B2E]">{calculated.estimated_volume_ml}ml</span>
            </div>

            <div className="bg-[#FAF8F5] p-2.5 rounded-xl border border-[#E6D7C3]">
              <span className="text-[9px] text-[#0E1B2E]/60 block uppercase font-bold">DENSITY</span>
              <span className="text-xs font-black text-[#581825] leading-snug">{calculated.protein_density_g_per_100kcal}g /100kcal</span>
            </div>
          </div>

          {/* Secondary Nutrition Table */}
          <div className="space-y-1.5 text-xs font-mono border-t border-b border-[#E6D7C3] py-3 mb-4">
            <div className="flex justify-between py-0.5">
              <span>Carbohydrates</span>
              <span className="font-bold">{calculated.carbs_g}g</span>
            </div>
            <div className="flex justify-between py-0.5 text-[#0E1B2E]/80 pl-3">
              <span>— of which sugars</span>
              <span className="font-bold">{calculated.sugar_g}g</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span>Fat</span>
              <span className="font-bold">{calculated.fat_g}g</span>
            </div>
            <div className="flex justify-between py-0.5 text-[#0E1B2E]/80 pl-3">
              <span>— of which saturates</span>
              <span className="font-bold">{calculated.sat_fat_g}g</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span>Dietary Fibre</span>
              <span className="font-bold">{calculated.fibre_g}g</span>
            </div>
            <div className="flex justify-between py-0.5">
              <span>Salt</span>
              <span className="font-bold">{calculated.salt_g}g</span>
            </div>
          </div>

          {/* Flavour Balance & Sweetness Gauges */}
          <div className="space-y-2 mb-4">
            <div>
              <div className="flex justify-between text-[10px] font-mono font-bold text-[#0E1B2E] mb-1">
                <span>SWEETNESS INDEX</span>
                <span>{calculated.sweetness_index}/100</span>
              </div>
              <div className="w-full h-2 bg-[#E6D7C3] rounded-full overflow-hidden">
                <div className="h-full bg-[#F3D068]" style={{ width: `${calculated.sweetness_index}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[10px] font-mono font-bold text-[#0E1B2E] mb-1">
                <span>ACIDITY INDEX</span>
                <span>{calculated.acidity_index}/100</span>
              </div>
              <div className="w-full h-2 bg-[#E6D7C3] rounded-full overflow-hidden">
                <div className="h-full bg-[#D64550]" style={{ width: `${calculated.acidity_index}%` }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[10px] font-mono font-bold text-[#0E1B2E] mb-1">
                <span>FLAVOUR BALANCE SCORE</span>
                <span>{calculated.balance_score}/100</span>
              </div>
              <div className="w-full h-2 bg-[#E6D7C3] rounded-full overflow-hidden">
                <div className="h-full bg-[#2A9D8F]" style={{ width: `${calculated.balance_score}%` }}></div>
              </div>
            </div>
          </div>

          {/* UK Allergen Profile Warnings */}
          <div className="p-3 bg-[#FAF8F5] border border-[#E6D7C3] rounded-xl text-xs font-mono">
            <span className="font-bold text-[#581825] flex items-center gap-1 mb-1">
              <ShieldAlert className="w-3.5 h-3.5" />
              UK REGULATED ALLERGEN PROFILE:
            </span>
            {calculated.allergens.contains.length > 0 ? (
              <p className="text-[#0E1B2E]">
                Contains: <strong className="uppercase font-bold">{calculated.allergens.contains.join(', ')}</strong>
              </p>
            ) : (
              <p className="text-[#2A9D8F] font-bold">No major allergens detected</p>
            )}
          </div>

          {/* Save / Export Action */}
          <button
            onClick={handleSaveRecipe}
            className="mt-4 w-full py-3 bg-[#0A3828] hover:bg-[#07291D] text-white text-xs font-bold rounded-xl shadow-md flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <Bookmark className="w-4 h-4 text-[#F3D068] fill-current" />
            <span>{savedSuccess ? 'RECIPE SAVED TO PROFILE!' : 'SAVE THIS SHAKE FORMULATION'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
