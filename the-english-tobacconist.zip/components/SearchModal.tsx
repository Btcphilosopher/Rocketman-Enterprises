'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Product, PRODUCTS } from '@/lib/products-data';
import { Search, X, Eye, Plus, Plane } from 'lucide-react';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectProduct,
  onAddToCart,
}) => {
  const [query, setQuery] = useState<string>('');

  if (!isOpen) return null;

  const results = PRODUCTS.filter((p) => {
    if (!query.trim()) return false;
    const q = query.toLowerCase();
    return (
      p.name.toLowerCase().includes(q) ||
      p.brand.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.country.toLowerCase().includes(q) ||
      p.format.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q)
    );
  });

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/80 backdrop-blur-sm p-4 pt-16 sm:pt-24">
      <div className="w-full max-w-3xl bg-[#12110E] border border-[#B69B6B]/50 p-6 shadow-2xl text-[#F1E9D8] rounded-sm space-y-6">
        {/* Search Header */}
        <div className="flex items-center justify-between border-b border-[#38332B] pb-4">
          <div className="flex items-center gap-2 flex-1 pr-4">
            <Search className="w-5 h-5 text-[#B69B6B]" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search catalogue by brand, format, leaf origin, or product SKU..."
              autoFocus
              className="w-full bg-transparent text-sm font-mono text-[#F1E9D8] placeholder-[#6E6659] focus:outline-none"
            />
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] rounded-sm"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto space-y-3 font-mono text-xs">
          {!query.trim() ? (
            <div className="text-center py-8 text-[#6E6659]">
              Type to search Cuban cigars, Virginia pipe flakes, accessories, or duty-free lines.
            </div>
          ) : results.length === 0 ? (
            <div className="text-center py-8 text-[#8C8270]">
              No items matching &quot;{query}&quot;. Try searching &quot;Churchill&quot;, &quot;Virginia&quot;, &quot;Humidor&quot;, or &quot;Duty Free&quot;.
            </div>
          ) : (
            results.map((product) => (
              <div
                key={product.id}
                className="bg-[#1C1A17] p-3 border border-[#38332B] hover:border-[#B69B6B] transition-colors rounded-sm flex items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="relative w-12 h-12 bg-[#12110E] border border-[#2A2722] overflow-hidden rounded-sm shrink-0">
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      referrerPolicy="no-referrer"
                      className="object-cover object-center"
                    />
                  </div>
                  <div>
                    <div className="text-[10px] text-[#8C8270]">
                      {product.brand} · {product.country}
                    </div>
                    <div
                      onClick={() => {
                        onSelectProduct(product);
                        onClose();
                      }}
                      className="font-serif text-sm font-bold text-[#F1E9D8] hover:text-[#B69B6B] cursor-pointer"
                    >
                      {product.name}
                    </div>
                    <div className="text-[10px] text-[#A69B89]">
                      {product.format} · £{product.price.toFixed(2)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      onSelectProduct(product);
                      onClose();
                    }}
                    className="p-2 bg-[#12110E] border border-[#38332B] hover:border-[#B69B6B] text-[#C5BCAB] rounded-sm"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => {
                      onAddToCart(product);
                      onClose();
                    }}
                    className="px-3 py-2 btn-brass text-xs font-mono uppercase font-bold flex items-center gap-1 rounded-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>BAG</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
