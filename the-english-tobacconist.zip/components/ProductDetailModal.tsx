'use client';

import React from 'react';
import Image from 'next/image';
import { Product } from '@/lib/products-data';
import { X, Plane, ShieldAlert, CheckCircle, Store, ShoppingBag } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
  ageVerified: boolean;
  minAge: number;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  ageVerified,
  minAge,
}) => {
  if (!product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#12110E] border border-[#B69B6B]/50 p-6 sm:p-8 text-[#F1E9D8] shadow-2xl my-8 rounded-sm">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] transition-colors rounded-sm"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Image Column */}
          <div className="space-y-4">
            <div className="relative h-72 sm:h-80 w-full bg-[#1C1A17] border border-[#38332B] overflow-hidden rounded-sm">
              <Image
                src={product.image}
                alt={product.name}
                fill
                referrerPolicy="no-referrer"
                className="object-cover object-center"
              />
            </div>

            {/* Regulatory Notice Banner */}
            <div className="bg-[#1C1A17] p-3 border-l-2 border-[#B69B6B] text-[11px] font-mono text-[#C5BCAB] space-y-1">
              <div className="text-[#B69B6B] font-bold uppercase flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>REGULATORY COMPLIANCE</span>
              </div>
              <p>{product.regulatoryNote}</p>
            </div>
          </div>

          {/* Details Column */}
          <div className="space-y-5">
            <div>
              <div className="text-xs font-mono text-[#8C8270] uppercase">
                {product.brand} · {product.country}
              </div>
              <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#F1E9D8] mt-1">
                {product.name}
              </h2>
              <div className="text-xs font-mono text-[#B69B6B] mt-1">
                SKU: {product.sku}
              </div>
            </div>

            {/* Pricing Box */}
            <div className="bg-[#1C1A17] p-4 border border-[#38332B] flex items-center justify-between font-mono">
              <div>
                <span className="text-xs text-[#8C8270] block">RETAIL PRICE</span>
                <span className="text-xl font-bold text-[#F1E9D8] tabular-nums">
                  £{product.price.toFixed(2)}
                </span>
              </div>
              {product.dutyFreePrice && (
                <div className="text-right border-l border-[#38332B] pl-4">
                  <span className="text-xs text-[#B69B6B] block font-semibold flex items-center gap-1 justify-end">
                    <Plane className="w-3 h-3" />
                    DUTY FREE
                  </span>
                  <span className="text-lg font-bold text-[#B69B6B] tabular-nums">
                    £{product.dutyFreePrice.toFixed(2)}
                  </span>
                </div>
              )}
            </div>

            {/* Specification Table */}
            <div className="text-xs font-mono bg-[#1C1A17]/60 border border-[#38332B] p-3 divide-y divide-[#38332B]">
              <div className="py-1.5 flex justify-between">
                <span className="text-[#8C8270]">CATEGORY</span>
                <span className="text-[#F1E9D8] uppercase">{product.category}</span>
              </div>
              <div className="py-1.5 flex justify-between">
                <span className="text-[#8C8270]">SUBCATEGORY</span>
                <span className="text-[#F1E9D8]">{product.subcategory}</span>
              </div>
              <div className="py-1.5 flex justify-between">
                <span className="text-[#8C8270]">FORMAT</span>
                <span className="text-[#F1E9D8]">{product.format}</span>
              </div>
              <div className="py-1.5 flex justify-between">
                <span className="text-[#8C8270]">PACK SIZE</span>
                <span className="text-[#F1E9D8]">{product.packSize}</span>
              </div>
              {product.wrapper && (
                <div className="py-1.5 flex justify-between">
                  <span className="text-[#8C8270]">WRAPPER LEAF</span>
                  <span className="text-[#F1E9D8]">{product.wrapper}</span>
                </div>
              )}
              {product.gauge && (
                <div className="py-1.5 flex justify-between">
                  <span className="text-[#8C8270]">RING GAUGE</span>
                  <span className="text-[#F1E9D8]">{product.gauge}</span>
                </div>
              )}
              {product.nicotineMg !== undefined && (
                <div className="py-1.5 flex justify-between">
                  <span className="text-[#8C8270]">NICOTINE CONTENT</span>
                  <span className="text-[#F1E9D8]">{product.nicotineMg}mg/ml</span>
                </div>
              )}
            </div>

            <p className="text-xs font-sans text-[#C5BCAB] leading-relaxed">
              {product.description}
            </p>

            {/* Actions */}
            <div className="pt-2 flex flex-col sm:flex-row gap-3">
              <button
                onClick={() => {
                  onAddToCart(product);
                  onClose();
                }}
                className="flex-1 py-3 btn-brass text-xs font-mono font-bold uppercase flex items-center justify-center gap-2 cursor-pointer rounded-sm"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>ADD TO SHOPPING BAG</span>
              </button>

              <button
                onClick={onClose}
                className="py-3 px-4 btn-oak text-xs font-mono uppercase rounded-sm"
              >
                CLOSE
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
