'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Plane, AlertTriangle, ShieldCheck, CheckCircle2, XCircle, Info, ExternalLink, Calendar, MapPin } from 'lucide-react';
import { DEPARTURE_POINTS, CUSTOMS_ALLOWANCES, DeparturePoint, CustomsAllowance } from '@/lib/customs-data';

interface TravelRetailCalculatorProps {
  onReserveCollection?: (details: any) => void;
}

export const TravelRetailCalculator: React.FC<TravelRetailCalculatorProps> = ({
  onReserveCollection,
}) => {
  const [selectedDeparture, setSelectedDeparture] = useState<string>('LHR-T5');
  const [selectedDestination, setSelectedDestination] = useState<string>('US');
  const [travellerType, setTravellerType] = useState<'UK_RESIDENT' | 'VISITOR' | 'TRANSIT'>('UK_RESIDENT');
  
  // User intended purchase quantities
  const [cigarettes, setCigarettes] = useState<number>(200);
  const [cigars, setCigars] = useState<number>(25);
  const [tobaccoGrams, setTobaccoGrams] = useState<number>(100);
  const [vapingMl, setVapingMl] = useState<number>(30);

  const [bookingConfirmed, setBookingConfirmed] = useState<boolean>(false);

  const departureObj = DEPARTURE_POINTS.find((d) => d.code === selectedDeparture) || DEPARTURE_POINTS[0];
  const allowanceObj = CUSTOMS_ALLOWANCES[selectedDestination] || CUSTOMS_ALLOWANCES['US'];

  // Allowance Calculation Logic
  // Split option percentage sum (Cigarettes % + Cigars % + Tobacco %)
  const cigarettesPct = allowanceObj.cigarettesLimit > 0 ? (cigarettes / allowanceObj.cigarettesLimit) * 100 : 0;
  const cigarsPct = allowanceObj.cigarsLimit > 0 ? (cigars / allowanceObj.cigarsLimit) * 100 : 0;
  const tobaccoPct = allowanceObj.tobaccoGramsLimit > 0 ? (tobaccoGrams / allowanceObj.tobaccoGramsLimit) * 100 : 0;

  // In UK/EU customs rules, tobacco limits are split options (i.e. Total % should not exceed 100% combined)
  const combinedTobaccoPct = cigarettesPct + cigarsPct + tobaccoPct;

  const isSingaporeProhibited = selectedDestination === 'SG';
  const isAustraliaStrict = selectedDestination === 'AU';

  const isWithinAllowance = !isSingaporeProhibited && combinedTobaccoPct <= 100 && vapingMl <= allowanceObj.vapingMlLimit;
  const isSlightlyOver = combinedTobaccoPct > 100 && combinedTobaccoPct <= 200;
  const isSignificantlyOver = combinedTobaccoPct > 200 || isSingaporeProhibited;

  const handleReserve = () => {
    setBookingConfirmed(true);
    setTimeout(() => {
      setBookingConfirmed(false);
    }, 6000);
  };

  return (
    <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Hero Banner */}
      <div className="relative rounded-sm overflow-hidden border border-[#B69B6B]/40 bg-[#1C1A17] p-8 sm:p-12 mb-10">
        <Image
          src="/images/travel_retail_lounge_1790955039666.jpg"
          alt="The Traveller's Tobacconist Lounge"
          fill
          referrerPolicy="no-referrer"
          className="object-cover object-center opacity-25"
        />
        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#17382D] border border-[#B69B6B]/50 text-[#F1E9D8] text-xs font-mono">
            <Plane className="w-3.5 h-3.5 text-[#B69B6B]" />
            <span>BRITISH TRAVEL RETAIL & DUTY FREE ADVISORY</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-serif font-bold tracking-tight text-[#F1E9D8]">
            THE TRAVELLER&apos;S TOBACCONIST
          </h1>

          <p className="text-base font-sans text-[#D8D0C1] leading-relaxed">
            British tobacco retail for eligible international travellers. Duty and tax treatment depends on departure point, destination, traveller eligibility, and applicable customs rules.
          </p>

          <div className="pt-2 text-xs font-mono font-bold text-[#B69B6B] border-t border-[#38332B] uppercase">
            DUTY-FREE AVAILABILITY AND ALLOWANCES ARE SUBJECT TO APPLICABLE CUSTOMS AND TAX RULES.
          </div>
        </div>
      </div>

      {/* Main Interactive Calculator Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Itinerary & Quantity Inputs */}
        <div className="lg:col-span-7 bg-[#1C1A17] border border-[#38332B] p-6 sm:p-8 space-y-6 rounded-sm">
          <div className="border-b border-[#38332B] pb-3">
            <h2 className="text-xl font-serif font-bold text-[#F1E9D8] flex items-center gap-2">
              <Plane className="w-5 h-5 text-[#B69B6B]" />
              1. TRAVEL ITINERARY & ELIGIBILITY
            </h2>
            <p className="text-xs font-mono text-[#8C8270] mt-1">
              Select departure location and destination country to evaluate customs limits.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Departure Point */}
            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-[#B69B6B] uppercase">
                DEPARTING FROM (UK PORT / AIRPORT):
              </label>
              <select
                value={selectedDeparture}
                onChange={(e) => setSelectedDeparture(e.target.value)}
                className="w-full bg-[#12110E] border border-[#38332B] p-2.5 text-xs font-mono text-[#F1E9D8] focus:outline-none focus:border-[#B69B6B]"
              >
                {DEPARTURE_POINTS.map((dp) => (
                  <option key={dp.code} value={dp.code}>
                    {dp.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Destination Country */}
            <div className="space-y-1.5">
              <label className="block text-xs font-mono text-[#B69B6B] uppercase">
                TRAVELLING TO (DESTINATION):
              </label>
              <select
                value={selectedDestination}
                onChange={(e) => setSelectedDestination(e.target.value)}
                className="w-full bg-[#12110E] border border-[#38332B] p-2.5 text-xs font-mono text-[#F1E9D8] focus:outline-none focus:border-[#B69B6B]"
              >
                {Object.values(CUSTOMS_ALLOWANCES).map((ca) => (
                  <option key={ca.destinationCode} value={ca.destinationCode}>
                    {ca.flag} {ca.destinationName}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Traveller Type */}
          <div className="space-y-1.5">
            <label className="block text-xs font-mono text-[#B69B6B] uppercase">
              TRAVELLER ELIGIBILITY STATUS:
            </label>
            <div className="grid grid-cols-3 gap-2 text-xs font-mono">
              <button
                type="button"
                onClick={() => setTravellerType('UK_RESIDENT')}
                className={`p-2.5 border text-center transition-colors ${
                  travellerType === 'UK_RESIDENT'
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#12110E] text-[#C5BCAB] border-[#38332B]'
                }`}
              >
                UK RESIDENT
              </button>
              <button
                type="button"
                onClick={() => setTravellerType('VISITOR')}
                className={`p-2.5 border text-center transition-colors ${
                  travellerType === 'VISITOR'
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#12110E] text-[#C5BCAB] border-[#38332B]'
                }`}
              >
                OVERSEAS VISITOR
              </button>
              <button
                type="button"
                onClick={() => setTravellerType('TRANSIT')}
                className={`p-2.5 border text-center transition-colors ${
                  travellerType === 'TRANSIT'
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#12110E] text-[#C5BCAB] border-[#38332B]'
                }`}
              >
                IN-TRANSIT
              </button>
            </div>
          </div>

          <div className="border-b border-[#38332B] pt-4 pb-2">
            <h2 className="text-xl font-serif font-bold text-[#F1E9D8] flex items-center gap-2">
              <Info className="w-5 h-5 text-[#B69B6B]" />
              2. INTENDED PURCHASE QUANTITIES
            </h2>
            <p className="text-xs font-mono text-[#8C8270] mt-1">
              Adjust planned items to calculate total personal allowance utilization.
            </p>
          </div>

          {/* Sliders / Quantity inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
            {/* Cigarettes */}
            <div className="bg-[#12110E] p-3 border border-[#38332B] space-y-2">
              <div className="flex justify-between text-[#B69B6B]">
                <span>CIGARETTES (UNITS)</span>
                <span className="text-[#F1E9D8] font-bold">{cigarettes}</span>
              </div>
              <input
                type="range"
                min="0"
                max="400"
                step="20"
                value={cigarettes}
                onChange={(e) => setCigarettes(Number(e.target.value))}
                className="w-full accent-[#B69B6B]"
              />
              <span className="text-[10px] text-[#8C8270] block">
                Destination Limit: {allowanceObj.cigarettesLimit} units
              </span>
            </div>

            {/* Cigars */}
            <div className="bg-[#12110E] p-3 border border-[#38332B] space-y-2">
              <div className="flex justify-between text-[#B69B6B]">
                <span>CIGARS (UNITS)</span>
                <span className="text-[#F1E9D8] font-bold">{cigars}</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={cigars}
                onChange={(e) => setCigars(Number(e.target.value))}
                className="w-full accent-[#B69B6B]"
              />
              <span className="text-[10px] text-[#8C8270] block">
                Destination Limit: {allowanceObj.cigarsLimit} units
              </span>
            </div>

            {/* Pipe / Rolling Tobacco */}
            <div className="bg-[#12110E] p-3 border border-[#38332B] space-y-2">
              <div className="flex justify-between text-[#B69B6B]">
                <span>PIPE / ROLLING TOBACCO (GRAMS)</span>
                <span className="text-[#F1E9D8] font-bold">{tobaccoGrams}g</span>
              </div>
              <input
                type="range"
                min="0"
                max="500"
                step="25"
                value={tobaccoGrams}
                onChange={(e) => setTobaccoGrams(Number(e.target.value))}
                className="w-full accent-[#B69B6B]"
              />
              <span className="text-[10px] text-[#8C8270] block">
                Destination Limit: {allowanceObj.tobaccoGramsLimit}g
              </span>
            </div>

            {/* Vaping Liquid */}
            <div className="bg-[#12110E] p-3 border border-[#38332B] space-y-2">
              <div className="flex justify-between text-[#B69B6B]">
                <span>VAPING REFILL LIQUID (ML)</span>
                <span className="text-[#F1E9D8] font-bold">{vapingMl}ml</span>
              </div>
              <input
                type="range"
                min="0"
                max="200"
                step="10"
                value={vapingMl}
                onChange={(e) => setVapingMl(Number(e.target.value))}
                className="w-full accent-[#B69B6B]"
              />
              <span className="text-[10px] text-[#8C8270] block">
                Destination Limit: {allowanceObj.vapingMlLimit}ml
              </span>
            </div>
          </div>
        </div>

        {/* Right Column: Custom Evaluation Results */}
        <div className="lg:col-span-5 bg-[#1C1A17] border border-[#38332B] p-6 sm:p-8 space-y-6 rounded-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="border-b border-[#38332B] pb-3">
              <span className="text-xs font-mono text-[#B69B6B] uppercase">
                CALCULATED COMPLIANCE ASSESSMENT
              </span>
              <h3 className="text-2xl font-serif font-bold text-[#F1E9D8] mt-1">
                ALLOWANCE EVALUATION
              </h3>
            </div>

            {/* Status Alert Banner */}
            {isSingaporeProhibited ? (
              <div className="bg-[#5A211F]/30 border border-[#5A211F] p-4 text-xs font-mono text-[#F1E9D8] space-y-1">
                <div className="flex items-center gap-1.5 text-[#5A211F] font-bold text-sm">
                  <XCircle className="w-5 h-5 text-red-500" />
                  <span>STRICT IMPORT PROHIBITION</span>
                </div>
                <p className="text-[#D8D0C1]">
                  Vaping products are strictly illegal in Singapore. All tobacco products must be declared immediately at Singapore Customs with zero duty-free concession.
                </p>
              </div>
            ) : isWithinAllowance ? (
              <div className="bg-[#17382D]/40 border border-[#B69B6B]/60 p-4 text-xs font-mono text-[#F1E9D8] space-y-1">
                <div className="flex items-center gap-1.5 text-[#B69B6B] font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-[#B69B6B]" />
                  <span>WITHIN PERSONAL ALLOWANCE</span>
                </div>
                <p className="text-[#C5BCAB]">
                  Combined tobacco total is {combinedTobaccoPct.toFixed(0)}% of your duty-free quota. No additional import tax or duty declaration expected at destination.
                </p>
              </div>
            ) : (
              <div className="bg-[#5A211F]/20 border border-[#5A211F] p-4 text-xs font-mono text-[#F1E9D8] space-y-1">
                <div className="flex items-center gap-1.5 text-amber-400 font-bold text-sm">
                  <AlertTriangle className="w-5 h-5 text-amber-400" />
                  <span>EXCEEDS DUTY-FREE ALLOWANCE ({combinedTobaccoPct.toFixed(0)}%)</span>
                </div>
                <p className="text-[#C5BCAB]">
                  Your requested quantities exceed standard duty-free limits. Excess quantities must be declared at customs and will incur destination excise duty.
                </p>
              </div>
            )}

            {/* Three Pillar Breakdown as requested by prompt */}
            <div className="space-y-3 font-mono text-xs">
              {/* Pillar 1: Store Availability */}
              <div className="bg-[#12110E] p-3 border border-[#2A2722]">
                <div className="text-[#B69B6B] font-bold uppercase mb-1">
                  1. STORE AVAILABILITY AT {departureObj.code}:
                </div>
                <p className="text-[#C5BCAB] text-[11px]">
                  All requested lines available for collection at {departureObj.terminalCollectionDesk}.
                </p>
              </div>

              {/* Pillar 2: Customs Allowance */}
              <div className="bg-[#12110E] p-3 border border-[#2A2722]">
                <div className="text-[#B69B6B] font-bold uppercase mb-1">
                  2. CUSTOMS ALLOWANCE ({allowanceObj.flag} {allowanceObj.destinationName}):
                </div>
                <p className="text-[#C5BCAB] text-[11px]">
                  {allowanceObj.declarationRequiredAbove}
                </p>
              </div>

              {/* Pillar 3: Tax / Duty Treatment */}
              <div className="bg-[#12110E] p-3 border border-[#2A2722]">
                <div className="text-[#B69B6B] font-bold uppercase mb-1">
                  3. TAX & DUTY TREATMENT:
                </div>
                <p className="text-[#C5BCAB] text-[11px]">
                  {isWithinAllowance
                    ? '0% UK VAT & 0% Destination Duty applied under personal duty-free allowance.'
                    : 'Standard retail pricing applies to excess units; destination customs duty payable upon entry.'}
                </p>
              </div>
            </div>

            {/* Official Source Link */}
            <div className="pt-2 text-[11px] font-mono text-[#8C8270] flex items-center justify-between border-t border-[#38332B]">
              <span>Official Border Authority:</span>
              <a
                href={allowanceObj.officialSourceUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[#B69B6B] hover:underline flex items-center gap-1"
              >
                <span>{allowanceObj.officialSourceLabel}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>

          {/* Reserve Collection Box */}
          <div className="pt-4 border-t border-[#38332B] space-y-3">
            {bookingConfirmed ? (
              <div className="bg-[#17382D] p-4 text-center border border-[#B69B6B] text-xs font-mono text-[#F1E9D8]">
                <CheckCircle2 className="w-6 h-6 text-[#B69B6B] mx-auto mb-1" />
                <span className="font-bold block">DEMO RESERVATION CONFIRMED</span>
                <span className="text-[11px] text-[#C5BCAB] block mt-1">
                  Ref: ET-TR-{departureObj.code}-2026. Please bring your boarding pass & physical ID to {departureObj.terminalCollectionDesk}.
                </span>
              </div>
            ) : (
              <button
                type="button"
                onClick={handleReserve}
                className="w-full py-3.5 btn-brass text-xs font-mono font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md"
              >
                <Calendar className="w-4 h-4" />
                <span>PRE-BOOK FOR AIRPORT COLLECTION</span>
              </button>
            )}

            <div className="text-[10px] font-mono text-[#6E6659] text-center">
              Demonstration travel retail interface. No real transactions take place.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
