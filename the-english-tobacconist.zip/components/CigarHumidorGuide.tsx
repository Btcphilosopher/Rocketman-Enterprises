'use client';

import React from 'react';
import Image from 'next/image';
import { Product, PRODUCTS } from '@/lib/products-data';
import { Compass, Flame, ShieldAlert, Sparkles, Plus, Eye } from 'lucide-react';

interface CigarHumidorGuideProps {
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const CigarHumidorGuide: React.FC<CigarHumidorGuideProps> = ({
  onSelectProduct,
  onAddToCart,
}) => {
  const cigars = PRODUCTS.filter((p) => p.category === 'cigars');

  return (
    <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Editorial Header */}
      <div className="relative rounded-sm overflow-hidden border border-[#B69B6B]/40 bg-[#1C1A17] p-8 sm:p-12 mb-12">
        <Image
          src="/images/cigar_cabinet_showcase_1790955003640.jpg"
          alt="Gentlemen's Cigar Cabinet"
          fill
          referrerPolicy="no-referrer"
          className="object-cover object-center opacity-30"
        />
        <div className="relative z-10 max-w-2xl space-y-3">
          <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase">
            ST JAMES’S & HAVANA HERITAGE
          </span>
          <h1 className="text-3xl sm:text-5xl font-serif font-bold text-[#F1E9D8]">
            THE CIGAR MERCHANTS
          </h1>
          <p className="text-sm font-sans text-[#D8D0C1] leading-relaxed">
            Hand-rolled long-filler cigars aged in Spanish cedar cabinets. A lineage spanning Cuban classics, New World reserves, and British travel retail exclusives.
          </p>
        </div>
      </div>

      {/* Humidor Storage Science Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <div className="bg-[#1C1A17] p-6 border border-[#38332B] space-y-2 rounded-sm">
          <div className="text-xs font-mono text-[#B69B6B] uppercase font-bold flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-[#B69B6B]" />
            HUMIDITY PRESERVATION
          </div>
          <p className="text-xs font-sans text-[#C5BCAB] leading-relaxed">
            Maintain cedar humidors strictly at 68%–72% Relative Humidity (RH) using distilled water or two-way humidity packs.
          </p>
        </div>

        <div className="bg-[#1C1A17] p-6 border border-[#38332B] space-y-2 rounded-sm">
          <div className="text-xs font-mono text-[#B69B6B] uppercase font-bold flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-[#B69B6B]" />
            TEMPERATURE STABILITY
          </div>
          <p className="text-xs font-sans text-[#C5BCAB] leading-relaxed">
            Store at 18°C–20°C. Temperatures exceeding 22°C risk tobacco beetle larvae hatching and wrapper oil loss.
          </p>
        </div>

        <div className="bg-[#1C1A17] p-6 border border-[#38332B] space-y-2 rounded-sm">
          <div className="text-xs font-mono text-[#B69B6B] uppercase font-bold flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-[#B69B6B]" />
            AIRFLOW & ROTATION
          </div>
          <p className="text-xs font-sans text-[#C5BCAB] leading-relaxed">
            Rotate cigar boxes every 60 days to ensure equal humidity distribution across upper and lower humidor trays.
          </p>
        </div>
      </div>

      {/* Cigar Product Showcase */}
      <div className="space-y-6">
        <div className="pb-3 border-b border-[#38332B] flex items-center justify-between">
          <h2 className="text-2xl font-serif font-bold text-[#F1E9D8]">
            FEATURED CIGAR SELECTION
          </h2>
          <span className="text-xs font-mono text-[#8C8270]">
            AGE RESTRICTED 18+ UK / 21+ US
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {cigars.map((cigar) => (
            <div
              key={cigar.id}
              className="bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] transition-all duration-300 p-5 rounded-sm flex flex-col justify-between"
            >
              <div>
                <div
                  onClick={() => onSelectProduct(cigar)}
                  className="relative h-56 w-full mb-4 bg-[#12110E] border border-[#2A2722] overflow-hidden cursor-pointer rounded-sm"
                >
                  <Image
                    src={cigar.image}
                    alt={cigar.name}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover object-center hover:scale-105 transition-transform duration-500 opacity-80 hover:opacity-100"
                  />
                </div>

                <div className="text-xs font-mono text-[#8C8270] uppercase mb-1">
                  {cigar.brand} · {cigar.country}
                </div>

                <h3
                  onClick={() => onSelectProduct(cigar)}
                  className="text-xl font-serif font-bold text-[#F1E9D8] hover:text-[#B69B6B] transition-colors cursor-pointer mb-2"
                >
                  {cigar.name}
                </h3>

                <p className="text-xs font-sans text-[#C5BCAB] line-clamp-2 mb-4">
                  {cigar.description}
                </p>

                <div className="text-[11px] font-mono bg-[#12110E] p-2.5 border border-[#2A2722] space-y-1 mb-4 text-[#A69B89]">
                  <div>FORMAT: <span className="text-[#F1E9D8]">{cigar.format}</span></div>
                  <div>RING GAUGE: <span className="text-[#F1E9D8]">{cigar.gauge || 50}</span></div>
                  <div>WRAPPER: <span className="text-[#F1E9D8]">{cigar.wrapper || 'Ecuadorian'}</span></div>
                </div>
              </div>

              <div className="pt-4 border-t border-[#38332B] flex items-center justify-between">
                <div>
                  <span className="text-xs font-mono text-[#8C8270] block">RETAIL PRICE</span>
                  <span className="text-base font-mono font-bold text-[#F1E9D8] tabular-nums">
                    £{cigar.price.toFixed(2)}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectProduct(cigar)}
                    className="p-2 bg-[#12110E] border border-[#38332B] hover:border-[#B69B6B] text-[#C5BCAB] hover:text-[#F1E9D8] transition-colors rounded-sm"
                  >
                    <Eye className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onAddToCart(cigar)}
                    className="px-3 py-2 btn-brass text-xs font-mono font-bold uppercase flex items-center gap-1 cursor-pointer rounded-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>BAG</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
