'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Product } from '@/lib/products-data';
import { X, ShoppingBag, Trash2, Plus, Minus, Plane, CheckCircle2 } from 'lucide-react';

export interface CartItem {
  product: Product;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  selectedStore: string;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  selectedStore,
}) => {
  const [isTravelling, setIsTravelling] = useState<boolean>(false);
  const [checkoutComplete, setCheckoutComplete] = useState<boolean>(false);

  if (!isOpen) return null;

  const subtotal = cartItems.reduce((sum, item) => {
    const price = isTravelling && item.product.dutyFreePrice ? item.product.dutyFreePrice : item.product.price;
    return sum + price * item.quantity;
  }, 0);

  const handleDemoCheckout = () => {
    setCheckoutComplete(true);
    setTimeout(() => {
      setCheckoutComplete(false);
      onClearCart();
      onClose();
    }, 5000);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#12110E] border-l border-[#B69B6B]/40 h-full p-6 text-[#F1E9D8] flex flex-col justify-between shadow-2xl overflow-y-auto">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-[#38332B] mb-6">
            <div className="flex items-center gap-2 text-xs font-mono text-[#B69B6B]">
              <ShoppingBag className="w-4 h-4 text-[#B69B6B]" />
              <span>SHOPPING BAG ({cartItems.reduce((acc, item) => acc + item.quantity, 0)})</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] rounded-sm"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Travel Retail Rate Toggle */}
          <div className="bg-[#1C1A17] p-3 border border-[#38332B] rounded-sm mb-6 flex items-center justify-between font-mono text-xs">
            <div className="flex items-center gap-2">
              <Plane className="w-4 h-4 text-[#B69B6B]" />
              <span className="text-[#C5BCAB]">TRAVELLING OVERSEAS?</span>
            </div>
            <label className="flex items-center gap-1.5 cursor-pointer text-[11px] text-[#B69B6B]">
              <input
                type="checkbox"
                checked={isTravelling}
                onChange={(e) => setIsTravelling(e.target.checked)}
                className="accent-[#B69B6B]"
              />
              <span>APPLY DUTY FREE</span>
            </label>
          </div>

          {/* Cart Item List */}
          {cartItems.length === 0 ? (
            <div className="text-center py-12 text-xs font-mono text-[#8C8270] space-y-2">
              <p>Your shopping bag is currently empty.</p>
              <p className="text-[11px] text-[#6E6659]">Browse our catalogue to select cigars, pipe leaf, or travel retail sets.</p>
            </div>
          ) : checkoutComplete ? (
            <div className="bg-[#17382D] p-6 text-center border border-[#B69B6B] text-xs font-mono space-y-2">
              <CheckCircle2 className="w-8 h-8 text-[#B69B6B] mx-auto" />
              <span className="text-base font-serif font-bold block text-[#F1E9D8]">ORDER RESERVATION CONFIRMED</span>
              <p className="text-[#C5BCAB] text-[11px]">
                Ref: ET-ORDER-2026-UK. Present age ID at {selectedStore} or Airport Collection Lounge upon arrival.
              </p>
            </div>
          ) : (
            <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
              {cartItems.map((item) => {
                const itemPrice = isTravelling && item.product.dutyFreePrice ? item.product.dutyFreePrice : item.product.price;

                return (
                  <div
                    key={item.product.id}
                    className="bg-[#1C1A17] p-3 border border-[#38332B] rounded-sm flex gap-3 text-xs font-mono"
                  >
                    <div className="relative w-16 h-16 bg-[#12110E] border border-[#2A2722] shrink-0 rounded-sm overflow-hidden">
                      <Image
                        src={item.product.image}
                        alt={item.product.name}
                        fill
                        referrerPolicy="no-referrer"
                        className="object-cover object-center opacity-80"
                      />
                    </div>

                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between font-serif text-sm font-bold text-[#F1E9D8]">
                        <span className="line-clamp-1">{item.product.name}</span>
                        <button
                          onClick={() => onRemoveItem(item.product.id)}
                          className="text-[#8C8270] hover:text-[#5A211F] ml-2"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-[10px] text-[#8C8270]">{item.product.brand} · {item.product.format}</div>

                      <div className="flex justify-between items-center pt-1">
                        <div className="flex items-center gap-1.5 border border-[#38332B] bg-[#12110E] px-1.5 py-0.5">
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, -1)}
                            className="text-[#C5BCAB] hover:text-[#F1E9D8]"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-1 text-[#F1E9D8] font-bold">{item.quantity}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.product.id, 1)}
                            className="text-[#C5BCAB] hover:text-[#F1E9D8]"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <div className="text-[#F1E9D8] font-bold tabular-nums">
                          £{(itemPrice * item.quantity).toFixed(2)}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Total & Checkout */}
        {!checkoutComplete && cartItems.length > 0 && (
          <div className="pt-4 border-t border-[#38332B] space-y-4">
            <div className="space-y-1 font-mono text-xs">
              <div className="flex justify-between text-[#8C8270]">
                <span>COLLECTION LOCATION:</span>
                <span className="text-[#F1E9D8] uppercase">{selectedStore}</span>
              </div>
              <div className="flex justify-between text-[#8C8270]">
                <span>DUTY RATE APPLIED:</span>
                <span className="text-[#B69B6B]">{isTravelling ? 'DUTY FREE EXEMPT' : 'STANDARD UK VAT'}</span>
              </div>
              <div className="flex justify-between text-base font-bold text-[#F1E9D8] pt-2 border-t border-[#38332B]">
                <span>ESTIMATED TOTAL:</span>
                <span className="tabular-nums">£{subtotal.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={handleDemoCheckout}
              className="w-full py-3.5 btn-brass text-xs font-mono font-bold uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-md"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>PRE-BOOK ORDER FOR STORE COLLECTION</span>
            </button>

            <div className="text-[10px] font-mono text-[#6E6659] text-center">
              Demonstration cart module. Physical age ID required at collection counter.
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
