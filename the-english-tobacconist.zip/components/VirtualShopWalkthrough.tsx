'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Compass, Info, ChevronRight, Sparkles } from 'lucide-react';

interface VirtualShopWalkthroughProps {
  onSelectCategory: (cat: string) => void;
}

export const VirtualShopWalkthrough: React.FC<VirtualShopWalkthroughProps> = ({
  onSelectCategory,
}) => {
  const [activeRoomIndex, setActiveRoomIndex] = useState(0);

  const rooms = [
    {
      id: 'counter',
      title: 'THE COUNTER',
      subtitle: 'The Merchant’s Desk & Briar Display',
      image: '/images/hero_tobacconist_interior_1790954990146.jpg',
      categoryTarget: 'pipe',
      architecture: 'Solitary dark oak merchant counter fitted with hallmarked brass scales, leather-bound ledgers, and handcrafted briar pipes.',
      curatorNote: 'The heart of traditional English shopkeeping: direct conversation across a solid timber surface, precise weight measurements, and custom pipe leaf advice.',
      hotspots: [
        { title: 'Brass Weighing Scales', desc: 'Precision balance used for custom pipe flake proportions.' },
        { title: 'Briar Pipe Rack', desc: 'Aged Italian briar pipes with sterling silver bands.' },
      ],
    },
    {
      id: 'cigar-cabinet',
      title: 'THE CIGAR CABINET',
      subtitle: 'Climate-Controlled Cedar Walk-In Humidor',
      image: '/images/cigar_cabinet_showcase_1790955003640.jpg',
      categoryTarget: 'cigars',
      architecture: 'Untreated Spanish cedar wood paneling maintained at a strict 70% relative humidity and 19°C temperature.',
      curatorNote: 'Housing Churchills, Robustos, and rare New World cabinets. Each box rests on slatted cedar shelves designed for uniform airflow.',
      hotspots: [
        { title: 'Digital Brass Hygrometer', desc: 'Monitors ambient humidity to 0.1% accuracy.' },
        { title: 'Cedar Cabinet Shelves', desc: 'Spanish cedar prevents tobacco beetles and preserves essential oils.' },
      ],
    },
    {
      id: 'tobacco-room',
      title: 'THE TOBACCO ROOM',
      subtitle: 'Virginia Flakes, Latakia & Blending Vaults',
      image: '/images/pipe_tobacco_blending_1790955016574.jpg',
      categoryTarget: 'pipe',
      architecture: 'A quiet room lined with glass blending jars, brass embossed tins, and pressed Virginia flake ribbons.',
      curatorNote: 'Here our blenders inspect flue-cured Virginia, sun-cured Latakia, and air-cured Burley leaf before vacuum sealing.',
      hotspots: [
        { title: 'Embossed Vacuum Tins', desc: 'Airtight tinplate packaging maintaining moisture content.' },
        { title: 'Blending Jars', desc: 'Aged leaf samples available for bespoke blend formulation.' },
      ],
    },
    {
      id: 'travel-desk',
      title: 'THE TRAVEL DESK',
      subtitle: 'Duty-Free Concierge & Departure Hub',
      image: '/images/travel_retail_lounge_1790955039666.jpg',
      categoryTarget: 'travel-retail',
      architecture: 'Dedicated travel lounge with departure monitors, international customs allowance guides, and sealed flight-ready collection bags.',
      curatorNote: 'Assisting international travellers with customs rules, duty calculation, and pre-orders for airport lounge collection.',
      hotspots: [
        { title: 'Customs Allowance Terminal', desc: 'Live customs lookup for UK, US, EU, and Asian destinations.' },
        { title: 'Sealed Flight Pouches', desc: 'Tamper-evident travel retail packaging.' },
      ],
    },
    {
      id: 'accessories-case',
      title: 'THE ACCESSORIES CASE',
      subtitle: 'Leather Goods, Cutters & Lighters',
      image: '/images/vaping_device_british_1790955029303.jpg',
      categoryTarget: 'accessories',
      architecture: 'Illuminated glass display cabinet featuring vegetable-tanned calfskin cases, guillotine cutters, and brushed titanium vaping suites.',
      curatorNote: 'Handmade objects designed for durability, international travel, and exact tobacco maintenance.',
      hotspots: [
        { title: 'Vegetable-Tanned Leather', desc: 'Cedar-lined cases for cigar protection during transit.' },
        { title: 'Guillotine Cutters', desc: 'Stainless steel dual blades for clean cap cuts.' },
      ],
    },
  ];

  const currentRoom = rooms[activeRoomIndex];

  return (
    <section className="py-16 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Section Header */}
      <div className="mb-8 pb-4 border-b border-[#38332B] flex flex-col md:flex-row md:items-end justify-between">
        <div>
          <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase flex items-center gap-1.5">
            <Compass className="w-4 h-4 text-[#B69B6B]" />
            INTERACTIVE RETAIL ARCHITECTURE
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#F1E9D8] mt-1">
            THE HOUSE — A VIRTUAL WALKTHROUGH
          </h2>
        </div>
        <p className="text-xs font-mono text-[#C5BCAB] mt-2 md:mt-0">
          EXPLORE OUR ST JAMES’S INTERIOR ROOM BY ROOM
        </p>
      </div>

      {/* Room Selector Navigation */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mb-8">
        {rooms.map((room, idx) => (
          <button
            key={room.id}
            onClick={() => setActiveRoomIndex(idx)}
            className={`p-3 text-left border text-xs font-mono transition-all rounded-sm ${
              activeRoomIndex === idx
                ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B] font-bold shadow-md'
                : 'bg-[#1C1A17] text-[#C5BCAB] border-[#38332B] hover:border-[#B69B6B]/50'
            }`}
          >
            <span className="text-[10px] text-[#B69B6B] block">ROOM 0{idx + 1}</span>
            <span className="truncate block font-semibold mt-0.5">{room.title}</span>
          </button>
        ))}
      </div>

      {/* Active Room Viewer */}
      <div className="bg-[#1C1A17] border border-[#38332B] p-6 sm:p-8 rounded-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Column: Image with Hotspots */}
        <div className="lg:col-span-7 relative h-80 sm:h-96 w-full bg-[#12110E] border border-[#38332B] overflow-hidden rounded-sm group">
          <Image
            src={currentRoom.image}
            alt={currentRoom.title}
            fill
            referrerPolicy="no-referrer"
            className="object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#12110E] via-transparent to-transparent" />

          {/* Overlay Room Title */}
          <div className="absolute bottom-4 left-4 z-10 bg-[#12110E]/90 border border-[#B69B6B]/40 px-3 py-1.5 text-xs font-mono text-[#F1E9D8]">
            <span className="text-[#B69B6B] font-bold">ST JAMES&apos;S HOUSE: </span>
            {currentRoom.title}
          </div>
        </div>

        {/* Right Column: Architectural Details & Curator Notes */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <span className="text-xs font-mono text-[#B69B6B] uppercase">
              ROOM 0{activeRoomIndex + 1} OF 05
            </span>
            <h3 className="text-3xl font-serif font-bold text-[#F1E9D8] mt-1">
              {currentRoom.title}
            </h3>
            <p className="text-xs font-mono text-[#A69B89] mt-1">
              {currentRoom.subtitle}
            </p>
          </div>

          <div className="bg-[#12110E] p-4 border-l-2 border-[#B69B6B] space-y-2 text-xs font-sans">
            <div className="font-mono text-[#B69B6B] font-bold uppercase text-[11px]">
              JOINERY & ARCHITECTURE
            </div>
            <p className="text-[#C5BCAB] leading-relaxed">
              {currentRoom.architecture}
            </p>
          </div>

          <div className="bg-[#12110E] p-4 border-l-2 border-[#17382D] space-y-2 text-xs font-sans">
            <div className="font-mono text-[#B69B6B] font-bold uppercase text-[11px] flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              CURATOR NOTES
            </div>
            <p className="text-[#C5BCAB] leading-relaxed">
              {currentRoom.curatorNote}
            </p>
          </div>

          {/* Hotspot highlights */}
          <div className="space-y-2">
            <span className="text-xs font-mono text-[#B69B6B] uppercase block">
              ROOM HIGHLIGHTS:
            </span>
            <div className="grid grid-cols-1 gap-2">
              {currentRoom.hotspots.map((hs, i) => (
                <div key={i} className="bg-[#12110E] p-2.5 border border-[#38332B] text-xs font-mono">
                  <span className="text-[#F1E9D8] font-bold block">{hs.title}</span>
                  <span className="text-[#8C8270] text-[11px] block">{hs.desc}</span>
                </div>
              ))}
            </div>
          </div>

          {/* CTA Button */}
          <button
            onClick={() => onSelectCategory(currentRoom.categoryTarget)}
            className="w-full py-3 btn-brass text-xs font-mono font-bold uppercase flex items-center justify-center gap-2 cursor-pointer rounded-sm"
          >
            <span>VIEW {currentRoom.title} CATALOGUE</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </section>
  );
};
