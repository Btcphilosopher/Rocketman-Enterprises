'use client';

import React from 'react';
import Image from 'next/image';
import { ArrowUpRight } from 'lucide-react';

interface CategoryShowcaseProps {
  onSelectCategory: (categoryKey: string) => void;
}

export const CategoryShowcase: React.FC<CategoryShowcaseProps> = ({
  onSelectCategory,
}) => {
  const categories = [
    {
      id: 'cigars',
      title: 'CIGARS',
      subtitle: 'Churchill, Robusto, Petit Corona & Cabinet Boxes',
      image: '/images/cigar_cabinet_showcase_1790955003640.jpg',
      itemCount: '3 Formats Available',
    },
    {
      id: 'pipe',
      title: 'PIPE TOBACCO',
      subtitle: 'Virginia Flakes, Latakia Mixtures & Aged Tins',
      image: '/images/pipe_tobacco_blending_1790955016574.jpg',
      itemCount: '3 Blends Available',
    },
    {
      id: 'vaping',
      title: 'VAPING SUITE',
      subtitle: 'Brushed Titanium Devices & Natural Tobacco Salts',
      image: '/images/vaping_device_british_1790955029303.jpg',
      itemCount: '3 Suite Items',
    },
    {
      id: 'travel-retail',
      title: 'TRAVEL RETAIL',
      subtitle: 'Duty-Free Allowances & Departure Airport Collections',
      image: '/images/travel_retail_lounge_1790955039666.jpg',
      itemCount: 'Duty-Free Hub',
    },
    {
      id: 'rolling',
      title: 'ROLLING TOBACCO',
      subtitle: 'Fine Cut Virginia & Fire-Cured Shags',
      image: '/images/pipe_tobacco_blending_1790955016574.jpg',
      itemCount: '2 Blends',
    },
    {
      id: 'cigarettes',
      title: 'CIGARETTES',
      subtitle: 'Plain Oval & Traditional Gold Flake King Size',
      image: '/images/hero_tobacconist_interior_1790954990146.jpg',
      itemCount: '2 Formats',
    },
    {
      id: 'accessories',
      title: 'ACCESSORIES',
      subtitle: 'Spanish Cedar Humidors, Briar Pipes & Leather Cases',
      image: '/images/cigar_cabinet_showcase_1790955003640.jpg',
      itemCount: '3 Craftsman Works',
    },
  ];

  return (
    <section className="py-16 px-4 sm:px-6 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-10 pb-4 border-b border-[#38332B]/80">
        <div>
          <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase">
            CATALOGUE DIRECTORY
          </span>
          <h2 className="text-3xl font-serif font-bold text-[#F1E9D8] mt-1">
            SHOP BY CATEGORY
          </h2>
        </div>
        <p className="text-xs font-mono text-[#A69B89] mt-2 sm:mt-0">
          ALL PRESENTATIONS COMPLY WITH UK & INTERNATIONAL TOBACCO REGULATIONS
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat, idx) => (
          <div
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className={`group relative h-72 rounded-sm overflow-hidden border border-[#38332B] hover:border-[#B69B6B] transition-all duration-300 cursor-pointer bg-[#1C1A17] flex flex-col justify-end p-6 ${
              idx === 0 || idx === 3 ? 'md:col-span-2 lg:col-span-1' : ''
            }`}
          >
            {/* Background Image */}
            <Image
              src={cat.image}
              alt={cat.title}
              fill
              referrerPolicy="no-referrer"
              className="object-cover object-center group-hover:scale-105 transition-transform duration-700 opacity-50 group-hover:opacity-65"
            />

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#12110E] via-[#12110E]/60 to-transparent" />

            {/* Content */}
            <div className="relative z-10 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#B69B6B]">
                <span>{cat.itemCount}</span>
                <span className="w-6 h-6 rounded-full bg-[#12110E]/80 border border-[#B69B6B]/40 flex items-center justify-center group-hover:bg-[#B69B6B] group-hover:text-[#12110E] transition-colors">
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </span>
              </div>

              <h3 className="text-2xl font-serif font-bold text-[#F1E9D8] group-hover:text-[#B69B6B] transition-colors">
                {cat.title}
              </h3>

              <p className="text-xs font-sans text-[#D8D0C1] line-clamp-2 leading-relaxed">
                {cat.subtitle}
              </p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
