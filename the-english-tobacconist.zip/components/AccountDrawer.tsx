'use client';

import React, { useState } from 'react';
import { X, User, ShieldCheck, Plane, MapPin, Package, FileText } from 'lucide-react';

interface AccountDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  ageVerified: boolean;
  minAge: number;
  selectedStore: string;
}

export const AccountDrawer: React.FC<AccountDrawerProps> = ({
  isOpen,
  onClose,
  ageVerified,
  minAge,
  selectedStore,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'itineraries' | 'humidor' | 'legal'>('profile');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-md bg-[#12110E] border-l border-[#B69B6B]/40 h-full p-6 text-[#F1E9D8] overflow-y-auto flex flex-col justify-between shadow-2xl">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-[#38332B] mb-6">
            <div className="flex items-center gap-2 text-xs font-mono text-[#B69B6B]">
              <User className="w-4 h-4 text-[#B69B6B]" />
              <span>PATRON ACCOUNT & TRAVEL PROFILE</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] rounded-sm"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Sub-navigation tabs */}
          <div className="grid grid-cols-4 gap-1 bg-[#1C1A17] p-1 border border-[#38332B] rounded-sm mb-6 font-mono text-[11px]">
            <button
              onClick={() => setActiveTab('profile')}
              className={`py-1.5 text-center transition-colors ${
                activeTab === 'profile' ? 'bg-[#17382D] text-[#F1E9D8] border border-[#B69B6B]' : 'text-[#C5BCAB]'
              }`}
            >
              PROFILE
            </button>
            <button
              onClick={() => setActiveTab('itineraries')}
              className={`py-1.5 text-center transition-colors ${
                activeTab === 'itineraries' ? 'bg-[#17382D] text-[#F1E9D8] border border-[#B69B6B]' : 'text-[#C5BCAB]'
              }`}
            >
              TRAVEL
            </button>
            <button
              onClick={() => setActiveTab('humidor')}
              className={`py-1.5 text-center transition-colors ${
                activeTab === 'humidor' ? 'bg-[#17382D] text-[#F1E9D8] border border-[#B69B6B]' : 'text-[#C5BCAB]'
              }`}
            >
              HUMIDOR
            </button>
            <button
              onClick={() => setActiveTab('legal')}
              className={`py-1.5 text-center transition-colors ${
                activeTab === 'legal' ? 'bg-[#17382D] text-[#F1E9D8] border border-[#B69B6B]' : 'text-[#C5BCAB]'
              }`}
            >
              LEGAL
            </button>
          </div>

          {/* Tab Content */}
          {activeTab === 'profile' && (
            <div className="space-y-4 font-mono text-xs">
              <div className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-3">
                <div className="flex justify-between items-center pb-2 border-b border-[#38332B]">
                  <span className="text-[#8C8270]">AGE STATUS</span>
                  <span className="text-[#B69B6B] font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {ageVerified ? `VERIFIED ${minAge}+` : 'UNVERIFIED'}
                  </span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-[#38332B]">
                  <span className="text-[#8C8270]">PREFERRED SHOP</span>
                  <span className="text-[#F1E9D8] font-bold flex items-center gap-1 uppercase">
                    <MapPin className="w-3.5 h-3.5 text-[#B69B6B]" />
                    {selectedStore}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-[#8C8270]">MEMBERSHIP REF</span>
                  <span className="text-[#F1E9D8]">ET-PATRON-2026-UK</span>
                </div>
              </div>

              <div className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
                <span className="text-[#B69B6B] font-bold block uppercase">STORE VISIT HISTORY</span>
                <p className="text-[#C5BCAB] text-[11px]">
                  Visited St James&apos;s Flagship on 14 Sept 2026 (Cigar Cabinet Reservation).
                </p>
              </div>
            </div>
          )}

          {activeTab === 'itineraries' && (
            <div className="space-y-3 font-mono text-xs">
              <div className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
                <div className="flex items-center gap-1.5 text-[#B69B6B] font-bold">
                  <Plane className="w-4 h-4" />
                  <span>LHR T5 ➔ JFK NEW YORK</span>
                </div>
                <p className="text-[#C5BCAB] text-[11px]">
                  Scheduled Departure: 18 Oct 2026. Reserved Duty-Free Item: 10x St James Reserve Churchills.
                </p>
                <div className="text-[10px] text-[#17382D] font-bold bg-[#B69B6B] px-2 py-0.5 inline-block">
                  COLLECTION DESK READY
                </div>
              </div>
            </div>
          )}

          {activeTab === 'humidor' && (
            <div className="space-y-3 font-mono text-xs">
              <div className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
                <div className="flex justify-between text-[#B69B6B] font-bold">
                  <span>SPANISH CEDAR DESKTOP</span>
                  <span>70% RH · 19°C</span>
                </div>
                <p className="text-[#C5BCAB] text-[11px]">
                  Current Inventory: 8x Crown Robusto Selected, 1x Royal Navy Cut Flake tin.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'legal' && (
            <div className="space-y-3 font-mono text-xs text-[#C5BCAB]">
              <div className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
                <span className="text-[#B69B6B] font-bold block uppercase">PRIVACY & DATA PROTECTION</span>
                <p className="text-[11px] leading-relaxed">
                  We process minimum personal data required for age verification and travel customs compliance under UK GDPR.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-[#38332B] text-center font-mono text-[10px] text-[#6E6659]">
          ENGLISH-TOBACCONIST-DEMO-001 · PATRON PROFILE
        </div>
      </div>
    </div>
  );
};
