'use client';

import React from 'react';
import { Search, ShoppingBag, MapPin, Sparkles, ShieldCheck, Menu, X } from 'lucide-react';

interface EnglishHeaderProps {
  currentTab: string;
  onSelectTab: (tab: string) => void;
  ageVerified: boolean;
  minAge: number;
  onOpenAgeGate: () => void;
  onOpenSearch: () => void;
  onOpenConcierge: () => void;
  onOpenCart: () => void;
  cartCount: number;
  selectedStore: string;
  onOpenStoreSelector: () => void;
}

export const EnglishHeader: React.FC<EnglishHeaderProps> = ({
  currentTab,
  onSelectTab,
  ageVerified,
  minAge,
  onOpenAgeGate,
  onOpenSearch,
  onOpenConcierge,
  onOpenCart,
  cartCount,
  selectedStore,
  onOpenStoreSelector,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { id: 'shop', label: 'SHOP' },
    { id: 'cigars', label: 'CIGARS' },
    { id: 'tobacco', label: 'TOBACCO' },
    { id: 'vaping', label: 'VAPING' },
    { id: 'travel-retail', label: 'TRAVEL RETAIL' },
    { id: 'virtual-house', label: 'THE HOUSE' },
    { id: 'shops', label: 'OUR SHOPS' },
    { id: 'journal', label: 'JOURNAL' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#12110E]/95 backdrop-blur-md border-b border-[#B69B6B]/25 text-[#F1E9D8]">
      {/* Top Banner Notice */}
      <div className="bg-[#1C1A17] border-b border-[#38332B]/50 px-4 py-1 text-[11px] font-mono text-[#C5BCAB] flex justify-between items-center">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#B69B6B] animate-pulse"></span>
          <span>EST. 2026 · ENGLAND — OFFICIAL HOUSE CATALOGUE & TRAVEL RETAIL</span>
        </div>
        <div className="hidden sm:flex items-center gap-4 text-[#8C8270]">
          <span>DUTY-FREE ALLOWANCES APPLY TO ELIGIBLE TRAVELLERS</span>
          <button onClick={onOpenAgeGate} className="hover:text-[#B69B6B] transition-colors flex items-center gap-1">
            <ShieldCheck className="w-3 h-3 text-[#B69B6B]" />
            <span>AGE STATUS: {ageVerified ? `VERIFIED ${minAge}+` : 'UNVERIFIED'}</span>
          </button>
        </div>
      </div>

      {/* Main 3-Zone Header Contract */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onSelectTab('home')}
            className="text-left font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#F1E9D8] hover:text-[#B69B6B] transition-colors"
          >
            THE ENGLISH TOBACCONIST
          </button>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden lg:flex items-center gap-5 text-xs font-mono font-medium tracking-wider text-[#C5BCAB]">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => onSelectTab(link.id)}
              className={`hover:text-[#F1E9D8] transition-colors py-1 relative whitespace-nowrap ${
                currentTab === link.id ? 'text-[#B69B6B] font-semibold' : ''
              }`}
            >
              {link.label}
              {currentTab === link.id && (
                <span className="absolute bottom-0 left-0 w-full h-[2px] bg-[#B69B6B]" />
              )}
            </button>
          ))}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Location Badge */}
          <button
            onClick={onOpenStoreSelector}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono text-[#C5BCAB] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B]/50 transition-colors rounded-sm"
            title="Select store location"
          >
            <MapPin className="w-3 h-3 text-[#B69B6B]" />
            <span className="truncate max-w-[100px] uppercase">{selectedStore}</span>
          </button>

          {/* Concierge AI Assistant */}
          <button
            onClick={onOpenConcierge}
            className="flex items-center gap-1.5 px-2.5 py-1 text-[11px] font-mono text-[#B69B6B] bg-[#17382D]/80 border border-[#B69B6B]/40 hover:bg-[#17382D] transition-colors rounded-sm"
            title="Consult AI Curator & Duty-Free Concierge"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#B69B6B]" />
            <span className="hidden md:inline">CURATOR AI</span>
          </button>

          {/* Search Button */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-[#C5BCAB] hover:text-[#F1E9D8] hover:bg-[#1C1A17] transition-colors rounded-sm"
            title="Search products and categories"
          >
            <Search className="w-4 h-4" />
          </button>

          {/* Shopping Bag */}
          <button
            onClick={onOpenCart}
            className="relative p-2 text-[#F1E9D8] bg-[#1C1A17] border border-[#B69B6B]/40 hover:border-[#B69B6B] transition-colors rounded-sm flex items-center justify-center"
            title="Shopping Bag"
          >
            <ShoppingBag className="w-4 h-4 text-[#B69B6B]" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-[#5A211F] text-[#F1E9D8] font-mono text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center border border-[#B69B6B]">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-[#C5BCAB] hover:text-[#F1E9D8] transition-colors"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-[#38332B] bg-[#12110E] px-4 py-4 space-y-3 font-mono text-xs text-[#C5BCAB]">
          <div className="grid grid-cols-2 gap-2 pb-3 border-b border-[#38332B]">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => {
                  onSelectTab(link.id);
                  setMobileMenuOpen(false);
                }}
                className={`text-left p-2 border transition-colors ${
                  currentTab === link.id
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#1C1A17] border-[#38332B] text-[#C5BCAB]'
                }`}
              >
                {link.label}
              </button>
            ))}
          </div>

          <div className="flex items-center justify-between pt-1 text-[11px]">
            <button
              onClick={() => {
                onOpenStoreSelector();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-[#B69B6B]"
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>STORE: {selectedStore}</span>
            </button>
            <button
              onClick={() => {
                onOpenAgeGate();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-[#C5BCAB]"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#B69B6B]" />
              <span>VERIFY AGE ({minAge}+)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
