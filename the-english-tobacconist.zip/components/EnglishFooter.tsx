'use client';

import React from 'react';
import { ShieldCheck, MapPin, Plane, Globe } from 'lucide-react';

interface EnglishFooterProps {
  onSelectTab: (tab: string) => void;
  onOpenResponsibleRetail: () => void;
  onOpenAgeGate: () => void;
}

export const EnglishFooter: React.FC<EnglishFooterProps> = ({
  onSelectTab,
  onOpenResponsibleRetail,
  onOpenAgeGate,
}) => {
  return (
    <footer className="bg-[#0F0E0C] border-t border-[#B69B6B]/30 text-[#F1E9D8] pt-16 pb-12 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Top Branding Row */}
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 pb-10 border-b border-[#38332B]/80">
          <div>
            <span className="text-xs font-mono text-[#B69B6B] tracking-[0.2em] uppercase block">
              EST. 2026 · ENGLAND
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#F1E9D8] mt-1">
              THE ENGLISH TOBACCONIST
            </h2>
            <p className="text-xs font-sans text-[#C5BCAB] mt-1 max-w-lg">
              A traditional English tobacconist reimagined as a premium retail brand and travel retail house.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 font-mono text-xs text-[#C5BCAB]">
            <button
              onClick={onOpenAgeGate}
              className="px-3 py-1.5 bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] transition-colors flex items-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-[#B69B6B]" />
              <span>VERIFY AGE STATUS</span>
            </button>

            <button
              onClick={onOpenResponsibleRetail}
              className="px-3 py-1.5 bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] transition-colors flex items-center gap-1.5"
            >
              <span>RESPONSIBLE RETAIL</span>
            </button>
          </div>
        </div>

        {/* Navigation Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 font-mono text-xs text-[#C5BCAB]">
          {/* Column 1: Catalogue */}
          <div className="space-y-3">
            <span className="text-[#B69B6B] uppercase font-bold block">HOUSE CATALOGUE</span>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('cigars')} className="hover:text-[#F1E9D8] transition-colors">
                  HAND-ROLLED CIGARS
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('tobacco')} className="hover:text-[#F1E9D8] transition-colors">
                  PIPE TOBACCO & FLAKES
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('tobacco')} className="hover:text-[#F1E9D8] transition-colors">
                  FINE CUT ROLLING TOBACCO
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('vaping')} className="hover:text-[#F1E9D8] transition-colors">
                  BRITISH VAPOUR SUITE
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Travel Retail */}
          <div className="space-y-3">
            <span className="text-[#B69B6B] uppercase font-bold block">TRAVEL RETAIL</span>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('travel-retail')} className="hover:text-[#F1E9D8] transition-colors">
                  DUTY FREE CALCULATOR
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('travel-retail')} className="hover:text-[#F1E9D8] transition-colors">
                  AIRPORT COLLECTION DESKS
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('travel-retail')} className="hover:text-[#F1E9D8] transition-colors">
                  CUSTOMS ALLOWANCES GUIDE
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Our Shops */}
          <div className="space-y-3">
            <span className="text-[#B69B6B] uppercase font-bold block">OUR SHOPS</span>
            <ul className="space-y-2">
              <li>
                <button onClick={() => onSelectTab('shops')} className="hover:text-[#F1E9D8] transition-colors">
                  LONDON ST JAMES’S FLAGSHIP
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('shops')} className="hover:text-[#F1E9D8] transition-colors">
                  YORK STONEGATE PARLOUR
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('shops')} className="hover:text-[#F1E9D8] transition-colors">
                  EDINBURGH ROYAL MILE VAULTS
                </button>
              </li>
              <li>
                <button onClick={() => onSelectTab('shops')} className="hover:text-[#F1E9D8] transition-colors">
                  BATH MILSOM STREET HOUSE
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Governance */}
          <div className="space-y-3">
            <span className="text-[#B69B6B] uppercase font-bold block">GOVERNANCE & LEGAL</span>
            <ul className="space-y-2">
              <li>
                <button onClick={onOpenResponsibleRetail} className="hover:text-[#F1E9D8] transition-colors">
                  AGE RESTRICTION POLICY
                </button>
              </li>
              <li>
                <button onClick={onOpenResponsibleRetail} className="hover:text-[#F1E9D8] transition-colors">
                  UK TOBACCO COMPLIANCE
                </button>
              </li>
              <li>
                <button onClick={onOpenResponsibleRetail} className="hover:text-[#F1E9D8] transition-colors">
                  PRIVACY & DATA PROTECTION
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Compliance Disclaimer Notice */}
        <div className="p-4 bg-[#1C1A17] border border-[#38332B] font-mono text-[11px] text-[#A69B89] space-y-2 rounded-sm">
          <div className="text-[#B69B6B] font-bold uppercase flex items-center justify-between">
            <span>DEMO & REGULATORY NOTICE — ENGLISH-TOBACCONIST-DEMO-001</span>
            <span>EST. 2026 · ENGLAND</span>
          </div>
          <p className="leading-relaxed">
            This website is a fictional retail brand experience. All shops, products, prices, inventory, and travel-retail calculations are synthetic demonstration data. Do not make health claims. Do not encourage smoking or vaping. Physical age verification (18+ in UK/EU, 21+ in USA) is strictly enforced under applicable tobacco regulations.
          </p>
        </div>

        {/* Bottom Copyright */}
        <div className="pt-4 border-t border-[#38332B]/60 text-center font-mono text-[11px] text-[#6E6659]">
          © 2026 THE ENGLISH TOBACCONIST CO. ALL RIGHTS RESERVED. REGISTERED IN ENGLAND & WALES.
        </div>
      </div>
    </footer>
  );
};
