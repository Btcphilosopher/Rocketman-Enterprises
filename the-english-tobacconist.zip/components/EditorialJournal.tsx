'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { BookOpen, Sparkles, Clock, ArrowRight } from 'lucide-react';

export const EditorialJournal: React.FC = () => {
  const [activeArticleId, setActiveArticleId] = useState<string>('art-01');

  const articles = [
    {
      id: 'art-01',
      title: 'The Architecture of the English Tobacconist: From St James’s to Travel Ports',
      date: 'OCTOBER 2026',
      readTime: '6 MIN READ',
      author: 'THE EDITORIAL DESK',
      image: '/images/hero_tobacconist_interior_1790954990146.jpg',
      leadQuote: 'The English tobacconist has traditionally been a place of small objects and careful transactions: a wooden counter, a glass cabinet, a brass till, a conversation about provenance.',
      bodyParagraphs: [
        'To step across the threshold of a traditional St James’s merchant is to enter a space designed around quiet material permanence. Dark oak counter fronts, bowed multi-pane windows, and hallmarked brass balance scales were not merely decorative elements; they were functional instruments of trust.',
        'In our modern translation, this spatial ethos extends into British travel retail. The airport lounge desk is reimagined not as a quick transactional kiosk, but as an extension of the country-house study: dark cedar shelving, soft directional illumination, and clear regulatory guidance.',
        'Whether in Mayfair, the Shambles of York, or Heathrow Terminal 5, the architectural purpose remains unchanged: to preserve fine leaf, maintain exact humidity, and provide clear factual assistance to the travelling patron.'
      ]
    },
    {
      id: 'art-02',
      title: 'Understanding Pipe Leaf: The Art of Virginia Flake and Latakia Aging',
      date: 'SEPTEMBER 2026',
      readTime: '8 MIN READ',
      author: 'SENIOR BLENDER',
      image: '/images/pipe_tobacco_blending_1790955016574.jpg',
      leadQuote: 'Unlike quick-cured leaf, traditional flue-cured Virginia and sun-cured Cypriot Latakia are agricultural products shaped by time, humidity, and subterranean pressing.',
      bodyParagraphs: [
        'Flue-cured Virginia leaf forms the backbone of traditional English pipe mixtures. High in natural sugars, the leaf undergoes slow fermentation in dark wooden presses, producing pressed flakes that can be folded or rubbed by hand.',
        'Cypriot Latakia, by contrast, is cured over smouldering aromatic hardwood fires in stone kilns. The resulting leaf imparts a deep smoky aroma, revered by collectors for over two centuries.',
        'In our blending vaults, vacuum-sealed tin packaging ensures that the natural essential oils remain undisturbed until opened by the pipe smoker.'
      ]
    },
    {
      id: 'art-03',
      title: 'The Anatomy of a Cedar Humidor: Relative Humidity and Airflow Mechanics',
      date: 'AUGUST 2026',
      readTime: '5 MIN READ',
      author: 'HUMIDOR CRAFTSMAN',
      image: '/images/cigar_cabinet_showcase_1790955003640.jpg',
      leadQuote: 'A handmade cigar is a living organic object. Deprived of moisture, wrapper leaves turn brittle; exposed to excessive humidity, combustion stalls.',
      bodyParagraphs: [
        'Untreated Spanish cedar (Cedrela odorata) remains the gold standard for cigar preservation. Its porous cellular structure absorbs excess moisture during humid periods and releases it when ambient air dries.',
        'Maintaining 68%–72% Relative Humidity at 18°C–20°C prevents both mold formation and leaf degradation. Precision analog hygrometers remain favoured over uncalibrated digital sensors for long-term cabinet monitoring.',
        'For travellers crossing climate zones, cedar-lined leather cases offer temporary protection, insulating cigars against cabin pressure changes and air conditioning.'
      ]
    }
  ];

  const activeArticle = articles.find((a) => a.id === activeArticleId) || articles[0];

  return (
    <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Section Title */}
      <div className="mb-8 pb-4 border-b border-[#38332B] flex flex-col sm:flex-row sm:items-end justify-between">
        <div>
          <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase flex items-center gap-1.5">
            <BookOpen className="w-4 h-4 text-[#B69B6B]" />
            THE ENGLISH JOURNAL
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#F1E9D8] mt-1">
            NOTES ON CRAFTSMANSHIP & PROVENANCE
          </h1>
        </div>
        <p className="text-xs font-mono text-[#C5BCAB] mt-2 sm:mt-0">
          EDITORIAL ARTICLES · HISTORICAL & ARCHITECTURAL DISCOURSES
        </p>
      </div>

      {/* Main Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Article Selector */}
        <div className="lg:col-span-4 space-y-3 font-mono text-xs">
          <span className="text-[#B69B6B] uppercase font-bold block mb-2">
            SELECT ESSAY:
          </span>
          {articles.map((art) => (
            <button
              key={art.id}
              onClick={() => setActiveArticleId(art.id)}
              className={`w-full text-left p-4 border transition-all rounded-sm ${
                activeArticleId === art.id
                  ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B] shadow-md'
                  : 'bg-[#1C1A17] text-[#C5BCAB] border-[#38332B] hover:border-[#B69B6B]/50'
              }`}
            >
              <div className="flex items-center gap-2 text-[10px] text-[#B69B6B] mb-1">
                <span>{art.date}</span>
                <span>·</span>
                <span>{art.readTime}</span>
              </div>
              <h3 className="font-serif text-base font-bold text-[#F1E9D8] line-clamp-2">
                {art.title}
              </h3>
            </button>
          ))}
        </div>

        {/* Right Column: Reading View */}
        <div className="lg:col-span-8 bg-[#1C1A17] border border-[#38332B] p-6 sm:p-10 space-y-6 rounded-sm">
          {/* Featured Image */}
          <div className="relative h-64 sm:h-80 w-full bg-[#12110E] border border-[#38332B] overflow-hidden rounded-sm">
            <Image
              src={activeArticle.image}
              alt={activeArticle.title}
              fill
              referrerPolicy="no-referrer"
              className="object-cover object-center opacity-85"
            />
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#B69B6B] mb-2">
              <span>{activeArticle.date}</span>
              <span>·</span>
              <span>{activeArticle.author}</span>
              <span>·</span>
              <span>{activeArticle.readTime}</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-serif font-bold text-[#F1E9D8] leading-tight">
              {activeArticle.title}
            </h2>
          </div>

          {/* Lead Quote */}
          <blockquote className="bg-[#12110E] p-5 border-l-2 border-[#B69B6B] font-serif italic text-lg sm:text-xl text-[#F1E9D8] leading-relaxed">
            &ldquo;{activeArticle.leadQuote}&rdquo;
          </blockquote>

          {/* Body Paragraphs */}
          <div className="space-y-4 font-sans text-sm text-[#D8D0C1] leading-relaxed">
            {activeArticle.bodyParagraphs.map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>

          <div className="pt-6 border-t border-[#38332B] text-xs font-mono text-[#8C8270] flex justify-between items-center">
            <span>THE ENGLISH TOBACCONIST EDITORIAL ARCHIVE</span>
            <span className="text-[#B69B6B]">EST. 2026 · ENGLAND</span>
          </div>
        </div>
      </div>
    </section>
  );
};
