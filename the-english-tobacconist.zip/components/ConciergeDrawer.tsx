'use client';

import React, { useState, useRef, useEffect } from 'react';
import { X, Sparkles, Send, ShieldAlert, Compass } from 'lucide-react';

interface ConciergeDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  role: 'user' | 'model';
  text: string;
}

export const ConciergeDrawer: React.FC<ConciergeDrawerProps> = ({
  isOpen,
  onClose,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      text: 'Good day. I am the Senior Retail Curator & Duty-Free Advisory Officer at The English Tobacconist. How may I assist you with product specifications, pipe leaf blending history, cigar humidor mechanics, or international travel allowances?',
    },
  ]);
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  if (!isOpen) return null;

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const response = await fetch('/api/concierge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: userMsg,
          contextHistory: messages.map((m) => ({
            role: m.role,
            parts: [{ text: m.text }],
          })),
        }),
      });

      const data = await response.json();
      if (data.text) {
        setMessages((prev) => [...prev, { role: 'model', text: data.text }]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: 'model', text: 'Our archives are momentarily undergoing re-indexing. Please query again.' },
        ]);
      }
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: 'model', text: 'Connection to our advisory desk was interrupted. Please try again.' },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-[#12110E] border-l border-[#B69B6B]/40 h-full p-6 text-[#F1E9D8] flex flex-col justify-between shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#38332B]">
          <div className="flex items-center gap-2 text-xs font-mono text-[#B69B6B]">
            <Sparkles className="w-4 h-4 text-[#B69B6B]" />
            <span>AI CURATOR & DUTY-FREE ADVISOR</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] rounded-sm"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="py-2 overflow-x-auto flex gap-1.5 font-mono text-[10px] text-[#C5BCAB] border-b border-[#38332B]">
          <button
            onClick={() => setInput('What humidity level should I keep my cedar humidor at?')}
            className="bg-[#1C1A17] border border-[#38332B] px-2.5 py-1 whitespace-nowrap hover:border-[#B69B6B]"
          >
            Humidor Humidity Guide
          </button>
          <button
            onClick={() => setInput('What are the duty free tobacco limits when flying from Heathrow to New York?')}
            className="bg-[#1C1A17] border border-[#38332B] px-2.5 py-1 whitespace-nowrap hover:border-[#B69B6B]"
          >
            LHR to US Customs
          </button>
          <button
            onClick={() => setInput('Explain the difference between Virginia flake and Latakia pipe tobacco.')}
            className="bg-[#1C1A17] border border-[#38332B] px-2.5 py-1 whitespace-nowrap hover:border-[#B69B6B]"
          >
            Virginia vs Latakia
          </button>
        </div>

        {/* Messages Body */}
        <div className="flex-1 overflow-y-auto my-4 space-y-4 pr-1 font-sans text-xs">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`p-4 rounded-sm border ${
                m.role === 'user'
                  ? 'bg-[#1C1A17] border-[#38332B] ml-8 text-[#F1E9D8]'
                  : 'bg-[#17382D]/40 border-[#B69B6B]/40 mr-4 text-[#D8D0C1]'
              }`}
            >
              <div className="text-[10px] font-mono text-[#B69B6B] uppercase mb-1">
                {m.role === 'user' ? 'YOU' : 'CURATOR ADVISORY OFFICER'}
              </div>
              <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
            </div>
          ))}
          {loading && (
            <div className="bg-[#17382D]/20 border border-[#B69B6B]/30 p-3 mr-4 text-xs font-mono text-[#B69B6B] animate-pulse">
              Consulting House Archives & Customs Regulations...
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Box */}
        <div className="pt-3 border-t border-[#38332B] space-y-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about humidor care, pipe leaf, or travel duty free rules..."
              className="flex-1 bg-[#1C1A17] border border-[#38332B] p-2.5 text-xs font-mono text-[#F1E9D8] placeholder-[#6E6659] focus:outline-none focus:border-[#B69B6B]"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="px-4 py-2.5 btn-brass text-xs font-mono uppercase font-bold flex items-center justify-center cursor-pointer rounded-sm"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <div className="text-[10px] font-mono text-[#6E6659] text-center flex items-center justify-center gap-1">
            <ShieldAlert className="w-3 h-3 text-[#B69B6B]" />
            <span>Factual regulatory & historical advice. No medical claims.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
