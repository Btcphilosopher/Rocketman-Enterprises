'use client';

import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, ExternalLink, Globe } from 'lucide-react';

interface AgeGateProps {
  isOpen: boolean;
  onVerify: (verifiedAge: number, jurisdiction: string) => void;
  onOpenResponsibleRetail: () => void;
}

export const AgeGate: React.FC<AgeGateProps> = ({
  isOpen,
  onVerify,
  onOpenResponsibleRetail,
}) => {
  const [selectedJurisdiction, setSelectedJurisdiction] = useState<'UK' | 'US' | 'INT'>('UK');
  const [confirmed, setConfirmed] = useState(false);

  if (!isOpen) return null;

  const minAge = selectedJurisdiction === 'US' ? 21 : 18;

  const handleVerify = () => {
    onVerify(minAge, selectedJurisdiction);
  };

  const handleLeave = () => {
    window.location.href = 'https://www.nhs.uk/live-well/quit-smoking/nhs-stop-smoking-services-help-you-quit/';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 transition-all duration-300">
      <div className="w-full max-w-xl bg-[#12110E] border border-[#B69B6B]/40 p-8 shadow-2xl relative overflow-hidden rounded-sm text-[#F1E9D8]">
        {/* Subtle brass corner accents */}
        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[#B69B6B]"></div>
        <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[#B69B6B]"></div>
        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[#B69B6B]"></div>
        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[#B69B6B]"></div>

        <div className="text-center space-y-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#1C1A17] border border-[#B69B6B]/50 text-[#B69B6B] mb-2">
            <ShieldCheck className="w-6 h-6" />
          </div>

          <div>
            <p className="text-xs tracking-[0.2em] font-mono text-[#B69B6B] uppercase mb-2">
              EST. 2026 · ENGLAND
            </p>
            <h1 className="text-3xl sm:text-4xl font-serif font-bold tracking-tight text-[#F1E9D8]">
              WELCOME TO<br />THE ENGLISH TOBACCONIST
            </h1>
            <p className="mt-3 text-sm text-[#C5BCAB] max-w-md mx-auto font-sans leading-relaxed">
              This website contains factual information regarding age-restricted tobacco, pipe leaf, cigars, and contemporary nicotine products.
            </p>
          </div>

          {/* Jurisdiction Selector */}
          <div className="bg-[#1C1A17] p-4 border border-[#38332B] rounded-sm text-left">
            <label className="block text-xs font-mono text-[#B69B6B] uppercase mb-2 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" />
              Select Your Jurisdiction:
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedJurisdiction('UK')}
                className={`px-3 py-2 text-xs font-medium border text-center transition-all ${
                  selectedJurisdiction === 'UK'
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#12110E] text-[#C5BCAB] border-[#38332B] hover:border-[#B69B6B]/50'
                }`}
              >
                UK & EU (18+)
              </button>
              <button
                type="button"
                onClick={() => setSelectedJurisdiction('US')}
                className={`px-3 py-2 text-xs font-medium border text-center transition-all ${
                  selectedJurisdiction === 'US'
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#12110E] text-[#C5BCAB] border-[#38332B] hover:border-[#B69B6B]/50'
                }`}
              >
                USA (21+)
              </button>
              <button
                type="button"
                onClick={() => setSelectedJurisdiction('INT')}
                className={`px-3 py-2 text-xs font-medium border text-center transition-all ${
                  selectedJurisdiction === 'INT'
                    ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                    : 'bg-[#12110E] text-[#C5BCAB] border-[#38332B] hover:border-[#B69B6B]/50'
                }`}
              >
                International (18+)
              </button>
            </div>
          </div>

          {/* Checkbox confirmation */}
          <label className="flex items-start gap-3 text-left cursor-pointer text-xs text-[#C5BCAB] bg-[#1C1A17]/50 p-3 border border-[#38332B]/60 rounded-sm">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-0.5 accent-[#B69B6B] h-4 w-4 rounded border-[#38332B]"
            />
            <span>
              I confirm that I am of legal purchasing age ({minAge} years or older) in my country or region of residence.
            </span>
          </label>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
            <button
              type="button"
              disabled={!confirmed}
              onClick={handleVerify}
              className={`w-full sm:w-auto px-6 py-3 text-xs font-bold tracking-wider uppercase transition-all ${
                confirmed
                  ? 'btn-brass shadow-lg cursor-pointer'
                  : 'bg-[#2A2722] text-[#6E6659] border border-[#38332B] cursor-not-allowed'
              }`}
            >
              I AM OF LEGAL AGE ({minAge}+)
            </button>
            <button
              type="button"
              onClick={handleLeave}
              className="w-full sm:w-auto px-6 py-3 text-xs font-mono tracking-wider text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B]/50 transition-all flex items-center justify-center gap-1.5"
            >
              LEAVE WEBSITE
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Regulatory Links */}
          <div className="pt-4 border-t border-[#38332B]/60 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 text-[11px] font-mono text-[#8C8270]">
            <button onClick={onOpenResponsibleRetail} className="hover:text-[#B69B6B] transition-colors underline">
              AGE POLICY
            </button>
            <span>·</span>
            <button onClick={onOpenResponsibleRetail} className="hover:text-[#B69B6B] transition-colors underline">
              RESPONSIBLE RETAIL
            </button>
            <span>·</span>
            <button onClick={onOpenResponsibleRetail} className="hover:text-[#B69B6B] transition-colors underline">
              LEGAL INFORMATION
            </button>
          </div>

          <div className="text-[10px] font-mono text-[#6E6659]">
            DEMO IDENTIFIER: ENGLISH-TOBACCONIST-DEMO-001 · CONCEPT WEBSITE
          </div>
        </div>
      </div>
    </div>
  );
};
