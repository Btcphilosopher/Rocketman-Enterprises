'use client';

import React from 'react';
import { X, ShieldCheck, FileText, AlertTriangle } from 'lucide-react';

interface ResponsibleRetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  minAge: number;
}

export const ResponsibleRetailModal: React.FC<ResponsibleRetailModalProps> = ({
  isOpen,
  onClose,
  minAge,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl bg-[#12110E] border border-[#B69B6B]/50 p-6 sm:p-8 text-[#F1E9D8] shadow-2xl my-8 rounded-sm">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] rounded-sm"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="space-y-6">
          <div className="flex items-center gap-2 text-xs font-mono text-[#B69B6B]">
            <ShieldCheck className="w-5 h-5 text-[#B69B6B]" />
            <span>RESPONSIBLE RETAIL & COMPLIANCE FRAMEWORK</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-[#F1E9D8]">
            AGE RESTRICTIONS & REGULATORY POLICIES
          </h2>

          <div className="space-y-4 font-sans text-xs text-[#D8D0C1] leading-relaxed max-h-96 overflow-y-auto pr-2">
            <section className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
              <h3 className="font-mono text-[#B69B6B] font-bold uppercase text-xs">
                1. MINIMUM LEGAL AGE VERIFICATION ({minAge}+)
              </h3>
              <p>
                In accordance with UK Tobacco and Related Products Regulations 2016 and international age-gate mandates, all sale and presentation of tobacco, pipe leaf, cigars, and nicotine vapour products are strictly restricted to adults aged 18 and over in the UK/EU (21+ in the USA). Physical or digital age verification is required prior to order dispatch or retail collection.
              </p>
            </section>

            <section className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
              <h3 className="font-mono text-[#B69B6B] font-bold uppercase text-xs">
                2. NON-PROMOTIONAL & NEUTRAL PRESENTATION
              </h3>
              <p>
                The English Tobacconist operates strictly as a retail catalogue and brand historical repository. We do not make health claims, therapeutic claims, or clean-use representations. We do not encourage tobacco or nicotine consumption, nor do we target minors or non-smokers.
              </p>
            </section>

            <section className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
              <h3 className="font-mono text-[#B69B6B] font-bold uppercase text-xs">
                3. TRAVEL RETAIL & CUSTOMS LAW
              </h3>
              <p>
                Duty-free availability, prices, and personal import allowances are subject to strict border customs regulations enforced by local government revenue authorities (e.g. HMRC, US CBP, Dubai Customs). Travellers are solely responsible for ensuring compliance with destination import limits.
              </p>
            </section>

            <section className="bg-[#1C1A17] p-4 border border-[#38332B] space-y-2">
              <h3 className="font-mono text-[#B69B6B] font-bold uppercase text-xs">
                4. CONCEPT & DEMONSTRATION NOTICE
              </h3>
              <p>
                This website is a synthetic demonstration store interface (ENGLISH-TOBACCONIST-DEMO-001). No real financial transactions or tobacco deliveries take place on this platform.
              </p>
            </section>
          </div>

          <div className="pt-4 border-t border-[#38332B] flex justify-end">
            <button
              onClick={onClose}
              className="px-6 py-2.5 btn-brass text-xs font-mono font-bold uppercase rounded-sm"
            >
              I UNDERSTAND
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
