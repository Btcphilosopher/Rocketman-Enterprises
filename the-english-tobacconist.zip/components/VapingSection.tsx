'use client';

import React from 'react';
import Image from 'next/image';
import { Product, PRODUCTS } from '@/lib/products-data';
import { ShieldAlert, Plus, Eye, Sparkles } from 'lucide-react';

interface VapingSectionProps {
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

export const VapingSection: React.FC<VapingSectionProps> = ({
  onSelectProduct,
  onAddToCart,
}) => {
  const vapingProducts = PRODUCTS.filter((p) => p.category === 'vaping');

  return (
    <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Visual Header */}
      <div className="relative rounded-sm overflow-hidden border border-[#38332B] bg-[#1C1A17] p-8 sm:p-12 mb-10">
        <Image
          src="/images/vaping_device_british_1790955029303.jpg"
          alt="The Vaping Suite"
          fill
          referrerPolicy="no-referrer"
          className="object-cover object-center opacity-30"
        />
        <div className="relative z-10 max-w-2xl space-y-3">
          <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase">
            CONTEMPORARY VAPOUR SUITE
          </span>
          <h1 className="text-3xl sm:text-5xl font-serif font-bold text-[#F1E9D8]">
            THE VAPOUR ARCHITECTURE
          </h1>
          <p className="text-sm font-sans text-[#D8D0C1] leading-relaxed">
            Restrained British vapour engineering. Crafted from English walnut, brushed aircraft titanium, and natural tobacco leaf distillates. Free from synthetic candy flavours or artificial additives.
          </p>
          <div className="pt-2 text-xs font-mono text-[#B69B6B] flex items-center gap-1.5 uppercase">
            <ShieldAlert className="w-4 h-4" />
            <span>STRICTLY AGE RESTRICTED 18+ · TPD COMPLIANT REFILLS</span>
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {vapingProducts.map((item) => (
          <div
            key={item.id}
            className="bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] transition-all p-5 rounded-sm flex flex-col justify-between"
          >
            <div>
              <div
                onClick={() => onSelectProduct(item)}
                className="relative h-56 w-full mb-4 bg-[#12110E] border border-[#2A2722] overflow-hidden cursor-pointer rounded-sm"
              >
                <Image
                  src={item.image}
                  alt={item.name}
                  fill
                  referrerPolicy="no-referrer"
                  className="object-cover object-center opacity-80 hover:scale-105 transition-transform duration-500 hover:opacity-100"
                />
              </div>

              <div className="text-xs font-mono text-[#8C8270] uppercase mb-1">
                {item.brand}
              </div>

              <h3
                onClick={() => onSelectProduct(item)}
                className="text-xl font-serif font-bold text-[#F1E9D8] hover:text-[#B69B6B] transition-colors cursor-pointer mb-2"
              >
                {item.name}
              </h3>

              <p className="text-xs font-sans text-[#C5BCAB] line-clamp-2 mb-4">
                {item.description}
              </p>

              <div className="text-[11px] font-mono bg-[#12110E] p-2.5 border border-[#2A2722] space-y-1 mb-4 text-[#A69B89]">
                <div>FORMAT: <span className="text-[#F1E9D8]">{item.format}</span></div>
                <div>PACK SIZE: <span className="text-[#F1E9D8]">{item.packSize}</span></div>
                {item.nicotineMg !== undefined && (
                  <div>NICOTINE STRENGTH: <span className="text-[#B69B6B] font-bold">{item.nicotineMg}mg/ml</span></div>
                )}
              </div>
            </div>

            <div className="pt-4 border-t border-[#38332B] flex items-center justify-between">
              <div>
                <span className="text-xs font-mono text-[#8C8270] block">RETAIL PRICE</span>
                <span className="text-base font-mono font-bold text-[#F1E9D8] tabular-nums">
                  £{item.price.toFixed(2)}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => onSelectProduct(item)}
                  className="p-2 bg-[#12110E] border border-[#38332B] hover:border-[#B69B6B] text-[#C5BCAB] hover:text-[#F1E9D8] transition-colors rounded-sm"
                >
                  <Eye className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onAddToCart(item)}
                  className="px-3 py-2 btn-brass text-xs font-mono font-bold uppercase flex items-center gap-1 cursor-pointer rounded-sm"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>BAG</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
