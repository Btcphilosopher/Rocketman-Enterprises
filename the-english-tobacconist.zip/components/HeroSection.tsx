'use client';

import React from 'react';
import Image from 'next/image';
import { Compass, MapPin, Plane } from 'lucide-react';

interface HeroSectionProps {
  onExplore: () => void;
  onFindShop: () => void;
  onTravelRetail: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExplore,
  onFindShop,
  onTravelRetail,
}) => {
  return (
    <section className="relative min-h-[580px] lg:min-h-[640px] flex items-center justify-center overflow-hidden border-b border-[#B69B6B]/30 bg-[#12110E]">
      {/* Background Image with Scrim */}
      <div className="absolute inset-0 z-0">
        <Image
          src="/images/hero_tobacconist_interior_1790954990146.jpg"
          alt="The English Tobacconist Interior"
          fill
          priority
          referrerPolicy="no-referrer"
          className="object-cover object-center opacity-40 scale-105 transform transition-transform duration-1000"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#12110E] via-[#12110E]/70 to-[#12110E]/40" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-transparent via-[#12110E]/50 to-[#12110E]" />
      </div>

      {/* Hero Content Box */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 py-16 text-center text-[#F1E9D8]">
        {/* Established Badge */}
        <div className="inline-flex items-center gap-3 px-4 py-1.5 mb-6 bg-[#1C1A17]/80 border border-[#B69B6B]/40 rounded-sm">
          <span className="w-1.5 h-1.5 bg-[#B69B6B] rounded-full"></span>
          <span className="text-xs font-mono tracking-[0.25em] text-[#B69B6B] uppercase">
            EST. 2026 · ENGLAND
          </span>
          <span className="w-1.5 h-1.5 bg-[#B69B6B] rounded-full"></span>
        </div>

        {/* Main Headline */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-serif font-bold tracking-tight leading-[1.08] text-[#F1E9D8] mb-6">
          THE ENGLISH<br />TOBACCONIST
        </h1>

        {/* Subtitle */}
        <p className="text-lg sm:text-xl font-sans text-[#D8D0C1] max-w-2xl mx-auto font-normal leading-relaxed mb-10">
          A modern British house of tobacco and travel retail. Craftsmanship, provenance, and international customs compliance.
        </p>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onExplore}
            className="w-full sm:w-auto px-8 py-3.5 btn-brass text-xs font-bold tracking-widest uppercase flex items-center justify-center gap-2 cursor-pointer shadow-lg"
          >
            <Compass className="w-4 h-4" />
            <span>EXPLORE THE HOUSE</span>
          </button>

          <button
            onClick={onFindShop}
            className="w-full sm:w-auto px-8 py-3.5 btn-oak text-xs font-bold tracking-widest uppercase flex items-center justify-center gap-2 cursor-pointer"
          >
            <MapPin className="w-4 h-4 text-[#B69B6B]" />
            <span>FIND A SHOP</span>
          </button>

          <button
            onClick={onTravelRetail}
            className="w-full sm:w-auto px-8 py-3.5 bg-[#17382D] text-[#F1E9D8] border border-[#B69B6B]/50 hover:bg-[#1f483b] transition-colors text-xs font-bold tracking-widest uppercase flex items-center justify-center gap-2 cursor-pointer"
          >
            <Plane className="w-4 h-4 text-[#B69B6B]" />
            <span>TRAVEL RETAIL</span>
          </button>
        </div>

        {/* Bottom Metadata Callout */}
        <div className="mt-12 pt-8 border-t border-[#38332B]/60 grid grid-cols-2 sm:grid-cols-4 gap-4 text-left font-mono text-[11px] text-[#A69B89]">
          <div>
            <span className="block text-[#B69B6B] font-bold">ST JAMES&apos;S FLAGSHIP</span>
            <span>14 St James&apos;s Street, London</span>
          </div>
          <div>
            <span className="block text-[#B69B6B] font-bold">DUTY FREE HUBS</span>
            <span>Heathrow, Gatwick, Edinburgh</span>
          </div>
          <div>
            <span className="block text-[#B69B6B] font-bold">AGE STATUS</span>
            <span>18+ Strictly Enforced</span>
          </div>
          <div>
            <span className="block text-[#B69B6B] font-bold">AUTHENTICITY</span>
            <span>100% Verified Leaf Provenance</span>
          </div>
        </div>
      </div>
    </section>
  );
};
