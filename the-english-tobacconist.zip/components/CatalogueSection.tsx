'use client';

import React, { useState, useMemo } from 'react';
import Image from 'next/image';
import { Product, PRODUCTS } from '@/lib/products-data';
import { Search, Filter, ShieldAlert, Plane, Check, Eye, Plus } from 'lucide-react';

interface CatalogueSectionProps {
  initialCategory?: string;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  ageVerified: boolean;
  minAge: number;
}

export const CatalogueSection: React.FC<CatalogueSectionProps> = ({
  initialCategory = 'all',
  onSelectProduct,
  onAddToCart,
  ageVerified,
  minAge,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [travelOnly, setTravelOnly] = useState<boolean>(false);
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc'>('featured');

  const categories = [
    { id: 'all', label: 'ALL PRODUCTS' },
    { id: 'cigars', label: 'CIGARS' },
    { id: 'pipe', label: 'PIPE TOBACCO' },
    { id: 'rolling', label: 'ROLLING' },
    { id: 'cigarettes', label: 'CIGARETTES' },
    { id: 'vaping', label: 'VAPING' },
    { id: 'accessories', label: 'ACCESSORIES' },
    { id: 'travel-retail', label: 'DUTY FREE EXCLUSIVES' },
  ];

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((p) => {
      // Category filter
      if (selectedCategory !== 'all' && p.category !== selectedCategory) {
        return false;
      }
      // Duty Free filter
      if (travelOnly && !p.travelRetailEligible) {
        return false;
      }
      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = p.name.toLowerCase().includes(q);
        const matchBrand = p.brand.toLowerCase().includes(q);
        const matchCountry = p.country.toLowerCase().includes(q);
        const matchSub = p.subcategory.toLowerCase().includes(q);
        if (!matchName && !matchBrand && !matchCountry && !matchSub) return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      return 0;
    });
  }, [selectedCategory, searchQuery, travelOnly, sortBy]);

  return (
    <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Header */}
      <div className="mb-8 pb-4 border-b border-[#38332B]">
        <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase">
          HOUSE CATALOGUE & INVENTORY
        </span>
        <h2 className="text-3xl sm:text-4xl font-serif font-bold text-[#F1E9D8] mt-1">
          PRODUCT CATALOGUE
        </h2>
        <p className="text-xs font-mono text-[#C5BCAB] mt-2">
          Factual product specifications for registered adult patrons ({minAge}+).
        </p>
      </div>

      {/* Filter & Control Bar */}
      <div className="space-y-4 mb-8">
        {/* Category Segmented Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3.5 py-2 text-xs font-mono tracking-wider transition-colors whitespace-nowrap rounded-sm border ${
                selectedCategory === cat.id
                  ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                  : 'bg-[#1C1A17] text-[#C5BCAB] border-[#38332B] hover:border-[#B69B6B]/50'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Secondary Search & Toggles */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 bg-[#1C1A17] p-3 border border-[#38332B] rounded-sm">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-[#8C8270]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by brand, leaf origin, format, or product code..."
              className="w-full bg-[#12110E] border border-[#38332B] pl-9 pr-4 py-2 text-xs font-mono text-[#F1E9D8] placeholder-[#6E6659] focus:outline-none focus:border-[#B69B6B]"
            />
          </div>

          {/* Travel Retail Filter & Sort Dropdown */}
          <div className="flex items-center gap-3 font-mono text-xs text-[#C5BCAB]">
            <label className="flex items-center gap-2 cursor-pointer bg-[#12110E] px-3 py-2 border border-[#38332B] hover:border-[#B69B6B]/50 transition-colors rounded-sm">
              <input
                type="checkbox"
                checked={travelOnly}
                onChange={(e) => setTravelOnly(e.target.checked)}
                className="accent-[#B69B6B]"
              />
              <Plane className="w-3.5 h-3.5 text-[#B69B6B]" />
              <span>DUTY FREE ELIGIBLE</span>
            </label>

            <select
              value={sortBy}
              onChange={(e: any) => setSortBy(e.target.value)}
              className="bg-[#12110E] border border-[#38332B] px-3 py-2 text-xs font-mono text-[#F1E9D8] focus:outline-none focus:border-[#B69B6B]"
            >
              <option value="featured">SORT: FEATURED</option>
              <option value="price-asc">PRICE: LOW TO HIGH</option>
              <option value="price-desc">PRICE: HIGH TO LOW</option>
            </select>
          </div>
        </div>
      </div>

      {/* Product Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-16 bg-[#1C1A17] border border-[#38332B] p-8">
          <p className="text-sm font-mono text-[#C5BCAB]">
            No products match your current category or search criteria.
          </p>
          <button
            onClick={() => {
              setSelectedCategory('all');
              setSearchQuery('');
              setTravelOnly(false);
            }}
            className="mt-4 px-4 py-2 btn-brass text-xs font-mono uppercase"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="group bg-[#1C1A17] border border-[#38332B] hover:border-[#B69B6B] transition-all duration-300 flex flex-col justify-between p-5 relative rounded-sm"
            >
              <div>
                {/* Image Showcase */}
                <div
                  onClick={() => onSelectProduct(product)}
                  className="relative h-52 w-full mb-4 bg-[#12110E] border border-[#2A2722] overflow-hidden cursor-pointer rounded-sm"
                >
                  <Image
                    src={product.image}
                    alt={product.name}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover object-center group-hover:scale-105 transition-transform duration-500 opacity-80 group-hover:opacity-100"
                  />
                  {product.travelRetailEligible && (
                    <div className="absolute top-2 left-2 bg-[#17382D]/90 border border-[#B69B6B]/60 text-[#F1E9D8] text-[10px] font-mono px-2 py-0.5 flex items-center gap-1">
                      <Plane className="w-3 h-3 text-[#B69B6B]" />
                      <span>DUTY FREE AVAILABLE</span>
                    </div>
                  )}
                  {product.ageRestricted && (
                    <div className="absolute top-2 right-2 bg-[#12110E]/90 border border-[#38332B] text-[#B69B6B] text-[10px] font-mono px-2 py-0.5">
                      AGE {product.legalAge}+
                    </div>
                  )}
                </div>

                {/* Clean Unboxed Metadata */}
                <div className="flex items-center gap-1.5 text-xs font-mono text-[#8C8270] mb-1">
                  <span>{product.brand.toUpperCase()}</span>
                  <span aria-hidden="true">·</span>
                  <span>{product.country}</span>
                </div>

                <h3
                  onClick={() => onSelectProduct(product)}
                  className="text-lg font-serif font-bold text-[#F1E9D8] hover:text-[#B69B6B] transition-colors cursor-pointer mb-2 line-clamp-1"
                >
                  {product.name}
                </h3>

                <p className="text-xs font-sans text-[#C5BCAB] line-clamp-2 mb-4 leading-relaxed">
                  {product.description}
                </p>

                {/* Format & Pack Size info */}
                <div className="text-[11px] font-mono text-[#A69B89] bg-[#12110E] p-2 border border-[#2A2722] mb-4 space-y-1">
                  <div>FORMAT: <span className="text-[#F1E9D8]">{product.format}</span></div>
                  <div>PACK: <span className="text-[#F1E9D8]">{product.packSize}</span></div>
                </div>
              </div>

              {/* Price & Actions */}
              <div className="pt-4 border-t border-[#38332B] flex items-center justify-between">
                <div>
                  <div className="text-base font-mono font-bold text-[#F1E9D8] tabular-nums">
                    £{product.price.toFixed(2)}
                  </div>
                  {product.dutyFreePrice && (
                    <div className="text-[10px] font-mono text-[#B69B6B] tabular-nums">
                      DUTY FREE: £{product.dutyFreePrice.toFixed(2)}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onSelectProduct(product)}
                    className="p-2 text-[#C5BCAB] hover:text-[#F1E9D8] bg-[#12110E] border border-[#38332B] hover:border-[#B69B6B] transition-colors rounded-sm"
                    title="View Full Specifications"
                  >
                    <Eye className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onAddToCart(product)}
                    className="px-3 py-2 btn-brass text-xs font-mono font-bold uppercase flex items-center gap-1.5 cursor-pointer rounded-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>BAG</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
