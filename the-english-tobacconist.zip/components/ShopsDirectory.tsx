'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { SHOPS, ShopLocation } from '@/lib/shops-data';
import { MapPin, Phone, Mail, Clock, ShieldCheck, Plane, Check } from 'lucide-react';

interface ShopsDirectoryProps {
  onSelectStoreLocation: (storeCity: string) => void;
  selectedStore: string;
}

export const ShopsDirectory: React.FC<ShopsDirectoryProps> = ({
  onSelectStoreLocation,
  selectedStore,
}) => {
  const [selectedCity, setSelectedCity] = useState<string>('ALL');

  const filteredShops = SHOPS.filter((s) => {
    if (selectedCity === 'ALL') return true;
    return s.city === selectedCity;
  });

  return (
    <section className="py-12 px-4 sm:px-6 max-w-7xl mx-auto text-[#F1E9D8]">
      {/* Section Title */}
      <div className="mb-8 pb-4 border-b border-[#38332B] flex flex-col sm:flex-row sm:items-end justify-between">
        <div>
          <span className="text-xs font-mono text-[#B69B6B] tracking-widest uppercase">
            RETAIL LOCATIONS & DUTY FREE DESKS
          </span>
          <h1 className="text-3xl sm:text-4xl font-serif font-bold text-[#F1E9D8] mt-1">
            OUR SHOPS
          </h1>
        </div>
        <div className="mt-2 sm:mt-0 text-xs font-mono text-[#B69B6B] border border-[#B69B6B]/40 px-3 py-1 bg-[#1C1A17]">
          DEMO RETAIL LOCATIONS · CONCEPT DATA
        </div>
      </div>

      {/* City Filter Buttons */}
      <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 font-mono text-xs">
        <button
          onClick={() => setSelectedCity('ALL')}
          className={`px-3.5 py-2 border transition-colors rounded-sm ${
            selectedCity === 'ALL'
              ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
              : 'bg-[#1C1A17] text-[#C5BCAB] border-[#38332B]'
          }`}
        >
          ALL CITIES
        </button>
        {SHOPS.map((s) => (
          <button
            key={s.id}
            onClick={() => setSelectedCity(s.city)}
            className={`px-3.5 py-2 border transition-colors rounded-sm ${
              selectedCity === s.city
                ? 'bg-[#17382D] text-[#F1E9D8] border-[#B69B6B]'
                : 'bg-[#1C1A17] text-[#C5BCAB] border-[#38332B]'
            }`}
          >
            {s.city}
          </button>
        ))}
      </div>

      {/* Shops Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredShops.map((shop) => {
          const isCurrentSelected = selectedStore.toLowerCase().includes(shop.city.toLowerCase());

          return (
            <div
              key={shop.id}
              className={`bg-[#1C1A17] border transition-all duration-300 p-6 rounded-sm flex flex-col justify-between ${
                isCurrentSelected ? 'border-[#B69B6B] shadow-lg bg-[#1C1A17]/90' : 'border-[#38332B]'
              }`}
            >
              <div>
                {/* Shop Image */}
                <div className="relative h-48 w-full mb-4 bg-[#12110E] border border-[#2A2722] overflow-hidden rounded-sm">
                  <Image
                    src={shop.image}
                    alt={shop.title}
                    fill
                    referrerPolicy="no-referrer"
                    className="object-cover object-center"
                  />
                  {shop.travelRetailHub && (
                    <div className="absolute top-2 left-2 bg-[#17382D]/90 border border-[#B69B6B]/60 text-[#F1E9D8] text-[10px] font-mono px-2 py-0.5 flex items-center gap-1">
                      <Plane className="w-3 h-3 text-[#B69B6B]" />
                      <span>AIRPORT COLLECTION HUB</span>
                    </div>
                  )}
                </div>

                <div className="text-xs font-mono text-[#B69B6B] uppercase">
                  {shop.city} · ENGLAND
                </div>

                <h3 className="text-xl font-serif font-bold text-[#F1E9D8] mt-1 mb-2">
                  {shop.title}
                </h3>

                <p className="text-xs font-sans text-[#C5BCAB] leading-relaxed mb-4">
                  {shop.description}
                </p>

                {/* Address & Hours */}
                <div className="text-xs font-mono bg-[#12110E] p-3 border border-[#2A2722] space-y-2 mb-4">
                  <div className="flex items-start gap-2 text-[#D8D0C1]">
                    <MapPin className="w-4 h-4 text-[#B69B6B] shrink-0 mt-0.5" />
                    <span>{shop.address}, {shop.postcode}</span>
                  </div>
                  <div className="flex items-start gap-2 text-[#C5BCAB]">
                    <Clock className="w-4 h-4 text-[#B69B6B] shrink-0 mt-0.5" />
                    <div>
                      <div>Mon–Fri: {shop.openingHours.weekdays}</div>
                      <div>Sat: {shop.openingHours.saturday}</div>
                      <div>Sun: {shop.openingHours.sunday}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-[#C5BCAB] pt-1 border-t border-[#2A2722]">
                    <Phone className="w-3.5 h-3.5 text-[#B69B6B]" />
                    <span>{shop.phone}</span>
                  </div>
                </div>

                {/* Services List */}
                <div className="space-y-1 mb-4 text-[11px] font-mono text-[#A69B89]">
                  <span className="text-[#B69B6B] font-bold block mb-1">AVAILABLE SERVICES:</span>
                  {shop.services.map((svc, i) => (
                    <div key={i} className="flex items-center gap-1.5">
                      <span className="w-1 h-1 bg-[#B69B6B] rounded-full"></span>
                      <span>{svc}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-[#38332B] space-y-2">
                <button
                  onClick={() => onSelectStoreLocation(shop.city)}
                  className={`w-full py-2.5 text-xs font-mono font-bold uppercase transition-all rounded-sm flex items-center justify-center gap-2 ${
                    isCurrentSelected
                      ? 'bg-[#17382D] text-[#F1E9D8] border border-[#B69B6B]'
                      : 'btn-oak'
                  }`}
                >
                  {isCurrentSelected ? (
                    <>
                      <Check className="w-4 h-4 text-[#B69B6B]" />
                      <span>SELECTED STORE</span>
                    </>
                  ) : (
                    <span>SET AS PREFERRED SHOP</span>
                  )}
                </button>

                <div className="text-[10px] font-mono text-[#6E6659] text-center">
                  {shop.demoNotice}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
