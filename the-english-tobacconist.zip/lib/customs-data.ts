export interface CustomsAllowance {
  destinationCode: string;
  destinationName: string;
  flag: string;
  currency: string;
  cigarettesLimit: number; // e.g. 200
  cigarsLimit: number; // e.g. 50
  cigarillosLimit: number; // e.g. 100
  tobaccoGramsLimit: number; // e.g. 250g
  vapingMlLimit: number; // e.g. 100ml
  monetaryValueLimitGBP: number; // e.g. £390 tax free goods limit
  minimumAgeToImport: number;
  declarationRequiredAbove: string;
  notes: string;
  officialSourceLabel: string;
  officialSourceUrl: string;
}

export interface DeparturePoint {
  code: string;
  name: string;
  type: 'Airport' | 'Seaport' | 'Eurostar Terminal';
  terminalCollectionDesk: string;
}

export const DEPARTURE_POINTS: DeparturePoint[] = [
  { code: 'LHR-T5', name: 'London Heathrow (LHR) — Terminal 5', type: 'Airport', terminalCollectionDesk: 'Travel Retail Boutique, High Street South Level 2' },
  { code: 'LHR-T2', name: 'London Heathrow (LHR) — Terminal 2', type: 'Airport', terminalCollectionDesk: 'Departure Lounge opposite Gate 12' },
  { code: 'LGW-S', name: 'London Gatwick (LGW) — South Terminal', type: 'Airport', terminalCollectionDesk: 'Main Duty Free Arcade Level 3' },
  { code: 'MAN-T1', name: 'Manchester Airport (MAN) — Terminal 1', type: 'Airport', terminalCollectionDesk: 'International Departures Lounge' },
  { code: 'EDI-T1', name: 'Edinburgh Airport (EDI)', type: 'Airport', terminalCollectionDesk: 'Main Retail Corridor opposite Gate 8' },
  { code: 'STP-EUR', name: 'London St Pancras International (Eurostar)', type: 'Eurostar Terminal', terminalCollectionDesk: 'International Departure Vaults' },
  { code: 'DOV-PORT', name: 'Port of Dover Passenger Terminal', type: 'Seaport', terminalCollectionDesk: 'Cross-Channel Retail Concourse' },
];

export const CUSTOMS_ALLOWANCES: Record<string, CustomsAllowance> = {
  'GB-RET': {
    destinationCode: 'GB-RET',
    destinationName: 'United Kingdom (Returning Resident / Visitor)',
    flag: '🇬🇧',
    currency: 'GBP (£)',
    cigarettesLimit: 200,
    cigarsLimit: 50,
    cigarillosLimit: 100,
    tobaccoGramsLimit: 250,
    vapingMlLimit: 100,
    monetaryValueLimitGBP: 390,
    minimumAgeToImport: 18,
    declarationRequiredAbove: 'Limits are split options (e.g. 200 cigarettes OR 50 cigars OR 250g tobacco).',
    notes: 'You can combine products provided you do not exceed 100% of your total personal allowance allowance.',
    officialSourceLabel: 'HM Revenue & Customs (HMRC) Duty Free Allowances',
    officialSourceUrl: 'https://www.gov.uk/bringing-goods-into-uk-personal-use/arriving-in-Great-Britain'
  },
  'US': {
    destinationCode: 'US',
    destinationName: 'United States of America',
    flag: '🇺🇸',
    currency: 'USD ($)',
    cigarettesLimit: 200,
    cigarsLimit: 100,
    cigarillosLimit: 100,
    tobaccoGramsLimit: 250,
    vapingMlLimit: 60,
    monetaryValueLimitGBP: 600,
    minimumAgeToImport: 21,
    declarationRequiredAbove: 'Must declare all tobacco products on CBP Form 6059B. Age minimum is strictly 21.',
    notes: 'Cuban-origin tobacco products are subject to OFAC sanctions and import restrictions.',
    officialSourceLabel: 'US Customs and Border Protection (CBP)',
    officialSourceUrl: 'https://www.cbp.gov/travel/international-visitors/kiosk'
  },
  'EU': {
    destinationCode: 'EU',
    destinationName: 'European Union (e.g. France, Spain, Germany, Italy)',
    flag: '🇪🇺',
    currency: 'EUR (€)',
    cigarettesLimit: 200,
    cigarsLimit: 50,
    cigarillosLimit: 100,
    tobaccoGramsLimit: 250,
    vapingMlLimit: 100,
    monetaryValueLimitGBP: 360,
    minimumAgeToImport: 18,
    declarationRequiredAbove: 'Air & sea travellers limit: 200 cigarettes or 250g tobacco. Land borders may have lower limits (40 cigarettes).',
    notes: 'Individual EU member states may enforce national minimum nicotine concentrations.',
    officialSourceLabel: 'European Commission Taxation and Customs Union',
    officialSourceUrl: 'https://ec.europa.eu/taxation_customs/individuals/travelling-entering-eu'
  },
  'AE': {
    destinationCode: 'AE',
    destinationName: 'United Arab Emirates (Dubai, Abu Dhabi)',
    flag: '🇦🇪',
    currency: 'AED',
    cigarettesLimit: 400,
    cigarsLimit: 50,
    cigarillosLimit: 50,
    tobaccoGramsLimit: 500,
    vapingMlLimit: 50,
    monetaryValueLimitGBP: 650,
    minimumAgeToImport: 18,
    declarationRequiredAbove: 'Excess quantities subject to 100% customs excise tax at port of entry.',
    notes: 'E-cigarettes must be TPD/ESMA compliant for personal import.',
    officialSourceLabel: 'Dubai Customs Authority',
    officialSourceUrl: 'https://www.dubaicustoms.gov.ae'
  },
  'SG': {
    destinationCode: 'SG',
    destinationName: 'Singapore',
    flag: '🇸🇬',
    currency: 'SGD ($)',
    cigarettesLimit: 0,
    cigarsLimit: 0,
    cigarillosLimit: 0,
    tobaccoGramsLimit: 0,
    vapingMlLimit: 0,
    monetaryValueLimitGBP: 0,
    minimumAgeToImport: 21,
    declarationRequiredAbove: 'NO duty-free concession on tobacco or nicotine in Singapore. ALL tobacco products must be declared and taxed.',
    notes: 'VAPING DEVICES AND E-LIQUIDS ARE STRICTLY PROHIBITED IN SINGAPORE BY LAW.',
    officialSourceLabel: 'Singapore Customs & Health Sciences Authority (HSA)',
    officialSourceUrl: 'https://www.customs.gov.sg/businesses/importing-goods/duty-checklist-and-tax-dutiable-goods'
  },
  'AU': {
    destinationCode: 'AU',
    destinationName: 'Australia',
    flag: '🇦🇺',
    currency: 'AUD ($)',
    cigarettesLimit: 25,
    cigarsLimit: 5,
    cigarillosLimit: 10,
    tobaccoGramsLimit: 25,
    vapingMlLimit: 0,
    monetaryValueLimitGBP: 480,
    minimumAgeToImport: 18,
    declarationRequiredAbove: 'Strict duty-free limit: ONE unopened packet of up to 25 cigarettes OR 25g of tobacco products.',
    notes: 'All nicotine e-cigarettes require a valid Australian medical prescription for import.',
    officialSourceLabel: 'Australian Border Force (ABF)',
    officialSourceUrl: 'https://www.abf.gov.au/entering-and-leaving-australia/duty-free'
  },
  'JP': {
    destinationCode: 'JP',
    destinationName: 'Japan',
    flag: '🇯🇵',
    currency: 'JPY (¥)',
    cigarettesLimit: 200,
    cigarsLimit: 50,
    cigarillosLimit: 50,
    tobaccoGramsLimit: 250,
    vapingMlLimit: 120,
    monetaryValueLimitGBP: 1000,
    minimumAgeToImport: 20,
    declarationRequiredAbove: 'Foreign residents and tourists can bring up to 200 cigarettes tax free.',
    notes: 'Vaping liquid containing nicotine is regulated as a pharmaceutical in Japan (up to 120ml personal supply).',
    officialSourceLabel: 'Japan Customs (Ministry of Finance)',
    officialSourceUrl: 'https://www.customs.go.jp/english/summary/passenger.htm'
  }
};
