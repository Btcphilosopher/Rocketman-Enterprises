export interface ShopLocation {
  id: string;
  city: string;
  title: string;
  address: string;
  postcode: string;
  phone: string;
  email: string;
  openingHours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
  services: string[];
  travelRetailHub: boolean;
  airportCollectionAvailable: boolean;
  image: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  description: string;
  demoNotice: string;
}

export const SHOPS: ShopLocation[] = [
  {
    id: 'shop-london',
    city: 'LONDON',
    title: 'The English Tobacconist — St James’s Flagship',
    address: '14 St James’s Street, Mayfair, London',
    postcode: 'SW1A 1EF',
    phone: '+44 (0)20 7930 1826',
    email: 'stjames@englishtobacconist.co.uk',
    openingHours: {
      weekdays: '09:00 – 18:30',
      saturday: '09:30 – 18:00',
      sunday: '11:00 – 16:00'
    },
    services: [
      'Climate-Controlled Walk-In Humidor',
      'Custom Pipe Tobacco Blending Counter',
      'Private Member Cigar Lockers',
      'Airport Duty-Free Pre-Order Collection Desk',
      'Vapour Bar & Testing Suite'
    ],
    travelRetailHub: true,
    airportCollectionAvailable: true,
    image: '/images/storefront_london_stjames_1790955050431.jpg',
    coordinates: { lat: 51.5064, lng: -0.1388 },
    description: 'Our historic flagship situated in London’s traditional merchant district, featuring dark oak cabinetry, a walk-in climate humidor, and dedicated travel retail desk.',
    demoNotice: 'Demonstration retail location. All store references are synthetic concept data.'
  },
  {
    id: 'shop-york',
    city: 'YORK',
    title: 'The English Tobacconist — Stonegate Merchant',
    address: '28 Stonegate, Medieval Quarter, York',
    postcode: 'YO1 8AS',
    phone: '+44 (0)1904 624 811',
    email: 'york@englishtobacconist.co.uk',
    openingHours: {
      weekdays: '09:30 – 17:30',
      saturday: '09:00 – 18:00',
      sunday: '11:30 – 16:30'
    },
    services: [
      'Vintage Pipe Tobacco Vault',
      'Cigar Preservation Consultation',
      'Click & Collect Retail',
      'Custom Leather Embossing'
    ],
    travelRetailHub: false,
    airportCollectionAvailable: false,
    image: '/images/hero_tobacconist_interior_1790954990146.jpg',
    coordinates: { lat: 53.9599, lng: -1.0827 },
    description: 'Housed within a timber-framed 16th century merchant building, offering hand-rolled cigars, specialized pipe blends, and rustic copper counter service.',
    demoNotice: 'Demonstration retail location. All store references are synthetic concept data.'
  },
  {
    id: 'shop-chester',
    city: 'CHESTER',
    title: 'The English Tobacconist — The Rows Parlour',
    address: '12 Watergate Row, Chester',
    postcode: 'CH1 2LD',
    phone: '+44 (0)1244 322 090',
    email: 'chester@englishtobacconist.co.uk',
    openingHours: {
      weekdays: '09:30 – 17:30',
      saturday: '09:30 – 17:30',
      sunday: 'Closed'
    },
    services: [
      'Cigar Sampling Lounge (Members)',
      'Aromatic Pipe Flake Selection',
      'Custom Gift Packaging'
    ],
    travelRetailHub: false,
    airportCollectionAvailable: false,
    image: '/images/cigar_cabinet_showcase_1790955003640.jpg',
    coordinates: { lat: 53.1905, lng: -2.8918 },
    description: 'Perched on Chester’s double-tiered medieval walkway, serving connoisseurs across the North West with aged cigars and traditional accessories.',
    demoNotice: 'Demonstration retail location. All store references are synthetic concept data.'
  },
  {
    id: 'shop-bath',
    city: 'BATH',
    title: 'The English Tobacconist — Milsom Street House',
    address: '42 Milsom Street, Georgian Quarter, Bath',
    postcode: 'BA1 1DN',
    phone: '+44 (0)1225 461 902',
    email: 'bath@englishtobacconist.co.uk',
    openingHours: {
      weekdays: '09:30 – 18:00',
      saturday: '09:00 – 18:00',
      sunday: '11:00 – 16:00'
    },
    services: [
      'Georgian Cedar Humidor',
      'Travel Retail Pre-Order Desk',
      'Refining & Lighter Servicing'
    ],
    travelRetailHub: true,
    airportCollectionAvailable: true,
    image: '/images/pipe_tobacco_blending_1790955016574.jpg',
    coordinates: { lat: 51.3837, lng: -2.3601 },
    description: 'Georgian stone facade with high ceilings, polished brass display cabinets, and specialized travel retail advisory for departures via Bristol & Heathrow.',
    demoNotice: 'Demonstration retail location. All store references are synthetic concept data.'
  },
  {
    id: 'shop-edinburgh',
    city: 'EDINBURGH',
    title: 'The English Tobacconist — Royal Mile Vaults',
    address: '182 High Street, Royal Mile, Edinburgh',
    postcode: 'EH1 1QS',
    phone: '+44 (0)131 225 5400',
    email: 'edinburgh@englishtobacconist.co.uk',
    openingHours: {
      weekdays: '09:00 – 18:00',
      saturday: '09:00 – 18:30',
      sunday: '10:30 – 17:00'
    },
    services: [
      'Highland Latakia Blending Desk',
      'Edinburgh Airport Duty-Free Pre-Order',
      'Whisky & Cigar Pairing Guide',
      'Custom Engraving'
    ],
    travelRetailHub: true,
    airportCollectionAvailable: true,
    image: '/images/travel_retail_lounge_1790955039666.jpg',
    coordinates: { lat: 55.9502, lng: -3.1878 },
    description: 'Located in the heart of Old Town Edinburgh, specializing in dark-fired pipe flakes, Cuban & New World cigars, and airport travel collection.',
    demoNotice: 'Demonstration retail location. All store references are synthetic concept data.'
  },
  {
    id: 'shop-oxford',
    city: 'OXFORD',
    title: 'The English Tobacconist — Broad Street Merchant',
    address: '54 Broad Street, Academic Quarter, Oxford',
    postcode: 'OX1 3BS',
    phone: '+44 (0)1865 243 102',
    email: 'oxford@englishtobacconist.co.uk',
    openingHours: {
      weekdays: '09:00 – 17:30',
      saturday: '09:30 – 17:30',
      sunday: '12:00 – 16:00'
    },
    services: [
      'Traditional Pipe Repair Studio',
      'University Club Lockers',
      'Subtle Vapour Refill Counter'
    ],
    travelRetailHub: false,
    airportCollectionAvailable: false,
    image: '/images/vaping_device_british_1790955029303.jpg',
    coordinates: { lat: 51.7543, lng: -1.2568 },
    description: 'A classic scholar’s tobacconist featuring quiet leather seating, briar pipe restoration tools, and an extensive library of cured Virginia flakes.',
    demoNotice: 'Demonstration retail location. All store references are synthetic concept data.'
  }
];
