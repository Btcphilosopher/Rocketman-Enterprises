import { GoogleGenAI } from '@google/genai';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { text: 'Concierge advisory service is currently offline (API key unconfigured).' },
        { status: 500 }
      );
    }

    const { prompt, contextHistory } = await req.json();

    if (!prompt || typeof prompt !== 'string') {
      return NextResponse.json({ error: 'Valid prompt string is required' }, { status: 400 });
    }

    const ai = new GoogleGenAI({ apiKey });

    const systemInstruction = `You are the Senior Retail Curator and Duty-Free Advisory Officer at "The English Tobacconist" (Est. 2026, England).
Your role is to assist discerning adult patrons with factual, historical, and regulatory information about:
1. Traditional pipe tobacco blends (Virginia flake, Latakia, Cavendish), pipe briar maintenance, and historical blending methods.
2. Premium hand-rolled cigars (origin, format, gauge, wrapper leaf, humidor humidity 68-72% maintenance).
3. Travel retail, customs allowances (UK, US, EU, UAE, Australia, etc.), duty-free eligibility, and airport store collections.
4. Compliance, legal age verification (18+ in UK, 21+ in US), and neutral product specifications.

STRICT COMPLIANCE RULES YOU MUST FOLLOW:
- NEVER make health claims or imply tobacco/nicotine is safe or clean.
- NEVER encourage smoking, vaping, or increased consumption.
- DO NOT use playful, youth-oriented, or glamorous smoking language.
- DO NOT invent customs laws; always note that duty-free allowances are subject to border customs rules and travellers must verify with official authorities.
- Maintain a polite, understated, authentic British retail tone (like a Savile Row merchant or traditional St James’s tobacconist). Keep answers concise, helpful, and elegant.`;

    const contents = contextHistory && Array.isArray(contextHistory)
      ? [...contextHistory, { role: 'user', parts: [{ text: prompt }] }]
      : prompt;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: contents,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.4,
        maxOutputTokens: 600,
      },
    });

    return NextResponse.json({ text: response.text || 'Thank you for your inquiry. Our curators are at your service.' });
  } catch (error: any) {
    console.error('Concierge API error:', error);
    return NextResponse.json(
      { text: 'An error occurred while consulting our archives. Please try again shortly.' },
      { status: 500 }
    );
  }
}
