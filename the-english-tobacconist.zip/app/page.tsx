'use client';

import React, { useState, useEffect } from 'react';
import { EnglishHeader } from '@/components/EnglishHeader';
import { HeroSection } from '@/components/HeroSection';
import { CategoryShowcase } from '@/components/CategoryShowcase';
import { CatalogueSection } from '@/components/CatalogueSection';
import { VirtualShopWalkthrough } from '@/components/VirtualShopWalkthrough';
import { TravelRetailCalculator } from '@/components/TravelRetailCalculator';
import { CigarHumidorGuide } from '@/components/CigarHumidorGuide';
import { VapingSection } from '@/components/VapingSection';
import { ShopsDirectory } from '@/components/ShopsDirectory';
import { EditorialJournal } from '@/components/EditorialJournal';
import { EnglishFooter } from '@/components/EnglishFooter';

import { AgeGate } from '@/components/AgeGate';
import { ProductDetailModal } from '@/components/ProductDetailModal';
import { SearchModal } from '@/components/SearchModal';
import { CartDrawer, CartItem } from '@/components/CartDrawer';
import { AccountDrawer } from '@/components/AccountDrawer';
import { ConciergeDrawer } from '@/components/ConciergeDrawer';
import { ResponsibleRetailModal } from '@/components/ResponsibleRetailModal';

import { Product, PRODUCTS } from '@/lib/products-data';

export default function Home() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [ageVerified, setAgeVerified] = useState<boolean>(false);
  const [minAge, setMinAge] = useState<number>(18);
  const [jurisdiction, setJurisdiction] = useState<string>('UK');
  const [ageGateOpen, setAgeGateOpen] = useState<boolean>(false);

  const [selectedStore, setSelectedStore] = useState<string>("LONDON ST JAMES'S");
  const [cart, setCart] = useState<CartItem[]>([]);

  // Modals / Drawers
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [conciergeOpen, setConciergeOpen] = useState<boolean>(false);
  const [cartOpen, setCartOpen] = useState<boolean>(false);
  const [accountOpen, setAccountOpen] = useState<boolean>(false);
  const [responsibleRetailOpen, setResponsibleRetailOpen] = useState<boolean>(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  useEffect(() => {
    // Check localStorage for saved age status
    const savedVerified = localStorage.getItem('et_age_verified');
    const savedAge = localStorage.getItem('et_min_age');
    const savedJur = localStorage.getItem('et_jurisdiction');

    if (savedVerified === 'true') {
      requestAnimationFrame(() => {
        if (savedAge) setMinAge(Number(savedAge));
        if (savedJur) setJurisdiction(savedJur);
        setAgeVerified(true);
      });
    } else {
      requestAnimationFrame(() => {
        setAgeGateOpen(true);
      });
    }
  }, []);

  const handleVerifyAge = (verifiedAge: number, selectedJur: string) => {
    setAgeVerified(true);
    setMinAge(verifiedAge);
    setJurisdiction(selectedJur);
    setAgeGateOpen(false);

    localStorage.setItem('et_age_verified', 'true');
    localStorage.setItem('et_min_age', String(verifiedAge));
    localStorage.setItem('et_jurisdiction', selectedJur);
  };

  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    setCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen bg-[#12110E] text-[#F1E9D8] font-sans selection:bg-[#B69B6B] selection:text-[#12110E]">
      {/* Header */}
      <EnglishHeader
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        ageVerified={ageVerified}
        minAge={minAge}
        onOpenAgeGate={() => setAgeGateOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
        onOpenConcierge={() => setConciergeOpen(true)}
        onOpenCart={() => setCartOpen(true)}
        cartCount={cartCount}
        selectedStore={selectedStore}
        onOpenStoreSelector={() => setAccountOpen(true)}
      />

      {/* Main Tab Views */}
      <main className="pb-16">
        {currentTab === 'home' && (
          <>
            <HeroSection
              onExplore={() => setCurrentTab('shop')}
              onFindShop={() => setCurrentTab('shops')}
              onTravelRetail={() => setCurrentTab('travel-retail')}
            />
            <CategoryShowcase onSelectCategory={(cat) => setCurrentTab(cat)} />
            <VirtualShopWalkthrough onSelectCategory={(cat) => setCurrentTab(cat)} />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 my-12 border-t border-[#38332B] pt-12">
              <CatalogueSection
                initialCategory="all"
                onSelectProduct={(p) => setSelectedProduct(p)}
                onAddToCart={handleAddToCart}
                ageVerified={ageVerified}
                minAge={minAge}
              />
            </div>
          </>
        )}

        {currentTab === 'shop' && (
          <CatalogueSection
            initialCategory="all"
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
            ageVerified={ageVerified}
            minAge={minAge}
          />
        )}

        {currentTab === 'cigars' && (
          <CigarHumidorGuide
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentTab === 'tobacco' && (
          <CatalogueSection
            initialCategory="pipe"
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
            ageVerified={ageVerified}
            minAge={minAge}
          />
        )}

        {currentTab === 'vaping' && (
          <VapingSection
            onSelectProduct={(p) => setSelectedProduct(p)}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentTab === 'travel-retail' && (
          <TravelRetailCalculator />
        )}

        {currentTab === 'virtual-house' && (
          <VirtualShopWalkthrough onSelectCategory={(cat) => setCurrentTab(cat)} />
        )}

        {currentTab === 'shops' && (
          <ShopsDirectory
            onSelectStoreLocation={(city) => setSelectedStore(city)}
            selectedStore={selectedStore}
          />
        )}

        {currentTab === 'journal' && (
          <EditorialJournal />
        )}
      </main>

      {/* Footer */}
      <EnglishFooter
        onSelectTab={setCurrentTab}
        onOpenResponsibleRetail={() => setResponsibleRetailOpen(true)}
        onOpenAgeGate={() => setAgeGateOpen(true)}
      />

      {/* Modals & Overlays */}
      <AgeGate
        isOpen={ageGateOpen}
        onVerify={handleVerifyAge}
        onOpenResponsibleRetail={() => {
          setAgeGateOpen(false);
          setResponsibleRetailOpen(true);
        }}
      />

      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        ageVerified={ageVerified}
        minAge={minAge}
      />

      <SearchModal
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectProduct={(p) => setSelectedProduct(p)}
        onAddToCart={handleAddToCart}
      />

      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        cartItems={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
        selectedStore={selectedStore}
      />

      <AccountDrawer
        isOpen={accountOpen}
        onClose={() => setAccountOpen(false)}
        ageVerified={ageVerified}
        minAge={minAge}
        selectedStore={selectedStore}
      />

      <ConciergeDrawer
        isOpen={conciergeOpen}
        onClose={() => setConciergeOpen(false)}
      />

      <ResponsibleRetailModal
        isOpen={responsibleRetailOpen}
        onClose={() => setResponsibleRetailOpen(false)}
        minAge={minAge}
      />
    </div>
  );
}
