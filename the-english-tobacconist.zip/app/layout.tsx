import type { Metadata } from 'next';
import { Cormorant_Garamond, Plus_Jakarta_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const displaySerif = Cormorant_Garamond({
  subsets: ['latin'],
  variable: '--font-serif',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

const bodySans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

const dataMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
  weight: ['400', '500'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'The English Tobacconist | Modern British Tobacco & Travel Retail',
  description: 'A traditional English tobacconist reimagined as a premium late-2020s retail brand and travel retail house. EST. 2026 · ENGLAND.',
  openGraph: {
    title: 'The English Tobacconist | Modern British Tobacco & Travel Retail',
    description: 'A traditional English tobacconist reimagined as a premium late-2020s retail brand and travel retail house. EST. 2026 · ENGLAND.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The English Tobacconist',
    description: 'A traditional English tobacconist reimagined as a premium late-2020s retail brand and travel retail house. EST. 2026 · ENGLAND.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${displaySerif.variable} ${bodySans.variable} ${dataMono.variable}`}>
      <body className="bg-[#12110E] text-[#F1E9D8] font-sans antialiased selection:bg-[#B69B6B] selection:text-[#12110E]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
