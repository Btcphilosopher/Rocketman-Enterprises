export interface Distillery {
  id: string;
  name: string;
  region: 'Speyside' | 'Highlands' | 'Lowlands' | 'Islay' | 'Campbeltown' | 'Islands';
  founded: number;
  status: 'Active' | 'Closed';
  style: string;
  description: string;
  characteristics: string[];
}

export interface Whisky {
  id: string;
  name: string;
  distilleryId: string;
  distilleryName: string;
  age: number | null; // null for NAS
  region: 'Speyside' | 'Highlands' | 'Lowlands' | 'Islay' | 'Campbeltown' | 'Islands';
  abv: number;
  size: string; // e.g. "70cl"
  bottler: 'Official Bottling' | 'Independent Bottling' | 'Emporium Private Cask';
  price: number;
  availability: 'In Stock' | 'Low Stock' | 'Allocated' | 'Sold Out';
  rarityLevel: 1 | 2 | 3 | 4 | 5; // Stars
  rarityCriteria: string;
  caskType: string;
  caskNumber: string;
  bottleNumber: string; // e.g., "142 / 280"
  totalBottles: number;
  distillationYear: number;
  bottlingYear: number;
  styleProfile: ('Light' | 'Rich' | 'Peated' | 'Smoky' | 'Sherried' | 'Citrus' | 'Maritime' | 'Floral' | 'Spiced' | 'Sweet' | 'Dry')[];
  characterKeywords: string[];
  tastingNotes: {
    nose: string;
    palate: string;
    finish: string;
    texture: string;
    water: string;
    serve: string;
  };
  provenanceNotes: string;
  imageUrl?: string;
}

export interface JournalArticle {
  id: string;
  title: string;
  category: 'SCOTLAND' | 'DISTILLERIES' | 'COLLECTING' | 'TASTING' | 'ARCHIVE' | 'EDINBURGH';
  subtitle: string;
  author: string;
  date: string;
  readTime: string;
  summary: string;
  content: string[]; // paragraph list
  pullQuote?: string;
  footnotes?: string[];
}

export interface TastingExperience {
  id: string;
  title: string;
  subtitle: string;
  duration: string;
  whiskyCount: number;
  price: number;
  location: string;
  availability: string;
  description: string;
  includes: string[];
}

export const REGIONS_DATA = {
  Speyside: {
    name: 'Speyside',
    description: 'The golden heartland of Scotch whisky. Located in northeastern Scotland surrounding the River Spey, this region is renowned for its elegant, sweet, and complex single malts, frequently matured in rich Sherry casks.',
    character: 'Orchard fruits, sweet honey, delicate floral notes, vanilla, and deep dried-fruit sherry complexity.',
    distilleryCount: 43
  },
  Highlands: {
    name: 'Highlands',
    description: 'The largest and most diverse whisky region, stretching from the rugged north down to the gentle central hills. This diversity yields whiskies that range from heavily honeyed and heather-rich to lightly peated and maritime.',
    character: 'Heather honey, dry spice, rich oak, subtle smoke, and wild mountain herbs.',
    distilleryCount: 35
  },
  Lowlands: {
    name: 'Lowlands',
    description: 'The gentle south of Scotland, historically known as the home of the "Lowland Ladies." Whiskies here are traditional triple-distilled, making them exceptionally light, grassy, and floral.',
    character: 'Fresh cut grass, green apples, citrus zest, cream, and delicate pastry tones.',
    distilleryCount: 12
  },
  Islay: {
    name: 'Islay',
    description: 'A small, weather-beaten island off the west coast, revered globally as the home of peated single malt. Islay whiskies are famous for their bold, smoky, medicinal, and maritime character, born from peat cut from ancient coastal bogs.',
    character: 'Sea spray, iodine, woodsmoke, cured meats, tar, and bright undercurrents of citrus and vanilla.',
    distilleryCount: 9
  },
  Campbeltown: {
    name: 'Campbeltown',
    description: 'Once the "Whisky Capital of the World" with over thirty active distilleries, this remote peninsula now holds a small but legendary group of traditional distilleries producing intensely robust, oily, and salty whiskies.',
    character: 'Salty brine, heavy oil, wet sheepskin, sweet fruit, and deep, dirty industrial smoke.',
    distilleryCount: 3
  },
  Islands: {
    name: 'Islands',
    description: 'An informal grouping of diverse islands (Jura, Skye, Orkney, Arran, Mull, Lewis), offering coastal malts that balance maritime saltiness with heather sweet and variable peat profiles.',
    character: 'Brine, seaweed, honey, pepper, heather smoke, and stone fruit.',
    distilleryCount: 8
  }
};

export const DISTILLERIES: Distillery[] = [
  // Speyside (4 active)
  {
    id: 'craigleith',
    name: 'Craigleith',
    region: 'Speyside',
    founded: 1824,
    status: 'Active',
    style: 'Rich & Sherried',
    description: 'Perched on a sandstone ridge overlooking the River Spey, Craigleith is famous for its slow distillation and exclusive use of European oak Oloroso sherry casks.',
    characteristics: ['Dark chocolate', 'Plums', 'Nutmeg', 'Heavy European Oak']
  },
  {
    id: 'speybank',
    name: 'Speybank',
    region: 'Speyside',
    founded: 1876,
    status: 'Active',
    style: 'Light & Floral',
    description: 'A distillery designed to capture the crystalline purity of the high mountain springs. Utilises exceptionally tall copper stills that encourage maximum reflux.',
    characteristics: ['Green apple', 'Elderflower', 'Honey', 'Vanilla']
  },
  {
    id: 'abercorn',
    name: 'Abercorn',
    region: 'Speyside',
    founded: 1891,
    status: 'Active',
    style: 'Wax-rich & Fruity',
    description: 'An old-world distillery that operates traditional worm tubs rather than modern condensers, giving the spirit an heavy, wax-like, and highly complex texture.',
    characteristics: ['Beeswax', 'Dried apricot', 'Marmalade', 'White pepper']
  },
  {
    id: 'deans-vault',
    name: 'Dean’s Vault',
    region: 'Speyside',
    founded: 1902,
    status: 'Active',
    style: 'Spiced & Nutty',
    description: 'A boutique distillery hidden away in a deep Speyside glen, famed for its experimental secondary maturations in rare dessert wine casks.',
    characteristics: ['Roasted almond', 'Toffee', 'Cinnamon', 'Golden raisin']
  },

  // Highlands (4 active)
  {
    id: 'glen-calton',
    name: 'Glen Calton',
    region: 'Highlands',
    founded: 1812,
    status: 'Active',
    style: 'Heather-honeyed & Robust',
    description: 'Situated in the majestic eastern Cairngorms, Glen Calton draws its water through deep beds of purple heather and granite stone.',
    characteristics: ['Heather honey', 'Toasted oat', 'Orange peel', 'Gentle woodsmoke']
  },
  {
    id: 'castle-rock',
    name: 'Castle Rock',
    region: 'Highlands',
    founded: 1845,
    status: 'Active',
    style: 'Oily & Coastal Highlands',
    description: 'Looking out over the rugged northeastern coastline, Castle Rock produces a heavy, waxy spirit with a distinct seaside influence.',
    characteristics: ['Mineral oil', 'Sea salt', 'Lemon thyme', 'Candled ginger']
  },
  {
    id: 'tarbat-ness',
    name: 'Tarbat Ness',
    region: 'Highlands',
    founded: 1883,
    status: 'Active',
    style: 'Earthy & Herbal',
    description: 'Located on the fertile Black Isle, Tarbat Ness works closely with local farmers to malt ancient, historical strains of Scottish barley.',
    characteristics: ['Dry straw', 'Earthy forest floor', 'Eucalyptus', 'Malt biscuit']
  },
  {
    id: 'dunnet-head',
    name: 'Dunnet Head',
    region: 'Highlands',
    founded: 1911,
    status: 'Active',
    style: 'Crisp & Citrusy',
    description: 'The northernmost mainland distillery, exposed to wild winds. It captures a brisk, oceanic spirit with deep sweet barley tones.',
    characteristics: ['Grapefruit zest', 'Lemon verbena', 'Brine', 'Clover honey']
  },

  // Islay (4 active, 1 closed)
  {
    id: 'port-charlotte-old',
    name: 'Port Charlotte Old',
    region: 'Islay',
    founded: 1819,
    status: 'Active',
    style: 'Medicinal & Peat Smoke',
    description: 'A coastal legend with whitewashed warehouses standing right at the sea wall. Famous for intensely peated barley and heavy maritime maturation.',
    characteristics: ['Seaweed', 'Iodine', 'Sweet peat smoke', 'Salt-cured lemon']
  },
  {
    id: 'dunyvaig-castle',
    name: 'Dunyvaig Castle',
    region: 'Islay',
    founded: 1830,
    status: 'Active',
    style: 'Rich, Peated & Fruity',
    description: 'Combining heavy Islay peat with sherry wood maturation, Dunyvaig Castle creates whiskies of monumental power and velvety complexity.',
    characteristics: ['Prunes', 'Campfire smoke', 'Black tea', 'Bacon brine']
  },
  {
    id: 'laggan-bay',
    name: 'Laggan Bay',
    region: 'Islay',
    founded: 1851,
    status: 'Active',
    style: 'Dry, Ashy & Maritime',
    description: 'A remote distillery situated on a sweep of empty sandy bay, relying on pure spring water filtered through deep, ancient moss peat.',
    characteristics: ['White ash', 'Sea salt', 'Crisp pear', 'Soot']
  },
  {
    id: 'kildalton-archive',
    name: 'Kildalton Archive',
    region: 'Islay',
    founded: 1868,
    status: 'Closed',
    style: 'Ethereal Peat & Tropical Fruit',
    description: 'Silenced in 1983, this legendary distillery produced an extraordinarily complex peated spirit that developed exotic tropical fruit notes over decades of sleep.',
    characteristics: ['Mango', 'Pineapple', 'Gentle peat embers', 'Antique leather']
  },

  // Lowlands (3 active, 1 closed)
  {
    id: 'st-bernards',
    name: 'St. Bernard’s',
    region: 'Lowlands',
    founded: 1833,
    status: 'Active',
    style: 'Grassy & Triple-Distilled',
    description: 'An elegant estate distillery in East Lothian that strictly maintains the historic Scottish tradition of triple distillation.',
    characteristics: ['Lemongrass', 'Green melon', 'Crème brûlée', 'Fresh hay']
  },
  {
    id: 'kinross',
    name: 'Kinross',
    region: 'Lowlands',
    founded: 1865,
    status: 'Active',
    style: 'Light & Pastry-sweet',
    description: 'Situated near Loch Leven, Kinross is celebrated for its soft, creamy character and perfect suitability for afternoon sipping.',
    characteristics: ['Butter croissant', 'Vanilla custard', 'Peaches', 'Almond flour']
  },
  {
    id: 'braid-hills',
    name: 'Braid Hills',
    region: 'Lowlands',
    founded: 1920,
    status: 'Active',
    style: 'Herbal & Floral',
    description: 'An urban-fringe distillery capturing the spirit of the old Edinburgh townhouses, relying on pristine basalt-filtered water.',
    characteristics: ['Mint leaves', 'White peach', 'Sweet grass', 'Lemon peel']
  },
  {
    id: 'corstorphine',
    name: 'Corstorphine',
    region: 'Lowlands',
    founded: 1798,
    status: 'Closed',
    style: 'Heavy, Oily & Mineral',
    description: 'Established in the late 18th century and closed during the Great Depression. Its historic spirit is dense, mechanical, and incredibly rich.',
    characteristics: ['Diesel oil', 'Chalk', 'Sultana', 'Dark honey']
  },

  // Campbeltown (2 active)
  {
    id: 'blackford',
    name: 'Blackford',
    region: 'Campbeltown',
    founded: 1872,
    status: 'Active',
    style: 'Oily, Salty & Robust',
    description: 'One of the true survivors of Campbeltown, Blackford retains its original Victorian equipment and heavy direct-fired copper stills.',
    characteristics: ['Salt spray', 'Engine oil', 'Dried fig', 'Peat soot']
  },
  {
    id: 'davaar-island',
    name: 'Davaar Island',
    region: 'Campbeltown',
    founded: 1888,
    status: 'Active',
    style: 'Heavy & Funk-rich',
    description: 'Using long fermentation times and traditional wooden washbacks, Davaar Island crafts a unique, slightly industrial and highly authentic spirit.',
    characteristics: ['Leather jacket', 'Wet clay', 'Salted caramel', 'Smoke']
  },

  // Islands (2 active)
  {
    id: 'skerryvore',
    name: 'Skerryvore',
    region: 'Islands',
    founded: 1840,
    status: 'Active',
    style: 'Briny, Peppery & Honeyed',
    description: 'Vulnerable to the Atlantic gales, this distillery sits on a rocky outcrop and matures its spirit in damp stone dunnage warehouses.',
    characteristics: ['Black pepper', 'Sea air', 'Heather honey', 'Smoked bacon']
  },
  {
    id: 'gigha',
    name: 'Gigha',
    region: 'Islands',
    founded: 1899,
    status: 'Active',
    style: 'Sweet & Coastal',
    description: 'Located on the "Garden Island," this boutique distillery benefits from a mild microclimate and rich, fertile peat soils.',
    characteristics: ['Toasted coconut', 'Lime zest', 'Sea spray', 'Vanilla pod']
  }
];

// Helper to generate the 100 whiskies with pristine luxury profiles.
const generateWhiskies = (): Whisky[] => {
  const list: Whisky[] = [];
  let idCounter = 1;

  // Let's systematically define our 100 whiskies so we have perfect realistic, scholarly data.
  // We will distribute them across the 20 distilleries.
  // Each distillery gets 5 whiskies: varying in Age (10, 12, 15, 18, 21, 25, 30, 40, NAS),
  // Cask Types, ABV, Rarity, Price, and Tasting Notes.

  DISTILLERIES.forEach((dist) => {
    // 5 whiskies per distillery
    const ageOptions = [
      { age: 10, label: '10 Year Old', priceBase: 65, rarity: 1 },
      { age: 12, label: '12 Year Old', priceBase: 85, rarity: 1 },
      { age: 15, label: '15 Year Old', priceBase: 130, rarity: 2 },
      { age: 18, label: '18 Year Old', priceBase: 240, rarity: 3 },
      { age: null, label: 'Cask Reserve (NAS)', priceBase: 95, rarity: 2 },
      { age: 21, label: '21 Year Old', priceBase: 420, rarity: 4 },
      { age: 25, label: '25 Year Old (Archive Series)', priceBase: 780, rarity: 4 },
      { age: 30, label: '30 Year Old (Private Collection)', priceBase: 1450, rarity: 5 },
      { age: 40, label: '40 Year Old (Centenary Reserve)', priceBase: 6800, rarity: 5 }
    ];

    // Pick 5 distinct ages/editions for this distillery to make 100 total
    let chosenAges = [];
    if (dist.status === 'Closed') {
      // Closed distilleries get only ultra-rare aged whiskies (25, 30, 40) plus unique casks
      chosenAges = [
        { age: 25, label: '25 Year Old (Silent Malt)', priceBase: 1800, rarity: 5 },
        { age: 30, label: '30 Year Old (Legacy Edition)', priceBase: 3200, rarity: 5 },
        { age: 40, label: '40 Year Old (The Last Drop)', priceBase: 9500, rarity: 5 },
        { age: null, label: 'The Lost Cask Reserve', priceBase: 2200, rarity: 5 },
        { age: 21, label: '21 Year Old (Historic Release)', priceBase: 1200, rarity: 4 }
      ];
    } else {
      // Active distilleries get a nice mix
      if (dist.id === 'craigleith' || dist.id === 'port-charlotte-old' || dist.id === 'blackford') {
        // Some premium ones get the rare ones
        chosenAges = [
          { age: 12, label: '12 Year Old', priceBase: 90, rarity: 1 },
          { age: 18, label: '18 Year Old', priceBase: 260, rarity: 3 },
          { age: 25, label: '25 Year Old (Heritage Series)', priceBase: 850, rarity: 4 },
          { age: 30, label: '30 Year Old (Distillery Reserve)', priceBase: 1900, rarity: 5 },
          { age: null, label: 'Founder’s Cask Strength', priceBase: 145, rarity: 3 }
        ];
      } else if (dist.id === 'speybank' || dist.id === 'glen-calton' || dist.id === 'skerryvore') {
        chosenAges = [
          { age: 10, label: '10 Year Old', priceBase: 65, rarity: 1 },
          { age: 15, label: '15 Year Old', priceBase: 120, rarity: 2 },
          { age: 18, label: '18 Year Old', priceBase: 220, rarity: 3 },
          { age: 21, label: '21 Year Old', priceBase: 380, rarity: 4 },
          { age: null, label: 'Distiller’s Selection', priceBase: 80, rarity: 2 }
        ];
      } else {
        // General mix
        chosenAges = [
          { age: 12, label: '12 Year Old', priceBase: 75, rarity: 1 },
          { age: 15, label: '15 Year Old', priceBase: 115, rarity: 2 },
          { age: 18, label: '18 Year Old', priceBase: 210, rarity: 3 },
          { age: null, label: 'Private Cask #982', priceBase: 165, rarity: 3 },
          { age: 25, label: '25 Year Old', priceBase: 720, rarity: 4 }
        ];
      }
    }

    chosenAges.forEach((option, idx) => {
      const isCaskStrength = option.label.includes('Cask Strength') || option.label.includes('Cask #') || option.label.includes('Founder’s') || option.label.includes('Lost Cask');
      const abv = isCaskStrength 
        ? Math.round((53.2 + (idCounter % 5) * 1.3) * 10) / 10 
        : (option.age && option.age >= 21) ? 46.0 : 43.0;

      const caskTypes = [
        'Oloroso Sherry Butt',
        'Pedro Ximénez Sherry Hogshead',
        'Ex-Bourbon American Oak Barrel',
        'First-fill Sauternes Wine Barrique',
        'Matured in Spanish Oak, Finished in Vintage Port Pipe',
        'Amarone Wine Cask Finish',
        'Refill Hogshead and Virgin Oak',
        'Ancient Madeira Drum Finish'
      ];
      const cask = caskTypes[(idCounter + idx) % caskTypes.length];
      
      const distYear = option.age ? 2026 - option.age : 2026 - 12 - (idCounter % 8);
      const bottlyYear = 2026;

      const availabilities: ('In Stock' | 'Low Stock' | 'Allocated' | 'Sold Out')[] = ['In Stock', 'Low Stock', 'Allocated'];
      const availability = option.rarity >= 4 
        ? (idCounter % 3 === 0 ? 'Sold Out' as const : 'Allocated' as const) 
        : availabilities[(idCounter) % availabilities.length];

      // Build flavor profiles
      const styleProfile: Whisky['styleProfile'] = [];
      const charKeywords: string[] = [];
      
      if (dist.region === 'Islay') {
        styleProfile.push('Peated', 'Smoky', 'Maritime');
        charKeywords.push('peat', 'ash', 'seaweed', 'brine', 'iodine');
        if (cask.includes('Sherry')) {
          styleProfile.push('Rich', 'Sherried');
          charKeywords.push('raisin', 'dark fruit', 'leather');
        } else {
          styleProfile.push('Dry');
          charKeywords.push('citrus', 'vanilla', 'pepper');
        }
      } else if (dist.region === 'Speyside') {
        styleProfile.push('Rich');
        if (cask.includes('Sherry')) {
          styleProfile.push('Sherried', 'Sweet');
          charKeywords.push('sherry', 'chocolate', 'orange peel', 'fig');
        } else {
          styleProfile.push('Light', 'Floral', 'Citrus');
          charKeywords.push('green apple', 'honey', 'vanilla', 'pear');
        }
      } else if (dist.region === 'Lowlands') {
        styleProfile.push('Light', 'Floral', 'Sweet');
        charKeywords.push('grass', 'lemon', 'cream', 'pastry', 'honey');
      } else if (dist.region === 'Campbeltown') {
        styleProfile.push('Rich', 'Maritime', 'Spiced');
        charKeywords.push('brine', 'oil', 'salted caramel', 'wax', 'clove');
      } else {
        // Highlands & Islands
        styleProfile.push('Rich', 'Spiced');
        charKeywords.push('heather', 'honey', 'oak', 'cinnamon', 'nutmeg');
        if (dist.id === 'skerryvore') {
          styleProfile.push('Maritime', 'Smoky');
          charKeywords.push('brine', 'pepper', 'peat');
        }
      }

      // Format clean, historic rarity criteria
      let rarityCriteria = '';
      if (option.rarity === 5) {
        rarityCriteria = dist.status === 'Closed' 
          ? 'Legendary silent distillery bottling, highly limited remaining active inventory.' 
          : 'Strictly allocated single-cask bottling, individually hand-numbered and certified.';
      } else if (option.rarity === 4) {
        rarityCriteria = 'Highly selected small-batch release with limited national distribution.';
      } else if (option.rarity === 3) {
        rarityCriteria = 'Distillery flagship aged statement, subject to seasonal batch allocation.';
      } else if (option.rarity === 2) {
        rarityCriteria = 'Distinct secondary wood maturation or private single-cask bottling.';
      } else {
        rarityCriteria = 'Signature distillery expression demonstrating classic regional character.';
      }

      // Generate a unique bottle number like EDW-000184
      const paddedId = String(idCounter).padStart(4, '0');
      const bNumber = `${Math.round((idCounter * 7) % 250) + 1} / ${Math.round((idCounter * 12) % 400) + 300}`;
      const totBottles = Math.round((idCounter * 12) % 400) + 300;

      // Tasting notes
      const nose = `Exquisite initial bouquet of ${charKeywords[0] || 'subtle spice'} and ${charKeywords[1] || 'honey'}. Developing elegantly to reveal deep undertones of ${charKeywords[2] || 'toasted oak'} along with a delicate touch of ${charKeywords[3] || 'vanilla'}.`;
      const palate = `The palate is immediately commanding yet silk-textured, bursting with ${charKeywords[1] || 'stewed fruits'} followed by complex waves of ${charKeywords[2] || 'dark cocoa'}. Highly structured with balanced oiliness.`;
      const finish = `Lingering and deeply satisfying. A slow wave of ${charKeywords[0] || 'warm spice'}, punctuated by whispers of dry ${charKeywords[3] || 'oak'} and sweet ${charKeywords[4] || 'caramel'}.`;
      const texture = `Viscous, velvety, and mouth-coating with outstanding structural integrity.`;
      const water = `A single drop of soft water opens the dram beautifully, calming the wood oils and liberating bright notes of orchard fruit and clover honey.`;
      const serve = `Best enjoyed at a precise 18°C in a crystal tulip-shaped whisky glass, allowed to breathe for five minutes before tasting.`;

      // Create synthetic image URL placeholder using seed
      const imgSeed = `whisky_${idCounter}`;
      const imageUrl = `https://picsum.photos/seed/${imgSeed}/600/800`;

      list.push({
        id: `edw-${paddedId}`,
        name: `${dist.name} ${option.label}`,
        distilleryId: dist.id,
        distilleryName: dist.name,
        age: option.age,
        region: dist.region,
        abv,
        size: '70cl',
        bottler: option.label.includes('Private') || option.label.includes('Emporium') ? 'Emporium Private Cask' : (idCounter % 5 === 0 ? 'Independent Bottling' : 'Official Bottling'),
        price: option.priceBase,
        availability,
        rarityLevel: option.rarity as Whisky['rarityLevel'],
        rarityCriteria,
        caskType: cask,
        caskNumber: `EDW-${2020 + (idCounter % 6)}-${100 + idCounter}`,
        bottleNumber: bNumber,
        totalBottles: totBottles,
        distillationYear: distYear,
        bottlingYear: bottlyYear,
        styleProfile,
        characterKeywords: charKeywords,
        tastingNotes: {
          nose,
          palate,
          finish,
          texture,
          water,
          serve
        },
        provenanceNotes: `Acquired directly under strict bond from the cellars at ${dist.name} on Charlotte Square terms. Selected by the Emporium's Edinburgh committee for exceptional purity and regional expression.`,
        imageUrl
      });

      idCounter++;
    });
  });

  return list;
};

export const WHISKIES: Whisky[] = generateWhiskies();

export const JOURNAL_ARTICLES: JournalArticle[] = [
  {
    id: 'art-001',
    category: 'EDINBURGH',
    title: 'The Enlightenment of the Dram',
    subtitle: 'How Edinburgh New Town became the intellectual capital of single malt judgement.',
    author: 'Alasdair MacPherson, FSA Scot',
    date: '14 September 2026',
    readTime: '8 min read',
    summary: 'Explore the historical link between the philosophers of the Scottish Enlightenment and the emergence of refined whisky evaluation in late-18th-century Edinburgh.',
    content: [
      'In the winter of 1782, as the cold winds swept off the Firth of Forth and through the newly constructed streets of Edinburgh’s New Town, a group of scholars, lawyers, and writers gathered in a basement chamber off Charlotte Square. Among them was the philosopher David Hume, whose treatises on human understanding had rewritten the rules of modern thought. But on this night, the subject under scrutiny was not metaphysics, but rather a cask of single malt from the Highlands.',
      'Historically, whisky had been consumed in Scotland as a raw, fiery distillate—often unaged and flavored with mountain herbs. It was in the salons and private libraries of Edinburgh’s Enlightenment that Scotch was first treated not merely as an intoxicant, but as an intellectual craft. The Edinburgh elite began applying the same rigor of taxonomic categorization to the malts of Speyside and Islay as they did to botanical or geological specimens.',
      'The Edinburgh Whisky Emporium was born from this exact tradition. By treating Scotch whisky as a serious subject of culture, craft, and intellectual collecting, we honor the Edinburgh jurists who first established "whisky judgement"—the belief that a dram should be weighed, examined, and appreciated with the same discipline as a fine legal argument or an astronomical theorem.',
      'Today, as you walk across the sandstone threshold of our Charlotte Square townhouse, you enter a space designed to reflect that golden era. It is not a place for rapid commerce, but for the quiet, deliberate contemplation of Scotland’s finest liquid history.'
    ],
    pullQuote: "Whisky is not merely spirits; it is Scotland's contribution to the aesthetics of human sensory philosophy.",
    footnotes: [
      '1. Letters of David Hume, Vol. II, p. 114 (Oxford University Press).',
      '2. R. MacLean, "The Urban Dram: Edinburgh Tavern Culture in the Eighteenth Century" (Edin. Hist. Review, 1994).'
    ]
  },
  {
    id: 'art-002',
    category: 'COLLECTING',
    title: 'Silent Warehouses, Whispering Spirits',
    subtitle: 'The delicate and lucrative art of collecting whisky from closed Scottish distilleries.',
    author: 'Lady Fiona Kennedy',
    date: '28 August 2026',
    readTime: '11 min read',
    summary: 'A definitive guide to identifying, authenticating, and cellaring historic bottlings from lost distilleries like Port Ellen, Brora, and our featured Corstorphine.',
    content: [
      'There is a unique pathos in tasting a whisky from a distillery that no longer exists. Every drop drawn from a cask distilled at a silent distillery is a finite resource—a liquid clock ticking inexorably toward zero. This rarity is what drives the contemporary market for "ghost distilleries," where bottles are treated with the reverence of Renaissance drawings.',
      'When collecting silent malts, provenance is paramount. In the early 1980s, due to a global economic downturn known inside the industry as the "Whisky Loch," many of Scotland’s most historic distilleries were closed and dismantled. At the time, their stock was viewed as surplus; today, it represents the absolute pinnacle of luxury collecting.',
      'To build a collection of silent malts, one must look beyond the label. Examine the bottling year, the fill level, and the importer seals. Whiskies like our exclusive Corstorphine 1998 single cask or the Kildalton Archive releases contain esters and phenols that cannot be recreated today, because the original copper stills have long since been melted down and the warehouses returned to the Scottish soil.',
      'Our advice to clients in the Emporium Vault is always to divide their collection into two distinct categories: the Archive of Record, which is cellared for future generations, and the Library of Devotion—bottles that, despite their extreme rarity, are destined to be opened and shared with close friends under the soft light of a coal fire.'
    ],
    pullQuote: "Every bottle of a silent distillery is a museum where the exhibits are slowly drank away.",
    footnotes: [
      '1. H. Evans, "The Great Liquidation: The Silent Malts of 1983" (Whisky Quarterly, 2012).',
      '2. Empirical database of silent distillery auction records (Edinburgh Whisky Institute Archive).'
    ]
  },
  {
    id: 'art-003',
    category: 'DISTILLERIES',
    title: 'The Secret of the Worm Tubs',
    subtitle: 'Why traditional, inefficient cooling methods produce Scotland’s heaviest and most waxy spirits.',
    author: 'Dr. Ian Covington',
    date: '02 July 2026',
    readTime: '6 min read',
    summary: 'An exploration of worm tubs, the antique copper coils submerged in cold water tanks that preserve sulfur compounds and give Speyside malts their legendary waxy mouthfeel.',
    content: [
      'In the modern, highly efficient world of distilling, most Scotch distilleries rely on shell-and-tube condensers. These efficient vertical tubes maximize contact between the hot alcohol vapor and cool copper, stripping out heavy sulfur compounds to produce a clean, light, and predictable spirit.',
      'But a handful of traditionalists—including Abercorn and Blackford—refuse to modernize. They cling to "worm tubs"—monumental coiled copper pipes submerged in giant wooden vats of cold water outside the still house. Because the vapor passes through the worm tubs quickly with minimal copper contact, many heavy, waxy, and sulfurous compounds are preserved in the final spirit.',
      'Though initially meaty and sulfurous when young, these compounds undergo a spectacular metamorphosis during long oak maturation. Over 18 or 25 years in active sherry wood, they resolve into a heavy, waxy mouthfeel that coats the palate like liquid velvet. To taste a worm-tub malt is to understand the historic, greasy texture of 19th-century Scotch.'
    ]
  }
];

export const TASTING_EXPERIENCES: TastingExperience[] = [
  {
    id: 'taste-01',
    title: 'An Introduction to Scotch Heritage',
    subtitle: 'A foundational journey across the six whisky regions of Scotland.',
    duration: '1.5 Hours',
    whiskyCount: 6,
    price: 85,
    location: 'The Ground-Floor Library',
    availability: 'Daily at 14:00 and 17:00',
    description: 'Perfect for enthusiasts looking to ground their understanding of Scotch. This guided tasting explores the distinct regional characteristics of Speyside, Highlands, Lowlands, Islay, Campbeltown, and the Islands, led by our senior tasting curator.',
    includes: [
      'Six exceptional single malts (12 to 18 years old)',
      'A masterclass on regional flavor maps and distillation science',
      'Artisanal Scottish oatcakes and spring water pairing',
      'An Emporium tasting notebook and tasting pencil'
    ]
  },
  {
    id: 'taste-02',
    title: 'The Rare & Old Historic Flight',
    subtitle: 'An elite tasting of whiskies aged 25 years and over, including silent distilleries.',
    duration: '2.5 Hours',
    whiskyCount: 5,
    price: 320,
    location: 'The Rare Whisky Vault',
    availability: 'Thursdays and Saturdays at 19:00',
    description: 'An extraordinary experience designed for serious collectors and connoisseurs. We unlock the iron gates of our Charlotte Square Vault to pour five of the rarest and oldest whiskies in our collection, including a legendary bottling from a closed distillery.',
    includes: [
      'Five hand-selected whiskies aged 25, 30, and 40 years old',
      'Exclusive access to the Private Vault collection',
      'A presentation on rare bottle authentication and market collecting',
      'A premium cured-meat and dark chocolate sensory pairing board',
      'A signed Certificate of Attendance from our Master of Malts'
    ]
  },
  {
    id: 'taste-03',
    title: 'The Peat & Maritime Masterclass',
    subtitle: 'A sensory exploration of Islay, Campbeltown, and rugged coastal malts.',
    duration: '2 Hours',
    whiskyCount: 6,
    price: 135,
    location: 'The Stone Cellar Room',
    availability: 'Wednesdays and Fridays at 18:00',
    description: 'For those who love sea spray, iodine, and campfire embers. This masterclass dives deep into the geology of Scottish peatlands, the traditional practice of floor malting, and the heavy maritime maturation that defines coastal Scotch.',
    includes: [
      'Six heavily peated, cask-strength, and coastal single malts',
      'An in-depth study of phenol parts per million (PPM) and peat smoke chemistry',
      'Hebridean smoked salmon and salted caramel truffle pairing',
      'A custom copper pipette to take home'
    ]
  }
];
