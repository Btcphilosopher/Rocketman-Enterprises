# THE EDINBURGH WHISKY EMPORIUM
## THE HOUSE OF SCOTCH.
### Rare whisky. Edinburgh judgement.

An elite digital representation of our fictional Edinburgh-based whisky institution, showcasing exceptional Scotch whiskies, scholarly editorial articles, private tasting booking systems, and detailed client portfolio collection management.

---

## 1. BRAND POSITIONING & VOICE
The Edinburgh Whisky Emporium presents itself as a serious house for serious Scotch, drawing intellectual inspiration from the Scottish Enlightenment, Edinburgh New Town sandstone, and Georgian architectural proportion. We treat Scotch as a subject of culture, taxonomic craft, and highly disciplined collecting.

---

## 2. TECHNICAL ARCHITECTURE

### Frontend Stack
- **Framework:** React 19, TypeScript, Next.js 15+ (App Router, Standalone deployment)
- **Styling:** Tailwind CSS v4, custom luxury `@theme` palette (`--color-walnut`, `--color-ivory`, `--color-forest`, `--color-brass`)
- **Animations:** Framer Motion (`motion/react`) for restrained, elegant, quiet luxury fades and drawer transitions
- **Icons:** Premium standard vectors from `lucide-react`

### State Management & Lifecycle
- **Global Context:** `EmporiumProvider` coordinates global app states:
  - Age gating status (verified 18+ compliance)
  - Retail Basket drawer tracking (simulated quantities, subtotals, custom delivery checks)
  - Customer Vault (`My Collection`) with dynamic statistic counts (Total, Regions, Distilleries, Seal Status)
  - Active screen router navigation ('home' | 'whisky' | 'rare' | 'distilleries' | 'library' | 'tasting' | 'house' | 'collection' | 'checkout' | 'admin' | 'contact')
  - Curation logs (real-time order checkout ledgers, tasting seat bookings)

### Database & Seed Models (`/lib/data/whiskyData.ts`)
- **Synthetic Dataset (EDINBURGH-EMPORIUM-DEMO-001):**
  - **100 Fictional Whisky Records:** Custom ages (10, 12, 15, 18, 21, 25, 30, 40, NAS), casks (Oloroso, PX Sherry, Sauternes, Port pipes, Madeira drums), ABV, hand-numbered batches, and detailed sensory dossiers.
  - **20 Fictional Distilleries:** Grouped by regions (Speyside, Highlands, Lowlands, Islay, Campbeltown, Islands) with history, status (Active/Closed), and style styles.
  - **Treatises & Articles:** Fine publishing articles linking Edinburgh Enlightenment scholars (David Hume) with modern whisky judgement taxonomies.

---

## 3. ADVANCED FEATURES

### 1. Age Verification Gateway
- Regulatory-compliant gate preventing interface access until birthdate verification confirms the client is 18+ years or older. Handles standard device cookie memory.

### 2. Preference-Based Curation Engine
- A 7-step interactive questionnaire asking:
  - Flavor style preferences (Rich, Floral, Peated, Sherried, Citrus, Maritime)
  - Peat smoke tolerance (None vs Heavy)
  - Regional focus, target ageStatements, budget, occasion, and collecting intention
  - Returns the top 3 matching bottles with custom-generated, scholarly committee matching explanations.

### 3. digital Certified Certificate of Provenance
- Clicking on any bottle launches a museum-catalog specification sheet. Inside the **Provenance** tab, a double-bordered, double-lined digital Certificate of Provenance is rendered with unique bottle serial numbers, distillation/bottling years, cask details, and registrar signatures. Fully responsive and prints perfectly on parchment paper via `window.print()` and custom CSS `@media print` rule exclusions.

### 4. Interactive Regional Map
- CSS/Vector mapping of Scotland's six whisky regions, showcasing detailed character notes, active/closed counts, and direct-buying catalog listings.

### 5. Private Tasting Booking
- Wizard coordinating premium Charlotte Square tasting experiences (Heritage Foundational, Rare & Old Vault flights, Peat masterclass), date schedules, guest counters, dietary notes, and ticket receipt creation.

---

## 4. LOCAL DEVELOPMENT & DEPLOYMENT

### Prerequisites
- Node.js 18+
- npm

### Installation
```bash
# Install package dependencies
npm install

# Run Node.js local dev server
npm run dev
```

### Standalone Docker Production Build
```dockerfile
# Simulated Dockerfile
FROM node:18-alpine AS base
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM node:18-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=base /app/.next/standalone ./
COPY --from=base /app/.next/static ./.next/static
EXPOSE 3000
CMD ["node", "server.js"]
```

---

## 5. DOCUMENTATION DIRECTIVE

### Accessibility Compliance (WCAG)
- Designed with rigorous high-contrast typography, semantic HTML elements (`<main>`, `<header>`, `<footer>`), keyboard navigation support, and fully descriptive ARIA tags.

### Performance Optimization
- Native Next.js Image component optimization with strict `referrerPolicy="no-referrer"` handling.
- Standalone standalone standalone caching layers and lazy layout transitions under Framer Motion.

### Security Architecture
- Simulated sandbox environment containing no raw client secret databases. Simulated payment forms utilize dummy values and perform zero live routing, protecting user privacy in bond.

---
**THE EDINBURGH WHISKY EMPORIUM**  
*The House of Scotch. Rare Whisky. Edinburgh Judgement.*
