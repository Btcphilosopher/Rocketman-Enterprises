'use client';

import React, { useState } from 'react';
import { Whisky, DISTILLERIES } from '@/lib/data/whiskyData';
import { X, ShieldCheck, Printer, Heart, ArrowRight, Truck, BookOpen, AlertCircle } from 'lucide-react';
import { useEmporium } from './EmporiumProvider';

interface ProductDetailModalProps {
  whisky: Whisky;
  onClose: () => void;
}

export default function ProductDetailModal({ whisky, onClose }: ProductDetailModalProps) {
  const { addToBasket, addToCollection, myCollection } = useEmporium();
  const [activeTab, setActiveTab] = useState<'the-whisky' | 'provenance' | 'tasting' | 'distillery'>('the-whisky');
  const [postcode, setPostcode] = useState('');
  const [deliveryResult, setDeliveryResult] = useState<string | null>(null);
  const [inCollection, setInCollection] = useState(myCollection.some(item => item.whiskyId === whisky.id));

  // Find distillery info
  const distillery = DISTILLERIES.find(d => d.id === whisky.distilleryId) || DISTILLERIES[0];

  const handleDeliveryCheck = (e: React.FormEvent) => {
    e.preventDefault();
    if (!postcode.trim()) return;
    
    const formatted = postcode.trim().toUpperCase();
    // Simulated delivery check
    if (formatted.startsWith('EH') || formatted.startsWith('G') || formatted.startsWith('AB') || formatted.startsWith('IV') || formatted.startsWith('DD')) {
      setDeliveryResult('AVAILABLE — Secure Next-Day courier delivery from Charlotte Square.');
    } else if (formatted.match(/^[A-Z]{1,2}[0-9]/)) {
      setDeliveryResult('AVAILABLE — Standard UK Courier delivery (3-5 business days).');
    } else if (['US', 'USA', 'UNITED STATES', 'CANADA', 'EUROPE', 'DE', 'FR', 'GERMANY', 'FRANCE'].includes(formatted)) {
      setDeliveryResult('RESTRICTIONS APPLY — Special export customs and duties apply at checkout.');
    } else {
      setDeliveryResult('AVAILABLE — Royal Mail Special Insured delivery (2-4 business days).');
    }
  };

  const handlePrintCertificate = () => {
    window.print();
  };

  const handleSaveToCollection = () => {
    if (inCollection) return;
    addToCollection({
      whiskyId: whisky.id,
      whiskyName: whisky.name,
      distilleryName: whisky.distilleryName,
      region: whisky.region,
      purchaseDate: new Date().toISOString().split('T')[0],
      purchasePrice: whisky.price,
      bottleNumber: whisky.bottleNumber,
      tastingNotes: `Acquired for physical collection cellaring. ${whisky.tastingNotes.nose}`,
      opened: false,
      provenance: whisky.provenanceNotes,
      location: 'Charlotte Square Vault'
    });
    setInCollection(true);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-walnut/85 backdrop-blur-sm flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-200">
      
      {/* Modal Card wrapper */}
      <div className="bg-ivory text-walnut w-full max-w-5xl rounded border-fine-heavy relative shadow-walnut-heavy flex flex-col md:overflow-hidden max-h-[90vh] print:max-h-none print:h-auto print:border-none print:shadow-none print:bg-white">
        
        {/* Header Close button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-walnut hover:text-brass p-1 z-30 transition-colors no-print"
          title="Close Catalog File"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Scroll Container */}
        <div className="overflow-y-auto flex-1 p-6 md:p-12 print:p-0">
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            
            {/* LEFT SIDE: Bottle Image & Simulated Bottle Liquid render */}
            <div className="md:col-span-5 flex flex-col items-center justify-center p-8 bg-walnut/[0.03] border border-brass/10 rounded min-h-[350px] relative print:hidden">
              {/* Corner fine markings */}
              <div className="absolute top-2 left-2 w-3 h-3 border-t border-l border-brass/35"></div>
              <div className="absolute top-2 right-2 w-3 h-3 border-t border-r border-brass/35"></div>
              <div className="absolute bottom-2 left-2 w-3 h-3 border-b border-l border-brass/35"></div>
              <div className="absolute bottom-2 right-2 w-3 h-3 border-b border-r border-brass/35"></div>

              {/* Simulated Liquid Render Container */}
              <div className="w-24 h-[300px] border border-brass/50 rounded-t-[2.5rem] rounded-b-lg bg-amber-950/5 relative flex flex-col items-center justify-end py-10 shadow-lg">
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-amber-700/80 via-amber-600/50 to-amber-500/10 h-[82%] rounded-b-lg"></div>
                
                {/* Simulated Cap */}
                <div className="w-8 h-10 bg-walnut/90 rounded-t border-b border-brass -mt-[170px] z-20 flex items-center justify-center">
                  <div className="w-full h-0.5 bg-brass/30 my-1"></div>
                </div>

                {/* Simulated Glass Refraction */}
                <div className="absolute top-4 left-2 w-1.5 h-64 bg-white/20 rounded-full filter blur-[1px]"></div>

                {/* Museum Style Label */}
                <div className="w-[84%] bg-ivory/95 border-fine p-2 text-center shadow-md z-10 font-serif leading-none">
                  <p className="text-[7px] uppercase tracking-[0.1em] text-brass-dark">EDINBURGH EMPORIUM</p>
                  <p className="font-bold text-[9px] text-walnut uppercase mt-1">{whisky.distilleryName}</p>
                  <div className="w-6 h-[0.5px] bg-brass/60 mx-auto my-1.5"></div>
                  <p className="text-[7px] text-walnut/80 tracking-widest">{whisky.age ? `${whisky.age} YEARS OLD` : 'CASK RESERVE'}</p>
                  <p className="text-[5px] text-brass font-mono mt-1">CASK NO. {whisky.caskNumber.substring(4, 10)}</p>
                </div>
              </div>

              <div className="mt-6 text-center space-y-1">
                <p className="text-[10px] font-mono uppercase tracking-widest text-walnut/50">ARCHIVE REFERENCE ID</p>
                <p className="text-xs font-semibold font-mono text-brass-dark">{whisky.id.toUpperCase()}</p>
              </div>
            </div>

            {/* RIGHT SIDE: Bottle Specs & Metadata */}
            <div className="md:col-span-7 flex flex-col justify-between h-full space-y-6 print:col-span-12">
              <div>
                <div className="flex items-center space-x-2.5 mb-2 no-print">
                  <span className="text-[10px] tracking-widest uppercase text-brass font-bold">
                    {whisky.region} SINGLE MALT
                  </span>
                  <span className="text-walnut/30">•</span>
                  <span className="text-[10px] tracking-widest font-mono text-walnut/60 uppercase">
                    {whisky.bottler}
                  </span>
                </div>

                <h2 className="font-serif text-3xl md:text-4xl tracking-tight text-walnut leading-tight font-light">
                  {whisky.name}
                </h2>

                {/* Star rating explanations */}
                <div className="flex items-center space-x-1.5 mt-2.5 mb-6">
                  <span className="text-xs text-brass font-semibold tracking-wider font-mono">
                    {'★'.repeat(whisky.rarityLevel)}
                  </span>
                  <span className="text-[10px] text-walnut/50 font-serif italic">
                    — Tier {whisky.rarityLevel} Rarity ({whisky.rarityCriteria})
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 py-4 border-t border-b border-brass/15 bg-brass/5 px-4 mb-6">
                  <div>
                    <span className="block text-[9px] uppercase tracking-widest text-brass-dark">AGE</span>
                    <span className="font-serif text-sm font-semibold">{whisky.age ? `${whisky.age} Years` : 'NAS'}</span>
                  </div>
                  <div>
                    <span className="block text-[9px] uppercase tracking-widest text-brass-dark">STRENGTH</span>
                    <span className="font-serif text-sm font-semibold">{whisky.abv}% ABV</span>
                  </div>
                  <div>
                    <span className="block text-[9px] uppercase tracking-widest text-brass-dark">VOLUME</span>
                    <span className="font-serif text-sm font-semibold">{whisky.size}</span>
                  </div>
                  <div>
                    <span className="block text-[9px] uppercase tracking-widest text-brass-dark">AVAILABILITY</span>
                    <span className={`text-xs uppercase font-semibold ${whisky.availability === 'In Stock' ? 'text-forest' : 'text-amber-800'}`}>{whisky.availability}</span>
                  </div>
                </div>

                <p className="text-2xl font-serif tracking-tight text-walnut mb-6">
                  £{whisky.price.toLocaleString()} <span className="text-xs text-walnut/45 uppercase tracking-widest font-sans font-normal font-mono">GBP</span>
                </p>

                {/* Primary Actions Row */}
                <div className="flex flex-col sm:flex-row gap-3 no-print">
                  <button
                    onClick={() => {
                      if (whisky.availability !== 'Sold Out') {
                        addToBasket(whisky, 1);
                      }
                    }}
                    disabled={whisky.availability === 'Sold Out'}
                    className={`flex-1 py-3 text-xs uppercase tracking-widest font-bold transition-colors ${
                      whisky.availability === 'Sold Out'
                        ? 'bg-walnut/20 text-walnut/40 border border-walnut/10 cursor-not-allowed'
                        : 'bg-walnut hover:bg-forest text-ivory border border-brass shadow-md hover:shadow-lg'
                    }`}
                  >
                    {whisky.availability === 'Sold Out' ? 'Allocated & Sold Out' : 'Acquire for Basket'}
                  </button>

                  <button
                    onClick={handleSaveToCollection}
                    disabled={inCollection}
                    className="py-3 px-4 border border-brass text-walnut hover:bg-brass/5 text-xs uppercase tracking-widest font-bold transition-all flex items-center justify-center space-x-1.5"
                  >
                    <Heart className={`w-4 h-4 ${inCollection ? 'fill-brass text-brass' : ''}`} />
                    <span>{inCollection ? 'In Your Private Vault' : 'Secure in My Vault'}</span>
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* LOWER TABS SECTION */}
          <div className="mt-12 border-t border-brass/25 pt-6">
            {/* Tab header buttons */}
            <div className="flex border-b border-brass/10 space-x-6 pb-2 mb-6 no-print">
              {[
                { id: 'the-whisky', label: 'THE WHISKY' },
                { id: 'provenance', label: 'PROVENANCE & CERTIFICATE' },
                { id: 'tasting', label: 'TASTING NOTES' },
                { id: 'distillery', label: 'DISTILLERY PROFILE' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`text-[10px] font-bold tracking-[0.2em] uppercase pb-2 transition-all ${
                    activeTab === tab.id 
                      ? 'text-brass border-b-2 border-brass' 
                      : 'text-walnut/60 hover:text-brass'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* TAB CONTENT: The Whisky & Story */}
            {activeTab === 'the-whisky' && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start animate-in fade-in duration-200">
                <div className="md:col-span-7 space-y-4">
                  <h4 className="font-serif text-lg text-walnut">Selection Story</h4>
                  <p className="text-xs text-walnut/80 leading-relaxed font-sans">
                    {whisky.provenanceNotes}
                  </p>
                  <p className="text-xs text-walnut/80 leading-relaxed font-sans">
                    Every element of this batch was curated directly under Charlotte Square supervision. Our Edinburgh assessors selected this expression for its pristine fidelity to classic regional profiles, utilizing non-chill filtered methods to preserve fragile cask esters.
                  </p>
                </div>
                <div className="md:col-span-5 bg-brass/5 border border-brass/25 p-6 rounded space-y-4 no-print">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-brass-dark">CHECK DELIVERY FEASIBILITY</h4>
                  <form onSubmit={handleDeliveryCheck} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Postcode or Country"
                      value={postcode}
                      onChange={(e) => setPostcode(e.target.value)}
                      className="bg-transparent border border-brass/40 text-xs p-2 focus:outline-none flex-1 text-walnut focus:border-brass rounded"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-walnut text-ivory uppercase tracking-widest text-[9px] font-bold hover:bg-forest rounded transition-colors"
                    >
                      Check
                    </button>
                  </form>
                  {deliveryResult && (
                    <div className="text-[11px] text-walnut/90 font-serif border-t border-brass/10 pt-2.5 flex items-start space-x-1">
                      <Truck className="w-3.5 h-3.5 text-brass mt-0.5 flex-shrink-0" />
                      <span>{deliveryResult}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB CONTENT: Certificate of Provenance */}
            {activeTab === 'provenance' && (
              <div className="space-y-6 animate-in fade-in duration-200">
                <div className="flex justify-between items-center no-print">
                  <p className="text-xs text-walnut/60 font-serif italic">This document serves as your official acquisition deed. Prints perfectly on fine parchment.</p>
                  <button 
                    onClick={handlePrintCertificate}
                    className="flex items-center space-x-1.5 border border-brass text-walnut hover:bg-brass/5 text-[10px] font-bold px-3 py-1.5 rounded uppercase tracking-wider"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Deed</span>
                  </button>
                </div>

                {/* THE CERTIFICATE (PRINTABLE) */}
                <div className="w-full border-fine-heavy bg-[#fdfdfc] p-8 md:p-12 relative shadow-sm overflow-hidden border-double border-4 select-none print:p-0 print:border-none print:shadow-none">
                  {/* Watermark Logo */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none">
                    <BookOpen className="w-[80%] h-[80%] text-walnut" />
                  </div>

                  <div className="text-center space-y-4">
                    <p className="text-[10px] uppercase tracking-[0.4em] text-brass">EDINBURGH · SCOTLAND</p>
                    <h5 className="font-serif text-3xl tracking-tight text-walnut">THE EDINBURGH WHISKY EMPORIUM</h5>
                    <h6 className="font-serif text-lg italic tracking-widest text-brass-dark">CERTIFICATE OF PROVENANCE</h6>
                    
                    <div className="w-32 h-[1px] bg-brass/30 mx-auto my-6"></div>

                    <p className="text-xs font-serif italic max-w-lg mx-auto text-[#1c140e]/80 leading-relaxed">
                      {"\"This document certifies that the hand-numbered single malt whisky described below represents an authentic bottle, acquired directly under bond from Charlotte Square, Edinburgh.\""}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6 my-10 border-t border-b border-brass/15 py-6 font-mono text-xs">
                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark mb-1">DEED REF</span>
                      <span className="font-bold text-walnut">EDW-{whisky.id.split('-')[1]}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark mb-1">DISTILLERY</span>
                      <span className="font-bold text-walnut">{whisky.distilleryName}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark mb-1">DISTILLED / BOTTLED</span>
                      <span className="font-bold text-walnut">{whisky.distillationYear} / {whisky.bottlingYear}</span>
                    </div>
                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark mb-1">BOTTLE BATCH NO</span>
                      <span className="font-bold text-walnut">{whisky.bottleNumber}</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-serif text-xs mb-8">
                    <div>
                      <span className="block font-mono text-[8px] uppercase tracking-widest text-brass-dark mb-1">CASK ASSIGNMENT</span>
                      <p className="text-walnut/90 font-medium leading-relaxed">{whisky.caskType}</p>
                    </div>
                    <div>
                      <span className="block font-mono text-[8px] uppercase tracking-widest text-brass-dark mb-1">CASK NO.</span>
                      <p className="text-walnut/90 font-mono font-bold">{whisky.caskNumber}</p>
                    </div>
                    <div>
                      <span className="block font-mono text-[8px] uppercase tracking-widest text-brass-dark mb-1">EDINBURGH COMMITTEE DEED</span>
                      <p className="text-walnut/80 italic leading-relaxed">{"\"Passed with unanimous recommendation on terms of peerless regional character.\""}</p>
                    </div>
                  </div>

                  <div className="pt-8 border-t border-brass/10 flex flex-col sm:flex-row items-center justify-between gap-6">
                    <div className="flex items-center space-x-2 text-forest">
                      <ShieldCheck className="w-5 h-5 text-brass" />
                      <span className="font-mono text-[9px] tracking-widest uppercase font-bold text-walnut">SECURE ARCHIVE STATUS</span>
                    </div>

                    <div className="flex space-x-12">
                      <div className="text-center font-serif">
                        <div className="text-sm font-semibold text-brass-dark italic">Alasdair MacPherson</div>
                        <div className="w-24 h-[1px] bg-brass/30 my-1 mx-auto"></div>
                        <p className="text-[8px] font-mono uppercase tracking-widest text-walnut/50">Master of Malts</p>
                      </div>
                      <div className="text-center font-serif">
                        <div className="text-sm font-semibold text-brass-dark italic">Charlotte Square</div>
                        <div className="w-24 h-[1px] bg-brass/30 my-1 mx-auto"></div>
                        <p className="text-[8px] font-mono uppercase tracking-widest text-walnut/50">Emporium Registrar</p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 text-center border-t border-brass/5 pt-4">
                    <p className="text-[8px] font-mono tracking-wide text-walnut/30">
                      THE EDINBURGH WHISKY EMPORIUM REGISTERED UNDER THE ALCOHOL LICENSING ACT OF SCOTLAND NO. SC-1782-EE.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT: Tasting Notes */}
            {activeTab === 'tasting' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start animate-in fade-in duration-200">
                <div className="space-y-4">
                  <h4 className="font-serif text-lg text-walnut">The Sensory Dossier</h4>
                  
                  <div className="space-y-4">
                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">NOSE</span>
                      <p className="text-xs text-walnut/85 leading-relaxed font-serif italic mt-1 bg-brass/[0.02] p-2.5 rounded border-l-2 border-brass">
                        {whisky.tastingNotes.nose}
                      </p>
                    </div>

                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">PALATE</span>
                      <p className="text-xs text-walnut/85 leading-relaxed font-serif italic mt-1 bg-brass/[0.02] p-2.5 rounded border-l-2 border-brass">
                        {whisky.tastingNotes.palate}
                      </p>
                    </div>

                    <div>
                      <span className="block text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">FINISH</span>
                      <p className="text-xs text-walnut/85 leading-relaxed font-serif italic mt-1 bg-brass/[0.02] p-2.5 rounded border-l-2 border-brass">
                        {whisky.tastingNotes.finish}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4 bg-brass/5 border border-brass/20 p-6 rounded">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-brass-dark mb-4 flex items-center space-x-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-brass" />
                    <span>SERVING PROTOCOLS</span>
                  </h4>

                  <div className="space-y-3 font-sans text-xs">
                    <div>
                      <strong className="block text-[10px] uppercase text-walnut/70 tracking-wider">TEXTURE IN OAK</strong>
                      <p className="text-walnut/80 mt-1 leading-relaxed">{whisky.tastingNotes.texture}</p>
                    </div>
                    <div>
                      <strong className="block text-[10px] uppercase text-walnut/70 tracking-wider">WATER RESPONSIVENESS</strong>
                      <p className="text-walnut/80 mt-1 leading-relaxed">{whisky.tastingNotes.water}</p>
                    </div>
                    <div>
                      <strong className="block text-[10px] uppercase text-walnut/70 tracking-wider">COMMITTEE SERVING RECOMMENDATION</strong>
                      <p className="text-walnut/80 mt-1 leading-relaxed">{whisky.tastingNotes.serve}</p>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t border-brass/10 flex items-center gap-1.5 text-[10px] text-walnut/50 font-serif italic">
                    <AlertCircle className="w-3.5 h-3.5 text-brass flex-shrink-0" />
                    <span>Demo sensory parameters explicitly compiled by our Edinburgh curation board.</span>
                  </div>
                </div>
              </div>
            )}

            {/* TAB CONTENT: Distillery Profile */}
            {activeTab === 'distillery' && (
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start animate-in fade-in duration-200">
                <div className="md:col-span-8 space-y-4">
                  <span className="text-[9px] uppercase tracking-widest text-brass font-bold">ESTABLISHED {distillery.founded}</span>
                  <h4 className="font-serif text-2xl text-walnut">{distillery.name} Distillery</h4>
                  <p className="text-xs text-walnut/85 leading-relaxed font-sans">
                    {distillery.description}
                  </p>
                  <p className="text-xs text-walnut/85 leading-relaxed font-sans">
                    Located in the legendary <strong className="text-brass-dark">{distillery.region}</strong> region, {distillery.name} has maintained small-batch distillation procedures for centuries. Today, it remains a jewel of traditional Scotch architecture and copper craftsmanship, operating under direct-fire stills.
                  </p>
                </div>

                <div className="md:col-span-4 bg-walnut/5 border border-brass/20 p-5 rounded space-y-4">
                  <h5 className="text-[10px] font-bold uppercase tracking-widest text-brass-dark">DISTILLERY CHARACTERISTICS</h5>
                  <div className="flex flex-wrap gap-1.5">
                    {distillery.characteristics.map(char => (
                      <span key={char} className="text-[10px] bg-ivory border border-brass/30 px-2.5 py-1 text-walnut rounded-full font-serif font-semibold italic">
                        {char}
                      </span>
                    ))}
                  </div>
                  <div className="text-[10px] space-y-1 text-walnut/60 font-mono">
                    <p>STATUS: <span className={distillery.status === 'Active' ? 'text-forest font-bold' : 'text-red-700 font-bold'}>{distillery.status.toUpperCase()}</span></p>
                    <p>DISTILLATION STYLE: {distillery.style.toUpperCase()}</p>
                  </div>
                </div>
              </div>
            )}
          </div>

        </div>
      </div>

    </div>
  );
}
