'use client';

import React, { useState } from 'react';
import { useEmporium } from './EmporiumProvider';
import { WHISKIES } from '@/lib/data/whiskyData';
import { Users, FileText, Calendar, TrendingUp, ShieldAlert, Check, Settings } from 'lucide-react';

export default function AdminView() {
  const { ordersLog, bookingsLog } = useEmporium();
  const [role, setRole] = useState<'CURATOR' | 'ADMIN' | 'BUYER' | 'EDITOR' | 'STORE_MANAGER'>('CURATOR');
  const [tempAvailability, setTempAvailability] = useState<{ [key: string]: string }>({});

  const roles = [
    { value: 'CURATOR' as const, label: 'Curator', desc: 'Authorized to review archive logs, edit tasting monographs, and sign Certificates of Provenance.' },
    { value: 'ADMIN' as const, label: 'Super Admin', desc: 'Full core systems access, audit logging controls, and financial compliance overrides.' },
    { value: 'BUYER' as const, label: 'Whisky Buyer', desc: 'Clearance to negotiate private casks, adjust global pricing sheets, and review low-stock reports.' },
    { value: 'EDITOR' as const, label: 'Journal Editor', desc: 'Authorized to compose monographs, publish treatises, and edit pull quotes.' },
    { value: 'STORE_MANAGER' as const, label: 'Store Manager', desc: 'Monitors courier scheduling, checks door age-ID compliance logs, and clears tasting bookings.' }
  ];

  const handleToggleStock = (whiskyId: string) => {
    setTempAvailability(prev => {
      const current = prev[whiskyId] || 'In Stock';
      const next = current === 'In Stock' ? 'Sold Out' : 'In Stock';
      return { ...prev, [whiskyId]: next };
    });
  };

  const activeRoleInfo = roles.find(r => r.value === role) || roles[0];

  // Calculate stats
  const totalSimSales = ordersLog.reduce((sum, o) => sum + o.totalPaid, 0);

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">MANAGEMENT TERMINAL</span>
        <h2 className="font-serif text-3xl md:text-4xl">Secretariat Office</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"The administrative vault of the Charlotte Square Committee. Strictly confidential.\""}
        </p>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8 space-y-8">
        
        {/* ROLE SECTOR CHANGER */}
        <div className="border-fine bg-ivory p-6 rounded shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-brass/10 pb-3 gap-3">
            <span className="text-xs uppercase font-bold tracking-widest text-walnut flex items-center space-x-1.5">
              <Settings className="w-4 h-4 text-brass" />
              <span>COMMTTEE ROLE SELECTOR</span>
            </span>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as any)}
              className="bg-ivory border border-brass/45 text-xs p-1.5 focus:outline-none rounded text-walnut font-bold"
            >
              {roles.map(r => <option key={r.value} value={r.value}>{r.label.toUpperCase()}</option>)}
            </select>
          </div>

          <div className="p-4 border border-brass/25 bg-brass/5 rounded flex items-start space-x-3">
            <ShieldAlert className="w-5 h-5 text-brass flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-xs font-bold text-walnut uppercase tracking-wider">CLEARANCE STATUS: APPROVED ({role})</p>
              <p className="text-xs font-serif italic text-walnut/75 leading-relaxed">{"\""}{activeRoleInfo.desc}{"\""}</p>
            </div>
          </div>
        </div>

        {/* OVERVIEW METRICS */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          {[
            { label: 'SIMULATED VALUE FLOW', value: `£${totalSimSales.toLocaleString()} GBP`, icon: TrendingUp },
            { label: 'ACQUISITION LOGS', value: `${ordersLog.length} Orders`, icon: FileText },
            { label: 'FLIGHT BOOKINGS', value: `${bookingsLog.length} Sessions`, icon: Calendar },
            { label: 'CATALOG SAMPLES', value: '100 Active Lots', icon: Users }
          ].map((stat, idx) => (
            <div key={idx} className="bg-[#fdfdfc] border border-brass/20 p-5 rounded flex items-center justify-between shadow-sm">
              <div className="space-y-1">
                <span className="block text-[8px] uppercase tracking-widest text-brass font-bold font-mono">{stat.label}</span>
                <p className="font-serif text-xl font-semibold text-walnut">{stat.value}</p>
              </div>
              <stat.icon className="w-8 h-8 text-brass/20 flex-shrink-0" />
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
          
          {/* SIMULATED CLIENT ORDERS */}
          <div className="border-fine bg-ivory p-6 rounded shadow-sm space-y-4">
            <h3 className="font-serif text-lg text-walnut uppercase tracking-widest border-b border-brass/10 pb-2">Acquisition Logs</h3>
            
            {ordersLog.length === 0 ? (
              <div className="text-center py-10 text-xs text-walnut/40 italic">
                {"\"No acquisitions registered in this session's ledger yet.\""}
              </div>
            ) : (
              <div className="space-y-4 max-h-[300px] overflow-y-auto">
                {ordersLog.map((order, idx) => (
                  <div key={idx} className="p-3 border border-brass/15 bg-[#fdfdfc] rounded text-xs space-y-2">
                    <div className="flex justify-between items-center font-mono text-[10px]">
                      <span className="font-bold text-walnut">{order.orderNumber}</span>
                      <span className="text-walnut/50">{order.timestamp.substring(11, 19)}</span>
                    </div>
                    <p className="font-serif text-xs italic text-walnut/80">Acquired by: <strong className="text-walnut font-normal">{order.customerName}</strong> ({order.address})</p>
                    <div className="border-t border-brass/5 pt-1 flex justify-between font-bold text-brass-dark">
                      <span>Total Invoice:</span>
                      <span className="font-mono">£{order.totalPaid} GBP</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* SIMULATED TASTING BOOKINGS */}
          <div className="border-fine bg-ivory p-6 rounded shadow-sm space-y-4">
            <h3 className="font-serif text-lg text-walnut uppercase tracking-widest border-b border-brass/10 pb-2">Tasting Bookings</h3>
            
            {bookingsLog.length === 0 ? (
              <div className="text-center py-10 text-xs text-walnut/40 italic">
                {"\"No private tasting bookings registered yet.\""}
              </div>
            ) : (
              <div className="space-y-4 max-h-[300px] overflow-y-auto">
                {bookingsLog.map((book, idx) => (
                  <div key={idx} className="p-3 border border-brass/15 bg-[#fdfdfc] rounded text-xs space-y-2">
                    <div className="flex justify-between items-center font-mono text-[10px]">
                      <span className="font-bold text-walnut">{book.reference}</span>
                      <span className="text-walnut/50">{book.timestamp.substring(11, 19)}</span>
                    </div>
                    <p className="font-serif text-xs italic text-walnut">Flight: <strong className="text-walnut font-normal">{book.experienceTitle}</strong></p>
                    <div className="font-mono text-[10px] text-walnut/60 flex justify-between">
                      <span>{book.date} @ {book.time}</span>
                      <span>Guests: {book.guests}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

        {/* INVENTORY ADJUSTMENT PANEL FOR BUYERS */}
        <div className="border-fine bg-ivory p-6 rounded shadow-sm space-y-4">
          <h3 className="font-serif text-lg text-walnut uppercase tracking-widest border-b border-brass/10 pb-2">Catalog Inventory Control Panel</h3>
          <p className="text-xs text-walnut/60 leading-relaxed max-w-xl">
            As a <strong className="text-brass-dark">Curator / Buyer</strong>, you have the clearance to adjust the availability of specific casks, simulating immediate allocated stock overrides.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-h-[320px] overflow-y-auto pr-2 divide-y divide-brass/5">
            {WHISKIES.slice(0, 15).map((whisky) => {
              const currentStock = tempAvailability[whisky.id] || whisky.availability;
              return (
                <div key={whisky.id} className="p-3 bg-[#fdfdfc] border border-brass/15 rounded flex items-center justify-between text-xs gap-4">
                  <div>
                    <h5 className="font-serif text-xs font-semibold text-walnut leading-snug">{whisky.name}</h5>
                    <p className="text-[9px] text-brass-dark uppercase font-mono mt-0.5">{whisky.region} • £{whisky.price}</p>
                  </div>

                  <button
                    onClick={() => handleToggleStock(whisky.id)}
                    className={`px-3 py-1 font-mono text-[10px] uppercase font-bold rounded border ${
                      currentStock === 'In Stock'
                        ? 'bg-forest/10 text-forest border-forest/20 hover:bg-forest/20'
                        : 'bg-red-950/20 text-red-700 border-red-900/20 hover:bg-red-950/30'
                    }`}
                  >
                    {currentStock === 'In Stock' ? 'In Stock' : 'Sold Out'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

      </section>

    </div>
  );
}
