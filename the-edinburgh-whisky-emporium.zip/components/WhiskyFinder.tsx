'use client';

import React, { useState } from 'react';
import { WHISKIES, Whisky } from '@/lib/data/whiskyData';
import { Sparkles, ArrowRight, RotateCcw, Check, Heart, HelpCircle } from 'lucide-react';

interface WhiskyFinderProps {
  onSelectWhisky: (whisky: Whisky) => void;
  onAddToBasket: (whisky: Whisky) => void;
}

export default function WhiskyFinder({ onSelectWhisky, onAddToBasket }: WhiskyFinderProps) {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({
    style: [] as string[],
    peat: '',
    region: [] as string[],
    age: '',
    budget: '',
    occasion: '',
    purpose: '' // Collecting or drinking
  });

  const [matches, setMatches] = useState<{ whisky: Whisky; score: number; reason: string }[]>([]);

  const styles = ['Rich', 'Light', 'Peated', 'Smoky', 'Sherried', 'Citrus', 'Maritime', 'Floral', 'Spiced', 'Sweet', 'Dry'];
  const peatLevels = [
    { value: 'none', label: 'None or minimal', desc: 'Prefer smooth, sweet, floral and grassy profiles.' },
    { value: 'subtle', label: 'Subtle and gentle', desc: 'Subtle heather-smoke or mild highland sea-salt breeze.' },
    { value: 'heavy', label: 'Heavily peated', desc: 'Revere iodine, heavy woodsmoke, medicinal bog, and sea air.' }
  ];
  const regions = ['Speyside', 'Highlands', 'Lowlands', 'Islay', 'Campbeltown', 'Islands'];
  const agePreferences = [
    { value: 'young', label: 'Vibrant & Youthful (NAS to 12 Years)', desc: 'Focus on pure barley, fresh cask, and distillery character.' },
    { value: 'mature', label: 'Well Aged (15 to 21 Years)', desc: 'Balanced integration of wood maturity and distillery profile.' },
    { value: 'ancient', label: 'Ancient & Rare (25 to 40 Years)', desc: 'Supreme complexity of long wood slumber. Deep antique leather.' }
  ];
  const budgetRanges = [
    { value: 'accessible', label: 'Under £100', min: 0, max: 100 },
    { value: 'connoisseur', label: '£100 to £300', min: 100, max: 300 },
    { value: 'collector', label: 'Over £300', min: 300, max: 15000 }
  ];
  const occasions = [
    { value: 'daily', label: 'Quiet evening sipping', desc: 'A companion for reading, thinking, or unwinding.' },
    { value: 'gift', label: 'An exceptional gift', desc: 'To impress a cherished friend or colleague with serious presentation.' },
    { value: 'milestone', label: 'A monumental milestone', desc: 'To uncork for celebration or to lock away in a private cellar.' }
  ];
  const purposes = [
    { value: 'drinking', label: 'Immediate drinking & devotion', desc: 'Destined to be opened, researched, and enjoyed.' },
    { value: 'collecting', label: 'Cellaring & investment', desc: 'Preserved intact as a historic, finite artifact of liquid art.' }
  ];

  const handleToggleStyle = (s: string) => {
    setAnswers(prev => ({
      ...prev,
      style: prev.style.includes(s) 
        ? prev.style.filter(item => item !== s) 
        : [...prev.style, s]
    }));
  };

  const handleToggleRegion = (r: string) => {
    setAnswers(prev => ({
      ...prev,
      region: prev.region.includes(r)
        ? prev.region.filter(item => item !== r)
        : [...prev.region, r]
    }));
  };

  const nextStep = () => {
    if (step < 6) {
      setStep(step + 1);
    } else {
      calculateMatches();
    }
  };

  const calculateMatches = () => {
    // Score each whisky in the database based on answers
    const scores = WHISKIES.map(whisky => {
      let score = 0;
      let matchingFactors: string[] = [];

      // 1. Style matching
      answers.style.forEach(s => {
        if (whisky.styleProfile.includes(s as any)) {
          score += 15;
          matchingFactors.push(s);
        }
      });

      // 2. Peat tolerance
      if (answers.peat === 'none') {
        if (whisky.styleProfile.includes('Peated') || whisky.styleProfile.includes('Smoky')) {
          score -= 30; // penalty for smoky whiskies
        } else {
          score += 20;
          matchingFactors.push('unpeated purity');
        }
      } else if (answers.peat === 'heavy') {
        if (whisky.styleProfile.includes('Peated') || whisky.styleProfile.includes('Smoky')) {
          score += 35;
          matchingFactors.push('heavy peat character');
        } else {
          score -= 10;
        }
      } else if (answers.peat === 'subtle') {
        if (whisky.characterKeywords.includes('smoke') || whisky.styleProfile.includes('Maritime')) {
          score += 25;
          matchingFactors.push('subtle coastal smoke');
        }
      }

      // 3. Region
      if (answers.region.length > 0) {
        if (answers.region.includes(whisky.region)) {
          score += 25;
          matchingFactors.push(`${whisky.region} region`);
        }
      }

      // 4. Age preference
      if (answers.age === 'young') {
        if (whisky.age === null || whisky.age <= 12) {
          score += 20;
          matchingFactors.push('youthful distillery notes');
        }
      } else if (answers.age === 'mature') {
        if (whisky.age && whisky.age >= 15 && whisky.age <= 21) {
          score += 25;
          matchingFactors.push('perfect aging integration');
        }
      } else if (answers.age === 'ancient') {
        if (whisky.age && whisky.age >= 25) {
          score += 35;
          matchingFactors.push('extreme archival maturity');
        }
      }

      // 5. Budget matching
      const budgetRule = budgetRanges.find(b => b.value === answers.budget);
      if (budgetRule) {
        if (whisky.price >= budgetRule.min && whisky.price <= budgetRule.max) {
          score += 30;
          matchingFactors.push('aligned financial range');
        } else if (whisky.price > budgetRule.max) {
          score -= 40; // budget cap strict penalty
        } else {
          score += 10; // lower price is fine, but focus on the target
        }
      }

      // 6. Purpose (collecting vs drinking) & Occasion
      if (answers.purpose === 'collecting') {
        if (whisky.rarityLevel >= 4 || whisky.availability === 'Allocated') {
          score += 30;
          matchingFactors.push('excellent archive and cellaring potential');
        }
      } else {
        if (whisky.availability === 'In Stock') {
          score += 15;
          matchingFactors.push('ready for immediate uncorking');
        }
      }

      // Generate a personalized reasons text
      const styleList = matchingFactors.slice(0, 3).join(', ');
      let reason = `Aligned perfectly via your preference for ${styleList || 'Scottish craftsmanship'}. `;
      
      if (answers.occasion === 'gift') {
        reason += `Includes luxury packaging and an impeccable presentation file, making it a stellar gift.`;
      } else if (answers.purpose === 'collecting') {
        reason += `Due to its ${whisky.rarityLevel}-star rarity status and limited bottle counts (${whisky.totalBottles} bottles total), this is an exceptional candidate for long-term cellaring.`;
      } else {
        reason += `The ${whisky.abv}% ABV and classic cask structure make this a stunning candidate for an quiet evening's intellectual exploration.`;
      }

      return { whisky, score, reason };
    });

    // Sort by score and take top 3
    const topMatches = scores
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);

    setMatches(topMatches);
    setStep(7); // Show results
  };

  const resetFinder = () => {
    setAnswers({
      style: [],
      peat: '',
      region: [],
      age: '',
      budget: '',
      occasion: '',
      purpose: ''
    });
    setMatches([]);
    setStep(0);
  };

  return (
    <div className="w-full max-w-3xl mx-auto border-fine bg-ivory text-walnut p-6 md:p-12 relative shadow-restrained">
      
      {/* Structural Corner Marks */}
      <div className="absolute top-2 left-2 w-3 h-3 border-t border-l border-brass/40"></div>
      <div className="absolute top-2 right-2 w-3 h-3 border-t border-r border-brass/40"></div>
      <div className="absolute bottom-2 left-2 w-3 h-3 border-b border-l border-brass/40"></div>
      <div className="absolute bottom-2 right-2 w-3 h-3 border-b border-r border-brass/40"></div>

      <div className="mb-6 border-b border-brass/10 pb-4 flex justify-between items-center">
        <div>
          <span className="text-[9px] uppercase tracking-[0.25em] text-brass font-bold">COMMITTEE CONSULTATION</span>
          <h3 className="font-serif text-2xl text-walnut">Find Your Scotch</h3>
        </div>
        {step > 0 && (
          <button 
            onClick={resetFinder}
            className="text-[9px] uppercase tracking-widest text-walnut/60 hover:text-brass flex items-center space-x-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset Search</span>
          </button>
        )}
      </div>

      {/* Step Progress Line */}
      {step < 7 && (
        <div className="w-full h-[2px] bg-brass/15 mb-8 relative">
          <div 
            className="absolute h-full bg-brass transition-all duration-300"
            style={{ width: `${(step / 6) * 100}%` }}
          ></div>
        </div>
      )}

      {/* QUESTION 1: Style preferences */}
      {step === 0 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">1. What flavour profiles do you enjoy?</h4>
            <p className="text-xs text-walnut/60">Select as many character parameters as you prefer. Our committee will cross-reference the exact ester signatures.</p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {styles.map(s => {
              const selected = answers.style.includes(s);
              return (
                <button
                  key={s}
                  onClick={() => handleToggleStyle(s)}
                  className={`p-3 text-left border text-xs tracking-wider transition-all rounded ${
                    selected 
                      ? 'bg-walnut text-ivory border-brass' 
                      : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{s.toUpperCase()}</span>
                    {selected && <Check className="w-3.5 h-3.5 text-brass" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* QUESTION 2: Peat level */}
      {step === 1 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">2. What is your tolerance for peat and smoke?</h4>
            <p className="text-xs text-walnut/60">Peat smoke delivers medicinal, coastal phenols. It is an acquired, historic, and powerful passion.</p>
          </div>
          <div className="space-y-3">
            {peatLevels.map(p => {
              const selected = answers.peat === p.value;
              return (
                <button
                  key={p.value}
                  onClick={() => setAnswers(prev => ({ ...prev, peat: p.value }))}
                  className={`w-full p-4 text-left border rounded transition-all flex justify-between items-start ${
                    selected ? 'bg-walnut text-ivory border-brass' : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <div>
                    <p className={`text-xs uppercase tracking-widest font-semibold ${selected ? 'text-brass' : 'text-walnut'}`}>{p.label}</p>
                    <p className="text-[11px] text-walnut/60 mt-1 max-w-md">{p.desc}</p>
                  </div>
                  {selected && <div className="p-1 rounded-full bg-brass/20"><Check className="w-4 h-4 text-brass" /></div>}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* QUESTION 3: Region preferences */}
      {step === 2 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">3. Do you have preferred geographical regions?</h4>
            <p className="text-xs text-walnut/60">Leave unselected to explore all of Scotland, or select your target regions of judgement.</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {regions.map(r => {
              const selected = answers.region.includes(r);
              return (
                <button
                  key={r}
                  onClick={() => handleToggleRegion(r)}
                  className={`p-3 text-left border text-xs tracking-wider transition-all rounded ${
                    selected 
                      ? 'bg-walnut text-ivory border-brass' 
                      : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <div className="flex justify-between items-center">
                    <span>{r.toUpperCase()}</span>
                    {selected && <Check className="w-3.5 h-3.5 text-brass" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* QUESTION 4: Age statement preference */}
      {step === 3 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">4. What wood aging profile appeals to your palate?</h4>
            <p className="text-xs text-walnut/60">Age shapes the texture. Young whisky displays the fire and barley of the still; ancient whisky reflects decades of silent oak extraction.</p>
          </div>
          <div className="space-y-3">
            {agePreferences.map(a => {
              const selected = answers.age === a.value;
              return (
                <button
                  key={a.value}
                  onClick={() => setAnswers(prev => ({ ...prev, age: a.value }))}
                  className={`w-full p-4 text-left border rounded transition-all flex justify-between items-start ${
                    selected ? 'bg-walnut text-ivory border-brass' : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <div>
                    <p className={`text-xs uppercase tracking-widest font-semibold ${selected ? 'text-brass' : 'text-walnut'}`}>{a.label}</p>
                    <p className="text-[11px] text-walnut/60 mt-1 max-w-md">{a.desc}</p>
                  </div>
                  {selected && <div className="p-1 rounded-full bg-brass/20"><Check className="w-4 h-4 text-brass" /></div>}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* QUESTION 5: Budget Range */}
      {step === 4 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">5. What is the target acquisition value?</h4>
            <p className="text-xs text-walnut/60">We curate across the financial spectrum, maintaining rigorous standard of judgement for every tier.</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {budgetRanges.map(b => {
              const selected = answers.budget === b.value;
              return (
                <button
                  key={b.value}
                  onClick={() => setAnswers(prev => ({ ...prev, budget: b.value }))}
                  className={`p-4 text-left border rounded transition-all flex flex-col justify-between ${
                    selected ? 'bg-walnut text-ivory border-brass' : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <p className={`text-xs uppercase tracking-widest font-bold ${selected ? 'text-brass' : 'text-brass-dark'}`}>
                    {b.label}
                  </p>
                  <p className="text-[10px] text-walnut/60 mt-2">
                    {b.value === 'accessible' ? 'Stellar everyday classics' : b.value === 'connoisseur' ? 'Exceptional small batch & aged' : 'Elite archival collectibles'}
                  </p>
                  {selected && <Check className="w-4 h-4 text-brass self-end mt-4" />}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* QUESTION 6: Occasion */}
      {step === 5 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">6. What is the intended occasion for the dram?</h4>
            <p className="text-xs text-walnut/60">We consider how the whiskey will be poured, matching the weight and sensory presence to the physical environment.</p>
          </div>
          <div className="space-y-3">
            {occasions.map(o => {
              const selected = answers.occasion === o.value;
              return (
                <button
                  key={o.value}
                  onClick={() => setAnswers(prev => ({ ...prev, occasion: o.value }))}
                  className={`w-full p-4 text-left border rounded transition-all flex justify-between items-start ${
                    selected ? 'bg-walnut text-ivory border-brass' : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <div>
                    <p className={`text-xs uppercase tracking-widest font-semibold ${selected ? 'text-brass' : 'text-walnut'}`}>{o.label}</p>
                    <p className="text-[11px] text-walnut/60 mt-1 max-w-md">{o.desc}</p>
                  </div>
                  {selected && <div className="p-1 rounded-full bg-brass/20"><Check className="w-4 h-4 text-brass" /></div>}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* QUESTION 7: Purpose */}
      {step === 6 && (
        <div className="space-y-6">
          <div>
            <h4 className="font-serif text-xl text-walnut mb-2">7. Are you collecting or immediate drinking?</h4>
            <p className="text-xs text-walnut/60">This decides whether we prioritize historic bottle-limit rarity index or sensory drinkability parameters.</p>
          </div>
          <div className="space-y-3">
            {purposes.map(p => {
              const selected = answers.purpose === p.value;
              return (
                <button
                  key={p.value}
                  onClick={() => setAnswers(prev => ({ ...prev, purpose: p.value }))}
                  className={`w-full p-4 text-left border rounded transition-all flex justify-between items-start ${
                    selected ? 'bg-walnut text-ivory border-brass' : 'border-brass/25 hover:border-brass/60 hover:bg-brass/5'
                  }`}
                >
                  <div>
                    <p className={`text-xs uppercase tracking-widest font-semibold ${selected ? 'text-brass' : 'text-walnut'}`}>{p.label}</p>
                    <p className="text-[11px] text-walnut/60 mt-1 max-w-md">{p.desc}</p>
                  </div>
                  {selected && <div className="p-1 rounded-full bg-brass/20"><Check className="w-4 h-4 text-brass" /></div>}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* RESULTS SCREEN */}
      {step === 7 && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <div className="text-center bg-brass/5 border border-brass/20 p-6 md:p-8 rounded">
            <h4 className="font-serif text-2xl text-walnut mb-2">Committee Recommendation Report</h4>
            <p className="text-xs text-walnut/70 max-w-lg mx-auto leading-relaxed">
              We have compiled several matching bottles based on your parameters. These records are selected for character alignment rather than objective superiority.
            </p>
          </div>

          <div className="space-y-6">
            {matches.map(({ whisky, score, reason }) => (
              <div 
                key={whisky.id}
                className="p-6 border border-brass/20 hover:border-brass/55 rounded-lg bg-[#fdfdfc] flex flex-col md:flex-row justify-between items-stretch gap-6 transition-all duration-300"
              >
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center space-x-2.5 mb-2">
                      <span className="text-[10px] font-mono font-semibold bg-walnut text-ivory px-2 py-0.5 rounded">
                        MATCH SCORE: {score}%
                      </span>
                      <span className="text-[10px] text-brass uppercase font-semibold">
                        {'★'.repeat(whisky.rarityLevel)}
                      </span>
                    </div>

                    <h5 className="font-serif text-xl text-walnut leading-snug">{whisky.name}</h5>
                    <p className="text-[10px] text-brass-dark uppercase font-mono mt-1">
                      {whisky.region} • {whisky.abv}% ABV • {whisky.size} • {whisky.caskType}
                    </p>

                    <p className="text-xs font-serif italic text-walnut/85 mt-4 border-l-2 border-brass/50 pl-3 py-1 bg-brass/5">
                      {"\""}{reason}{"\""}
                    </p>
                  </div>

                  <div className="mt-6 flex flex-wrap gap-2">
                    <button
                      onClick={() => onSelectWhisky(whisky)}
                      className="px-4 py-2 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-wider font-semibold transition-all rounded"
                    >
                      View Archive File
                    </button>
                    <button
                      onClick={() => onAddToBasket(whisky)}
                      className="px-4 py-2 border border-brass text-walnut hover:bg-brass/5 text-xs uppercase tracking-wider font-semibold transition-all rounded"
                    >
                      Acquire Bottle — £{whisky.price}
                    </button>
                  </div>
                </div>

                <div className="w-full md:w-44 flex flex-col items-center justify-center p-4 border border-brass/10 bg-brass/5 rounded relative">
                  {/* Fictional bottle simulation rendering */}
                  <div className="w-16 h-36 border border-brass/40 rounded-t-3xl rounded-b-md bg-amber-800/10 relative flex flex-col items-center justify-between py-4 shadow-sm">
                    {/* Liquid fill color based on type */}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-amber-600/60 to-amber-500/20 h-28 rounded-b-md"></div>
                    <div className="w-6 h-8 bg-walnut/90 rounded-t border border-brass/20 z-10 -mt-8"></div>
                    
                    {/* Bottle mini label */}
                    <div className="w-12 bg-ivory/95 border border-brass/30 p-1 text-[6px] text-center font-serif leading-none z-10">
                      <p className="font-bold text-[5px] text-walnut uppercase">{whisky.distilleryName.substring(0, 10)}</p>
                      <div className="w-4 h-[1px] bg-brass/50 mx-auto my-0.5"></div>
                      <p className="text-brass-dark">{whisky.age ? `${whisky.age} YR` : 'RESERVE'}</p>
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-walnut/50 mt-4">
                    Ref: {whisky.caskNumber}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center pt-4">
            <button
              onClick={resetFinder}
              className="px-6 py-2.5 bg-transparent border border-brass text-brass hover:bg-brass/5 text-xs uppercase tracking-widest font-semibold transition-all rounded"
            >
              Consult Committee Again
            </button>
          </div>
        </div>
      )}

      {/* Navigation Buttons Row */}
      {step < 7 && (
        <div className="mt-8 pt-6 border-t border-brass/15 flex justify-between items-center">
          <button
            onClick={() => setStep(prev => Math.max(0, prev - 1))}
            disabled={step === 0}
            className={`text-xs uppercase tracking-wider font-semibold ${
              step === 0 ? 'text-walnut/30 cursor-not-allowed' : 'text-walnut/80 hover:text-brass'
            }`}
          >
            Back
          </button>

          <button
            onClick={nextStep}
            className="px-5 py-2.5 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-[0.15em] font-bold transition-all flex items-center space-x-1.5"
          >
            <span>{step === 6 ? 'Get Recommendations' : 'Continue'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

    </div>
  );
}
