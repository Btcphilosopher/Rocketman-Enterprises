'use client';

import React, { useState, useMemo } from 'react';
import { useEmporium, CollectionItem } from './EmporiumProvider';
import { WHISKIES } from '@/lib/data/whiskyData';
import { Sparkles, Calendar, Plus, FolderHeart, Trash2, Eye, ShieldCheck } from 'lucide-react';

export default function CollectionDashboard() {
  const { 
    myCollection, 
    addToCollection, 
    removeFromCollection, 
    toggleCollectionOpened 
  } = useEmporium();

  // Modal form toggle
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [whiskyId, setWhiskyId] = useState('');
  const [customName, setCustomName] = useState('');
  const [customRegion, setCustomRegion] = useState('Speyside');
  const [customDistillery, setCustomDistillery] = useState('');
  const [purchaseDate, setPurchaseDate] = useState('2026-10-02');
  const [purchasePrice, setPurchasePrice] = useState('');
  const [bottleNumber, setBottleNumber] = useState('024 / 300');
  const [location, setLocation] = useState('Charlotte Square Vault');
  const [addError, setAddError] = useState('');

  // 1. Calculate dynamic statistics
  const totalBottles = myCollection.length;
  
  const uniqueDistilleries = useMemo(() => {
    const set = new Set(myCollection.map(item => item.distilleryName));
    return set.size;
  }, [myCollection]);

  const uniqueRegions = useMemo(() => {
    const set = new Set(myCollection.map(item => item.region));
    return set.size;
  }, [myCollection]);

  const openBottles = useMemo(() => {
    return myCollection.filter(item => item.opened).length;
  }, [myCollection]);

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let name = '';
    let distName = '';
    let reg = '';

    if (whiskyId) {
      // Find from database
      const found = WHISKIES.find(w => w.id === whiskyId);
      if (found) {
        name = found.name;
        distName = found.distilleryName;
        reg = found.region;
      }
    } else {
      if (!customName.trim()) {
        setAddError('Please enter a custom whisky name or select from the database.');
        return;
      }
      name = customName;
      distName = customDistillery || 'Independent Distillery';
      reg = customRegion;
    }

    addToCollection({
      whiskyId: whiskyId || 'custom',
      whiskyName: name,
      distilleryName: distName,
      region: reg,
      purchaseDate,
      purchasePrice: Number(purchasePrice) || 0,
      bottleNumber,
      tastingNotes: 'Unopened. Placed in cellar storage.',
      opened: false,
      provenance: 'Registered in My Vault.',
      location
    });

    // Reset
    setWhiskyId('');
    setCustomName('');
    setCustomDistillery('');
    setPurchasePrice('');
    setShowAddForm(false);
    setAddError('');
  };

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold font-mono">CLIENT PORTFOLIO VAULT</span>
        <h2 className="font-serif text-3xl md:text-4xl">My Private Vault</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"Log and audit your personal acquisitions. View statistics, storage locations, and update taste notes for opened bottles.\""}
        </p>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8 space-y-8">
        
        {/* STATS CARDS ROW */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { value: totalBottles, label: 'BOTTLES OWNED', desc: 'Total registered lots' },
            { value: uniqueDistilleries, label: 'DISTILLERIES', desc: 'Distinct distilleries' },
            { value: uniqueRegions, label: 'REGIONS', desc: 'Scotch regions mapped' },
            { value: openBottles, label: 'OPEN BOTTLES', desc: 'Active drinking stock' }
          ].map((stat, idx) => (
            <div key={idx} className="bg-ivory border border-brass/25 rounded p-5 text-center shadow-sm space-y-1">
              <span className="block text-[8px] uppercase tracking-widest text-brass-dark font-mono font-bold">{stat.label}</span>
              <p className="font-serif text-3xl sm:text-4xl font-light text-walnut">{stat.value}</p>
              <p className="text-[10px] text-walnut/50 italic font-serif">{stat.desc}</p>
            </div>
          ))}
        </div>

        {/* Action Row */}
        <div className="flex justify-between items-center border-b border-brass/15 pb-4">
          <h3 className="font-serif text-lg text-walnut uppercase tracking-widest">Vault Registry</h3>
          
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="px-4 py-2 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-widest font-bold transition-all border border-brass rounded flex items-center space-x-1"
          >
            <Plus className="w-4 h-4 text-brass" />
            <span>{showAddForm ? 'Close Vault Registry Form' : 'Register Bottle In Vault'}</span>
          </button>
        </div>

        {/* VAULT REGISTER ADD BOTTLE FORM */}
        {showAddForm && (
          <div className="border-fine bg-brass/5 p-6 rounded shadow-inner max-w-2xl mx-auto animate-in fade-in duration-200">
            <h4 className="font-serif text-lg text-walnut mb-4">Register Acquisition File</h4>
            
            <form onSubmit={handleAddSubmit} className="space-y-4">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Select From Emporium Catalog</label>
                  <select
                    value={whiskyId}
                    onChange={(e) => {
                      setWhiskyId(e.target.value);
                      setAddError('');
                    }}
                    className="w-full bg-ivory border border-brass/30 text-xs p-2 focus:outline-none focus:border-brass rounded"
                  >
                    <option value="">-- Or enter Custom Bottle Below --</option>
                    {WHISKIES.map(w => (
                      <option key={w.id} value={w.id}>{w.name} — £{w.price}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Storage Location</label>
                  <select
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="w-full bg-ivory border border-brass/30 text-xs p-2 focus:outline-none focus:border-brass rounded"
                  >
                    <option value="Charlotte Square Vault">Charlotte Square Vault Room</option>
                    <option value="Home Study Cabinet">Home Study Cabinet</option>
                    <option value="Cellar Rack B">Cellar Rack B</option>
                    <option value="Edinburgh Safe Box">Edinburgh Safe Box</option>
                  </select>
                </div>
              </div>

              {/* Custom fields if not in database */}
              {!whiskyId && (
                <div className="p-4 border border-brass/20 rounded bg-ivory space-y-4 animate-in fade-in duration-150">
                  <p className="text-[10px] text-brass-dark font-mono font-semibold uppercase">CUSTOM ACQUISITION ENTRIES</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-wider font-bold">Whisky Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Laphroaig Vintage"
                        value={customName}
                        onChange={(e) => setCustomName(e.target.value)}
                        className="w-full bg-transparent border border-brass/35 text-xs p-1.5 focus:outline-none focus:border-brass rounded"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-wider font-bold">Distillery</label>
                      <input
                        type="text"
                        placeholder="e.g. Laphroaig"
                        value={customDistillery}
                        onChange={(e) => setCustomDistillery(e.target.value)}
                        className="w-full bg-transparent border border-brass/35 text-xs p-1.5 focus:outline-none focus:border-brass rounded"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[8px] uppercase tracking-wider font-bold">Region</label>
                      <select
                        value={customRegion}
                        onChange={(e) => setCustomRegion(e.target.value)}
                        className="w-full bg-transparent border border-brass/35 text-xs p-1.5 focus:outline-none focus:border-brass rounded"
                      >
                        <option value="Speyside">Speyside</option>
                        <option value="Highlands">Highlands</option>
                        <option value="Lowlands">Lowlands</option>
                        <option value="Islay">Islay</option>
                        <option value="Campbeltown">Campbeltown</option>
                        <option value="Islands">Islands</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Purchase Date</label>
                  <input
                    type="date"
                    value={purchaseDate}
                    onChange={(e) => setPurchaseDate(e.target.value)}
                    className="w-full bg-ivory border border-brass/30 text-xs p-2 focus:outline-none focus:border-brass rounded font-mono"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Purchase Price (£)</label>
                  <input
                    type="number"
                    placeholder="e.g. 180"
                    value={purchasePrice}
                    onChange={(e) => setPurchasePrice(e.target.value)}
                    className="w-full bg-ivory border border-brass/30 text-xs p-2 focus:outline-none focus:border-brass rounded"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Bottle Batch No.</label>
                  <input
                    type="text"
                    value={bottleNumber}
                    onChange={(e) => setBottleNumber(e.target.value)}
                    className="w-full bg-ivory border border-brass/30 text-xs p-2 focus:outline-none focus:border-brass rounded font-mono"
                  />
                </div>
              </div>

              {addError && <p className="text-xs text-red-700 bg-red-50 p-2 border border-red-200">{addError}</p>}

              <button
                type="submit"
                className="px-5 py-2.5 bg-walnut text-ivory uppercase tracking-widest text-xs font-bold hover:bg-forest rounded transition-all"
              >
                Register In Private Ledger
              </button>
            </form>
          </div>
        )}

        {/* VAULT TABLE LIST */}
        <div className="border border-brass/25 rounded bg-[#fdfdfc] shadow-sm overflow-hidden no-print">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-walnut text-[#dfd9ce] uppercase tracking-wider text-[9px] border-b border-brass/20">
                  <th className="p-4">LOT / NAME</th>
                  <th className="p-4">REGION</th>
                  <th className="p-4">STORAGE SEC</th>
                  <th className="p-4">PURCHASE PRICE</th>
                  <th className="p-4">BOTTLE NO</th>
                  <th className="p-4">SEAL STATUS</th>
                  <th className="p-4 text-right">LEDGER ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-brass/10 font-sans">
                {myCollection.map((item) => (
                  <tr key={item.id} className="hover:bg-brass/[0.02] transition-colors">
                    <td className="p-4">
                      <p className="font-serif text-sm font-semibold text-walnut">{item.whiskyName}</p>
                      <p className="text-[9px] text-brass-dark font-mono uppercase mt-0.5">{item.distilleryName}</p>
                    </td>
                    <td className="p-4 font-mono text-[10px] uppercase text-walnut/70">{item.region}</td>
                    <td className="p-4 text-walnut/70 italic font-serif text-xs">{item.location}</td>
                    <td className="p-4 font-mono">£{item.purchasePrice}</td>
                    <td className="p-4 font-mono">{item.bottleNumber}</td>
                    <td className="p-4">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-widest ${
                        item.opened 
                          ? 'bg-amber-100 text-amber-800 border border-amber-200' 
                          : 'bg-forest/10 text-forest border border-forest/20'
                      }`}>
                        {item.opened ? 'UNSEALED & ACTIVE' : 'SEALED VAULTED'}
                      </span>
                    </td>
                    <td className="p-4 text-right space-x-2">
                      <button
                        onClick={() => toggleCollectionOpened(item.id)}
                        className="text-[10px] uppercase tracking-wider text-brass font-bold hover:underline"
                        title={item.opened ? "Mark as unopened" : "Open bottle & unseal"}
                      >
                        {item.opened ? 'Re-seal' : 'Unseal'}
                      </button>
                      <button
                        onClick={() => removeFromCollection(item.id)}
                        className="text-[10px] uppercase tracking-wider text-red-700 font-bold hover:underline"
                        title="Deregister bottle"
                      >
                        Deregister
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </section>

    </div>
  );
}
