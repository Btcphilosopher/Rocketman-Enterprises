'use client';

import React from 'react';
import { useEmporium } from './EmporiumProvider';
import { X, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';

interface BasketDrawerProps {
  onClose: () => void;
}

export default function BasketDrawer({ onClose }: BasketDrawerProps) {
  const { 
    basket, 
    updateBasketQuantity, 
    removeFromBasket, 
    basketTotal,
    setActiveView
  } = useEmporium();

  const handleCheckoutClick = () => {
    onClose();
    setActiveView('checkout');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden no-print">
      {/* Backdrop overlay */}
      <div 
        onClick={onClose}
        className="absolute inset-0 bg-walnut/70 backdrop-blur-xs transition-opacity duration-300"
      ></div>

      {/* Drawer content sliding in from right */}
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md bg-ivory text-walnut flex flex-col shadow-walnut-heavy border-l border-brass/30 relative">
          
          {/* Top Header */}
          <div className="p-6 border-b border-brass/15 flex justify-between items-center bg-walnut text-ivory">
            <div className="flex items-center space-x-2.5">
              <ShoppingBag className="w-4 h-4 text-brass" />
              <h3 className="font-serif text-lg tracking-wide">Your Acquisition Basket</h3>
            </div>
            <button 
              onClick={onClose}
              className="text-ivory hover:text-brass p-1 transition-colors"
              title="Close Basket"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* List of items */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {basket.length === 0 ? (
              <div className="text-center py-20 space-y-4">
                <ShoppingBag className="w-12 h-12 text-brass/25 mx-auto" />
                <p className="font-serif italic text-sm text-walnut/60">
                  {"\"Your basket is currently empty of Scotch spirits.\""}
                </p>
                <button
                  onClick={() => {
                    onClose();
                    setActiveView('whisky');
                  }}
                  className="px-5 py-2 border border-brass text-xs uppercase tracking-widest font-semibold hover:bg-brass/5 transition-all text-brass"
                >
                  Explore Collection
                </button>
              </div>
            ) : (
              basket.map((item) => (
                <div 
                  key={item.whisky.id}
                  className="p-4 border border-brass/10 hover:border-brass/30 bg-[#fdfdfc] rounded flex gap-4 transition-all"
                >
                  {/* Small bottle liquid simulator preview */}
                  <div className="w-12 h-24 border border-brass/20 rounded-t-xl rounded-b bg-amber-800/5 relative flex-shrink-0 flex items-center justify-end py-3">
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-amber-600/70 to-amber-500/20 h-16 rounded-b"></div>
                    <div className="w-3.5 h-4 bg-walnut/90 rounded-t border border-brass/10 -mt-8"></div>
                  </div>

                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="text-xs font-semibold text-walnut leading-tight">{item.whisky.name}</h4>
                      <p className="text-[9px] text-brass-dark uppercase font-mono mt-0.5">{item.whisky.region} • {item.whisky.abv}% ABV</p>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      {/* Quantities adjuster */}
                      <div className="flex items-center border border-brass/30 rounded overflow-hidden">
                        <button
                          onClick={() => updateBasketQuantity(item.whisky.id, item.quantity - 1)}
                          className="px-2 py-1 hover:bg-brass/5 text-xs text-walnut/70 border-r border-brass/20"
                        >
                          -
                        </button>
                        <span className="px-3 text-xs font-mono font-bold text-walnut">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateBasketQuantity(item.whisky.id, item.quantity + 1)}
                          className="px-2 py-1 hover:bg-brass/5 text-xs text-walnut/70 border-l border-brass/20"
                        >
                          +
                        </button>
                      </div>

                      <div className="text-right">
                        <p className="text-xs font-semibold text-walnut">£{(item.whisky.price * item.quantity).toLocaleString()}</p>
                        <button
                          onClick={() => removeFromBasket(item.whisky.id)}
                          className="text-[9px] text-red-700 hover:underline flex items-center space-x-0.5 mt-1 self-end"
                          title="Remove item"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Bottom Total / Summary */}
          {basket.length > 0 && (
            <div className="p-6 border-t border-brass/25 bg-brass/5 space-y-4 shadow-inner">
              <div className="flex justify-between items-center text-xs text-walnut/60 font-mono">
                <span>ACQUISITION SUB-TOTAL</span>
                <span className="font-semibold text-walnut">£{basketTotal.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center text-xs text-walnut/60 font-mono">
                <span>ESTIMATED DELIVERY TAX</span>
                <span className="text-forest font-semibold">FREE (UK COURIER)</span>
              </div>
              <div className="border-t border-brass/10 pt-3 flex justify-between items-center">
                <span className="font-serif text-sm uppercase tracking-wider font-semibold">Total Invoice</span>
                <span className="font-serif text-xl font-bold text-walnut">£{basketTotal.toLocaleString()}</span>
              </div>

              <div className="pt-2">
                <button
                  onClick={handleCheckoutClick}
                  className="w-full py-3 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-widest font-bold transition-all border border-brass shadow flex items-center justify-center space-x-1.5"
                >
                  <span>Proceed to Checkout</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="text-[9px] text-center text-walnut/50 mt-3 leading-relaxed">
                  Compliance Notice: Delivery requires a physical age-check at the recipient’s address. No alcohol is sold to individuals under 18.
                </p>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
