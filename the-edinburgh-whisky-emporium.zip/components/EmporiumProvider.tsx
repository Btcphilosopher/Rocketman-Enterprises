'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Whisky, WHISKIES, TastingExperience } from '@/lib/data/whiskyData';

export interface BasketItem {
  whisky: Whisky;
  quantity: number;
}

export interface CollectionItem {
  id: string;
  whiskyId: string;
  whiskyName: string;
  distilleryName: string;
  region: string;
  purchaseDate: string;
  purchasePrice: number;
  bottleNumber: string;
  tastingNotes: string;
  opened: boolean;
  provenance: string;
  location: string;
}

export type ViewType = 
  | 'home' 
  | 'whisky' 
  | 'rare' 
  | 'distilleries' 
  | 'library' 
  | 'tasting' 
  | 'house' 
  | 'collection' 
  | 'checkout' 
  | 'admin' 
  | 'contact';

interface EmporiumContextType {
  ageVerified: boolean;
  verifyAge: (over18: boolean) => void;
  basket: BasketItem[];
  addToBasket: (whisky: Whisky, quantity?: number) => void;
  removeFromBasket: (whiskyId: string) => void;
  updateBasketQuantity: (whiskyId: string, quantity: number) => void;
  clearBasket: () => void;
  basketTotal: number;
  myCollection: CollectionItem[];
  addToCollection: (item: Omit<CollectionItem, 'id'>) => void;
  removeFromCollection: (id: string) => void;
  toggleCollectionOpened: (id: string) => void;
  activeView: ViewType;
  setActiveView: (view: ViewType) => void;
  selectedWhisky: Whisky | null;
  setSelectedWhisky: (whisky: Whisky | null) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  ordersLog: any[];
  addOrder: (order: any) => void;
  bookingsLog: any[];
  addBooking: (booking: any) => void;
}

const EmporiumContext = createContext<EmporiumContextType | undefined>(undefined);

export function EmporiumProvider({ children }: { children: React.ReactNode }) {
  const [ageVerified, setAgeVerified] = useState<boolean>(false);
  const [basket, setBasket] = useState<BasketItem[]>([]);
  const [activeView, setActiveView] = useState<ViewType>('home');
  const [selectedWhisky, setSelectedWhisky] = useState<Whisky | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [myCollection, setMyCollection] = useState<CollectionItem[]>([]);
  const [ordersLog, setOrdersLog] = useState<any[]>([]);
  const [bookingsLog, setBookingsLog] = useState<any[]>([]);
  const [mounted, setMounted] = useState<boolean>(false);

  // Initial load from localStorage
  useEffect(() => {
    setTimeout(() => {
      setMounted(true);
      
      const savedAge = localStorage.getItem('edw_age_verified');
      if (savedAge === 'true') {
        setAgeVerified(true);
      }

      const savedBasket = localStorage.getItem('edw_basket');
      if (savedBasket) {
        try { setBasket(JSON.parse(savedBasket)); } catch (e) { console.error(e); }
      }

      const savedOrders = localStorage.getItem('edw_orders');
      if (savedOrders) {
        try { setOrdersLog(JSON.parse(savedOrders)); } catch (e) { console.error(e); }
      }

      const savedBookings = localStorage.getItem('edw_bookings');
      if (savedBookings) {
        try { setBookingsLog(JSON.parse(savedBookings)); } catch (e) { console.error(e); }
      }

      // Seed My Collection with "27 BOTTLES, 12 DISTILLERIES, 8 REGIONS, 3 OPEN BOTTLES" as required
      const savedCollection = localStorage.getItem('edw_collection');
      if (savedCollection) {
        try {
          setMyCollection(JSON.parse(savedCollection));
        } catch (e) {
          console.error(e);
        }
      } else {
        // Generate standard seed collection using our fictional whiskies
        const seedBottles: CollectionItem[] = [];
        const count = 27;
        
        // Let's pick 27 unique whiskies from our synthetic database to seed the collection beautifully
        for (let i = 0; i < count; i++) {
          const wIdx = (i * 3.7) % WHISKIES.length;
          const whisky = WHISKIES[Math.floor(wIdx)];
          // Open exactly 3 bottles
          const opened = i < 3;
          
          seedBottles.push({
            id: `seed-col-${i}`,
            whiskyId: whisky.id,
            whiskyName: whisky.name,
            distilleryName: whisky.distilleryName,
            region: whisky.region,
            purchaseDate: `2026-0${(i % 8) + 1}-1${i % 9}`,
            purchasePrice: whisky.price,
            bottleNumber: `${10 + i} / ${whisky.totalBottles}`,
            tastingNotes: opened ? `Incredible expression of ${whisky.region}. ${whisky.tastingNotes.nose}` : 'Unopened. Kept in cellaring environment.',
            opened,
            provenance: 'Acquired at Charlotte Square auction room.',
            location: i % 3 === 0 ? 'Charlotte Square Vault' : (i % 3 === 1 ? 'Home Study Cabinet' : 'Cellar Rack B')
          });
        }
        setMyCollection(seedBottles);
        localStorage.setItem('edw_collection', JSON.stringify(seedBottles));
      }
    }, 0);
  }, []);

  // Sync to localStorage
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('edw_basket', JSON.stringify(basket));
    }
  }, [basket, mounted]);

  useEffect(() => {
    if (mounted) {
      localStorage.setItem('edw_collection', JSON.stringify(myCollection));
    }
  }, [myCollection, mounted]);

  useEffect(() => {
    if (mounted) {
      localStorage.setItem('edw_orders', JSON.stringify(ordersLog));
    }
  }, [ordersLog, mounted]);

  useEffect(() => {
    if (mounted) {
      localStorage.setItem('edw_bookings', JSON.stringify(bookingsLog));
    }
  }, [bookingsLog, mounted]);

  const verifyAge = (over18: boolean) => {
    if (over18) {
      setAgeVerified(true);
      localStorage.setItem('edw_age_verified', 'true');
    } else {
      setAgeVerified(false);
      localStorage.setItem('edw_age_verified', 'false');
    }
  };

  const addToBasket = (whisky: Whisky, quantity = 1) => {
    setBasket((prev) => {
      const existing = prev.find((item) => item.whisky.id === whisky.id);
      if (existing) {
        return prev.map((item) =>
          item.whisky.id === whisky.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { whisky, quantity }];
    });
  };

  const removeFromBasket = (whiskyId: string) => {
    setBasket((prev) => prev.filter((item) => item.whisky.id !== whiskyId));
  };

  const updateBasketQuantity = (whiskyId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromBasket(whiskyId);
      return;
    }
    setBasket((prev) =>
      prev.map((item) =>
        item.whisky.id === whiskyId ? { ...item, quantity } : item
      )
    );
  };

  const clearBasket = () => {
    setBasket([]);
  };

  const basketTotal = basket.reduce(
    (total, item) => total + item.whisky.price * item.quantity,
    0
  );

  const addToCollection = (item: Omit<CollectionItem, 'id'>) => {
    const newItem: CollectionItem = {
      ...item,
      id: `col-${Date.now()}`
    };
    setMyCollection((prev) => {
      const updated = [newItem, ...prev];
      return updated;
    });
  };

  const removeFromCollection = (id: string) => {
    setMyCollection((prev) => prev.filter((item) => item.id !== id));
  };

  const toggleCollectionOpened = (id: string) => {
    setMyCollection((prev) =>
      prev.map((item) =>
        item.id === id
          ? {
              ...item,
              opened: !item.opened,
              tastingNotes: !item.opened
                ? 'Bottle opened. A rich and nuanced dram.'
                : 'Unopened. Cellared.'
            }
          : item
      )
    );
  };

  const addOrder = (order: any) => {
    setOrdersLog((prev) => [order, ...prev]);
  };

  const addBooking = (booking: any) => {
    setBookingsLog((prev) => [booking, ...prev]);
  };

  return (
    <EmporiumContext.Provider
      value={{
        ageVerified,
        verifyAge,
        basket,
        addToBasket,
        removeFromBasket,
        updateBasketQuantity,
        clearBasket,
        basketTotal,
        myCollection,
        addToCollection,
        removeFromCollection,
        toggleCollectionOpened,
        activeView,
        setActiveView,
        selectedWhisky,
        setSelectedWhisky,
        searchQuery,
        setSearchQuery,
        ordersLog,
        addOrder,
        bookingsLog,
        addBooking
      }}
    >
      {children}
    </EmporiumContext.Provider>
  );
}

export function useEmporium() {
  const context = useContext(EmporiumContext);
  if (context === undefined) {
    throw new Error('useEmporium must be used within an EmporiumProvider');
  }
  return context;
}
