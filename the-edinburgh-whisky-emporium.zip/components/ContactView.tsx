'use client';

import React, { useState } from 'react';
import { Mail, Phone, MapPin, Compass, Check, ShieldAlert } from 'lucide-react';

export default function ContactView() {
  const [submitted, setSubmitted] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [enquiry, setEnquiry] = useState('PRIVATE_SOURCING');
  const [message, setMessage] = useState('');

  const handleEnquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email) return;
    setSubmitted(true);
  };

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold font-mono">ENQUIRY CHANNELS</span>
        <h2 className="font-serif text-3xl md:text-4xl">Charlotte Square Chambers</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"Connect with the selection committee. Request private sourcing files, corporate hospitality, and collection consultation.\""}
        </p>
      </section>

      <section className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Contact particulars (lg:span-5) */}
        <div className="lg:col-span-5 bg-ivory border border-brass/25 rounded p-6 md:p-8 space-y-6 shadow-sm">
          <div>
            <span className="text-[8px] uppercase tracking-widest text-brass font-mono font-bold">PHYSICAL BOUNDS</span>
            <h3 className="font-serif text-2xl text-walnut mt-1">The Emporium Chambers</h3>
            <p className="text-xs text-walnut/60 font-serif italic mt-0.5">Charlotte Square, Edinburgh New Town</p>
          </div>

          <div className="space-y-4 border-t border-b border-brass/10 py-5 text-xs text-walnut/80">
            <div className="flex items-start space-x-3">
              <MapPin className="w-5 h-5 text-brass mt-0.5 flex-shrink-0" />
              <div>
                <strong>Charlotte Square Chambers</strong>
                <p className="text-walnut/60 mt-0.5">17 Charlotte Square, Edinburgh, EH2 4DR, Scotland</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Phone className="w-5 h-5 text-brass mt-0.5 flex-shrink-0" />
              <div>
                <strong>Curator Registry Line</strong>
                <p className="text-walnut/60 mt-0.5">+44 (0) 131 555 1782</p>
              </div>
            </div>

            <div className="flex items-start space-x-3">
              <Mail className="w-5 h-5 text-brass mt-0.5 flex-shrink-0" />
              <div>
                <strong>Registrar Dispatch</strong>
                <p className="text-walnut/60 mt-0.5">committee@edinburghwhisky.scot</p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-[8px] uppercase tracking-widest text-brass font-mono font-bold">REGULAR VISITING TERMS</span>
            <div className="text-xs text-walnut/70 space-y-1.5 font-sans">
              <p className="flex justify-between"><span>Monday — Friday:</span> <span className="font-semibold text-walnut font-mono">10:00 - 18:00</span></p>
              <p className="flex justify-between"><span>Saturday:</span> <span className="font-semibold text-walnut font-mono">11:00 - 19:00</span></p>
              <p className="flex justify-between text-red-700 font-semibold"><span>Sunday (Sabbath Terms):</span> <span>CLOSED FOR STILL SLEEP</span></p>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Interactive enquiry form (lg:span-7) */}
        <div className="lg:col-span-7 bg-ivory border-fine p-6 md:p-8 rounded relative shadow-restrained">
          
          {submitted ? (
            <div className="text-center py-16 space-y-4 animate-in fade-in duration-300">
              <div className="w-12 h-12 rounded-full bg-forest/10 text-forest flex items-center justify-center mx-auto">
                <Check className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[10px] uppercase tracking-widest text-brass font-mono font-bold">TRANSMISSION SUCCESSFUL</span>
                <h4 className="font-serif text-2xl text-walnut mt-1">Enquiry Registered</h4>
                <p className="text-xs text-walnut/60 max-w-sm mx-auto leading-relaxed mt-2">
                  We have successfully filed your enquiry in our Charlotte Square desk drawer. A committee member will draft a reply under seal within 24 business hours.
                </p>
              </div>
              <button
                onClick={() => {
                  setSubmitted(false);
                  setName('');
                  setEmail('');
                  setMessage('');
                }}
                className="px-5 py-2 border border-brass text-xs uppercase tracking-widest font-bold text-brass hover:bg-brass/5"
              >
                File Another Enquiry
              </button>
            </div>
          ) : (
            <div className="space-y-6 animate-in fade-in duration-200">
              <div>
                <span className="text-[9px] uppercase tracking-widest text-brass font-bold">CHAMBERS CORRESPONDENCE</span>
                <h3 className="font-serif text-2xl text-walnut mt-1">Submit Private Enquiry</h3>
                <p className="text-xs text-walnut/60 border-b border-brass/10 pb-3.5">
                  Your details will be filed securely under bond. No telemetry trackers are active in this connection.
                </p>
              </div>

              <form onSubmit={handleEnquirySubmit} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Your Name</label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                      className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Email Address</label>
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Subject Curation Sector</label>
                  <select
                    value={enquiry}
                    onChange={(e) => setEnquiry(e.target.value)}
                    className="w-full bg-ivory border border-brass/40 p-2.5 focus:outline-none focus:border-brass text-xs text-walnut rounded font-bold"
                  >
                    <option value="PRIVATE_SOURCING">Private Sourcing — Rare Bottles Sourcing</option>
                    <option value="CELLAR_CONSULTATION">Cellaring Consultation — Private Inventory Maturation</option>
                    <option value="CORPORATE_GIFTS">Corporate Gifting & Wholesale Accounts</option>
                    <option value="EVENT_TICKETS">Private Tastings & Drawing Room Bookings</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Particulars of Enquiry Message</label>
                  <textarea
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                    placeholder="Provide details about your desired vintage year, budget ranges, or specific distillery interests..."
                    className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass text-xs text-walnut rounded"
                  ></textarea>
                </div>

                <div className="pt-4 text-right">
                  <button
                    type="submit"
                    className="px-6 py-3 bg-walnut hover:bg-forest text-ivory uppercase tracking-widest text-xs font-bold border border-brass shadow"
                  >
                    Transmit Correspondence Letter
                  </button>
                </div>
              </form>
            </div>
          )}

        </div>

      </section>

    </div>
  );
}
