'use client';

import React, { useState, useMemo } from 'react';
import { useEmporium } from './EmporiumProvider';
import { WHISKIES, Whisky } from '@/lib/data/whiskyData';
import { Filter, SlidersHorizontal, Search, RotateCcw, Compass, Check } from 'lucide-react';
import WhiskyFinder from './WhiskyFinder';

interface WhiskyViewProps {
  onSelectWhisky: (whisky: Whisky) => void;
  onAddToBasket: (whisky: Whisky) => void;
}

export default function WhiskyView({ onSelectWhisky, onAddToBasket }: WhiskyViewProps) {
  const { searchQuery, setSearchQuery } = useEmporium();
  
  // Local filter states
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [selectedStyle, setSelectedStyle] = useState<string>('All');
  const [selectedAge, setSelectedAge] = useState<string>('All');
  const [selectedRarity, setSelectedRarity] = useState<string>('All');
  const [selectedStrength, setSelectedStrength] = useState<string>('All');
  const [selectedCask, setSelectedCask] = useState<string>('All');
  const [showFinder, setShowFinder] = useState(false);

  // Available filter options
  const regions = ['All', 'Speyside', 'Highlands', 'Lowlands', 'Islay', 'Campbeltown', 'Islands'];
  const styles = ['All', 'Rich', 'Light', 'Peated', 'Smoky', 'Sherried', 'Citrus', 'Maritime', 'Floral', 'Spiced', 'Sweet', 'Dry'];
  const ages = ['All', 'NAS', '10+', '12+', '15+', '18+', '21+', '25+', '30+', '40+'];
  const rarities = ['All', '★', '★★', '★★★', '★★★★', '★★★★★'];
  const strengths = ['All', '40-46%', '46-55%', '55%+', 'Cask Strength'];
  const casks = ['All', 'Sherry', 'Bourbon', 'Port', 'Madeira', 'Wine', 'Refill Hogshead'];

  const resetAllFilters = () => {
    setSearchQuery('');
    setSelectedRegion('All');
    setSelectedStyle('All');
    setSelectedAge('All');
    setSelectedRarity('All');
    setSelectedStrength('All');
    setSelectedCask('All');
  };

  // Advanced filtering logic across all 100 whiskies
  const filteredWhiskies = useMemo(() => {
    return WHISKIES.filter((whisky) => {
      // 1. Search Query (Fuzzy matching across Name, Distillery, Region, Cask, and Keywords)
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesName = whisky.name.toLowerCase().includes(query);
        const matchesDistillery = whisky.distilleryName.toLowerCase().includes(query);
        const matchesRegion = whisky.region.toLowerCase().includes(query);
        const matchesCask = whisky.caskType.toLowerCase().includes(query);
        const matchesKeywords = whisky.characterKeywords.some((keyword) =>
          keyword.toLowerCase().includes(query)
        );
        if (!matchesName && !matchesDistillery && !matchesRegion && !matchesCask && !matchesKeywords) {
          return false;
        }
      }

      // 2. Region filter
      if (selectedRegion !== 'All' && whisky.region !== selectedRegion) {
        return false;
      }

      // 3. Style filter
      if (selectedStyle !== 'All' && !whisky.styleProfile.includes(selectedStyle as any)) {
        return false;
      }

      // 4. Age filter
      if (selectedAge !== 'All') {
        if (selectedAge === 'NAS') {
          if (whisky.age !== null) return false;
        } else {
          const minAge = parseInt(selectedAge);
          if (whisky.age === null || whisky.age < minAge) return false;
        }
      }

      // 5. Rarity filter
      if (selectedRarity !== 'All') {
        const starsCount = selectedRarity.length;
        if (whisky.rarityLevel !== starsCount) return false;
      }

      // 6. Strength filter
      if (selectedStrength !== 'All') {
        if (selectedStrength === '40-46%') {
          if (whisky.abv < 40 || whisky.abv > 46) return false;
        } else if (selectedStrength === '46-55%') {
          if (whisky.abv < 46 || whisky.abv > 55) return false;
        } else if (selectedStrength === '55%+') {
          if (whisky.abv < 55) return false;
        } else if (selectedStrength === 'Cask Strength') {
          if (whisky.abv < 50) return false; // Cask strength generally higher
        }
      }

      // 7. Cask filter
      if (selectedCask !== 'All') {
        const term = selectedCask.toLowerCase();
        if (!whisky.caskType.toLowerCase().includes(term)) return false;
      }

      return true;
    });
  }, [searchQuery, selectedRegion, selectedStyle, selectedAge, selectedRarity, selectedStrength, selectedCask]);

  return (
    <div className="space-y-10 pb-16">
      
      {/* Search Header Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">THE REGISTRY ARCHIVE</span>
        <h2 className="font-serif text-3xl md:text-4xl">The Whisky Catalog</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"A complete taxanomic audit of the emporium's allocations, containing rare official releases, independent single casks, and private reserve bottlings.\""}
        </p>

        {/* Questionnaire Trigger */}
        <div className="pt-2">
          <button
            onClick={() => setShowFinder(!showFinder)}
            className="px-6 py-2 bg-brass text-walnut uppercase tracking-widest text-[10px] font-bold hover:bg-brass-dark transition-all rounded inline-flex items-center space-x-2 shadow"
          >
            <Compass className="w-4 h-4 animate-spin-slow" />
            <span>{showFinder ? 'Close Advisor Panel' : 'Consult Selection Committee Quiz'}</span>
          </button>
        </div>
      </section>

      {/* Recommended consultation panel */}
      {showFinder && (
        <section className="max-w-7xl mx-auto px-4 md:px-8">
          <WhiskyFinder onSelectWhisky={onSelectWhisky} onAddToBasket={onAddToBasket} />
        </section>
      )}

      {/* Main filter-and-list interface */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-4 gap-8 items-start">
        
        {/* Left Side: Filter controls */}
        <div className="lg:col-span-1 bg-ivory border border-brass/25 rounded p-5 space-y-6 shadow-sm sticky top-28 z-30">
          <div className="flex justify-between items-center border-b border-brass/10 pb-3">
            <span className="text-xs uppercase font-bold tracking-widest text-walnut flex items-center space-x-1.5">
              <Filter className="w-3.5 h-3.5 text-brass" />
              <span>REGISTRY FILTERS</span>
            </span>
            <button
              onClick={resetAllFilters}
              className="text-[9px] uppercase tracking-widest text-red-700 hover:underline flex items-center space-x-0.5 font-semibold"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </div>

          {/* Search bar input within panel */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Search Registry</label>
            <div className="relative">
              <input
                type="text"
                placeholder="Search catalog terms..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut"
              />
              <Search className="absolute right-2 top-2.5 w-3.5 h-3.5 text-brass" />
            </div>
          </div>

          {/* Region filter */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Region of Origin</label>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="w-full bg-ivory border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut"
            >
              {regions.map(r => <option key={r} value={r}>{r === 'All' ? 'All Scotland' : r}</option>)}
            </select>
          </div>

          {/* Style filter */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Flavor Profile</label>
            <select
              value={selectedStyle}
              onChange={(e) => setSelectedStyle(e.target.value)}
              className="w-full bg-ivory border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut"
            >
              {styles.map(s => <option key={s} value={s}>{s === 'All' ? 'All Flavor Styles' : s}</option>)}
            </select>
          </div>

          {/* Age filter */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Age Statement</label>
            <select
              value={selectedAge}
              onChange={(e) => setSelectedAge(e.target.value)}
              className="w-full bg-ivory border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut"
            >
              {ages.map(a => <option key={a} value={a}>{a === 'All' ? 'All Statements' : a === 'NAS' ? 'NAS (No Age Statement)' : `${a} Years`}</option>)}
            </select>
          </div>

          {/* Rarity filter */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Rarity Tier Index</label>
            <select
              value={selectedRarity}
              onChange={(e) => setSelectedRarity(e.target.value)}
              className="w-full bg-ivory border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut font-mono"
            >
              {rarities.map(r => <option key={r} value={r}>{r === 'All' ? 'All Rarity levels' : r}</option>)}
            </select>
          </div>

          {/* Strength filter */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Strength (ABV)</label>
            <select
              value={selectedStrength}
              onChange={(e) => setSelectedStrength(e.target.value)}
              className="w-full bg-ivory border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut"
            >
              {strengths.map(s => <option key={s} value={s}>{s === 'All' ? 'All Strengths' : s}</option>)}
            </select>
          </div>

          {/* Cask Type filter */}
          <div className="space-y-1.5">
            <label className="text-[9px] uppercase tracking-wider font-bold text-brass-dark">Cask Wood Finish</label>
            <select
              value={selectedCask}
              onChange={(e) => setSelectedCask(e.target.value)}
              className="w-full bg-ivory border border-brass/35 text-xs p-2 focus:outline-none focus:border-brass rounded text-walnut"
            >
              {casks.map(c => <option key={c} value={c}>{c === 'All' ? 'All Wood Finishes' : c}</option>)}
            </select>
          </div>

          <div className="border-t border-brass/10 pt-3 text-center">
            <span className="text-[10px] font-mono text-walnut/40">
              AUDITED RESULTS: {filteredWhiskies.length} / 100 RECORDS
            </span>
          </div>
        </div>

        {/* Right Side: Product Card Grid */}
        <div className="lg:col-span-3 space-y-6">
          {filteredWhiskies.length === 0 ? (
            <div className="text-center p-20 border border-dashed border-brass/30 bg-[#fdfdfc] rounded">
              <Compass className="w-12 h-12 text-brass/20 mx-auto mb-4" />
              <h4 className="font-serif text-lg text-walnut">No records found matching filters.</h4>
              <p className="text-xs text-walnut/60 max-w-sm mx-auto mt-1 leading-relaxed">
                Adjust your search keywords or reset filter panels to explore our extensive 100 fictional catalog records.
              </p>
              <button
                onClick={resetAllFilters}
                className="mt-6 px-4 py-2 bg-walnut text-ivory text-xs uppercase tracking-widest font-semibold hover:bg-forest transition-colors rounded"
              >
                Reset Registry Search
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
              {filteredWhiskies.map((whisky) => (
                <div 
                  key={whisky.id}
                  onClick={() => onSelectWhisky(whisky)}
                  className="bg-ivory border border-brass/20 rounded p-4 flex flex-col justify-between hover:border-brass/55 cursor-pointer hover:shadow-restrained transition-all duration-300 group"
                >
                  {/* Small bottle visual container */}
                  <div className="h-44 bg-walnut/[0.02] border border-brass/10 rounded flex items-center justify-center p-2 relative overflow-hidden mb-4">
                    <div className="w-10 h-32 border border-brass/35 rounded-t-xl rounded-b bg-amber-800/5 relative flex flex-col items-center justify-end py-5 transition-transform duration-500 group-hover:scale-105">
                      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-amber-600/60 to-amber-500/20 h-24 rounded-b"></div>
                      <div className="w-3 h-5 bg-walnut/95 border border-brass/15 rounded-t -mt-8 z-10"></div>
                      
                      {/* Bottle small label */}
                      <div className="w-8 bg-ivory/95 border border-brass/35 p-0.5 text-[4px] text-center font-serif leading-none z-10">
                        <p className="font-bold text-walnut uppercase">{whisky.distilleryName.substring(0, 10)}</p>
                      </div>
                    </div>

                    {/* Rarity Level Overlap */}
                    <div className="absolute top-2 left-2 text-[8px] font-mono text-brass">
                      {'★'.repeat(whisky.rarityLevel)}
                    </div>
                    <div className="absolute bottom-2 right-2 text-[8px] font-mono text-walnut/40 uppercase">
                      {whisky.region}
                    </div>
                  </div>

                  {/* Metadata labels */}
                  <div className="space-y-1.5 flex-1 flex flex-col justify-between">
                    <div>
                      <span className="block text-[8px] uppercase tracking-widest text-brass font-bold leading-tight">
                        {whisky.distilleryName}
                      </span>
                      <h4 className="font-serif text-xs text-walnut font-medium line-clamp-2 leading-snug group-hover:text-brass transition-colors">
                        {whisky.name}
                      </h4>
                      <p className="text-[9px] text-walnut/50 font-mono mt-0.5 uppercase">
                        {whisky.abv}% ABV • {whisky.size}
                      </p>
                    </div>

                    <div className="pt-2.5 border-t border-brass/10 flex justify-between items-center mt-3.5">
                      <p className="font-serif text-sm font-semibold text-walnut">£{whisky.price}</p>
                      <span className="text-[9px] font-bold text-brass uppercase tracking-wider group-hover:translate-x-1 transition-transform">
                        View Record →
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

      </section>

    </div>
  );
}
