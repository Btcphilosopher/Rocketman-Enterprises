'use client';

import React from 'react';
import { useEmporium } from './EmporiumProvider';
import { WHISKIES, Whisky } from '@/lib/data/whiskyData';
import { Search, Compass, BookOpen, Clock, Heart, ShieldAlert } from 'lucide-react';
import RegionMap from './RegionMap';
import { motion } from 'motion/react';

interface HomeViewProps {
  onSelectWhisky: (whisky: Whisky) => void;
  onAddToBasket: (whisky: Whisky) => void;
}

export default function HomeView({ onSelectWhisky, onAddToBasket }: HomeViewProps) {
  const { setActiveView, setSearchQuery } = useEmporium();

  // Find 4 pristine, premium featured whiskies for the homepage catalog
  const featuredBottles = [
    WHISKIES.find(w => w.id === 'edw-0003'), // Speybank 15
    WHISKIES.find(w => w.id === 'edw-0013'), // Craigleith 25 Hertiage (Ultra luxury)
    WHISKIES.find(w => w.id === 'edw-0043'), // Port Charlotte 25 Heritage (Islay peated)
    WHISKIES.find(w => w.id === 'edw-0079')  // Blackford Cask Private #982
  ].filter(Boolean) as Whisky[];

  const handlePromptClick = (term: string) => {
    setSearchQuery(term);
    setActiveView('whisky');
  };

  const handleCollectionEnter = () => {
    setActiveView('whisky');
  };

  return (
    <div className="space-y-16 pb-16">
      
      {/* 1. EDITORIAL HOMEPAGE HERO */}
      <section className="relative w-full h-[540px] flex items-center justify-center bg-walnut text-ivory overflow-hidden border-b border-brass/20">
        
        {/* Atmospheric Background Image */}
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://picsum.photos/seed/edinburgh_whisky/1920/1080" 
            alt="The Charlotte Square Whisky Library" 
            className="w-full h-full object-cover filter brightness-[0.7] desaturate-[0.3]"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Shadow gradient overlays */}
        <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-walnut to-transparent z-10"></div>
        <div className="absolute inset-y-0 left-0 w-72 bg-gradient-to-r from-walnut/60 to-transparent z-10"></div>

        {/* Core Hero Typography */}
        <div className="relative z-20 text-center px-4 max-w-4xl space-y-6">
          <motion.p 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-xs uppercase tracking-[0.4em] text-brass font-bold"
          >
            ESTABLISHED 1782 · EDINBURGH
          </motion.p>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-serif text-4xl sm:text-5xl md:text-6xl tracking-tight text-[#f3efe6]"
          >
            THE HOUSE OF SCOTCH.
          </motion.h2>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="font-serif text-lg sm:text-xl md:text-2xl italic tracking-wide text-brass-dark"
          >
            Rare whisky. Edinburgh judgement.
          </motion.p>

          <div className="w-20 h-[1px] bg-brass mx-auto my-6"></div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-2"
          >
            <button
              onClick={() => setActiveView('whisky')}
              className="px-8 py-3.5 bg-ivory text-walnut uppercase tracking-widest text-xs font-bold border border-brass hover:bg-forest hover:text-ivory transition-all duration-300 shadow-md w-full sm:w-auto"
            >
              Enter the Collection
            </button>
            <button
              onClick={() => setActiveView('rare')}
              className="px-8 py-3.5 bg-transparent text-ivory uppercase tracking-widest text-xs font-bold border border-ivory/60 hover:border-brass hover:text-brass transition-all duration-300 w-full sm:w-auto"
            >
              Discover Rare & Old
            </button>
          </motion.div>
        </div>

        {/* Bottom Corner markings */}
        <div className="absolute bottom-4 left-4 text-[9px] font-mono uppercase tracking-widest text-brass/40 hidden md:block">
          RECORDS SECTION 01 // VOL. 17
        </div>
        <div className="absolute bottom-4 right-4 text-[9px] font-mono uppercase tracking-widest text-brass/40 hidden md:block">
          EDINBURGH COURIER TERMINAL
        </div>
      </section>

      {/* 2. SEARCH-FIRST HOMEPAGE DISCOVERY BOX */}
      <section className="max-w-4xl mx-auto px-4 md:px-8">
        <div className="bg-ivory border-fine p-6 md:p-8 rounded shadow-restrained text-center relative overflow-hidden">
          {/* Subtle floral/geometric detail */}
          <div className="absolute top-2 right-2 text-brass/10"><Compass className="w-16 h-16" /></div>

          <h3 className="font-serif text-lg text-walnut mb-2 uppercase tracking-wider">FIND YOUR SCOTCH</h3>
          <p className="text-xs text-walnut/60 mb-6 max-w-md mx-auto">
            Input a preferred style parameter, distillation year, or region keyword to instantly query the emporium registry.
          </p>

          {/* Large search input */}
          <div className="max-w-xl mx-auto mb-4 relative">
            <input
              type="text"
              placeholder="Search whisky, distillery, region or style..."
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handlePromptClick((e.target as HTMLInputElement).value);
                }
              }}
              className="w-full bg-transparent border-b border-brass-dark/60 text-base md:text-lg py-3 px-1 text-center font-serif text-walnut focus:outline-none focus:border-brass"
            />
            <div className="absolute right-2 top-3.5 text-brass"><Search className="w-5 h-5" /></div>
          </div>

          {/* Prompt terms list */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-4 text-[10px] uppercase font-mono text-walnut/50">
            <span>SUGGESTED FILTERS:</span>
            {[
              'Islay whisky',
              '18 year old Speyside',
              'cask strength',
              'sherry matured',
              'rare whisky'
            ].map(prompt => (
              <button
                key={prompt}
                onClick={() => handlePromptClick(prompt)}
                className="bg-brass/5 hover:bg-brass/15 border border-brass/20 text-brass-dark px-2.5 py-1 rounded transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. BRAND INTRODUCTION */}
      <section className="max-w-4xl mx-auto px-4 md:px-8 text-center space-y-6">
        <span className="text-[10px] uppercase tracking-[0.3em] text-brass font-bold">
          SCOTLAND, SELECTED.
        </span>
        <h3 className="font-serif text-3xl md:text-4xl tracking-tight text-walnut max-w-2xl mx-auto leading-tight font-light">
          {"\"For those who believe exceptional whisky is worth looking for.\""}
        </h3>
        <p className="text-xs md:text-sm text-walnut/75 leading-relaxed max-w-2xl mx-auto font-sans">
          The Edinburgh Whisky Emporium is not a supermarket, nor is it a tourist souvenir depot. We are a Scottish whisky institution. Our panel of selectors searches across Scotland{"'"}s mountains, coastal glens, and deep river basins to discover small-batch independent bottlings, single cask strength reserves, and magnificent closed-distillery lots. Every item in our catalog is backed by genuine provenance and historic Edinburgh judgement.
        </p>
        <div className="pt-2">
          <button
            onClick={() => setActiveView('library')}
            className="text-xs uppercase tracking-widest text-brass hover:text-brass-dark font-semibold border-b border-brass pb-0.5"
          >
            Read Our Manifesto
          </button>
        </div>
      </section>

      {/* 4. FEATURED PRODUCTS GRID */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 border-b border-brass/15 pb-4">
          <div>
            <span className="text-[9px] uppercase tracking-[0.25em] text-brass font-bold">THE HIGHLIGHTS</span>
            <h3 className="font-serif text-2xl md:text-3xl text-walnut">The Collection</h3>
          </div>
          <button
            onClick={handleCollectionEnter}
            className="text-[11px] font-semibold tracking-wider text-brass hover:text-brass-dark uppercase mt-2 sm:mt-0 flex items-center space-x-1"
          >
            <span>View All 100 Whiskies</span>
            <span>→</span>
          </button>
        </div>

        {/* Grid of featured product cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredBottles.map((whisky) => (
            <div 
              key={whisky.id}
              onClick={() => onSelectWhisky(whisky)}
              className="bg-ivory border border-brass/20 rounded p-4 flex flex-col justify-between hover:border-brass/55 cursor-pointer hover:shadow-restrained transition-all duration-300 group"
            >
              {/* Bottle Simulator rendering inside card */}
              <div className="h-56 bg-walnut/[0.02] border border-brass/10 rounded flex items-center justify-center p-4 relative overflow-hidden mb-4">
                <div className="w-14 h-40 border border-brass/40 rounded-t-2xl rounded-b-md bg-amber-800/5 relative flex flex-col items-center justify-end py-6 transition-transform duration-500 group-hover:scale-105">
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-amber-700/60 to-amber-500/20 h-28 rounded-b"></div>
                  <div className="w-4 h-6 bg-walnut/95 border border-brass/15 rounded-t -mt-10 z-10"></div>
                  
                  {/* Bottle Label */}
                  <div className="w-10 bg-ivory/95 border border-brass/35 p-1 text-[5px] text-center font-serif leading-none z-10 shadow-sm">
                    <p className="font-bold text-walnut uppercase">{whisky.distilleryName.substring(0, 10)}</p>
                    <div className="w-3 h-[0.5px] bg-brass/45 mx-auto my-0.5"></div>
                    <p className="text-brass-dark">{whisky.age ? `${whisky.age} YR` : 'RESERVE'}</p>
                  </div>
                </div>

                {/* Overlap Rarity Indicators */}
                <div className="absolute top-2 left-2 text-[9px] font-mono text-brass">
                  {'★'.repeat(whisky.rarityLevel)}
                </div>
                <div className="absolute bottom-2 right-2 text-[8px] font-mono text-walnut/40 uppercase">
                  {whisky.region}
                </div>
              </div>

              {/* Text detail */}
              <div className="space-y-1.5 flex-1 flex flex-col justify-between">
                <div>
                  <span className="block text-[9px] uppercase tracking-widest text-brass font-bold">
                    {whisky.distilleryName}
                  </span>
                  <h4 className="font-serif text-sm text-walnut font-medium line-clamp-2 leading-snug group-hover:text-brass transition-colors">
                    {whisky.name}
                  </h4>
                  <p className="text-[9px] text-walnut/50 font-mono mt-1 uppercase">
                    {whisky.caskType.split(',')[0]} • {whisky.abv}% ABV
                  </p>
                </div>

                <div className="pt-3 border-t border-brass/10 flex justify-between items-center mt-3">
                  <p className="font-serif text-sm font-semibold text-walnut">£{whisky.price}</p>
                  <span className="text-[10px] font-semibold text-brass uppercase tracking-wider group-hover:translate-x-1 transition-transform">
                    View Record →
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. INTERACTIVE REGIONAL MAP PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 py-4 bg-brass/[0.03] border-t border-b border-brass/20">
        <div className="max-w-3xl mx-auto text-center space-y-3 mb-10 pt-4">
          <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">INTERACTIVE ENCYCLOPEDIA</span>
          <h3 className="font-serif text-3xl text-walnut">Scotland’s Whisky Regions</h3>
          <p className="text-xs text-walnut/60 max-w-lg mx-auto leading-relaxed">
            Every geographic coordinate of Scotland molds the flavor compounds of the barley. Tap the mapping points below to explore characteristic profiles.
          </p>
        </div>

        <RegionMap onSelectWhisky={onSelectWhisky} />
      </section>

      {/* 6. CHARLOTTE SQUARE TOWNHOUSE ROOMS PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-5 space-y-6">
            <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">PHYSICAL SEAT</span>
            <h3 className="font-serif text-3xl text-walnut leading-tight font-light">
              The Townhouse on Charlotte Square
            </h3>
            <p className="text-xs text-walnut/70 leading-relaxed font-sans">
              Our magnificent physical location in Edinburgh{"'"}s New Town is an exact representation of Enlightenment architecture. Inside these sandstone walls lies the ground-floor spirits room, our private tasting library holding historic rare volumes, and the secure subterranean iron-gated vaults where rare private allocations are matured under bond.
            </p>

            <div className="space-y-3">
              {[
                { name: 'Ground-Floor Retail Vault', desc: 'Browse the catalog physically under advice.' },
                { name: 'Subterranean Vault Room', desc: 'Secure temperature-controlled collectors room.' },
                { name: 'Tasting Rooms & Fireplace', desc: 'Private booking events led by Master of Malts.' }
              ].map((room) => (
                <div key={room.name} className="flex items-start space-x-3 text-xs">
                  <div className="w-1.5 h-1.5 bg-brass mt-1.5 rounded-full"></div>
                  <div>
                    <strong className="block text-walnut">{room.name}</strong>
                    <span className="text-walnut/50 font-serif italic text-[11px]">{room.desc}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <button
                onClick={() => setActiveView('house')}
                className="px-6 py-2.5 bg-walnut hover:bg-forest text-ivory uppercase tracking-widest text-xs font-bold transition-all border border-brass shadow"
              >
                Inspect the Townhouse
              </button>
            </div>
          </div>

          <div className="md:col-span-7 bg-walnut/5 border border-brass/25 rounded p-3">
            <img 
              src="https://picsum.photos/seed/edinburgh_townhouse/800/500" 
              alt="Charlotte Square Townhouse Exterior" 
              className="w-full h-auto object-cover rounded shadow filter brightness-[0.9] desaturate-[0.1]"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* 7. JOURNAL PULL SECTION */}
      <section className="max-w-4xl mx-auto px-4 md:px-8 text-center bg-walnut text-ivory p-8 md:p-12 border border-brass/40 relative">
        <div className="absolute top-2 left-2 w-3 h-3 border-t border-l border-brass/50"></div>
        <div className="absolute top-2 right-2 w-3 h-3 border-t border-r border-brass/50"></div>
        <div className="absolute bottom-2 left-2 w-3 h-3 border-b border-l border-brass/50"></div>
        <div className="absolute bottom-2 right-2 w-3 h-3 border-b border-r border-brass/50"></div>

        <div className="space-y-4 max-w-xl mx-auto">
          <BookOpen className="w-8 h-8 text-brass mx-auto mb-2" />
          <span className="text-[10px] uppercase tracking-[0.3em] text-brass">THE EMPORIUM JOURNAL // ARTICLE</span>
          <h4 className="font-serif text-2xl text-ivory">The Enlightenment of the Dram</h4>
          <p className="text-xs text-ivory/70 leading-relaxed font-serif italic">
            {"\"How the jurists, scholars, and scientists of Edinburgh's golden age first taxonomic-classified the Scotch of Speyside and Islay...\""}
          </p>
          <div className="pt-4">
            <button
              onClick={() => setActiveView('library')}
              className="px-6 py-2.5 bg-ivory text-walnut uppercase tracking-widest text-[10px] font-bold hover:bg-brass hover:text-walnut transition-all"
            >
              Read full publication
            </button>
          </div>
        </div>
      </section>

    </div>
  );
}
