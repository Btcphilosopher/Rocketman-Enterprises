'use client';

import React, { useState } from 'react';
import { JOURNAL_ARTICLES, JournalArticle } from '@/lib/data/whiskyData';
import { BookOpen, Calendar, ArrowLeft, Clock } from 'lucide-react';

export default function LibraryView() {
  const [activeArticle, setActiveArticle] = useState<JournalArticle | null>(null);

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4 no-print">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">THE INTELLECTUAL COMPASS</span>
        <h2 className="font-serif text-3xl md:text-4xl">The Whisky Library</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"The House of Scotch is built on scholarship. Explore treatises on historic distillation, maturation science, collecting and Edinburgh heritage.\""}
        </p>
      </section>

      {/* Main Container */}
      <section className="max-w-4xl mx-auto px-4 md:px-8">
        
        {/* LIST VIEW */}
        {!activeArticle ? (
          <div className="space-y-12 animate-in fade-in duration-200">
            <div className="border-b border-brass/25 pb-3">
              <h3 className="font-serif text-xl text-walnut uppercase tracking-widest">Journal Catalog</h3>
            </div>

            <div className="space-y-10">
              {JOURNAL_ARTICLES.map((art) => (
                <div 
                  key={art.id}
                  onClick={() => setActiveArticle(art)}
                  className="group cursor-pointer space-y-3.5 border-b border-brass/10 pb-8"
                >
                  <div className="flex items-center space-x-3 text-[9px] uppercase tracking-wider text-brass font-bold font-mono">
                    <span>{art.category}</span>
                    <span className="text-walnut/30">•</span>
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {art.readTime}</span>
                  </div>

                  <h4 className="font-serif text-2xl sm:text-3xl text-walnut leading-tight font-light group-hover:text-brass transition-colors">
                    {art.title}
                  </h4>

                  <p className="font-serif text-base italic text-brass-dark tracking-wide">
                    {art.subtitle}
                  </p>

                  <p className="text-xs text-walnut/75 leading-relaxed font-sans max-w-2xl line-clamp-2">
                    {art.summary}
                  </p>

                  <div className="flex items-center justify-between pt-2">
                    <p className="text-[10px] text-walnut/50 font-serif italic">
                      Written by: {art.author} — {art.date}
                    </p>
                    <span className="text-xs uppercase tracking-widest text-brass group-hover:translate-x-1.5 transition-transform font-bold font-mono">
                      Read Treatise →
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          /* SCHOLARLY ARTICLE READER VIEW */
          <div className="space-y-8 animate-in fade-in duration-300 print:p-0">
            {/* Back action */}
            <button
              onClick={() => setActiveArticle(null)}
              className="text-xs uppercase tracking-widest text-walnut hover:text-brass font-bold font-mono flex items-center space-x-1.5 no-print"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Journal</span>
            </button>

            {/* Article content sheet */}
            <article className="border-fine bg-[#fdfdfc] p-8 md:p-12 rounded relative shadow-sm overflow-hidden border-double border-4">
              
              {/* Header profile */}
              <div className="text-center space-y-4 mb-10 border-b border-brass/15 pb-8">
                <div className="flex justify-center items-center space-x-3 text-[10px] uppercase tracking-widest font-mono text-brass font-bold">
                  <span>{activeArticle.category}</span>
                  <span className="text-walnut/30">•</span>
                  <span>{activeArticle.readTime}</span>
                </div>

                <h3 className="font-serif text-3xl md:text-4xl text-walnut leading-tight font-light tracking-tight max-w-2xl mx-auto">
                  {activeArticle.title}
                </h3>

                <p className="font-serif text-lg italic text-brass-dark tracking-wide max-w-xl mx-auto leading-relaxed">
                  {"\""}{activeArticle.subtitle}{"\""}
                </p>

                <div className="pt-4 flex flex-col items-center justify-center space-y-1 text-[11px] text-walnut/60 font-serif italic">
                  <p>COMPILED BY: <span className="font-semibold text-walnut">{activeArticle.author}</span></p>
                  <p>OFFICIAL JOURNAL RECORD DEED — {activeArticle.date.toUpperCase()}</p>
                </div>
              </div>

              {/* Body Paragraph list */}
              <div className="space-y-6 font-serif text-sm md:text-base text-walnut/90 leading-relaxed max-w-2xl mx-auto text-justify">
                {activeArticle.content.map((para, idx) => {
                  if (idx === 0) {
                    // Inject a drop cap on the first paragraph for historic publishing feel!
                    const firstChar = para.charAt(0);
                    const remainingText = para.substring(1);
                    return (
                      <p key={idx} className="relative first-letter:float-left first-letter:text-5xl first-letter:font-serif first-letter:font-bold first-letter:mr-3 first-letter:mt-1 first-letter:text-brass leading-relaxed">
                        {remainingText}
                      </p>
                    );
                  }
                  return <p key={idx}>{para}</p>;
                })}

                {/* Pull Quote */}
                {activeArticle.pullQuote && (
                  <blockquote className="my-10 border-t border-b border-brass/20 py-6 text-center max-w-lg mx-auto">
                    <p className="font-serif text-xl italic text-brass-dark leading-relaxed">
                      {"\""}{activeArticle.pullQuote}{"\""}
                    </p>
                  </blockquote>
                )}
              </div>

              {/* Footnotes */}
              {activeArticle.footnotes && activeArticle.footnotes.length > 0 && (
                <div className="mt-12 pt-8 border-t border-brass/15 font-sans text-[10px] text-walnut/50 space-y-1.5 max-w-2xl mx-auto">
                  <span className="block font-bold uppercase tracking-wider text-brass-dark font-mono mb-2">SCHOLARLY FOOTNOTES & CITATIONS</span>
                  {activeArticle.footnotes.map((note, index) => (
                    <p key={index} className="leading-relaxed">
                      {note}
                    </p>
                  ))}
                </div>
              )}

              {/* Reader actions */}
              <div className="mt-12 pt-6 border-t border-brass/10 flex items-center justify-between text-[11px] font-mono text-walnut/40 no-print">
                <span>Charlotte Square Library Archive</span>
                <button
                  onClick={() => window.print()}
                  className="text-brass hover:underline uppercase font-bold"
                >
                  Print Treatise Deed
                </button>
              </div>

            </article>
          </div>
        )}

      </section>

    </div>
  );
}
