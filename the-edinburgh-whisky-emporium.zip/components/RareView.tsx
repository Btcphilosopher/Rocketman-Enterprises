'use client';

import React from 'react';
import { WHISKIES, Whisky } from '@/lib/data/whiskyData';
import { ShieldCheck, Compass, Sparkles, BookOpen } from 'lucide-react';

interface RareViewProps {
  onSelectWhisky: (whisky: Whisky) => void;
}

export default function RareView({ onSelectWhisky }: RareViewProps) {
  // Filter elite bottles (Rarity >= 4 or closed distilleries)
  const eliteWhiskies = WHISKIES.filter(
    (w) => w.rarityLevel >= 4 || w.distilleryName.includes('Kildalton') || w.distilleryName.includes('Corstorphine')
  ).slice(0, 9); // Take top 9 for beautiful display

  return (
    <div className="bg-walnut text-ivory min-h-screen py-12 px-4 md:px-8 space-y-16 selection:bg-brass selection:text-walnut">
      
      {/* Editorial Header */}
      <section className="max-w-4xl mx-auto text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.4em] text-brass font-bold">
          THE GOLDEN SEAL
        </span>
        <h2 className="font-serif text-4xl sm:text-5xl tracking-tight text-[#f3efe6]">
          RARE & OLD
        </h2>
        <div className="w-16 h-[1px] bg-brass mx-auto my-4"></div>
        <p className="text-xs sm:text-sm font-serif italic text-[#dfd9ce]/80 max-w-lg mx-auto leading-relaxed">
          {"\"Welcome to the Vault Archives. This section represents our most guarded small-batch casks and allocations from silent distilleries. Access is highly selective.\""}
        </p>
      </section>

      {/* Rarity Index Explanation Banner */}
      <section className="max-w-5xl mx-auto border border-brass/30 bg-walnut/40 p-6 md:p-8 rounded relative overflow-hidden">
        {/* Subtle background graphic */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none">
          <BookOpen className="w-full h-full text-brass" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
          <div className="md:col-span-4 space-y-2">
            <span className="text-[8px] uppercase tracking-widest text-brass font-mono">OBJECTIVE AUDIT PROTOCOL</span>
            <h3 className="font-serif text-xl text-ivory">The Rarity Index Explained</h3>
            <p className="text-[11px] text-[#dfd9ce]/60 leading-relaxed font-sans">
              Unlike subjective quality rankings, our stars represent quantifiable criteria based on limited bottle availability, aging brackets, and active distillery status.
            </p>
          </div>

          <div className="md:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="border border-brass/10 p-4 rounded bg-walnut/50 space-y-1">
              <span className="text-xs text-brass font-mono font-bold">★★★★★ (5 Stars)</span>
              <p className="text-[10px] uppercase text-[#dfd9ce]/70 tracking-wider">Silent Distillery & Single Casks</p>
              <p className="text-[10px] text-[#dfd9ce]/50 leading-relaxed">
                Bottles produced by ghost distilleries that have been demolished, or private single casks where remaining stock is under 300 bottles globally.
              </p>
            </div>
            <div className="border border-brass/10 p-4 rounded bg-walnut/50 space-y-1">
              <span className="text-xs text-brass font-mono font-bold">★★★★ (4 Stars)</span>
              <p className="text-[10px] uppercase text-[#dfd9ce]/70 tracking-wider">Highly Aged Allocations</p>
              <p className="text-[10px] text-[#dfd9ce]/50 leading-relaxed">
                Expressions that have completed a minimum of 21 years of active oak sleep. Subject to strict annual bottle allowances.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Flagship Editorial Products Grid */}
      <section className="max-w-7xl mx-auto space-y-8">
        <div className="border-b border-brass/25 pb-4">
          <h3 className="font-serif text-xl sm:text-2xl text-ivory tracking-wider uppercase">The Vault Catalogue</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {eliteWhiskies.map((whisky) => (
            <div 
              key={whisky.id}
              onClick={() => onSelectWhisky(whisky)}
              className="bg-walnut/30 border border-brass/20 rounded p-6 flex flex-col justify-between hover:border-brass/70 cursor-pointer transition-all duration-300 group hover:bg-walnut/50"
            >
              {/* Massive bottle display container */}
              <div className="h-64 bg-black/20 border border-brass/10 rounded flex items-center justify-center p-4 relative overflow-hidden mb-6">
                <div className="w-16 h-48 border border-brass/35 rounded-t-3xl rounded-b bg-amber-900/10 relative flex flex-col items-center justify-end py-8 transition-transform duration-500 group-hover:scale-105">
                  {/* Rich deep amber gold liquid color gradient */}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-amber-800 via-amber-600/50 to-amber-500/10 h-[86%] rounded-b"></div>
                  <div className="w-4 h-8 bg-walnut border border-brass/20 rounded-t -mt-10 z-10"></div>
                  
                  {/* Bottle Label */}
                  <div className="w-12 bg-[#fdfdfc]/95 border border-brass p-1 text-[5px] text-center font-serif leading-none z-10 text-walnut">
                    <p className="font-bold uppercase tracking-wide text-walnut">{whisky.distilleryName.substring(0, 10)}</p>
                    <p className="text-brass-dark text-[4px] mt-0.5">{whisky.age ? `${whisky.age} YRS OLD` : 'ARCHIVE'}</p>
                  </div>
                </div>

                <div className="absolute top-4 left-4 text-xs font-mono text-brass">
                  {'★'.repeat(whisky.rarityLevel)}
                </div>
                {whisky.distilleryId === 'kildalton-archive' || whisky.distilleryId === 'corstorphine' ? (
                  <div className="absolute top-4 right-4 bg-red-950/40 text-red-400 border border-red-900/40 text-[8px] px-1.5 py-0.5 rounded font-mono font-bold uppercase tracking-widest">
                    SILENT MALT
                  </div>
                ) : null}
              </div>

              {/* Specs & Info */}
              <div className="space-y-4">
                <div>
                  <span className="text-[10px] uppercase tracking-widest text-brass font-bold">
                    {whisky.region} SINGLE CASK
                  </span>
                  <h4 className="font-serif text-lg text-ivory font-light leading-tight mt-1 group-hover:text-brass transition-colors">
                    {whisky.name}
                  </h4>
                  <p className="text-[10px] text-[#dfd9ce]/50 font-mono mt-1 leading-relaxed">
                    CASK: {whisky.caskType}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 py-2.5 border-t border-b border-brass/10 text-[10px] font-mono text-[#dfd9ce]/60">
                  <div>
                    <span>ABV: {whisky.abv}%</span>
                  </div>
                  <div className="text-right">
                    <span>BOTTLE NO: {whisky.bottleNumber}</span>
                  </div>
                </div>

                <div className="flex justify-between items-center pt-2">
                  <p className="font-serif text-lg font-semibold text-brass">£{whisky.price.toLocaleString()}</p>
                  <span className="text-[10px] font-bold text-brass uppercase tracking-widest group-hover:translate-x-1.5 transition-transform flex items-center space-x-1">
                    <span>Inspect Record</span>
                    <span>→</span>
                  </span>
                </div>
              </div>

            </div>
          ))}
        </div>
      </section>

      {/* Beautiful Trust Badge Footer */}
      <section className="max-w-4xl mx-auto text-center border-t border-brass/15 pt-12 flex flex-col items-center space-y-4">
        <ShieldCheck className="w-10 h-10 text-brass" />
        <span className="text-[10px] uppercase tracking-[0.3em] text-brass">CERTIFIED BOND RECONCILIATION</span>
        <p className="text-xs text-[#dfd9ce]/60 leading-relaxed max-w-md">
          Each rare bottle dispatched from Charlotte Square holds an exclusive, printable digital Certificate of Provenance containing audit logs and signatures of the committee members.
        </p>
      </section>

    </div>
  );
}
