'use client';

import React, { useState } from 'react';
import { BookOpen, Compass, ShieldAlert, Sparkles, MapPin } from 'lucide-react';

export default function HouseView() {
  const [activeFloor, setActiveFloor] = useState<'vault' | 'retail' | 'library' | 'cellar'>('retail');

  const floorplans = {
    retail: {
      title: 'The Ground-Floor Spirits Room',
      subtitle: 'Victorian Walnut Cases & Stone Sills',
      desc: 'The immediate threshold off Charlotte Square. Here, under high Georgian ceilings, our signature active expressions are showcased on dark walnut shelving. Our keepers wait behind heavy brass-mounted counters to consult with clients.',
      details: [
        'Over 100 signature expressions available for immediate acquisition',
        'Staffed by fully certified Whisky Curation specialists',
        'Traditional brass scales and historical ledger reference files'
      ],
      architectNote: 'Designed in 1792 by Robert Adam, featuring original polished sandstone flags and double-aspect sash windows looking over the central gardens.'
    },
    library: {
      title: 'The First-Floor Tasting Library',
      subtitle: 'Where Philosophy Meets Maturation',
      desc: 'The intellectual heart of the House. Surrounded by floor-to-ceiling bookshelves holding rare 18th-century scientific and philosophical treatises, clients sit in deep leather wingback chairs under brass reading lamps to sample rare flights.',
      details: [
        'Contains our rare 18th-century Edinburgh Enlightenment monographs',
        'Hosted tastings led directly by our Master of Malts',
        'A warm, roaring open coal hearth burning during winter terms'
      ],
      architectNote: 'Features authentic plaster cornices depicting Scottish thistle patterns and a magnificent Carrara marble fireplace.'
    },
    vault: {
      title: 'The Subterranean Rare Vault',
      subtitle: 'Iron Gates & Controlled Dampness',
      desc: 'Behind thick iron-barred gates and temperature-locked sandstone walls lies the vault. This secure, silent vault contains our collection of single cask reserves, vintage bottlings, and extremely scarce silent-distillery cases.',
      details: [
        'Secure double-lock entry system with strict curator supervision',
        'Atmospheric dunnage conditions: 12°C constant, 75% humidity',
        'Private collectors reserves available for long-term bound cellaring'
      ],
      architectNote: 'Originally constructed as a secure bank depository during the Napoleonic wars, maintaining 1.5-meter thick Scottish basalt foundations.'
    },
    cellar: {
      title: 'The Stone Cellar Room',
      subtitle: 'Underground Tasting Tables & Oak Pipes',
      desc: 'Deep below the ground, where the street noises disappear. Surrounded by raw stone walls and rows of maturing casks, clients participate in coastal and heavily peated sensory masterclasses under low candlelight.',
      details: [
        'Damp stone walls that preserve ancient oak spirit oils',
        'Maturing private casks owned directly by the emporium committee',
        'A long, heavy English oak refectory table seating up to 12 guests'
      ],
      architectNote: 'Retains original curved barrel-vaulted brickwork ceilings and direct-drainage channels.'
    }
  };

  const currentFloor = floorplans[activeFloor];

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">PHYSICAL TOPOGRAPHY</span>
        <h2 className="font-serif text-3xl md:text-4xl">The Townhouse on Charlotte Square</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"A multi-floor architectural journey through our historic Edinburgh headquarters. Hover or select floors to inspect rooms.\""}
        </p>
      </section>

      {/* Main Floor-Planner Grid */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        
        {/* LEFT SIDE: Architectural Stack Diagram (lg:span-6) */}
        <div className="lg:col-span-6 bg-walnut/5 border border-brass/25 rounded p-6 flex flex-col justify-between relative min-h-[450px]">
          <div className="flex items-center justify-between text-[10px] text-brass">
            <div className="flex items-center space-x-1.5 font-bold uppercase tracking-wider">
              <Compass className="w-4 h-4 animate-spin-slow" />
              <span>THE TOWNHOUSE STACK DIAGRAM</span>
            </div>
            <span className="font-mono text-walnut/40">SEC: ED-TOWN-CS17</span>
          </div>

          {/* Graphical Representation of floors stacked */}
          <div className="my-10 space-y-4 max-w-sm mx-auto w-full">
            {[
              { id: 'library' as const, num: 'FLR 1', name: 'THE TASTING LIBRARY' },
              { id: 'retail' as const, num: 'G-FLR', name: 'GROUND SPIRITS ROOM' },
              { id: 'vault' as const, num: 'BSMT', name: 'THE SUBTERRANEAN VAULT' },
              { id: 'cellar' as const, num: 'CELL', name: 'THE STONE CELLAR' }
            ].map((floor) => {
              const isActive = activeFloor === floor.id;
              return (
                <button
                  key={floor.id}
                  onClick={() => setActiveFloor(floor.id)}
                  className={`w-full p-4 text-left border rounded transition-all duration-300 relative flex justify-between items-center group focus:outline-none ${
                    isActive 
                      ? 'bg-walnut text-ivory border-brass shadow-md translate-x-2' 
                      : 'bg-ivory text-walnut border-brass/25 hover:border-brass/70'
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    <span className="font-mono text-xs text-brass font-bold">{floor.num}</span>
                    <span className="font-serif text-sm tracking-wide font-medium">{floor.name}</span>
                  </div>
                  {isActive && <Sparkles className="w-4 h-4 text-brass animate-pulse" />}
                  {!isActive && <span className="text-[10px] text-walnut/40 uppercase group-hover:underline">Inspect</span>}
                </button>
              );
            })}
          </div>

          <div className="text-center text-[10px] font-serif italic text-walnut/40">
            Interactive structural diagram representing original Robert Adam foundations.
          </div>
        </div>

        {/* RIGHT SIDE: Floor dossier content (lg:span-6) */}
        <div className="lg:col-span-6 bg-ivory border-fine p-6 md:p-8 rounded relative shadow-restrained flex flex-col justify-between">
          
          <div>
            <span className="text-[9px] uppercase tracking-widest text-brass font-bold">CHAMBER SPECS DEED</span>
            <h3 className="font-serif text-2xl md:text-3xl text-walnut mt-1 mb-2">
              {currentFloor.title}
            </h3>
            <p className="font-serif text-xs italic text-brass-dark mb-4 border-b border-brass/10 pb-2">
              {currentFloor.subtitle}
            </p>

            <p className="text-xs text-walnut/80 leading-relaxed font-sans mb-6">
              {currentFloor.desc}
            </p>

            <div className="space-y-3 bg-brass/5 border border-brass/20 p-4 rounded mb-6">
              <span className="block text-[8px] uppercase tracking-widest text-brass-dark font-bold font-mono">ROOM OPERATIONS & SPECIFICATION</span>
              {currentFloor.details.map((detail, idx) => (
                <div key={idx} className="flex items-start space-x-2 text-xs">
                  <div className="w-1.5 h-1.5 bg-brass mt-1.5 rounded-full flex-shrink-0"></div>
                  <span className="text-walnut/80 leading-snug">{detail}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-brass/10">
            <span className="block text-[8px] uppercase tracking-widest text-brass-dark font-mono font-bold mb-1">ARCHITECT’S STRUCTURAL NOTES</span>
            <p className="text-[11px] font-serif italic text-walnut/60 leading-relaxed">
              {"\""}{currentFloor.architectNote}{"\""}
            </p>
          </div>

        </div>

      </section>

    </div>
  );
}
