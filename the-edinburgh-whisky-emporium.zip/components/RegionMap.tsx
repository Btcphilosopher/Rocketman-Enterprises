'use client';

import React, { useState } from 'react';
import { REGIONS_DATA, WHISKIES, Whisky } from '@/lib/data/whiskyData';
import { Map, MapPin, Sparkles, BookOpen } from 'lucide-react';

interface RegionMapProps {
  onSelectWhisky: (whisky: Whisky) => void;
}

export default function RegionMap({ onSelectWhisky }: RegionMapProps) {
  const [activeRegion, setActiveRegion] = useState<keyof typeof REGIONS_DATA>('Speyside');

  const regionInfo = REGIONS_DATA[activeRegion];
  
  // Find up to 3 featured whiskies for this region
  const featuredWhiskies = WHISKIES.filter(
    (w) => w.region === activeRegion && w.rarityLevel >= 4
  ).slice(0, 3);

  const regions: { id: keyof typeof REGIONS_DATA; name: string; top: string; left: string; size: string }[] = [
    { id: 'Highlands', name: 'Highlands', top: '25%', left: '42%', size: 'w-24 h-24' },
    { id: 'Speyside', name: 'Speyside', top: '28%', left: '68%', size: 'w-14 h-14' },
    { id: 'Islands', name: 'Islands', top: '20%', left: '15%', size: 'w-20 h-20' },
    { id: 'Islay', name: 'Islay', top: '55%', left: '10%', size: 'w-12 h-12' },
    { id: 'Lowlands', name: 'Lowlands', top: '70%', left: '48%', size: 'w-20 h-20' },
    { id: 'Campbeltown', name: 'Campbeltown', top: '65%', left: '25%', size: 'w-10 h-10' }
  ];

  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch py-6">
      
      {/* Left side: Cartographic representation */}
      <div className="lg:col-span-7 bg-walnut/5 border border-brass/25 rounded p-6 relative min-h-[420px] flex flex-col justify-between overflow-hidden">
        {/* Subtle grid styling */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{
          backgroundImage: 'radial-gradient(#1c140e 1.5px, transparent 1.5px)',
          backgroundSize: '16px 16px'
        }}></div>

        <div className="flex items-center justify-between z-10">
          <div className="flex items-center space-x-2 text-brass">
            <Map className="w-4 h-4" />
            <span className="text-[10px] font-semibold uppercase tracking-[0.2em]">SCOTLAND CARTOGRAPHIC COMPASS</span>
          </div>
          <span className="text-[9px] font-mono text-walnut/40">GRID REF: NT 253 741</span>
        </div>

        {/* The Map Layout container */}
        <div className="relative w-full h-[320px] my-4 mx-auto max-w-md">
          {/* Decorative compass rose */}
          <div className="absolute top-4 right-4 w-12 h-12 border border-brass/20 rounded-full flex items-center justify-center text-brass/40 text-[8px] font-mono">
            <div className="absolute w-full h-[1px] bg-brass/10 rotate-45"></div>
            <div className="absolute w-full h-[1px] bg-brass/10 -rotate-45"></div>
            N
          </div>

          {/* Region selector pins placed logically over a simulated map coordinate system */}
          {regions.map((reg) => {
            const isActive = activeRegion === reg.id;
            return (
              <button
                key={reg.id}
                onClick={() => setActiveRegion(reg.id)}
                style={{ top: reg.top, left: reg.left }}
                className="absolute transform -translate-x-1/2 -translate-y-1/2 group z-20 focus:outline-none"
              >
                <div className={`flex items-center space-x-1.5 p-1 px-2.5 rounded border transition-all duration-300 ${
                  isActive 
                    ? 'bg-walnut text-ivory border-brass shadow-md scale-105' 
                    : 'bg-ivory/95 text-walnut border-brass/30 hover:border-brass hover:bg-ivory'
                }`}>
                  <MapPin className={`w-3 h-3 ${isActive ? 'text-brass animate-pulse' : 'text-brass-dark'}`} />
                  <span className="text-[10px] font-semibold tracking-wider">{reg.name}</span>
                </div>
              </button>
            );
          })}

          {/* Decorative Sea tags */}
          <span className="absolute bottom-12 left-4 text-[9px] font-serif italic text-brass-dark/30 tracking-widest uppercase">
            Atlantic Ocean
          </span>
          <span className="absolute top-12 right-4 text-[9px] font-serif italic text-brass-dark/30 tracking-widest uppercase">
            North Sea
          </span>
          <span className="absolute bottom-32 right-12 text-[9px] font-serif italic text-brass-dark/30 tracking-widest uppercase">
            Firth of Forth
          </span>
        </div>

        <div className="text-center text-[10px] text-walnut/50 z-10 font-serif italic">
          Click any geographical marker to inspect regional whisky style records.
        </div>
      </div>

      {/* Right side: Region Dossier Information */}
      <div className="lg:col-span-5 flex flex-col justify-between border-fine bg-ivory p-6 md:p-8 relative">
        <div className="absolute top-0 right-0 w-24 h-24 pointer-events-none opacity-[0.02]">
          <BookOpen className="w-full h-full text-walnut" />
        </div>

        <div>
          <span className="text-[9px] uppercase tracking-[0.25em] text-brass font-bold">
            ARCHIVAL REGION FILE
          </span>
          <h3 className="font-serif text-3xl text-walnut mt-1 mb-4 border-b border-brass/10 pb-2">
            {regionInfo.name}
          </h3>
          
          <p className="text-xs text-walnut/80 leading-relaxed font-sans mb-6">
            {regionInfo.description}
          </p>

          <div className="bg-brass/5 border border-brass/25 p-4 rounded mb-6">
            <h4 className="text-[10px] font-semibold uppercase tracking-widest text-brass-dark mb-1.5">
              REGIONAL STYLE PROFILE
            </h4>
            <p className="text-xs font-serif italic text-walnut leading-relaxed">
              {"\""}{regionInfo.character}{"\""}
            </p>
          </div>
        </div>

        <div>
          <h4 className="text-[10px] font-bold uppercase tracking-widest text-walnut/70 mb-3 flex items-center space-x-1.5">
            <Sparkles className="w-3.5 h-3.5 text-brass" />
            <span>FEATURED SELECTIONS</span>
          </h4>

          <div className="space-y-3">
            {featuredWhiskies.map((whisky) => (
              <div 
                key={whisky.id}
                onClick={() => onSelectWhisky(whisky)}
                className="flex items-center justify-between p-2.5 border border-brass/10 hover:border-brass/40 hover:bg-brass/5 cursor-pointer rounded transition-all duration-200"
              >
                <div>
                  <p className="text-[11px] font-semibold text-walnut leading-tight">{whisky.name}</p>
                  <p className="text-[9px] text-brass-dark uppercase font-mono">{whisky.caskType.split(',')[0]} • {whisky.abv}% ABV</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-semibold text-walnut">£{whisky.price}</p>
                  <p className="text-[8px] text-brass uppercase tracking-wider font-mono">View Record</p>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
