'use client';

import React, { useState } from 'react';
import { TASTING_EXPERIENCES, TastingExperience } from '@/lib/data/whiskyData';
import { useEmporium } from './EmporiumProvider';
import { Calendar, Users, Clock, MapPin, Sparkles, AlertCircle, Check } from 'lucide-react';

export default function TastingView() {
  const { addBooking } = useEmporium();
  const [selectedExp, setSelectedExp] = useState<TastingExperience | null>(null);
  
  // Form states
  const [date, setDate] = useState('2026-10-15');
  const [time, setTime] = useState('18:00');
  const [guests, setGuests] = useState('2');
  const [dietary, setDietary] = useState('');
  const [bookedTicket, setBookedTicket] = useState<any | null>(null);
  const [bookingError, setBookingError] = useState('');

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedExp) return;

    if (!date) {
      setBookingError('Please select a valid date.');
      return;
    }

    const ticketRef = `EDW-TASTE-${Math.floor(100000 + Math.random() * 900000)}`;
    const newBooking = {
      reference: ticketRef,
      experienceId: selectedExp.id,
      experienceTitle: selectedExp.title,
      date,
      time,
      guests: Number(guests),
      dietary: dietary || 'None declared',
      location: selectedExp.location,
      totalCost: selectedExp.price * Number(guests),
      timestamp: new Date().toISOString()
    };

    // Save to context
    addBooking(newBooking);
    setBookedTicket(newBooking);
    setBookingError('');
  };

  const handleReset = () => {
    setBookedTicket(null);
    setSelectedExp(null);
    setDietary('');
  };

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">THE PRIVATE DRAWING ROOMS</span>
        <h2 className="font-serif text-3xl md:text-4xl">Private Tasting Experiences</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"Savor aged single malts under professional curation in our historic Charlotte Square townhouse. Sessions are strictly private.\""}
        </p>
      </section>

      {/* Main container */}
      <section className="max-w-7xl mx-auto px-4 md:px-8">
        
        {!selectedExp ? (
          /* EXPERIENCE CATALOG VIEW */
          <div className="space-y-8 animate-in fade-in duration-250">
            <div className="border-b border-brass/25 pb-3">
              <h3 className="font-serif text-xl text-walnut uppercase tracking-widest">Select An Experience</h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {TASTING_EXPERIENCES.map((exp) => (
                <div 
                  key={exp.id}
                  className="bg-ivory border border-brass/25 rounded p-6 flex flex-col justify-between hover:border-brass/55 hover:shadow-restrained transition-all duration-300"
                >
                  <div className="space-y-4">
                    <div>
                      <span className="text-[8px] uppercase tracking-widest text-brass font-mono">EDINBURGH FLIGHTS</span>
                      <h4 className="font-serif text-xl text-walnut leading-snug mt-1">{exp.title}</h4>
                      <p className="font-serif text-xs italic text-brass-dark mt-0.5">{exp.subtitle}</p>
                    </div>

                    <div className="space-y-2 border-t border-b border-brass/10 py-3.5 text-xs text-walnut/70 font-sans">
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4 text-brass" />
                        <span>Duration: {exp.duration}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4 text-brass" />
                        <span>Availability: {exp.availability}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="w-4 h-4 text-brass" />
                        <span>Location: {exp.location}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-forest font-semibold">
                        <Sparkles className="w-4 h-4 text-brass" />
                        <span>Includes {exp.whiskyCount} exceptional malts</span>
                      </div>
                    </div>

                    <p className="text-xs text-walnut/80 leading-relaxed font-sans line-clamp-3">
                      {exp.description}
                    </p>
                  </div>

                  <div className="mt-8 pt-4 border-t border-brass/10 flex items-center justify-between">
                    <div>
                      <p className="text-xs text-walnut/50 uppercase tracking-wider">Per Person</p>
                      <p className="font-serif text-xl font-bold text-walnut">£{exp.price}</p>
                    </div>
                    <button
                      onClick={() => setSelectedExp(exp)}
                      className="px-4 py-2.5 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-widest font-bold transition-all border border-brass shadow"
                    >
                      Book Flight
                    </button>
                  </div>

                </div>
              ))}
            </div>
          </div>
        ) : bookedTicket ? (
          /* BOOKING CONFIRMED SCREEN */
          <div className="max-w-xl mx-auto space-y-6 animate-in fade-in duration-300">
            <div className="border-fine-heavy bg-[#fdfdfc] p-8 md:p-10 rounded shadow-restrained border-double border-4 text-center space-y-6">
              
              <div className="w-12 h-12 rounded-full bg-forest/10 flex items-center justify-center mx-auto text-forest">
                <Check className="w-6 h-6" />
              </div>

              <div>
                <span className="text-[10px] uppercase tracking-widest font-mono text-brass font-bold">REGISTRATION SUCCESSFUL</span>
                <h4 className="font-serif text-2xl text-walnut mt-1">Your Tasting Pass Is Certified</h4>
                <p className="text-[10px] font-mono text-walnut/50 mt-1">REFERENCE DEED: {bookedTicket.reference}</p>
              </div>

              <div className="border-t border-b border-brass/15 py-4 space-y-3 font-sans text-xs text-left max-w-sm mx-auto">
                <div className="flex justify-between">
                  <span className="text-walnut/60 font-semibold">Tasting Flight:</span>
                  <span className="text-walnut font-bold">{bookedTicket.experienceTitle}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-walnut/60 font-semibold">Selected Date & Time:</span>
                  <span className="text-walnut font-bold font-mono">{bookedTicket.date} @ {bookedTicket.time}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-walnut/60 font-semibold">Guest Attendance:</span>
                  <span className="text-walnut font-bold">{bookedTicket.guests} guests</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-walnut/60 font-semibold">Tasting Location:</span>
                  <span className="text-walnut font-bold">{bookedTicket.location}</span>
                </div>
                <div className="flex justify-between border-t border-brass/10 pt-2 text-sm font-semibold">
                  <span className="text-brass-dark">Total Paid (Simulated):</span>
                  <span className="text-walnut font-mono">£{bookedTicket.totalCost} GBP</span>
                </div>
              </div>

              <div className="font-serif italic text-xs text-walnut/75 leading-relaxed max-w-md mx-auto">
                {"\"Please present this confirmed ledger entry at the 18th-century sandstone threshold off Charlotte Square upon arrival. Our gatekeepers will guide you inside.\""}
              </div>

              <div className="pt-4 border-t border-brass/10 flex justify-between gap-4">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 border border-brass text-walnut text-[10px] uppercase tracking-wider font-bold rounded"
                >
                  Print Pass
                </button>
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-walnut hover:bg-forest text-ivory text-[10px] uppercase tracking-wider font-bold rounded"
                >
                  Book Another Flight
                </button>
              </div>

            </div>
          </div>
        ) : (
          /* BOOKING WIZARD FORM */
          <div className="max-w-2xl mx-auto animate-in fade-in duration-200">
            <button
              onClick={() => setSelectedExp(null)}
              className="text-xs uppercase tracking-widest text-walnut hover:text-brass font-bold mb-6 block"
            >
              ← Back to Experiences
            </button>

            <div className="border-fine bg-ivory p-6 md:p-10 rounded shadow-restrained relative">
              <span className="text-[9px] uppercase tracking-widest text-brass font-bold">COMMITTEE SCHEDULER</span>
              <h4 className="font-serif text-2xl text-walnut mt-1 mb-2">Book: {selectedExp.title}</h4>
              <p className="text-xs text-walnut/60 mb-6 border-b border-brass/10 pb-4">
                {selectedExp.location} • Includes {selectedExp.whiskyCount} hand-numbered malts.
              </p>

              <form onSubmit={handleBookingSubmit} className="space-y-6">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Date selection */}
                  <div className="space-y-1.5">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold">Select Date</label>
                    <input
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass text-xs text-walnut font-mono rounded"
                    />
                  </div>

                  {/* Time slot selection */}
                  <div className="space-y-1.5">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold">Select Session Time</label>
                    <select
                      value={time}
                      onChange={(e) => setTime(e.target.value)}
                      className="w-full bg-ivory border border-brass/40 p-2.5 focus:outline-none focus:border-brass text-xs text-walnut rounded"
                    >
                      <option value="14:00">14:00 (Afternoon Foundations)</option>
                      <option value="17:00">17:00 (Sunset Committee Flight)</option>
                      <option value="19:00">19:00 (Evening Vault Devotion)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Guest count selector */}
                  <div className="space-y-1.5">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold">Attendance Size</label>
                    <select
                      value={guests}
                      onChange={(e) => setGuests(e.target.value)}
                      className="w-full bg-ivory border border-brass/40 p-2.5 focus:outline-none focus:border-brass text-xs text-walnut rounded"
                    >
                      {[1, 2, 3, 4, 5, 6].map(num => (
                        <option key={num} value={num}>{num} Person{num > 1 ? 's' : ''}</option>
                      ))}
                    </select>
                    <p className="text-[9px] text-walnut/50">For larger groups over 6 people, please contact our private corporate services.</p>
                  </div>

                  {/* Dietary notes */}
                  <div className="space-y-1.5">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold">Sensory / Dietary Notes</label>
                    <input
                      type="text"
                      placeholder="e.g. Vegetarian, Nut allergies"
                      value={dietary}
                      onChange={(e) => setDietary(e.target.value)}
                      className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass text-xs text-walnut rounded"
                    />
                  </div>
                </div>

                {bookingError && (
                  <p className="p-2 border border-red-200 text-red-700 bg-red-50 text-xs text-center">{bookingError}</p>
                )}

                {/* Submit row */}
                <div className="pt-4 border-t border-brass/10 flex justify-between items-center">
                  <div>
                    <span className="block text-[9px] uppercase tracking-widest text-walnut/50">Simulated Total Invoice</span>
                    <strong className="font-serif text-lg text-walnut">£{selectedExp.price * Number(guests)} GBP</strong>
                  </div>
                  <button
                    type="submit"
                    className="px-6 py-3 bg-walnut hover:bg-forest text-ivory uppercase tracking-widest text-xs font-bold transition-all border border-brass shadow"
                  >
                    Confirm Private Flight
                  </button>
                </div>

              </form>
            </div>
          </div>
        )}

      </section>

    </div>
  );
}
