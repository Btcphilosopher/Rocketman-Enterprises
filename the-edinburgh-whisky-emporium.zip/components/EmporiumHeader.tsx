'use client';

import React, { useState } from 'react';
import { useEmporium, ViewType } from './EmporiumProvider';
import { Search, ShoppingBag, FolderHeart, Menu, X, ShieldAlert } from 'lucide-react';

interface EmporiumHeaderProps {
  onOpenBasket: () => void;
}

export default function EmporiumHeader({ onOpenBasket }: EmporiumHeaderProps) {
  const { 
    activeView, 
    setActiveView, 
    basket, 
    searchQuery, 
    setSearchQuery 
  } = useEmporium();
  
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);

  const totalItems = basket.reduce((sum, item) => sum + item.quantity, 0);

  const navItems: { label: string; view: ViewType }[] = [
    { label: 'WHISKY', view: 'whisky' },
    { label: 'RARE & OLD', view: 'rare' },
    { label: 'THE COLLECTION', view: 'home' }, // Leads to homepage and featured grid
    { label: 'DISTILLERIES', view: 'distilleries' },
    { label: 'THE LIBRARY', view: 'library' },
    { label: 'TASTING', view: 'tasting' },
    { label: 'THE HOUSE', view: 'house' },
    { label: 'CONTACT', view: 'contact' }
  ];

  const handleNavClick = (view: ViewType) => {
    setActiveView(view);
    setMobileMenuOpen(false);
  };

  const triggerSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveView('whisky');
    setSearchOpen(false);
  };

  return (
    <header className="w-full bg-ivory border-b border-brass/20 sticky top-0 z-40 no-print">
      {/* Top line notification */}
      <div className="bg-walnut text-[#dfd9ce] text-[9px] uppercase tracking-[0.4em] py-2 px-4 text-center border-b border-brass/10 flex items-center justify-center space-x-2">
        <span>EDINBURGH · SCOTLAND</span>
        <span className="text-brass-dark">•</span>
        <span>FREE UK COURIER ON ACQUISITIONS OVER £250</span>
        <span className="text-brass-dark">•</span>
        <span className="text-brass flex items-center gap-1">
          <ShieldAlert className="w-3 h-3" /> 18+ AGE VERIFIED SECURE GATE
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 py-4 flex flex-col items-center">
        {/* Main Logo & Wordmark */}
        <div 
          onClick={() => handleNavClick('home')} 
          className="text-center cursor-pointer group mb-4"
        >
          <p className="text-[10px] md:text-xs uppercase tracking-[0.25em] text-brass group-hover:text-brass-dark transition-colors font-medium">
            ESTD. 1782 — CHARLOTTE SQUARE
          </p>
          <h1 className="font-serif text-3xl md:text-4xl tracking-tight text-walnut mt-1">
            THE EDINBURGH
          </h1>
          <h2 className="font-serif text-xl md:text-2xl italic tracking-widest text-brass-dark">
            WHISKY EMPORIUM
          </h2>
        </div>

        {/* Desktop Navigation & Actions Row */}
        <div className="w-full flex items-center justify-between border-t border-brass/15 pt-3">
          
          {/* Left Action: Search toggler */}
          <div className="flex items-center space-x-4 w-1/4">
            <button 
              onClick={() => setSearchOpen(!searchOpen)}
              className="text-walnut hover:text-brass transition-colors p-1"
              aria-label="Toggle Search"
            >
              <Search className="w-4 h-4" />
            </button>
            
            {searchOpen && (
              <form onSubmit={triggerSearch} className="hidden md:flex items-center">
                <input
                  type="text"
                  placeholder="Search whisky, distillery..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-transparent border-b border-brass/35 focus:border-brass text-xs p-1 focus:outline-none w-40 text-walnut"
                />
              </form>
            )}
          </div>

          {/* Centered Desktop Menu */}
          <nav className="hidden lg:flex items-center space-x-6">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.view)}
                className={`text-[11px] font-semibold tracking-[0.2em] transition-all hover:text-brass ${
                  activeView === item.view 
                    ? 'text-brass border-b border-brass/60 pb-0.5' 
                    : 'text-walnut/80'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Right Actions: Private Vault (My Collection) & Basket */}
          <div className="flex items-center justify-end space-x-4 w-1/4">
            <button
              onClick={() => handleNavClick('collection')}
              className={`flex items-center space-x-1.5 p-1 transition-colors ${
                activeView === 'collection' ? 'text-brass' : 'text-walnut hover:text-brass'
              }`}
              title="My Vault"
            >
              <FolderHeart className="w-4 h-4" />
              <span className="hidden md:inline text-[10px] uppercase tracking-widest font-semibold">
                MY VAULT
              </span>
            </button>

            <button
              onClick={onOpenBasket}
              className="relative text-walnut hover:text-brass transition-colors p-1 flex items-center space-x-1"
              title="Shopping Basket"
            >
              <ShoppingBag className="w-4 h-4" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-forest text-ivory text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-mono font-bold">
                  {totalItems}
                </span>
              )}
              <span className="hidden md:inline text-[10px] uppercase tracking-widest font-semibold">
                BASKET
              </span>
            </button>

            {/* Admin trigger button for Curators */}
            <button
              onClick={() => handleNavClick('admin')}
              className={`text-[9px] uppercase border px-2 py-0.5 rounded tracking-wider font-mono ${
                activeView === 'admin'
                  ? 'border-brass text-brass bg-walnut'
                  : 'border-brass/30 text-brass/70 hover:border-brass'
              }`}
            >
              CURATOR
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden text-walnut hover:text-brass transition-colors p-1"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>

        {/* Mobile Search Bar Expand */}
        {searchOpen && (
          <form onSubmit={triggerSearch} className="w-full mt-3 flex md:hidden">
            <input
              type="text"
              placeholder="Search catalog (e.g., Islay peated 18)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent border-b border-brass/50 text-sm py-2 px-1 focus:outline-none text-walnut"
            />
          </form>
        )}
      </div>

      {/* Mobile Menu Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-ivory border-t border-brass/25 py-4 px-6 space-y-3 shadow-md animate-in fade-in slide-in-from-top-4 duration-250">
          <div className="grid grid-cols-2 gap-3 pb-4 border-b border-brass/10">
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.view)}
                className={`text-left text-[11px] font-semibold tracking-wider p-2 rounded hover:bg-brass/5 ${
                  activeView === item.view ? 'text-brass bg-brass/5' : 'text-walnut/90'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="flex justify-between items-center pt-2">
            <button
              onClick={() => handleNavClick('collection')}
              className="text-[11px] font-semibold tracking-wider text-walnut flex items-center space-x-1"
            >
              <FolderHeart className="w-4 h-4 text-brass" />
              <span>MY VAULT</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenBasket();
              }}
              className="text-[11px] font-semibold tracking-wider text-walnut flex items-center space-x-1"
            >
              <ShoppingBag className="w-4 h-4 text-brass" />
              <span>BASKET ({totalItems})</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
