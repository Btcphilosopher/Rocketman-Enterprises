'use client';

import React, { useState } from 'react';
import { useEmporium, BasketItem } from './EmporiumProvider';
import { Check, ShieldCheck, CreditCard, Truck, Calendar, Printer, BookOpen } from 'lucide-react';

export default function CheckoutView() {
  const { 
    basket, 
    basketTotal, 
    clearBasket, 
    addOrder,
    setActiveView
  } = useEmporium();

  const [step, setStep] = useState(1); // 1: Basket, 2: Delivery, 3: Age Compliance, 4: Payment, 5: Confirmed

  // Form states
  const [name, setName] = useState('Lady Fiona Kennedy');
  const [email, setEmail] = useState('fiona@kennedy.scot');
  const [address, setAddress] = useState('17 Charlotte Square, New Town');
  const [city, setCity] = useState('Edinburgh');
  const [postcode, setPostcode] = useState('EH2 4DR');
  const [country, setCountry] = useState('United Kingdom');
  const [deliveryType, setDeliveryType] = useState('EDINBURGH_COURIER');
  
  const [ageConfirm, setAgeConfirm] = useState(false);
  const [recipientConfirm, setRecipientConfirm] = useState(false);

  const [cardName, setCardName] = useState('Fiona Kennedy');
  const [cardNumber, setCardNumber] = useState('•••• •••• •••• 4200');
  const [cardExpiry, setCardExpiry] = useState('11/29');
  const [cardCVC, setCardCVC] = useState('184');

  const [orderRecord, setOrderRecord] = useState<any | null>(null);

  const handleNextStep = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      processOrder();
    }
  };

  const processOrder = () => {
    const orderNo = `EDW-ORDER-${Math.floor(100000 + Math.random() * 900000)}`;
    const itemsSaved = basket.map(item => ({
      whiskyId: item.whisky.id,
      whiskyName: item.whisky.name,
      price: item.whisky.price,
      quantity: item.quantity,
      caskNumber: item.whisky.caskNumber,
      bottleNumber: item.whisky.bottleNumber,
      totalBottles: item.whisky.totalBottles
    }));

    const finalOrder = {
      orderNumber: orderNo,
      customerName: name,
      customerEmail: email,
      address: `${address}, ${city}, ${postcode}, ${country}`,
      deliveryType,
      items: itemsSaved,
      totalPaid: basketTotal,
      timestamp: new Date().toISOString()
    };

    // Save to context logs
    addOrder(finalOrder);
    setOrderRecord(finalOrder);
    clearBasket();
    setStep(5);
  };

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4 no-print">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">SECURE TRANSACTION</span>
        <h2 className="font-serif text-3xl md:text-4xl">Checkout Ledger</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"Simulated financial compliance gateway for Charlotte Square spirits acquisitions.\""}
        </p>
      </section>

      <section className="max-w-5xl mx-auto px-4 md:px-8">
        
        {/* PROGRESS STEP BAR (no print) */}
        {step < 5 && (
          <div className="flex justify-between items-center max-w-3xl mx-auto mb-10 text-xs font-mono uppercase text-walnut/50 border-b border-brass/10 pb-4 no-print">
            {[
              { num: 1, label: 'Invoice' },
              { num: 2, label: 'Delivery Address' },
              { num: 3, label: 'Age Verification' },
              { num: 4, label: 'Secure Payment' }
            ].map((s) => (
              <div 
                key={s.num}
                className={`flex items-center space-x-1.5 ${
                  step === s.num ? 'text-brass font-bold' : step > s.num ? 'text-forest' : ''
                }`}
              >
                <span className={`w-5 h-5 rounded-full border flex items-center justify-center text-[10px] ${
                  step === s.num ? 'border-brass bg-walnut text-ivory' : step > s.num ? 'border-forest bg-forest/10 text-forest' : 'border-brass/35'
                }`}>
                  {step > s.num ? '✓' : s.num}
                </span>
                <span>{s.label}</span>
              </div>
            ))}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* STAGE 1: INVOICE / BASKET OVERVIEW */}
          {step === 1 && (
            <div className="lg:col-span-12 space-y-6">
              <div className="border-fine bg-ivory p-6 md:p-8 rounded shadow-sm space-y-6">
                <h3 className="font-serif text-lg text-walnut uppercase tracking-widest border-b border-brass/10 pb-2">Step 1: Audit Acquisition Bill</h3>
                
                {basket.length === 0 ? (
                  <div className="text-center py-12 space-y-3">
                    <p className="font-serif italic text-xs text-walnut/50">{"\"Your basket holds no active spirits declarations.\""}</p>
                    <button
                      onClick={() => setActiveView('whisky')}
                      className="px-4 py-2 bg-walnut text-ivory text-xs uppercase tracking-wider font-bold border border-brass"
                    >
                      Browse Whisky
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {basket.map((item) => (
                      <div key={item.whisky.id} className="flex justify-between items-center py-3 border-b border-brass/10 text-xs">
                        <div>
                          <h4 className="font-serif text-sm font-semibold text-walnut">{item.whisky.name}</h4>
                          <p className="text-[10px] text-brass-dark uppercase font-mono mt-0.5">{item.whisky.region} • {item.whisky.abv}% ABV • Qty: {item.quantity}</p>
                        </div>
                        <p className="font-mono font-bold">£{(item.whisky.price * item.quantity).toLocaleString()}</p>
                      </div>
                    ))}

                    <div className="border-t border-brass/15 pt-4 flex justify-between items-center font-serif text-base">
                      <strong className="uppercase tracking-wider font-semibold">Total Invoice Value:</strong>
                      <strong className="text-lg font-bold">£{basketTotal.toLocaleString()} GBP</strong>
                    </div>

                    <div className="pt-4 text-right">
                      <button
                        onClick={handleNextStep}
                        className="px-6 py-3 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-widest font-bold border border-brass shadow"
                      >
                        Confirm Invoice — Proceed to Delivery
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* STAGE 2: DELIVERY ADDRESS FORM */}
          {step === 2 && (
            <div className="lg:col-span-12 space-y-6">
              <div className="border-fine bg-ivory p-6 md:p-8 rounded shadow-sm space-y-6">
                <h3 className="font-serif text-lg text-walnut uppercase tracking-widest border-b border-brass/10 pb-2">Step 2: Consignment Address Details</h3>
                
                <form onSubmit={(e) => { e.preventDefault(); handleNextStep(); }} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Recipient Name</label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Contact Email</label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Consignment Address</label>
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      required
                      className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">City</label>
                      <input
                        type="text"
                        value={city}
                        onChange={(e) => setCity(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Postcode</label>
                      <input
                        type="text"
                        value={postcode}
                        onChange={(e) => setPostcode(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Country</label>
                      <input
                        type="text"
                        value={country}
                        onChange={(e) => setCountry(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2 text-xs text-walnut rounded"
                      />
                    </div>
                  </div>

                  <div className="p-4 border border-brass/25 rounded bg-brass/5 space-y-2">
                    <span className="text-[8px] uppercase tracking-widest text-brass font-bold font-mono">ESTIMATED SHIPPNG COURIER (SIMULATED)</span>
                    <div className="flex items-start space-x-2 text-xs font-serif italic text-walnut">
                      <Truck className="w-4 h-4 text-brass" />
                      {postcode.toUpperCase().startsWith('EH') ? (
                        <span>AVAILABLE — Next-day secure Edinburgh cargo courier from Charlotte Square. (FREE)</span>
                      ) : (
                        <span>AVAILABLE — Standard UK Courier delivery (3-5 business days). (FREE)</span>
                      )}
                    </div>
                  </div>

                  <div className="pt-4 text-right">
                    <button
                      type="submit"
                      className="px-6 py-3 bg-walnut hover:bg-forest text-ivory text-xs uppercase tracking-widest font-bold border border-brass shadow"
                    >
                      Confirm Address — Proceed to Age Verification
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

          {/* STAGE 3: AGE VERIFICATION COMPLIANCE */}
          {step === 3 && (
            <div className="lg:col-span-12 space-y-6">
              <div className="border-fine bg-ivory p-6 md:p-8 rounded shadow-sm space-y-6 max-w-xl mx-auto">
                <div className="text-center space-y-2">
                  <ShieldCheck className="w-10 h-10 text-brass mx-auto" />
                  <h3 className="font-serif text-lg text-walnut uppercase tracking-widest">Step 3: Age Compliance Verification</h3>
                  <p className="text-[11px] text-walnut/60 leading-relaxed font-sans">
                    Due to licensing regulations of Scotland, alcohol consignments cannot be left with or accepted by persons under the age of 18 years.
                  </p>
                </div>

                <div className="space-y-4 pt-4 border-t border-brass/10">
                  <div className="flex items-start space-x-3 text-xs">
                    <input
                      type="checkbox"
                      id="ageConfirm"
                      checked={ageConfirm}
                      onChange={(e) => setAgeConfirm(e.target.checked)}
                      className="accent-brass mt-1 cursor-pointer"
                    />
                    <label htmlFor="ageConfirm" className="text-walnut/80 leading-relaxed cursor-pointer select-none">
                      I certify under strict penalty of law that I am 18 years of age or older, and legally permitted to purchase Scotch spirits.
                    </label>
                  </div>

                  <div className="flex items-start space-x-3 text-xs">
                    <input
                      type="checkbox"
                      id="recipientConfirm"
                      checked={recipientConfirm}
                      onChange={(e) => setRecipientConfirm(e.target.checked)}
                      className="accent-brass mt-1 cursor-pointer"
                    />
                    <label htmlFor="recipientConfirm" className="text-walnut/80 leading-relaxed cursor-pointer select-none">
                      I understand that the courier will physically request formal photo ID (Passport / Drivers License) upon home door delivery.
                    </label>
                  </div>
                </div>

                <div className="pt-4 text-center">
                  <button
                    onClick={handleNextStep}
                    disabled={!ageConfirm || !recipientConfirm}
                    className={`px-6 py-3 uppercase tracking-widest text-xs font-bold transition-all border ${
                      ageConfirm && recipientConfirm
                        ? 'bg-walnut hover:bg-forest text-ivory border-brass shadow'
                        : 'bg-walnut/20 text-walnut/40 border-walnut/10 cursor-not-allowed'
                    }`}
                  >
                    Confirm Compliance — Proceed to Payment
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* STAGE 4: SIMULATED PAYMENT */}
          {step === 4 && (
            <div className="lg:col-span-12 space-y-6">
              <div className="border-fine bg-ivory p-6 md:p-8 rounded shadow-sm space-y-6 max-w-md mx-auto">
                <div className="text-center space-y-1 border-b border-brass/10 pb-4">
                  <CreditCard className="w-8 h-8 text-brass mx-auto mb-2" />
                  <h3 className="font-serif text-lg text-walnut uppercase tracking-widest">Step 4: Secure Payment Gateway</h3>
                  <p className="text-[10px] text-brass-dark font-mono font-bold uppercase">SIMULATED TESTING SANDBOX</p>
                </div>

                <form onSubmit={(e) => { e.preventDefault(); handleNextStep(); }} className="space-y-4 text-xs font-sans">
                  
                  <div className="space-y-1">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Cardholder Name</label>
                    <input
                      type="text"
                      value={cardName}
                      onChange={(e) => setCardName(e.target.value)}
                      required
                      className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass rounded"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Credit Card Number</label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      required
                      className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass rounded font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Expiration Date</label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass rounded font-mono"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] uppercase tracking-widest text-brass-dark font-bold font-mono">Security Code (CVC)</label>
                      <input
                        type="password"
                        value={cardCVC}
                        onChange={(e) => setCardCVC(e.target.value)}
                        required
                        className="w-full bg-transparent border border-brass/40 p-2.5 focus:outline-none focus:border-brass rounded font-mono"
                      />
                    </div>
                  </div>

                  <div className="p-3 bg-brass/5 border border-brass/25 rounded text-[10px] leading-relaxed text-walnut/60 font-serif italic text-center">
                    {"\"Payment is fully simulated. No monetary assets or secret credentials will be routed or recorded.\""}
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-walnut hover:bg-forest text-ivory uppercase tracking-widest text-xs font-bold transition-all border border-brass shadow"
                  >
                    Submit Simulated Order — £{basketTotal.toLocaleString()}
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* STAGE 5: CONFINED ORDER CONFIRMED WITH CERTIFICATE PRINTER */}
          {step === 5 && orderRecord && (
            <div className="lg:col-span-12 space-y-8 animate-in fade-in duration-300">
              
              {/* Receipt confirmation banner (no print) */}
              <div className="border-fine-heavy bg-ivory p-6 md:p-8 rounded shadow-sm text-center space-y-4 max-w-xl mx-auto no-print">
                <div className="w-12 h-12 rounded-full bg-forest/10 text-forest flex items-center justify-center mx-auto">
                  <Check className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-[9px] uppercase tracking-widest text-brass font-bold font-mono font-semibold">ORDER RECONCILIATION SUCCESSFUL</span>
                  <h3 className="font-serif text-2xl text-walnut mt-1">Acquisition Secured</h3>
                  <p className="text-[10px] font-mono text-walnut/50">ORDER NO: {orderRecord.orderNumber}</p>
                </div>
                <div className="text-xs text-walnut/70 max-w-sm mx-auto font-serif italic leading-relaxed">
                  {"\"Your simulated order was successfully registered in the Charlotte Square ledger vaults. Below represents your Certified digital Certificate of Provenance.\""}
                </div>
                <div className="flex justify-center gap-3">
                  <button
                    onClick={() => window.print()}
                    className="flex items-center space-x-1 border border-brass text-walnut hover:bg-brass/5 text-[10px] font-bold px-3 py-1.5 rounded uppercase font-mono"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>Print Receipt Portfolio</span>
                  </button>
                  <button
                    onClick={() => setActiveView('home')}
                    className="bg-walnut hover:bg-forest text-ivory text-[10px] font-bold px-4 py-1.5 rounded uppercase font-mono"
                  >
                    Return Home
                  </button>
                </div>
              </div>

              {/* THE OFFICIAL PRINTABLE CERTIFICATE CARD FOR ORDERED PRODUCTS */}
              {orderRecord.items.map((item: any, index: number) => (
                <div 
                  key={index}
                  className="border-fine bg-[#fdfdfc] p-8 md:p-12 rounded relative shadow-sm border-double border-4 select-none print:border-none print:shadow-none print:p-0"
                >
                  {/* Decorative Watermark */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-[0.02] pointer-events-none">
                    <BookOpen className="w-[80%] h-[80%] text-walnut" />
                  </div>

                  <div className="text-center space-y-4">
                    <p className="text-[9px] uppercase tracking-[0.4em] text-brass">EDINBURGH · SCOTLAND</p>
                    <h4 className="font-serif text-2xl md:text-3xl tracking-tight text-walnut">THE EDINBURGH WHISKY EMPORIUM</h4>
                    <h5 className="font-serif text-base italic tracking-widest text-brass-dark border-b border-brass/10 pb-4">OFFICIAL PROVENANCE TRANSACTION COUPLING</h5>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 my-8 border-t border-b border-brass/15 py-5 font-mono text-xs">
                    <div>
                      <span className="block text-[8px] uppercase tracking-widest text-brass-dark mb-1">TRANSACTION NO</span>
                      <span className="font-bold text-walnut">{orderRecord.orderNumber}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] uppercase tracking-widest text-brass-dark mb-1">LOT TITLE</span>
                      <span className="font-bold text-walnut">{item.whiskyName}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] uppercase tracking-widest text-brass-dark mb-1">BOTTLE BATCH</span>
                      <span className="font-bold text-walnut">{item.bottleNumber}</span>
                    </div>
                    <div>
                      <span className="block text-[8px] uppercase tracking-widest text-brass-dark mb-1">CASK NO REF</span>
                      <span className="font-bold text-walnut">{item.caskNumber}</span>
                    </div>
                  </div>

                  <div className="space-y-4 font-serif text-xs text-walnut/80 max-w-2xl mx-auto leading-relaxed">
                    <p>
                      This document certifies under physical corporate bond that the emporium registrar of Charlotte Square has authorized and secured the transfer of <strong className="text-walnut">{item.whiskyName}</strong> (Cask {item.caskNumber}) to the registered vaults of <strong className="text-walnut">{orderRecord.customerName}</strong>.
                    </p>
                    <p>
                      This bottle has been verified for authenticity against our master taxanomic ledger records, maintaining standard dunnage-storage integrity until transit clearance.
                    </p>
                  </div>

                  <div className="mt-8 pt-6 border-t border-brass/15 flex flex-col sm:flex-row items-center justify-between gap-4 font-serif text-xs">
                    <div className="flex items-center space-x-1.5 text-forest font-semibold">
                      <ShieldCheck className="w-5 h-5 text-brass" />
                      <span className="font-mono text-[8px] tracking-widest uppercase text-walnut">SECURED IN BOND</span>
                    </div>
                    <div className="text-center sm:text-right">
                      <p className="text-xs font-semibold text-brass-dark italic">Alasdair MacPherson</p>
                      <p className="text-[8px] font-mono uppercase text-walnut/50 tracking-wider">Master of Malts — Committee Registrar</p>
                    </div>
                  </div>
                </div>
              ))}

            </div>
          )}

        </div>

      </section>

    </div>
  );
}
