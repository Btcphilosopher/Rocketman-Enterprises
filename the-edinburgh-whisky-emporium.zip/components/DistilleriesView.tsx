'use client';

import React, { useState, useMemo } from 'react';
import { DISTILLERIES, WHISKIES, Distillery, Whisky } from '@/lib/data/whiskyData';
import { Search, Compass, AlertCircle, Calendar, ShieldCheck, MapPin } from 'lucide-react';

interface DistilleriesViewProps {
  onSelectWhisky: (whisky: Whisky) => void;
}

export default function DistilleriesView({ onSelectWhisky }: DistilleriesViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('All');
  const [activeDistillery, setActiveDistillery] = useState<Distillery | null>(DISTILLERIES[0]);

  const regions = ['All', 'Speyside', 'Highlands', 'Lowlands', 'Islay', 'Campbeltown', 'Islands'];

  // Filter distilleries based on search and selected region
  const filteredDistilleries = useMemo(() => {
    return DISTILLERIES.filter((dist) => {
      if (selectedRegion !== 'All' && dist.region !== selectedRegion) {
        return false;
      }
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        return dist.name.toLowerCase().includes(query) || dist.style.toLowerCase().includes(query);
      }
      return true;
    });
  }, [searchQuery, selectedRegion]);

  // Find related bottles for the active distillery
  const relatedBottles = useMemo(() => {
    if (!activeDistillery) return [];
    return WHISKIES.filter((w) => w.distilleryId === activeDistillery.id);
  }, [activeDistillery]);

  return (
    <div className="space-y-10 pb-16">
      
      {/* Banner */}
      <section className="bg-walnut text-ivory py-10 px-6 border-b border-brass/20 text-center space-y-4">
        <span className="text-[10px] uppercase tracking-[0.25em] text-brass font-bold">SCOTTISH PAROCHIAL AUDIT</span>
        <h2 className="font-serif text-3xl md:text-4xl">The Distillery Directory</h2>
        <p className="text-xs text-ivory/70 max-w-xl mx-auto font-serif italic">
          {"\"A comprehensive index of Scotland's active and silent distilleries under emporium observation. Grouped by historic regional boundaries.\""}
        </p>
      </section>

      {/* Main grid splitter */}
      <section className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: Search & Directory List (lg:span-5) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-ivory border border-brass/20 p-4 rounded shadow-sm space-y-3">
            <div className="relative">
              <input
                type="text"
                placeholder="Search distilleries or styles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-transparent border-b border-brass/30 text-xs py-2 px-1 focus:outline-none focus:border-brass text-walnut"
              />
              <Search className="absolute right-2 top-2 w-3.5 h-3.5 text-brass" />
            </div>

            <div className="flex gap-2 items-center text-[10px] uppercase font-mono overflow-x-auto py-1">
              {regions.map((reg) => (
                <button
                  key={reg}
                  onClick={() => setSelectedRegion(reg)}
                  className={`px-2.5 py-1 rounded-full border transition-colors flex-shrink-0 ${
                    selectedRegion === reg
                      ? 'bg-walnut text-ivory border-brass'
                      : 'border-brass/25 text-walnut/70 hover:border-brass'
                  }`}
                >
                  {reg === 'All' ? 'All Regions' : reg}
                </button>
              ))}
            </div>
          </div>

          <div className="border border-brass/20 bg-[#fdfdfc] rounded divide-y divide-brass/10 max-h-[500px] overflow-y-auto shadow-sm">
            {filteredDistilleries.length === 0 ? (
              <div className="p-8 text-center text-xs text-walnut/50">
                No distilleries found matching filters.
              </div>
            ) : (
              filteredDistilleries.map((dist) => {
                const isActive = activeDistillery?.id === dist.id;
                return (
                  <div
                    key={dist.id}
                    onClick={() => setActiveDistillery(dist)}
                    className={`p-4 cursor-pointer transition-all flex justify-between items-center ${
                      isActive ? 'bg-brass/5 border-l-4 border-l-brass' : 'hover:bg-brass/[0.02]'
                    }`}
                  >
                    <div>
                      <h4 className="font-serif text-sm text-walnut font-medium">{dist.name}</h4>
                      <p className="text-[10px] text-brass-dark uppercase font-mono mt-0.5">{dist.region} • Estd. {dist.founded}</p>
                    </div>
                    <div className="text-right flex flex-col items-end gap-1">
                      <span className={`text-[8px] font-mono px-1.5 py-0.5 rounded font-bold uppercase tracking-wider ${
                        dist.status === 'Active' ? 'bg-forest/10 text-forest' : 'bg-red-950/20 text-red-700'
                      }`}>
                        {dist.status}
                      </span>
                      <span className="text-[9px] text-walnut/40 font-mono">View File</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: Active Distillery Dossier File (lg:span-7) */}
        <div className="lg:col-span-7 bg-ivory border-fine p-6 md:p-8 rounded relative shadow-restrained">
          
          {/* Fictional identifier header */}
          <div className="absolute top-2 right-4 text-[8px] font-mono text-walnut/30 uppercase tracking-widest">
            REGISTRY DOSSIER
          </div>

          {activeDistillery ? (
            <div className="space-y-6">
              
              {/* Header profile */}
              <div>
                <span className="text-[9px] uppercase tracking-widest text-brass font-bold">{activeDistillery.region} GEOGRAPHICAL FILE</span>
                <h3 className="font-serif text-3xl text-walnut mt-1 mb-2">{activeDistillery.name}</h3>
                
                <div className="flex flex-wrap gap-4 text-xs font-mono text-walnut/60 py-2 border-t border-b border-brass/10 my-4">
                  <div className="flex items-center space-x-1.5">
                    <Calendar className="w-4 h-4 text-brass" />
                    <span>FOUNDED: {activeDistillery.founded}</span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <ShieldCheck className="w-4 h-4 text-brass" />
                    <span>STATUS: <strong className={activeDistillery.status === 'Active' ? 'text-forest' : 'text-red-700'}>{activeDistillery.status.toUpperCase()}</strong></span>
                  </div>
                  <div className="flex items-center space-x-1.5">
                    <MapPin className="w-4 h-4 text-brass" />
                    <span>COORDINATES: {activeDistillery.region} BOUNDS</span>
                  </div>
                </div>
              </div>

              {/* History Text */}
              <div className="space-y-4">
                <h4 className="font-serif text-base text-walnut border-b border-brass/10 pb-1 uppercase tracking-widest">Historical Profile</h4>
                <p className="text-xs text-walnut/80 leading-relaxed">
                  {activeDistillery.description}
                </p>
                <p className="text-xs text-walnut/80 leading-relaxed">
                  This house is particularly noted for its traditional distillation approaches, and maintaining wooden washbacks that cultivate specialized wild yeasts. Its water is drawn through pristine regional aquifer streams.
                </p>
              </div>

              {/* Style & Characteristics */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="border border-brass/20 p-4 rounded bg-brass/5">
                  <span className="block text-[8px] uppercase tracking-widest text-brass-dark font-bold font-mono mb-1.5">HOUSE PROFILE STYLE</span>
                  <p className="text-xs font-serif font-medium text-walnut">{activeDistillery.style}</p>
                </div>
                <div className="border border-brass/20 p-4 rounded bg-brass/5 space-y-2">
                  <span className="block text-[8px] uppercase tracking-widest text-brass-dark font-bold font-mono">SPECIFIC ATTRIBUTES</span>
                  <div className="flex flex-wrap gap-1">
                    {activeDistillery.characteristics.map(char => (
                      <span key={char} className="text-[9px] bg-ivory text-walnut/80 border border-brass/20 px-2 py-0.5 rounded font-serif italic">
                        {char}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Connected related bottles */}
              <div className="space-y-4 pt-4 border-t border-brass/10">
                <h4 className="font-serif text-base text-walnut border-b border-brass/10 pb-1 uppercase tracking-widest">Allocations In Stock</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {relatedBottles.map((whisky) => (
                    <div 
                      key={whisky.id}
                      onClick={() => onSelectWhisky(whisky)}
                      className="p-3 border border-brass/10 hover:border-brass hover:bg-brass/5 cursor-pointer rounded flex justify-between items-center transition-all duration-200"
                    >
                      <div className="flex items-center space-x-2.5">
                        {/* Miniature bottle simulator graphic */}
                        <div className="w-6 h-12 border border-brass/20 rounded-t-lg rounded-b bg-amber-800/10 relative flex-shrink-0 flex items-center justify-end py-1">
                          <div className="absolute inset-x-0 bottom-0 bg-amber-600/50 h-8 rounded-b"></div>
                        </div>
                        <div>
                          <p className="text-[11px] font-semibold text-walnut leading-tight">{whisky.name.replace(activeDistillery.name, '').trim() || 'Signature Expression'}</p>
                          <p className="text-[8px] text-brass uppercase tracking-wide font-mono mt-0.5">{whisky.abv}% ABV • {whisky.age ? `${whisky.age} Yr` : 'NAS'}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-[11px] font-bold text-walnut">£{whisky.price}</p>
                        <p className="text-[8px] text-brass uppercase font-mono">View File</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Compliance Warning */}
              <div className="p-3 bg-brass/5 border border-brass/20 text-walnut/50 text-[10px] font-serif italic flex items-center gap-1.5 rounded">
                <AlertCircle className="w-4 h-4 text-brass flex-shrink-0" />
                <span>The details represented are compiled under synthetic archive parameters for testing purposes. Fictional demo records are clearly declared.</span>
              </div>

            </div>
          ) : (
            <div className="text-center py-20 text-xs text-walnut/40">
              Select a distillery from the directory list to examine its architectural and liquid records.
            </div>
          )}

        </div>

      </section>

    </div>
  );
}
