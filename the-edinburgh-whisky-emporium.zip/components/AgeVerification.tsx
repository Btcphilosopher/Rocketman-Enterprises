'use client';

import React, { useState } from 'react';
import { useEmporium } from './EmporiumProvider';
import { ShieldCheck } from 'lucide-react';

export default function AgeVerification() {
  const { verifyAge } = useEmporium();
  const [day, setDay] = useState('');
  const [month, setMonth] = useState('');
  const [year, setYear] = useState('');
  const [remember, setRemember] = useState(true);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!day || !month || !year) {
      setError('Please provide a complete date of birth.');
      return;
    }

    const birthDate = new Date(Number(year), Number(month) - 1, Number(day));
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }

    if (age >= 18) {
      verifyAge(true);
    } else {
      setError('You must be 18 years of age or older to enter this Emporium.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-walnut paper-texture">
      <div className="w-full max-w-xl p-8 md:p-12 border-fine-heavy bg-ivory text-walnut shadow-walnut-heavy relative">
        {/* Corner elegant details */}
        <div className="absolute top-3 left-3 w-4 h-4 border-t border-l border-brass"></div>
        <div className="absolute top-3 right-3 w-4 h-4 border-t border-r border-brass"></div>
        <div className="absolute bottom-3 left-3 w-4 h-4 border-b border-l border-brass"></div>
        <div className="absolute bottom-3 right-3 w-4 h-4 border-b border-r border-brass"></div>

        <div className="text-center mb-8">
          <p className="text-xs uppercase tracking-[0.25em] text-brass font-medium mb-3">
            Edinburgh · Scotland
          </p>
          <h1 className="font-serif text-3xl md:text-4xl tracking-tight text-walnut mb-2">
            THE EDINBURGH
          </h1>
          <h2 className="font-serif text-2xl md:text-3xl italic tracking-wide text-brass-dark mb-4">
            WHISKY EMPORIUM
          </h2>
          <div className="w-24 h-[1px] bg-brass mx-auto my-6"></div>
          <p className="text-sm font-serif italic text-[#1c140e]/70 max-w-md mx-auto">
            {"\"Rare whisky. Edinburgh judgement. By entering these doors, you cross into a historic Scottish institution.\""}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 max-w-md mx-auto">
          <div className="text-center">
            <label className="block text-xs uppercase tracking-widest text-walnut/80 mb-4 font-semibold">
              Verify Your Date of Birth
            </label>
            <div className="grid grid-cols-3 gap-3">
              <input
                type="number"
                placeholder="DD"
                min="1"
                max="31"
                value={day}
                onChange={(e) => {
                  setError('');
                  setDay(e.target.value);
                }}
                className="p-3 text-center border border-brass/40 bg-transparent focus:border-brass focus:outline-none font-mono text-lg text-walnut"
              />
              <input
                type="number"
                placeholder="MM"
                min="1"
                max="12"
                value={month}
                onChange={(e) => {
                  setError('');
                  setMonth(e.target.value);
                }}
                className="p-3 text-center border border-brass/40 bg-transparent focus:border-brass focus:outline-none font-mono text-lg text-walnut"
              />
              <input
                type="number"
                placeholder="YYYY"
                min="1900"
                max="2026"
                value={year}
                onChange={(e) => {
                  setError('');
                  setYear(e.target.value);
                }}
                className="p-3 text-center border border-brass/40 bg-transparent focus:border-brass focus:outline-none font-mono text-lg text-walnut"
              />
            </div>
          </div>

          {error && (
            <p className="text-xs text-red-700 bg-red-50 p-2 text-center border border-red-200">
              {error}
            </p>
          )}

          <div className="flex items-center justify-center space-x-2">
            <input
              type="checkbox"
              id="remember"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
              className="accent-brass"
            />
            <label htmlFor="remember" className="text-xs text-walnut/60 cursor-pointer select-none">
              Remember me on this device for 30 days
            </label>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-walnut hover:bg-forest text-ivory uppercase tracking-[0.2em] text-xs font-semibold transition-all duration-300 border border-brass shadow-md hover:shadow-lg hover:border-brass-dark"
            >
              Enter the Emporium
            </button>
          </div>
        </form>

        <div className="mt-8 pt-6 border-t border-brass/20 text-center flex flex-col items-center justify-center space-y-2">
          <div className="flex items-center space-x-1.5 text-walnut/50 text-xs">
            <ShieldCheck className="w-4 h-4 text-brass" />
            <span>Age-Gated Compliance System</span>
          </div>
          <p className="text-[10px] text-walnut/40 max-w-xs leading-relaxed">
            You must be of legal purchasing age in your country of residence. In the UK, this is 18 years. We promote responsible drinking.
          </p>
        </div>
      </div>
    </div>
  );
}
