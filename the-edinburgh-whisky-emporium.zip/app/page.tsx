'use client';

import React, { useState } from 'react';
import { useEmporium } from '@/components/EmporiumProvider';
import AgeVerification from '@/components/AgeVerification';
import EmporiumHeader from '@/components/EmporiumHeader';
import HomeView from '@/components/HomeView';
import WhiskyView from '@/components/WhiskyView';
import RareView from '@/components/RareView';
import DistilleriesView from '@/components/DistilleriesView';
import LibraryView from '@/components/LibraryView';
import TastingView from '@/components/TastingView';
import HouseView from '@/components/HouseView';
import CollectionDashboard from '@/components/CollectionDashboard';
import CheckoutView from '@/components/CheckoutView';
import AdminView from '@/components/AdminView';
import ContactView from '@/components/ContactView';
import BasketDrawer from '@/components/BasketDrawer';
import ProductDetailModal from '@/components/ProductDetailModal';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, BookOpen, Facebook, Twitter, Instagram } from 'lucide-react';

export default function Home() {
  const { 
    ageVerified, 
    activeView, 
    selectedWhisky, 
    setSelectedWhisky,
    addToBasket
  } = useEmporium();

  const [basketOpen, setBasketOpen] = useState(false);

  // Decides which view body component to render based on global context state
  const renderActiveView = () => {
    switch (activeView) {
      case 'home':
        return (
          <HomeView 
            onSelectWhisky={(w) => setSelectedWhisky(w)} 
            onAddToBasket={(w) => addToBasket(w, 1)} 
          />
        );
      case 'whisky':
        return (
          <WhiskyView 
            onSelectWhisky={(w) => setSelectedWhisky(w)} 
            onAddToBasket={(w) => addToBasket(w, 1)} 
          />
        );
      case 'rare':
        return <RareView onSelectWhisky={(w) => setSelectedWhisky(w)} />;
      case 'distilleries':
        return <DistilleriesView onSelectWhisky={(w) => setSelectedWhisky(w)} />;
      case 'library':
        return <LibraryView />;
      case 'tasting':
        return <TastingView />;
      case 'house':
        return <HouseView />;
      case 'collection':
        return <CollectionDashboard />;
      case 'checkout':
        return <CheckoutView />;
      case 'admin':
        return <AdminView />;
      case 'contact':
        return <ContactView />;
      default:
        return (
          <HomeView 
            onSelectWhisky={(w) => setSelectedWhisky(w)} 
            onAddToBasket={(w) => addToBasket(w, 1)} 
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-between paper-texture relative">
      
      {/* Absolute Age Gate Shield overlay if not verified */}
      <AnimatePresence>
        {!ageVerified && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-0 z-50"
          >
            <AgeVerification />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Luxury Header Navigation */}
      <EmporiumHeader onOpenBasket={() => setBasketOpen(true)} />

      {/* Body Views container with route transition simulations */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 md:px-8 py-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeView}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.35 }}
          >
            {renderActiveView()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Understated Luxury Footer */}
      <footer className="w-full bg-[#1c140e] text-[#dfd9ce] py-12 px-6 border-t border-brass/25 font-sans mt-16 no-print">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          
          {/* Logo brand */}
          <div className="md:col-span-5 space-y-4">
            <div className="space-y-1">
              <span className="text-[10px] uppercase tracking-[0.3em] text-brass block">CHARLOTTE SQUARE · EDINBURGH</span>
              <h4 className="font-serif text-2xl tracking-tight">THE EDINBURGH WHISKY EMPORIUM</h4>
              <p className="font-serif italic text-sm text-brass-dark">{"\"Rare whisky. Edinburgh judgement.\""}</p>
            </div>
            <p className="text-xs text-[#dfd9ce]/60 max-w-sm leading-relaxed">
              We are an established Edinburgh institution dedicated to the taxonomy, curation, and preservation of Scotland{"'"}s finest liquid history. Not a tourist gift depot. Selected in Edinburgh.
            </p>
          </div>

          {/* Quick navigations */}
          <div className="md:col-span-3 space-y-3 text-xs">
            <span className="block text-[10px] uppercase tracking-wider text-brass font-bold font-mono">SECTIONS</span>
            <div className="grid grid-cols-2 gap-2 text-[#dfd9ce]/75">
              <button onClick={() => setSelectedWhisky(null)} className="hover:text-brass text-left">The Collection</button>
              <button onClick={() => setSelectedWhisky(null)} className="hover:text-brass text-left">The Library</button>
              <button onClick={() => setSelectedWhisky(null)} className="hover:text-brass text-left">Distilleries</button>
              <button onClick={() => setSelectedWhisky(null)} className="hover:text-brass text-left">Private Tastings</button>
              <button onClick={() => setSelectedWhisky(null)} className="hover:text-brass text-left">Charlotte House</button>
              <button onClick={() => setSelectedWhisky(null)} className="hover:text-brass text-left">Curator Office</button>
            </div>
          </div>

          {/* Responsible drinking guidelines */}
          <div className="md:col-span-4 space-y-4 text-xs">
            <span className="block text-[10px] uppercase tracking-wider text-brass font-bold font-mono">RESPONSIBLE RETAIL AUDIT</span>
            <p className="text-[#dfd9ce]/60 leading-relaxed text-[11px]">
              You must be of minimum legal age in your country of residence to acquire or view spirits. In the UK, this is 18 years. Courier transit requires door-to-door physical age checking.
            </p>
            <div className="flex items-center space-x-2 text-[10px] text-brass">
              <ShieldAlert className="w-4 h-4 flex-shrink-0" />
              <span>LICENSED UNDER THE SCOTTISH ALCOHOL ACT NO. SC-1782-EE.</span>
            </div>
          </div>

        </div>

        {/* Core copyright footer info */}
        <div className="max-w-7xl mx-auto mt-12 pt-8 border-t border-brass/10 flex flex-col sm:flex-row items-center justify-between text-[11px] text-[#dfd9ce]/40 gap-4">
          <p>© 2026 The Edinburgh Whisky Emporium. Built under Charlotte Square terms. Clearly identified synthetic catalogue data.</p>
          <div className="flex space-x-4">
            <Facebook className="w-4 h-4 hover:text-brass cursor-pointer" />
            <Twitter className="w-4 h-4 hover:text-brass cursor-pointer" />
            <Instagram className="w-4 h-4 hover:text-brass cursor-pointer" />
          </div>
        </div>
      </footer>

      {/* Sliding Basket drawer popup */}
      <AnimatePresence>
        {basketOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50"
          >
            <BasketDrawer onClose={() => setBasketOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Product Detail Sheet modal */}
      <AnimatePresence>
        {selectedWhisky && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50"
          >
            <ProductDetailModal 
              whisky={selectedWhisky} 
              onClose={() => setSelectedWhisky(null)} 
            />
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
