import type { Metadata } from 'next';
import { Cormorant_Garamond, Inter } from 'next/font/google';
import './globals.css';
import { EmporiumProvider } from '@/components/EmporiumProvider';

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-serif',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'The Edinburgh Whisky Emporium | The House of Scotch',
  description: 'Elite Edinburgh-based whisky institution specialising in exceptional Scotch single malts and rare bottles. Selected in Edinburgh. Rare whisky, Edinburgh judgement.',
  openGraph: {
    title: 'The Edinburgh Whisky Emporium | The House of Scotch',
    description: 'Rare whisky, Edinburgh judgement. Exceptional Scotch single malts and closed-distillery allocations in Charlotte Square.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'The Edinburgh Whisky Emporium',
    description: 'Rare whisky, Edinburgh judgement. Traditional small-batch selections from the heart of Edinburgh.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${cormorant.variable} ${inter.variable}`}>
      <body suppressHydrationWarning className="bg-ivory text-walnut font-sans antialiased selection:bg-brass selection:text-walnut">
        <EmporiumProvider>
          {children}
        </EmporiumProvider>
      </body>
    </html>
  );
}
