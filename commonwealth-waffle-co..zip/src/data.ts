import { MenuItem, LocationInfo, SupplierInfo } from './types';

export const INITIAL_MENU: MenuItem[] = [
  // --- Vermont Maple Collection ---
  {
    id: 'vt-maple-butter',
    name: 'Vermont Maple Butter Waffle',
    category: 'Classic Waffles',
    subcategory: 'Vermont Maple Collection',
    description: 'Our traditional sourdough waffle drenched in pure Grade-A amber syrup sourced from Hillsboro Farm, crowned with an generous sphere of whipped salted sea-salt butter.',
    price: 14.00,
    ingredients: ['Sourdough batter', 'Grade-A Vermont Maple Syrup', 'Whipped Sea-Salt Butter'],
    image: 'https://images.unsplash.com/photo-1562376502-6f769499c886?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['Vermont Maple', 'House Favorite']
  },
  {
    id: 'smoked-bacon-maple',
    name: 'Smoked Bacon & Maple Waffle',
    category: 'Savoury Waffles',
    subcategory: 'Vermont Maple Collection',
    description: 'Thick-cut wood-smoked bacon baked directly into a crispy Belgian waffle, glazed with Vermont maple reduction and finished with crackled black pepper.',
    price: 16.50,
    ingredients: ['Applewood Smoked Bacon', 'Classic waffle batter', 'Maple reduction', 'Black pepper'],
    image: 'https://images.unsplash.com/photo-1504754524776-8f4f37790ca0?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['Savory', 'Staff Favorite']
  },

  // --- New England Berry Collection ---
  {
    id: 'maine-blueberry',
    name: 'Wild Maine Blueberry Waffle',
    category: 'Belgian Waffles',
    subcategory: 'New England Berry Collection',
    description: 'Leavened Brussels-style waffle laden with wild Maine blueberries, layered with organic lemon curd, sweet mascarpone whip, and lavender-infused syrup.',
    price: 15.50,
    ingredients: ['Belgian batter', 'Maine wild blueberries', 'Lemon curd', 'Mascarpone whip', 'Lavender syrup'],
    image: 'https://images.unsplash.com/photo-1484723091739-30a097e8f929?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['Maine Blueberry', 'Fresh Fruit']
  },
  {
    id: 'cape-cod-berry',
    name: 'Cape Cod Berry Waffle',
    category: 'Seasonal Specials',
    subcategory: 'New England Berry Collection',
    description: 'Fresh warm waffle topped with a tart cranberry and local raspberry compote, layered with white chocolate shavings and a dollop of Devonshire clotted cream.',
    price: 16.00,
    ingredients: ['Cranberry-raspberry compote', 'White chocolate', 'Clotted cream'],
    image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Seasonal', 'Tart']
  },

  // --- Classic Comforts ---
  {
    id: 'boston-cream',
    name: 'The Boston Cream Waffle',
    category: 'Classic Waffles',
    subcategory: 'Classic Comforts',
    description: 'A decadent interpretation of the Boston Classic. Filled with rich, velvety Madagascar vanilla bean pastry cream, coated in a warm glossy dark chocolate ganache glaze.',
    price: 15.00,
    ingredients: ['Vanilla bean pastry cream', 'Dark chocolate ganache', 'Sourdough waffle'],
    image: 'https://images.unsplash.com/photo-1598214886806-c87b2a370944?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['Decadent']
  },
  {
    id: 'clotted-cream-strawberry',
    name: 'Clotted Cream & Strawberries',
    category: 'Classic Waffles',
    subcategory: 'Classic Comforts',
    description: 'Fresh sliced native strawberries on a light waffle, served with premium imported English clotted cream from Devonshire and dusted with chamomile-infused sugar.',
    price: 14.50,
    ingredients: ['Native strawberries', 'Devon clotted cream', 'Chamomile sugar'],
    image: 'https://images.unsplash.com/photo-1464305795204-6f5bdf7af244?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['British Heritage']
  },
  {
    id: 'dark-choco-salt',
    name: 'Dark Chocolate & Sea Salt Waffle',
    category: 'Belgian Waffles',
    subcategory: 'Classic Comforts',
    description: 'Premium 72% Valrhona dark chocolate pieces baked in, drizzled with hot fudge, and sprinkled with flaky sea salt harvested from the shores of Maine.',
    price: 13.50,
    ingredients: ['72% Valrhona dark chocolate', 'Hot fudge', 'Maine sea salt'],
    image: 'https://images.unsplash.com/photo-1518492104633-130d0cc84637?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Rich']
  },

  // --- Savoury Craft ---
  {
    id: 'english-breakfast-waffle',
    name: 'The English Breakfast Waffle',
    category: 'Breakfast',
    subcategory: 'Savoury Craft',
    description: 'A full breakfast feast on a waffle. Heritage pork Cumberland sausage, sunny-side organic egg, blistered heirloom tomatoes, roasted field mushrooms, and a side of maple beans.',
    price: 18.50,
    ingredients: ['Cumberland sausage', 'Sunny-side egg', 'Heirloom tomatoes', 'Field mushrooms', 'Maple baked beans'],
    image: 'https://images.unsplash.com/photo-1513442542250-854d436a73f2?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['Hearty', 'British Heritage']
  },
  {
    id: 'cheddar-herb',
    name: 'Vermont Cheddar & Herb Waffle',
    category: 'Savoury Waffles',
    subcategory: 'Savoury Craft',
    description: 'Aged Vermont white cheddar and fresh chives folded into our sourdough batter, served warm with roasted garlic butter and a dollop of sour cream.',
    price: 15.00,
    ingredients: ['Aged white cheddar', 'Fresh chives', 'Sourdough batter', 'Garlic butter', 'Sour cream'],
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Aged Cheese', 'Savory']
  },
  {
    id: 'apple-cinnamon',
    name: 'Orchard Apple & Cinnamon Waffle',
    category: 'Seasonal Specials',
    subcategory: 'Classic Comforts',
    description: 'Warm, spiced apples from cider orchards in Massachusetts, roasted with brown sugar and cinnamon, served with toasted pecans and vanilla bean gelato.',
    price: 14.50,
    ingredients: ['Spiced Massachusetts apples', 'Toasted pecans', 'Cinnamon', 'Vanilla gelato'],
    image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Massachusetts Orchard', 'Warm Gelato']
  },

  // --- Beverages ---
  {
    id: 'artisan-pour-over',
    name: 'Artisan V60 Pour-Over Coffee',
    category: 'Drinks',
    subcategory: 'Coffee',
    description: 'Single-origin beans from George Howell Coffee Roasters, precisely brewed using a ceramic V60. Notes of dark berry and honeyed caramel.',
    price: 5.50,
    ingredients: ['Single-origin beans', 'Filtered spring water'],
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['George Howell', 'Crafted']
  },
  {
    id: 'flat-white',
    name: 'The Anglo Flat White',
    category: 'Drinks',
    subcategory: 'Coffee',
    description: 'Double shot of our custom house espresso blend with perfectly steamed, velvety microfoam milk from New England dairy cooperatives.',
    price: 5.00,
    ingredients: ['Espresso', 'Local microfoam milk'],
    image: 'https://images.unsplash.com/photo-1577968897966-3d4325b36b61?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Classic']
  },
  {
    id: 'london-fog',
    name: 'Imperial London Fog',
    category: 'Drinks',
    subcategory: 'Tea',
    description: 'Premium Earl Grey tea steeped with lavender petals, sweetened with house-infused vanilla syrup, and finished with warm steamed local milk.',
    price: 5.25,
    ingredients: ['Earl Grey tea', 'Lavender', 'Vanilla syrup', 'Steamed milk'],
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Traditional']
  },
  {
    id: 'belgian-hot-choco',
    name: 'Heirloom Belgian Hot Chocolate',
    category: 'Drinks',
    subcategory: 'Hot Chocolate',
    description: 'Melted Belgian milk and dark chocolates emulsified with organic cream, toasted homemade vanilla bean marshmallow, and a pinch of salt.',
    price: 6.50,
    ingredients: ['Belgian chocolate', 'Organic cream', 'Homemade marshmallow'],
    image: 'https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=800&q=80',
    signature: true,
    tags: ['Decadent']
  },
  {
    id: 'cold-pressed-orange',
    name: 'Cold-Pressed Maine Cran-Orange',
    category: 'Drinks',
    subcategory: 'Fresh Juices',
    description: 'Crisp, tart juice pressed daily from local Massachusetts cranberries and sweet Valencia oranges. Refreshing and high in antioxidants.',
    price: 6.00,
    ingredients: ['Cranberries', 'Valencia oranges'],
    image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Cold-pressed', 'Tart']
  },
  {
    id: 'salted-caramel-shake',
    name: 'Salted Butter Caramel Milkshake',
    category: 'Drinks',
    subcategory: 'Milkshakes',
    description: 'House-made butter caramel ice cream blended with farm-fresh milk, layered with toasted pecans and a heavy drizzle of golden butterscotch.',
    price: 8.00,
    ingredients: ['Caramel ice cream', 'Local milk', 'Toasted pecans', 'Butterscotch'],
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=800&q=80',
    signature: false,
    tags: ['Rich', 'Sweet']
  }
];

export const INITIAL_LOCATIONS: LocationInfo[] = [
  {
    id: 'loc-boston',
    name: 'Back Bay Flasghip',
    city: 'Boston',
    address: '75 Newbury St, Boston, MA 02116',
    phone: '(617) 555-0143',
    hours: {
      weekdays: '7:00 AM — 9:00 PM',
      weekends: '8:00 AM — 10:00 PM'
    },
    parking: 'Metered street parking on Newbury St; nearby garage parking at 100 Clarendon St.',
    accessibility: 'Fully wheelchair accessible ramp at Newbury St entrance. ADA compliant tables and restrooms.',
    photography: 'Our flagship space showcases restored 19th-century red brick walls, high-ceiling heavy timber beams, bespoke brass chandeliers, and a white Carrara marble counter.',
    directions: 'Located in the heart of Back Bay, between Clarendon and Dartmouth streets. A 3-minute walk from the Copley T station (Green Line).',
    image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'loc-cambridge',
    name: 'Harvard Square',
    city: 'Cambridge',
    address: '14 Brattle St, Cambridge, MA 02138',
    phone: '(617) 555-0182',
    hours: {
      weekdays: '7:00 AM — 10:00 PM',
      weekends: '8:00 AM — 11:00 PM'
    },
    parking: 'Public parking garage at Harvard Square Parking (65 JFK St). Bicycle racks directly outside.',
    accessibility: 'Street-level entrance with automatic doors. All dining spaces are single-level.',
    photography: 'An academic sanctuary featuring oak wood panelling, bookshelves stocked with leather-bound literature, cozy green leather booths, and custom brass study lamps.',
    directions: 'Located just steps from the Harvard Square Red Line subway station, next to the historic Brattle Theatre.',
    image: 'https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'loc-providence',
    name: 'College Hill',
    city: 'Providence',
    address: '220 Thayer St, Providence, RI 02906',
    phone: '(401) 555-0199',
    hours: {
      weekdays: '7:30 AM — 9:00 PM',
      weekends: '8:30 AM — 10:00 PM'
    },
    parking: 'On-street parking on Thayer and Hope St. Dedicated merchant parking spaces in the rear lot.',
    accessibility: 'Flat entrance. Accessible seating options available throughout.',
    photography: 'A bright, airy, industrial mill-inspired aesthetic combining slate floors with exposed copper pipes, green botanical plants, and wide floor-to-ceiling iron-frame windows.',
    directions: 'Located on Thayer Street, immediate neighbor to Brown University and RISD campus limits.',
    image: 'https://images.unsplash.com/photo-1498804103079-a6351b050096?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'loc-portland',
    name: 'The Old Port',
    city: 'Portland',
    address: '88 Commercial St, Portland, ME 04101',
    phone: '(207) 555-0121',
    hours: {
      weekdays: '7:00 AM — 8:00 PM',
      weekends: '8:00 AM — 9:00 PM'
    },
    parking: 'Street parking along the wharf. Public lot access on Custom House Wharf.',
    accessibility: 'Historical brick cobblestone approach. Interior is ramp-enabled for full accessibility.',
    photography: 'A maritime-infused jewel on the wharf. Weathered oak bar counters, nautical brass fittings, slate grey tile floors, and beautiful views of Portland Harbor.',
    directions: 'Positioned right on Commercial St, opposite Custom House Wharf in Portland\'s historic Old Port district.',
    image: 'https://images.unsplash.com/photo-1543007630-9710e4a00a20?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'loc-burlington',
    name: 'Church Street',
    city: 'Burlington',
    address: '112 Church St, Burlington, VT 05401',
    phone: '(802) 555-0164',
    hours: {
      weekdays: '7:30 AM — 8:00 PM',
      weekends: '8:00 AM — 9:30 PM'
    },
    parking: 'Church Street Marketplace parking garage (Cherry St). Direct pedestrian access.',
    accessibility: 'Step-free entryway from pedestrianized Church Street. Wide pathways inside.',
    photography: 'Cozy Nordic chalet vibes. Saturated forest green walls, light birch woodwork, a blazing brick hearth, and soft woolen blankets draped over bench seats.',
    directions: 'Located in the middle block of Burlington\'s pedestrianized Church Street Marketplace.',
    image: 'https://images.unsplash.com/photo-1559925393-8be0ec4767c8?auto=format&fit=crop&w=800&q=80'
  }
];

export const SUPPLIERS: SupplierInfo[] = [
  {
    id: 'sup-hillsboro',
    name: 'Hillsboro Maple Farm',
    produce: 'Grade-A Amber Maple Syrup',
    location: 'Hillsboro, Vermont',
    story: 'For four generations, the Hillsboro family has tapped their grove of sugar maples in the Green Mountains. They boil their sap using traditional wood fires, yielding an incredibly rich, caramelized, amber syrup that serves as the crown jewel of our Vermont Maple Butter waffle.',
    image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sup-kennebec',
    name: 'Kennebec Berry Co.',
    produce: 'Wild Organic Blueberries',
    location: 'Kennebec Valley, Maine',
    story: 'Kennebec Berry Co. harvests wild lowbush blueberries from glacial barrens in Maine. These tiny, concentrated flavor-bombs are naturally resilient and packed with high antioxidants, resulting in the deep floral-tart compotes that top our signature Maine Blueberry Waffles.',
    image: 'https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'sup-narragansett',
    name: 'Narragansett Creamery',
    produce: 'Artisanal Whipped Butter & Dairy',
    location: 'Providence, Rhode Island',
    story: 'Committed to sourcing from small family-owned dairy farms across New England, Narragansett Creamery crafts small-batch fresh dairy. They supply CWC with rich salted butter, organic mascarpone, cream, and milk, with absolutely no artificial hormones.',
    image: 'https://images.unsplash.com/photo-1527018601619-a508a2be00cd?auto=format&fit=crop&w=800&q=80'
  }
];
