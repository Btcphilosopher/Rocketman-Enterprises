export interface MenuItem {
  id: string;
  name: string;
  category: 
    | 'Classic Waffles' 
    | 'Belgian Waffles' 
    | 'Savoury Waffles' 
    | 'Breakfast' 
    | 'Seasonal Specials' 
    | 'Drinks';
  subcategory: string; // e.g. "Coffee", "Tea", "Vermont Maple Collection", "House Butter Selection", etc.
  description: string;
  price: number;
  ingredients: string[];
  image: string;
  signature?: boolean;
  tags?: string[];
}

export interface LocationInfo {
  id: string;
  name: string;
  city: string;
  address: string;
  phone: string;
  hours: {
    weekdays: string;
    weekends: string;
  };
  parking: string;
  accessibility: string;
  photography: string; // Description of interior aesthetics for managers/photography section
  directions: string;
  image: string;
}

export interface WaffleCustomization {
  batter: 'Traditional Sourdough' | 'Gluten-Free Oat' | 'Spiced Ginger' | 'Savory Cheddar Chive';
  syrup: 'Grade-A Vermont Amber Maple' | 'Wild Maine Blueberry Drizzle' | 'Rich Dark Chocolate Ganache' | 'English Toffee' | 'None';
  extraToppings: string[];
}

export interface CartItem {
  id: string; // Unique instance ID (combines menuItem.id + customization hash)
  menuItem: MenuItem;
  quantity: number;
  customization?: WaffleCustomization;
  price: number; // Includes base + extras
}

export interface Order {
  id: string;
  customerName: string;
  email: string;
  phone: string;
  type: 'pickup' | 'delivery';
  deliveryAddress?: string;
  scheduledTime: string;
  items: {
    name: string;
    quantity: number;
    price: number;
    customization?: string;
  }[];
  total: number;
  status: 'Pending' | 'Prepped' | 'Out for Delivery' | 'Ready for Pickup' | 'Completed' | 'Cancelled';
  date: string;
}

export interface Reservation {
  id: string;
  name: string;
  email: string;
  phone: string;
  date: string;
  time: string;
  guests: number;
  locationId: string;
  locationName: string;
  status: 'Confirmed' | 'Seated' | 'Cancelled';
  notes?: string;
}

export interface LoyaltyMember {
  name: string;
  email: string;
  phone: string;
  memberId: string;
  points: number;
  tier: 'Patron' | 'Sovereign' | 'Commonwealth Guild';
  joinedDate: string;
}

export interface SupplierInfo {
  id: string;
  name: string;
  produce: string;
  location: string;
  story: string;
  image: string;
}
