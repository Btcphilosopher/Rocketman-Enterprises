import React from 'react';
import { ArrowRight, Compass, Calendar, Award } from 'lucide-react';
import { motion } from 'motion/react';

interface HomeHeroProps {
  onViewMenu: () => void;
  onFindCafe: () => void;
  onBookTable: () => void;
}

export const HomeHero: React.FC<HomeHeroProps> = ({
  onViewMenu,
  onFindCafe,
  onBookTable
}) => {
  return (
    <div className="flex flex-col flex-1 min-h-[calc(100vh-100px)] bg-[#FAF9F6]">
      {/* Hero Body Content */}
      <div className="flex-1 flex flex-col lg:flex-row border-b border-navy/10">
        {/* Left Editorial Column */}
        <div className="w-full lg:w-1/2 p-6 md:p-12 xl:p-16 flex flex-col justify-center border-r border-navy/10 relative overflow-hidden bg-[#FAF9F6]">
          {/* Subtle decorative background detail */}
          <div className="absolute top-0 left-0 w-full h-full opacity-5 pointer-events-none bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-brass via-transparent to-transparent"></div>
          
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-4 z-10"
          >
            <span className="font-sans text-[11px] md:text-xs uppercase tracking-[0.25em] font-bold text-brass block">
              Crafted Daily. Shared Together.
            </span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-serif text-[48px] sm:text-[60px] md:text-[72px] lg:text-[64px] xl:text-[76px] leading-[0.95] tracking-tighter text-navy mb-8 z-10 font-bold"
          >
            WAFFLES,<br />
            <span className="italic font-normal text-brass">Crafted for the</span><br />
            Commonwealth.
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-sans text-base md:text-lg text-slate-grey font-light leading-relaxed max-w-lg mb-10 z-10"
          >
            An Anglo-Futurist interpretation of New England hospitality. We weave British artisanal baking methods with our region’s coastal heritage, heritage grains, and local orchard harvests.
          </motion.p>

          {/* Call to Actions */}
          <motion.div 
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 z-10"
          >
            <button 
              onClick={onViewMenu}
              className="bg-navy hover:bg-brass text-white px-8 py-4 text-xs uppercase tracking-widest font-bold flex items-center justify-center gap-2 transition-all duration-300"
            >
              Explore The Menu <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={onFindCafe}
              className="border border-navy/30 hover:border-brass hover:text-brass text-navy px-8 py-4 text-xs uppercase tracking-widest font-bold transition-all duration-300"
            >
              Find a Café
            </button>
          </motion.div>

          {/* Quick Stats Grid */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.2, delay: 0.5 }}
            className="mt-12 pt-8 border-t border-navy/5 grid grid-cols-3 gap-4"
          >
            <div>
              <span className="font-serif text-2xl font-bold text-navy">100%</span>
              <span className="block text-[9px] uppercase tracking-wider text-slate-grey mt-1">Local Dairy</span>
            </div>
            <div>
              <span className="font-serif text-2xl font-bold text-navy">24hr</span>
              <span className="block text-[9px] uppercase tracking-wider text-slate-grey mt-1">Sourdough Rise</span>
            </div>
            <div>
              <span className="font-serif text-2xl font-bold text-navy">10</span>
              <span className="block text-[9px] uppercase tracking-wider text-slate-grey mt-1">New England Cafés</span>
            </div>
          </motion.div>
        </div>

        {/* Right Visual Image Showcase */}
        <div className="w-full lg:w-1/2 bg-[#EAE8E4] relative flex items-center justify-center p-6 md:p-12 min-h-[400px] lg:min-h-0">
          {/* Main Artwork Container - Framing like a high-end photo print */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.96 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1.2 }}
            className="w-full h-full border-4 md:border-8 border-white p-4 shadow-2xl bg-white relative flex flex-col justify-between"
          >
            {/* Visual background image representing the editorial photography */}
            <div className="absolute inset-0 z-0 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1562376502-6f769499c886?auto=format&fit=crop&w=1200&q=85" 
                alt="Signature Waffles on handmade dark plate beside artisan pour-over coffee"
                className="w-full h-full object-cover brightness-[0.7] contrast-[1.05]"
                referrerPolicy="no-referrer"
              />
              {/* Linen Paper overlay for refined tactile feel */}
              <div className="absolute inset-0 opacity-15 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/linen-paper.png')]"></div>
              {/* Dark vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-navy/60 via-transparent to-navy/30"></div>
            </div>

            {/* Top Right Corner Crest */}
            <div className="z-10 text-right text-white">
              <span className="font-sans text-[9px] tracking-[0.3em] uppercase block font-semibold opacity-70">
                Premium Selection
              </span>
            </div>

            {/* Centered Crest */}
            <div className="z-10 text-center my-auto py-12">
              <div className="w-24 h-24 md:w-32 md:h-32 border-2 border-brass rounded-full mx-auto mb-4 flex items-center justify-center bg-navy/40 backdrop-blur-xs transition-transform duration-500 hover:rotate-12">
                <span className="font-serif text-2xl md:text-3xl text-brass italic">CWC</span>
              </div>
              <span className="font-sans text-[10px] md:text-[11px] text-white tracking-[0.4em] uppercase font-bold opacity-80 block">
                The Signature Collection
              </span>
              <span className="font-serif text-xs md:text-sm text-brass italic block mt-1">
                Vermont Maple & Wild Maine Blueberry
              </span>
            </div>

            {/* Decorative corners */}
            <div className="absolute top-8 left-8 w-8 h-8 border-t border-l border-brass/50 z-10"></div>
            <div className="absolute bottom-8 right-8 w-8 h-8 border-b border-r border-brass/50 z-10"></div>

            {/* Bottom Credit */}
            <div className="z-10 flex justify-between items-end text-white/70 text-[9px] uppercase tracking-widest">
              <span>Plate No. 04</span>
              <span>George Howell Brew</span>
            </div>
          </motion.div>
          
          {/* Floating Heritage Badge */}
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="absolute -bottom-4 md:bottom-12 -left-2 md:-left-6 bg-brass text-white p-4 md:p-6 shadow-2xl z-20"
          >
            <Award className="w-5 h-5 mb-2 text-white opacity-90" />
            <span className="font-sans text-[9px] tracking-widest uppercase block mb-1 opacity-80">Established</span>
            <span className="font-serif text-xl md:text-2xl font-bold">2024</span>
          </motion.div>
        </div>
      </div>

      {/* Footer Rail */}
      <div className="h-auto lg:h-24 border-t border-navy/10 flex flex-col lg:flex-row items-stretch lg:items-center px-6 md:px-12 bg-white gap-6 lg:gap-0 py-6 lg:py-0">
        <div className="flex-1 flex flex-col sm:flex-row gap-6 md:gap-12">
          <div className="flex flex-col border-l-2 border-brass pl-4">
            <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-brass mb-1">Signature</span>
            <span className="font-serif text-sm font-semibold text-navy">Maine Blueberry Waffle</span>
            <span className="text-[11px] text-slate-grey">Wild lowbush berries & mascarpone</span>
          </div>
          <div className="flex flex-col border-l-2 border-brass pl-4">
            <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-brass mb-1">Regional</span>
            <span className="font-serif text-sm font-semibold text-navy">Vermont Maple Butter</span>
            <span className="text-[11px] text-slate-grey">Hillsboro Farm Grade-A nectar</span>
          </div>
          <div className="flex flex-col border-l-2 border-brass pl-4">
            <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-brass mb-1">Decadent</span>
            <span className="font-serif text-sm font-semibold text-navy">The Boston Cream</span>
            <span className="text-[11px] text-slate-grey">Vanilla pastry cream & dark ganache</span>
          </div>
        </div>

        <div className="flex items-center justify-between lg:justify-end gap-8 border-t lg:border-t-0 border-navy/10 pt-4 lg:pt-0">
          <div className="text-left lg:text-right">
            <span className="font-sans text-[9px] uppercase tracking-[0.2em] font-bold block text-navy">Flagship Location</span>
            <span className="font-sans text-xs text-slate-grey">75 Newbury St, Back Bay, Boston</span>
          </div>
          <button 
            onClick={onBookTable}
            className="w-10 h-10 rounded-full border border-navy/10 hover:border-brass flex items-center justify-center cursor-pointer transition-colors duration-300 group"
            title="Book Flagship Table"
          >
            <Compass className="w-4 h-4 text-navy group-hover:text-brass transition-colors" />
          </button>
        </div>
      </div>
    </div>
  );
};
