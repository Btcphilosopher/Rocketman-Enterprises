import React from 'react';
import { SupplierInfo } from '../types';
import { Leaf, Award, Heart, ShieldCheck, Flame } from 'lucide-react';
import { motion } from 'motion/react';

interface AboutSectionProps {
  suppliers: SupplierInfo[];
}

export const AboutSection: React.FC<AboutSectionProps> = ({ suppliers }) => {
  return (
    <div className="bg-[#FAF9F6] py-12 px-6 md:px-12 xl:px-16 min-h-screen">
      {/* Brand Story Hero banner */}
      <div className="max-w-4xl mx-auto text-center mb-16">
        <span className="font-sans text-xs uppercase tracking-[0.3em] font-bold text-brass block mb-2">
          Our Heritage
        </span>
        <h2 className="font-serif text-4xl md:text-5xl lg:text-6xl font-bold text-navy mb-6">
          The Sourdough & Craft Philosophy
        </h2>
        <div className="w-16 h-0.5 bg-brass mx-auto mb-8"></div>
        <p className="font-serif text-lg md:text-xl text-navy italic leading-relaxed font-light">
          "Crafted Daily. Shared Together." is not just our tagline—it is our regional commitment. We merge the disciplined techniques of British high hospitality with the seasonal abundance of New England orchards, forests, and bays.
        </p>
      </div>

      {/* Narrative Section - Two Columns */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12 mb-20 items-center">
        <div className="space-y-6">
          <span className="font-sans text-[10px] uppercase tracking-widest font-bold text-brass block">
            The Sourdough Secret
          </span>
          <h3 className="font-serif text-2xl md:text-3xl font-bold text-navy">
            Wild Yeast. Twenty-Four Hour Rises.
          </h3>
          <p className="font-sans text-sm text-slate-grey font-light leading-relaxed">
            Standard waffle mixes rely heavily on chemical leaveners, leaving them heavy and doughy. Our signature waffles utilize an active, wild sourdough culture that dates back to a historic London bakery. 
          </p>
          <p className="font-sans text-sm text-slate-grey font-light leading-relaxed">
            By allowing our batter to ferment slowly for 24 hours at cellar temperatures, complex starches are broken down, yielding an incredibly airy, complex crumb, with a crisp, caramelised outer shell that stands proudly against heavy syrups.
          </p>
          
          <div className="flex gap-4 pt-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-brass/10 flex items-center justify-center text-brass">
                <Flame className="w-4 h-4" />
              </div>
              <span className="font-sans text-[10px] uppercase tracking-wider font-bold text-navy">Wood-Fired Syrup</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-brass/10 flex items-center justify-center text-brass">
                <Leaf className="w-4 h-4" />
              </div>
              <span className="font-sans text-[10px] uppercase tracking-wider font-bold text-navy">Organic Herbs</span>
            </div>
          </div>
        </div>

        {/* Decorative Collage Image */}
        <div className="relative p-4 border border-navy/10 bg-white">
          <img 
            src="https://images.unsplash.com/photo-1541832676-9b763b0239ab?auto=format&fit=crop&w=800&q=80" 
            alt="Hand-sifting flour in kitchen with natural morning light"
            className="w-full h-80 object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 opacity-15 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/linen-paper.png')]"></div>
          {/* Caption */}
          <div className="absolute bottom-8 left-8 right-8 bg-navy text-white p-4 text-center border border-brass">
            <span className="font-sans text-[9px] uppercase tracking-[0.3em] text-brass block mb-1">
              Baking Protocol No. 12
            </span>
            <span className="font-serif text-xs italic">
              "Airy core, caramelized crust, optimal structural resilience."
            </span>
          </div>
        </div>
      </div>

      {/* Grid of Suppliers */}
      <div className="max-w-7xl mx-auto space-y-10 border-t border-navy/10 pt-16">
        <div className="text-center md:text-left max-w-xl">
          <span className="font-sans text-[10px] uppercase tracking-widest font-bold text-brass block mb-1">
            Regional Abundance
          </span>
          <h3 className="font-serif text-3xl font-bold text-navy">
            Our Local Partners & Suppliers
          </h3>
          <p className="font-sans text-xs text-slate-grey font-light mt-2 leading-relaxed">
            True luxury begins with the soil. We partner directly with small, independent New England family farmers and creamers who honor traditional, regenerative methods.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {suppliers.map(sup => (
            <div 
              key={sup.id}
              className="bg-white border border-navy/10 hover:border-brass/30 transition-all duration-300 flex flex-col justify-between"
            >
              {/* Supplier Image */}
              <div className="h-48 overflow-hidden relative bg-[#EAE8E4]">
                <img 
                  src={sup.image} 
                  alt={sup.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
                <div className="absolute bottom-4 left-4 text-white">
                  <span className="font-sans text-[9px] uppercase tracking-wider bg-brass text-white px-2 py-0.5 font-bold">
                    {sup.location}
                  </span>
                </div>
              </div>

              {/* Text Description */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div className="space-y-2">
                  <span className="font-sans text-[10px] uppercase tracking-widest text-brass font-bold block">
                    {sup.produce}
                  </span>
                  <h4 className="font-serif text-lg font-bold text-navy">
                    {sup.name}
                  </h4>
                  <p className="font-sans text-xs text-slate-grey leading-relaxed font-light">
                    {sup.story}
                  </p>
                </div>

                <div className="pt-4 border-t border-navy/5 flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-[9px] uppercase tracking-widest font-bold text-navy/70">
                    <ShieldCheck className="w-3.5 h-3.5 text-forest-green" />
                    <span>Direct-Sourced</span>
                  </div>
                  <span className="text-[10px] font-serif text-slate-grey italic">Est. Partner</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Interior Heritage Block */}
      <div className="max-w-6xl mx-auto mt-24 bg-navy text-white p-8 md:p-16 border-4 border-brass relative overflow-hidden">
        {/* Paper texture overlay */}
        <div className="absolute inset-0 opacity-10 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/linen-paper.png')] pointer-events-none"></div>
        {/* Soft background glow */}
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-brass/10 rounded-full blur-2xl pointer-events-none"></div>

        <div className="max-w-2xl space-y-6 relative z-10">
          <span className="font-sans text-[10px] uppercase tracking-[0.25em] text-brass font-bold block">
            Timeless Gatherings
          </span>
          <h3 className="font-serif text-3xl md:text-4xl font-bold leading-tight">
            An Architectural Sabbatical
          </h3>
          <p className="font-sans text-sm text-white/80 font-light leading-relaxed">
            We believe that hospitality is multi-sensory. Our dining rooms are designed as quiet sanctuaries—sanctified by natural European oak timber floors, custom polished brass light fixtures, slate fireplaces, and deep hunter green or navy hues.
          </p>
          <p className="font-sans text-sm text-white/80 font-light leading-relaxed">
            There are no neon lights, no screens, and no rush. Only the crackle of vinyl records playing acoustic folk, the aroma of single-origin coffee brewing on our ceramic V60 bars, and the simple joy of warm sourdough waffles.
          </p>

          <div className="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="border border-white/15 p-3 text-center">
              <span className="block font-serif text-base font-bold text-brass">Oak Timber</span>
              <span className="block text-[8px] uppercase tracking-wider text-white/60 mt-1">Floors & Panels</span>
            </div>
            <div className="border border-white/15 p-3 text-center">
              <span className="block font-serif text-base font-bold text-brass">Solid Brass</span>
              <span className="block text-[8px] uppercase tracking-wider text-white/60 mt-1">Light Fittings</span>
            </div>
            <div className="border border-white/15 p-3 text-center">
              <span className="block font-serif text-base font-bold text-brass">Slate Stone</span>
              <span className="block text-[8px] uppercase tracking-wider text-white/60 mt-1">Hearths & Slabs</span>
            </div>
            <div className="border border-white/15 p-3 text-center">
              <span className="block font-serif text-base font-bold text-brass">White Ceramic</span>
              <span className="block text-[8px] uppercase tracking-wider text-white/60 mt-1">Vessel Plates</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
