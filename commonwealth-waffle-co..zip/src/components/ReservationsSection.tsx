import React, { useState } from 'react';
import { LocationInfo, Reservation } from '../types';
import { Calendar, Users, Clock, Mail, Phone, User, CheckCircle, Trash2, X } from 'lucide-react';
import { motion } from 'motion/react';

interface ReservationsSectionProps {
  locations: LocationInfo[];
  reservations: Reservation[];
  onAddReservation: (res: Omit<Reservation, 'id' | 'status'>) => void;
  onCancelReservation: (id: string) => void;
  isOpen: boolean;
  onClose: () => void;
  preselectedLocationId?: string;
}

export const ReservationsSection: React.FC<ReservationsSectionProps> = ({
  locations,
  reservations,
  onAddReservation,
  onCancelReservation,
  isOpen,
  onClose,
  preselectedLocationId
}) => {
  const [locationId, setLocationId] = useState(preselectedLocationId || locations[0]?.id || '');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('10:00 AM');
  const [guests, setGuests] = useState(2);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [notes, setNotes] = useState('');
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [lastBookingId, setLastBookingId] = useState('');

  // Sane reservation times
  const timeSlots = [
    '7:30 AM', '8:00 AM', '8:30 AM', '9:00 AM', '9:30 AM', '10:00 AM', 
    '10:30 AM', '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM', '1:00 PM', 
    '1:30 PM', '2:00 PM', '5:00 PM', '5:30 PM', '6:00 PM', '6:30 PM', 
    '7:00 PM', '7:30 PM', '8:00 PM', '8:30 PM'
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!locationId || !date || !time || !name || !email || !phone) {
      alert('Please fill in all mandatory fields');
      return;
    }

    const loc = locations.find(l => l.id === locationId);
    const locName = loc ? `${loc.city} (${loc.name})` : 'Commonwealth Waffle Co.';

    const tempId = 'RES-' + Math.floor(100000 + Math.random() * 900000);

    onAddReservation({
      name,
      email,
      phone,
      date,
      time,
      guests,
      locationId,
      locationName: locName,
      notes
    });

    setLastBookingId(tempId);
    setBookingSuccess(true);

    // Reset fields
    setDate('');
    setNotes('');
  };

  const handleReset = () => {
    setBookingSuccess(false);
    setLastBookingId('');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-navy/60 backdrop-blur-xs flex items-center justify-end z-50">
      <motion.div 
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 100 }}
        className="bg-[#FAF9F6] w-full max-w-xl h-full shadow-2xl flex flex-col justify-between overflow-y-auto border-l-4 border-brass"
      >
        {/* Header */}
        <div className="p-6 md:p-8 border-b border-navy/10 flex items-center justify-between sticky top-0 bg-[#FAF9F6] z-10">
          <div>
            <span className="font-sans text-[10px] uppercase tracking-widest text-brass font-bold block mb-1">
              Table Planning
            </span>
            <h3 className="font-serif text-2xl font-bold text-navy">
              Book a Waffle Table
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-2 border border-navy/10 hover:border-brass text-navy hover:text-brass transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form or Success State */}
        <div className="p-6 md:p-8 flex-1 space-y-8">
          {bookingSuccess ? (
            <div className="bg-white border border-brass p-6 text-center space-y-6 shadow-md my-12">
              <div className="w-16 h-16 rounded-full bg-forest-green/10 text-forest-green mx-auto flex items-center justify-center">
                <CheckCircle className="w-8 h-8" />
              </div>
              <div className="space-y-2">
                <span className="font-sans text-[10px] uppercase tracking-widest font-bold text-brass block">
                  Reservation Confirmed
                </span>
                <h4 className="font-serif text-2xl font-bold text-navy">
                  We Have Saved Your Table
                </h4>
                <p className="font-sans text-xs text-slate-grey font-light max-w-md mx-auto">
                  Your table has been reserved under the name <strong className="text-navy">{name}</strong>. A premium digest invitation card has been sent to <span className="text-navy">{email}</span>.
                </p>
              </div>

              {/* Booking reference voucher details */}
              <div className="bg-[#FAF9F6] border border-navy/5 p-4 rounded-xs text-left text-xs space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-grey font-medium uppercase tracking-wider text-[9px]">Location</span>
                  <span className="font-bold text-navy text-right">
                    {locations.find(l => l.id === locationId)?.name} ({locations.find(l => l.id === locationId)?.city})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-grey font-medium uppercase tracking-wider text-[9px]">Confirmation No</span>
                  <span className="font-bold text-brass tracking-widest uppercase">{lastBookingId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-grey font-medium uppercase tracking-wider text-[9px]">Guests / Table Size</span>
                  <span className="font-bold text-navy">{guests} Persons</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-grey font-medium uppercase tracking-wider text-[9px]">Date & Session</span>
                  <span className="font-bold text-navy">{date} at {time}</span>
                </div>
              </div>

              <div className="pt-4 flex flex-col gap-3">
                <button
                  onClick={handleReset}
                  className="bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold py-3 transition-colors duration-300 w-full"
                >
                  Book Another Table
                </button>
                <button
                  onClick={onClose}
                  className="border border-navy/20 hover:border-brass text-navy hover:text-brass text-xs uppercase tracking-widest font-bold py-3 transition-colors duration-300 w-full"
                >
                  Close Window
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Location Select */}
              <div className="space-y-2">
                <label htmlFor="location" className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                  1. House Location *
                </label>
                <select
                  id="location"
                  value={locationId}
                  onChange={(e) => setLocationId(e.target.value)}
                  className="w-full border border-navy/15 bg-white p-3 text-xs uppercase tracking-wider font-semibold text-navy focus:outline-none focus:border-brass rounded-none"
                  required
                >
                  {locations.map(loc => (
                    <option key={loc.id} value={loc.id}>
                      {loc.city} — {loc.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Guests Selector */}
              <div className="space-y-2">
                <label className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                  2. Table Size / Party Size *
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[1, 2, 4, 6].map(num => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setGuests(num)}
                      className={`py-3 text-xs font-bold transition-all border ${
                        guests === num 
                          ? 'bg-navy text-white border-navy shadow-md' 
                          : 'bg-white text-navy border-navy/10 hover:bg-navy/5'
                      }`}
                    >
                      <Users className="w-3.5 h-3.5 mx-auto mb-1 opacity-70" />
                      {num} {num === 1 ? 'Guest' : 'Guests'}
                    </button>
                  ))}
                </div>
                {/* Manual selector */}
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-[10px] text-slate-grey font-medium uppercase tracking-wider">Custom Count (up to 12):</span>
                  <input 
                    type="number" 
                    min="1" 
                    max="12" 
                    value={guests} 
                    onChange={(e) => setGuests(parseInt(e.target.value) || 2)} 
                    className="w-16 p-1 text-xs border border-navy/15 text-center font-bold text-navy"
                  />
                </div>
              </div>

              {/* Date Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="resDate" className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                    3. Dining Date *
                  </label>
                  <div className="relative">
                    <input
                      id="resDate"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      min={new Date().toISOString().split('T')[0]}
                      className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="resTime" className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                    4. Session Time *
                  </label>
                  <select
                    id="resTime"
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full border border-navy/15 bg-white p-3 text-xs uppercase tracking-wider font-semibold text-navy focus:outline-none focus:border-brass rounded-none"
                    required
                  >
                    {timeSlots.map(t => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Contact Fields */}
              <div className="space-y-4 border-t border-navy/10 pt-6">
                <span className="block text-[10px] uppercase tracking-widest font-bold text-brass mb-2">
                  5. Guest Credentials
                </span>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-semibold text-navy">
                    <User className="w-3.5 h-3.5 text-brass" />
                    <label htmlFor="guestName">Full Name *</label>
                  </div>
                  <input
                    id="guestName"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="E.g., Lord Alistair"
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                    required
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs font-semibold text-navy">
                      <Mail className="w-3.5 h-3.5 text-brass" />
                      <label htmlFor="guestEmail">Email Address *</label>
                    </div>
                    <input
                      id="guestEmail"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="alistair@commonwealth.uk"
                      className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs font-semibold text-navy">
                      <Phone className="w-3.5 h-3.5 text-brass" />
                      <label htmlFor="guestPhone">Phone Number *</label>
                    </div>
                    <input
                      id="guestPhone"
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="(617) 555-0143"
                      className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label htmlFor="guestNotes" className="block text-xs font-semibold text-navy">Special Dietary Requirements / Placement Notes</label>
                  <textarea
                    id="guestNotes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="E.g., Vegan butter request, birthday anniversary plaque, quiet leather booth in the corner, etc."
                    rows={2}
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold py-4 transition-all duration-300 shadow-md text-center mt-4"
              >
                Confirm Sourdough Table Reservation
              </button>
            </form>
          )}

          {/* Active Reservations in Current Session */}
          {reservations.length > 0 && (
            <div className="border-t border-navy/10 pt-8 mt-8 space-y-4">
              <h4 className="font-serif text-lg font-bold text-navy">
                Your Scheduled Bookings
              </h4>
              <div className="space-y-3">
                {reservations.map(res => (
                  <div key={res.id} className="bg-white border border-navy/5 p-4 flex items-center justify-between shadow-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-serif text-xs font-bold text-navy">{res.locationName}</span>
                        <span className="font-sans text-[8px] bg-forest-green/10 text-forest-green px-2 py-0.5 uppercase tracking-widest font-bold">
                          {res.status}
                        </span>
                      </div>
                      <p className="font-sans text-[10px] text-slate-grey mt-1">
                        {res.date} at {res.time} • {res.guests} Guests
                      </p>
                      {res.notes && (
                        <p className="font-sans text-[9px] text-slate-grey italic mt-1">
                          Note: "{res.notes}"
                        </p>
                      )}
                    </div>
                    <button
                      onClick={() => onCancelReservation(res.id)}
                      className="p-2 border border-red-100 text-red-500 hover:bg-red-50 hover:border-red-300 transition-colors"
                      title="Cancel Booking"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
