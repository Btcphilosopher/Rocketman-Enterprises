import React, { useState } from 'react';
import { MenuItem, CartItem, WaffleCustomization } from '../types';
import { Sparkles, Check, ShoppingBag, Plus, Minus, X } from 'lucide-react';
import { motion } from 'motion/react';

interface MenuSectionProps {
  menuItems: MenuItem[];
  onAddToCart: (item: MenuItem, quantity: number, customization?: WaffleCustomization) => void;
}

type MenuCategory = 'All' | 'Classic Waffles' | 'Belgian Waffles' | 'Savoury Waffles' | 'Breakfast' | 'Seasonal Specials' | 'Drinks';

export const MenuSection: React.FC<MenuSectionProps> = ({ menuItems, onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<MenuCategory>('All');
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  
  // Customization state
  const [customQuantity, setCustomQuantity] = useState(1);
  const [selectedBatter, setSelectedBatter] = useState<WaffleCustomization['batter']>('Traditional Sourdough');
  const [selectedSyrup, setSelectedSyrup] = useState<WaffleCustomization['syrup']>('Grade-A Vermont Amber Maple');
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);

  const categories: MenuCategory[] = [
    'All',
    'Classic Waffles',
    'Belgian Waffles',
    'Savoury Waffles',
    'Breakfast',
    'Seasonal Specials',
    'Drinks'
  ];

  const filteredItems = selectedCategory === 'All' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory);

  const getSubcategories = () => {
    const subs = new Set<string>();
    filteredItems.forEach(item => {
      if (item.subcategory) subs.add(item.subcategory);
    });
    return Array.from(subs);
  };

  const handleOpenCustomizer = (item: MenuItem) => {
    setCustomizingItem(item);
    setCustomQuantity(1);
    setSelectedBatter('Traditional Sourdough');
    // Set default syrup based on item
    if (item.id.includes('blueberry') || item.name.includes('Blueberry')) {
      setSelectedSyrup('Wild Maine Blueberry Drizzle');
    } else if (item.id.includes('choco') || item.name.includes('Chocolate')) {
      setSelectedSyrup('Rich Dark Chocolate Ganache');
    } else if (item.category === 'Drinks') {
      setSelectedSyrup('None');
    } else {
      setSelectedSyrup('Grade-A Vermont Amber Maple');
    }
    setSelectedExtras([]);
  };

  const toggleExtra = (extraName: string) => {
    if (selectedExtras.includes(extraName)) {
      setSelectedExtras(selectedExtras.filter(e => e !== extraName));
    } else {
      setSelectedExtras([...selectedExtras, extraName]);
    }
  };

  const extraPrices: { [key: string]: number } = {
    'Devonshire Clotted Cream': 2.00,
    'Native Sweet Strawberries': 1.50,
    'Whipped Sea-Salt Butter': 1.00,
    'Roasted Massachusetts Apples': 1.50,
    'Applewood Smoked Bacon': 2.50,
    'Vanilla Bean Gelato': 2.00,
    'Flaky Maine Sea Salt': 0.50
  };

  const batterPriceIncrements: { [key in WaffleCustomization['batter']]: number } = {
    'Traditional Sourdough': 0,
    'Gluten-Free Oat': 0,
    'Spiced Ginger': 1.00,
    'Savory Cheddar Chive': 1.50
  };

  // Compute live customized item price
  const basePrice = customizingItem ? customizingItem.price : 0;
  const batterAddon = customizingItem && customizingItem.category !== 'Drinks' ? batterPriceIncrements[selectedBatter] : 0;
  const extrasCost = selectedExtras.reduce((sum, extra) => sum + (extraPrices[extra] || 0), 0);
  const singleItemPrice = basePrice + batterAddon + extrasCost;
  const totalPrice = singleItemPrice * customQuantity;

  const handleAddCustomizedToCart = () => {
    if (!customizingItem) return;
    
    if (customizingItem.category === 'Drinks') {
      onAddToCart(customizingItem, customQuantity);
    } else {
      const customization: WaffleCustomization = {
        batter: selectedBatter,
        syrup: selectedSyrup,
        extraToppings: selectedExtras
      };
      onAddToCart(customizingItem, customQuantity, customization);
    }
    setCustomizingItem(null);
  };

  return (
    <div className="py-12 bg-[#FAF9F6] px-6 md:px-12 xl:px-16 min-h-screen">
      {/* Menu Header */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="font-sans text-xs uppercase tracking-[0.25em] font-bold text-brass block mb-2">
          Gourmet Offerings
        </span>
        <h2 className="font-serif text-4xl md:text-5xl font-bold text-navy mb-4">
          The Sourdough & Belgian Menus
        </h2>
        <div className="w-16 h-0.5 bg-brass mx-auto mb-4"></div>
        <p className="font-sans text-sm md:text-base text-slate-grey font-light">
          Each waffle rises for 24 hours on our custom wild yeast culture before being baked to golden, crispy perfection.
        </p>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap justify-center gap-2 md:gap-4 mb-16 border-b border-navy/10 pb-6 max-w-4xl mx-auto">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 text-[11px] uppercase tracking-widest font-bold transition-all duration-300 ${
              selectedCategory === cat
                ? 'bg-navy text-white shadow-md'
                : 'bg-white text-navy hover:bg-navy/5 border border-navy/10'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Menu Grid organized by Subcategories */}
      <div className="space-y-16 max-w-7xl mx-auto">
        {getSubcategories().map(subcat => {
          const itemsInSub = filteredItems.filter(item => item.subcategory === subcat);
          if (itemsInSub.length === 0) return null;
          
          return (
            <div key={subcat} className="space-y-6">
              {/* Subcategory Label */}
              <div className="border-b border-navy/10 pb-2 flex items-baseline justify-between">
                <h3 className="font-serif text-xl md:text-2xl italic font-semibold text-navy">
                  {subcat}
                </h3>
                <span className="font-sans text-[10px] text-slate-grey tracking-widest uppercase">
                  {itemsInSub.length} {itemsInSub.length === 1 ? 'Item' : 'Items'}
                </span>
              </div>

              {/* Items Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {itemsInSub.map(item => (
                  <div 
                    key={item.id}
                    className="bg-white border border-navy/10 group flex flex-col justify-between hover:shadow-xl hover:border-brass/40 transition-all duration-300 relative"
                  >
                    {/* Floating Signature Tag */}
                    {item.signature && (
                      <div className="absolute top-4 left-4 bg-navy text-brass border border-brass px-3 py-1 text-[9px] uppercase tracking-widest font-bold z-10 flex items-center gap-1">
                        <Sparkles className="w-2.5 h-2.5 text-brass" />
                        Signature Item
                      </div>
                    )}

                    {/* Image Area */}
                    <div className="h-56 overflow-hidden relative bg-[#EAE8E4]">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        referrerPolicy="no-referrer"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>

                    {/* Text Details */}
                    <div className="p-6 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-start gap-2 mb-2">
                          <h4 className="font-serif text-lg font-bold text-navy group-hover:text-brass transition-colors">
                            {item.name}
                          </h4>
                          <span className="font-serif text-base font-bold text-navy shrink-0">
                            ${item.price.toFixed(2)}
                          </span>
                        </div>
                        <p className="font-sans text-xs text-slate-grey font-light leading-relaxed mb-4">
                          {item.description}
                        </p>
                      </div>

                      {/* Footer Info / Buy trigger */}
                      <div className="pt-4 border-t border-navy/5 flex items-center justify-between mt-auto">
                        {/* Ingredient list snippet */}
                        <div className="flex flex-wrap gap-1 max-w-[60%]">
                          {item.ingredients.slice(0, 2).map((ing, idx) => (
                            <span key={idx} className="bg-[#FAF9F6] text-navy/70 text-[9px] px-2 py-0.5 border border-navy/5 font-semibold">
                              {ing}
                            </span>
                          ))}
                          {item.ingredients.length > 2 && (
                            <span className="text-[9px] text-slate-grey font-bold pl-1">+{item.ingredients.length - 2}</span>
                          )}
                        </div>

                        {/* Order Trigger */}
                        <button
                          onClick={() => handleOpenCustomizer(item)}
                          className="bg-navy hover:bg-brass text-white text-[10px] uppercase tracking-widest font-bold px-3 py-2 transition-colors duration-300"
                        >
                          {item.category === 'Drinks' ? 'Add To Order' : 'Customize'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* --- CUSTOMIZER MODAL --- */}
      {customizingItem && (
        <div className="fixed inset-0 bg-navy/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="bg-[#FAF9F6] w-full max-w-2xl max-h-[90vh] overflow-y-auto border-4 border-white shadow-2xl flex flex-col relative"
          >
            {/* Modal Header */}
            <div className="flex justify-between items-start p-6 border-b border-navy/10 sticky top-0 bg-[#FAF9F6] z-10">
              <div>
                <span className="font-sans text-[10px] uppercase tracking-widest text-brass font-bold block mb-1">
                  {customizingItem.category}
                </span>
                <h3 className="font-serif text-2xl font-bold text-navy">
                  {customizingItem.name}
                </h3>
              </div>
              <button 
                onClick={() => setCustomizingItem(null)}
                className="p-2 border border-navy/10 hover:border-brass text-navy hover:text-brass transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Scrollable Body */}
            <div className="p-6 space-y-8 flex-1">
              {/* Product Info Banner */}
              <div className="flex flex-col sm:flex-row gap-4 bg-white p-4 border border-navy/10">
                <img 
                  src={customizingItem.image} 
                  alt={customizingItem.name}
                  className="w-24 h-24 object-cover border border-navy/10 shrink-0"
                  referrerPolicy="no-referrer"
                />
                <div>
                  <p className="font-sans text-xs text-slate-grey font-light mb-2">
                    {customizingItem.description}
                  </p>
                  <p className="font-sans text-[11px] font-bold text-navy uppercase tracking-wider">
                    Base Ingredients: <span className="text-slate-grey font-normal normal-case">{customizingItem.ingredients.join(', ')}</span>
                  </p>
                </div>
              </div>

              {/* Only show batter & syrup if it is not a Drink */}
              {customizingItem.category !== 'Drinks' ? (
                <>
                  {/* Batter Selection */}
                  <div className="space-y-3">
                    <h4 className="font-serif text-base font-bold text-navy border-b border-navy/5 pb-1">
                      1. Choose Sourdough Batter
                    </h4>
                    <p className="text-[11px] text-slate-grey font-light mb-2">Each batter is prepared freshly every morning.</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {(['Traditional Sourdough', 'Gluten-Free Oat', 'Spiced Ginger', 'Savory Cheddar Chive'] as const).map(bat => {
                        const increment = batterPriceIncrements[bat];
                        return (
                          <button
                            key={bat}
                            type="button"
                            onClick={() => setSelectedBatter(bat)}
                            className={`flex justify-between items-center p-3 text-left border text-xs font-semibold uppercase tracking-wider transition-all ${
                              selectedBatter === bat
                                ? 'bg-navy text-white border-navy shadow-md'
                                : 'bg-white text-navy border-navy/10 hover:bg-navy/5'
                            }`}
                          >
                            <span>{bat}</span>
                            <span className="opacity-80">
                              {increment === 0 ? 'Included' : `+$${increment.toFixed(2)}`}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Syrup Selection */}
                  <div className="space-y-3">
                    <h4 className="font-serif text-base font-bold text-navy border-b border-navy/5 pb-1">
                      2. Select Artisanal Glaze / Syrup
                    </h4>
                    <p className="text-[11px] text-slate-grey font-light mb-2">Our syrups are infused with organic regional aromatics.</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {(['Grade-A Vermont Amber Maple', 'Wild Maine Blueberry Drizzle', 'Rich Dark Chocolate Ganache', 'English Toffee', 'None'] as const).map(syr => (
                        <button
                          key={syr}
                          type="button"
                          onClick={() => setSelectedSyrup(syr)}
                          className={`flex justify-between items-center p-3 text-left border text-xs font-semibold uppercase tracking-wider transition-all ${
                            selectedSyrup === syr
                              ? 'bg-navy text-white border-navy shadow-md'
                              : 'bg-white text-navy border-navy/10 hover:bg-navy/5'
                          }`}
                        >
                          <span>{syr}</span>
                          {selectedSyrup === syr && <Check className="w-3.5 h-3.5 text-brass" />}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Premium Extra Toppings */}
                  <div className="space-y-3">
                    <h4 className="font-serif text-base font-bold text-navy border-b border-navy/5 pb-1">
                      3. Premium Extra Toppings (Optional)
                    </h4>
                    <p className="text-[11px] text-slate-grey font-light mb-2">Load your waffle with additional locally sourced farm items.</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {Object.entries(extraPrices).map(([name, price]) => {
                        const isSelected = selectedExtras.includes(name);
                        return (
                          <button
                            key={name}
                            type="button"
                            onClick={() => toggleExtra(name)}
                            className={`flex justify-between items-center p-3 text-left border text-xs font-semibold transition-all ${
                              isSelected
                                ? 'bg-brass text-white border-brass shadow-md'
                                : 'bg-white text-navy border-navy/10 hover:bg-navy/5'
                            }`}
                          >
                            <span className="uppercase tracking-wider">{name}</span>
                            <span className={isSelected ? 'text-white' : 'text-brass'}>
                              +${price.toFixed(2)}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              ) : (
                <div className="p-4 bg-white border border-navy/5 text-center">
                  <p className="font-sans text-xs text-slate-grey italic">
                    This beverage is prepared exactly as requested using standard premium barista practices. No custom modifiers are required.
                  </p>
                </div>
              )}
            </div>

            {/* Modal Sticky Footer - Checkout & Quantity */}
            <div className="p-6 border-t border-navy/10 sticky bottom-0 bg-white flex flex-col sm:flex-row items-center justify-between gap-4">
              {/* Quantity Selector */}
              <div className="flex items-center gap-3 border border-navy/20 bg-[#FAF9F6] p-1">
                <button 
                  onClick={() => setCustomQuantity(Math.max(1, customQuantity - 1))}
                  className="p-2 hover:bg-navy/5 text-navy text-sm font-bold transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="font-serif text-base font-bold text-navy w-8 text-center">
                  {customQuantity}
                </span>
                <button 
                  onClick={() => setCustomQuantity(customQuantity + 1)}
                  className="p-2 hover:bg-navy/5 text-navy text-sm font-bold transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Total Price and Action */}
              <div className="flex items-center gap-6 w-full sm:w-auto justify-between sm:justify-end">
                <div className="text-right">
                  <span className="block text-[9px] uppercase tracking-widest text-slate-grey">Current Total</span>
                  <span className="font-serif text-2xl font-bold text-navy">
                    ${totalPrice.toFixed(2)}
                  </span>
                </div>
                <button
                  onClick={handleAddCustomizedToCart}
                  className="bg-navy hover:bg-brass text-white px-8 py-4 text-xs uppercase tracking-widest font-bold flex items-center gap-2 transition-all duration-300 shadow-md"
                >
                  <ShoppingBag className="w-3.5 h-3.5" />
                  Add To Order
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
