import React, { useState } from 'react';
import { LoyaltyMember } from '../types';
import { User, Award, QrCode, Sparkles, Check, Gift, ArrowRight, ShieldAlert, X } from 'lucide-react';
import { motion } from 'motion/react';

interface LoyaltySectionProps {
  member: LoyaltyMember | null;
  onRegisterMember: (name: string, email: string, phone: string) => void;
  isOpen: boolean;
  onClose: () => void;
  ordersCount: number;
  totalSpent: number;
}

export const LoyaltySection: React.FC<LoyaltySectionProps> = ({
  member,
  onRegisterMember,
  isOpen,
  onClose,
  ordersCount,
  totalSpent
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  // Sane mock rewards
  const rewards = [
    { id: 'rew-coffee', name: 'Free George Howell Pour-Over', cost: 50, description: 'Single-origin drip brew precisely prepared at our V60 bar.' },
    { id: 'rew-butter', name: 'Free Whipped Sea-Salt Butter Jar', cost: 120, description: 'An 8oz glass crock of our signature salted farm butter.' },
    { id: 'rew-waffle', name: 'Free Vermont Maple Butter Waffle', cost: 200, description: 'Our flagship golden sourdough waffle with Grade-A maple syrup.' },
    { id: 'rew-tasting', name: 'Exclusive Seasonal Tasting Ticket', cost: 500, description: 'Early-access dining table reservation with our head culinary master.' }
  ];

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email && phone) {
      onRegisterMember(name, email, phone);
    }
  };

  if (!isOpen) return null;

  // Derive points from current orders and spending if member is active
  const calculatedPoints = member ? Math.floor(member.points + (totalSpent * 10)) : 0;
  
  // Determine Tier
  let currentTier: LoyaltyMember['tier'] = 'Patron';
  let tierProgress = 0;
  let nextTier = 'Sovereign';
  let pointsNeeded = 200;

  if (calculatedPoints >= 500) {
    currentTier = 'Commonwealth Guild';
    tierProgress = 100;
    nextTier = 'Supreme Honor';
    pointsNeeded = 0;
  } else if (calculatedPoints >= 200) {
    currentTier = 'Sovereign';
    tierProgress = ((calculatedPoints - 200) / 300) * 100;
    nextTier = 'Commonwealth Guild';
    pointsNeeded = 500 - calculatedPoints;
  } else {
    currentTier = 'Patron';
    tierProgress = (calculatedPoints / 200) * 100;
    nextTier = 'Sovereign';
    pointsNeeded = 200 - calculatedPoints;
  }

  return (
    <div className="fixed inset-0 bg-navy/60 backdrop-blur-xs flex items-center justify-end z-50">
      <motion.div 
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 100 }}
        className="bg-[#FAF9F6] w-full max-w-md h-full shadow-2xl flex flex-col justify-between overflow-y-auto border-l-4 border-brass"
      >
        {/* Header */}
        <div className="p-6 border-b border-navy/10 flex items-center justify-between sticky top-0 bg-[#FAF9F6] z-10">
          <div>
            <span className="font-sans text-[10px] uppercase tracking-widest text-brass font-bold block mb-1">
              Loyalty Guild
            </span>
            <h3 className="font-serif text-2xl font-bold text-navy">
              The Commonwealth Club
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-2 border border-navy/10 hover:border-brass text-navy hover:text-brass transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Core Content */}
        <div className="p-6 flex-1 space-y-6">
          {!member ? (
            /* REGISTRATION FORM STATE */
            <div className="space-y-6 my-4">
              <div className="text-center bg-white border border-navy/10 p-6 space-y-3">
                <Award className="w-10 h-10 text-brass mx-auto" />
                <h4 className="font-serif text-xl font-bold text-navy">Join the Inner Circle</h4>
                <p className="font-sans text-xs text-slate-grey font-light leading-relaxed">
                  Unlock access to special tastings, birthday gestures, secret seasonal syrups, and earn **10 reward points** on every single dollar spent across our New England houses.
                </p>
              </div>

              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-1">
                  <label htmlFor="member_name" className="block text-[10px] uppercase tracking-widest font-bold text-brass">Full Name</label>
                  <input
                    id="member_name"
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="E.g., Alistair Cooke"
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label htmlFor="member_email" className="block text-[10px] uppercase tracking-widest font-bold text-brass">Email Address</label>
                  <input
                    id="member_email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="alistair@cooke.com"
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label htmlFor="member_phone" className="block text-[10px] uppercase tracking-widest font-bold text-brass">Phone Number</label>
                  <input
                    id="member_phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="(617) 555-0143"
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold py-4 transition-all duration-300 shadow-md text-center"
                >
                  Join The Commonwealth Club
                </button>
              </form>

              <div className="flex items-start gap-2 text-[10px] text-slate-grey bg-navy/5 p-3 leading-relaxed">
                <ShieldAlert className="w-4 h-4 text-brass shrink-0" />
                <span>By joining, you agree to receive digital vouchers, menu launches, and exclusive table availability digests. We never sell your credentials.</span>
              </div>
            </div>
          ) : (
            /* ACTIVE MEMBER PROFILE DASHBOARD */
            <div className="space-y-6">
              {/* Digital Membership Card */}
              <div className="bg-navy text-white p-6 border-2 border-brass shadow-xl relative overflow-hidden">
                <div className="absolute inset-0 opacity-10 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/linen-paper.png')]"></div>
                <div className="absolute -top-16 -right-16 w-36 h-36 bg-brass/10 rounded-full blur-xl"></div>
                
                <div className="flex justify-between items-start mb-8 z-10 relative">
                  <div>
                    <span className="font-serif text-lg font-bold tracking-tight text-white block uppercase leading-none">
                      Commonwealth Club
                    </span>
                    <span className="font-sans text-[8px] tracking-widest text-brass block uppercase font-bold mt-1">
                      New England Guild Card
                    </span>
                  </div>
                  <Sparkles className="w-5 h-5 text-brass animate-pulse" />
                </div>

                <div className="flex justify-between items-end z-10 relative">
                  <div className="space-y-1">
                    <span className="block text-[9px] uppercase tracking-wider text-white/50">Guild Member</span>
                    <strong className="block text-sm font-serif font-semibold text-white uppercase">{member.name}</strong>
                    <span className="block text-[10px] font-sans text-brass uppercase font-bold tracking-widest">
                      {currentTier} Tier
                    </span>
                  </div>

                  {/* Visual QR scan code */}
                  <div className="bg-white p-2 border border-brass">
                    <QrCode className="w-10 h-10 text-navy" />
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-white/10 flex justify-between text-[9px] text-white/60 font-semibold uppercase tracking-widest">
                  <span>ID: {member.memberId}</span>
                  <span>Joined {member.joinedDate}</span>
                </div>
              </div>

              {/* Reward Points Stat Ring block */}
              <div className="bg-white border border-navy/10 p-6 flex justify-between items-center shadow-xs">
                <div>
                  <span className="text-[10px] uppercase tracking-widest font-bold text-brass block">Active Ledger Balance</span>
                  <span className="font-serif text-4xl font-bold text-navy block mt-1">
                    {calculatedPoints} <span className="text-lg font-normal text-slate-grey">Pts</span>
                  </span>
                  {pointsNeeded > 0 ? (
                    <span className="text-[10px] text-slate-grey block mt-1">
                      Earn <strong>{pointsNeeded}</strong> more points to reach <strong className="text-brass">{nextTier}</strong>.
                    </span>
                  ) : (
                    <span className="text-[10px] text-forest-green block mt-1">
                      You have achieved our absolute highest guild honors!
                    </span>
                  )}
                </div>
                
                {/* Visual Circle progress */}
                <div className="w-16 h-16 rounded-full border-4 border-navy/5 flex items-center justify-center relative">
                  <div className="text-[11px] font-serif font-bold text-brass">{Math.floor(tierProgress)}%</div>
                  <div 
                    className="absolute inset-0 rounded-full border-4 border-brass border-t-transparent border-r-transparent rotate-45"
                    style={{ clipPath: `polygon(0 0, 100% 0, 100% ${tierProgress}%, 0 ${tierProgress}%)` }}
                  ></div>
                </div>
              </div>

              {/* Earn Points Hint block */}
              {ordersCount > 0 && (
                <div className="bg-forest-green/5 border border-forest-green/20 p-3 flex items-center gap-2 text-xs text-forest-green">
                  <Gift className="w-4 h-4 shrink-0" />
                  <span>
                    You accumulated <strong>{Math.floor(totalSpent * 10)}</strong> pts from your <strong>{ordersCount}</strong> online order{ordersCount > 1 ? 's' : ''}!
                  </span>
                </div>
              )}

              {/* Redeemable Rewards list */}
              <div className="space-y-3">
                <span className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                  Redeem Guild Rewards
                </span>

                <div className="space-y-3">
                  {rewards.map(rew => {
                    const canAfford = calculatedPoints >= rew.cost;
                    return (
                      <div 
                        key={rew.id} 
                        className={`border p-4 bg-white flex flex-col justify-between transition-all ${
                          canAfford ? 'border-navy/15 hover:border-brass/50' : 'border-navy/5 opacity-60'
                        }`}
                      >
                        <div className="flex justify-between items-start gap-4 mb-2">
                          <div>
                            <h5 className="font-serif text-sm font-bold text-navy">{rew.name}</h5>
                            <p className="font-sans text-xs text-slate-grey font-light mt-0.5">{rew.description}</p>
                          </div>
                          <span className={`font-serif text-sm font-bold shrink-0 ${canAfford ? 'text-brass' : 'text-slate-grey'}`}>
                            {rew.cost} Pts
                          </span>
                        </div>

                        <div className="flex justify-end pt-2 border-t border-navy/5 mt-2">
                          <button
                            disabled={!canAfford}
                            onClick={() => alert(`Reward Redeemed! A custom digital voucher for ${rew.name} has been added to your email ${member.email}.`)}
                            className={`px-3 py-1.5 text-[9px] uppercase tracking-widest font-bold transition-all ${
                              canAfford 
                                ? 'bg-navy hover:bg-brass text-white cursor-pointer' 
                                : 'bg-navy/5 text-navy/40 cursor-not-allowed'
                            }`}
                          >
                            Redeem Reward
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Points activity ledger */}
              <div className="border-t border-navy/10 pt-4 space-y-2">
                <span className="block text-[10px] uppercase tracking-widest font-bold text-navy opacity-60">
                  Activity Ledger
                </span>
                <div className="bg-white border border-navy/5 p-3 rounded-xs text-[11px] space-y-2 max-h-32 overflow-y-auto">
                  <div className="flex justify-between text-slate-grey">
                    <span>Guild Welcoming Bonus</span>
                    <span className="text-forest-green font-bold">+50 pts</span>
                  </div>
                  {ordersCount > 0 && (
                    <div className="flex justify-between text-slate-grey">
                      <span>Online Orders Multiplier (10x)</span>
                      <span className="text-forest-green font-bold">+{Math.floor(totalSpent * 10)} pts</span>
                    </div>
                  )}
                  {calculatedPoints >= 200 && (
                    <div className="flex justify-between text-brass font-semibold">
                      <span>Sovereign Rank Achievement</span>
                      <span>Unlocked</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};
