import React from 'react';
import { ShoppingBag, Calendar, User, ShieldCheck } from 'lucide-react';
import { CartItem } from '../types';

interface NavbarProps {
  cart: CartItem[];
  currentView: string;
  setCurrentView: (view: string) => void;
  onOpenCart: () => void;
  onOpenReservations: () => void;
  onOpenLoyalty: () => void;
  onOpenCMS: () => void;
  cmsActive: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  cart,
  currentView,
  setCurrentView,
  onOpenCart,
  onOpenReservations,
  onOpenLoyalty,
  onOpenCMS,
  cmsActive
}) => {
  const totalCartItems = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <nav className="flex flex-col md:flex-row items-center justify-between px-6 md:px-12 py-6 border-b border-navy/10 bg-[#FAF9F6] sticky top-0 z-40 transition-all duration-300">
      {/* Brand Identity */}
      <div 
        className="flex flex-col cursor-pointer select-none mb-4 md:mb-0 text-center md:text-left"
        onClick={() => setCurrentView('home')}
      >
        <span className="font-serif text-2xl font-bold tracking-tight uppercase leading-none text-navy">
          Commonwealth
        </span>
        <span className="font-sans text-[10px] tracking-[0.25em] font-semibold text-brass uppercase mt-1">
          Waffle Company
        </span>
      </div>

      {/* Navigation Links */}
      <div className="flex flex-wrap justify-center gap-6 md:gap-10 text-[11px] uppercase tracking-widest font-semibold text-navy/80 mb-4 md:mb-0">
        <button 
          onClick={() => setCurrentView('menu')}
          className={`hover:text-brass transition-colors py-1 ${currentView === 'menu' ? 'text-brass border-b-2 border-brass' : ''}`}
        >
          The Menu
        </button>
        <button 
          onClick={() => setCurrentView('locations')}
          className={`hover:text-brass transition-colors py-1 ${currentView === 'locations' ? 'text-brass border-b-2 border-brass' : ''}`}
        >
          Locations
        </button>
        <button 
          onClick={() => setCurrentView('suppliers')}
          className={`hover:text-brass transition-colors py-1 ${currentView === 'suppliers' ? 'text-brass border-b-2 border-brass' : ''}`}
        >
          Our Suppliers
        </button>
        <button 
          onClick={onOpenLoyalty}
          className="hover:text-brass transition-colors py-1 flex items-center gap-1"
        >
          <User className="w-3.5 h-3.5" />
          The Club
        </button>
      </div>

      {/* Utility Actions */}
      <div className="flex items-center gap-3 md:gap-4 flex-wrap justify-center">
        {/* Reservation Quick Button */}
        <button 
          onClick={onOpenReservations}
          className="flex items-center gap-2 border border-navy/30 hover:border-brass px-4 py-2 text-[11px] uppercase tracking-[0.1em] font-bold text-navy hover:text-brass transition-all duration-300"
        >
          <Calendar className="w-3.5 h-3.5" />
          Book Table
        </button>

        {/* Online Order Quick Button */}
        <button 
          onClick={() => setCurrentView('menu')}
          className="bg-navy text-white hover:bg-brass hover:text-white px-5 py-2 text-[11px] uppercase tracking-[0.1em] font-bold transition-all duration-300"
        >
          Order Online
        </button>

        {/* Cart Icon */}
        <button 
          onClick={onOpenCart}
          className="relative p-2 text-navy hover:text-brass transition-colors duration-200"
          aria-label="Shopping Cart"
        >
          <ShoppingBag className="w-5 h-5" />
          {totalCartItems > 0 && (
            <span className="absolute -top-1 -right-1 bg-brass text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
              {totalCartItems}
            </span>
          )}
        </button>

        {/* CMS Dashboard Access */}
        <button
          onClick={onOpenCMS}
          className={`flex items-center gap-1 px-3 py-2 text-[10px] uppercase tracking-wider font-bold transition-all duration-300 border ${
            cmsActive 
              ? 'bg-brass text-white border-brass' 
              : 'border-navy/10 text-navy/60 hover:text-navy hover:border-navy/30'
          }`}
          title="Restaurant Manager Portal"
        >
          <ShieldCheck className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">CMS Portal</span>
        </button>
      </div>
    </nav>
  );
};
