import React, { useState } from 'react';
import { CartItem, Order, LocationInfo } from '../types';
import { ShoppingBag, CreditCard, ChevronRight, CheckCircle, Trash2, ShieldCheck, MapPin, Clock, Truck, ArrowRight, X } from 'lucide-react';
import { motion } from 'motion/react';

interface OrderSectionProps {
  cart: CartItem[];
  onUpdateQty: (id: string, newQty: number) => void;
  onRemoveItem: (id: string) => void;
  onCheckout: (orderDetails: {
    customerName: string;
    email: string;
    phone: string;
    type: 'pickup' | 'delivery';
    deliveryAddress?: string;
    scheduledTime: string;
  }) => void;
  activeOrder: Order | null;
  locations: LocationInfo[];
  isOpen: boolean;
  onClose: () => void;
}

export const OrderSection: React.FC<OrderSectionProps> = ({
  cart,
  onUpdateQty,
  onRemoveItem,
  onCheckout,
  activeOrder,
  locations,
  isOpen,
  onClose
}) => {
  const [checkoutMode, setCheckoutMode] = useState(false);
  const [orderType, setOrderType] = useState<'pickup' | 'delivery'>('pickup');
  const [pickupLocation, setPickupLocation] = useState(locations[0]?.id || '');
  const [address, setAddress] = useState('');
  const [scheduledTime, setScheduledTime] = useState('ASAP');
  
  // Checkout credentials
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  // Payment credentials
  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvc, setCvc] = useState('');
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  // Time Slot Selection
  const timeSlots = ['ASAP', '11:00 AM', '11:30 AM', '12:00 PM', '12:30 PM', '1:00 PM', '1:30 PM', '2:00 PM', '5:30 PM', '6:00 PM', '6:30 PM', '7:00 PM', '7:30 PM', '8:00 PM'];

  const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const tax = subtotal * 0.0825; // New England sales tax average
  const deliveryFee = orderType === 'delivery' ? 5.00 : 0.00;
  const total = subtotal + tax + deliveryFee;

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !phone || (orderType === 'delivery' && !address)) {
      alert('Please fill in all customer detail fields.');
      return;
    }
    if (!cardNumber || !expiry || !cvc) {
      alert('Please enter your card credentials for our secure checkout.');
      return;
    }

    // Process checkout
    onCheckout({
      customerName: name,
      email,
      phone,
      type: orderType,
      deliveryAddress: orderType === 'delivery' ? address : `Pickup from ${locations.find(l => l.id === pickupLocation)?.name}`,
      scheduledTime
    });

    setPaymentSuccess(true);
    setCheckoutMode(false);
  };

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Format card number with spaces (4-4-4-4)
    let value = e.target.value.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
    let matches = value.match(/\d{4,16}/g);
    let match = (matches && matches[0]) || '';
    let parts = [];

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4));
    }

    if (parts.length > 0) {
      setCardNumber(parts.join(' '));
    } else {
      setCardNumber(value);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-navy/60 backdrop-blur-xs flex items-center justify-end z-50">
      <motion.div 
        initial={{ opacity: 0, x: 100 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: 100 }}
        className="bg-[#FAF9F6] w-full max-w-lg h-full shadow-2xl flex flex-col justify-between overflow-y-auto border-l-4 border-brass"
      >
        {/* Header */}
        <div className="p-6 border-b border-navy/10 flex items-center justify-between sticky top-0 bg-[#FAF9F6] z-10">
          <div>
            <span className="font-sans text-[10px] uppercase tracking-widest text-brass font-bold block mb-1">
              Gourmet takeaway
            </span>
            <h3 className="font-serif text-2xl font-bold text-navy">
              {activeOrder ? 'Track Your Order' : checkoutMode ? 'Secure Checkout' : 'Your Waffle Basket'}
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-2 border border-navy/10 hover:border-brass text-navy hover:text-brass transition-all"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic States inside Drawer Body */}
        <div className="p-6 flex-1 space-y-6">
          {activeOrder ? (
            /* ACTIVE ORDER TRACKER */
            <div className="space-y-8 my-4">
              <div className="text-center space-y-3 bg-white p-6 border border-brass shadow-md">
                <div className="w-12 h-12 rounded-full bg-forest-green/10 text-forest-green flex items-center justify-center mx-auto">
                  <CheckCircle className="w-6 h-6" />
                </div>
                <div>
                  <span className="font-sans text-[10px] uppercase tracking-widest font-bold text-brass block">Order Dispatched</span>
                  <h4 className="font-serif text-xl font-bold text-navy">Ref No: {activeOrder.id}</h4>
                  <p className="font-sans text-xs text-slate-grey mt-1">
                    Prepared with love at <strong>Commonwealth Waffle Co.</strong>
                  </p>
                </div>
              </div>

              {/* Progress Tracker Stages */}
              <div className="space-y-6 bg-white p-6 border border-navy/10 relative">
                <div className="absolute left-[34px] top-10 bottom-10 w-0.5 bg-navy/5"></div>
                
                {/* Stage 1: Received */}
                <div className="flex gap-4 items-start relative z-10">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 font-serif text-xs font-bold ${
                    ['Pending', 'Prepped', 'Out for Delivery', 'Ready for Pickup', 'Completed'].includes(activeOrder.status)
                      ? 'bg-navy border-brass text-brass'
                      : 'bg-white border-navy/10 text-navy/40'
                  }`}>
                    1
                  </div>
                  <div>
                    <h5 className="font-serif text-sm font-bold text-navy">Order Received</h5>
                    <p className="font-sans text-[11px] text-slate-grey">The house kitchen has logged and queued your waffles.</p>
                  </div>
                </div>

                {/* Stage 2: Prepped */}
                <div className="flex gap-4 items-start relative z-10">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 font-serif text-xs font-bold ${
                    ['Prepped', 'Out for Delivery', 'Ready for Pickup', 'Completed'].includes(activeOrder.status)
                      ? 'bg-navy border-brass text-brass'
                      : 'bg-white border-navy/10 text-navy/40'
                  }`}>
                    2
                  </div>
                  <div>
                    <h5 className="font-serif text-sm font-bold text-navy">Sourdough Ironing & Bake</h5>
                    <p className="font-sans text-[11px] text-slate-grey">Waffle iron heating, organic batter pouring to golden caramel.</p>
                  </div>
                </div>

                {/* Stage 3: Artisanal Topping */}
                <div className="flex gap-4 items-start relative z-10">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 font-serif text-xs font-bold ${
                    ['Out for Delivery', 'Ready for Pickup', 'Completed'].includes(activeOrder.status)
                      ? 'bg-navy border-brass text-brass'
                      : 'bg-white border-navy/10 text-navy/40'
                  }`}>
                    3
                  </div>
                  <div>
                    <h5 className="font-serif text-sm font-bold text-navy">Artisanal Glazing & Assembly</h5>
                    <p className="font-sans text-[11px] text-slate-grey">Adding freshly prepared fruit, wild berries, and clotted cream.</p>
                  </div>
                </div>

                {/* Stage 4: Out for Dispatch / Ready */}
                <div className="flex gap-4 items-start relative z-10">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center border-2 font-serif text-xs font-bold ${
                    ['Completed', 'Completed'].includes(activeOrder.status) || (activeOrder.type === 'delivery' && activeOrder.status === 'Out for Delivery') || (activeOrder.type === 'pickup' && activeOrder.status === 'Ready for Pickup')
                      ? 'bg-navy border-brass text-brass animate-pulse'
                      : 'bg-white border-navy/10 text-navy/40'
                  }`}>
                    4
                  </div>
                  <div>
                    <h5 className="font-serif text-sm font-bold text-navy">
                      {activeOrder.type === 'delivery' ? 'Dispatched with Courier' : 'Ready on the House Counter'}
                    </h5>
                    <p className="font-sans text-[11px] text-slate-grey">
                      {activeOrder.type === 'delivery' 
                        ? 'Our private courier has dispatched. Secure heat-locked bags are active.' 
                        : 'Your warm box is waiting on Newbury St. Tell the barista your name.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Order details description */}
              <div className="bg-white border border-navy/10 p-4 space-y-2 text-xs">
                <span className="font-serif text-xs font-bold text-navy block border-b border-navy/5 pb-1">
                  Deliver To
                </span>
                <p className="font-sans text-slate-grey">{activeOrder.deliveryAddress}</p>
                <div className="flex justify-between font-bold text-navy pt-2 border-t border-navy/5">
                  <span>Grand Total</span>
                  <span>${activeOrder.total.toFixed(2)}</span>
                </div>
              </div>

              <div className="bg-navy/5 p-4 text-center border border-navy/10 text-[10px] text-navy font-semibold flex items-center gap-1 justify-center">
                <ShieldCheck className="w-4 h-4 text-brass" />
                <span>Dynamic WebSocket Simulation Active. Status can be updated from CMS.</span>
              </div>
            </div>
          ) : checkoutMode ? (
            /* CHECKOUT CREDIT INTERFACE */
            <form onSubmit={handleCheckoutSubmit} className="space-y-6 my-2">
              <div className="space-y-3">
                <span className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                  1. Order Delivery Selection
                </span>
                
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setOrderType('pickup')}
                    className={`py-3 text-xs font-bold border flex items-center justify-center gap-1.5 transition-all ${
                      orderType === 'pickup'
                        ? 'bg-navy text-white border-navy shadow-md'
                        : 'bg-white text-navy border-navy/10 hover:bg-navy/5'
                    }`}
                  >
                    <Clock className="w-3.5 h-3.5" />
                    Pickup at House
                  </button>
                  <button
                    type="button"
                    onClick={() => setOrderType('delivery')}
                    className={`py-3 text-xs font-bold border flex items-center justify-center gap-1.5 transition-all ${
                      orderType === 'delivery'
                        ? 'bg-navy text-white border-navy shadow-md'
                        : 'bg-white text-navy border-navy/10 hover:bg-navy/5'
                    }`}
                  >
                    <Truck className="w-3.5 h-3.5" />
                    Express Courier
                  </button>
                </div>
              </div>

              {orderType === 'pickup' ? (
                <div className="space-y-1">
                  <label htmlFor="pickup" className="block text-[9px] uppercase tracking-widest font-bold text-slate-grey">Select Pickup Café House</label>
                  <select
                    id="pickup"
                    value={pickupLocation}
                    onChange={(e) => setPickupLocation(e.target.value)}
                    className="w-full border border-navy/15 bg-white p-3 text-xs uppercase tracking-wider font-semibold text-navy focus:outline-none focus:border-brass rounded-none"
                  >
                    {locations.map(loc => (
                      <option key={loc.id} value={loc.id}>{loc.city} — {loc.name}</option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="space-y-1">
                  <label htmlFor="delivery_address" className="block text-[9px] uppercase tracking-widest font-bold text-slate-grey">Courier Delivery Address</label>
                  <input
                    id="delivery_address"
                    type="text"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="75 Beacon St, Beacon Hill, Boston, MA"
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none"
                    required
                  />
                </div>
              )}

              {/* Time Scheduling */}
              <div className="space-y-1">
                <label htmlFor="schedule_time" className="block text-[9px] uppercase tracking-widest font-bold text-slate-grey">Scheduled Basket Arrival</label>
                <select
                  id="schedule_time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e.target.value)}
                  className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none"
                >
                  {timeSlots.map(t => (
                    <option key={t} value={t}>{t === 'ASAP' ? 'Prepare ASAP (25-30 Mins)' : `Schedule for ${t}`}</option>
                  ))}
                </select>
              </div>

              {/* Contact Credentials */}
              <div className="space-y-3 border-t border-navy/10 pt-4">
                <span className="block text-[10px] uppercase tracking-widest font-bold text-brass">
                  2. Customer Information
                </span>

                <div className="space-y-1">
                  <input
                    type="text"
                    placeholder="Full Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none"
                    required
                  />
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none"
                    required
                  />
                </div>
              </div>

              {/* Payment Credentials (Stripe simulated) */}
              <div className="space-y-3 border-t border-navy/10 pt-4">
                <span className="block text-[10px] uppercase tracking-widest font-bold text-brass flex items-center gap-1">
                  <CreditCard className="w-3.5 h-3.5" />
                  3. Secure Stripe Credit Card
                </span>

                <div className="space-y-2">
                  <input
                    type="text"
                    maxLength={19}
                    placeholder="Card Number (4111 2222 3333 4444)"
                    value={cardNumber}
                    onChange={handleCardNumberChange}
                    className="w-full border border-navy/15 bg-white p-3 text-xs text-navy font-mono focus:outline-none focus:border-brass"
                    required
                  />
                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      maxLength={5}
                      placeholder="MM/YY"
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      className="w-full border border-navy/15 bg-white p-3 text-xs text-navy font-mono focus:outline-none focus:border-brass"
                      required
                    />
                    <input
                      type="password"
                      maxLength={3}
                      placeholder="CVC"
                      value={cvc}
                      onChange={(e) => setCvc(e.target.value)}
                      className="w-full border border-navy/15 bg-white p-3 text-xs text-navy font-mono focus:outline-none focus:border-brass"
                      required
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-brass hover:bg-navy text-white text-xs uppercase tracking-widest font-bold py-4 transition-all duration-300 shadow-md text-center mt-2"
              >
                Authorize Payment of ${total.toFixed(2)}
              </button>
            </form>
          ) : cart.length === 0 ? (
            /* EMPTY BASKET */
            <div className="text-center py-20 space-y-4">
              <ShoppingBag className="w-16 h-16 text-navy/10 mx-auto" />
              <div className="space-y-1">
                <h4 className="font-serif text-lg font-bold text-navy">Basket is Vacant</h4>
                <p className="font-sans text-xs text-slate-grey font-light max-w-xs mx-auto">
                  Browse our sourdough waffles or George Howell drip coffees and load items to begin.
                </p>
              </div>
            </div>
          ) : (
            /* BASKET REVIEW */
            <div className="space-y-4 my-2">
              <span className="block text-[10px] uppercase tracking-widest font-bold text-brass">Review Selected Items</span>
              <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2">
                {cart.map(item => (
                  <div key={item.id} className="bg-white border border-navy/10 p-4 flex gap-4 justify-between shadow-xs relative">
                    <img 
                      src={item.menuItem.image} 
                      alt={item.menuItem.name}
                      className="w-16 h-16 object-cover border border-navy/5 shrink-0"
                      referrerPolicy="no-referrer"
                    />

                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between items-start">
                        <h5 className="font-serif text-sm font-bold text-navy">{item.menuItem.name}</h5>
                        <strong className="font-serif text-xs text-navy">${(item.price * item.quantity).toFixed(2)}</strong>
                      </div>

                      {/* Customization specs detail list */}
                      {item.customization && (
                        <div className="space-y-0.5 text-[10px] text-slate-grey font-light">
                          <p>• Batter: <span className="font-semibold text-navy">{item.customization.batter}</span></p>
                          <p>• Glaze: <span className="font-semibold text-navy">{item.customization.syrup}</span></p>
                          {item.customization.extraToppings.length > 0 && (
                            <p>• Extras: <span className="font-semibold text-brass">{item.customization.extraToppings.join(', ')}</span></p>
                          )}
                        </div>
                      )}

                      {/* Quantity Editor */}
                      <div className="flex items-center justify-between pt-2">
                        <div className="flex items-center gap-2 border border-navy/10 bg-[#FAF9F6] p-0.5 text-xs font-semibold">
                          <button 
                            onClick={() => onUpdateQty(item.id, item.quantity - 1)}
                            className="p-1 hover:bg-navy/5"
                          >
                            <Trash2 className="w-3 h-3 text-red-500" />
                          </button>
                          <span className="font-serif w-6 text-center text-xs font-bold">{item.quantity}</span>
                          <button 
                            onClick={() => onUpdateQty(item.id, item.quantity + 1)}
                            className="p-1 hover:bg-navy/5 text-navy"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-[10px] text-red-500 hover:underline uppercase tracking-wider font-bold"
                        >
                          Remove Item
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Sticky Bill / Actions Footer */}
        {!activeOrder && cart.length > 0 && (
          <div className="p-6 border-t border-navy/10 bg-white space-y-4">
            {/* Invoice Table */}
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-slate-grey">
                <span>Basket Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-grey">
                <span>New England Sales Tax (8.25%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              {orderType === 'delivery' && (
                <div className="flex justify-between text-slate-grey">
                  <span>Courier Dispatched Handling Fee</span>
                  <span>$5.00</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-navy pt-2 border-t border-navy/5 mt-2">
                <span>Grand Total</span>
                <span className="font-serif text-lg font-bold text-navy">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Checkouts Actions */}
            {checkoutMode ? (
              <button
                onClick={() => setCheckoutMode(false)}
                className="w-full border border-navy/30 text-navy hover:text-brass hover:border-brass text-xs uppercase tracking-widest font-bold py-3 transition-colors duration-300 text-center block"
              >
                Return to Basket Review
              </button>
            ) : (
              <button
                onClick={() => setCheckoutMode(true)}
                className="w-full bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold py-4 transition-all duration-300 shadow-md text-center block"
              >
                Proceed to Secure Checkout
              </button>
            )}
          </div>
        )}
      </motion.div>
    </div>
  );
};
