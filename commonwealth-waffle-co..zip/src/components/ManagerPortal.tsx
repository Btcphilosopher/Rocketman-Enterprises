import React, { useState } from 'react';
import { MenuItem, Order, Reservation, LocationInfo } from '../types';
import { ShieldCheck, Plus, Trash2, Edit, Check, LayoutGrid, Calendar, FileBarChart, ShoppingCart, KeyRound, ArrowRight, DollarSign, Users, Award } from 'lucide-react';
import { motion } from 'motion/react';

interface ManagerPortalProps {
  menuItems: MenuItem[];
  orders: Order[];
  reservations: Reservation[];
  locations: LocationInfo[];
  onUpdateMenu: (newMenu: MenuItem[]) => void;
  onUpdateOrderStatus: (orderId: string, status: Order['status']) => void;
  onUpdateReservationStatus: (resId: string, status: Reservation['status']) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const ManagerPortal: React.FC<ManagerPortalProps> = ({
  menuItems,
  orders,
  reservations,
  locations,
  onUpdateMenu,
  onUpdateOrderStatus,
  onUpdateReservationStatus,
  isOpen,
  onClose
}) => {
  const [authorized, setAuthorized] = useState(false);
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState(false);
  const [activeTab, setActiveTab] = useState<'orders' | 'reservations' | 'menu' | 'analytics'>('orders');

  // Menu Creation States
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState('');
  const [newItemCat, setNewItemCat] = useState<MenuItem['category']>('Classic Waffles');
  const [newItemSubcat, setNewItemSubcat] = useState('Vermont Maple Collection');
  const [newItemDesc, setNewItemDesc] = useState('');
  const [newItemIngs, setNewItemIngs] = useState('');
  const [newItemImage, setNewItemImage] = useState('https://images.unsplash.com/photo-1562376502-6f769499c886?auto=format&fit=crop&w=800&q=80');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.toLowerCase() === 'commonwealth' || password === '') {
      setAuthorized(true);
      setLoginError(false);
    } else {
      setLoginError(true);
    }
  };

  const handleBypass = () => {
    setAuthorized(true);
    setLoginError(false);
  };

  const handleAddMenuItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName || !newItemPrice || !newItemDesc) {
      alert('Please fill out Name, Price, and Description.');
      return;
    }

    const priceNum = parseFloat(newItemPrice);
    if (isNaN(priceNum)) {
      alert('Price must be a valid number.');
      return;
    }

    const newItem: MenuItem = {
      id: 'custom-' + Date.now(),
      name: newItemName,
      price: priceNum,
      category: newItemCat,
      subcategory: newItemSubcat,
      description: newItemDesc,
      ingredients: newItemIngs.split(',').map(i => i.trim()).filter(Boolean),
      image: newItemImage || 'https://images.unsplash.com/photo-1562376502-6f769499c886?auto=format&fit=crop&w=800&q=80',
      signature: false
    };

    onUpdateMenu([...menuItems, newItem]);
    
    // Reset Form
    setNewItemName('');
    setNewItemPrice('');
    setNewItemDesc('');
    setNewItemIngs('');
    setShowAddForm(false);
    alert('Seasonal menu item published successfully!');
  };

  const handleDeleteItem = (id: string) => {
    if (confirm('Are you sure you want to remove this item from the active menu?')) {
      onUpdateMenu(menuItems.filter(item => item.id !== id));
    }
  };

  const handlePriceEdit = (id: string, currentPrice: number) => {
    const newPriceStr = prompt('Enter new retail price for this waffle:', currentPrice.toString());
    if (newPriceStr === null) return;
    const priceNum = parseFloat(newPriceStr);
    if (isNaN(priceNum)) {
      alert('Invalid price.');
      return;
    }
    
    onUpdateMenu(menuItems.map(item => {
      if (item.id === id) {
        return { ...item, price: priceNum };
      }
      return item;
    }));
  };

  if (!isOpen) return null;

  // Analytics Computation values
  const totalRevenue = orders
    .filter(o => o.status === 'Completed')
    .reduce((sum, o) => sum + o.total, 0) + 1240.00; // adding starting base

  const categorySales = {
    'Classic': 45,
    'Belgian': 32,
    'Savoury': 28,
    'Beverages': 54
  };

  return (
    <div className="fixed inset-0 bg-navy/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-[#FAF9F6] w-full max-w-5xl h-[85vh] border-4 border-white shadow-2xl flex flex-col overflow-hidden relative">
        {/* Header rail */}
        <div className="bg-navy text-white p-6 flex justify-between items-center shrink-0 border-b-2 border-brass">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full border border-brass flex items-center justify-center bg-navy text-brass">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="font-sans text-[10px] tracking-widest text-brass font-bold block uppercase">
                Staff Administration
              </span>
              <h3 className="font-serif text-xl font-bold">
                Commonwealth Manager Portal
              </h3>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 border border-white/20 hover:border-brass text-white hover:text-brass transition-all"
          >
            Close Portal
          </button>
        </div>

        {!authorized ? (
          /* PASSWORDS AUTH SCREEN */
          <div className="flex-1 flex flex-col items-center justify-center p-8 max-w-md mx-auto space-y-6">
            <div className="text-center space-y-2">
              <KeyRound className="w-12 h-12 text-brass mx-auto" />
              <h4 className="font-serif text-2xl font-bold text-navy">Enter Staff Credentials</h4>
              <p className="font-sans text-xs text-slate-grey font-light">
                This portal is reserved for New England store managers and head culinary baristas.
              </p>
            </div>

            <form onSubmit={handleLogin} className="w-full space-y-4">
              <div className="space-y-1">
                <label className="block text-[10px] uppercase tracking-widest font-bold text-brass">Portal Password</label>
                <input
                  type="password"
                  placeholder="Enter 'commonwealth' or press bypass"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full border border-navy/15 bg-white p-3 text-xs text-navy focus:outline-none focus:border-brass rounded-none text-center"
                />
              </div>

              {loginError && (
                <p className="text-[11px] text-red-500 font-bold text-center">
                  Incorrect credential code. Try 'commonwealth'.
                </p>
              )}

              <div className="flex gap-3">
                <button
                  type="submit"
                  className="flex-1 bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold py-3 transition-colors"
                >
                  Authorize
                </button>
                <button
                  type="button"
                  onClick={handleBypass}
                  className="flex-1 border border-navy/20 hover:border-brass text-navy hover:text-brass text-xs uppercase tracking-widest font-bold py-3 transition-colors"
                >
                  Quick Bypass
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* AUTHORIZED CMS WORKSPACE */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden bg-[#FAF9F6]">
            {/* Sidebar tabs navigation */}
            <div className="w-full md:w-64 bg-white border-r border-navy/10 flex flex-col justify-between shrink-0">
              <div className="p-4 space-y-1">
                <button
                  onClick={() => setActiveTab('orders')}
                  className={`w-full flex items-center gap-3 p-3 text-xs font-bold uppercase tracking-wider transition-all ${
                    activeTab === 'orders' ? 'bg-navy text-white border-l-4 border-brass' : 'text-navy/70 hover:bg-navy/5'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4 shrink-0" />
                  <span>Takeaway Orders ({orders.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('reservations')}
                  className={`w-full flex items-center gap-3 p-3 text-xs font-bold uppercase tracking-wider transition-all ${
                    activeTab === 'reservations' ? 'bg-navy text-white border-l-4 border-brass' : 'text-navy/70 hover:bg-navy/5'
                  }`}
                >
                  <Calendar className="w-4 h-4 shrink-0" />
                  <span>Table Bookings ({reservations.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('menu')}
                  className={`w-full flex items-center gap-3 p-3 text-xs font-bold uppercase tracking-wider transition-all ${
                    activeTab === 'menu' ? 'bg-navy text-white border-l-4 border-brass' : 'text-navy/70 hover:bg-navy/5'
                  }`}
                >
                  <LayoutGrid className="w-4 h-4 shrink-0" />
                  <span>Sourdough Menu ({menuItems.length})</span>
                </button>

                <button
                  onClick={() => setActiveTab('analytics')}
                  className={`w-full flex items-center gap-3 p-3 text-xs font-bold uppercase tracking-wider transition-all ${
                    activeTab === 'analytics' ? 'bg-navy text-white border-l-4 border-brass' : 'text-navy/70 hover:bg-navy/5'
                  }`}
                >
                  <FileBarChart className="w-4 h-4 shrink-0" />
                  <span>Sales & Reports</span>
                </button>
              </div>

              {/* Quick Summary stats widget */}
              <div className="p-6 border-t border-navy/5 bg-[#FAF9F6] text-xs space-y-4">
                <div>
                  <span className="block text-[9px] uppercase tracking-widest text-slate-grey font-bold">Total Sales Vault</span>
                  <strong className="block text-xl font-serif font-bold text-navy">${totalRevenue.toFixed(2)}</strong>
                </div>
                <div>
                  <span className="block text-[9px] uppercase tracking-widest text-slate-grey font-bold">Sourdough Rising</span>
                  <span className="text-[11px] text-forest-green font-bold flex items-center gap-1 mt-0.5">
                    ● Stable 24h Vault
                  </span>
                </div>
              </div>
            </div>

            {/* Scrollable Content Workspace area */}
            <div className="flex-1 p-6 overflow-y-auto">
              
              {/* --- TABS 1: ORDERS --- */}
              {activeTab === 'orders' && (
                <div className="space-y-6">
                  <div className="flex justify-between items-baseline border-b border-navy/10 pb-2">
                    <h4 className="font-serif text-xl font-bold text-navy">Takeaway & Courier Tickets</h4>
                    <span className="text-xs font-sans text-slate-grey">{orders.length} Active Tickets</span>
                  </div>

                  {orders.length === 0 ? (
                    <div className="text-center py-16 bg-white border border-navy/5 p-6">
                      <ShoppingCart className="w-12 h-12 text-navy/15 mx-auto mb-2" />
                      <p className="font-sans text-xs text-slate-grey">No customer online orders have been registered in this session.</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map(order => (
                        <div key={order.id} className="bg-white border border-navy/10 p-6 shadow-xs space-y-4">
                          <div className="flex justify-between items-start flex-wrap gap-2 pb-3 border-b border-navy/5">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="font-serif text-base font-bold text-navy">Order {order.id}</span>
                                <span className={`text-[9px] uppercase tracking-widest font-bold px-2 py-0.5 ${
                                  order.type === 'delivery' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                                }`}>
                                  {order.type}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-grey mt-0.5">Date: {order.date} • Scheduled Arrival: <strong>{order.scheduledTime}</strong></p>
                            </div>

                            {/* Dropdown status update changer */}
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] uppercase tracking-widest font-bold text-brass">Adjust Status:</span>
                              <select
                                value={order.status}
                                onChange={(e) => onUpdateOrderStatus(order.id, e.target.value as Order['status'])}
                                className="border border-navy/20 bg-[#FAF9F6] p-1.5 text-[10px] uppercase tracking-wider font-bold text-navy focus:outline-none"
                              >
                                <option value="Pending">1. Received / Pending</option>
                                <option value="Prepped">2. Preparing Waffles</option>
                                <option value="Out for Delivery">3a. Out for Delivery</option>
                                <option value="Ready for Pickup">3b. Ready for Pickup</option>
                                <option value="Completed">4. Completed</option>
                                <option value="Cancelled">X. Cancelled</option>
                              </select>
                            </div>
                          </div>

                          {/* Customer coordinates */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                            <div>
                              <strong className="block text-navy uppercase tracking-wider text-[9px]">Recipient</strong>
                              <p className="text-slate-grey">{order.customerName}</p>
                              <p className="text-slate-grey">{order.phone} • {order.email}</p>
                            </div>
                            <div className="sm:col-span-2">
                              <strong className="block text-navy uppercase tracking-wider text-[9px]">Location Coordinates</strong>
                              <p className="text-slate-grey">{order.deliveryAddress}</p>
                            </div>
                          </div>

                          {/* Items table */}
                          <div className="bg-[#FAF9F6] border border-navy/5 p-4 rounded-xs text-xs space-y-1">
                            {order.items.map((item, idx) => (
                              <div key={idx} className="flex justify-between font-semibold">
                                <span className="text-navy">{item.quantity}x {item.name} <span className="text-[10px] text-slate-grey font-normal">{item.customization}</span></span>
                                <span className="text-navy">${(item.price * item.quantity).toFixed(2)}</span>
                              </div>
                            ))}
                            <div className="flex justify-between font-bold text-navy border-t border-navy/5 pt-2 mt-2">
                              <span>Total Value</span>
                              <span>${order.total.toFixed(2)}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* --- TABS 2: RESERVATIONS --- */}
              {activeTab === 'reservations' && (
                <div className="space-y-6">
                  <div className="flex justify-between items-baseline border-b border-navy/10 pb-2">
                    <h4 className="font-serif text-xl font-bold text-navy">Dining Table Reservations</h4>
                    <span className="text-xs font-sans text-slate-grey">{reservations.length} Booked Tables</span>
                  </div>

                  {reservations.length === 0 ? (
                    <div className="text-center py-16 bg-white border border-navy/5 p-6">
                      <Calendar className="w-12 h-12 text-navy/15 mx-auto mb-2" />
                      <p className="font-sans text-xs text-slate-grey">No reservations scheduled for this session.</p>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {reservations.map(res => (
                        <div key={res.id} className="bg-white border border-navy/10 p-5 shadow-xs relative">
                          <div className="absolute top-4 right-4 flex items-center gap-1.5">
                            <span className={`text-[8px] uppercase tracking-widest font-bold px-2 py-0.5 rounded-xs ${
                              res.status === 'Confirmed' ? 'bg-forest-green/10 text-forest-green' : 'bg-red-100 text-red-700'
                            }`}>
                              {res.status}
                            </span>
                          </div>

                          <div className="space-y-3">
                            <div>
                              <span className="font-sans text-[9px] uppercase tracking-widest text-brass font-bold block">{res.locationName}</span>
                              <h5 className="font-serif text-base font-bold text-navy">{res.name}</h5>
                              <p className="text-[11px] text-slate-grey">{res.phone} • {res.email}</p>
                            </div>

                            <div className="border-t border-navy/5 pt-2 flex justify-between text-xs font-semibold text-navy">
                              <span>Date: {res.date}</span>
                              <span>Time: {res.time}</span>
                              <span>Guests: {res.guests}</span>
                            </div>

                            {res.notes && (
                              <p className="text-[10px] text-slate-grey italic bg-navy/5 p-2 leading-relaxed">
                                Notes: "{res.notes}"
                              </p>
                            )}

                            {/* Reservations status adjust toggles */}
                            <div className="pt-2 border-t border-navy/5 flex gap-2 justify-end">
                              <button
                                onClick={() => onUpdateReservationStatus(res.id, 'Seated')}
                                className="bg-forest-green/10 hover:bg-forest-green/20 text-forest-green text-[9px] uppercase tracking-widest font-bold px-3 py-1.5 transition-colors"
                              >
                                Mark Seated
                              </button>
                              <button
                                onClick={() => onUpdateReservationStatus(res.id, 'Cancelled')}
                                className="bg-red-50 hover:bg-red-100 text-red-500 text-[9px] uppercase tracking-widest font-bold px-3 py-1.5 transition-colors"
                              >
                                Cancel Table
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* --- TABS 3: MENU EDITOR --- */}
              {activeTab === 'menu' && (
                <div className="space-y-6">
                  <div className="flex justify-between items-center border-b border-navy/10 pb-2">
                    <h4 className="font-serif text-xl font-bold text-navy">Active Menu Inventory</h4>
                    <button
                      onClick={() => setShowAddForm(!showAddForm)}
                      className="bg-navy hover:bg-brass text-white text-[10px] uppercase tracking-widest font-bold px-4 py-2 transition-colors flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      Add Seasonal Item
                    </button>
                  </div>

                  {/* Add Product Form */}
                  {showAddForm && (
                    <form onSubmit={handleAddMenuItem} className="bg-white border-2 border-brass p-6 shadow-md space-y-4">
                      <span className="font-sans text-[10px] uppercase tracking-widest text-brass font-bold block mb-2">Publish New Seasonal Dish</span>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label htmlFor="waffleName" className="block text-xs font-bold text-navy">Item Name *</label>
                          <input
                            id="waffleName"
                            type="text"
                            placeholder="E.g., Spiced Gingerbread Waffle"
                            value={newItemName}
                            onChange={(e) => setNewItemName(e.target.value)}
                            className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                            required
                          />
                        </div>

                        <div className="space-y-1">
                          <label htmlFor="wafflePrice" className="block text-xs font-bold text-navy">Retail Price ($) *</label>
                          <input
                            id="wafflePrice"
                            type="text"
                            placeholder="15.50"
                            value={newItemPrice}
                            onChange={(e) => setNewItemPrice(e.target.value)}
                            className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                            required
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <label htmlFor="waffleCategory" className="block text-xs font-bold text-navy">Category *</label>
                          <select
                            id="waffleCategory"
                            value={newItemCat}
                            onChange={(e) => setNewItemCat(e.target.value as MenuItem['category'])}
                            className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                          >
                            <option value="Classic Waffles">Classic Waffles</option>
                            <option value="Belgian Waffles">Belgian Waffles</option>
                            <option value="Savoury Waffles">Savoury Waffles</option>
                            <option value="Breakfast">Breakfast</option>
                            <option value="Seasonal Specials">Seasonal Specials</option>
                            <option value="Drinks">Drinks</option>
                          </select>
                        </div>

                        <div className="space-y-1">
                          <label htmlFor="waffleSubcat" className="block text-xs font-bold text-navy">Subcategory (Collection) *</label>
                          <input
                            id="waffleSubcat"
                            type="text"
                            placeholder="E.g., Vermont Maple Collection"
                            value={newItemSubcat}
                            onChange={(e) => setNewItemSubcat(e.target.value)}
                            className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                            required
                          />
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label htmlFor="waffleImage" className="block text-xs font-bold text-navy">Photo URL</label>
                        <input
                          id="waffleImage"
                          type="url"
                          placeholder="https://images.unsplash.com/photo-..."
                          value={newItemImage}
                          onChange={(e) => setNewItemImage(e.target.value)}
                          className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                        />
                      </div>

                      <div className="space-y-1">
                        <label htmlFor="waffleIngredients" className="block text-xs font-bold text-navy">Ingredients (Comma separated)</label>
                        <input
                          id="waffleIngredients"
                          type="text"
                          placeholder="Molasses, Ground ginger, Whipped molasses butter, Toasted walnuts"
                          value={newItemIngs}
                          onChange={(e) => setNewItemIngs(e.target.value)}
                          className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                        />
                      </div>

                      <div className="space-y-1">
                        <label htmlFor="waffleDescription" className="block text-xs font-bold text-navy">Gourmet Description *</label>
                        <textarea
                          id="waffleDescription"
                          placeholder="A detailed narrative of flavors, local origins, and cooking details."
                          value={newItemDesc}
                          onChange={(e) => setNewItemDesc(e.target.value)}
                          rows={2}
                          className="w-full border border-navy/15 bg-white p-2 text-xs text-navy"
                          required
                        />
                      </div>

                      <div className="flex gap-2">
                        <button
                          type="submit"
                          className="bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold px-6 py-3 transition-colors"
                        >
                          Publish To Active Menu
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowAddForm(false)}
                          className="border border-navy/20 hover:border-brass text-navy text-xs uppercase tracking-widest font-bold px-6 py-3 transition-colors"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Products table list */}
                  <div className="space-y-2">
                    {menuItems.map(item => (
                      <div key={item.id} className="bg-white border border-navy/10 p-4 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <img 
                            src={item.image} 
                            alt={item.name}
                            className="w-12 h-12 object-cover border"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <span className="font-sans text-[8px] uppercase tracking-widest text-brass font-bold block">{item.category} • {item.subcategory}</span>
                            <h5 className="font-serif text-sm font-bold text-navy">{item.name}</h5>
                            <span className="font-serif text-xs font-semibold text-slate-grey">${item.price.toFixed(2)}</span>
                          </div>
                        </div>

                        <div className="flex gap-2 shrink-0">
                          <button
                            onClick={() => handlePriceEdit(item.id, item.price)}
                            className="p-2 border border-navy/10 text-navy hover:border-brass hover:text-brass transition-all"
                            title="Edit Price"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteItem(item.id)}
                            className="p-2 border border-red-100 text-red-500 hover:bg-red-50 hover:border-red-300 transition-colors"
                            title="Delete Item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* --- TABS 4: ANALYTICS VAULT --- */}
              {activeTab === 'analytics' && (
                <div className="space-y-8">
                  <div className="border-b border-navy/10 pb-2">
                    <h4 className="font-serif text-xl font-bold text-navy">Sales & Sourdough Performance Analytics</h4>
                  </div>

                  {/* Summary metric blocks */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-white border border-navy/10 p-6 shadow-xs">
                      <span className="block text-[9px] uppercase tracking-widest font-bold text-brass">Cumulative Revenue</span>
                      <strong className="block text-3xl font-serif text-navy mt-1">${totalRevenue.toFixed(2)}</strong>
                      <span className="text-[10px] text-forest-green block mt-1">↑ 14.2% Growth from June</span>
                    </div>

                    <div className="bg-white border border-navy/10 p-6 shadow-xs">
                      <span className="block text-[9px] uppercase tracking-widest font-bold text-brass">Table Covers Reserved</span>
                      <strong className="block text-3xl font-serif text-navy mt-1">{reservations.length + 84}</strong>
                      <span className="text-[10px] text-slate-grey block mt-1">Sourdough reservations seated</span>
                    </div>

                    <div className="bg-white border border-navy/10 p-6 shadow-xs">
                      <span className="block text-[9px] uppercase tracking-widest font-bold text-brass">Takeaway Orders Processed</span>
                      <strong className="block text-3xl font-serif text-navy mt-1">{orders.length + 412}</strong>
                      <span className="text-[10px] text-forest-green block mt-1">98.4% On-time courier delivery</span>
                    </div>
                  </div>

                  {/* Interactive Pure SVG & CSS Charts */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    
                    {/* Graph A: Category breakdown bar graphs */}
                    <div className="bg-white border border-navy/10 p-6 space-y-4">
                      <h5 className="font-serif text-sm font-bold text-navy border-b border-navy/5 pb-1 uppercase tracking-wider text-[10px]">
                        Category Popularity (%)
                      </h5>
                      
                      <div className="space-y-3 pt-2">
                        {Object.entries(categorySales).map(([cat, val]) => {
                          const totalPct = (val / 159) * 100;
                          return (
                            <div key={cat} className="space-y-1">
                              <div className="flex justify-between text-xs font-semibold text-navy">
                                <span>{cat} Collection</span>
                                <span>{Math.round(totalPct)}% ({val} items)</span>
                              </div>
                              <div className="w-full h-3 bg-navy/5 rounded-full overflow-hidden">
                                <div 
                                  className="h-full bg-brass transition-all duration-1000"
                                  style={{ width: `${totalPct}%` }}
                                ></div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Graph B: Daily Hour Distribution line graphs */}
                    <div className="bg-white border border-navy/10 p-6 space-y-4">
                      <h5 className="font-serif text-sm font-bold text-navy border-b border-navy/5 pb-1 uppercase tracking-wider text-[10px]">
                        Busy Hourly Covers (Rush index)
                      </h5>

                      {/* Visual pure CSS bar representation of hourly traffic */}
                      <div className="flex items-end justify-between h-40 pt-4 px-2">
                        {[
                          { hour: '7am', count: 32 },
                          { hour: '9am', count: 85 },
                          { hour: '11am', count: 64 },
                          { hour: '1pm', count: 42 },
                          { hour: '3pm', count: 25 },
                          { hour: '5pm', count: 55 },
                          { hour: '7pm', count: 90 },
                          { hour: '9pm', count: 40 },
                        ].map((item, index) => {
                          const scalePct = (item.count / 90) * 100;
                          return (
                            <div key={index} className="flex flex-col items-center flex-1 h-full justify-end group">
                              <div className="text-[9px] font-bold text-brass opacity-0 group-hover:opacity-100 mb-1 transition-opacity">
                                {item.count}
                              </div>
                              <div 
                                className="w-4 bg-navy hover:bg-brass transition-all duration-700 rounded-t-xs"
                                style={{ height: `${scalePct}%` }}
                              ></div>
                              <span className="text-[8px] uppercase tracking-wider font-bold text-slate-grey mt-2">
                                {item.hour}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
