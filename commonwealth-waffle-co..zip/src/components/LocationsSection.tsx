import React, { useState } from 'react';
import { LocationInfo } from '../types';
import { MapPin, Clock, Info, Navigation, Star, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';

interface LocationsSectionProps {
  locations: LocationInfo[];
  onReserveAtLocation: (location: LocationInfo) => void;
}

export const LocationsSection: React.FC<LocationsSectionProps> = ({
  locations,
  onReserveAtLocation
}) => {
  const [activeLocationId, setActiveLocationId] = useState<string>(locations[0]?.id || '');

  const activeLocation = locations.find(loc => loc.id === activeLocationId) || locations[0];

  // SVG coordinate mapping for the stylized New England map
  // Sizing of map is roughly 300x400
  const cityCoordinates: { [key: string]: { x: number; y: number } } = {
    'loc-boston': { x: 180, y: 250 },      // Boston
    'loc-cambridge': { x: 160, y: 240 },   // Cambridge is very close to Boston
    'loc-providence': { x: 165, y: 310 },  // Providence, RI
    'loc-portland': { x: 230, y: 140 },    // Portland, ME
    'loc-burlington': { x: 80, y: 110 }    // Burlington, VT
  };

  return (
    <div className="py-12 bg-[#FAF9F6] px-6 md:px-12 xl:px-16 min-h-screen">
      {/* Page Header */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="font-sans text-xs uppercase tracking-[0.25em] font-bold text-brass block mb-2">
          New England Markets
        </span>
        <h2 className="font-serif text-4xl md:text-5xl font-bold text-navy mb-4">
          The Flagship Houses
        </h2>
        <div className="w-16 h-0.5 bg-brass mx-auto mb-4"></div>
        <p className="font-sans text-sm md:text-base text-slate-grey font-light">
          Each location is architecturally unique, breathing contemporary life into traditional New England mills, storefronts, and libraries.
        </p>
      </div>

      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-12 items-start">
        {/* Left Column: Locations Navigation Cards */}
        <div className="w-full lg:w-5/12 space-y-4">
          <span className="font-sans text-[10px] uppercase tracking-widest font-bold text-navy/50 block mb-2">
            Select an House Location
          </span>
          {locations.map(loc => {
            const isActive = loc.id === activeLocationId;
            return (
              <button
                key={loc.id}
                onClick={() => setActiveLocationId(loc.id)}
                className={`w-full text-left p-6 border transition-all duration-300 flex items-start justify-between relative group ${
                  isActive
                    ? 'bg-navy text-white border-navy shadow-lg'
                    : 'bg-white text-navy border-navy/10 hover:border-brass/50 hover:shadow-md'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <span className={`font-sans text-[9px] uppercase tracking-wider font-bold px-2 py-0.5 ${
                      isActive ? 'bg-brass text-white' : 'bg-navy/5 text-brass border border-brass/20'
                    }`}>
                      {loc.city}
                    </span>
                    <span className="font-sans text-[10px] text-slate-grey font-light">
                      {loc.phone}
                    </span>
                  </div>
                  <h4 className="font-serif text-lg font-bold">
                    {loc.name}
                  </h4>
                  <p className={`font-sans text-xs leading-relaxed ${isActive ? 'text-white/80' : 'text-slate-grey'}`}>
                    {loc.address}
                  </p>
                </div>
                
                <div className="flex flex-col items-end justify-between h-full py-1 shrink-0 pl-4">
                  <span className={`text-[10px] uppercase tracking-widest font-bold ${isActive ? 'text-brass' : 'text-navy/40 group-hover:text-brass'}`}>
                    Details
                  </span>
                  <ArrowRight className={`w-4 h-4 mt-4 transition-transform ${
                    isActive ? 'text-brass translate-x-1' : 'text-navy/30 group-hover:translate-x-1 group-hover:text-brass'
                  }`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Middle Column: Stylized Visual Map */}
        <div className="w-full lg:w-3/12 flex flex-col items-center justify-center p-6 bg-white border border-navy/10 shadow-sm relative">
          <span className="font-sans text-[9px] uppercase tracking-[0.2em] text-brass font-bold mb-4">
            New England Geographic Cartography
          </span>
          
          <div className="w-full h-[360px] bg-[#FAF9F6] border border-navy/5 relative overflow-hidden select-none">
            {/* Stylized custom SVG map outline representation of New England states */}
            <svg 
              className="absolute inset-0 w-full h-full" 
              viewBox="0 0 300 400" 
              fill="none" 
              xmlns="http://www.w3.org/2000/svg"
            >
              {/* Soft grid overlay */}
              <defs>
                <pattern id="grid" width="30" height="30" patternUnits="userSpaceOnUse">
                  <path d="M 30 0 L 0 0 0 30" fill="none" stroke="rgba(10, 31, 48, 0.03)" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />

              {/* Minimalist Coastline Sketch */}
              <path 
                d="M100,380 C110,360 130,350 140,330 C150,310 160,320 170,290 C180,260 200,250 210,210 C220,170 240,150 250,110 C260,70 270,50 280,30" 
                stroke="rgba(197, 160, 89, 0.2)" 
                strokeWidth="2" 
                strokeDasharray="4 4" 
              />
              
              {/* Simplified State boundary labels */}
              <text x="30" y="80" fill="rgba(10,31,48,0.15)" className="font-serif text-[11px] italic font-bold">Vermont</text>
              <text x="210" y="80" fill="rgba(10,31,48,0.15)" className="font-serif text-[11px] italic font-bold">Maine</text>
              <text x="50" y="220" fill="rgba(10,31,48,0.15)" className="font-serif text-[11px] italic font-bold">Mass</text>
              <text x="80" y="340" fill="rgba(10,31,48,0.15)" className="font-serif text-[11px] italic font-bold">R.I.</text>

              {/* State boundary dotted vectors */}
              <path d="M120,40 L120,160 L180,160 M120,200 L190,200 L200,320" stroke="rgba(10,31,48,0.04)" strokeWidth="1" />
            </svg>

            {/* Render coordinates pins */}
            {locations.map(loc => {
              const coords = cityCoordinates[loc.id] || { x: 150, y: 200 };
              const isActive = loc.id === activeLocationId;
              
              return (
                <button
                  key={loc.id}
                  onClick={() => setActiveLocationId(loc.id)}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer z-20 group"
                  style={{ left: coords.x, top: coords.y }}
                >
                  <div className="relative flex items-center justify-center">
                    {/* Ring animation */}
                    {isActive && (
                      <span className="absolute inline-flex h-8 w-8 rounded-full bg-brass/30 animate-ping"></span>
                    )}
                    
                    {/* Pin element */}
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center border-2 shadow-md transition-all duration-300 ${
                      isActive 
                        ? 'bg-navy border-brass scale-125' 
                        : 'bg-white border-navy/40 group-hover:border-brass group-hover:scale-110'
                    }`}>
                      <MapPin className={`w-2.5 h-2.5 ${isActive ? 'text-brass' : 'text-navy'}`} />
                    </div>

                    {/* Pop label */}
                    <span className={`absolute top-6 font-sans text-[9px] uppercase tracking-widest font-bold whitespace-nowrap px-2 py-0.5 border ${
                      isActive 
                        ? 'bg-navy text-white border-brass opacity-100' 
                        : 'bg-white text-navy border-navy/10 opacity-70 group-hover:opacity-100 transition-opacity'
                    }`}>
                      {loc.city}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Column: Detailed Location Inspection Card */}
        {activeLocation && (
          <motion.div 
            key={activeLocation.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="w-full lg:w-4/12 bg-white border border-navy/10 p-8 flex flex-col justify-between shadow-lg relative min-h-[500px]"
          >
            {/* Corner styling */}
            <div className="absolute top-0 right-0 w-12 h-12 border-t-2 border-r-2 border-brass/30"></div>
            
            <div className="space-y-8">
              {/* Title & Banner Image */}
              <div className="space-y-3">
                <img 
                  src={activeLocation.image} 
                  alt={activeLocation.name}
                  className="w-full h-48 object-cover border border-navy/10 mb-4"
                  referrerPolicy="no-referrer"
                />
                <span className="font-sans text-[11px] uppercase tracking-[0.2em] text-brass font-bold block">
                  {activeLocation.city} Flagship
                </span>
                <h3 className="font-serif text-2xl font-bold text-navy">
                  {activeLocation.name}
                </h3>
                <p className="font-sans text-xs text-slate-grey font-light">
                  {activeLocation.address}
                </p>
              </div>

              {/* Key Hours */}
              <div className="grid grid-cols-2 gap-4 border-t border-b border-navy/10 py-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest font-bold text-brass">
                    <Clock className="w-3 h-3" />
                    <span>Weekdays</span>
                  </div>
                  <p className="font-sans text-xs text-navy font-semibold">
                    {activeLocation.hours.weekdays}
                  </p>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-widest font-bold text-brass">
                    <Clock className="w-3 h-3" />
                    <span>Weekends</span>
                  </div>
                  <p className="font-sans text-xs text-navy font-semibold">
                    {activeLocation.hours.weekends}
                  </p>
                </div>
              </div>

              {/* Accompanying information points */}
              <div className="space-y-4">
                {/* Architecture */}
                <div className="space-y-1">
                  <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-navy opacity-60">
                    Aesthetic Interiors
                  </span>
                  <p className="font-sans text-xs text-slate-grey font-light leading-relaxed">
                    {activeLocation.photography}
                  </p>
                </div>

                {/* Parking */}
                <div className="space-y-1">
                  <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-navy opacity-60">
                    Parking & Approach
                  </span>
                  <p className="font-sans text-xs text-slate-grey font-light leading-relaxed">
                    {activeLocation.parking}
                  </p>
                </div>

                {/* Accessibility */}
                <div className="space-y-1">
                  <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-navy opacity-60">
                    Accessibility Specs
                  </span>
                  <p className="font-sans text-xs text-slate-grey font-light leading-relaxed">
                    {activeLocation.accessibility}
                  </p>
                </div>

                {/* Directions */}
                <div className="space-y-1">
                  <span className="font-sans text-[9px] uppercase tracking-widest font-bold text-navy opacity-60 flex items-center gap-1">
                    <Navigation className="w-2.5 h-2.5" />
                    Getting Here
                  </span>
                  <p className="font-sans text-xs text-slate-grey font-light leading-relaxed">
                    {activeLocation.directions}
                  </p>
                </div>
              </div>
            </div>

            {/* Reserve Trigger */}
            <div className="pt-8 mt-8 border-t border-navy/5">
              <button
                onClick={() => onReserveAtLocation(activeLocation)}
                className="w-full bg-navy hover:bg-brass text-white text-xs uppercase tracking-widest font-bold py-4 transition-all duration-300 shadow-md text-center block"
              >
                Reserve a Table at {activeLocation.city}
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
