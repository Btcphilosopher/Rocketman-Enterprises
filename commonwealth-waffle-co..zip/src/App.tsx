import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HomeHero } from './components/HomeHero';
import { MenuSection } from './components/MenuSection';
import { LocationsSection } from './components/LocationsSection';
import { AboutSection } from './components/AboutSection';
import { ReservationsSection } from './components/ReservationsSection';
import { LoyaltySection } from './components/LoyaltySection';
import { OrderSection } from './components/OrderSection';
import { ManagerPortal } from './components/ManagerPortal';

import { INITIAL_MENU, INITIAL_LOCATIONS, SUPPLIERS } from './data';
import { MenuItem, CartItem, Order, Reservation, LoyaltyMember, LocationInfo, WaffleCustomization } from './types';
import { ArrowUpRight, Compass, ShieldCheck, Heart, Mail } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  // Views navigation
  const [currentView, setCurrentView] = useState<string>('home');

  // Modular state managers
  const [menuItems, setMenuItems] = useState<MenuItem[]>(INITIAL_MENU);
  const [locations] = useState<LocationInfo[]>(INITIAL_LOCATIONS);
  const [suppliers] = useState(SUPPLIERS);

  // Cart, Orders & checkout states
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [activeOrder, setActiveOrder] = useState<Order | null>(null);

  // Table reservation states
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [preselectedLocId, setPreselectedLocId] = useState<string>('');

  // Loyalty Program states
  const [loyaltyMember, setLoyaltyMember] = useState<LoyaltyMember | null>(null);

  // Modals & Panels toggle triggers
  const [cartOpen, setCartOpen] = useState(false);
  const [reservationsOpen, setReservationsOpen] = useState(false);
  const [loyaltyOpen, setLoyaltyOpen] = useState(false);
  const [cmsOpen, setCmsOpen] = useState(false);

  // Persistent mock variables to link orders to loyalty point upgrades
  const [ordersCount, setOrdersCount] = useState(0);
  const [totalSpent, setTotalSpent] = useState(0);

  // Sane scroll reset on view transitions
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  // Cart operations with precise configuration duplicate check
  const handleAddToCart = (item: MenuItem, quantity: number, customization?: WaffleCustomization) => {
    const isWaffle = item.category !== 'Drinks';
    
    // Create a deterministic hash/id for item + customization
    let cartInstanceId = item.id;
    let singleItemPrice = item.price;

    if (isWaffle && customization) {
      const batterAddon = customization.batter === 'Savory Cheddar Chive' ? 1.50 : customization.batter === 'Spiced Ginger' ? 1.00 : 0;
      const extraPrices: { [key: string]: number } = {
        'Devonshire Clotted Cream': 2.00,
        'Native Sweet Strawberries': 1.50,
        'Whipped Sea-Salt Butter': 1.00,
        'Roasted Massachusetts Apples': 1.50,
        'Applewood Smoked Bacon': 2.50,
        'Vanilla Bean Gelato': 2.00,
        'Flaky Maine Sea Salt': 0.50
      };
      const extrasCost = customization.extraToppings.reduce((sum, extra) => sum + (extraPrices[extra] || 0), 0);
      singleItemPrice = item.price + batterAddon + extrasCost;

      // Instance ID is item ID + custom selections stringified to avoid collision
      cartInstanceId = `${item.id}-${customization.batter}-${customization.syrup}-${customization.extraToppings.sort().join(',')}`;
    }

    setCart(prevCart => {
      const existingIdx = prevCart.findIndex(c => c.id === cartInstanceId);
      if (existingIdx > -1) {
        const updated = [...prevCart];
        updated[existingIdx].quantity += quantity;
        return updated;
      } else {
        return [
          ...prevCart,
          {
            id: cartInstanceId,
            menuItem: item,
            quantity,
            customization,
            price: singleItemPrice
          }
        ];
      }
    });

    setCartOpen(true);
  };

  const handleUpdateCartQty = (id: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(id);
      return;
    }
    setCart(prevCart => prevCart.map(item => item.id === id ? { ...item, quantity: newQty } : item));
  };

  const handleRemoveCartItem = (id: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== id));
  };

  // Checkout submit - registers order and prompts loyalty point accumulation
  const handleCheckout = (orderDetails: {
    customerName: string;
    email: string;
    phone: string;
    type: 'pickup' | 'delivery';
    deliveryAddress?: string;
    scheduledTime: string;
  }) => {
    const subtotal = cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    const tax = subtotal * 0.0825;
    const deliveryFee = orderDetails.type === 'delivery' ? 5.00 : 0.00;
    const orderTotal = subtotal + tax + deliveryFee;

    const newOrder: Order = {
      id: 'CWC-' + Math.floor(10000 + Math.random() * 90000),
      customerName: orderDetails.customerName,
      email: orderDetails.email,
      phone: orderDetails.phone,
      type: orderDetails.type,
      deliveryAddress: orderDetails.deliveryAddress,
      scheduledTime: orderDetails.scheduledTime,
      items: cart.map(c => ({
        name: c.menuItem.name,
        quantity: c.quantity,
        price: c.price,
        customization: c.customization 
          ? `(${c.customization.batter}, ${c.customization.syrup}, Toppings: ${c.customization.extraToppings.join(', ') || 'None'})` 
          : ''
      })),
      total: orderTotal,
      status: 'Pending',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    };

    // Add to orders archive and set active order tracking
    setOrders(prev => [newOrder, ...prev]);
    setActiveOrder(newOrder);
    
    // Accumulate metrics for loyalty club points
    setOrdersCount(prev => prev + 1);
    setTotalSpent(prev => prev + orderTotal);

    // Clear shopping cart
    setCart([]);
  };

  // Table reservation handlers
  const handleAddReservation = (resDetails: Omit<Reservation, 'id' | 'status'>) => {
    const newRes: Reservation = {
      ...resDetails,
      id: 'RES-' + Math.floor(100000 + Math.random() * 900000),
      status: 'Confirmed'
    };
    setReservations(prev => [newRes, ...prev]);
  };

  const handleCancelReservation = (id: string) => {
    if (confirm('Are you sure you want to cancel this reservation?')) {
      setReservations(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleReserveAtLocation = (loc: LocationInfo) => {
    setPreselectedLocId(loc.id);
    setReservationsOpen(true);
  };

  // Loyalty Register
  const handleRegisterMember = (name: string, email: string, phone: string) => {
    const newMember: LoyaltyMember = {
      name,
      email,
      phone,
      memberId: 'GW-' + Math.floor(10000 + Math.random() * 90000),
      points: 50, // 50 Welcome points!
      tier: 'Patron',
      joinedDate: new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })
    };
    setLoyaltyMember(newMember);
  };

  // CMS Webhook Updates - modifies states in real-time
  const handleUpdateMenu = (newMenu: MenuItem[]) => {
    setMenuItems(newMenu);
  };

  const handleUpdateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    if (activeOrder && activeOrder.id === orderId) {
      setActiveOrder(prev => prev ? { ...prev, status } : null);
    }
  };

  const handleUpdateReservationStatus = (resId: string, status: Reservation['status']) => {
    setReservations(prev => prev.map(r => r.id === resId ? { ...r, status } : r));
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] selection:bg-brass selection:text-white font-sans overflow-x-hidden antialiased text-navy">
      {/* Top Refined Announcement Bar */}
      <div className="bg-navy text-[#FAF9F6] text-[10px] md:text-xs py-2 px-6 flex flex-col sm:flex-row justify-between items-center gap-2 border-b border-brass/30 tracking-widest font-semibold uppercase">
        <span className="flex items-center gap-1">
          <span className="inline-block w-1.5 h-1.5 bg-brass rounded-full animate-ping"></span>
          Expanding Throughout New England — Now Open in Portland & Burlington
        </span>
        <span className="text-brass font-bold">
          Free Delivery for Commonwealth Club Members
        </span>
      </div>

      {/* Navigation Header */}
      <Navbar 
        cart={cart}
        currentView={currentView}
        setCurrentView={setCurrentView}
        onOpenCart={() => setCartOpen(true)}
        onOpenReservations={() => {
          setPreselectedLocId('');
          setReservationsOpen(true);
        }}
        onOpenLoyalty={() => setLoyaltyOpen(true)}
        onOpenCMS={() => setCmsOpen(true)}
        cmsActive={cmsOpen}
      />

      {/* Primary Section Canvas */}
      <main className="flex-1 flex flex-col">
        {currentView === 'home' && (
          <HomeHero 
            onViewMenu={() => setCurrentView('menu')}
            onFindCafe={() => setCurrentView('locations')}
            onBookTable={() => setReservationsOpen(true)}
          />
        )}

        {currentView === 'menu' && (
          <MenuSection 
            menuItems={menuItems}
            onAddToCart={handleAddToCart}
          />
        )}

        {currentView === 'locations' && (
          <LocationsSection 
            locations={locations}
            onReserveAtLocation={handleReserveAtLocation}
          />
        )}

        {currentView === 'suppliers' && (
          <AboutSection 
            suppliers={suppliers}
          />
        )}
      </main>

      {/* Elegant Editorial Footer */}
      <footer className="bg-navy text-white pt-16 pb-8 px-6 md:px-12 border-t-2 border-brass relative overflow-hidden shrink-0 mt-auto">
        <div className="absolute inset-0 opacity-10 mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/linen-paper.png')] pointer-events-none"></div>
        
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 border-b border-white/10 pb-12 mb-12">
          {/* Brand Col */}
          <div className="space-y-4">
            <div className="flex flex-col">
              <span className="font-serif text-2xl font-bold tracking-tight uppercase leading-none text-white">
                Commonwealth
              </span>
              <span className="font-sans text-[9px] tracking-[0.25em] font-semibold text-brass uppercase mt-1">
                Waffle Company
              </span>
            </div>
            <p className="font-sans text-xs text-white/60 font-light leading-relaxed">
              We weave British craftsmanship and culinary discipline with the bountiful regional harvests of New England.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h5 className="font-serif text-sm font-semibold text-brass uppercase tracking-wider text-[10px]">The Brand</h5>
            <ul className="space-y-2 text-xs text-white/70 font-light">
              <li><button onClick={() => setCurrentView('menu')} className="hover:text-brass transition-colors">Sourdough Menu</button></li>
              <li><button onClick={() => setCurrentView('locations')} className="hover:text-brass transition-colors">Our Houses</button></li>
              <li><button onClick={() => setCurrentView('suppliers')} className="hover:text-brass transition-colors">Suppliers & Farms</button></li>
              <li><button onClick={() => setLoyaltyOpen(true)} className="hover:text-brass transition-colors">The Loyalty Club</button></li>
            </ul>
          </div>

          {/* Locations List */}
          <div className="space-y-4">
            <h5 className="font-serif text-sm font-semibold text-brass uppercase tracking-wider text-[10px]">Active Houses</h5>
            <ul className="space-y-1.5 text-[11px] text-white/70 font-light">
              <li>Boston — Back Bay Flagship</li>
              <li>Cambridge — Harvard Square</li>
              <li>Providence — College Hill</li>
              <li>Portland — Old Port Wharf</li>
              <li>Burlington — Church Street</li>
            </ul>
          </div>

          {/* Newsletter signup */}
          <div className="space-y-4">
            <h5 className="font-serif text-sm font-semibold text-brass uppercase tracking-wider text-[10px]">The Sourdough Digest</h5>
            <p className="font-sans text-xs text-white/60 font-light leading-relaxed">
              Receive table availability reports, secret seasonal toppings, and regional farm journals.
            </p>
            <form onSubmit={(e) => { e.preventDefault(); alert('Subscribed to the Sourdough Digest!'); }} className="flex">
              <input 
                type="email" 
                placeholder="aristocrat@email.com" 
                className="bg-white/5 border border-white/10 p-2.5 text-xs text-white focus:outline-none focus:border-brass w-full"
                required
              />
              <button type="submit" className="bg-brass hover:bg-white hover:text-navy text-white p-2.5 transition-colors">
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>

        {/* Bottom Credits */}
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center text-[10px] text-white/50 font-semibold tracking-widest uppercase gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <span>© {new Date().getFullYear()} Commonwealth Waffle Co. All Rights Reserved.</span>
            <span className="block text-[8px] text-brass/70 mt-1 normal-case tracking-normal">An Anglo-Futurist Hospitality interpretation. Engineered with deep craft.</span>
          </div>

          <div className="flex gap-6">
            <button onClick={() => setCmsOpen(true)} className="hover:text-brass text-brass font-bold flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Staff Portal (CMS)
            </button>
            <span className="flex items-center gap-1">
              <Heart className="w-3 h-3 text-red-500 fill-red-500" />
              New England Hospitality
            </span>
          </div>
        </div>
      </footer>

      {/* --- SLIDEOVER DRAWERS & MODALS --- */}
      <AnimatePresence>
        {/* Reservation Sidebar Drawer */}
        {reservationsOpen && (
          <ReservationsSection 
            locations={locations}
            reservations={reservations}
            onAddReservation={handleAddReservation}
            onCancelReservation={handleCancelReservation}
            isOpen={reservationsOpen}
            onClose={() => setReservationsOpen(false)}
            preselectedLocationId={preselectedLocId}
          />
        )}

        {/* Loyalty Membership Sidebar Drawer */}
        {loyaltyOpen && (
          <LoyaltySection 
            member={loyaltyMember}
            onRegisterMember={handleRegisterMember}
            isOpen={loyaltyOpen}
            onClose={() => setLoyaltyOpen(false)}
            ordersCount={ordersCount}
            totalSpent={totalSpent}
          />
        )}

        {/* Cart Review & Checkout Sidebar Drawer */}
        {cartOpen && (
          <OrderSection 
            cart={cart}
            onUpdateQty={handleUpdateCartQty}
            onRemoveItem={handleRemoveCartItem}
            onCheckout={handleCheckout}
            activeOrder={activeOrder}
            locations={locations}
            isOpen={cartOpen}
            onClose={() => setCartOpen(false)}
          />
        )}

        {/* Administration CMS Modal Workspace */}
        {cmsOpen && (
          <ManagerPortal 
            menuItems={menuItems}
            orders={orders}
            reservations={reservations}
            locations={locations}
            onUpdateMenu={handleUpdateMenu}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onUpdateReservationStatus={handleUpdateReservationStatus}
            isOpen={cmsOpen}
            onClose={() => setCmsOpen(false)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
