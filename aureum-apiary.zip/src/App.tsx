/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Mail, ArrowRight, ShieldCheck, HelpCircle, Star, Sparkles, Navigation, Globe, Send, Check } from "lucide-react";
import { HoneyProduct, CartItem } from "./types";

// Import modular sub-components
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import FeaturedProducts from "./components/FeaturedProducts";
import LandscapeOrigins from "./components/LandscapeOrigins";
import TraceabilityScanner from "./components/TraceabilityScanner";
import SommelierQuiz from "./components/SommelierQuiz";
import SustainabilityTracker from "./components/SustainabilityTracker";
import JournalSection from "./components/JournalSection";
import CartDrawer from "./components/CartDrawer";

export default function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");

  // Newsletter Subscription state
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);

  // Aureum Syndicate cycle state (Subscription club)
  const [selectedCycle, setSelectedCycle] = useState("monthly");

  // Track scroll section entries to update active nav state
  useEffect(() => {
    const handleScroll = () => {
      const sections = ["hero", "shop", "origins", "traceability", "sommelier", "sustainability", "journal"];
      const scrollPos = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const handleAddToCart = (product: HoneyProduct) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prevCart, { product, quantity: 1 }];
    });
    // Trigger slide out open cart feedback
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const handleSubscribeNewsletter = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim()) {
      setNewsletterSubscribed(true);
      setTimeout(() => {
        setNewsletterEmail("");
      }, 3000);
    }
  };

  return (
    <div className="min-h-screen bg-[#FCFBF8] text-neutral-800 font-sans antialiased selection:bg-amber-100 selection:text-amber-900 pb-0">
      
      {/* 1. Global Navigation */}
      <Navbar
        cart={cart}
        onOpenCart={() => setIsCartOpen(true)}
        onNavigate={handleNavigate}
        activeSection={activeSection}
      />

      {/* 2. Primary Hero Banner */}
      <Hero onNavigate={handleNavigate} />

      {/* 3. Core Curated Catalog Section */}
      <FeaturedProducts onAddToCart={handleAddToCart} />

      {/* 4. Landscape Terroir & Beekeeping Stories */}
      <LandscapeOrigins />

      {/* 5. Interactive Batch Traceability Scanner */}
      <TraceabilityScanner />

      {/* 6. AI Sommelier Palate Matching Quiz */}
      <SommelierQuiz onAddToCart={handleAddToCart} />

      {/* 7. Audited Ecological Sustainability metrics */}
      <SustainabilityTracker />

      {/* 8. Lifestyle Chronicle Magazine */}
      <JournalSection />

      {/* 9. THE AUREUM SYNDICATE: Subscription Club Section */}
      <section className="py-24 bg-[#FCFBF8] border-t border-neutral-100 px-4 md:px-8 max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          <div className="lg:col-span-5 text-left">
            <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-amber-600 uppercase">
              Exclusive Allocation
            </span>
            <h3 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-3 mb-6">
              The Aureum <br />
              <span className="font-serif italic font-normal text-amber-500">Syndicate.</span>
            </h3>
            <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed mb-6">
              A limited-allocation reservation program delivering direct seasonal honey extracts. Secure your annually guaranteed allotment of our active apiary honeys, pre-filtered and hand-numbered directly from our English oak vaults.
            </p>

            <ul className="space-y-3 text-xs font-sans text-neutral-600 mb-8">
              <li className="flex items-center gap-3">
                <Check size={14} className="text-amber-500" /> Guaranteed allocation of our rarest Seasonal Solstices.
              </li>
              <li className="flex items-center gap-3">
                <Check size={14} className="text-amber-500" /> Direct access to IoT hive colony audio feeds.
              </li>
              <li className="flex items-center gap-3">
                <Check size={14} className="text-amber-500" /> Complimentary carbon-neutral express courier.
              </li>
            </ul>
          </div>

          <div className="lg:col-span-7 bg-white border border-neutral-100 rounded-[2.5rem] p-8 md:p-10 shadow-sm text-left">
            <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-6">
              Select Subscription Cycle
            </span>

            {/* Cycle Selectors */}
            <div className="grid grid-cols-3 gap-3 mb-8">
              {[
                { id: "monthly", label: "Monthly Extract", price: "£28" },
                { id: "seasonal", label: "Equinox (Quarterly)", price: "£79" },
                { id: "annual", label: "Solstice (Annual)", price: "£280" }
              ].map((cycle) => (
                <button
                  key={cycle.id}
                  onClick={() => setSelectedCycle(cycle.id)}
                  className={`p-4 rounded-2xl border text-left transition-all focus:outline-none ${
                    selectedCycle === cycle.id
                      ? "bg-amber-500/10 border-amber-500 shadow-md"
                      : "bg-transparent border-neutral-150 hover:bg-[#FCFBF8]"
                  }`}
                  id={`cycle-${cycle.id}`}
                >
                  <span className="block text-[10px] font-sans text-neutral-400 uppercase tracking-wider mb-2">
                    {cycle.label}
                  </span>
                  <span className="block text-lg font-sans font-medium text-neutral-800">
                    {cycle.price}
                  </span>
                </button>
              ))}
            </div>

            {/* Dynamic Details based on cycle */}
            <div className="bg-[#FCFBF8] border border-neutral-100 p-5 rounded-2xl mb-8 text-xs font-sans text-neutral-500 leading-relaxed">
              {selectedCycle === "monthly" && (
                <p><strong>Monthly Allocation:</strong> Enjoy one hand-numbered signature jar matching the current floral blooming index delivered to your door. Fully customizable flavor matching.</p>
              )}
              {selectedCycle === "seasonal" && (
                <p><strong>Quarterly Allocation:</strong> Centered around the Equinoxes and Solstices, receive three curate-grade jars encapsulating Yorkshire Moor Heather, Cotswold Acacia, and organic forest honeydews.</p>
              )}
              {selectedCycle === "annual" && (
                <p><strong>Annual Vault Allocation:</strong> Twelve signature harvests + one bottle of our extremely limited-reserve Royal Oak forest honeydew housed inside an engraved, serial-numbered British wood showcase vault.</p>
              )}
            </div>

            <button
              onClick={() => alert("Thank you for your interest in the Aureum Syndicate. Memberships are currently closed as we audit colony capacities for 2045. Sign up for our chronicle newsletter below to join the priority reservation list.")}
              className="w-full py-4 bg-neutral-900 text-neutral-50 text-xs font-sans tracking-widest uppercase font-semibold rounded-full hover:bg-neutral-800 transition-all shadow-md flex items-center justify-center gap-2"
              id="join-syndicate-btn"
            >
              <span>Join priority syndicate list</span>
              <ArrowRight size={14} />
            </button>
          </div>

        </div>
      </section>

      {/* 10. VERIFIED REVIEWS & TESTIMONIALS */}
      <section className="py-24 bg-white border-t border-neutral-100 px-4 md:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-amber-600 uppercase">
            Customer Devotion
          </span>
          <h3 className="text-3xl font-sans tracking-tight text-neutral-800 font-light mt-3 mb-4">
            Voices of Aureum
          </h3>
          <p className="text-xs font-sans text-neutral-500 leading-relaxed">
            Our luxury nectars are enjoyed by certified culinary sommeliers, eco-preservationists, and connoisseurs across the British Isles.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left" id="reviews-grid">
          {[
            {
              quote: "The Cotswold Acacia honey is water-clear, glassy, and absolutely elegant. It carries an incredibly light pear blossom finish that never overpowers my white peony teas. Breathtaking industrial glass bottle design.",
              author: "Lady Arabella Finch",
              location: "Bath, Somerset",
              match: "Acacia Honey",
              rating: 5
            },
            {
              quote: "I am thoroughly fascinated by their blockchain traceability ledger. I entered batch WS-2045-A and could verify the exact hive coordinate map. Aureum matches high technology with beautiful local apiculture.",
              author: "Professor James Henderson",
              location: "Oxfordshire",
              match: "Wildflower Honey",
              rating: 5
            },
            {
              quote: "Our dining guests are continually charmed by the deep, rich molasses complexity of the Limited Oak Reserve. The presentation case makes it double as an organic perfume-style masterpiece.",
              author: "Chef Michel Roux Jr. (Advisory)",
              location: "London Office",
              match: "Limited Reserve (Oak)",
              rating: 5
            }
          ].map((rev, idx) => (
            <div
              key={idx}
              className="p-8 bg-[#FCFBF8] border border-neutral-100 rounded-3xl flex flex-col justify-between shadow-sm hover:shadow-md transition-shadow"
              id={`review-card-${idx}`}
            >
              <div>
                <div className="flex items-center gap-1 text-amber-500 mb-6">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} size={13} fill="currentColor" />
                  ))}
                </div>
                <blockquote className="text-sm font-sans text-neutral-600 leading-relaxed tracking-wide italic mb-6">
                  "{rev.quote}"
                </blockquote>
              </div>
              <div className="flex justify-between items-end border-t border-neutral-100 pt-4 mt-4">
                <div>
                  <span className="block text-xs font-sans font-semibold text-neutral-800 leading-none mb-1">
                    {rev.author}
                  </span>
                  <span className="block text-[9px] font-sans text-neutral-400 mt-0.5 uppercase tracking-wider">
                    {rev.location}
                  </span>
                </div>
                <span className="px-2.5 py-1 bg-amber-500/5 text-amber-700 text-[8px] font-sans font-semibold uppercase tracking-wider rounded-full border border-amber-500/10">
                  Matched: {rev.match}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 11. NEWSLETTER SUBSCRIPTION BLOCK */}
      <section className="py-24 bg-[#FCFBF8] border-t border-neutral-100 relative overflow-hidden text-center">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,rgba(245,158,11,0.02)_0%,transparent_70%)] pointer-events-none" />
        <div className="max-w-xl mx-auto px-4 relative z-10">
          <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-amber-600 uppercase flex items-center justify-center gap-1.5 mb-2">
            <Mail size={12} /> The Botanical Newsletter
          </span>
          <h3 className="text-3xl font-sans tracking-tight text-neutral-800 font-light mt-1 mb-4">
            Join the Aureum Chronicle
          </h3>
          <p className="text-xs font-sans text-neutral-500 leading-relaxed max-w-sm mx-auto mb-8">
            Receive early access announcements regarding our upcoming honey harvests, limited edition presentation reserves, and sustainable agriculture field reports.
          </p>

          <form onSubmit={handleSubscribeNewsletter} className="max-w-md mx-auto relative flex items-center">
            <input
              type="email"
              placeholder="Enter email for chronicles..."
              value={newsletterEmail}
              onChange={(e) => setNewsletterEmail(e.target.value)}
              className="w-full bg-white border border-neutral-200 rounded-full py-4 px-6 text-xs font-sans tracking-wider focus:outline-none focus:border-amber-500 shadow-sm"
              required
              id="newsletter-email-input"
            />
            <button
              type="submit"
              className="absolute right-2 top-2 bottom-2 px-6 bg-neutral-900 hover:bg-neutral-800 text-neutral-50 rounded-full text-[9px] font-sans tracking-widest uppercase font-semibold transition-all flex items-center gap-1.5 focus:outline-none"
              id="newsletter-submit-btn"
            >
              {newsletterSubscribed ? (
                <>
                  <Check size={10} />
                  <span>Subscribed</span>
                </>
              ) : (
                <>
                  <span>Subscribe</span>
                  <Send size={10} />
                </>
              )}
            </button>
          </form>
        </div>
      </section>

      {/* 12. EDITORIAL MAP SITE FOOTER */}
      <footer className="bg-neutral-900 text-neutral-400 py-16 px-4 md:px-8 border-t border-neutral-800 text-left">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-5 gap-8 mb-12">
          
          <div className="col-span-2 space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-amber-500/15 border border-amber-500/30 flex items-center justify-center">
                <span className="text-amber-400 font-bold text-xs tracking-widest font-sans">AU</span>
              </div>
              <div>
                <span className="block font-sans font-medium text-xs tracking-[0.25em] text-neutral-50 uppercase leading-none">
                  AUREUM APIARY
                </span>
                <span className="block text-[8px] font-sans text-neutral-500 tracking-[0.15em] uppercase mt-0.5">
                  Pure • British • Timeless
                </span>
              </div>
            </div>
            <p className="text-xs font-sans text-neutral-500 leading-relaxed max-w-xs">
              A luxury British honey house dedicated to regenerating English wildflower biodiversity through stateful non-invasive sensor technology and organic agricultural cooperatives.
            </p>
          </div>

          <div>
            <h5 className="text-[10px] font-sans font-bold text-neutral-300 uppercase tracking-widest mb-4">
              Botanical Catalog
            </h5>
            <ul className="space-y-2 text-xs font-sans text-neutral-500">
              <li><button onClick={() => handleNavigate("shop")} className="hover:text-neutral-200 transition-colors">Somerset Wildflower</button></li>
              <li><button onClick={() => handleNavigate("shop")} className="hover:text-neutral-200 transition-colors">Cotswold Acacia</button></li>
              <li><button onClick={() => handleNavigate("shop")} className="hover:text-neutral-200 transition-colors">Yorkshire Moor Heather</button></li>
              <li><button onClick={() => handleNavigate("shop")} className="hover:text-neutral-200 transition-colors">Limited Royal Reserve</button></li>
            </ul>
          </div>

          <div>
            <h5 className="text-[10px] font-sans font-bold text-neutral-300 uppercase tracking-widest mb-4">
              Precision Core
            </h5>
            <ul className="space-y-2 text-xs font-sans text-neutral-500">
              <li><button onClick={() => handleNavigate("origins")} className="hover:text-neutral-200 transition-colors">Regional Terroir</button></li>
              <li><button onClick={() => handleNavigate("traceability")} className="hover:text-neutral-200 transition-colors">Trace Your Jar</button></li>
              <li><button onClick={() => handleNavigate("sommelier")} className="hover:text-neutral-200 transition-colors">AI flavor sommelier</button></li>
              <li><button onClick={() => handleNavigate("sustainability")} className="hover:text-neutral-200 transition-colors">Regenerative Ledger</button></li>
            </ul>
          </div>

          <div>
            <h5 className="text-[10px] font-sans font-bold text-neutral-300 uppercase tracking-widest mb-4">
              House Address
            </h5>
            <p className="text-xs font-sans text-neutral-500 leading-relaxed">
              Aureum House Office, <br />
              Belgravia Mews, <br />
              London, SW1X 8AA <br />
              United Kingdom
            </p>
          </div>

        </div>

        <div className="max-w-7xl mx-auto pt-8 border-t border-neutral-800 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-sans text-neutral-600">
          <p>© 2045 Aureum Apiary Ltd. All rights reserved. Registered DEFRA apiculture license 48a-S.</p>
          <div className="flex gap-6">
            <span className="hover:text-neutral-500 cursor-pointer">Terms of Allocation</span>
            <span className="hover:text-neutral-500 cursor-pointer">Privacy Matrix</span>
            <span className="hover:text-neutral-500 cursor-pointer">IoT sensor disclosures</span>
          </div>
        </div>
      </footer>

      {/* 13. Shopping Bag Drawer (Slideout component) */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

    </div>
  );
}
