import { HoneyProduct, JournalEntry, BeekeeperProfile } from "./types";

export const HONEY_PRODUCTS: HoneyProduct[] = [
  {
    id: "wildflower",
    name: "Wildflower Honey",
    origin: "Somerset Meadows, England",
    description: "An elegant wildflower meadow harvest. Balanced, smooth, and classic with natural clover sweetness.",
    longDescription: "Harvested from our precision hives in the heart of Somerset, our Wildflower Honey is a celebration of classic British nature. Over sixty wildflower species—including chamomile, clover, and lavender—contribute to this beautifully complex yet approachable nectar. Each jar represents a snapshot of early summer pasture health, with low-intervention cold extraction keeping the delicate floral enzymes fully active.",
    price: 32,
    image: "/src/assets/images/wildflower_honey_card_1784888934506.jpg",
    rating: 4.9,
    reviewsCount: 124,
    floralNotes: ["Clover", "Lavender", "Chamomile"],
    colorIntensity: 2,
    batchNo: "WS-2045-A",
    hiveCoordinates: "51.1789° N, 2.6322° W",
    elevation: "84m",
    harvestDate: "June 2045",
    floralComposition: [
      { species: "Trifolium repens (White Clover)", percentage: 48 },
      { species: "Chamaemelum nobile (Chamomile)", percentage: 32 },
      { species: "Lavandula angustifolia (Lavender)", percentage: 20 }
    ],
    beekeeperName: "Dr. Arthur Stone",
    inStock: true
  },
  {
    id: "acacia",
    name: "Acacia Honey",
    origin: "Cotswold Valleys, England",
    description: "An ultra-delicate, glassy and pale honey with low acidity and subtle notes of vanilla.",
    longDescription: "Grown in the sunny slopes of the Cotswold valleys, our Acacia Honey represents the peak of light, minimalist honey profiling. Drawn from ancient white-blossomed acacia groves, it remains perfectly fluid, water-clear, and low in acid. It carries a whisper of vanilla, fresh pear, and sweet summer rain, making it the perfect refined addition to premium white teas or high-end baking.",
    price: 35,
    image: "/src/assets/images/acacia_honey_card_1784888966469.jpg",
    rating: 4.8,
    reviewsCount: 96,
    floralNotes: ["Vanilla", "Pear Blossom", "White Acacia"],
    colorIntensity: 1,
    batchNo: "AC-2045-B",
    hiveCoordinates: "51.8972° N, 1.7218° W",
    elevation: "112m",
    harvestDate: "May 2045",
    floralComposition: [
      { species: "Robinia pseudoacacia (Black Locust)", percentage: 82 },
      { species: "Prunus spinosa (Blackthorn)", percentage: 12 },
      { species: "Crataegus monogyna (Hawthorn)", percentage: 6 }
    ],
    beekeeperName: "Eleanor Vance",
    inStock: true
  },
  {
    id: "heather",
    name: "Heather Honey",
    origin: "Yorkshire Moors, England",
    description: "A dark, robust, amber-caramel honey. Deeply rich, complex, and aromatic with a peaty warmth.",
    longDescription: "Harvested during the late August purple bloom on the Yorkshire Moors, our Heather Honey is thixotropic—a rare, jelly-like luxury. Highly aromatic with notes of dark caramel, peat, and a gentle bitter-sweet malt, this honey is curated for connoisseurs who appreciate the wild, untamed elements of northern British highlands. It pair exquisitely with vintage cheddars and strong single-malt whiskies.",
    price: 38,
    image: "/src/assets/images/wildflower_honey_card_1784888934506.jpg", // Represent dark amber beautifully via design tint
    rating: 5.0,
    reviewsCount: 88,
    floralNotes: ["Yorkshire Heather", "Toffee-Caramel", "Peat Wood"],
    colorIntensity: 4,
    batchNo: "HM-2045-C",
    hiveCoordinates: "54.3411° N, 0.9254° W",
    elevation: "245m",
    harvestDate: "August 2045",
    floralComposition: [
      { species: "Calluna vulgaris (Ling Heather)", percentage: 76 },
      { species: "Erica tetralix (Cross-leaved Heath)", percentage: 18 },
      { species: "Vaccinium myrtillus (Bilberry)", percentage: 6 }
    ],
    beekeeperName: "Hamish Macleod",
    inStock: true,
    status: "Best Seller"
  },
  {
    id: "lime",
    name: "Lime Blossom Honey",
    origin: "Shropshire Woods, England",
    description: "A fresh, cooling green-gold honey with a distinctive lime-leaf and minty-fresh finish.",
    longDescription: "Harvested from ancient linden and lime tree canopies in Shropshire, this honey is a revelation of refreshing herbal flavor. The pale green-gold nectar is highly active, carrying natural minty-fresh cooling properties. Notes of citrus peel, sweet herbal grass, and a crisp, clean finish make this a magnificent honey for green teas, yogurt parfaits, or a refreshing tonic on a bright morning.",
    price: 34,
    image: "/src/assets/images/acacia_honey_card_1784888966469.jpg",
    rating: 4.7,
    reviewsCount: 61,
    floralNotes: ["Citrus Peel", "Mint Leaves", "Linden Wood"],
    colorIntensity: 2,
    batchNo: "LB-2045-D",
    hiveCoordinates: "52.7071° N, 2.7543° W",
    elevation: "98m",
    harvestDate: "July 2045",
    floralComposition: [
      { species: "Tilia cordata (Small-leaved Lime)", percentage: 72 },
      { species: "Tilia platyphyllos (Large-leaved Lime)", percentage: 22 },
      { species: "Acer pseudoplatanus (Sycamore)", percentage: 6 }
    ],
    beekeeperName: "Clara Finch",
    inStock: true
  },
  {
    id: "limited-reserve",
    name: "Limited Reserve (Oak Forest)",
    origin: "Royal Windsor Forest, England",
    description: "Deep, intense, and dark oak honeydew. Extremely rich with notes of malt and dark chocolate.",
    longDescription: "An ultra-rare, collector-grade forest honeydew. Rather than floral nectar, this intense syrup is harvested during high-summer from ancient English oaks in Berkshire. It is extremely high in mineral content, boasting a thick, dark profile resembling roasted molasses, rich malt, and cocoa nibs. Produced in limited quantities of only 250 jars, each individually numbered, signed, and packaged in a custom brass-jointed presentation box.",
    price: 120,
    image: "/src/assets/images/limited_reserve_card_1784888949709.jpg",
    rating: 5.0,
    reviewsCount: 42,
    floralNotes: ["Malt Molasses", "Dark Chocolate", "Ancient Oak Wood"],
    colorIntensity: 5,
    batchNo: "LR-2045-R",
    hiveCoordinates: "51.4812° N, 0.6052° W",
    elevation: "65m",
    harvestDate: "September 2045",
    floralComposition: [
      { species: "Quercus robur (English Oak Honeydew)", percentage: 90 },
      { species: "Castanea sativa (Sweet Chestnut)", percentage: 10 }
    ],
    beekeeperName: "Dr. Arthur Stone",
    inStock: true,
    status: "Limited Reserve"
  },
  {
    id: "seasonal-summer",
    name: "Summer Solstice Seasonal",
    origin: "Kentish Fruit Orchards, England",
    description: "A bright, highly fragrant honey with wild orchard strawberry, clover and warm peach notes.",
    longDescription: "A seasonal triumph celebrating the high peak of British summer. Harvested at the solstice from our apiaries nestled inside Kent's regenerative cherry and peach orchards, this honey bursts with natural summery energy. Notes of wild orchard strawberries, peach skin, and early summer rose hips form a sweet, high-contrast experience that perfectly captures the golden sunshine of the Garden of England.",
    price: 45,
    image: "/src/assets/images/wildflower_honey_card_1784888934506.jpg",
    rating: 4.9,
    reviewsCount: 35,
    floralNotes: ["Strawberry Blossom", "Sunlit Peach", "Wild Rose Hip"],
    colorIntensity: 3,
    batchNo: "SS-2045-S",
    hiveCoordinates: "51.2787° N, 0.5218° E",
    elevation: "70m",
    harvestDate: "June 2045",
    floralComposition: [
      { species: "Fragaria ananassa (Strawberry Blossom)", percentage: 52 },
      { species: "Prunus persica (Peach Orchard)", percentage: 28 },
      { species: "Rosa canina (Wild Dog Rose)", percentage: 20 }
    ],
    beekeeperName: "Oliver West",
    inStock: true,
    status: "Seasonal"
  }
];

export const BEEKEEPERS: BeekeeperProfile[] = [
  {
    name: "Dr. Arthur Stone",
    location: "Somerset Apiary Hub",
    experience: "18 Years in Precision Agriculture",
    quote: "Agriculture isn't about fighting nature; it's about listening to it. By using low-impact acoustics inside our hives, we check hive health without opening them—keeping the bees completely relaxed.",
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=600"
  },
  {
    name: "Eleanor Vance",
    location: "Cotswold Wildwood",
    experience: "12 Years in Floral Conservation",
    quote: "The Cotswolds offer an incredible biological canvas. We help local farmers transition to regenerative meadows, ensuring our bees access diverse and chemical-free forage throughout the season.",
    image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=600"
  },
  {
    name: "Hamish Macleod",
    location: "Yorkshire Moors Edge",
    experience: "25 Years in Moorland Apiculture",
    quote: "Heather honey is Britain's wild gold. It requires rugged, sturdy hives and an intimate knowledge of the moorland winds. There's no other flavor in the world that carries this much character.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=600"
  }
];

export const JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: "j-1",
    title: "Precision Apiculture: Inside the 2045 Hive",
    category: "Technology",
    readTime: "5 min read",
    date: "July 12, 2045",
    excerpt: "Discover how minimal-invasive sensor grids and neural-acoustic mapping allow us to monitor hive health and queen longevity without ever disturbing our colonies.",
    image: "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&q=80&w=600",
    content: "Our hypermodern apiaries are equipped with subtle, non-intrusive sensor layers that analyze humidity, temperature, and high-frequency audio signatures. By tracking the exact frequency of the hive's collective hum, our machine learning models can detect stressors, food shortages, or swarming instincts several days before they manifest physically. This ensures we preserve colony integrity, allowing our bees to thrive in a stress-free environment, resulting in pure, chemical-free honey of outstanding grade."
  },
  {
    id: "j-2",
    title: "Regenerative Farming & The British Honey Renaissance",
    category: "Sustainability",
    readTime: "4 min read",
    date: "June 28, 2045",
    excerpt: "How partnering with organic estates across Somerset is planting thousands of acres of ancient British flora, reversing decades of biodiversity loss.",
    image: "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?auto=format&fit=crop&q=80&w=600",
    content: "At Aureum, we believe luxury food must regenerate the earth rather than deplete it. We actively subsidize local British farmers to convert traditional monoculture crops into vibrant multi-species meadow pasture. By sowing heirloom clover, chamomile, wild sage, and borage, we are not only designing a richer flavor profile for our honey but also providing critical nesting sanctuaries for hundreds of species of solitary bees, butterflies, and wild birds."
  },
  {
    id: "j-3",
    title: "Culinary Pairings: A Study in Glass and Gold",
    category: "Gastronomy",
    readTime: "6 min read",
    date: "May 18, 2045",
    excerpt: "The master sommelier's guide to pairing Heather, Acacia, and Oak Reserve honeys with regional British farmhouse cheeses and sourdoughs.",
    image: "https://images.unsplash.com/photo-1486427944299-d1955d23e317?auto=format&fit=crop&q=80&w=600",
    content: "Honey is much like fine wine; it carries the exact terroir, mineral chemistry, and weather of the week it was gathered. This journal explores how our robust Yorkshire Heather Honey cuts through the heavy salt and creamy richness of organic blue stiltons, while Cotswold Acacia Honey highlights the sweet, delicate yeast of fresh sourdough. Elevate your sensory dining experiences with these simple, precision-guided matching techniques."
  }
];

export const QUIZ_QUESTIONS = [
  {
    id: "taste",
    question: "Which flavor notes resonate most with your sensory palate?",
    options: [
      { value: "delicate-vanilla", label: "Delicate Vanilla & Pear", desc: "Clear, clean, very mild sweetness" },
      { value: "classic-floral", label: "Classic Chamomile & Lavender", desc: "Warm, smooth, balanced meadows" },
      { value: "bright-citrus", label: "Refreshing Citrus & Peppermint", desc: "Vibrant, green-gold cooling tones" },
      { value: "bold-caramel", label: "Dark Toffee, Peat & Malt", desc: "Rich, intense, bitter-sweet complexity" }
    ]
  },
  {
    id: "sweetness",
    question: "What level of sweet intensity do you prefer?",
    options: [
      { value: "light", label: "Whisper Sweet", desc: "Low-impact sweetness, perfectly fluid" },
      { value: "balanced", label: "Medium Balanced", desc: "The perfect classic honey texture and bite" },
      { value: "intense", label: "Deep & Malty", desc: "Heavy molasses-style rich sweetness" }
    ]
  },
  {
    id: "usage",
    question: "How do you envision enjoying your honey?",
    options: [
      { value: "tea", label: "Drizzled in Fine Tea", desc: "Must dissolve beautifully and not overpower herbs" },
      { value: "cheese", label: "Paired with Cheeses & Sourdough", desc: "A culinary centerpiece for gourmet boards" },
      { value: "spoon", label: "Straight from the Spoon", desc: "Pure tasting, raw medicinal/enzymatic benefit" },
      { value: "cooking", label: "Gourmet Baking & Glazes", desc: "Caramelizes beautifully under precision heat" }
    ]
  },
  {
    id: "mood",
    question: "Choose a mood that inspires you today:",
    options: [
      { value: "airy", label: "Bright, Airy Cotswold Morning", desc: "Soft winds and dewy meadows" },
      { value: "rustic", label: "Yorkshire Highlands Twilight", desc: "Earthy, robust warmth and stone hearths" },
      { value: "royal", label: "Ancient Oak Wood Shade", desc: "Deep contemplation, luxury, and stillness" },
      { value: "vibrant", label: "High-Summer Solstice Orchard", desc: "Bursting with sunbeams and sweet blossoms" }
    ]
  }
];
