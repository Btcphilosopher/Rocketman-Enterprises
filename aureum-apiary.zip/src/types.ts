export interface FloralComposition {
  species: string;
  percentage: number;
}

export interface HoneyProduct {
  id: string;
  name: string;
  origin: string;
  description: string;
  longDescription: string;
  price: number;
  image: string;
  rating: number;
  reviewsCount: number;
  floralNotes: string[];
  colorIntensity: number; // 1 (very light) to 5 (very dark)
  batchNo: string;
  hiveCoordinates: string;
  elevation: string;
  harvestDate: string;
  floralComposition: FloralComposition[];
  beekeeperName: string;
  inStock: boolean;
  status?: string; // e.g. "Limited Reserve", "Seasonal", "Sold Out"
}

export interface CartItem {
  product: HoneyProduct;
  quantity: number;
}

export interface BeekeeperProfile {
  name: string;
  location: string;
  experience: string;
  quote: string;
  image: string;
}

export interface JournalEntry {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  excerpt: string;
  image: string;
  content: string;
}

export interface SommelierRecommendation {
  recommendedHoneyId: string;
  expertExplanation: string;
  tastingNotes: string[];
  suggestedPairing: string;
  culinaryUsage: string;
}
