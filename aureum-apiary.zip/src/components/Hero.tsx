import React from "react";
import { Sparkles, ArrowRight, ShieldCheck, Compass, Leaf } from "lucide-react";
import { motion } from "motion/react";

interface HeroProps {
  onNavigate: (sectionId: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section
      id="hero"
      className="relative min-h-[92vh] pt-32 pb-16 flex items-center bg-[#FCFBF8] overflow-hidden px-4 md:px-8 max-w-7xl mx-auto"
    >
      {/* Background Soft Organic Geometries */}
      <div className="absolute top-[-10%] right-[-10%] w-[50vw] h-[50vw] rounded-full bg-gradient-to-br from-amber-100/30 to-amber-200/10 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] left-[-10%] w-[40vw] h-[40vw] rounded-full bg-gradient-to-tr from-amber-50/20 to-orange-100/10 blur-[100px] pointer-events-none" />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center w-full relative z-10">
        
        {/* Left Column: Typographic Narrative */}
        <div className="col-span-1 lg:col-span-6 flex flex-col justify-center text-left">
          
          {/* Tagline Badge */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-brand-gold/10 border border-brand-gold/25 rounded-full text-brand-gold w-fit mb-6"
          >
            <Sparkles size={12} />
            <span className="text-[10px] font-sans font-medium tracking-[0.2em] uppercase">
              The Future of British Food
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h1
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="text-5xl md:text-7xl font-sans tracking-tight text-neutral-800 leading-[1.05] font-light mb-6"
          >
            Honey, <br />
            <span className="font-serif italic font-normal text-brand-gold">Elevated.</span>
          </motion.h1>

          {/* Subheading Narrative */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.4 }}
            className="space-y-3 mb-8 max-w-lg text-neutral-500 text-sm font-sans tracking-wide"
          >
            <p className="flex items-center gap-3 border-l-2 border-brand-gold/30 pl-4 py-0.5">
              <span className="font-semibold text-neutral-700">Pure British honey.</span> Monofloral and wildflower harvests, raw and unfiltered.
            </p>
            <p className="flex items-center gap-3 border-l-2 border-brand-gold/30 pl-4 py-0.5">
              <span className="font-semibold text-neutral-700">From regenerative landscapes.</span> Supporting over sixty species of wildflowers.
            </p>
            <p className="flex items-center gap-3 border-l-2 border-brand-gold/30 pl-4 py-0.5">
              <span className="font-semibold text-neutral-700">Crafted with precision.</span> Acoustic hive health technology, traceably cataloged.
            </p>
            <p className="flex items-center gap-3 border-l-2 border-brand-gold/30 pl-4 py-0.5">
              <span className="font-semibold text-neutral-700">Delivered with elegance.</span> Hand-finished jars wrapped in luxury sustainable card.
            </p>
          </motion.div>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-wrap items-center gap-4"
          >
            <button
              onClick={() => onNavigate("shop")}
              className="px-8 py-4 bg-neutral-900 text-neutral-50 rounded-full font-sans text-xs tracking-widest uppercase font-medium shadow-md shadow-black/10 hover:bg-neutral-800 hover:shadow-lg transition-all flex items-center gap-2 group focus:outline-none"
              id="hero-shop-btn"
            >
              <span>Shop Collection</span>
              <ArrowRight size={14} className="transition-transform group-hover:translate-x-1" />
            </button>

            <button
              onClick={() => onNavigate("origins")}
              className="px-8 py-4 glass-card-button text-neutral-600 rounded-full font-sans text-xs tracking-widest uppercase font-medium hover:text-brand-gold transition-all flex items-center gap-2 focus:outline-none"
              id="hero-origins-btn"
            >
              <Compass size={14} />
              <span>Explore Origins</span>
            </button>
          </motion.div>

          {/* Quick Value Trust Banner */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="grid grid-cols-3 gap-4 border-t border-neutral-100 mt-12 pt-6"
          >
            <div className="flex items-center gap-2">
              <ShieldCheck className="text-brand-gold flex-shrink-0" size={16} />
              <span className="text-[10px] font-sans text-neutral-500 tracking-wider uppercase">
                100% Raw & Certified
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Leaf className="text-brand-gold flex-shrink-0" size={16} />
              <span className="text-[10px] font-sans text-neutral-500 tracking-wider uppercase">
                Regenerative Soil
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Compass className="text-brand-gold flex-shrink-0" size={16} />
              <span className="text-[10px] font-sans text-neutral-500 tracking-wider uppercase">
                Traceable Hive
              </span>
            </div>
          </motion.div>

        </div>

        {/* Right Column: Hyper-luxury Asset Photography Frame */}
        <div className="col-span-1 lg:col-span-6 relative flex justify-center">
          
          {/* Aesthetic Circular Backdrop */}
          <div className="absolute top-[50%] left-[50%] -translate-x-1/2 -translate-y-1/2 w-[90%] h-[90%] bg-white rounded-full border border-neutral-100 shadow-inner -z-10" />

          {/* Primary Photo Wrapper */}
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-lg aspect-[4/5] rounded-[2rem] overflow-hidden shadow-2xl border border-white/50"
            id="hero-image-frame"
          >
            {/* The actual generated photography */}
            <img
              src="/src/assets/images/luxury_honey_hero_1784888917973.jpg"
              alt="Aureum Apiary luxury perfume-style glass honey jar catching sunlight"
              className="w-full h-full object-cover select-none pointer-events-none"
              referrerPolicy="no-referrer"
            />

            {/* Glowing amber sunbeam filter overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-amber-500/10 via-transparent to-transparent pointer-events-none mix-blend-overlay" />
          </motion.div>

          {/* Interactive Floating Micro-Metric Cards (Glassmorphism) */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.8 }}
            className="absolute top-8 -right-4 md:-right-8 glass-panel p-4 rounded-2xl flex items-center gap-3 max-w-[210px]"
          >
            <div className="w-10 h-10 rounded-xl bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold font-serif font-semibold text-sm">
              94%
            </div>
            <div>
              <span className="block text-[10px] font-sans text-neutral-400 uppercase tracking-widest leading-none mb-1">
                Colony Health
              </span>
              <span className="block text-[11px] font-sans text-neutral-700 font-medium">
                Sensors Optimal
              </span>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 1 }}
            className="absolute bottom-12 -left-4 md:-left-8 glass-panel p-4 rounded-2xl flex items-center gap-3 max-w-[210px]"
          >
            <div className="w-10 h-10 rounded-xl bg-neutral-900 flex items-center justify-center text-brand-gold">
              <Leaf size={16} />
            </div>
            <div>
              <span className="block text-[10px] font-sans text-neutral-400 uppercase tracking-widest leading-none mb-1">
                Ecology
              </span>
              <span className="block text-[11px] font-sans text-neutral-700 font-medium">
                Net-Carbon Neutral
              </span>
            </div>
          </motion.div>

        </div>

      </div>
    </section>
  );
}
