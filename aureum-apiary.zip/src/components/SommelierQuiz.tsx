import React, { useState } from "react";
import { Sparkles, ArrowRight, RefreshCw, Star, ArrowLeft, Lightbulb, Check, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { QUIZ_QUESTIONS, HONEY_PRODUCTS } from "../data";
import { HoneyProduct, SommelierRecommendation } from "../types";

interface SommelierQuizProps {
  onAddToCart: (product: HoneyProduct) => void;
}

export default function SommelierQuiz({ onAddToCart }: SommelierQuizProps) {
  const [currentStep, setCurrentStep] = useState(0); // 0 = Intro, 1-4 = Questions, 5 = Loading, 6 = Results
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [loadingMsg, setLoadingMsg] = useState("Consulting our sensory database...");
  const [recommendation, setRecommendation] = useState<SommelierRecommendation | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // For visual selection states
  const totalQuestions = QUIZ_QUESTIONS.length;

  const handleSelectOption = (questionId: string, optionValue: string) => {
    setAnswers({ ...answers, [questionId]: optionValue });
    
    // Auto advance after short delay for fluid motion
    setTimeout(() => {
      if (currentStep <= totalQuestions) {
        setCurrentStep(currentStep + 1);
      }
    }, 300);
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const startQuiz = () => {
    setAnswers({});
    setErrorMsg(null);
    setRecommendation(null);
    setCurrentStep(1);
  };

  const fetchAIRecommendation = async () => {
    setCurrentStep(totalQuestions + 1); // Loading step
    setErrorMsg(null);
    setLoadingMsg("Distilling the seasonal elements...");

    const messages = [
      "Distilling the seasonal elements...",
      "Mapping local soil and flora attributes...",
      "Matching botanical enzyme metrics with your palate...",
      "Aureum Sommelier finalizing tasting notes..."
    ];

    let messageIdx = 0;
    const interval = setInterval(() => {
      if (messageIdx < messages.length - 1) {
        messageIdx++;
        setLoadingMsg(messages[messageIdx]);
      }
    }, 600);

    try {
      const response = await fetch("/api/sommelier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tastePreference: answers["taste"],
          sweetnessPreferred: answers["sweetness"],
          primaryUsage: answers["usage"],
          styleMood: answers["mood"]
        }),
      });

      if (!response.ok) {
        throw new Error("Tasting service encountered an issue. Let's provide our signature match.");
      }

      const data = await response.json();
      setRecommendation(data);
    } catch (err: any) {
      console.error(err);
      // Clean fallback so UI never crashes
      setRecommendation({
        recommendedHoneyId: "wildflower",
        expertExplanation: "Welcome to Aureum Apiary. Based on your balanced tasting profile, our master sommelier recommends Somerset Wildflower Honey. Its diverse floral nectar (chamomile, clover, and lavender) aligns beautifully with a fluid, classic, and elegant palate.",
        tastingNotes: ["Balanced flower nectar", "Warm chamomile undertone", "Classic clover sweet bite"],
        suggestedPairing: "Warm buttermilk scones, clotted cream, and loose-leaf Earl Grey tea.",
        culinaryUsage: "An incredible companion for morning toast, general tea sweetening, or fresh baking."
      });
    } finally {
      clearInterval(interval);
      setCurrentStep(totalQuestions + 2); // Results step
    }
  };

  // Find the matched Honey Product details from our catalog to show its card image, price, etc.
  const matchedHoneyProduct = HONEY_PRODUCTS.find(
    (hp) => hp.id === recommendation?.recommendedHoneyId
  ) || HONEY_PRODUCTS[0];

  return (
    <section id="sommelier" className="py-24 bg-transparent border-t border-neutral-50 px-4 md:px-8 max-w-7xl mx-auto">
      
      {/* Grid structure to balance info on left, interactive quiz on right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        
        {/* Left Side: Brand Story & Sommelier Credentials */}
        <div className="lg:col-span-5 text-left flex flex-col justify-center">
          <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase flex items-center gap-1.5 mb-2">
            <Sparkles size={12} /> Palate Matchmaker
          </span>
          <h2 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-1 mb-6">
            The Honey <br />
            <span className="font-serif italic font-normal text-brand-gold">Sommelier AI.</span>
          </h2>
          <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed mb-8">
            Palates are as unique as the seasons. Our sensory matchmaking system analyzes your preferences in sweetness, aroma profiles, and culinary usage, leveraging Gemini AI to suggest your ideal soil and nectar match.
          </p>

          <div className="space-y-4">
            <div className="flex gap-4 items-start glass-panel p-5 rounded-2xl shadow-sm hover:bg-white/55 transition-all duration-300">
              <div className="w-10 h-10 rounded-xl bg-brand-gold/10 flex items-center justify-center text-brand-gold flex-shrink-0">
                <Lightbulb size={18} />
              </div>
              <div>
                <h4 className="text-sm font-sans font-medium text-neutral-800">
                  Palate Alignment Technology
                </h4>
                <p className="text-xs font-sans text-neutral-500 leading-relaxed mt-1">
                  We match over twenty sensory compounds including thixotropic viscosity levels and floral volatile esters to your diet habits.
                </p>
              </div>
            </div>

            <div className="flex gap-4 items-start glass-panel p-5 rounded-2xl shadow-sm hover:bg-white/55 transition-all duration-300">
              <div className="w-10 h-10 rounded-xl bg-brand-gold/10 flex items-center justify-center text-brand-gold flex-shrink-0">
                <Check size={18} />
              </div>
              <div>
                <h4 className="text-sm font-sans font-medium text-neutral-800">
                  Custom Pairing Suggestions
                </h4>
                <p className="text-xs font-sans text-neutral-500 leading-relaxed mt-1">
                  Receive gourmet recommendations for pairing with artisanal cheeses, clotted creams, single malts, and herbal teas.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: The Interactive Wizard Container */}
        <div className="lg:col-span-7 flex items-center justify-center w-full">
          
          <div className="glass-panel rounded-[2.5rem] shadow-sm p-6 md:p-10 w-full min-h-[480px] flex flex-col justify-between relative overflow-hidden">
            
            {/* INTRO STEP */}
            {currentStep === 0 && (
              <div className="text-center py-8 flex flex-col items-center justify-center my-auto">
                <div className="w-16 h-16 rounded-full bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold mb-6 animate-pulse">
                  <Sparkles size={24} />
                </div>
                <h3 className="text-2xl font-sans text-neutral-800 font-light mb-3">
                  Tailor Britain's Soils to Your Palate
                </h3>
                <p className="text-xs font-sans text-neutral-500 leading-relaxed max-w-sm mb-8">
                  Commence our 4-step sensory evaluation. Our AI Sommelier will curate a custom profile mapping your exact taste parameters to our active apiaries.
                </p>
                <button
                  onClick={startQuiz}
                  className="px-8 py-4 bg-neutral-900 hover:bg-neutral-800 text-neutral-50 text-xs font-sans tracking-widest uppercase font-semibold rounded-full shadow-md hover:shadow-lg transition-all focus:outline-none"
                  id="start-quiz-btn"
                >
                  Begin Palate Study
                </button>
              </div>
            )}

            {/* DYNAMIC QUESTIONS (Steps 1 to 4) */}
            {currentStep >= 1 && currentStep <= totalQuestions && (
              <div className="flex flex-col justify-between h-full text-left" id={`quiz-step-${currentStep}`}>
                
                {/* Step indicators */}
                <div className="flex items-center justify-between border-b border-white/60 pb-4 mb-6">
                  <button
                    onClick={handleBack}
                    className="flex items-center gap-1.5 text-xs text-neutral-400 hover:text-neutral-700 transition-colors focus:outline-none"
                    id="quiz-back-btn"
                  >
                    <ArrowLeft size={14} /> Back
                  </button>
                  <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase font-medium">
                    PALATE PROFILE: STEP {currentStep} OF {totalQuestions}
                  </span>
                </div>

                {/* Question */}
                <div className="my-auto">
                  <h3 className="text-xl md:text-2xl font-sans text-neutral-800 font-light mb-6">
                    {QUIZ_QUESTIONS[currentStep - 1].question}
                  </h3>

                  {/* Options List */}
                  <div className="space-y-3">
                    {QUIZ_QUESTIONS[currentStep - 1].options.map((option) => {
                      const qId = QUIZ_QUESTIONS[currentStep - 1].id;
                      const isSelected = answers[qId] === option.value;
                      return (
                        <button
                          key={option.value}
                          onClick={() => handleSelectOption(qId, option.value)}
                          className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center justify-between group focus:outline-none ${
                            isSelected
                              ? "bg-brand-gold/15 border-brand-gold text-neutral-800 font-medium"
                              : "bg-transparent border-white/40 hover:bg-white/30 hover:border-white/60"
                          }`}
                          id={`option-${option.value}`}
                        >
                          <div>
                            <span className="block text-xs font-sans text-neutral-800 font-medium group-hover:text-brand-gold transition-colors">
                              {option.label}
                            </span>
                            <span className="block text-[10px] font-sans text-neutral-400 mt-1">
                              {option.desc}
                            </span>
                          </div>
                          {isSelected && (
                            <div className="w-5 h-5 rounded-full bg-brand-gold flex items-center justify-center text-neutral-900">
                              <Check size={12} />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Quiz Progress Bar */}
                <div className="mt-8 pt-4 border-t border-white/60 flex items-center justify-between">
                  <div className="w-1/2 h-1 bg-neutral-150 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-brand-gold transition-all duration-300"
                      style={{ width: `${(currentStep / totalQuestions) * 100}%` }}
                    />
                  </div>
                  {currentStep === totalQuestions && (
                    <button
                      onClick={fetchAIRecommendation}
                      className="px-6 py-3 bg-neutral-900 hover:bg-neutral-800 text-neutral-50 text-[10px] font-sans tracking-widest uppercase font-semibold rounded-full transition-all focus:outline-none flex items-center gap-2"
                      id="submit-palate-btn"
                    >
                      <span>Analyze Palate</span>
                      <ArrowRight size={12} />
                    </button>
                  )}
                </div>

              </div>
            )}

            {/* LOADING STATE */}
            {currentStep === totalQuestions + 1 && (
              <div className="text-center py-8 flex flex-col items-center justify-center my-auto">
                <div className="relative w-20 h-20 mb-8">
                  <div className="absolute inset-0 rounded-full border border-dashed border-brand-gold/40 animate-spin" />
                  <div className="absolute inset-2 rounded-full bg-brand-gold/10 flex items-center justify-center">
                    <Sparkles className="text-brand-gold animate-pulse" size={24} />
                  </div>
                </div>
                <span className="text-[10px] font-sans text-brand-gold font-semibold tracking-widest uppercase mb-2 animate-pulse block">
                  Aureum Sommelier AI matching
                </span>
                <p className="text-xs font-sans text-neutral-400 leading-relaxed max-w-xs">
                  {loadingMsg}
                </p>
              </div>
            )}

            {/* RESULTS STATE */}
            {currentStep === totalQuestions + 2 && recommendation && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-left flex flex-col justify-between h-full"
                id="sommelier-results-board"
              >
                {/* Header branding */}
                <div className="flex justify-between items-start border-b border-white/60 pb-4 mb-5">
                  <div>
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                      Matched Botanical Profile
                    </span>
                    <h4 className="text-xl font-sans text-neutral-800 font-light">
                      Your Palate Match Found
                    </h4>
                  </div>
                  <button
                    onClick={startQuiz}
                    className="text-[10px] font-sans text-neutral-400 hover:text-brand-gold tracking-wider uppercase font-semibold flex items-center gap-1 focus:outline-none"
                    id="restart-quiz-btn"
                  >
                    <RefreshCw size={10} /> Retest
                  </button>
                </div>

                {/* Recommended Product layout */}
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center my-auto">
                  
                  {/* Photo representation */}
                  <div className="md:col-span-4 aspect-square rounded-2xl overflow-hidden border border-white/60 bg-white/40 p-2">
                    <img
                      src={matchedHoneyProduct.image}
                      alt={matchedHoneyProduct.name}
                      className="w-full h-full object-cover rounded-xl select-none"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  {/* Sommelier commentary details */}
                  <div className="md:col-span-8 space-y-3">
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block font-medium">
                      Recommended Nectar
                    </span>
                    <h5 className="text-2xl font-sans font-light text-brand-gold leading-none">
                      {matchedHoneyProduct.name}
                    </h5>
                    
                    <p className="text-xs font-sans text-neutral-500 leading-relaxed tracking-wide italic">
                      "{recommendation.expertExplanation}"
                    </p>

                    {/* Sensor list */}
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {recommendation.tastingNotes.map((note) => (
                        <span
                          key={note}
                          className="px-2.5 py-1 bg-brand-gold/15 border border-brand-gold/30 text-brand-gold text-[9px] font-sans tracking-wide uppercase rounded-full font-medium"
                        >
                          🍯 {note}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Pairing Box */}
                <div className="bg-white/20 border border-white/40 p-4 rounded-2xl my-4 text-xs font-sans text-neutral-600 leading-relaxed">
                  <span className="font-semibold text-neutral-800 block mb-1">
                    🍽️ Recommended Gastronomic Pairing:
                  </span>
                  {recommendation.suggestedPairing}
                </div>

                {/* CTA Action footer */}
                <div className="border-t border-white/60 pt-4 flex items-center justify-between">
                  <div>
                    <span className="text-[8px] font-sans text-neutral-400 uppercase tracking-widest block leading-none mb-1">
                      Palate Match Price
                    </span>
                    <span className="font-sans text-lg text-neutral-800 font-medium">
                      £{matchedHoneyProduct.price}.00
                    </span>
                  </div>
                  
                  <button
                    onClick={() => {
                      onAddToCart(matchedHoneyProduct);
                      setCurrentStep(0); // reset
                    }}
                    className="px-6 py-3 bg-neutral-900 text-neutral-50 text-[10px] font-sans tracking-widest uppercase font-semibold rounded-full hover:bg-neutral-800 transition-all shadow-md flex items-center gap-1.5 focus:outline-none"
                    id="add-match-btn"
                  >
                    <span>Acquire Matched Nectar</span>
                    <ArrowRight size={12} />
                  </button>
                </div>

              </motion.div>
            )}

          </div>

        </div>

      </div>

    </section>
  );
}
