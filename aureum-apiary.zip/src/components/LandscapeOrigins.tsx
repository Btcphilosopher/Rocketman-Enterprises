import React, { useState } from "react";
import { Compass, Thermometer, Droplets, CloudSun, Eye, Sparkles, MapPin, Award, ShieldAlert, Laptop } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { HONEY_PRODUCTS, BEEKEEPERS } from "../data";

export default function LandscapeOrigins() {
  const [activeRegionId, setActiveRegionId] = useState("Somerset");
  const [selectedBeekeeper, setSelectedBeekeeper] = useState(BEEKEEPERS[0]);

  const regions = [
    {
      name: "Somerset Meadows",
      id: "Somerset",
      elevation: "84m",
      temp: "21.5°C",
      humidity: "62%",
      soilHealth: "Excellent (pH 6.8)",
      flora: "Wild Clover, Chamomile, English Lavender",
      hives: 24,
      hiveStatus: "Active & Optimal",
      desc: "Our primary hub located amidst low-density Somerset meadows, utilizing custom acoustic frequency monitoring."
    },
    {
      name: "Cotswold Valleys",
      id: "Cotswold",
      elevation: "112m",
      temp: "19.8°C",
      humidity: "58%",
      soilHealth: "Vibrant Limestone (pH 7.2)",
      flora: "Black Locust Acacia, White Clover, Hawthorn",
      hives: 18,
      hiveStatus: "Active",
      desc: "Sunny, sheltered limestone valley slopes ideal for light, delicate acacia groves and wild rosehips."
    },
    {
      name: "Yorkshire Moors",
      id: "Yorkshire",
      elevation: "245m",
      temp: "17.2°C",
      humidity: "71%",
      soilHealth: "Acidic Peatland (pH 5.4)",
      flora: "Ling Heather, Cross-leaved Heath, Wild Bilberry",
      hives: 32,
      hiveStatus: "Honey Flow Stage",
      desc: "A windswept, rugged landscape generating our robust, jelly-like thixotropic Heather Honey."
    },
    {
      name: "Windsor Forest",
      id: "Windsor",
      elevation: "65m",
      temp: "20.1°C",
      humidity: "65%",
      soilHealth: "Ancient Woodland Humus (pH 6.2)",
      flora: "English Oak Honeydew, Sweet Chestnut",
      hives: 12,
      hiveStatus: "Limited Reserve Mode",
      desc: "An organic woodland canopy protected for centuries, generating exceptionally dark, mineral-rich honeydew."
    }
  ];

  const currentRegion = regions.find((r) => r.id === activeRegionId) || regions[0];

  return (
    <section id="origins" className="py-24 bg-[#FCFBF8] border-t border-neutral-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="text-left max-w-xl">
            <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase flex items-center gap-1.5">
              <Compass size={12} /> Regenerative Terroir
            </span>
            <h2 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-3 mb-4">
              British Nature, <br />
              <span className="font-serif italic font-normal text-brand-gold">Precision Engineered.</span>
            </h2>
            <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed">
              We position our lightweight modern apiaries in hand-selected biological corridors. Explore the local microclimates and soil conditions that form our distinct nectars.
            </p>
          </div>
          
          {/* Quick Stats Badges */}
          <div className="flex flex-wrap gap-4">
            <div className="glass-panel px-5 py-4 rounded-2xl flex items-center gap-3 shadow-sm">
              <span className="text-2xl font-sans font-light text-brand-gold">142</span>
              <span className="text-[9px] font-sans text-neutral-400 tracking-widest uppercase text-left block leading-tight">
                Active <br />IoT Hives
              </span>
            </div>
            <div className="glass-panel px-5 py-4 rounded-2xl flex items-center gap-3 shadow-sm">
              <span className="text-2xl font-sans font-light text-brand-gold">65+</span>
              <span className="text-[9px] font-sans text-neutral-400 tracking-widest uppercase text-left block leading-tight">
                Plant <br />Species Monitored
              </span>
            </div>
          </div>
        </div>

        {/* INTERACTIVE TERROIR EXPLORER */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch mb-24">
          
          {/* Left Column: Region Selectors & Quick Description */}
          <div className="lg:col-span-4 flex flex-col justify-between text-left">
            <div className="space-y-3">
              <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-2">
                Select Apiary Locale
              </span>
              {regions.map((region) => (
                <button
                  key={region.id}
                  onClick={() => setActiveRegionId(region.id)}
                  className={`w-full text-left p-5 rounded-2xl border transition-all flex items-center justify-between group focus:outline-none ${
                    activeRegionId === region.id
                      ? "glass-card-dense border-brand-gold shadow-md translate-x-2"
                      : "bg-transparent border-white/40 hover:bg-white/30 hover:border-white/60"
                  }`}
                  id={`region-btn-${region.id}`}
                >
                  <div>
                    <span className="block text-[10px] font-sans text-neutral-400 uppercase tracking-wider mb-1">
                      United Kingdom
                    </span>
                    <span className="block text-base font-sans text-neutral-800 font-light tracking-tight group-hover:text-brand-gold transition-colors">
                      {region.name}
                    </span>
                  </div>
                  <Compass
                    size={16}
                    className={`transition-all ${
                      activeRegionId === region.id ? "text-brand-gold rotate-45" : "text-neutral-300 group-hover:text-neutral-500"
                    }`}
                  />
                </button>
              ))}
            </div>

            <div className="mt-8 bg-brand-gold/10 border border-brand-gold/25 p-6 rounded-3xl">
              <span className="text-[10px] font-sans font-medium text-brand-gold uppercase tracking-widest block mb-2">
                Landscape Micro-Study
              </span>
              <p className="text-xs font-sans text-neutral-500 leading-relaxed">
                {currentRegion.desc} Our bees forage within a strict 3km radius to guarantee absolute mono-floral integrity and chemical-free foraging paths.
              </p>
            </div>
          </div>

          {/* Right Column: Dynamic Telemetry Board (Glassmorphism design) */}
          <div className="lg:col-span-8 glass-panel rounded-[2.5rem] p-6 md:p-10 shadow-sm flex flex-col justify-between relative overflow-hidden">
            
            {/* Soft backdrop graphics */}
            <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-brand-gold/5 blur-3xl pointer-events-none" />

            <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/60 pb-6 mb-8 gap-4">
              <div className="text-left">
                <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                  Active Apiary Hub
                </span>
                <h4 className="text-2xl font-sans text-neutral-800 font-light">
                  {currentRegion.name} telemetry
                </h4>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 bg-white/40 border border-white/60 rounded-full text-green-700 text-[10px] font-sans font-medium uppercase tracking-wider">
                <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                <span>Hive Grid: {currentRegion.hiveStatus}</span>
              </div>
            </div>

            {/* Grid of Microclimatic data */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-left mb-8">
              <div className="bg-white/30 p-5 rounded-2xl border border-white/50">
                <Thermometer className="text-brand-gold mb-3" size={20} />
                <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                  Ambient Temp
                </span>
                <span className="text-lg font-sans font-semibold text-neutral-700">
                  {currentRegion.temp}
                </span>
              </div>

              <div className="bg-white/30 p-5 rounded-2xl border border-white/50">
                <Droplets className="text-brand-gold mb-3" size={20} />
                <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                  Air Humidity
                </span>
                <span className="text-lg font-sans font-semibold text-neutral-700">
                  {currentRegion.humidity}
                </span>
              </div>

              <div className="bg-white/30 p-5 rounded-2xl border border-white/50">
                <Award className="text-brand-gold mb-3" size={20} />
                <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                  Regen Hives
                </span>
                <span className="text-lg font-sans font-semibold text-neutral-700">
                  {currentRegion.hives} active
                </span>
              </div>

              <div className="bg-white/30 p-5 rounded-2xl border border-white/50">
                <CloudSun className="text-brand-gold mb-3" size={20} />
                <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                  Soil Chemistry
                </span>
                <span className="text-xs font-sans font-semibold text-neutral-700 leading-tight block pt-0.5">
                  {currentRegion.soilHealth}
                </span>
              </div>
            </div>

            {/* Flora Canopy Report */}
            <div className="bg-white/20 border border-white/40 p-6 rounded-2xl text-left">
              <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-2">
                Predominant Botanical Foraging Canopy
              </span>
              <div className="flex flex-wrap gap-2">
                {currentRegion.flora.split(", ").map((flower) => (
                  <span
                    key={flower}
                    className="px-3.5 py-1.5 bg-white/40 border border-white/60 text-neutral-600 text-xs font-sans rounded-full shadow-sm hover:border-brand-gold hover:text-neutral-800 transition-all cursor-default"
                  >
                    🌻 {flower}
                  </span>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* WHY BRITISH HONEY SECTION */}
        <div className="border-t border-neutral-100 pt-20 mb-20">
          <div className="text-center max-w-xl mx-auto mb-16">
            <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-amber-600 uppercase">
              The Aureum Philosophy
            </span>
            <h3 className="text-3xl font-sans tracking-tight text-neutral-800 font-light mt-3">
              Why British Honey?
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="p-8 bg-white border border-neutral-100 rounded-3xl shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 mb-6">
                <Sparkles size={20} />
              </div>
              <h4 className="text-lg font-sans font-medium text-neutral-800 mb-3">
                1. Ultimate Purity
              </h4>
              <p className="text-xs font-sans text-neutral-500 leading-relaxed">
                Our honey is 100% coldextracted, raw, and completely unpasteurized. It retains every natural pollen grain, amino acid, and active enzyme, exactly as the bees synthesized it.
              </p>
            </div>

            <div className="p-8 bg-white border border-neutral-100 rounded-3xl shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 mb-6">
                <Laptop size={20} />
              </div>
              <h4 className="text-lg font-sans font-medium text-neutral-800 mb-3">
                2. Non-Invasive Tech
              </h4>
              <p className="text-xs font-sans text-neutral-500 leading-relaxed">
                By integrating microacoustics and temperature grids inside lightweight hives, we audit colony state without pulling frame components out. A quiet bee is a happy bee.
              </p>
            </div>

            <div className="p-8 bg-white border border-neutral-100 rounded-3xl shadow-sm">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 mb-6">
                <Award size={20} />
              </div>
              <h4 className="text-lg font-sans font-medium text-neutral-800 mb-3">
                3. Regenerative Impact
              </h4>
              <p className="text-xs font-sans text-neutral-500 leading-relaxed">
                We reinvest 10% of our margins directly into planting wild native meadowlands alongside regional farmers, guaranteeing the countryside remains healthy and vibrant for decades.
              </p>
            </div>
          </div>
        </div>

        {/* MEET THE BEEKEEPERS */}
        <div className="border-t border-neutral-100 pt-20">
          <div className="text-center max-w-xl mx-auto mb-16">
            <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase">
              Curators of the Colony
            </span>
            <h3 className="text-3xl font-sans tracking-tight text-neutral-800 font-light mt-3 mb-4">
              Meet the Beekeepers
            </h3>
            <p className="text-xs font-sans text-neutral-500 leading-relaxed">
              Our apiaries are curated by leading agronomists, conservationists, and veterans who treat apiculture with artistic devotion.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Beekeeper selector list */}
            <div className="lg:col-span-4 space-y-3">
              {BEEKEEPERS.map((bk) => (
                <button
                  key={bk.name}
                  onClick={() => setSelectedBeekeeper(bk)}
                  className={`w-full text-left p-4 rounded-2xl border transition-all flex items-center gap-4 focus:outline-none ${
                    selectedBeekeeper.name === bk.name
                      ? "glass-card-dense border-brand-gold shadow-md"
                      : "bg-transparent border-white/40 hover:bg-white/30 hover:border-white/60"
                  }`}
                  id={`beekeeper-btn-${bk.name.replace(/\s+/g, "")}`}
                >
                  <img
                    src={bk.image}
                    alt={bk.name}
                    className="w-12 h-12 rounded-full object-cover border border-neutral-100 shadow-sm"
                  />
                  <div>
                    <span className="block text-[8px] font-sans text-neutral-400 uppercase tracking-widest">
                      {bk.location}
                    </span>
                    <span className="block text-sm font-sans font-medium text-neutral-800">
                      {bk.name}
                    </span>
                  </div>
                </button>
              ))}
            </div>

            {/* Beekeeper Showcase Card */}
            <div className="lg:col-span-8 glass-panel rounded-[2rem] p-6 md:p-10 shadow-sm text-left">
              <AnimatePresence mode="wait">
                <motion.div
                  key={selectedBeekeeper.name}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.4 }}
                  className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center"
                >
                  <div className="md:col-span-4 aspect-[3/4] w-full rounded-2xl overflow-hidden border border-white/60 shadow-sm">
                    <img
                      src={selectedBeekeeper.image}
                      alt={selectedBeekeeper.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="md:col-span-8 flex flex-col justify-center">
                    <span className="text-[10px] font-sans font-semibold text-brand-gold tracking-widest uppercase mb-1 block">
                      {selectedBeekeeper.experience}
                    </span>
                    <h4 className="text-2xl font-sans font-light text-neutral-800 leading-none mb-4">
                      {selectedBeekeeper.name}
                    </h4>
                    <span className="text-xs font-sans font-medium text-neutral-400 block mb-6">
                      📍 {selectedBeekeeper.location}
                    </span>
                    <blockquote className="text-sm font-serif italic text-neutral-600 border-l-4 border-brand-gold/35 pl-6 py-2 leading-relaxed mb-6">
                      "{selectedBeekeeper.quote}"
                    </blockquote>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}
