import React, { useState } from "react";
import { Leaf, ShieldCheck, HelpCircle, ArrowRight, Sun, Award } from "lucide-react";
import { motion } from "motion/react";

export default function SustainabilityTracker() {
  const [activeMetric, setActiveMetric] = useState("flora");

  const metrics = {
    flora: {
      title: "Botanical Flora Sanctuary",
      figure: "12,450 sq m",
      growth: "+18% year-over-year",
      auditor: "Soil Association Verified",
      narrative: "Every jar purchased subsidizes the planting of organic heirloom wildflower seeds (Chamomile, Clover, Borage, Lavender) directly across our Somerset agricultural cooperative corridors."
    },
    carbon: {
      title: "Carbon Offset Equivalence",
      figure: "-84.2 Tonnes CO2",
      growth: "Net-Carbon Negative",
      auditor: "Carbon Trust Audited",
      narrative: "By utilizing local sustainably-sourced British ash wood for our hive structures and organic cotton beeswax wrappers for shipping, our full lifecycle carbon footprint is fully negative."
    },
    colony: {
      title: "Active Colony Support Ratio",
      figure: "8.2 Million Bees",
      growth: "100% Native British Black Bee",
      auditor: "Bee Improvement & Breeders Association",
      narrative: "We focus exclusively on backing Apis mellifera mellifera, Britain's native black honeybee. This rugged species thrives in wet climate environments, boosting local crop pollination rates by 300%."
    }
  };

  const currentMetric = metrics[activeMetric as keyof typeof metrics];

  return (
    <section id="sustainability" className="py-24 bg-transparent border-t border-neutral-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase flex items-center justify-center gap-1.5">
            <Leaf size={12} /> Regenerative Ledger
          </span>
          <h2 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-3 mb-4">
            Audited Ecological <br />
            <span className="font-serif italic font-normal text-brand-gold">Stewardship.</span>
          </h2>
          <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed">
            True luxury must contribute more to the soil than it extracts. Toggle our verified performance parameters to audit our 2045 regenerative metrics.
          </p>
        </div>

        {/* Impact Visualizer Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column: Interactive Selector List */}
          <div className="lg:col-span-5 space-y-3 text-left">
            <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-3">
              Audited Ecological Verticals
            </span>
            {Object.keys(metrics).map((key) => {
              const active = activeMetric === key;
              const data = metrics[key as keyof typeof metrics];
              return (
                <button
                  key={key}
                  onClick={() => setActiveMetric(key)}
                  className={`w-full text-left p-6 rounded-3xl border transition-all flex items-center justify-between group focus:outline-none ${
                    active
                      ? "glass-card-dense border-brand-gold shadow-md translate-x-2"
                      : "bg-transparent border-white/40 hover:bg-white/30 hover:border-white/60"
                  }`}
                  id={`sustainability-metric-btn-${key}`}
                >
                  <div>
                    <span className="block text-[8px] font-sans text-neutral-400 uppercase tracking-widest leading-none mb-1">
                      Indicator ID: {key.toUpperCase()}
                    </span>
                    <span className="block text-base font-sans text-neutral-800 font-light">
                      {data.title}
                    </span>
                  </div>
                  <Leaf
                    size={16}
                    className={`transition-all ${
                      active ? "text-brand-gold" : "text-neutral-300 group-hover:text-neutral-500"
                    }`}
                  />
                </button>
              );
            })}
          </div>

          {/* Right Column: High-contrast metric output dashboard */}
          <div className="lg:col-span-7 glass-panel rounded-[2.5rem] p-8 md:p-12 shadow-sm text-left relative overflow-hidden">
            
            {/* Visual background details */}
            <div className="absolute top-0 right-0 p-6 opacity-5">
              <Sun size={200} className="text-brand-gold" />
            </div>

            <span className="text-[9px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
              Active Stewardship Metric
            </span>
            <h4 className="text-2xl font-sans text-neutral-800 font-light mb-6">
              {currentMetric.title}
            </h4>

            {/* Giant display figure */}
            <div className="mb-6">
              <span className="block text-4xl md:text-6xl font-sans font-extralight text-brand-gold tracking-tight">
                {currentMetric.figure}
              </span>
              <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase mt-1 block">
                {currentMetric.growth}
              </span>
            </div>

            {/* Narrative detail */}
            <div className="bg-white/20 border border-white/40 p-6 rounded-2xl mb-8">
              <p className="text-sm font-sans text-neutral-500 leading-relaxed tracking-wide">
                {currentMetric.narrative}
              </p>
            </div>

            {/* Trust compliance row */}
            <div className="flex flex-wrap gap-4 justify-between items-center border-t border-white/60 pt-6">
              <div className="flex items-center gap-2">
                <ShieldCheck className="text-brand-gold" size={16} />
                <span className="text-[10px] font-sans font-medium text-neutral-600 uppercase tracking-wider">
                  {currentMetric.auditor}
                </span>
              </div>

              <div className="flex items-center gap-1 text-[10px] font-sans text-brand-gold uppercase tracking-widest font-semibold cursor-pointer hover:text-brand-gold/80 transition-colors">
                <span>View Full Sustainability Report</span>
                <ArrowRight size={10} />
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
}
