import React, { useState } from "react";
import { Sparkles, Compass, ShieldCheck, Cpu, Database, ClipboardCheck, ArrowRight, RefreshCw, Star } from "lucide-react";
import { motion } from "motion/react";
import { HONEY_PRODUCTS } from "../data";

export default function TraceabilityScanner() {
  const [batchInput, setBatchInput] = useState("WS-2045-A");
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const [scannedProduct, setScannedProduct] = useState(HONEY_PRODUCTS[0]);

  const handleScan = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanInput = batchInput.trim().toUpperCase();
    const product = HONEY_PRODUCTS.find((p) => p.batchNo.toUpperCase() === cleanInput) || HONEY_PRODUCTS[0];
    
    setIsScanning(true);
    setScanComplete(false);

    // Simulate luxury biotech scan
    setTimeout(() => {
      setScannedProduct(product);
      setIsScanning(false);
      setScanComplete(true);
    }, 2200);
  };

  const handlePresetClick = (batch: string) => {
    setBatchInput(batch);
    const product = HONEY_PRODUCTS.find((p) => p.batchNo === batch) || HONEY_PRODUCTS[0];
    setScannedProduct(product);
    setScanComplete(false);
  };

  return (
    <section id="traceability" className="py-24 bg-transparent border-t border-neutral-50 px-4 md:px-8 max-w-7xl mx-auto">
      
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase flex items-center justify-center gap-1.5">
          <Cpu size={12} /> Blockchain Traceability
        </span>
        <h2 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-3 mb-4">
          Trace Your <span className="font-serif italic font-normal text-brand-gold">Jar.</span>
        </h2>
        <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed">
          Every hand-numbered Aureum jar has a traceable ledger record. Select a batch ID below to audit the queen's health, hive elevation, and floral percentages.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
        
        {/* Left Side: Scanner Input Panel */}
        <div className="lg:col-span-5 flex flex-col justify-between text-left glass-panel rounded-[2.5rem] p-6 md:p-8 shadow-sm hover:bg-white/55 transition-all duration-300">
          <div>
            <div className="flex items-center gap-2 text-brand-gold mb-6">
              <Database size={16} />
              <span className="text-xs font-sans font-semibold uppercase tracking-wider">
                Audited Batch Ledger
              </span>
            </div>

            <h4 className="text-xl font-sans text-neutral-800 font-light mb-4">
              Enter the batch number located on your signature label:
            </h4>

            <form onSubmit={handleScan} className="space-y-4 mb-8">
              <div className="relative">
                <input
                  type="text"
                  placeholder="e.g. WS-2045-A"
                  value={batchInput}
                  onChange={(e) => setBatchInput(e.target.value)}
                  className="w-full bg-white/40 border border-white/60 rounded-full py-4 px-6 text-sm font-sans tracking-widest uppercase focus:outline-none focus:border-brand-gold transition-colors shadow-inner"
                  id="batch-input"
                />
                <button
                  type="submit"
                  disabled={isScanning}
                  className="absolute right-2 top-2 bottom-2 bg-neutral-900 text-neutral-50 text-[10px] font-sans tracking-widest uppercase rounded-full px-5 hover:bg-neutral-800 transition-all flex items-center justify-center gap-2 focus:outline-none"
                  id="scan-btn"
                >
                  {isScanning ? (
                    <>
                      <RefreshCw className="animate-spin" size={12} />
                      <span>Scanning...</span>
                    </>
                  ) : (
                    <>
                      <span>Analyze</span>
                      <ArrowRight size={12} />
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Quick Presets */}
            <div className="space-y-2">
              <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-3">
                Or select an active apiary ledger preset:
              </span>
              <div className="flex flex-wrap gap-2">
                {HONEY_PRODUCTS.map((prod) => (
                  <button
                    key={prod.id}
                    onClick={() => handlePresetClick(prod.batchNo)}
                    className={`px-3 py-1.5 rounded-full border text-[10px] font-sans tracking-widest uppercase transition-all focus:outline-none ${
                      batchInput === prod.batchNo && !scanComplete
                        ? "bg-brand-gold/15 border-brand-gold text-brand-gold font-medium"
                        : "bg-white/30 border-white/50 text-neutral-500 hover:border-brand-gold/40"
                    }`}
                    id={`preset-${prod.id}`}
                  >
                    {prod.batchNo}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/60 flex items-center gap-3">
            <ClipboardCheck className="text-brand-gold flex-shrink-0" size={18} />
            <span className="text-[10px] font-sans text-neutral-400 uppercase tracking-wide leading-relaxed">
              Fully verified with DEFRA and British Beekeepers Association compliance matrices.
            </span>
          </div>
        </div>

        {/* Right Side: Animated Screen and Certificate */}
        <div className="lg:col-span-7 flex items-center justify-center">
          
          <div className="w-full relative min-h-[450px] glass-panel rounded-[2.5rem] shadow-sm overflow-hidden flex items-center justify-center p-6 md:p-10">
            
            {/* Dynamic Content Switching */}
            {!isScanning && !scanComplete && (
              <div className="text-center max-w-sm flex flex-col items-center">
                <div className="w-16 h-16 rounded-full bg-white/30 flex items-center justify-center text-neutral-400 mb-6 border border-white/50 shadow-inner">
                  <Cpu size={24} className="text-brand-gold" />
                </div>
                <h4 className="text-lg font-sans font-light text-neutral-800 mb-2">
                  System Standby
                </h4>
                <p className="text-xs font-sans text-neutral-500 leading-relaxed mb-4">
                  Please submit or select a valid batch number to commence precision molecular and coordinates mapping diagnostics.
                </p>
                <button
                  onClick={handleScan}
                  className="px-5 py-2.5 glass-card-button text-neutral-600 rounded-full text-[10px] font-sans tracking-widest uppercase transition-all focus:outline-none"
                  id="init-scan-btn"
                >
                  Run Demo Diagnostic
                </button>
              </div>
            )}

            {/* SCANNING STATE (Biotech loading effect) */}
            {isScanning && (
              <div className="text-center max-w-xs flex flex-col items-center">
                
                {/* Custom scanning animation node */}
                <div className="relative w-24 h-24 mb-8">
                  {/* Outer spinning ring */}
                  <div className="absolute inset-0 rounded-full border-2 border-dashed border-brand-gold/30 animate-spin" />
                  {/* Inner pulsing circle */}
                  <div className="absolute inset-2 rounded-full border border-brand-gold/45 bg-brand-gold/10 animate-pulse flex items-center justify-center">
                    <RefreshCw className="text-brand-gold animate-spin" style={{ animationDuration: "3s" }} size={24} />
                  </div>
                </div>

                <span className="text-[10px] font-sans text-brand-gold font-semibold uppercase tracking-widest animate-pulse mb-2">
                  Analyzing molecular chemistry
                </span>
                <p className="text-xs font-sans text-neutral-400 leading-relaxed">
                  Sequencing pollen DNA isotopes and fetching acoustic telemetry vectors from DEFRA node...
                </p>
              </div>
            )}

            {/* SCAN COMPLETE CERTIFICATE DISPLAY */}
            {scanComplete && (
              <motion.div
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full text-left"
                id="trace-certificate"
              >
                {/* Header branding */}
                <div className="flex justify-between items-start border-b border-white/60 pb-5 mb-6">
                  <div>
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                      Certified Traceability Ledger
                    </span>
                    <h5 className="text-xl font-sans text-neutral-800 font-light">
                      Aureum Certified: {scannedProduct.batchNo}
                    </h5>
                  </div>
                  <div className="px-3 py-1 bg-brand-gold/15 border border-brand-gold/30 text-brand-gold rounded-full text-[9px] font-sans font-medium tracking-wider uppercase">
                    Authentic Raw
                  </div>
                </div>

                {/* Main Information blocks */}
                <div className="grid grid-cols-2 gap-6 mb-6">
                  <div>
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                      Botanical Variety
                    </span>
                    <span className="text-sm font-sans font-medium text-neutral-800">
                      {scannedProduct.name}
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                      Geographical Hive Pin
                    </span>
                    <span className="text-sm font-sans font-medium text-neutral-800 flex items-center gap-1">
                      <Compass size={12} className="text-brand-gold" />
                      {scannedProduct.hiveCoordinates}
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                      Beekeeping Curator
                    </span>
                    <span className="text-sm font-sans font-medium text-neutral-800">
                      {scannedProduct.beekeeperName}
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block mb-1">
                      Harvest Season
                    </span>
                    <span className="text-sm font-sans font-medium text-neutral-800">
                      {scannedProduct.harvestDate} ({scannedProduct.elevation} elevation)
                    </span>
                  </div>
                </div>

                {/* Pollen Census Bars */}
                <div className="bg-white/20 border border-white/40 p-5 rounded-2xl mb-6">
                  <span className="text-[9px] font-sans text-neutral-400 tracking-widest uppercase block mb-3">
                    Dominant Pollen DNA Census
                  </span>
                  <div className="space-y-3">
                    {scannedProduct.floralComposition.map((item) => (
                      <div key={item.species} className="text-xs">
                        <div className="flex justify-between font-sans text-neutral-600 mb-1">
                          <span className="italic">{item.species}</span>
                          <span className="font-semibold text-neutral-800">{item.percentage}%</span>
                        </div>
                        <div className="w-full h-1 bg-neutral-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-brand-gold"
                            style={{ width: `${item.percentage}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Trust Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-white/60">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="text-brand-gold" size={16} />
                    <span className="text-[10px] font-sans text-neutral-500 tracking-wider uppercase font-medium">
                      Immutable Signature Record Verified
                    </span>
                  </div>
                  <button
                    onClick={() => setScanComplete(false)}
                    className="text-[10px] font-sans text-neutral-400 hover:text-neutral-700 tracking-wider uppercase font-semibold flex items-center gap-1 focus:outline-none"
                    id="reset-scan-btn"
                  >
                    <RefreshCw size={10} />
                    Clear Certificate
                  </button>
                </div>

              </motion.div>
            )}

          </div>

        </div>

      </div>

    </section>
  );
}
