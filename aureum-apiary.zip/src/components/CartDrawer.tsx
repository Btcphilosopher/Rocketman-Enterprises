import React, { useState } from "react";
import { X, Minus, Plus, Trash2, ShoppingBag, Gift, Truck, ShieldCheck, CreditCard, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CartItem } from "../types";

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, quantity: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart
}: CartDrawerProps) {
  const [includeGiftBox, setIncludeGiftBox] = useState(false);
  const [giftNote, setGiftNote] = useState("");
  const [checkoutStage, setCheckoutStage] = useState<"cart" | "processing" | "receipt">("cart");
  const [receiptNo, setReceiptNo] = useState("");

  const itemsPrice = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const giftBoxPrice = includeGiftBox ? 15 : 0;
  const shippingPrice = itemsPrice > 70 ? 0 : 5.5; // Free over £70
  const totalPrice = itemsPrice + giftBoxPrice + shippingPrice;

  const handleCheckout = () => {
    setCheckoutStage("processing");
    // Generate a beautiful mock order ID
    const randomId = "AU-" + Math.floor(100000 + Math.random() * 900000);
    setReceiptNo(randomId);

    setTimeout(() => {
      setCheckoutStage("receipt");
    }, 2500);
  };

  const resetCartAfterCheckout = () => {
    onClearCart();
    setCheckoutStage("cart");
    setIncludeGiftBox(false);
    setGiftNote("");
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-sm"
            id="cart-backdrop"
          />

          {/* Sliding Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed right-0 top-0 bottom-0 z-50 w-full max-w-md glass-panel shadow-2xl flex flex-col justify-between h-full"
            id="cart-panel"
          >
            {/* STAGE 1 & 2: Active Cart or Processing Payment */}
            {checkoutStage !== "receipt" && (
              <>
                {/* Panel Header */}
                <div className="p-6 border-b border-white/60 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ShoppingBag size={18} className="text-brand-gold" />
                    <span className="font-sans font-medium text-sm tracking-widest uppercase text-neutral-800">
                      Your Shopping Bag
                    </span>
                  </div>
                  <button
                    onClick={onClose}
                    className="p-2 rounded-full hover:bg-white/40 text-neutral-400 hover:text-neutral-700 transition-colors focus:outline-none"
                    id="close-cart-btn"
                  >
                    <X size={18} />
                  </button>
                </div>

                {checkoutStage === "cart" ? (
                  <>
                    {/* Cart list content */}
                    <div className="flex-1 overflow-y-auto p-6 space-y-6">
                      {cart.length === 0 ? (
                        <div className="text-center py-16 flex flex-col items-center">
                          <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center text-neutral-400 mb-4 border border-white/60">
                            <ShoppingBag size={18} />
                          </div>
                          <p className="text-sm font-sans text-neutral-500">Your bag is currently empty.</p>
                          <button
                            onClick={onClose}
                            className="mt-4 text-[10px] font-sans font-bold uppercase tracking-widest text-brand-gold hover:text-brand-gold/80 focus:outline-none"
                            id="continue-shopping-btn"
                          >
                            Browse Collection
                          </button>
                        </div>
                      ) : (
                        <>
                          {/* Cart Items list */}
                          <div className="space-y-4">
                            {cart.map((item) => (
                              <div
                                key={item.product.id}
                                className="flex gap-4 p-4 bg-white/25 backdrop-blur-md border border-white/60 rounded-2xl relative text-left"
                                id={`cart-item-${item.product.id}`}
                              >
                                {/* Thumbnail */}
                                <div className="w-16 h-16 rounded-xl overflow-hidden bg-white/40 border border-white/50 flex-shrink-0">
                                  <img
                                    src={item.product.image}
                                    alt={item.product.name}
                                    className="w-full h-full object-cover"
                                    referrerPolicy="no-referrer"
                                  />
                                </div>

                                {/* Details */}
                                <div className="flex-1 flex flex-col justify-between">
                                  <div>
                                    <h5 className="font-sans text-xs font-semibold text-neutral-800 uppercase tracking-wide leading-none mb-1">
                                      {item.product.name}
                                    </h5>
                                    <span className="block text-[9px] font-sans text-neutral-400 uppercase tracking-widest">
                                      {item.product.origin}
                                    </span>
                                  </div>

                                  <div className="flex items-center justify-between mt-2">
                                    {/* Quantities editor */}
                                    <div className="flex items-center border border-white/60 rounded-full py-1 px-2.5 bg-white/40 backdrop-blur-sm">
                                      <button
                                        onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                                        className="p-1 text-neutral-400 hover:text-neutral-700 transition-colors focus:outline-none"
                                        id={`minus-qty-${item.product.id}`}
                                      >
                                        <Minus size={10} />
                                      </button>
                                      <span className="text-xs font-sans font-medium px-2.5 text-neutral-700">
                                        {item.quantity}
                                      </span>
                                      <button
                                        onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                                        className="p-1 text-neutral-400 hover:text-neutral-700 transition-colors focus:outline-none"
                                        id={`plus-qty-${item.product.id}`}
                                      >
                                        <Plus size={10} />
                                      </button>
                                    </div>

                                    {/* Subtotal */}
                                    <span className="text-sm font-sans font-medium text-neutral-700">
                                      £{item.product.price * item.quantity}.00
                                    </span>
                                  </div>
                                </div>

                                {/* Delete item */}
                                <button
                                  onClick={() => onRemoveItem(item.product.id)}
                                  className="absolute top-4 right-4 text-neutral-300 hover:text-red-500 transition-colors focus:outline-none"
                                  id={`remove-${item.product.id}`}
                                >
                                  <Trash2 size={13} />
                                </button>
                              </div>
                            ))}
                          </div>

                          {/* Premium Wooden Box Box Selector */}
                          <div className="bg-white/25 backdrop-blur-md border border-white/60 p-5 rounded-2xl text-left space-y-3">
                            <label className="flex items-center gap-3 cursor-pointer select-none">
                              <input
                                type="checkbox"
                                checked={includeGiftBox}
                                onChange={(e) => setIncludeGiftBox(e.target.checked)}
                                className="w-4 h-4 text-brand-gold border-white/60 rounded focus:ring-brand-gold"
                                id="giftbox-checkbox"
                              />
                              <div className="flex items-center gap-2 text-neutral-800">
                                <Gift size={16} className="text-brand-gold flex-shrink-0" />
                                <span className="text-xs font-sans font-medium">
                                  Oak Presentation Gift Box (+£15.00)
                                </span>
                              </div>
                            </label>
                            <p className="text-[10px] font-sans text-neutral-400 leading-normal pl-7">
                              A hand-crafted English oak slide-top presentation box with brass joinery and deep wood shaving protection.
                            </p>

                            {includeGiftBox && (
                              <div className="pl-7 pt-2">
                                <textarea
                                  placeholder="Type a custom message to engrave on the brass plaque closure..."
                                  value={giftNote}
                                  onChange={(e) => setGiftNote(e.target.value)}
                                  className="w-full bg-white/30 border border-white/60 rounded-xl p-3 text-xs font-sans text-neutral-700 focus:outline-none focus:border-brand-gold shadow-inner h-16"
                                  id="gift-note-textarea"
                                />
                              </div>
                            )}
                          </div>
                        </>
                      )}
                    </div>

                    {/* Summary Calculations Footer */}
                    {cart.length > 0 && (
                      <div className="bg-white/30 backdrop-blur-md p-6 border-t border-white/60 space-y-4">
                        <div className="space-y-2 text-left">
                          <div className="flex justify-between text-xs font-sans text-neutral-500">
                            <span>Subtotal</span>
                            <span>£{itemsPrice}.00</span>
                          </div>
                          {includeGiftBox && (
                            <div className="flex justify-between text-xs font-sans text-neutral-500">
                              <span>Oak Presentation Cases</span>
                              <span>£15.00</span>
                            </div>
                          )}
                          <div className="flex justify-between text-xs font-sans text-neutral-500">
                            <span className="flex items-center gap-1">
                              <Truck size={12} /> Shipping (Carbon-Neutral)
                            </span>
                            <span>{shippingPrice === 0 ? "Complimentary" : `£${shippingPrice.toFixed(2)}`}</span>
                          </div>
                          <div className="flex justify-between text-sm font-sans font-medium text-neutral-800 pt-2 border-t border-dashed border-white/40">
                            <span>Total Acquisition Price</span>
                            <span>£{totalPrice}.00</span>
                          </div>
                        </div>

                        <button
                          onClick={handleCheckout}
                          className="w-full py-4 bg-neutral-900 text-neutral-50 text-xs font-sans tracking-widest uppercase font-semibold rounded-full hover:bg-neutral-800 transition-all shadow-md flex items-center justify-center gap-2 focus:outline-none"
                          id="checkout-btn"
                        >
                          <CreditCard size={14} />
                          <span>Aquire and Checkout</span>
                        </button>
                      </div>
                    )}
                  </>
                ) : (
                  /* PAYMENT PROCESSING LOADER */
                  <div className="flex-1 flex flex-col items-center justify-center p-8 text-center my-auto">
                    <div className="relative w-16 h-16 mb-6">
                      <div className="absolute inset-0 rounded-full border-2 border-dashed border-brand-gold/30 animate-spin" />
                      <div className="absolute inset-2 rounded-full bg-brand-gold/10 flex items-center justify-center">
                        <RefreshCw className="text-brand-gold animate-spin" size={20} />
                      </div>
                    </div>
                    <span className="text-[10px] font-sans text-brand-gold font-semibold tracking-widest uppercase animate-pulse mb-2">
                      Securing transaction ledger
                    </span>
                    <p className="text-xs font-sans text-neutral-400 max-w-xs leading-relaxed">
                      Securing organic agricultural compliance certificates and auditing payment vault routing...
                    </p>
                  </div>
                )}
              </>
            )}

            {/* STAGE 3: ORDER CONFIRMED RECEIPT SCREEN */}
            {checkoutStage === "receipt" && (
              <div className="flex flex-col h-full justify-between p-8 text-left">
                {/* Branding indicator */}
                <div className="border-b border-white/60 pb-5 mb-6 text-center">
                  <div className="w-12 h-12 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold mx-auto mb-4 border border-brand-gold/30">
                    <ShieldCheck size={22} />
                  </div>
                  <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                    Acquisition Complete
                  </span>
                  <h4 className="text-2xl font-sans text-neutral-800 font-light leading-none">
                    Order Confirmed
                  </h4>
                </div>

                {/* Receipt Details block */}
                <div className="flex-1 space-y-6">
                  <p className="text-xs font-sans text-neutral-500 leading-relaxed">
                    Thank you for your purchase from Aureum Apiary. Your order has been securely registered in our block-ledger. A traceable confirmation card has been dispatched to your email address.
                  </p>

                  <div className="space-y-3 bg-white/20 border border-white/40 p-5 rounded-2xl text-xs font-sans text-neutral-600">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Order Reference:</span>
                      <span className="font-medium text-neutral-800 tracking-wider font-sans">{receiptNo}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Acquisition Total:</span>
                      <span className="font-semibold text-neutral-800 font-sans">£{totalPrice}.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Shipping Mode:</span>
                      <span className="font-medium text-neutral-800">Emission-Neutral Royal Mail Spec</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Estimated Arrival:</span>
                      <span className="font-medium text-neutral-800">48-72 Hours (Express)</span>
                    </div>
                  </div>

                  {includeGiftBox && (
                    <div className="border border-white/60 p-4 rounded-xl text-[11px] font-sans text-neutral-500 bg-white/20">
                      <span className="font-semibold text-neutral-700 block mb-1">
                        🎁 Engraved Brass plaque closures:
                      </span>
                      "{giftNote || "No message requested."}"
                    </div>
                  )}
                </div>

                {/* Reset button */}
                <div className="pt-6 border-t border-white/60">
                  <button
                    onClick={resetCartAfterCheckout}
                    className="w-full py-4 bg-neutral-900 text-neutral-50 text-xs font-sans tracking-widest uppercase font-semibold rounded-full hover:bg-neutral-800 transition-all shadow-sm focus:outline-none"
                    id="finish-checkout-btn"
                  >
                    Continue Journey
                  </button>
                </div>
              </div>
            )}

          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
