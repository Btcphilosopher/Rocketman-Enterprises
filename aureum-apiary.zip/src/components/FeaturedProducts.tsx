import React, { useState } from "react";
import { Plus, Eye, Star, Sliders, MapPin, Sparkles, X, ShoppingBag } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { HoneyProduct } from "../types";
import { HONEY_PRODUCTS } from "../data";

interface FeaturedProductsProps {
  onAddToCart: (product: HoneyProduct) => void;
}

export default function FeaturedProducts({ onAddToCart }: FeaturedProductsProps) {
  const [selectedProduct, setSelectedProduct] = useState<HoneyProduct | null>(null);
  const [activeTab, setActiveTab] = useState<"story" | "scientific">("story");

  return (
    <section id="shop" className="py-24 bg-transparent px-4 md:px-8 max-w-7xl mx-auto">
      
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase">
          Curated Collection
        </span>
        <h2 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-3 mb-4">
          Nectar, <span className="font-serif italic font-normal text-brand-gold">Perfected.</span>
        </h2>
        <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed">
          Six distinct flavor profiles gathered with low-intervention precision. Hand-numbered, certified raw, and curated like fine botanical perfume.
        </p>
      </div>

      {/* Product Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12" id="products-grid">
        {HONEY_PRODUCTS.map((product) => (
          <motion.div
            key={product.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8 }}
            className="group relative glass-panel rounded-[2rem] p-6 shadow-sm hover:shadow-xl hover:bg-white/55 hover:border-white/80 transition-all duration-500"
            id={`product-card-${product.id}`}
          >
            {/* Dynamic Status / Badge */}
            {product.status && (
              <div className="absolute top-6 left-6 z-10 px-3 py-1 bg-neutral-900/90 text-neutral-50 rounded-full text-[9px] font-sans font-medium tracking-widest uppercase">
                {product.status}
              </div>
            )}

            {/* Product Image Frame */}
            <div className="relative aspect-square w-full rounded-2xl overflow-hidden mb-6 bg-white/60 border border-white/80 flex items-center justify-center">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover select-none pointer-events-none transition-transform duration-1000 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              
              {/* Image Glass Overlay for Hover Action */}
              <div className="absolute inset-0 bg-neutral-950/15 opacity-0 group-hover:opacity-100 backdrop-blur-[2px] transition-all flex items-center justify-center gap-4">
                <button
                  onClick={() => {
                    setSelectedProduct(product);
                    setActiveTab("story");
                  }}
                  className="w-10 h-10 rounded-full bg-white text-neutral-800 flex items-center justify-center shadow-md hover:scale-110 hover:bg-neutral-50 transition-all focus:outline-none"
                  title="Quick View"
                  id={`quickview-${product.id}`}
                >
                  <Eye size={16} />
                </button>
                <button
                  onClick={() => onAddToCart(product)}
                  className="w-10 h-10 rounded-full bg-brand-gold text-white flex items-center justify-center shadow-md hover:scale-110 hover:bg-brand-gold/90 transition-all focus:outline-none"
                  title="Add to Cart"
                  id={`add-to-cart-${product.id}`}
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>

            {/* Card Information */}
            <div className="flex flex-col text-left">
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-1.5 text-neutral-400">
                  <MapPin size={12} />
                  <span className="text-[10px] font-sans tracking-wider uppercase">
                    {product.origin}
                  </span>
                </div>
                <div className="flex items-center gap-1 text-brand-gold">
                  <Star size={11} fill="currentColor" />
                  <span className="text-[10px] font-sans font-semibold text-neutral-600">
                    {product.rating}
                  </span>
                </div>
              </div>

              <h3 className="font-sans text-xl font-light text-neutral-800 tracking-tight group-hover:text-brand-gold transition-colors">
                {product.name}
              </h3>
              
              <p className="text-[11px] font-sans text-neutral-400 tracking-wide mt-1.5 line-clamp-2">
                {product.description}
              </p>

              {/* Price & Action Row */}
              <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/60">
                <div>
                  <span className="text-[9px] font-sans text-neutral-400 uppercase tracking-widest block leading-none mb-1">
                    Signature Jar
                  </span>
                  <span className="font-sans text-lg text-neutral-800 font-medium">
                    £{product.price}.00
                  </span>
                </div>
                <button
                  onClick={() => onAddToCart(product)}
                  className="px-5 py-2.5 bg-neutral-900 text-neutral-50 text-[10px] font-sans tracking-widest uppercase font-medium rounded-full hover:bg-neutral-800 hover:scale-102 transition-all shadow-sm focus:outline-none"
                  id={`add-btn-${product.id}`}
                >
                  Add To Cart
                </button>
              </div>
            </div>

          </motion.div>
        ))}
      </div>

      {/* QUICK VIEW DETAILS MODAL */}
      <AnimatePresence>
        {selectedProduct && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-md flex items-center justify-center p-4"
            id="quickview-modal"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.6 }}
              className="glass-card-dense rounded-[2.5rem] shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto relative"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedProduct(null)}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/50 text-neutral-400 hover:text-neutral-700 transition-colors z-20 focus:outline-none"
                id="close-modal-btn"
              >
                <X size={20} />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 p-8 md:p-12">
                
                {/* Left Side: Product Shot */}
                <div className="md:col-span-5 flex flex-col justify-center items-center">
                  <div className="aspect-square w-full rounded-2xl overflow-hidden bg-white/40 border border-white/60 p-4">
                    <img
                      src={selectedProduct.image}
                      alt={selectedProduct.name}
                      className="w-full h-full object-cover rounded-xl select-none"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  
                  {/* Small Info Badges */}
                  <div className="grid grid-cols-2 gap-3 w-full mt-4">
                    <div className="bg-white/30 p-3 rounded-xl border border-white/50">
                      <span className="block text-[8px] font-sans text-neutral-400 uppercase tracking-widest mb-1">
                        Batch Number
                      </span>
                      <span className="block text-xs font-sans text-neutral-700 font-medium">
                        {selectedProduct.batchNo}
                      </span>
                    </div>
                    <div className="bg-white/30 p-3 rounded-xl border border-white/50">
                      <span className="block text-[8px] font-sans text-neutral-400 uppercase tracking-widest mb-1">
                        Elevation
                      </span>
                      <span className="block text-xs font-sans text-neutral-700 font-medium">
                        {selectedProduct.elevation}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right Side: Narrative and Technical Tabs */}
                <div className="md:col-span-7 flex flex-col text-left">
                  <span className="text-[10px] font-sans font-semibold text-brand-gold tracking-[0.2em] uppercase flex items-center gap-1.5 mb-2">
                    <Sparkles size={11} /> {selectedProduct.origin}
                  </span>
                  
                  <h3 className="text-3xl font-sans tracking-tight text-neutral-800 font-light leading-none mb-4">
                    {selectedProduct.name}
                  </h3>

                  {/* Rating summary */}
                  <div className="flex items-center gap-1 text-brand-gold mb-6">
                    <Star size={14} fill="currentColor" />
                    <Star size={14} fill="currentColor" />
                    <Star size={14} fill="currentColor" />
                    <Star size={14} fill="currentColor" />
                    <Star size={14} fill="currentColor" />
                    <span className="text-xs font-sans text-neutral-500 ml-2">
                      5.0 ({selectedProduct.reviewsCount} verified connoisseurs)
                    </span>
                  </div>

                  {/* Tab Selectors */}
                  <div className="flex border-b border-neutral-100 mb-6">
                    <button
                      onClick={() => setActiveTab("story")}
                      className={`pb-3 text-xs font-sans tracking-widest uppercase relative font-medium mr-8 focus:outline-none ${
                        activeTab === "story" ? "text-neutral-900" : "text-neutral-400"
                      }`}
                      id="tab-story-btn"
                    >
                      Botanical Story
                      {activeTab === "story" && (
                        <motion.span
                          layoutId="modal-tab-line"
                          className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-gold"
                        />
                      )}
                    </button>
                    <button
                      onClick={() => setActiveTab("scientific")}
                      className={`pb-3 text-xs font-sans tracking-widest uppercase relative font-medium focus:outline-none ${
                        activeTab === "scientific" ? "text-neutral-900" : "text-neutral-400"
                      }`}
                      id="tab-scientific-btn"
                    >
                      Scientific Breakdown
                      {activeTab === "scientific" && (
                        <motion.span
                          layoutId="modal-tab-line"
                          className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-gold"
                        />
                      )}
                    </button>
                  </div>

                  {/* Tab Contents */}
                  <div className="min-h-[160px]">
                    <AnimatePresence mode="wait">
                      {activeTab === "story" ? (
                        <motion.div
                          key="story"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          transition={{ duration: 0.3 }}
                        >
                          <p className="text-sm font-sans text-neutral-600 tracking-wide leading-relaxed">
                            {selectedProduct.longDescription}
                          </p>
                          <div className="flex flex-wrap gap-2 mt-6">
                            {selectedProduct.floralNotes.map((note) => (
                              <span
                                key={note}
                                className="px-3 py-1 bg-brand-gold/15 border border-brand-gold/30 text-brand-gold text-[10px] font-sans font-medium tracking-wider uppercase rounded-full"
                              >
                                {note}
                              </span>
                            ))}
                          </div>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="scientific"
                          initial={{ opacity: 0, y: 5 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -5 }}
                          transition={{ duration: 0.3 }}
                          className="space-y-4"
                        >
                          <div>
                            <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-2">
                              Floral Nectar Abundance
                            </span>
                            <div className="space-y-2">
                              {selectedProduct.floralComposition.map((comp) => (
                                <div key={comp.species} className="text-xs">
                                  <div className="flex justify-between font-sans text-neutral-700 mb-1">
                                    <span className="italic">{comp.species}</span>
                                    <span className="font-semibold">{comp.percentage}%</span>
                                  </div>
                                  <div className="w-full h-1 bg-neutral-150 rounded-full overflow-hidden">
                                    <div
                                      className="h-full bg-brand-gold"
                                      style={{ width: `${comp.percentage}%` }}
                                    />
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 pt-2">
                            <div>
                              <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                                Hive Location
                              </span>
                              <span className="text-xs font-sans text-neutral-600">
                                {selectedProduct.hiveCoordinates}
                              </span>
                            </div>
                            <div>
                              <span className="text-[10px] font-sans text-neutral-400 tracking-widest uppercase block mb-1">
                                Beekeeping Curator
                              </span>
                              <span className="text-xs font-sans text-neutral-600">
                                {selectedProduct.beekeeperName}
                              </span>
                            </div>
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Add To Cart block */}
                  <div className="mt-8 pt-6 border-t border-white/60 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-sans text-neutral-400 uppercase tracking-widest block leading-none mb-1">
                        Price Per Jar
                      </span>
                      <span className="font-sans text-2xl text-neutral-800 font-medium">
                        £{selectedProduct.price}.00
                      </span>
                    </div>
                    
                    <button
                      onClick={() => {
                        onAddToCart(selectedProduct);
                        setSelectedProduct(null);
                      }}
                      className="px-8 py-3.5 bg-neutral-900 text-neutral-50 text-xs font-sans tracking-widest uppercase font-semibold rounded-full hover:bg-neutral-800 transition-all shadow-md flex items-center gap-2 focus:outline-none"
                      id="modal-add-to-cart-btn"
                    >
                      <ShoppingBag size={14} />
                      <span>Add to Shopping Bag</span>
                    </button>
                  </div>

                </div>

              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}
