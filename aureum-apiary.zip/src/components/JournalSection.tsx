import React, { useState } from "react";
import { BookOpen, Calendar, Clock, X, Sparkles, ArrowRight } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { JOURNAL_ENTRIES } from "../data";
import { JournalEntry } from "../types";

export default function JournalSection() {
  const [selectedArticle, setSelectedArticle] = useState<JournalEntry | null>(null);

  return (
    <section id="journal" className="py-24 bg-transparent border-t border-neutral-50 px-4 md:px-8 max-w-7xl mx-auto">
      
      {/* Section Header */}
      <div className="text-center max-w-2xl mx-auto mb-16">
        <span className="text-[10px] font-sans font-semibold tracking-[0.25em] text-brand-gold uppercase flex items-center justify-center gap-1.5">
          <BookOpen size={12} /> Aureum Magazine
        </span>
        <h2 className="text-3xl md:text-5xl font-sans tracking-tight text-neutral-800 leading-tight font-light mt-3 mb-4">
          The Botanical <span className="font-serif italic font-normal text-brand-gold">Chronicle.</span>
        </h2>
        <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed">
          Explore beekeeping journals, crop technology, floral preservation studies, and luxury culinary pairings curated directly by our agronomy desk.
        </p>
      </div>

      {/* Journal Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12" id="journal-grid">
        {JOURNAL_ENTRIES.map((entry) => (
          <motion.article
            key={entry.id}
            initial={{ opacity: 0, y: 15 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="group text-left cursor-pointer"
            onClick={() => setSelectedArticle(entry)}
            id={`journal-entry-${entry.id}`}
          >
            {/* Elegant Image Container */}
            <div className="aspect-[16/10] w-full rounded-2xl overflow-hidden mb-6 border border-white/60 bg-white/40 relative shadow-sm">
              <img
                src={entry.image}
                alt={entry.title}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
              />
              <div className="absolute top-4 left-4 px-3 py-1 bg-white/80 backdrop-blur-md border border-white/60 text-[9px] font-sans font-medium tracking-widest text-neutral-800 uppercase rounded-full shadow-sm">
                {entry.category}
              </div>
            </div>

            {/* Meta Tags */}
            <div className="flex items-center gap-4 text-[10px] font-sans text-neutral-400 uppercase tracking-widest mb-3">
              <span className="flex items-center gap-1">
                <Calendar size={11} /> {entry.date}
              </span>
              <span className="flex items-center gap-1">
                <Clock size={11} /> {entry.readTime}
              </span>
            </div>

            {/* Heading and Excerpt */}
            <h3 className="text-lg font-sans font-medium text-neutral-800 tracking-tight group-hover:text-brand-gold transition-colors leading-snug mb-3">
              {entry.title}
            </h3>
            <p className="text-xs font-sans text-neutral-500 leading-relaxed line-clamp-3 mb-4">
              {entry.excerpt}
            </p>

            {/* Read action */}
            <div className="inline-flex items-center gap-1 text-[10px] font-sans text-neutral-800 font-bold uppercase tracking-widest group-hover:text-brand-gold transition-colors">
              <span>Read Journal Entry</span>
              <ArrowRight size={10} className="transition-transform group-hover:translate-x-1" />
            </div>

          </motion.article>
        ))}
      </div>

      {/* ARTICLE READER MODAL */}
      <AnimatePresence>
        {selectedArticle && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-neutral-900/40 backdrop-blur-md flex items-center justify-center p-4"
            id="article-reader-modal"
          >
            <motion.div
              initial={{ scale: 0.96, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.96, opacity: 0, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
              className="glass-card-dense rounded-[2.5rem] shadow-2xl max-w-3xl w-full max-h-[85vh] overflow-y-auto relative p-6 md:p-10"
            >
              {/* Close Button */}
              <button
                onClick={() => setSelectedArticle(null)}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-white/50 text-neutral-400 hover:text-neutral-700 transition-colors z-20 focus:outline-none"
                id="close-article-btn"
              >
                <X size={20} />
              </button>

              <div className="text-left mt-6">
                
                {/* Meta details */}
                <div className="flex items-center gap-4 text-[10px] font-sans text-neutral-400 uppercase tracking-widest mb-4">
                  <span className="px-3 py-1 bg-brand-gold/15 border border-brand-gold/30 text-brand-gold rounded-full font-medium">
                    {selectedArticle.category}
                  </span>
                  <span>{selectedArticle.date}</span>
                  <span>•</span>
                  <span>{selectedArticle.readTime}</span>
                </div>

                <h3 className="text-3xl font-sans tracking-tight text-neutral-800 font-light mb-6">
                  {selectedArticle.title}
                </h3>

                {/* Banner Shot */}
                <div className="aspect-[16/9] w-full rounded-2xl overflow-hidden border border-white/60 mb-8 shadow-sm">
                  <img
                    src={selectedArticle.image}
                    alt={selectedArticle.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Article Body */}
                <div className="prose prose-neutral max-w-none">
                  <p className="text-sm font-sans font-medium text-neutral-700 tracking-wide leading-relaxed mb-6">
                    {selectedArticle.excerpt}
                  </p>
                  <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed">
                    {selectedArticle.content}
                  </p>
                  <p className="text-sm font-sans text-neutral-500 tracking-wide leading-relaxed mt-4">
                    Our team regularly updates our digital chronicle with deep insights into bio-dynamics, precision IoT honey extraction, and recipes designed to pair beautifully with organic, local English countryside produce.
                  </p>
                </div>

                {/* Bottom author footer */}
                <div className="border-t border-white/60 mt-10 pt-6 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-brand-gold/15 flex items-center justify-center text-brand-gold font-bold text-xs">
                      AU
                    </div>
                    <div>
                      <span className="block text-xs font-sans font-medium text-neutral-800 leading-none">
                        Aureum Editorial Desk
                      </span>
                      <span className="block text-[9px] font-sans text-neutral-400 mt-0.5 uppercase tracking-wider">
                        Published London Office
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedArticle(null)}
                    className="px-5 py-2.5 glass-card-button text-neutral-600 rounded-full text-[10px] font-sans tracking-widest uppercase transition-all focus:outline-none"
                    id="back-articles-btn"
                  >
                    Back to Articles
                  </button>
                </div>

              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </section>
  );
}
