import React, { useState } from "react";
import { ShoppingBag, Search, User, Menu, X, Sparkles, Navigation } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { CartItem } from "../types";

interface NavbarProps {
  cart: CartItem[];
  onOpenCart: () => void;
  onNavigate: (sectionId: string) => void;
  activeSection: string;
}

export default function Navbar({ cart, onOpenCart, onNavigate, activeSection }: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  const menuItems = [
    { label: "Shop Honey", target: "shop" },
    { label: "Our Origins", target: "origins" },
    { label: "Traceability", target: "traceability" },
    { label: "Sommelier AI", target: "sommelier" },
    { label: "Sustainability", target: "sustainability" },
    { label: "Journal", target: "journal" }
  ];

  return (
    <>
      <motion.header
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="fixed top-6 left-0 right-0 z-50 px-4 md:px-8 max-w-7xl mx-auto"
        id="navbar"
      >
        <div className="glass-header rounded-full py-4 px-6 md:px-8 shadow-sm flex items-center justify-between transition-all hover:bg-white/55 hover:border-white/85 hover:shadow-md">
          {/* Logo / Brand Signature */}
          <button
            onClick={() => onNavigate("hero")}
            className="flex items-center gap-2 group text-left focus:outline-none"
            id="nav-logo-btn"
          >
            <div className="w-8 h-8 rounded-full bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center transition-all group-hover:scale-105 group-hover:bg-brand-gold/20">
              <span className="text-brand-gold font-semibold text-xs tracking-widest">AU</span>
            </div>
            <div>
              <span className="block font-sans font-medium text-sm tracking-[0.25em] text-neutral-800 uppercase leading-none">
                AUREUM APIARY
              </span>
              <span className="block text-[8px] font-sans text-neutral-400 tracking-[0.15em] uppercase mt-0.5 font-light">
                Pure • British • Timeless
              </span>
            </div>
          </button>

          {/* Center Links (Desktop) */}
          <nav className="hidden md:flex items-center gap-8">
            {menuItems.map((item) => {
              const isActive = activeSection === item.target;
              return (
                <button
                  key={item.target}
                  onClick={() => onNavigate(item.target)}
                  className={`text-xs font-sans tracking-[0.1em] uppercase relative py-1 transition-colors hover:text-neutral-900 focus:outline-none ${
                    isActive ? "text-neutral-900 font-medium" : "text-neutral-500 font-normal"
                  }`}
                  id={`nav-link-${item.target}`}
                >
                  {item.label}
                  {isActive && (
                    <motion.span
                      layoutId="nav-underline"
                      className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-gold"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Right Action Icons */}
          <div className="flex items-center gap-4">
            {/* Search toggler */}
            <div className="relative">
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className="p-2 text-neutral-500 hover:text-neutral-800 transition-colors rounded-full hover:bg-white/40"
                aria-label="Search"
                id="search-toggle-btn"
              >
                <Search size={18} />
              </button>
              <AnimatePresence>
                {searchOpen && (
                  <motion.div
                    initial={{ width: 0, opacity: 0 }}
                    animate={{ width: 200, opacity: 1 }}
                    exit={{ width: 0, opacity: 0 }}
                    className="absolute right-10 top-0.5 bg-white/80 backdrop-blur-md border border-white/60 rounded-full px-3 py-1 text-xs"
                  >
                    <input
                      type="text"
                      placeholder="Search collection..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-transparent border-none outline-none text-neutral-700 font-sans"
                      autoFocus
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Profile (Aesthetic) */}
            <button
              className="p-2 text-neutral-500 hover:text-neutral-800 transition-colors rounded-full hover:bg-white/40 hidden sm:block"
              aria-label="Account"
              id="account-btn"
            >
              <User size={18} />
            </button>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative py-2 px-3 bg-neutral-900 text-neutral-50 hover:bg-neutral-800 transition-all rounded-full flex items-center gap-2 shadow-sm shadow-black/10 focus:outline-none"
              id="cart-toggle-btn"
            >
              <ShoppingBag size={15} />
              <span className="text-[10px] font-medium font-sans tracking-widest uppercase">
                Cart
              </span>
              <AnimatePresence mode="wait">
                <motion.span
                  key={cartCount}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="bg-brand-gold text-neutral-900 font-sans font-bold text-[9px] w-4 h-4 rounded-full flex items-center justify-center shadow-sm"
                >
                  {cartCount}
                </motion.span>
              </AnimatePresence>
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-neutral-600 hover:text-neutral-800"
              aria-label="Toggle menu"
              id="mobile-menu-btn"
            >
              {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </motion.header>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4 }}
            className="fixed inset-x-0 top-24 z-40 mx-4 md:hidden"
            id="mobile-nav-overlay"
          >
            <div className="glass-card-dense rounded-3xl p-6 shadow-xl flex flex-col gap-4">
              {menuItems.map((item) => (
                <button
                  key={item.target}
                  onClick={() => {
                    onNavigate(item.target);
                    setIsMobileMenuOpen(false);
                  }}
                  className="text-sm font-sans tracking-[0.1em] uppercase py-3 text-left border-b border-neutral-50 text-neutral-600 hover:text-neutral-900 hover:pl-2 transition-all flex items-center justify-between"
                  id={`mobile-nav-link-${item.target}`}
                >
                  <span>{item.label}</span>
                  <Navigation size={12} className="text-neutral-400 rotate-90" />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
