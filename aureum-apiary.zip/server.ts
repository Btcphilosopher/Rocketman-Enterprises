import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Initialize Gemini Client Lazily/Safely
let ai: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!ai) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY environment variable is not configured in Secrets.");
    }
    ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return ai;
}

// Available Honeys for Gemini Reference
const HONEY_CATALOG_SUMMARY = [
  {
    id: "wildflower",
    name: "Wildflower Honey",
    profile: "Classic, highly sweet, versatile, balanced floral nectar, soft chamomile and lavender undertones."
  },
  {
    id: "heather",
    name: "Heather Honey",
    profile: "Bold, rich, bitter-sweet, aromatic woody peat, deep warmth, perfect for dark beers, cheeses, or robust porridge."
  },
  {
    id: "acacia",
    name: "Acacia Honey",
    profile: "Delicate, water-white, silky, low-acidity, light sweetness with subtle hints of vanilla and pear blossom. Ideal for drizzling on fresh yogurt or white teas."
  },
  {
    id: "lime",
    name: "Lime Blossom Honey",
    profile: "Vibrant green-gold, refreshing, citrusy with a distinctive minty-fresh cooling finish. Excellent in green or mint teas, or paired with goat cheese."
  },
  {
    id: "limited-reserve",
    name: "Limited Reserve (Oak Forest)",
    profile: "Rare dark forest honeydew from Berkshire Oak forests. Deeply intense, woody, malty, caramelized, and exceptionally premium."
  },
  {
    id: "seasonal-summer",
    name: "Seasonal Collection (Summer Solstice)",
    profile: "Fruit-orchard harvest with notes of wild strawberry blossom, clover, and warm sunlit peach. Bright, highly aromatic, and elegant."
  }
];

// 1. API: Honey Sommelier AI Matching endpoint
app.post("/api/sommelier", async (req, res) => {
  try {
    const { tastePreference, sweetnessPreferred, primaryUsage, styleMood } = req.body;

    if (!tastePreference || !sweetnessPreferred || !primaryUsage) {
      return res.status(400).json({ error: "Missing required preferences fields." });
    }

    let client;
    try {
      client = getGeminiClient();
    } catch (err: any) {
      console.warn("Gemini client initialization warning:", err.message);
      // Fallback response for missing API key so the UX doesn't crash
      return res.json({
        recommendedHoneyId: "wildflower",
        expertExplanation: "Welcome to Aureum Apiary. To unlock our fully personalized, AI-powered tasting recommendations, please configure your GEMINI_API_KEY in the Secrets tab. In the meantime, based on our traditional beekeeping wisdom, we highly recommend our exquisite Somerset Wildflower Honey—an exceptional classic with balanced floral warmth.",
        tastingNotes: ["Balanced floral nectar", "Chamomile warmth", "Classic clover sweetness"],
        suggestedPairing: "English scones with clotted cream, paired with Earl Grey tea.",
        culinaryUsage: "An excellent all-rounder, perfect for morning toasts, baking, or general tea sweetening."
      });
    }

    const prompt = `
      You are the Master Honey Sommelier at Aureum Apiary, a hypermodern, high-end, luxury British honey house.
      You guide customers using a playful, optimistic, clean, slightly charming and twee, yet extremely refined "modern British luxury" voice (similar to a premium brand like Aesop, Monocle, or COS).

      A customer is seeking their perfect honey. Here are their sensory preferences:
      - Preferred Taste Profile: "${tastePreference}"
      - Sweetness Level: "${sweetnessPreferred}"
      - Primary Intended Use: "${primaryUsage}"
      - Mood or Aesthetic Vibe: "${styleMood || "Bright & Optimistic"}"

      Analyze their preferences and recommend EXACTLY ONE honey from our luxury catalog:
      ${JSON.stringify(HONEY_CATALOG_SUMMARY, null, 2)}

      Your recommendation MUST be returned in valid JSON format matching this exact schema:
      {
        "recommendedHoneyId": "one of the IDs from the catalog",
        "expertExplanation": "A beautifully written, highly engaging explanation of why this honey perfectly matches their taste buds and mood, using sophisticated and poetic British culinary terms. Keep it to 3-4 sentences.",
        "tastingNotes": ["An array of 3 distinct, poetic tasting sensory notes, e.g. 'Hints of crushed vanilla pod', 'Vibrant peppermint finish'"],
        "suggestedPairing": "A highly precise, luxurious culinary pairing suggestion, e.g. 'Somerset Montgomery Cheddar and visual crisp pear slices'",
        "culinaryUsage": "How they should serve and enjoy this honey to highlight its unique scientific and flavor properties."
      }
    `;

    const response = await client.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            recommendedHoneyId: { type: Type.STRING },
            expertExplanation: { type: Type.STRING },
            tastingNotes: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            suggestedPairing: { type: Type.STRING },
            culinaryUsage: { type: Type.STRING }
          },
          required: ["recommendedHoneyId", "expertExplanation", "tastingNotes", "suggestedPairing", "culinaryUsage"]
        }
      }
    });

    const textOutput = response.text;
    if (!textOutput) {
      throw new Error("No text returned from Gemini API");
    }

    const recommendationData = JSON.parse(textOutput.trim());
    res.json(recommendationData);
  } catch (error: any) {
    console.error("Sommelier match error:", error);
    res.status(500).json({ error: error.message || "Failed to match honey recommendation." });
  }
});

// 2. Health check route
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

// 3. Vite development / production middleware setup
async function setupVite() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting server in development mode with Vite HMR middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting server in production mode...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Luxury Full-Stack Server running at http://localhost:${PORT}`);
  });
}

setupVite().catch((err) => {
  console.error("Vite server setup failed:", err);
});
